
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/inert-spacer-inline-r10/main-options:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100842e40 <_js_json_stringify_full>:
100842e40:     	sub	sp, sp, #0x110
100842e44:     	stp	d9, d8, [sp, #0xa0]
100842e48:     	stp	x28, x27, [sp, #0xb0]
100842e4c:     	stp	x26, x25, [sp, #0xc0]
100842e50:     	stp	x24, x23, [sp, #0xd0]
100842e54:     	stp	x22, x21, [sp, #0xe0]
100842e58:     	stp	x20, x19, [sp, #0xf0]
100842e5c:     	stp	x29, x30, [sp, #0x100]
100842e60:     	add	x29, sp, #0x100
100842e64:     	mov.16b	v9, v2
100842e68:     	mov.16b	v8, v0
100842e6c:     	mov	x26, #0x1               ; =1
100842e70:     	movk	x26, #0x7ffc, lsl #48
100842e74:     	fmov	x19, d8
100842e78:     	fmov	x20, d1
100842e7c:     	fmov	x23, d9
100842e80:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100842e84:     	add	x9, x23, x8
100842e88:     	add	x27, x20, x8
100842e8c:     	cmp	x9, #0x2
100842e90:     	b.hs	0x100842eac <_js_json_stringify_full+0x6c>
100842e94:     	cmp	x27, #0x2
100842e98:     	b.lo	0x100842ebc <_js_json_stringify_full+0x7c>
100842e9c:     	mov	w21, #0x0               ; =0
100842ea0:     	cmp	x19, x26
100842ea4:     	b.eq	0x10084430c <_js_json_stringify_full+0x14cc>
100842ea8:     	b	0x100843434 <_js_json_stringify_full+0x5f4>
100842eac:     	add	x8, x26, #0x2
100842eb0:     	cmp	x23, x8
100842eb4:     	ccmp	x27, #0x2, #0x2, eq
100842eb8:     	b.hs	0x100842e9c <_js_json_stringify_full+0x5c>
100842ebc:     	mov	x8, #-0x2               ; =-2
100842ec0:     	movk	x8, #0x8003, lsl #48
100842ec4:     	add	x8, x19, x8
100842ec8:     	cmp	x8, #0x3
100842ecc:     	b.hs	0x100842ee0 <_js_json_stringify_full+0xa0>
100842ed0:     	adrp	x9, 0x100c96000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4da0>
100842ed4:     	add	x9, x9, #0x7e8
100842ed8:     	ldr	x21, [x9, x8, lsl #3]
100842edc:     	b	0x100844314 <_js_json_stringify_full+0x14d4>
100842ee0:     	strb	wzr, [sp, #0x3c]
100842ee4:     	str	wzr, [sp, #0x38]
100842ee8:     	and	x8, x19, #0xffff000000000000
100842eec:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100842ef0:     	cmp	x8, x9
100842ef4:     	b.eq	0x100842f68 <_js_json_stringify_full+0x128>
100842ef8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100842efc:     	cmp	x8, x9
100842f00:     	b.ne	0x100843364 <_js_json_stringify_full+0x524>
100842f04:     	ubfx	x10, x19, #40, #8
100842f08:     	cbz	x10, 0x100842f58 <_js_json_stringify_full+0x118>
100842f0c:     	strb	w19, [sp, #0x38]
100842f10:     	cmp	x10, #0x1
100842f14:     	b.eq	0x100842f58 <_js_json_stringify_full+0x118>
100842f18:     	lsr	x9, x19, #8
100842f1c:     	strb	w9, [sp, #0x39]
100842f20:     	cmp	x10, #0x2
100842f24:     	b.eq	0x100842f58 <_js_json_stringify_full+0x118>
100842f28:     	lsr	x9, x19, #16
100842f2c:     	strb	w9, [sp, #0x3a]
100842f30:     	cmp	x10, #0x3
100842f34:     	b.eq	0x100842f58 <_js_json_stringify_full+0x118>
100842f38:     	lsr	x9, x19, #24
100842f3c:     	strb	w9, [sp, #0x3b]
100842f40:     	cmp	x10, #0x4
100842f44:     	b.eq	0x100842f58 <_js_json_stringify_full+0x118>
100842f48:     	lsr	x9, x19, #32
100842f4c:     	strb	w9, [sp, #0x3c]
100842f50:     	cmp	x10, #0x5
100842f54:     	b.ne	0x100844b00 <_js_json_stringify_full+0x1cc0>
100842f58:     	add	x11, sp, #0x38
100842f5c:     	cmp	w10, #0x3
100842f60:     	b.ls	0x100842f80 <_js_json_stringify_full+0x140>
100842f64:     	b	0x100843364 <_js_json_stringify_full+0x524>
100842f68:     	ands	x9, x19, #0xffffffffffff
100842f6c:     	b.eq	0x100843428 <_js_json_stringify_full+0x5e8>
100842f70:     	add	x11, x9, #0x14
100842f74:     	ldr	w10, [x9, #0x4]
100842f78:     	cmp	w10, #0x3
100842f7c:     	b.hi	0x100843364 <_js_json_stringify_full+0x524>
100842f80:     	stur	wzr, [sp, #0x71]
100842f84:     	mov	w9, #0x22               ; =34
100842f88:     	strb	w9, [sp, #0x70]
100842f8c:     	cbz	w10, 0x100842fc4 <_js_json_stringify_full+0x184>
100842f90:     	add	x12, sp, #0x70
100842f94:     	ldrb	w13, [x11]
100842f98:     	sxtb	w15, w13
100842f9c:     	cmp	w13, #0xb
100842fa0:     	b.le	0x100842fcc <_js_json_stringify_full+0x18c>
100842fa4:     	cmp	w13, #0x21
100842fa8:     	b.gt	0x100842fec <_js_json_stringify_full+0x1ac>
100842fac:     	cmp	w13, #0xc
100842fb0:     	b.eq	0x100843020 <_js_json_stringify_full+0x1e0>
100842fb4:     	cmp	w13, #0xd
100842fb8:     	b.ne	0x100842ffc <_js_json_stringify_full+0x1bc>
100842fbc:     	mov	w15, #0x72              ; =114
100842fc0:     	b	0x10084302c <_js_json_stringify_full+0x1ec>
100842fc4:     	mov	w12, #0x1               ; =1
100842fc8:     	b	0x100843054 <_js_json_stringify_full+0x214>
100842fcc:     	cmp	w13, #0x8
100842fd0:     	b.eq	0x100843018 <_js_json_stringify_full+0x1d8>
100842fd4:     	cmp	w13, #0x9
100842fd8:     	b.eq	0x100843028 <_js_json_stringify_full+0x1e8>
100842fdc:     	cmp	w13, #0xa
100842fe0:     	b.ne	0x100842ffc <_js_json_stringify_full+0x1bc>
100842fe4:     	mov	w15, #0x6e              ; =110
100842fe8:     	b	0x10084302c <_js_json_stringify_full+0x1ec>
100842fec:     	cmp	w13, #0x22
100842ff0:     	b.eq	0x10084302c <_js_json_stringify_full+0x1ec>
100842ff4:     	cmp	w13, #0x5c
100842ff8:     	b.eq	0x10084302c <_js_json_stringify_full+0x1ec>
100842ffc:     	cmp	w15, #0x20
100843000:     	b.lt	0x100843364 <_js_json_stringify_full+0x524>
100843004:     	mov	w14, #0x0               ; =0
100843008:     	add	x13, x12, #0x2
10084300c:     	mov	w12, #0x2               ; =2
100843010:     	mov	w16, #0x1               ; =1
100843014:     	b	0x100843044 <_js_json_stringify_full+0x204>
100843018:     	mov	w15, #0x62              ; =98
10084301c:     	b	0x10084302c <_js_json_stringify_full+0x1ec>
100843020:     	mov	w15, #0x66              ; =102
100843024:     	b	0x10084302c <_js_json_stringify_full+0x1ec>
100843028:     	mov	w15, #0x74              ; =116
10084302c:     	add	x13, x12, #0x3
100843030:     	mov	w12, #0x5c              ; =92
100843034:     	strb	w12, [sp, #0x71]
100843038:     	mov	w14, #0x1               ; =1
10084303c:     	mov	w12, #0x3               ; =3
100843040:     	mov	w16, #0x2               ; =2
100843044:     	add	x17, sp, #0x70
100843048:     	strb	w15, [x17, x16]
10084304c:     	cmp	w10, #0x1
100843050:     	b.ne	0x10084308c <_js_json_stringify_full+0x24c>
100843054:     	add	x10, sp, #0x70
100843058:     	strb	w9, [x10, x12]
10084305c:     	add	x8, x12, #0x1
100843060:     	cmp	x12, #0x3
100843064:     	b.hs	0x100843078 <_js_json_stringify_full+0x238>
100843068:     	mov	x13, #0x0               ; =0
10084306c:     	mov	x11, #0x0               ; =0
100843070:     	add	x9, sp, #0x70
100843074:     	b	0x1008432d4 <_js_json_stringify_full+0x494>
100843078:     	cmp	x12, #0xf
10084307c:     	b.hs	0x1008430bc <_js_json_stringify_full+0x27c>
100843080:     	mov	x11, #0x0               ; =0
100843084:     	mov	x13, #0x0               ; =0
100843088:     	b	0x100843230 <_js_json_stringify_full+0x3f0>
10084308c:     	ldrb	w16, [x11, #0x1]
100843090:     	sxtb	w15, w16
100843094:     	cmp	w16, #0xb
100843098:     	b.le	0x100843304 <_js_json_stringify_full+0x4c4>
10084309c:     	cmp	w16, #0x21
1008430a0:     	b.gt	0x100843324 <_js_json_stringify_full+0x4e4>
1008430a4:     	cmp	w16, #0xc
1008430a8:     	b.eq	0x100843354 <_js_json_stringify_full+0x514>
1008430ac:     	cmp	w16, #0xd
1008430b0:     	b.ne	0x100843334 <_js_json_stringify_full+0x4f4>
1008430b4:     	mov	w15, #0x72              ; =114
1008430b8:     	b	0x100843360 <_js_json_stringify_full+0x520>
1008430bc:     	and	x12, x8, #0xc
1008430c0:     	and	x11, x8, #0x10
1008430c4:     	add	x13, sp, #0x70
1008430c8:     	add	x9, x13, x11
1008430cc:     	adrp	x14, 0x100c97000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5da0>
1008430d0:     	ldr	q0, [x14, #0x960]
1008430d4:     	adrp	x14, 0x100c97000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5da0>
1008430d8:     	ldr	q1, [x14, #0x970]
1008430dc:     	adrp	x14, 0x100c97000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5da0>
1008430e0:     	ldr	q2, [x14, #0x980]
1008430e4:     	adrp	x14, 0x100c97000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5da0>
1008430e8:     	ldr	q3, [x14, #0x990]
1008430ec:     	adrp	x14, 0x100c97000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5da0>
1008430f0:     	ldr	q4, [x14, #0x9a0]
1008430f4:     	movi.2d	v5, #0000000000000000
1008430f8:     	adrp	x14, 0x100c97000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5da0>
1008430fc:     	ldr	q6, [x14, #0x9b0]
100843100:     	adrp	x14, 0x100c96000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4da0>
100843104:     	ldr	q7, [x14, #0xad0]
100843108:     	mov	w14, #0x10              ; =16
10084310c:     	movi.2d	v16, #0000000000000000
100843110:     	dup.2d	v17, x14
100843114:     	adrp	x14, 0x100c36000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x335aa>
100843118:     	ldr	q19, [x14, #0x9d0]
10084311c:     	and	x14, x8, #0x10
100843120:     	movi.2d	v20, #0000000000000000
100843124:     	movi.2d	v18, #0000000000000000
100843128:     	movi.2d	v23, #0000000000000000
10084312c:     	movi.2d	v21, #0000000000000000
100843130:     	movi.2d	v24, #0000000000000000
100843134:     	movi.2d	v22, #0000000000000000
100843138:     	ldr	q25, [x13], #0x10
10084313c:     	ushll.8h	v26, v25, #0x0
100843140:     	ushll2.4s	v27, v26, #0x0
100843144:     	ushll2.2d	v28, v27, #0x0
100843148:     	ushll2.8h	v25, v25, #0x0
10084314c:     	ushll.4s	v29, v25, #0x0
100843150:     	ushll2.2d	v30, v29, #0x0
100843154:     	ushll.2d	v29, v29, #0x0
100843158:     	ushll.2d	v27, v27, #0x0
10084315c:     	ushll.4s	v26, v26, #0x0
100843160:     	ushll2.2d	v31, v26, #0x0
100843164:     	ushll2.4s	v25, v25, #0x0
100843168:     	ushll.2d	v8, v25, #0x0
10084316c:     	ushll.2d	v26, v26, #0x0
100843170:     	ushll2.2d	v25, v25, #0x0
100843174:     	shl.2d	v9, v0, #0x3
100843178:     	ushl.2d	v25, v25, v9
10084317c:     	shl.2d	v9, v19, #0x3
100843180:     	ushl.2d	v26, v26, v9
100843184:     	shl.2d	v9, v1, #0x3
100843188:     	ushl.2d	v8, v8, v9
10084318c:     	shl.2d	v9, v7, #0x3
100843190:     	ushl.2d	v31, v31, v9
100843194:     	shl.2d	v9, v6, #0x3
100843198:     	ushl.2d	v27, v27, v9
10084319c:     	shl.2d	v9, v3, #0x3
1008431a0:     	ushl.2d	v29, v29, v9
1008431a4:     	shl.2d	v9, v2, #0x3
1008431a8:     	ushl.2d	v30, v30, v9
1008431ac:     	shl.2d	v9, v4, #0x3
1008431b0:     	ushl.2d	v28, v28, v9
1008431b4:     	orr.16b	v18, v28, v18
1008431b8:     	orr.16b	v21, v30, v21
1008431bc:     	orr.16b	v23, v29, v23
1008431c0:     	orr.16b	v20, v27, v20
1008431c4:     	orr.16b	v5, v31, v5
1008431c8:     	orr.16b	v24, v8, v24
1008431cc:     	orr.16b	v16, v26, v16
1008431d0:     	orr.16b	v22, v25, v22
1008431d4:     	add.2d	v6, v6, v17
1008431d8:     	add.2d	v7, v7, v17
1008431dc:     	add.2d	v19, v19, v17
1008431e0:     	add.2d	v4, v4, v17
1008431e4:     	add.2d	v3, v3, v17
1008431e8:     	add.2d	v2, v2, v17
1008431ec:     	add.2d	v1, v1, v17
1008431f0:     	add.2d	v0, v0, v17
1008431f4:     	subs	x14, x14, #0x10
1008431f8:     	b.ne	0x100843138 <_js_json_stringify_full+0x2f8>
1008431fc:     	orr.16b	v0, v16, v23
100843200:     	orr.16b	v1, v20, v24
100843204:     	orr.16b	v0, v0, v1
100843208:     	orr.16b	v1, v5, v21
10084320c:     	orr.16b	v2, v18, v22
100843210:     	orr.16b	v1, v1, v2
100843214:     	orr.16b	v0, v0, v1
100843218:     	mov	d1, v0[1]
10084321c:     	orr.8b	v0, v0, v1
100843220:     	fmov	x13, d0
100843224:     	cmp	x8, x11
100843228:     	b.eq	0x1008432f4 <_js_json_stringify_full+0x4b4>
10084322c:     	cbz	x12, 0x1008432d4 <_js_json_stringify_full+0x494>
100843230:     	mov	x14, x11
100843234:     	and	x11, x8, #0x1c
100843238:     	add	x15, sp, #0x70
10084323c:     	add	x9, x15, x11
100843240:     	fmov	d0, x13
100843244:     	movi.2d	v1, #0000000000000000
100843248:     	dup.2d	v3, x14
10084324c:     	adrp	x12, 0x100c96000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4da0>
100843250:     	ldr	q2, [x12, #0xad0]
100843254:     	orr.16b	v2, v3, v2
100843258:     	adrp	x12, 0x100c36000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x335aa>
10084325c:     	ldr	q4, [x12, #0x9d0]
100843260:     	orr.16b	v3, v3, v4
100843264:     	sub	x12, x14, x11
100843268:     	add	x13, x15, x14
10084326c:     	movi.2d	v4, #0x000000000000ff
100843270:     	mov	w14, #0x4               ; =4
100843274:     	dup.2d	v5, x14
100843278:     	ldr	s6, [x13], #0x4
10084327c:     	ushll.8h	v6, v6, #0x0
100843280:     	ushll.4s	v6, v6, #0x0
100843284:     	ushll2.2d	v7, v6, #0x0
100843288:     	and.16b	v7, v7, v4
10084328c:     	ushll.2d	v6, v6, #0x0
100843290:     	and.16b	v6, v6, v4
100843294:     	shl.2d	v16, v2, #0x3
100843298:     	shl.2d	v17, v3, #0x3
10084329c:     	ushl.2d	v6, v6, v17
1008432a0:     	ushl.2d	v7, v7, v16
1008432a4:     	orr.16b	v1, v7, v1
1008432a8:     	orr.16b	v0, v6, v0
1008432ac:     	add.2d	v2, v2, v5
1008432b0:     	add.2d	v3, v3, v5
1008432b4:     	adds	x12, x12, #0x4
1008432b8:     	b.ne	0x100843278 <_js_json_stringify_full+0x438>
1008432bc:     	orr.16b	v0, v0, v1
1008432c0:     	mov	d1, v0[1]
1008432c4:     	orr.8b	v0, v0, v1
1008432c8:     	fmov	x13, d0
1008432cc:     	cmp	x8, x11
1008432d0:     	b.eq	0x1008432f4 <_js_json_stringify_full+0x4b4>
1008432d4:     	add	x10, x10, x8
1008432d8:     	lsl	x11, x11, #3
1008432dc:     	ldrb	w12, [x9], #0x1
1008432e0:     	lsl	x12, x12, x11
1008432e4:     	orr	x13, x12, x13
1008432e8:     	add	x11, x11, #0x8
1008432ec:     	cmp	x9, x10
1008432f0:     	b.ne	0x1008432dc <_js_json_stringify_full+0x49c>
1008432f4:     	orr	x8, x13, x8, lsl #40
1008432f8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1008432fc:     	orr	x21, x8, x9
100843300:     	b	0x100844314 <_js_json_stringify_full+0x14d4>
100843304:     	cmp	w16, #0x8
100843308:     	b.eq	0x10084334c <_js_json_stringify_full+0x50c>
10084330c:     	cmp	w16, #0x9
100843310:     	b.eq	0x10084335c <_js_json_stringify_full+0x51c>
100843314:     	cmp	w16, #0xa
100843318:     	b.ne	0x100843334 <_js_json_stringify_full+0x4f4>
10084331c:     	mov	w15, #0x6e              ; =110
100843320:     	b	0x100843360 <_js_json_stringify_full+0x520>
100843324:     	cmp	w16, #0x22
100843328:     	b.eq	0x100843360 <_js_json_stringify_full+0x520>
10084332c:     	cmp	w16, #0x5c
100843330:     	b.eq	0x100843360 <_js_json_stringify_full+0x520>
100843334:     	cmp	w15, #0x20
100843338:     	b.lt	0x100843364 <_js_json_stringify_full+0x524>
10084333c:     	add	x13, sp, #0x70
100843340:     	strb	w15, [x13, x12]
100843344:     	add	x12, x12, #0x1
100843348:     	b	0x1008438e0 <_js_json_stringify_full+0xaa0>
10084334c:     	mov	w15, #0x62              ; =98
100843350:     	b	0x100843360 <_js_json_stringify_full+0x520>
100843354:     	mov	w15, #0x66              ; =102
100843358:     	b	0x100843360 <_js_json_stringify_full+0x520>
10084335c:     	mov	w15, #0x74              ; =116
100843360:     	tbz	w14, #0x0, 0x1008438cc <_js_json_stringify_full+0xa8c>
100843364:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100843368:     	cmp	x8, x9
10084336c:     	b.eq	0x1008433b4 <_js_json_stringify_full+0x574>
100843370:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100843374:     	cmp	x8, x9
100843378:     	b.ne	0x100843428 <_js_json_stringify_full+0x5e8>
10084337c:     	and	x8, x19, #0xffffffffffff
100843380:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
100843384:     	mov	x10, #0x7fffffffffff    ; =140737488355327
100843388:     	movk	x10, #0xffef, lsl #16
10084338c:     	cmp	x9, x10
100843390:     	b.hi	0x100843428 <_js_json_stringify_full+0x5e8>
100843394:     	ldr	w8, [x8, #0x4]
100843398:     	cmp	w8, #0x40
10084339c:     	b.lo	0x100843428 <_js_json_stringify_full+0x5e8>
1008433a0:     	and	x0, x19, #0xffffffffffff
1008433a4:     	bl	0x1004f0328 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
1008433a8:     	cmp	x0, #0x1
1008433ac:     	b.ne	0x100843428 <_js_json_stringify_full+0x5e8>
1008433b0:     	b	0x100843568 <_js_json_stringify_full+0x728>
1008433b4:     	and	x24, x19, #0xffffffffffff
1008433b8:     	and	x0, x19, #0xffffffffffff
1008433bc:     	bl	0x100578040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1008433c0:     	cbz	x0, 0x1008433f4 <_js_json_stringify_full+0x5b4>
1008433c4:     	ldrb	w8, [x0]
1008433c8:     	cmp	w8, #0x2
1008433cc:     	b.ne	0x1008433f4 <_js_json_stringify_full+0x5b4>
1008433d0:     	ldrsb	w8, [x0, #0x1]
1008433d4:     	tbnz	w8, #0x1f, 0x1008433f4 <_js_json_stringify_full+0x5b4>
1008433d8:     	ldrh	w8, [x0, #0x2]
1008433dc:     	tbnz	w8, #0xb, 0x1008433f4 <_js_json_stringify_full+0x5b4>
1008433e0:     	ldr	w8, [x0, #0x4]
1008433e4:     	cmp	w8, #0x18
1008433e8:     	b.lo	0x1008433f4 <_js_json_stringify_full+0x5b4>
1008433ec:     	ldr	w8, [x24]
1008433f0:     	cbz	w8, 0x100844470 <_js_json_stringify_full+0x1630>
1008433f4:     	and	x0, x19, #0xffffffffffff
1008433f8:     	bl	0x100578040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1008433fc:     	cbz	x0, 0x100843428 <_js_json_stringify_full+0x5e8>
100843400:     	ldrb	w8, [x0]
100843404:     	cmp	w8, #0x2
100843408:     	b.ne	0x100843428 <_js_json_stringify_full+0x5e8>
10084340c:     	ldrh	w8, [x0, #0x2]
100843410:     	tbnz	w8, #0xb, 0x100843428 <_js_json_stringify_full+0x5e8>
100843414:     	ldr	w8, [x0, #0x4]
100843418:     	cmp	w8, #0x18
10084341c:     	b.lo	0x100843428 <_js_json_stringify_full+0x5e8>
100843420:     	ldr	w8, [x24]
100843424:     	cbz	w8, 0x100844414 <_js_json_stringify_full+0x15d4>
100843428:     	mov	w21, #0x1               ; =1
10084342c:     	cmp	x19, x26
100843430:     	b.eq	0x10084430c <_js_json_stringify_full+0x14cc>
100843434:     	and	x22, x19, #0xffff000000000000
100843438:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084343c:     	cmp	x22, x8
100843440:     	b.ne	0x100843478 <_js_json_stringify_full+0x638>
100843444:     	and	x8, x19, #0xffffffffffff
100843448:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084344c:     	b.lo	0x100843464 <_js_json_stringify_full+0x624>
100843450:     	ldr	w8, [x8, #0xc]
100843454:     	mov	w9, #0x4f53             ; =20307
100843458:     	movk	w9, #0x434c, lsl #16
10084345c:     	cmp	w8, w9
100843460:     	b.eq	0x10084430c <_js_json_stringify_full+0x14cc>
100843464:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100843468:     	cmp	x22, x8
10084346c:     	b.ne	0x1008434a4 <_js_json_stringify_full+0x664>
100843470:     	and	x0, x19, #0xffffffffffff
100843474:     	b	0x1008434cc <_js_json_stringify_full+0x68c>
100843478:     	lsr	x8, x19, #52
10084347c:     	cbnz	x8, 0x100843554 <_js_json_stringify_full+0x714>
100843480:     	and	x8, x19, #0x7
100843484:     	cbz	x19, 0x1008434b0 <_js_json_stringify_full+0x670>
100843488:     	cbnz	x8, 0x1008434b0 <_js_json_stringify_full+0x670>
10084348c:     	mov	x0, x19
100843490:     	bl	0x10050c7b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100843494:     	mov	x8, x19
100843498:     	tbnz	w0, #0x0, 0x100843448 <_js_json_stringify_full+0x608>
10084349c:     	mov	x8, #0x0                ; =0
1008434a0:     	b	0x1008434b0 <_js_json_stringify_full+0x670>
1008434a4:     	lsr	x8, x19, #52
1008434a8:     	cbnz	x8, 0x100843554 <_js_json_stringify_full+0x714>
1008434ac:     	and	x8, x19, #0x7
1008434b0:     	cbz	x19, 0x100843554 <_js_json_stringify_full+0x714>
1008434b4:     	cbnz	x8, 0x100843554 <_js_json_stringify_full+0x714>
1008434b8:     	mov	x0, x19
1008434bc:     	bl	0x10050c7b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008434c0:     	mov	x8, x0
1008434c4:     	mov	x0, x19
1008434c8:     	tbz	w8, #0x0, 0x100843554 <_js_json_stringify_full+0x714>
1008434cc:     	cmp	x0, #0x100, lsl #12     ; =0x100000
1008434d0:     	b.lo	0x100843554 <_js_json_stringify_full+0x714>
1008434d4:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1008434d8:     	add	x8, x8, #0xf70
1008434dc:     	ldaprb	w8, [x8]
1008434e0:     	cbz	w8, 0x100843554 <_js_json_stringify_full+0x714>
1008434e4:     	lsr	x8, x0, #3
1008434e8:     	mov	x9, #0x7c15             ; =31765
1008434ec:     	movk	x9, #0x7f4a, lsl #16
1008434f0:     	movk	x9, #0x79b9, lsl #32
1008434f4:     	movk	x9, #0x9e37, lsl #48
1008434f8:     	mul	x8, x8, x9
1008434fc:     	lsr	x10, x8, #54
100843500:     	lsr	x11, x8, #60
100843504:     	adrp	x9, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100843508:     	add	x9, x9, #0xef0
10084350c:     	add	x11, x9, x11, lsl #3
100843510:     	ldapr	x11, [x11]
100843514:     	lsr	x10, x11, x10
100843518:     	tbz	w10, #0x0, 0x100843554 <_js_json_stringify_full+0x714>
10084351c:     	lsr	x10, x8, #44
100843520:     	ubfx	x11, x8, #50, #4
100843524:     	add	x11, x9, x11, lsl #3
100843528:     	ldapr	x11, [x11]
10084352c:     	lsr	x10, x11, x10
100843530:     	tbz	w10, #0x0, 0x100843554 <_js_json_stringify_full+0x714>
100843534:     	lsr	x10, x8, #34
100843538:     	ubfx	x8, x8, #40, #4
10084353c:     	add	x8, x9, x8, lsl #3
100843540:     	ldapr	x8, [x8]
100843544:     	lsr	x8, x8, x10
100843548:     	tbz	w8, #0x0, 0x100843554 <_js_json_stringify_full+0x714>
10084354c:     	bl	0x10034a0ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
100843550:     	tbnz	w0, #0x0, 0x10084430c <_js_json_stringify_full+0x14cc>
100843554:     	tbz	w21, #0x0, 0x100843574 <_js_json_stringify_full+0x734>
100843558:     	mov.16b	v0, v8
10084355c:     	bl	0x1004eb3fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100843560:     	cmp	x0, #0x1
100843564:     	b.ne	0x100843574 <_js_json_stringify_full+0x734>
100843568:     	mov	x21, #0x7fff000000000000 ; =9223090561878065152
10084356c:     	bfxil	x21, x1, #0, #48
100843570:     	b	0x100844314 <_js_json_stringify_full+0x14d4>
100843574:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100843578:     	cmp	x22, x8
10084357c:     	b.ne	0x1008435cc <_js_json_stringify_full+0x78c>
100843580:     	ands	x21, x19, #0xffffffffffff
100843584:     	b.eq	0x1008435cc <_js_json_stringify_full+0x78c>
100843588:     	mov	x0, x21
10084358c:     	bl	0x10050c7b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100843590:     	cbz	w0, 0x1008435cc <_js_json_stringify_full+0x78c>
100843594:     	ldurb	w8, [x21, #-0x8]
100843598:     	cmp	w8, #0x9
10084359c:     	b.ne	0x1008435cc <_js_json_stringify_full+0x78c>
1008435a0:     	ldr	w8, [x21, #0x4]
1008435a4:     	mov	w9, #0x5841             ; =22593
1008435a8:     	movk	w9, #0x4c5a, lsl #16
1008435ac:     	cmp	w8, w9
1008435b0:     	b.ne	0x1008435cc <_js_json_stringify_full+0x78c>
1008435b4:     	mov	x0, x21
1008435b8:     	bl	0x10068551c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
1008435bc:     	cbz	x0, 0x1008435cc <_js_json_stringify_full+0x78c>
1008435c0:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
1008435c4:     	bfxil	x19, x0, #0, #48
1008435c8:     	fmov	d8, x19
1008435cc:     	mov	w8, #0x7ffd             ; =32765
1008435d0:     	cmp	x8, x23, lsr #48
1008435d4:     	b.ne	0x1008435e8 <_js_json_stringify_full+0x7a8>
1008435d8:     	and	x1, x23, #0xffffffffffff
1008435dc:     	cmp	x1, #0x100, lsl #12     ; =0x100000
1008435e0:     	b.hs	0x1008435fc <_js_json_stringify_full+0x7bc>
1008435e4:     	b	0x100843650 <_js_json_stringify_full+0x810>
1008435e8:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
1008435ec:     	mov	x9, #0xfffffff00000     ; =281474975662080
1008435f0:     	mov	x1, x23
1008435f4:     	cmp	x8, x9
1008435f8:     	b.hs	0x100843650 <_js_json_stringify_full+0x810>
1008435fc:     	lsr	x8, x1, #47
100843600:     	cbnz	x8, 0x100843650 <_js_json_stringify_full+0x810>
100843604:     	add	x0, sp, #0x70
100843608:     	bl	0x10076b32c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
10084360c:     	ldr	w8, [sp, #0x70]
100843610:     	tbz	w8, #0x0, 0x100843650 <_js_json_stringify_full+0x810>
100843614:     	ldr	w8, [sp, #0x78]
100843618:     	mov	w9, #-0xff30            ; =-65328
10084361c:     	cmp	w8, w9
100843620:     	b.eq	0x100843644 <_js_json_stringify_full+0x804>
100843624:     	mov	w9, #-0xff2f            ; =-65327
100843628:     	cmp	w8, w9
10084362c:     	b.ne	0x100843650 <_js_json_stringify_full+0x810>
100843630:     	mov.16b	v0, v9
100843634:     	bl	0x10084577c <_js_jsvalue_to_string>
100843638:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
10084363c:     	bfxil	x23, x0, #0, #48
100843640:     	b	0x100843650 <_js_json_stringify_full+0x810>
100843644:     	mov.16b	v0, v9
100843648:     	bl	0x10086cd20 <_js_number_coerce>
10084364c:     	fmov	x23, d0
100843650:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100843654:     	add	x8, x23, x8
100843658:     	cmp	x8, #0x3
10084365c:     	b.hs	0x100843674 <_js_json_stringify_full+0x834>
100843660:     	mov	x21, #0x0               ; =0
100843664:     	mov	w8, #0x1                ; =1
100843668:     	stp	xzr, x8, [sp]
10084366c:     	str	xzr, [sp, #0x10]
100843670:     	b	0x100843928 <_js_json_stringify_full+0xae8>
100843674:     	and	x8, x23, #0xffff000000000000
100843678:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084367c:     	cmp	x8, x9
100843680:     	b.eq	0x1008436a4 <_js_json_stringify_full+0x864>
100843684:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100843688:     	cmp	x8, x9
10084368c:     	b.ne	0x100843730 <_js_json_stringify_full+0x8f0>
100843690:     	and	x8, x23, #0xffffffffffff
100843694:     	cmp	x8, #0x1, lsl #12       ; =0x1000
100843698:     	b.hs	0x100843778 <_js_json_stringify_full+0x938>
10084369c:     	mov	x9, #0x0                ; =0
1008436a0:     	b	0x100843780 <_js_json_stringify_full+0x940>
1008436a4:     	strb	wzr, [sp, #0x3c]
1008436a8:     	str	wzr, [sp, #0x38]
1008436ac:     	ubfx	x1, x23, #40, #8
1008436b0:     	cbz	x1, 0x100843700 <_js_json_stringify_full+0x8c0>
1008436b4:     	strb	w23, [sp, #0x38]
1008436b8:     	cmp	x1, #0x1
1008436bc:     	b.eq	0x100843700 <_js_json_stringify_full+0x8c0>
1008436c0:     	lsr	x8, x23, #8
1008436c4:     	strb	w8, [sp, #0x39]
1008436c8:     	cmp	x1, #0x2
1008436cc:     	b.eq	0x100843700 <_js_json_stringify_full+0x8c0>
1008436d0:     	lsr	x8, x23, #16
1008436d4:     	strb	w8, [sp, #0x3a]
1008436d8:     	cmp	x1, #0x3
1008436dc:     	b.eq	0x100843700 <_js_json_stringify_full+0x8c0>
1008436e0:     	lsr	x8, x23, #24
1008436e4:     	strb	w8, [sp, #0x3b]
1008436e8:     	cmp	x1, #0x4
1008436ec:     	b.eq	0x100843700 <_js_json_stringify_full+0x8c0>
1008436f0:     	lsr	x8, x23, #32
1008436f4:     	strb	w8, [sp, #0x3c]
1008436f8:     	cmp	x1, #0x5
1008436fc:     	b.ne	0x100844b00 <_js_json_stringify_full+0x1cc0>
100843700:     	add	x8, sp, #0x70
100843704:     	add	x0, sp, #0x38
100843708:     	bl	0x10002b398 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
10084370c:     	ldr	w8, [sp, #0x70]
100843710:     	ldp	x9, x21, [sp, #0x78]
100843714:     	cmp	w8, #0x0
100843718:     	csinc	x22, x9, xzr, eq
10084371c:     	csel	x24, xzr, x21, ne
100843720:     	tbz	x24, #0x3f, 0x100843860 <_js_json_stringify_full+0xa20>
100843724:     	mov	x0, #0x0                ; =0
100843728:     	mov	x1, x21
10084372c:     	bl	0x100b0f440 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100843730:     	add	x8, x26, #0x3
100843734:     	cmp	x23, x8
100843738:     	b.eq	0x100843660 <_js_json_stringify_full+0x820>
10084373c:     	fmov	d0, x23
100843740:     	fcvtzu	x8, d0
100843744:     	mov	w9, #0xa                ; =10
100843748:     	cmp	x8, #0xa
10084374c:     	csel	x3, x8, x9, lo
100843750:     	adrp	x1, 0x100c40000 <_PERRY_EMPTY_STRING+0x19e4>
100843754:     	add	x1, x1, #0x7ac
100843758:     	add	x0, sp, #0x70
10084375c:     	mov	w2, #0x1                ; =1
100843760:     	bl	0x10022dc74 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
100843764:     	ldr	x21, [sp, #0x80]
100843768:     	str	x21, [sp, #0x10]
10084376c:     	ldr	q0, [sp, #0x70]
100843770:     	str	q0, [sp]
100843774:     	b	0x100843928 <_js_json_stringify_full+0xae8>
100843778:     	ldr	w21, [x8, #0x4]
10084377c:     	add	x9, x8, #0x14
100843780:     	mov	x14, #0x0               ; =0
100843784:     	mov	x8, #0x0                ; =0
100843788:     	cmp	x9, #0x0
10084378c:     	csel	x23, xzr, x21, eq
100843790:     	csinc	x22, x9, xzr, ne
100843794:     	add	x9, x22, x23
100843798:     	mov	w10, #0x1               ; =1
10084379c:     	mov	x11, x22
1008437a0:     	b	0x1008437d0 <_js_json_stringify_full+0x990>
1008437a4:     	add	x12, x11, #0x2
1008437a8:     	bfi	w15, w13, #6, #5
1008437ac:     	mov	x13, x15
1008437b0:     	sub	x11, x24, x11
1008437b4:     	add	x14, x11, x12
1008437b8:     	cmp	w13, #0x10, lsl #12     ; =0x10000
1008437bc:     	cinc	x11, x10, hs
1008437c0:     	add	x8, x11, x8
1008437c4:     	mov	x11, x12
1008437c8:     	cmp	x8, #0xa
1008437cc:     	b.hi	0x100843888 <_js_json_stringify_full+0xa48>
1008437d0:     	cmp	x11, x9
1008437d4:     	b.eq	0x100843838 <_js_json_stringify_full+0x9f8>
1008437d8:     	mov	x24, x14
1008437dc:     	mov	x12, x11
1008437e0:     	ldrsb	w14, [x12], #0x1
1008437e4:     	and	w13, w14, #0xff
1008437e8:     	tbz	w14, #0x1f, 0x1008437b0 <_js_json_stringify_full+0x970>
1008437ec:     	ldrb	w12, [x11, #0x1]
1008437f0:     	and	w15, w12, #0x3f
1008437f4:     	cmp	w13, #0xe0
1008437f8:     	b.lo	0x1008437a4 <_js_json_stringify_full+0x964>
1008437fc:     	and	w14, w13, #0x1f
100843800:     	ldrb	w12, [x11, #0x2]
100843804:     	and	w12, w12, #0x3f
100843808:     	orr	w15, w12, w15, lsl #6
10084380c:     	cmp	w13, #0xf0
100843810:     	b.lo	0x10084382c <_js_json_stringify_full+0x9ec>
100843814:     	add	x12, x11, #0x4
100843818:     	ldrb	w13, [x11, #0x3]
10084381c:     	and	w13, w13, #0x3f
100843820:     	orr	w13, w13, w15, lsl #6
100843824:     	bfi	w13, w14, #18, #3
100843828:     	b	0x1008437b0 <_js_json_stringify_full+0x970>
10084382c:     	add	x12, x11, #0x3
100843830:     	orr	w13, w15, w14, lsl #12
100843834:     	b	0x1008437b0 <_js_json_stringify_full+0x970>
100843838:     	cbz	x23, 0x1008438bc <_js_json_stringify_full+0xa7c>
10084383c:     	mov	x0, x23
100843840:     	mov	w1, #0x1                ; =1
100843844:     	bl	0x100b5c2c8 <_mi_malloc_aligned>
100843848:     	cbz	x0, 0x100844ae8 <_js_json_stringify_full+0x1ca8>
10084384c:     	mov	x25, x0
100843850:     	mov	x1, x22
100843854:     	mov	x2, x23
100843858:     	bl	0x100b5eeec <_writev+0x100b5eeec>
10084385c:     	b	0x1008438c4 <_js_json_stringify_full+0xa84>
100843860:     	cbz	x24, 0x100843918 <_js_json_stringify_full+0xad8>
100843864:     	mov	x0, x24
100843868:     	mov	w1, #0x1                ; =1
10084386c:     	bl	0x100b5c2c8 <_mi_malloc_aligned>
100843870:     	cbz	x0, 0x100844af4 <_js_json_stringify_full+0x1cb4>
100843874:     	mov	x23, x0
100843878:     	mov	x1, x22
10084387c:     	mov	x2, x24
100843880:     	bl	0x100b5eeec <_writev+0x100b5eeec>
100843884:     	b	0x100843920 <_js_json_stringify_full+0xae0>
100843888:     	cbz	x24, 0x1008438bc <_js_json_stringify_full+0xa7c>
10084388c:     	cmp	x24, x23
100843890:     	b.hs	0x100844368 <_js_json_stringify_full+0x1528>
100843894:     	ldrsb	w8, [x22, x24]
100843898:     	cmn	w8, #0x40
10084389c:     	b.ge	0x10084436c <_js_json_stringify_full+0x152c>
1008438a0:     	adrp	x4, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
1008438a4:     	add	x4, x4, #0x2b8
1008438a8:     	mov	x0, x22
1008438ac:     	mov	x1, x23
1008438b0:     	mov	x2, #0x0                ; =0
1008438b4:     	mov	x3, x24
1008438b8:     	bl	0x100b0f7b8 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
1008438bc:     	mov	x21, #0x0               ; =0
1008438c0:     	mov	w25, #0x1               ; =1
1008438c4:     	stp	x21, x25, [sp]
1008438c8:     	b	0x100843924 <_js_json_stringify_full+0xae4>
1008438cc:     	add	x14, sp, #0x70
1008438d0:     	mov	w16, #0x5c              ; =92
1008438d4:     	strb	w16, [x14, x12]
1008438d8:     	add	x12, x12, #0x2
1008438dc:     	strb	w15, [x13, #0x1]
1008438e0:     	cmp	w10, #0x2
1008438e4:     	b.eq	0x100843054 <_js_json_stringify_full+0x214>
1008438e8:     	ldrb	w11, [x11, #0x2]
1008438ec:     	sxtb	w10, w11
1008438f0:     	cmp	w11, #0xb
1008438f4:     	b.le	0x1008443f4 <_js_json_stringify_full+0x15b4>
1008438f8:     	cmp	w11, #0x21
1008438fc:     	b.gt	0x100844440 <_js_json_stringify_full+0x1600>
100843900:     	cmp	w11, #0xc
100843904:     	b.eq	0x1008444cc <_js_json_stringify_full+0x168c>
100843908:     	cmp	w11, #0xd
10084390c:     	b.ne	0x100844450 <_js_json_stringify_full+0x1610>
100843910:     	mov	w10, #0x72              ; =114
100843914:     	b	0x1008444d8 <_js_json_stringify_full+0x1698>
100843918:     	mov	x21, #0x0               ; =0
10084391c:     	mov	w23, #0x1               ; =1
100843920:     	stp	x21, x23, [sp]
100843924:     	str	x21, [sp, #0x10]
100843928:     	cmp	x27, #0x2
10084392c:     	b.lo	0x100843a6c <_js_json_stringify_full+0xc2c>
100843930:     	and	x24, x20, #0xffff000000000000
100843934:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100843938:     	cmp	x24, x8
10084393c:     	b.ne	0x100843a48 <_js_json_stringify_full+0xc08>
100843940:     	and	x22, x20, #0xffffffffffff
100843944:     	cmp	x22, #0x100, lsl #12    ; =0x100000
100843948:     	b.lo	0x100843a6c <_js_json_stringify_full+0xc2c>
10084394c:     	mov	x0, x22
100843950:     	bl	0x100507cc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
100843954:     	tbnz	w0, #0x0, 0x100843a6c <_js_json_stringify_full+0xc2c>
100843958:     	lsr	x8, x22, #51
10084395c:     	cmp	x8, #0xfff
100843960:     	b.lo	0x100843978 <_js_json_stringify_full+0xb38>
100843964:     	mov	w8, #0x7ffc             ; =32764
100843968:     	cmp	x8, x22, lsr #48
10084396c:     	b.eq	0x100843a6c <_js_json_stringify_full+0xc2c>
100843970:     	ands	x22, x22, #0xffffffffffff
100843974:     	b.eq	0x100843a6c <_js_json_stringify_full+0xc2c>
100843978:     	and	x8, x22, #0xfffffffffff00000
10084397c:     	lsr	x9, x22, #47
100843980:     	cmp	x9, #0x0
100843984:     	ccmp	x8, #0x0, #0x4, eq
100843988:     	b.eq	0x100843a6c <_js_json_stringify_full+0xc2c>
10084398c:     	tst	x22, #0x3
100843990:     	ccmp	x22, #0x7, #0x0, eq
100843994:     	b.ls	0x100844708 <_js_json_stringify_full+0x18c8>
100843998:     	adrp	x8, 0x100f7c000 <_perry_global_options_worker_ts__1>
10084399c:     	ldr	x8, [x8, #0x48]
1008439a0:     	cmn	x8, #0x1
1008439a4:     	b.eq	0x100844658 <_js_json_stringify_full+0x1818>
1008439a8:     	mrs	x9, TPIDRRO_EL0
1008439ac:     	and	x9, x9, #0xfffffffffffffff8
1008439b0:     	ldr	x0, [x9, x8, lsl #3]
1008439b4:     	cbz	x0, 0x100844658 <_js_json_stringify_full+0x1818>
1008439b8:     	lsr	x1, x22, #20
1008439bc:     	ldr	x8, [x0, #0x10]
1008439c0:     	ldrb	w9, [x8]
1008439c4:     	cmp	w9, #0x2
1008439c8:     	b.ne	0x100844670 <_js_json_stringify_full+0x1830>
1008439cc:     	ldrb	w9, [x8, #0x88]
1008439d0:     	tbz	w9, #0x0, 0x1008439f0 <_js_json_stringify_full+0xbb0>
1008439d4:     	ldr	x9, [x8, #0x80]
1008439d8:     	cmp	x9, x1
1008439dc:     	b.ne	0x1008439f0 <_js_json_stringify_full+0xbb0>
1008439e0:     	ldp	x9, x10, [x8, #0x60]
1008439e4:     	cmp	x9, x22
1008439e8:     	ccmp	x10, x22, #0x0, ls
1008439ec:     	b.hi	0x100844650 <_js_json_stringify_full+0x1810>
1008439f0:     	ldrb	w9, [x8, #0xb8]
1008439f4:     	cbz	w9, 0x100843a14 <_js_json_stringify_full+0xbd4>
1008439f8:     	ldr	x9, [x8, #0xb0]
1008439fc:     	cmp	x9, x1
100843a00:     	b.ne	0x100843a14 <_js_json_stringify_full+0xbd4>
100843a04:     	ldp	x9, x10, [x8, #0x90]
100843a08:     	cmp	x9, x22
100843a0c:     	ccmp	x10, x22, #0x0, ls
100843a10:     	b.hi	0x1008448d8 <_js_json_stringify_full+0x1a98>
100843a14:     	ldrb	w9, [x8, #0xe8]
100843a18:     	cbz	w9, 0x100844490 <_js_json_stringify_full+0x1650>
100843a1c:     	ldr	x9, [x8, #0xe0]
100843a20:     	cmp	x9, x1
100843a24:     	b.ne	0x100844490 <_js_json_stringify_full+0x1650>
100843a28:     	ldr	x9, [x8, #0xc0]
100843a2c:     	cmp	x9, x22
100843a30:     	b.hi	0x100844490 <_js_json_stringify_full+0x1650>
100843a34:     	ldr	x9, [x8, #0xc8]
100843a38:     	cmp	x9, x22
100843a3c:     	b.ls	0x100844490 <_js_json_stringify_full+0x1650>
100843a40:     	add	x9, x8, #0xc0
100843a44:     	b	0x1008448dc <_js_json_stringify_full+0x1a9c>
100843a48:     	lsr	x8, x20, #52
100843a4c:     	cbnz	x8, 0x100843a6c <_js_json_stringify_full+0xc2c>
100843a50:     	cbz	x20, 0x100843a6c <_js_json_stringify_full+0xc2c>
100843a54:     	and	x8, x20, #0x7
100843a58:     	cbnz	x8, 0x100843a6c <_js_json_stringify_full+0xc2c>
100843a5c:     	mov	x0, x20
100843a60:     	bl	0x10050c7b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100843a64:     	mov	x22, x20
100843a68:     	cbnz	w0, 0x100843944 <_js_json_stringify_full+0xb04>
100843a6c:     	mov	x24, #-0x1              ; =-1
100843a70:     	str	x24, [sp, #0x20]
100843a74:     	mov	w23, #0x1               ; =1
100843a78:     	cmp	x27, #0x1
100843a7c:     	cset	w8, hi
100843a80:     	tst	w8, w23
100843a84:     	b.eq	0x100843af8 <_js_json_stringify_full+0xcb8>
100843a88:     	and	x22, x20, #0xffff000000000000
100843a8c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100843a90:     	cmp	x22, x8
100843a94:     	b.ne	0x100843ad0 <_js_json_stringify_full+0xc90>
100843a98:     	and	x8, x20, #0xffffffffffff
100843a9c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100843aa0:     	b.lo	0x100843af8 <_js_json_stringify_full+0xcb8>
100843aa4:     	ldr	w8, [x8, #0xc]
100843aa8:     	mov	w9, #0x4f53             ; =20307
100843aac:     	movk	w9, #0x434c, lsl #16
100843ab0:     	cmp	w8, w9
100843ab4:     	b.ne	0x100843af8 <_js_json_stringify_full+0xcb8>
100843ab8:     	and	x8, x20, #0xffffffffffff
100843abc:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100843ac0:     	cmp	x22, x9
100843ac4:     	csel	x28, x8, x20, eq
100843ac8:     	mov	w27, #0x1               ; =1
100843acc:     	b	0x100843afc <_js_json_stringify_full+0xcbc>
100843ad0:     	lsr	x8, x20, #52
100843ad4:     	cbnz	x8, 0x100843af8 <_js_json_stringify_full+0xcb8>
100843ad8:     	mov	w27, #0x0               ; =0
100843adc:     	cbz	x20, 0x100843afc <_js_json_stringify_full+0xcbc>
100843ae0:     	and	x8, x20, #0x7
100843ae4:     	cbnz	x8, 0x100843afc <_js_json_stringify_full+0xcbc>
100843ae8:     	mov	x0, x20
100843aec:     	bl	0x10050c7b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100843af0:     	mov	x8, x20
100843af4:     	tbnz	w0, #0x0, 0x100843a9c <_js_json_stringify_full+0xc5c>
100843af8:     	mov	w27, #0x0               ; =0
100843afc:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100843b00:     	add	x0, x0, #0xd78
100843b04:     	ldr	x8, [x0]
100843b08:     	blr	x8
100843b0c:     	mov	x20, x0
100843b10:     	ldr	w25, [x0]
100843b14:     	add	w8, w25, #0x1
100843b18:     	str	w8, [x0]
100843b1c:     	cbz	w25, 0x100843b8c <_js_json_stringify_full+0xd4c>
100843b20:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100843b24:     	add	x0, x0, #0xd00
100843b28:     	ldr	x8, [x0]
100843b2c:     	blr	x8
100843b30:     	ldrb	w8, [x0, #0x20]
100843b34:     	cmp	w8, #0x1
100843b38:     	b.ne	0x100844948 <_js_json_stringify_full+0x1b08>
100843b3c:     	ldr	x8, [x0]
100843b40:     	cbnz	x8, 0x100844954 <_js_json_stringify_full+0x1b14>
100843b44:     	mov	x8, #-0x1               ; =-1
100843b48:     	str	x8, [x0]
100843b4c:     	ldr	x22, [x0, #0x18]
100843b50:     	ldr	x8, [x0, #0x8]
100843b54:     	cmp	x22, x8
100843b58:     	b.eq	0x10084433c <_js_json_stringify_full+0x14fc>
100843b5c:     	ldr	x8, [x0, #0x10]
100843b60:     	mov	w9, #0x18               ; =24
100843b64:     	madd	x8, x22, x9, x8
100843b68:     	mov	w9, #0x8                ; =8
100843b6c:     	stp	xzr, x9, [x8]
100843b70:     	str	xzr, [x8, #0x10]
100843b74:     	add	x8, x22, #0x1
100843b78:     	str	x8, [x0, #0x18]
100843b7c:     	ldr	x8, [x0]
100843b80:     	add	x8, x8, #0x1
100843b84:     	str	x8, [x0]
100843b88:     	b	0x100843bf4 <_js_json_stringify_full+0xdb4>
100843b8c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100843b90:     	add	x0, x0, #0xdc0
100843b94:     	ldr	x8, [x0]
100843b98:     	blr	x8
100843b9c:     	strb	wzr, [x0]
100843ba0:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100843ba4:     	add	x0, x0, #0xdf0
100843ba8:     	ldr	x8, [x0]
100843bac:     	blr	x8
100843bb0:     	strb	wzr, [x0]
100843bb4:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100843bb8:     	ldr	w22, [x8, #0x5a8]
100843bbc:     	cmp	w22, #0x300
100843bc0:     	b.hs	0x10084438c <_js_json_stringify_full+0x154c>
100843bc4:     	adrp	x8, 0x100f7c000 <_perry_global_options_worker_ts__1>
100843bc8:     	ldr	x8, [x8, #0x48]
100843bcc:     	cmn	x8, #0x1
100843bd0:     	b.eq	0x10084437c <_js_json_stringify_full+0x153c>
100843bd4:     	mrs	x9, TPIDRRO_EL0
100843bd8:     	and	x9, x9, #0xfffffffffffffff8
100843bdc:     	ldr	x0, [x9, x8, lsl #3]
100843be0:     	cbz	x0, 0x10084437c <_js_json_stringify_full+0x153c>
100843be4:     	add	x8, x0, x22, lsl #3
100843be8:     	ldr	x0, [x8, #0x1e8]
100843bec:     	cbz	x0, 0x10084438c <_js_json_stringify_full+0x154c>
100843bf0:     	str	xzr, [x0]
100843bf4:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100843bf8:     	add	x0, x0, #0xd30
100843bfc:     	ldr	x8, [x0]
100843c00:     	blr	x8
100843c04:     	mov	x22, x0
100843c08:     	ldrb	w8, [x0, #0x18]
100843c0c:     	cmp	w8, #0x1
100843c10:     	b.ne	0x1008448fc <_js_json_stringify_full+0x1abc>
100843c14:     	ldr	x8, [x0]
100843c18:     	mov	x9, #-0x1               ; =-1
100843c1c:     	str	x9, [x0]
100843c20:     	cmn	x8, #0x2
100843c24:     	b.eq	0x100844a94 <_js_json_stringify_full+0x1c54>
100843c28:     	cmn	x8, #0x1
100843c2c:     	b.eq	0x100843d00 <_js_json_stringify_full+0xec0>
100843c30:     	add	x9, sp, #0x38
100843c34:     	ldur	q0, [x0, #0x8]
100843c38:     	stur	q0, [x9, #0x8]
100843c3c:     	str	x8, [sp, #0x38]
100843c40:     	tbz	w23, #0x0, 0x100843d14 <_js_json_stringify_full+0xed4>
100843c44:     	tbz	w27, #0x0, 0x100843dfc <_js_json_stringify_full+0xfbc>
100843c48:     	bl	0x100288a98 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
100843c4c:     	str	x0, [sp, #0x50]
100843c50:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100843c54:     	stp	x28, x8, [sp, #0x78]
100843c58:     	mov	w8, #0x1                ; =1
100843c5c:     	str	x8, [sp, #0x70]
100843c60:     	add	x0, sp, #0x70
100843c64:     	bl	0x100288ba0 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
100843c68:     	mov	x21, x0
100843c6c:     	str	x0, [sp, #0x58]
100843c70:     	mov	w0, #0x0                ; =0
100843c74:     	bl	0x10034882c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100843c78:     	stp	xzr, xzr, [x0]
100843c7c:     	str	wzr, [x0, #0x10]
100843c80:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100843c84:     	bfxil	x8, x0, #0, #48
100843c88:     	fmov	d0, x8
100843c8c:     	bl	0x1002087a4 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
100843c90:     	mov	x19, x0
100843c94:     	adrp	x23, 0x100f7c000 <_perry_global_options_worker_ts__1>
100843c98:     	ldr	x8, [x23, #0x48]
100843c9c:     	cmn	x8, #0x1
100843ca0:     	b.eq	0x100843e60 <_js_json_stringify_full+0x1020>
100843ca4:     	mrs	x9, TPIDRRO_EL0
100843ca8:     	and	x9, x9, #0xfffffffffffffff8
100843cac:     	ldr	x8, [x9, x8, lsl #3]
100843cb0:     	cbz	x8, 0x100843e60 <_js_json_stringify_full+0x1020>
100843cb4:     	ldr	x8, [x8, #0x19e8]
100843cb8:     	cbz	x8, 0x100843e60 <_js_json_stringify_full+0x1020>
100843cbc:     	ldr	x9, [x8]
100843cc0:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100843cc4:     	cmp	x9, x10
100843cc8:     	b.hs	0x1008449cc <_js_json_stringify_full+0x1b8c>
100843ccc:     	add	x10, x9, #0x1
100843cd0:     	str	x10, [x8]
100843cd4:     	ldr	x10, [x8, #0x18]
100843cd8:     	cmp	x19, x10
100843cdc:     	b.hs	0x1008449d8 <_js_json_stringify_full+0x1b98>
100843ce0:     	ldr	x10, [x8, #0x10]
100843ce4:     	mov	w11, #0x18              ; =24
100843ce8:     	madd	x10, x19, x11, x10
100843cec:     	ldr	x11, [x10]
100843cf0:     	cbnz	x11, 0x100844a38 <_js_json_stringify_full+0x1bf8>
100843cf4:     	ldr	x0, [x10, #0x8]
100843cf8:     	str	x9, [x8]
100843cfc:     	b	0x100843e68 <_js_json_stringify_full+0x1028>
100843d00:     	mov	x8, #0x0                ; =0
100843d04:     	mov	w9, #0x1                ; =1
100843d08:     	stp	x9, xzr, [sp, #0x40]
100843d0c:     	str	x8, [sp, #0x38]
100843d10:     	tbnz	w23, #0x0, 0x100843c44 <_js_json_stringify_full+0xe04>
100843d14:     	cmp	x21, #0x0
100843d18:     	cset	w6, ne
100843d1c:     	ldp	x0, x1, [sp, #0x28]
100843d20:     	ldp	x3, x4, [sp, #0x8]
100843d24:     	add	x2, sp, #0x38
100843d28:     	mov.16b	v0, v8
100843d2c:     	mov	x5, #0x0                ; =0
100843d30:     	bl	0x100500500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
100843d34:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100843d38:     	add	x0, x0, #0xd90
100843d3c:     	ldr	x8, [x0]
100843d40:     	blr	x8
100843d44:     	ldrb	w8, [x0, #0x20]
100843d48:     	cbnz	w8, 0x100844960 <_js_json_stringify_full+0x1b20>
100843d4c:     	ldr	x8, [x0]
100843d50:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100843d54:     	cmp	x8, x9
100843d58:     	b.hs	0x100844990 <_js_json_stringify_full+0x1b50>
100843d5c:     	ldr	x9, [x0, #0x18]
100843d60:     	cbz	x9, 0x100843d6c <_js_json_stringify_full+0xf2c>
100843d64:     	cbnz	x8, 0x10084499c <_js_json_stringify_full+0x1b5c>
100843d68:     	str	xzr, [x0, #0x18]
100843d6c:     	ldp	x0, x1, [sp, #0x40]
100843d70:     	cmp	x1, #0x5
100843d74:     	b.hi	0x100843ddc <_js_json_stringify_full+0xf9c>
100843d78:     	cbz	x1, 0x100843fec <_js_json_stringify_full+0x11ac>
100843d7c:     	ldrsb	w8, [x0]
100843d80:     	tbnz	w8, #0x1f, 0x100843ddc <_js_json_stringify_full+0xf9c>
100843d84:     	cmp	x1, #0x1
100843d88:     	b.eq	0x100843dc4 <_js_json_stringify_full+0xf84>
100843d8c:     	ldrsb	w8, [x0, #0x1]
100843d90:     	tbnz	w8, #0x1f, 0x100843ddc <_js_json_stringify_full+0xf9c>
100843d94:     	cmp	x1, #0x2
100843d98:     	b.eq	0x100843dc4 <_js_json_stringify_full+0xf84>
100843d9c:     	ldrsb	w8, [x0, #0x2]
100843da0:     	tbnz	w8, #0x1f, 0x100843ddc <_js_json_stringify_full+0xf9c>
100843da4:     	cmp	x1, #0x3
100843da8:     	b.eq	0x100843dc4 <_js_json_stringify_full+0xf84>
100843dac:     	ldrsb	w8, [x0, #0x3]
100843db0:     	tbnz	w8, #0x1f, 0x100843ddc <_js_json_stringify_full+0xf9c>
100843db4:     	cmp	x1, #0x4
100843db8:     	b.eq	0x100843dc4 <_js_json_stringify_full+0xf84>
100843dbc:     	ldrsb	w8, [x0, #0x4]
100843dc0:     	tbnz	w8, #0x1f, 0x100843ddc <_js_json_stringify_full+0xf9c>
100843dc4:     	cmp	x1, #0x4
100843dc8:     	b.hs	0x10084412c <_js_json_stringify_full+0x12ec>
100843dcc:     	mov	x10, #0x0               ; =0
100843dd0:     	mov	x9, #0x0                ; =0
100843dd4:     	mov	x8, x0
100843dd8:     	b	0x1008441bc <_js_json_stringify_full+0x137c>
100843ddc:     	bl	0x100327508 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
100843de0:     	mov	x21, #0x7fff000000000000 ; =9223090561878065152
100843de4:     	bfxil	x21, x0, #0, #48
100843de8:     	ldp	x23, x0, [sp, #0x38]
100843dec:     	ldrb	w8, [x22, #0x18]
100843df0:     	cmp	w8, #0x1
100843df4:     	b.eq	0x1008441f8 <_js_json_stringify_full+0x13b8>
100843df8:     	b	0x100844928 <_js_json_stringify_full+0x1ae8>
100843dfc:     	mov	w0, #0x0                ; =0
100843e00:     	bl	0x10034882c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100843e04:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100843e08:     	bfxil	x8, x0, #0, #48
100843e0c:     	fmov	d1, x8
100843e10:     	stp	xzr, xzr, [x0]
100843e14:     	str	wzr, [x0, #0x10]
100843e18:     	mov.16b	v0, v8
100843e1c:     	bl	0x1004fcf7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100843e20:     	mov.16b	v8, v0
100843e24:     	fmov	x23, d8
100843e28:     	cmp	x23, x26
100843e2c:     	b.eq	0x100844074 <_js_json_stringify_full+0x1234>
100843e30:     	mov	w8, #0x7ffd             ; =32765
100843e34:     	cmp	x8, x23, lsr #48
100843e38:     	b.ne	0x100844044 <_js_json_stringify_full+0x1204>
100843e3c:     	and	x8, x23, #0xffffffffffff
100843e40:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100843e44:     	b.lo	0x100844068 <_js_json_stringify_full+0x1228>
100843e48:     	ldr	w8, [x8, #0xc]
100843e4c:     	mov	w9, #0x4f53             ; =20307
100843e50:     	movk	w9, #0x434c, lsl #16
100843e54:     	cmp	w8, w9
100843e58:     	b.ne	0x100844068 <_js_json_stringify_full+0x1228>
100843e5c:     	b	0x100844074 <_js_json_stringify_full+0x1234>
100843e60:     	mov	x0, x19
100843e64:     	bl	0x1001399f0 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100843e68:     	fmov	d1, x0
100843e6c:     	mov.16b	v0, v8
100843e70:     	bl	0x1004fcf7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100843e74:     	mov.16b	v8, v0
100843e78:     	ldr	x8, [x23, #0x48]
100843e7c:     	cmn	x8, #0x1
100843e80:     	b.eq	0x100843ee4 <_js_json_stringify_full+0x10a4>
100843e84:     	mrs	x9, TPIDRRO_EL0
100843e88:     	and	x9, x9, #0xfffffffffffffff8
100843e8c:     	ldr	x8, [x9, x8, lsl #3]
100843e90:     	cbz	x8, 0x100843ee4 <_js_json_stringify_full+0x10a4>
100843e94:     	ldr	x8, [x8, #0x19e8]
100843e98:     	cbz	x8, 0x100843ee4 <_js_json_stringify_full+0x10a4>
100843e9c:     	ldr	x9, [x8]
100843ea0:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100843ea4:     	cmp	x9, x10
100843ea8:     	b.hs	0x1008449cc <_js_json_stringify_full+0x1b8c>
100843eac:     	add	x10, x9, #0x1
100843eb0:     	str	x10, [x8]
100843eb4:     	ldr	x10, [x8, #0x18]
100843eb8:     	cmp	x21, x10
100843ebc:     	b.hs	0x1008449d8 <_js_json_stringify_full+0x1b98>
100843ec0:     	ldr	x10, [x8, #0x10]
100843ec4:     	mov	w11, #0x18              ; =24
100843ec8:     	madd	x10, x21, x11, x10
100843ecc:     	ldr	x11, [x10]
100843ed0:     	cmp	x11, #0x1
100843ed4:     	b.ne	0x100844aac <_js_json_stringify_full+0x1c6c>
100843ed8:     	ldr	x21, [x10, #0x8]
100843edc:     	str	x9, [x8]
100843ee0:     	b	0x100843ef0 <_js_json_stringify_full+0x10b0>
100843ee4:     	mov	x0, x21
100843ee8:     	bl	0x100139918 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
100843eec:     	mov	x21, x0
100843ef0:     	ldr	x8, [x23, #0x48]
100843ef4:     	cmn	x8, #0x1
100843ef8:     	b.eq	0x100843f58 <_js_json_stringify_full+0x1118>
100843efc:     	mrs	x9, TPIDRRO_EL0
100843f00:     	and	x9, x9, #0xfffffffffffffff8
100843f04:     	ldr	x8, [x9, x8, lsl #3]
100843f08:     	cbz	x8, 0x100843f58 <_js_json_stringify_full+0x1118>
100843f0c:     	ldr	x8, [x8, #0x19e8]
100843f10:     	cbz	x8, 0x100843f58 <_js_json_stringify_full+0x1118>
100843f14:     	ldr	x9, [x8]
100843f18:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100843f1c:     	cmp	x9, x10
100843f20:     	b.hs	0x1008449cc <_js_json_stringify_full+0x1b8c>
100843f24:     	add	x10, x9, #0x1
100843f28:     	str	x10, [x8]
100843f2c:     	ldr	x10, [x8, #0x18]
100843f30:     	cmp	x19, x10
100843f34:     	b.hs	0x1008449d8 <_js_json_stringify_full+0x1b98>
100843f38:     	ldr	x10, [x8, #0x10]
100843f3c:     	mov	w11, #0x18              ; =24
100843f40:     	madd	x10, x19, x11, x10
100843f44:     	ldr	x11, [x10]
100843f48:     	cbnz	x11, 0x100844a38 <_js_json_stringify_full+0x1bf8>
100843f4c:     	ldr	x0, [x10, #0x8]
100843f50:     	str	x9, [x8]
100843f54:     	b	0x100843f60 <_js_json_stringify_full+0x1120>
100843f58:     	mov	x0, x19
100843f5c:     	bl	0x1001399f0 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100843f60:     	fmov	d9, x0
100843f64:     	mov.16b	v0, v8
100843f68:     	bl	0x1004fcab4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
100843f6c:     	mov.16b	v2, v0
100843f70:     	mov	x0, x21
100843f74:     	mov.16b	v0, v9
100843f78:     	mov.16b	v1, v8
100843f7c:     	bl	0x1004fcd94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
100843f80:     	str	d0, [sp, #0x60]
100843f84:     	fmov	x19, d0
100843f88:     	cmp	x19, x26
100843f8c:     	b.ne	0x100843ff4 <_js_json_stringify_full+0x11b4>
100843f90:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100843f94:     	add	x0, x0, #0xd90
100843f98:     	ldr	x8, [x0]
100843f9c:     	blr	x8
100843fa0:     	ldrb	w8, [x0, #0x20]
100843fa4:     	cbnz	w8, 0x100844a8c <_js_json_stringify_full+0x1c4c>
100843fa8:     	ldr	x8, [x0]
100843fac:     	cbnz	x8, 0x100844adc <_js_json_stringify_full+0x1c9c>
100843fb0:     	str	xzr, [x0, #0x18]
100843fb4:     	ldp	x21, x19, [sp, #0x38]
100843fb8:     	ldrb	w8, [x22, #0x18]
100843fbc:     	cmp	w8, #0x1
100843fc0:     	b.ne	0x100844a10 <_js_json_stringify_full+0x1bd0>
100843fc4:     	ldp	x8, x0, [x22]
100843fc8:     	stp	x21, x19, [x22]
100843fcc:     	str	xzr, [x22, #0x10]
100843fd0:     	sub	x8, x8, #0x1
100843fd4:     	cmn	x8, #0x2
100843fd8:     	b.hs	0x100843fe0 <_js_json_stringify_full+0x11a0>
100843fdc:     	bl	0x100b5c040 <_mi_free>
100843fe0:     	cbz	w25, 0x1008442a0 <_js_json_stringify_full+0x1460>
100843fe4:     	bl	0x100325768 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100843fe8:     	b	0x1008442a4 <_js_json_stringify_full+0x1464>
100843fec:     	mov	x10, #0x0               ; =0
100843ff0:     	b	0x1008441dc <_js_json_stringify_full+0x139c>
100843ff4:     	add	x0, sp, #0x38
100843ff8:     	bl	0x1004fdaf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
100843ffc:     	tbnz	w0, #0x0, 0x100844038 <_js_json_stringify_full+0x11f8>
100844000:     	mov	x0, x19
100844004:     	bl	0x10032546c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
100844008:     	cmp	x0, #0x1
10084400c:     	b.ne	0x100844aa0 <_js_json_stringify_full+0x1c60>
100844010:     	add	x8, sp, #0x68
100844014:     	add	x9, sp, #0x60
100844018:     	stp	x1, x8, [sp, #0x68]
10084401c:     	str	x9, [sp, #0x78]
100844020:     	add	x8, sp, #0x38
100844024:     	mov	x9, sp
100844028:     	stp	x8, x9, [sp, #0x80]
10084402c:     	add	x0, sp, #0x58
100844030:     	add	x1, sp, #0x70
100844034:     	bl	0x100141410 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
100844038:     	add	x0, sp, #0x50
10084403c:     	bl	0x1001644fc <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100844040:     	b	0x100843d34 <_js_json_stringify_full+0xef4>
100844044:     	lsr	x8, x23, #52
100844048:     	cbnz	x8, 0x100844068 <_js_json_stringify_full+0x1228>
10084404c:     	cbz	x23, 0x100844068 <_js_json_stringify_full+0x1228>
100844050:     	and	x8, x23, #0x7
100844054:     	cbnz	x8, 0x100844068 <_js_json_stringify_full+0x1228>
100844058:     	mov	x0, x23
10084405c:     	bl	0x10050c7b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100844060:     	mov	x8, x23
100844064:     	tbnz	w0, #0x0, 0x100843e40 <_js_json_stringify_full+0x1000>
100844068:     	mov	x0, x23
10084406c:     	bl	0x100506b14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
100844070:     	tbz	w0, #0x0, 0x100844100 <_js_json_stringify_full+0x12c0>
100844074:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100844078:     	add	x0, x0, #0xd90
10084407c:     	ldr	x8, [x0]
100844080:     	blr	x8
100844084:     	ldrb	w8, [x0, #0x20]
100844088:     	cbnz	w8, 0x1008449dc <_js_json_stringify_full+0x1b9c>
10084408c:     	ldr	x8, [x0]
100844090:     	cbnz	x8, 0x100844a04 <_js_json_stringify_full+0x1bc4>
100844094:     	str	xzr, [x0, #0x18]
100844098:     	ldp	x21, x19, [sp, #0x38]
10084409c:     	ldrb	w8, [x22, #0x18]
1008440a0:     	cmp	w8, #0x1
1008440a4:     	b.ne	0x1008449b8 <_js_json_stringify_full+0x1b78>
1008440a8:     	ldp	x8, x0, [x22]
1008440ac:     	stp	x21, x19, [x22]
1008440b0:     	str	xzr, [x22, #0x10]
1008440b4:     	sub	x8, x8, #0x1
1008440b8:     	cmn	x8, #0x2
1008440bc:     	b.hs	0x1008440c4 <_js_json_stringify_full+0x1284>
1008440c0:     	bl	0x100b5c040 <_mi_free>
1008440c4:     	cbz	w25, 0x1008440e4 <_js_json_stringify_full+0x12a4>
1008440c8:     	bl	0x100325768 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
1008440cc:     	ldr	w8, [x20]
1008440d0:     	sub	w8, w8, #0x1
1008440d4:     	str	w8, [x20]
1008440d8:     	cmn	x24, #0x1
1008440dc:     	b.ne	0x1008442c0 <_js_json_stringify_full+0x1480>
1008440e0:     	b	0x1008442fc <_js_json_stringify_full+0x14bc>
1008440e4:     	bl	0x100325598 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
1008440e8:     	ldr	w8, [x20]
1008440ec:     	sub	w8, w8, #0x1
1008440f0:     	str	w8, [x20]
1008440f4:     	cmn	x24, #0x1
1008440f8:     	b.ne	0x1008442c0 <_js_json_stringify_full+0x1480>
1008440fc:     	b	0x1008442fc <_js_json_stringify_full+0x14bc>
100844100:     	cmp	x19, x23
100844104:     	b.eq	0x100844110 <_js_json_stringify_full+0x12d0>
100844108:     	mov.16b	v0, v8
10084410c:     	bl	0x10050beec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
100844110:     	cbz	x21, 0x10084439c <_js_json_stringify_full+0x155c>
100844114:     	ldp	x1, x2, [sp, #0x8]
100844118:     	add	x0, sp, #0x38
10084411c:     	mov.16b	v0, v8
100844120:     	mov	x3, #0x0                ; =0
100844124:     	bl	0x1004fe5e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
100844128:     	b	0x1008443ac <_js_json_stringify_full+0x156c>
10084412c:     	and	x9, x1, #0x4
100844130:     	add	x8, x0, x9
100844134:     	adrp	x10, 0x100c96000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4da0>
100844138:     	ldr	q0, [x10, #0xad0]
10084413c:     	adrp	x10, 0x100c36000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x335aa>
100844140:     	ldr	q2, [x10, #0x9d0]
100844144:     	movi.2d	v1, #0000000000000000
100844148:     	movi.2d	v3, #0x000000000000ff
10084414c:     	mov	w10, #0x4               ; =4
100844150:     	dup.2d	v4, x10
100844154:     	mov	x10, x0
100844158:     	and	x11, x1, #0x4
10084415c:     	movi.2d	v5, #0000000000000000
100844160:     	ldr	s6, [x10], #0x4
100844164:     	ushll.8h	v6, v6, #0x0
100844168:     	ushll.4s	v6, v6, #0x0
10084416c:     	ushll2.2d	v7, v6, #0x0
100844170:     	and.16b	v7, v7, v3
100844174:     	ushll.2d	v6, v6, #0x0
100844178:     	and.16b	v6, v6, v3
10084417c:     	shl.2d	v16, v0, #0x3
100844180:     	shl.2d	v17, v2, #0x3
100844184:     	ushl.2d	v6, v6, v17
100844188:     	ushl.2d	v7, v7, v16
10084418c:     	orr.16b	v1, v7, v1
100844190:     	orr.16b	v5, v6, v5
100844194:     	add.2d	v0, v0, v4
100844198:     	add.2d	v2, v2, v4
10084419c:     	subs	x11, x11, #0x4
1008441a0:     	b.ne	0x100844160 <_js_json_stringify_full+0x1320>
1008441a4:     	orr.16b	v0, v5, v1
1008441a8:     	mov	d1, v0[1]
1008441ac:     	orr.8b	v0, v0, v1
1008441b0:     	fmov	x10, d0
1008441b4:     	cmp	x1, x9
1008441b8:     	b.eq	0x1008441dc <_js_json_stringify_full+0x139c>
1008441bc:     	add	x11, x0, x1
1008441c0:     	lsl	x9, x9, #3
1008441c4:     	ldrb	w12, [x8], #0x1
1008441c8:     	lsl	x12, x12, x9
1008441cc:     	orr	x10, x12, x10
1008441d0:     	add	x9, x9, #0x8
1008441d4:     	cmp	x8, x11
1008441d8:     	b.ne	0x1008441c4 <_js_json_stringify_full+0x1384>
1008441dc:     	orr	x8, x10, x1, lsl #40
1008441e0:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1008441e4:     	orr	x21, x8, x9
1008441e8:     	ldr	x23, [sp, #0x38]
1008441ec:     	ldrb	w8, [x22, #0x18]
1008441f0:     	cmp	w8, #0x1
1008441f4:     	b.ne	0x100844928 <_js_json_stringify_full+0x1ae8>
1008441f8:     	ldp	x9, x8, [x22]
1008441fc:     	stp	x23, x0, [x22]
100844200:     	str	xzr, [x22, #0x10]
100844204:     	sub	x9, x9, #0x1
100844208:     	cmn	x9, #0x2
10084420c:     	b.hs	0x100844218 <_js_json_stringify_full+0x13d8>
100844210:     	mov	x0, x8
100844214:     	bl	0x100b5c040 <_mi_free>
100844218:     	cbz	w25, 0x100844238 <_js_json_stringify_full+0x13f8>
10084421c:     	bl	0x100325768 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100844220:     	ldr	w8, [x20]
100844224:     	sub	w8, w8, #0x1
100844228:     	str	w8, [x20]
10084422c:     	cmn	x24, #0x1
100844230:     	b.ne	0x100844250 <_js_json_stringify_full+0x1410>
100844234:     	b	0x10084428c <_js_json_stringify_full+0x144c>
100844238:     	bl	0x100325598 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084423c:     	ldr	w8, [x20]
100844240:     	sub	w8, w8, #0x1
100844244:     	str	w8, [x20]
100844248:     	cmn	x24, #0x1
10084424c:     	b.eq	0x10084428c <_js_json_stringify_full+0x144c>
100844250:     	ldp	x19, x20, [sp, #0x28]
100844254:     	cbz	x20, 0x100844280 <_js_json_stringify_full+0x1440>
100844258:     	add	x22, x19, #0x8
10084425c:     	b	0x10084426c <_js_json_stringify_full+0x142c>
100844260:     	add	x22, x22, #0x18
100844264:     	subs	x20, x20, #0x1
100844268:     	b.eq	0x100844280 <_js_json_stringify_full+0x1440>
10084426c:     	ldur	x8, [x22, #-0x8]
100844270:     	cbz	x8, 0x100844260 <_js_json_stringify_full+0x1420>
100844274:     	ldr	x0, [x22]
100844278:     	bl	0x100b5c040 <_mi_free>
10084427c:     	b	0x100844260 <_js_json_stringify_full+0x1420>
100844280:     	cbz	x24, 0x10084428c <_js_json_stringify_full+0x144c>
100844284:     	mov	x0, x19
100844288:     	bl	0x100b5c040 <_mi_free>
10084428c:     	ldr	x8, [sp]
100844290:     	cbz	x8, 0x100844314 <_js_json_stringify_full+0x14d4>
100844294:     	ldr	x0, [sp, #0x8]
100844298:     	bl	0x100b5c040 <_mi_free>
10084429c:     	b	0x100844314 <_js_json_stringify_full+0x14d4>
1008442a0:     	bl	0x100325598 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
1008442a4:     	ldr	w8, [x20]
1008442a8:     	sub	w8, w8, #0x1
1008442ac:     	str	w8, [x20]
1008442b0:     	add	x0, sp, #0x50
1008442b4:     	bl	0x1001644fc <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
1008442b8:     	cmn	x24, #0x1
1008442bc:     	b.eq	0x1008442fc <_js_json_stringify_full+0x14bc>
1008442c0:     	ldp	x19, x20, [sp, #0x28]
1008442c4:     	cbz	x20, 0x1008442f0 <_js_json_stringify_full+0x14b0>
1008442c8:     	add	x21, x19, #0x8
1008442cc:     	b	0x1008442dc <_js_json_stringify_full+0x149c>
1008442d0:     	add	x21, x21, #0x18
1008442d4:     	subs	x20, x20, #0x1
1008442d8:     	b.eq	0x1008442f0 <_js_json_stringify_full+0x14b0>
1008442dc:     	ldur	x8, [x21, #-0x8]
1008442e0:     	cbz	x8, 0x1008442d0 <_js_json_stringify_full+0x1490>
1008442e4:     	ldr	x0, [x21]
1008442e8:     	bl	0x100b5c040 <_mi_free>
1008442ec:     	b	0x1008442d0 <_js_json_stringify_full+0x1490>
1008442f0:     	cbz	x24, 0x1008442fc <_js_json_stringify_full+0x14bc>
1008442f4:     	mov	x0, x19
1008442f8:     	bl	0x100b5c040 <_mi_free>
1008442fc:     	ldr	x8, [sp]
100844300:     	cbz	x8, 0x10084430c <_js_json_stringify_full+0x14cc>
100844304:     	ldr	x0, [sp, #0x8]
100844308:     	bl	0x100b5c040 <_mi_free>
10084430c:     	mov	x21, #0x1               ; =1
100844310:     	movk	x21, #0x7ffc, lsl #48
100844314:     	mov	x0, x21
100844318:     	ldp	x29, x30, [sp, #0x100]
10084431c:     	ldp	x20, x19, [sp, #0xf0]
100844320:     	ldp	x22, x21, [sp, #0xe0]
100844324:     	ldp	x24, x23, [sp, #0xd0]
100844328:     	ldp	x26, x25, [sp, #0xc0]
10084432c:     	ldp	x28, x27, [sp, #0xb0]
100844330:     	ldp	d9, d8, [sp, #0xa0]
100844334:     	add	sp, sp, #0x110
100844338:     	ret
10084433c:     	mov	x26, x21
100844340:     	mov	x21, x28
100844344:     	mov	x28, x0
100844348:     	add	x0, x0, #0x8
10084434c:     	bl	0x100b38dd0 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100844350:     	mov	x0, x28
100844354:     	mov	x28, x21
100844358:     	mov	x21, x26
10084435c:     	mov	x26, #0x1               ; =1
100844360:     	movk	x26, #0x7ffc, lsl #48
100844364:     	b	0x100843b5c <_js_json_stringify_full+0xd1c>
100844368:     	b.ne	0x1008438a0 <_js_json_stringify_full+0xa60>
10084436c:     	tbz	x24, #0x3f, 0x1008443c4 <_js_json_stringify_full+0x1584>
100844370:     	mov	x0, #0x0                ; =0
100844374:     	mov	x1, x24
100844378:     	bl	0x100b0f440 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084437c:     	bl	0x100b3c47c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100844380:     	add	x8, x0, x22, lsl #3
100844384:     	ldr	x0, [x8, #0x1e8]
100844388:     	cbnz	x0, 0x100843bf0 <_js_json_stringify_full+0xdb0>
10084438c:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
100844390:     	add	x0, x0, #0x180
100844394:     	bl	0x100b39c9c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100844398:     	b	0x100843bf0 <_js_json_stringify_full+0xdb0>
10084439c:     	add	x1, sp, #0x38
1008443a0:     	mov.16b	v0, v8
1008443a4:     	mov	w0, #0x0                ; =0
1008443a8:     	bl	0x100506bec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
1008443ac:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008443b0:     	add	x0, x0, #0xdc0
1008443b4:     	ldr	x8, [x0]
1008443b8:     	blr	x8
1008443bc:     	strb	wzr, [x0]
1008443c0:     	b	0x100843d34 <_js_json_stringify_full+0xef4>
1008443c4:     	mov	x0, x24
1008443c8:     	mov	w1, #0x1                ; =1
1008443cc:     	bl	0x100b5c2c8 <_mi_malloc_aligned>
1008443d0:     	mov	x25, x0
1008443d4:     	mov	w0, #0x1                ; =1
1008443d8:     	cbz	x25, 0x100844374 <_js_json_stringify_full+0x1534>
1008443dc:     	mov	x0, x25
1008443e0:     	mov	x1, x22
1008443e4:     	mov	x2, x24
1008443e8:     	bl	0x100b5eeec <_writev+0x100b5eeec>
1008443ec:     	mov	x21, x24
1008443f0:     	b	0x1008438c4 <_js_json_stringify_full+0xa84>
1008443f4:     	cmp	w11, #0x8
1008443f8:     	b.eq	0x1008444c4 <_js_json_stringify_full+0x1684>
1008443fc:     	cmp	w11, #0x9
100844400:     	b.eq	0x1008444d4 <_js_json_stringify_full+0x1694>
100844404:     	cmp	w11, #0xa
100844408:     	b.ne	0x100844450 <_js_json_stringify_full+0x1610>
10084440c:     	mov	w10, #0x6e              ; =110
100844410:     	b	0x1008444d8 <_js_json_stringify_full+0x1698>
100844414:     	mov	x22, x0
100844418:     	and	x0, x19, #0xffffffffffff
10084441c:     	bl	0x1003452c0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
100844420:     	cbz	x0, 0x1008444fc <_js_json_stringify_full+0x16bc>
100844424:     	ldr	w21, [x0]
100844428:     	cmp	w21, #0x4
10084442c:     	b.hi	0x100843428 <_js_json_stringify_full+0x5e8>
100844430:     	ldr	w8, [x0, #0x4]
100844434:     	cmp	w21, w8
100844438:     	b.hi	0x100843428 <_js_json_stringify_full+0x5e8>
10084443c:     	b	0x100844500 <_js_json_stringify_full+0x16c0>
100844440:     	cmp	w11, #0x22
100844444:     	b.eq	0x1008444d8 <_js_json_stringify_full+0x1698>
100844448:     	cmp	w11, #0x5c
10084444c:     	b.eq	0x1008444d8 <_js_json_stringify_full+0x1698>
100844450:     	cmp	x12, #0x3
100844454:     	mov	w11, #0x20              ; =32
100844458:     	ccmp	w10, w11, #0x8, ls
10084445c:     	b.lt	0x100843364 <_js_json_stringify_full+0x524>
100844460:     	add	x8, sp, #0x70
100844464:     	strb	w10, [x8, x12]
100844468:     	add	x12, x12, #0x1
10084446c:     	b	0x100843054 <_js_json_stringify_full+0x214>
100844470:     	mov	x1, x0
100844474:     	and	x0, x19, #0xffffffffffff
100844478:     	mov	x22, x1
10084447c:     	bl	0x1004f6480 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
100844480:     	cmp	x0, #0x1
100844484:     	b.ne	0x1008445a8 <_js_json_stringify_full+0x1768>
100844488:     	mov	x21, x1
10084448c:     	b	0x100844314 <_js_json_stringify_full+0x14d4>
100844490:     	ldrb	w9, [x8, #0x118]
100844494:     	cbz	w9, 0x1008446d0 <_js_json_stringify_full+0x1890>
100844498:     	ldr	x9, [x8, #0x110]
10084449c:     	cmp	x9, x1
1008444a0:     	b.ne	0x1008446d0 <_js_json_stringify_full+0x1890>
1008444a4:     	ldr	x9, [x8, #0xf0]
1008444a8:     	cmp	x9, x22
1008444ac:     	b.hi	0x1008446d0 <_js_json_stringify_full+0x1890>
1008444b0:     	ldr	x9, [x8, #0xf8]
1008444b4:     	cmp	x9, x22
1008444b8:     	b.ls	0x1008446d0 <_js_json_stringify_full+0x1890>
1008444bc:     	add	x9, x8, #0xf0
1008444c0:     	b	0x1008448dc <_js_json_stringify_full+0x1a9c>
1008444c4:     	mov	w10, #0x62              ; =98
1008444c8:     	b	0x1008444d8 <_js_json_stringify_full+0x1698>
1008444cc:     	mov	w10, #0x66              ; =102
1008444d0:     	b	0x1008444d8 <_js_json_stringify_full+0x1698>
1008444d4:     	mov	w10, #0x74              ; =116
1008444d8:     	cmp	x12, #0x2
1008444dc:     	b.hi	0x100843364 <_js_json_stringify_full+0x524>
1008444e0:     	add	x8, sp, #0x70
1008444e4:     	add	x8, x8, x12
1008444e8:     	add	x12, x12, #0x2
1008444ec:     	mov	w11, #0x5c              ; =92
1008444f0:     	strb	w11, [x8]
1008444f4:     	strb	w10, [x8, #0x1]
1008444f8:     	b	0x100843054 <_js_json_stringify_full+0x214>
1008444fc:     	mov	x21, #0x0               ; =0
100844500:     	ldr	w8, [x22, #0x4]
100844504:     	lsl	x9, x21, #3
100844508:     	add	x9, x9, #0x18
10084450c:     	cmp	x9, x8
100844510:     	b.hi	0x100843428 <_js_json_stringify_full+0x5e8>
100844514:     	ldr	w8, [x24, #0x4]
100844518:     	mov	w9, #-0x40000000        ; =-1073741824
10084451c:     	cmp	w8, w9
100844520:     	csel	w8, w8, wzr, lt
100844524:     	mov	x22, x0
100844528:     	mov	x0, x8
10084452c:     	bl	0x1005e29a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
100844530:     	mov	w9, #0x2                ; =2
100844534:     	cmp	w1, #0x2
100844538:     	csel	w10, w1, w9, hi
10084453c:     	tst	w0, #0x1
100844540:     	csel	x8, x10, x9, ne
100844544:     	cmp	x21, x8
100844548:     	b.hi	0x100843428 <_js_json_stringify_full+0x5e8>
10084454c:     	cbz	x21, 0x10084490c <_js_json_stringify_full+0x1acc>
100844550:     	mov	x0, x22
100844554:     	mov	x1, x21
100844558:     	bl	0x1004ed440 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
10084455c:     	tbz	w0, #0x0, 0x100843428 <_js_json_stringify_full+0x5e8>
100844560:     	cmp	x21, #0x1
100844564:     	b.eq	0x1008449a8 <_js_json_stringify_full+0x1b68>
100844568:     	cmp	x21, #0x2
10084456c:     	b.ne	0x100844a60 <_js_json_stringify_full+0x1c20>
100844570:     	mov	x22, #0x0               ; =0
100844574:     	add	x24, x24, #0x10
100844578:     	mov	w8, #0x1                ; =1
10084457c:     	mov	x25, x8
100844580:     	ldr	x1, [x24, x22, lsl #3]
100844584:     	add	x0, sp, #0x70
100844588:     	bl	0x1004ed494 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
10084458c:     	ldr	w8, [sp, #0x70]
100844590:     	cmn	w8, #0x1
100844594:     	b.ne	0x100844a48 <_js_json_stringify_full+0x1c08>
100844598:     	mov	w8, #0x0                ; =0
10084459c:     	mov	w22, #0x1               ; =1
1008445a0:     	tbnz	w25, #0x0, 0x10084457c <_js_json_stringify_full+0x173c>
1008445a4:     	b	0x100844a60 <_js_json_stringify_full+0x1c20>
1008445a8:     	and	x0, x19, #0xffffffffffff
1008445ac:     	bl	0x1003452c0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
1008445b0:     	cbz	x0, 0x10084463c <_js_json_stringify_full+0x17fc>
1008445b4:     	ldr	w21, [x0]
1008445b8:     	cbz	w21, 0x10084463c <_js_json_stringify_full+0x17fc>
1008445bc:     	cmp	w21, #0x8
1008445c0:     	b.hi	0x1008433f4 <_js_json_stringify_full+0x5b4>
1008445c4:     	ldr	w8, [x0, #0x4]
1008445c8:     	cmp	w21, w8
1008445cc:     	b.hi	0x1008433f4 <_js_json_stringify_full+0x5b4>
1008445d0:     	ldr	w8, [x22, #0x4]
1008445d4:     	lsl	x9, x21, #3
1008445d8:     	add	x9, x9, #0x18
1008445dc:     	cmp	x9, x8
1008445e0:     	b.hi	0x1008433f4 <_js_json_stringify_full+0x5b4>
1008445e4:     	ldr	w8, [x24, #0x4]
1008445e8:     	mov	w9, #-0x40000000        ; =-1073741824
1008445ec:     	cmp	w8, w9
1008445f0:     	csel	w8, w8, wzr, lt
1008445f4:     	mov	x22, x0
1008445f8:     	mov	x0, x8
1008445fc:     	bl	0x1005e29a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
100844600:     	mov	w9, #0x2                ; =2
100844604:     	cmp	w1, #0x2
100844608:     	csel	w10, w1, w9, hi
10084460c:     	tst	w0, #0x1
100844610:     	csel	w8, w10, w9, ne
100844614:     	cmp	w21, w8
100844618:     	b.hi	0x1008433f4 <_js_json_stringify_full+0x5b4>
10084461c:     	mov	x0, x22
100844620:     	mov	x1, x21
100844624:     	bl	0x1004ed440 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
100844628:     	cbz	w0, 0x1008433f4 <_js_json_stringify_full+0x5b4>
10084462c:     	and	x0, x19, #0xffffffffffff
100844630:     	mov	x1, x21
100844634:     	bl	0x1004f55c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
100844638:     	b	0x100844644 <_js_json_stringify_full+0x1804>
10084463c:     	and	x0, x19, #0xffffffffffff
100844640:     	bl	0x1004f6340 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
100844644:     	mov	x21, x1
100844648:     	tbz	w0, #0x0, 0x1008433f4 <_js_json_stringify_full+0x5b4>
10084464c:     	b	0x100844314 <_js_json_stringify_full+0x14d4>
100844650:     	add	x9, x8, #0x60
100844654:     	b	0x1008448dc <_js_json_stringify_full+0x1a9c>
100844658:     	bl	0x100b3c47c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084465c:     	lsr	x1, x22, #20
100844660:     	ldr	x8, [x0, #0x10]
100844664:     	ldrb	w9, [x8]
100844668:     	cmp	w9, #0x2
10084466c:     	b.eq	0x1008439cc <_js_json_stringify_full+0xb8c>
100844670:     	ldr	x9, [x8, #0x8]
100844674:     	ldr	x10, [x8, #0x28]
100844678:     	sub	x9, x1, x9
10084467c:     	cmp	x9, x10
100844680:     	b.hs	0x1008446c4 <_js_json_stringify_full+0x1884>
100844684:     	ldr	x10, [x8, #0x20]
100844688:     	mov	w11, #0x28              ; =40
10084468c:     	madd	x9, x9, x11, x10
100844690:     	ldr	x10, [x9]
100844694:     	ldr	x11, [x8, #0x10]
100844698:     	cmp	x10, x11
10084469c:     	b.ne	0x1008446d0 <_js_json_stringify_full+0x1890>
1008446a0:     	ldp	x10, x11, [x9, #0x8]
1008446a4:     	cmp	x10, x22
1008446a8:     	ccmp	x11, x22, #0x0, ls
1008446ac:     	b.ls	0x1008446d0 <_js_json_stringify_full+0x1890>
1008446b0:     	ldr	x10, [x8, #0x30]
1008446b4:     	add	x10, x10, #0x1
1008446b8:     	str	x10, [x8, #0x30]
1008446bc:     	add	x8, x9, #0x21
1008446c0:     	b	0x1008448ec <_js_json_stringify_full+0x1aac>
1008446c4:     	ldr	x9, [x8, #0x58]
1008446c8:     	add	x9, x9, #0x1
1008446cc:     	str	x9, [x8, #0x58]
1008446d0:     	ldr	x9, [x8, #0x38]
1008446d4:     	add	x9, x9, #0x1
1008446d8:     	str	x9, [x8, #0x38]
1008446dc:     	mov	x0, x22
1008446e0:     	bl	0x10051b9c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1008446e4:     	and	w8, w0, #0xff
1008446e8:     	cbz	w8, 0x100844708 <_js_json_stringify_full+0x18c8>
1008446ec:     	ldurb	w8, [x22, #-0x8]
1008446f0:     	ldurb	w9, [x22, #-0x7]
1008446f4:     	mov	w10, #0x82              ; =130
1008446f8:     	and	w9, w9, w10
1008446fc:     	cmp	w9, #0x2
100844700:     	ccmp	w8, #0x1, #0x0, eq
100844704:     	b.eq	0x10084479c <_js_json_stringify_full+0x195c>
100844708:     	mov	x0, x22
10084470c:     	bl	0x100578040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100844710:     	mov	x23, x0
100844714:     	cbz	x0, 0x100844740 <_js_json_stringify_full+0x1900>
100844718:     	ldrb	w8, [x23]
10084471c:     	cmp	w8, #0x1
100844720:     	b.ne	0x100844760 <_js_json_stringify_full+0x1920>
100844724:     	ldrsb	w8, [x23, #0x1]
100844728:     	tbnz	w8, #0x1f, 0x1008447c4 <_js_json_stringify_full+0x1984>
10084472c:     	mov	x0, x23
100844730:     	ldp	w9, w8, [x22]
100844734:     	cmp	w9, w8
100844738:     	b.hi	0x100844848 <_js_json_stringify_full+0x1a08>
10084473c:     	b	0x100844860 <_js_json_stringify_full+0x1a20>
100844740:     	mov	x0, x22
100844744:     	bl	0x1005864b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100844748:     	tbnz	w0, #0x0, 0x100844758 <_js_json_stringify_full+0x1918>
10084474c:     	mov	x0, x22
100844750:     	bl	0x1002a15c8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
100844754:     	tbz	w0, #0x0, 0x100843a6c <_js_json_stringify_full+0xc2c>
100844758:     	mov	x0, #0x0                ; =0
10084475c:     	b	0x100844838 <_js_json_stringify_full+0x19f8>
100844760:     	mov	x0, x23
100844764:     	cmp	w8, #0x1
100844768:     	b.eq	0x100844838 <_js_json_stringify_full+0x19f8>
10084476c:     	cmp	w8, #0x9
100844770:     	b.ne	0x100843a6c <_js_json_stringify_full+0xc2c>
100844774:     	ldr	w8, [x22, #0x4]
100844778:     	mov	w9, #0x5841             ; =22593
10084477c:     	movk	w9, #0x4c5a, lsl #16
100844780:     	cmp	w8, w9
100844784:     	b.ne	0x100843a6c <_js_json_stringify_full+0xc2c>
100844788:     	mov	x0, x22
10084478c:     	bl	0x100373030 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
100844790:     	mov	x22, x0
100844794:     	cbnz	x0, 0x100844888 <_js_json_stringify_full+0x1a48>
100844798:     	b	0x100843a6c <_js_json_stringify_full+0xc2c>
10084479c:     	ldr	w8, [x22]
1008447a0:     	mov	w9, #0xe100             ; =57600
1008447a4:     	movk	w9, #0x5f5, lsl #16
1008447a8:     	orr	w9, w9, #0x1
1008447ac:     	cmp	w8, w9
1008447b0:     	b.hs	0x100844708 <_js_json_stringify_full+0x18c8>
1008447b4:     	ldr	w9, [x22, #0x4]
1008447b8:     	cmp	w8, w9
1008447bc:     	b.ls	0x100844888 <_js_json_stringify_full+0x1a48>
1008447c0:     	b	0x100844708 <_js_json_stringify_full+0x18c8>
1008447c4:     	ldr	x22, [x23, #0x8]
1008447c8:     	mov	x0, x22
1008447cc:     	bl	0x100578040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1008447d0:     	cbz	x0, 0x100843a6c <_js_json_stringify_full+0xc2c>
1008447d4:     	ldrb	w8, [x0]
1008447d8:     	cmp	w8, #0x1
1008447dc:     	b.ne	0x100843a6c <_js_json_stringify_full+0xc2c>
1008447e0:     	ldrsb	w8, [x0, #0x1]
1008447e4:     	tbz	w8, #0x1f, 0x100844730 <_js_json_stringify_full+0x18f0>
1008447e8:     	mov	w25, #0x1               ; =1
1008447ec:     	ldr	x22, [x0, #0x8]
1008447f0:     	mov	x0, x22
1008447f4:     	bl	0x100578040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1008447f8:     	cbz	x0, 0x100843a6c <_js_json_stringify_full+0xc2c>
1008447fc:     	ldrb	w8, [x0]
100844800:     	cmp	w8, #0x1
100844804:     	b.ne	0x100843a6c <_js_json_stringify_full+0xc2c>
100844808:     	cmp	w25, #0x3f
10084480c:     	b.hi	0x100843a6c <_js_json_stringify_full+0xc2c>
100844810:     	add	w25, w25, #0x1
100844814:     	ldrsb	w8, [x0, #0x1]
100844818:     	tbnz	w8, #0x1f, 0x1008447ec <_js_json_stringify_full+0x19ac>
10084481c:     	str	x22, [x23, #0x8]
100844820:     	ldrb	w8, [x23, #0x1]
100844824:     	orr	w8, w8, #0x80
100844828:     	strb	w8, [x23, #0x1]
10084482c:     	ldrb	w8, [x0]
100844830:     	cmp	w8, #0x1
100844834:     	b.ne	0x10084476c <_js_json_stringify_full+0x192c>
100844838:     	ldp	w9, w8, [x22]
10084483c:     	cmp	w9, w8
100844840:     	b.ls	0x100844860 <_js_json_stringify_full+0x1a20>
100844844:     	cbz	x23, 0x100844870 <_js_json_stringify_full+0x1a30>
100844848:     	ldr	w9, [x0, #0x4]
10084484c:     	ubfiz	x8, x8, #3, #32
100844850:     	add	x8, x8, #0x10
100844854:     	cmp	x8, x9
100844858:     	b.eq	0x100844888 <_js_json_stringify_full+0x1a48>
10084485c:     	b	0x100844870 <_js_json_stringify_full+0x1a30>
100844860:     	mov	w8, #0xe100             ; =57600
100844864:     	movk	w8, #0x5f5, lsl #16
100844868:     	cmp	w9, w8
10084486c:     	b.ls	0x100844888 <_js_json_stringify_full+0x1a48>
100844870:     	mov	x0, x22
100844874:     	bl	0x1005864b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100844878:     	tbnz	w0, #0x0, 0x100844888 <_js_json_stringify_full+0x1a48>
10084487c:     	mov	x0, x22
100844880:     	bl	0x1002a15c8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
100844884:     	tbz	w0, #0x0, 0x100843a6c <_js_json_stringify_full+0xc2c>
100844888:     	ldp	w8, w9, [x22]
10084488c:     	sub	w10, w9, #0x1
100844890:     	mov	w11, #0x270f            ; =9999
100844894:     	cmp	w10, w11
100844898:     	ccmp	w8, w9, #0x2, lo
10084489c:     	b.hi	0x100843a6c <_js_json_stringify_full+0xc2c>
1008448a0:     	and	x8, x20, #0xffffffffffff
1008448a4:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
1008448a8:     	cmp	x24, x9
1008448ac:     	csel	x1, x8, x20, eq
1008448b0:     	add	x0, sp, #0x20
1008448b4:     	bl	0x1004fd2f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer20extract_string_array>
1008448b8:     	ldr	x24, [sp, #0x20]
1008448bc:     	cmn	x24, #0x1
1008448c0:     	cset	w23, eq
1008448c4:     	cmp	x27, #0x1
1008448c8:     	cset	w8, hi
1008448cc:     	tst	w8, w23
1008448d0:     	b.ne	0x100843a88 <_js_json_stringify_full+0xc48>
1008448d4:     	b	0x100843af8 <_js_json_stringify_full+0xcb8>
1008448d8:     	add	x9, x8, #0x90
1008448dc:     	ldr	x10, [x8, #0x30]
1008448e0:     	add	x10, x10, #0x1
1008448e4:     	str	x10, [x8, #0x30]
1008448e8:     	add	x8, x9, #0x19
1008448ec:     	ldrb	w8, [x8]
1008448f0:     	cmp	w8, #0xff
1008448f4:     	b.ne	0x1008446e8 <_js_json_stringify_full+0x18a8>
1008448f8:     	b	0x1008446dc <_js_json_stringify_full+0x189c>
1008448fc:     	mov	x0, x22
100844900:     	bl	0x100b1b644 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100844904:     	cbnz	x0, 0x100843c14 <_js_json_stringify_full+0xdd4>
100844908:     	b	0x100844a94 <_js_json_stringify_full+0x1c54>
10084490c:     	and	x0, x19, #0xffffffffffff
100844910:     	bl	0x1004f53f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
100844914:     	mov	w0, w0
100844918:     	mov	x21, #0x7d7b            ; =32123
10084491c:     	movk	x21, #0x200, lsl #32
100844920:     	movk	x21, #0x7ff9, lsl #48
100844924:     	b	0x100844a78 <_js_json_stringify_full+0x1c38>
100844928:     	mov	x19, x0
10084492c:     	mov	x0, x22
100844930:     	bl	0x100b1b644 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100844934:     	mov	x22, x0
100844938:     	mov	x0, x19
10084493c:     	cbnz	x22, 0x1008441f8 <_js_json_stringify_full+0x13b8>
100844940:     	cbnz	x23, 0x100844a24 <_js_json_stringify_full+0x1be4>
100844944:     	b	0x100844a94 <_js_json_stringify_full+0x1c54>
100844948:     	bl	0x100b1b7a4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
10084494c:     	cbnz	x0, 0x100843b3c <_js_json_stringify_full+0xcfc>
100844950:     	b	0x100844a94 <_js_json_stringify_full+0x1c54>
100844954:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100844958:     	add	x0, x0, #0x440
10084495c:     	bl	0x100b0f7ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100844960:     	cmp	w8, #0x1
100844964:     	b.ne	0x100844a94 <_js_json_stringify_full+0x1c54>
100844968:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x60>
10084496c:     	add	x1, x1, #0x18
100844970:     	mov	x19, x0
100844974:     	bl	0x100a1d51c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100844978:     	mov	x0, x19
10084497c:     	strb	wzr, [x19, #0x20]
100844980:     	ldr	x8, [x19]
100844984:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100844988:     	cmp	x8, x9
10084498c:     	b.lo	0x100843d5c <_js_json_stringify_full+0xf1c>
100844990:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100844994:     	add	x0, x0, #0xea8
100844998:     	bl	0x100b0f81c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
10084499c:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008449a0:     	add	x0, x0, #0xec0
1008449a4:     	bl	0x100b0f7ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008449a8:     	and	x0, x19, #0xffffffffffff
1008449ac:     	bl	0x1004ed040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
1008449b0:     	mov	x21, x1
1008449b4:     	b	0x100844a78 <_js_json_stringify_full+0x1c38>
1008449b8:     	mov	x0, x22
1008449bc:     	bl	0x100b1b644 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008449c0:     	mov	x22, x0
1008449c4:     	cbnz	x0, 0x1008440a8 <_js_json_stringify_full+0x1268>
1008449c8:     	b	0x100844a20 <_js_json_stringify_full+0x1be0>
1008449cc:     	adrp	x0, 0x100ef3000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
1008449d0:     	add	x0, x0, #0xd70
1008449d4:     	bl	0x100b0f81c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1008449d8:     	bl	0x100b489d4 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
1008449dc:     	cmp	w8, #0x2
1008449e0:     	b.eq	0x100844a94 <_js_json_stringify_full+0x1c54>
1008449e4:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x60>
1008449e8:     	add	x1, x1, #0x18
1008449ec:     	mov	x19, x0
1008449f0:     	bl	0x100a1d51c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1008449f4:     	mov	x0, x19
1008449f8:     	strb	wzr, [x19, #0x20]
1008449fc:     	ldr	x8, [x19]
100844a00:     	cbz	x8, 0x100844094 <_js_json_stringify_full+0x1254>
100844a04:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100844a08:     	add	x0, x0, #0xe90
100844a0c:     	bl	0x100b0f7ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100844a10:     	mov	x0, x22
100844a14:     	bl	0x100b1b644 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100844a18:     	mov	x22, x0
100844a1c:     	cbnz	x0, 0x100843fc4 <_js_json_stringify_full+0x1184>
100844a20:     	cbz	x21, 0x100844a94 <_js_json_stringify_full+0x1c54>
100844a24:     	mov	x0, x19
100844a28:     	bl	0x100b5c040 <_mi_free>
100844a2c:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100844a30:     	add	x0, x0, #0xc18
100844a34:     	bl	0x100b5569c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100844a38:     	adrp	x0, 0x100c3f000 <_PERRY_EMPTY_STRING+0x9e4>
100844a3c:     	add	x0, x0, #0x540
100844a40:     	mov	w1, #0xf                ; =15
100844a44:     	bl	0x100b4899c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100844a48:     	and	x0, x19, #0xffffffffffff
100844a4c:     	add	x2, sp, #0x70
100844a50:     	mov	x1, x22
100844a54:     	bl	0x1004ed840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
100844a58:     	tbnz	w0, #0x0, 0x100844488 <_js_json_stringify_full+0x1648>
100844a5c:     	mov	w21, #0x2               ; =2
100844a60:     	and	x0, x19, #0xffffffffffff
100844a64:     	mov	x1, x21
100844a68:     	bl	0x1004ebec0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
100844a6c:     	mov	x21, x1
100844a70:     	mov	x26, #0x1               ; =1
100844a74:     	movk	x26, #0x7ffc, lsl #48
100844a78:     	tbnz	w0, #0x0, 0x100844314 <_js_json_stringify_full+0x14d4>
100844a7c:     	mov	w21, #0x1               ; =1
100844a80:     	cmp	x19, x26
100844a84:     	b.eq	0x10084430c <_js_json_stringify_full+0x14cc>
100844a88:     	b	0x100843434 <_js_json_stringify_full+0x5f4>
100844a8c:     	cmp	w8, #0x2
100844a90:     	b.ne	0x100844abc <_js_json_stringify_full+0x1c7c>
100844a94:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100844a98:     	add	x0, x0, #0xc18
100844a9c:     	bl	0x100b5569c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100844aa0:     	adrp	x0, 0x100f2b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x190>
100844aa4:     	add	x0, x0, #0x848
100844aa8:     	bl	0x100b0f8b0 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100844aac:     	adrp	x0, 0x100c3f000 <_PERRY_EMPTY_STRING+0x9e4>
100844ab0:     	add	x0, x0, #0x277
100844ab4:     	mov	w1, #0xb                ; =11
100844ab8:     	bl	0x100b4899c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100844abc:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x60>
100844ac0:     	add	x1, x1, #0x18
100844ac4:     	mov	x19, x0
100844ac8:     	bl	0x100a1d51c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100844acc:     	mov	x0, x19
100844ad0:     	strb	wzr, [x19, #0x20]
100844ad4:     	ldr	x8, [x19]
100844ad8:     	cbz	x8, 0x100843fb0 <_js_json_stringify_full+0x1170>
100844adc:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100844ae0:     	add	x0, x0, #0xe78
100844ae4:     	bl	0x100b0f7ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100844ae8:     	mov	w0, #0x1                ; =1
100844aec:     	mov	x1, x23
100844af0:     	bl	0x100b0f440 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100844af4:     	mov	w0, #0x1                ; =1
100844af8:     	mov	x1, x21
100844afc:     	bl	0x100b0f440 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100844b00:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100844b04:     	add	x2, x2, #0x3c8
100844b08:     	mov	w0, #0x5                ; =5
100844b0c:     	mov	w1, #0x5                ; =5
100844b10:     	bl	0x100b0f94c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
		...
