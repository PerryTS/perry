
benchmarks/json_performance/.work/source-length-hint-r27/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100136500 <__RINvMNtCsjgY6bXVaRmE_4core6optionINtB3_6OptionQNtNtNtCs3gRpqoBkMHm_13perry_runtime5arena12construction17ConstructionBatchE6map_orOhNCNvNtNtBP_6string17json_construction34string_from_json_bytes_known_utf160EBP_>:
100136500:     	cbz	x0, 0x10013654c <__RINvMNtCsjgY6bXVaRmE_4core6optionINtB3_6OptionQNtNtNtCs3gRpqoBkMHm_13perry_runtime5arena12construction17ConstructionBatchE6map_orOhNCNvNtNtBP_6string17json_construction34string_from_json_bytes_known_utf160EBP_+0x4c>
100136504:     	cmn	x1, #0x10
100136508:     	b.hi	0x100136548 <__RINvMNtCsjgY6bXVaRmE_4core6optionINtB3_6OptionQNtNtNtCs3gRpqoBkMHm_13perry_runtime5arena12construction17ConstructionBatchE6map_orOhNCNvNtNtBP_6string17json_construction34string_from_json_bytes_known_utf160EBP_+0x48>
10013650c:     	add	x8, x1, #0xf
100136510:     	and	x8, x8, #0xfffffffffffffff8
100136514:     	cmp	x8, #0x4, lsl #12       ; =0x4000
100136518:     	b.hi	0x100136548 <__RINvMNtCsjgY6bXVaRmE_4core6optionINtB3_6OptionQNtNtNtCs3gRpqoBkMHm_13perry_runtime5arena12construction17ConstructionBatchE6map_orOhNCNvNtNtBP_6string17json_construction34string_from_json_bytes_known_utf160EBP_+0x48>
10013651c:     	ldr	x9, [x0, #0x8]
100136520:     	ldrb	w9, [x9]
100136524:     	tbnz	w9, #0x0, 0x100136548 <__RINvMNtCsjgY6bXVaRmE_4core6optionINtB3_6OptionQNtNtNtCs3gRpqoBkMHm_13perry_runtime5arena12construction17ConstructionBatchE6map_orOhNCNvNtNtBP_6string17json_construction34string_from_json_bytes_known_utf160EBP_+0x48>
100136528:     	ldr	x9, [x0]
10013652c:     	ldp	x10, x11, [x9, #0x8]
100136530:     	add	x10, x10, #0x7
100136534:     	and	x10, x10, #0xfffffffffffffff8
100136538:     	subs	x11, x11, x10
10013653c:     	csel	x11, xzr, x11, lo
100136540:     	cmp	x8, x11
100136544:     	b.ls	0x100136550 <__RINvMNtCsjgY6bXVaRmE_4core6optionINtB3_6OptionQNtNtNtCs3gRpqoBkMHm_13perry_runtime5arena12construction17ConstructionBatchE6map_orOhNCNvNtNtBP_6string17json_construction34string_from_json_bytes_known_utf160EBP_+0x50>
100136548:     	mov	x0, #0x0                ; =0
10013654c:     	ret
100136550:     	ldr	x11, [x9]
100136554:     	add	x11, x11, x10
100136558:     	add	x10, x10, x8
10013655c:     	str	x10, [x9, #0x8]
100136560:     	mov	w9, #0x203              ; =515
100136564:     	stp	w9, w8, [x11]
100136568:     	add	x0, x11, #0x8
10013656c:     	ret
