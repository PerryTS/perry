
benchmarks/json_performance/.work/source-length-hint-r27/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100245e48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value>:
100245e48:     	sub	sp, sp, #0x80
100245e4c:     	stp	x28, x27, [sp, #0x20]
100245e50:     	stp	x26, x25, [sp, #0x30]
100245e54:     	stp	x24, x23, [sp, #0x40]
100245e58:     	stp	x22, x21, [sp, #0x50]
100245e5c:     	stp	x20, x19, [sp, #0x60]
100245e60:     	stp	x29, x30, [sp, #0x70]
100245e64:     	add	x29, sp, #0x70
100245e68:     	mov	x22, x0
100245e6c:     	ldr	x20, [x0, #0x70]
100245e70:     	ldp	x8, x9, [x0]
100245e74:     	cmp	x8, #0x0
100245e78:     	ccmp	x9, x20, #0x0, ne
100245e7c:     	b.eq	0x100245ea8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x60>
100245e80:     	add	x0, sp, #0x8
100245e84:     	mov	x1, x22
100245e88:     	bl	0x1002459f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes>
100245e8c:     	ldr	x23, [sp, #0x8]
100245e90:     	cmn	x23, #0x2
100245e94:     	b.ne	0x100245ed8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x90>
100245e98:     	strb	wzr, [x22, #0xd4]
100245e9c:     	mov	x0, #0x2                ; =2
100245ea0:     	movk	x0, #0x7ffc, lsl #48
100245ea4:     	b	0x100245eb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x70>
100245ea8:     	ldp	x8, x9, [x22, #0x10]
100245eac:     	str	x8, [x22, #0x70]
100245eb0:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100245eb4:     	bfxil	x0, x9, #0, #48
100245eb8:     	ldp	x29, x30, [sp, #0x70]
100245ebc:     	ldp	x20, x19, [sp, #0x60]
100245ec0:     	ldp	x22, x21, [sp, #0x50]
100245ec4:     	ldp	x24, x23, [sp, #0x40]
100245ec8:     	ldp	x26, x25, [sp, #0x30]
100245ecc:     	ldp	x28, x27, [sp, #0x20]
100245ed0:     	add	sp, sp, #0x80
100245ed4:     	ret
100245ed8:     	ldp	x21, x19, [sp, #0x10]
100245edc:     	cmp	x19, #0x6
100245ee0:     	b.hs	0x100245f70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x128>
100245ee4:     	subs	x8, x19, #0x3
100245ee8:     	b.lo	0x100245f9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x154>
100245eec:     	ldrb	w9, [x21]
100245ef0:     	cmp	w9, #0xed
100245ef4:     	b.ne	0x100245f14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xcc>
100245ef8:     	ldrb	w9, [x21, #0x1]
100245efc:     	and	w9, w9, #0xe0
100245f00:     	cmp	w9, #0xa0
100245f04:     	b.ne	0x100245f14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xcc>
100245f08:     	ldrsb	w9, [x21, #0x2]
100245f0c:     	cmn	w9, #0x40
100245f10:     	b.lt	0x100245f70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x128>
100245f14:     	cbz	x8, 0x100245f9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x154>
100245f18:     	ldrb	w9, [x21, #0x1]
100245f1c:     	cmp	w9, #0xed
100245f20:     	b.ne	0x100245f40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xf8>
100245f24:     	ldrb	w9, [x21, #0x2]
100245f28:     	and	w9, w9, #0xe0
100245f2c:     	cmp	w9, #0xa0
100245f30:     	b.ne	0x100245f40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xf8>
100245f34:     	ldrsb	w9, [x21, #0x3]
100245f38:     	cmn	w9, #0x40
100245f3c:     	b.lt	0x100245f70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x128>
100245f40:     	cmp	x8, #0x1
100245f44:     	b.eq	0x100245f9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x154>
100245f48:     	ldrb	w8, [x21, #0x2]
100245f4c:     	cmp	w8, #0xed
100245f50:     	b.ne	0x100245f9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x154>
100245f54:     	ldrb	w8, [x21, #0x3]
100245f58:     	and	w8, w8, #0xe0
100245f5c:     	cmp	w8, #0xa0
100245f60:     	b.ne	0x100245f9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x154>
100245f64:     	ldrsb	w8, [x21, #0x4]
100245f68:     	cmn	w8, #0x40
100245f6c:     	b.ge	0x100245f9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x154>
100245f70:     	cmn	x23, #0x1
100245f74:     	b.eq	0x100245fb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x170>
100245f78:     	mov	x0, x21
100245f7c:     	mov	x1, x19
100245f80:     	bl	0x10034b970 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
100245f84:     	mov	x8, x0
100245f88:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100245f8c:     	bfxil	x0, x8, #0, #48
100245f90:     	cmp	x23, #0x1
100245f94:     	b.ge	0x100246110 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2c8>
100245f98:     	b	0x100245eb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x70>
100245f9c:     	cbz	x19, 0x100246044 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x1fc>
100245fa0:     	cmp	x19, #0x4
100245fa4:     	b.hs	0x10024604c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x204>
100245fa8:     	mov	x10, #0x0               ; =0
100245fac:     	mov	x9, #0x0                ; =0
100245fb0:     	mov	x8, x21
100245fb4:     	b	0x1002460dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x294>
100245fb8:     	ldr	x24, [x22, #0x68]
100245fbc:     	sub	x8, x24, x19
100245fc0:     	cmp	x8, #0x101
100245fc4:     	mov	w8, #0xff               ; =255
100245fc8:     	ccmp	x19, x8, #0x0, lo
100245fcc:     	b.ls	0x100246124 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2dc>
100245fd0:     	ldr	x0, [x22, #0x60]
100245fd4:     	ldr	x23, [x22, #0xc8]
100245fd8:     	mov	x1, x24
100245fdc:     	mov	x2, x23
100245fe0:     	mov	x3, x20
100245fe4:     	mov	x4, x19
100245fe8:     	bl	0x1006c66d0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len>
100245fec:     	tbz	w0, #0x0, 0x100246128 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2e0>
100245ff0:     	mov	x26, x1
100245ff4:     	lsr	w8, w19, #19
100245ff8:     	cbz	w8, 0x100246238 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3f0>
100245ffc:     	mov	w8, w19
100246000:     	add	x0, x8, #0x14
100246004:     	mov	w1, #0x3                ; =3
100246008:     	bl	0x100458500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
10024600c:     	mov	x25, x0
100246010:     	stp	w26, w19, [x0]
100246014:     	str	w19, [x0, #0x8]
100246018:     	mov	x8, #0x200000000        ; =8589934592
10024601c:     	stur	x8, [x0, #0xc]
100246020:     	add	x0, x0, #0x14
100246024:     	mov	x1, x21
100246028:     	mov	x2, x19
10024602c:     	bl	0x100b622ec <_writev+0x100b622ec>
100246030:     	mov	x0, x19
100246034:     	bl	0x1004f0080 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat33note_completed_malloc_json_output>
100246038:     	cmp	x24, #0x200, lsl #12    ; =0x200000
10024603c:     	b.ls	0x100246144 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2fc>
100246040:     	b	0x10024622c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3e4>
100246044:     	mov	x10, #0x0               ; =0
100246048:     	b	0x1002460fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2b4>
10024604c:     	and	x9, x19, #0x4
100246050:     	add	x8, x21, x9
100246054:     	adrp	x10, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x49b0>
100246058:     	ldr	q0, [x10, #0xec0]
10024605c:     	adrp	x10, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x331ba>
100246060:     	ldr	q2, [x10, #0xdc0]
100246064:     	movi.2d	v1, #0000000000000000
100246068:     	movi.2d	v3, #0x000000000000ff
10024606c:     	mov	w10, #0x4               ; =4
100246070:     	dup.2d	v4, x10
100246074:     	mov	x10, x21
100246078:     	and	x11, x19, #0x4
10024607c:     	movi.2d	v5, #0000000000000000
100246080:     	ldr	s6, [x10], #0x4
100246084:     	ushll.8h	v6, v6, #0x0
100246088:     	ushll.4s	v6, v6, #0x0
10024608c:     	ushll2.2d	v7, v6, #0x0
100246090:     	and.16b	v7, v7, v3
100246094:     	ushll.2d	v6, v6, #0x0
100246098:     	and.16b	v6, v6, v3
10024609c:     	shl.2d	v16, v0, #0x3
1002460a0:     	shl.2d	v17, v2, #0x3
1002460a4:     	ushl.2d	v6, v6, v17
1002460a8:     	ushl.2d	v7, v7, v16
1002460ac:     	orr.16b	v1, v7, v1
1002460b0:     	orr.16b	v5, v6, v5
1002460b4:     	add.2d	v0, v0, v4
1002460b8:     	add.2d	v2, v2, v4
1002460bc:     	subs	x11, x11, #0x4
1002460c0:     	b.ne	0x100246080 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x238>
1002460c4:     	orr.16b	v0, v5, v1
1002460c8:     	mov	d1, v0[1]
1002460cc:     	orr.8b	v0, v0, v1
1002460d0:     	fmov	x10, d0
1002460d4:     	cmp	x19, x9
1002460d8:     	b.eq	0x1002460fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2b4>
1002460dc:     	add	x11, x21, x19
1002460e0:     	lsl	x9, x9, #3
1002460e4:     	ldrb	w12, [x8], #0x1
1002460e8:     	lsl	x12, x12, x9
1002460ec:     	orr	x10, x12, x10
1002460f0:     	add	x9, x9, #0x8
1002460f4:     	cmp	x8, x11
1002460f8:     	b.ne	0x1002460e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x29c>
1002460fc:     	orr	x8, x10, x19, lsl #40
100246100:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100246104:     	orr	x0, x8, x9
100246108:     	cmp	x23, #0x1
10024610c:     	b.lt	0x100245eb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x70>
100246110:     	mov	x19, x0
100246114:     	mov	x0, x21
100246118:     	bl	0x100b5f440 <_mi_free>
10024611c:     	mov	x0, x19
100246120:     	b	0x100245eb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x70>
100246124:     	ldr	x23, [x22, #0xc8]
100246128:     	add	x0, x22, #0x20
10024612c:     	mov	x1, x21
100246130:     	mov	x2, x19
100246134:     	bl	0x1005eb184 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>
100246138:     	mov	x25, x0
10024613c:     	cmp	x24, #0x200, lsl #12    ; =0x200000
100246140:     	b.hi	0x10024622c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3e4>
100246144:     	cmp	x19, #0x100
100246148:     	b.lo	0x10024622c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3e4>
10024614c:     	cbz	x23, 0x10024622c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3e4>
100246150:     	cbz	x25, 0x10024622c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3e4>
100246154:     	ldr	x21, [x22, #0x70]
100246158:     	sub	x8, x24, x24, lsr #1
10024615c:     	orr	x9, x21, x20
100246160:     	tst	x9, #0xffffffff00000000
100246164:     	ccmp	x19, x8, #0x0, eq
100246168:     	b.lo	0x10024622c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3e4>
10024616c:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
100246170:     	ldr	w19, [x8, #0x560]
100246174:     	cmp	w19, #0x300
100246178:     	b.hs	0x1002462f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x4a8>
10024617c:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100246180:     	ldr	x8, [x8, #0x48]
100246184:     	cmn	x8, #0x1
100246188:     	b.eq	0x1002462e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x498>
10024618c:     	mrs	x9, TPIDRRO_EL0
100246190:     	and	x9, x9, #0xfffffffffffffff8
100246194:     	ldr	x0, [x9, x8, lsl #3]
100246198:     	cbz	x0, 0x1002462e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x498>
10024619c:     	add	x8, x0, x19, lsl #3
1002461a0:     	ldr	x19, [x8, #0x1e8]
1002461a4:     	cbz	x19, 0x1002462f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x4a8>
1002461a8:     	ldr	x8, [x19]
1002461ac:     	cbnz	x8, 0x100246308 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x4c0>
1002461b0:     	mov	x8, #-0x1               ; =-1
1002461b4:     	str	x8, [x19]
1002461b8:     	ldrb	w8, [x19, #0x24]
1002461bc:     	cmp	w8, #0x2
1002461c0:     	b.eq	0x1002461e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x39c>
1002461c4:     	ldr	x8, [x19, #0x8]
1002461c8:     	cmp	x8, x23
1002461cc:     	b.ne	0x1002461e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x39c>
1002461d0:     	ldr	w8, [x19, #0x18]
1002461d4:     	cmp	w8, w24
1002461d8:     	b.ne	0x1002461e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x39c>
1002461dc:     	mov	x8, #0x0                ; =0
1002461e0:     	b	0x100246228 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3e0>
1002461e4:     	stp	x23, x25, [x19, #0x8]
1002461e8:     	stp	w24, w20, [x19, #0x18]
1002461ec:     	str	w21, [x19, #0x20]
1002461f0:     	strb	wzr, [x19, #0x24]
1002461f4:     	adrp	x20, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1002461f8:     	ldr	w8, [x20, #0x864]
1002461fc:     	cbz	w8, 0x10024620c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3c4>
100246200:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100246204:     	bfxil	x0, x23, #0, #48
100246208:     	bl	0x1004768b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
10024620c:     	ldr	w8, [x20, #0x864]
100246210:     	cbz	w8, 0x100246220 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3d8>
100246214:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100246218:     	bfxil	x0, x25, #0, #48
10024621c:     	bl	0x1004768b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
100246220:     	ldr	x8, [x19]
100246224:     	add	x8, x8, #0x1
100246228:     	str	x8, [x19]
10024622c:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100246230:     	bfxil	x0, x25, #0, #48
100246234:     	b	0x100245eb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x70>
100246238:     	add	x27, x19, #0x14
10024623c:     	ldr	w8, [x22, #0x20]
100246240:     	add	x9, x22, #0x28
100246244:     	cmp	w8, #0x0
100246248:     	csel	x0, x9, xzr, ne
10024624c:     	add	x1, x19, #0x14
100246250:     	bl	0x100136500 <__RINvMNtCsjgY6bXVaRmE_4core6optionINtB3_6OptionQNtNtNtCs3gRpqoBkMHm_13perry_runtime5arena12construction17ConstructionBatchE6map_orOhNCNvNtNtBP_6string17json_construction34string_from_json_bytes_known_utf160EBP_>
100246254:     	cbz	x0, 0x100246288 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x440>
100246258:     	mov	x25, x0
10024625c:     	ldur	w8, [x0, #-0x4]
100246260:     	subs	x8, x8, #0x8
100246264:     	csel	x8, xzr, x8, lo
100246268:     	subs	x9, x8, x27
10024626c:     	csel	x1, xzr, x9, lo
100246270:     	b.ls	0x1002462b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x46c>
100246274:     	cmp	x1, #0x9
100246278:     	b.hs	0x1002462ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x464>
10024627c:     	add	x8, x25, x8
100246280:     	stur	xzr, [x8, #-0x8]
100246284:     	b	0x1002462b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x46c>
100246288:     	mov	x0, x19
10024628c:     	bl	0x10034b32c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100246290:     	mov	x25, x0
100246294:     	mov	x0, x1
100246298:     	stp	w26, w19, [x25]
10024629c:     	str	w19, [x25, #0x8]
1002462a0:     	mov	x8, #0x200000000        ; =8589934592
1002462a4:     	stur	x8, [x25, #0xc]
1002462a8:     	b	0x1002462c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x480>
1002462ac:     	add	x0, x25, x27
1002462b0:     	bl	0x100b61e24 <_writev+0x100b61e24>
1002462b4:     	stp	w26, w19, [x25]
1002462b8:     	str	w19, [x25, #0x8]
1002462bc:     	mov	x8, #0x200000000        ; =8589934592
1002462c0:     	stur	x8, [x25, #0xc]
1002462c4:     	add	x0, x25, #0x14
1002462c8:     	mov	x1, x21
1002462cc:     	mov	x2, x19
1002462d0:     	bl	0x100b622ec <_writev+0x100b622ec>
1002462d4:     	cmp	x24, #0x200, lsl #12    ; =0x200000
1002462d8:     	b.ls	0x100246144 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2fc>
1002462dc:     	b	0x10024622c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3e4>
1002462e0:     	bl	0x100b3f87c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1002462e4:     	add	x8, x0, x19, lsl #3
1002462e8:     	ldr	x19, [x8, #0x1e8]
1002462ec:     	cbnz	x19, 0x1002461a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x360>
1002462f0:     	adrp	x0, 0x100f0f000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1002462f4:     	add	x0, x0, #0xfa0
1002462f8:     	bl	0x100b3d09c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1002462fc:     	mov	x19, x0
100246300:     	ldr	x8, [x0]
100246304:     	cbz	x8, 0x1002461b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x368>
100246308:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10024630c:     	add	x0, x0, #0xce0
100246310:     	bl	0x100b12bac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
		...
