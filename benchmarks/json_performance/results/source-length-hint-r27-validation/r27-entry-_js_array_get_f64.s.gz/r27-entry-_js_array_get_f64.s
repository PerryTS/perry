
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/source-length-hint-r27/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007be3d0 <_js_array_get_f64>:
1007be3d0:     	sub	sp, sp, #0x70
1007be3d4:     	stp	x26, x25, [sp, #0x20]
1007be3d8:     	stp	x24, x23, [sp, #0x30]
1007be3dc:     	stp	x22, x21, [sp, #0x40]
1007be3e0:     	stp	x20, x19, [sp, #0x50]
1007be3e4:     	stp	x29, x30, [sp, #0x60]
1007be3e8:     	add	x29, sp, #0x60
1007be3ec:     	mov	x19, x1
1007be3f0:     	mov	x22, x0
1007be3f4:     	lsr	x25, x0, #51
1007be3f8:     	mov	x20, x0
1007be3fc:     	cmp	x25, #0xfff
1007be400:     	b.lo	0x1007be41c <_js_array_get_f64+0x4c>
1007be404:     	mov	w8, #0x7ffc             ; =32764
1007be408:     	cmp	x8, x22, lsr #48
1007be40c:     	b.ne	0x1007be418 <_js_array_get_f64+0x48>
1007be410:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007be414:     	b	0x1007beac8 <_js_array_get_f64+0x6f8>
1007be418:     	and	x20, x22, #0xffffffffffff
1007be41c:     	lsr	x8, x20, #3
1007be420:     	cmp	x8, #0x200
1007be424:     	b.ls	0x1007be45c <_js_array_get_f64+0x8c>
1007be428:     	ldurb	w8, [x20, #-0x8]
1007be42c:     	cmp	w8, #0x9
1007be430:     	b.ne	0x1007be45c <_js_array_get_f64+0x8c>
1007be434:     	ldr	w8, [x20, #0x4]
1007be438:     	mov	w9, #0x5841             ; =22593
1007be43c:     	movk	w9, #0x4c5a, lsl #16
1007be440:     	cmp	w8, w9
1007be444:     	b.ne	0x1007be45c <_js_array_get_f64+0x8c>
1007be448:     	mov	x0, x20
1007be44c:     	mov	x1, x19
1007be450:     	bl	0x100688184 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get>
1007be454:     	fmov	d0, x0
1007be458:     	b	0x1007beacc <_js_array_get_f64+0x6fc>
1007be45c:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007be460:     	b.lo	0x1007be510 <_js_array_get_f64+0x140>
1007be464:     	tst	x20, #0xffff800000000000
1007be468:     	mov	w8, #0x1000             ; =4096
1007be46c:     	ccmp	x20, x8, #0x0, eq
1007be470:     	b.lo	0x1007be510 <_js_array_get_f64+0x140>
1007be474:     	ldurb	w24, [x20, #-0x8]
1007be478:     	ldurh	w23, [x20, #-0x6]
1007be47c:     	cmp	w24, #0xa
1007be480:     	b.gt	0x1007be628 <_js_array_get_f64+0x258>
1007be484:     	cmp	w24, #0x2
1007be488:     	b.eq	0x1007be6b0 <_js_array_get_f64+0x2e0>
1007be48c:     	cmp	w24, #0x8
1007be490:     	b.ne	0x1007be518 <_js_array_get_f64+0x148>
1007be494:     	mov	x0, x20
1007be498:     	bl	0x100305328 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007be49c:     	cbz	w0, 0x1007be740 <_js_array_get_f64+0x370>
1007be4a0:     	mov	x22, #0x1               ; =1
1007be4a4:     	movk	x22, #0x7ffc, lsl #48
1007be4a8:     	lsr	x8, x20, #51
1007be4ac:     	cmp	x8, #0xfff
1007be4b0:     	b.lo	0x1007be4c4 <_js_array_get_f64+0xf4>
1007be4b4:     	mov	w8, #0x7ffc             ; =32764
1007be4b8:     	cmp	x8, x20, lsr #48
1007be4bc:     	b.eq	0x1007beac8 <_js_array_get_f64+0x6f8>
1007be4c0:     	and	x20, x20, #0xffffffffffff
1007be4c4:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007be4c8:     	b.lo	0x1007be4e8 <_js_array_get_f64+0x118>
1007be4cc:     	tst	x20, #0xffff800000000000
1007be4d0:     	mov	w8, #0x1000             ; =4096
1007be4d4:     	ccmp	x20, x8, #0x0, eq
1007be4d8:     	b.lo	0x1007be4e8 <_js_array_get_f64+0x118>
1007be4dc:     	ldurb	w8, [x20, #-0x8]
1007be4e0:     	cmp	w8, #0x2
1007be4e4:     	b.eq	0x1007bedb4 <_js_array_get_f64+0x9e4>
1007be4e8:     	cbz	x20, 0x1007beac8 <_js_array_get_f64+0x6f8>
1007be4ec:     	mov	x0, x20
1007be4f0:     	mov	x1, x19
1007be4f4:     	bl	0x1003054d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007be4f8:     	cmp	w0, #0x1
1007be4fc:     	b.ne	0x1007beac8 <_js_array_get_f64+0x6f8>
1007be500:     	ldr	x8, [x20, #0x8]
1007be504:     	ubfiz	x9, x1, #4, #32
1007be508:     	ldr	x22, [x8, x9]
1007be50c:     	b	0x1007beac8 <_js_array_get_f64+0x6f8>
1007be510:     	mov	w23, #0x0               ; =0
1007be514:     	mov	w24, #0x0               ; =0
1007be518:     	mov	x21, x22
1007be51c:     	cmp	x25, #0xfff
1007be520:     	b.lo	0x1007be538 <_js_array_get_f64+0x168>
1007be524:     	mov	w8, #0x7ffc             ; =32764
1007be528:     	cmp	x8, x22, lsr #48
1007be52c:     	b.eq	0x1007beab4 <_js_array_get_f64+0x6e4>
1007be530:     	ands	x21, x22, #0xffffffffffff
1007be534:     	b.eq	0x1007beab4 <_js_array_get_f64+0x6e4>
1007be538:     	and	x8, x21, #0xfffffffffff00000
1007be53c:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007be540:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007be544:     	cmp	x9, x10
1007be548:     	ccmp	x8, #0x0, #0x4, lo
1007be54c:     	b.eq	0x1007beab4 <_js_array_get_f64+0x6e4>
1007be550:     	tst	x21, #0x3
1007be554:     	ccmp	x21, #0x7, #0x0, eq
1007be558:     	b.ls	0x1007be808 <_js_array_get_f64+0x438>
1007be55c:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be560:     	ldr	x8, [x8, #0x48]
1007be564:     	cmn	x8, #0x1
1007be568:     	b.eq	0x1007be758 <_js_array_get_f64+0x388>
1007be56c:     	mrs	x9, TPIDRRO_EL0
1007be570:     	and	x9, x9, #0xfffffffffffffff8
1007be574:     	ldr	x0, [x9, x8, lsl #3]
1007be578:     	cbz	x0, 0x1007be758 <_js_array_get_f64+0x388>
1007be57c:     	lsr	x1, x21, #20
1007be580:     	ldr	x8, [x0, #0x10]
1007be584:     	ldrb	w9, [x8]
1007be588:     	cmp	w9, #0x2
1007be58c:     	b.ne	0x1007be770 <_js_array_get_f64+0x3a0>
1007be590:     	ldrb	w9, [x8, #0x88]
1007be594:     	tbz	w9, #0x0, 0x1007be5b4 <_js_array_get_f64+0x1e4>
1007be598:     	ldr	x9, [x8, #0x80]
1007be59c:     	cmp	x9, x1
1007be5a0:     	b.ne	0x1007be5b4 <_js_array_get_f64+0x1e4>
1007be5a4:     	ldp	x9, x10, [x8, #0x60]
1007be5a8:     	cmp	x9, x21
1007be5ac:     	ccmp	x10, x21, #0x0, ls
1007be5b0:     	b.hi	0x1007be750 <_js_array_get_f64+0x380>
1007be5b4:     	ldrb	w9, [x8, #0xb8]
1007be5b8:     	cbz	w9, 0x1007be5d8 <_js_array_get_f64+0x208>
1007be5bc:     	ldr	x9, [x8, #0xb0]
1007be5c0:     	cmp	x9, x1
1007be5c4:     	b.ne	0x1007be5d8 <_js_array_get_f64+0x208>
1007be5c8:     	ldp	x9, x10, [x8, #0x90]
1007be5cc:     	cmp	x9, x21
1007be5d0:     	ccmp	x10, x21, #0x0, ls
1007be5d4:     	b.hi	0x1007bec18 <_js_array_get_f64+0x848>
1007be5d8:     	ldrb	w9, [x8, #0xe8]
1007be5dc:     	cbz	w9, 0x1007be5fc <_js_array_get_f64+0x22c>
1007be5e0:     	ldr	x9, [x8, #0xe0]
1007be5e4:     	cmp	x9, x1
1007be5e8:     	b.ne	0x1007be5fc <_js_array_get_f64+0x22c>
1007be5ec:     	ldp	x9, x10, [x8, #0xc0]
1007be5f0:     	cmp	x9, x21
1007be5f4:     	ccmp	x10, x21, #0x0, ls
1007be5f8:     	b.hi	0x1007bed00 <_js_array_get_f64+0x930>
1007be5fc:     	ldrb	w9, [x8, #0x118]
1007be600:     	cbz	w9, 0x1007be7d0 <_js_array_get_f64+0x400>
1007be604:     	ldr	x9, [x8, #0x110]
1007be608:     	cmp	x9, x1
1007be60c:     	b.ne	0x1007be7d0 <_js_array_get_f64+0x400>
1007be610:     	ldp	x9, x10, [x8, #0xf0]
1007be614:     	cmp	x9, x21
1007be618:     	ccmp	x10, x21, #0x0, ls
1007be61c:     	b.ls	0x1007be7d0 <_js_array_get_f64+0x400>
1007be620:     	add	x9, x8, #0xf0
1007be624:     	b	0x1007bed04 <_js_array_get_f64+0x934>
1007be628:     	cmp	w24, #0xb
1007be62c:     	b.eq	0x1007be6c8 <_js_array_get_f64+0x2f8>
1007be630:     	cmp	w24, #0xc
1007be634:     	b.ne	0x1007be518 <_js_array_get_f64+0x148>
1007be638:     	mov	x0, x20
1007be63c:     	bl	0x10030b0b8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007be640:     	cbz	w0, 0x1007be748 <_js_array_get_f64+0x378>
1007be644:     	mov	x22, #0x1               ; =1
1007be648:     	movk	x22, #0x7ffc, lsl #48
1007be64c:     	lsr	x8, x20, #51
1007be650:     	cmp	x8, #0xfff
1007be654:     	b.lo	0x1007be668 <_js_array_get_f64+0x298>
1007be658:     	mov	w8, #0x7ffc             ; =32764
1007be65c:     	cmp	x8, x20, lsr #48
1007be660:     	b.eq	0x1007beac8 <_js_array_get_f64+0x6f8>
1007be664:     	and	x20, x20, #0xffffffffffff
1007be668:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007be66c:     	b.lo	0x1007be68c <_js_array_get_f64+0x2bc>
1007be670:     	tst	x20, #0xffff800000000000
1007be674:     	mov	w8, #0x1000             ; =4096
1007be678:     	ccmp	x20, x8, #0x0, eq
1007be67c:     	b.lo	0x1007be68c <_js_array_get_f64+0x2bc>
1007be680:     	ldurb	w8, [x20, #-0x8]
1007be684:     	cmp	w8, #0x2
1007be688:     	b.eq	0x1007bedcc <_js_array_get_f64+0x9fc>
1007be68c:     	cbz	x20, 0x1007beac8 <_js_array_get_f64+0x6f8>
1007be690:     	mov	x0, x20
1007be694:     	mov	x1, x19
1007be698:     	bl	0x10030cd30 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007be69c:     	cmp	w0, #0x1
1007be6a0:     	b.ne	0x1007beac8 <_js_array_get_f64+0x6f8>
1007be6a4:     	ldr	x8, [x20, #0x8]
1007be6a8:     	ldr	x22, [x8, w1, uxtw #3]
1007be6ac:     	b	0x1007beac8 <_js_array_get_f64+0x6f8>
1007be6b0:     	mov	x0, x22
1007be6b4:     	mov	x1, x19
1007be6b8:     	bl	0x10054888c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007be6bc:     	tbnz	w0, #0x0, 0x1007beac4 <_js_array_get_f64+0x6f4>
1007be6c0:     	mov	w24, #0x2               ; =2
1007be6c4:     	b	0x1007be518 <_js_array_get_f64+0x148>
1007be6c8:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be6cc:     	add	x8, x8, #0xec0
1007be6d0:     	ldaprb	w8, [x8]
1007be6d4:     	cbz	w8, 0x1007be738 <_js_array_get_f64+0x368>
1007be6d8:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be6dc:     	add	x8, x8, #0x58
1007be6e0:     	ldapr	x8, [x8]
1007be6e4:     	cmp	x20, x8
1007be6e8:     	b.lo	0x1007be738 <_js_array_get_f64+0x368>
1007be6ec:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be6f0:     	add	x8, x8, #0x60
1007be6f4:     	ldapr	x8, [x8]
1007be6f8:     	cmp	x20, x8
1007be6fc:     	b.hi	0x1007be738 <_js_array_get_f64+0x368>
1007be700:     	mov	x0, x20
1007be704:     	bl	0x1002a4df8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be708:     	tbz	w0, #0x0, 0x1007be738 <_js_array_get_f64+0x368>
1007be70c:     	add	x0, sp, #0x8
1007be710:     	mov	x1, x20
1007be714:     	bl	0x1002a4c2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007be718:     	ldr	x8, [sp, #0x8]
1007be71c:     	cbz	x8, 0x1007bed44 <_js_array_get_f64+0x974>
1007be720:     	cmp	x8, #0x1
1007be724:     	b.ne	0x1007bed88 <_js_array_get_f64+0x9b8>
1007be728:     	ldr	d0, [sp, #0x10]
1007be72c:     	scvtf	d1, w19
1007be730:     	bl	0x10081c974 <_js_dyn_index_get>
1007be734:     	b	0x1007beac4 <_js_array_get_f64+0x6f4>
1007be738:     	mov	w24, #0xb               ; =11
1007be73c:     	b	0x1007be518 <_js_array_get_f64+0x148>
1007be740:     	mov	w24, #0x8               ; =8
1007be744:     	b	0x1007be518 <_js_array_get_f64+0x148>
1007be748:     	mov	w24, #0xc               ; =12
1007be74c:     	b	0x1007be518 <_js_array_get_f64+0x148>
1007be750:     	add	x9, x8, #0x60
1007be754:     	b	0x1007bed04 <_js_array_get_f64+0x934>
1007be758:     	bl	0x100b3f87c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007be75c:     	lsr	x1, x21, #20
1007be760:     	ldr	x8, [x0, #0x10]
1007be764:     	ldrb	w9, [x8]
1007be768:     	cmp	w9, #0x2
1007be76c:     	b.eq	0x1007be590 <_js_array_get_f64+0x1c0>
1007be770:     	ldr	x9, [x8, #0x8]
1007be774:     	ldr	x10, [x8, #0x28]
1007be778:     	sub	x9, x1, x9
1007be77c:     	cmp	x9, x10
1007be780:     	b.hs	0x1007be7c4 <_js_array_get_f64+0x3f4>
1007be784:     	ldr	x10, [x8, #0x20]
1007be788:     	mov	w11, #0x28              ; =40
1007be78c:     	madd	x9, x9, x11, x10
1007be790:     	ldr	x10, [x9]
1007be794:     	ldr	x11, [x8, #0x10]
1007be798:     	cmp	x10, x11
1007be79c:     	b.ne	0x1007be7d0 <_js_array_get_f64+0x400>
1007be7a0:     	ldp	x10, x11, [x9, #0x8]
1007be7a4:     	cmp	x10, x21
1007be7a8:     	ccmp	x11, x21, #0x0, ls
1007be7ac:     	b.ls	0x1007be7d0 <_js_array_get_f64+0x400>
1007be7b0:     	ldr	x10, [x8, #0x30]
1007be7b4:     	add	x10, x10, #0x1
1007be7b8:     	str	x10, [x8, #0x30]
1007be7bc:     	add	x8, x9, #0x21
1007be7c0:     	b	0x1007bed14 <_js_array_get_f64+0x944>
1007be7c4:     	ldr	x9, [x8, #0x58]
1007be7c8:     	add	x9, x9, #0x1
1007be7cc:     	str	x9, [x8, #0x58]
1007be7d0:     	ldr	x9, [x8, #0x38]
1007be7d4:     	add	x9, x9, #0x1
1007be7d8:     	str	x9, [x8, #0x38]
1007be7dc:     	mov	x0, x21
1007be7e0:     	bl	0x10051e5c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007be7e4:     	and	w8, w0, #0xff
1007be7e8:     	cbz	w8, 0x1007be808 <_js_array_get_f64+0x438>
1007be7ec:     	ldurb	w8, [x21, #-0x8]
1007be7f0:     	ldurb	w9, [x21, #-0x7]
1007be7f4:     	mov	w10, #0x82              ; =130
1007be7f8:     	and	w9, w9, w10
1007be7fc:     	cmp	w9, #0x2
1007be800:     	ccmp	w8, #0x1, #0x0, eq
1007be804:     	b.eq	0x1007be8d8 <_js_array_get_f64+0x508>
1007be808:     	mov	x0, x21
1007be80c:     	bl	0x10057ac40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be810:     	cbz	x0, 0x1007be838 <_js_array_get_f64+0x468>
1007be814:     	ldrb	w9, [x0]
1007be818:     	cmp	w9, #0x1
1007be81c:     	b.ne	0x1007be854 <_js_array_get_f64+0x484>
1007be820:     	ldrsb	w8, [x0, #0x1]
1007be824:     	tbnz	w8, #0x1f, 0x1007be900 <_js_array_get_f64+0x530>
1007be828:     	ldp	w10, w9, [x21]
1007be82c:     	cmp	w10, w9
1007be830:     	b.hi	0x1007be98c <_js_array_get_f64+0x5bc>
1007be834:     	b	0x1007be9a4 <_js_array_get_f64+0x5d4>
1007be838:     	mov	x25, x0
1007be83c:     	mov	x0, x21
1007be840:     	bl	0x100589474 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be844:     	tbz	w0, #0x0, 0x1007be890 <_js_array_get_f64+0x4c0>
1007be848:     	mov	x0, #0x0                ; =0
1007be84c:     	mov	x8, x25
1007be850:     	b	0x1007be97c <_js_array_get_f64+0x5ac>
1007be854:     	mov	x8, x0
1007be858:     	cmp	w9, #0x1
1007be85c:     	b.eq	0x1007be97c <_js_array_get_f64+0x5ac>
1007be860:     	cmp	w9, #0x9
1007be864:     	b.ne	0x1007beab4 <_js_array_get_f64+0x6e4>
1007be868:     	ldr	w8, [x21, #0x4]
1007be86c:     	mov	w9, #0x5841             ; =22593
1007be870:     	movk	w9, #0x4c5a, lsl #16
1007be874:     	cmp	w8, w9
1007be878:     	b.ne	0x1007beab4 <_js_array_get_f64+0x6e4>
1007be87c:     	mov	x0, x21
1007be880:     	bl	0x100375fd0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007be884:     	cbz	x0, 0x1007beab4 <_js_array_get_f64+0x6e4>
1007be888:     	mov	x21, x0
1007be88c:     	b	0x1007be9c0 <_js_array_get_f64+0x5f0>
1007be890:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be894:     	add	x8, x8, #0xec0
1007be898:     	ldaprb	w8, [x8]
1007be89c:     	cbz	w8, 0x1007beab4 <_js_array_get_f64+0x6e4>
1007be8a0:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be8a4:     	add	x8, x8, #0x58
1007be8a8:     	ldapr	x8, [x8]
1007be8ac:     	cmp	x8, x21
1007be8b0:     	b.hi	0x1007beab4 <_js_array_get_f64+0x6e4>
1007be8b4:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be8b8:     	add	x8, x8, #0x60
1007be8bc:     	ldapr	x8, [x8]
1007be8c0:     	cmp	x8, x21
1007be8c4:     	b.lo	0x1007beab4 <_js_array_get_f64+0x6e4>
1007be8c8:     	mov	x0, x21
1007be8cc:     	bl	0x1002a4df8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be8d0:     	tbnz	w0, #0x0, 0x1007be848 <_js_array_get_f64+0x478>
1007be8d4:     	b	0x1007beab4 <_js_array_get_f64+0x6e4>
1007be8d8:     	ldr	w8, [x21]
1007be8dc:     	mov	w9, #0xe100             ; =57600
1007be8e0:     	movk	w9, #0x5f5, lsl #16
1007be8e4:     	orr	w9, w9, #0x1
1007be8e8:     	cmp	w8, w9
1007be8ec:     	b.hs	0x1007be808 <_js_array_get_f64+0x438>
1007be8f0:     	ldr	w9, [x21, #0x4]
1007be8f4:     	cmp	w8, w9
1007be8f8:     	b.ls	0x1007be9c0 <_js_array_get_f64+0x5f0>
1007be8fc:     	b	0x1007be808 <_js_array_get_f64+0x438>
1007be900:     	mov	x25, x0
1007be904:     	ldr	x21, [x0, #0x8]
1007be908:     	mov	x0, x21
1007be90c:     	bl	0x10057ac40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be910:     	cbz	x0, 0x1007beab4 <_js_array_get_f64+0x6e4>
1007be914:     	ldrb	w8, [x0]
1007be918:     	cmp	w8, #0x1
1007be91c:     	b.ne	0x1007beab4 <_js_array_get_f64+0x6e4>
1007be920:     	ldrsb	w8, [x0, #0x1]
1007be924:     	tbz	w8, #0x1f, 0x1007be828 <_js_array_get_f64+0x458>
1007be928:     	mov	w26, #0x1               ; =1
1007be92c:     	ldr	x21, [x0, #0x8]
1007be930:     	mov	x0, x21
1007be934:     	bl	0x10057ac40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be938:     	cbz	x0, 0x1007beab4 <_js_array_get_f64+0x6e4>
1007be93c:     	ldrb	w8, [x0]
1007be940:     	cmp	w8, #0x1
1007be944:     	b.ne	0x1007beab4 <_js_array_get_f64+0x6e4>
1007be948:     	cmp	w26, #0x3f
1007be94c:     	b.hi	0x1007beab4 <_js_array_get_f64+0x6e4>
1007be950:     	add	w26, w26, #0x1
1007be954:     	ldrsb	w8, [x0, #0x1]
1007be958:     	tbnz	w8, #0x1f, 0x1007be92c <_js_array_get_f64+0x55c>
1007be95c:     	str	x21, [x25, #0x8]
1007be960:     	ldrb	w8, [x25, #0x1]
1007be964:     	orr	w9, w8, #0x80
1007be968:     	mov	x8, x25
1007be96c:     	strb	w9, [x25, #0x1]
1007be970:     	ldrb	w9, [x0]
1007be974:     	cmp	w9, #0x1
1007be978:     	b.ne	0x1007be860 <_js_array_get_f64+0x490>
1007be97c:     	ldp	w10, w9, [x21]
1007be980:     	cmp	w10, w9
1007be984:     	b.ls	0x1007be9a4 <_js_array_get_f64+0x5d4>
1007be988:     	cbz	x8, 0x1007be9b4 <_js_array_get_f64+0x5e4>
1007be98c:     	ldr	w8, [x0, #0x4]
1007be990:     	ubfiz	x9, x9, #3, #32
1007be994:     	add	x9, x9, #0x10
1007be998:     	cmp	x9, x8
1007be99c:     	b.eq	0x1007be9c0 <_js_array_get_f64+0x5f0>
1007be9a0:     	b	0x1007be9b4 <_js_array_get_f64+0x5e4>
1007be9a4:     	mov	w8, #0xe100             ; =57600
1007be9a8:     	movk	w8, #0x5f5, lsl #16
1007be9ac:     	cmp	w10, w8
1007be9b0:     	b.ls	0x1007be9c0 <_js_array_get_f64+0x5f0>
1007be9b4:     	mov	x0, x21
1007be9b8:     	bl	0x100589474 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be9bc:     	tbz	w0, #0x0, 0x1007bea70 <_js_array_get_f64+0x6a0>
1007be9c0:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be9c4:     	add	x8, x8, #0xec0
1007be9c8:     	ldaprb	w8, [x8]
1007be9cc:     	cbz	w8, 0x1007bea14 <_js_array_get_f64+0x644>
1007be9d0:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be9d4:     	add	x8, x8, #0x58
1007be9d8:     	ldapr	x8, [x8]
1007be9dc:     	cmp	x21, x8
1007be9e0:     	b.lo	0x1007bea14 <_js_array_get_f64+0x644>
1007be9e4:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be9e8:     	add	x8, x8, #0x60
1007be9ec:     	ldapr	x8, [x8]
1007be9f0:     	cmp	x21, x8
1007be9f4:     	b.hi	0x1007bea14 <_js_array_get_f64+0x644>
1007be9f8:     	mov	x0, x21
1007be9fc:     	bl	0x1002a4df8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bea00:     	tbz	w0, #0x0, 0x1007bea14 <_js_array_get_f64+0x644>
1007bea04:     	mov	x0, x21
1007bea08:     	mov	x1, x19
1007bea0c:     	bl	0x1008fc688 <_js_typed_array_get>
1007bea10:     	b	0x1007beac4 <_js_array_get_f64+0x6f4>
1007bea14:     	mov	x0, x21
1007bea18:     	bl	0x100589474 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bea1c:     	tbz	w0, #0x0, 0x1007bea44 <_js_array_get_f64+0x674>
1007bea20:     	mov	x0, x21
1007bea24:     	mov	x1, x19
1007bea28:     	bl	0x10058679c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007bea2c:     	and	w8, w1, #0xff
1007bea30:     	ucvtf	d0, w8
1007bea34:     	fmov	x8, d0
1007bea38:     	tst	w0, #0x1
1007bea3c:     	csel	x22, x8, xzr, ne
1007bea40:     	b	0x1007beac8 <_js_array_get_f64+0x6f8>
1007bea44:     	cmp	x21, x20
1007bea48:     	b.eq	0x1007beaf0 <_js_array_get_f64+0x720>
1007bea4c:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007bea50:     	b.lo	0x1007beae8 <_js_array_get_f64+0x718>
1007bea54:     	tst	x21, #0xffff800000000000
1007bea58:     	mov	w8, #0x1000             ; =4096
1007bea5c:     	ccmp	x21, x8, #0x0, eq
1007bea60:     	b.lo	0x1007beae8 <_js_array_get_f64+0x718>
1007bea64:     	ldurb	w24, [x21, #-0x8]
1007bea68:     	ldurh	w23, [x21, #-0x6]
1007bea6c:     	b	0x1007beaf0 <_js_array_get_f64+0x720>
1007bea70:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007bea74:     	add	x8, x8, #0xec0
1007bea78:     	ldaprb	w8, [x8]
1007bea7c:     	cbz	w8, 0x1007beab4 <_js_array_get_f64+0x6e4>
1007bea80:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007bea84:     	add	x8, x8, #0x58
1007bea88:     	ldapr	x8, [x8]
1007bea8c:     	cmp	x21, x8
1007bea90:     	b.lo	0x1007beab4 <_js_array_get_f64+0x6e4>
1007bea94:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007bea98:     	add	x8, x8, #0x60
1007bea9c:     	ldapr	x8, [x8]
1007beaa0:     	cmp	x21, x8
1007beaa4:     	b.hi	0x1007beab4 <_js_array_get_f64+0x6e4>
1007beaa8:     	mov	x0, x21
1007beaac:     	bl	0x1002a4df8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007beab0:     	tbnz	w0, #0x0, 0x1007be9c0 <_js_array_get_f64+0x5f0>
1007beab4:     	mov	x0, x22
1007beab8:     	mov	x1, x19
1007beabc:     	bl	0x10054888c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007beac0:     	tbz	w0, #0x0, 0x1007bed98 <_js_array_get_f64+0x9c8>
1007beac4:     	fmov	x22, d0
1007beac8:     	fmov	d0, x22
1007beacc:     	ldp	x29, x30, [sp, #0x60]
1007bead0:     	ldp	x20, x19, [sp, #0x50]
1007bead4:     	ldp	x22, x21, [sp, #0x40]
1007bead8:     	ldp	x24, x23, [sp, #0x30]
1007beadc:     	ldp	x26, x25, [sp, #0x20]
1007beae0:     	add	sp, sp, #0x70
1007beae4:     	ret
1007beae8:     	mov	w23, #0x0               ; =0
1007beaec:     	mov	w24, #0x0               ; =0
1007beaf0:     	cmp	w24, #0x1
1007beaf4:     	b.ne	0x1007beca8 <_js_array_get_f64+0x8d8>
1007beaf8:     	tbz	w23, #0xa, 0x1007beca8 <_js_array_get_f64+0x8d8>
1007beafc:     	adrp	x8, 0x100b65000 <_anon.2aa35172874dc18ddd0733027929dfee.91+0x10d>
1007beb00:     	add	x8, x8, #0x28c
1007beb04:     	cmp	w19, #0x3e8
1007beb08:     	b.lo	0x1007beb80 <_js_array_get_f64+0x7b0>
1007beb0c:     	mov	x9, #0x0                ; =0
1007beb10:     	mov	w11, #0x1759            ; =5977
1007beb14:     	movk	w11, #0xd1b7, lsl #16
1007beb18:     	mov	w12, #0x2710            ; =10000
1007beb1c:     	mov	w13, #0x147b            ; =5243
1007beb20:     	mov	w14, #0x64              ; =100
1007beb24:     	add	x15, sp, #0x8
1007beb28:     	mov	w16, #0x967f            ; =38527
1007beb2c:     	movk	w16, #0x98, lsl #16
1007beb30:     	mov	x10, x19
1007beb34:     	mov	x17, x10
1007beb38:     	umull	x10, w10, w11
1007beb3c:     	lsr	x10, x10, #45
1007beb40:     	msub	w0, w10, w12, w17
1007beb44:     	ubfx	w1, w0, #2, #14
1007beb48:     	mul	w1, w1, w13
1007beb4c:     	lsr	w1, w1, #17
1007beb50:     	msub	w0, w1, w14, w0
1007beb54:     	add	x2, x15, x9
1007beb58:     	ldrh	w1, [x8, w1, uxtw #1]
1007beb5c:     	strh	w1, [x2, #0x6]
1007beb60:     	and	x0, x0, #0xffff
1007beb64:     	ldrh	w0, [x8, x0, lsl #1]
1007beb68:     	strh	w0, [x2, #0x8]
1007beb6c:     	sub	x9, x9, #0x4
1007beb70:     	cmp	w17, w16
1007beb74:     	b.hi	0x1007beb34 <_js_array_get_f64+0x764>
1007beb78:     	add	x9, x9, #0xa
1007beb7c:     	b	0x1007beb88 <_js_array_get_f64+0x7b8>
1007beb80:     	mov	w9, #0xa                ; =10
1007beb84:     	mov	x10, x19
1007beb88:     	cmp	w10, #0x9
1007beb8c:     	b.ls	0x1007bebc0 <_js_array_get_f64+0x7f0>
1007beb90:     	sub	x9, x9, #0x2
1007beb94:     	ubfx	w11, w10, #2, #14
1007beb98:     	mov	w12, #0x147b            ; =5243
1007beb9c:     	mul	w11, w11, w12
1007beba0:     	lsr	w11, w11, #17
1007beba4:     	mov	w12, #0x64              ; =100
1007beba8:     	msub	w10, w11, w12, w10
1007bebac:     	and	x10, x10, #0xffff
1007bebb0:     	ldrh	w10, [x8, x10, lsl #1]
1007bebb4:     	add	x12, sp, #0x8
1007bebb8:     	strh	w10, [x12, x9]
1007bebbc:     	mov	x10, x11
1007bebc0:     	cbz	w19, 0x1007bebf8 <_js_array_get_f64+0x828>
1007bebc4:     	cbnz	w10, 0x1007bebf8 <_js_array_get_f64+0x828>
1007bebc8:     	cmp	x9, #0xa
1007bebcc:     	b.ne	0x1007bec20 <_js_array_get_f64+0x850>
1007bebd0:     	mov	w23, #0x1               ; =1
1007bebd4:     	add	x0, sp, #0x8
1007bebd8:     	mov	x1, x21
1007bebdc:     	mov	w2, #0x1                ; =1
1007bebe0:     	mov	x3, #0x0                ; =0
1007bebe4:     	bl	0x1005b2b7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007bebe8:     	ldr	x8, [sp, #0x8]
1007bebec:     	mov	w20, #0x1               ; =1
1007bebf0:     	cbnz	x8, 0x1007bec70 <_js_array_get_f64+0x8a0>
1007bebf4:     	b	0x1007beca8 <_js_array_get_f64+0x8d8>
1007bebf8:     	sub	x23, x9, #0x1
1007bebfc:     	ubfiz	w10, w10, #1, #4
1007bec00:     	add	x8, x8, x10
1007bec04:     	ldrb	w8, [x8, #0x1]
1007bec08:     	add	x10, sp, #0x8
1007bec0c:     	strb	w8, [x10, x23]
1007bec10:     	mov	w8, #0xb                ; =11
1007bec14:     	b	0x1007bec28 <_js_array_get_f64+0x858>
1007bec18:     	add	x9, x8, #0x90
1007bec1c:     	b	0x1007bed04 <_js_array_get_f64+0x934>
1007bec20:     	mov	w8, #0xa                ; =10
1007bec24:     	mov	x23, x9
1007bec28:     	sub	x22, x8, x9
1007bec2c:     	mov	x0, x22
1007bec30:     	mov	w1, #0x1                ; =1
1007bec34:     	bl	0x100b5f6c8 <_mi_malloc_aligned>
1007bec38:     	cbz	x0, 0x1007bede4 <_js_array_get_f64+0xa14>
1007bec3c:     	mov	x20, x0
1007bec40:     	add	x8, sp, #0x8
1007bec44:     	add	x1, x8, x23
1007bec48:     	mov	x2, x22
1007bec4c:     	bl	0x100b622ec <_writev+0x100b622ec>
1007bec50:     	add	x0, sp, #0x8
1007bec54:     	mov	x1, x21
1007bec58:     	mov	x2, x20
1007bec5c:     	mov	x3, x22
1007bec60:     	bl	0x1005b2b7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007bec64:     	ldr	w8, [sp, #0x8]
1007bec68:     	tbz	w8, #0x0, 0x1007beca0 <_js_array_get_f64+0x8d0>
1007bec6c:     	mov	w23, #0x0               ; =0
1007bec70:     	mov	x22, #0x1               ; =1
1007bec74:     	movk	x22, #0x7ffc, lsl #48
1007bec78:     	ldr	x0, [sp, #0x10]
1007bec7c:     	cbz	x0, 0x1007bed34 <_js_array_get_f64+0x964>
1007bec80:     	cbz	x21, 0x1007bed24 <_js_array_get_f64+0x954>
1007bec84:     	lsr	x8, x21, #52
1007bec88:     	cmp	x8, #0x7fe
1007bec8c:     	b.hi	0x1007bed28 <_js_array_get_f64+0x958>
1007bec90:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007bec94:     	bfxil	x8, x21, #0, #48
1007bec98:     	mov	x21, x8
1007bec9c:     	b	0x1007bed28 <_js_array_get_f64+0x958>
1007beca0:     	mov	x0, x20
1007beca4:     	bl	0x100b5f440 <_mi_free>
1007beca8:     	ldr	w8, [x21]
1007becac:     	cmp	w19, w8
1007becb0:     	b.hs	0x1007becf0 <_js_array_get_f64+0x920>
1007becb4:     	ldr	w8, [x21, #0x4]
1007becb8:     	cmp	w19, w8
1007becbc:     	b.hs	0x1007bece0 <_js_array_get_f64+0x910>
1007becc0:     	add	x8, x21, w19, uxtw #3
1007becc4:     	ldr	x22, [x8, #0x8]
1007becc8:     	mov	x8, #0x1                ; =1
1007beccc:     	movk	x8, #0x7ffc, lsl #48
1007becd0:     	add	x8, x8, #0xf
1007becd4:     	cmp	x22, x8
1007becd8:     	b.ne	0x1007beac8 <_js_array_get_f64+0x6f8>
1007becdc:     	b	0x1007becf0 <_js_array_get_f64+0x920>
1007bece0:     	mov	x0, x21
1007bece4:     	mov	x1, x19
1007bece8:     	bl	0x10052ac84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007becec:     	tbnz	w0, #0x0, 0x1007beac4 <_js_array_get_f64+0x6f4>
1007becf0:     	mov	x0, x21
1007becf4:     	mov	x1, x19
1007becf8:     	bl	0x1006c76d8 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007becfc:     	b	0x1007beac4 <_js_array_get_f64+0x6f4>
1007bed00:     	add	x9, x8, #0xc0
1007bed04:     	ldr	x10, [x8, #0x30]
1007bed08:     	add	x10, x10, #0x1
1007bed0c:     	str	x10, [x8, #0x30]
1007bed10:     	add	x8, x9, #0x19
1007bed14:     	ldrb	w8, [x8]
1007bed18:     	cmp	w8, #0xff
1007bed1c:     	b.ne	0x1007be7e8 <_js_array_get_f64+0x418>
1007bed20:     	b	0x1007be7dc <_js_array_get_f64+0x40c>
1007bed24:     	add	x21, x22, #0x1
1007bed28:     	fmov	d0, x21
1007bed2c:     	bl	0x1006fd4fc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007bed30:     	mov	x22, x0
1007bed34:     	tbnz	w23, #0x0, 0x1007beac8 <_js_array_get_f64+0x6f8>
1007bed38:     	mov	x0, x20
1007bed3c:     	bl	0x100b5f440 <_mi_free>
1007bed40:     	b	0x1007beac8 <_js_array_get_f64+0x6f8>
1007bed44:     	ldr	x20, [sp, #0x10]
1007bed48:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007bed4c:     	ldr	x8, [x8, #0xed8]
1007bed50:     	cbz	x8, 0x1007bed68 <_js_array_get_f64+0x998>
1007bed54:     	mov	x0, x20
1007bed58:     	bl	0x10013cdc0 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007bed5c:     	tbz	w0, #0x0, 0x1007bed68 <_js_array_get_f64+0x998>
1007bed60:     	mov	x0, x20
1007bed64:     	bl	0x1002bf000 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007bed68:     	tbnz	w19, #0x1f, 0x1007bed88 <_js_array_get_f64+0x9b8>
1007bed6c:     	ldr	w8, [x20]
1007bed70:     	cmp	w19, w8
1007bed74:     	b.hs	0x1007bed88 <_js_array_get_f64+0x9b8>
1007bed78:     	mov	w1, w19
1007bed7c:     	mov	x0, x20
1007bed80:     	bl	0x1002a528c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007bed84:     	b	0x1007beac4 <_js_array_get_f64+0x6f4>
1007bed88:     	mov	x8, #0x1                ; =1
1007bed8c:     	movk	x8, #0x7ffc, lsl #48
1007bed90:     	mov	x22, x8
1007bed94:     	b	0x1007beac8 <_js_array_get_f64+0x6f8>
1007bed98:     	mov	x0, x22
1007bed9c:     	bl	0x100b47db0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007beda0:     	cmp	x0, #0x1
1007beda4:     	b.ne	0x1007be410 <_js_array_get_f64+0x40>
1007beda8:     	mov	x0, x19
1007bedac:     	bl	0x100b47dd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007bedb0:     	b	0x1007beac4 <_js_array_get_f64+0x6f4>
1007bedb4:     	mov	x0, x20
1007bedb8:     	mov	w1, #0x0                ; =0
1007bedbc:     	bl	0x100b4a340 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bedc0:     	mov	x20, x0
1007bedc4:     	cbnz	x0, 0x1007be4ec <_js_array_get_f64+0x11c>
1007bedc8:     	b	0x1007beac8 <_js_array_get_f64+0x6f8>
1007bedcc:     	mov	x0, x20
1007bedd0:     	mov	w1, #0x1                ; =1
1007bedd4:     	bl	0x100b4a340 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bedd8:     	mov	x20, x0
1007beddc:     	cbnz	x0, 0x1007be690 <_js_array_get_f64+0x2c0>
1007bede0:     	b	0x1007beac8 <_js_array_get_f64+0x6f8>
1007bede4:     	mov	w0, #0x1                ; =1
1007bede8:     	mov	x1, x22
1007bedec:     	bl	0x100b12800 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
