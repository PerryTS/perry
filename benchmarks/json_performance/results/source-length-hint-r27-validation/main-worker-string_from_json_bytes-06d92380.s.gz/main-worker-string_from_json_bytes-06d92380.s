
benchmarks/json_performance/.work/source-length-hint-r27/main-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001005eaf04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>:
1005eaf04:     	sub	sp, sp, #0x60
1005eaf08:     	stp	x24, x23, [sp, #0x20]
1005eaf0c:     	stp	x22, x21, [sp, #0x30]
1005eaf10:     	stp	x20, x19, [sp, #0x40]
1005eaf14:     	stp	x29, x30, [sp, #0x50]
1005eaf18:     	add	x29, sp, #0x50
1005eaf1c:     	mov	x19, x1
1005eaf20:     	cmp	x2, #0x40
1005eaf24:     	b.hs	0x1005eb058 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x154>
1005eaf28:     	ands	x8, x2, #0x38
1005eaf2c:     	b.eq	0x1005eaf50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4c>
1005eaf30:     	and	x9, x2, #0x38
1005eaf34:     	neg	x9, x9
1005eaf38:     	mov	x10, x19
1005eaf3c:     	ldr	x11, [x10], #0x8
1005eaf40:     	tst	x11, #0x8080808080808080
1005eaf44:     	b.ne	0x1005eafe4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eaf48:     	adds	x9, x9, #0x8
1005eaf4c:     	b.ne	0x1005eaf3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x38>
1005eaf50:     	mov	x20, x2
1005eaf54:     	and	x9, x2, #0x7
1005eaf58:     	cbz	x9, 0x1005eb124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eaf5c:     	add	x8, x19, x8
1005eaf60:     	ldrsb	w10, [x8]
1005eaf64:     	tbnz	w10, #0x1f, 0x1005eafe4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eaf68:     	mov	x20, x2
1005eaf6c:     	cmp	x9, #0x1
1005eaf70:     	b.eq	0x1005eb124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eaf74:     	ldrsb	w10, [x8, #0x1]
1005eaf78:     	tbnz	w10, #0x1f, 0x1005eafe4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eaf7c:     	mov	x20, x2
1005eaf80:     	cmp	x9, #0x2
1005eaf84:     	b.eq	0x1005eb124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eaf88:     	ldrsb	w10, [x8, #0x2]
1005eaf8c:     	tbnz	w10, #0x1f, 0x1005eafe4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eaf90:     	mov	x20, x2
1005eaf94:     	cmp	x9, #0x3
1005eaf98:     	b.eq	0x1005eb124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eaf9c:     	ldrsb	w10, [x8, #0x3]
1005eafa0:     	tbnz	w10, #0x1f, 0x1005eafe4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eafa4:     	mov	x20, x2
1005eafa8:     	cmp	x9, #0x4
1005eafac:     	b.eq	0x1005eb124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eafb0:     	ldrsb	w10, [x8, #0x4]
1005eafb4:     	tbnz	w10, #0x1f, 0x1005eafe4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eafb8:     	mov	x20, x2
1005eafbc:     	cmp	x9, #0x5
1005eafc0:     	b.eq	0x1005eb124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eafc4:     	ldrsb	w10, [x8, #0x5]
1005eafc8:     	tbnz	w10, #0x1f, 0x1005eafe4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eafcc:     	mov	x20, x2
1005eafd0:     	cmp	x9, #0x6
1005eafd4:     	b.eq	0x1005eb124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eafd8:     	ldrsb	w8, [x8, #0x6]
1005eafdc:     	mov	x20, x2
1005eafe0:     	tbz	w8, #0x1f, 0x1005eb124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eafe4:     	cbz	w2, 0x1005eb0e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1e0>
1005eafe8:     	mov	x20, x2
1005eafec:     	mov	w21, w2
1005eaff0:     	cbz	x21, 0x1005eb124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eaff4:     	mov	x8, x19
1005eaff8:     	ands	x9, x2, #0x3
1005eaffc:     	b.eq	0x1005eb018 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x114>
1005eb000:     	mov	x8, x19
1005eb004:     	ldrsb	w10, [x8]
1005eb008:     	tbnz	w10, #0x1f, 0x1005eb0fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005eb00c:     	add	x8, x8, #0x1
1005eb010:     	subs	x9, x9, #0x1
1005eb014:     	b.ne	0x1005eb004 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x100>
1005eb018:     	mov	x20, x2
1005eb01c:     	cmp	x21, #0x4
1005eb020:     	b.lo	0x1005eb124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb024:     	add	x9, x19, x21
1005eb028:     	ldrsb	w10, [x8]
1005eb02c:     	tbnz	w10, #0x1f, 0x1005eb0fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005eb030:     	ldrsb	w10, [x8, #0x1]
1005eb034:     	tbnz	w10, #0x1f, 0x1005eb0fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005eb038:     	ldrsb	w10, [x8, #0x2]
1005eb03c:     	tbnz	w10, #0x1f, 0x1005eb0fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005eb040:     	ldrsb	w10, [x8, #0x3]
1005eb044:     	tbnz	w10, #0x1f, 0x1005eb0fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005eb048:     	add	x8, x8, #0x4
1005eb04c:     	cmp	x8, x9
1005eb050:     	b.ne	0x1005eb028 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x124>
1005eb054:     	b	0x1005eb0dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1d8>
1005eb058:     	and	x8, x2, #0x7fffffffffffffc0
1005eb05c:     	add	x8, x19, x8
1005eb060:     	mov	x9, x19
1005eb064:     	ldp	q0, q1, [x9]
1005eb068:     	ldp	q2, q3, [x9, #0x20]
1005eb06c:     	orr.16b	v0, v1, v0
1005eb070:     	orr.16b	v1, v2, v3
1005eb074:     	orr.16b	v0, v0, v1
1005eb078:     	umaxv.16b	b0, v0
1005eb07c:     	fmov	w10, s0
1005eb080:     	tbnz	w10, #0x7, 0x1005eafe4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eb084:     	add	x9, x9, #0x40
1005eb088:     	cmp	x9, x8
1005eb08c:     	b.ne	0x1005eb064 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x160>
1005eb090:     	ands	x9, x2, #0x30
1005eb094:     	b.eq	0x1005eb0b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1b4>
1005eb098:     	mov	x10, x9
1005eb09c:     	mov	x11, x8
1005eb0a0:     	ldr	q0, [x11], #0x10
1005eb0a4:     	umaxv.16b	b0, v0
1005eb0a8:     	fmov	w12, s0
1005eb0ac:     	tbnz	w12, #0x7, 0x1005eafe4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eb0b0:     	subs	x10, x10, #0x10
1005eb0b4:     	b.ne	0x1005eb0a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x19c>
1005eb0b8:     	mov	x20, x2
1005eb0bc:     	and	x10, x2, #0xf
1005eb0c0:     	cbz	x10, 0x1005eb124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb0c4:     	add	x8, x8, x9
1005eb0c8:     	ldrsb	w9, [x8]
1005eb0cc:     	tbnz	w9, #0x1f, 0x1005eafe4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eb0d0:     	add	x8, x8, #0x1
1005eb0d4:     	subs	x10, x10, #0x1
1005eb0d8:     	b.ne	0x1005eb0c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1c4>
1005eb0dc:     	mov	x20, x2
1005eb0e0:     	b	0x1005eb124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb0e4:     	mov	w20, #0x0               ; =0
1005eb0e8:     	mov	w8, #0x14               ; =20
1005eb0ec:     	orr	x8, x2, x8
1005eb0f0:     	ldr	x9, [x0]
1005eb0f4:     	cbnz	x9, 0x1005eb1cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x2c8>
1005eb0f8:     	b	0x1005eb208 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005eb0fc:     	mov	x22, x0
1005eb100:     	mov	x23, x2
1005eb104:     	cmp	w2, #0x3f
1005eb108:     	b.ls	0x1005eb254 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x350>
1005eb10c:     	mov	x0, x19
1005eb110:     	mov	x1, x21
1005eb114:     	bl	0x1005ea920 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
1005eb118:     	mov	x20, x0
1005eb11c:     	mov	x2, x23
1005eb120:     	mov	x0, x22
1005eb124:     	lsr	w8, w2, #19
1005eb128:     	cbz	w8, 0x1005eb1c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x2bc>
1005eb12c:     	mov	w23, w2
1005eb130:     	add	x0, x23, #0x14
1005eb134:     	mov	w1, #0x3                ; =3
1005eb138:     	mov	x22, x2
1005eb13c:     	bl	0x100458380 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
1005eb140:     	mov	x21, x0
1005eb144:     	stp	w20, w22, [x0]
1005eb148:     	str	w22, [x0, #0x8]
1005eb14c:     	mov	x8, #0x200000000        ; =8589934592
1005eb150:     	stur	x8, [x0, #0xc]
1005eb154:     	add	x0, x0, #0x14
1005eb158:     	mov	x1, x19
1005eb15c:     	mov	x2, x22
1005eb160:     	bl	0x100b61dec <_writev+0x100b61dec>
1005eb164:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1005eb168:     	ldr	w19, [x8, #0x590]
1005eb16c:     	cmp	w19, #0x300
1005eb170:     	b.hs	0x1005eb358 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x454>
1005eb174:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1005eb178:     	ldr	x8, [x8, #0x48]
1005eb17c:     	cmn	x8, #0x1
1005eb180:     	b.eq	0x1005eb348 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x444>
1005eb184:     	mrs	x9, TPIDRRO_EL0
1005eb188:     	and	x9, x9, #0xfffffffffffffff8
1005eb18c:     	ldr	x0, [x9, x8, lsl #3]
1005eb190:     	cbz	x0, 0x1005eb348 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x444>
1005eb194:     	add	x8, x0, x19, lsl #3
1005eb198:     	ldr	x0, [x8, #0x1e8]
1005eb19c:     	cbz	x0, 0x1005eb358 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x454>
1005eb1a0:     	ldr	x8, [x0]
1005eb1a4:     	adds	x8, x8, x23
1005eb1a8:     	csinv	x8, x8, xzr, lo
1005eb1ac:     	str	x8, [x0]
1005eb1b0:     	lsr	x8, x8, #25
1005eb1b4:     	cbz	x8, 0x1005eb238 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x334>
1005eb1b8:     	bl	0x10045f2b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
1005eb1bc:     	b	0x1005eb238 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x334>
1005eb1c0:     	add	x8, x2, #0x14
1005eb1c4:     	ldr	x9, [x0]
1005eb1c8:     	cbz	x9, 0x1005eb208 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005eb1cc:     	add	x9, x8, #0xf
1005eb1d0:     	and	x9, x9, #0xfffffffffffffff8
1005eb1d4:     	cmp	x9, #0x4, lsl #12       ; =0x4000
1005eb1d8:     	b.hi	0x1005eb208 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005eb1dc:     	ldr	x10, [x0, #0x10]
1005eb1e0:     	ldrb	w10, [x10]
1005eb1e4:     	tbnz	w10, #0x0, 0x1005eb208 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005eb1e8:     	ldr	x10, [x0, #0x8]
1005eb1ec:     	ldp	x11, x12, [x10, #0x8]
1005eb1f0:     	add	x11, x11, #0x7
1005eb1f4:     	and	x11, x11, #0xfffffffffffffff8
1005eb1f8:     	subs	x12, x12, x11
1005eb1fc:     	csel	x12, xzr, x12, lo
1005eb200:     	cmp	x9, x12
1005eb204:     	b.ls	0x1005eb2e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x3dc>
1005eb208:     	mov	x0, x2
1005eb20c:     	mov	x22, x2
1005eb210:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
1005eb214:     	mov	x21, x0
1005eb218:     	mov	x0, x1
1005eb21c:     	stp	w20, w22, [x21]
1005eb220:     	str	w22, [x21, #0x8]
1005eb224:     	mov	x8, #0x200000000        ; =8589934592
1005eb228:     	stur	x8, [x21, #0xc]
1005eb22c:     	mov	x1, x19
1005eb230:     	mov	x2, x22
1005eb234:     	bl	0x100b61dec <_writev+0x100b61dec>
1005eb238:     	mov	x0, x21
1005eb23c:     	ldp	x29, x30, [sp, #0x50]
1005eb240:     	ldp	x20, x19, [sp, #0x40]
1005eb244:     	ldp	x22, x21, [sp, #0x30]
1005eb248:     	ldp	x24, x23, [sp, #0x20]
1005eb24c:     	add	sp, sp, #0x60
1005eb250:     	ret
1005eb254:     	add	x8, sp, #0x8
1005eb258:     	mov	x0, x19
1005eb25c:     	mov	x1, x21
1005eb260:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
1005eb264:     	ldr	x8, [sp, #0x8]
1005eb268:     	cbz	x8, 0x1005eb320 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x41c>
1005eb26c:     	mov	w20, #0x0               ; =0
1005eb270:     	mov	x8, #0x0                ; =0
1005eb274:     	mov	w9, #0x2                ; =2
1005eb278:     	mov	w10, #0x3               ; =3
1005eb27c:     	mov	w11, #0x4               ; =4
1005eb280:     	mov	x2, x23
1005eb284:     	mov	x0, x22
1005eb288:     	b	0x1005eb2a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x39c>
1005eb28c:     	add	w20, w20, #0x1
1005eb290:     	mov	w12, #0x1               ; =1
1005eb294:     	add	x8, x12, x8
1005eb298:     	cmp	x8, x21
1005eb29c:     	b.hs	0x1005eb124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb2a0:     	ldrsb	w12, [x19, x8]
1005eb2a4:     	tbz	w12, #0x1f, 0x1005eb28c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x388>
1005eb2a8:     	and	w12, w12, #0xff
1005eb2ac:     	cmp	w12, #0xc0
1005eb2b0:     	b.lo	0x1005eb290 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x38c>
1005eb2b4:     	cmp	w12, #0xf0
1005eb2b8:     	add	w13, w20, #0x2
1005eb2bc:     	csel	x14, x10, x11, lo
1005eb2c0:     	csinc	w13, w13, w20, hs
1005eb2c4:     	cmp	w12, #0xe0
1005eb2c8:     	csel	x12, x9, x14, lo
1005eb2cc:     	csinc	w20, w13, w20, hs
1005eb2d0:     	add	x8, x12, x8
1005eb2d4:     	cmp	x8, x21
1005eb2d8:     	b.lo	0x1005eb2a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x39c>
1005eb2dc:     	b	0x1005eb124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb2e0:     	ldr	x12, [x10]
1005eb2e4:     	add	x22, x12, x11
1005eb2e8:     	add	x11, x11, x9
1005eb2ec:     	str	x11, [x10, #0x8]
1005eb2f0:     	mov	w10, #0x203             ; =515
1005eb2f4:     	stp	w10, w9, [x22]
1005eb2f8:     	add	x21, x22, #0x8
1005eb2fc:     	sub	x10, x9, #0x8
1005eb300:     	subs	x10, x10, x8
1005eb304:     	csel	x1, xzr, x10, lo
1005eb308:     	b.ls	0x1005eb3ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4a8>
1005eb30c:     	cmp	x1, #0x9
1005eb310:     	b.hs	0x1005eb39c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x498>
1005eb314:     	add	x8, x22, x9
1005eb318:     	stur	xzr, [x8, #-0x8]
1005eb31c:     	b	0x1005eb3ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4a8>
1005eb320:     	ldr	x8, [sp, #0x18]
1005eb324:     	mov	x2, x23
1005eb328:     	mov	x0, x22
1005eb32c:     	cbz	x8, 0x1005eb380 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x47c>
1005eb330:     	ldr	x9, [sp, #0x10]
1005eb334:     	cmp	x8, #0x8
1005eb338:     	b.hs	0x1005eb388 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x484>
1005eb33c:     	mov	x10, #0x0               ; =0
1005eb340:     	mov	w20, #0x0               ; =0
1005eb344:     	b	0x1005eb67c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x778>
1005eb348:     	bl	0x100b3f37c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005eb34c:     	add	x8, x0, x19, lsl #3
1005eb350:     	ldr	x0, [x8, #0x1e8]
1005eb354:     	cbnz	x0, 0x1005eb1a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x29c>
1005eb358:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1005eb35c:     	add	x0, x0, #0x78
1005eb360:     	bl	0x100b3cb9c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1005eb364:     	ldr	x8, [x0]
1005eb368:     	adds	x8, x8, x23
1005eb36c:     	csinv	x8, x8, xzr, lo
1005eb370:     	str	x8, [x0]
1005eb374:     	lsr	x8, x8, #25
1005eb378:     	cbnz	x8, 0x1005eb1b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x2b4>
1005eb37c:     	b	0x1005eb238 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x334>
1005eb380:     	mov	w20, #0x0               ; =0
1005eb384:     	b	0x1005eb124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb388:     	cmp	x8, #0x20
1005eb38c:     	b.hs	0x1005eb3c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4c4>
1005eb390:     	mov	x10, #0x0               ; =0
1005eb394:     	mov	w20, #0x0               ; =0
1005eb398:     	b	0x1005eb5cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x6c8>
1005eb39c:     	add	x0, x21, x8
1005eb3a0:     	mov	x23, x2
1005eb3a4:     	bl	0x100b61924 <_writev+0x100b61924>
1005eb3a8:     	mov	x2, x23
1005eb3ac:     	stp	w20, w2, [x22, #0x8]
1005eb3b0:     	str	w2, [x22, #0x10]
1005eb3b4:     	mov	x8, #0x200000000        ; =8589934592
1005eb3b8:     	stur	x8, [x22, #0x14]
1005eb3bc:     	add	x0, x22, #0x1c
1005eb3c0:     	mov	x1, x19
1005eb3c4:     	b	0x1005eb234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x330>
1005eb3c8:     	movi.2d	v0, #0000000000000000
1005eb3cc:     	and	x11, x8, #0x18
1005eb3d0:     	movi.16b	v1, #0xf0
1005eb3d4:     	and	x10, x8, #0xffffffffffffffe0
1005eb3d8:     	movi.4s	v2, #0x2
1005eb3dc:     	add	x12, x9, #0x10
1005eb3e0:     	movi.16b	v4, #0xc0
1005eb3e4:     	and	x13, x8, #0xffffffffffffffe0
1005eb3e8:     	movi.2d	v3, #0000000000000000
1005eb3ec:     	movi.2d	v6, #0000000000000000
1005eb3f0:     	movi.2d	v5, #0000000000000000
1005eb3f4:     	movi.2d	v7, #0000000000000000
1005eb3f8:     	movi.2d	v16, #0000000000000000
1005eb3fc:     	movi.2d	v17, #0000000000000000
1005eb400:     	movi.2d	v18, #0000000000000000
1005eb404:     	ldp	q20, q19, [x12, #-0x10]
1005eb408:     	cmhi.16b	v21, v1, v20
1005eb40c:     	sshll2.8h	v22, v21, #0x0
1005eb410:     	sshll2.4s	v23, v22, #0x0
1005eb414:     	sshll.4s	v24, v22, #0x0
1005eb418:     	sshll.8h	v21, v21, #0x0
1005eb41c:     	sshll2.4s	v25, v21, #0x0
1005eb420:     	sshll.4s	v26, v21, #0x0
1005eb424:     	cmhi.16b	v27, v1, v19
1005eb428:     	sshll2.8h	v28, v27, #0x0
1005eb42c:     	sshll2.4s	v29, v28, #0x0
1005eb430:     	sshll.4s	v30, v28, #0x0
1005eb434:     	sshll.8h	v27, v27, #0x0
1005eb438:     	sshll2.4s	v31, v27, #0x0
1005eb43c:     	bic.16b	v26, v2, v26
1005eb440:     	ssubw.4s	v26, v26, v21
1005eb444:     	bic.16b	v25, v2, v25
1005eb448:     	ssubw2.4s	v25, v25, v21
1005eb44c:     	sshll.4s	v21, v27, #0x0
1005eb450:     	bic.16b	v24, v2, v24
1005eb454:     	ssubw.4s	v24, v24, v22
1005eb458:     	bic.16b	v23, v2, v23
1005eb45c:     	ssubw2.4s	v22, v23, v22
1005eb460:     	bic.16b	v21, v2, v21
1005eb464:     	ssubw.4s	v21, v21, v27
1005eb468:     	bic.16b	v23, v2, v31
1005eb46c:     	ssubw2.4s	v23, v23, v27
1005eb470:     	bic.16b	v27, v2, v30
1005eb474:     	ssubw.4s	v27, v27, v28
1005eb478:     	bic.16b	v29, v2, v29
1005eb47c:     	ssubw2.4s	v28, v29, v28
1005eb480:     	cmgt.16b	v29, v4, v20
1005eb484:     	sshll2.8h	v30, v29, #0x0
1005eb488:     	ushll2.4s	v31, v30, #0x0
1005eb48c:     	bic.16b	v22, v22, v31
1005eb490:     	cmlt.16b	v20, v20, #0
1005eb494:     	sshll.8h	v29, v29, #0x0
1005eb498:     	ushll.4s	v30, v30, #0x0
1005eb49c:     	bic.16b	v24, v24, v30
1005eb4a0:     	ushll2.4s	v30, v29, #0x0
1005eb4a4:     	bic.16b	v25, v25, v30
1005eb4a8:     	sshll2.8h	v30, v20, #0x0
1005eb4ac:     	sshll.8h	v20, v20, #0x0
1005eb4b0:     	ushll.4s	v29, v29, #0x0
1005eb4b4:     	bic.16b	v26, v26, v29
1005eb4b8:     	sshll.4s	v29, v20, #0x0
1005eb4bc:     	and.16b	v26, v26, v29
1005eb4c0:     	mvn.16b	v29, v29
1005eb4c4:     	sub.4s	v26, v26, v29
1005eb4c8:     	sshll2.4s	v29, v30, #0x0
1005eb4cc:     	sshll.4s	v30, v30, #0x0
1005eb4d0:     	sshll2.4s	v20, v20, #0x0
1005eb4d4:     	and.16b	v25, v25, v20
1005eb4d8:     	mvn.16b	v20, v20
1005eb4dc:     	sub.4s	v20, v25, v20
1005eb4e0:     	cmgt.16b	v25, v4, v19
1005eb4e4:     	and.16b	v24, v24, v30
1005eb4e8:     	mvn.16b	v30, v30
1005eb4ec:     	sub.4s	v24, v24, v30
1005eb4f0:     	sshll2.8h	v30, v25, #0x0
1005eb4f4:     	and.16b	v22, v22, v29
1005eb4f8:     	mvn.16b	v29, v29
1005eb4fc:     	sub.4s	v22, v22, v29
1005eb500:     	ushll2.4s	v29, v30, #0x0
1005eb504:     	bic.16b	v28, v28, v29
1005eb508:     	cmlt.16b	v19, v19, #0
1005eb50c:     	sshll.8h	v25, v25, #0x0
1005eb510:     	ushll.4s	v29, v30, #0x0
1005eb514:     	bic.16b	v27, v27, v29
1005eb518:     	ushll2.4s	v29, v25, #0x0
1005eb51c:     	bic.16b	v23, v23, v29
1005eb520:     	sshll.8h	v29, v19, #0x0
1005eb524:     	ushll.4s	v25, v25, #0x0
1005eb528:     	bic.16b	v21, v21, v25
1005eb52c:     	sshll.4s	v25, v29, #0x0
1005eb530:     	and.16b	v21, v21, v25
1005eb534:     	mvn.16b	v25, v25
1005eb538:     	sub.4s	v21, v21, v25
1005eb53c:     	sshll2.8h	v19, v19, #0x0
1005eb540:     	sshll2.4s	v25, v29, #0x0
1005eb544:     	and.16b	v23, v23, v25
1005eb548:     	mvn.16b	v25, v25
1005eb54c:     	sub.4s	v23, v23, v25
1005eb550:     	sshll.4s	v25, v19, #0x0
1005eb554:     	and.16b	v27, v27, v25
1005eb558:     	mvn.16b	v25, v25
1005eb55c:     	sub.4s	v25, v27, v25
1005eb560:     	sshll2.4s	v19, v19, #0x0
1005eb564:     	and.16b	v27, v28, v19
1005eb568:     	mvn.16b	v19, v19
1005eb56c:     	sub.4s	v19, v27, v19
1005eb570:     	add.4s	v7, v22, v7
1005eb574:     	add.4s	v5, v24, v5
1005eb578:     	add.4s	v6, v20, v6
1005eb57c:     	add.4s	v3, v26, v3
1005eb580:     	add.4s	v18, v19, v18
1005eb584:     	add.4s	v17, v25, v17
1005eb588:     	add.4s	v0, v23, v0
1005eb58c:     	add.4s	v16, v21, v16
1005eb590:     	add	x12, x12, #0x20
1005eb594:     	subs	x13, x13, #0x20
1005eb598:     	b.ne	0x1005eb404 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x500>
1005eb59c:     	add.4s	v0, v0, v6
1005eb5a0:     	add.4s	v1, v18, v7
1005eb5a4:     	add.4s	v2, v16, v3
1005eb5a8:     	add.4s	v3, v17, v5
1005eb5ac:     	add.4s	v2, v2, v3
1005eb5b0:     	add.4s	v0, v0, v1
1005eb5b4:     	add.4s	v0, v2, v0
1005eb5b8:     	addv.4s	s0, v0
1005eb5bc:     	fmov	w20, s0
1005eb5c0:     	cmp	x8, x10
1005eb5c4:     	b.eq	0x1005eb124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb5c8:     	cbz	x11, 0x1005eb67c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x778>
1005eb5cc:     	mov	x12, x10
1005eb5d0:     	and	x10, x8, #0xfffffffffffffff8
1005eb5d4:     	movi.2d	v0, #0000000000000000
1005eb5d8:     	mov.s	v0[0], w20
1005eb5dc:     	movi.2d	v1, #0000000000000000
1005eb5e0:     	sub	x11, x12, x10
1005eb5e4:     	add	x12, x9, x12
1005eb5e8:     	movi.8b	v2, #0xf0
1005eb5ec:     	movi.4s	v3, #0x2
1005eb5f0:     	movi.8b	v4, #0xc0
1005eb5f4:     	ldr	d5, [x12], #0x8
1005eb5f8:     	sshll.8h	v6, v5, #0x0
1005eb5fc:     	cmlt.8h	v6, v6, #0
1005eb600:     	sshll2.4s	v7, v6, #0x0
1005eb604:     	sshll.4s	v6, v6, #0x0
1005eb608:     	cmhi.8b	v16, v2, v5
1005eb60c:     	sshll.8h	v16, v16, #0x0
1005eb610:     	sshll2.4s	v17, v16, #0x0
1005eb614:     	sshll.4s	v18, v16, #0x0
1005eb618:     	bic.16b	v18, v3, v18
1005eb61c:     	ssubw.4s	v18, v18, v16
1005eb620:     	bic.16b	v17, v3, v17
1005eb624:     	ssubw2.4s	v16, v17, v16
1005eb628:     	cmgt.8b	v5, v4, v5
1005eb62c:     	sshll.8h	v5, v5, #0x0
1005eb630:     	ushll.4s	v17, v5, #0x0
1005eb634:     	ushll2.4s	v5, v5, #0x0
1005eb638:     	bic.16b	v5, v16, v5
1005eb63c:     	bic.16b	v16, v18, v17
1005eb640:     	and.16b	v16, v16, v6
1005eb644:     	mvn.16b	v6, v6
1005eb648:     	sub.4s	v6, v16, v6
1005eb64c:     	and.16b	v5, v5, v7
1005eb650:     	mvn.16b	v7, v7
1005eb654:     	sub.4s	v5, v5, v7
1005eb658:     	add.4s	v1, v5, v1
1005eb65c:     	add.4s	v0, v6, v0
1005eb660:     	adds	x11, x11, #0x8
1005eb664:     	b.ne	0x1005eb5f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x6f0>
1005eb668:     	add.4s	v0, v0, v1
1005eb66c:     	addv.4s	s0, v0
1005eb670:     	fmov	w20, s0
1005eb674:     	cmp	x8, x10
1005eb678:     	b.eq	0x1005eb124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb67c:     	sub	x8, x8, x10
1005eb680:     	add	x9, x9, x10
1005eb684:     	mov	w10, #0x1               ; =1
1005eb688:     	ldrsb	w11, [x9], #0x1
1005eb68c:     	and	w12, w11, #0xff
1005eb690:     	cmp	w12, #0xf0
1005eb694:     	cinc	w13, w10, hs
1005eb698:     	cmp	w12, #0xc0
1005eb69c:     	csel	w12, wzr, w13, lo
1005eb6a0:     	tst	w11, #0x80000000
1005eb6a4:     	csinc	w11, w12, wzr, ne
1005eb6a8:     	add	w20, w11, w20
1005eb6ac:     	subs	x8, x8, #0x1
1005eb6b0:     	b.ne	0x1005eb688 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x784>
1005eb6b4:     	b	0x1005eb124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
