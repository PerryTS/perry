
benchmarks/json_performance/.work/source-length-hint-r27/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001005eb184 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>:
1005eb184:     	sub	sp, sp, #0x60
1005eb188:     	stp	x24, x23, [sp, #0x20]
1005eb18c:     	stp	x22, x21, [sp, #0x30]
1005eb190:     	stp	x20, x19, [sp, #0x40]
1005eb194:     	stp	x29, x30, [sp, #0x50]
1005eb198:     	add	x29, sp, #0x50
1005eb19c:     	mov	x19, x1
1005eb1a0:     	cmp	x2, #0x40
1005eb1a4:     	b.hs	0x1005eb2d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x154>
1005eb1a8:     	ands	x8, x2, #0x38
1005eb1ac:     	b.eq	0x1005eb1d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4c>
1005eb1b0:     	and	x9, x2, #0x38
1005eb1b4:     	neg	x9, x9
1005eb1b8:     	mov	x10, x19
1005eb1bc:     	ldr	x11, [x10], #0x8
1005eb1c0:     	tst	x11, #0x8080808080808080
1005eb1c4:     	b.ne	0x1005eb264 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eb1c8:     	adds	x9, x9, #0x8
1005eb1cc:     	b.ne	0x1005eb1bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x38>
1005eb1d0:     	mov	x20, x2
1005eb1d4:     	and	x9, x2, #0x7
1005eb1d8:     	cbz	x9, 0x1005eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb1dc:     	add	x8, x19, x8
1005eb1e0:     	ldrsb	w10, [x8]
1005eb1e4:     	tbnz	w10, #0x1f, 0x1005eb264 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eb1e8:     	mov	x20, x2
1005eb1ec:     	cmp	x9, #0x1
1005eb1f0:     	b.eq	0x1005eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb1f4:     	ldrsb	w10, [x8, #0x1]
1005eb1f8:     	tbnz	w10, #0x1f, 0x1005eb264 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eb1fc:     	mov	x20, x2
1005eb200:     	cmp	x9, #0x2
1005eb204:     	b.eq	0x1005eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb208:     	ldrsb	w10, [x8, #0x2]
1005eb20c:     	tbnz	w10, #0x1f, 0x1005eb264 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eb210:     	mov	x20, x2
1005eb214:     	cmp	x9, #0x3
1005eb218:     	b.eq	0x1005eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb21c:     	ldrsb	w10, [x8, #0x3]
1005eb220:     	tbnz	w10, #0x1f, 0x1005eb264 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eb224:     	mov	x20, x2
1005eb228:     	cmp	x9, #0x4
1005eb22c:     	b.eq	0x1005eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb230:     	ldrsb	w10, [x8, #0x4]
1005eb234:     	tbnz	w10, #0x1f, 0x1005eb264 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eb238:     	mov	x20, x2
1005eb23c:     	cmp	x9, #0x5
1005eb240:     	b.eq	0x1005eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb244:     	ldrsb	w10, [x8, #0x5]
1005eb248:     	tbnz	w10, #0x1f, 0x1005eb264 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eb24c:     	mov	x20, x2
1005eb250:     	cmp	x9, #0x6
1005eb254:     	b.eq	0x1005eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb258:     	ldrsb	w8, [x8, #0x6]
1005eb25c:     	mov	x20, x2
1005eb260:     	tbz	w8, #0x1f, 0x1005eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb264:     	cbz	w2, 0x1005eb364 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1e0>
1005eb268:     	mov	x20, x2
1005eb26c:     	mov	w21, w2
1005eb270:     	cbz	x21, 0x1005eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb274:     	mov	x8, x19
1005eb278:     	ands	x9, x2, #0x3
1005eb27c:     	b.eq	0x1005eb298 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x114>
1005eb280:     	mov	x8, x19
1005eb284:     	ldrsb	w10, [x8]
1005eb288:     	tbnz	w10, #0x1f, 0x1005eb37c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005eb28c:     	add	x8, x8, #0x1
1005eb290:     	subs	x9, x9, #0x1
1005eb294:     	b.ne	0x1005eb284 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x100>
1005eb298:     	mov	x20, x2
1005eb29c:     	cmp	x21, #0x4
1005eb2a0:     	b.lo	0x1005eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb2a4:     	add	x9, x19, x21
1005eb2a8:     	ldrsb	w10, [x8]
1005eb2ac:     	tbnz	w10, #0x1f, 0x1005eb37c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005eb2b0:     	ldrsb	w10, [x8, #0x1]
1005eb2b4:     	tbnz	w10, #0x1f, 0x1005eb37c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005eb2b8:     	ldrsb	w10, [x8, #0x2]
1005eb2bc:     	tbnz	w10, #0x1f, 0x1005eb37c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005eb2c0:     	ldrsb	w10, [x8, #0x3]
1005eb2c4:     	tbnz	w10, #0x1f, 0x1005eb37c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005eb2c8:     	add	x8, x8, #0x4
1005eb2cc:     	cmp	x8, x9
1005eb2d0:     	b.ne	0x1005eb2a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x124>
1005eb2d4:     	b	0x1005eb35c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1d8>
1005eb2d8:     	and	x8, x2, #0x7fffffffffffffc0
1005eb2dc:     	add	x8, x19, x8
1005eb2e0:     	mov	x9, x19
1005eb2e4:     	ldp	q0, q1, [x9]
1005eb2e8:     	ldp	q2, q3, [x9, #0x20]
1005eb2ec:     	orr.16b	v0, v1, v0
1005eb2f0:     	orr.16b	v1, v2, v3
1005eb2f4:     	orr.16b	v0, v0, v1
1005eb2f8:     	umaxv.16b	b0, v0
1005eb2fc:     	fmov	w10, s0
1005eb300:     	tbnz	w10, #0x7, 0x1005eb264 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eb304:     	add	x9, x9, #0x40
1005eb308:     	cmp	x9, x8
1005eb30c:     	b.ne	0x1005eb2e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x160>
1005eb310:     	ands	x9, x2, #0x30
1005eb314:     	b.eq	0x1005eb338 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1b4>
1005eb318:     	mov	x10, x9
1005eb31c:     	mov	x11, x8
1005eb320:     	ldr	q0, [x11], #0x10
1005eb324:     	umaxv.16b	b0, v0
1005eb328:     	fmov	w12, s0
1005eb32c:     	tbnz	w12, #0x7, 0x1005eb264 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eb330:     	subs	x10, x10, #0x10
1005eb334:     	b.ne	0x1005eb320 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x19c>
1005eb338:     	mov	x20, x2
1005eb33c:     	and	x10, x2, #0xf
1005eb340:     	cbz	x10, 0x1005eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb344:     	add	x8, x8, x9
1005eb348:     	ldrsb	w9, [x8]
1005eb34c:     	tbnz	w9, #0x1f, 0x1005eb264 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eb350:     	add	x8, x8, #0x1
1005eb354:     	subs	x10, x10, #0x1
1005eb358:     	b.ne	0x1005eb348 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1c4>
1005eb35c:     	mov	x20, x2
1005eb360:     	b	0x1005eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb364:     	mov	w20, #0x0               ; =0
1005eb368:     	mov	w8, #0x14               ; =20
1005eb36c:     	orr	x8, x2, x8
1005eb370:     	ldr	x9, [x0]
1005eb374:     	cbnz	x9, 0x1005eb44c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x2c8>
1005eb378:     	b	0x1005eb488 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005eb37c:     	mov	x22, x0
1005eb380:     	mov	x23, x2
1005eb384:     	cmp	w2, #0x3f
1005eb388:     	b.ls	0x1005eb4d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x350>
1005eb38c:     	mov	x0, x19
1005eb390:     	mov	x1, x21
1005eb394:     	bl	0x1005eaba0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
1005eb398:     	mov	x20, x0
1005eb39c:     	mov	x2, x23
1005eb3a0:     	mov	x0, x22
1005eb3a4:     	lsr	w8, w2, #19
1005eb3a8:     	cbz	w8, 0x1005eb440 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x2bc>
1005eb3ac:     	mov	w23, w2
1005eb3b0:     	add	x0, x23, #0x14
1005eb3b4:     	mov	w1, #0x3                ; =3
1005eb3b8:     	mov	x22, x2
1005eb3bc:     	bl	0x100458500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
1005eb3c0:     	mov	x21, x0
1005eb3c4:     	stp	w20, w22, [x0]
1005eb3c8:     	str	w22, [x0, #0x8]
1005eb3cc:     	mov	x8, #0x200000000        ; =8589934592
1005eb3d0:     	stur	x8, [x0, #0xc]
1005eb3d4:     	add	x0, x0, #0x14
1005eb3d8:     	mov	x1, x19
1005eb3dc:     	mov	x2, x22
1005eb3e0:     	bl	0x100b622ec <_writev+0x100b622ec>
1005eb3e4:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
1005eb3e8:     	ldr	w19, [x8, #0x590]
1005eb3ec:     	cmp	w19, #0x300
1005eb3f0:     	b.hs	0x1005eb5d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x454>
1005eb3f4:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1005eb3f8:     	ldr	x8, [x8, #0x48]
1005eb3fc:     	cmn	x8, #0x1
1005eb400:     	b.eq	0x1005eb5c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x444>
1005eb404:     	mrs	x9, TPIDRRO_EL0
1005eb408:     	and	x9, x9, #0xfffffffffffffff8
1005eb40c:     	ldr	x0, [x9, x8, lsl #3]
1005eb410:     	cbz	x0, 0x1005eb5c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x444>
1005eb414:     	add	x8, x0, x19, lsl #3
1005eb418:     	ldr	x0, [x8, #0x1e8]
1005eb41c:     	cbz	x0, 0x1005eb5d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x454>
1005eb420:     	ldr	x8, [x0]
1005eb424:     	adds	x8, x8, x23
1005eb428:     	csinv	x8, x8, xzr, lo
1005eb42c:     	str	x8, [x0]
1005eb430:     	lsr	x8, x8, #25
1005eb434:     	cbz	x8, 0x1005eb4b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x334>
1005eb438:     	bl	0x10045f434 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
1005eb43c:     	b	0x1005eb4b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x334>
1005eb440:     	add	x8, x2, #0x14
1005eb444:     	ldr	x9, [x0]
1005eb448:     	cbz	x9, 0x1005eb488 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005eb44c:     	add	x9, x8, #0xf
1005eb450:     	and	x9, x9, #0xfffffffffffffff8
1005eb454:     	cmp	x9, #0x4, lsl #12       ; =0x4000
1005eb458:     	b.hi	0x1005eb488 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005eb45c:     	ldr	x10, [x0, #0x10]
1005eb460:     	ldrb	w10, [x10]
1005eb464:     	tbnz	w10, #0x0, 0x1005eb488 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005eb468:     	ldr	x10, [x0, #0x8]
1005eb46c:     	ldp	x11, x12, [x10, #0x8]
1005eb470:     	add	x11, x11, #0x7
1005eb474:     	and	x11, x11, #0xfffffffffffffff8
1005eb478:     	subs	x12, x12, x11
1005eb47c:     	csel	x12, xzr, x12, lo
1005eb480:     	cmp	x9, x12
1005eb484:     	b.ls	0x1005eb560 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x3dc>
1005eb488:     	mov	x0, x2
1005eb48c:     	mov	x22, x2
1005eb490:     	bl	0x10034b32c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
1005eb494:     	mov	x21, x0
1005eb498:     	mov	x0, x1
1005eb49c:     	stp	w20, w22, [x21]
1005eb4a0:     	str	w22, [x21, #0x8]
1005eb4a4:     	mov	x8, #0x200000000        ; =8589934592
1005eb4a8:     	stur	x8, [x21, #0xc]
1005eb4ac:     	mov	x1, x19
1005eb4b0:     	mov	x2, x22
1005eb4b4:     	bl	0x100b622ec <_writev+0x100b622ec>
1005eb4b8:     	mov	x0, x21
1005eb4bc:     	ldp	x29, x30, [sp, #0x50]
1005eb4c0:     	ldp	x20, x19, [sp, #0x40]
1005eb4c4:     	ldp	x22, x21, [sp, #0x30]
1005eb4c8:     	ldp	x24, x23, [sp, #0x20]
1005eb4cc:     	add	sp, sp, #0x60
1005eb4d0:     	ret
1005eb4d4:     	add	x8, sp, #0x8
1005eb4d8:     	mov	x0, x19
1005eb4dc:     	mov	x1, x21
1005eb4e0:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
1005eb4e4:     	ldr	x8, [sp, #0x8]
1005eb4e8:     	cbz	x8, 0x1005eb5a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x41c>
1005eb4ec:     	mov	w20, #0x0               ; =0
1005eb4f0:     	mov	x8, #0x0                ; =0
1005eb4f4:     	mov	w9, #0x2                ; =2
1005eb4f8:     	mov	w10, #0x3               ; =3
1005eb4fc:     	mov	w11, #0x4               ; =4
1005eb500:     	mov	x2, x23
1005eb504:     	mov	x0, x22
1005eb508:     	b	0x1005eb520 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x39c>
1005eb50c:     	add	w20, w20, #0x1
1005eb510:     	mov	w12, #0x1               ; =1
1005eb514:     	add	x8, x12, x8
1005eb518:     	cmp	x8, x21
1005eb51c:     	b.hs	0x1005eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb520:     	ldrsb	w12, [x19, x8]
1005eb524:     	tbz	w12, #0x1f, 0x1005eb50c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x388>
1005eb528:     	and	w12, w12, #0xff
1005eb52c:     	cmp	w12, #0xc0
1005eb530:     	b.lo	0x1005eb510 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x38c>
1005eb534:     	cmp	w12, #0xf0
1005eb538:     	add	w13, w20, #0x2
1005eb53c:     	csel	x14, x10, x11, lo
1005eb540:     	csinc	w13, w13, w20, hs
1005eb544:     	cmp	w12, #0xe0
1005eb548:     	csel	x12, x9, x14, lo
1005eb54c:     	csinc	w20, w13, w20, hs
1005eb550:     	add	x8, x12, x8
1005eb554:     	cmp	x8, x21
1005eb558:     	b.lo	0x1005eb520 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x39c>
1005eb55c:     	b	0x1005eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb560:     	ldr	x12, [x10]
1005eb564:     	add	x22, x12, x11
1005eb568:     	add	x11, x11, x9
1005eb56c:     	str	x11, [x10, #0x8]
1005eb570:     	mov	w10, #0x203             ; =515
1005eb574:     	stp	w10, w9, [x22]
1005eb578:     	add	x21, x22, #0x8
1005eb57c:     	sub	x10, x9, #0x8
1005eb580:     	subs	x10, x10, x8
1005eb584:     	csel	x1, xzr, x10, lo
1005eb588:     	b.ls	0x1005eb62c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4a8>
1005eb58c:     	cmp	x1, #0x9
1005eb590:     	b.hs	0x1005eb61c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x498>
1005eb594:     	add	x8, x22, x9
1005eb598:     	stur	xzr, [x8, #-0x8]
1005eb59c:     	b	0x1005eb62c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4a8>
1005eb5a0:     	ldr	x8, [sp, #0x18]
1005eb5a4:     	mov	x2, x23
1005eb5a8:     	mov	x0, x22
1005eb5ac:     	cbz	x8, 0x1005eb600 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x47c>
1005eb5b0:     	ldr	x9, [sp, #0x10]
1005eb5b4:     	cmp	x8, #0x8
1005eb5b8:     	b.hs	0x1005eb608 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x484>
1005eb5bc:     	mov	x10, #0x0               ; =0
1005eb5c0:     	mov	w20, #0x0               ; =0
1005eb5c4:     	b	0x1005eb8fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x778>
1005eb5c8:     	bl	0x100b3f87c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005eb5cc:     	add	x8, x0, x19, lsl #3
1005eb5d0:     	ldr	x0, [x8, #0x1e8]
1005eb5d4:     	cbnz	x0, 0x1005eb420 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x29c>
1005eb5d8:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1005eb5dc:     	add	x0, x0, #0x78
1005eb5e0:     	bl	0x100b3d09c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1005eb5e4:     	ldr	x8, [x0]
1005eb5e8:     	adds	x8, x8, x23
1005eb5ec:     	csinv	x8, x8, xzr, lo
1005eb5f0:     	str	x8, [x0]
1005eb5f4:     	lsr	x8, x8, #25
1005eb5f8:     	cbnz	x8, 0x1005eb438 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x2b4>
1005eb5fc:     	b	0x1005eb4b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x334>
1005eb600:     	mov	w20, #0x0               ; =0
1005eb604:     	b	0x1005eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb608:     	cmp	x8, #0x20
1005eb60c:     	b.hs	0x1005eb648 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4c4>
1005eb610:     	mov	x10, #0x0               ; =0
1005eb614:     	mov	w20, #0x0               ; =0
1005eb618:     	b	0x1005eb84c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x6c8>
1005eb61c:     	add	x0, x21, x8
1005eb620:     	mov	x23, x2
1005eb624:     	bl	0x100b61e24 <_writev+0x100b61e24>
1005eb628:     	mov	x2, x23
1005eb62c:     	stp	w20, w2, [x22, #0x8]
1005eb630:     	str	w2, [x22, #0x10]
1005eb634:     	mov	x8, #0x200000000        ; =8589934592
1005eb638:     	stur	x8, [x22, #0x14]
1005eb63c:     	add	x0, x22, #0x1c
1005eb640:     	mov	x1, x19
1005eb644:     	b	0x1005eb4b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x330>
1005eb648:     	movi.2d	v0, #0000000000000000
1005eb64c:     	and	x11, x8, #0x18
1005eb650:     	movi.16b	v1, #0xf0
1005eb654:     	and	x10, x8, #0xffffffffffffffe0
1005eb658:     	movi.4s	v2, #0x2
1005eb65c:     	add	x12, x9, #0x10
1005eb660:     	movi.16b	v4, #0xc0
1005eb664:     	and	x13, x8, #0xffffffffffffffe0
1005eb668:     	movi.2d	v3, #0000000000000000
1005eb66c:     	movi.2d	v6, #0000000000000000
1005eb670:     	movi.2d	v5, #0000000000000000
1005eb674:     	movi.2d	v7, #0000000000000000
1005eb678:     	movi.2d	v16, #0000000000000000
1005eb67c:     	movi.2d	v17, #0000000000000000
1005eb680:     	movi.2d	v18, #0000000000000000
1005eb684:     	ldp	q20, q19, [x12, #-0x10]
1005eb688:     	cmhi.16b	v21, v1, v20
1005eb68c:     	sshll2.8h	v22, v21, #0x0
1005eb690:     	sshll2.4s	v23, v22, #0x0
1005eb694:     	sshll.4s	v24, v22, #0x0
1005eb698:     	sshll.8h	v21, v21, #0x0
1005eb69c:     	sshll2.4s	v25, v21, #0x0
1005eb6a0:     	sshll.4s	v26, v21, #0x0
1005eb6a4:     	cmhi.16b	v27, v1, v19
1005eb6a8:     	sshll2.8h	v28, v27, #0x0
1005eb6ac:     	sshll2.4s	v29, v28, #0x0
1005eb6b0:     	sshll.4s	v30, v28, #0x0
1005eb6b4:     	sshll.8h	v27, v27, #0x0
1005eb6b8:     	sshll2.4s	v31, v27, #0x0
1005eb6bc:     	bic.16b	v26, v2, v26
1005eb6c0:     	ssubw.4s	v26, v26, v21
1005eb6c4:     	bic.16b	v25, v2, v25
1005eb6c8:     	ssubw2.4s	v25, v25, v21
1005eb6cc:     	sshll.4s	v21, v27, #0x0
1005eb6d0:     	bic.16b	v24, v2, v24
1005eb6d4:     	ssubw.4s	v24, v24, v22
1005eb6d8:     	bic.16b	v23, v2, v23
1005eb6dc:     	ssubw2.4s	v22, v23, v22
1005eb6e0:     	bic.16b	v21, v2, v21
1005eb6e4:     	ssubw.4s	v21, v21, v27
1005eb6e8:     	bic.16b	v23, v2, v31
1005eb6ec:     	ssubw2.4s	v23, v23, v27
1005eb6f0:     	bic.16b	v27, v2, v30
1005eb6f4:     	ssubw.4s	v27, v27, v28
1005eb6f8:     	bic.16b	v29, v2, v29
1005eb6fc:     	ssubw2.4s	v28, v29, v28
1005eb700:     	cmgt.16b	v29, v4, v20
1005eb704:     	sshll2.8h	v30, v29, #0x0
1005eb708:     	ushll2.4s	v31, v30, #0x0
1005eb70c:     	bic.16b	v22, v22, v31
1005eb710:     	cmlt.16b	v20, v20, #0
1005eb714:     	sshll.8h	v29, v29, #0x0
1005eb718:     	ushll.4s	v30, v30, #0x0
1005eb71c:     	bic.16b	v24, v24, v30
1005eb720:     	ushll2.4s	v30, v29, #0x0
1005eb724:     	bic.16b	v25, v25, v30
1005eb728:     	sshll2.8h	v30, v20, #0x0
1005eb72c:     	sshll.8h	v20, v20, #0x0
1005eb730:     	ushll.4s	v29, v29, #0x0
1005eb734:     	bic.16b	v26, v26, v29
1005eb738:     	sshll.4s	v29, v20, #0x0
1005eb73c:     	and.16b	v26, v26, v29
1005eb740:     	mvn.16b	v29, v29
1005eb744:     	sub.4s	v26, v26, v29
1005eb748:     	sshll2.4s	v29, v30, #0x0
1005eb74c:     	sshll.4s	v30, v30, #0x0
1005eb750:     	sshll2.4s	v20, v20, #0x0
1005eb754:     	and.16b	v25, v25, v20
1005eb758:     	mvn.16b	v20, v20
1005eb75c:     	sub.4s	v20, v25, v20
1005eb760:     	cmgt.16b	v25, v4, v19
1005eb764:     	and.16b	v24, v24, v30
1005eb768:     	mvn.16b	v30, v30
1005eb76c:     	sub.4s	v24, v24, v30
1005eb770:     	sshll2.8h	v30, v25, #0x0
1005eb774:     	and.16b	v22, v22, v29
1005eb778:     	mvn.16b	v29, v29
1005eb77c:     	sub.4s	v22, v22, v29
1005eb780:     	ushll2.4s	v29, v30, #0x0
1005eb784:     	bic.16b	v28, v28, v29
1005eb788:     	cmlt.16b	v19, v19, #0
1005eb78c:     	sshll.8h	v25, v25, #0x0
1005eb790:     	ushll.4s	v29, v30, #0x0
1005eb794:     	bic.16b	v27, v27, v29
1005eb798:     	ushll2.4s	v29, v25, #0x0
1005eb79c:     	bic.16b	v23, v23, v29
1005eb7a0:     	sshll.8h	v29, v19, #0x0
1005eb7a4:     	ushll.4s	v25, v25, #0x0
1005eb7a8:     	bic.16b	v21, v21, v25
1005eb7ac:     	sshll.4s	v25, v29, #0x0
1005eb7b0:     	and.16b	v21, v21, v25
1005eb7b4:     	mvn.16b	v25, v25
1005eb7b8:     	sub.4s	v21, v21, v25
1005eb7bc:     	sshll2.8h	v19, v19, #0x0
1005eb7c0:     	sshll2.4s	v25, v29, #0x0
1005eb7c4:     	and.16b	v23, v23, v25
1005eb7c8:     	mvn.16b	v25, v25
1005eb7cc:     	sub.4s	v23, v23, v25
1005eb7d0:     	sshll.4s	v25, v19, #0x0
1005eb7d4:     	and.16b	v27, v27, v25
1005eb7d8:     	mvn.16b	v25, v25
1005eb7dc:     	sub.4s	v25, v27, v25
1005eb7e0:     	sshll2.4s	v19, v19, #0x0
1005eb7e4:     	and.16b	v27, v28, v19
1005eb7e8:     	mvn.16b	v19, v19
1005eb7ec:     	sub.4s	v19, v27, v19
1005eb7f0:     	add.4s	v7, v22, v7
1005eb7f4:     	add.4s	v5, v24, v5
1005eb7f8:     	add.4s	v6, v20, v6
1005eb7fc:     	add.4s	v3, v26, v3
1005eb800:     	add.4s	v18, v19, v18
1005eb804:     	add.4s	v17, v25, v17
1005eb808:     	add.4s	v0, v23, v0
1005eb80c:     	add.4s	v16, v21, v16
1005eb810:     	add	x12, x12, #0x20
1005eb814:     	subs	x13, x13, #0x20
1005eb818:     	b.ne	0x1005eb684 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x500>
1005eb81c:     	add.4s	v0, v0, v6
1005eb820:     	add.4s	v1, v18, v7
1005eb824:     	add.4s	v2, v16, v3
1005eb828:     	add.4s	v3, v17, v5
1005eb82c:     	add.4s	v2, v2, v3
1005eb830:     	add.4s	v0, v0, v1
1005eb834:     	add.4s	v0, v2, v0
1005eb838:     	addv.4s	s0, v0
1005eb83c:     	fmov	w20, s0
1005eb840:     	cmp	x8, x10
1005eb844:     	b.eq	0x1005eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb848:     	cbz	x11, 0x1005eb8fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x778>
1005eb84c:     	mov	x12, x10
1005eb850:     	and	x10, x8, #0xfffffffffffffff8
1005eb854:     	movi.2d	v0, #0000000000000000
1005eb858:     	mov.s	v0[0], w20
1005eb85c:     	movi.2d	v1, #0000000000000000
1005eb860:     	sub	x11, x12, x10
1005eb864:     	add	x12, x9, x12
1005eb868:     	movi.8b	v2, #0xf0
1005eb86c:     	movi.4s	v3, #0x2
1005eb870:     	movi.8b	v4, #0xc0
1005eb874:     	ldr	d5, [x12], #0x8
1005eb878:     	sshll.8h	v6, v5, #0x0
1005eb87c:     	cmlt.8h	v6, v6, #0
1005eb880:     	sshll2.4s	v7, v6, #0x0
1005eb884:     	sshll.4s	v6, v6, #0x0
1005eb888:     	cmhi.8b	v16, v2, v5
1005eb88c:     	sshll.8h	v16, v16, #0x0
1005eb890:     	sshll2.4s	v17, v16, #0x0
1005eb894:     	sshll.4s	v18, v16, #0x0
1005eb898:     	bic.16b	v18, v3, v18
1005eb89c:     	ssubw.4s	v18, v18, v16
1005eb8a0:     	bic.16b	v17, v3, v17
1005eb8a4:     	ssubw2.4s	v16, v17, v16
1005eb8a8:     	cmgt.8b	v5, v4, v5
1005eb8ac:     	sshll.8h	v5, v5, #0x0
1005eb8b0:     	ushll.4s	v17, v5, #0x0
1005eb8b4:     	ushll2.4s	v5, v5, #0x0
1005eb8b8:     	bic.16b	v5, v16, v5
1005eb8bc:     	bic.16b	v16, v18, v17
1005eb8c0:     	and.16b	v16, v16, v6
1005eb8c4:     	mvn.16b	v6, v6
1005eb8c8:     	sub.4s	v6, v16, v6
1005eb8cc:     	and.16b	v5, v5, v7
1005eb8d0:     	mvn.16b	v7, v7
1005eb8d4:     	sub.4s	v5, v5, v7
1005eb8d8:     	add.4s	v1, v5, v1
1005eb8dc:     	add.4s	v0, v6, v0
1005eb8e0:     	adds	x11, x11, #0x8
1005eb8e4:     	b.ne	0x1005eb874 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x6f0>
1005eb8e8:     	add.4s	v0, v0, v1
1005eb8ec:     	addv.4s	s0, v0
1005eb8f0:     	fmov	w20, s0
1005eb8f4:     	cmp	x8, x10
1005eb8f8:     	b.eq	0x1005eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb8fc:     	sub	x8, x8, x10
1005eb900:     	add	x9, x9, x10
1005eb904:     	mov	w10, #0x1               ; =1
1005eb908:     	ldrsb	w11, [x9], #0x1
1005eb90c:     	and	w12, w11, #0xff
1005eb910:     	cmp	w12, #0xf0
1005eb914:     	cinc	w13, w10, hs
1005eb918:     	cmp	w12, #0xc0
1005eb91c:     	csel	w12, wzr, w13, lo
1005eb920:     	tst	w11, #0x80000000
1005eb924:     	csinc	w11, w12, wzr, ne
1005eb928:     	add	w20, w11, w20
1005eb92c:     	subs	x8, x8, #0x1
1005eb930:     	b.ne	0x1005eb908 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x784>
1005eb934:     	b	0x1005eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
