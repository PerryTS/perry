; ModuleID = '/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/source-length-hint-r27/candidate-token-ir-native/.perry-trace/llvm/test_json_source_token_length_ts.ll'
source_filename = "perry_module"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx15.0.0"

module asm ".no_dead_strip __LLVM_StackMaps"

@test_json_source_token_length_ts_.str.0 = private unnamed_addr constant [92 x i8] c"/Users/amlug/projects/perry/json-merged-pr10022/test-files/test_json_source_token_length.ts\00"
@test_json_source_token_length_ts_.str.0.bytes = private unnamed_addr constant [12 x i8] c"ascii text \00"
@test_json_source_token_length_ts_.str.1.bytes = private unnamed_addr constant [13 x i8] c"\E6\9D\B1\E4\BA\AC\F0\9F\99\82\C3\A9\00"
@test_json_source_token_length_ts_.str.2.bytes = private unnamed_addr constant [13 x i8] c"\F0\90\80\80\F0\90\90\B7\F0\A4\AD\A2\00"
@test_json_source_token_length_ts_.str.3.bytes = private unnamed_addr constant [7 x i8] c"{\22id\22:\00"
@test_json_source_token_length_ts_.str.4.bytes = private unnamed_addr constant [10 x i8] c",\22text\22:\22\00"
@test_json_source_token_length_ts_.str.5.bytes = private unnamed_addr constant [3 x i8] c"\22}\00"
@test_json_source_token_length_ts_.str.6.bytes = private unnamed_addr constant [7 x i8] c"{\22\C3\A9\22:\00"
@test_json_source_token_length_ts_.str.7.bytes = private unnamed_addr constant [17 x i8] c"\\n\\uD83D\\uDE42\22}\00"
@test_json_source_token_length_ts_.str.8.bytes = private unnamed_addr constant [6 x i8] c"\0A\F0\9F\99\82\00"
@test_json_source_token_length_ts_.str.9.bytes = private unnamed_addr constant [2 x i8] c" \00"
@test_json_source_token_length_ts_.str.10.bytes = private unnamed_addr constant [5 x i8] c"text\00"
@test_json_source_token_length_ts_.str.11.bytes = private unnamed_addr constant [21 x i8] c"parsed token changed\00"
@test_json_source_token_length_ts_.str.12.bytes = private unnamed_addr constant [7 x i8] c"length\00"
@test_json_source_token_length_ts_.str.13.bytes = private unnamed_addr constant [33 x i8] c",\22name\22:\22source token lifetime\22}\00"
@test_json_source_token_length_ts_.str.14.bytes = private unnamed_addr constant [3 x i8] c"id\00"
@test_json_source_token_length_ts_.str.15.bytes = private unnamed_addr constant [14 x i8] c"churn changed\00"
@test_json_source_token_length_ts_.str.16.bytes = private unnamed_addr constant [24 x i8] c"retained output changed\00"
@test_json_source_token_length_ts_.str.17.bytes = private unnamed_addr constant [24 x i8] c"retained source changed\00"
@test_json_source_token_length_ts_.str.18.bytes = private unnamed_addr constant [7 x i8] c"VERIFY\00"
@test_json_source_token_length_ts_.str.19.bytes = private unnamed_addr constant [9 x i8] c"retained\00"
@PERRY_SYMBOL_PROPERTY_IC_EPOCH = external global i64
@PERRY_GC_POLL_ARMED = external global i32
@PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD = external global [65536 x i8]
@PERRY_PER_OBJECT_LAYOUTS_ANY = external global i32
@PERRY_LAYOUT_ADDR_FILTER = external global [64 x i64]
@PERRY_YOUNG_LAYOUT_RECORDS = external global i32
@PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED = external global i8
@PERRY_ARRAY_PROTO_ITERATOR_PATCHED = external global i8
@PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT = external global i32
@PERRY_HOT_TSD_KEY = external global i64
@PERRY_TA_KIND_CACHE = external global [64 x i64]
@PERRY_U8_INLINE_CACHE = external global [64 x i64]
@PERRY_TA_VIEW_GUARD = external global i64
@perry_null_guard_zero_test_json_source_token_length_ts = internal global i32 0
@perry_ic_test_json_source_token_length_ts__0 = private global ptr null
@perry_ic_test_json_source_token_length_ts__2 = private global ptr null
@perry_ic_test_json_source_token_length_ts__5 = private global ptr null
@perry_ic_test_json_source_token_length_ts__8 = private global ptr null
@perry_ic_test_json_source_token_length_ts__10 = private global ptr null
@perry_ic_test_json_source_token_length_ts__13 = private global ptr null
@perry_ic_test_json_source_token_length_ts__14 = private global ptr null
@perry_ic_test_json_source_token_length_ts__15 = private global ptr null
@perry_ic_test_json_source_token_length_ts__18 = private global ptr null
@perry_ic_test_json_source_token_length_ts__22 = private global ptr null
@perry_ic_test_json_source_token_length_ts__24 = private global ptr null
@perry_ic_test_json_source_token_length_ts__26 = private global ptr null
@perry_ic_test_json_source_token_length_ts__28 = private global ptr null
@perry_ic_test_json_source_token_length_ts__29 = private global ptr null
@perry_ic_test_json_source_token_length_ts__32 = private global ptr null
@perry_ic_test_json_source_token_length_ts__34 = private global ptr null
@perry_ic_test_json_source_token_length_ts__35 = private global ptr null
@test_json_source_token_length_ts_.str.0.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.1.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.2.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.3.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.4.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.5.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.6.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.7.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.8.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.9.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.10.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.11.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.12.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.13.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.14.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.15.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.16.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.17.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.18.handle = internal global double 0.000000e+00
@test_json_source_token_length_ts_.str.19.handle = internal global double 0.000000e+00

declare void @js_gc_init()

declare void @js_typed_feedback_maybe_dump_trace()

declare void @js_set_process_entry_path(ptr, i32)

declare void @js_stdlib_init_dispatch()

declare void @perry_app_group_init(ptr, i32)

declare void @perry_update_notify_startup(ptr, i32)

declare void @perry_macos_bundle_chdir()

declare i32 @perry_i18n_locale_index_for(i64, i32)

declare void @perry_i18n_init(ptr, ptr, i32, i32)

declare void @perry_i18n_set_currencies(ptr, i32)

declare i32 @perry_i18n_plural_category(i32, double)

declare void @js_register_function_name_static(ptr, ptr, i32)

declare void @js_register_function_name(ptr, ptr, i32)

declare void @js_register_function_source_static(ptr, ptr, i32, i32)

declare void @js_register_function_source(ptr, ptr, i32, i32)

declare void @js_console_log_dynamic(double)

declare void @js_console_log_number(double)

declare void @js_console_error_dynamic(double)

declare void @js_console_error_number(double)

declare void @js_console_warn_dynamic(double)

declare void @js_console_warn_number(double)

declare void @js_console_dir_with_options(double, double)

declare double @js_console_method_by_value(double)

declare double @js_nanbox_string(i64)

; Function Attrs: nounwind willreturn
declare double @js_nanbox_pointer(i64) #0

; Function Attrs: nounwind willreturn
declare i64 @js_nanbox_get_pointer(double) #0

declare double @js_native_handle_new_owned(i64, i64, i32, i32, ptr, ptr, i64)

declare double @js_native_handle_new_borrowed(i64, i64, i32, i32, ptr, i64)

declare i64 @js_native_handle_unwrap(double, i64, i32, i32, i32)

declare i64 @js_string_from_bytes(ptr, i32)

declare i64 @js_string_from_wtf8_bytes(ptr, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_is_truthy(double) #0

declare double @js_native_abi_check_f64(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_f64_arg_guard(double) #0

declare double @js_typed_f64_arg_to_raw(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_string_arg_guard(double) #0

declare i64 @js_typed_string_arg_to_raw(double)

declare i32 @js_param_type_guard(double, ptr, i32)

declare float @js_native_abi_check_f32(double)

declare i8 @js_native_abi_check_i8(double)

declare i16 @js_native_abi_check_i16(double)

declare i32 @js_native_abi_check_i32(double)

declare i64 @js_native_abi_check_i64(double)

declare i8 @js_native_abi_check_u8(double)

declare i16 @js_native_abi_check_u16(double)

declare i32 @js_native_abi_check_u32(double)

declare i64 @js_native_abi_check_u64(double)

declare i64 @js_native_abi_check_usize(double)

declare i64 @js_native_abi_check_isize(double)

declare double @js_native_abi_materialize_i64(i64)

declare double @js_native_abi_materialize_u64(i64)

declare i64 @js_native_abi_check_string_ptr(double)

declare i64 @js_native_abi_check_ptr(double)

declare ptr @js_native_abi_check_buffer_data_ptr(double)

declare i64 @js_native_abi_check_buffer_byte_len(double)

declare i64 @js_native_abi_check_promise(double)

declare i64 @js_native_abi_check_pod_object(double)

declare double @js_date_now()

declare void @js_gc_register_global_root(i64)

declare i64 @js_string_concat(i64, i64)

declare double @js_string_concat_box(double, double)

declare i64 @js_jsvalue_to_string(double)

declare i64 @js_jsvalue_to_string_method(double)

declare i64 @js_jsvalue_to_string_coerce(double)

declare i64 @js_string_concat_value(i64, double)

declare double @js_string_concat_site_value(i64, i64, double)

declare i64 @js_value_concat_string(double, i64)

declare double @js_string_concat_value_box(i64, double)

declare double @js_string_add_value(double, double)

declare double @js_value_add_string(double, double)

declare i64 @js_string_concat_chain(i64, i32)

declare i64 @js_string_append_chain(i64, i32)

declare i64 @js_string_append(i64, i64)

declare i64 @js_string_append_known_heap(i64, i64)

declare i32 @js_string_index_of(i64, i64)

declare i32 @js_string_index_of_from(i64, i64, i32)

declare i32 @js_string_position_to_index(double)

declare i64 @js_string_slice(i64, i32, i32)

declare i64 @js_string_substring(i64, i32, i32)

declare i64 @js_string_substr(i64, double, double)

declare i64 @js_string_split(i64, i64)

declare i64 @js_string_split_n(i64, i64, i32)

declare double @js_string_split_part_value(i64, i64, i32)

declare double @js_string_split_part_utf16_length(i64, i64, i32)

declare double @js_string_to_upper_case_split_part_utf16_length(i64, i64, i32)

declare i32 @js_string_to_upper_case_index_of(i64, i64)

declare i64 @js_string_split_value(i64, double, double)

declare double @js_math_trunc(double)

declare double @js_math_round(double)

declare double @js_math_sign(double)

declare double @js_math_imul(double, double)

declare double @js_math_pow(double, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.ceil.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.copysign.f64(double, double) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.aarch64.fjcvtzs(double) #3

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #5

declare i64 @js_json_stringify(double, i32)

declare i64 @js_map_alloc(i32)

declare i64 @js_text_encoder_encode_into_llvm(double, double)

declare i64 @js_value_typeof(double)

declare i32 @js_value_typeof_tag(double)

declare i32 @js_string_starts_with(i64, i64)

declare i32 @js_string_ends_with(i64, i64)

declare i64 @js_string_search_value_to_string(double, i32)

declare i32 @js_string_starts_with_at(i64, i64, i32)

declare i32 @js_string_ends_with_at(i64, i64, i32)

declare i64 @js_closure_alloc(ptr, i32)

declare i64 @js_closure_alloc_init(ptr, i32, ptr)

declare i64 @js_closure_alloc_singleton(ptr)

declare i64 @js_closure_alloc_with_captures_singleton(ptr, i32, ptr)

declare void @js_closure_set_capture_bits(i64, i32, i64)

declare void @js_closure_set_box_capture_ptr(i64, i32, i64)

declare i64 @js_closure_get_capture_bits(i64, i32)

declare void @js_closure_set_capture_f64(i64, i32, double)

declare double @js_closure_get_capture_f64(i64, i32)

declare void @js_register_closure_rest(ptr, i32)

declare void @js_register_closure_synthetic_arguments(ptr, i32)

declare void @js_register_closure_rest_and_arguments(ptr, i32)

declare void @js_register_closure_arity(ptr, i32)

declare void @js_register_closure_length(ptr, i32)

declare void @js_register_closure_arrow_function(ptr)

declare void @js_register_closure_trusted_direct(ptr, ptr, i32, i64)

declare void @js_register_closure_versioned_loop_direct(ptr, ptr, i32, i64)

declare ptr @js_closure_resolve_versioned_loop_direct_call(i64, i32)

declare void @js_register_closure_strict_function(ptr)

declare void @js_register_closure_async_function(ptr)

declare void @js_register_closure_generator_function(ptr)

declare void @js_register_closure_async_generator_function(ptr)

declare i64 @js_closure_unbox_callee_checked(double)

declare i64 @js_closure_unbox_callee_checked_rebind(double, double)

declare double @js_closure_call0(i64)

declare double @js_closure_call1(i64, double)

declare double @js_closure_call1_receiverless(i64, double)

declare double @js_closure_call2(i64, double, double)

declare double @js_closure_call3(i64, double, double, double)

declare ptr @js_closure_resolve_arrow_direct_call(i64, i32)

declare double @js_closure_call4(i64, double, double, double, double)

declare double @js_closure_call5(i64, double, double, double, double, double)

declare double @js_closure_call6(i64, double, double, double, double, double, double)

declare double @js_closure_call7(i64, double, double, double, double, double, double, double)

declare double @js_closure_call8(i64, double, double, double, double, double, double, double, double)

declare double @js_closure_call9(i64, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call10(i64, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call11(i64, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call12(i64, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call13(i64, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call14(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call15(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call16(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare i64 @js_array_map(i64, i64)

declare void @js_array_map_discard(i64, i64)

declare i64 @js_array_filter(i64, i64)

declare i64 @js_array_concat(i64, i64)

declare i64 @js_array_concat_new(i64, i64)

declare i64 @js_error_new()

declare i64 @js_error_new_with_message(i64)

declare i64 @js_error_new_from_value(double)

declare i64 @js_error_new_kind_from_value(i32, double)

declare i64 @js_error_new_with_cause_from_value(double, double)

declare i64 @js_error_new_kind_with_options_from_value(i32, double, double)

declare double @js_assert_assertion_error_ctor(double)

declare double @js_assert_assert_ctor(double)

declare void @js_throw_type_error_property_access(i32, ptr, i64)

declare void @js_throw_type_error_not_a_function(ptr, i64, ptr, i64)

declare void @js_throw_error_with_code(ptr, i64, ptr, i64, i32)

declare i64 @js_map_set(i64, double, double)

declare i64 @js_map_set_string_number(i64, i64, double)

declare i64 @js_map_set_string_key(i64, i64, double)

declare i64 @js_map_set_string_i32(i64, i64, i32)

declare i64 @js_map_set_string_u32(i64, i64, i32)

declare i64 @js_map_set_string_f32(i64, i64, float)

declare i64 @js_map_set_string_bool(i64, i64, i32)

declare i64 @js_map_set_string_string(i64, i64, i64)

declare i64 @js_map_set_number_key(i64, double, double)

declare double @js_map_get(i64, double)

declare double @js_declared_map_get(double, double)

declare double @js_map_get_string_key(i64, i64)

declare double @js_map_get_number_key(i64, double)

declare i32 @js_map_has(i64, double)

declare i32 @js_map_has_string_key(i64, i64)

declare i32 @js_map_has_number_key(i64, double)

declare i32 @js_map_delete(i64, double)

declare i32 @js_map_delete_string_key(i64, i64)

declare i32 @js_map_delete_number_key(i64, double)

declare i64 @js_object_keys(i64)

declare i64 @js_object_keys_value(double)

declare i64 @js_for_in_keys_value(double)

declare i64 @js_for_in_keys_stable_value(double)

declare double @js_is_finite(double)

declare i32 @js_is_undefined_or_bare_nan(double)

declare double @js_math_min_array(i64)

declare double @js_math_max_array(i64)

declare double @js_math_min2(double, double)

declare double @js_math_max2(double, double)

declare i64 @js_string_coerce(double)

declare i64 @js_string_coerce_method_this(double, ptr, i64)

declare i64 @js_array_slice(i64, i32, i32)

declare i64 @js_array_slice_values(i64, double, double)

declare double @js_array_shift_f64(i64)

declare i64 @js_set_alloc(i32)

declare i64 @js_set_from_array(i64)

declare i64 @js_set_from_iterable(double)

declare i64 @js_map_from_array(i64)

declare i64 @js_map_from_iterable(double)

declare double @js_object_has_property(double, double)

declare double @js_in_operator(double, double)

declare double @js_private_brand_check(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_guard(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_brand_add(double, i32)

declare double @js_private_field_add(double, i32, double, double)

declare double @js_class_field_add(double, double, double)

declare double @js_class_computed_field_key(double, i32, ptr, i64)

declare double @js_fs_to_unix_timestamp(double)

declare i32 @js_fs_write_file_sync(double, double)

declare i32 @js_fs_write_file_sync_options(double, double, double)

declare i32 @js_fs_append_file_sync(double, double)

declare i32 @js_fs_append_file_sync_options(double, double, double)

declare i32 @js_fs_exists_sync(double)

declare i64 @js_fs_read_file_sync(double)

declare double @js_fs_read_file_dispatch(double, double)

declare double @js_fs_open_as_blob(double, double)

declare double @js_fs_promises_read_file(double, double)

declare double @js_fs_promises_write_file(double, double, double)

declare double @js_fs_promises_append_file(double, double, double)

declare double @js_fs_promises_mkdir(double, double)

declare double @js_fs_promises_rmdir(double, double)

declare i32 @js_fs_mkdir_sync(double)

declare i32 @js_fs_mkdir_sync_options(double, double)

declare i32 @js_fs_unlink_sync(double)

declare double @js_fs_readdir_sync(double, double)

declare double @js_fs_stat_sync(double)

declare double @js_fs_stat_sync_options(double, double)

declare double @js_fs_lstat_sync(double)

declare double @js_fs_lstat_sync_options(double, double)

declare i32 @js_fs_rename_sync(double, double)

declare i32 @js_fs_copy_file_sync(double, double)

declare i32 @js_fs_copy_file_sync_flags(double, double, double)

declare i32 @js_fs_cp_sync(double, double)

declare i32 @js_fs_cp_sync_options(double, double, double)

declare i32 @js_fs_chmod_sync(double, double)

declare i32 @js_fs_chown_sync(double, double, double)

declare i32 @js_fs_lchown_sync(double, double, double)

declare i32 @js_fs_lchmod_sync(double, double)

declare i32 @js_fs_truncate_sync(double, double)

declare i32 @js_fs_ftruncate_sync(double, double)

declare i32 @js_fs_fsync_sync(double)

declare i32 @js_fs_fdatasync_sync(double)

declare i32 @js_fs_fchmod_sync(double, double)

declare i32 @js_fs_fchown_sync(double, double, double)

declare double @js_fs_fstat_sync(double)

declare double @js_fs_fstat_sync_options(double, double)

declare i32 @js_fs_utimes_sync(double, double, double)

declare i32 @js_fs_lutimes_sync(double, double, double)

declare i32 @js_fs_futimes_sync(double, double, double)

declare double @js_fs_readv_sync(double, double, double)

declare double @js_fs_writev_sync(double, double, double)

declare double @js_fs_statfs_sync(double)

declare double @js_fs_statfs_sync_options(double, double)

declare double @js_fs_opendir_sync(double)

declare double @js_fs_glob_sync(double)

declare double @js_fs_glob_sync_options(double, double)

declare i32 @js_fs_link_sync(double, double)

declare i32 @js_fs_symlink_sync(double, double)

declare double @js_fs_symlink_callback(double, double, double, double)

declare i64 @js_fs_readlink_sync(double)

declare i64 @js_fs_readlink_sync_options(double, double)

declare double @js_fs_readlink_dispatch(double, double)

declare double @js_fs_open_sync(double, double)

declare i32 @js_fs_close_sync(double)

declare double @js_fs_read_sync(double, double, double, double, double)

declare double @js_fs_read_sync_options(double, double, double)

declare double @js_fs_write_sync(double, double)

declare double @js_fs_write_string_sync_options(double, double, double)

declare double @js_fs_write_buffer_sync(double, double, double, double, double)

declare double @js_fs_write_sync_options_dispatch(double, double, double)

declare i32 @js_fs_access_sync(double)

declare i32 @js_fs_access_sync_mode(double, double)

declare double @js_fs_access_sync_throw(double)

declare double @js_fs_access_sync_throw_mode(double, double)

declare i64 @js_fs_realpath_sync(double)

declare double @js_fs_realpath_dispatch(double, double)

declare i64 @js_fs_mkdtemp_sync(double)

declare i64 @js_fs_mkdtemp_sync_options(double, double)

declare double @js_fs_mkdtemp_dispatch(double, double)

declare double @js_fs_mkdtemp_disposable_sync(double, double)

declare i32 @js_fs_rmdir_sync(double)

declare i32 @js_fs_rmdir_sync_options(double, double)

declare i32 @js_fs_rm_recursive(double)

declare i32 @js_fs_rm_recursive_options(double, double)

declare double @js_fs_create_write_stream(double, double)

declare double @js_fs_create_read_stream(double, double)

declare double @js_fs_utf8_stream_new(double)

declare double @js_fs_utf8_stream_call_without_new(double)

declare double @js_fs_utf8_stream_write(double, double)

declare double @js_fs_utf8_stream_flush(double, double)

declare double @js_fs_utf8_stream_flush_sync(double)

declare double @js_fs_utf8_stream_end(double, double)

declare double @js_fs_utf8_stream_destroy(double)

declare double @js_fs_utf8_stream_reopen(double, double)

declare double @js_fs_utf8_stream_on(double, double, double)

declare double @js_fs_utf8_stream_once(double, double, double)

declare double @js_fs_utf8_stream_off(double, double, double)

declare double @js_fs_utf8_stream_remove_all(double, double)

declare double @js_fs_utf8_stream_listener_count(double, double)

declare double @js_fs_utf8_stream_emit(double, double, double)

declare double @js_fs_read_file_callback(double, double, double)

declare double @js_fs_stats_is_file(double)

declare double @js_fs_stats_is_directory(double)

declare i64 @js_fs_read_file_binary(double)

declare double @js_number_coerce(double)

declare double @js_math_to_number(double)

declare i64 @js_set_add(i64, double)

declare i64 @js_set_add_string(i64, i64)

declare i64 @js_set_add_number(i64, double)

declare i64 @js_set_add_i32(i64, i32)

declare i64 @js_set_add_u32(i64, i32)

declare i64 @js_set_add_f32(i64, float)

declare i64 @js_set_add_bool(i64, i32)

declare i32 @js_set_has(i64, double)

declare double @js_readonly_set_has(double, double)

declare i32 @js_set_has_string(i64, i64)

declare i32 @js_set_has_number(i64, double)

declare i32 @js_set_has_i32(i64, i32)

declare i32 @js_set_has_u32(i64, i32)

declare i32 @js_set_has_f32(i64, float)

declare i32 @js_set_has_bool(i64, i32)

declare i32 @js_set_delete(i64, double)

declare i32 @js_set_delete_string(i64, i64)

declare i32 @js_set_delete_number(i64, double)

declare i32 @js_set_delete_i32(i64, i32)

declare i32 @js_set_delete_u32(i64, i32)

declare i32 @js_set_delete_f32(i64, float)

declare i32 @js_set_delete_bool(i64, i32)

declare i32 @js_set_size(i64)

declare i64 @js_set_union(i64, double)

declare i64 @js_set_intersection(i64, double)

declare i64 @js_set_difference(i64, double)

declare i64 @js_set_symmetric_difference(i64, double)

declare i32 @js_set_is_subset_of(i64, double)

declare i32 @js_set_is_superset_of(i64, double)

declare i32 @js_set_is_disjoint_from(i64, double)

declare i64 @js_string_to_lower_case(i64)

declare i64 @js_string_to_upper_case(i64)

declare i64 @js_string_to_locale_lower_case(i64, double)

declare i64 @js_string_to_locale_upper_case(i64, double)

declare void @js_string_validate_collator_args(double, double)

declare i64 @js_string_trim(i64)

declare i64 @js_string_trim_start(i64)

declare i64 @js_string_trim_end(i64)

declare i64 @js_string_big(i64)

declare i64 @js_string_blink(i64)

declare i64 @js_string_bold(i64)

declare i64 @js_string_fixed(i64)

declare i64 @js_string_italics(i64)

declare i64 @js_string_small(i64)

declare i64 @js_string_strike(i64)

declare i64 @js_string_sub(i64)

declare i64 @js_string_sup(i64)

declare i64 @js_string_anchor(i64, i64)

declare i64 @js_string_link(i64, i64)

declare i64 @js_string_fontcolor(i64, i64)

declare i64 @js_string_fontsize(i64, i64)

declare i64 @js_string_char_at(i64, i32)

declare double @js_string_index_get(i64, double)

declare double @js_string_index_get_boxed(double, double)

declare i32 @js_string_index_to_i32(double)

declare i32 @js_string_end_index_to_i32(double, i32)

declare double @js_typed_feedback_object_get_field_by_value_f64(i64, i64, double)

declare double @js_dyn_index_get(double, double)

declare double @js_packed_arraylike_index_get(double, double, ptr)

declare i32 @js_packed_arraylike_loop_guard(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_guard_live(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_revalidate_live(double, double, i32, ptr)

declare double @js_dyn_index_set(double, double, double)

declare double @js_dyn_index_set_strict(double, double, double, i32)

declare i64 @js_string_to_char_array(i64)

declare i64 @js_string_repeat(i64, double)

declare i64 @js_string_replace_string(i64, i64, i64)

declare i64 @js_string_replace_all_string(i64, i64, i64)

declare i32 @js_string_equals(i64, i64)

declare i32 @js_string_compare(i64, i64)

declare i32 @js_jsvalue_equals(double, double)

declare i32 @js_string_compare_value(double, double)

declare i64 @js_jsvalue_to_string_radix(double, double)

declare double @js_math_random()

declare double @js_webassembly_validate(double)

declare double @js_webassembly_compile(double)

declare double @js_webassembly_module_new(double)

declare double @js_webassembly_module_exports(double)

declare double @js_webassembly_module_imports(double)

declare double @js_webassembly_module_custom_sections(double, double)

declare double @js_webassembly_instantiate(double, double)

declare double @js_wasi_emit_warning()

declare double @js_webassembly_call_export_0(double, double)

declare double @js_webassembly_call_export_1(double, double, double)

declare double @js_webassembly_call_export_2(double, double, double, double)

declare double @js_webassembly_call_export_3(double, double, double, double, double)

declare double @js_webassembly_call_export_4(double, double, double, double, double, double)

declare void @js_console_log_spread(i64)

declare void @js_console_info_spread(i64)

declare void @js_console_debug_spread(i64)

declare void @js_console_error_spread(i64)

declare void @js_console_warn_spread(i64)

declare double @js_util_format(i64)

declare double @js_util_format_with_options(double, i64)

declare double @js_util_inspect(double, double)

declare double @js_util_debuglog(double, double)

declare double @js_util_diff(double, double)

declare double @js_util_inherits(double, double)

declare double @js_util_is_deep_strict_equal(double, double)

declare double @js_util_strip_vt_control_characters(double)

declare double @js_util_style_text(double, double, double)

declare double @js_util_get_call_sites(double, double)

declare double @js_util_promisify(double)

declare double @js_util_callbackify(double)

declare double @js_util_deprecate(double, double, double)

declare double @js_util_aborted(double, double)

declare double @js_util_transferable_abort_controller()

declare double @js_util_transferable_abort_signal(double)

declare double @js_util_parse_args(double)

declare double @js_boxed_number_new(double)

declare double @js_boxed_string_new(double, i32)

declare double @js_boxed_boolean_new(double)

declare double @js_util_types_is_arguments_object(double)

declare double @js_util_types_is_promise(double)

declare double @js_util_types_is_big_int_object(double)

declare double @js_util_types_is_symbol_object(double)

declare double @js_util_types_is_array_buffer(double)

declare double @js_util_types_is_shared_array_buffer(double)

declare double @js_util_types_is_any_array_buffer(double)

declare double @js_util_types_is_array_buffer_view(double)

declare double @js_util_types_is_data_view(double)

declare double @js_util_types_is_typed_array(double)

declare double @js_util_types_is_uint8_array(double)

declare double @js_util_types_is_int8_array(double)

declare double @js_util_types_is_int16_array(double)

declare double @js_util_types_is_uint16_array(double)

declare double @js_util_types_is_int32_array(double)

declare double @js_util_types_is_uint32_array(double)

declare double @js_util_types_is_float16_array(double)

declare double @js_util_types_is_float32_array(double)

declare double @js_util_types_is_float64_array(double)

declare double @js_util_types_is_uint8_clamped_array(double)

declare double @js_util_types_is_big_int64_array(double)

declare double @js_util_types_is_big_uint64_array(double)

declare double @js_util_types_is_map(double)

declare double @js_util_types_is_weak_map(double)

declare double @js_util_types_is_set(double)

declare double @js_util_types_is_weak_set(double)

declare double @js_util_types_is_date(double)

declare double @js_util_types_is_reg_exp(double)

declare double @js_util_types_is_async_function(double)

declare double @js_util_types_is_generator_function(double)

declare double @js_util_types_is_generator_object(double)

declare double @js_util_types_is_native_error(double)

declare double @js_util_types_is_number_object(double)

declare double @js_util_types_is_string_object(double)

declare double @js_util_types_is_boolean_object(double)

declare double @js_util_types_is_boxed_primitive(double)

declare double @js_util_types_is_external(double)

declare double @js_util_types_is_module_namespace_object(double)

declare double @js_util_types_is_key_object(double)

declare double @js_util_types_is_crypto_key(double)

declare double @js_util_types_is_proxy(double)

declare double @js_util_types_is_map_iterator(double)

declare double @js_util_types_is_set_iterator(double)

declare double @js_data_view_new(double, double, double)

declare double @js_data_view_get_direct(double, double, double, i32, i32)

declare double @js_data_view_set_direct(double, double, double, double, i32, i32)

declare i64 @js_getenv(i64)

declare double @js_getenv_value(i64)

declare void @js_setenv(i64, double)

declare void @js_removeenv(i64)

declare double @js_process_exit_code_get()

declare double @js_process_exit_code_set(double)

declare void @js_console_table(double)

declare void @js_console_table_with_properties(double, double)

declare void @js_console_trace(double)

declare void @js_console_trace_spread(i64)

declare i64 @js_process_cwd()

declare i64 @js_process_argv()

declare double @js_process_pid()

declare double @js_process_ppid()

declare double @js_process_uptime()

declare i64 @js_process_version()

declare double @js_process_versions()

declare double @js_process_memory_usage()

declare double @js_bigint_as_int_n_call(double, double)

declare double @js_bigint_as_uint_n_call(double, double)

declare double @js_v8_serialize(double)

declare double @js_v8_deserialize(double)

declare double @js_v8_get_heap_statistics()

declare double @js_v8_get_heap_code_statistics()

declare double @js_v8_get_heap_space_statistics()

declare double @js_v8_cached_data_version_tag()

declare double @js_v8_get_heap_snapshot(double)

declare double @js_v8_write_heap_snapshot(double, double)

declare double @js_v8_gc_profiler_new()

declare double @js_v8_gc_profiler_start(double)

declare double @js_v8_gc_profiler_stop(double)

declare double @js_v8_gc_profiler_report()

declare double @js_v8_serializer_new(double)

declare double @js_v8_deserializer_new(double)

declare double @js_v8_noop_undefined()

declare double @js_v8_is_building_snapshot()

declare double @js_v8_namespace(ptr, i64)

declare double @js_v8_throw_not_building_snapshot()

declare double @js_v8_promise_hook_register()

declare double @js_v8_promise_hooks_on_init(double)

declare double @js_v8_promise_hooks_on_before(double)

declare double @js_v8_promise_hooks_on_after(double)

declare double @js_v8_promise_hooks_on_settled(double)

declare double @js_v8_promise_hooks_create_hook(double)

declare double @js_process_thread_cpu_usage(double)

declare double @js_process_available_memory()

declare double @js_process_constrained_memory()

declare double @js_process_source_maps_enabled()

declare double @js_process_set_source_maps_enabled(double)

declare double @js_process_has_uncaught_exception_capture_callback()

declare double @js_process_set_uncaught_exception_capture_callback(double)

declare double @js_process_add_uncaught_exception_capture_callback(double)

declare double @js_process_getuid()

declare double @js_process_geteuid()

declare double @js_process_getgid()

declare double @js_process_getegid()

declare void @js_process_emit_warning(double, double, double)

declare double @js_process_cpu_usage(double)

declare double @js_process_resource_usage()

declare double @js_process_active_resources_info()

declare double @js_process_env()

declare double @js_process_hrtime_bigint()

declare double @js_process_hrtime(double)

declare double @js_process_title()

declare void @js_process_set_title(double)

declare void @js_process_chdir(i64)

declare void @js_process_chdir_jsv(double)

declare double @js_process_kill(double, double)

declare void @js_process_exit(double)

declare void @js_process_abort()

declare double @js_process_umask()

declare double @js_process_umask_set(double)

declare double @js_process_on(i64, i64)

declare double @js_process_add_listener(i64, i64)

declare double @js_process_once(i64, i64)

declare double @js_process_prepend_listener(i64, i64)

declare double @js_process_prepend_once_listener(i64, i64)

declare double @js_process_emit(i64, i64)

declare void @js_process_emit_before_exit(double)

declare void @js_process_emit_before_exit_pending()

declare void @js_process_run_exit_sequence()

declare void @js_process_run_finalization_exit()

declare void @js_trace_events_flush_output()

declare void @js_promise_report_unhandled_rejections()

declare i32 @js_process_pending_exit_code()

declare void @js_gc_release_current_thread_collection_side_allocations()

declare double @js_process_remove_listener(i64, i64)

declare double @js_process_off(i64, i64)

declare double @js_process_remove_all_listeners(i64)

declare double @js_process_listener_count(i64, i64)

declare i64 @js_process_listeners(i64)

declare i64 @js_process_raw_listeners(i64)

declare i64 @js_process_event_names()

declare double @js_process_set_max_listeners(double)

declare double @js_process_get_max_listeners()

declare double @js_process_get_builtin_module(double)

declare double @js_process_get_builtin_module_devirt(double)

declare double @js_process_execve(double, double, double)

declare double @js_module_is_builtin(double)

declare double @js_module_find_package_json(double, double, double)

declare double @js_module_find_source_map(double)

declare double @js_module_source_map_new(double, double)

declare double @js_module_register(double, double, double)

declare double @js_module_register_hooks(double)

declare void @js_process_next_tick(i64, i64)

declare double @js_process_stdin()

declare double @js_process_stdout()

declare double @js_process_stderr()

declare double @js_readline_set_raw_mode(double)

declare void @js_readline_stdin_on(i64, i64)

declare double @js_readline_stdin_remove_listener(i64, i64)

declare double @js_readline_stdin_pause()

declare double @js_readline_stdin_resume()

declare double @js_readline_stdin_unref()

declare double @js_readline_stdin_ref()

declare double @js_readline_stdin_destroy()

declare double @js_tty_isatty(double)

declare double @js_tty_read_stream_new(double)

declare double @js_tty_write_stream_new(double)

declare double @js_wasi_constructor_call(double)

declare double @js_process_stdin_isatty()

declare double @js_process_stdout_isatty()

declare double @js_process_stderr_isatty()

declare double @js_process_stdout_columns()

declare double @js_process_stdout_rows()

declare double @js_process_stdout_on(i64, i64)

declare i64 @js_os_platform()

declare i64 @js_os_arch()

declare i64 @js_os_type()

declare i64 @js_os_release()

declare i64 @js_os_hostname()

declare i64 @js_os_eol()

declare double @js_os_available_parallelism()

declare i64 @js_os_endianness()

declare i64 @js_os_dev_null()

declare i64 @js_os_machine()

declare i64 @js_os_loadavg()

declare i64 @js_os_version()

declare i64 @js_box_alloc_bits(i64)

declare i64 @js_box_get_bits(i64)

declare i64 @js_box_get_bits_named(i64, double)

declare void @js_box_set_bits(i64, i64)

declare i64 @js_box_get_bits_trusted(i64)

declare i64 @js_box_get_bits_trusted_named(i64, double)

declare void @js_box_set_bits_trusted_no_barrier(i64, i64)

declare i64 @js_box_alloc(double)

declare double @js_box_get(i64)

declare void @js_box_set(i64, double)

declare i64 @js_i32_box_alloc(i32)

declare i32 @js_i32_box_get(i64)

declare void @js_i32_box_set(i64, i32)

declare void @js_box_release(i64)

declare void @js_i32_box_release(i64)

declare void @js_bool_box_release(i64)

declare i64 @js_bool_box_alloc(i32)

declare i32 @js_bool_box_get(i64)

declare void @js_bool_box_set(i64, i32)

declare i64 @js_arguments_object_alloc(double, double, i32)

declare void @js_arguments_object_map_index(i64, i32, i64)

declare i64 @js_array_like_to_array(double)

declare i32 @js_object_get_class_id(i64)

declare i64 @js_object_alloc_with_parent(i32, i32, i32)

declare i64 @js_object_alloc_class_with_keys(i32, i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_dynamic_parent(i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_inline_keys(i32, i32, i32, i64)

declare i64 @js_object_alloc_class_inline_keys_stamped(i32, i32, i32, i64, i32)

declare i64 @js_build_class_keys_array(i32, i32, ptr, i32)

declare i32 @js_object_shape_id_for_keys(i64, i32)

declare i32 @js_gc_typed_shape_id_for_keys(i32, i64, i32, ptr, i32, ptr, i32)

declare ptr @js_inline_arena_state()

declare ptr @js_inline_arena_slow_alloc(ptr, i64, i64)

declare i32 @js_object_delete_field(i64, i64)

declare i32 @js_object_delete_field_value(double, i64)

declare i32 @js_object_delete_dynamic_value(double, double)

declare double @js_delete_result(i32, i32)

declare i64 @js_eq(i64, i64)

declare i64 @js_loose_eq(i64, i64)

declare i64 @js_number_to_fixed(double, double)

declare i64 @js_string_replace_regex(i64, i64, i64)

declare i64 @js_string_replace_all_regex(i64, i64, i64)

declare double @js_array_at(i64, double)

declare double @js_date_get_time(double)

declare double @js_date_get_full_year(double)

declare double @js_date_get_month(double)

declare double @js_date_get_date(double)

declare double @js_date_get_day(double)

declare double @js_date_get_hours(double)

declare double @js_date_get_minutes(double)

declare double @js_date_get_seconds(double)

declare double @js_date_get_milliseconds(double)

declare double @js_date_get_utc_day(double)

declare double @js_date_get_utc_full_year(double)

declare double @js_date_get_utc_month(double)

declare double @js_date_get_utc_date(double)

declare double @js_date_get_utc_hours(double)

declare double @js_date_get_utc_minutes(double)

declare double @js_date_get_utc_seconds(double)

declare double @js_date_get_utc_milliseconds(double)

declare double @js_date_value_of(double)

declare double @js_date_get_timezone_offset(double)

declare double @js_date_coerce_number(double)

declare double @js_rel_lt(double, double)

declare double @js_rel_le(double, double)

declare double @js_rel_gt(double, double)

declare double @js_rel_ge(double, double)

declare i64 @js_date_to_string(double)

declare i64 @js_date_to_iso_string(double)

declare i64 @js_date_to_iso_string_or_throw(double)

declare double @js_date_new_from_timestamp(double)

declare double @js_date_new_from_value(double)

declare i32 @js_array_indexOf_f64(i64, double)

declare i64 @js_array_indexOf_jsvalue(i64, double, double, i32)

declare i64 @js_array_last_index_of_jsvalue(i64, double, double, i32)

declare i32 @js_array_includes_f64(i64, double)

declare i32 @js_array_includes_jsvalue(i64, double, double, i32)

declare i32 @js_map_size(i64)

declare void @js_map_clear(i64)

declare void @js_set_clear(i64)

declare i64 @js_map_entries(i64)

declare i64 @js_map_keys(i64)

declare i64 @js_map_values(i64)

declare double @js_map_entry_key_at(i64, i32)

declare double @js_map_entry_value_at(i64, i32)

declare double @js_map_entry_key_raw_at(i64, i32)

declare double @js_map_entry_value_raw_at(i64, i32)

declare double @js_set_value_raw_at(i64, i32)

declare double @js_map_find_key_index(double, double)

declare double @js_set_find_value_index(double, double)

declare double @js_map_cursor_next(double, double, double)

declare double @js_map_compaction_epoch(double)

declare double @js_set_cursor_next(double, double, double)

declare double @js_set_compaction_epoch(double)

declare void @js_map_foreach(i64, double, double)

declare void @js_set_foreach(i64, double, double)

declare i64 @js_map_entries_iter_obj(i64)

declare i64 @js_map_keys_iter_obj(i64)

declare i64 @js_map_values_iter_obj(i64)

declare i64 @js_set_values_iter_obj(i64)

declare i64 @js_set_keys_iter_obj(i64)

declare i64 @js_set_entries_iter_obj(i64)

declare i64 @js_set_to_array(i64)

declare double @js_set_value_at(i64, i32)

declare i64 @js_array_splice(i64, i32, i32, ptr, i32, ptr)

declare i32 @js_array_splice_delete_count(double)

declare double @js_parse_int(i64, double)

declare double @js_parse_float(i64)

declare double @js_array_reduce(i64, i64, i32, double)

declare double @js_array_reduce_right(i64, i64, i32, double)

declare i64 @js_array_sort_default(i64)

declare i64 @js_array_reverse(i64)

declare double @js_array_reverse_value(double)

declare i64 @js_array_flat(i64)

declare i64 @js_array_flat_depth(i64, double)

declare i64 @js_array_flatMap(i64, i64)

declare i64 @js_array_sort_with_comparator(i64, i64)

declare i64 @js_validate_array_comparator(double)

declare i64 @js_validate_array_callback(double)

declare i64 @js_validate_array_map_callback(i64, double)

declare i64 @js_array_to_reversed(i64)

declare i64 @js_array_to_sorted_default(i64)

declare i64 @js_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_array_to_spliced(i64, double, double, ptr, i32)

declare i64 @js_array_with(i64, double, double)

declare i64 @js_array_copy_within(i64, double, double, i32, double)

declare double @js_array_copy_within_value(double, double, double, i32, double)

declare i64 @js_regexp_new(i64, i64)

declare i64 @js_regexp_new_site(i64, i64, i64)

declare i64 @js_regexp_new_factory_site(i64, i64, i64, i64)

declare i64 @js_regexp_site_test_new(i64, i64, i64)

declare double @js_regexp_site_factory_call_value(i64, double)

declare double @js_regexp_site_factory_call_method(i64, double, double)

declare double @js_regexp_site_test_get_method(i64, double)

declare double @js_regexp_site_test_dispatch(i64, double, double, double)

declare i64 @js_regexp_construct(double, double)

declare i64 @js_regexp_construct_call(double, double)

declare i32 @js_regexp_test(i64, i64)

declare double @js_regexp_escape(double)

declare i64 @js_get_string_pointer_unified(double)

declare i32 @js_switch_strict_equals(double, double)

declare i64 @js_value_to_str_ptr_for_ffi(double)

declare void @js_string_addref(i64)

declare void @js_string_addref_if_heap_string(double)

declare i64 @js_bigint_from_string(ptr, i32)

declare i64 @js_bigint_from_f64(double)

declare i64 @js_bigint_from_i128_parts(i64, i64)

declare i32 @js_bigint_cmp(i64, i64)

declare double @js_dynamic_add(double, double)

declare double @js_to_numeric(double)

declare double @js_numeric_step(double, i32)

declare i64 @js_box_capture_cell_ptr(i64)

declare double @js_dynamic_string_or_number_add(double, double)

declare double @js_dynamic_sub(double, double)

declare double @js_dynamic_mul(double, double)

declare double @js_dynamic_div(double, double)

declare double @js_dynamic_mod(double, double)

declare double @js_dynamic_bitand(double, double)

declare double @js_dynamic_bitor(double, double)

declare double @js_dynamic_bitxor(double, double)

declare double @js_dynamic_shl(double, double)

declare double @js_dynamic_shr(double, double)

declare double @js_dynamic_bitnot(double)

declare double @js_dynamic_pow(double, double)

declare double @js_dynamic_ushr(double, double)

declare double @js_instanceof(double, i32)

declare double @js_instanceof_dynamic(double, double)

declare double @js_instanceof_noncallable_rhs()

declare void @js_register_class_extends_error(i32)

declare void @js_register_class_extends_data_view(i32)

declare void @js_register_class_extends_typed_array(i32)

declare void @js_register_class_id(i32)

declare void @js_register_class_name(i32, ptr, i32)

declare void @js_register_class_source(i32, ptr, i32)

declare void @js_register_class_length(i32, i32)

declare void @js_register_anon_shape_class_id(i32)

declare double @js_get_global_this_builtin_value(ptr, i64)

declare double @js_promise_static_function_value(ptr, i64)

declare double @js_builtin_prototype_method_value(ptr, i64, ptr, i64)

declare void @js_register_class_parent(i32, i32)

declare void @js_register_class_generic_origin(i32, i32)

declare void @js_register_class_parent_dynamic(i32, double)

declare double @js_get_dynamic_parent_value(i32)

declare void @js_class_register_capture_values(i32, ptr, i64)

declare void @js_class_object_refresh_capture_values(double, i64, double)

declare void @js_tdz_suppress_begin()

declare void @js_tdz_suppress_end()

declare double @js_class_capture_value(i32, i32)

declare double @js_class_capture_value_for_receiver(double, i32, i32)

declare double @js_class_capture_value_or(i32, i32, double)

declare double @js_param_or_class_capture_value(double, i32, i32)

declare void @js_super_construct_apply(i32, double, double)

declare double @js_super_method_call_dynamic(i32, ptr, i64, double, ptr, i64)

declare double @js_super_method_call_dynamic_apply(i32, ptr, i64, double, double)

declare i64 @js_array_push_spread_any(i64, double)

declare i32 @js_set_function_prototype(double, double)

declare double @js_set_prototype_property(double, double, i32)

declare void @js_register_prototype_method(i32, ptr, i64, double)

declare i32 @js_register_function_prototype_method(double, ptr, i64, double)

declare double @js_new_function_construct(double, ptr, i64)

declare double @js_function_ctor_from_strings(ptr, i64)

declare double @js_new_function_construct_apply(double, double)

declare double @js_throw_not_a_constructor()

declare double @js_new_target_value()

declare double @js_get_function_prototype_method(double, ptr, i64)

declare double @js_function_prototype_value_for_read(double)

declare i64 @js_typeerror_new(i64)

declare i64 @js_rangeerror_new(i64)

declare i64 @js_syntaxerror_new(i64)

declare i64 @js_referenceerror_new(i64)

declare double @js_throw_symbol_constructor_type_error()

declare double @js_throw_bigint_constructor_type_error()

declare double @js_throw_strict_eval_arguments_syntax_error()

declare double @js_throw_eval_syntax_error(double)

declare double @js_throw_restricted_function_property_assignment()

declare double @js_throw_math_constructor_type_error()

declare double @js_throw_json_constructor_type_error()

declare double @js_webcrypto_illegal_constructor()

declare double @js_throw_type_error_const_assignment(double)

declare double @js_throw_reference_error_unresolvable_assignment(double)

declare double @js_throw_reference_error_unresolved_get()

declare double @js_with_implicit_unset()

declare double @js_with_implicit_read(double, double)

declare double @js_iterator_result_validate(double)

declare double @js_for_of_next(double)

declare double @js_segments_view_open(double, double)

declare double @js_segments_view_next(double)

declare double @js_segments_view_code_point_at(double, double)

declare double @js_segments_view_segment(double)

declare double @js_segments_view_regexp_test(double, double)

declare double @js_global_get_or_throw_unresolved(double)

declare double @js_module_ambient_require()

declare double @js_module_ambient_require_apply(double)

declare double @js_module_dynamic_import_fallback(double)

declare double @js_module_dynamic_import_deferred(double, double)

declare double @js_module_create_require_devirt(double)

declare double @js_global_get_optional(double)

declare double @js_global_update(double, double, double)

declare double @js_global_assign_existing_or_throw(double, double)

declare double @js_throw_reference_error_this_before_super()

declare double @js_throw_reference_error_super_delete()

declare double @js_throw_reference_error_unresolved_assignment()

declare i64 @js_evalerror_new(i64)

declare i64 @js_urierror_new(i64)

declare i64 @js_weakmap_new()

declare i64 @js_weakset_new()

declare double @js_weakmap_init_iterable(double, double)

declare double @js_weakset_init_iterable(double, double)

declare double @js_weakmap_set(double, double, double)

declare double @js_weakmap_get(double, double)

declare double @js_weakmap_has(double, double)

declare double @js_weakmap_delete(double, double)

declare double @js_weakset_add(double, double)

declare double @js_weakset_has(double, double)

declare double @js_weakset_delete(double, double)

declare double @js_weak_throw_primitive()

declare i64 @js_buffer_from_string(i64, i32)

declare i32 @js_encoding_tag_from_value(double)

declare i64 @js_value_to_string_with_encoding(double, i32)

declare i64 @js_value_to_string_with_encoding_or_radix(double, i32, double)

declare i64 @js_object_values(i64)

declare i64 @js_object_values_value(double)

declare i64 @js_object_entries(i64)

declare i64 @js_object_entries_value(double)

declare i64 @js_path_join(i64, i64)

declare i64 @js_path_win32_join(i64, i64)

declare i64 @js_path_win32_dirname(i64)

declare i64 @js_path_win32_basename(i64)

declare i64 @js_path_win32_basename_ext(i64, i64)

declare i64 @js_path_win32_extname(i64)

declare i32 @js_path_win32_is_absolute(i64)

declare i64 @js_path_win32_normalize(i64)

declare i64 @js_path_win32_parse(i64)

declare i64 @js_path_win32_format(double)

declare i64 @js_path_win32_relative(i64, i64)

declare i64 @js_path_win32_relative_checked(double, double)

declare i64 @js_path_win32_resolve(i64)

declare i64 @js_path_win32_resolve_join(i64, i64)

declare i64 @js_path_win32_to_namespaced_path(i64)

declare double @js_path_win32_to_namespaced_path_value(double)

declare i32 @js_path_win32_matches_glob(i64, i64)

declare i64 @js_path_win32_sep_get()

declare i64 @js_path_win32_delimiter_get()

declare i64 @js_path_dirname(i64)

declare i64 @js_path_resolve(i64)

declare i64 @js_path_relative(i64, i64)

declare i64 @js_path_relative_checked(double, double)

declare i64 @js_path_to_namespaced_path(i64)

declare double @js_path_to_namespaced_path_value(double)

declare i32 @js_path_matches_glob(i64, i64)

declare i64 @js_path_resolve_join(i64, i64)

declare i64 @js_path_arg_header(double)

declare i64 @js_path_join_value(double, double)

declare i64 @js_path_win32_join_value(double, double)

declare i64 @js_path_resolve_join_value(double, double)

declare i64 @js_path_win32_resolve_join_value(double, double)

declare i64 @js_path_basename_ext_value(double, double)

declare i64 @js_path_win32_basename_ext_value(double, double)

declare i32 @js_path_matches_glob_value(double, double)

declare i32 @js_path_win32_matches_glob_value(double, double)

declare double @js_object_from_entries(double)

declare i64 @js_string_match(i64, i64)

declare i64 @js_string_match_all(i64, i64)

declare i64 @js_string_match_all_value(i64, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log2.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log10.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.exp.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sin.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.cos.f64(double) #1

declare i64 @js_path_basename(i64)

declare i64 @js_path_basename_ext(i64, i64)

declare i64 @js_path_extname(i64)

declare i64 @js_path_sep_get()

declare i64 @js_path_delimiter_get()

declare i64 @js_path_parse(i64)

declare i64 @js_json_parse(i64)

declare i64 @js_json_text_to_string(double)

declare double @js_json_raw_json(double)

declare double @js_json_is_raw_json(double)

declare i64 @js_json_parse_or_null(i64)

declare i64 @js_json_parse_typed_array(i64, i64, i32, i32)

declare i64 @js_date_to_date_string(double)

declare i64 @js_date_to_time_string(double)

declare i64 @js_date_to_utc_string(double)

declare i64 @js_date_to_locale_date_string(double)

declare i64 @js_date_to_locale_time_string(double)

declare i64 @js_date_to_json(double)

declare i64 @js_regexp_exec(i64, i64)

declare i64 @js_number_to_precision(double, double)

declare i64 @js_number_to_exponential(double, double)

declare double @js_date_new()

declare double @js_number_is_integer(double)

declare double @js_number_is_nan(double)

declare double @js_number_is_safe_integer(double)

declare double @js_date_parse(i64)

declare double @js_date_utc(ptr, i32)

declare double @js_date_new_local_components(double, double, double, double, double, double, double)

declare double @js_date_apply_setter(double, i32, i32, ptr, i32)

declare double @js_math_clz32(double)

declare double @js_math_cbrt(double)

declare double @js_math_fround(double)

declare double @js_math_f16round(double)

declare double @js_math_sinh(double)

declare double @js_math_cosh(double)

declare double @js_math_tanh(double)

declare double @js_math_asinh(double)

declare double @js_math_acosh(double)

declare double @js_math_atanh(double)

declare double @js_math_hypot(double, double)

declare double @js_object_is(double, double)

declare i64 @js_path_normalize(i64)

declare i64 @js_path_format(double)

declare i32 @js_path_is_absolute(i64)

declare i64 @js_encode_uri(double)

declare i64 @js_decode_uri(double)

declare i64 @js_encode_uri_component(double)

declare i64 @js_decode_uri_component(double)

declare i64 @js_text_encoder_new()

declare i64 @js_text_decoder_new(double, double, double)

declare i64 @js_text_encoder_encode_llvm(double)

declare i64 @js_text_decoder_decode_llvm(double, double)

declare i64 @js_text_decoder_encoding(double)

declare double @js_text_decoder_fatal(double)

declare double @js_text_decoder_ignore_bom(double)

declare void @js_queue_microtask(i64)

declare void @js_queue_next_tick(i64)

declare void @js_queue_next_tick_args(i64, ptr, i32)

declare void @js_drain_queued_microtasks()

declare i64 @js_uint8array_from_array(i64)

declare i64 @js_uint8array_alloc(i32)

declare i64 @js_uint8array_new(double)

declare i64 @js_uint8array_view(double, double, double)

declare i64 @js_typed_array_new_empty(i32, i32)

declare i64 @js_typed_array_new_from_array(i32, i64)

declare i64 @js_typed_array_new(i32, double)

declare i64 @js_typed_array_view(i32, double, double, double)

declare i32 @js_typed_array_length(i64)

declare double @js_typed_array_get(i64, i32)

declare i32 @js_typed_array_read_int32(i64, i32)

declare double @js_typed_array_read_f64(i64, i32)

declare double @js_u8_buffer_read_f64(i64, i32)

declare double @js_typed_array_index_get_dynamic(i64, double)

declare double @js_typed_array_at(i64, double)

declare void @js_typed_array_set(i64, i32, double)

declare double @js_typed_array_index_set_dynamic(i64, double, double)

declare i32 @js_uint8array_get(i64, i32)

declare double @js_uint8array_index_get_value(i64, i32)

declare void @js_uint8array_set(i64, i32, i32)

declare i64 @js_native_arena_alloc(i64)

declare i64 @js_native_arena_view(i64, i32, i64, i64)

declare i64 @js_native_pod_view(i64, i64, i64, i64, i64, i64)

declare double @js_native_pod_view_length(double)

declare ptr @js_native_abi_check_pod_view_data_ptr(double, i64)

declare i64 @js_native_abi_check_pod_view_record_count(double, i64)

declare void @js_native_arena_dispose(i64)

declare void @js_native_memory_fill_u32(i64, double)

declare void @js_native_memory_copy(i64, i64)

declare i64 @js_typed_array_to_reversed(i64)

declare i64 @js_typed_array_to_sorted_default(i64)

declare i64 @js_typed_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_typed_array_with(i64, double, double)

declare double @js_typed_array_find_last(i64, i64)

declare double @js_typed_array_find_last_index(i64, i64)

declare double @js_typed_array_set_from(i64, double, double)

declare i64 @js_typed_array_subarray(i64, i32, double, i32, double)

declare double @js_object_has_own(double, double)

declare double @js_object_property_is_enumerable(double, double)

declare double @js_object_define_getter(double, double, double)

declare double @js_object_define_setter(double, double, double)

declare double @js_object_lookup_getter(double, double)

declare double @js_object_lookup_setter(double, double)

declare double @js_object_get_own_field_or_undef(double, ptr, i64)

declare double @js_unresolved_namespace_stub()

declare double @js_node_submodule_export_as_function(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace_member(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace(ptr, i32)

declare void @js_node_submod_install_vm()

declare void @js_node_submod_install_timers()

declare void @js_node_submod_install_timers_promises()

declare void @js_node_submod_install_fs_promises()

declare void @js_node_submod_install_readline_promises()

declare void @js_node_submod_install_stream_promises()

declare void @js_node_submod_install_stream_consumers()

declare void @js_node_submod_install_stream_web()

declare void @js_node_submod_install_hono_jsx_server()

declare void @js_node_submod_install_hono_jsx_streaming()

declare void @js_node_submod_install_sys()

declare void @js_node_submod_install_diagnostics_channel()

declare void @js_node_submod_install_trace_events()

declare void @js_node_submod_install_test()

declare void @js_node_submod_install_test_reporters()

declare void @js_node_submod_install_all()

declare void @js_node_submod_enable_install_all()

declare double @js_unresolved_default_call()

declare double @js_get_global_this()

declare double @js_module_top_this()

declare double @js_global_or_console_property_by_name(i64)

declare void @js_class_register_static_symbol(i32, double, double)

declare void @js_register_class_computed_method(i64, double, i64, i64, i64, i64, i64)

declare void @js_register_class_computed_accessor(i64, double, i64, i64, i64, i64)

declare void @js_class_register_static_field(i32, ptr, i64, double, ptr)

declare double @js_object_define_property(double, double, double)

declare double @js_object_define_get_accessor(double, double, double)

declare double @js_object_get_own_property_descriptor(double, double)

declare double @js_object_get_own_property_descriptors(double)

declare double @js_object_get_own_property_names(double)

declare double @js_symbol_new(double)

declare double @js_symbol_new_empty()

declare double @js_symbol_for(double)

declare double @js_symbol_computed_member(double, double)

declare double @js_symbol_key_for(double)

declare double @js_symbol_description(double)

declare i64 @js_symbol_to_string(double)

declare i32 @js_symbol_equals(double, double)

declare i32 @js_is_symbol(double)

declare i64 @js_object_get_own_property_symbols(double)

declare double @js_object_set_symbol_property(double, double, double)

declare double @js_to_property_key(double)

declare double @js_object_set_property_key(double, double, double)

declare double @js_object_get_property_key(double, double)

declare double @js_object_set_property_key_method(double, double, double)

declare double @js_object_super_get(double, double, double)

declare double @js_object_super_put_value_set(double, double, double, double, i32)

declare double @js_object_super_call(double, double, double, ptr, i64)

declare double @js_object_literal_infer_computed_function_name(double, double)

declare double @js_object_get_symbol_property(double, double)

declare double @js_object_get_symbol_property_ic_miss(double, double, ptr)

declare double @js_object_get_symbol_then_field_ic_miss(double, double, ptr, i64, ptr, ptr)

declare double @js_object_create(double)

declare double @js_object_create_with_props(double, double)

declare double @js_object_freeze(double)

declare double @js_object_seal(double)

declare double @js_object_prevent_extensions(double)

declare void @js_object_copy_own_fields(i64, double)

declare double @js_object_assign_validate_target(double)

declare double @js_object_assign_one(double, double)

declare double @js_string_at(i64, i32)

declare double @js_string_code_point_at(i64, i32)

declare i64 @js_string_from_code_point(double)

declare i64 @js_string_raw(double, double)

declare i64 @js_string_from_char_code(double)

declare i64 @js_string_from_char_code_array(double)

declare double @js_string_char_code_at(i64, i32)

declare i32 @js_string_last_index_of(i64, i64)

declare i32 @js_string_last_index_of_from(i64, i64, double, i32)

declare double @js_string_locale_compare(i64, i64)

declare double @js_string_locale_compare_opts(i64, i64, double)

declare i64 @js_string_normalize(i64, double)

declare i64 @js_string_pad_start(i64, double, i64)

declare i64 @js_string_pad_end(i64, double, i64)

declare i64 @js_string_pad_fill(double)

declare double @js_string_is_well_formed(i64)

declare i64 @js_string_to_well_formed(i64)

declare i32 @js_string_search_regex(i64, i64)

declare i32 @js_string_search_value(i64, double)

declare i64 @js_string_match_value(i64, double)

declare double @js_regexp_exec_get_index()

declare i64 @js_regexp_exec_get_groups()

declare double @js_regexp_get_last_index(i64)

declare void @js_regexp_set_last_index(i64, double)

declare i64 @js_regexp_get_source(i64)

declare i64 @js_regexp_get_flags(i64)

declare i64 @js_string_replace_regex_named(i64, i64, i64)

declare i64 @js_string_replace_all_regex_named(i64, i64, i64)

declare i64 @js_string_replace_string_fn(i64, i64, double)

declare i64 @js_string_replace_string_dyn(i64, i64, double)

declare i64 @js_string_replace_all_string_dyn(i64, i64, double)

declare i64 @js_string_replace_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_all_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_string_fn(i64, i64, double)

declare i64 @js_string_replace_regex_fn(i64, i64, double)

declare i64 @js_string_replace_all_regex_fn(i64, i64, double)

declare double @js_structured_clone(double)

declare double @js_structured_clone_with_options(double, double)

declare double @js_generator_attach_prototype(double, i32)

declare double @js_generator_attach_closure_prototype(double, i64)

declare i64 @js_weakref_new(double)

declare double @js_weakref_deref(double)

declare i64 @js_finreg_new(double)

declare double @js_finreg_register(double, double, double, double)

declare double @js_finreg_unregister(double, double)

declare i64 @js_atob(double)

declare i64 @js_btoa(double)

declare double @js_object_is_frozen(double)

declare double @js_object_is_sealed(double)

declare double @js_object_is_extensible(double)

declare i64 @js_aggregateerror_new(i64, i64)

declare i64 @js_error_new_with_cause(i64, double)

declare i64 @js_aggregateerror_new_full(double, i64, double)

declare i64 @js_error_new_kind_with_options(i32, i64, double)

declare double @js_error_is_error(double)

declare i64 @js_error_get_errors(i64)

declare i64 @js_crypto_sha256(i64)

declare i64 @js_crypto_sha256_bytes(i64)

declare i64 @js_crypto_md5(i64)

declare i64 @js_crypto_hmac_sha256(i64, i64)

declare i64 @js_crypto_hmac_sha256_bytes(i64, i64)

declare void @js_runtime_validate_string_arg(double, ptr, i32)

declare void @js_set_call_location(ptr, i64, i32)

declare void @js_runtime_validate_crypto_key_arg(double, ptr, i32)

declare void @js_runtime_validate_integer_arg(double, ptr, i32, double, double)

declare i64 @js_crypto_pbkdf2_bytes(i64, i64, double, double, i64)

declare double @js_crypto_pbkdf2_async_alg(i64, i64, double, double, i64, double)

declare i64 @js_crypto_argon2_sync(i64, double)

declare double @js_crypto_argon2_async(i64, double, double)

declare i64 @js_crypto_encapsulate(double)

declare double @js_crypto_encapsulate_async(double, double)

declare i64 @js_crypto_decapsulate(double, double)

declare double @js_crypto_decapsulate_async(double, double, double)

declare i64 @js_crypto_hkdf_bytes_alg(i64, i64, i64, i64, double)

declare double @js_crypto_hkdf_async_alg(i64, i64, i64, i64, double, double)

declare i64 @js_crypto_scrypt_bytes(i64, i64, double, double)

declare double @js_crypto_scrypt_async(i64, i64, double, double, double)

declare i64 @js_crypto_sign_rsa_sha256(i64, i64, double)

declare double @js_crypto_sign_async(i64, i64, double, double)

declare double @js_crypto_verify_rsa_sha256(i64, i64, double, i64)

declare double @js_crypto_verify_async(i64, i64, double, i64, double)

declare i64 @js_crypto_public_encrypt(i64, i64)

declare i64 @js_crypto_private_decrypt(i64, i64)

declare i64 @js_crypto_private_encrypt(i64, i64)

declare i64 @js_crypto_public_decrypt(i64, i64)

declare i64 @js_crypto_create_public_key(i64)

declare i64 @js_crypto_create_private_key_value(double)

declare i64 @js_crypto_create_public_key_value(double)

declare i64 @js_crypto_generate_key_pair_sync_rsa(double)

declare i64 @js_crypto_generate_key_pair_sync_ec_p256(double)

declare i64 @js_crypto_generate_key_pair_sync_ed25519(double)

declare i64 @js_crypto_generate_key_pair_sync_x25519(double)

declare double @js_crypto_generate_key_pair_async(i64, double, double)

declare i64 @js_crypto_diffie_hellman(double)

declare double @js_crypto_get_cipher_info(double, double)

declare i64 @js_crypto_get_curves()

declare i64 @js_crypto_secure_heap_used()

declare i64 @js_crypto_random_bytes_buffer(double)

declare double @js_crypto_random_bytes_async(double, double)

declare i64 @js_crypto_random_uuid(double)

declare i64 @js_crypto_random_uuidv7()

declare double @js_crypto_random_int(double, double)

declare double @js_crypto_random_int_async(double, double, double)

declare double @js_crypto_timing_safe_equal(double, double)

declare i64 @js_crypto_get_hashes()

declare i64 @js_crypto_get_ciphers()

declare double @js_crypto_generate_prime_sync(double, double)

declare double @js_crypto_generate_prime_async(double, double, double)

declare double @js_crypto_check_prime_sync(double, double)

declare double @js_crypto_check_prime_async(double, double, double)

declare i64 @js_crypto_create_secret_key(i64, i64)

declare i64 @js_crypto_generate_key_sync(i64, double)

declare double @js_crypto_generate_key_async(i64, double, double)

declare i64 @js_webcrypto_digest(double, double)

declare i64 @js_webcrypto_import_key(double, double, double, double, double)

declare i64 @js_webcrypto_export_key(double, double)

declare i64 @js_webcrypto_sign(double, double, double)

declare i64 @js_webcrypto_verify(double, double, double, double)

declare i64 @js_webcrypto_derive_bits(double, double, double)

declare i64 @js_webcrypto_derive_key(double, double, double, double, double)

declare i64 @js_webcrypto_encrypt(double, double, double)

declare i64 @js_webcrypto_decrypt(double, double, double)

declare i64 @js_webcrypto_generate_key(double, double, double)

declare i64 @js_webcrypto_wrap_key(double, double, double, double)

declare i64 @js_webcrypto_unwrap_key(double, double, double, double, double, double, double)

declare i64 @js_zlib_create_brotli_decompress(double)

declare double @js_crypto_random_fill_sync(double, double, double)

declare double @js_crypto_random_fill_async(double, double, double, double)

declare double @js_crypto_create_hash(i64)

declare double @js_crypto_create_hash_options(i64, double)

declare double @js_crypto_x509_new(i64)

declare double @js_crypto_certificate_verify_spkac(double)

declare double @js_crypto_certificate_export_public_key(double)

declare double @js_crypto_certificate_export_challenge(double)

declare double @js_crypto_create_sign(i64)

declare double @js_crypto_create_verify(i64)

declare double @js_crypto_create_ecdh(i64)

declare double @js_crypto_create_diffie_hellman(double, double, double)

declare double @js_crypto_get_diffie_hellman(double)

declare double @js_crypto_ecdh_convert_key(double, double, double, double, double)

declare double @js_crypto_create_hmac(i64, i64)

declare i64 @js_buffer_alloc(i32, i32)

declare i64 @js_buffer_alloc_fill_value(i32, double, i32)

declare i64 @js_array_buffer_new(i32)

declare i64 @js_shared_array_buffer_new(i32)

declare i64 @js_array_buffer_new_value(double)

declare i64 @js_shared_array_buffer_new_value(double)

declare i64 @js_json_stringify_full(double, double, double)

declare i64 @js_json_parse_with_reviver(i64, i64)

declare double @js_array_find(i64, i64)

declare i32 @js_array_findIndex(i64, i64)

declare double @js_array_find_last(i64, i64)

declare i32 @js_array_find_last_index(i64, i64)

declare double @js_array_some(i64, i64)

declare double @js_array_some_captureless(i64, ptr)

declare double @js_array_every(i64, i64)

declare i32 @js_promise_state(i64)

declare double @js_promise_value(i64)

declare double @js_promise_reason(i64)

declare i32 @js_value_is_promise(double)

declare double @js_assimilate_thenable(double)

declare i32 @js_promise_run_microtasks()

declare i32 @js_promise_run_microtasks_event_loop()

declare i32 @js_promise_run_microtasks_await_loop()

declare i32 @js_await_loop_tick_timers()

declare void @js_mark_entry_module_esm()

declare i32 @js_promise_run_promise_jobs()

declare void @js_run_stdlib_pump()

declare void @js_sleep_ms(double)

declare void @js_wait_for_event()

declare i32 @js_event_loop_host_driven()

declare void @js_unsettled_top_level_await_exit()

declare void @js_throw(double)

declare void @js_eh_try_push()

declare i32 @perry_eh_personality(...)

declare void @js_try_end()

declare double @js_get_exception()

declare void @js_clear_exception()

declare i32 @js_has_exception()

declare void @js_enter_finally()

declare void @js_leave_finally()

declare double @js_await_any_promise(double)

declare i64 @js_promise_new()

declare i64 @js_promise_new_with_executor(i64)

declare i32 @js_timer_tick()

declare i32 @js_timer_tick_if_refed()

declare i32 @js_callback_timer_tick()

declare i32 @js_interval_timer_tick()

declare i32 @js_timer_has_pending()

declare i32 @js_callback_timer_has_pending()

declare i32 @js_interval_timer_has_pending()

declare i32 @js_stdlib_has_active_handles()

declare i32 @js_bun_ffi_has_active_threadsafe_callbacks()

declare i32 @js_microtasks_pending()

declare i64 @js_timer_validate_callback(double, i32)

declare i64 @js_set_timeout_callback(i64, double)

declare i64 @js_set_timeout_callback_args(i64, double, ptr, i32)

declare i64 @js_set_immediate_callback(i64)

declare i64 @js_set_immediate_callback_args(i64, ptr, i32)

declare i64 @setInterval(i64, double)

declare i64 @js_set_interval_callback_args(i64, double, ptr, i32)

declare void @clearTimeout(i64)

declare void @clearInterval(i64)

declare void @clearImmediate(i64)

declare void @js_clear_timeout_value(double)

declare void @js_clear_interval_value(double)

declare void @js_clear_immediate_value(double)

declare i64 @js_buffer_from_array(i64)

declare i64 @js_buffer_from_arraybuffer_slice(i64, i32, i32)

declare i32 @js_buffer_length(i64)

declare i32 @js_buffer_get(i64, i32)

declare double @js_buffer_index_get_value(i64, i32)

declare ptr @js_native_buffer_data_ptr(double)

declare i64 @js_native_buffer_byte_len(double)

declare void @js_console_time(i64)

declare void @js_console_time_end(i64)

declare void @js_console_time_log(i64)

declare void @js_console_time_value(double)

declare void @js_console_time_end_value(double)

declare void @js_console_time_log_value(double)

declare void @js_console_time_log_spread(double, i64)

declare void @js_console_count(i64)

declare void @js_console_count_reset(i64)

declare void @js_console_count_value(double)

declare void @js_console_count_reset_value(double)

declare double @js_console_new(double)

declare double @js_console_new2(double, double)

declare void @js_console_group_begin()

declare void @js_console_group_end()

declare void @js_console_clear()

declare void @js_console_noop()

declare double @js_native_call_method(double, ptr, i64, ptr, i64)

declare double @js_native_call_method_by_id(double, i64, ptr, i64)

declare double @js_native_call_method_apply(double, ptr, i64, i64)

declare double @js_native_call_method_apply_by_id(double, i64, i64)

declare double @js_native_call_method_str_key(double, i64, ptr, i64)

declare double @js_native_call_method_value(double, double, ptr, i64)

declare double @js_native_call_method_value_apply(double, double, i64)

declare void @js_promise_resolve(i64, double)

declare void @js_promise_reject(i64, double)

declare void @js_promise_mark_internally_handled(i64)

declare i64 @js_promise_resolved(double)

declare i64 @js_async_fn_result(double)

declare i64 @js_promise_rejected(double)

declare double @js_create_namespace(i32, ptr, ptr, ptr, ptr)

declare double @js_finalize_namespace(double)

declare i64 @js_promise_then(i64, i64, i64)

declare i64 @js_promise_resolved_then(double, i64, i64)

declare i64 @js_promise_finally(i64, i64)

declare double @js_promise_then_checked(double, double, double)

declare double @js_promise_catch_checked(double, double)

declare double @js_promise_finally_checked(double, double)

declare i64 @js_promise_closure_arg(double)

declare i64 @js_promise_all(i64)

declare i64 @js_promise_race(i64)

declare i64 @js_promise_any(i64)

declare i64 @js_promise_all_settled(i64)

declare i64 @js_promise_all_iterable(double)

declare i64 @js_promise_race_iterable(double)

declare i64 @js_promise_any_iterable(double)

declare i64 @js_promise_all_settled_iterable(double)

declare i64 @js_promise_with_resolvers()

declare i64 @js_promise_try(double, i64)

declare i64 @js_array_unshift_f64(i64, double)

declare i64 @js_array_unshift_variadic(i64, ptr, i32)

declare i64 @js_array_entries(i64)

declare i64 @js_array_keys(i64)

declare i64 @js_array_values(i64)

declare i64 @js_array_entries_iter_obj(i64)

declare i64 @js_array_keys_iter_obj(i64)

declare i64 @js_array_values_iter_obj(i64)

declare double @js_response_new(i64, double, i64, double)

declare double @js_fetch_unwrap_handle(double)

declare double @js_response_body_init_reset()

declare i64 @js_response_body_init_ptr(double)

declare double @js_headers_new()

declare double @js_headers_set(double, i64, i64)

declare double @js_headers_append(double, i64, i64)

declare i64 @js_headers_get(double, i64)

declare double @js_headers_get_set_cookie(double)

declare double @js_headers_has(double, i64)

declare double @js_headers_delete(double, i64)

declare double @js_headers_for_each(double, double)

declare double @js_headers_keys(double)

declare double @js_headers_values(double)

declare double @js_headers_entries(double)

declare double @js_headers_init_from_value(double, double)

declare double @js_headers_method_value(double, i64, i64)

declare double @js_request_new(i64, i64, i64, double, i64, i64, i64, i64, i64, i64, i64, double, i64, double)

declare double @js_request_new_from_init(i64, double)

declare i64 @js_request_get_url(double)

declare i64 @js_request_input_to_url(double)

declare i64 @js_request_get_method(double)

declare double @js_request_get_body(double)

declare double @js_request_body_used(double)

declare i64 @js_request_get_destination(double)

declare i64 @js_request_get_referrer(double)

declare i64 @js_request_get_referrer_policy(double)

declare i64 @js_request_get_mode(double)

declare i64 @js_request_get_credentials(double)

declare i64 @js_request_get_cache(double)

declare i64 @js_request_get_redirect(double)

declare i64 @js_request_get_integrity(double)

declare double @js_request_get_keepalive(double)

declare i64 @js_request_get_duplex(double)

declare double @js_request_get_signal(double)

declare double @js_request_get_headers(double)

declare i64 @js_request_text(double)

declare i64 @js_request_json(double)

declare i64 @js_request_array_buffer(double)

declare i64 @js_request_blob(double)

declare i64 @js_request_bytes(double)

declare i64 @js_request_form_data(double)

declare double @js_request_clone(double)

declare double @js_fetch_response_status(double)

declare i64 @js_fetch_response_status_text(double)

declare double @js_fetch_response_ok(double)

declare i64 @js_fetch_response_type(double)

declare i64 @js_fetch_response_url(double)

declare double @js_fetch_response_redirected(double)

declare double @js_response_body_used(double)

declare i64 @js_fetch_response_text(double)

declare i64 @js_fetch_response_json(double)

declare double @js_response_get_headers(double)

declare double @js_response_clone(double)

declare i64 @js_response_array_buffer(double)

declare i64 @js_response_blob(double)

declare i64 @js_response_bytes(double)

declare i64 @js_response_form_data(double)

declare double @js_form_data_new()

declare double @js_form_data_append(double, double, double, double)

declare double @js_form_data_set(double, double, double, double)

declare double @js_form_data_delete(double, i64)

declare double @js_form_data_get(double, i64)

declare double @js_form_data_get_all(double, i64)

declare double @js_form_data_has(double, i64)

declare double @js_form_data_entries(double)

declare double @js_form_data_keys(double)

declare double @js_form_data_values(double)

declare double @js_form_data_for_each(double, double)

declare double @js_blob_size(double)

declare i64 @js_blob_type(double)

declare i64 @js_blob_array_buffer(double)

declare i64 @js_blob_bytes(double)

declare i64 @js_blob_text(double)

declare double @js_blob_slice(double, double, double, i64)

declare double @js_blob_new(double, double)

declare double @js_file_new(double, double, double, double)

declare i64 @js_file_name(double)

declare double @js_file_last_modified(double)

declare i64 @js_url_create_object_url(double)

declare void @js_url_revoke_object_url(double)

declare double @js_buffer_resolve_object_url(double)

declare double @js_response_static_json(double, double, i64, double)

declare double @js_response_static_redirect(i64, double)

declare double @js_response_static_error()

declare double @js_blob_stream(double)

declare double @js_response_body(double)

declare double @js_readable_stream_new(double, double, double, double)

declare double @js_readable_stream_new_with_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_with_strategy_and_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_from_source_object(double, double)

declare double @js_readable_stream_get_reader(double)

declare double @js_readable_stream_get_reader_with_options(double, double)

declare double @js_readable_stream_get_byob_reader(double)

declare double @js_readable_stream_controller_byob_request(double)

declare double @js_readable_stream_from_iterable(double)

declare double @js_readable_stream_locked(double)

declare i64 @js_readable_stream_cancel(double, double)

declare double @js_readable_stream_tee(double)

declare i64 @js_readable_stream_pipe_to(double, double, double)

declare double @js_readable_stream_pipe_through(double, double, double)

declare double @js_readable_stream_pipe_through_validate(double, double, double, double)

declare double @js_readable_stream_controller_enqueue(double, double)

declare double @js_readable_stream_controller_close(double)

declare double @js_readable_stream_controller_error(double, double)

declare double @js_readable_stream_controller_desired_size(double)

declare i64 @js_reader_read(double)

declare i64 @js_reader_read_with_view(double, double)

declare double @js_reader_release_lock(double)

declare i64 @js_reader_closed(double)

declare i64 @js_reader_cancel(double, double)

declare double @js_writable_stream_new(double, double, double, double, double)

declare double @js_writable_stream_new_with_sink_type(double, double, double, double, double, double)

declare double @js_writable_stream_new_from_sink_object(double, double)

declare double @js_writable_stream_throw_invalid_sink()

declare double @js_writable_stream_get_writer(double)

declare double @js_writable_stream_locked(double)

declare i64 @js_writable_stream_close(double)

declare i64 @js_writable_stream_abort(double, double)

declare i64 @js_writer_write(double, double)

declare i64 @js_writer_close(double)

declare i64 @js_writer_abort(double, double)

declare double @js_writer_release_lock(double)

declare i64 @js_writer_closed(double)

declare i64 @js_writer_ready(double)

declare double @js_writer_desired_size(double)

declare double @js_transform_stream_new(double, double, double, double, double)

declare double @js_transform_stream_new_from_transformer_object(double, double, double)

declare double @js_transform_stream_readable(double)

declare double @js_transform_stream_writable(double)

declare double @js_text_encoding_stream_new()

declare double @js_text_encoder_stream_new()

declare double @js_text_decoder_stream_new()

declare double @js_stream_web_text_encoder_stream_new()

declare double @js_stream_web_text_decoder_stream_new(double, double)

declare double @js_stream_web_compression_stream_new(double)

declare double @js_stream_web_decompression_stream_new(double)

declare double @js_streams_strategy_high_water_mark(double)

declare double @js_count_queuing_strategy_new(double)

declare double @js_byte_length_queuing_strategy_new(double)

declare double @js_stream_unwrap_handle(double)

declare double @js_readable_stream_subclass_init(double, double, double, double, double)

declare double @js_writable_stream_subclass_init(double, double, double, double, double)

declare double @js_transform_stream_subclass_init(double, double, double, double)

declare double @js_request_subclass_init(double, double, double)

declare double @js_response_subclass_init(double, double, double)

declare double @js_fetch_or_value_super(double, double, ptr, i64)

declare double @js_builtin_subclass_construct(i32, ptr, i64, ptr, i64)

declare i64 @js_abort_controller_new()

declare i64 @js_abort_controller_signal(i64)

declare void @js_abort_controller_abort(i64)

declare void @js_abort_controller_abort_reason(i64, double)

declare void @js_abort_signal_add_listener(i64, double, double)

declare i64 @js_abort_signal_timeout(double)

declare i64 @js_abort_signal_abort(double)

declare i64 @js_abort_signal_any(i64)

declare double @js_abort_signal_throw_if_aborted(i64)

declare i64 @js_event_target_new()

declare i64 @js_event_new(double, double, i32)

declare double @js_event_subclass_init(double, double, double, i32, i32)

declare i64 @js_custom_event_new(double, double, i32)

declare i64 @js_dom_exception_new(double, double)

declare double @js_dom_exception_subclass_init(double, double, double)

declare void @js_event_target_add_event_listener(i64, i64, i64)

declare void @js_event_target_add_event_listener_with_options(i64, i64, i64, double)

declare void @js_event_target_remove_event_listener(i64, i64, i64)

declare void @js_event_target_remove_event_listener_with_options(i64, i64, i64, double)

declare double @js_event_target_dispatch_event(i64, double)

declare i32 @js_event_target_is_event_target(i64)

declare i64 @js_event_target_get_event_listeners(i64, i64)

declare double @js_event_target_get_max_listeners(i64)

declare i32 @js_event_target_set_max_listeners(i64, double)

declare double @js_message_channel_new()

declare double @js_message_port_constructor_error()

declare double @js_broadcast_channel_new(double)

declare i64 @js_array_alloc(i32)

declare i64 @js_tagged_template_register_raw(i64, i64)

declare i64 @js_tagged_template_get_or_init(i64, i64, i64)

declare i64 @js_template_raw(i64)

declare i64 @js_array_create()

declare i64 @js_array_constructor_single(double)

declare i64 @js_array_alloc_literal(i32)

declare i64 @js_array_from_values(ptr, i32)

declare double @js_value_from_const_descriptor(ptr, i32)

declare i64 @js_array_push_f64(i64, double)

declare i64 @js_array_push_u31_with_length(i64, i32, ptr)

declare i64 @js_array_push_f64_spec(i64, double)

declare void @js_array_push_guard(i64)

declare i64 @js_array_push_hole(i64)

declare i64 @js_array_numeric_push_f64_unboxed(i64, double)

declare i64 @js_array_push_spread_f64(i64, i64)

declare double @js_array_get_f64(i64, i32)

declare i32 @js_array_ensure_element_shape(i64)

declare double @js_array_get_index_or_string(i64, double)

declare double @js_array_numeric_get_f64_unboxed(i64, i32)

declare void @js_array_set_f64(i64, i32, double)

declare i32 @js_array_numeric_set_f64_unboxed(i64, i32, double)

declare i64 @js_array_set_f64_extend(i64, i32, double)

declare i64 @js_array_set_f64_extend_strict(i64, i32, double)

declare i64 @js_array_fill_f64_const_extend(i64, i32, double)

declare i64 @js_array_fill_f64_iota_extend(i64, i32)

declare i64 @js_array_fill_f64_const_len_extend(i64, double)

declare i64 @js_array_fill_f64_iota_len_extend(i64)

declare i64 @js_array_numeric_range_add(double, double, double, double)

declare i64 @js_array_numeric_range_add_len(double, double, double)

declare i64 @js_array_fill_range_strided_tagged(double, double, double, double, i64)

declare i64 @js_array_set_string_key(i64, i64, double)

declare i64 @js_array_set_index_or_string(i64, double, double)

declare i64 @js_array_mark_arguments_object(i64)

declare i32 @js_array_mark_numeric_f64_layout(i64)

declare i32 @js_array_is_numeric_f64_layout(i64)

declare void @js_array_clear_numeric_layout(i64)

; Function Attrs: nounwind willreturn
declare double @js_array_numeric_value_to_raw_f64(double) #0

declare double @js_array_refresh_local_head(double)

declare void @js_array_note_numeric_write(i64, i64)

declare void @js_array_declare_all_pointer_elements(i64)

declare i32 @js_array_length(i64)

declare double @js_array_is_array(double)

declare double @js_value_length_f64(double)

declare double @js_value_length_property_f64(double)

declare double @js_value_length_property_ic_f64(double, ptr)

declare nonnull ptr @js_shadow_frame_enter(i32)

declare i64 @js_shadow_frame_push(i32)

declare void @js_shadow_frame_pop(i64)

declare void @js_shadow_slot_set(i32, i64)

declare void @js_shadow_slot_bind(i32, ptr)

declare void @js_gc_write_barriers_emitted(i32)

declare i32 @js_gc_temp_root_push(i64)

declare i64 @js_gc_temp_root_get(i32)

declare void @js_gc_temp_root_set(i32, i64)

declare void @js_gc_temp_root_truncate(i32)

declare void @js_array_push_f64_temp_rooted(i32, double)

declare void @js_gc_loop_safepoint()

declare void @js_write_barrier(i64, i64)

declare void @js_write_barrier_slot(i64, i64, i64)

declare i64 @js_array_live_head(i64)

declare void @js_write_barrier_slot_validated_parent(i64, i64, i64)

declare void @js_write_barrier_root_nanbox(i64)

declare void @js_write_barrier_root_heap_word(i64)

declare void @js_gc_note_slot_layout(i64, i32, i64)

declare void @js_gc_note_slot_layout_aware(i64, i32, i64, i64)

declare void @js_gc_init_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_declare_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_forget_object_layout(i64)

declare double @js_array_pop_f64(i64)

declare i64 @js_array_join(i64, i64)

declare i64 @js_array_join_value(i64, double)

declare void @js_array_forEach(i64, i64)

declare i64 @js_array_fill(i64, double)

declare i64 @js_array_fill_range(i64, double, double, double)

declare double @js_array_fill_generic(double, double, i32, double, i32, double)

declare i32 @js_array_delete(i64, i32)

declare void @js_array_set_length(i64, double)

declare void @js_array_set_length_strict(i64, double)

declare i64 @js_array_clone(i64)

declare i32 @js_short_packed_spread_values(double, ptr)

declare i64 @js_spread_tail_fallback_args(ptr, i64, double)

declare i64 @js_array_from_value(double)

declare i64 @js_array_from_arraylike_holey_value(double)

declare double @js_iterator_from(double)

declare i64 @js_array_from_mapped(double, double, double)

declare i64 @js_array_concat_variadic(i64, ptr, i32)

declare double @js_arraylike_forEach(double, double, double)

declare double @js_arraylike_map(double, double, double)

declare double @js_arraylike_filter(double, double, double)

declare double @js_arraylike_some(double, double, double)

declare double @js_arraylike_every(double, double, double)

declare double @js_arraylike_find(double, double, double)

declare double @js_arraylike_findIndex(double, double, double)

declare double @js_arraylike_findLast(double, double, double)

declare double @js_arraylike_findLastIndex(double, double, double)

declare double @js_arraylike_reduce(double, double, i32, double)

declare double @js_arraylike_reduceRight(double, double, i32, double)

declare double @js_arraylike_indexOf(double, double, double, i32)

declare double @js_arraylike_lastIndexOf(double, double, double, i32)

declare double @js_arraylike_includes(double, double, double, i32)

declare double @js_arraylike_at(double, double)

declare double @js_arraylike_join(double, double)

declare double @js_arraylike_flat(double, double)

declare double @js_arraylike_slice(double, double, i32, double, i32)

declare double @js_arraylike_sort(double, double)

declare double @js_arraylike_splice(double, ptr, i32)

declare double @js_arraylike_concat(double, ptr, i32)

declare double @js_arraylike_pop(double)

declare double @js_arraylike_shift(double)

declare double @js_arraylike_push(double, ptr, i32)

declare double @js_arraylike_unshift(double, ptr, i32)

declare i64 @js_array_clone_for_spread(double)

declare i64 @js_array_spread_append(i64, double)

declare i64 @js_iterator_to_array(double)

declare double @js_iterator_next_result(double)

declare double @js_iterator_close_if_not_done(double, double)

declare double @js_iterator_rest_to_array(double, double)

declare double @js_get_iterator(double)

declare double @js_get_async_iterator(double)

declare double @js_for_of_to_array(double)

declare i64 @js_object_alloc(i32, i32)

declare double @js_object_coerce(double)

declare void @js_object_mark_class(i64)

declare void @js_class_object_pin_parent(i64, i32)

declare i64 @js_object_alloc_with_shape(i32, i32, ptr, i32)

declare void @js_object_set_field(i64, i32, i64)

declare i64 @js_object_get_field(i64, i32)

declare void @js_object_set_field_by_name(i64, i64, double)

declare void @js_object_set_field_by_property_id(i64, i64, double)

declare void @js_object_set_field_by_name_nonenum(i64, i64, double)

declare void @js_error_subclass_default_init(double, double)

declare void @js_object_set_field_by_name_nonconfigurable(i64, i64, double)

declare void @js_error_apply_cause_to_object(i64, double)

declare void @js_error_subclass_capture_stack(double)

declare i32 @js_with_has_binding(double, i64)

declare double @js_with_get_binding(double, i64)

declare double @js_with_set_binding(double, i64, double, i32)

declare i32 @js_with_delete_binding(double, i64)

declare i32 @js_pod_scalar_write_compatible(double, i32)

declare void @js_typed_feedback_register_site(i64, i32, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64)

declare void @js_typed_feedback_record_guard_pass(i64)

declare void @js_typed_feedback_record_guard_fail(i64)

declare void @js_typed_feedback_record_fallback_call(i64)

declare void @js_typed_feedback_observe_property_get(i64, i64, i64)

declare void @js_typed_feedback_observe_property_set(i64, i64, i64)

declare double @js_typed_feedback_object_get_field_by_name_f64(i64, i64, i64)

declare void @js_typed_feedback_object_set_field_by_name(i64, i64, i64, double)

declare void @js_typed_feedback_object_set_field_by_name_fast(i64, i64, i64, double)

declare i32 @js_typed_feedback_class_field_set_guard(i64, double, i32, i32, i64, i32, double, i32)

declare void @js_class_field_set_fallback(i64, i64, i64, double)

declare void @js_class_field_set_ic(i64, double, i32, i32, i64, i32, double, i32)

declare i32 @js_typed_feedback_class_field_get_guard(i64, double, i32, i32, i64, i32, i32)

declare double @js_class_field_get_ic(i64, double, i32, i32, i64, i32, i32)

declare double @js_typed_feedback_native_call_method(i64, double, ptr, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_by_id(i64, double, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_apply(i64, double, ptr, i64, i64)

declare double @js_typed_feedback_native_call_method_apply_by_id(i64, double, i64, i64)

declare i32 @js_typed_feedback_method_direct_call_guard(i64, double, i32, i32, ptr, i64, ptr)

declare i32 @js_method_direct_shape_guard(double, i32, i32, i32)

declare i32 @js_method_direct_shape_class(double, ptr, i32)

declare i32 @js_typed_feedback_closure_direct_call_guard(i64, double, ptr, i32, i32)

declare i64 @js_closure_exact_func_guard(double, ptr)

declare i64 @js_object_own_method_cache_miss(double, i32, i32, ptr, i64, ptr, ptr)

declare void @js_typed_feedback_object_set_unboxed_f64_field(i64, i64, i32, i64, double)

declare double @js_typed_feedback_observe_helper_return(i64, double)

declare void @js_object_set_index_polymorphic(i64, double, double)

declare double @js_object_get_index_polymorphic(i64, double)

declare double @js_object_get_field_by_name_f64(i64, i64)

declare double @js_object_get_field_by_name_boxed(double, i64)

declare double @js_object_get_field_by_property_id_f64(i64, i64)

declare double @js_native_module_property_by_name(ptr, i64, ptr, i64)

declare double @js_native_module_esm_export_value(double, double)

declare double @js_native_module_named_esm_export_value(double, double)

declare double @js_create_native_module_namespace(ptr, i64)

declare void @js_nm_install_assert()

declare void @js_nm_install_async_hooks()

declare void @js_nm_install_bigint()

declare void @js_nm_install_buffer()

declare void @js_bun_tcp_nm_install()

declare void @js_nm_install_bun()

declare void @js_nm_install_bun_ffi()

declare void @js_nm_install_child_process()

declare void @js_nm_install_cluster()

declare void @js_nm_install_console()

declare void @js_nm_install_crypto()

declare void @js_nm_install_dgram()

declare void @js_nm_install_dns()

declare void @js_nm_install_domain()

declare void @js_nm_install_events()

declare void @js_nm_install_fs()

declare void @js_nm_install_http()

declare void @js_nm_install_inspector()

declare void @js_nm_install_module()

declare void @js_nm_install_net()

declare void @js_nm_install_node_pty()

declare void @js_nm_install_os()

declare void @js_nm_install_path()

declare void @js_nm_install_perf()

declare void @js_nm_install_process()

declare void @js_nm_install_punycode()

declare void @js_nm_install_querystring()

declare void @js_nm_install_readline()

declare void @js_nm_install_repl()

declare void @js_nm_install_sea()

declare void @js_nm_install_sqlite()

declare void @js_nm_install_stream()

declare void @js_nm_install_timers()

declare void @js_nm_install_tls()

declare void @js_nm_install_tty()

declare void @js_nm_install_url()

declare void @js_nm_install_util()

declare void @js_nm_install_v8()

declare void @js_nm_install_vm()

declare void @js_nm_install_wasi()

declare void @js_nm_install_zlib()

declare void @js_nm_install_all()

declare double @js_object_get_field_ic_miss(i64, i64, ptr)

declare double @js_object_get_field_ic(i64, i64, i64, ptr)

declare i64 @js_object_rest(i64, i64)

declare double @js_require_object_coercible(double)

declare double @js_require_json_disk(double)

declare double @js_require_resolve_node_modules(double, double)

declare void @js_globalthis_seed_async_local_storage()

declare void @js_register_path_module_partial(double, double)

declare void @js_register_path_module(double, double)

declare void @js_link_path_module_parent(double)

declare void @js_run_module_init_catching(i64)

declare double @js_require_path_module(double)

declare double @js_has_path_module(double)

declare void @js_register_path_init(ptr, i64, i64)

declare i64 @js_array_alloc_with_length(i32)

declare void @js_array_set_f64_unchecked(i64, i32, double)

declare double @js_typed_feedback_array_get_f64(i64, i64, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_get_guard(i64, double, i32, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_get_guard(i64, double, i32, i32) #0

declare i32 @js_typed_feedback_packed_f64_array_loop_guard(i64, double)

declare i32 @js_string_array_range_loop_guard(double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense_i32(i64, double, i32, i32)

declare i32 @js_typed_feedback_masked_window_ta_kind(i64, double, i32, i32)

declare i64 @js_typed_array_masked_window_data_ptr(double)

declare i64 @js_packed_ecs_u32_loop_guard(double, double, double, double, double, double, i32, ptr)

declare i32 @js_typed_feedback_packed_u32_array_loop_guard(i64, double)

declare double @js_typed_feedback_array_index_get_fallback_boxed(i64, double, double)

declare void @js_typed_feedback_array_set_f64(i64, i64, i32, double)

declare i64 @js_typed_feedback_array_set_f64_extend(i64, i64, i32, double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_push_guard(i64, double, double) #0

declare double @js_typed_feedback_array_index_set_fallback_boxed(i64, double, double, double, i32)

declare void @js_typed_feedback_observe_array_element(i64, i64, i32)

declare i64 @js_typed_feedback_array_set_string_key(i64, i64, i64, double)

declare i64 @js_typed_feedback_array_set_index_or_string(i64, i64, double, double, i32)

declare void @js_typed_feedback_object_set_index_polymorphic(i64, i64, double, double)

declare double @js_proxy_new(double, double)

declare double @js_proxy_revocable(double, double)

declare void @js_proxy_revoke(double)

declare i32 @js_proxy_is_revoked(double)

declare i32 @js_proxy_is_proxy(double)

declare double @js_proxy_target(double)

declare double @js_proxy_get(double, double)

declare double @js_proxy_set(double, double, double)

declare double @js_proxy_has(double, double)

declare double @js_proxy_delete(double, double)

declare double @js_proxy_apply(double, double, double)

declare double @js_proxy_construct(double, double, double)

declare double @js_reflect_construct(double, double, double)

declare double @js_reflect_get(double, double, double)

declare double @js_reflect_set(double, double, double, double)

declare double @js_put_value_set(double, double, double, double, i32)

declare i32 @js_transition_ic_spill_append(double, i64, i32, double)

declare ptr @perry_transition_cache_base()

declare void @js_transition_ic_note_hit()

declare double @js_put_value_set_dyn_ic(ptr, double, double, double, i32)

declare double @js_put_value_set_ic_miss(double, i64, double, i32, ptr, i32)

declare i32 @js_put_value_set_ic_overflow_store(double, i64, i32, double)

declare double @js_object_get_field_ic_overflow_load(i64, i64, i32, ptr)

declare double @js_put_value_set_ic_poly_tail(ptr, double, i64, double, i32)

declare i64 @js_object_array_numeric_write_guard(double, double, double, double, double, i32, i32)

declare i64 @js_object_array_numeric_write_range_guard(double, double, double, double, double, i32, i32, i32)

declare double @js_super_put_value_set(i32, double, double, double, i32)

declare double @js_super_accessor_get(i32, double, double)

declare double @js_reflect_has(double, double)

declare double @js_reflect_delete(double, double)

declare double @js_reflect_own_keys(double)

declare double @js_reflect_apply(double, double, double)

declare double @js_reflect_define_property(double, double, double)

declare double @js_reflect_get_own_property_descriptor(double, double)

declare double @js_reflect_get_prototype_of(double)

declare double @js_reflect_set_prototype_of(double, double)

declare double @js_reflect_is_extensible(double)

declare double @js_reflect_prevent_extensions(double)

declare double @js_reflect_define_metadata(double, double, double, double)

declare double @js_reflect_get_metadata(double, double, double)

declare double @js_reflect_get_own_metadata(double, double, double)

declare double @js_reflect_has_metadata(double, double, double)

declare double @js_reflect_has_own_metadata(double, double, double)

declare double @js_reflect_get_metadata_keys(double, double)

declare double @js_reflect_get_own_metadata_keys(double, double)

declare double @js_reflect_delete_metadata(double, double, double)

declare double @js_http_server_construct_with_this(double, double, double)

declare double @js_https_server_construct_with_this(double, double, double)

declare i64 @js_net_socket_set_encoding(i64, i64)

declare double @js_vm_create_context(double, double)

declare double @js_vm_create_script_branded(double, double)

declare double @js_vm_module_call()

declare double @js_vm_module_constructor_error()

declare double @js_repl_start(double)

declare double @js_repl_repl_server_new(double)

declare double @js_repl_recoverable_new(double)

declare double @js_worker_threads_worker_new(i64, double)

declare double @js_worker_threads_worker_post_message(i64, double)

declare double @js_worker_threads_worker_on(i64, double, i64)

declare double @js_worker_threads_worker_once(i64, double, i64)

declare double @js_worker_threads_worker_off(i64, double, i64)

declare double @js_worker_threads_worker_add_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_remove_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_terminate(i64)

declare double @js_worker_threads_worker_ref(i64)

declare double @js_worker_threads_worker_unref(i64)

declare double @js_worker_threads_worker_get_heap_statistics(i64)

declare double @js_worker_threads_worker_cpu_usage(i64, double)

declare double @js_worker_threads_worker_get_heap_snapshot(i64, double)

declare double @js_worker_threads_worker_start_cpu_profile(i64)

declare double @js_worker_threads_worker_start_heap_profile(i64)

declare i64 @js_http_client_request_end(i64, double)

declare i64 @js_http_client_request_write(i64, double)

declare i64 @js_http_client_request_end_full(i64, double, i64, i64)

declare double @js_http_client_request_write_full(i64, double, i64, i64)

declare i64 @js_http_set_timeout_full(i64, double, i64)

declare i64 @js_http_client_request_method(i64)

declare i64 @js_http_client_request_protocol(i64)

declare i64 @js_http_client_request_host(i64)

declare i64 @js_http_client_request_path(i64)

declare double @js_http_client_request_listener_count(i64, i64)

declare double @js_http_client_request_get_header(i64, i64)

declare double @js_http_client_request_has_header(i64, i64)

declare double @js_http_client_request_remove_header(i64, i64)

declare double @js_http_client_request_get_header_names(i64)

declare double @js_http_client_request_get_headers(i64)

declare double @js_http_client_request_get_raw_header_names(i64)

declare double @js_http_client_request_abort(i64)

declare i64 @js_http_client_request_destroy(i64, double)

declare double @js_http_client_request_noop_undefined(i64, double, double)

declare double @js_http_client_request_aborted(i64)

declare double @js_http_client_request_destroyed(i64)

declare double @js_http_client_request_finished(i64)

declare double @js_http_client_request_reused_socket(i64)

declare double @js_http_client_request_max_headers_count(i64)

declare double @js_http_client_request_writable_ended(i64)

declare double @js_http_client_request_writable_finished(i64)

declare double @js_http_client_request_socket(i64)

declare i64 @js_http_get(double, i64)

declare i64 @js_http_get_overload(i64)

declare i64 @js_http_request_overload(i64)

declare i64 @js_https_get_overload(i64)

declare i64 @js_https_request_overload(i64)

declare i64 @js_http_on(i64, i64, i64)

declare i64 @js_http_once(i64, i64, i64)

declare i64 @js_http_request(double, i64)

declare i64 @js_http_request_body(i64)

declare double @js_http_request_body_length(i64)

declare i64 @js_http_request_content_type(i64)

declare double @js_http_request_has_header(i64, i64)

declare i64 @js_http_request_header(i64, i64)

declare i64 @js_http_request_headers_all(i64)

declare double @js_http_request_id(i64)

declare double @js_http_request_is_method(i64, i64)

declare i64 @js_http_request_method(i64)

declare i64 @js_http_request_path(i64)

declare i64 @js_http_request_query(i64)

declare i64 @js_http_request_query_all(i64)

declare i64 @js_http_request_query_param(i64, i64)

declare double @js_http_respond_error(i64, double, i64)

declare double @js_http_respond_html(i64, double, i64)

declare double @js_http_respond_json(i64, double, i64)

declare double @js_http_respond_not_found(i64)

declare double @js_http_respond_redirect(i64, i64, double)

declare i64 @js_http_respond_status_text(double)

declare double @js_http_respond_text(i64, double, i64)

declare double @js_http_respond_with_headers(i64, double, i64, i64)

declare double @js_http_response_headers(i64)

declare double @js_http_response_trailers(i64)

declare double @js_http_incoming_message_socket(i64)

declare double @js_http_incoming_message_req(i64)

declare i64 @js_http_incoming_message_set_encoding(i64, i64)

declare i64 @js_http_server_accept_v2(i64)

declare double @js_http_server_close(i64)

declare i64 @js_http_server_create(double)

declare i64 @js_http_set_header(i64, i64, i64)

declare i64 @js_http_set_timeout(i64, double)

declare double @js_http_status_code(i64)

declare i64 @js_http_status_message(i64)

declare i64 @js_http_agent_new(double)

declare i64 @js_https_agent_new(double)

declare i64 @js_http_agent_get_name(i64, double)

declare i64 @js_http_agent_noop_self(i64)

declare double @js_http_agent_max_sockets(i64)

declare double @js_http_agent_max_free_sockets(i64)

declare double @js_http_agent_max_total_sockets(i64)

declare double @js_http_agent_keep_alive_msecs(i64)

declare double @js_http_agent_keep_alive(i64)

declare i64 @js_http_agent_protocol(i64)

declare double @js_http_agent_default_port(i64)

declare void @js_http_agent_set_protocol(i64, i64)

declare i64 @js_http_agent_destroy(i64)

declare double @js_http_agent_destroyed(i64)

declare double @js_http_agent_sockets(i64)

declare double @js_http_agent_free_sockets(i64)

declare double @js_http_agent_requests(i64)

declare void @js_http_agent_set_max_sockets(i64, double)

declare void @js_http_agent_set_max_free_sockets(i64, double)

declare void @js_http_agent_set_max_total_sockets(i64, double)

declare void @js_http_agent_set_keep_alive(i64, double)

declare void @js_http_agent_set_keep_alive_msecs(i64, double)

declare void @js_http_agent_set_create_connection(i64, i64)

declare void @js_http_agent_set_create_socket(i64, i64)

declare i64 @js_http_agent_create_connection(i64)

declare i64 @js_http_agent_create_socket(i64)

declare i64 @js_https_get(double, i64)

declare i64 @js_https_request(double, i64)

declare i64 @js_node_http_create_server(i64)

declare i64 @js_node_http_server_listen(i64, i64)

declare void @js_node_http_server_close(i64, i64)

declare void @js_node_http_server_close_all_connections(i64)

declare void @js_node_http_server_close_idle_connections(i64)

declare i64 @js_node_http_server_address_json(i64)

declare i32 @js_node_http_server_listening(i64)

declare double @js_node_http_server_listening_value(i64)

declare double @js_node_http_server_on(i64, i64, i64)

declare i64 @js_node_http_im_method(i64)

declare i64 @js_node_http_im_url(i64)

declare i64 @js_node_http_im_http_version(i64)

declare i64 @js_node_http_im_headers_json(i64)

declare i64 @js_node_http_im_raw_headers_json(i64)

declare i64 @js_node_http_im_headers_distinct_json(i64)

declare i64 @js_node_http_im_trailers_json(i64)

declare i64 @js_node_http_im_raw_trailers_json(i64)

declare i64 @js_node_http_im_trailers_distinct_json(i64)

declare i32 @js_node_http_im_complete(i64)

declare i32 @js_node_http_im_aborted(i64)

declare i32 @js_node_http_im_destroyed(i64)

declare i64 @js_node_http_im_remote_address(i64)

declare double @js_node_http_im_remote_port(i64)

declare void @js_node_http_im_pause(i64)

declare void @js_node_http_im_resume(i64)

declare void @js_node_http_im_destroy(i64)

declare double @js_node_http_im_on(i64, i64, i64)

declare double @js_node_http_im_once(i64, i64, i64)

declare double @js_node_http_im_read(i64)

declare i64 @js_node_http_im_set_timeout(i64, double, i64)

declare void @js_node_http_res_set_status(i64, double)

declare double @js_node_http_res_get_status(i64)

declare void @js_node_http_res_set_status_message(i64, i64)

declare void @js_node_http_res_set_header(i64, i64, double)

declare i64 @js_node_http_res_set_header_self(i64, i64, double)

declare double @js_node_http_res_get_header(i64, i64)

declare void @js_node_http_res_remove_header(i64, i64)

declare i32 @js_node_http_res_has_header(i64, i64)

declare double @js_node_http_res_has_header_value(i64, i64)

declare i64 @js_node_http_res_get_headers_json(i64)

declare i64 @js_node_http_res_get_header_names_json(i64)

declare i64 @js_node_http_res_append_header(i64, i64, i64)

declare i64 @js_node_http_res_set_headers(i64, double)

declare double @js_node_http_res_get_status_message(i64)

declare i32 @js_node_http_res_headers_sent(i64)

declare i32 @js_node_http_res_writable_ended(i64)

declare i32 @js_node_http_res_writable_finished(i64)

declare i32 @js_node_http_res_finished(i64)

declare i32 @js_node_http_res_send_date(i64)

declare void @js_node_http_res_set_send_date(i64, double)

declare i32 @js_node_http_res_strict_content_length(i64)

declare void @js_node_http_res_set_strict_content_length(i64, double)

declare i64 @js_node_http_res_req_handle(i64)

declare void @js_node_http_res_write_head(i64, double, i64, i64)

declare i32 @js_node_http_res_write(i64, double)

declare double @js_node_http_res_write_full(i64, double, i64, i64)

declare void @js_node_http_res_add_trailers(i64, double)

declare void @js_node_http_res_end(i64, double)

declare void @js_node_http_res_end_full(i64, double, i64, i64)

declare void @js_node_http_res_flush_headers(i64)

declare void @js_node_http_res_cork(i64)

declare void @js_node_http_res_uncork(i64)

declare i64 @js_node_http_res_set_timeout(i64, double, i64)

declare void @js_node_http_res_write_early_hints(i64, double, i64)

declare void @js_node_http_res_write_continue(i64)

declare void @js_node_http_res_write_processing(i64)

declare double @js_node_http_res_on(i64, i64, i64)

declare i64 @js_node_https_create_server(double, i64)

declare i64 @js_node_https_server_listen(i64, i64)

declare void @js_node_https_server_close(i64, i64)

declare void @js_node_https_server_close_all_connections(i64)

declare void @js_node_https_server_close_idle_connections(i64)

declare i64 @js_node_https_server_address_json(i64)

declare double @js_node_https_server_on(i64, i64, i64)

declare double @js_node_https_server_listening_value(i64)

declare double @js_node_https_server_headers_timeout(i64)

declare double @js_node_https_server_set_headers_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout(i64)

declare double @js_node_https_server_set_keep_alive_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout_buffer(i64)

declare double @js_node_https_server_set_keep_alive_timeout_buffer(i64, double)

declare double @js_node_https_server_request_timeout(i64)

declare double @js_node_https_server_set_request_timeout(i64, double)

declare double @js_node_https_server_idle_timeout(i64)

declare double @js_node_https_server_set_idle_timeout(i64, double)

declare double @js_node_https_server_max_headers_count(i64)

declare double @js_node_https_server_set_max_headers_count(i64, double)

declare double @js_node_https_server_max_requests_per_socket(i64)

declare double @js_node_https_server_set_max_requests_per_socket(i64, double)

declare i64 @js_node_https_server_set_timeout_method(i64, double, i64)

declare i64 @js_node_http2_create_server(double, double)

declare i64 @js_node_http2_create_secure_server(double, i64)

declare i64 @js_node_http2_connect(double, double, i64)

declare i64 @js_node_http2_server_listen(i64, i64)

declare void @js_node_http2_server_close(i64, i64)

declare i64 @js_node_http2_server_address_json(i64)

declare double @js_node_http2_server_on(i64, i64, i64)

declare i64 @js_node_http2_get_default_settings()

declare i64 @js_node_http2_get_packed_settings(i64)

declare i64 @js_node_http2_get_unpacked_settings(i64)

declare i64 @js_pg_client_connect(i64)

declare i64 @js_pg_client_end(i64)

declare i64 @js_pg_client_new(i64)

declare i64 @js_pg_client_query(i64, i64)

declare i64 @js_pg_client_query_params(i64, i64, i64)

declare i64 @js_pg_connect(i64)

declare i64 @js_pg_create_pool(i64)

declare i64 @js_pg_pool_end(i64)

declare i64 @js_pg_pool_new(i64)

declare i64 @js_pg_pool_query(i64, i64)

declare i64 @js_ioredis_connect(i64)

declare i64 @js_ioredis_decr(i64, i64)

declare i64 @js_ioredis_del(i64, i64)

declare void @js_ioredis_disconnect(i64)

declare i64 @js_ioredis_exists(i64, i64)

declare i64 @js_ioredis_expire(i64, i64, double)

declare i64 @js_ioredis_get(i64, i64)

declare i64 @js_ioredis_hdel(i64, i64, i64)

declare i64 @js_ioredis_hget(i64, i64, i64)

declare i64 @js_ioredis_hgetall(i64, i64)

declare i64 @js_ioredis_hlen(i64, i64)

declare i64 @js_ioredis_hset(i64, i64, i64, i64)

declare i64 @js_ioredis_incr(i64, i64)

declare i64 @js_ioredis_new(i64)

declare i64 @js_ioredis_ping(i64)

declare i64 @js_ioredis_quit(i64)

declare i64 @js_ioredis_set(i64, i64, i64)

declare i64 @js_ioredis_setex(i64, i64, double, i64)

declare i64 @js_mongodb_client_close(i64)

declare i64 @js_mongodb_client_connect(i64)

declare i64 @js_mongodb_client_db(i64, i64)

declare i64 @js_mongodb_client_list_databases(i64)

declare i64 @js_mongodb_client_new(i64)

declare i64 @js_mongodb_collection_count_value(i64, double)

declare i64 @js_mongodb_collection_delete_many_value(i64, double)

declare i64 @js_mongodb_collection_delete_one_value(i64, double)

declare i64 @js_mongodb_collection_find_one_value(i64, double)

declare i64 @js_mongodb_collection_find_value(i64, double)

declare i64 @js_mongodb_collection_insert_many_value(i64, double)

declare i64 @js_mongodb_collection_insert_one_value(i64, double)

declare i64 @js_mongodb_collection_update_many_value(i64, double, double)

declare i64 @js_mongodb_collection_update_one_value(i64, double, double)

declare i64 @js_mongodb_collection_count(i64, i64)

declare i64 @js_mongodb_collection_delete_many(i64, i64)

declare i64 @js_mongodb_collection_delete_one(i64, i64)

declare i64 @js_mongodb_collection_find(i64, i64)

declare i64 @js_mongodb_collection_find_one(i64, i64)

declare i64 @js_mongodb_collection_insert_many(i64, i64)

declare i64 @js_mongodb_collection_insert_one(i64, i64)

declare i64 @js_mongodb_collection_update_many(i64, i64, i64)

declare i64 @js_mongodb_collection_update_one(i64, i64, i64)

declare i64 @js_mongodb_connect(i64)

declare i64 @js_mongodb_db_collection(i64, i64)

declare i64 @js_mongodb_db_list_collections(i64)

declare void @js_sqlite_close(i64)

declare void @js_sqlite_exec(i64, i64)

declare i64 @js_sqlite_open(i64)

declare i64 @js_sqlite_pragma(i64, i64, i64)

declare i64 @js_sqlite_prepare(i64, i64)

declare i64 @js_sqlite_stmt_all(i64, i64)

declare i64 @js_sqlite_stmt_columns(i64)

declare i64 @js_sqlite_stmt_get(i64, i64)

declare i64 @js_sqlite_stmt_run(i64, i64)

declare i64 @js_sqlite_transaction(i64, i64)

declare void @js_sqlite_transaction_commit(i64)

declare void @js_sqlite_transaction_rollback(i64)

declare i64 @js_bun_sqlite_database_call(double, double)

declare i64 @js_bun_sqlite_database_new(double, double)

declare i64 @js_bun_sqlite_database_query(i64, double)

declare i64 @js_bun_sqlite_database_run(i64, double, i64)

declare i64 @js_bun_sqlite_database_filename(i64)

declare i64 @js_bun_sqlite_database_transaction(i64, double)

declare i64 @js_bun_sqlite_statement_values(i64, i64)

declare double @js_bun_sqlite_statement_safe_integers(i64, double)

declare void @js_bun_sqlite_statement_finalize(i64)

declare i64 @js_node_sqlite_backup(double, double, double)

declare i64 @js_node_sqlite_database_sync_call(double, double)

declare i64 @js_node_sqlite_database_sync_new(double, double)

declare i32 @js_node_sqlite_database_sync_open(i64)

declare i32 @js_node_sqlite_database_sync_close(i64)

declare i32 @js_node_sqlite_database_sync_dispose(i64)

declare i32 @js_node_sqlite_database_sync_exec(i64, double)

declare i64 @js_node_sqlite_database_sync_prepare(i64, double, double)

declare i32 @js_node_sqlite_database_sync_function(i64, double, double, double)

declare i32 @js_node_sqlite_database_sync_aggregate(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_defensive(i64, double)

declare i32 @js_node_sqlite_database_sync_set_authorizer(i64, double)

declare i64 @js_node_sqlite_database_sync_create_tag_store(i64, double)

declare i64 @js_node_sqlite_database_sync_create_session(i64, double)

declare double @js_node_sqlite_database_sync_apply_changeset(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_load_extension(i64, double)

declare i32 @js_node_sqlite_database_sync_load_extension(i64, double)

declare double @js_node_sqlite_database_sync_location(i64, double)

declare double @js_node_sqlite_database_sync_is_open(i64)

declare double @js_node_sqlite_database_sync_is_transaction(i64)

declare i64 @js_node_sqlite_database_sync_limits(i64)

declare i64 @js_node_sqlite_statement_sync_call(double, double)

declare i64 @js_node_sqlite_statement_sync_new(double, double)

declare i64 @js_node_sqlite_statement_sync_run(i64, i64)

declare double @js_node_sqlite_statement_sync_get(i64, i64)

declare i64 @js_node_sqlite_statement_sync_all(i64, i64)

declare double @js_node_sqlite_statement_sync_iterate(i64, i64)

declare i64 @js_node_sqlite_statement_sync_columns(i64)

declare i32 @js_node_sqlite_statement_sync_set_read_bigints(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_return_arrays(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_bare_named_parameters(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_unknown_named_parameters(i64, double)

declare i64 @js_node_sqlite_statement_sync_source_sql(i64)

declare i64 @js_node_sqlite_statement_sync_expanded_sql(i64)

declare i64 @js_node_sqlite_sql_tag_store_run(i64, i64)

declare double @js_node_sqlite_sql_tag_store_get(i64, i64)

declare i64 @js_node_sqlite_sql_tag_store_all(i64, i64)

declare double @js_node_sqlite_sql_tag_store_iterate(i64, i64)

declare i32 @js_node_sqlite_sql_tag_store_clear(i64)

declare double @js_node_sqlite_sql_tag_store_size(i64)

declare double @js_node_sqlite_sql_tag_store_capacity(i64)

declare i64 @js_node_sqlite_sql_tag_store_db(i64)

declare i64 @js_node_sqlite_session_call(double, double)

declare i64 @js_node_sqlite_session_new(double, double)

declare i64 @js_node_sqlite_session_changeset(i64)

declare i64 @js_node_sqlite_session_patchset(i64)

declare i32 @js_node_sqlite_session_close(i64)

declare i32 @js_node_sqlite_session_dispose(i64)

declare i64 @js_os_cpus()

declare double @js_os_freemem()

declare i64 @js_os_homedir()

declare i64 @js_os_network_interfaces()

declare i64 @js_os_tmpdir()

declare double @js_os_totalmem()

declare double @js_os_uptime()

declare i64 @js_os_user_info()

declare i64 @js_os_user_info_buffer()

declare i64 @js_os_user_info_options(i64)

declare i64 @js_crypto_aes256_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_encrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_encrypt(i64, i64, i64)

declare double @js_crypto_create_cipheriv(i64, i64, i64, double)

declare double @js_crypto_create_decipheriv(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sha256(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sync(i64, i64, i64, i64, double)

declare i64 @js_crypto_pbkdf2(i64, i64, double, double)

declare i64 @js_crypto_random_bytes_hex(double)

declare i64 @js_crypto_random_nonce()

declare i64 @js_crypto_scrypt(i64, i64, double)

declare double @js_crypto_generate_key_pair_sync(i64, i64)

declare i64 @js_crypto_scrypt_custom(i64, i64, double, double, double, double)

declare i64 @js_crypto_x25519_keypair()

declare i64 @js_crypto_x25519_shared_secret(i64, i64)

declare i64 @js_keccak256_native(i64)

declare i64 @js_keccak256_native_bytes(i64)

declare i64 @js_nanoid(double)

declare i64 @js_nanoid_custom(i64, double)

declare i64 @js_argon2_hash(i64)

declare i64 @js_argon2_hash_options(i64, i64)

declare i64 @js_argon2_verify(i64, i64)

declare i64 @js_bcrypt_compare(i64, i64)

declare double @js_bcrypt_compare_sync(i64, i64)

declare i64 @js_bcrypt_gen_salt(double)

declare i64 @js_bcrypt_hash(i64, double)

declare i64 @js_bcrypt_hash_sync(i64, double)

declare i64 @js_ads_interstitial_load(i64)

declare i64 @js_ads_interstitial_show()

declare i64 @js_ads_rewarded_load(i64)

declare i64 @js_ads_rewarded_show()

declare double @js_ads_banner_create(i64, i64)

declare void @js_ads_banner_destroy(double)

declare i64 @js_ads_request_consent()

declare i64 @js_perry_read_embedded(double)

declare i64 @js_perry_embedded_files()

declare double @js_thread_parallel_map(double, double)

declare double @js_thread_parallel_filter(double, double)

declare double @js_thread_spawn(double)

declare double @js_perry_native_i8(double)

declare double @js_perry_native_i16(double)

declare double @js_perry_native_u8(double)

declare double @js_perry_native_u16(double)

declare double @js_perry_native_i32(double)

declare double @js_perry_native_i64(double)

declare double @js_perry_native_u32(double)

declare double @js_perry_native_u64(double)

declare double @js_perry_native_usize(double)

declare double @js_perry_native_isize(double)

declare double @js_perry_native_f32(double)

declare double @js_perry_native_f64(double)

declare i64 @js_jwt_decode(i64)

declare i64 @js_jwt_sign(i64, i64, double, i64)

declare i64 @js_jwt_sign_es256(i64, i64, double, i64)

declare i64 @js_jwt_sign_rs256(i64, i64, double, i64)

declare i64 @js_jwt_verify(i64, i64)

declare i64 @js_jwt_verify_es256(i64, i64)

declare i64 @js_jwt_verify_rs256(i64, i64)

declare i64 @js_jwt_sign_dyn(i64, i64, i64, double, i64)

declare i64 @js_jwt_verify_dyn(i64, i64, i64)

declare i64 @js_jwt_sign_dyn_opts(i64, i64, double)

declare i64 @js_jwt_verify_dyn_opts(i64, i64, double)

declare double @js_axios_create(i64)

declare i64 @js_axios_delete(i64)

declare i64 @js_axios_get(i64)

declare i64 @js_axios_head(i64)

declare i64 @js_axios_options(i64)

declare i64 @js_axios_post(i64, double)

declare i64 @js_axios_put(i64, double)

declare i64 @js_axios_patch(i64, double)

declare i64 @js_axios_request(i64)

declare double @js_axios_response_status(i64)

declare i64 @js_axios_response_status_text(i64)

declare i64 @js_axios_response_data(i64)

declare double @js_axios_response_data_parsed(i64)

declare i64 @js_sharp_auto_orient(i64)

declare i64 @js_sharp_avif(i64, double)

declare i64 @js_sharp_blur(i64, double)

declare i64 @js_sharp_composite(i64, double)

declare i64 @js_sharp_extend(i64, double)

declare i64 @js_sharp_extract(i64, double)

declare i64 @js_sharp_flip(i64)

declare i64 @js_sharp_flop(i64)

declare i64 @js_sharp_from_buffer(i64, double)

declare i64 @js_sharp_from_file(i64)

declare i64 @js_sharp_from_input(i64)

declare i64 @js_sharp_grayscale(i64)

declare i64 @js_sharp_metadata(i64)

declare i64 @js_sharp_sharpen(i64)

declare i64 @js_sharp_trim(i64)

declare i64 @js_sharp_negate(i64)

declare i64 @js_sharp_quality(i64, double)

declare i64 @js_sharp_resize(i64, double, double)

declare i64 @js_sharp_rotate(i64, double)

declare i64 @js_sharp_to_buffer(i64)

declare i64 @js_sharp_to_file(i64, i64)

declare i64 @js_sharp_to_format(i64, i64)

declare void @js_cron_clear_interval(i64)

declare void @js_cron_clear_timeout(i64)

declare i64 @js_cron_describe(i64)

declare double @js_cron_job_is_running(i64)

declare i64 @js_cron_job_new(i64, i64, double)

declare void @js_cron_job_start(i64)

declare void @js_cron_job_stop(i64)

declare i64 @js_cron_next_date(i64)

declare i64 @js_cron_next_dates(i64, double)

declare i64 @js_cron_schedule(i64, i64)

declare i64 @js_cron_set_interval(double, double)

declare i64 @js_cron_set_timeout(double, double)

declare i32 @js_cron_timer_has_pending()

declare i32 @js_cron_timer_tick()

declare double @js_cron_validate(i64)

declare i64 @js_async_hooks_create_hook(double)

declare double @js_async_hooks_execution_async_id()

declare double @js_async_hooks_trigger_async_id()

declare double @js_async_hooks_execution_async_resource()

declare i64 @js_async_hook_enable(i64)

declare i64 @js_async_hook_disable(i64)

declare i64 @js_async_resource_new(double, double)

declare double @js_async_resource_subclass_init(double, double, double)

declare double @js_async_resource_async_id(i64)

declare double @js_async_resource_trigger_async_id(i64)

declare i64 @js_async_resource_emit_destroy(i64)

declare double @js_async_resource_run_in_async_scope(i64, double, double, i64)

declare i64 @js_async_resource_bind(i64, double, double)

declare i64 @js_async_resource_static_bind(i64, double)

declare void @js_async_local_storage_disable(i64)

declare void @js_async_local_storage_enter_with(i64, double)

declare double @js_async_local_storage_exit(i64, double, i64)

declare double @js_async_local_storage_get_store(i64)

declare i64 @js_async_local_storage_new()

declare double @js_async_local_storage_subclass_init(double)

declare double @js_async_local_storage_run(i64, double, double, i64)

declare i64 @js_disposable_stack_new()

declare i64 @js_async_disposable_stack_new()

declare double @js_suppressed_error_new(double, double, double)

declare i64 @js_zlib_deflate_sync(i64, double)

declare void @js_zlib_deflate(double, double)

declare i64 @js_zlib_gunzip_sync(i64)

declare void @js_zlib_gunzip(double, double)

declare i64 @js_zlib_gzip_sync(i64, double)

declare void @js_zlib_gzip(double, double)

declare i64 @js_zlib_inflate_sync(i64)

declare void @js_zlib_inflate(double, double)

declare i64 @js_zlib_deflate_raw_sync(double, double)

declare void @js_zlib_deflate_raw(double, double)

declare i64 @js_zlib_inflate_raw_sync(double)

declare void @js_zlib_inflate_raw(double, double)

declare i64 @js_zlib_unzip_sync(double)

declare void @js_zlib_unzip(double, double)

declare double @js_zlib_crc32(double, double)

declare i64 @js_zlib_brotli_compress_sync(i64)

declare i64 @js_zlib_brotli_decompress_sync(i64)

declare void @js_zlib_brotli_compress(double, double)

declare void @js_zlib_brotli_decompress(double, double)

declare i64 @js_zlib_zstd_compress_sync(double, double)

declare i64 @js_zlib_zstd_decompress_sync(double, double)

declare void @js_zlib_zstd_compress(double, double)

declare void @js_zlib_zstd_decompress(double, double)

declare i64 @js_zlib_create_gzip(double)

declare i64 @js_zlib_create_gunzip(double)

declare i64 @js_zlib_create_deflate(double)

declare i64 @js_zlib_create_inflate(double)

declare i64 @js_zlib_create_deflate_raw(double)

declare i64 @js_zlib_create_inflate_raw(double)

declare i64 @js_zlib_create_unzip(double)

declare i64 @js_zlib_create_brotli_compress(double)

declare i64 @js_zlib_create_zstd_compress(double)

declare i64 @js_zlib_create_zstd_decompress(double)

declare i64 @js_buffer_alloc_unsafe(i32)

declare i32 @js_buffer_byte_length(i64)

declare i32 @js_buffer_byte_length_value(double, double)

declare i64 @js_buffer_concat(i64)

declare i64 @js_buffer_concat_with_length(i64, double)

declare i32 @js_buffer_validate_size(double)

declare i64 @js_buffer_validate_concat_list(double)

declare i32 @js_buffer_copy(i64, i64, i32, i32, i32)

declare i32 @js_buffer_equals(i64, i64)

declare i64 @js_buffer_fill(i64, i32)

declare i64 @js_buffer_from_value(i64, i32)

declare double @js_buffer_is_ascii(double)

declare i32 @js_buffer_is_buffer(i64)

declare i32 @js_buffer_is_node_buffer(i64)

declare i32 @js_buffer_is_encoding(double)

declare double @js_buffer_is_utf8(double)

declare void @js_buffer_print(i64)

declare void @js_buffer_set(i64, i32, i32)

declare void @js_buffer_set_from(i64, i64, i32)

declare i64 @js_buffer_slice(i64, i32, i32)

declare i64 @js_buffer_to_string(i64, i32)

declare i64 @js_buffer_transcode(double, double, double)

declare i32 @js_buffer_write(i64, i64, i32, i32)

declare double @js_child_process_exec_sync(i64, i64)

declare double @js_child_process_exec(i64, double, double)

declare i64 @js_child_process_get_process_status(double)

declare i32 @js_child_process_kill_process(double)

declare i64 @js_child_process_spawn_background(double, i64, double, double)

declare i64 @js_child_process_spawn_sync(i64, i64, i64)

declare double @js_child_process_spawn_streams(i64, i64, i64)

declare double @js_pty_spawn(i64, i64, i64)

declare double @js_child_process_fork(i64, i64, i64)

declare double @js_child_process_exec_file(i64, double, double, double)

declare double @js_child_process_exec_file_sync(i64, double, double)

declare double @js_child_process_validate_command(double, ptr, i32)

declare double @js_child_process_validate_args(double)

declare double @js_child_process_validate_options(double, i32, i32)

declare double @js_child_process_validate_fork_module(double)

declare double @js_child_process_validate_spawn_args(double, i32, i32)

declare double @js_child_process_new()

declare i64 @js_cheerio_load(i64)

declare i64 @js_cheerio_load_fragment(i64)

declare i64 @js_cheerio_select(i64, i64)

declare i64 @js_cheerio_selection_attr(i64, i64)

declare i64 @js_cheerio_selection_attrs(i64, i64)

declare i64 @js_cheerio_selection_children(i64, i64)

declare i64 @js_cheerio_selection_eq(i64, double)

declare i64 @js_cheerio_selection_find(i64, i64)

declare i64 @js_cheerio_selection_first(i64)

declare double @js_cheerio_selection_has_class(i64, i64)

declare i64 @js_cheerio_selection_html(i64)

declare double @js_cheerio_selection_is(i64, i64)

declare i64 @js_cheerio_selection_last(i64)

declare double @js_cheerio_selection_length(i64)

declare i64 @js_cheerio_selection_parent(i64)

declare i64 @js_cheerio_selection_text(i64)

declare i64 @js_cheerio_selection_texts(i64)

declare i64 @js_cheerio_selection_to_array(i64)

declare double @js_url_file_url_to_path(double, double)

declare double @js_url_file_url_to_path_buffer(double, double)

declare double @js_url_get_hash(i64)

declare double @js_url_get_host(i64)

declare double @js_url_get_hostname(i64)

declare double @js_url_get_href(i64)

declare double @js_url_get_origin(i64)

declare double @js_url_get_pathname(i64)

declare double @js_url_get_port(i64)

declare double @js_url_get_protocol(i64)

declare double @js_url_get_search(i64)

declare double @js_url_get_search_params(i64)

declare i64 @js_url_new(i64)

declare i64 @js_url_new_with_base(i64, i64)

declare i64 @js_url_pattern_new(double, double)

declare double @js_url_pattern_constructor_call(double, double)

declare i32 @js_url_can_parse(i64)

declare i32 @js_url_can_parse_with_base(i64, i64)

declare i64 @js_url_parse(i64)

declare i64 @js_url_parse_with_base(i64, i64)

declare void @js_url_set_pathname(i64, double)

declare void @js_url_set_search(i64, double)

declare void @js_url_set_hash(i64, double)

declare void @js_url_set_protocol(i64, double)

declare void @js_url_set_hostname(i64, double)

declare void @js_url_set_port(i64, double)

declare void @js_url_set_username(i64, double)

declare void @js_url_set_password(i64, double)

declare void @js_url_set_href(i64, double)

declare double @js_url_search_params_has2(i64, double, double)

declare void @js_url_search_params_delete2(i64, double, double)

declare double @js_url_search_params_throw_missing_args(i32)

declare void @js_url_search_params_append(i64, double, double)

declare void @js_url_search_params_delete(i64, double)

declare i64 @js_url_search_params_get(i64, double)

declare double @js_url_search_params_get_all(i64, double)

declare double @js_url_search_params_has(i64, double)

declare i64 @js_url_search_params_new(i64)

declare i64 @js_url_search_params_new_any(double)

declare i64 @js_url_search_params_new_empty()

declare double @js_url_search_params_subclass_init(double, double)

declare void @js_url_search_params_set(i64, double, double)

declare i64 @js_url_search_params_to_string(i64)

declare i32 @js_url_search_params_size(i64)

declare double @js_url_search_params_entries_arr(i64)

declare double @js_url_search_params_keys_arr(i64)

declare double @js_url_search_params_values_arr(i64)

declare void @js_url_search_params_sort(i64)

declare void @js_url_search_params_for_each(i64, double, double)

declare i64 @js_url_coerce_string(double)

declare double @js_url_path_to_file_url(double, double)

declare double @js_url_domain_to_ascii(double)

declare double @js_url_domain_to_unicode(double)

declare double @js_url_to_http_options(double)

declare double @js_url_legacy_url_new()

declare double @js_url_format(double, double)

declare double @js_url_legacy_parse(double, double, double)

declare double @js_url_legacy_resolve(double, double)

declare double @js_url_legacy_resolve_object(double, double)

declare void @js_ws_close(i64)

declare i64 @js_ws_connect(i64)

declare double @js_ws_connect_start(double)

declare i64 @js_ws_handle_to_i64(double)

declare double @js_ws_is_open(i64)

declare double @js_ws_message_count(i64)

declare double @js_ws_ready_state(i64)

declare i64 @js_ws_on(i64, i64, i64)

declare i64 @js_ws_receive(i64)

declare void @js_ws_send(i64, i64)

declare void @js_ws_send_to_client(double, i64)

declare void @js_ws_close_client(double)

declare void @js_ws_send_client_i64(i64, i64)

declare void @js_ws_close_client_i64(i64)

declare i64 @js_ws_on_client_i64(i64, i64, i64)

declare void @js_ws_server_close(i64)

declare double @js_ws_server_clients(i64)

declare double @js_ws_server_address(i64)

declare i32 @js_ws_server_emit(i64, i64, double, double)

declare i64 @js_ws_server_new(double)

declare void @js_ws_handle_upgrade(i64, double, double, double, i64)

declare i64 @js_ws_wait_for_message(i64, double)

declare i64 @js_pdf_create_pdf(double)

declare void @js_pdf_add_text(i64, i64, double, double, double)

declare void @js_pdf_add_line(i64, double, double, double, double)

declare void @js_pdf_new_page(i64)

declare void @js_pdf_save(i64)

declare i64 @js_commander_action(i64, i64)

declare i64 @js_commander_command(i64, i64)

declare i64 @js_commander_description(i64, i64)

declare i64 @js_commander_get_option(i64, i64)

declare double @js_commander_get_option_bool(i64, i64)

declare double @js_commander_get_option_number(i64, i64)

declare i64 @js_commander_name(i64, i64)

declare i64 @js_commander_new()

declare i64 @js_commander_option(i64, i64, i64, i64)

declare i64 @js_commander_opts(i64)

declare i64 @js_commander_parse(i64, double)

declare i64 @js_commander_required_option(i64, i64, i64, i64)

declare i64 @js_commander_version(i64, i64)

declare double @js_dotenv_config()

declare double @js_dotenv_config_path(i64)

declare i64 @js_dotenv_parse(i64)

declare double @js_datefns_add_days(double, double)

declare double @js_datefns_add_months(double, double)

declare double @js_datefns_add_years(double, double)

declare double @js_datefns_difference_in_days(double, double)

declare double @js_datefns_difference_in_hours(double, double)

declare double @js_datefns_difference_in_minutes(double, double)

declare double @js_datefns_end_of_day(double)

declare i64 @js_datefns_format(double, i64)

declare double @js_datefns_is_after(double, double)

declare double @js_datefns_is_before(double, double)

declare double @js_datefns_parse_iso(i64)

declare double @js_datefns_start_of_day(double)

declare double @js_dayjs_add(i64, double, i64)

declare double @js_dayjs_date(i64)

declare double @js_dayjs_day(i64)

declare double @js_dayjs_diff(i64, i64, i64)

declare double @js_dayjs_end_of(i64, i64)

declare double @js_dayjs_factory(i64)

declare i64 @js_dayjs_format(i64, i64)

declare double @js_dayjs_from_timestamp(double)

declare double @js_dayjs_hour(i64)

declare double @js_dayjs_is_after(i64, i64)

declare double @js_dayjs_is_before(i64, i64)

declare double @js_dayjs_is_same(i64, i64)

declare double @js_dayjs_is_valid(i64)

declare double @js_dayjs_millisecond(i64)

declare double @js_dayjs_minute(i64)

declare double @js_dayjs_month(i64)

declare double @js_dayjs_now()

declare double @js_dayjs_parse(i64)

declare double @js_dayjs_second(i64)

declare double @js_dayjs_start_of(i64, i64)

declare double @js_dayjs_subtract(i64, double, i64)

declare i64 @js_dayjs_to_iso_string(i64)

declare double @js_dayjs_unix(i64)

declare double @js_dayjs_value_of(i64)

declare double @js_dayjs_year(i64)

declare double @js_moment_add(i64, double, i64)

declare double @js_moment_clone(i64)

declare double @js_moment_date(i64)

declare double @js_moment_day(i64)

declare double @js_moment_diff(i64, i64, i64)

declare double @js_moment_end_of(i64, i64)

declare double @js_moment_factory(i64)

declare i64 @js_moment_format(i64, i64)

declare i64 @js_moment_from_now(i64)

declare double @js_moment_from_timestamp(double)

declare double @js_moment_hour(i64)

declare double @js_moment_is_after(i64, i64)

declare double @js_moment_is_before(i64, i64)

declare double @js_moment_is_between(i64, i64, i64)

declare double @js_moment_is_same(i64, i64, i64)

declare double @js_moment_is_valid(i64)

declare double @js_moment_millisecond(i64)

declare double @js_moment_minute(i64)

declare double @js_moment_month(i64)

declare double @js_moment_now()

declare double @js_moment_parse(i64)

declare double @js_moment_second(i64)

declare double @js_moment_start_of(i64, i64)

declare double @js_moment_subtract(i64, double, i64)

declare double @js_moment_to_date(i64)

declare i64 @js_moment_to_iso_string(i64)

declare double @js_moment_unix(i64)

declare double @js_moment_value_of(i64)

declare double @js_moment_year(i64)

declare i64 @js_decimal_abs(i64)

declare i64 @js_decimal_ceil(i64)

declare double @js_decimal_cmp(i64, i64)

declare double @js_decimal_cmp_value(i64, double)

declare i64 @js_decimal_coerce_to_handle(double)

declare i64 @js_decimal_div(i64, i64)

declare i64 @js_decimal_div_number(i64, double)

declare i64 @js_decimal_div_value(i64, double)

declare double @js_decimal_eq(i64, i64)

declare double @js_decimal_eq_value(i64, double)

declare i64 @js_decimal_floor(i64)

declare i64 @js_decimal_from_number(double)

declare i64 @js_decimal_from_string(i64)

declare double @js_decimal_gt(i64, i64)

declare double @js_decimal_gt_value(i64, double)

declare double @js_decimal_gte(i64, i64)

declare double @js_decimal_gte_value(i64, double)

declare double @js_decimal_is_negative(i64)

declare double @js_decimal_is_positive(i64)

declare double @js_decimal_is_zero(i64)

declare double @js_decimal_lt(i64, i64)

declare double @js_decimal_lt_value(i64, double)

declare double @js_decimal_lte(i64, i64)

declare double @js_decimal_lte_value(i64, double)

declare i64 @js_decimal_minus(i64, i64)

declare i64 @js_decimal_minus_number(i64, double)

declare i64 @js_decimal_minus_value(i64, double)

declare i64 @js_decimal_mod(i64, i64)

declare i64 @js_decimal_mod_value(i64, double)

declare i64 @js_decimal_neg(i64)

declare i64 @js_decimal_plus(i64, i64)

declare i64 @js_decimal_plus_number(i64, double)

declare i64 @js_decimal_plus_value(i64, double)

declare i64 @js_decimal_pow(i64, double)

declare i64 @js_decimal_round(i64)

declare i64 @js_decimal_sqrt(i64)

declare i64 @js_decimal_times(i64, i64)

declare i64 @js_decimal_times_number(i64, double)

declare i64 @js_decimal_times_value(i64, double)

declare i64 @js_decimal_to_fixed(i64, double)

declare double @js_decimal_to_number(i64)

declare i64 @js_decimal_to_string(i64)

declare i64 @js_ethers_format_ether(i64)

declare i64 @js_ethers_format_units(i64, double)

declare i64 @js_ethers_get_address(i64)

declare i64 @js_ethers_parse_ether(i64)

declare i64 @js_ethers_parse_units(i64, double)

declare i64 @js_lodash_camel_case(i64)

declare i64 @js_lodash_capitalize(i64)

declare i64 @js_lodash_chunk(i64, double)

declare double @js_lodash_clamp(double, double, double)

declare i64 @js_lodash_compact(i64)

declare i64 @js_lodash_concat(i64, i64)

declare i64 @js_lodash_difference(i64, i64)

declare i64 @js_lodash_drop(i64, double)

declare i64 @js_lodash_drop_right(i64, double)

declare double @js_lodash_ends_with(i64, i64)

declare i64 @js_lodash_escape(i64)

declare double @js_lodash_first(i64)

declare i64 @js_lodash_flatten(i64)

declare double @js_lodash_in_range(double, double, double)

declare double @js_lodash_includes(i64, i64)

declare i64 @js_lodash_initial(i64)

declare i64 @js_lodash_kebab_case(i64)

declare double @js_lodash_last(i64)

declare i64 @js_lodash_lower_case(i64)

declare i64 @js_lodash_lower_first(i64)

declare double @js_lodash_max(i64)

declare double @js_lodash_max_by(i64, double)

declare double @js_lodash_mean(i64)

declare double @js_lodash_mean_by(i64, double)

declare double @js_lodash_min(i64)

declare double @js_lodash_min_by(i64, double)

declare i64 @js_lodash_pad(i64, double)

declare i64 @js_lodash_pad_end(i64, double)

declare i64 @js_lodash_pad_start(i64, double)

declare double @js_lodash_random(double, double)

declare i64 @js_lodash_repeat(i64, double)

declare i64 @js_lodash_replace(i64, i64, i64)

declare i64 @js_lodash_reverse(i64)

declare double @js_lodash_size(i64)

declare i64 @js_lodash_snake_case(i64)

declare i64 @js_lodash_split(i64, i64)

declare i64 @js_lodash_start_case(i64)

declare double @js_lodash_starts_with(i64, i64)

declare double @js_lodash_sum(i64)

declare double @js_lodash_sum_by(i64, double)

declare i64 @js_lodash_tail(i64)

declare i64 @js_lodash_take(i64, double)

declare i64 @js_lodash_take_right(i64, double)

declare i64 @js_lodash_trim(i64)

declare i64 @js_lodash_trim_end(i64)

declare i64 @js_lodash_trim_start(i64)

declare i64 @js_lodash_truncate(i64, double)

declare i64 @js_lodash_unescape(i64)

declare i64 @js_lodash_uniq(i64)

declare i64 @js_lodash_upper_case(i64)

declare i64 @js_lodash_upper_first(i64)

declare void @js_lru_cache_clear(i64)

declare double @js_lru_cache_delete(i64, double)

declare double @js_lru_cache_get(i64, double)

declare double @js_lru_cache_has(i64, double)

declare i64 @js_lru_cache_new(double)

declare double @js_lru_cache_peek(i64, double)

declare i64 @js_lru_cache_set(i64, double, double)

declare double @js_lru_cache_size(i64)

declare double @js_event_emitter_subclass_init(double)

declare double @js_event_emitter_async_resource_subclass_init(double, double)

declare double @js_array_subclass_init(double, double)

declare double @js_array_subclass_init_args(double, ptr, i64)

declare double @js_map_set_subclass_init(double, i32, double)

declare double @js_weak_collection_subclass_init(double, i32, double)

declare double @js_promise_subclass_init(double, double)

declare double @js_node_stream_readable_new(double)

declare double @js_node_stream_readable_subclass_init(double, double)

declare double @js_node_stream_writable_new(double)

declare double @js_node_stream_writable_subclass_init(double, double)

declare double @js_node_stream_duplex_new(double)

declare double @js_node_stream_duplex_subclass_init(double, double)

declare double @js_node_stream_transform_new(double)

declare double @js_node_stream_transform_subclass_init(double, double)

declare double @js_node_stream_passthrough_new(double)

declare double @js_node_stream_readable_from(double)

declare double @js_node_stream_readable_from_options(double, double)

declare double @js_node_stream_duplex_from_options(double, double)

declare double @js_node_stream_is_disturbed(double)

declare double @js_node_stream_is_errored(double)

declare double @js_node_stream_is_readable(double)

declare double @js_node_stream_is_writable(double)

declare double @js_node_stream_is_array_buffer_view(double)

declare double @js_node_stream_is_uint8_array(double)

declare double @js_node_stream_is_destroyed(double)

declare double @js_node_stream_uint8_array_to_buffer(double)

declare double @js_node_stream_get_default_hwm(double)

declare double @js_node_stream_set_default_hwm(double, double)

declare double @js_node_stream_add_abort_signal(double, double)

declare double @js_node_stream_compose(i64)

declare double @js_node_stream_pipeline(i64)

declare double @js_node_stream_finished(i64)

declare double @js_node_stream_duplex_pair(double)

declare double @js_node_stream_readable_to_web(double)

declare double @js_node_stream_writable_to_web(double)

declare double @js_node_stream_duplex_to_web(double)

declare double @js_node_stream_readable_from_web(double, double)

declare double @js_node_stream_writable_from_web(double, double)

declare double @js_node_stream_duplex_from_web(double, double)

declare double @js_node_stream_to_web(double)

declare double @js_node_stream_from_web(double)

declare double @js_node_stream_method_readable_aborted(i64)

declare double @js_node_stream_method_closed(i64)

declare double @js_node_stream_method_errored(i64)

declare double @js_node_stream_method_readable_did_read(i64)

declare double @js_node_stream_method_destroyed(i64)

declare double @js_node_stream_method_destroy(i64, double)

declare double @js_node_stream_method_pause(i64)

declare double @js_node_stream_method_readable(i64)

declare double @js_node_stream_method_readable_length(i64)

declare double @js_node_stream_method_readable_flowing(i64)

declare double @js_node_stream_method_readable_ended(i64)

declare double @js_node_stream_method_readable_object_mode(i64)

declare double @js_node_stream_method_pipe(i64, double, double)

declare double @js_node_stream_method_unpipe(i64, double)

declare double @js_node_stream_method_is_paused(i64)

declare double @js_node_stream_method_resume(i64)

declare double @js_node_stream_method_readable_encoding(i64)

declare double @js_node_stream_method_cork(i64)

declare double @js_node_stream_method_uncork(i64)

declare double @js_node_stream_method_writable_corked(i64)

declare double @js_node_stream_method_writable_length(i64)

declare double @js_node_stream_method_writable_need_drain(i64)

declare double @js_node_stream_method_writable(i64)

declare double @js_node_stream_method_writable_ended(i64)

declare double @js_node_stream_method_writable_finished(i64)

declare double @js_node_stream_method_allow_half_open(i64)

declare double @js_node_stream_method_set_encoding(i64, double)

declare double @js_node_stream_method_writable_object_mode(i64)

declare double @js_event_emitter_emit(i64, i64, i64)

declare double @js_event_emitter_emit0(i64, i64)

declare double @js_event_emitter_listener_count(i64, i64, i64)

declare i64 @js_event_emitter_new()

declare i64 @js_event_emitter_new_with_options(double)

declare i64 @js_event_emitter_on(i64, i64, i64)

declare i64 @js_event_emitter_once(i64, i64, i64)

declare i64 @js_event_emitter_prepend_listener(i64, i64, i64)

declare i64 @js_event_emitter_prepend_once_listener(i64, i64, i64)

declare i64 @js_event_emitter_remove_all_listeners(i64, i64)

declare i64 @js_event_emitter_remove_listener(i64, i64, i64)

declare i64 @js_event_emitter_set_max_listeners(i64, double)

declare double @js_event_emitter_get_max_listeners(i64)

declare i64 @js_event_emitter_event_names(i64)

declare i64 @js_event_emitter_listeners(i64, i64)

declare i64 @js_event_emitter_raw_listeners(i64, i64)

declare double @js_event_emitter_domain_value(i64)

declare i64 @js_event_emitter_async_resource_new(double)

declare double @js_event_emitter_async_resource_call(double)

declare double @js_event_emitter_async_resource_async_id(i64)

declare double @js_event_emitter_async_resource_trigger_async_id(i64)

declare double @js_event_emitter_async_resource_async_resource(i64)

declare double @js_event_emitter_async_resource_emit_destroy(i64)

declare i64 @js_events_once(double, i64, double)

declare i64 @js_events_on(double, i64, double)

declare i64 @js_events_add_abort_listener(double, double)

declare i64 @js_events_get_event_listeners(double, i64)

declare double @js_events_listener_count(double, i64)

declare double @js_events_get_max_listeners(double)

declare double @js_events_set_max_listeners(double, i64)

declare double @js_events_init()

declare i64 @js_domain_create()

declare i64 @js_domain_on(i64, i64, i64)

declare double @js_domain_emit(i64, i64, i64)

declare double @js_domain_run(i64, double, i64)

declare double @js_domain_bind(i64, double)

declare double @js_domain_intercept(i64, double)

declare i64 @js_domain_add(i64, double)

declare i64 @js_domain_remove(i64, double)

declare double @js_domain_enter(i64)

declare double @js_domain_exit(i64)

declare i64 @js_string_decoder_new(i64)

declare double @js_string_decoder_write(i64, double)

declare double @js_string_decoder_end(i64, double)

declare double @js_querystring_escape(double)

declare double @js_querystring_unescape(double)

declare i64 @js_querystring_unescape_buffer(double, double)

declare i64 @js_querystring_parse(double, double, double, double)

declare double @js_querystring_stringify(double, double, double, double)

declare i32 @js_fastify_add_hook(i64, i64, i64)

declare i32 @js_fastify_all(i64, i64, i64)

declare i64 @js_fastify_create()

declare i64 @js_fastify_create_with_opts(double)

declare double @js_fastify_ctx_html(i64, i64, double)

declare double @js_fastify_ctx_json(i64, double, double)

declare double @js_fastify_ctx_redirect(i64, i64, double)

declare double @js_fastify_ctx_text(i64, i64, double)

declare i32 @js_fastify_delete(i64, i64, i64)

declare i32 @js_fastify_get(i64, i64, i64)

declare i32 @js_fastify_head(i64, i64, i64)

declare void @js_fastify_listen(i64, double, i64)

declare void @js_fastify_app_close(i64)

declare i64 @js_fastify_app_server(i64)

declare void @js_fastify_app_on(i64, i64, i64)

declare i32 @js_fastify_options(i64, i64, i64)

declare i32 @js_fastify_patch(i64, i64, i64)

declare i32 @js_fastify_post(i64, i64, i64)

declare i32 @js_fastify_put(i64, i64, i64)

declare i32 @js_fastify_register(i64, i64, double)

declare i64 @js_fastify_reply_header(i64, i64, i64)

declare i32 @js_fastify_reply_send(i64, double)

declare i64 @js_fastify_reply_status(i64, double)

declare i64 @js_fastify_reply_type(i64, i64)

declare i64 @js_fastify_req_body(i64)

declare double @js_fastify_req_get_user_data(i64)

declare i64 @js_fastify_req_header(i64, i64)

declare i64 @js_fastify_req_headers(i64)

declare double @js_fastify_req_json(i64)

declare i64 @js_fastify_req_method(i64)

declare i64 @js_fastify_req_param(i64, i64)

declare i64 @js_fastify_req_params(i64)

declare i64 @js_fastify_req_query(i64)

declare double @js_fastify_req_query_object(i64)

declare void @js_fastify_req_set_user_data(i64, double)

declare i64 @js_fastify_req_url(i64)

declare i32 @js_fastify_route(i64, i64, i64, i64)

declare i32 @js_fastify_set_error_handler(i64, i64)

declare double @js_nodemailer_create_transport(i64)

declare i64 @js_nodemailer_send_mail(i64, i64)

declare i64 @js_nodemailer_verify(i64)

declare i64 @js_ratelimit_block(i64, i64, double)

declare i64 @js_ratelimit_consume(i64, i64, double)

declare i64 @js_ratelimit_create(i64)

declare i64 @js_ratelimit_delete(i64, i64)

declare i64 @js_ratelimit_get(i64, i64)

declare i64 @js_ratelimit_new_from_options(i64)

declare i64 @js_ratelimit_penalty(i64, i64, double)

declare i64 @js_ratelimit_reward(i64, i64, double)

declare double @js_validator_contains(i64, i64)

declare double @js_validator_equals(i64, i64)

declare double @js_validator_is_alpha(i64)

declare double @js_validator_is_alphanumeric(i64)

declare double @js_validator_is_email(i64)

declare double @js_validator_is_empty(i64)

declare double @js_validator_is_float(i64)

declare double @js_validator_is_hexadecimal(i64)

declare double @js_validator_is_int(i64)

declare double @js_validator_is_json(i64)

declare double @js_validator_is_length(i64, double, double)

declare double @js_validator_is_lowercase(i64)

declare double @js_validator_is_numeric(i64)

declare double @js_validator_is_uppercase(i64)

declare double @js_validator_is_url(i64)

declare double @js_validator_is_uuid(i64)

declare i64 @js_date_to_locale_string(double)

declare i64 @js_number_to_locale_string(double)

declare double @js_value_to_locale_string(double)

declare i64 @js_string_split_regex(i64, i64)

declare i32 @js_object_delete_dynamic(i64, double)

declare double @js_object_get_prototype_of(double)

declare double @js_object_set_prototype_of(double, double)

declare double @js_object_define_properties(double, double)

declare double @js_math_acos(double)

declare double @js_math_asin(double)

declare double @js_math_atan(double)

declare double @js_math_atan2(double, double)

declare double @js_math_cos(double)

declare double @js_math_expm1(double)

declare double @js_math_log(double)

declare double @js_math_log10(double)

declare double @js_math_log1p(double)

declare double @js_math_log2(double)

declare double @js_math_sin(double)

declare double @js_math_tan(double)

declare double @js_atomics_load(ptr, double, double)

declare double @js_atomics_is_lock_free(ptr, double)

declare double @js_atomics_store(ptr, double, double, double)

declare double @js_atomics_add(ptr, double, double, double)

declare double @js_atomics_sub(ptr, double, double, double)

declare double @js_atomics_and(ptr, double, double, double)

declare double @js_atomics_or(ptr, double, double, double)

declare double @js_atomics_xor(ptr, double, double, double)

declare double @js_atomics_exchange(ptr, double, double, double)

declare double @js_atomics_compare_exchange(ptr, double, double, double, double)

declare double @js_atomics_notify(ptr, double, double, double)

declare double @js_atomics_wait(ptr, double, double, double, double)

declare double @js_atomics_wait_async(ptr, double, double, double, double)

declare double @js_number_is_finite(double)

declare double @js_json_get_bool(i64, i64)

declare double @js_json_get_number(i64, i64)

declare i64 @js_json_get_string(i64, i64)

declare double @js_json_is_valid(i64)

declare i64 @js_json_stringify_bool(double)

declare i64 @js_json_stringify_null()

declare i64 @js_json_stringify_number(double)

declare i64 @js_json_stringify_string(i64)

declare void @js_set_property(double, i64, i64, double)

declare i64 @js_error_get_message(i64)

declare double @js_await_js_promise(double)

declare i64 @js_text_decoder_decode(i64)

declare i64 @js_text_encoder_encode(double)

declare double @js_call_function(i64, i64, i64, i64, i64)

declare double @js_call_method(double, i64, i64, i64, i64)

declare double @js_call_value(double, i64, i64)

declare double @js_closure_call_array(i64, ptr, i64)

declare double @js_closure_call_apply_with_spread(double, ptr, i64, i64)

declare double @js_create_callback(i64, i64, i64)

declare double @js_dynamic_neg(double)

declare double @js_dynamic_pos(double)

declare i32 @js_dynamic_string_equals(double, double)

declare double @js_is_nan(double)

declare i32 @js_jsvalue_compare(double, double)

declare i32 @js_jsvalue_loose_equals(double, double)

declare void @js_gc_collect()

declare void @js_console_assert(double, i64)

declare void @js_console_assert_spread(double, i64)

declare void @js_console_group(i64)

declare double @js_console_context(double)

declare double @js_console_create_task(double)

declare i64 @js_fetch_input_ptr(double)

declare i64 @js_fetch_get(i64)

declare i64 @js_fetch_get_with_auth(i64, i64)

declare i64 @js_fetch_post(i64, i64, i64)

declare i64 @js_fetch_post_with_auth(i64, i64, i64)

declare double @js_fetch_stream_close(double)

declare i64 @js_fetch_stream_poll(double)

declare double @js_fetch_stream_start(i64, i64, i64, i64)

declare double @js_fetch_stream_status(double)

declare i64 @js_fetch_text(i64)

declare i64 @js_fetch_with_options(i64, i64, i64, i64)

declare void @js_fetch_set_pending_signal(double)

declare i64 @js_fetch_headers_to_json(double)

declare double @js_net_create_connection(i32, i64, i64)

declare i64 @js_net_create_server(i64, i64)

declare i64 @js_ext_net_create_server(i64, i64)

declare i64 @js_ext_net_socket_connect(double, double, double)

declare double @js_net_normalize_args(double)

declare double @js_net_create_server_handle_stub(double, double, double, double, double)

declare void @js_net_validate_create_server_options(double)

declare i64 @js_net_socket_set_timeout(i64, double, i64)

declare void @js_net_server_listen(i64, double, double, double)

declare void @js_net_server_close(i64, i64)

declare i64 @js_net_server_address(i64)

declare void @js_net_server_on(i64, i64, i64)

declare double @js_net_server_get_listening(i64)

declare double @js_net_server_get_connections(i64)

declare double @js_net_server_get_max_connections(i64)

declare double @js_net_server_set_max_connections(i64, double)

declare double @js_net_server_get_drop_max_connection(i64)

declare double @js_net_server_set_drop_max_connection(i64, double)

declare i64 @js_net_block_list_new()

declare double @js_net_block_list_is_block_list(double)

declare double @js_net_block_list_add_address(i64, i64, i64)

declare double @js_net_block_list_add_range(i64, i64, i64, i64)

declare double @js_net_block_list_add_subnet(i64, i64, double, i64)

declare double @js_net_block_list_check(i64, i64, i64)

declare double @js_net_block_list_to_json(i64)

declare i64 @js_net_block_list_rules(i64)

declare double @js_net_block_list_from_json(i64, double)

declare i64 @js_net_socket_address_new(double)

declare double @js_net_socket_address_parse(i64)

declare i64 @js_net_socket_address_get_address(i64)

declare i64 @js_net_socket_address_get_family(i64)

declare double @js_net_socket_address_get_port(i64)

declare double @js_net_socket_address_get_flowlabel(i64)

declare double @js_net_socket_get_type_of_service(i64)

declare i64 @js_net_socket_set_type_of_service(i64, double)

declare i64 @js_net_socket_address(i64)

declare i64 @js_net_socket_once(i64, i64, i64)

declare i64 @js_ext_net_socket_once(i64, i64, i64)

declare void @js_ext_net_socket_on(i64, i64, i64)

declare i64 @js_ext_tls_connect(double, double, double, double)

declare i64 @js_net_socket_remove_listener(i64, i64, i64)

declare i64 @js_net_socket_remove_all_listeners(i64, i64)

declare double @js_net_socket_listener_count(i64, i64)

declare i64 @js_net_socket_event_names(i64)

declare i64 @js_net_socket_reset_and_destroy(i64)

declare i64 @js_net_server_once(i64, i64, i64)

declare i64 @js_net_server_remove_listener(i64, i64, i64)

declare i64 @js_net_server_remove_all_listeners(i64, i64)

declare double @js_net_server_listener_count(i64, i64)

declare i64 @js_net_server_event_names(i64)

declare double @js_performance_now()

declare double @js_perf_mark(double, double)

declare double @js_perf_measure(double, double, double)

declare double @js_perf_get_entries()

declare double @js_perf_get_entries_by_type(double)

declare double @js_perf_get_entries_by_name(double, double)

declare double @js_perf_clear_marks(double)

declare double @js_perf_clear_measures(double)

declare double @js_perf_event_loop_utilization(double, double)

declare double @js_perf_to_json()

declare double @js_perf_clear_resource_timings()

declare double @js_perf_set_resource_timing_buffer_size(double)

declare double @js_perf_mark_resource_timing(double, double, double, double, double, double, double, double)

declare double @js_perf_timerify(double, double)

declare double @js_perf_observer_new(double)

declare double @js_perf_observer_observe(double, double)

declare double @js_perf_observer_disconnect(double)

declare double @js_perf_observer_take_records(double)

declare double @js_perf_monitor_event_loop_delay(double)

declare double @js_perf_create_histogram(double)

declare double @js_iter_result_set(double, i32)

declare double @js_iter_result_set_f64(double, i32)

declare double @js_iter_result_set_i32(i32, i32)

declare double @js_iter_result_set_i1(i32, i32)

declare double @js_iter_result_get_value()

declare double @js_iter_result_get_value_f64()

declare i32 @js_iter_result_get_value_i32()

declare i32 @js_iter_result_get_value_i1()

declare double @js_iter_result_get_done()

declare i64 @js_async_step_chain(double, i64)

declare i64 @js_async_step_done(double, i64)

declare i64 @js_get_current_step_closure()

declare double @js_async_first_call(double)

declare double @js_async_generator_resume(double, double, double)

declare void @js_register_class_getter(i64, i64, i64, i64)

declare void @js_register_class_setter(i64, i64, i64, i64)

declare void @js_register_class_string_member_order(i64, i64, i64, i64, i64)

declare void @js_register_class_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_getter(i64, i64, i64, i64)

declare void @js_register_class_static_setter(i64, i64, i64, i64)

declare void @js_register_class_method(i64, i64, i64, i64, i64, i64, i64)

declare void @js_register_class_constructor(i64, i64, i64, i64)

declare void @js_register_class_constructor_flags(i64, i64, i64)

declare void @js_register_class_static_method(i64, i64, i64, i64, i64, i64)

declare double @js_class_static_method_call(double, i64, i64, ptr, i64)

declare double @js_class_method_bind(double, i64, i64)

declare double @js_class_method_snapshot_bind(double, i64, i64)

declare double @js_class_method_bind_by_id(double, i64)

declare double @js_class_lexical_binding_get(double)

declare double @js_class_lexical_binding_set(double, double)

declare double @js_class_prototype_method_value(double, double)

declare double @js_implicit_this_get()

declare double @js_implicit_this_get_sloppy()

declare double @js_implicit_this_set(double)

declare double @js_static_this_resolve(double)

declare void @js_static_this_arm_classref(i32)

declare void @js_static_this_arm_value(double)

declare double @js_ctor_return_override(double, double, i32)

declare double @js_new_target_get()

declare double @js_new_target_set(double)

declare void @js_derived_super_scope_push(ptr)

declare void @js_derived_super_scope_pop()

declare double @js_derived_super_bind_current()

declare double @js_derived_this_check_current()

declare double @js_get_export(i64, i64, i64)

declare double @js_get_property(double, i64, i64)

declare i64 @js_load_module(i64, i64)

declare double @js_module_dynamic_import_apply_hooks(double)

declare double @js_native_call_method_nullsafe(double, i64, i64, i64, i64)

declare double @js_native_call_value(double, i64, i64)

declare double @js_new_from_handle(double, i64, i64)

declare double @js_new_instance(i64, i64, i64, i64, i64)

declare void @js_runtime_init()

declare double @js_object_set_symbol_method(double, double, double)

declare double @js_object_set_method_by_name(double, double, double)

declare double @js_object_define_accessor(double, double, double, double)

declare double @js_object_literal_set_computed(double, double, double)

declare double @js_object_literal_to_property_key(double)

declare double @js_object_literal_set_prototype(double, double)

declare double @js_to_primitive(double, i32)

declare void @js_register_class_has_instance(i32, i64)

declare void @js_register_class_to_string_tag(i32, i64)

declare double @js_object_to_string(double)

declare double @js_object_group_by(double, double)

declare double @js_map_group_by(double, double)

declare double @js_array_from_async(double, double, double)

declare double @js_jsx(double, double)

declare double @js_jsxs(double, double)

declare i64 @js_node_http_server_ref(i64)

declare i64 @js_node_http_server_unref(i64)

declare i64 @js_node_https_server_ref(i64)

declare i64 @js_node_https_server_unref(i64)

declare double @js_http_client_request_flush_headers(i64, double, double)

declare double @js_node_http_im_http_version_major(i64)

declare double @js_node_http_im_http_version_minor(i64)

declare i64 @js_node_http_im_pause_self(i64)

declare i64 @js_node_http_im_resume_self(i64)

declare i64 @js_commander_args_array(i64)

declare i64 @js_commander_argument(i64, i64)

declare double @__ic_decl_5()

declare double @__ic_decl_8()

declare double @__ic_decl_10()

declare double @__ic_decl_13()

declare double @__ic_decl_18()

declare double @__ic_decl_22()

declare double @__ic_decl_24()

declare double @__ic_decl_26()

declare double @__ic_decl_28()

declare double @__ic_decl_32()

declare double @__ic_decl_34()

declare token @llvm.experimental.gc.statepoint.p0(i64 immarg, i32 immarg, ptr, i32 immarg, i32 immarg, ...)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token, i32 immarg, i32 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.experimental.gc.result.i1(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i8 @llvm.experimental.gc.result.i8(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i16 @llvm.experimental.gc.result.i16(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.experimental.gc.result.i32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i64 @llvm.experimental.gc.result.i64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i128 @llvm.experimental.gc.result.i128(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.experimental.gc.result.f32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare double @llvm.experimental.gc.result.f64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr @llvm.experimental.gc.result.p0(token) #3

; Function Attrs: optsize
define internal double @__perry_wrap_perry_unknown_func_test_json_source_token_length_ts(i64 %this_closure, double %a0, double %a1, double %a2, double %a3, double %a4) #6 {
entry.0:
  ret double 0x7FFC000000000001
}

; Function Attrs: optsize
define void @test_json_source_token_length_ts__init() #6 {
entry.0:
  ret void
}

; Function Attrs: optsize
define i32 @main() #6 gc "statepoint-example" {
entry.0:
  %r266 = alloca [32 x double], align 8
  %r459 = alloca [32 x double], align 8
  %r652 = alloca [32 x double], align 8
  %r852 = alloca [32 x double], align 8
  %r1996 = alloca [32 x double], align 8
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (ptr, i32)) @js_set_process_entry_path, i32 2, i32 0, ptr @test_json_source_token_length_ts_.str.0, i32 91, i32 0, i32 0)
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_init, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token2 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32)) @js_gc_write_barriers_emitted, i32 1, i32 0, i32 1, i32 0, i32 0)
  %statepoint_token3 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @perry_macos_bundle_chdir, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token4 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @__perry_init_strings_test_json_source_token_length_ts, i32 0, i32 0, i32 0, i32 0)
  %r2 = load double, ptr @test_json_source_token_length_ts_.str.0.handle, align 8
  %r3 = load double, ptr @test_json_source_token_length_ts_.str.1.handle, align 8
  %r4 = load double, ptr @test_json_source_token_length_ts_.str.2.handle, align 8
  br label %arena_state.init.1

arena_state.init.1:                               ; preds = %entry.0
  %r8 = load atomic i64, ptr @PERRY_HOT_TSD_KEY monotonic, align 8
  %r9 = icmp ne i64 %r8, -1
  br i1 %r9, label %arena_state.hot_tls.tsd.3, label %arena_state.hot_tls.slow.5

arena_state.ready.2:                              ; preds = %arena_state.hot_tls.resolved.7
  %r24 = getelementptr i8, ptr %r22, i64 8
  %r25 = load i64, ptr %r24, align 8
  %r26 = add i64 %r25, 40
  %r27 = getelementptr i8, ptr %r22, i64 16
  %r28 = load i64, ptr %r27, align 8
  %r29 = icmp ule i64 %r26, %r28
  br i1 %r29, label %arrlit.fast.8, label %arrlit.slow.9

arena_state.hot_tls.tsd.3:                        ; preds = %arena_state.init.1
  %r10 = call i64 asm sideeffect "mrs $0, tpidrro_el0", "=r"() #7
  %r11 = and i64 %r10, -8
  %r12 = shl i64 %r8, 3
  %r13 = add i64 %r11, %r12
  %r14 = inttoptr i64 %r13 to ptr
  %r15 = load ptr, ptr %r14, align 8
  %r16 = icmp ne ptr %r15, null
  br i1 %r16, label %arena_state.hot_tls.fast.4, label %arena_state.hot_tls.slow.5

arena_state.hot_tls.fast.4:                       ; preds = %arena_state.hot_tls.tsd.3
  %r17 = getelementptr i8, ptr %r15, i64 8
  %r18 = load ptr, ptr %r17, align 8
  %r19 = load ptr, ptr %r18, align 8
  %r20 = icmp ne ptr %r19, null
  br i1 %r20, label %arena_state.hot_tls.ready.6, label %arena_state.hot_tls.slow.5

arena_state.hot_tls.slow.5:                       ; preds = %arena_state.hot_tls.fast.4, %arena_state.hot_tls.tsd.3, %arena_state.init.1
  %statepoint_token5 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr ()) @js_inline_arena_state, i32 0, i32 0, i32 0, i32 0)
  %r2147 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token5)
  br label %arena_state.hot_tls.resolved.7

arena_state.hot_tls.ready.6:                      ; preds = %arena_state.hot_tls.fast.4
  br label %arena_state.hot_tls.resolved.7

arena_state.hot_tls.resolved.7:                   ; preds = %arena_state.hot_tls.ready.6, %arena_state.hot_tls.slow.5
  %r22 = phi ptr [ %r18, %arena_state.hot_tls.ready.6 ], [ %r2147, %arena_state.hot_tls.slow.5 ]
  br label %arena_state.ready.2

arrlit.fast.8:                                    ; preds = %arena_state.ready.2
  store i64 %r26, ptr %r24, align 8
  %r30 = load ptr, ptr %r22, align 8
  %r31 = getelementptr i8, ptr %r30, i64 %r25
  br label %arrlit.merge.10

arrlit.slow.9:                                    ; preds = %arena_state.ready.2
  %statepoint_token48 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr (ptr, i64, i64)) @js_inline_arena_slow_alloc, i32 3, i32 0, ptr %r22, i64 40, i64 8, i32 0, i32 0)
  %r32100 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token48)
  br label %arrlit.merge.10

arrlit.merge.10:                                  ; preds = %arrlit.slow.9, %arrlit.fast.8
  %r33 = phi ptr [ %r31, %arrlit.fast.8 ], [ %r32100, %arrlit.slow.9 ]
  store i64 172872434177, ptr %r33, align 8
  %r34 = getelementptr i8, ptr %r33, i64 8
  store i64 12884901891, ptr %r34, align 8
  %r35 = getelementptr i8, ptr %r33, i64 8
  %r36 = ptrtoint ptr %r35 to i64
  %r37 = getelementptr inbounds nuw i8, ptr %r33, i64 16
  %r4449 = load double, ptr @test_json_source_token_length_ts_.str.0.handle, align 8
  store double %r4449, ptr %r37, align 8
  %r4448 = load double, ptr @test_json_source_token_length_ts_.str.0.handle, align 8
  call void @js_string_addref_if_heap_string(double %r4448) #7
  %r4447 = load double, ptr @test_json_source_token_length_ts_.str.0.handle, align 8
  %r38 = bitcast double %r4447 to i64
  %r4445 = load double, ptr @test_json_source_token_length_ts_.str.0.handle, align 8
  %r4446 = bitcast double %r4445 to i64
  call void @js_gc_note_slot_layout(i64 %r36, i32 0, i64 %r4446) #7
  %r39 = getelementptr inbounds nuw i8, ptr %r33, i64 24
  %r4444 = load double, ptr @test_json_source_token_length_ts_.str.1.handle, align 8
  store double %r4444, ptr %r39, align 8
  %r4443 = load double, ptr @test_json_source_token_length_ts_.str.1.handle, align 8
  call void @js_string_addref_if_heap_string(double %r4443) #7
  %r4442 = load double, ptr @test_json_source_token_length_ts_.str.1.handle, align 8
  %r40 = bitcast double %r4442 to i64
  %r4440 = load double, ptr @test_json_source_token_length_ts_.str.1.handle, align 8
  %r4441 = bitcast double %r4440 to i64
  call void @js_gc_note_slot_layout(i64 %r36, i32 1, i64 %r4441) #7
  %r41 = getelementptr inbounds nuw i8, ptr %r33, i64 32
  %r4439 = load double, ptr @test_json_source_token_length_ts_.str.2.handle, align 8
  store double %r4439, ptr %r41, align 8
  %r4438 = load double, ptr @test_json_source_token_length_ts_.str.2.handle, align 8
  call void @js_string_addref_if_heap_string(double %r4438) #7
  %r4437 = load double, ptr @test_json_source_token_length_ts_.str.2.handle, align 8
  %r42 = bitcast double %r4437 to i64
  %r4435 = load double, ptr @test_json_source_token_length_ts_.str.2.handle, align 8
  %r4436 = bitcast double %r4435 to i64
  call void @js_gc_note_slot_layout(i64 %r36, i32 2, i64 %r4436) #7
  %r43 = or i64 %r36, 9222527611924643840
  %r44 = bitcast i64 %r43 to double
  %rs4gc.b12 = bitcast double %r44 to i64
  %rs4gc.s12 = inttoptr i64 %rs4gc.b12 to ptr addrspace(1)
  %r45.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12 to i64
  %r45 = call i64 asm "", "=r,0"(i64 %r45.rs4i) #7
  %r46 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r47 = icmp ne i32 %r46, 0
  br i1 %r47, label %shadow.root.barrier.11, label %shadow.root.barrier.done.12

shadow.root.barrier.11:                           ; preds = %arrlit.merge.10
  call void @js_write_barrier_root_nanbox(i64 %r45) #7
  br label %shadow.root.barrier.done.12

shadow.root.barrier.done.12:                      ; preds = %shadow.root.barrier.11, %arrlit.merge.10
  %statepoint_token101 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s12) ]
  %r49102 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token101)
  %rs4gc.s12.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token101, i32 0, i32 0) ; (%rs4gc.s12, %rs4gc.s12)
  %r50 = or i64 %r49102, 9222527611924643840
  %r51 = bitcast i64 %r50 to double
  %rs4gc.b13 = bitcast double %r51 to i64
  %rs4gc.s13 = inttoptr i64 %rs4gc.b13 to ptr addrspace(1)
  %r52.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13 to i64
  %r52 = call i64 asm "", "=r,0"(i64 %r52.rs4i) #7
  %r53 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r54 = icmp ne i32 %r53, 0
  br i1 %r54, label %shadow.root.barrier.13, label %shadow.root.barrier.done.14

shadow.root.barrier.13:                           ; preds = %shadow.root.barrier.done.12
  call void @js_write_barrier_root_nanbox(i64 %r52) #7
  br label %shadow.root.barrier.done.14

shadow.root.barrier.done.14:                      ; preds = %shadow.root.barrier.13, %shadow.root.barrier.done.12
  %statepoint_token103 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13, ptr addrspace(1) %rs4gc.s12.relocated) ]
  %r56104 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token103)
  %rs4gc.s13.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token103, i32 0, i32 0) ; (%rs4gc.s13, %rs4gc.s13)
  %rs4gc.s12.relocated105 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token103, i32 1, i32 1) ; (%rs4gc.s12.relocated, %rs4gc.s12.relocated)
  %r57 = or i64 %r56104, 9222527611924643840
  %r58 = bitcast i64 %r57 to double
  %rs4gc.b14 = bitcast double %r58 to i64
  %rs4gc.s14 = inttoptr i64 %rs4gc.b14 to ptr addrspace(1)
  %r59.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r59 = call i64 asm "", "=r,0"(i64 %r59.rs4i) #7
  %r60 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r61 = icmp ne i32 %r60, 0
  br i1 %r61, label %shadow.root.barrier.15, label %shadow.root.barrier.done.16

shadow.root.barrier.15:                           ; preds = %shadow.root.barrier.done.14
  call void @js_write_barrier_root_nanbox(i64 %r59) #7
  br label %shadow.root.barrier.done.16

shadow.root.barrier.done.16:                      ; preds = %shadow.root.barrier.15, %shadow.root.barrier.done.14
  br label %for.cond.17

for.cond.17:                                      ; preds = %for.update.19, %shadow.root.barrier.done.16
  %.0 = phi ptr addrspace(1) [ %rs4gc.s12.relocated105, %shadow.root.barrier.done.16 ], [ %.13, %for.update.19 ]
  %r62.0 = phi i32 [ 0, %shadow.root.barrier.done.16 ], [ %r1043, %for.update.19 ]
  %r55.0.base = phi ptr addrspace(1) [ %rs4gc.s14, %shadow.root.barrier.done.16 ], [ %.01469, %for.update.19 ], !is_base_value !0
  %r55.0 = phi ptr addrspace(1) [ %rs4gc.s14, %shadow.root.barrier.done.16 ], [ %.01470, %for.update.19 ]
  %r48.0.base = phi ptr addrspace(1) [ %rs4gc.s13.relocated, %shadow.root.barrier.done.16 ], [ %.11466, %for.update.19 ], !is_base_value !0
  %r48.0 = phi ptr addrspace(1) [ %rs4gc.s13.relocated, %shadow.root.barrier.done.16 ], [ %.11468, %for.update.19 ]
  %r64 = sitofp i32 %r62.0 to double
  %r65.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r65.rs4o = call i64 asm "", "=r,0"(i64 %r65.rs4i) #7
  %r65 = bitcast i64 %r65.rs4o to double
  %r66 = bitcast double %r65 to i64
  %r67 = and i64 %r66, 281474976710655
  %r68 = lshr i64 %r66, 48
  %r69 = and i64 %r68, 65533
  %r70 = icmp eq i64 %r69, 32765
  %r71 = icmp ugt i64 %r67, 1048575
  %r72 = and i1 %r70, %r71
  br i1 %r72, label %plen.check_gc.21, label %plen.slow.23

for.body.18:                                      ; preds = %gcpoll.done.43
  %r179.rs4i = ptrtoint ptr addrspace(1) %.3 to i64
  %r179.rs4o = call i64 asm "", "=r,0"(i64 %r179.rs4i) #7
  %r179 = bitcast i64 %r179.rs4o to double
  %r181 = bitcast double %r179 to i64
  %r182 = and i64 %r181, 281474976710655
  %r183 = lshr i64 %r181, 48
  %r184 = icmp eq i64 %r183, 32765
  %r185 = icmp ugt i64 %r182, 1048575
  %r186 = and i1 %r184, %r185
  br i1 %r186, label %arr.guard.deref.48, label %arr.fallback.45

for.update.19:                                    ; preds = %gcpoll.done.142
  %r1043 = add i32 %r62.0, 1
  %r1044 = sitofp i32 %r62.0 to double
  %r1045 = sitofp i32 %r1043 to double
  br label %for.cond.17

for.exit.20:                                      ; preds = %gcpoll.done.43
  %statepoint_token106 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.21266, ptr addrspace(1) %.21280, ptr addrspace(1) %.21333, ptr addrspace(1) %.21386) ]
  %r1047107 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token106)
  %r55.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token106, i32 0, i32 0) ; (%.21266, %.21266)
  %r48.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token106, i32 1, i32 1) ; (%.21280, %.21280)
  %r55.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token106, i32 0, i32 2) ; (%.21266, %.21333)
  %r48.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token106, i32 1, i32 3) ; (%.21280, %.21386)
  %r1048 = or i64 %r1047107, 9222527611924643840
  %r1049 = bitcast i64 %r1048 to double
  %rs4gc.b15 = bitcast double %r1049 to i64
  %rs4gc.s15 = inttoptr i64 %rs4gc.b15 to ptr addrspace(1)
  %r1050.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15 to i64
  %r1050 = call i64 asm "", "=r,0"(i64 %r1050.rs4i) #7
  %r1051 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1052 = icmp ne i32 %r1051, 0
  br i1 %r1052, label %shadow.root.barrier.143, label %shadow.root.barrier.done.144

plen.check_gc.21:                                 ; preds = %for.cond.17
  %r73 = sub nuw nsw i64 %r67, 8
  %r74 = inttoptr i64 %r73 to ptr
  %r75 = load i8, ptr %r74, align 1
  %r76 = icmp eq i8 %r75, 1
  %r77 = icmp eq i8 %r75, 3
  %r78 = or i1 %r76, %r77
  %r79 = sub nuw nsw i64 %r67, 7
  %r80 = inttoptr i64 %r79 to ptr
  %r81 = load i8, ptr %r80, align 1
  %r82 = and i8 %r81, -128
  %r83 = icmp eq i8 %r82, 0
  %r84 = and i1 %r78, %r83
  br i1 %r84, label %plen.fast.22, label %plen.slow.23

plen.fast.22:                                     ; preds = %plen.check_gc.21
  %r86 = inttoptr i64 %r67 to ptr
  %r87 = select i1 false, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r86
  %r88 = load i32, ptr %r87, align 4
  %r89 = uitofp i32 %r88 to double
  br label %plen.merge.24

plen.slow.23:                                     ; preds = %plen.check_gc.21, %for.cond.17
  %r90 = lshr i64 %r66, 48
  %r91 = icmp eq i64 %r90, 32765
  %r92 = icmp uge i64 %r67, 2199023255552
  %r93 = icmp ult i64 %r67, 140737488355328
  %r94 = and i1 %r91, %r92
  %r95 = and i1 %r94, %r93
  %r96 = load ptr, ptr @perry_ic_test_json_source_token_length_ts__0, align 8
  br i1 %r95, label %plen.ic.header.25, label %plen.ic.miss.37

plen.merge.24:                                    ; preds = %plen.ic.merge.38, %plen.fast.22
  %.01384 = phi ptr addrspace(1) [ %r48.0, %plen.fast.22 ], [ %.11385, %plen.ic.merge.38 ]
  %.01331 = phi ptr addrspace(1) [ %r55.0, %plen.fast.22 ], [ %.11332, %plen.ic.merge.38 ]
  %.01278 = phi ptr addrspace(1) [ %r48.0.base, %plen.fast.22 ], [ %.11279, %plen.ic.merge.38 ]
  %.01264 = phi ptr addrspace(1) [ %r55.0.base, %plen.fast.22 ], [ %.11265, %plen.ic.merge.38 ]
  %.1 = phi ptr addrspace(1) [ %.0, %plen.fast.22 ], [ %.2, %plen.ic.merge.38 ]
  %r171 = phi double [ %r89, %plen.fast.22 ], [ %r170, %plen.ic.merge.38 ]
  %r172 = fcmp olt double %r64, %r171
  %r173 = select i1 %r172, i64 9222246136947933188, i64 9222246136947933187
  %r174 = bitcast i64 %r173 to double
  %r176 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r177 = icmp ne i32 %r176, 0
  br i1 %r177, label %gcpoll.42, label %gcpoll.done.43

plen.ic.header.25:                                ; preds = %plen.slow.23
  %r98 = sub nuw nsw i64 %r67, 8
  %r99 = inttoptr i64 %r98 to ptr
  %r100 = load i8, ptr %r99, align 1
  %r101 = icmp eq i8 %r100, 2
  %r102 = sub nuw nsw i64 %r67, 7
  %r103 = inttoptr i64 %r102 to ptr
  %r104 = load i8, ptr %r103, align 1
  %r105 = and i8 %r104, -128
  %r106 = icmp eq i8 %r105, 0
  %r107 = and i1 %r101, %r106
  br i1 %r107, label %plen.elem.meta.39, label %plen.ic.miss.37

plen.ic.shape.26:                                 ; preds = %plen.elem.store.40, %plen.elem.meta.39
  %r97 = icmp ne ptr %r96, null
  br i1 %r97, label %plen.ic.shape.probe.27, label %plen.ic.miss.37

plen.ic.shape.probe.27:                           ; preds = %plen.ic.shape.26
  %r119 = inttoptr i64 %r67 to ptr
  %r120 = load i32, ptr %r119, align 4
  %r121 = add nuw nsw i64 %r67, 4
  %r122 = inttoptr i64 %r121 to ptr
  %r123 = load i32, ptr %r122, align 4
  %r124 = zext i32 %r120 to i64
  %r125 = zext i32 %r123 to i64
  %r126 = shl nuw i64 %r124, 32
  %r127 = or i64 %r126, %r125
  %r128 = getelementptr i64, ptr %r96, i64 0
  %r129 = load i64, ptr %r128, align 8
  %r130 = icmp ne i64 %r129, 0
  br i1 %r130, label %plen.ic.identity.28, label %plen.ic.miss.37

plen.ic.identity.28:                              ; preds = %plen.ic.shape.probe.27
  %r131 = and i64 %r129, -9223372036854775808
  %0 = icmp slt i64 %r129, 0
  br i1 %0, label %plen.ic.family_meta.30, label %plen.ic.exact.29

plen.ic.exact.29:                                 ; preds = %plen.ic.identity.28
  %r133 = icmp eq i64 %r127, %r129
  br i1 %r133, label %plen.ic.slot.32, label %plen.ic.miss.37

plen.ic.family_meta.30:                           ; preds = %plen.ic.identity.28
  %r134 = add nuw nsw i64 %r67, 8
  %r135 = inttoptr i64 %r134 to ptr
  %r136 = load i64, ptr %r135, align 8
  %r137 = icmp ne i64 %r136, 0
  br i1 %r137, label %plen.ic.family_token.31, label %plen.ic.miss.37

plen.ic.family_token.31:                          ; preds = %plen.ic.family_meta.30
  %r138 = inttoptr i64 %r136 to ptr
  %r139 = getelementptr i64, ptr %r138, i64 6
  %r140 = load i64, ptr %r139, align 8
  %r141 = icmp eq i64 %r140, %r129
  br i1 %r141, label %plen.ic.slot.32, label %plen.ic.miss.37

plen.ic.slot.32:                                  ; preds = %plen.ic.family_token.31, %plen.ic.exact.29
  %r142 = getelementptr i64, ptr %r96, i64 1
  %r143 = load i64, ptr %r142, align 8
  %r144 = getelementptr i64, ptr %r96, i64 2
  %r145 = load i64, ptr %r144, align 8
  %r146 = icmp ult i64 %r143, %r145
  br i1 %r146, label %plen.ic.inline.33, label %plen.ic.spill_meta.34

plen.ic.inline.33:                                ; preds = %plen.ic.slot.32
  %r147 = shl i64 %r143, 3
  %r148 = add i64 %r147, 16
  %r149 = add i64 %r67, %r148
  %r150 = inttoptr i64 %r149 to ptr
  %r151 = load double, ptr %r150, align 8
  br label %plen.ic.merge.38

plen.ic.spill_meta.34:                            ; preds = %plen.ic.slot.32
  %r152 = add nuw nsw i64 %r67, 8
  %r153 = inttoptr i64 %r152 to ptr
  %r154 = load i64, ptr %r153, align 8
  %r155 = icmp ne i64 %r154, 0
  br i1 %r155, label %plen.ic.spill_ptr.35, label %plen.ic.miss.37

plen.ic.spill_ptr.35:                             ; preds = %plen.ic.spill_meta.34
  %r156 = inttoptr i64 %r154 to ptr
  %r157 = getelementptr i64, ptr %r156, i64 4
  %r158 = load i64, ptr %r157, align 8
  %r159 = icmp ne i64 %r158, 0
  %r160 = select i1 %r159, i64 %r158, i64 %r154
  %r161 = inttoptr i64 %r160 to ptr
  %r162 = load i32, ptr %r161, align 4
  %r163 = zext i32 %r162 to i64
  %r164 = icmp ult i64 %r143, %r163
  %r165 = and i1 %r159, %r164
  br i1 %r165, label %plen.ic.spill_load.36, label %plen.ic.miss.37

plen.ic.spill_load.36:                            ; preds = %plen.ic.spill_ptr.35
  %r166 = add nuw nsw i64 %r143, 1
  %r167 = getelementptr inbounds nuw i64, ptr %r161, i64 %r166
  %r168 = load double, ptr %r167, align 8
  br label %plen.ic.merge.38

plen.ic.miss.37:                                  ; preds = %plen.ic.spill_ptr.35, %plen.ic.spill_meta.34, %plen.ic.family_token.31, %plen.ic.family_meta.30, %plen.ic.exact.29, %plen.ic.shape.probe.27, %plen.ic.shape.26, %plen.ic.header.25, %plen.slow.23
  %statepoint_token108 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r65, ptr @perry_ic_test_json_source_token_length_ts__0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.0.base, ptr addrspace(1) %r55.0.base, ptr addrspace(1) %.0, ptr addrspace(1) %r55.0, ptr addrspace(1) %r48.0) ]
  %r169109 = call double @llvm.experimental.gc.result.f64(token %statepoint_token108)
  %r48.0.base.relocated110 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 0, i32 0) ; (%r48.0.base, %r48.0.base)
  %r55.0.base.relocated111 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 1, i32 1) ; (%r55.0.base, %r55.0.base)
  %rs4gc.s12.relocated112 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 2, i32 2) ; (%.0, %.0)
  %r55.0.relocated113 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 1, i32 3) ; (%r55.0.base, %r55.0)
  %r48.0.relocated114 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 0, i32 4) ; (%r48.0.base, %r48.0)
  br label %plen.ic.merge.38

plen.ic.merge.38:                                 ; preds = %plen.elem.length.41, %plen.ic.miss.37, %plen.ic.spill_load.36, %plen.ic.inline.33
  %.11385 = phi ptr addrspace(1) [ %r48.0, %plen.elem.length.41 ], [ %r48.0, %plen.ic.inline.33 ], [ %r48.0, %plen.ic.spill_load.36 ], [ %r48.0.relocated114, %plen.ic.miss.37 ]
  %.11332 = phi ptr addrspace(1) [ %r55.0, %plen.elem.length.41 ], [ %r55.0, %plen.ic.inline.33 ], [ %r55.0, %plen.ic.spill_load.36 ], [ %r55.0.relocated113, %plen.ic.miss.37 ]
  %.11279 = phi ptr addrspace(1) [ %r48.0.base, %plen.elem.length.41 ], [ %r48.0.base, %plen.ic.inline.33 ], [ %r48.0.base, %plen.ic.spill_load.36 ], [ %r48.0.base.relocated110, %plen.ic.miss.37 ]
  %.11265 = phi ptr addrspace(1) [ %r55.0.base, %plen.elem.length.41 ], [ %r55.0.base, %plen.ic.inline.33 ], [ %r55.0.base, %plen.ic.spill_load.36 ], [ %r55.0.base.relocated111, %plen.ic.miss.37 ]
  %.2 = phi ptr addrspace(1) [ %.0, %plen.elem.length.41 ], [ %.0, %plen.ic.inline.33 ], [ %.0, %plen.ic.spill_load.36 ], [ %rs4gc.s12.relocated112, %plen.ic.miss.37 ]
  %r170 = phi double [ %r118, %plen.elem.length.41 ], [ %r151, %plen.ic.inline.33 ], [ %r168, %plen.ic.spill_load.36 ], [ %r169109, %plen.ic.miss.37 ]
  br label %plen.merge.24

plen.elem.meta.39:                                ; preds = %plen.ic.header.25
  %r108 = add nuw nsw i64 %r67, 8
  %r109 = inttoptr i64 %r108 to ptr
  %r110 = load i64, ptr %r109, align 8
  %r111 = icmp ne i64 %r110, 0
  br i1 %r111, label %plen.elem.store.40, label %plen.ic.shape.26

plen.elem.store.40:                               ; preds = %plen.elem.meta.39
  %r112 = inttoptr i64 %r110 to ptr
  %r113 = getelementptr i64, ptr %r112, i64 12
  %r114 = load i64, ptr %r113, align 8
  %r115 = icmp ne i64 %r114, 0
  br i1 %r115, label %plen.elem.length.41, label %plen.ic.shape.26

plen.elem.length.41:                              ; preds = %plen.elem.store.40
  %r116 = inttoptr i64 %r114 to ptr
  %r117 = load i32, ptr %r116, align 4
  %r118 = uitofp i32 %r117 to double
  br label %plen.ic.merge.38

gcpoll.42:                                        ; preds = %plen.merge.24
  %statepoint_token115 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1, ptr addrspace(1) %.01264, ptr addrspace(1) %.01331, ptr addrspace(1) %.01278, ptr addrspace(1) %.01384) ]
  %rs4gc.s12.relocated116 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token115, i32 0, i32 0) ; (%.1, %.1)
  %r55.0.base.relocated117 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token115, i32 1, i32 1) ; (%.01264, %.01264)
  %r55.0.relocated118 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token115, i32 1, i32 2) ; (%.01264, %.01331)
  %r48.0.base.relocated119 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token115, i32 3, i32 3) ; (%.01278, %.01278)
  %r48.0.relocated120 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token115, i32 3, i32 4) ; (%.01278, %.01384)
  br label %gcpoll.done.43

gcpoll.done.43:                                   ; preds = %gcpoll.42, %plen.merge.24
  %.21386 = phi ptr addrspace(1) [ %r48.0.relocated120, %gcpoll.42 ], [ %.01384, %plen.merge.24 ]
  %.21333 = phi ptr addrspace(1) [ %r55.0.relocated118, %gcpoll.42 ], [ %.01331, %plen.merge.24 ]
  %.21280 = phi ptr addrspace(1) [ %r48.0.base.relocated119, %gcpoll.42 ], [ %.01278, %plen.merge.24 ]
  %.21266 = phi ptr addrspace(1) [ %r55.0.base.relocated117, %gcpoll.42 ], [ %.01264, %plen.merge.24 ]
  %.3 = phi ptr addrspace(1) [ %rs4gc.s12.relocated116, %gcpoll.42 ], [ %.1, %plen.merge.24 ]
  %r175 = icmp eq i64 %r173, 9222246136947933188
  br i1 %r175, label %for.body.18, label %for.exit.20

arr.fast.44:                                      ; preds = %arr.guard.range.50
  %r242 = zext i32 %r62.0 to i64
  %r243 = shl nuw nsw i64 %r242, 3
  %r244 = add nuw nsw i64 %r243, 8
  %r245 = add i64 %r201, %r244
  %r246 = inttoptr i64 %r245 to ptr
  %r247 = load double, ptr %r246, align 8
  %r248 = bitcast double %r247 to i64
  %r249 = icmp eq i64 %r248, 9222246136947933200
  %r251 = select i1 %r249, double 0x7FFC000000000001, double %r247
  br label %arr.merge.47

arr.fallback.45:                                  ; preds = %arr.guard.live.49, %arr.guard.deref.48, %for.body.18
  %r240 = sitofp i32 %r62.0 to double
  %statepoint_token121 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 5587713372188573697, double %r179, double %r240, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3, ptr addrspace(1) %.21266, ptr addrspace(1) %.21333, ptr addrspace(1) %.21280, ptr addrspace(1) %.21386) ]
  %r241122 = call double @llvm.experimental.gc.result.f64(token %statepoint_token121)
  %rs4gc.s12.relocated123 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token121, i32 0, i32 0) ; (%.3, %.3)
  %r55.0.base.relocated124 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token121, i32 1, i32 1) ; (%.21266, %.21266)
  %r55.0.relocated125 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token121, i32 1, i32 2) ; (%.21266, %.21333)
  %r48.0.base.relocated126 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token121, i32 3, i32 3) ; (%.21280, %.21280)
  %r48.0.relocated127 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token121, i32 3, i32 4) ; (%.21280, %.21386)
  br label %arr.merge.47

arr.guard.oob.46:                                 ; preds = %arr.guard.range.50
  br label %arr.merge.47

arr.merge.47:                                     ; preds = %arr.guard.oob.46, %arr.fallback.45, %arr.fast.44
  %.31387 = phi ptr addrspace(1) [ %.21386, %arr.fast.44 ], [ %.21386, %arr.guard.oob.46 ], [ %r48.0.relocated127, %arr.fallback.45 ]
  %.31334 = phi ptr addrspace(1) [ %.21333, %arr.fast.44 ], [ %.21333, %arr.guard.oob.46 ], [ %r55.0.relocated125, %arr.fallback.45 ]
  %.31281 = phi ptr addrspace(1) [ %.21280, %arr.fast.44 ], [ %.21280, %arr.guard.oob.46 ], [ %r48.0.base.relocated126, %arr.fallback.45 ]
  %.31267 = phi ptr addrspace(1) [ %.21266, %arr.fast.44 ], [ %.21266, %arr.guard.oob.46 ], [ %r55.0.base.relocated124, %arr.fallback.45 ]
  %.4 = phi ptr addrspace(1) [ %.3, %arr.fast.44 ], [ %.3, %arr.guard.oob.46 ], [ %rs4gc.s12.relocated123, %arr.fallback.45 ]
  %r252 = phi double [ %r251, %arr.fast.44 ], [ %r241122, %arr.fallback.45 ], [ 0x7FFC000000000001, %arr.guard.oob.46 ]
  %statepoint_token128 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r252, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4, ptr addrspace(1) %.31267, ptr addrspace(1) %.31334, ptr addrspace(1) %.31281, ptr addrspace(1) %.31387) ]
  %r253129 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token128)
  %rs4gc.s12.relocated130 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token128, i32 0, i32 0) ; (%.4, %.4)
  %r55.0.base.relocated131 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token128, i32 1, i32 1) ; (%.31267, %.31267)
  %r55.0.relocated132 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token128, i32 1, i32 2) ; (%.31267, %.31334)
  %r48.0.base.relocated133 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token128, i32 3, i32 3) ; (%.31281, %.31281)
  %r48.0.relocated134 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token128, i32 3, i32 4) ; (%.31281, %.31387)
  %statepoint_token135 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_string_repeat, i32 2, i32 0, i64 %r253129, double 2.000000e+04, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s12.relocated130, ptr addrspace(1) %r55.0.base.relocated131, ptr addrspace(1) %r55.0.relocated132, ptr addrspace(1) %r48.0.base.relocated133, ptr addrspace(1) %r48.0.relocated134) ]
  %r254136 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token135)
  %rs4gc.s12.relocated137 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 0, i32 0) ; (%rs4gc.s12.relocated130, %rs4gc.s12.relocated130)
  %r55.0.base.relocated138 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 1, i32 1) ; (%r55.0.base.relocated131, %r55.0.base.relocated131)
  %r55.0.relocated139 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 1, i32 2) ; (%r55.0.base.relocated131, %r55.0.relocated132)
  %r48.0.base.relocated140 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 3, i32 3) ; (%r48.0.base.relocated133, %r48.0.base.relocated133)
  %r48.0.relocated141 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 3, i32 4) ; (%r48.0.base.relocated133, %r48.0.relocated134)
  %r255 = or i64 %r254136, 9223090561878065152
  %r256 = bitcast i64 %r255 to double
  %rs4gc.b16 = bitcast double %r256 to i64
  %rs4gc.s16 = inttoptr i64 %rs4gc.b16 to ptr addrspace(1)
  %r257.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16 to i64
  %r257 = call i64 asm "", "=r,0"(i64 %r257.rs4i) #7
  %r258 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r259 = icmp ne i32 %r258, 0
  br i1 %r259, label %shadow.root.barrier.51, label %shadow.root.barrier.done.52

arr.guard.deref.48:                               ; preds = %for.body.18
  %r187 = bitcast double %r179 to i64
  %r188 = and i64 %r187, 281474976710655
  %r189 = sub nsw i64 %r188, 8
  %r190 = inttoptr i64 %r189 to ptr
  %r191 = load i8, ptr %r190, align 1
  %r192 = icmp eq i8 %r191, 1
  %r193 = sub nsw i64 %r188, 7
  %r194 = inttoptr i64 %r193 to ptr
  %r195 = load i8, ptr %r194, align 1
  %r196 = and i8 %r195, -128
  %r197 = icmp ne i8 %r196, 0
  %r198 = inttoptr i64 %r188 to ptr
  %r199 = load i64, ptr %r198, align 8
  %r200 = and i1 %r192, %r197
  %r201 = select i1 %r200, i64 %r199, i64 %r188
  %r202 = lshr i64 %r201, 48
  %r203 = icmp eq i64 %r202, 0
  %r204 = icmp ugt i64 %r201, 1048575
  %r205 = and i1 %r203, %r204
  br i1 %r205, label %arr.guard.live.49, label %arr.fallback.45

arr.guard.live.49:                                ; preds = %arr.guard.deref.48
  %r206 = sub nuw i64 %r201, 8
  %r207 = inttoptr i64 %r206 to ptr
  %r208 = load i8, ptr %r207, align 1
  %r209 = icmp eq i8 %r208, 1
  %r210 = sub nuw i64 %r201, 7
  %r211 = inttoptr i64 %r210 to ptr
  %r212 = load i8, ptr %r211, align 1
  %r213 = and i8 %r212, -128
  %r214 = icmp eq i8 %r213, 0
  %r215 = sub nuw i64 %r201, 6
  %r216 = inttoptr i64 %r215 to ptr
  %r217 = load i16, ptr %r216, align 2
  %r218 = and i16 %r217, 1024
  %r219 = icmp eq i16 %r218, 0
  %r220 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r221 = icmp eq i8 %r220, 0
  %r222 = inttoptr i64 %r201 to ptr
  %r223 = load i32, ptr %r222, align 4
  %r224 = getelementptr i8, ptr %r222, i64 4
  %r225 = load i32, ptr %r224, align 4
  %r226 = icmp slt i32 %r62.0, 0
  %r227 = icmp eq i1 %r226, false
  %r229 = icmp ule i32 %r223, 16000000
  %r230 = icmp ule i32 %r225, 16000000
  %r231 = icmp ule i32 %r223, %r225
  %r232 = and i1 %r209, %r214
  %r233 = and i1 %r232, %r219
  %r234 = and i1 %r233, %r221
  %r235 = and i1 %r234, %r227
  %r236 = and i1 %r235, %r229
  %r237 = and i1 %r236, %r230
  %r238 = and i1 %r237, %r231
  br i1 %r238, label %arr.guard.range.50, label %arr.fallback.45

arr.guard.range.50:                               ; preds = %arr.guard.live.49
  %r228 = icmp ult i32 %r62.0, %r223
  br i1 %r228, label %arr.fast.44, label %arr.guard.oob.46

shadow.root.barrier.51:                           ; preds = %arr.merge.47
  call void @js_write_barrier_root_nanbox(i64 %r257) #7
  br label %shadow.root.barrier.done.52

shadow.root.barrier.done.52:                      ; preds = %shadow.root.barrier.51, %arr.merge.47
  %r260 = load double, ptr @test_json_source_token_length_ts_.str.3.handle, align 8
  %r262 = sitofp i32 %r62.0 to double
  %r263 = load double, ptr @test_json_source_token_length_ts_.str.4.handle, align 8
  %r264.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16 to i64
  %r264.rs4o = call i64 asm "", "=r,0"(i64 %r264.rs4i) #7
  %r264 = bitcast i64 %r264.rs4o to double
  %r265 = load double, ptr @test_json_source_token_length_ts_.str.5.handle, align 8
  %r267 = getelementptr double, ptr %r266, i64 0
  store double %r260, ptr %r267, align 8
  %r268 = getelementptr double, ptr %r266, i64 1
  store double %r262, ptr %r268, align 8
  %r269 = getelementptr double, ptr %r266, i64 2
  store double %r263, ptr %r269, align 8
  %r270 = getelementptr double, ptr %r266, i64 3
  store double %r264, ptr %r270, align 8
  %r271 = getelementptr double, ptr %r266, i64 4
  store double %r265, ptr %r271, align 8
  %r272 = ptrtoint ptr %r266 to i64
  %statepoint_token142 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r272, i32 5, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s16, ptr addrspace(1) %rs4gc.s12.relocated137, ptr addrspace(1) %r55.0.base.relocated138, ptr addrspace(1) %r55.0.relocated139, ptr addrspace(1) %r48.0.base.relocated140, ptr addrspace(1) %r48.0.relocated141) ]
  %r273143 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token142)
  %rs4gc.s16.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token142, i32 0, i32 0) ; (%rs4gc.s16, %rs4gc.s16)
  %rs4gc.s12.relocated144 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token142, i32 1, i32 1) ; (%rs4gc.s12.relocated137, %rs4gc.s12.relocated137)
  %r55.0.base.relocated145 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token142, i32 2, i32 2) ; (%r55.0.base.relocated138, %r55.0.base.relocated138)
  %r55.0.relocated146 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token142, i32 2, i32 3) ; (%r55.0.base.relocated138, %r55.0.relocated139)
  %r48.0.base.relocated147 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token142, i32 4, i32 4) ; (%r48.0.base.relocated140, %r48.0.base.relocated140)
  %r48.0.relocated148 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token142, i32 4, i32 5) ; (%r48.0.base.relocated140, %r48.0.relocated141)
  %r274 = or i64 %r273143, 9223090561878065152
  %r275 = bitcast i64 %r274 to double
  %r276 = bitcast i64 %r274 to double
  %r277.rs4i = ptrtoint ptr addrspace(1) %r48.0.relocated148 to i64
  %r277.rs4o = call i64 asm "", "=r,0"(i64 %r277.rs4i) #7
  %r277 = bitcast i64 %r277.rs4o to double
  %r278 = bitcast double %r277 to i64
  %r279 = and i64 %r278, 281474976710655
  %r280 = sub nsw i64 %r279, 8
  %r281 = inttoptr i64 %r280 to ptr
  %r282 = load i8, ptr %r281, align 1
  %r283 = icmp ne i8 %r282, 1
  %r284 = sub nsw i64 %r279, 7
  %r285 = inttoptr i64 %r284 to ptr
  %r286 = load i8, ptr %r285, align 1
  %r287 = and i8 %r286, -128
  %r288 = icmp ne i8 %r287, 0
  %r289 = or i1 %r283, %r288
  br i1 %r288, label %apush.fwd.53, label %apush.elements.54

apush.fwd.53:                                     ; preds = %apush.elements.check.55, %shadow.root.barrier.done.52
  %statepoint_token149 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r279, double %r276, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s16.relocated, ptr addrspace(1) %rs4gc.s12.relocated144, ptr addrspace(1) %r55.0.base.relocated145, ptr addrspace(1) %r55.0.relocated146) ]
  %r316150 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token149)
  %rs4gc.s16.relocated151 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token149, i32 0, i32 0) ; (%rs4gc.s16.relocated, %rs4gc.s16.relocated)
  %rs4gc.s12.relocated152 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token149, i32 1, i32 1) ; (%rs4gc.s12.relocated144, %rs4gc.s12.relocated144)
  %r55.0.base.relocated153 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token149, i32 2, i32 2) ; (%r55.0.base.relocated145, %r55.0.base.relocated145)
  %r55.0.relocated154 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token149, i32 2, i32 3) ; (%r55.0.base.relocated145, %r55.0.relocated146)
  %r317 = or i64 %r316150, 9222527611924643840
  %r318 = bitcast i64 %r317 to double
  %rs4gc.b17 = bitcast double %r318 to i64
  %rs4gc.s17 = inttoptr i64 %rs4gc.b17 to ptr addrspace(1)
  br label %apush.merge.59

apush.elements.54:                                ; preds = %shadow.root.barrier.done.52
  %r291 = add nuw nsw i64 %r279, 8
  %r292 = inttoptr i64 %r291 to ptr
  %r293 = load i64, ptr %r292, align 8
  %r294 = icmp ne i64 %r293, 0
  %r295 = icmp eq i8 %r282, 2
  %r296 = and i1 %r295, %r294
  %r297 = select i1 %r296, i64 %r293, i64 %r279
  %r298 = inttoptr i64 %r297 to ptr
  %r299 = getelementptr i64, ptr %r298, i64 12
  %r300 = load i64, ptr %r299, align 8
  %r301 = icmp ne i64 %r300, 0
  %r302 = and i1 %r296, %r301
  %r303 = select i1 %r302, i64 %r300, i64 %r279
  %r290 = icmp eq i8 %r282, 1
  br i1 %r290, label %apush.nofwd.56, label %apush.elements.check.55

apush.elements.check.55:                          ; preds = %apush.elements.54
  %r304 = icmp ne i64 %r303, 0
  %r305 = sub i64 %r303, 8
  %r306 = inttoptr i64 %r305 to ptr
  %r307 = load i8, ptr %r306, align 1
  %r308 = icmp eq i8 %r307, 1
  %r309 = sub i64 %r303, 7
  %r310 = inttoptr i64 %r309 to ptr
  %r311 = load i8, ptr %r310, align 1
  %r312 = and i8 %r311, -128
  %r313 = icmp eq i8 %r312, 0
  %r314 = and i1 %r304, %r308
  %r315 = and i1 %r314, %r313
  br i1 %r315, label %apush.nofwd.56, label %apush.fwd.53

apush.nofwd.56:                                   ; preds = %apush.elements.check.55, %apush.elements.54
  %r319 = phi i64 [ %r279, %apush.elements.54 ], [ %r303, %apush.elements.check.55 ]
  %r320 = sub i64 %r319, 6
  %r321 = inttoptr i64 %r320 to ptr
  %r322 = load i16, ptr %r321, align 2
  %r323 = and i16 %r322, 1031
  %r324 = icmp eq i16 %r323, 0
  %r325 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r326 = icmp eq i8 %r325, 0
  %r327 = and i1 %r324, %r326
  %r328 = icmp ult i64 %r319, 4096
  %r329 = inttoptr i64 %r319 to ptr
  %r330 = select i1 %r328, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r329
  %r331 = load i32, ptr %r330, align 4
  %r332 = add i64 %r319, 4
  %r333 = inttoptr i64 %r332 to ptr
  %r334 = load i32, ptr %r333, align 4
  %r335 = icmp ult i32 %r331, %r334
  %r336 = and i1 %r335, %r327
  br i1 %r336, label %apush.inbounds.57, label %apush.realloc.58

apush.inbounds.57:                                ; preds = %apush.nofwd.56
  %r337 = icmp ult i64 %r319, 4096
  %r338 = inttoptr i64 %r319 to ptr
  %r339 = select i1 %r337, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r338
  %r340 = load i32, ptr %r339, align 4
  %r341 = zext i32 %r340 to i64
  %r342 = shl nuw nsw i64 %r341, 3
  %r343 = add nuw nsw i64 %r342, 8
  %r344 = add i64 %r319, %r343
  %r345 = inttoptr i64 %r344 to ptr
  store double %r276, ptr %r345, align 8
  %r346 = lshr i64 %r274, 48
  %r348 = and i16 %r322, -1920
  %r349 = icmp eq i16 %r348, -24576
  br label %apush.pointer_layout.bookkeeping.60

apush.realloc.58:                                 ; preds = %apush.nofwd.56
  %statepoint_token155 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r279, double %r276, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s16.relocated, ptr addrspace(1) %rs4gc.s12.relocated144, ptr addrspace(1) %r55.0.base.relocated145, ptr addrspace(1) %r55.0.relocated146) ]
  %r361156 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token155)
  %rs4gc.s16.relocated157 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 0, i32 0) ; (%rs4gc.s16.relocated, %rs4gc.s16.relocated)
  %rs4gc.s12.relocated158 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 1, i32 1) ; (%rs4gc.s12.relocated144, %rs4gc.s12.relocated144)
  %r55.0.base.relocated159 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 2, i32 2) ; (%r55.0.base.relocated145, %r55.0.base.relocated145)
  %r55.0.relocated160 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 2, i32 3) ; (%r55.0.base.relocated145, %r55.0.relocated146)
  %r362 = or i64 %r361156, 9222527611924643840
  %r363 = bitcast i64 %r362 to double
  %rs4gc.b18 = bitcast double %r363 to i64
  %rs4gc.s18 = inttoptr i64 %rs4gc.b18 to ptr addrspace(1)
  br label %apush.merge.59

apush.merge.59:                                   ; preds = %apush.barrier.done.63, %apush.realloc.58, %apush.fwd.53
  %.01446 = phi ptr addrspace(1) [ %rs4gc.s16.relocated151, %apush.fwd.53 ], [ %rs4gc.s16.relocated, %apush.barrier.done.63 ], [ %rs4gc.s16.relocated157, %apush.realloc.58 ]
  %.41335 = phi ptr addrspace(1) [ %r55.0.relocated154, %apush.fwd.53 ], [ %r55.0.relocated146, %apush.barrier.done.63 ], [ %r55.0.relocated160, %apush.realloc.58 ]
  %.41268 = phi ptr addrspace(1) [ %r55.0.base.relocated153, %apush.fwd.53 ], [ %r55.0.base.relocated145, %apush.barrier.done.63 ], [ %r55.0.base.relocated159, %apush.realloc.58 ]
  %.5 = phi ptr addrspace(1) [ %rs4gc.s12.relocated152, %apush.fwd.53 ], [ %rs4gc.s12.relocated144, %apush.barrier.done.63 ], [ %rs4gc.s12.relocated158, %apush.realloc.58 ]
  %r48.1.base = phi ptr addrspace(1) [ %rs4gc.s17, %apush.fwd.53 ], [ %r48.0.base.relocated147, %apush.barrier.done.63 ], [ %rs4gc.s18, %apush.realloc.58 ], !is_base_value !0
  %r48.1 = phi ptr addrspace(1) [ %rs4gc.s17, %apush.fwd.53 ], [ %r48.0.relocated148, %apush.barrier.done.63 ], [ %rs4gc.s18, %apush.realloc.58 ]
  %r364.rs4i = ptrtoint ptr addrspace(1) %.01446 to i64
  %r364.rs4o = call i64 asm "", "=r,0"(i64 %r364.rs4i) #7
  %r364 = bitcast i64 %r364.rs4o to double
  %r365 = bitcast double %r364 to i64
  %r366.rs4i = ptrtoint ptr addrspace(1) %.41335 to i64
  %r366.rs4o = call i64 asm "", "=r,0"(i64 %r366.rs4i) #7
  %r366 = bitcast i64 %r366.rs4o to double
  %r367 = bitcast double %r366 to i64
  %r368 = and i64 %r367, 281474976710655
  %r369 = sub nsw i64 %r368, 8
  %r370 = inttoptr i64 %r369 to ptr
  %r371 = load i8, ptr %r370, align 1
  %r372 = icmp ne i8 %r371, 1
  %r373 = sub nsw i64 %r368, 7
  %r374 = inttoptr i64 %r373 to ptr
  %r375 = load i8, ptr %r374, align 1
  %r376 = and i8 %r375, -128
  %r377 = icmp ne i8 %r376, 0
  %r378 = or i1 %r372, %r377
  br i1 %r377, label %apush.fwd.64, label %apush.elements.65

apush.pointer_layout.bookkeeping.60:              ; preds = %apush.inbounds.57
  call void @js_string_addref_if_heap_string(double %r276) #7
  call void @js_gc_note_slot_layout(i64 %r319, i32 %r340, i64 %r274) #7
  call void @js_array_note_numeric_write(i64 %r319, i64 %r274) #7
  br label %apush.pointer_layout.done.61

apush.pointer_layout.done.61:                     ; preds = %apush.pointer_layout.bookkeeping.60
  %r351 = sub i64 %r319, 7
  %r352 = inttoptr i64 %r351 to ptr
  %r353 = load i8, ptr %r352, align 1
  %r354 = and i8 %r353, 32
  %r355 = icmp ne i8 %r354, 0
  %r356 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r357 = icmp ne i32 %r356, 0
  %r358 = or i1 %r355, %r357
  br i1 %r358, label %apush.barrier.62, label %apush.barrier.done.63

apush.barrier.62:                                 ; preds = %apush.pointer_layout.done.61
  call void @js_write_barrier_slot_validated_parent(i64 %r319, i64 %r344, i64 %r274) #7
  br label %apush.barrier.done.63

apush.barrier.done.63:                            ; preds = %apush.barrier.62, %apush.pointer_layout.done.61
  %r359 = add i32 %r340, 1
  %r360 = inttoptr i64 %r319 to ptr
  store i32 %r359, ptr %r360, align 4
  br label %apush.merge.59

apush.fwd.64:                                     ; preds = %apush.elements.check.66, %apush.merge.59
  %statepoint_token161 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r368, double %r364, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.1, ptr addrspace(1) %r48.1.base, ptr addrspace(1) %.01446, ptr addrspace(1) %.5) ]
  %r405162 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token161)
  %r48.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token161, i32 1, i32 0) ; (%r48.1.base, %r48.1)
  %r48.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token161, i32 1, i32 1) ; (%r48.1.base, %r48.1.base)
  %rs4gc.s16.relocated163 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token161, i32 2, i32 2) ; (%.01446, %.01446)
  %rs4gc.s12.relocated164 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token161, i32 3, i32 3) ; (%.5, %.5)
  %r406 = or i64 %r405162, 9222527611924643840
  %r407 = bitcast i64 %r406 to double
  %rs4gc.b19 = bitcast double %r407 to i64
  %rs4gc.s19 = inttoptr i64 %rs4gc.b19 to ptr addrspace(1)
  br label %apush.merge.70

apush.elements.65:                                ; preds = %apush.merge.59
  %r380 = add nuw nsw i64 %r368, 8
  %r381 = inttoptr i64 %r380 to ptr
  %r382 = load i64, ptr %r381, align 8
  %r383 = icmp ne i64 %r382, 0
  %r384 = icmp eq i8 %r371, 2
  %r385 = and i1 %r384, %r383
  %r386 = select i1 %r385, i64 %r382, i64 %r368
  %r387 = inttoptr i64 %r386 to ptr
  %r388 = getelementptr i64, ptr %r387, i64 12
  %r389 = load i64, ptr %r388, align 8
  %r390 = icmp ne i64 %r389, 0
  %r391 = and i1 %r385, %r390
  %r392 = select i1 %r391, i64 %r389, i64 %r368
  %r379 = icmp eq i8 %r371, 1
  br i1 %r379, label %apush.nofwd.67, label %apush.elements.check.66

apush.elements.check.66:                          ; preds = %apush.elements.65
  %r393 = icmp ne i64 %r392, 0
  %r394 = sub i64 %r392, 8
  %r395 = inttoptr i64 %r394 to ptr
  %r396 = load i8, ptr %r395, align 1
  %r397 = icmp eq i8 %r396, 1
  %r398 = sub i64 %r392, 7
  %r399 = inttoptr i64 %r398 to ptr
  %r400 = load i8, ptr %r399, align 1
  %r401 = and i8 %r400, -128
  %r402 = icmp eq i8 %r401, 0
  %r403 = and i1 %r393, %r397
  %r404 = and i1 %r403, %r402
  br i1 %r404, label %apush.nofwd.67, label %apush.fwd.64

apush.nofwd.67:                                   ; preds = %apush.elements.check.66, %apush.elements.65
  %r408 = phi i64 [ %r368, %apush.elements.65 ], [ %r392, %apush.elements.check.66 ]
  %r409 = sub i64 %r408, 6
  %r410 = inttoptr i64 %r409 to ptr
  %r411 = load i16, ptr %r410, align 2
  %r412 = and i16 %r411, 1031
  %r413 = icmp eq i16 %r412, 0
  %r414 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r415 = icmp eq i8 %r414, 0
  %r416 = and i1 %r413, %r415
  %r417 = icmp ult i64 %r408, 4096
  %r418 = inttoptr i64 %r408 to ptr
  %r419 = select i1 %r417, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r418
  %r420 = load i32, ptr %r419, align 4
  %r421 = add i64 %r408, 4
  %r422 = inttoptr i64 %r421 to ptr
  %r423 = load i32, ptr %r422, align 4
  %r424 = icmp ult i32 %r420, %r423
  %r425 = and i1 %r424, %r416
  br i1 %r425, label %apush.inbounds.68, label %apush.realloc.69

apush.inbounds.68:                                ; preds = %apush.nofwd.67
  %r426 = icmp ult i64 %r408, 4096
  %r427 = inttoptr i64 %r408 to ptr
  %r428 = select i1 %r426, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r427
  %r429 = load i32, ptr %r428, align 4
  %r430 = zext i32 %r429 to i64
  %r431 = shl nuw nsw i64 %r430, 3
  %r432 = add nuw nsw i64 %r431, 8
  %r433 = add i64 %r408, %r432
  %r434 = inttoptr i64 %r433 to ptr
  store double %r364, ptr %r434, align 8
  %r435 = lshr i64 %r365, 48
  %r436 = icmp eq i64 %r435, 32765
  %r437 = and i16 %r411, -1920
  %r438 = icmp eq i16 %r437, -24576
  %r439 = and i1 %r436, %r438
  br i1 %r439, label %apush.pointer_layout.done.72, label %apush.pointer_layout.bookkeeping.71

apush.realloc.69:                                 ; preds = %apush.nofwd.67
  %statepoint_token165 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r368, double %r364, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.1, ptr addrspace(1) %r48.1.base, ptr addrspace(1) %.01446, ptr addrspace(1) %.5) ]
  %r450166 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token165)
  %r48.1.relocated167 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token165, i32 1, i32 0) ; (%r48.1.base, %r48.1)
  %r48.1.base.relocated168 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token165, i32 1, i32 1) ; (%r48.1.base, %r48.1.base)
  %rs4gc.s16.relocated169 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token165, i32 2, i32 2) ; (%.01446, %.01446)
  %rs4gc.s12.relocated170 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token165, i32 3, i32 3) ; (%.5, %.5)
  %r451 = or i64 %r450166, 9222527611924643840
  %r452 = bitcast i64 %r451 to double
  %rs4gc.b20 = bitcast double %r452 to i64
  %rs4gc.s20 = inttoptr i64 %rs4gc.b20 to ptr addrspace(1)
  br label %apush.merge.70

apush.merge.70:                                   ; preds = %apush.barrier.done.74, %apush.realloc.69, %apush.fwd.64
  %.01454 = phi ptr addrspace(1) [ %r48.1.base.relocated, %apush.fwd.64 ], [ %r48.1.base, %apush.barrier.done.74 ], [ %r48.1.base.relocated168, %apush.realloc.69 ]
  %.01453 = phi ptr addrspace(1) [ %r48.1.relocated, %apush.fwd.64 ], [ %r48.1, %apush.barrier.done.74 ], [ %r48.1.relocated167, %apush.realloc.69 ]
  %.11447 = phi ptr addrspace(1) [ %rs4gc.s16.relocated163, %apush.fwd.64 ], [ %.01446, %apush.barrier.done.74 ], [ %rs4gc.s16.relocated169, %apush.realloc.69 ]
  %.6 = phi ptr addrspace(1) [ %rs4gc.s12.relocated164, %apush.fwd.64 ], [ %.5, %apush.barrier.done.74 ], [ %rs4gc.s12.relocated170, %apush.realloc.69 ]
  %r55.1.base = phi ptr addrspace(1) [ %rs4gc.s19, %apush.fwd.64 ], [ %.41268, %apush.barrier.done.74 ], [ %rs4gc.s20, %apush.realloc.69 ], !is_base_value !0
  %r55.1 = phi ptr addrspace(1) [ %rs4gc.s19, %apush.fwd.64 ], [ %.41335, %apush.barrier.done.74 ], [ %rs4gc.s20, %apush.realloc.69 ]
  %r453 = load double, ptr @test_json_source_token_length_ts_.str.6.handle, align 8
  %r455 = sitofp i32 %r62.0 to double
  %r456 = load double, ptr @test_json_source_token_length_ts_.str.4.handle, align 8
  %r457.rs4i = ptrtoint ptr addrspace(1) %.11447 to i64
  %r457.rs4o = call i64 asm "", "=r,0"(i64 %r457.rs4i) #7
  %r457 = bitcast i64 %r457.rs4o to double
  %r458 = load double, ptr @test_json_source_token_length_ts_.str.5.handle, align 8
  %r460 = getelementptr double, ptr %r459, i64 0
  store double %r453, ptr %r460, align 8
  %r461 = getelementptr double, ptr %r459, i64 1
  store double %r455, ptr %r461, align 8
  %r462 = getelementptr double, ptr %r459, i64 2
  store double %r456, ptr %r462, align 8
  %r463 = getelementptr double, ptr %r459, i64 3
  store double %r457, ptr %r463, align 8
  %r464 = getelementptr double, ptr %r459, i64 4
  store double %r458, ptr %r464, align 8
  %r465 = ptrtoint ptr %r459 to i64
  %statepoint_token171 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r465, i32 5, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11447, ptr addrspace(1) %.6, ptr addrspace(1) %r55.1.base, ptr addrspace(1) %r55.1, ptr addrspace(1) %.01454, ptr addrspace(1) %.01453) ]
  %r466172 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token171)
  %rs4gc.s16.relocated173 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 0, i32 0) ; (%.11447, %.11447)
  %rs4gc.s12.relocated174 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 1, i32 1) ; (%.6, %.6)
  %r55.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 2, i32 2) ; (%r55.1.base, %r55.1.base)
  %r55.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 2, i32 3) ; (%r55.1.base, %r55.1)
  %r48.1.base.relocated175 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 4, i32 4) ; (%.01454, %.01454)
  %r48.1.relocated176 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 4, i32 5) ; (%.01454, %.01453)
  %r467 = or i64 %r466172, 9223090561878065152
  %r468 = bitcast i64 %r467 to double
  %r469 = bitcast i64 %r467 to double
  %r470.rs4i = ptrtoint ptr addrspace(1) %r48.1.relocated176 to i64
  %r470.rs4o = call i64 asm "", "=r,0"(i64 %r470.rs4i) #7
  %r470 = bitcast i64 %r470.rs4o to double
  %r471 = bitcast double %r470 to i64
  %r472 = and i64 %r471, 281474976710655
  %r473 = sub nsw i64 %r472, 8
  %r474 = inttoptr i64 %r473 to ptr
  %r475 = load i8, ptr %r474, align 1
  %r476 = icmp ne i8 %r475, 1
  %r477 = sub nsw i64 %r472, 7
  %r478 = inttoptr i64 %r477 to ptr
  %r479 = load i8, ptr %r478, align 1
  %r480 = and i8 %r479, -128
  %r481 = icmp ne i8 %r480, 0
  %r482 = or i1 %r476, %r481
  br i1 %r481, label %apush.fwd.75, label %apush.elements.76

apush.pointer_layout.bookkeeping.71:              ; preds = %apush.inbounds.68
  call void @js_string_addref_if_heap_string(double %r364) #7
  %r4433.rs4i = ptrtoint ptr addrspace(1) %.01446 to i64
  %r4433.rs4o = call i64 asm "", "=r,0"(i64 %r4433.rs4i) #7
  %r4433 = bitcast i64 %r4433.rs4o to double
  %r4434 = bitcast double %r4433 to i64
  call void @js_gc_note_slot_layout(i64 %r408, i32 %r429, i64 %r4434) #7
  %r4431.rs4i = ptrtoint ptr addrspace(1) %.01446 to i64
  %r4431.rs4o = call i64 asm "", "=r,0"(i64 %r4431.rs4i) #7
  %r4431 = bitcast i64 %r4431.rs4o to double
  %r4432 = bitcast double %r4431 to i64
  call void @js_array_note_numeric_write(i64 %r408, i64 %r4432) #7
  br label %apush.pointer_layout.done.72

apush.pointer_layout.done.72:                     ; preds = %apush.pointer_layout.bookkeeping.71, %apush.inbounds.68
  %r440 = sub i64 %r408, 7
  %r441 = inttoptr i64 %r440 to ptr
  %r442 = load i8, ptr %r441, align 1
  %r443 = and i8 %r442, 32
  %r444 = icmp ne i8 %r443, 0
  %r445 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r446 = icmp ne i32 %r445, 0
  %r447 = or i1 %r444, %r446
  br i1 %r447, label %apush.barrier.73, label %apush.barrier.done.74

apush.barrier.73:                                 ; preds = %apush.pointer_layout.done.72
  %r4429.rs4i = ptrtoint ptr addrspace(1) %.01446 to i64
  %r4429.rs4o = call i64 asm "", "=r,0"(i64 %r4429.rs4i) #7
  %r4429 = bitcast i64 %r4429.rs4o to double
  %r4430 = bitcast double %r4429 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r408, i64 %r433, i64 %r4430) #7
  br label %apush.barrier.done.74

apush.barrier.done.74:                            ; preds = %apush.barrier.73, %apush.pointer_layout.done.72
  %r448 = add i32 %r429, 1
  %r449 = inttoptr i64 %r408 to ptr
  store i32 %r448, ptr %r449, align 4
  br label %apush.merge.70

apush.fwd.75:                                     ; preds = %apush.elements.check.77, %apush.merge.70
  %statepoint_token177 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r472, double %r469, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s16.relocated173, ptr addrspace(1) %rs4gc.s12.relocated174, ptr addrspace(1) %r55.1.base.relocated, ptr addrspace(1) %r55.1.relocated) ]
  %r509178 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token177)
  %rs4gc.s16.relocated179 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token177, i32 0, i32 0) ; (%rs4gc.s16.relocated173, %rs4gc.s16.relocated173)
  %rs4gc.s12.relocated180 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token177, i32 1, i32 1) ; (%rs4gc.s12.relocated174, %rs4gc.s12.relocated174)
  %r55.1.base.relocated181 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token177, i32 2, i32 2) ; (%r55.1.base.relocated, %r55.1.base.relocated)
  %r55.1.relocated182 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token177, i32 2, i32 3) ; (%r55.1.base.relocated, %r55.1.relocated)
  %r510 = or i64 %r509178, 9222527611924643840
  %r511 = bitcast i64 %r510 to double
  %rs4gc.b21 = bitcast double %r511 to i64
  %rs4gc.s21 = inttoptr i64 %rs4gc.b21 to ptr addrspace(1)
  br label %apush.merge.81

apush.elements.76:                                ; preds = %apush.merge.70
  %r484 = add nuw nsw i64 %r472, 8
  %r485 = inttoptr i64 %r484 to ptr
  %r486 = load i64, ptr %r485, align 8
  %r487 = icmp ne i64 %r486, 0
  %r488 = icmp eq i8 %r475, 2
  %r489 = and i1 %r488, %r487
  %r490 = select i1 %r489, i64 %r486, i64 %r472
  %r491 = inttoptr i64 %r490 to ptr
  %r492 = getelementptr i64, ptr %r491, i64 12
  %r493 = load i64, ptr %r492, align 8
  %r494 = icmp ne i64 %r493, 0
  %r495 = and i1 %r489, %r494
  %r496 = select i1 %r495, i64 %r493, i64 %r472
  %r483 = icmp eq i8 %r475, 1
  br i1 %r483, label %apush.nofwd.78, label %apush.elements.check.77

apush.elements.check.77:                          ; preds = %apush.elements.76
  %r497 = icmp ne i64 %r496, 0
  %r498 = sub i64 %r496, 8
  %r499 = inttoptr i64 %r498 to ptr
  %r500 = load i8, ptr %r499, align 1
  %r501 = icmp eq i8 %r500, 1
  %r502 = sub i64 %r496, 7
  %r503 = inttoptr i64 %r502 to ptr
  %r504 = load i8, ptr %r503, align 1
  %r505 = and i8 %r504, -128
  %r506 = icmp eq i8 %r505, 0
  %r507 = and i1 %r497, %r501
  %r508 = and i1 %r507, %r506
  br i1 %r508, label %apush.nofwd.78, label %apush.fwd.75

apush.nofwd.78:                                   ; preds = %apush.elements.check.77, %apush.elements.76
  %r512 = phi i64 [ %r472, %apush.elements.76 ], [ %r496, %apush.elements.check.77 ]
  %r513 = sub i64 %r512, 6
  %r514 = inttoptr i64 %r513 to ptr
  %r515 = load i16, ptr %r514, align 2
  %r516 = and i16 %r515, 1031
  %r517 = icmp eq i16 %r516, 0
  %r518 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r519 = icmp eq i8 %r518, 0
  %r520 = and i1 %r517, %r519
  %r521 = icmp ult i64 %r512, 4096
  %r522 = inttoptr i64 %r512 to ptr
  %r523 = select i1 %r521, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r522
  %r524 = load i32, ptr %r523, align 4
  %r525 = add i64 %r512, 4
  %r526 = inttoptr i64 %r525 to ptr
  %r527 = load i32, ptr %r526, align 4
  %r528 = icmp ult i32 %r524, %r527
  %r529 = and i1 %r528, %r520
  br i1 %r529, label %apush.inbounds.79, label %apush.realloc.80

apush.inbounds.79:                                ; preds = %apush.nofwd.78
  %r530 = icmp ult i64 %r512, 4096
  %r531 = inttoptr i64 %r512 to ptr
  %r532 = select i1 %r530, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r531
  %r533 = load i32, ptr %r532, align 4
  %r534 = zext i32 %r533 to i64
  %r535 = shl nuw nsw i64 %r534, 3
  %r536 = add nuw nsw i64 %r535, 8
  %r537 = add i64 %r512, %r536
  %r538 = inttoptr i64 %r537 to ptr
  store double %r469, ptr %r538, align 8
  %r539 = lshr i64 %r467, 48
  %r541 = and i16 %r515, -1920
  %r542 = icmp eq i16 %r541, -24576
  br label %apush.pointer_layout.bookkeeping.82

apush.realloc.80:                                 ; preds = %apush.nofwd.78
  %statepoint_token183 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r472, double %r469, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s16.relocated173, ptr addrspace(1) %rs4gc.s12.relocated174, ptr addrspace(1) %r55.1.base.relocated, ptr addrspace(1) %r55.1.relocated) ]
  %r554184 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token183)
  %rs4gc.s16.relocated185 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token183, i32 0, i32 0) ; (%rs4gc.s16.relocated173, %rs4gc.s16.relocated173)
  %rs4gc.s12.relocated186 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token183, i32 1, i32 1) ; (%rs4gc.s12.relocated174, %rs4gc.s12.relocated174)
  %r55.1.base.relocated187 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token183, i32 2, i32 2) ; (%r55.1.base.relocated, %r55.1.base.relocated)
  %r55.1.relocated188 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token183, i32 2, i32 3) ; (%r55.1.base.relocated, %r55.1.relocated)
  %r555 = or i64 %r554184, 9222527611924643840
  %r556 = bitcast i64 %r555 to double
  %rs4gc.b22 = bitcast double %r556 to i64
  %rs4gc.s22 = inttoptr i64 %rs4gc.b22 to ptr addrspace(1)
  br label %apush.merge.81

apush.merge.81:                                   ; preds = %apush.barrier.done.85, %apush.realloc.80, %apush.fwd.75
  %.01456 = phi ptr addrspace(1) [ %r55.1.relocated182, %apush.fwd.75 ], [ %r55.1.relocated, %apush.barrier.done.85 ], [ %r55.1.relocated188, %apush.realloc.80 ]
  %.01455 = phi ptr addrspace(1) [ %r55.1.base.relocated181, %apush.fwd.75 ], [ %r55.1.base.relocated, %apush.barrier.done.85 ], [ %r55.1.base.relocated187, %apush.realloc.80 ]
  %.21448 = phi ptr addrspace(1) [ %rs4gc.s16.relocated179, %apush.fwd.75 ], [ %rs4gc.s16.relocated173, %apush.barrier.done.85 ], [ %rs4gc.s16.relocated185, %apush.realloc.80 ]
  %.7 = phi ptr addrspace(1) [ %rs4gc.s12.relocated180, %apush.fwd.75 ], [ %rs4gc.s12.relocated174, %apush.barrier.done.85 ], [ %rs4gc.s12.relocated186, %apush.realloc.80 ]
  %r48.2.base = phi ptr addrspace(1) [ %rs4gc.s21, %apush.fwd.75 ], [ %r48.1.base.relocated175, %apush.barrier.done.85 ], [ %rs4gc.s22, %apush.realloc.80 ], !is_base_value !0
  %r48.2 = phi ptr addrspace(1) [ %rs4gc.s21, %apush.fwd.75 ], [ %r48.1.relocated176, %apush.barrier.done.85 ], [ %rs4gc.s22, %apush.realloc.80 ]
  %r557.rs4i = ptrtoint ptr addrspace(1) %.21448 to i64
  %r557.rs4o = call i64 asm "", "=r,0"(i64 %r557.rs4i) #7
  %r557 = bitcast i64 %r557.rs4o to double
  %r558 = bitcast double %r557 to i64
  %r559.rs4i = ptrtoint ptr addrspace(1) %.01456 to i64
  %r559.rs4o = call i64 asm "", "=r,0"(i64 %r559.rs4i) #7
  %r559 = bitcast i64 %r559.rs4o to double
  %r560 = bitcast double %r559 to i64
  %r561 = and i64 %r560, 281474976710655
  %r562 = sub nsw i64 %r561, 8
  %r563 = inttoptr i64 %r562 to ptr
  %r564 = load i8, ptr %r563, align 1
  %r565 = icmp ne i8 %r564, 1
  %r566 = sub nsw i64 %r561, 7
  %r567 = inttoptr i64 %r566 to ptr
  %r568 = load i8, ptr %r567, align 1
  %r569 = and i8 %r568, -128
  %r570 = icmp ne i8 %r569, 0
  %r571 = or i1 %r565, %r570
  br i1 %r570, label %apush.fwd.86, label %apush.elements.87

apush.pointer_layout.bookkeeping.82:              ; preds = %apush.inbounds.79
  call void @js_string_addref_if_heap_string(double %r469) #7
  call void @js_gc_note_slot_layout(i64 %r512, i32 %r533, i64 %r467) #7
  call void @js_array_note_numeric_write(i64 %r512, i64 %r467) #7
  br label %apush.pointer_layout.done.83

apush.pointer_layout.done.83:                     ; preds = %apush.pointer_layout.bookkeeping.82
  %r544 = sub i64 %r512, 7
  %r545 = inttoptr i64 %r544 to ptr
  %r546 = load i8, ptr %r545, align 1
  %r547 = and i8 %r546, 32
  %r548 = icmp ne i8 %r547, 0
  %r549 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r550 = icmp ne i32 %r549, 0
  %r551 = or i1 %r548, %r550
  br i1 %r551, label %apush.barrier.84, label %apush.barrier.done.85

apush.barrier.84:                                 ; preds = %apush.pointer_layout.done.83
  call void @js_write_barrier_slot_validated_parent(i64 %r512, i64 %r537, i64 %r467) #7
  br label %apush.barrier.done.85

apush.barrier.done.85:                            ; preds = %apush.barrier.84, %apush.pointer_layout.done.83
  %r552 = add i32 %r533, 1
  %r553 = inttoptr i64 %r512 to ptr
  store i32 %r552, ptr %r553, align 4
  br label %apush.merge.81

apush.fwd.86:                                     ; preds = %apush.elements.check.88, %apush.merge.81
  %statepoint_token189 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r561, double %r557, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.2, ptr addrspace(1) %r48.2.base, ptr addrspace(1) %.21448, ptr addrspace(1) %.7) ]
  %r598190 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token189)
  %r48.2.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token189, i32 1, i32 0) ; (%r48.2.base, %r48.2)
  %r48.2.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token189, i32 1, i32 1) ; (%r48.2.base, %r48.2.base)
  %rs4gc.s16.relocated191 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token189, i32 2, i32 2) ; (%.21448, %.21448)
  %rs4gc.s12.relocated192 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token189, i32 3, i32 3) ; (%.7, %.7)
  %r599 = or i64 %r598190, 9222527611924643840
  %r600 = bitcast i64 %r599 to double
  %rs4gc.b23 = bitcast double %r600 to i64
  %rs4gc.s23 = inttoptr i64 %rs4gc.b23 to ptr addrspace(1)
  br label %apush.merge.92

apush.elements.87:                                ; preds = %apush.merge.81
  %r573 = add nuw nsw i64 %r561, 8
  %r574 = inttoptr i64 %r573 to ptr
  %r575 = load i64, ptr %r574, align 8
  %r576 = icmp ne i64 %r575, 0
  %r577 = icmp eq i8 %r564, 2
  %r578 = and i1 %r577, %r576
  %r579 = select i1 %r578, i64 %r575, i64 %r561
  %r580 = inttoptr i64 %r579 to ptr
  %r581 = getelementptr i64, ptr %r580, i64 12
  %r582 = load i64, ptr %r581, align 8
  %r583 = icmp ne i64 %r582, 0
  %r584 = and i1 %r578, %r583
  %r585 = select i1 %r584, i64 %r582, i64 %r561
  %r572 = icmp eq i8 %r564, 1
  br i1 %r572, label %apush.nofwd.89, label %apush.elements.check.88

apush.elements.check.88:                          ; preds = %apush.elements.87
  %r586 = icmp ne i64 %r585, 0
  %r587 = sub i64 %r585, 8
  %r588 = inttoptr i64 %r587 to ptr
  %r589 = load i8, ptr %r588, align 1
  %r590 = icmp eq i8 %r589, 1
  %r591 = sub i64 %r585, 7
  %r592 = inttoptr i64 %r591 to ptr
  %r593 = load i8, ptr %r592, align 1
  %r594 = and i8 %r593, -128
  %r595 = icmp eq i8 %r594, 0
  %r596 = and i1 %r586, %r590
  %r597 = and i1 %r596, %r595
  br i1 %r597, label %apush.nofwd.89, label %apush.fwd.86

apush.nofwd.89:                                   ; preds = %apush.elements.check.88, %apush.elements.87
  %r601 = phi i64 [ %r561, %apush.elements.87 ], [ %r585, %apush.elements.check.88 ]
  %r602 = sub i64 %r601, 6
  %r603 = inttoptr i64 %r602 to ptr
  %r604 = load i16, ptr %r603, align 2
  %r605 = and i16 %r604, 1031
  %r606 = icmp eq i16 %r605, 0
  %r607 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r608 = icmp eq i8 %r607, 0
  %r609 = and i1 %r606, %r608
  %r610 = icmp ult i64 %r601, 4096
  %r611 = inttoptr i64 %r601 to ptr
  %r612 = select i1 %r610, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r611
  %r613 = load i32, ptr %r612, align 4
  %r614 = add i64 %r601, 4
  %r615 = inttoptr i64 %r614 to ptr
  %r616 = load i32, ptr %r615, align 4
  %r617 = icmp ult i32 %r613, %r616
  %r618 = and i1 %r617, %r609
  br i1 %r618, label %apush.inbounds.90, label %apush.realloc.91

apush.inbounds.90:                                ; preds = %apush.nofwd.89
  %r619 = icmp ult i64 %r601, 4096
  %r620 = inttoptr i64 %r601 to ptr
  %r621 = select i1 %r619, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r620
  %r622 = load i32, ptr %r621, align 4
  %r623 = zext i32 %r622 to i64
  %r624 = shl nuw nsw i64 %r623, 3
  %r625 = add nuw nsw i64 %r624, 8
  %r626 = add i64 %r601, %r625
  %r627 = inttoptr i64 %r626 to ptr
  store double %r557, ptr %r627, align 8
  %r628 = lshr i64 %r558, 48
  %r629 = icmp eq i64 %r628, 32765
  %r630 = and i16 %r604, -1920
  %r631 = icmp eq i16 %r630, -24576
  %r632 = and i1 %r629, %r631
  br i1 %r632, label %apush.pointer_layout.done.94, label %apush.pointer_layout.bookkeeping.93

apush.realloc.91:                                 ; preds = %apush.nofwd.89
  %statepoint_token193 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r561, double %r557, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.2, ptr addrspace(1) %r48.2.base, ptr addrspace(1) %.21448, ptr addrspace(1) %.7) ]
  %r643194 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token193)
  %r48.2.relocated195 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token193, i32 1, i32 0) ; (%r48.2.base, %r48.2)
  %r48.2.base.relocated196 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token193, i32 1, i32 1) ; (%r48.2.base, %r48.2.base)
  %rs4gc.s16.relocated197 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token193, i32 2, i32 2) ; (%.21448, %.21448)
  %rs4gc.s12.relocated198 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token193, i32 3, i32 3) ; (%.7, %.7)
  %r644 = or i64 %r643194, 9222527611924643840
  %r645 = bitcast i64 %r644 to double
  %rs4gc.b24 = bitcast double %r645 to i64
  %rs4gc.s24 = inttoptr i64 %rs4gc.b24 to ptr addrspace(1)
  br label %apush.merge.92

apush.merge.92:                                   ; preds = %apush.barrier.done.96, %apush.realloc.91, %apush.fwd.86
  %.01458 = phi ptr addrspace(1) [ %r48.2.base.relocated, %apush.fwd.86 ], [ %r48.2.base, %apush.barrier.done.96 ], [ %r48.2.base.relocated196, %apush.realloc.91 ]
  %.01457 = phi ptr addrspace(1) [ %r48.2.relocated, %apush.fwd.86 ], [ %r48.2, %apush.barrier.done.96 ], [ %r48.2.relocated195, %apush.realloc.91 ]
  %.31449 = phi ptr addrspace(1) [ %rs4gc.s16.relocated191, %apush.fwd.86 ], [ %.21448, %apush.barrier.done.96 ], [ %rs4gc.s16.relocated197, %apush.realloc.91 ]
  %.8 = phi ptr addrspace(1) [ %rs4gc.s12.relocated192, %apush.fwd.86 ], [ %.7, %apush.barrier.done.96 ], [ %rs4gc.s12.relocated198, %apush.realloc.91 ]
  %r55.2.base = phi ptr addrspace(1) [ %rs4gc.s23, %apush.fwd.86 ], [ %.01455, %apush.barrier.done.96 ], [ %rs4gc.s24, %apush.realloc.91 ], !is_base_value !0
  %r55.2 = phi ptr addrspace(1) [ %rs4gc.s23, %apush.fwd.86 ], [ %.01456, %apush.barrier.done.96 ], [ %rs4gc.s24, %apush.realloc.91 ]
  %r646 = load double, ptr @test_json_source_token_length_ts_.str.3.handle, align 8
  %r648 = sitofp i32 %r62.0 to double
  %r649 = load double, ptr @test_json_source_token_length_ts_.str.4.handle, align 8
  %r650.rs4i = ptrtoint ptr addrspace(1) %.31449 to i64
  %r650.rs4o = call i64 asm "", "=r,0"(i64 %r650.rs4i) #7
  %r650 = bitcast i64 %r650.rs4o to double
  %r651 = load double, ptr @test_json_source_token_length_ts_.str.7.handle, align 8
  %r653 = getelementptr double, ptr %r652, i64 0
  store double %r646, ptr %r653, align 8
  %r654 = getelementptr double, ptr %r652, i64 1
  store double %r648, ptr %r654, align 8
  %r655 = getelementptr double, ptr %r652, i64 2
  store double %r649, ptr %r655, align 8
  %r656 = getelementptr double, ptr %r652, i64 3
  store double %r650, ptr %r656, align 8
  %r657 = getelementptr double, ptr %r652, i64 4
  store double %r651, ptr %r657, align 8
  %r658 = ptrtoint ptr %r652 to i64
  %statepoint_token199 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r658, i32 5, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r55.2, ptr addrspace(1) %r55.2.base, ptr addrspace(1) %.31449, ptr addrspace(1) %.8, ptr addrspace(1) %.01458, ptr addrspace(1) %.01457) ]
  %r659200 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token199)
  %r55.2.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token199, i32 1, i32 0) ; (%r55.2.base, %r55.2)
  %r55.2.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token199, i32 1, i32 1) ; (%r55.2.base, %r55.2.base)
  %rs4gc.s16.relocated201 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token199, i32 2, i32 2) ; (%.31449, %.31449)
  %rs4gc.s12.relocated202 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token199, i32 3, i32 3) ; (%.8, %.8)
  %r48.2.base.relocated203 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token199, i32 4, i32 4) ; (%.01458, %.01458)
  %r48.2.relocated204 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token199, i32 4, i32 5) ; (%.01458, %.01457)
  %r660 = or i64 %r659200, 9223090561878065152
  %r661 = bitcast i64 %r660 to double
  %r662 = bitcast i64 %r660 to double
  %r663.rs4i = ptrtoint ptr addrspace(1) %r48.2.relocated204 to i64
  %r663.rs4o = call i64 asm "", "=r,0"(i64 %r663.rs4i) #7
  %r663 = bitcast i64 %r663.rs4o to double
  %r664 = bitcast double %r663 to i64
  %r665 = and i64 %r664, 281474976710655
  %r666 = sub nsw i64 %r665, 8
  %r667 = inttoptr i64 %r666 to ptr
  %r668 = load i8, ptr %r667, align 1
  %r669 = icmp ne i8 %r668, 1
  %r670 = sub nsw i64 %r665, 7
  %r671 = inttoptr i64 %r670 to ptr
  %r672 = load i8, ptr %r671, align 1
  %r673 = and i8 %r672, -128
  %r674 = icmp ne i8 %r673, 0
  %r675 = or i1 %r669, %r674
  br i1 %r674, label %apush.fwd.97, label %apush.elements.98

apush.pointer_layout.bookkeeping.93:              ; preds = %apush.inbounds.90
  call void @js_string_addref_if_heap_string(double %r557) #7
  %r4427.rs4i = ptrtoint ptr addrspace(1) %.21448 to i64
  %r4427.rs4o = call i64 asm "", "=r,0"(i64 %r4427.rs4i) #7
  %r4427 = bitcast i64 %r4427.rs4o to double
  %r4428 = bitcast double %r4427 to i64
  call void @js_gc_note_slot_layout(i64 %r601, i32 %r622, i64 %r4428) #7
  %r4425.rs4i = ptrtoint ptr addrspace(1) %.21448 to i64
  %r4425.rs4o = call i64 asm "", "=r,0"(i64 %r4425.rs4i) #7
  %r4425 = bitcast i64 %r4425.rs4o to double
  %r4426 = bitcast double %r4425 to i64
  call void @js_array_note_numeric_write(i64 %r601, i64 %r4426) #7
  br label %apush.pointer_layout.done.94

apush.pointer_layout.done.94:                     ; preds = %apush.pointer_layout.bookkeeping.93, %apush.inbounds.90
  %r633 = sub i64 %r601, 7
  %r634 = inttoptr i64 %r633 to ptr
  %r635 = load i8, ptr %r634, align 1
  %r636 = and i8 %r635, 32
  %r637 = icmp ne i8 %r636, 0
  %r638 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r639 = icmp ne i32 %r638, 0
  %r640 = or i1 %r637, %r639
  br i1 %r640, label %apush.barrier.95, label %apush.barrier.done.96

apush.barrier.95:                                 ; preds = %apush.pointer_layout.done.94
  %r4423.rs4i = ptrtoint ptr addrspace(1) %.21448 to i64
  %r4423.rs4o = call i64 asm "", "=r,0"(i64 %r4423.rs4i) #7
  %r4423 = bitcast i64 %r4423.rs4o to double
  %r4424 = bitcast double %r4423 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r601, i64 %r626, i64 %r4424) #7
  br label %apush.barrier.done.96

apush.barrier.done.96:                            ; preds = %apush.barrier.95, %apush.pointer_layout.done.94
  %r641 = add i32 %r622, 1
  %r642 = inttoptr i64 %r601 to ptr
  store i32 %r641, ptr %r642, align 4
  br label %apush.merge.92

apush.fwd.97:                                     ; preds = %apush.elements.check.99, %apush.merge.92
  %statepoint_token205 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r665, double %r662, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r55.2.relocated, ptr addrspace(1) %r55.2.base.relocated, ptr addrspace(1) %rs4gc.s16.relocated201, ptr addrspace(1) %rs4gc.s12.relocated202) ]
  %r702206 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token205)
  %r55.2.relocated207 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token205, i32 1, i32 0) ; (%r55.2.base.relocated, %r55.2.relocated)
  %r55.2.base.relocated208 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token205, i32 1, i32 1) ; (%r55.2.base.relocated, %r55.2.base.relocated)
  %rs4gc.s16.relocated209 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token205, i32 2, i32 2) ; (%rs4gc.s16.relocated201, %rs4gc.s16.relocated201)
  %rs4gc.s12.relocated210 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token205, i32 3, i32 3) ; (%rs4gc.s12.relocated202, %rs4gc.s12.relocated202)
  %r703 = or i64 %r702206, 9222527611924643840
  %r704 = bitcast i64 %r703 to double
  %rs4gc.b25 = bitcast double %r704 to i64
  %rs4gc.s25 = inttoptr i64 %rs4gc.b25 to ptr addrspace(1)
  br label %apush.merge.103

apush.elements.98:                                ; preds = %apush.merge.92
  %r677 = add nuw nsw i64 %r665, 8
  %r678 = inttoptr i64 %r677 to ptr
  %r679 = load i64, ptr %r678, align 8
  %r680 = icmp ne i64 %r679, 0
  %r681 = icmp eq i8 %r668, 2
  %r682 = and i1 %r681, %r680
  %r683 = select i1 %r682, i64 %r679, i64 %r665
  %r684 = inttoptr i64 %r683 to ptr
  %r685 = getelementptr i64, ptr %r684, i64 12
  %r686 = load i64, ptr %r685, align 8
  %r687 = icmp ne i64 %r686, 0
  %r688 = and i1 %r682, %r687
  %r689 = select i1 %r688, i64 %r686, i64 %r665
  %r676 = icmp eq i8 %r668, 1
  br i1 %r676, label %apush.nofwd.100, label %apush.elements.check.99

apush.elements.check.99:                          ; preds = %apush.elements.98
  %r690 = icmp ne i64 %r689, 0
  %r691 = sub i64 %r689, 8
  %r692 = inttoptr i64 %r691 to ptr
  %r693 = load i8, ptr %r692, align 1
  %r694 = icmp eq i8 %r693, 1
  %r695 = sub i64 %r689, 7
  %r696 = inttoptr i64 %r695 to ptr
  %r697 = load i8, ptr %r696, align 1
  %r698 = and i8 %r697, -128
  %r699 = icmp eq i8 %r698, 0
  %r700 = and i1 %r690, %r694
  %r701 = and i1 %r700, %r699
  br i1 %r701, label %apush.nofwd.100, label %apush.fwd.97

apush.nofwd.100:                                  ; preds = %apush.elements.check.99, %apush.elements.98
  %r705 = phi i64 [ %r665, %apush.elements.98 ], [ %r689, %apush.elements.check.99 ]
  %r706 = sub i64 %r705, 6
  %r707 = inttoptr i64 %r706 to ptr
  %r708 = load i16, ptr %r707, align 2
  %r709 = and i16 %r708, 1031
  %r710 = icmp eq i16 %r709, 0
  %r711 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r712 = icmp eq i8 %r711, 0
  %r713 = and i1 %r710, %r712
  %r714 = icmp ult i64 %r705, 4096
  %r715 = inttoptr i64 %r705 to ptr
  %r716 = select i1 %r714, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r715
  %r717 = load i32, ptr %r716, align 4
  %r718 = add i64 %r705, 4
  %r719 = inttoptr i64 %r718 to ptr
  %r720 = load i32, ptr %r719, align 4
  %r721 = icmp ult i32 %r717, %r720
  %r722 = and i1 %r721, %r713
  br i1 %r722, label %apush.inbounds.101, label %apush.realloc.102

apush.inbounds.101:                               ; preds = %apush.nofwd.100
  %r723 = icmp ult i64 %r705, 4096
  %r724 = inttoptr i64 %r705 to ptr
  %r725 = select i1 %r723, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r724
  %r726 = load i32, ptr %r725, align 4
  %r727 = zext i32 %r726 to i64
  %r728 = shl nuw nsw i64 %r727, 3
  %r729 = add nuw nsw i64 %r728, 8
  %r730 = add i64 %r705, %r729
  %r731 = inttoptr i64 %r730 to ptr
  store double %r662, ptr %r731, align 8
  %r732 = lshr i64 %r660, 48
  %r734 = and i16 %r708, -1920
  %r735 = icmp eq i16 %r734, -24576
  br label %apush.pointer_layout.bookkeeping.104

apush.realloc.102:                                ; preds = %apush.nofwd.100
  %statepoint_token211 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r665, double %r662, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r55.2.relocated, ptr addrspace(1) %r55.2.base.relocated, ptr addrspace(1) %rs4gc.s16.relocated201, ptr addrspace(1) %rs4gc.s12.relocated202) ]
  %r747212 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token211)
  %r55.2.relocated213 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 1, i32 0) ; (%r55.2.base.relocated, %r55.2.relocated)
  %r55.2.base.relocated214 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 1, i32 1) ; (%r55.2.base.relocated, %r55.2.base.relocated)
  %rs4gc.s16.relocated215 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 2, i32 2) ; (%rs4gc.s16.relocated201, %rs4gc.s16.relocated201)
  %rs4gc.s12.relocated216 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 3, i32 3) ; (%rs4gc.s12.relocated202, %rs4gc.s12.relocated202)
  %r748 = or i64 %r747212, 9222527611924643840
  %r749 = bitcast i64 %r748 to double
  %rs4gc.b26 = bitcast double %r749 to i64
  %rs4gc.s26 = inttoptr i64 %rs4gc.b26 to ptr addrspace(1)
  br label %apush.merge.103

apush.merge.103:                                  ; preds = %apush.barrier.done.107, %apush.realloc.102, %apush.fwd.97
  %.01460 = phi ptr addrspace(1) [ %r55.2.base.relocated208, %apush.fwd.97 ], [ %r55.2.base.relocated, %apush.barrier.done.107 ], [ %r55.2.base.relocated214, %apush.realloc.102 ]
  %.01459 = phi ptr addrspace(1) [ %r55.2.relocated207, %apush.fwd.97 ], [ %r55.2.relocated, %apush.barrier.done.107 ], [ %r55.2.relocated213, %apush.realloc.102 ]
  %.41450 = phi ptr addrspace(1) [ %rs4gc.s16.relocated209, %apush.fwd.97 ], [ %rs4gc.s16.relocated201, %apush.barrier.done.107 ], [ %rs4gc.s16.relocated215, %apush.realloc.102 ]
  %.9 = phi ptr addrspace(1) [ %rs4gc.s12.relocated210, %apush.fwd.97 ], [ %rs4gc.s12.relocated202, %apush.barrier.done.107 ], [ %rs4gc.s12.relocated216, %apush.realloc.102 ]
  %r48.3.base = phi ptr addrspace(1) [ %rs4gc.s25, %apush.fwd.97 ], [ %r48.2.base.relocated203, %apush.barrier.done.107 ], [ %rs4gc.s26, %apush.realloc.102 ], !is_base_value !0
  %r48.3 = phi ptr addrspace(1) [ %rs4gc.s25, %apush.fwd.97 ], [ %r48.2.relocated204, %apush.barrier.done.107 ], [ %rs4gc.s26, %apush.realloc.102 ]
  %r750.rs4i = ptrtoint ptr addrspace(1) %.41450 to i64
  %r750.rs4o = call i64 asm "", "=r,0"(i64 %r750.rs4i) #7
  %r750 = bitcast i64 %r750.rs4o to double
  %r751 = load double, ptr @test_json_source_token_length_ts_.str.8.handle, align 8
  %statepoint_token217 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_string_concat_box, i32 2, i32 0, double %r750, double %r751, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.3, ptr addrspace(1) %r48.3.base, ptr addrspace(1) %.41450, ptr addrspace(1) %.9, ptr addrspace(1) %.01460, ptr addrspace(1) %.01459) ]
  %r752218 = call double @llvm.experimental.gc.result.f64(token %statepoint_token217)
  %r48.3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token217, i32 1, i32 0) ; (%r48.3.base, %r48.3)
  %r48.3.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token217, i32 1, i32 1) ; (%r48.3.base, %r48.3.base)
  %rs4gc.s16.relocated219 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token217, i32 2, i32 2) ; (%.41450, %.41450)
  %rs4gc.s12.relocated220 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token217, i32 3, i32 3) ; (%.9, %.9)
  %r55.2.base.relocated221 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token217, i32 4, i32 4) ; (%.01460, %.01460)
  %r55.2.relocated222 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token217, i32 4, i32 5) ; (%.01460, %.01459)
  %r753 = bitcast double %r752218 to i64
  %r754.rs4i = ptrtoint ptr addrspace(1) %r55.2.relocated222 to i64
  %r754.rs4o = call i64 asm "", "=r,0"(i64 %r754.rs4i) #7
  %r754 = bitcast i64 %r754.rs4o to double
  %r755 = bitcast double %r754 to i64
  %r756 = and i64 %r755, 281474976710655
  %r757 = sub nsw i64 %r756, 8
  %r758 = inttoptr i64 %r757 to ptr
  %r759 = load i8, ptr %r758, align 1
  %r760 = icmp ne i8 %r759, 1
  %r761 = sub nsw i64 %r756, 7
  %r762 = inttoptr i64 %r761 to ptr
  %r763 = load i8, ptr %r762, align 1
  %r764 = and i8 %r763, -128
  %r765 = icmp ne i8 %r764, 0
  %r766 = or i1 %r760, %r765
  br i1 %r765, label %apush.fwd.108, label %apush.elements.109

apush.pointer_layout.bookkeeping.104:             ; preds = %apush.inbounds.101
  call void @js_string_addref_if_heap_string(double %r662) #7
  call void @js_gc_note_slot_layout(i64 %r705, i32 %r726, i64 %r660) #7
  call void @js_array_note_numeric_write(i64 %r705, i64 %r660) #7
  br label %apush.pointer_layout.done.105

apush.pointer_layout.done.105:                    ; preds = %apush.pointer_layout.bookkeeping.104
  %r737 = sub i64 %r705, 7
  %r738 = inttoptr i64 %r737 to ptr
  %r739 = load i8, ptr %r738, align 1
  %r740 = and i8 %r739, 32
  %r741 = icmp ne i8 %r740, 0
  %r742 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r743 = icmp ne i32 %r742, 0
  %r744 = or i1 %r741, %r743
  br i1 %r744, label %apush.barrier.106, label %apush.barrier.done.107

apush.barrier.106:                                ; preds = %apush.pointer_layout.done.105
  call void @js_write_barrier_slot_validated_parent(i64 %r705, i64 %r730, i64 %r660) #7
  br label %apush.barrier.done.107

apush.barrier.done.107:                           ; preds = %apush.barrier.106, %apush.pointer_layout.done.105
  %r745 = add i32 %r726, 1
  %r746 = inttoptr i64 %r705 to ptr
  store i32 %r745, ptr %r746, align 4
  br label %apush.merge.103

apush.fwd.108:                                    ; preds = %apush.elements.check.110, %apush.merge.103
  %statepoint_token223 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r756, double %r752218, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.3.relocated, ptr addrspace(1) %r48.3.base.relocated, ptr addrspace(1) %rs4gc.s16.relocated219, ptr addrspace(1) %rs4gc.s12.relocated220) ]
  %r793224 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token223)
  %r48.3.relocated225 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token223, i32 1, i32 0) ; (%r48.3.base.relocated, %r48.3.relocated)
  %r48.3.base.relocated226 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token223, i32 1, i32 1) ; (%r48.3.base.relocated, %r48.3.base.relocated)
  %rs4gc.s16.relocated227 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token223, i32 2, i32 2) ; (%rs4gc.s16.relocated219, %rs4gc.s16.relocated219)
  %rs4gc.s12.relocated228 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token223, i32 3, i32 3) ; (%rs4gc.s12.relocated220, %rs4gc.s12.relocated220)
  %r794 = or i64 %r793224, 9222527611924643840
  %r795 = bitcast i64 %r794 to double
  %rs4gc.b27 = bitcast double %r795 to i64
  %rs4gc.s27 = inttoptr i64 %rs4gc.b27 to ptr addrspace(1)
  br label %apush.merge.114

apush.elements.109:                               ; preds = %apush.merge.103
  %r768 = add nuw nsw i64 %r756, 8
  %r769 = inttoptr i64 %r768 to ptr
  %r770 = load i64, ptr %r769, align 8
  %r771 = icmp ne i64 %r770, 0
  %r772 = icmp eq i8 %r759, 2
  %r773 = and i1 %r772, %r771
  %r774 = select i1 %r773, i64 %r770, i64 %r756
  %r775 = inttoptr i64 %r774 to ptr
  %r776 = getelementptr i64, ptr %r775, i64 12
  %r777 = load i64, ptr %r776, align 8
  %r778 = icmp ne i64 %r777, 0
  %r779 = and i1 %r773, %r778
  %r780 = select i1 %r779, i64 %r777, i64 %r756
  %r767 = icmp eq i8 %r759, 1
  br i1 %r767, label %apush.nofwd.111, label %apush.elements.check.110

apush.elements.check.110:                         ; preds = %apush.elements.109
  %r781 = icmp ne i64 %r780, 0
  %r782 = sub i64 %r780, 8
  %r783 = inttoptr i64 %r782 to ptr
  %r784 = load i8, ptr %r783, align 1
  %r785 = icmp eq i8 %r784, 1
  %r786 = sub i64 %r780, 7
  %r787 = inttoptr i64 %r786 to ptr
  %r788 = load i8, ptr %r787, align 1
  %r789 = and i8 %r788, -128
  %r790 = icmp eq i8 %r789, 0
  %r791 = and i1 %r781, %r785
  %r792 = and i1 %r791, %r790
  br i1 %r792, label %apush.nofwd.111, label %apush.fwd.108

apush.nofwd.111:                                  ; preds = %apush.elements.check.110, %apush.elements.109
  %r796 = phi i64 [ %r756, %apush.elements.109 ], [ %r780, %apush.elements.check.110 ]
  %r797 = sub i64 %r796, 6
  %r798 = inttoptr i64 %r797 to ptr
  %r799 = load i16, ptr %r798, align 2
  %r800 = and i16 %r799, 1031
  %r801 = icmp eq i16 %r800, 0
  %r802 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r803 = icmp eq i8 %r802, 0
  %r804 = and i1 %r801, %r803
  %r805 = icmp ult i64 %r796, 4096
  %r806 = inttoptr i64 %r796 to ptr
  %r807 = select i1 %r805, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r806
  %r808 = load i32, ptr %r807, align 4
  %r809 = add i64 %r796, 4
  %r810 = inttoptr i64 %r809 to ptr
  %r811 = load i32, ptr %r810, align 4
  %r812 = icmp ult i32 %r808, %r811
  %r813 = and i1 %r812, %r804
  br i1 %r813, label %apush.inbounds.112, label %apush.realloc.113

apush.inbounds.112:                               ; preds = %apush.nofwd.111
  %r814 = icmp ult i64 %r796, 4096
  %r815 = inttoptr i64 %r796 to ptr
  %r816 = select i1 %r814, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r815
  %r817 = load i32, ptr %r816, align 4
  %r818 = zext i32 %r817 to i64
  %r819 = shl nuw nsw i64 %r818, 3
  %r820 = add nuw nsw i64 %r819, 8
  %r821 = add i64 %r796, %r820
  %r822 = inttoptr i64 %r821 to ptr
  store double %r752218, ptr %r822, align 8
  %r823 = lshr i64 %r753, 48
  %r824 = icmp eq i64 %r823, 32765
  %r825 = and i16 %r799, -1920
  %r826 = icmp eq i16 %r825, -24576
  %r827 = and i1 %r824, %r826
  br i1 %r827, label %apush.pointer_layout.done.116, label %apush.pointer_layout.bookkeeping.115

apush.realloc.113:                                ; preds = %apush.nofwd.111
  %statepoint_token229 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r756, double %r752218, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.3.relocated, ptr addrspace(1) %r48.3.base.relocated, ptr addrspace(1) %rs4gc.s16.relocated219, ptr addrspace(1) %rs4gc.s12.relocated220) ]
  %r838230 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token229)
  %r48.3.relocated231 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token229, i32 1, i32 0) ; (%r48.3.base.relocated, %r48.3.relocated)
  %r48.3.base.relocated232 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token229, i32 1, i32 1) ; (%r48.3.base.relocated, %r48.3.base.relocated)
  %rs4gc.s16.relocated233 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token229, i32 2, i32 2) ; (%rs4gc.s16.relocated219, %rs4gc.s16.relocated219)
  %rs4gc.s12.relocated234 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token229, i32 3, i32 3) ; (%rs4gc.s12.relocated220, %rs4gc.s12.relocated220)
  %r839 = or i64 %r838230, 9222527611924643840
  %r840 = bitcast i64 %r839 to double
  %rs4gc.b28 = bitcast double %r840 to i64
  %rs4gc.s28 = inttoptr i64 %rs4gc.b28 to ptr addrspace(1)
  br label %apush.merge.114

apush.merge.114:                                  ; preds = %apush.barrier.done.118, %apush.realloc.113, %apush.fwd.108
  %.01462 = phi ptr addrspace(1) [ %r48.3.base.relocated226, %apush.fwd.108 ], [ %r48.3.base.relocated, %apush.barrier.done.118 ], [ %r48.3.base.relocated232, %apush.realloc.113 ]
  %.01461 = phi ptr addrspace(1) [ %r48.3.relocated225, %apush.fwd.108 ], [ %r48.3.relocated, %apush.barrier.done.118 ], [ %r48.3.relocated231, %apush.realloc.113 ]
  %.51451 = phi ptr addrspace(1) [ %rs4gc.s16.relocated227, %apush.fwd.108 ], [ %rs4gc.s16.relocated219, %apush.barrier.done.118 ], [ %rs4gc.s16.relocated233, %apush.realloc.113 ]
  %.10 = phi ptr addrspace(1) [ %rs4gc.s12.relocated228, %apush.fwd.108 ], [ %rs4gc.s12.relocated220, %apush.barrier.done.118 ], [ %rs4gc.s12.relocated234, %apush.realloc.113 ]
  %r55.3.base = phi ptr addrspace(1) [ %rs4gc.s27, %apush.fwd.108 ], [ %r55.2.base.relocated221, %apush.barrier.done.118 ], [ %rs4gc.s28, %apush.realloc.113 ], !is_base_value !0
  %r55.3 = phi ptr addrspace(1) [ %rs4gc.s27, %apush.fwd.108 ], [ %r55.2.relocated222, %apush.barrier.done.118 ], [ %rs4gc.s28, %apush.realloc.113 ]
  %r841 = load double, ptr @test_json_source_token_length_ts_.str.9.handle, align 8
  %statepoint_token235 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r841, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10, ptr addrspace(1) %r55.3.base, ptr addrspace(1) %r55.3, ptr addrspace(1) %.51451, ptr addrspace(1) %.01462, ptr addrspace(1) %.01461) ]
  %r842236 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token235)
  %rs4gc.s12.relocated237 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 0, i32 0) ; (%.10, %.10)
  %r55.3.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 1, i32 1) ; (%r55.3.base, %r55.3.base)
  %r55.3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 1, i32 2) ; (%r55.3.base, %r55.3)
  %rs4gc.s16.relocated238 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 3, i32 3) ; (%.51451, %.51451)
  %r48.3.base.relocated239 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 4, i32 4) ; (%.01462, %.01462)
  %r48.3.relocated240 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 4, i32 5) ; (%.01462, %.01461)
  %statepoint_token241 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_string_repeat, i32 2, i32 0, i64 %r842236, double 2.570000e+02, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s12.relocated237, ptr addrspace(1) %r55.3.base.relocated, ptr addrspace(1) %r55.3.relocated, ptr addrspace(1) %rs4gc.s16.relocated238, ptr addrspace(1) %r48.3.base.relocated239, ptr addrspace(1) %r48.3.relocated240) ]
  %r843242 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token241)
  %rs4gc.s12.relocated243 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token241, i32 0, i32 0) ; (%rs4gc.s12.relocated237, %rs4gc.s12.relocated237)
  %r55.3.base.relocated244 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token241, i32 1, i32 1) ; (%r55.3.base.relocated, %r55.3.base.relocated)
  %r55.3.relocated245 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token241, i32 1, i32 2) ; (%r55.3.base.relocated, %r55.3.relocated)
  %rs4gc.s16.relocated246 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token241, i32 3, i32 3) ; (%rs4gc.s16.relocated238, %rs4gc.s16.relocated238)
  %r48.3.base.relocated247 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token241, i32 4, i32 4) ; (%r48.3.base.relocated239, %r48.3.base.relocated239)
  %r48.3.relocated248 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token241, i32 4, i32 5) ; (%r48.3.base.relocated239, %r48.3.relocated240)
  %r844 = or i64 %r843242, 9223090561878065152
  %r845 = bitcast i64 %r844 to double
  %r846 = load double, ptr @test_json_source_token_length_ts_.str.3.handle, align 8
  %r848 = sitofp i32 %r62.0 to double
  %r849 = load double, ptr @test_json_source_token_length_ts_.str.4.handle, align 8
  %r850.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16.relocated246 to i64
  %r850.rs4o = call i64 asm "", "=r,0"(i64 %r850.rs4i) #7
  %r850 = bitcast i64 %r850.rs4o to double
  %r851 = load double, ptr @test_json_source_token_length_ts_.str.5.handle, align 8
  %r853 = getelementptr double, ptr %r852, i64 0
  store double %r845, ptr %r853, align 8
  %r854 = getelementptr double, ptr %r852, i64 1
  store double %r846, ptr %r854, align 8
  %r855 = getelementptr double, ptr %r852, i64 2
  store double %r848, ptr %r855, align 8
  %r856 = getelementptr double, ptr %r852, i64 3
  store double %r849, ptr %r856, align 8
  %r857 = getelementptr double, ptr %r852, i64 4
  store double %r850, ptr %r857, align 8
  %r858 = getelementptr double, ptr %r852, i64 5
  store double %r851, ptr %r858, align 8
  %r859 = ptrtoint ptr %r852 to i64
  %statepoint_token249 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r859, i32 6, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s12.relocated243, ptr addrspace(1) %r55.3.base.relocated244, ptr addrspace(1) %r55.3.relocated245, ptr addrspace(1) %rs4gc.s16.relocated246, ptr addrspace(1) %r48.3.base.relocated247, ptr addrspace(1) %r48.3.relocated248) ]
  %r860250 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token249)
  %rs4gc.s12.relocated251 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token249, i32 0, i32 0) ; (%rs4gc.s12.relocated243, %rs4gc.s12.relocated243)
  %r55.3.base.relocated252 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token249, i32 1, i32 1) ; (%r55.3.base.relocated244, %r55.3.base.relocated244)
  %r55.3.relocated253 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token249, i32 1, i32 2) ; (%r55.3.base.relocated244, %r55.3.relocated245)
  %rs4gc.s16.relocated254 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token249, i32 3, i32 3) ; (%rs4gc.s16.relocated246, %rs4gc.s16.relocated246)
  %r48.3.base.relocated255 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token249, i32 4, i32 4) ; (%r48.3.base.relocated247, %r48.3.base.relocated247)
  %r48.3.relocated256 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token249, i32 4, i32 5) ; (%r48.3.base.relocated247, %r48.3.relocated248)
  %r861 = or i64 %r860250, 9223090561878065152
  %r862 = bitcast i64 %r861 to double
  %r863 = bitcast i64 %r861 to double
  %r864.rs4i = ptrtoint ptr addrspace(1) %r48.3.relocated256 to i64
  %r864.rs4o = call i64 asm "", "=r,0"(i64 %r864.rs4i) #7
  %r864 = bitcast i64 %r864.rs4o to double
  %r865 = bitcast double %r864 to i64
  %r866 = and i64 %r865, 281474976710655
  %r867 = sub nsw i64 %r866, 8
  %r868 = inttoptr i64 %r867 to ptr
  %r869 = load i8, ptr %r868, align 1
  %r870 = icmp ne i8 %r869, 1
  %r871 = sub nsw i64 %r866, 7
  %r872 = inttoptr i64 %r871 to ptr
  %r873 = load i8, ptr %r872, align 1
  %r874 = and i8 %r873, -128
  %r875 = icmp ne i8 %r874, 0
  %r876 = or i1 %r870, %r875
  br i1 %r875, label %apush.fwd.119, label %apush.elements.120

apush.pointer_layout.bookkeeping.115:             ; preds = %apush.inbounds.112
  call void @js_string_addref_if_heap_string(double %r752218) #7
  call void @js_gc_note_slot_layout(i64 %r796, i32 %r817, i64 %r753) #7
  call void @js_array_note_numeric_write(i64 %r796, i64 %r753) #7
  br label %apush.pointer_layout.done.116

apush.pointer_layout.done.116:                    ; preds = %apush.pointer_layout.bookkeeping.115, %apush.inbounds.112
  %r828 = sub i64 %r796, 7
  %r829 = inttoptr i64 %r828 to ptr
  %r830 = load i8, ptr %r829, align 1
  %r831 = and i8 %r830, 32
  %r832 = icmp ne i8 %r831, 0
  %r833 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r834 = icmp ne i32 %r833, 0
  %r835 = or i1 %r832, %r834
  br i1 %r835, label %apush.barrier.117, label %apush.barrier.done.118

apush.barrier.117:                                ; preds = %apush.pointer_layout.done.116
  call void @js_write_barrier_slot_validated_parent(i64 %r796, i64 %r821, i64 %r753) #7
  br label %apush.barrier.done.118

apush.barrier.done.118:                           ; preds = %apush.barrier.117, %apush.pointer_layout.done.116
  %r836 = add i32 %r817, 1
  %r837 = inttoptr i64 %r796 to ptr
  store i32 %r836, ptr %r837, align 4
  br label %apush.merge.114

apush.fwd.119:                                    ; preds = %apush.elements.check.121, %apush.merge.114
  %statepoint_token257 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r866, double %r863, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s12.relocated251, ptr addrspace(1) %r55.3.base.relocated252, ptr addrspace(1) %r55.3.relocated253, ptr addrspace(1) %rs4gc.s16.relocated254) ]
  %r903258 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token257)
  %rs4gc.s12.relocated259 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token257, i32 0, i32 0) ; (%rs4gc.s12.relocated251, %rs4gc.s12.relocated251)
  %r55.3.base.relocated260 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token257, i32 1, i32 1) ; (%r55.3.base.relocated252, %r55.3.base.relocated252)
  %r55.3.relocated261 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token257, i32 1, i32 2) ; (%r55.3.base.relocated252, %r55.3.relocated253)
  %rs4gc.s16.relocated262 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token257, i32 3, i32 3) ; (%rs4gc.s16.relocated254, %rs4gc.s16.relocated254)
  %r904 = or i64 %r903258, 9222527611924643840
  %r905 = bitcast i64 %r904 to double
  %rs4gc.b29 = bitcast double %r905 to i64
  %rs4gc.s29 = inttoptr i64 %rs4gc.b29 to ptr addrspace(1)
  br label %apush.merge.125

apush.elements.120:                               ; preds = %apush.merge.114
  %r878 = add nuw nsw i64 %r866, 8
  %r879 = inttoptr i64 %r878 to ptr
  %r880 = load i64, ptr %r879, align 8
  %r881 = icmp ne i64 %r880, 0
  %r882 = icmp eq i8 %r869, 2
  %r883 = and i1 %r882, %r881
  %r884 = select i1 %r883, i64 %r880, i64 %r866
  %r885 = inttoptr i64 %r884 to ptr
  %r886 = getelementptr i64, ptr %r885, i64 12
  %r887 = load i64, ptr %r886, align 8
  %r888 = icmp ne i64 %r887, 0
  %r889 = and i1 %r883, %r888
  %r890 = select i1 %r889, i64 %r887, i64 %r866
  %r877 = icmp eq i8 %r869, 1
  br i1 %r877, label %apush.nofwd.122, label %apush.elements.check.121

apush.elements.check.121:                         ; preds = %apush.elements.120
  %r891 = icmp ne i64 %r890, 0
  %r892 = sub i64 %r890, 8
  %r893 = inttoptr i64 %r892 to ptr
  %r894 = load i8, ptr %r893, align 1
  %r895 = icmp eq i8 %r894, 1
  %r896 = sub i64 %r890, 7
  %r897 = inttoptr i64 %r896 to ptr
  %r898 = load i8, ptr %r897, align 1
  %r899 = and i8 %r898, -128
  %r900 = icmp eq i8 %r899, 0
  %r901 = and i1 %r891, %r895
  %r902 = and i1 %r901, %r900
  br i1 %r902, label %apush.nofwd.122, label %apush.fwd.119

apush.nofwd.122:                                  ; preds = %apush.elements.check.121, %apush.elements.120
  %r906 = phi i64 [ %r866, %apush.elements.120 ], [ %r890, %apush.elements.check.121 ]
  %r907 = sub i64 %r906, 6
  %r908 = inttoptr i64 %r907 to ptr
  %r909 = load i16, ptr %r908, align 2
  %r910 = and i16 %r909, 1031
  %r911 = icmp eq i16 %r910, 0
  %r912 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r913 = icmp eq i8 %r912, 0
  %r914 = and i1 %r911, %r913
  %r915 = icmp ult i64 %r906, 4096
  %r916 = inttoptr i64 %r906 to ptr
  %r917 = select i1 %r915, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r916
  %r918 = load i32, ptr %r917, align 4
  %r919 = add i64 %r906, 4
  %r920 = inttoptr i64 %r919 to ptr
  %r921 = load i32, ptr %r920, align 4
  %r922 = icmp ult i32 %r918, %r921
  %r923 = and i1 %r922, %r914
  br i1 %r923, label %apush.inbounds.123, label %apush.realloc.124

apush.inbounds.123:                               ; preds = %apush.nofwd.122
  %r924 = icmp ult i64 %r906, 4096
  %r925 = inttoptr i64 %r906 to ptr
  %r926 = select i1 %r924, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r925
  %r927 = load i32, ptr %r926, align 4
  %r928 = zext i32 %r927 to i64
  %r929 = shl nuw nsw i64 %r928, 3
  %r930 = add nuw nsw i64 %r929, 8
  %r931 = add i64 %r906, %r930
  %r932 = inttoptr i64 %r931 to ptr
  store double %r863, ptr %r932, align 8
  %r933 = lshr i64 %r861, 48
  %r935 = and i16 %r909, -1920
  %r936 = icmp eq i16 %r935, -24576
  br label %apush.pointer_layout.bookkeeping.126

apush.realloc.124:                                ; preds = %apush.nofwd.122
  %statepoint_token263 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r866, double %r863, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s12.relocated251, ptr addrspace(1) %r55.3.base.relocated252, ptr addrspace(1) %r55.3.relocated253, ptr addrspace(1) %rs4gc.s16.relocated254) ]
  %r948264 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token263)
  %rs4gc.s12.relocated265 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token263, i32 0, i32 0) ; (%rs4gc.s12.relocated251, %rs4gc.s12.relocated251)
  %r55.3.base.relocated266 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token263, i32 1, i32 1) ; (%r55.3.base.relocated252, %r55.3.base.relocated252)
  %r55.3.relocated267 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token263, i32 1, i32 2) ; (%r55.3.base.relocated252, %r55.3.relocated253)
  %rs4gc.s16.relocated268 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token263, i32 3, i32 3) ; (%rs4gc.s16.relocated254, %rs4gc.s16.relocated254)
  %r949 = or i64 %r948264, 9222527611924643840
  %r950 = bitcast i64 %r949 to double
  %rs4gc.b30 = bitcast double %r950 to i64
  %rs4gc.s30 = inttoptr i64 %rs4gc.b30 to ptr addrspace(1)
  br label %apush.merge.125

apush.merge.125:                                  ; preds = %apush.barrier.done.129, %apush.realloc.124, %apush.fwd.119
  %.01464 = phi ptr addrspace(1) [ %r55.3.relocated261, %apush.fwd.119 ], [ %r55.3.relocated253, %apush.barrier.done.129 ], [ %r55.3.relocated267, %apush.realloc.124 ]
  %.01463 = phi ptr addrspace(1) [ %r55.3.base.relocated260, %apush.fwd.119 ], [ %r55.3.base.relocated252, %apush.barrier.done.129 ], [ %r55.3.base.relocated266, %apush.realloc.124 ]
  %.61452 = phi ptr addrspace(1) [ %rs4gc.s16.relocated262, %apush.fwd.119 ], [ %rs4gc.s16.relocated254, %apush.barrier.done.129 ], [ %rs4gc.s16.relocated268, %apush.realloc.124 ]
  %.11 = phi ptr addrspace(1) [ %rs4gc.s12.relocated259, %apush.fwd.119 ], [ %rs4gc.s12.relocated251, %apush.barrier.done.129 ], [ %rs4gc.s12.relocated265, %apush.realloc.124 ]
  %r48.4.base = phi ptr addrspace(1) [ %rs4gc.s29, %apush.fwd.119 ], [ %r48.3.base.relocated255, %apush.barrier.done.129 ], [ %rs4gc.s30, %apush.realloc.124 ], !is_base_value !0
  %r48.4 = phi ptr addrspace(1) [ %rs4gc.s29, %apush.fwd.119 ], [ %r48.3.relocated256, %apush.barrier.done.129 ], [ %rs4gc.s30, %apush.realloc.124 ]
  %r951.rs4i = ptrtoint ptr addrspace(1) %.61452 to i64
  %r951.rs4o = call i64 asm "", "=r,0"(i64 %r951.rs4i) #7
  %r951 = bitcast i64 %r951.rs4o to double
  %r952 = bitcast double %r951 to i64
  %r953.rs4i = ptrtoint ptr addrspace(1) %.01464 to i64
  %r953.rs4o = call i64 asm "", "=r,0"(i64 %r953.rs4i) #7
  %r953 = bitcast i64 %r953.rs4o to double
  %r954 = bitcast double %r953 to i64
  %r955 = and i64 %r954, 281474976710655
  %r956 = sub nsw i64 %r955, 8
  %r957 = inttoptr i64 %r956 to ptr
  %r958 = load i8, ptr %r957, align 1
  %r959 = icmp ne i8 %r958, 1
  %r960 = sub nsw i64 %r955, 7
  %r961 = inttoptr i64 %r960 to ptr
  %r962 = load i8, ptr %r961, align 1
  %r963 = and i8 %r962, -128
  %r964 = icmp ne i8 %r963, 0
  %r965 = or i1 %r959, %r964
  br i1 %r964, label %apush.fwd.130, label %apush.elements.131

apush.pointer_layout.bookkeeping.126:             ; preds = %apush.inbounds.123
  call void @js_string_addref_if_heap_string(double %r863) #7
  call void @js_gc_note_slot_layout(i64 %r906, i32 %r927, i64 %r861) #7
  call void @js_array_note_numeric_write(i64 %r906, i64 %r861) #7
  br label %apush.pointer_layout.done.127

apush.pointer_layout.done.127:                    ; preds = %apush.pointer_layout.bookkeeping.126
  %r938 = sub i64 %r906, 7
  %r939 = inttoptr i64 %r938 to ptr
  %r940 = load i8, ptr %r939, align 1
  %r941 = and i8 %r940, 32
  %r942 = icmp ne i8 %r941, 0
  %r943 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r944 = icmp ne i32 %r943, 0
  %r945 = or i1 %r942, %r944
  br i1 %r945, label %apush.barrier.128, label %apush.barrier.done.129

apush.barrier.128:                                ; preds = %apush.pointer_layout.done.127
  call void @js_write_barrier_slot_validated_parent(i64 %r906, i64 %r931, i64 %r861) #7
  br label %apush.barrier.done.129

apush.barrier.done.129:                           ; preds = %apush.barrier.128, %apush.pointer_layout.done.127
  %r946 = add i32 %r927, 1
  %r947 = inttoptr i64 %r906 to ptr
  store i32 %r946, ptr %r947, align 4
  br label %apush.merge.125

apush.fwd.130:                                    ; preds = %apush.elements.check.132, %apush.merge.125
  %statepoint_token269 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r955, double %r951, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.4.base, ptr addrspace(1) %.11, ptr addrspace(1) %r48.4) ]
  %r992270 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token269)
  %r48.4.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token269, i32 0, i32 0) ; (%r48.4.base, %r48.4.base)
  %rs4gc.s12.relocated271 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token269, i32 1, i32 1) ; (%.11, %.11)
  %r48.4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token269, i32 0, i32 2) ; (%r48.4.base, %r48.4)
  %r993 = or i64 %r992270, 9222527611924643840
  %r994 = bitcast i64 %r993 to double
  %rs4gc.b31 = bitcast double %r994 to i64
  %rs4gc.s31 = inttoptr i64 %rs4gc.b31 to ptr addrspace(1)
  br label %apush.merge.136

apush.elements.131:                               ; preds = %apush.merge.125
  %r967 = add nuw nsw i64 %r955, 8
  %r968 = inttoptr i64 %r967 to ptr
  %r969 = load i64, ptr %r968, align 8
  %r970 = icmp ne i64 %r969, 0
  %r971 = icmp eq i8 %r958, 2
  %r972 = and i1 %r971, %r970
  %r973 = select i1 %r972, i64 %r969, i64 %r955
  %r974 = inttoptr i64 %r973 to ptr
  %r975 = getelementptr i64, ptr %r974, i64 12
  %r976 = load i64, ptr %r975, align 8
  %r977 = icmp ne i64 %r976, 0
  %r978 = and i1 %r972, %r977
  %r979 = select i1 %r978, i64 %r976, i64 %r955
  %r966 = icmp eq i8 %r958, 1
  br i1 %r966, label %apush.nofwd.133, label %apush.elements.check.132

apush.elements.check.132:                         ; preds = %apush.elements.131
  %r980 = icmp ne i64 %r979, 0
  %r981 = sub i64 %r979, 8
  %r982 = inttoptr i64 %r981 to ptr
  %r983 = load i8, ptr %r982, align 1
  %r984 = icmp eq i8 %r983, 1
  %r985 = sub i64 %r979, 7
  %r986 = inttoptr i64 %r985 to ptr
  %r987 = load i8, ptr %r986, align 1
  %r988 = and i8 %r987, -128
  %r989 = icmp eq i8 %r988, 0
  %r990 = and i1 %r980, %r984
  %r991 = and i1 %r990, %r989
  br i1 %r991, label %apush.nofwd.133, label %apush.fwd.130

apush.nofwd.133:                                  ; preds = %apush.elements.check.132, %apush.elements.131
  %r995 = phi i64 [ %r955, %apush.elements.131 ], [ %r979, %apush.elements.check.132 ]
  %r996 = sub i64 %r995, 6
  %r997 = inttoptr i64 %r996 to ptr
  %r998 = load i16, ptr %r997, align 2
  %r999 = and i16 %r998, 1031
  %r1000 = icmp eq i16 %r999, 0
  %r1001 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1002 = icmp eq i8 %r1001, 0
  %r1003 = and i1 %r1000, %r1002
  %r1004 = icmp ult i64 %r995, 4096
  %r1005 = inttoptr i64 %r995 to ptr
  %r1006 = select i1 %r1004, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r1005
  %r1007 = load i32, ptr %r1006, align 4
  %r1008 = add i64 %r995, 4
  %r1009 = inttoptr i64 %r1008 to ptr
  %r1010 = load i32, ptr %r1009, align 4
  %r1011 = icmp ult i32 %r1007, %r1010
  %r1012 = and i1 %r1011, %r1003
  br i1 %r1012, label %apush.inbounds.134, label %apush.realloc.135

apush.inbounds.134:                               ; preds = %apush.nofwd.133
  %r1013 = icmp ult i64 %r995, 4096
  %r1014 = inttoptr i64 %r995 to ptr
  %r1015 = select i1 %r1013, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r1014
  %r1016 = load i32, ptr %r1015, align 4
  %r1017 = zext i32 %r1016 to i64
  %r1018 = shl nuw nsw i64 %r1017, 3
  %r1019 = add nuw nsw i64 %r1018, 8
  %r1020 = add i64 %r995, %r1019
  %r1021 = inttoptr i64 %r1020 to ptr
  store double %r951, ptr %r1021, align 8
  %r1022 = lshr i64 %r952, 48
  %r1023 = icmp eq i64 %r1022, 32765
  %r1024 = and i16 %r998, -1920
  %r1025 = icmp eq i16 %r1024, -24576
  %r1026 = and i1 %r1023, %r1025
  br i1 %r1026, label %apush.pointer_layout.done.138, label %apush.pointer_layout.bookkeeping.137

apush.realloc.135:                                ; preds = %apush.nofwd.133
  %statepoint_token272 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r955, double %r951, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.4.base, ptr addrspace(1) %.11, ptr addrspace(1) %r48.4) ]
  %r1037273 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token272)
  %r48.4.base.relocated274 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token272, i32 0, i32 0) ; (%r48.4.base, %r48.4.base)
  %rs4gc.s12.relocated275 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token272, i32 1, i32 1) ; (%.11, %.11)
  %r48.4.relocated276 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token272, i32 0, i32 2) ; (%r48.4.base, %r48.4)
  %r1038 = or i64 %r1037273, 9222527611924643840
  %r1039 = bitcast i64 %r1038 to double
  %rs4gc.b32 = bitcast double %r1039 to i64
  %rs4gc.s32 = inttoptr i64 %rs4gc.b32 to ptr addrspace(1)
  br label %apush.merge.136

apush.merge.136:                                  ; preds = %apush.barrier.done.140, %apush.realloc.135, %apush.fwd.130
  %.01467 = phi ptr addrspace(1) [ %r48.4.relocated, %apush.fwd.130 ], [ %r48.4, %apush.barrier.done.140 ], [ %r48.4.relocated276, %apush.realloc.135 ]
  %.01465 = phi ptr addrspace(1) [ %r48.4.base.relocated, %apush.fwd.130 ], [ %r48.4.base, %apush.barrier.done.140 ], [ %r48.4.base.relocated274, %apush.realloc.135 ]
  %.12 = phi ptr addrspace(1) [ %rs4gc.s12.relocated271, %apush.fwd.130 ], [ %.11, %apush.barrier.done.140 ], [ %rs4gc.s12.relocated275, %apush.realloc.135 ]
  %r55.4.base = phi ptr addrspace(1) [ %rs4gc.s31, %apush.fwd.130 ], [ %.01463, %apush.barrier.done.140 ], [ %rs4gc.s32, %apush.realloc.135 ], !is_base_value !0
  %r55.4 = phi ptr addrspace(1) [ %rs4gc.s31, %apush.fwd.130 ], [ %.01464, %apush.barrier.done.140 ], [ %rs4gc.s32, %apush.realloc.135 ]
  %r1040 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1041 = icmp ne i32 %r1040, 0
  br i1 %r1041, label %gcpoll.141, label %gcpoll.done.142

apush.pointer_layout.bookkeeping.137:             ; preds = %apush.inbounds.134
  call void @js_string_addref_if_heap_string(double %r951) #7
  %r4421.rs4i = ptrtoint ptr addrspace(1) %.61452 to i64
  %r4421.rs4o = call i64 asm "", "=r,0"(i64 %r4421.rs4i) #7
  %r4421 = bitcast i64 %r4421.rs4o to double
  %r4422 = bitcast double %r4421 to i64
  call void @js_gc_note_slot_layout(i64 %r995, i32 %r1016, i64 %r4422) #7
  %r4419.rs4i = ptrtoint ptr addrspace(1) %.61452 to i64
  %r4419.rs4o = call i64 asm "", "=r,0"(i64 %r4419.rs4i) #7
  %r4419 = bitcast i64 %r4419.rs4o to double
  %r4420 = bitcast double %r4419 to i64
  call void @js_array_note_numeric_write(i64 %r995, i64 %r4420) #7
  br label %apush.pointer_layout.done.138

apush.pointer_layout.done.138:                    ; preds = %apush.pointer_layout.bookkeeping.137, %apush.inbounds.134
  %r1027 = sub i64 %r995, 7
  %r1028 = inttoptr i64 %r1027 to ptr
  %r1029 = load i8, ptr %r1028, align 1
  %r1030 = and i8 %r1029, 32
  %r1031 = icmp ne i8 %r1030, 0
  %r1032 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1033 = icmp ne i32 %r1032, 0
  %r1034 = or i1 %r1031, %r1033
  br i1 %r1034, label %apush.barrier.139, label %apush.barrier.done.140

apush.barrier.139:                                ; preds = %apush.pointer_layout.done.138
  %r4417.rs4i = ptrtoint ptr addrspace(1) %.61452 to i64
  %r4417.rs4o = call i64 asm "", "=r,0"(i64 %r4417.rs4i) #7
  %r4417 = bitcast i64 %r4417.rs4o to double
  %r4418 = bitcast double %r4417 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r995, i64 %r1020, i64 %r4418) #7
  br label %apush.barrier.done.140

apush.barrier.done.140:                           ; preds = %apush.barrier.139, %apush.pointer_layout.done.138
  %r1035 = add i32 %r1016, 1
  %r1036 = inttoptr i64 %r995 to ptr
  store i32 %r1035, ptr %r1036, align 4
  br label %apush.merge.136

gcpoll.141:                                       ; preds = %apush.merge.136
  %statepoint_token277 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r55.4.base, ptr addrspace(1) %r55.4, ptr addrspace(1) %.01465, ptr addrspace(1) %.01467, ptr addrspace(1) %.12) ]
  %r55.4.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token277, i32 0, i32 0) ; (%r55.4.base, %r55.4.base)
  %r55.4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token277, i32 0, i32 1) ; (%r55.4.base, %r55.4)
  %r48.4.base.relocated278 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token277, i32 2, i32 2) ; (%.01465, %.01465)
  %r48.4.relocated279 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token277, i32 2, i32 3) ; (%.01465, %.01467)
  %rs4gc.s12.relocated280 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token277, i32 4, i32 4) ; (%.12, %.12)
  br label %gcpoll.done.142

gcpoll.done.142:                                  ; preds = %gcpoll.141, %apush.merge.136
  %.01470 = phi ptr addrspace(1) [ %r55.4.relocated, %gcpoll.141 ], [ %r55.4, %apush.merge.136 ]
  %.01469 = phi ptr addrspace(1) [ %r55.4.base.relocated, %gcpoll.141 ], [ %r55.4.base, %apush.merge.136 ]
  %.11468 = phi ptr addrspace(1) [ %r48.4.relocated279, %gcpoll.141 ], [ %.01467, %apush.merge.136 ]
  %.11466 = phi ptr addrspace(1) [ %r48.4.base.relocated278, %gcpoll.141 ], [ %.01465, %apush.merge.136 ]
  %.13 = phi ptr addrspace(1) [ %rs4gc.s12.relocated280, %gcpoll.141 ], [ %.12, %apush.merge.136 ]
  br label %for.update.19

shadow.root.barrier.143:                          ; preds = %for.exit.20
  call void @js_write_barrier_root_nanbox(i64 %r1050) #7
  br label %shadow.root.barrier.done.144

shadow.root.barrier.done.144:                     ; preds = %shadow.root.barrier.143, %for.exit.20
  br label %for.cond.145

for.cond.145:                                     ; preds = %for.update.147, %shadow.root.barrier.done.144
  %.41388 = phi ptr addrspace(1) [ %r48.0.relocated, %shadow.root.barrier.done.144 ], [ %.271411, %for.update.147 ]
  %.51336 = phi ptr addrspace(1) [ %r55.0.relocated, %shadow.root.barrier.done.144 ], [ %.281359, %for.update.147 ]
  %.41282 = phi ptr addrspace(1) [ %r48.0.base.relocated, %shadow.root.barrier.done.144 ], [ %.271305, %for.update.147 ]
  %.51269 = phi ptr addrspace(1) [ %r55.0.base.relocated, %shadow.root.barrier.done.144 ], [ %.28, %for.update.147 ]
  %r1054.0 = phi i32 [ 0, %shadow.root.barrier.done.144 ], [ %r2344, %for.update.147 ]
  %r1053.0 = phi ptr addrspace(1) [ null, %shadow.root.barrier.done.144 ], [ %.71601, %for.update.147 ]
  %r1046.0.base = phi ptr addrspace(1) [ %rs4gc.s15, %shadow.root.barrier.done.144 ], [ %.61608, %for.update.147 ], !is_base_value !0
  %r1046.0 = phi ptr addrspace(1) [ %rs4gc.s15, %shadow.root.barrier.done.144 ], [ %.61615, %for.update.147 ]
  %r1056 = sitofp i32 %r1054.0 to double
  %r1057 = fcmp olt double %r1056, 6.400000e+01
  %r1058 = select i1 %r1057, i64 9222246136947933188, i64 9222246136947933187
  %r1059 = bitcast i64 %r1058 to double
  %r1060 = icmp eq i64 %r1058, 9222246136947933188
  br i1 %r1060, label %for.body.146, label %for.exit.148

for.body.146:                                     ; preds = %for.cond.145
  %r1063 = sitofp i32 %r1054.0 to double
  %r1064.rs4i = ptrtoint ptr addrspace(1) %.41388 to i64
  %r1064.rs4o = call i64 asm "", "=r,0"(i64 %r1064.rs4i) #7
  %r1064 = bitcast i64 %r1064.rs4o to double
  %r1065 = bitcast double %r1064 to i64
  %r1066 = and i64 %r1065, 281474976710655
  %r1067 = lshr i64 %r1065, 48
  %r1068 = and i64 %r1067, 65533
  %r1069 = icmp eq i64 %r1068, 32765
  %r1070 = icmp ugt i64 %r1066, 1048575
  %r1071 = and i1 %r1069, %r1070
  br i1 %r1071, label %plen.check_gc.149, label %plen.slow.151

for.update.147:                                   ; preds = %gcpoll.done.378
  %r2344 = add i32 %r1054.0, 1
  %r2345 = sitofp i32 %r1054.0 to double
  %r2346 = sitofp i32 %r2344 to double
  br label %for.cond.145

for.exit.148:                                     ; preds = %for.cond.145
  br label %for.cond.379

plen.check_gc.149:                                ; preds = %for.body.146
  %r1072 = sub nuw nsw i64 %r1066, 8
  %r1073 = inttoptr i64 %r1072 to ptr
  %r1074 = load i8, ptr %r1073, align 1
  %r1075 = icmp eq i8 %r1074, 1
  %r1076 = icmp eq i8 %r1074, 3
  %r1077 = or i1 %r1075, %r1076
  %r1078 = sub nuw nsw i64 %r1066, 7
  %r1079 = inttoptr i64 %r1078 to ptr
  %r1080 = load i8, ptr %r1079, align 1
  %r1081 = and i8 %r1080, -128
  %r1082 = icmp eq i8 %r1081, 0
  %r1083 = and i1 %r1077, %r1082
  br i1 %r1083, label %plen.fast.150, label %plen.slow.151

plen.fast.150:                                    ; preds = %plen.check_gc.149
  %r1085 = inttoptr i64 %r1066 to ptr
  %r1086 = select i1 false, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r1085
  %r1087 = load i32, ptr %r1086, align 4
  %r1088 = uitofp i32 %r1087 to double
  br label %plen.merge.152

plen.slow.151:                                    ; preds = %plen.check_gc.149, %for.body.146
  %r1089 = lshr i64 %r1065, 48
  %r1090 = icmp eq i64 %r1089, 32765
  %r1091 = icmp uge i64 %r1066, 2199023255552
  %r1092 = icmp ult i64 %r1066, 140737488355328
  %r1093 = and i1 %r1090, %r1091
  %r1094 = and i1 %r1093, %r1092
  %r1095 = load ptr, ptr @perry_ic_test_json_source_token_length_ts__2, align 8
  br i1 %r1094, label %plen.ic.header.153, label %plen.ic.miss.165

plen.merge.152:                                   ; preds = %plen.ic.merge.166, %plen.fast.150
  %.11530 = phi ptr addrspace(1) [ %r1046.0, %plen.fast.150 ], [ %.21531, %plen.ic.merge.166 ]
  %.01520 = phi ptr addrspace(1) [ %r1053.0, %plen.fast.150 ], [ %.11521, %plen.ic.merge.166 ]
  %.11472 = phi ptr addrspace(1) [ %r1046.0.base, %plen.fast.150 ], [ %.21473, %plen.ic.merge.166 ]
  %.61390 = phi ptr addrspace(1) [ %.41388, %plen.fast.150 ], [ %.71391, %plen.ic.merge.166 ]
  %.71338 = phi ptr addrspace(1) [ %.51336, %plen.fast.150 ], [ %.81339, %plen.ic.merge.166 ]
  %.61284 = phi ptr addrspace(1) [ %.41282, %plen.fast.150 ], [ %.71285, %plen.ic.merge.166 ]
  %.71271 = phi ptr addrspace(1) [ %.51269, %plen.fast.150 ], [ %.81272, %plen.ic.merge.166 ]
  %r1170 = phi double [ %r1088, %plen.fast.150 ], [ %r1169, %plen.ic.merge.166 ]
  %r1171 = fcmp oge double %r1063, 0xC1E0000000000000
  %r1172 = fcmp ole double %r1063, 0x41DFFFFFFFC00000
  %r1173 = fcmp oge double %r1170, 0xC1E0000000000000
  %r1174 = fcmp ole double %r1170, 0x41DFFFFFFFC00000
  %r1175 = and i1 %r1171, %r1172
  %r1176 = and i1 %r1173, %r1174
  %r1177 = and i1 %r1175, %r1176
  br i1 %r1177, label %mod.i32.convert.170, label %mod.f64.fallback.172

plen.ic.header.153:                               ; preds = %plen.slow.151
  %r1097 = sub nuw nsw i64 %r1066, 8
  %r1098 = inttoptr i64 %r1097 to ptr
  %r1099 = load i8, ptr %r1098, align 1
  %r1100 = icmp eq i8 %r1099, 2
  %r1101 = sub nuw nsw i64 %r1066, 7
  %r1102 = inttoptr i64 %r1101 to ptr
  %r1103 = load i8, ptr %r1102, align 1
  %r1104 = and i8 %r1103, -128
  %r1105 = icmp eq i8 %r1104, 0
  %r1106 = and i1 %r1100, %r1105
  br i1 %r1106, label %plen.elem.meta.167, label %plen.ic.miss.165

plen.ic.shape.154:                                ; preds = %plen.elem.store.168, %plen.elem.meta.167
  %r1096 = icmp ne ptr %r1095, null
  br i1 %r1096, label %plen.ic.shape.probe.155, label %plen.ic.miss.165

plen.ic.shape.probe.155:                          ; preds = %plen.ic.shape.154
  %r1118 = inttoptr i64 %r1066 to ptr
  %r1119 = load i32, ptr %r1118, align 4
  %r1120 = add nuw nsw i64 %r1066, 4
  %r1121 = inttoptr i64 %r1120 to ptr
  %r1122 = load i32, ptr %r1121, align 4
  %r1123 = zext i32 %r1119 to i64
  %r1124 = zext i32 %r1122 to i64
  %r1125 = shl nuw i64 %r1123, 32
  %r1126 = or i64 %r1125, %r1124
  %r1127 = getelementptr i64, ptr %r1095, i64 0
  %r1128 = load i64, ptr %r1127, align 8
  %r1129 = icmp ne i64 %r1128, 0
  br i1 %r1129, label %plen.ic.identity.156, label %plen.ic.miss.165

plen.ic.identity.156:                             ; preds = %plen.ic.shape.probe.155
  %r1130 = and i64 %r1128, -9223372036854775808
  %1 = icmp slt i64 %r1128, 0
  br i1 %1, label %plen.ic.family_meta.158, label %plen.ic.exact.157

plen.ic.exact.157:                                ; preds = %plen.ic.identity.156
  %r1132 = icmp eq i64 %r1126, %r1128
  br i1 %r1132, label %plen.ic.slot.160, label %plen.ic.miss.165

plen.ic.family_meta.158:                          ; preds = %plen.ic.identity.156
  %r1133 = add nuw nsw i64 %r1066, 8
  %r1134 = inttoptr i64 %r1133 to ptr
  %r1135 = load i64, ptr %r1134, align 8
  %r1136 = icmp ne i64 %r1135, 0
  br i1 %r1136, label %plen.ic.family_token.159, label %plen.ic.miss.165

plen.ic.family_token.159:                         ; preds = %plen.ic.family_meta.158
  %r1137 = inttoptr i64 %r1135 to ptr
  %r1138 = getelementptr i64, ptr %r1137, i64 6
  %r1139 = load i64, ptr %r1138, align 8
  %r1140 = icmp eq i64 %r1139, %r1128
  br i1 %r1140, label %plen.ic.slot.160, label %plen.ic.miss.165

plen.ic.slot.160:                                 ; preds = %plen.ic.family_token.159, %plen.ic.exact.157
  %r1141 = getelementptr i64, ptr %r1095, i64 1
  %r1142 = load i64, ptr %r1141, align 8
  %r1143 = getelementptr i64, ptr %r1095, i64 2
  %r1144 = load i64, ptr %r1143, align 8
  %r1145 = icmp ult i64 %r1142, %r1144
  br i1 %r1145, label %plen.ic.inline.161, label %plen.ic.spill_meta.162

plen.ic.inline.161:                               ; preds = %plen.ic.slot.160
  %r1146 = shl i64 %r1142, 3
  %r1147 = add i64 %r1146, 16
  %r1148 = add i64 %r1066, %r1147
  %r1149 = inttoptr i64 %r1148 to ptr
  %r1150 = load double, ptr %r1149, align 8
  br label %plen.ic.merge.166

plen.ic.spill_meta.162:                           ; preds = %plen.ic.slot.160
  %r1151 = add nuw nsw i64 %r1066, 8
  %r1152 = inttoptr i64 %r1151 to ptr
  %r1153 = load i64, ptr %r1152, align 8
  %r1154 = icmp ne i64 %r1153, 0
  br i1 %r1154, label %plen.ic.spill_ptr.163, label %plen.ic.miss.165

plen.ic.spill_ptr.163:                            ; preds = %plen.ic.spill_meta.162
  %r1155 = inttoptr i64 %r1153 to ptr
  %r1156 = getelementptr i64, ptr %r1155, i64 4
  %r1157 = load i64, ptr %r1156, align 8
  %r1158 = icmp ne i64 %r1157, 0
  %r1159 = select i1 %r1158, i64 %r1157, i64 %r1153
  %r1160 = inttoptr i64 %r1159 to ptr
  %r1161 = load i32, ptr %r1160, align 4
  %r1162 = zext i32 %r1161 to i64
  %r1163 = icmp ult i64 %r1142, %r1162
  %r1164 = and i1 %r1158, %r1163
  br i1 %r1164, label %plen.ic.spill_load.164, label %plen.ic.miss.165

plen.ic.spill_load.164:                           ; preds = %plen.ic.spill_ptr.163
  %r1165 = add nuw nsw i64 %r1142, 1
  %r1166 = getelementptr inbounds nuw i64, ptr %r1160, i64 %r1165
  %r1167 = load double, ptr %r1166, align 8
  br label %plen.ic.merge.166

plen.ic.miss.165:                                 ; preds = %plen.ic.spill_ptr.163, %plen.ic.spill_meta.162, %plen.ic.family_token.159, %plen.ic.family_meta.158, %plen.ic.exact.157, %plen.ic.shape.probe.155, %plen.ic.shape.154, %plen.ic.header.153, %plen.slow.151
  %statepoint_token281 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r1064, ptr @perry_ic_test_json_source_token_length_ts__2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1046.0.base, ptr addrspace(1) %r1053.0, ptr addrspace(1) %.51269, ptr addrspace(1) %.41282, ptr addrspace(1) %r1046.0, ptr addrspace(1) %.51336, ptr addrspace(1) %.41388) ]
  %r1168282 = call double @llvm.experimental.gc.result.f64(token %statepoint_token281)
  %r1046.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token281, i32 0, i32 0) ; (%r1046.0.base, %r1046.0.base)
  %r1053.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token281, i32 1, i32 1) ; (%r1053.0, %r1053.0)
  %r55.0.base.relocated283 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token281, i32 2, i32 2) ; (%.51269, %.51269)
  %r48.0.base.relocated284 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token281, i32 3, i32 3) ; (%.41282, %.41282)
  %r1046.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token281, i32 0, i32 4) ; (%r1046.0.base, %r1046.0)
  %r55.0.relocated285 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token281, i32 2, i32 5) ; (%.51269, %.51336)
  %r48.0.relocated286 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token281, i32 3, i32 6) ; (%.41282, %.41388)
  br label %plen.ic.merge.166

plen.ic.merge.166:                                ; preds = %plen.elem.length.169, %plen.ic.miss.165, %plen.ic.spill_load.164, %plen.ic.inline.161
  %.21531 = phi ptr addrspace(1) [ %r1046.0, %plen.elem.length.169 ], [ %r1046.0, %plen.ic.inline.161 ], [ %r1046.0, %plen.ic.spill_load.164 ], [ %r1046.0.relocated, %plen.ic.miss.165 ]
  %.11521 = phi ptr addrspace(1) [ %r1053.0, %plen.elem.length.169 ], [ %r1053.0, %plen.ic.inline.161 ], [ %r1053.0, %plen.ic.spill_load.164 ], [ %r1053.0.relocated, %plen.ic.miss.165 ]
  %.21473 = phi ptr addrspace(1) [ %r1046.0.base, %plen.elem.length.169 ], [ %r1046.0.base, %plen.ic.inline.161 ], [ %r1046.0.base, %plen.ic.spill_load.164 ], [ %r1046.0.base.relocated, %plen.ic.miss.165 ]
  %.71391 = phi ptr addrspace(1) [ %.41388, %plen.elem.length.169 ], [ %.41388, %plen.ic.inline.161 ], [ %.41388, %plen.ic.spill_load.164 ], [ %r48.0.relocated286, %plen.ic.miss.165 ]
  %.81339 = phi ptr addrspace(1) [ %.51336, %plen.elem.length.169 ], [ %.51336, %plen.ic.inline.161 ], [ %.51336, %plen.ic.spill_load.164 ], [ %r55.0.relocated285, %plen.ic.miss.165 ]
  %.71285 = phi ptr addrspace(1) [ %.41282, %plen.elem.length.169 ], [ %.41282, %plen.ic.inline.161 ], [ %.41282, %plen.ic.spill_load.164 ], [ %r48.0.base.relocated284, %plen.ic.miss.165 ]
  %.81272 = phi ptr addrspace(1) [ %.51269, %plen.elem.length.169 ], [ %.51269, %plen.ic.inline.161 ], [ %.51269, %plen.ic.spill_load.164 ], [ %r55.0.base.relocated283, %plen.ic.miss.165 ]
  %r1169 = phi double [ %r1117, %plen.elem.length.169 ], [ %r1150, %plen.ic.inline.161 ], [ %r1167, %plen.ic.spill_load.164 ], [ %r1168282, %plen.ic.miss.165 ]
  br label %plen.merge.152

plen.elem.meta.167:                               ; preds = %plen.ic.header.153
  %r1107 = add nuw nsw i64 %r1066, 8
  %r1108 = inttoptr i64 %r1107 to ptr
  %r1109 = load i64, ptr %r1108, align 8
  %r1110 = icmp ne i64 %r1109, 0
  br i1 %r1110, label %plen.elem.store.168, label %plen.ic.shape.154

plen.elem.store.168:                              ; preds = %plen.elem.meta.167
  %r1111 = inttoptr i64 %r1109 to ptr
  %r1112 = getelementptr i64, ptr %r1111, i64 12
  %r1113 = load i64, ptr %r1112, align 8
  %r1114 = icmp ne i64 %r1113, 0
  br i1 %r1114, label %plen.elem.length.169, label %plen.ic.shape.154

plen.elem.length.169:                             ; preds = %plen.elem.store.168
  %r1115 = inttoptr i64 %r1113 to ptr
  %r1116 = load i32, ptr %r1115, align 4
  %r1117 = uitofp i32 %r1116 to double
  br label %plen.ic.merge.166

mod.i32.convert.170:                              ; preds = %plen.merge.152
  %r1178 = fptosi double %r1063 to i32
  %r1179 = fptosi double %r1170 to i32
  %r1180 = sitofp i32 %r1178 to double
  %r1181 = sitofp i32 %r1179 to double
  %r1182 = fcmp oeq double %r1180, %r1063
  %r1183 = fcmp oeq double %r1181, %r1170
  %r1184 = icmp ne i32 %r1179, 0
  %r1185 = and i1 %r1182, %r1183
  %r1186 = and i1 %r1185, %r1184
  br i1 %r1186, label %mod.i32.integer.171, label %mod.f64.fallback.172

mod.i32.integer.171:                              ; preds = %mod.i32.convert.170
  %r1187 = srem i32 %r1178, %r1179
  %r1188 = sitofp i32 %r1187 to double
  %r1189 = icmp eq i32 %r1187, 0
  %r1190 = bitcast double %r1063 to i64
  %r1191 = icmp slt i64 %r1190, 0
  %r1192 = and i1 %r1189, %r1191
  %r1193 = fneg double %r1188
  %r1194 = select i1 %r1192, double %r1193, double %r1188
  br label %mod.merge.173

mod.f64.fallback.172:                             ; preds = %mod.i32.convert.170, %plen.merge.152
  %r1195 = frem double %r1063, %r1170
  br label %mod.merge.173

mod.merge.173:                                    ; preds = %mod.f64.fallback.172, %mod.i32.integer.171
  %r1196 = phi double [ %r1194, %mod.i32.integer.171 ], [ %r1195, %mod.f64.fallback.172 ]
  %r1198.rs4i = ptrtoint ptr addrspace(1) %.61390 to i64
  %r1198.rs4o = call i64 asm "", "=r,0"(i64 %r1198.rs4i) #7
  %r1198 = bitcast i64 %r1198.rs4o to double
  %r1200 = fcmp oge double %r1196, 0.000000e+00
  %r1201 = fcmp ole double %r1196, 0x41DFFFFFFFC00000
  %r1202 = and i1 %r1200, %r1201
  %r1203 = select i1 %r1202, double %r1196, double 0.000000e+00
  %r1204 = fptosi double %r1203 to i32
  %r1205 = sitofp i32 %r1204 to double
  %r1206 = fcmp oeq double %r1205, %r1196
  %r1207 = and i1 %r1202, %r1206
  %r1208 = bitcast double %r1196 to i64
  %r1209 = lshr i64 %r1208, 48
  %r1210 = icmp eq i64 %r1209, 32766
  %r1211 = trunc i64 %r1208 to i32
  %r1212 = icmp sge i32 %r1211, 0
  %r1213 = and i1 %r1210, %r1212
  %r1214 = or i1 %r1207, %r1213
  %r1215 = select i1 %r1210, i32 %r1211, i32 %r1204
  br i1 %r1214, label %aidx.canonical.174, label %aidx.runtime_key.175

aidx.canonical.174:                               ; preds = %mod.merge.173
  %r1216 = bitcast double %r1198 to i64
  %r1217 = and i64 %r1216, 281474976710655
  %r1218 = lshr i64 %r1216, 48
  %r1219 = icmp eq i64 %r1218, 32765
  %r1220 = icmp ugt i64 %r1217, 1048575
  %r1221 = and i1 %r1219, %r1220
  br i1 %r1221, label %aidx.dynamic.guard.deref.181, label %aidx.dynamic.fallback.178

aidx.runtime_key.175:                             ; preds = %mod.merge.173
  %r1288 = bitcast double %r1198 to i64
  %r1289 = and i64 %r1288, 281474976710655
  %statepoint_token287 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_array_get_index_or_string, i32 2, i32 0, i64 %r1289, double %r1196, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11472, ptr addrspace(1) %.01520, ptr addrspace(1) %.71271, ptr addrspace(1) %.61284, ptr addrspace(1) %.11530, ptr addrspace(1) %.71338, ptr addrspace(1) %.61390) ]
  %r1290288 = call double @llvm.experimental.gc.result.f64(token %statepoint_token287)
  %r1046.0.base.relocated289 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token287, i32 0, i32 0) ; (%.11472, %.11472)
  %r1053.0.relocated290 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token287, i32 1, i32 1) ; (%.01520, %.01520)
  %r55.0.base.relocated291 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token287, i32 2, i32 2) ; (%.71271, %.71271)
  %r48.0.base.relocated292 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token287, i32 3, i32 3) ; (%.61284, %.61284)
  %r1046.0.relocated293 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token287, i32 0, i32 4) ; (%.11472, %.11530)
  %r55.0.relocated294 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token287, i32 2, i32 5) ; (%.71271, %.71338)
  %r48.0.relocated295 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token287, i32 3, i32 6) ; (%.61284, %.61390)
  br label %aidx.dynamic_merge.176

aidx.dynamic_merge.176:                           ; preds = %aidx.dynamic.merge.180, %aidx.runtime_key.175
  %.31532 = phi ptr addrspace(1) [ %.41533, %aidx.dynamic.merge.180 ], [ %r1046.0.relocated293, %aidx.runtime_key.175 ]
  %.21522 = phi ptr addrspace(1) [ %.31523, %aidx.dynamic.merge.180 ], [ %r1053.0.relocated290, %aidx.runtime_key.175 ]
  %.31474 = phi ptr addrspace(1) [ %.41475, %aidx.dynamic.merge.180 ], [ %r1046.0.base.relocated289, %aidx.runtime_key.175 ]
  %.81392 = phi ptr addrspace(1) [ %.91393, %aidx.dynamic.merge.180 ], [ %r48.0.relocated295, %aidx.runtime_key.175 ]
  %.91340 = phi ptr addrspace(1) [ %.101341, %aidx.dynamic.merge.180 ], [ %r55.0.relocated294, %aidx.runtime_key.175 ]
  %.81286 = phi ptr addrspace(1) [ %.91287, %aidx.dynamic.merge.180 ], [ %r48.0.base.relocated292, %aidx.runtime_key.175 ]
  %.91273 = phi ptr addrspace(1) [ %.101274, %aidx.dynamic.merge.180 ], [ %r55.0.base.relocated291, %aidx.runtime_key.175 ]
  %r1291 = phi double [ %r1287, %aidx.dynamic.merge.180 ], [ %r1290288, %aidx.runtime_key.175 ]
  %statepoint_token296 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r1291, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31474, ptr addrspace(1) %.21522, ptr addrspace(1) %.91273, ptr addrspace(1) %.81286, ptr addrspace(1) %.31532, ptr addrspace(1) %.91340, ptr addrspace(1) %.81392) ]
  %r1292297 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token296)
  %r1046.0.base.relocated298 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token296, i32 0, i32 0) ; (%.31474, %.31474)
  %r1053.0.relocated299 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token296, i32 1, i32 1) ; (%.21522, %.21522)
  %r55.0.base.relocated300 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token296, i32 2, i32 2) ; (%.91273, %.91273)
  %r48.0.base.relocated301 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token296, i32 3, i32 3) ; (%.81286, %.81286)
  %r1046.0.relocated302 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token296, i32 0, i32 4) ; (%.31474, %.31532)
  %r55.0.relocated303 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token296, i32 2, i32 5) ; (%.91273, %.91340)
  %r48.0.relocated304 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token296, i32 3, i32 6) ; (%.81286, %.81392)
  %statepoint_token305 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r1292297, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1046.0.base.relocated298, ptr addrspace(1) %r1053.0.relocated299, ptr addrspace(1) %r55.0.base.relocated300, ptr addrspace(1) %r48.0.base.relocated301, ptr addrspace(1) %r1046.0.relocated302, ptr addrspace(1) %r55.0.relocated303, ptr addrspace(1) %r48.0.relocated304) ]
  %r1293306 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token305)
  %r1046.0.base.relocated307 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token305, i32 0, i32 0) ; (%r1046.0.base.relocated298, %r1046.0.base.relocated298)
  %r1053.0.relocated308 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token305, i32 1, i32 1) ; (%r1053.0.relocated299, %r1053.0.relocated299)
  %r55.0.base.relocated309 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token305, i32 2, i32 2) ; (%r55.0.base.relocated300, %r55.0.base.relocated300)
  %r48.0.base.relocated310 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token305, i32 3, i32 3) ; (%r48.0.base.relocated301, %r48.0.base.relocated301)
  %r1046.0.relocated311 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token305, i32 0, i32 4) ; (%r1046.0.base.relocated298, %r1046.0.relocated302)
  %r55.0.relocated312 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token305, i32 2, i32 5) ; (%r55.0.base.relocated300, %r55.0.relocated303)
  %r48.0.relocated313 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token305, i32 3, i32 6) ; (%r48.0.base.relocated301, %r48.0.relocated304)
  %r1294 = bitcast i64 %r1293306 to double
  %rs4gc.b34 = bitcast double %r1294 to i64
  %rs4gc.s34 = inttoptr i64 %rs4gc.b34 to ptr addrspace(1)
  %r1295.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s34 to i64
  %r1295 = call i64 asm "", "=r,0"(i64 %r1295.rs4i) #7
  %r1296 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1297 = icmp ne i32 %r1296, 0
  br i1 %r1297, label %shadow.root.barrier.184, label %shadow.root.barrier.done.185

aidx.dynamic.fast.177:                            ; preds = %aidx.dynamic.guard.range.183
  %r1277 = zext i32 %r1215 to i64
  %r1278 = shl nuw nsw i64 %r1277, 3
  %r1279 = add nuw nsw i64 %r1278, 8
  %r1280 = add i64 %r1236, %r1279
  %r1281 = inttoptr i64 %r1280 to ptr
  %r1282 = load double, ptr %r1281, align 8
  %r1283 = bitcast double %r1282 to i64
  %r1284 = icmp eq i64 %r1283, 9222246136947933200
  %r1286 = select i1 %r1284, double 0x7FFC000000000001, double %r1282
  br label %aidx.dynamic.merge.180

aidx.dynamic.fallback.178:                        ; preds = %aidx.dynamic.guard.live.182, %aidx.dynamic.guard.deref.181, %aidx.canonical.174
  %r1275 = sitofp i32 %r1215 to double
  %statepoint_token314 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 5587713372188573699, double %r1198, double %r1275, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11472, ptr addrspace(1) %.01520, ptr addrspace(1) %.71271, ptr addrspace(1) %.61284, ptr addrspace(1) %.11530, ptr addrspace(1) %.71338, ptr addrspace(1) %.61390) ]
  %r1276315 = call double @llvm.experimental.gc.result.f64(token %statepoint_token314)
  %r1046.0.base.relocated316 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 0, i32 0) ; (%.11472, %.11472)
  %r1053.0.relocated317 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 1, i32 1) ; (%.01520, %.01520)
  %r55.0.base.relocated318 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 2, i32 2) ; (%.71271, %.71271)
  %r48.0.base.relocated319 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 3, i32 3) ; (%.61284, %.61284)
  %r1046.0.relocated320 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 0, i32 4) ; (%.11472, %.11530)
  %r55.0.relocated321 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 2, i32 5) ; (%.71271, %.71338)
  %r48.0.relocated322 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 3, i32 6) ; (%.61284, %.61390)
  br label %aidx.dynamic.merge.180

aidx.dynamic.guard.oob.179:                       ; preds = %aidx.dynamic.guard.range.183
  br label %aidx.dynamic.merge.180

aidx.dynamic.merge.180:                           ; preds = %aidx.dynamic.guard.oob.179, %aidx.dynamic.fallback.178, %aidx.dynamic.fast.177
  %.41533 = phi ptr addrspace(1) [ %.11530, %aidx.dynamic.fast.177 ], [ %.11530, %aidx.dynamic.guard.oob.179 ], [ %r1046.0.relocated320, %aidx.dynamic.fallback.178 ]
  %.31523 = phi ptr addrspace(1) [ %.01520, %aidx.dynamic.fast.177 ], [ %.01520, %aidx.dynamic.guard.oob.179 ], [ %r1053.0.relocated317, %aidx.dynamic.fallback.178 ]
  %.41475 = phi ptr addrspace(1) [ %.11472, %aidx.dynamic.fast.177 ], [ %.11472, %aidx.dynamic.guard.oob.179 ], [ %r1046.0.base.relocated316, %aidx.dynamic.fallback.178 ]
  %.91393 = phi ptr addrspace(1) [ %.61390, %aidx.dynamic.fast.177 ], [ %.61390, %aidx.dynamic.guard.oob.179 ], [ %r48.0.relocated322, %aidx.dynamic.fallback.178 ]
  %.101341 = phi ptr addrspace(1) [ %.71338, %aidx.dynamic.fast.177 ], [ %.71338, %aidx.dynamic.guard.oob.179 ], [ %r55.0.relocated321, %aidx.dynamic.fallback.178 ]
  %.91287 = phi ptr addrspace(1) [ %.61284, %aidx.dynamic.fast.177 ], [ %.61284, %aidx.dynamic.guard.oob.179 ], [ %r48.0.base.relocated319, %aidx.dynamic.fallback.178 ]
  %.101274 = phi ptr addrspace(1) [ %.71271, %aidx.dynamic.fast.177 ], [ %.71271, %aidx.dynamic.guard.oob.179 ], [ %r55.0.base.relocated318, %aidx.dynamic.fallback.178 ]
  %r1287 = phi double [ %r1286, %aidx.dynamic.fast.177 ], [ %r1276315, %aidx.dynamic.fallback.178 ], [ 0x7FFC000000000001, %aidx.dynamic.guard.oob.179 ]
  br label %aidx.dynamic_merge.176

aidx.dynamic.guard.deref.181:                     ; preds = %aidx.canonical.174
  %r1222 = bitcast double %r1198 to i64
  %r1223 = and i64 %r1222, 281474976710655
  %r1224 = sub nsw i64 %r1223, 8
  %r1225 = inttoptr i64 %r1224 to ptr
  %r1226 = load i8, ptr %r1225, align 1
  %r1227 = icmp eq i8 %r1226, 1
  %r1228 = sub nsw i64 %r1223, 7
  %r1229 = inttoptr i64 %r1228 to ptr
  %r1230 = load i8, ptr %r1229, align 1
  %r1231 = and i8 %r1230, -128
  %r1232 = icmp ne i8 %r1231, 0
  %r1233 = inttoptr i64 %r1223 to ptr
  %r1234 = load i64, ptr %r1233, align 8
  %r1235 = and i1 %r1227, %r1232
  %r1236 = select i1 %r1235, i64 %r1234, i64 %r1223
  %r1237 = lshr i64 %r1236, 48
  %r1238 = icmp eq i64 %r1237, 0
  %r1239 = icmp ugt i64 %r1236, 1048575
  %r1240 = and i1 %r1238, %r1239
  br i1 %r1240, label %aidx.dynamic.guard.live.182, label %aidx.dynamic.fallback.178

aidx.dynamic.guard.live.182:                      ; preds = %aidx.dynamic.guard.deref.181
  %r1241 = sub nuw i64 %r1236, 8
  %r1242 = inttoptr i64 %r1241 to ptr
  %r1243 = load i8, ptr %r1242, align 1
  %r1244 = icmp eq i8 %r1243, 1
  %r1245 = sub nuw i64 %r1236, 7
  %r1246 = inttoptr i64 %r1245 to ptr
  %r1247 = load i8, ptr %r1246, align 1
  %r1248 = and i8 %r1247, -128
  %r1249 = icmp eq i8 %r1248, 0
  %r1250 = sub nuw i64 %r1236, 6
  %r1251 = inttoptr i64 %r1250 to ptr
  %r1252 = load i16, ptr %r1251, align 2
  %r1253 = and i16 %r1252, 1024
  %r1254 = icmp eq i16 %r1253, 0
  %r1255 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1256 = icmp eq i8 %r1255, 0
  %r1257 = inttoptr i64 %r1236 to ptr
  %r1258 = load i32, ptr %r1257, align 4
  %r1259 = getelementptr i8, ptr %r1257, i64 4
  %r1260 = load i32, ptr %r1259, align 4
  %r1261 = icmp slt i32 %r1215, 0
  %r1262 = icmp eq i1 %r1261, false
  %r1264 = icmp ule i32 %r1258, 16000000
  %r1265 = icmp ule i32 %r1260, 16000000
  %r1266 = icmp ule i32 %r1258, %r1260
  %r1267 = and i1 %r1244, %r1249
  %r1268 = and i1 %r1267, %r1254
  %r1269 = and i1 %r1268, %r1256
  %r1270 = and i1 %r1269, %r1262
  %r1271 = and i1 %r1270, %r1264
  %r1272 = and i1 %r1271, %r1265
  %r1273 = and i1 %r1272, %r1266
  br i1 %r1273, label %aidx.dynamic.guard.range.183, label %aidx.dynamic.fallback.178

aidx.dynamic.guard.range.183:                     ; preds = %aidx.dynamic.guard.live.182
  %r1263 = icmp ult i32 %r1215, %r1258
  br i1 %r1263, label %aidx.dynamic.fast.177, label %aidx.dynamic.guard.oob.179

shadow.root.barrier.184:                          ; preds = %aidx.dynamic_merge.176
  call void @js_write_barrier_root_nanbox(i64 %r1295) #7
  br label %shadow.root.barrier.done.185

shadow.root.barrier.done.185:                     ; preds = %shadow.root.barrier.184, %aidx.dynamic_merge.176
  %r1298.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s34 to i64
  %r1298.rs4o = call i64 asm "", "=r,0"(i64 %r1298.rs4i) #7
  %r1298 = bitcast i64 %r1298.rs4o to double
  %r1299 = bitcast double %r1298 to i64
  %r1300 = and i64 %r1299, 281474976710655
  %r1301 = lshr i64 %r1299, 48
  %r1302 = and i64 %r1301, 65533
  %r1303 = icmp eq i64 %r1302, 32765
  br i1 %r1303, label %pget.recv_ok.187, label %pget.recv_other.191

pget.recv_sso.186:                                ; preds = %pget.recv_other.191
  %r1441 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r1442 = bitcast double %r1441 to i64
  %r1443 = and i64 %r1442, 281474976710655
  %statepoint_token323 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1299, i64 %r1443, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1046.0.base.relocated307, ptr addrspace(1) %rs4gc.s34, ptr addrspace(1) %r1053.0.relocated308, ptr addrspace(1) %r55.0.base.relocated309, ptr addrspace(1) %r48.0.base.relocated310, ptr addrspace(1) %r1046.0.relocated311, ptr addrspace(1) %r55.0.relocated312, ptr addrspace(1) %r48.0.relocated313) ]
  %r1444324 = call double @llvm.experimental.gc.result.f64(token %statepoint_token323)
  %r1046.0.base.relocated325 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token323, i32 0, i32 0) ; (%r1046.0.base.relocated307, %r1046.0.base.relocated307)
  %rs4gc.s34.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token323, i32 1, i32 1) ; (%rs4gc.s34, %rs4gc.s34)
  %r1053.0.relocated326 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token323, i32 2, i32 2) ; (%r1053.0.relocated308, %r1053.0.relocated308)
  %r55.0.base.relocated327 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token323, i32 3, i32 3) ; (%r55.0.base.relocated309, %r55.0.base.relocated309)
  %r48.0.base.relocated328 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token323, i32 4, i32 4) ; (%r48.0.base.relocated310, %r48.0.base.relocated310)
  %r1046.0.relocated329 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token323, i32 0, i32 5) ; (%r1046.0.base.relocated307, %r1046.0.relocated311)
  %r55.0.relocated330 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token323, i32 3, i32 6) ; (%r55.0.base.relocated309, %r55.0.relocated312)
  %r48.0.relocated331 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token323, i32 4, i32 7) ; (%r48.0.base.relocated310, %r48.0.relocated313)
  br label %pget.recv_merge.190

pget.recv_ok.187:                                 ; preds = %shadow.root.barrier.done.185
  %r1310 = icmp ugt i64 %r1300, 1048575
  br i1 %r1310, label %pic.recv_hdr.208, label %pic.miss.cold.205

pget.recv_bad.188:                                ; preds = %pget.check_class_ref.192
  %r1433 = icmp eq i64 %r1299, 9222246136947933185
  %r1434 = icmp eq i64 %r1299, 9222246136947933186
  %r1435 = or i1 %r1433, %r1434
  br i1 %r1435, label %pget.throw_nullish.215, label %pget.recv_undef_return.216

pget.recv_class_ref.189:                          ; preds = %pget.check_class_ref.192
  %r1306 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r1307 = bitcast double %r1306 to i64
  %r1308 = and i64 %r1307, 281474976710655
  %statepoint_token332 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 5587713372188573700, i64 %r1299, i64 %r1308, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1046.0.base.relocated307, ptr addrspace(1) %rs4gc.s34, ptr addrspace(1) %r1053.0.relocated308, ptr addrspace(1) %r55.0.base.relocated309, ptr addrspace(1) %r48.0.base.relocated310, ptr addrspace(1) %r1046.0.relocated311, ptr addrspace(1) %r55.0.relocated312, ptr addrspace(1) %r48.0.relocated313) ]
  %r1309333 = call double @llvm.experimental.gc.result.f64(token %statepoint_token332)
  %r1046.0.base.relocated334 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token332, i32 0, i32 0) ; (%r1046.0.base.relocated307, %r1046.0.base.relocated307)
  %rs4gc.s34.relocated335 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token332, i32 1, i32 1) ; (%rs4gc.s34, %rs4gc.s34)
  %r1053.0.relocated336 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token332, i32 2, i32 2) ; (%r1053.0.relocated308, %r1053.0.relocated308)
  %r55.0.base.relocated337 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token332, i32 3, i32 3) ; (%r55.0.base.relocated309, %r55.0.base.relocated309)
  %r48.0.base.relocated338 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token332, i32 4, i32 4) ; (%r48.0.base.relocated310, %r48.0.base.relocated310)
  %r1046.0.relocated339 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token332, i32 0, i32 5) ; (%r1046.0.base.relocated307, %r1046.0.relocated311)
  %r55.0.relocated340 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token332, i32 3, i32 6) ; (%r55.0.base.relocated309, %r55.0.relocated312)
  %r48.0.relocated341 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token332, i32 4, i32 7) ; (%r48.0.base.relocated310, %r48.0.relocated313)
  br label %pget.recv_merge.190

pget.recv_merge.190:                              ; preds = %pget.recv_undef_return.216, %pic.merge.207, %pget.recv_class_ref.189, %pget.recv_sso.186
  %.01578 = phi ptr addrspace(1) [ %.11579, %pic.merge.207 ], [ %rs4gc.s34.relocated, %pget.recv_sso.186 ], [ %rs4gc.s34.relocated335, %pget.recv_class_ref.189 ], [ %rs4gc.s34.relocated366, %pget.recv_undef_return.216 ]
  %.51534 = phi ptr addrspace(1) [ %.61535, %pic.merge.207 ], [ %r1046.0.relocated329, %pget.recv_sso.186 ], [ %r1046.0.relocated339, %pget.recv_class_ref.189 ], [ %r1046.0.relocated370, %pget.recv_undef_return.216 ]
  %.41524 = phi ptr addrspace(1) [ %.51525, %pic.merge.207 ], [ %r1053.0.relocated326, %pget.recv_sso.186 ], [ %r1053.0.relocated336, %pget.recv_class_ref.189 ], [ %r1053.0.relocated367, %pget.recv_undef_return.216 ]
  %.51476 = phi ptr addrspace(1) [ %.61477, %pic.merge.207 ], [ %r1046.0.base.relocated325, %pget.recv_sso.186 ], [ %r1046.0.base.relocated334, %pget.recv_class_ref.189 ], [ %r1046.0.base.relocated365, %pget.recv_undef_return.216 ]
  %.101394 = phi ptr addrspace(1) [ %.111395, %pic.merge.207 ], [ %r48.0.relocated331, %pget.recv_sso.186 ], [ %r48.0.relocated341, %pget.recv_class_ref.189 ], [ %r48.0.relocated372, %pget.recv_undef_return.216 ]
  %.111342 = phi ptr addrspace(1) [ %.121343, %pic.merge.207 ], [ %r55.0.relocated330, %pget.recv_sso.186 ], [ %r55.0.relocated340, %pget.recv_class_ref.189 ], [ %r55.0.relocated371, %pget.recv_undef_return.216 ]
  %.101288 = phi ptr addrspace(1) [ %.111289, %pic.merge.207 ], [ %r48.0.base.relocated328, %pget.recv_sso.186 ], [ %r48.0.base.relocated338, %pget.recv_class_ref.189 ], [ %r48.0.base.relocated369, %pget.recv_undef_return.216 ]
  %.111275 = phi ptr addrspace(1) [ %.121276, %pic.merge.207 ], [ %r55.0.base.relocated327, %pget.recv_sso.186 ], [ %r55.0.base.relocated337, %pget.recv_class_ref.189 ], [ %r55.0.base.relocated368, %pget.recv_undef_return.216 ]
  %r1445 = phi double [ %r1432, %pic.merge.207 ], [ %r1440364, %pget.recv_undef_return.216 ], [ %r1444324, %pget.recv_sso.186 ], [ %r1309333, %pget.recv_class_ref.189 ]
  %r1446 = bitcast double %r1445 to i64
  %rs4gc.s35 = inttoptr i64 %r1446 to ptr addrspace(1)
  %r1448.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35 to i64
  %r1448 = call i64 asm "", "=r,0"(i64 %r1448.rs4i) #7
  %r1449 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1450 = icmp ne i32 %r1449, 0
  br i1 %r1450, label %shadow.root.barrier.217, label %shadow.root.barrier.done.218

pget.recv_other.191:                              ; preds = %shadow.root.barrier.done.185
  %r1304 = icmp eq i64 %r1301, 32761
  br i1 %r1304, label %pget.recv_sso.186, label %pget.check_class_ref.192

pget.check_class_ref.192:                         ; preds = %pget.recv_other.191
  %r1305 = icmp eq i64 %r1301, 32766
  br i1 %r1305, label %pget.recv_class_ref.189, label %pget.recv_bad.188

pic.hit.193:                                      ; preds = %pic.token.209
  %r1335 = getelementptr i64, ptr %r1320, i64 1
  %r1336 = load i64, ptr %r1335, align 8
  %r1337 = and i64 %r1336, 1073741824
  %r1338 = icmp ne i64 %r1337, 0
  br i1 %r1338, label %pic.hit.overflow.210, label %pic.hit.inline.211

pic.hit.live.194:                                 ; preds = %pic.hit.inline.211
  br label %pic.merge.207

pic.prefix.guard.195:                             ; preds = %pic.token.209
  %r1351 = getelementptr i64, ptr %r1320, i64 2
  %r1352 = load i64, ptr %r1351, align 8
  %r1353 = icmp ne i64 %r1352, 0
  br i1 %r1353, label %pic.prefix.meta.196, label %pic.miss.204

pic.prefix.meta.196:                              ; preds = %pic.prefix.guard.195
  %r1354 = add nuw nsw i64 %r1300, 8
  %r1355 = inttoptr i64 %r1354 to ptr
  %r1356 = load i64, ptr %r1355, align 8
  %r1357 = icmp ne i64 %r1356, 0
  br i1 %r1357, label %pic.prefix.token.197, label %pic.miss.204

pic.prefix.token.197:                             ; preds = %pic.prefix.meta.196
  %r1358 = inttoptr i64 %r1356 to ptr
  %r1359 = getelementptr i64, ptr %r1358, i64 6
  %r1360 = load i64, ptr %r1359, align 8
  %r1361 = icmp eq i64 %r1360, %r1352
  br i1 %r1361, label %pic.prefix.hit.198, label %pic.miss.204

pic.prefix.hit.198:                               ; preds = %pic.prefix.token.197
  %r1362 = getelementptr i64, ptr %r1320, i64 1
  %r1363 = load i64, ptr %r1362, align 8
  %r1364 = shl i64 %r1363, 3
  %r1365 = add nuw nsw i64 %r1300, 16
  %r1366 = add i64 %r1365, %r1364
  %r1367 = inttoptr i64 %r1366 to ptr
  %r1368 = load double, ptr %r1367, align 8
  br label %pic.merge.207

pic.desc.classify.199:                            ; preds = %pic.recv_hdr.208
  %r1324 = and i1 %r1314, %r1321
  br i1 %r1324, label %pic.desc.prefix.guard.200, label %pic.miss.cold.205

pic.desc.prefix.guard.200:                        ; preds = %pic.desc.classify.199
  %r1369 = getelementptr i64, ptr %r1320, i64 2
  %r1370 = load i64, ptr %r1369, align 8
  %r1371 = icmp ne i64 %r1370, 0
  br i1 %r1371, label %pic.desc.prefix.meta.201, label %pic.miss.cold.205

pic.desc.prefix.meta.201:                         ; preds = %pic.desc.prefix.guard.200
  %r1372 = add nuw nsw i64 %r1300, 8
  %r1373 = inttoptr i64 %r1372 to ptr
  %r1374 = load i64, ptr %r1373, align 8
  %r1375 = icmp ne i64 %r1374, 0
  br i1 %r1375, label %pic.desc.prefix.token.202, label %pic.miss.cold.205

pic.desc.prefix.token.202:                        ; preds = %pic.desc.prefix.meta.201
  %r1376 = inttoptr i64 %r1374 to ptr
  %r1377 = getelementptr i64, ptr %r1376, i64 6
  %r1378 = load i64, ptr %r1377, align 8
  %r1379 = icmp eq i64 %r1378, %r1370
  br i1 %r1379, label %pic.desc.prefix.hit.203, label %pic.miss.cold.205

pic.desc.prefix.hit.203:                          ; preds = %pic.desc.prefix.token.202
  %r1380 = getelementptr i64, ptr %r1320, i64 1
  %r1381 = load i64, ptr %r1380, align 8
  %r1382 = shl i64 %r1381, 3
  %r1383 = add nuw nsw i64 %r1300, 16
  %r1384 = add i64 %r1383, %r1382
  %r1385 = inttoptr i64 %r1384 to ptr
  %r1386 = load double, ptr %r1385, align 8
  br label %pic.merge.207

pic.miss.204:                                     ; preds = %pic.hit.inline.211, %pic.prefix.token.197, %pic.prefix.meta.196, %pic.prefix.guard.195
  %r1387 = getelementptr i64, ptr %r1320, i64 3
  %r1388 = load i64, ptr %r1387, align 8
  %r1389 = icmp sgt i64 %r1388, 0
  br i1 %r1389, label %pic.ways.212, label %pic.miss.call.206

pic.miss.cold.205:                                ; preds = %pic.desc.prefix.token.202, %pic.desc.prefix.meta.201, %pic.desc.prefix.guard.200, %pic.desc.classify.199, %pget.recv_ok.187
  br label %pic.miss.call.206

pic.miss.call.206:                                ; preds = %pic.way.load.213, %pic.ways.212, %pic.miss.cold.205, %pic.miss.204
  %r1428 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r1429 = bitcast double %r1428 to i64
  %r1430 = and i64 %r1429, 281474976710655
  %statepoint_token342 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1300, i64 %r1430, ptr @perry_ic_test_json_source_token_length_ts__5, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1046.0.base.relocated307, ptr addrspace(1) %rs4gc.s34, ptr addrspace(1) %r1053.0.relocated308, ptr addrspace(1) %r55.0.base.relocated309, ptr addrspace(1) %r48.0.base.relocated310, ptr addrspace(1) %r1046.0.relocated311, ptr addrspace(1) %r55.0.relocated312, ptr addrspace(1) %r48.0.relocated313) ]
  %r1431343 = call double @llvm.experimental.gc.result.f64(token %statepoint_token342)
  %r1046.0.base.relocated344 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 0, i32 0) ; (%r1046.0.base.relocated307, %r1046.0.base.relocated307)
  %rs4gc.s34.relocated345 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 1, i32 1) ; (%rs4gc.s34, %rs4gc.s34)
  %r1053.0.relocated346 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 2, i32 2) ; (%r1053.0.relocated308, %r1053.0.relocated308)
  %r55.0.base.relocated347 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 3, i32 3) ; (%r55.0.base.relocated309, %r55.0.base.relocated309)
  %r48.0.base.relocated348 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 4, i32 4) ; (%r48.0.base.relocated310, %r48.0.base.relocated310)
  %r1046.0.relocated349 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 0, i32 5) ; (%r1046.0.base.relocated307, %r1046.0.relocated311)
  %r55.0.relocated350 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 3, i32 6) ; (%r55.0.base.relocated309, %r55.0.relocated312)
  %r48.0.relocated351 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 4, i32 7) ; (%r48.0.base.relocated310, %r48.0.relocated313)
  br label %pic.merge.207

pic.merge.207:                                    ; preds = %pic.way.live.214, %pic.hit.overflow.210, %pic.miss.call.206, %pic.desc.prefix.hit.203, %pic.prefix.hit.198, %pic.hit.live.194
  %.11579 = phi ptr addrspace(1) [ %rs4gc.s34.relocated355, %pic.hit.overflow.210 ], [ %rs4gc.s34.relocated345, %pic.miss.call.206 ], [ %rs4gc.s34, %pic.way.live.214 ], [ %rs4gc.s34, %pic.hit.live.194 ], [ %rs4gc.s34, %pic.prefix.hit.198 ], [ %rs4gc.s34, %pic.desc.prefix.hit.203 ]
  %.61535 = phi ptr addrspace(1) [ %r1046.0.relocated359, %pic.hit.overflow.210 ], [ %r1046.0.relocated349, %pic.miss.call.206 ], [ %r1046.0.relocated311, %pic.way.live.214 ], [ %r1046.0.relocated311, %pic.hit.live.194 ], [ %r1046.0.relocated311, %pic.prefix.hit.198 ], [ %r1046.0.relocated311, %pic.desc.prefix.hit.203 ]
  %.51525 = phi ptr addrspace(1) [ %r1053.0.relocated356, %pic.hit.overflow.210 ], [ %r1053.0.relocated346, %pic.miss.call.206 ], [ %r1053.0.relocated308, %pic.way.live.214 ], [ %r1053.0.relocated308, %pic.hit.live.194 ], [ %r1053.0.relocated308, %pic.prefix.hit.198 ], [ %r1053.0.relocated308, %pic.desc.prefix.hit.203 ]
  %.61477 = phi ptr addrspace(1) [ %r1046.0.base.relocated354, %pic.hit.overflow.210 ], [ %r1046.0.base.relocated344, %pic.miss.call.206 ], [ %r1046.0.base.relocated307, %pic.way.live.214 ], [ %r1046.0.base.relocated307, %pic.hit.live.194 ], [ %r1046.0.base.relocated307, %pic.prefix.hit.198 ], [ %r1046.0.base.relocated307, %pic.desc.prefix.hit.203 ]
  %.111395 = phi ptr addrspace(1) [ %r48.0.relocated361, %pic.hit.overflow.210 ], [ %r48.0.relocated351, %pic.miss.call.206 ], [ %r48.0.relocated313, %pic.way.live.214 ], [ %r48.0.relocated313, %pic.hit.live.194 ], [ %r48.0.relocated313, %pic.prefix.hit.198 ], [ %r48.0.relocated313, %pic.desc.prefix.hit.203 ]
  %.121343 = phi ptr addrspace(1) [ %r55.0.relocated360, %pic.hit.overflow.210 ], [ %r55.0.relocated350, %pic.miss.call.206 ], [ %r55.0.relocated312, %pic.way.live.214 ], [ %r55.0.relocated312, %pic.hit.live.194 ], [ %r55.0.relocated312, %pic.prefix.hit.198 ], [ %r55.0.relocated312, %pic.desc.prefix.hit.203 ]
  %.111289 = phi ptr addrspace(1) [ %r48.0.base.relocated358, %pic.hit.overflow.210 ], [ %r48.0.base.relocated348, %pic.miss.call.206 ], [ %r48.0.base.relocated310, %pic.way.live.214 ], [ %r48.0.base.relocated310, %pic.hit.live.194 ], [ %r48.0.base.relocated310, %pic.prefix.hit.198 ], [ %r48.0.base.relocated310, %pic.desc.prefix.hit.203 ]
  %.121276 = phi ptr addrspace(1) [ %r55.0.base.relocated357, %pic.hit.overflow.210 ], [ %r55.0.base.relocated347, %pic.miss.call.206 ], [ %r55.0.base.relocated309, %pic.way.live.214 ], [ %r55.0.base.relocated309, %pic.hit.live.194 ], [ %r55.0.base.relocated309, %pic.prefix.hit.198 ], [ %r55.0.base.relocated309, %pic.desc.prefix.hit.203 ]
  %r1432 = phi double [ %r1348, %pic.hit.live.194 ], [ %r1343353, %pic.hit.overflow.210 ], [ %r1368, %pic.prefix.hit.198 ], [ %r1386, %pic.desc.prefix.hit.203 ], [ %r1425, %pic.way.live.214 ], [ %r1431343, %pic.miss.call.206 ]
  br label %pget.recv_merge.190

pic.recv_hdr.208:                                 ; preds = %pget.recv_ok.187
  %r1311 = sub nuw nsw i64 %r1300, 8
  %r1312 = inttoptr i64 %r1311 to ptr
  %r1313 = load i8, ptr %r1312, align 1
  %r1314 = icmp eq i8 %r1313, 2
  %r1315 = sub nuw nsw i64 %r1300, 6
  %r1316 = inttoptr i64 %r1315 to ptr
  %r1317 = load i16, ptr %r1316, align 2
  %r1318 = and i16 %r1317, 2048
  %r1319 = icmp eq i16 %r1318, 0
  %r1320 = load ptr, ptr @perry_ic_test_json_source_token_length_ts__5, align 8
  %r1321 = icmp ne ptr %r1320, null
  %r1322 = and i1 %r1314, %r1319
  %r1323 = and i1 %r1322, %r1321
  br i1 %r1323, label %pic.token.209, label %pic.desc.classify.199

pic.token.209:                                    ; preds = %pic.recv_hdr.208
  %r1325 = add nuw nsw i64 %r1300, 4
  %r1326 = inttoptr i64 %r1325 to ptr
  %r1327 = load i32, ptr %r1326, align 4
  %r1328 = zext i32 %r1327 to i64
  %r1329 = or i64 %r1328, 4611686018427387904
  %r1330 = icmp ne i32 %r1327, 0
  %r1331 = getelementptr i64, ptr %r1320, i64 0
  %r1332 = load i64, ptr %r1331, align 8
  %r1333 = icmp eq i64 %r1329, %r1332
  %r1334 = and i1 %r1333, %r1330
  br i1 %r1334, label %pic.hit.193, label %pic.prefix.guard.195

pic.hit.overflow.210:                             ; preds = %pic.hit.193
  %r1339 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r1340 = bitcast double %r1339 to i64
  %r1341 = and i64 %r1340, 281474976710655
  %r1342 = trunc i64 %r1336 to i32
  %statepoint_token352 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1300, i64 %r1341, i32 %r1342, ptr @perry_ic_test_json_source_token_length_ts__5, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1046.0.base.relocated307, ptr addrspace(1) %rs4gc.s34, ptr addrspace(1) %r1053.0.relocated308, ptr addrspace(1) %r55.0.base.relocated309, ptr addrspace(1) %r48.0.base.relocated310, ptr addrspace(1) %r1046.0.relocated311, ptr addrspace(1) %r55.0.relocated312, ptr addrspace(1) %r48.0.relocated313) ]
  %r1343353 = call double @llvm.experimental.gc.result.f64(token %statepoint_token352)
  %r1046.0.base.relocated354 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token352, i32 0, i32 0) ; (%r1046.0.base.relocated307, %r1046.0.base.relocated307)
  %rs4gc.s34.relocated355 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token352, i32 1, i32 1) ; (%rs4gc.s34, %rs4gc.s34)
  %r1053.0.relocated356 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token352, i32 2, i32 2) ; (%r1053.0.relocated308, %r1053.0.relocated308)
  %r55.0.base.relocated357 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token352, i32 3, i32 3) ; (%r55.0.base.relocated309, %r55.0.base.relocated309)
  %r48.0.base.relocated358 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token352, i32 4, i32 4) ; (%r48.0.base.relocated310, %r48.0.base.relocated310)
  %r1046.0.relocated359 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token352, i32 0, i32 5) ; (%r1046.0.base.relocated307, %r1046.0.relocated311)
  %r55.0.relocated360 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token352, i32 3, i32 6) ; (%r55.0.base.relocated309, %r55.0.relocated312)
  %r48.0.relocated361 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token352, i32 4, i32 7) ; (%r48.0.base.relocated310, %r48.0.relocated313)
  br label %pic.merge.207

pic.hit.inline.211:                               ; preds = %pic.hit.193
  %r1344 = shl i64 %r1336, 3
  %r1345 = add nuw nsw i64 %r1300, 16
  %r1346 = add i64 %r1345, %r1344
  %r1347 = inttoptr i64 %r1346 to ptr
  %r1348 = load double, ptr %r1347, align 8
  %r1349 = bitcast double %r1348 to i64
  %r1350 = icmp eq i64 %r1349, 9222246136947933200
  br i1 %r1350, label %pic.miss.204, label %pic.hit.live.194

pic.ways.212:                                     ; preds = %pic.miss.204
  %r1390 = getelementptr i64, ptr %r1320, i64 4
  %r1391 = load i64, ptr %r1390, align 8
  %r1392 = icmp eq i64 %r1391, %r1329
  %r1393 = getelementptr i64, ptr %r1320, i64 5
  %r1394 = load i64, ptr %r1393, align 8
  %r1395 = select i1 %r1392, i64 %r1394, i64 0
  %r1396 = getelementptr i64, ptr %r1320, i64 6
  %r1397 = load i64, ptr %r1396, align 8
  %r1398 = icmp eq i64 %r1397, %r1329
  %r1399 = getelementptr i64, ptr %r1320, i64 7
  %r1400 = load i64, ptr %r1399, align 8
  %r1401 = select i1 %r1398, i64 %r1400, i64 0
  %r1402 = getelementptr i64, ptr %r1320, i64 8
  %r1403 = load i64, ptr %r1402, align 8
  %r1404 = icmp eq i64 %r1403, %r1329
  %r1405 = getelementptr i64, ptr %r1320, i64 9
  %r1406 = load i64, ptr %r1405, align 8
  %r1407 = select i1 %r1404, i64 %r1406, i64 0
  %r1408 = getelementptr i64, ptr %r1320, i64 10
  %r1409 = load i64, ptr %r1408, align 8
  %r1410 = icmp eq i64 %r1409, %r1329
  %r1411 = getelementptr i64, ptr %r1320, i64 11
  %r1412 = load i64, ptr %r1411, align 8
  %r1413 = select i1 %r1410, i64 %r1412, i64 0
  %r1414 = or i1 %r1392, %r1398
  %r1415 = select i1 %r1392, i64 %r1395, i64 %r1401
  %r1416 = or i1 %r1404, %r1410
  %r1417 = select i1 %r1404, i64 %r1407, i64 %r1413
  %r1418 = or i1 %r1414, %r1416
  %r1419 = select i1 %r1414, i64 %r1415, i64 %r1417
  %r1420 = and i1 %r1330, %r1418
  br i1 %r1420, label %pic.way.load.213, label %pic.miss.call.206

pic.way.load.213:                                 ; preds = %pic.ways.212
  %r1421 = shl i64 %r1419, 3
  %r1422 = add nuw nsw i64 %r1300, 16
  %r1423 = add i64 %r1422, %r1421
  %r1424 = inttoptr i64 %r1423 to ptr
  %r1425 = load double, ptr %r1424, align 8
  %r1426 = bitcast double %r1425 to i64
  %r1427 = icmp eq i64 %r1426, 9222246136947933200
  br i1 %r1427, label %pic.miss.call.206, label %pic.way.live.214

pic.way.live.214:                                 ; preds = %pic.way.load.213
  br label %pic.merge.207

pget.throw_nullish.215:                           ; preds = %pget.recv_bad.188
  %r1436 = zext i1 %r1434 to i32
  %statepoint_token362 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1436, ptr @test_json_source_token_length_ts_.str.10.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.216:                       ; preds = %pget.recv_bad.188
  %r1437 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r1438 = bitcast double %r1437 to i64
  %r1439 = and i64 %r1438, 281474976710655
  %statepoint_token363 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1299, i64 %r1439, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1046.0.base.relocated307, ptr addrspace(1) %rs4gc.s34, ptr addrspace(1) %r1053.0.relocated308, ptr addrspace(1) %r55.0.base.relocated309, ptr addrspace(1) %r48.0.base.relocated310, ptr addrspace(1) %r1046.0.relocated311, ptr addrspace(1) %r55.0.relocated312, ptr addrspace(1) %r48.0.relocated313) ]
  %r1440364 = call double @llvm.experimental.gc.result.f64(token %statepoint_token363)
  %r1046.0.base.relocated365 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token363, i32 0, i32 0) ; (%r1046.0.base.relocated307, %r1046.0.base.relocated307)
  %rs4gc.s34.relocated366 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token363, i32 1, i32 1) ; (%rs4gc.s34, %rs4gc.s34)
  %r1053.0.relocated367 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token363, i32 2, i32 2) ; (%r1053.0.relocated308, %r1053.0.relocated308)
  %r55.0.base.relocated368 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token363, i32 3, i32 3) ; (%r55.0.base.relocated309, %r55.0.base.relocated309)
  %r48.0.base.relocated369 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token363, i32 4, i32 4) ; (%r48.0.base.relocated310, %r48.0.base.relocated310)
  %r1046.0.relocated370 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token363, i32 0, i32 5) ; (%r1046.0.base.relocated307, %r1046.0.relocated311)
  %r55.0.relocated371 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token363, i32 3, i32 6) ; (%r55.0.base.relocated309, %r55.0.relocated312)
  %r48.0.relocated372 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token363, i32 4, i32 7) ; (%r48.0.base.relocated310, %r48.0.relocated313)
  br label %pget.recv_merge.190

shadow.root.barrier.217:                          ; preds = %pget.recv_merge.190
  call void @js_write_barrier_root_nanbox(i64 %r1448) #7
  br label %shadow.root.barrier.done.218

shadow.root.barrier.done.218:                     ; preds = %shadow.root.barrier.217, %pget.recv_merge.190
  %r1451.rs4i = ptrtoint ptr addrspace(1) %.111342 to i64
  %r1451.rs4o = call i64 asm "", "=r,0"(i64 %r1451.rs4i) #7
  %r1451 = bitcast i64 %r1451.rs4o to double
  %r1453 = fcmp oge double %r1196, 0.000000e+00
  %r1454 = fcmp ole double %r1196, 0x41DFFFFFFFC00000
  %r1455 = and i1 %r1453, %r1454
  %r1456 = select i1 %r1455, double %r1196, double 0.000000e+00
  %r1457 = fptosi double %r1456 to i32
  %r1458 = sitofp i32 %r1457 to double
  %r1459 = fcmp oeq double %r1458, %r1196
  %r1460 = and i1 %r1455, %r1459
  %r1461 = bitcast double %r1196 to i64
  %r1462 = lshr i64 %r1461, 48
  %r1463 = icmp eq i64 %r1462, 32766
  %r1464 = trunc i64 %r1461 to i32
  %r1465 = icmp sge i32 %r1464, 0
  %r1466 = and i1 %r1463, %r1465
  %r1467 = or i1 %r1460, %r1466
  %r1468 = select i1 %r1463, i32 %r1464, i32 %r1457
  br i1 %r1467, label %aidx.canonical.219, label %aidx.runtime_key.220

aidx.canonical.219:                               ; preds = %shadow.root.barrier.done.218
  %r1469 = bitcast double %r1451 to i64
  %r1470 = and i64 %r1469, 281474976710655
  %r1471 = lshr i64 %r1469, 48
  %r1472 = icmp eq i64 %r1471, 32765
  %r1473 = icmp ugt i64 %r1470, 1048575
  %r1474 = and i1 %r1472, %r1473
  br i1 %r1474, label %aidx.dynamic.guard.deref.226, label %aidx.dynamic.fallback.223

aidx.runtime_key.220:                             ; preds = %shadow.root.barrier.done.218
  %r1541 = bitcast double %r1451 to i64
  %r1542 = and i64 %r1541, 281474976710655
  %statepoint_token373 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_array_get_index_or_string, i32 2, i32 0, i64 %r1542, double %r1196, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.51476, ptr addrspace(1) %.01578, ptr addrspace(1) %.111275, ptr addrspace(1) %.101288, ptr addrspace(1) %.51534, ptr addrspace(1) %.41524, ptr addrspace(1) %rs4gc.s35, ptr addrspace(1) %.111342, ptr addrspace(1) %.101394) ]
  %r1543374 = call double @llvm.experimental.gc.result.f64(token %statepoint_token373)
  %r1046.0.base.relocated375 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token373, i32 0, i32 0) ; (%.51476, %.51476)
  %rs4gc.s34.relocated376 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token373, i32 1, i32 1) ; (%.01578, %.01578)
  %r55.0.base.relocated377 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token373, i32 2, i32 2) ; (%.111275, %.111275)
  %r48.0.base.relocated378 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token373, i32 3, i32 3) ; (%.101288, %.101288)
  %r1046.0.relocated379 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token373, i32 0, i32 4) ; (%.51476, %.51534)
  %r1053.0.relocated380 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token373, i32 5, i32 5) ; (%.41524, %.41524)
  %rs4gc.s35.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token373, i32 6, i32 6) ; (%rs4gc.s35, %rs4gc.s35)
  %r55.0.relocated381 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token373, i32 2, i32 7) ; (%.111275, %.111342)
  %r48.0.relocated382 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token373, i32 3, i32 8) ; (%.101288, %.101394)
  br label %aidx.dynamic_merge.221

aidx.dynamic_merge.221:                           ; preds = %aidx.dynamic.merge.225, %aidx.runtime_key.220
  %.01588 = phi ptr addrspace(1) [ %.11589, %aidx.dynamic.merge.225 ], [ %rs4gc.s35.relocated, %aidx.runtime_key.220 ]
  %.21580 = phi ptr addrspace(1) [ %.31581, %aidx.dynamic.merge.225 ], [ %rs4gc.s34.relocated376, %aidx.runtime_key.220 ]
  %.71536 = phi ptr addrspace(1) [ %.81537, %aidx.dynamic.merge.225 ], [ %r1046.0.relocated379, %aidx.runtime_key.220 ]
  %.61526 = phi ptr addrspace(1) [ %.71527, %aidx.dynamic.merge.225 ], [ %r1053.0.relocated380, %aidx.runtime_key.220 ]
  %.71478 = phi ptr addrspace(1) [ %.81479, %aidx.dynamic.merge.225 ], [ %r1046.0.base.relocated375, %aidx.runtime_key.220 ]
  %.121396 = phi ptr addrspace(1) [ %.131397, %aidx.dynamic.merge.225 ], [ %r48.0.relocated382, %aidx.runtime_key.220 ]
  %.131344 = phi ptr addrspace(1) [ %.141345, %aidx.dynamic.merge.225 ], [ %r55.0.relocated381, %aidx.runtime_key.220 ]
  %.121290 = phi ptr addrspace(1) [ %.131291, %aidx.dynamic.merge.225 ], [ %r48.0.base.relocated378, %aidx.runtime_key.220 ]
  %.131277 = phi ptr addrspace(1) [ %.14, %aidx.dynamic.merge.225 ], [ %r55.0.base.relocated377, %aidx.runtime_key.220 ]
  %r1544 = phi double [ %r1540, %aidx.dynamic.merge.225 ], [ %r1543374, %aidx.runtime_key.220 ]
  %r1545.rs4i = ptrtoint ptr addrspace(1) %.01588 to i64
  %r1545 = call i64 asm "", "=r,0"(i64 %r1545.rs4i) #7
  %r1546 = bitcast i64 %r1545 to double
  %r1547 = bitcast double %r1544 to i64
  %r1548 = and i64 %r1545, 9221120237041090560
  %r1549 = icmp ne i64 %r1548, 9221120237041090560
  %r1550 = and i64 %r1547, 9221120237041090560
  %r1551 = icmp ne i64 %r1550, 9221120237041090560
  %r1552 = and i1 %r1549, %r1551
  br i1 %r1552, label %dyncmp.num.229, label %dyncmp.slow.230

aidx.dynamic.fast.222:                            ; preds = %aidx.dynamic.guard.range.228
  %r1530 = zext i32 %r1468 to i64
  %r1531 = shl nuw nsw i64 %r1530, 3
  %r1532 = add nuw nsw i64 %r1531, 8
  %r1533 = add i64 %r1489, %r1532
  %r1534 = inttoptr i64 %r1533 to ptr
  %r1535 = load double, ptr %r1534, align 8
  %r1536 = bitcast double %r1535 to i64
  %r1537 = icmp eq i64 %r1536, 9222246136947933200
  %r1539 = select i1 %r1537, double 0x7FFC000000000001, double %r1535
  br label %aidx.dynamic.merge.225

aidx.dynamic.fallback.223:                        ; preds = %aidx.dynamic.guard.live.227, %aidx.dynamic.guard.deref.226, %aidx.canonical.219
  %r1528 = sitofp i32 %r1468 to double
  %statepoint_token383 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 5587713372188573702, double %r1451, double %r1528, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.51476, ptr addrspace(1) %.01578, ptr addrspace(1) %.111275, ptr addrspace(1) %.101288, ptr addrspace(1) %.51534, ptr addrspace(1) %.41524, ptr addrspace(1) %rs4gc.s35, ptr addrspace(1) %.111342, ptr addrspace(1) %.101394) ]
  %r1529384 = call double @llvm.experimental.gc.result.f64(token %statepoint_token383)
  %r1046.0.base.relocated385 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token383, i32 0, i32 0) ; (%.51476, %.51476)
  %rs4gc.s34.relocated386 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token383, i32 1, i32 1) ; (%.01578, %.01578)
  %r55.0.base.relocated387 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token383, i32 2, i32 2) ; (%.111275, %.111275)
  %r48.0.base.relocated388 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token383, i32 3, i32 3) ; (%.101288, %.101288)
  %r1046.0.relocated389 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token383, i32 0, i32 4) ; (%.51476, %.51534)
  %r1053.0.relocated390 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token383, i32 5, i32 5) ; (%.41524, %.41524)
  %rs4gc.s35.relocated391 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token383, i32 6, i32 6) ; (%rs4gc.s35, %rs4gc.s35)
  %r55.0.relocated392 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token383, i32 2, i32 7) ; (%.111275, %.111342)
  %r48.0.relocated393 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token383, i32 3, i32 8) ; (%.101288, %.101394)
  br label %aidx.dynamic.merge.225

aidx.dynamic.guard.oob.224:                       ; preds = %aidx.dynamic.guard.range.228
  br label %aidx.dynamic.merge.225

aidx.dynamic.merge.225:                           ; preds = %aidx.dynamic.guard.oob.224, %aidx.dynamic.fallback.223, %aidx.dynamic.fast.222
  %.11589 = phi ptr addrspace(1) [ %rs4gc.s35, %aidx.dynamic.fast.222 ], [ %rs4gc.s35, %aidx.dynamic.guard.oob.224 ], [ %rs4gc.s35.relocated391, %aidx.dynamic.fallback.223 ]
  %.31581 = phi ptr addrspace(1) [ %.01578, %aidx.dynamic.fast.222 ], [ %.01578, %aidx.dynamic.guard.oob.224 ], [ %rs4gc.s34.relocated386, %aidx.dynamic.fallback.223 ]
  %.81537 = phi ptr addrspace(1) [ %.51534, %aidx.dynamic.fast.222 ], [ %.51534, %aidx.dynamic.guard.oob.224 ], [ %r1046.0.relocated389, %aidx.dynamic.fallback.223 ]
  %.71527 = phi ptr addrspace(1) [ %.41524, %aidx.dynamic.fast.222 ], [ %.41524, %aidx.dynamic.guard.oob.224 ], [ %r1053.0.relocated390, %aidx.dynamic.fallback.223 ]
  %.81479 = phi ptr addrspace(1) [ %.51476, %aidx.dynamic.fast.222 ], [ %.51476, %aidx.dynamic.guard.oob.224 ], [ %r1046.0.base.relocated385, %aidx.dynamic.fallback.223 ]
  %.131397 = phi ptr addrspace(1) [ %.101394, %aidx.dynamic.fast.222 ], [ %.101394, %aidx.dynamic.guard.oob.224 ], [ %r48.0.relocated393, %aidx.dynamic.fallback.223 ]
  %.141345 = phi ptr addrspace(1) [ %.111342, %aidx.dynamic.fast.222 ], [ %.111342, %aidx.dynamic.guard.oob.224 ], [ %r55.0.relocated392, %aidx.dynamic.fallback.223 ]
  %.131291 = phi ptr addrspace(1) [ %.101288, %aidx.dynamic.fast.222 ], [ %.101288, %aidx.dynamic.guard.oob.224 ], [ %r48.0.base.relocated388, %aidx.dynamic.fallback.223 ]
  %.14 = phi ptr addrspace(1) [ %.111275, %aidx.dynamic.fast.222 ], [ %.111275, %aidx.dynamic.guard.oob.224 ], [ %r55.0.base.relocated387, %aidx.dynamic.fallback.223 ]
  %r1540 = phi double [ %r1539, %aidx.dynamic.fast.222 ], [ %r1529384, %aidx.dynamic.fallback.223 ], [ 0x7FFC000000000001, %aidx.dynamic.guard.oob.224 ]
  br label %aidx.dynamic_merge.221

aidx.dynamic.guard.deref.226:                     ; preds = %aidx.canonical.219
  %r1475 = bitcast double %r1451 to i64
  %r1476 = and i64 %r1475, 281474976710655
  %r1477 = sub nsw i64 %r1476, 8
  %r1478 = inttoptr i64 %r1477 to ptr
  %r1479 = load i8, ptr %r1478, align 1
  %r1480 = icmp eq i8 %r1479, 1
  %r1481 = sub nsw i64 %r1476, 7
  %r1482 = inttoptr i64 %r1481 to ptr
  %r1483 = load i8, ptr %r1482, align 1
  %r1484 = and i8 %r1483, -128
  %r1485 = icmp ne i8 %r1484, 0
  %r1486 = inttoptr i64 %r1476 to ptr
  %r1487 = load i64, ptr %r1486, align 8
  %r1488 = and i1 %r1480, %r1485
  %r1489 = select i1 %r1488, i64 %r1487, i64 %r1476
  %r1490 = lshr i64 %r1489, 48
  %r1491 = icmp eq i64 %r1490, 0
  %r1492 = icmp ugt i64 %r1489, 1048575
  %r1493 = and i1 %r1491, %r1492
  br i1 %r1493, label %aidx.dynamic.guard.live.227, label %aidx.dynamic.fallback.223

aidx.dynamic.guard.live.227:                      ; preds = %aidx.dynamic.guard.deref.226
  %r1494 = sub nuw i64 %r1489, 8
  %r1495 = inttoptr i64 %r1494 to ptr
  %r1496 = load i8, ptr %r1495, align 1
  %r1497 = icmp eq i8 %r1496, 1
  %r1498 = sub nuw i64 %r1489, 7
  %r1499 = inttoptr i64 %r1498 to ptr
  %r1500 = load i8, ptr %r1499, align 1
  %r1501 = and i8 %r1500, -128
  %r1502 = icmp eq i8 %r1501, 0
  %r1503 = sub nuw i64 %r1489, 6
  %r1504 = inttoptr i64 %r1503 to ptr
  %r1505 = load i16, ptr %r1504, align 2
  %r1506 = and i16 %r1505, 1024
  %r1507 = icmp eq i16 %r1506, 0
  %r1508 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1509 = icmp eq i8 %r1508, 0
  %r1510 = inttoptr i64 %r1489 to ptr
  %r1511 = load i32, ptr %r1510, align 4
  %r1512 = getelementptr i8, ptr %r1510, i64 4
  %r1513 = load i32, ptr %r1512, align 4
  %r1514 = icmp slt i32 %r1468, 0
  %r1515 = icmp eq i1 %r1514, false
  %r1517 = icmp ule i32 %r1511, 16000000
  %r1518 = icmp ule i32 %r1513, 16000000
  %r1519 = icmp ule i32 %r1511, %r1513
  %r1520 = and i1 %r1497, %r1502
  %r1521 = and i1 %r1520, %r1507
  %r1522 = and i1 %r1521, %r1509
  %r1523 = and i1 %r1522, %r1515
  %r1524 = and i1 %r1523, %r1517
  %r1525 = and i1 %r1524, %r1518
  %r1526 = and i1 %r1525, %r1519
  br i1 %r1526, label %aidx.dynamic.guard.range.228, label %aidx.dynamic.fallback.223

aidx.dynamic.guard.range.228:                     ; preds = %aidx.dynamic.guard.live.227
  %r1516 = icmp ult i32 %r1468, %r1511
  br i1 %r1516, label %aidx.dynamic.fast.222, label %aidx.dynamic.guard.oob.224

dyncmp.num.229:                                   ; preds = %aidx.dynamic_merge.221
  %r1553 = fcmp oeq double %r1546, %r1544
  %r1554 = select i1 %r1553, i64 9222246136947933188, i64 9222246136947933187
  br label %dyncmp.merge.231

dyncmp.slow.230:                                  ; preds = %aidx.dynamic_merge.221
  %statepoint_token394 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i64)) @js_eq, i32 2, i32 0, i64 %r1545, i64 %r1547, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.71478, ptr addrspace(1) %.21580, ptr addrspace(1) %.131277, ptr addrspace(1) %.121290, ptr addrspace(1) %.71536, ptr addrspace(1) %.61526, ptr addrspace(1) %.131344, ptr addrspace(1) %.121396) ]
  %r1555395 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token394)
  %r1046.0.base.relocated396 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 0, i32 0) ; (%.71478, %.71478)
  %rs4gc.s34.relocated397 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 1, i32 1) ; (%.21580, %.21580)
  %r55.0.base.relocated398 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 2, i32 2) ; (%.131277, %.131277)
  %r48.0.base.relocated399 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 3, i32 3) ; (%.121290, %.121290)
  %r1046.0.relocated400 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 0, i32 4) ; (%.71478, %.71536)
  %r1053.0.relocated401 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 5, i32 5) ; (%.61526, %.61526)
  %r55.0.relocated402 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 2, i32 6) ; (%.131277, %.131344)
  %r48.0.relocated403 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 3, i32 7) ; (%.121290, %.121396)
  br label %dyncmp.merge.231

dyncmp.merge.231:                                 ; preds = %dyncmp.slow.230, %dyncmp.num.229
  %.41582 = phi ptr addrspace(1) [ %.21580, %dyncmp.num.229 ], [ %rs4gc.s34.relocated397, %dyncmp.slow.230 ]
  %.91538 = phi ptr addrspace(1) [ %.71536, %dyncmp.num.229 ], [ %r1046.0.relocated400, %dyncmp.slow.230 ]
  %.81528 = phi ptr addrspace(1) [ %.61526, %dyncmp.num.229 ], [ %r1053.0.relocated401, %dyncmp.slow.230 ]
  %.91480 = phi ptr addrspace(1) [ %.71478, %dyncmp.num.229 ], [ %r1046.0.base.relocated396, %dyncmp.slow.230 ]
  %.141398 = phi ptr addrspace(1) [ %.121396, %dyncmp.num.229 ], [ %r48.0.relocated403, %dyncmp.slow.230 ]
  %.151346 = phi ptr addrspace(1) [ %.131344, %dyncmp.num.229 ], [ %r55.0.relocated402, %dyncmp.slow.230 ]
  %.141292 = phi ptr addrspace(1) [ %.121290, %dyncmp.num.229 ], [ %r48.0.base.relocated399, %dyncmp.slow.230 ]
  %.15 = phi ptr addrspace(1) [ %.131277, %dyncmp.num.229 ], [ %r55.0.base.relocated398, %dyncmp.slow.230 ]
  %r1556 = phi i64 [ %r1554, %dyncmp.num.229 ], [ %r1555395, %dyncmp.slow.230 ]
  %r1557 = icmp eq i64 %r1556, 9222246136947933188
  %r1558 = xor i1 %r1557, true
  %r1559 = select i1 %r1558, i64 9222246136947933188, i64 9222246136947933187
  %r1560 = bitcast i64 %r1559 to double
  %r1561 = icmp eq i64 %r1559, 9222246136947933188
  br i1 %r1561, label %if.then.232, label %if.else.233

if.then.232:                                      ; preds = %dyncmp.merge.231
  %r1562 = load double, ptr @test_json_source_token_length_ts_.str.11.handle, align 8
  %statepoint_token404 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_error_new_from_value, i32 1, i32 0, double %r1562, i32 0, i32 0)
  %r1563405 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token404)
  %r1564 = or i64 %r1563405, 9222527611924643840
  %r1565 = bitcast i64 %r1564 to double
  %statepoint_token406 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r1565, i32 0, i32 0)
  unreachable

if.else.233:                                      ; preds = %dyncmp.merge.231
  br label %if.merge.234

if.merge.234:                                     ; preds = %if.else.233
  %r1566.rs4i = ptrtoint ptr addrspace(1) %.81528 to i64
  %r1566.rs4o = call i64 asm "", "=r,0"(i64 %r1566.rs4i) #7
  %r1566 = bitcast i64 %r1566.rs4o to double
  %r1567 = bitcast double %r1566 to i64
  %rs4gc.s36 = inttoptr i64 %r1567 to ptr addrspace(1)
  %r1568.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s36 to i64
  %r1568 = call i64 asm "", "=r,0"(i64 %r1568.rs4i) #7
  %r1569 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1570 = icmp ne i32 %r1569, 0
  br i1 %r1570, label %shadow.root.barrier.235, label %shadow.root.barrier.done.236

shadow.root.barrier.235:                          ; preds = %if.merge.234
  call void @js_write_barrier_root_nanbox(i64 %r1568) #7
  br label %shadow.root.barrier.done.236

shadow.root.barrier.done.236:                     ; preds = %shadow.root.barrier.235, %if.merge.234
  %r1571.rs4i = ptrtoint ptr addrspace(1) %.41582 to i64
  %r1571.rs4o = call i64 asm "", "=r,0"(i64 %r1571.rs4i) #7
  %r1571 = bitcast i64 %r1571.rs4o to double
  %r1572 = bitcast double %r1571 to i64
  %r1573 = and i64 %r1572, 281474976710655
  %r1574 = lshr i64 %r1572, 48
  %r1575 = and i64 %r1574, 65533
  %r1576 = icmp eq i64 %r1575, 32765
  br i1 %r1576, label %pget.recv_ok.238, label %pget.recv_other.242

pget.recv_sso.237:                                ; preds = %pget.recv_other.242
  %r1714 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r1715 = bitcast double %r1714 to i64
  %r1716 = and i64 %r1715, 281474976710655
  %statepoint_token407 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1572, i64 %r1716, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.91480, ptr addrspace(1) %.41582, ptr addrspace(1) %rs4gc.s36, ptr addrspace(1) %.15, ptr addrspace(1) %.141292, ptr addrspace(1) %.91538, ptr addrspace(1) %.151346, ptr addrspace(1) %.141398) ]
  %r1717408 = call double @llvm.experimental.gc.result.f64(token %statepoint_token407)
  %r1046.0.base.relocated409 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token407, i32 0, i32 0) ; (%.91480, %.91480)
  %rs4gc.s34.relocated410 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token407, i32 1, i32 1) ; (%.41582, %.41582)
  %rs4gc.s36.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token407, i32 2, i32 2) ; (%rs4gc.s36, %rs4gc.s36)
  %r55.0.base.relocated411 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token407, i32 3, i32 3) ; (%.15, %.15)
  %r48.0.base.relocated412 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token407, i32 4, i32 4) ; (%.141292, %.141292)
  %r1046.0.relocated413 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token407, i32 0, i32 5) ; (%.91480, %.91538)
  %r55.0.relocated414 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token407, i32 3, i32 6) ; (%.15, %.151346)
  %r48.0.relocated415 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token407, i32 4, i32 7) ; (%.141292, %.141398)
  br label %pget.recv_merge.241

pget.recv_ok.238:                                 ; preds = %shadow.root.barrier.done.236
  %r1583 = icmp ugt i64 %r1573, 1048575
  br i1 %r1583, label %pic.recv_hdr.259, label %pic.miss.cold.256

pget.recv_bad.239:                                ; preds = %pget.check_class_ref.243
  %r1706 = icmp eq i64 %r1572, 9222246136947933185
  %r1707 = icmp eq i64 %r1572, 9222246136947933186
  %r1708 = or i1 %r1706, %r1707
  br i1 %r1708, label %pget.throw_nullish.266, label %pget.recv_undef_return.267

pget.recv_class_ref.240:                          ; preds = %pget.check_class_ref.243
  %r1579 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r1580 = bitcast double %r1579 to i64
  %r1581 = and i64 %r1580, 281474976710655
  %statepoint_token416 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 5587713372188573703, i64 %r1572, i64 %r1581, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.91480, ptr addrspace(1) %.41582, ptr addrspace(1) %rs4gc.s36, ptr addrspace(1) %.15, ptr addrspace(1) %.141292, ptr addrspace(1) %.91538, ptr addrspace(1) %.151346, ptr addrspace(1) %.141398) ]
  %r1582417 = call double @llvm.experimental.gc.result.f64(token %statepoint_token416)
  %r1046.0.base.relocated418 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token416, i32 0, i32 0) ; (%.91480, %.91480)
  %rs4gc.s34.relocated419 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token416, i32 1, i32 1) ; (%.41582, %.41582)
  %rs4gc.s36.relocated420 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token416, i32 2, i32 2) ; (%rs4gc.s36, %rs4gc.s36)
  %r55.0.base.relocated421 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token416, i32 3, i32 3) ; (%.15, %.15)
  %r48.0.base.relocated422 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token416, i32 4, i32 4) ; (%.141292, %.141292)
  %r1046.0.relocated423 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token416, i32 0, i32 5) ; (%.91480, %.91538)
  %r55.0.relocated424 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token416, i32 3, i32 6) ; (%.15, %.151346)
  %r48.0.relocated425 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token416, i32 4, i32 7) ; (%.141292, %.141398)
  br label %pget.recv_merge.241

pget.recv_merge.241:                              ; preds = %pget.recv_undef_return.267, %pic.merge.258, %pget.recv_class_ref.240, %pget.recv_sso.237
  %.01590 = phi ptr addrspace(1) [ %.11591, %pic.merge.258 ], [ %rs4gc.s36.relocated, %pget.recv_sso.237 ], [ %rs4gc.s36.relocated420, %pget.recv_class_ref.240 ], [ %rs4gc.s36.relocated451, %pget.recv_undef_return.267 ]
  %.51583 = phi ptr addrspace(1) [ %.61584, %pic.merge.258 ], [ %rs4gc.s34.relocated410, %pget.recv_sso.237 ], [ %rs4gc.s34.relocated419, %pget.recv_class_ref.240 ], [ %rs4gc.s34.relocated450, %pget.recv_undef_return.267 ]
  %.101539 = phi ptr addrspace(1) [ %.111540, %pic.merge.258 ], [ %r1046.0.relocated413, %pget.recv_sso.237 ], [ %r1046.0.relocated423, %pget.recv_class_ref.240 ], [ %r1046.0.relocated454, %pget.recv_undef_return.267 ]
  %.101481 = phi ptr addrspace(1) [ %.111482, %pic.merge.258 ], [ %r1046.0.base.relocated409, %pget.recv_sso.237 ], [ %r1046.0.base.relocated418, %pget.recv_class_ref.240 ], [ %r1046.0.base.relocated449, %pget.recv_undef_return.267 ]
  %.151399 = phi ptr addrspace(1) [ %.161400, %pic.merge.258 ], [ %r48.0.relocated415, %pget.recv_sso.237 ], [ %r48.0.relocated425, %pget.recv_class_ref.240 ], [ %r48.0.relocated456, %pget.recv_undef_return.267 ]
  %.161347 = phi ptr addrspace(1) [ %.171348, %pic.merge.258 ], [ %r55.0.relocated414, %pget.recv_sso.237 ], [ %r55.0.relocated424, %pget.recv_class_ref.240 ], [ %r55.0.relocated455, %pget.recv_undef_return.267 ]
  %.151293 = phi ptr addrspace(1) [ %.161294, %pic.merge.258 ], [ %r48.0.base.relocated412, %pget.recv_sso.237 ], [ %r48.0.base.relocated422, %pget.recv_class_ref.240 ], [ %r48.0.base.relocated453, %pget.recv_undef_return.267 ]
  %.16 = phi ptr addrspace(1) [ %.17, %pic.merge.258 ], [ %r55.0.base.relocated411, %pget.recv_sso.237 ], [ %r55.0.base.relocated421, %pget.recv_class_ref.240 ], [ %r55.0.base.relocated452, %pget.recv_undef_return.267 ]
  %r1718 = phi double [ %r1705, %pic.merge.258 ], [ %r1713448, %pget.recv_undef_return.267 ], [ %r1717408, %pget.recv_sso.237 ], [ %r1582417, %pget.recv_class_ref.240 ]
  %r1719 = bitcast double %r1718 to i64
  %r1720 = and i64 %r1719, 281474976710655
  %r1721 = lshr i64 %r1719, 48
  %r1722 = and i64 %r1721, 65533
  %r1723 = icmp eq i64 %r1722, 32765
  br i1 %r1723, label %pget.recv_ok.269, label %pget.recv_other.274

pget.recv_other.242:                              ; preds = %shadow.root.barrier.done.236
  %r1577 = icmp eq i64 %r1574, 32761
  br i1 %r1577, label %pget.recv_sso.237, label %pget.check_class_ref.243

pget.check_class_ref.243:                         ; preds = %pget.recv_other.242
  %r1578 = icmp eq i64 %r1574, 32766
  br i1 %r1578, label %pget.recv_class_ref.240, label %pget.recv_bad.239

pic.hit.244:                                      ; preds = %pic.token.260
  %r1608 = getelementptr i64, ptr %r1593, i64 1
  %r1609 = load i64, ptr %r1608, align 8
  %r1610 = and i64 %r1609, 1073741824
  %r1611 = icmp ne i64 %r1610, 0
  br i1 %r1611, label %pic.hit.overflow.261, label %pic.hit.inline.262

pic.hit.live.245:                                 ; preds = %pic.hit.inline.262
  br label %pic.merge.258

pic.prefix.guard.246:                             ; preds = %pic.token.260
  %r1624 = getelementptr i64, ptr %r1593, i64 2
  %r1625 = load i64, ptr %r1624, align 8
  %r1626 = icmp ne i64 %r1625, 0
  br i1 %r1626, label %pic.prefix.meta.247, label %pic.miss.255

pic.prefix.meta.247:                              ; preds = %pic.prefix.guard.246
  %r1627 = add nuw nsw i64 %r1573, 8
  %r1628 = inttoptr i64 %r1627 to ptr
  %r1629 = load i64, ptr %r1628, align 8
  %r1630 = icmp ne i64 %r1629, 0
  br i1 %r1630, label %pic.prefix.token.248, label %pic.miss.255

pic.prefix.token.248:                             ; preds = %pic.prefix.meta.247
  %r1631 = inttoptr i64 %r1629 to ptr
  %r1632 = getelementptr i64, ptr %r1631, i64 6
  %r1633 = load i64, ptr %r1632, align 8
  %r1634 = icmp eq i64 %r1633, %r1625
  br i1 %r1634, label %pic.prefix.hit.249, label %pic.miss.255

pic.prefix.hit.249:                               ; preds = %pic.prefix.token.248
  %r1635 = getelementptr i64, ptr %r1593, i64 1
  %r1636 = load i64, ptr %r1635, align 8
  %r1637 = shl i64 %r1636, 3
  %r1638 = add nuw nsw i64 %r1573, 16
  %r1639 = add i64 %r1638, %r1637
  %r1640 = inttoptr i64 %r1639 to ptr
  %r1641 = load double, ptr %r1640, align 8
  br label %pic.merge.258

pic.desc.classify.250:                            ; preds = %pic.recv_hdr.259
  %r1597 = and i1 %r1587, %r1594
  br i1 %r1597, label %pic.desc.prefix.guard.251, label %pic.miss.cold.256

pic.desc.prefix.guard.251:                        ; preds = %pic.desc.classify.250
  %r1642 = getelementptr i64, ptr %r1593, i64 2
  %r1643 = load i64, ptr %r1642, align 8
  %r1644 = icmp ne i64 %r1643, 0
  br i1 %r1644, label %pic.desc.prefix.meta.252, label %pic.miss.cold.256

pic.desc.prefix.meta.252:                         ; preds = %pic.desc.prefix.guard.251
  %r1645 = add nuw nsw i64 %r1573, 8
  %r1646 = inttoptr i64 %r1645 to ptr
  %r1647 = load i64, ptr %r1646, align 8
  %r1648 = icmp ne i64 %r1647, 0
  br i1 %r1648, label %pic.desc.prefix.token.253, label %pic.miss.cold.256

pic.desc.prefix.token.253:                        ; preds = %pic.desc.prefix.meta.252
  %r1649 = inttoptr i64 %r1647 to ptr
  %r1650 = getelementptr i64, ptr %r1649, i64 6
  %r1651 = load i64, ptr %r1650, align 8
  %r1652 = icmp eq i64 %r1651, %r1643
  br i1 %r1652, label %pic.desc.prefix.hit.254, label %pic.miss.cold.256

pic.desc.prefix.hit.254:                          ; preds = %pic.desc.prefix.token.253
  %r1653 = getelementptr i64, ptr %r1593, i64 1
  %r1654 = load i64, ptr %r1653, align 8
  %r1655 = shl i64 %r1654, 3
  %r1656 = add nuw nsw i64 %r1573, 16
  %r1657 = add i64 %r1656, %r1655
  %r1658 = inttoptr i64 %r1657 to ptr
  %r1659 = load double, ptr %r1658, align 8
  br label %pic.merge.258

pic.miss.255:                                     ; preds = %pic.hit.inline.262, %pic.prefix.token.248, %pic.prefix.meta.247, %pic.prefix.guard.246
  %r1660 = getelementptr i64, ptr %r1593, i64 3
  %r1661 = load i64, ptr %r1660, align 8
  %r1662 = icmp sgt i64 %r1661, 0
  br i1 %r1662, label %pic.ways.263, label %pic.miss.call.257

pic.miss.cold.256:                                ; preds = %pic.desc.prefix.token.253, %pic.desc.prefix.meta.252, %pic.desc.prefix.guard.251, %pic.desc.classify.250, %pget.recv_ok.238
  br label %pic.miss.call.257

pic.miss.call.257:                                ; preds = %pic.way.load.264, %pic.ways.263, %pic.miss.cold.256, %pic.miss.255
  %r1701 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r1702 = bitcast double %r1701 to i64
  %r1703 = and i64 %r1702, 281474976710655
  %statepoint_token426 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1573, i64 %r1703, ptr @perry_ic_test_json_source_token_length_ts__8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.91480, ptr addrspace(1) %.41582, ptr addrspace(1) %rs4gc.s36, ptr addrspace(1) %.15, ptr addrspace(1) %.141292, ptr addrspace(1) %.91538, ptr addrspace(1) %.151346, ptr addrspace(1) %.141398) ]
  %r1704427 = call double @llvm.experimental.gc.result.f64(token %statepoint_token426)
  %r1046.0.base.relocated428 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token426, i32 0, i32 0) ; (%.91480, %.91480)
  %rs4gc.s34.relocated429 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token426, i32 1, i32 1) ; (%.41582, %.41582)
  %rs4gc.s36.relocated430 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token426, i32 2, i32 2) ; (%rs4gc.s36, %rs4gc.s36)
  %r55.0.base.relocated431 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token426, i32 3, i32 3) ; (%.15, %.15)
  %r48.0.base.relocated432 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token426, i32 4, i32 4) ; (%.141292, %.141292)
  %r1046.0.relocated433 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token426, i32 0, i32 5) ; (%.91480, %.91538)
  %r55.0.relocated434 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token426, i32 3, i32 6) ; (%.15, %.151346)
  %r48.0.relocated435 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token426, i32 4, i32 7) ; (%.141292, %.141398)
  br label %pic.merge.258

pic.merge.258:                                    ; preds = %pic.way.live.265, %pic.hit.overflow.261, %pic.miss.call.257, %pic.desc.prefix.hit.254, %pic.prefix.hit.249, %pic.hit.live.245
  %.11591 = phi ptr addrspace(1) [ %rs4gc.s36.relocated440, %pic.hit.overflow.261 ], [ %rs4gc.s36.relocated430, %pic.miss.call.257 ], [ %rs4gc.s36, %pic.way.live.265 ], [ %rs4gc.s36, %pic.hit.live.245 ], [ %rs4gc.s36, %pic.prefix.hit.249 ], [ %rs4gc.s36, %pic.desc.prefix.hit.254 ]
  %.61584 = phi ptr addrspace(1) [ %rs4gc.s34.relocated439, %pic.hit.overflow.261 ], [ %rs4gc.s34.relocated429, %pic.miss.call.257 ], [ %.41582, %pic.way.live.265 ], [ %.41582, %pic.hit.live.245 ], [ %.41582, %pic.prefix.hit.249 ], [ %.41582, %pic.desc.prefix.hit.254 ]
  %.111540 = phi ptr addrspace(1) [ %r1046.0.relocated443, %pic.hit.overflow.261 ], [ %r1046.0.relocated433, %pic.miss.call.257 ], [ %.91538, %pic.way.live.265 ], [ %.91538, %pic.hit.live.245 ], [ %.91538, %pic.prefix.hit.249 ], [ %.91538, %pic.desc.prefix.hit.254 ]
  %.111482 = phi ptr addrspace(1) [ %r1046.0.base.relocated438, %pic.hit.overflow.261 ], [ %r1046.0.base.relocated428, %pic.miss.call.257 ], [ %.91480, %pic.way.live.265 ], [ %.91480, %pic.hit.live.245 ], [ %.91480, %pic.prefix.hit.249 ], [ %.91480, %pic.desc.prefix.hit.254 ]
  %.161400 = phi ptr addrspace(1) [ %r48.0.relocated445, %pic.hit.overflow.261 ], [ %r48.0.relocated435, %pic.miss.call.257 ], [ %.141398, %pic.way.live.265 ], [ %.141398, %pic.hit.live.245 ], [ %.141398, %pic.prefix.hit.249 ], [ %.141398, %pic.desc.prefix.hit.254 ]
  %.171348 = phi ptr addrspace(1) [ %r55.0.relocated444, %pic.hit.overflow.261 ], [ %r55.0.relocated434, %pic.miss.call.257 ], [ %.151346, %pic.way.live.265 ], [ %.151346, %pic.hit.live.245 ], [ %.151346, %pic.prefix.hit.249 ], [ %.151346, %pic.desc.prefix.hit.254 ]
  %.161294 = phi ptr addrspace(1) [ %r48.0.base.relocated442, %pic.hit.overflow.261 ], [ %r48.0.base.relocated432, %pic.miss.call.257 ], [ %.141292, %pic.way.live.265 ], [ %.141292, %pic.hit.live.245 ], [ %.141292, %pic.prefix.hit.249 ], [ %.141292, %pic.desc.prefix.hit.254 ]
  %.17 = phi ptr addrspace(1) [ %r55.0.base.relocated441, %pic.hit.overflow.261 ], [ %r55.0.base.relocated431, %pic.miss.call.257 ], [ %.15, %pic.way.live.265 ], [ %.15, %pic.hit.live.245 ], [ %.15, %pic.prefix.hit.249 ], [ %.15, %pic.desc.prefix.hit.254 ]
  %r1705 = phi double [ %r1621, %pic.hit.live.245 ], [ %r1616437, %pic.hit.overflow.261 ], [ %r1641, %pic.prefix.hit.249 ], [ %r1659, %pic.desc.prefix.hit.254 ], [ %r1698, %pic.way.live.265 ], [ %r1704427, %pic.miss.call.257 ]
  br label %pget.recv_merge.241

pic.recv_hdr.259:                                 ; preds = %pget.recv_ok.238
  %r1584 = sub nuw nsw i64 %r1573, 8
  %r1585 = inttoptr i64 %r1584 to ptr
  %r1586 = load i8, ptr %r1585, align 1
  %r1587 = icmp eq i8 %r1586, 2
  %r1588 = sub nuw nsw i64 %r1573, 6
  %r1589 = inttoptr i64 %r1588 to ptr
  %r1590 = load i16, ptr %r1589, align 2
  %r1591 = and i16 %r1590, 2048
  %r1592 = icmp eq i16 %r1591, 0
  %r1593 = load ptr, ptr @perry_ic_test_json_source_token_length_ts__8, align 8
  %r1594 = icmp ne ptr %r1593, null
  %r1595 = and i1 %r1587, %r1592
  %r1596 = and i1 %r1595, %r1594
  br i1 %r1596, label %pic.token.260, label %pic.desc.classify.250

pic.token.260:                                    ; preds = %pic.recv_hdr.259
  %r1598 = add nuw nsw i64 %r1573, 4
  %r1599 = inttoptr i64 %r1598 to ptr
  %r1600 = load i32, ptr %r1599, align 4
  %r1601 = zext i32 %r1600 to i64
  %r1602 = or i64 %r1601, 4611686018427387904
  %r1603 = icmp ne i32 %r1600, 0
  %r1604 = getelementptr i64, ptr %r1593, i64 0
  %r1605 = load i64, ptr %r1604, align 8
  %r1606 = icmp eq i64 %r1602, %r1605
  %r1607 = and i1 %r1606, %r1603
  br i1 %r1607, label %pic.hit.244, label %pic.prefix.guard.246

pic.hit.overflow.261:                             ; preds = %pic.hit.244
  %r1612 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r1613 = bitcast double %r1612 to i64
  %r1614 = and i64 %r1613, 281474976710655
  %r1615 = trunc i64 %r1609 to i32
  %statepoint_token436 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1573, i64 %r1614, i32 %r1615, ptr @perry_ic_test_json_source_token_length_ts__8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.91480, ptr addrspace(1) %.41582, ptr addrspace(1) %rs4gc.s36, ptr addrspace(1) %.15, ptr addrspace(1) %.141292, ptr addrspace(1) %.91538, ptr addrspace(1) %.151346, ptr addrspace(1) %.141398) ]
  %r1616437 = call double @llvm.experimental.gc.result.f64(token %statepoint_token436)
  %r1046.0.base.relocated438 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token436, i32 0, i32 0) ; (%.91480, %.91480)
  %rs4gc.s34.relocated439 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token436, i32 1, i32 1) ; (%.41582, %.41582)
  %rs4gc.s36.relocated440 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token436, i32 2, i32 2) ; (%rs4gc.s36, %rs4gc.s36)
  %r55.0.base.relocated441 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token436, i32 3, i32 3) ; (%.15, %.15)
  %r48.0.base.relocated442 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token436, i32 4, i32 4) ; (%.141292, %.141292)
  %r1046.0.relocated443 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token436, i32 0, i32 5) ; (%.91480, %.91538)
  %r55.0.relocated444 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token436, i32 3, i32 6) ; (%.15, %.151346)
  %r48.0.relocated445 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token436, i32 4, i32 7) ; (%.141292, %.141398)
  br label %pic.merge.258

pic.hit.inline.262:                               ; preds = %pic.hit.244
  %r1617 = shl i64 %r1609, 3
  %r1618 = add nuw nsw i64 %r1573, 16
  %r1619 = add i64 %r1618, %r1617
  %r1620 = inttoptr i64 %r1619 to ptr
  %r1621 = load double, ptr %r1620, align 8
  %r1622 = bitcast double %r1621 to i64
  %r1623 = icmp eq i64 %r1622, 9222246136947933200
  br i1 %r1623, label %pic.miss.255, label %pic.hit.live.245

pic.ways.263:                                     ; preds = %pic.miss.255
  %r1663 = getelementptr i64, ptr %r1593, i64 4
  %r1664 = load i64, ptr %r1663, align 8
  %r1665 = icmp eq i64 %r1664, %r1602
  %r1666 = getelementptr i64, ptr %r1593, i64 5
  %r1667 = load i64, ptr %r1666, align 8
  %r1668 = select i1 %r1665, i64 %r1667, i64 0
  %r1669 = getelementptr i64, ptr %r1593, i64 6
  %r1670 = load i64, ptr %r1669, align 8
  %r1671 = icmp eq i64 %r1670, %r1602
  %r1672 = getelementptr i64, ptr %r1593, i64 7
  %r1673 = load i64, ptr %r1672, align 8
  %r1674 = select i1 %r1671, i64 %r1673, i64 0
  %r1675 = getelementptr i64, ptr %r1593, i64 8
  %r1676 = load i64, ptr %r1675, align 8
  %r1677 = icmp eq i64 %r1676, %r1602
  %r1678 = getelementptr i64, ptr %r1593, i64 9
  %r1679 = load i64, ptr %r1678, align 8
  %r1680 = select i1 %r1677, i64 %r1679, i64 0
  %r1681 = getelementptr i64, ptr %r1593, i64 10
  %r1682 = load i64, ptr %r1681, align 8
  %r1683 = icmp eq i64 %r1682, %r1602
  %r1684 = getelementptr i64, ptr %r1593, i64 11
  %r1685 = load i64, ptr %r1684, align 8
  %r1686 = select i1 %r1683, i64 %r1685, i64 0
  %r1687 = or i1 %r1665, %r1671
  %r1688 = select i1 %r1665, i64 %r1668, i64 %r1674
  %r1689 = or i1 %r1677, %r1683
  %r1690 = select i1 %r1677, i64 %r1680, i64 %r1686
  %r1691 = or i1 %r1687, %r1689
  %r1692 = select i1 %r1687, i64 %r1688, i64 %r1690
  %r1693 = and i1 %r1603, %r1691
  br i1 %r1693, label %pic.way.load.264, label %pic.miss.call.257

pic.way.load.264:                                 ; preds = %pic.ways.263
  %r1694 = shl i64 %r1692, 3
  %r1695 = add nuw nsw i64 %r1573, 16
  %r1696 = add i64 %r1695, %r1694
  %r1697 = inttoptr i64 %r1696 to ptr
  %r1698 = load double, ptr %r1697, align 8
  %r1699 = bitcast double %r1698 to i64
  %r1700 = icmp eq i64 %r1699, 9222246136947933200
  br i1 %r1700, label %pic.miss.call.257, label %pic.way.live.265

pic.way.live.265:                                 ; preds = %pic.way.load.264
  br label %pic.merge.258

pget.throw_nullish.266:                           ; preds = %pget.recv_bad.239
  %r1709 = zext i1 %r1707 to i32
  %statepoint_token446 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1709, ptr @test_json_source_token_length_ts_.str.10.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.267:                       ; preds = %pget.recv_bad.239
  %r1710 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r1711 = bitcast double %r1710 to i64
  %r1712 = and i64 %r1711, 281474976710655
  %statepoint_token447 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1572, i64 %r1712, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.91480, ptr addrspace(1) %.41582, ptr addrspace(1) %rs4gc.s36, ptr addrspace(1) %.15, ptr addrspace(1) %.141292, ptr addrspace(1) %.91538, ptr addrspace(1) %.151346, ptr addrspace(1) %.141398) ]
  %r1713448 = call double @llvm.experimental.gc.result.f64(token %statepoint_token447)
  %r1046.0.base.relocated449 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 0, i32 0) ; (%.91480, %.91480)
  %rs4gc.s34.relocated450 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 1, i32 1) ; (%.41582, %.41582)
  %rs4gc.s36.relocated451 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 2, i32 2) ; (%rs4gc.s36, %rs4gc.s36)
  %r55.0.base.relocated452 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 3, i32 3) ; (%.15, %.15)
  %r48.0.base.relocated453 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 4, i32 4) ; (%.141292, %.141292)
  %r1046.0.relocated454 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 0, i32 5) ; (%.91480, %.91538)
  %r55.0.relocated455 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 3, i32 6) ; (%.15, %.151346)
  %r48.0.relocated456 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 4, i32 7) ; (%.141292, %.141398)
  br label %pget.recv_merge.241

pget.recv_sso.268:                                ; preds = %pget.recv_other.274
  %r1862 = lshr i64 %r1719, 40
  %r1863 = and i64 %r1862, 255
  %r1864 = uitofp nneg i64 %r1863 to double
  br label %pget.recv_merge.272

pget.recv_ok.269:                                 ; preds = %pget.recv_merge.241
  %r1730 = icmp eq i64 %r1721, 32767
  br i1 %r1730, label %pget.strlen_heap.273, label %pget.recv_obj.276

pget.recv_bad.270:                                ; preds = %pget.check_class_ref.275
  %r1854 = icmp eq i64 %r1719, 9222246136947933185
  %r1855 = icmp eq i64 %r1719, 9222246136947933186
  %r1856 = or i1 %r1854, %r1855
  br i1 %r1856, label %pget.throw_nullish.299, label %pget.recv_undef_return.300

pget.recv_class_ref.271:                          ; preds = %pget.check_class_ref.275
  %r1726 = load double, ptr @test_json_source_token_length_ts_.str.12.handle, align 8
  %r1727 = bitcast double %r1726 to i64
  %r1728 = and i64 %r1727, 281474976710655
  %statepoint_token457 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 5587713372188573705, i64 %r1719, i64 %r1728, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.16, ptr addrspace(1) %.151293, ptr addrspace(1) %.101481, ptr addrspace(1) %.101539, ptr addrspace(1) %.51583, ptr addrspace(1) %.01590, ptr addrspace(1) %.161347, ptr addrspace(1) %.151399) ]
  %r1729458 = call double @llvm.experimental.gc.result.f64(token %statepoint_token457)
  %r55.0.base.relocated459 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token457, i32 0, i32 0) ; (%.16, %.16)
  %r48.0.base.relocated460 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token457, i32 1, i32 1) ; (%.151293, %.151293)
  %r1046.0.base.relocated461 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token457, i32 2, i32 2) ; (%.101481, %.101481)
  %r1046.0.relocated462 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token457, i32 2, i32 3) ; (%.101481, %.101539)
  %rs4gc.s34.relocated463 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token457, i32 4, i32 4) ; (%.51583, %.51583)
  %rs4gc.s36.relocated464 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token457, i32 5, i32 5) ; (%.01590, %.01590)
  %r55.0.relocated465 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token457, i32 0, i32 6) ; (%.16, %.161347)
  %r48.0.relocated466 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token457, i32 1, i32 7) ; (%.151293, %.151399)
  br label %pget.recv_merge.272

pget.recv_merge.272:                              ; preds = %pget.recv_undef_return.300, %pic.merge.291, %pget.strlen_heap.273, %pget.recv_class_ref.271, %pget.recv_sso.268
  %.21592 = phi ptr addrspace(1) [ %.01590, %pget.strlen_heap.273 ], [ %.31593, %pic.merge.291 ], [ %.01590, %pget.recv_sso.268 ], [ %rs4gc.s36.relocated464, %pget.recv_class_ref.271 ], [ %rs4gc.s36.relocated495, %pget.recv_undef_return.300 ]
  %.71585 = phi ptr addrspace(1) [ %.51583, %pget.strlen_heap.273 ], [ %.81586, %pic.merge.291 ], [ %.51583, %pget.recv_sso.268 ], [ %rs4gc.s34.relocated463, %pget.recv_class_ref.271 ], [ %rs4gc.s34.relocated494, %pget.recv_undef_return.300 ]
  %.121541 = phi ptr addrspace(1) [ %.101539, %pget.strlen_heap.273 ], [ %.131542, %pic.merge.291 ], [ %.101539, %pget.recv_sso.268 ], [ %r1046.0.relocated462, %pget.recv_class_ref.271 ], [ %r1046.0.relocated493, %pget.recv_undef_return.300 ]
  %.121483 = phi ptr addrspace(1) [ %.101481, %pget.strlen_heap.273 ], [ %.131484, %pic.merge.291 ], [ %.101481, %pget.recv_sso.268 ], [ %r1046.0.base.relocated461, %pget.recv_class_ref.271 ], [ %r1046.0.base.relocated492, %pget.recv_undef_return.300 ]
  %.171401 = phi ptr addrspace(1) [ %.151399, %pget.strlen_heap.273 ], [ %.181402, %pic.merge.291 ], [ %.151399, %pget.recv_sso.268 ], [ %r48.0.relocated466, %pget.recv_class_ref.271 ], [ %r48.0.relocated497, %pget.recv_undef_return.300 ]
  %.181349 = phi ptr addrspace(1) [ %.161347, %pget.strlen_heap.273 ], [ %.191350, %pic.merge.291 ], [ %.161347, %pget.recv_sso.268 ], [ %r55.0.relocated465, %pget.recv_class_ref.271 ], [ %r55.0.relocated496, %pget.recv_undef_return.300 ]
  %.171295 = phi ptr addrspace(1) [ %.151293, %pget.strlen_heap.273 ], [ %.181296, %pic.merge.291 ], [ %.151293, %pget.recv_sso.268 ], [ %r48.0.base.relocated460, %pget.recv_class_ref.271 ], [ %r48.0.base.relocated491, %pget.recv_undef_return.300 ]
  %.18 = phi ptr addrspace(1) [ %.16, %pget.strlen_heap.273 ], [ %.19, %pic.merge.291 ], [ %.16, %pget.recv_sso.268 ], [ %r55.0.base.relocated459, %pget.recv_class_ref.271 ], [ %r55.0.base.relocated490, %pget.recv_undef_return.300 ]
  %r1870 = phi double [ %r1853, %pic.merge.291 ], [ %r1861489, %pget.recv_undef_return.300 ], [ %r1864, %pget.recv_sso.268 ], [ %r1729458, %pget.recv_class_ref.271 ], [ %r1869, %pget.strlen_heap.273 ]
  %r1871.rs4i = ptrtoint ptr addrspace(1) %.21592 to i64
  %r1871 = call i64 asm "", "=r,0"(i64 %r1871.rs4i) #7
  %r1872 = bitcast i64 %r1871 to double
  %r1873 = and i64 %r1871, -281474976710656
  %r1874 = icmp ult i64 %r1873, 9221401712017801216
  %r1875 = icmp ugt i64 %r1873, 9223090561878065152
  %r1876 = or i1 %r1874, %r1875
  %r1877 = bitcast double %r1870 to i64
  %r1878 = and i64 %r1877, -281474976710656
  %r1879 = icmp ult i64 %r1878, 9221401712017801216
  %r1880 = icmp ugt i64 %r1878, 9223090561878065152
  %r1881 = or i1 %r1879, %r1880
  %r1882 = and i1 %r1876, %r1881
  br i1 %r1882, label %guarded_add.numeric.301, label %guarded_add.dynamic.302

pget.strlen_heap.273:                             ; preds = %pget.recv_ok.269
  %r1865 = icmp ult i64 %r1720, 4096
  %r1866 = inttoptr i64 %r1720 to ptr
  %r1867 = select i1 %r1865, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r1866
  %r1868 = load i32, ptr %r1867, align 4
  %r1869 = uitofp i32 %r1868 to double
  br label %pget.recv_merge.272

pget.recv_other.274:                              ; preds = %pget.recv_merge.241
  %r1724 = icmp eq i64 %r1721, 32761
  br i1 %r1724, label %pget.recv_sso.268, label %pget.check_class_ref.275

pget.check_class_ref.275:                         ; preds = %pget.recv_other.274
  %r1725 = icmp eq i64 %r1721, 32766
  br i1 %r1725, label %pget.recv_class_ref.271, label %pget.recv_bad.270

pget.recv_obj.276:                                ; preds = %pget.recv_ok.269
  %r1731 = icmp ugt i64 %r1720, 1048575
  br i1 %r1731, label %pic.recv_hdr.292, label %pic.miss.cold.289

pic.hit.277:                                      ; preds = %pic.token.293
  %r1756 = getelementptr i64, ptr %r1741, i64 1
  %r1757 = load i64, ptr %r1756, align 8
  %r1758 = and i64 %r1757, 1073741824
  %r1759 = icmp ne i64 %r1758, 0
  br i1 %r1759, label %pic.hit.overflow.294, label %pic.hit.inline.295

pic.hit.live.278:                                 ; preds = %pic.hit.inline.295
  br label %pic.merge.291

pic.prefix.guard.279:                             ; preds = %pic.token.293
  %r1772 = getelementptr i64, ptr %r1741, i64 2
  %r1773 = load i64, ptr %r1772, align 8
  %r1774 = icmp ne i64 %r1773, 0
  br i1 %r1774, label %pic.prefix.meta.280, label %pic.miss.288

pic.prefix.meta.280:                              ; preds = %pic.prefix.guard.279
  %r1775 = add nuw nsw i64 %r1720, 8
  %r1776 = inttoptr i64 %r1775 to ptr
  %r1777 = load i64, ptr %r1776, align 8
  %r1778 = icmp ne i64 %r1777, 0
  br i1 %r1778, label %pic.prefix.token.281, label %pic.miss.288

pic.prefix.token.281:                             ; preds = %pic.prefix.meta.280
  %r1779 = inttoptr i64 %r1777 to ptr
  %r1780 = getelementptr i64, ptr %r1779, i64 6
  %r1781 = load i64, ptr %r1780, align 8
  %r1782 = icmp eq i64 %r1781, %r1773
  br i1 %r1782, label %pic.prefix.hit.282, label %pic.miss.288

pic.prefix.hit.282:                               ; preds = %pic.prefix.token.281
  %r1783 = getelementptr i64, ptr %r1741, i64 1
  %r1784 = load i64, ptr %r1783, align 8
  %r1785 = shl i64 %r1784, 3
  %r1786 = add nuw nsw i64 %r1720, 16
  %r1787 = add i64 %r1786, %r1785
  %r1788 = inttoptr i64 %r1787 to ptr
  %r1789 = load double, ptr %r1788, align 8
  br label %pic.merge.291

pic.desc.classify.283:                            ; preds = %pic.recv_hdr.292
  %r1745 = and i1 %r1735, %r1742
  br i1 %r1745, label %pic.desc.prefix.guard.284, label %pic.miss.cold.289

pic.desc.prefix.guard.284:                        ; preds = %pic.desc.classify.283
  %r1790 = getelementptr i64, ptr %r1741, i64 2
  %r1791 = load i64, ptr %r1790, align 8
  %r1792 = icmp ne i64 %r1791, 0
  br i1 %r1792, label %pic.desc.prefix.meta.285, label %pic.miss.cold.289

pic.desc.prefix.meta.285:                         ; preds = %pic.desc.prefix.guard.284
  %r1793 = add nuw nsw i64 %r1720, 8
  %r1794 = inttoptr i64 %r1793 to ptr
  %r1795 = load i64, ptr %r1794, align 8
  %r1796 = icmp ne i64 %r1795, 0
  br i1 %r1796, label %pic.desc.prefix.token.286, label %pic.miss.cold.289

pic.desc.prefix.token.286:                        ; preds = %pic.desc.prefix.meta.285
  %r1797 = inttoptr i64 %r1795 to ptr
  %r1798 = getelementptr i64, ptr %r1797, i64 6
  %r1799 = load i64, ptr %r1798, align 8
  %r1800 = icmp eq i64 %r1799, %r1791
  br i1 %r1800, label %pic.desc.prefix.hit.287, label %pic.miss.cold.289

pic.desc.prefix.hit.287:                          ; preds = %pic.desc.prefix.token.286
  %r1801 = getelementptr i64, ptr %r1741, i64 1
  %r1802 = load i64, ptr %r1801, align 8
  %r1803 = shl i64 %r1802, 3
  %r1804 = add nuw nsw i64 %r1720, 16
  %r1805 = add i64 %r1804, %r1803
  %r1806 = inttoptr i64 %r1805 to ptr
  %r1807 = load double, ptr %r1806, align 8
  br label %pic.merge.291

pic.miss.288:                                     ; preds = %pic.hit.inline.295, %pic.prefix.token.281, %pic.prefix.meta.280, %pic.prefix.guard.279
  %r1808 = getelementptr i64, ptr %r1741, i64 3
  %r1809 = load i64, ptr %r1808, align 8
  %r1810 = icmp sgt i64 %r1809, 0
  br i1 %r1810, label %pic.ways.296, label %pic.miss.call.290

pic.miss.cold.289:                                ; preds = %pic.desc.prefix.token.286, %pic.desc.prefix.meta.285, %pic.desc.prefix.guard.284, %pic.desc.classify.283, %pget.recv_obj.276
  br label %pic.miss.call.290

pic.miss.call.290:                                ; preds = %pic.way.load.297, %pic.ways.296, %pic.miss.cold.289, %pic.miss.288
  %r1849 = load double, ptr @test_json_source_token_length_ts_.str.12.handle, align 8
  %r1850 = bitcast double %r1849 to i64
  %r1851 = and i64 %r1850, 281474976710655
  %statepoint_token467 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1720, i64 %r1851, ptr @perry_ic_test_json_source_token_length_ts__10, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.16, ptr addrspace(1) %.151293, ptr addrspace(1) %.101481, ptr addrspace(1) %.101539, ptr addrspace(1) %.51583, ptr addrspace(1) %.01590, ptr addrspace(1) %.161347, ptr addrspace(1) %.151399) ]
  %r1852468 = call double @llvm.experimental.gc.result.f64(token %statepoint_token467)
  %r55.0.base.relocated469 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token467, i32 0, i32 0) ; (%.16, %.16)
  %r48.0.base.relocated470 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token467, i32 1, i32 1) ; (%.151293, %.151293)
  %r1046.0.base.relocated471 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token467, i32 2, i32 2) ; (%.101481, %.101481)
  %r1046.0.relocated472 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token467, i32 2, i32 3) ; (%.101481, %.101539)
  %rs4gc.s34.relocated473 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token467, i32 4, i32 4) ; (%.51583, %.51583)
  %rs4gc.s36.relocated474 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token467, i32 5, i32 5) ; (%.01590, %.01590)
  %r55.0.relocated475 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token467, i32 0, i32 6) ; (%.16, %.161347)
  %r48.0.relocated476 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token467, i32 1, i32 7) ; (%.151293, %.151399)
  br label %pic.merge.291

pic.merge.291:                                    ; preds = %pic.way.live.298, %pic.hit.overflow.294, %pic.miss.call.290, %pic.desc.prefix.hit.287, %pic.prefix.hit.282, %pic.hit.live.278
  %.31593 = phi ptr addrspace(1) [ %rs4gc.s36.relocated484, %pic.hit.overflow.294 ], [ %rs4gc.s36.relocated474, %pic.miss.call.290 ], [ %.01590, %pic.way.live.298 ], [ %.01590, %pic.hit.live.278 ], [ %.01590, %pic.prefix.hit.282 ], [ %.01590, %pic.desc.prefix.hit.287 ]
  %.81586 = phi ptr addrspace(1) [ %rs4gc.s34.relocated483, %pic.hit.overflow.294 ], [ %rs4gc.s34.relocated473, %pic.miss.call.290 ], [ %.51583, %pic.way.live.298 ], [ %.51583, %pic.hit.live.278 ], [ %.51583, %pic.prefix.hit.282 ], [ %.51583, %pic.desc.prefix.hit.287 ]
  %.131542 = phi ptr addrspace(1) [ %r1046.0.relocated482, %pic.hit.overflow.294 ], [ %r1046.0.relocated472, %pic.miss.call.290 ], [ %.101539, %pic.way.live.298 ], [ %.101539, %pic.hit.live.278 ], [ %.101539, %pic.prefix.hit.282 ], [ %.101539, %pic.desc.prefix.hit.287 ]
  %.131484 = phi ptr addrspace(1) [ %r1046.0.base.relocated481, %pic.hit.overflow.294 ], [ %r1046.0.base.relocated471, %pic.miss.call.290 ], [ %.101481, %pic.way.live.298 ], [ %.101481, %pic.hit.live.278 ], [ %.101481, %pic.prefix.hit.282 ], [ %.101481, %pic.desc.prefix.hit.287 ]
  %.181402 = phi ptr addrspace(1) [ %r48.0.relocated486, %pic.hit.overflow.294 ], [ %r48.0.relocated476, %pic.miss.call.290 ], [ %.151399, %pic.way.live.298 ], [ %.151399, %pic.hit.live.278 ], [ %.151399, %pic.prefix.hit.282 ], [ %.151399, %pic.desc.prefix.hit.287 ]
  %.191350 = phi ptr addrspace(1) [ %r55.0.relocated485, %pic.hit.overflow.294 ], [ %r55.0.relocated475, %pic.miss.call.290 ], [ %.161347, %pic.way.live.298 ], [ %.161347, %pic.hit.live.278 ], [ %.161347, %pic.prefix.hit.282 ], [ %.161347, %pic.desc.prefix.hit.287 ]
  %.181296 = phi ptr addrspace(1) [ %r48.0.base.relocated480, %pic.hit.overflow.294 ], [ %r48.0.base.relocated470, %pic.miss.call.290 ], [ %.151293, %pic.way.live.298 ], [ %.151293, %pic.hit.live.278 ], [ %.151293, %pic.prefix.hit.282 ], [ %.151293, %pic.desc.prefix.hit.287 ]
  %.19 = phi ptr addrspace(1) [ %r55.0.base.relocated479, %pic.hit.overflow.294 ], [ %r55.0.base.relocated469, %pic.miss.call.290 ], [ %.16, %pic.way.live.298 ], [ %.16, %pic.hit.live.278 ], [ %.16, %pic.prefix.hit.282 ], [ %.16, %pic.desc.prefix.hit.287 ]
  %r1853 = phi double [ %r1769, %pic.hit.live.278 ], [ %r1764478, %pic.hit.overflow.294 ], [ %r1789, %pic.prefix.hit.282 ], [ %r1807, %pic.desc.prefix.hit.287 ], [ %r1846, %pic.way.live.298 ], [ %r1852468, %pic.miss.call.290 ]
  br label %pget.recv_merge.272

pic.recv_hdr.292:                                 ; preds = %pget.recv_obj.276
  %r1732 = sub nuw nsw i64 %r1720, 8
  %r1733 = inttoptr i64 %r1732 to ptr
  %r1734 = load i8, ptr %r1733, align 1
  %r1735 = icmp eq i8 %r1734, 2
  %r1736 = sub nuw nsw i64 %r1720, 6
  %r1737 = inttoptr i64 %r1736 to ptr
  %r1738 = load i16, ptr %r1737, align 2
  %r1739 = and i16 %r1738, 2048
  %r1740 = icmp eq i16 %r1739, 0
  %r1741 = load ptr, ptr @perry_ic_test_json_source_token_length_ts__10, align 8
  %r1742 = icmp ne ptr %r1741, null
  %r1743 = and i1 %r1735, %r1740
  %r1744 = and i1 %r1743, %r1742
  br i1 %r1744, label %pic.token.293, label %pic.desc.classify.283

pic.token.293:                                    ; preds = %pic.recv_hdr.292
  %r1746 = add nuw nsw i64 %r1720, 4
  %r1747 = inttoptr i64 %r1746 to ptr
  %r1748 = load i32, ptr %r1747, align 4
  %r1749 = zext i32 %r1748 to i64
  %r1750 = or i64 %r1749, 4611686018427387904
  %r1751 = icmp ne i32 %r1748, 0
  %r1752 = getelementptr i64, ptr %r1741, i64 0
  %r1753 = load i64, ptr %r1752, align 8
  %r1754 = icmp eq i64 %r1750, %r1753
  %r1755 = and i1 %r1754, %r1751
  br i1 %r1755, label %pic.hit.277, label %pic.prefix.guard.279

pic.hit.overflow.294:                             ; preds = %pic.hit.277
  %r1760 = load double, ptr @test_json_source_token_length_ts_.str.12.handle, align 8
  %r1761 = bitcast double %r1760 to i64
  %r1762 = and i64 %r1761, 281474976710655
  %r1763 = trunc i64 %r1757 to i32
  %statepoint_token477 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1720, i64 %r1762, i32 %r1763, ptr @perry_ic_test_json_source_token_length_ts__10, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.16, ptr addrspace(1) %.151293, ptr addrspace(1) %.101481, ptr addrspace(1) %.101539, ptr addrspace(1) %.51583, ptr addrspace(1) %.01590, ptr addrspace(1) %.161347, ptr addrspace(1) %.151399) ]
  %r1764478 = call double @llvm.experimental.gc.result.f64(token %statepoint_token477)
  %r55.0.base.relocated479 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token477, i32 0, i32 0) ; (%.16, %.16)
  %r48.0.base.relocated480 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token477, i32 1, i32 1) ; (%.151293, %.151293)
  %r1046.0.base.relocated481 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token477, i32 2, i32 2) ; (%.101481, %.101481)
  %r1046.0.relocated482 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token477, i32 2, i32 3) ; (%.101481, %.101539)
  %rs4gc.s34.relocated483 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token477, i32 4, i32 4) ; (%.51583, %.51583)
  %rs4gc.s36.relocated484 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token477, i32 5, i32 5) ; (%.01590, %.01590)
  %r55.0.relocated485 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token477, i32 0, i32 6) ; (%.16, %.161347)
  %r48.0.relocated486 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token477, i32 1, i32 7) ; (%.151293, %.151399)
  br label %pic.merge.291

pic.hit.inline.295:                               ; preds = %pic.hit.277
  %r1765 = shl i64 %r1757, 3
  %r1766 = add nuw nsw i64 %r1720, 16
  %r1767 = add i64 %r1766, %r1765
  %r1768 = inttoptr i64 %r1767 to ptr
  %r1769 = load double, ptr %r1768, align 8
  %r1770 = bitcast double %r1769 to i64
  %r1771 = icmp eq i64 %r1770, 9222246136947933200
  br i1 %r1771, label %pic.miss.288, label %pic.hit.live.278

pic.ways.296:                                     ; preds = %pic.miss.288
  %r1811 = getelementptr i64, ptr %r1741, i64 4
  %r1812 = load i64, ptr %r1811, align 8
  %r1813 = icmp eq i64 %r1812, %r1750
  %r1814 = getelementptr i64, ptr %r1741, i64 5
  %r1815 = load i64, ptr %r1814, align 8
  %r1816 = select i1 %r1813, i64 %r1815, i64 0
  %r1817 = getelementptr i64, ptr %r1741, i64 6
  %r1818 = load i64, ptr %r1817, align 8
  %r1819 = icmp eq i64 %r1818, %r1750
  %r1820 = getelementptr i64, ptr %r1741, i64 7
  %r1821 = load i64, ptr %r1820, align 8
  %r1822 = select i1 %r1819, i64 %r1821, i64 0
  %r1823 = getelementptr i64, ptr %r1741, i64 8
  %r1824 = load i64, ptr %r1823, align 8
  %r1825 = icmp eq i64 %r1824, %r1750
  %r1826 = getelementptr i64, ptr %r1741, i64 9
  %r1827 = load i64, ptr %r1826, align 8
  %r1828 = select i1 %r1825, i64 %r1827, i64 0
  %r1829 = getelementptr i64, ptr %r1741, i64 10
  %r1830 = load i64, ptr %r1829, align 8
  %r1831 = icmp eq i64 %r1830, %r1750
  %r1832 = getelementptr i64, ptr %r1741, i64 11
  %r1833 = load i64, ptr %r1832, align 8
  %r1834 = select i1 %r1831, i64 %r1833, i64 0
  %r1835 = or i1 %r1813, %r1819
  %r1836 = select i1 %r1813, i64 %r1816, i64 %r1822
  %r1837 = or i1 %r1825, %r1831
  %r1838 = select i1 %r1825, i64 %r1828, i64 %r1834
  %r1839 = or i1 %r1835, %r1837
  %r1840 = select i1 %r1835, i64 %r1836, i64 %r1838
  %r1841 = and i1 %r1751, %r1839
  br i1 %r1841, label %pic.way.load.297, label %pic.miss.call.290

pic.way.load.297:                                 ; preds = %pic.ways.296
  %r1842 = shl i64 %r1840, 3
  %r1843 = add nuw nsw i64 %r1720, 16
  %r1844 = add i64 %r1843, %r1842
  %r1845 = inttoptr i64 %r1844 to ptr
  %r1846 = load double, ptr %r1845, align 8
  %r1847 = bitcast double %r1846 to i64
  %r1848 = icmp eq i64 %r1847, 9222246136947933200
  br i1 %r1848, label %pic.miss.call.290, label %pic.way.live.298

pic.way.live.298:                                 ; preds = %pic.way.load.297
  br label %pic.merge.291

pget.throw_nullish.299:                           ; preds = %pget.recv_bad.270
  %r1857 = zext i1 %r1855 to i32
  %statepoint_token487 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1857, ptr @test_json_source_token_length_ts_.str.12.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.300:                       ; preds = %pget.recv_bad.270
  %r1858 = load double, ptr @test_json_source_token_length_ts_.str.12.handle, align 8
  %r1859 = bitcast double %r1858 to i64
  %r1860 = and i64 %r1859, 281474976710655
  %statepoint_token488 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1719, i64 %r1860, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.16, ptr addrspace(1) %.151293, ptr addrspace(1) %.101481, ptr addrspace(1) %.101539, ptr addrspace(1) %.51583, ptr addrspace(1) %.01590, ptr addrspace(1) %.161347, ptr addrspace(1) %.151399) ]
  %r1861489 = call double @llvm.experimental.gc.result.f64(token %statepoint_token488)
  %r55.0.base.relocated490 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token488, i32 0, i32 0) ; (%.16, %.16)
  %r48.0.base.relocated491 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token488, i32 1, i32 1) ; (%.151293, %.151293)
  %r1046.0.base.relocated492 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token488, i32 2, i32 2) ; (%.101481, %.101481)
  %r1046.0.relocated493 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token488, i32 2, i32 3) ; (%.101481, %.101539)
  %rs4gc.s34.relocated494 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token488, i32 4, i32 4) ; (%.51583, %.51583)
  %rs4gc.s36.relocated495 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token488, i32 5, i32 5) ; (%.01590, %.01590)
  %r55.0.relocated496 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token488, i32 0, i32 6) ; (%.16, %.161347)
  %r48.0.relocated497 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token488, i32 1, i32 7) ; (%.151293, %.151399)
  br label %pget.recv_merge.272

guarded_add.numeric.301:                          ; preds = %pget.recv_merge.272
  %r1883 = fadd double %r1872, %r1870
  br label %guarded_add.merge.303

guarded_add.dynamic.302:                          ; preds = %pget.recv_merge.272
  %statepoint_token498 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r1872, double %r1870, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.18, ptr addrspace(1) %.171295, ptr addrspace(1) %.121483, ptr addrspace(1) %.121541, ptr addrspace(1) %.71585, ptr addrspace(1) %.181349, ptr addrspace(1) %.171401) ]
  %r1884499 = call double @llvm.experimental.gc.result.f64(token %statepoint_token498)
  %r55.0.base.relocated500 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 0, i32 0) ; (%.18, %.18)
  %r48.0.base.relocated501 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 1, i32 1) ; (%.171295, %.171295)
  %r1046.0.base.relocated502 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 2, i32 2) ; (%.121483, %.121483)
  %r1046.0.relocated503 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 2, i32 3) ; (%.121483, %.121541)
  %rs4gc.s34.relocated504 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 4, i32 4) ; (%.71585, %.71585)
  %r55.0.relocated505 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 0, i32 5) ; (%.18, %.181349)
  %r48.0.relocated506 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 1, i32 6) ; (%.171295, %.171401)
  br label %guarded_add.merge.303

guarded_add.merge.303:                            ; preds = %guarded_add.dynamic.302, %guarded_add.numeric.301
  %.91587 = phi ptr addrspace(1) [ %.71585, %guarded_add.numeric.301 ], [ %rs4gc.s34.relocated504, %guarded_add.dynamic.302 ]
  %.141543 = phi ptr addrspace(1) [ %.121541, %guarded_add.numeric.301 ], [ %r1046.0.relocated503, %guarded_add.dynamic.302 ]
  %.141485 = phi ptr addrspace(1) [ %.121483, %guarded_add.numeric.301 ], [ %r1046.0.base.relocated502, %guarded_add.dynamic.302 ]
  %.191403 = phi ptr addrspace(1) [ %.171401, %guarded_add.numeric.301 ], [ %r48.0.relocated506, %guarded_add.dynamic.302 ]
  %.201351 = phi ptr addrspace(1) [ %.181349, %guarded_add.numeric.301 ], [ %r55.0.relocated505, %guarded_add.dynamic.302 ]
  %.191297 = phi ptr addrspace(1) [ %.171295, %guarded_add.numeric.301 ], [ %r48.0.base.relocated501, %guarded_add.dynamic.302 ]
  %.20 = phi ptr addrspace(1) [ %.18, %guarded_add.numeric.301 ], [ %r55.0.base.relocated500, %guarded_add.dynamic.302 ]
  %r1885 = phi double [ %r1883, %guarded_add.numeric.301 ], [ %r1884499, %guarded_add.dynamic.302 ]
  %rs4gc.b37 = bitcast double %r1885 to i64
  %rs4gc.s37 = inttoptr i64 %rs4gc.b37 to ptr addrspace(1)
  %r1886.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s37 to i64
  %r1886 = call i64 asm "", "=r,0"(i64 %r1886.rs4i) #7
  %r1887 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1888 = icmp ne i32 %r1887, 0
  br i1 %r1888, label %shadow.root.barrier.304, label %shadow.root.barrier.done.305

shadow.root.barrier.304:                          ; preds = %guarded_add.merge.303
  call void @js_write_barrier_root_nanbox(i64 %r1886) #7
  br label %shadow.root.barrier.done.305

shadow.root.barrier.done.305:                     ; preds = %shadow.root.barrier.304, %guarded_add.merge.303
  %r1889.rs4i = ptrtoint ptr addrspace(1) %.91587 to i64
  %r1889.rs4o = call i64 asm "", "=r,0"(i64 %r1889.rs4i) #7
  %r1889 = bitcast i64 %r1889.rs4o to double
  %r1890 = bitcast double %r1889 to i64
  %r1891.rs4i = ptrtoint ptr addrspace(1) %.141543 to i64
  %r1891.rs4o = call i64 asm "", "=r,0"(i64 %r1891.rs4i) #7
  %r1891 = bitcast i64 %r1891.rs4o to double
  %r1892 = bitcast double %r1891 to i64
  %r1893 = and i64 %r1892, 281474976710655
  %r1894 = sub nsw i64 %r1893, 8
  %r1895 = inttoptr i64 %r1894 to ptr
  %r1896 = load i8, ptr %r1895, align 1
  %r1897 = icmp ne i8 %r1896, 1
  %r1898 = sub nsw i64 %r1893, 7
  %r1899 = inttoptr i64 %r1898 to ptr
  %r1900 = load i8, ptr %r1899, align 1
  %r1901 = and i8 %r1900, -128
  %r1902 = icmp ne i8 %r1901, 0
  %r1903 = or i1 %r1897, %r1902
  br i1 %r1902, label %apush.fwd.306, label %apush.elements.307

apush.fwd.306:                                    ; preds = %apush.elements.check.308, %shadow.root.barrier.done.305
  %statepoint_token507 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1893, double %r1889, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s37, ptr addrspace(1) %.20, ptr addrspace(1) %.191297, ptr addrspace(1) %.201351, ptr addrspace(1) %.191403) ]
  %r1930508 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token507)
  %rs4gc.s37.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token507, i32 0, i32 0) ; (%rs4gc.s37, %rs4gc.s37)
  %r55.0.base.relocated509 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token507, i32 1, i32 1) ; (%.20, %.20)
  %r48.0.base.relocated510 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token507, i32 2, i32 2) ; (%.191297, %.191297)
  %r55.0.relocated511 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token507, i32 1, i32 3) ; (%.20, %.201351)
  %r48.0.relocated512 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token507, i32 2, i32 4) ; (%.191297, %.191403)
  %r1931 = or i64 %r1930508, 9222527611924643840
  %r1932 = bitcast i64 %r1931 to double
  %rs4gc.b38 = bitcast double %r1932 to i64
  %rs4gc.s38 = inttoptr i64 %rs4gc.b38 to ptr addrspace(1)
  br label %apush.merge.312

apush.elements.307:                               ; preds = %shadow.root.barrier.done.305
  %r1905 = add nuw nsw i64 %r1893, 8
  %r1906 = inttoptr i64 %r1905 to ptr
  %r1907 = load i64, ptr %r1906, align 8
  %r1908 = icmp ne i64 %r1907, 0
  %r1909 = icmp eq i8 %r1896, 2
  %r1910 = and i1 %r1909, %r1908
  %r1911 = select i1 %r1910, i64 %r1907, i64 %r1893
  %r1912 = inttoptr i64 %r1911 to ptr
  %r1913 = getelementptr i64, ptr %r1912, i64 12
  %r1914 = load i64, ptr %r1913, align 8
  %r1915 = icmp ne i64 %r1914, 0
  %r1916 = and i1 %r1910, %r1915
  %r1917 = select i1 %r1916, i64 %r1914, i64 %r1893
  %r1904 = icmp eq i8 %r1896, 1
  br i1 %r1904, label %apush.nofwd.309, label %apush.elements.check.308

apush.elements.check.308:                         ; preds = %apush.elements.307
  %r1918 = icmp ne i64 %r1917, 0
  %r1919 = sub i64 %r1917, 8
  %r1920 = inttoptr i64 %r1919 to ptr
  %r1921 = load i8, ptr %r1920, align 1
  %r1922 = icmp eq i8 %r1921, 1
  %r1923 = sub i64 %r1917, 7
  %r1924 = inttoptr i64 %r1923 to ptr
  %r1925 = load i8, ptr %r1924, align 1
  %r1926 = and i8 %r1925, -128
  %r1927 = icmp eq i8 %r1926, 0
  %r1928 = and i1 %r1918, %r1922
  %r1929 = and i1 %r1928, %r1927
  br i1 %r1929, label %apush.nofwd.309, label %apush.fwd.306

apush.nofwd.309:                                  ; preds = %apush.elements.check.308, %apush.elements.307
  %r1933 = phi i64 [ %r1893, %apush.elements.307 ], [ %r1917, %apush.elements.check.308 ]
  %r1934 = sub i64 %r1933, 6
  %r1935 = inttoptr i64 %r1934 to ptr
  %r1936 = load i16, ptr %r1935, align 2
  %r1937 = and i16 %r1936, 1031
  %r1938 = icmp eq i16 %r1937, 0
  %r1939 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1940 = icmp eq i8 %r1939, 0
  %r1941 = and i1 %r1938, %r1940
  %r1942 = icmp ult i64 %r1933, 4096
  %r1943 = inttoptr i64 %r1933 to ptr
  %r1944 = select i1 %r1942, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r1943
  %r1945 = load i32, ptr %r1944, align 4
  %r1946 = add i64 %r1933, 4
  %r1947 = inttoptr i64 %r1946 to ptr
  %r1948 = load i32, ptr %r1947, align 4
  %r1949 = icmp ult i32 %r1945, %r1948
  %r1950 = and i1 %r1949, %r1941
  br i1 %r1950, label %apush.inbounds.310, label %apush.realloc.311

apush.inbounds.310:                               ; preds = %apush.nofwd.309
  %r1951 = icmp ult i64 %r1933, 4096
  %r1952 = inttoptr i64 %r1933 to ptr
  %r1953 = select i1 %r1951, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r1952
  %r1954 = load i32, ptr %r1953, align 4
  %r1955 = zext i32 %r1954 to i64
  %r1956 = shl nuw nsw i64 %r1955, 3
  %r1957 = add nuw nsw i64 %r1956, 8
  %r1958 = add i64 %r1933, %r1957
  %r1959 = inttoptr i64 %r1958 to ptr
  store double %r1889, ptr %r1959, align 8
  %r1960 = lshr i64 %r1890, 48
  %r1961 = icmp eq i64 %r1960, 32765
  %r1962 = and i16 %r1936, -1920
  %r1963 = icmp eq i16 %r1962, -24576
  %r1964 = and i1 %r1961, %r1963
  br i1 %r1964, label %apush.pointer_layout.done.314, label %apush.pointer_layout.bookkeeping.313

apush.realloc.311:                                ; preds = %apush.nofwd.309
  %statepoint_token513 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1893, double %r1889, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s37, ptr addrspace(1) %.20, ptr addrspace(1) %.191297, ptr addrspace(1) %.201351, ptr addrspace(1) %.191403) ]
  %r1975514 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token513)
  %rs4gc.s37.relocated515 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token513, i32 0, i32 0) ; (%rs4gc.s37, %rs4gc.s37)
  %r55.0.base.relocated516 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token513, i32 1, i32 1) ; (%.20, %.20)
  %r48.0.base.relocated517 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token513, i32 2, i32 2) ; (%.191297, %.191297)
  %r55.0.relocated518 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token513, i32 1, i32 3) ; (%.20, %.201351)
  %r48.0.relocated519 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token513, i32 2, i32 4) ; (%.191297, %.191403)
  %r1976 = or i64 %r1975514, 9222527611924643840
  %r1977 = bitcast i64 %r1976 to double
  %rs4gc.b39 = bitcast double %r1977 to i64
  %rs4gc.s39 = inttoptr i64 %rs4gc.b39 to ptr addrspace(1)
  br label %apush.merge.312

apush.merge.312:                                  ; preds = %apush.barrier.done.316, %apush.realloc.311, %apush.fwd.306
  %.01594 = phi ptr addrspace(1) [ %rs4gc.s37.relocated, %apush.fwd.306 ], [ %rs4gc.s37, %apush.barrier.done.316 ], [ %rs4gc.s37.relocated515, %apush.realloc.311 ]
  %.201404 = phi ptr addrspace(1) [ %r48.0.relocated512, %apush.fwd.306 ], [ %.191403, %apush.barrier.done.316 ], [ %r48.0.relocated519, %apush.realloc.311 ]
  %.211352 = phi ptr addrspace(1) [ %r55.0.relocated511, %apush.fwd.306 ], [ %.201351, %apush.barrier.done.316 ], [ %r55.0.relocated518, %apush.realloc.311 ]
  %.201298 = phi ptr addrspace(1) [ %r48.0.base.relocated510, %apush.fwd.306 ], [ %.191297, %apush.barrier.done.316 ], [ %r48.0.base.relocated517, %apush.realloc.311 ]
  %.21 = phi ptr addrspace(1) [ %r55.0.base.relocated509, %apush.fwd.306 ], [ %.20, %apush.barrier.done.316 ], [ %r55.0.base.relocated516, %apush.realloc.311 ]
  %r1046.1.base = phi ptr addrspace(1) [ %rs4gc.s38, %apush.fwd.306 ], [ %.141485, %apush.barrier.done.316 ], [ %rs4gc.s39, %apush.realloc.311 ], !is_base_value !0
  %r1046.1 = phi ptr addrspace(1) [ %rs4gc.s38, %apush.fwd.306 ], [ %.141543, %apush.barrier.done.316 ], [ %rs4gc.s39, %apush.realloc.311 ]
  %statepoint_token520 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01594, ptr addrspace(1) %r1046.1.base, ptr addrspace(1) %.21, ptr addrspace(1) %.201298, ptr addrspace(1) %r1046.1, ptr addrspace(1) %.211352, ptr addrspace(1) %.201404) ]
  %r1979521 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token520)
  %rs4gc.s37.relocated522 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token520, i32 0, i32 0) ; (%.01594, %.01594)
  %r1046.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token520, i32 1, i32 1) ; (%r1046.1.base, %r1046.1.base)
  %r55.0.base.relocated523 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token520, i32 2, i32 2) ; (%.21, %.21)
  %r48.0.base.relocated524 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token520, i32 3, i32 3) ; (%.201298, %.201298)
  %r1046.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token520, i32 1, i32 4) ; (%r1046.1.base, %r1046.1)
  %r55.0.relocated525 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token520, i32 2, i32 5) ; (%.21, %.211352)
  %r48.0.relocated526 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token520, i32 3, i32 6) ; (%.201298, %.201404)
  %r1980 = or i64 %r1979521, 9222527611924643840
  %r1981 = bitcast i64 %r1980 to double
  %rs4gc.b40 = bitcast double %r1981 to i64
  %rs4gc.s40 = inttoptr i64 %rs4gc.b40 to ptr addrspace(1)
  %r1982.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s40 to i64
  %r1982 = call i64 asm "", "=r,0"(i64 %r1982.rs4i) #7
  %r1983 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1984 = icmp ne i32 %r1983, 0
  br i1 %r1984, label %shadow.root.barrier.317, label %shadow.root.barrier.done.318

apush.pointer_layout.bookkeeping.313:             ; preds = %apush.inbounds.310
  call void @js_string_addref_if_heap_string(double %r1889) #7
  %r4415.rs4i = ptrtoint ptr addrspace(1) %.91587 to i64
  %r4415.rs4o = call i64 asm "", "=r,0"(i64 %r4415.rs4i) #7
  %r4415 = bitcast i64 %r4415.rs4o to double
  %r4416 = bitcast double %r4415 to i64
  call void @js_gc_note_slot_layout(i64 %r1933, i32 %r1954, i64 %r4416) #7
  %r4413.rs4i = ptrtoint ptr addrspace(1) %.91587 to i64
  %r4413.rs4o = call i64 asm "", "=r,0"(i64 %r4413.rs4i) #7
  %r4413 = bitcast i64 %r4413.rs4o to double
  %r4414 = bitcast double %r4413 to i64
  call void @js_array_note_numeric_write(i64 %r1933, i64 %r4414) #7
  br label %apush.pointer_layout.done.314

apush.pointer_layout.done.314:                    ; preds = %apush.pointer_layout.bookkeeping.313, %apush.inbounds.310
  %r1965 = sub i64 %r1933, 7
  %r1966 = inttoptr i64 %r1965 to ptr
  %r1967 = load i8, ptr %r1966, align 1
  %r1968 = and i8 %r1967, 32
  %r1969 = icmp ne i8 %r1968, 0
  %r1970 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1971 = icmp ne i32 %r1970, 0
  %r1972 = or i1 %r1969, %r1971
  br i1 %r1972, label %apush.barrier.315, label %apush.barrier.done.316

apush.barrier.315:                                ; preds = %apush.pointer_layout.done.314
  %r4411.rs4i = ptrtoint ptr addrspace(1) %.91587 to i64
  %r4411.rs4o = call i64 asm "", "=r,0"(i64 %r4411.rs4i) #7
  %r4411 = bitcast i64 %r4411.rs4o to double
  %r4412 = bitcast double %r4411 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r1933, i64 %r1958, i64 %r4412) #7
  br label %apush.barrier.done.316

apush.barrier.done.316:                           ; preds = %apush.barrier.315, %apush.pointer_layout.done.314
  %r1973 = add i32 %r1954, 1
  %r1974 = inttoptr i64 %r1933 to ptr
  store i32 %r1973, ptr %r1974, align 4
  br label %apush.merge.312

shadow.root.barrier.317:                          ; preds = %apush.merge.312
  call void @js_write_barrier_root_nanbox(i64 %r1982) #7
  br label %shadow.root.barrier.done.318

shadow.root.barrier.done.318:                     ; preds = %shadow.root.barrier.317, %apush.merge.312
  br label %for.cond.319

for.cond.319:                                     ; preds = %for.update.321, %shadow.root.barrier.done.318
  %.01609 = phi ptr addrspace(1) [ %r1046.1.relocated, %shadow.root.barrier.done.318 ], [ %.21611, %for.update.321 ]
  %.01602 = phi ptr addrspace(1) [ %r1046.1.base.relocated, %shadow.root.barrier.done.318 ], [ %.21604, %for.update.321 ]
  %.11595 = phi ptr addrspace(1) [ %rs4gc.s37.relocated522, %shadow.root.barrier.done.318 ], [ %.31597, %for.update.321 ]
  %.211405 = phi ptr addrspace(1) [ %r48.0.relocated526, %shadow.root.barrier.done.318 ], [ %.231407, %for.update.321 ]
  %.221353 = phi ptr addrspace(1) [ %r55.0.relocated525, %shadow.root.barrier.done.318 ], [ %.241355, %for.update.321 ]
  %.211299 = phi ptr addrspace(1) [ %r48.0.base.relocated524, %shadow.root.barrier.done.318 ], [ %.231301, %for.update.321 ]
  %.22 = phi ptr addrspace(1) [ %r55.0.base.relocated523, %shadow.root.barrier.done.318 ], [ %.24, %for.update.321 ]
  %r1985.0 = phi i32 [ 0, %shadow.root.barrier.done.318 ], [ %r2098, %for.update.321 ]
  %r1978.0.base = phi ptr addrspace(1) [ %rs4gc.s40, %shadow.root.barrier.done.318 ], [ %.01616, %for.update.321 ], !is_base_value !0
  %r1978.0 = phi ptr addrspace(1) [ %rs4gc.s40, %shadow.root.barrier.done.318 ], [ %.01617, %for.update.321 ]
  %r1987 = sitofp i32 %r1985.0 to double
  %r1988 = fcmp olt double %r1987, 4.800000e+01
  %r1989 = select i1 %r1988, i64 9222246136947933188, i64 9222246136947933187
  %r1990 = bitcast i64 %r1989 to double
  %r1991 = icmp eq i64 %r1989, 9222246136947933188
  br i1 %r1991, label %for.body.320, label %for.exit.322

for.body.320:                                     ; preds = %for.cond.319
  %r1992 = load double, ptr @test_json_source_token_length_ts_.str.3.handle, align 8
  %r1994 = sitofp i32 %r1985.0 to double
  %r1995 = load double, ptr @test_json_source_token_length_ts_.str.13.handle, align 8
  %r1997 = getelementptr double, ptr %r1996, i64 0
  store double %r1992, ptr %r1997, align 8
  %r1998 = getelementptr double, ptr %r1996, i64 1
  store double %r1994, ptr %r1998, align 8
  %r1999 = getelementptr double, ptr %r1996, i64 2
  store double %r1995, ptr %r1999, align 8
  %r2000 = ptrtoint ptr %r1996 to i64
  %statepoint_token527 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r2000, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11595, ptr addrspace(1) %.01602, ptr addrspace(1) %.22, ptr addrspace(1) %.211299, ptr addrspace(1) %r1978.0.base, ptr addrspace(1) %r1978.0, ptr addrspace(1) %.01609, ptr addrspace(1) %.221353, ptr addrspace(1) %.211405) ]
  %r2001528 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token527)
  %rs4gc.s37.relocated529 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token527, i32 0, i32 0) ; (%.11595, %.11595)
  %r1046.1.base.relocated530 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token527, i32 1, i32 1) ; (%.01602, %.01602)
  %r55.0.base.relocated531 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token527, i32 2, i32 2) ; (%.22, %.22)
  %r48.0.base.relocated532 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token527, i32 3, i32 3) ; (%.211299, %.211299)
  %r1978.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token527, i32 4, i32 4) ; (%r1978.0.base, %r1978.0.base)
  %r1978.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token527, i32 4, i32 5) ; (%r1978.0.base, %r1978.0)
  %r1046.1.relocated533 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token527, i32 1, i32 6) ; (%.01602, %.01609)
  %r55.0.relocated534 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token527, i32 2, i32 7) ; (%.22, %.221353)
  %r48.0.relocated535 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token527, i32 3, i32 8) ; (%.211299, %.211405)
  %r2002 = or i64 %r2001528, 9223090561878065152
  %r2003 = bitcast i64 %r2002 to double
  %statepoint_token536 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r2003, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s37.relocated529, ptr addrspace(1) %r1046.1.base.relocated530, ptr addrspace(1) %r55.0.base.relocated531, ptr addrspace(1) %r48.0.base.relocated532, ptr addrspace(1) %r1978.0.base.relocated, ptr addrspace(1) %r1978.0.relocated, ptr addrspace(1) %r1046.1.relocated533, ptr addrspace(1) %r55.0.relocated534, ptr addrspace(1) %r48.0.relocated535) ]
  %r2004537 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token536)
  %rs4gc.s37.relocated538 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token536, i32 0, i32 0) ; (%rs4gc.s37.relocated529, %rs4gc.s37.relocated529)
  %r1046.1.base.relocated539 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token536, i32 1, i32 1) ; (%r1046.1.base.relocated530, %r1046.1.base.relocated530)
  %r55.0.base.relocated540 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token536, i32 2, i32 2) ; (%r55.0.base.relocated531, %r55.0.base.relocated531)
  %r48.0.base.relocated541 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token536, i32 3, i32 3) ; (%r48.0.base.relocated532, %r48.0.base.relocated532)
  %r1978.0.base.relocated542 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token536, i32 4, i32 4) ; (%r1978.0.base.relocated, %r1978.0.base.relocated)
  %r1978.0.relocated543 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token536, i32 4, i32 5) ; (%r1978.0.base.relocated, %r1978.0.relocated)
  %r1046.1.relocated544 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token536, i32 1, i32 6) ; (%r1046.1.base.relocated530, %r1046.1.relocated533)
  %r55.0.relocated545 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token536, i32 2, i32 7) ; (%r55.0.base.relocated531, %r55.0.relocated534)
  %r48.0.relocated546 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token536, i32 3, i32 8) ; (%r48.0.base.relocated532, %r48.0.relocated535)
  %statepoint_token547 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r2004537, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s37.relocated538, ptr addrspace(1) %r1046.1.base.relocated539, ptr addrspace(1) %r55.0.base.relocated540, ptr addrspace(1) %r48.0.base.relocated541, ptr addrspace(1) %r1978.0.base.relocated542, ptr addrspace(1) %r1978.0.relocated543, ptr addrspace(1) %r1046.1.relocated544, ptr addrspace(1) %r55.0.relocated545, ptr addrspace(1) %r48.0.relocated546) ]
  %r2005548 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token547)
  %rs4gc.s37.relocated549 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token547, i32 0, i32 0) ; (%rs4gc.s37.relocated538, %rs4gc.s37.relocated538)
  %r1046.1.base.relocated550 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token547, i32 1, i32 1) ; (%r1046.1.base.relocated539, %r1046.1.base.relocated539)
  %r55.0.base.relocated551 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token547, i32 2, i32 2) ; (%r55.0.base.relocated540, %r55.0.base.relocated540)
  %r48.0.base.relocated552 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token547, i32 3, i32 3) ; (%r48.0.base.relocated541, %r48.0.base.relocated541)
  %r1978.0.base.relocated553 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token547, i32 4, i32 4) ; (%r1978.0.base.relocated542, %r1978.0.base.relocated542)
  %r1978.0.relocated554 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token547, i32 4, i32 5) ; (%r1978.0.base.relocated542, %r1978.0.relocated543)
  %r1046.1.relocated555 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token547, i32 1, i32 6) ; (%r1046.1.base.relocated539, %r1046.1.relocated544)
  %r55.0.relocated556 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token547, i32 2, i32 7) ; (%r55.0.base.relocated540, %r55.0.relocated545)
  %r48.0.relocated557 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token547, i32 3, i32 8) ; (%r48.0.base.relocated541, %r48.0.relocated546)
  %r2006 = bitcast i64 %r2005548 to double
  %r2007 = bitcast i64 %r2005548 to double
  %r2008.rs4i = ptrtoint ptr addrspace(1) %r1978.0.relocated554 to i64
  %r2008.rs4o = call i64 asm "", "=r,0"(i64 %r2008.rs4i) #7
  %r2008 = bitcast i64 %r2008.rs4o to double
  %r2009 = bitcast double %r2008 to i64
  %r2010 = and i64 %r2009, 281474976710655
  %r2011 = sub nsw i64 %r2010, 8
  %r2012 = inttoptr i64 %r2011 to ptr
  %r2013 = load i8, ptr %r2012, align 1
  %r2014 = icmp ne i8 %r2013, 1
  %r2015 = sub nsw i64 %r2010, 7
  %r2016 = inttoptr i64 %r2015 to ptr
  %r2017 = load i8, ptr %r2016, align 1
  %r2018 = and i8 %r2017, -128
  %r2019 = icmp ne i8 %r2018, 0
  %r2020 = or i1 %r2014, %r2019
  br i1 %r2019, label %apush.fwd.323, label %apush.elements.324

for.update.321:                                   ; preds = %gcpoll.done.335
  %r2098 = add i32 %r1985.0, 1
  %r2099 = sitofp i32 %r1985.0 to double
  %r2100 = sitofp i32 %r2098 to double
  br label %for.cond.319

for.exit.322:                                     ; preds = %for.cond.319
  %r2101.rs4i = ptrtoint ptr addrspace(1) %r1978.0 to i64
  %r2101.rs4o = call i64 asm "", "=r,0"(i64 %r2101.rs4i) #7
  %r2101 = bitcast i64 %r2101.rs4o to double
  %r2102 = bitcast double %r2101 to i64
  %r2103 = and i64 %r2102, 281474976710655
  %r2104 = lshr i64 %r2102, 48
  %r2105 = icmp eq i64 %r2104, 32765
  %r2106 = icmp ugt i64 %r2103, 1048575
  %r2107 = and i1 %r2105, %r2106
  br i1 %r2107, label %arr.guard.deref.340, label %arr.fallback.337

apush.fwd.323:                                    ; preds = %apush.elements.check.325, %for.body.320
  %statepoint_token558 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r2010, double %r2007, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s37.relocated549, ptr addrspace(1) %r1046.1.base.relocated550, ptr addrspace(1) %r55.0.base.relocated551, ptr addrspace(1) %r48.0.base.relocated552, ptr addrspace(1) %r1046.1.relocated555, ptr addrspace(1) %r55.0.relocated556, ptr addrspace(1) %r48.0.relocated557) ]
  %r2047559 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token558)
  %rs4gc.s37.relocated560 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token558, i32 0, i32 0) ; (%rs4gc.s37.relocated549, %rs4gc.s37.relocated549)
  %r1046.1.base.relocated561 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token558, i32 1, i32 1) ; (%r1046.1.base.relocated550, %r1046.1.base.relocated550)
  %r55.0.base.relocated562 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token558, i32 2, i32 2) ; (%r55.0.base.relocated551, %r55.0.base.relocated551)
  %r48.0.base.relocated563 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token558, i32 3, i32 3) ; (%r48.0.base.relocated552, %r48.0.base.relocated552)
  %r1046.1.relocated564 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token558, i32 1, i32 4) ; (%r1046.1.base.relocated550, %r1046.1.relocated555)
  %r55.0.relocated565 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token558, i32 2, i32 5) ; (%r55.0.base.relocated551, %r55.0.relocated556)
  %r48.0.relocated566 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token558, i32 3, i32 6) ; (%r48.0.base.relocated552, %r48.0.relocated557)
  %r2048 = or i64 %r2047559, 9222527611924643840
  %r2049 = bitcast i64 %r2048 to double
  %rs4gc.b41 = bitcast double %r2049 to i64
  %rs4gc.s41 = inttoptr i64 %rs4gc.b41 to ptr addrspace(1)
  br label %apush.merge.329

apush.elements.324:                               ; preds = %for.body.320
  %r2022 = add nuw nsw i64 %r2010, 8
  %r2023 = inttoptr i64 %r2022 to ptr
  %r2024 = load i64, ptr %r2023, align 8
  %r2025 = icmp ne i64 %r2024, 0
  %r2026 = icmp eq i8 %r2013, 2
  %r2027 = and i1 %r2026, %r2025
  %r2028 = select i1 %r2027, i64 %r2024, i64 %r2010
  %r2029 = inttoptr i64 %r2028 to ptr
  %r2030 = getelementptr i64, ptr %r2029, i64 12
  %r2031 = load i64, ptr %r2030, align 8
  %r2032 = icmp ne i64 %r2031, 0
  %r2033 = and i1 %r2027, %r2032
  %r2034 = select i1 %r2033, i64 %r2031, i64 %r2010
  %r2021 = icmp eq i8 %r2013, 1
  br i1 %r2021, label %apush.nofwd.326, label %apush.elements.check.325

apush.elements.check.325:                         ; preds = %apush.elements.324
  %r2035 = icmp ne i64 %r2034, 0
  %r2036 = sub i64 %r2034, 8
  %r2037 = inttoptr i64 %r2036 to ptr
  %r2038 = load i8, ptr %r2037, align 1
  %r2039 = icmp eq i8 %r2038, 1
  %r2040 = sub i64 %r2034, 7
  %r2041 = inttoptr i64 %r2040 to ptr
  %r2042 = load i8, ptr %r2041, align 1
  %r2043 = and i8 %r2042, -128
  %r2044 = icmp eq i8 %r2043, 0
  %r2045 = and i1 %r2035, %r2039
  %r2046 = and i1 %r2045, %r2044
  br i1 %r2046, label %apush.nofwd.326, label %apush.fwd.323

apush.nofwd.326:                                  ; preds = %apush.elements.check.325, %apush.elements.324
  %r2050 = phi i64 [ %r2010, %apush.elements.324 ], [ %r2034, %apush.elements.check.325 ]
  %r2051 = sub i64 %r2050, 6
  %r2052 = inttoptr i64 %r2051 to ptr
  %r2053 = load i16, ptr %r2052, align 2
  %r2054 = and i16 %r2053, 1031
  %r2055 = icmp eq i16 %r2054, 0
  %r2056 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2057 = icmp eq i8 %r2056, 0
  %r2058 = and i1 %r2055, %r2057
  %r2059 = icmp ult i64 %r2050, 4096
  %r2060 = inttoptr i64 %r2050 to ptr
  %r2061 = select i1 %r2059, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r2060
  %r2062 = load i32, ptr %r2061, align 4
  %r2063 = add i64 %r2050, 4
  %r2064 = inttoptr i64 %r2063 to ptr
  %r2065 = load i32, ptr %r2064, align 4
  %r2066 = icmp ult i32 %r2062, %r2065
  %r2067 = and i1 %r2066, %r2058
  br i1 %r2067, label %apush.inbounds.327, label %apush.realloc.328

apush.inbounds.327:                               ; preds = %apush.nofwd.326
  %r2068 = icmp ult i64 %r2050, 4096
  %r2069 = inttoptr i64 %r2050 to ptr
  %r2070 = select i1 %r2068, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r2069
  %r2071 = load i32, ptr %r2070, align 4
  %r2072 = zext i32 %r2071 to i64
  %r2073 = shl nuw nsw i64 %r2072, 3
  %r2074 = add nuw nsw i64 %r2073, 8
  %r2075 = add i64 %r2050, %r2074
  %r2076 = inttoptr i64 %r2075 to ptr
  store double %r2007, ptr %r2076, align 8
  %r2077 = lshr i64 %r2005548, 48
  %r2078 = icmp eq i64 %r2077, 32765
  %r2079 = and i16 %r2053, -1920
  %r2080 = icmp eq i16 %r2079, -24576
  %r2081 = and i1 %r2078, %r2080
  br i1 %r2081, label %apush.pointer_layout.done.331, label %apush.pointer_layout.bookkeeping.330

apush.realloc.328:                                ; preds = %apush.nofwd.326
  %statepoint_token567 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r2010, double %r2007, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s37.relocated549, ptr addrspace(1) %r1046.1.base.relocated550, ptr addrspace(1) %r55.0.base.relocated551, ptr addrspace(1) %r48.0.base.relocated552, ptr addrspace(1) %r1046.1.relocated555, ptr addrspace(1) %r55.0.relocated556, ptr addrspace(1) %r48.0.relocated557) ]
  %r2092568 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token567)
  %rs4gc.s37.relocated569 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token567, i32 0, i32 0) ; (%rs4gc.s37.relocated549, %rs4gc.s37.relocated549)
  %r1046.1.base.relocated570 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token567, i32 1, i32 1) ; (%r1046.1.base.relocated550, %r1046.1.base.relocated550)
  %r55.0.base.relocated571 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token567, i32 2, i32 2) ; (%r55.0.base.relocated551, %r55.0.base.relocated551)
  %r48.0.base.relocated572 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token567, i32 3, i32 3) ; (%r48.0.base.relocated552, %r48.0.base.relocated552)
  %r1046.1.relocated573 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token567, i32 1, i32 4) ; (%r1046.1.base.relocated550, %r1046.1.relocated555)
  %r55.0.relocated574 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token567, i32 2, i32 5) ; (%r55.0.base.relocated551, %r55.0.relocated556)
  %r48.0.relocated575 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token567, i32 3, i32 6) ; (%r48.0.base.relocated552, %r48.0.relocated557)
  %r2093 = or i64 %r2092568, 9222527611924643840
  %r2094 = bitcast i64 %r2093 to double
  %rs4gc.b42 = bitcast double %r2094 to i64
  %rs4gc.s42 = inttoptr i64 %rs4gc.b42 to ptr addrspace(1)
  br label %apush.merge.329

apush.merge.329:                                  ; preds = %apush.barrier.done.333, %apush.realloc.328, %apush.fwd.323
  %.11610 = phi ptr addrspace(1) [ %r1046.1.relocated564, %apush.fwd.323 ], [ %r1046.1.relocated555, %apush.barrier.done.333 ], [ %r1046.1.relocated573, %apush.realloc.328 ]
  %.11603 = phi ptr addrspace(1) [ %r1046.1.base.relocated561, %apush.fwd.323 ], [ %r1046.1.base.relocated550, %apush.barrier.done.333 ], [ %r1046.1.base.relocated570, %apush.realloc.328 ]
  %.21596 = phi ptr addrspace(1) [ %rs4gc.s37.relocated560, %apush.fwd.323 ], [ %rs4gc.s37.relocated549, %apush.barrier.done.333 ], [ %rs4gc.s37.relocated569, %apush.realloc.328 ]
  %.221406 = phi ptr addrspace(1) [ %r48.0.relocated566, %apush.fwd.323 ], [ %r48.0.relocated557, %apush.barrier.done.333 ], [ %r48.0.relocated575, %apush.realloc.328 ]
  %.231354 = phi ptr addrspace(1) [ %r55.0.relocated565, %apush.fwd.323 ], [ %r55.0.relocated556, %apush.barrier.done.333 ], [ %r55.0.relocated574, %apush.realloc.328 ]
  %.221300 = phi ptr addrspace(1) [ %r48.0.base.relocated563, %apush.fwd.323 ], [ %r48.0.base.relocated552, %apush.barrier.done.333 ], [ %r48.0.base.relocated572, %apush.realloc.328 ]
  %.23 = phi ptr addrspace(1) [ %r55.0.base.relocated562, %apush.fwd.323 ], [ %r55.0.base.relocated551, %apush.barrier.done.333 ], [ %r55.0.base.relocated571, %apush.realloc.328 ]
  %r1978.1.base = phi ptr addrspace(1) [ %rs4gc.s41, %apush.fwd.323 ], [ %r1978.0.base.relocated553, %apush.barrier.done.333 ], [ %rs4gc.s42, %apush.realloc.328 ], !is_base_value !0
  %r1978.1 = phi ptr addrspace(1) [ %rs4gc.s41, %apush.fwd.323 ], [ %r1978.0.relocated554, %apush.barrier.done.333 ], [ %rs4gc.s42, %apush.realloc.328 ]
  %r2095 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r2096 = icmp ne i32 %r2095, 0
  br i1 %r2096, label %gcpoll.334, label %gcpoll.done.335

apush.pointer_layout.bookkeeping.330:             ; preds = %apush.inbounds.327
  call void @js_string_addref_if_heap_string(double %r2007) #7
  call void @js_gc_note_slot_layout(i64 %r2050, i32 %r2071, i64 %r2005548) #7
  call void @js_array_note_numeric_write(i64 %r2050, i64 %r2005548) #7
  br label %apush.pointer_layout.done.331

apush.pointer_layout.done.331:                    ; preds = %apush.pointer_layout.bookkeeping.330, %apush.inbounds.327
  %r2082 = sub i64 %r2050, 7
  %r2083 = inttoptr i64 %r2082 to ptr
  %r2084 = load i8, ptr %r2083, align 1
  %r2085 = and i8 %r2084, 32
  %r2086 = icmp ne i8 %r2085, 0
  %r2087 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2088 = icmp ne i32 %r2087, 0
  %r2089 = or i1 %r2086, %r2088
  br i1 %r2089, label %apush.barrier.332, label %apush.barrier.done.333

apush.barrier.332:                                ; preds = %apush.pointer_layout.done.331
  call void @js_write_barrier_slot_validated_parent(i64 %r2050, i64 %r2075, i64 %r2005548) #7
  br label %apush.barrier.done.333

apush.barrier.done.333:                           ; preds = %apush.barrier.332, %apush.pointer_layout.done.331
  %r2090 = add i32 %r2071, 1
  %r2091 = inttoptr i64 %r2050 to ptr
  store i32 %r2090, ptr %r2091, align 4
  br label %apush.merge.329

gcpoll.334:                                       ; preds = %apush.merge.329
  %statepoint_token576 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1978.1.base, ptr addrspace(1) %r1978.1, ptr addrspace(1) %.21596, ptr addrspace(1) %.11603, ptr addrspace(1) %.23, ptr addrspace(1) %.221300, ptr addrspace(1) %.11610, ptr addrspace(1) %.231354, ptr addrspace(1) %.221406) ]
  %r1978.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token576, i32 0, i32 0) ; (%r1978.1.base, %r1978.1.base)
  %r1978.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token576, i32 0, i32 1) ; (%r1978.1.base, %r1978.1)
  %rs4gc.s37.relocated577 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token576, i32 2, i32 2) ; (%.21596, %.21596)
  %r1046.1.base.relocated578 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token576, i32 3, i32 3) ; (%.11603, %.11603)
  %r55.0.base.relocated579 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token576, i32 4, i32 4) ; (%.23, %.23)
  %r48.0.base.relocated580 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token576, i32 5, i32 5) ; (%.221300, %.221300)
  %r1046.1.relocated581 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token576, i32 3, i32 6) ; (%.11603, %.11610)
  %r55.0.relocated582 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token576, i32 4, i32 7) ; (%.23, %.231354)
  %r48.0.relocated583 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token576, i32 5, i32 8) ; (%.221300, %.221406)
  br label %gcpoll.done.335

gcpoll.done.335:                                  ; preds = %gcpoll.334, %apush.merge.329
  %.01617 = phi ptr addrspace(1) [ %r1978.1.relocated, %gcpoll.334 ], [ %r1978.1, %apush.merge.329 ]
  %.01616 = phi ptr addrspace(1) [ %r1978.1.base.relocated, %gcpoll.334 ], [ %r1978.1.base, %apush.merge.329 ]
  %.21611 = phi ptr addrspace(1) [ %r1046.1.relocated581, %gcpoll.334 ], [ %.11610, %apush.merge.329 ]
  %.21604 = phi ptr addrspace(1) [ %r1046.1.base.relocated578, %gcpoll.334 ], [ %.11603, %apush.merge.329 ]
  %.31597 = phi ptr addrspace(1) [ %rs4gc.s37.relocated577, %gcpoll.334 ], [ %.21596, %apush.merge.329 ]
  %.231407 = phi ptr addrspace(1) [ %r48.0.relocated583, %gcpoll.334 ], [ %.221406, %apush.merge.329 ]
  %.241355 = phi ptr addrspace(1) [ %r55.0.relocated582, %gcpoll.334 ], [ %.231354, %apush.merge.329 ]
  %.231301 = phi ptr addrspace(1) [ %r48.0.base.relocated580, %gcpoll.334 ], [ %.221300, %apush.merge.329 ]
  %.24 = phi ptr addrspace(1) [ %r55.0.base.relocated579, %gcpoll.334 ], [ %.23, %apush.merge.329 ]
  br label %for.update.321

arr.fast.336:                                     ; preds = %arr.guard.range.342
  %r2166 = add i64 %r2122, 384
  %r2167 = inttoptr i64 %r2166 to ptr
  %r2168 = load double, ptr %r2167, align 8
  %r2169 = bitcast double %r2168 to i64
  %r2170 = icmp eq i64 %r2169, 9222246136947933200
  %r2172 = select i1 %r2170, double 0x7FFC000000000001, double %r2168
  br label %arr.merge.339

arr.fallback.337:                                 ; preds = %arr.guard.live.341, %arr.guard.deref.340, %for.exit.322
  %statepoint_token584 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 5587713372188573707, double %r2101, double 4.700000e+01, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11595, ptr addrspace(1) %.01602, ptr addrspace(1) %.22, ptr addrspace(1) %.211299, ptr addrspace(1) %.01609, ptr addrspace(1) %.221353, ptr addrspace(1) %.211405) ]
  %r2162585 = call double @llvm.experimental.gc.result.f64(token %statepoint_token584)
  %rs4gc.s37.relocated586 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token584, i32 0, i32 0) ; (%.11595, %.11595)
  %r1046.1.base.relocated587 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token584, i32 1, i32 1) ; (%.01602, %.01602)
  %r55.0.base.relocated588 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token584, i32 2, i32 2) ; (%.22, %.22)
  %r48.0.base.relocated589 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token584, i32 3, i32 3) ; (%.211299, %.211299)
  %r1046.1.relocated590 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token584, i32 1, i32 4) ; (%.01602, %.01609)
  %r55.0.relocated591 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token584, i32 2, i32 5) ; (%.22, %.221353)
  %r48.0.relocated592 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token584, i32 3, i32 6) ; (%.211299, %.211405)
  br label %arr.merge.339

arr.guard.oob.338:                                ; preds = %arr.guard.range.342
  br label %arr.merge.339

arr.merge.339:                                    ; preds = %arr.guard.oob.338, %arr.fallback.337, %arr.fast.336
  %.31612 = phi ptr addrspace(1) [ %.01609, %arr.fast.336 ], [ %.01609, %arr.guard.oob.338 ], [ %r1046.1.relocated590, %arr.fallback.337 ]
  %.31605 = phi ptr addrspace(1) [ %.01602, %arr.fast.336 ], [ %.01602, %arr.guard.oob.338 ], [ %r1046.1.base.relocated587, %arr.fallback.337 ]
  %.41598 = phi ptr addrspace(1) [ %.11595, %arr.fast.336 ], [ %.11595, %arr.guard.oob.338 ], [ %rs4gc.s37.relocated586, %arr.fallback.337 ]
  %.241408 = phi ptr addrspace(1) [ %.211405, %arr.fast.336 ], [ %.211405, %arr.guard.oob.338 ], [ %r48.0.relocated592, %arr.fallback.337 ]
  %.251356 = phi ptr addrspace(1) [ %.221353, %arr.fast.336 ], [ %.221353, %arr.guard.oob.338 ], [ %r55.0.relocated591, %arr.fallback.337 ]
  %.241302 = phi ptr addrspace(1) [ %.211299, %arr.fast.336 ], [ %.211299, %arr.guard.oob.338 ], [ %r48.0.base.relocated589, %arr.fallback.337 ]
  %.25 = phi ptr addrspace(1) [ %.22, %arr.fast.336 ], [ %.22, %arr.guard.oob.338 ], [ %r55.0.base.relocated588, %arr.fallback.337 ]
  %r2173 = phi double [ %r2172, %arr.fast.336 ], [ %r2162585, %arr.fallback.337 ], [ 0x7FFC000000000001, %arr.guard.oob.338 ]
  %r2174 = bitcast double %r2173 to i64
  %r2175 = and i64 %r2174, 281474976710655
  %r2176 = lshr i64 %r2174, 48
  %r2177 = and i64 %r2176, 65533
  %r2178 = icmp eq i64 %r2177, 32765
  br i1 %r2178, label %pget.recv_ok.344, label %pget.recv_other.348

arr.guard.deref.340:                              ; preds = %for.exit.322
  %r2108 = bitcast double %r2101 to i64
  %r2109 = and i64 %r2108, 281474976710655
  %r2110 = sub nsw i64 %r2109, 8
  %r2111 = inttoptr i64 %r2110 to ptr
  %r2112 = load i8, ptr %r2111, align 1
  %r2113 = icmp eq i8 %r2112, 1
  %r2114 = sub nsw i64 %r2109, 7
  %r2115 = inttoptr i64 %r2114 to ptr
  %r2116 = load i8, ptr %r2115, align 1
  %r2117 = and i8 %r2116, -128
  %r2118 = icmp ne i8 %r2117, 0
  %r2119 = inttoptr i64 %r2109 to ptr
  %r2120 = load i64, ptr %r2119, align 8
  %r2121 = and i1 %r2113, %r2118
  %r2122 = select i1 %r2121, i64 %r2120, i64 %r2109
  %r2123 = lshr i64 %r2122, 48
  %r2124 = icmp eq i64 %r2123, 0
  %r2125 = icmp ugt i64 %r2122, 1048575
  %r2126 = and i1 %r2124, %r2125
  br i1 %r2126, label %arr.guard.live.341, label %arr.fallback.337

arr.guard.live.341:                               ; preds = %arr.guard.deref.340
  %r2127 = sub nuw i64 %r2122, 8
  %r2128 = inttoptr i64 %r2127 to ptr
  %r2129 = load i8, ptr %r2128, align 1
  %r2130 = icmp eq i8 %r2129, 1
  %r2131 = sub nuw i64 %r2122, 7
  %r2132 = inttoptr i64 %r2131 to ptr
  %r2133 = load i8, ptr %r2132, align 1
  %r2134 = and i8 %r2133, -128
  %r2135 = icmp eq i8 %r2134, 0
  %r2136 = sub nuw i64 %r2122, 6
  %r2137 = inttoptr i64 %r2136 to ptr
  %r2138 = load i16, ptr %r2137, align 2
  %r2139 = and i16 %r2138, 1024
  %r2140 = icmp eq i16 %r2139, 0
  %r2141 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2142 = icmp eq i8 %r2141, 0
  %r2143 = inttoptr i64 %r2122 to ptr
  %r2144 = load i32, ptr %r2143, align 4
  %r2145 = getelementptr i8, ptr %r2143, i64 4
  %r2146 = load i32, ptr %r2145, align 4
  %r2150 = icmp ule i32 %r2144, 16000000
  %r2151 = icmp ule i32 %r2146, 16000000
  %r2152 = icmp ule i32 %r2144, %r2146
  %r2153 = and i1 %r2130, %r2135
  %r2154 = and i1 %r2153, %r2140
  %r2155 = and i1 %r2154, %r2142
  %r2157 = and i1 %r2155, %r2150
  %r2158 = and i1 %r2157, %r2151
  %r2159 = and i1 %r2158, %r2152
  br i1 %r2159, label %arr.guard.range.342, label %arr.fallback.337

arr.guard.range.342:                              ; preds = %arr.guard.live.341
  %r2149 = icmp ult i32 47, %r2144
  br i1 %r2149, label %arr.fast.336, label %arr.guard.oob.338

pget.recv_sso.343:                                ; preds = %pget.recv_other.348
  %r2316 = load double, ptr @test_json_source_token_length_ts_.str.14.handle, align 8
  %r2317 = bitcast double %r2316 to i64
  %r2318 = and i64 %r2317, 281474976710655
  %statepoint_token593 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2174, i64 %r2318, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.41598, ptr addrspace(1) %.31605, ptr addrspace(1) %.25, ptr addrspace(1) %.241302, ptr addrspace(1) %.31612, ptr addrspace(1) %.251356, ptr addrspace(1) %.241408) ]
  %r2319594 = call double @llvm.experimental.gc.result.f64(token %statepoint_token593)
  %rs4gc.s37.relocated595 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token593, i32 0, i32 0) ; (%.41598, %.41598)
  %r1046.1.base.relocated596 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token593, i32 1, i32 1) ; (%.31605, %.31605)
  %r55.0.base.relocated597 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token593, i32 2, i32 2) ; (%.25, %.25)
  %r48.0.base.relocated598 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token593, i32 3, i32 3) ; (%.241302, %.241302)
  %r1046.1.relocated599 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token593, i32 1, i32 4) ; (%.31605, %.31612)
  %r55.0.relocated600 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token593, i32 2, i32 5) ; (%.25, %.251356)
  %r48.0.relocated601 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token593, i32 3, i32 6) ; (%.241302, %.241408)
  br label %pget.recv_merge.347

pget.recv_ok.344:                                 ; preds = %arr.merge.339
  %r2185 = icmp ugt i64 %r2175, 1048575
  br i1 %r2185, label %pic.recv_hdr.365, label %pic.miss.cold.362

pget.recv_bad.345:                                ; preds = %pget.check_class_ref.349
  %r2308 = icmp eq i64 %r2174, 9222246136947933185
  %r2309 = icmp eq i64 %r2174, 9222246136947933186
  %r2310 = or i1 %r2308, %r2309
  br i1 %r2310, label %pget.throw_nullish.372, label %pget.recv_undef_return.373

pget.recv_class_ref.346:                          ; preds = %pget.check_class_ref.349
  %r2181 = load double, ptr @test_json_source_token_length_ts_.str.14.handle, align 8
  %r2182 = bitcast double %r2181 to i64
  %r2183 = and i64 %r2182, 281474976710655
  %statepoint_token602 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 5587713372188573708, i64 %r2174, i64 %r2183, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.41598, ptr addrspace(1) %.31605, ptr addrspace(1) %.25, ptr addrspace(1) %.241302, ptr addrspace(1) %.31612, ptr addrspace(1) %.251356, ptr addrspace(1) %.241408) ]
  %r2184603 = call double @llvm.experimental.gc.result.f64(token %statepoint_token602)
  %rs4gc.s37.relocated604 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token602, i32 0, i32 0) ; (%.41598, %.41598)
  %r1046.1.base.relocated605 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token602, i32 1, i32 1) ; (%.31605, %.31605)
  %r55.0.base.relocated606 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token602, i32 2, i32 2) ; (%.25, %.25)
  %r48.0.base.relocated607 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token602, i32 3, i32 3) ; (%.241302, %.241302)
  %r1046.1.relocated608 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token602, i32 1, i32 4) ; (%.31605, %.31612)
  %r55.0.relocated609 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token602, i32 2, i32 5) ; (%.25, %.251356)
  %r48.0.relocated610 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token602, i32 3, i32 6) ; (%.241302, %.241408)
  br label %pget.recv_merge.347

pget.recv_merge.347:                              ; preds = %pget.recv_undef_return.373, %pic.merge.364, %pget.recv_class_ref.346, %pget.recv_sso.343
  %.41613 = phi ptr addrspace(1) [ %.51614, %pic.merge.364 ], [ %r1046.1.relocated599, %pget.recv_sso.343 ], [ %r1046.1.relocated608, %pget.recv_class_ref.346 ], [ %r1046.1.relocated636, %pget.recv_undef_return.373 ]
  %.41606 = phi ptr addrspace(1) [ %.51607, %pic.merge.364 ], [ %r1046.1.base.relocated596, %pget.recv_sso.343 ], [ %r1046.1.base.relocated605, %pget.recv_class_ref.346 ], [ %r1046.1.base.relocated633, %pget.recv_undef_return.373 ]
  %.51599 = phi ptr addrspace(1) [ %.61600, %pic.merge.364 ], [ %rs4gc.s37.relocated595, %pget.recv_sso.343 ], [ %rs4gc.s37.relocated604, %pget.recv_class_ref.346 ], [ %rs4gc.s37.relocated632, %pget.recv_undef_return.373 ]
  %.251409 = phi ptr addrspace(1) [ %.261410, %pic.merge.364 ], [ %r48.0.relocated601, %pget.recv_sso.343 ], [ %r48.0.relocated610, %pget.recv_class_ref.346 ], [ %r48.0.relocated638, %pget.recv_undef_return.373 ]
  %.261357 = phi ptr addrspace(1) [ %.271358, %pic.merge.364 ], [ %r55.0.relocated600, %pget.recv_sso.343 ], [ %r55.0.relocated609, %pget.recv_class_ref.346 ], [ %r55.0.relocated637, %pget.recv_undef_return.373 ]
  %.251303 = phi ptr addrspace(1) [ %.261304, %pic.merge.364 ], [ %r48.0.base.relocated598, %pget.recv_sso.343 ], [ %r48.0.base.relocated607, %pget.recv_class_ref.346 ], [ %r48.0.base.relocated635, %pget.recv_undef_return.373 ]
  %.26 = phi ptr addrspace(1) [ %.27, %pic.merge.364 ], [ %r55.0.base.relocated597, %pget.recv_sso.343 ], [ %r55.0.base.relocated606, %pget.recv_class_ref.346 ], [ %r55.0.base.relocated634, %pget.recv_undef_return.373 ]
  %r2320 = phi double [ %r2307, %pic.merge.364 ], [ %r2315631, %pget.recv_undef_return.373 ], [ %r2319594, %pget.recv_sso.343 ], [ %r2184603, %pget.recv_class_ref.346 ]
  %r2321 = bitcast double %r2320 to i64
  %r2322 = lshr i64 %r2321, 48
  %r2323 = icmp eq i64 %r2322, 32766
  %r2324 = trunc i64 %r2321 to i32
  %r2325 = sitofp i32 %r2324 to double
  %r2326 = select i1 %r2323, double %r2325, double %r2320
  %r2333 = fcmp une double %r2326, 4.700000e+01
  %r2334 = select i1 %r2333, i64 9222246136947933188, i64 9222246136947933187
  %r2335 = bitcast i64 %r2334 to double
  %r2336 = icmp eq i64 %r2334, 9222246136947933188
  br i1 %r2336, label %if.then.374, label %if.else.375

pget.recv_other.348:                              ; preds = %arr.merge.339
  %r2179 = icmp eq i64 %r2176, 32761
  br i1 %r2179, label %pget.recv_sso.343, label %pget.check_class_ref.349

pget.check_class_ref.349:                         ; preds = %pget.recv_other.348
  %r2180 = icmp eq i64 %r2176, 32766
  br i1 %r2180, label %pget.recv_class_ref.346, label %pget.recv_bad.345

pic.hit.350:                                      ; preds = %pic.token.366
  %r2210 = getelementptr i64, ptr %r2195, i64 1
  %r2211 = load i64, ptr %r2210, align 8
  %r2212 = and i64 %r2211, 1073741824
  %r2213 = icmp ne i64 %r2212, 0
  br i1 %r2213, label %pic.hit.overflow.367, label %pic.hit.inline.368

pic.hit.live.351:                                 ; preds = %pic.hit.inline.368
  br label %pic.merge.364

pic.prefix.guard.352:                             ; preds = %pic.token.366
  %r2226 = getelementptr i64, ptr %r2195, i64 2
  %r2227 = load i64, ptr %r2226, align 8
  %r2228 = icmp ne i64 %r2227, 0
  br i1 %r2228, label %pic.prefix.meta.353, label %pic.miss.361

pic.prefix.meta.353:                              ; preds = %pic.prefix.guard.352
  %r2229 = add nuw nsw i64 %r2175, 8
  %r2230 = inttoptr i64 %r2229 to ptr
  %r2231 = load i64, ptr %r2230, align 8
  %r2232 = icmp ne i64 %r2231, 0
  br i1 %r2232, label %pic.prefix.token.354, label %pic.miss.361

pic.prefix.token.354:                             ; preds = %pic.prefix.meta.353
  %r2233 = inttoptr i64 %r2231 to ptr
  %r2234 = getelementptr i64, ptr %r2233, i64 6
  %r2235 = load i64, ptr %r2234, align 8
  %r2236 = icmp eq i64 %r2235, %r2227
  br i1 %r2236, label %pic.prefix.hit.355, label %pic.miss.361

pic.prefix.hit.355:                               ; preds = %pic.prefix.token.354
  %r2237 = getelementptr i64, ptr %r2195, i64 1
  %r2238 = load i64, ptr %r2237, align 8
  %r2239 = shl i64 %r2238, 3
  %r2240 = add nuw nsw i64 %r2175, 16
  %r2241 = add i64 %r2240, %r2239
  %r2242 = inttoptr i64 %r2241 to ptr
  %r2243 = load double, ptr %r2242, align 8
  br label %pic.merge.364

pic.desc.classify.356:                            ; preds = %pic.recv_hdr.365
  %r2199 = and i1 %r2189, %r2196
  br i1 %r2199, label %pic.desc.prefix.guard.357, label %pic.miss.cold.362

pic.desc.prefix.guard.357:                        ; preds = %pic.desc.classify.356
  %r2244 = getelementptr i64, ptr %r2195, i64 2
  %r2245 = load i64, ptr %r2244, align 8
  %r2246 = icmp ne i64 %r2245, 0
  br i1 %r2246, label %pic.desc.prefix.meta.358, label %pic.miss.cold.362

pic.desc.prefix.meta.358:                         ; preds = %pic.desc.prefix.guard.357
  %r2247 = add nuw nsw i64 %r2175, 8
  %r2248 = inttoptr i64 %r2247 to ptr
  %r2249 = load i64, ptr %r2248, align 8
  %r2250 = icmp ne i64 %r2249, 0
  br i1 %r2250, label %pic.desc.prefix.token.359, label %pic.miss.cold.362

pic.desc.prefix.token.359:                        ; preds = %pic.desc.prefix.meta.358
  %r2251 = inttoptr i64 %r2249 to ptr
  %r2252 = getelementptr i64, ptr %r2251, i64 6
  %r2253 = load i64, ptr %r2252, align 8
  %r2254 = icmp eq i64 %r2253, %r2245
  br i1 %r2254, label %pic.desc.prefix.hit.360, label %pic.miss.cold.362

pic.desc.prefix.hit.360:                          ; preds = %pic.desc.prefix.token.359
  %r2255 = getelementptr i64, ptr %r2195, i64 1
  %r2256 = load i64, ptr %r2255, align 8
  %r2257 = shl i64 %r2256, 3
  %r2258 = add nuw nsw i64 %r2175, 16
  %r2259 = add i64 %r2258, %r2257
  %r2260 = inttoptr i64 %r2259 to ptr
  %r2261 = load double, ptr %r2260, align 8
  br label %pic.merge.364

pic.miss.361:                                     ; preds = %pic.hit.inline.368, %pic.prefix.token.354, %pic.prefix.meta.353, %pic.prefix.guard.352
  %r2262 = getelementptr i64, ptr %r2195, i64 3
  %r2263 = load i64, ptr %r2262, align 8
  %r2264 = icmp sgt i64 %r2263, 0
  br i1 %r2264, label %pic.ways.369, label %pic.miss.call.363

pic.miss.cold.362:                                ; preds = %pic.desc.prefix.token.359, %pic.desc.prefix.meta.358, %pic.desc.prefix.guard.357, %pic.desc.classify.356, %pget.recv_ok.344
  br label %pic.miss.call.363

pic.miss.call.363:                                ; preds = %pic.way.load.370, %pic.ways.369, %pic.miss.cold.362, %pic.miss.361
  %r2303 = load double, ptr @test_json_source_token_length_ts_.str.14.handle, align 8
  %r2304 = bitcast double %r2303 to i64
  %r2305 = and i64 %r2304, 281474976710655
  %statepoint_token611 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r2175, i64 %r2305, ptr @perry_ic_test_json_source_token_length_ts__13, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.41598, ptr addrspace(1) %.31605, ptr addrspace(1) %.25, ptr addrspace(1) %.241302, ptr addrspace(1) %.31612, ptr addrspace(1) %.251356, ptr addrspace(1) %.241408) ]
  %r2306612 = call double @llvm.experimental.gc.result.f64(token %statepoint_token611)
  %rs4gc.s37.relocated613 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 0, i32 0) ; (%.41598, %.41598)
  %r1046.1.base.relocated614 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 1, i32 1) ; (%.31605, %.31605)
  %r55.0.base.relocated615 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 2, i32 2) ; (%.25, %.25)
  %r48.0.base.relocated616 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 3, i32 3) ; (%.241302, %.241302)
  %r1046.1.relocated617 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 1, i32 4) ; (%.31605, %.31612)
  %r55.0.relocated618 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 2, i32 5) ; (%.25, %.251356)
  %r48.0.relocated619 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 3, i32 6) ; (%.241302, %.241408)
  br label %pic.merge.364

pic.merge.364:                                    ; preds = %pic.way.live.371, %pic.hit.overflow.367, %pic.miss.call.363, %pic.desc.prefix.hit.360, %pic.prefix.hit.355, %pic.hit.live.351
  %.51614 = phi ptr addrspace(1) [ %r1046.1.relocated626, %pic.hit.overflow.367 ], [ %r1046.1.relocated617, %pic.miss.call.363 ], [ %.31612, %pic.way.live.371 ], [ %.31612, %pic.hit.live.351 ], [ %.31612, %pic.prefix.hit.355 ], [ %.31612, %pic.desc.prefix.hit.360 ]
  %.51607 = phi ptr addrspace(1) [ %r1046.1.base.relocated623, %pic.hit.overflow.367 ], [ %r1046.1.base.relocated614, %pic.miss.call.363 ], [ %.31605, %pic.way.live.371 ], [ %.31605, %pic.hit.live.351 ], [ %.31605, %pic.prefix.hit.355 ], [ %.31605, %pic.desc.prefix.hit.360 ]
  %.61600 = phi ptr addrspace(1) [ %rs4gc.s37.relocated622, %pic.hit.overflow.367 ], [ %rs4gc.s37.relocated613, %pic.miss.call.363 ], [ %.41598, %pic.way.live.371 ], [ %.41598, %pic.hit.live.351 ], [ %.41598, %pic.prefix.hit.355 ], [ %.41598, %pic.desc.prefix.hit.360 ]
  %.261410 = phi ptr addrspace(1) [ %r48.0.relocated628, %pic.hit.overflow.367 ], [ %r48.0.relocated619, %pic.miss.call.363 ], [ %.241408, %pic.way.live.371 ], [ %.241408, %pic.hit.live.351 ], [ %.241408, %pic.prefix.hit.355 ], [ %.241408, %pic.desc.prefix.hit.360 ]
  %.271358 = phi ptr addrspace(1) [ %r55.0.relocated627, %pic.hit.overflow.367 ], [ %r55.0.relocated618, %pic.miss.call.363 ], [ %.251356, %pic.way.live.371 ], [ %.251356, %pic.hit.live.351 ], [ %.251356, %pic.prefix.hit.355 ], [ %.251356, %pic.desc.prefix.hit.360 ]
  %.261304 = phi ptr addrspace(1) [ %r48.0.base.relocated625, %pic.hit.overflow.367 ], [ %r48.0.base.relocated616, %pic.miss.call.363 ], [ %.241302, %pic.way.live.371 ], [ %.241302, %pic.hit.live.351 ], [ %.241302, %pic.prefix.hit.355 ], [ %.241302, %pic.desc.prefix.hit.360 ]
  %.27 = phi ptr addrspace(1) [ %r55.0.base.relocated624, %pic.hit.overflow.367 ], [ %r55.0.base.relocated615, %pic.miss.call.363 ], [ %.25, %pic.way.live.371 ], [ %.25, %pic.hit.live.351 ], [ %.25, %pic.prefix.hit.355 ], [ %.25, %pic.desc.prefix.hit.360 ]
  %r2307 = phi double [ %r2223, %pic.hit.live.351 ], [ %r2218621, %pic.hit.overflow.367 ], [ %r2243, %pic.prefix.hit.355 ], [ %r2261, %pic.desc.prefix.hit.360 ], [ %r2300, %pic.way.live.371 ], [ %r2306612, %pic.miss.call.363 ]
  br label %pget.recv_merge.347

pic.recv_hdr.365:                                 ; preds = %pget.recv_ok.344
  %r2186 = sub nuw nsw i64 %r2175, 8
  %r2187 = inttoptr i64 %r2186 to ptr
  %r2188 = load i8, ptr %r2187, align 1
  %r2189 = icmp eq i8 %r2188, 2
  %r2190 = sub nuw nsw i64 %r2175, 6
  %r2191 = inttoptr i64 %r2190 to ptr
  %r2192 = load i16, ptr %r2191, align 2
  %r2193 = and i16 %r2192, 2048
  %r2194 = icmp eq i16 %r2193, 0
  %r2195 = load ptr, ptr @perry_ic_test_json_source_token_length_ts__13, align 8
  %r2196 = icmp ne ptr %r2195, null
  %r2197 = and i1 %r2189, %r2194
  %r2198 = and i1 %r2197, %r2196
  br i1 %r2198, label %pic.token.366, label %pic.desc.classify.356

pic.token.366:                                    ; preds = %pic.recv_hdr.365
  %r2200 = add nuw nsw i64 %r2175, 4
  %r2201 = inttoptr i64 %r2200 to ptr
  %r2202 = load i32, ptr %r2201, align 4
  %r2203 = zext i32 %r2202 to i64
  %r2204 = or i64 %r2203, 4611686018427387904
  %r2205 = icmp ne i32 %r2202, 0
  %r2206 = getelementptr i64, ptr %r2195, i64 0
  %r2207 = load i64, ptr %r2206, align 8
  %r2208 = icmp eq i64 %r2204, %r2207
  %r2209 = and i1 %r2208, %r2205
  br i1 %r2209, label %pic.hit.350, label %pic.prefix.guard.352

pic.hit.overflow.367:                             ; preds = %pic.hit.350
  %r2214 = load double, ptr @test_json_source_token_length_ts_.str.14.handle, align 8
  %r2215 = bitcast double %r2214 to i64
  %r2216 = and i64 %r2215, 281474976710655
  %r2217 = trunc i64 %r2211 to i32
  %statepoint_token620 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r2175, i64 %r2216, i32 %r2217, ptr @perry_ic_test_json_source_token_length_ts__13, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.41598, ptr addrspace(1) %.31605, ptr addrspace(1) %.25, ptr addrspace(1) %.241302, ptr addrspace(1) %.31612, ptr addrspace(1) %.251356, ptr addrspace(1) %.241408) ]
  %r2218621 = call double @llvm.experimental.gc.result.f64(token %statepoint_token620)
  %rs4gc.s37.relocated622 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token620, i32 0, i32 0) ; (%.41598, %.41598)
  %r1046.1.base.relocated623 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token620, i32 1, i32 1) ; (%.31605, %.31605)
  %r55.0.base.relocated624 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token620, i32 2, i32 2) ; (%.25, %.25)
  %r48.0.base.relocated625 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token620, i32 3, i32 3) ; (%.241302, %.241302)
  %r1046.1.relocated626 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token620, i32 1, i32 4) ; (%.31605, %.31612)
  %r55.0.relocated627 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token620, i32 2, i32 5) ; (%.25, %.251356)
  %r48.0.relocated628 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token620, i32 3, i32 6) ; (%.241302, %.241408)
  br label %pic.merge.364

pic.hit.inline.368:                               ; preds = %pic.hit.350
  %r2219 = shl i64 %r2211, 3
  %r2220 = add nuw nsw i64 %r2175, 16
  %r2221 = add i64 %r2220, %r2219
  %r2222 = inttoptr i64 %r2221 to ptr
  %r2223 = load double, ptr %r2222, align 8
  %r2224 = bitcast double %r2223 to i64
  %r2225 = icmp eq i64 %r2224, 9222246136947933200
  br i1 %r2225, label %pic.miss.361, label %pic.hit.live.351

pic.ways.369:                                     ; preds = %pic.miss.361
  %r2265 = getelementptr i64, ptr %r2195, i64 4
  %r2266 = load i64, ptr %r2265, align 8
  %r2267 = icmp eq i64 %r2266, %r2204
  %r2268 = getelementptr i64, ptr %r2195, i64 5
  %r2269 = load i64, ptr %r2268, align 8
  %r2270 = select i1 %r2267, i64 %r2269, i64 0
  %r2271 = getelementptr i64, ptr %r2195, i64 6
  %r2272 = load i64, ptr %r2271, align 8
  %r2273 = icmp eq i64 %r2272, %r2204
  %r2274 = getelementptr i64, ptr %r2195, i64 7
  %r2275 = load i64, ptr %r2274, align 8
  %r2276 = select i1 %r2273, i64 %r2275, i64 0
  %r2277 = getelementptr i64, ptr %r2195, i64 8
  %r2278 = load i64, ptr %r2277, align 8
  %r2279 = icmp eq i64 %r2278, %r2204
  %r2280 = getelementptr i64, ptr %r2195, i64 9
  %r2281 = load i64, ptr %r2280, align 8
  %r2282 = select i1 %r2279, i64 %r2281, i64 0
  %r2283 = getelementptr i64, ptr %r2195, i64 10
  %r2284 = load i64, ptr %r2283, align 8
  %r2285 = icmp eq i64 %r2284, %r2204
  %r2286 = getelementptr i64, ptr %r2195, i64 11
  %r2287 = load i64, ptr %r2286, align 8
  %r2288 = select i1 %r2285, i64 %r2287, i64 0
  %r2289 = or i1 %r2267, %r2273
  %r2290 = select i1 %r2267, i64 %r2270, i64 %r2276
  %r2291 = or i1 %r2279, %r2285
  %r2292 = select i1 %r2279, i64 %r2282, i64 %r2288
  %r2293 = or i1 %r2289, %r2291
  %r2294 = select i1 %r2289, i64 %r2290, i64 %r2292
  %r2295 = and i1 %r2205, %r2293
  br i1 %r2295, label %pic.way.load.370, label %pic.miss.call.363

pic.way.load.370:                                 ; preds = %pic.ways.369
  %r2296 = shl i64 %r2294, 3
  %r2297 = add nuw nsw i64 %r2175, 16
  %r2298 = add i64 %r2297, %r2296
  %r2299 = inttoptr i64 %r2298 to ptr
  %r2300 = load double, ptr %r2299, align 8
  %r2301 = bitcast double %r2300 to i64
  %r2302 = icmp eq i64 %r2301, 9222246136947933200
  br i1 %r2302, label %pic.miss.call.363, label %pic.way.live.371

pic.way.live.371:                                 ; preds = %pic.way.load.370
  br label %pic.merge.364

pget.throw_nullish.372:                           ; preds = %pget.recv_bad.345
  %r2311 = zext i1 %r2309 to i32
  %statepoint_token629 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2311, ptr @test_json_source_token_length_ts_.str.14.bytes, i64 2, i32 0, i32 0)
  unreachable

pget.recv_undef_return.373:                       ; preds = %pget.recv_bad.345
  %r2312 = load double, ptr @test_json_source_token_length_ts_.str.14.handle, align 8
  %r2313 = bitcast double %r2312 to i64
  %r2314 = and i64 %r2313, 281474976710655
  %statepoint_token630 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2174, i64 %r2314, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.41598, ptr addrspace(1) %.31605, ptr addrspace(1) %.25, ptr addrspace(1) %.241302, ptr addrspace(1) %.31612, ptr addrspace(1) %.251356, ptr addrspace(1) %.241408) ]
  %r2315631 = call double @llvm.experimental.gc.result.f64(token %statepoint_token630)
  %rs4gc.s37.relocated632 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token630, i32 0, i32 0) ; (%.41598, %.41598)
  %r1046.1.base.relocated633 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token630, i32 1, i32 1) ; (%.31605, %.31605)
  %r55.0.base.relocated634 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token630, i32 2, i32 2) ; (%.25, %.25)
  %r48.0.base.relocated635 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token630, i32 3, i32 3) ; (%.241302, %.241302)
  %r1046.1.relocated636 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token630, i32 1, i32 4) ; (%.31605, %.31612)
  %r55.0.relocated637 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token630, i32 2, i32 5) ; (%.25, %.251356)
  %r48.0.relocated638 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token630, i32 3, i32 6) ; (%.241302, %.241408)
  br label %pget.recv_merge.347

if.then.374:                                      ; preds = %pget.recv_merge.347
  %r2337 = load double, ptr @test_json_source_token_length_ts_.str.15.handle, align 8
  %statepoint_token639 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_error_new_from_value, i32 1, i32 0, double %r2337, i32 0, i32 0)
  %r2338640 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token639)
  %r2339 = or i64 %r2338640, 9222527611924643840
  %r2340 = bitcast i64 %r2339 to double
  %statepoint_token641 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r2340, i32 0, i32 0)
  unreachable

if.else.375:                                      ; preds = %pget.recv_merge.347
  br label %if.merge.376

if.merge.376:                                     ; preds = %if.else.375
  %r2341 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r2342 = icmp ne i32 %r2341, 0
  br i1 %r2342, label %gcpoll.377, label %gcpoll.done.378

gcpoll.377:                                       ; preds = %if.merge.376
  %statepoint_token642 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.51599, ptr addrspace(1) %.41606, ptr addrspace(1) %.41613, ptr addrspace(1) %.26, ptr addrspace(1) %.251303, ptr addrspace(1) %.261357, ptr addrspace(1) %.251409) ]
  %rs4gc.s37.relocated643 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token642, i32 0, i32 0) ; (%.51599, %.51599)
  %r1046.1.base.relocated644 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token642, i32 1, i32 1) ; (%.41606, %.41606)
  %r1046.1.relocated645 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token642, i32 1, i32 2) ; (%.41606, %.41613)
  %r55.0.base.relocated646 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token642, i32 3, i32 3) ; (%.26, %.26)
  %r48.0.base.relocated647 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token642, i32 4, i32 4) ; (%.251303, %.251303)
  %r55.0.relocated648 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token642, i32 3, i32 5) ; (%.26, %.261357)
  %r48.0.relocated649 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token642, i32 4, i32 6) ; (%.251303, %.251409)
  br label %gcpoll.done.378

gcpoll.done.378:                                  ; preds = %gcpoll.377, %if.merge.376
  %.61615 = phi ptr addrspace(1) [ %r1046.1.relocated645, %gcpoll.377 ], [ %.41613, %if.merge.376 ]
  %.61608 = phi ptr addrspace(1) [ %r1046.1.base.relocated644, %gcpoll.377 ], [ %.41606, %if.merge.376 ]
  %.71601 = phi ptr addrspace(1) [ %rs4gc.s37.relocated643, %gcpoll.377 ], [ %.51599, %if.merge.376 ]
  %.271411 = phi ptr addrspace(1) [ %r48.0.relocated649, %gcpoll.377 ], [ %.251409, %if.merge.376 ]
  %.281359 = phi ptr addrspace(1) [ %r55.0.relocated648, %gcpoll.377 ], [ %.261357, %if.merge.376 ]
  %.271305 = phi ptr addrspace(1) [ %r48.0.base.relocated647, %gcpoll.377 ], [ %.251303, %if.merge.376 ]
  %.28 = phi ptr addrspace(1) [ %r55.0.base.relocated646, %gcpoll.377 ], [ %.26, %if.merge.376 ]
  br label %for.update.147

for.cond.379:                                     ; preds = %for.update.381, %for.exit.148
  %.01529 = phi ptr addrspace(1) [ %r1046.0, %for.exit.148 ], [ %.391568, %for.update.381 ]
  %.01471 = phi ptr addrspace(1) [ %r1046.0.base, %for.exit.148 ], [ %.391510, %for.update.381 ]
  %.51389 = phi ptr addrspace(1) [ %.41388, %for.exit.148 ], [ %.521436, %for.update.381 ]
  %.61337 = phi ptr addrspace(1) [ %.51336, %for.exit.148 ], [ %.521383, %for.update.381 ]
  %.51283 = phi ptr addrspace(1) [ %.41282, %for.exit.148 ], [ %.521330, %for.update.381 ]
  %.61270 = phi ptr addrspace(1) [ %.51269, %for.exit.148 ], [ %.52, %for.update.381 ]
  %r2347.0 = phi i32 [ 0, %for.exit.148 ], [ %r3709, %for.update.381 ]
  %r1053.1 = phi ptr addrspace(1) [ %r1053.0, %for.exit.148 ], [ %.01670, %for.update.381 ]
  %r2349 = sitofp i32 %r2347.0 to double
  %r2350.rs4i = ptrtoint ptr addrspace(1) %.01529 to i64
  %r2350.rs4o = call i64 asm "", "=r,0"(i64 %r2350.rs4i) #7
  %r2350 = bitcast i64 %r2350.rs4o to double
  %r2351 = bitcast double %r2350 to i64
  %r2352 = and i64 %r2351, 281474976710655
  %r2353 = lshr i64 %r2351, 48
  %r2354 = and i64 %r2353, 65533
  %r2355 = icmp eq i64 %r2354, 32765
  %r2356 = icmp ugt i64 %r2352, 1048575
  %r2357 = and i1 %r2355, %r2356
  br i1 %r2357, label %plen.check_gc.383, label %plen.slow.385

for.body.380:                                     ; preds = %gcpoll.done.405
  %r2465 = sitofp i32 %r2347.0 to double
  %r2466.rs4i = ptrtoint ptr addrspace(1) %.311415 to i64
  %r2466.rs4o = call i64 asm "", "=r,0"(i64 %r2466.rs4i) #7
  %r2466 = bitcast i64 %r2466.rs4o to double
  %r2467 = bitcast double %r2466 to i64
  %r2468 = and i64 %r2467, 281474976710655
  %r2469 = lshr i64 %r2467, 48
  %r2470 = and i64 %r2469, 65533
  %r2471 = icmp eq i64 %r2470, 32765
  %r2472 = icmp ugt i64 %r2468, 1048575
  %r2473 = and i1 %r2471, %r2472
  br i1 %r2473, label %plen.check_gc.406, label %plen.slow.408

for.update.381:                                   ; preds = %gcpoll.done.648
  %r3709 = add i32 %r2347.0, 1
  %r3710 = sitofp i32 %r2347.0 to double
  %r3711 = sitofp i32 %r3709 to double
  br label %for.cond.379

for.exit.382:                                     ; preds = %gcpoll.done.405
  br label %for.cond.649

plen.check_gc.383:                                ; preds = %for.cond.379
  %r2358 = sub nuw nsw i64 %r2352, 8
  %r2359 = inttoptr i64 %r2358 to ptr
  %r2360 = load i8, ptr %r2359, align 1
  %r2361 = icmp eq i8 %r2360, 1
  %r2362 = icmp eq i8 %r2360, 3
  %r2363 = or i1 %r2361, %r2362
  %r2364 = sub nuw nsw i64 %r2352, 7
  %r2365 = inttoptr i64 %r2364 to ptr
  %r2366 = load i8, ptr %r2365, align 1
  %r2367 = and i8 %r2366, -128
  %r2368 = icmp eq i8 %r2367, 0
  %r2369 = and i1 %r2363, %r2368
  br i1 %r2369, label %plen.fast.384, label %plen.slow.385

plen.fast.384:                                    ; preds = %plen.check_gc.383
  %r2371 = inttoptr i64 %r2352 to ptr
  %r2372 = select i1 false, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r2371
  %r2373 = load i32, ptr %r2372, align 4
  %r2374 = uitofp i32 %r2373 to double
  br label %plen.merge.386

plen.slow.385:                                    ; preds = %plen.check_gc.383, %for.cond.379
  %r2375 = lshr i64 %r2351, 48
  %r2376 = icmp eq i64 %r2375, 32765
  %r2377 = icmp uge i64 %r2352, 2199023255552
  %r2378 = icmp ult i64 %r2352, 140737488355328
  %r2379 = and i1 %r2376, %r2377
  %r2380 = and i1 %r2379, %r2378
  %r2381 = load ptr, ptr @perry_ic_test_json_source_token_length_ts__14, align 8
  br i1 %r2380, label %plen.ic.header.387, label %plen.ic.miss.399

plen.merge.386:                                   ; preds = %plen.ic.merge.400, %plen.fast.384
  %.11619 = phi ptr addrspace(1) [ %r1053.1, %plen.fast.384 ], [ %.21620, %plen.ic.merge.400 ]
  %.161545 = phi ptr addrspace(1) [ %.01529, %plen.fast.384 ], [ %.171546, %plen.ic.merge.400 ]
  %.161487 = phi ptr addrspace(1) [ %.01471, %plen.fast.384 ], [ %.171488, %plen.ic.merge.400 ]
  %.291413 = phi ptr addrspace(1) [ %.51389, %plen.fast.384 ], [ %.301414, %plen.ic.merge.400 ]
  %.291360 = phi ptr addrspace(1) [ %.61337, %plen.fast.384 ], [ %.301361, %plen.ic.merge.400 ]
  %.291307 = phi ptr addrspace(1) [ %.51283, %plen.fast.384 ], [ %.301308, %plen.ic.merge.400 ]
  %.29 = phi ptr addrspace(1) [ %.61270, %plen.fast.384 ], [ %.30, %plen.ic.merge.400 ]
  %r2456 = phi double [ %r2374, %plen.fast.384 ], [ %r2455, %plen.ic.merge.400 ]
  %r2457 = fcmp olt double %r2349, %r2456
  %r2458 = select i1 %r2457, i64 9222246136947933188, i64 9222246136947933187
  %r2459 = bitcast i64 %r2458 to double
  %r2461 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r2462 = icmp ne i32 %r2461, 0
  br i1 %r2462, label %gcpoll.404, label %gcpoll.done.405

plen.ic.header.387:                               ; preds = %plen.slow.385
  %r2383 = sub nuw nsw i64 %r2352, 8
  %r2384 = inttoptr i64 %r2383 to ptr
  %r2385 = load i8, ptr %r2384, align 1
  %r2386 = icmp eq i8 %r2385, 2
  %r2387 = sub nuw nsw i64 %r2352, 7
  %r2388 = inttoptr i64 %r2387 to ptr
  %r2389 = load i8, ptr %r2388, align 1
  %r2390 = and i8 %r2389, -128
  %r2391 = icmp eq i8 %r2390, 0
  %r2392 = and i1 %r2386, %r2391
  br i1 %r2392, label %plen.elem.meta.401, label %plen.ic.miss.399

plen.ic.shape.388:                                ; preds = %plen.elem.store.402, %plen.elem.meta.401
  %r2382 = icmp ne ptr %r2381, null
  br i1 %r2382, label %plen.ic.shape.probe.389, label %plen.ic.miss.399

plen.ic.shape.probe.389:                          ; preds = %plen.ic.shape.388
  %r2404 = inttoptr i64 %r2352 to ptr
  %r2405 = load i32, ptr %r2404, align 4
  %r2406 = add nuw nsw i64 %r2352, 4
  %r2407 = inttoptr i64 %r2406 to ptr
  %r2408 = load i32, ptr %r2407, align 4
  %r2409 = zext i32 %r2405 to i64
  %r2410 = zext i32 %r2408 to i64
  %r2411 = shl nuw i64 %r2409, 32
  %r2412 = or i64 %r2411, %r2410
  %r2413 = getelementptr i64, ptr %r2381, i64 0
  %r2414 = load i64, ptr %r2413, align 8
  %r2415 = icmp ne i64 %r2414, 0
  br i1 %r2415, label %plen.ic.identity.390, label %plen.ic.miss.399

plen.ic.identity.390:                             ; preds = %plen.ic.shape.probe.389
  %r2416 = and i64 %r2414, -9223372036854775808
  %2 = icmp slt i64 %r2414, 0
  br i1 %2, label %plen.ic.family_meta.392, label %plen.ic.exact.391

plen.ic.exact.391:                                ; preds = %plen.ic.identity.390
  %r2418 = icmp eq i64 %r2412, %r2414
  br i1 %r2418, label %plen.ic.slot.394, label %plen.ic.miss.399

plen.ic.family_meta.392:                          ; preds = %plen.ic.identity.390
  %r2419 = add nuw nsw i64 %r2352, 8
  %r2420 = inttoptr i64 %r2419 to ptr
  %r2421 = load i64, ptr %r2420, align 8
  %r2422 = icmp ne i64 %r2421, 0
  br i1 %r2422, label %plen.ic.family_token.393, label %plen.ic.miss.399

plen.ic.family_token.393:                         ; preds = %plen.ic.family_meta.392
  %r2423 = inttoptr i64 %r2421 to ptr
  %r2424 = getelementptr i64, ptr %r2423, i64 6
  %r2425 = load i64, ptr %r2424, align 8
  %r2426 = icmp eq i64 %r2425, %r2414
  br i1 %r2426, label %plen.ic.slot.394, label %plen.ic.miss.399

plen.ic.slot.394:                                 ; preds = %plen.ic.family_token.393, %plen.ic.exact.391
  %r2427 = getelementptr i64, ptr %r2381, i64 1
  %r2428 = load i64, ptr %r2427, align 8
  %r2429 = getelementptr i64, ptr %r2381, i64 2
  %r2430 = load i64, ptr %r2429, align 8
  %r2431 = icmp ult i64 %r2428, %r2430
  br i1 %r2431, label %plen.ic.inline.395, label %plen.ic.spill_meta.396

plen.ic.inline.395:                               ; preds = %plen.ic.slot.394
  %r2432 = shl i64 %r2428, 3
  %r2433 = add i64 %r2432, 16
  %r2434 = add i64 %r2352, %r2433
  %r2435 = inttoptr i64 %r2434 to ptr
  %r2436 = load double, ptr %r2435, align 8
  br label %plen.ic.merge.400

plen.ic.spill_meta.396:                           ; preds = %plen.ic.slot.394
  %r2437 = add nuw nsw i64 %r2352, 8
  %r2438 = inttoptr i64 %r2437 to ptr
  %r2439 = load i64, ptr %r2438, align 8
  %r2440 = icmp ne i64 %r2439, 0
  br i1 %r2440, label %plen.ic.spill_ptr.397, label %plen.ic.miss.399

plen.ic.spill_ptr.397:                            ; preds = %plen.ic.spill_meta.396
  %r2441 = inttoptr i64 %r2439 to ptr
  %r2442 = getelementptr i64, ptr %r2441, i64 4
  %r2443 = load i64, ptr %r2442, align 8
  %r2444 = icmp ne i64 %r2443, 0
  %r2445 = select i1 %r2444, i64 %r2443, i64 %r2439
  %r2446 = inttoptr i64 %r2445 to ptr
  %r2447 = load i32, ptr %r2446, align 4
  %r2448 = zext i32 %r2447 to i64
  %r2449 = icmp ult i64 %r2428, %r2448
  %r2450 = and i1 %r2444, %r2449
  br i1 %r2450, label %plen.ic.spill_load.398, label %plen.ic.miss.399

plen.ic.spill_load.398:                           ; preds = %plen.ic.spill_ptr.397
  %r2451 = add nuw nsw i64 %r2428, 1
  %r2452 = getelementptr inbounds nuw i64, ptr %r2446, i64 %r2451
  %r2453 = load double, ptr %r2452, align 8
  br label %plen.ic.merge.400

plen.ic.miss.399:                                 ; preds = %plen.ic.spill_ptr.397, %plen.ic.spill_meta.396, %plen.ic.family_token.393, %plen.ic.family_meta.392, %plen.ic.exact.391, %plen.ic.shape.probe.389, %plen.ic.shape.388, %plen.ic.header.387, %plen.slow.385
  %statepoint_token650 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r2350, ptr @perry_ic_test_json_source_token_length_ts__14, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1053.1, ptr addrspace(1) %.51283, ptr addrspace(1) %.61270, ptr addrspace(1) %.01471, ptr addrspace(1) %.51389, ptr addrspace(1) %.61337, ptr addrspace(1) %.01529) ]
  %r2454651 = call double @llvm.experimental.gc.result.f64(token %statepoint_token650)
  %r1053.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token650, i32 0, i32 0) ; (%r1053.1, %r1053.1)
  %r48.0.base.relocated652 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token650, i32 1, i32 1) ; (%.51283, %.51283)
  %r55.0.base.relocated653 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token650, i32 2, i32 2) ; (%.61270, %.61270)
  %r1046.0.base.relocated654 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token650, i32 3, i32 3) ; (%.01471, %.01471)
  %r48.0.relocated655 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token650, i32 1, i32 4) ; (%.51283, %.51389)
  %r55.0.relocated656 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token650, i32 2, i32 5) ; (%.61270, %.61337)
  %r1046.0.relocated657 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token650, i32 3, i32 6) ; (%.01471, %.01529)
  br label %plen.ic.merge.400

plen.ic.merge.400:                                ; preds = %plen.elem.length.403, %plen.ic.miss.399, %plen.ic.spill_load.398, %plen.ic.inline.395
  %.21620 = phi ptr addrspace(1) [ %r1053.1, %plen.elem.length.403 ], [ %r1053.1, %plen.ic.inline.395 ], [ %r1053.1, %plen.ic.spill_load.398 ], [ %r1053.1.relocated, %plen.ic.miss.399 ]
  %.171546 = phi ptr addrspace(1) [ %.01529, %plen.elem.length.403 ], [ %.01529, %plen.ic.inline.395 ], [ %.01529, %plen.ic.spill_load.398 ], [ %r1046.0.relocated657, %plen.ic.miss.399 ]
  %.171488 = phi ptr addrspace(1) [ %.01471, %plen.elem.length.403 ], [ %.01471, %plen.ic.inline.395 ], [ %.01471, %plen.ic.spill_load.398 ], [ %r1046.0.base.relocated654, %plen.ic.miss.399 ]
  %.301414 = phi ptr addrspace(1) [ %.51389, %plen.elem.length.403 ], [ %.51389, %plen.ic.inline.395 ], [ %.51389, %plen.ic.spill_load.398 ], [ %r48.0.relocated655, %plen.ic.miss.399 ]
  %.301361 = phi ptr addrspace(1) [ %.61337, %plen.elem.length.403 ], [ %.61337, %plen.ic.inline.395 ], [ %.61337, %plen.ic.spill_load.398 ], [ %r55.0.relocated656, %plen.ic.miss.399 ]
  %.301308 = phi ptr addrspace(1) [ %.51283, %plen.elem.length.403 ], [ %.51283, %plen.ic.inline.395 ], [ %.51283, %plen.ic.spill_load.398 ], [ %r48.0.base.relocated652, %plen.ic.miss.399 ]
  %.30 = phi ptr addrspace(1) [ %.61270, %plen.elem.length.403 ], [ %.61270, %plen.ic.inline.395 ], [ %.61270, %plen.ic.spill_load.398 ], [ %r55.0.base.relocated653, %plen.ic.miss.399 ]
  %r2455 = phi double [ %r2403, %plen.elem.length.403 ], [ %r2436, %plen.ic.inline.395 ], [ %r2453, %plen.ic.spill_load.398 ], [ %r2454651, %plen.ic.miss.399 ]
  br label %plen.merge.386

plen.elem.meta.401:                               ; preds = %plen.ic.header.387
  %r2393 = add nuw nsw i64 %r2352, 8
  %r2394 = inttoptr i64 %r2393 to ptr
  %r2395 = load i64, ptr %r2394, align 8
  %r2396 = icmp ne i64 %r2395, 0
  br i1 %r2396, label %plen.elem.store.402, label %plen.ic.shape.388

plen.elem.store.402:                              ; preds = %plen.elem.meta.401
  %r2397 = inttoptr i64 %r2395 to ptr
  %r2398 = getelementptr i64, ptr %r2397, i64 12
  %r2399 = load i64, ptr %r2398, align 8
  %r2400 = icmp ne i64 %r2399, 0
  br i1 %r2400, label %plen.elem.length.403, label %plen.ic.shape.388

plen.elem.length.403:                             ; preds = %plen.elem.store.402
  %r2401 = inttoptr i64 %r2399 to ptr
  %r2402 = load i32, ptr %r2401, align 4
  %r2403 = uitofp i32 %r2402 to double
  br label %plen.ic.merge.400

gcpoll.404:                                       ; preds = %plen.merge.386
  %statepoint_token658 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11619, ptr addrspace(1) %.291307, ptr addrspace(1) %.29, ptr addrspace(1) %.161487, ptr addrspace(1) %.291413, ptr addrspace(1) %.291360, ptr addrspace(1) %.161545) ]
  %r1053.1.relocated659 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token658, i32 0, i32 0) ; (%.11619, %.11619)
  %r48.0.base.relocated660 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token658, i32 1, i32 1) ; (%.291307, %.291307)
  %r55.0.base.relocated661 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token658, i32 2, i32 2) ; (%.29, %.29)
  %r1046.0.base.relocated662 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token658, i32 3, i32 3) ; (%.161487, %.161487)
  %r48.0.relocated663 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token658, i32 1, i32 4) ; (%.291307, %.291413)
  %r55.0.relocated664 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token658, i32 2, i32 5) ; (%.29, %.291360)
  %r1046.0.relocated665 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token658, i32 3, i32 6) ; (%.161487, %.161545)
  br label %gcpoll.done.405

gcpoll.done.405:                                  ; preds = %gcpoll.404, %plen.merge.386
  %.31621 = phi ptr addrspace(1) [ %r1053.1.relocated659, %gcpoll.404 ], [ %.11619, %plen.merge.386 ]
  %.181547 = phi ptr addrspace(1) [ %r1046.0.relocated665, %gcpoll.404 ], [ %.161545, %plen.merge.386 ]
  %.181489 = phi ptr addrspace(1) [ %r1046.0.base.relocated662, %gcpoll.404 ], [ %.161487, %plen.merge.386 ]
  %.311415 = phi ptr addrspace(1) [ %r48.0.relocated663, %gcpoll.404 ], [ %.291413, %plen.merge.386 ]
  %.311362 = phi ptr addrspace(1) [ %r55.0.relocated664, %gcpoll.404 ], [ %.291360, %plen.merge.386 ]
  %.311309 = phi ptr addrspace(1) [ %r48.0.base.relocated660, %gcpoll.404 ], [ %.291307, %plen.merge.386 ]
  %.31 = phi ptr addrspace(1) [ %r55.0.base.relocated661, %gcpoll.404 ], [ %.29, %plen.merge.386 ]
  %r2460 = icmp eq i64 %r2458, 9222246136947933188
  br i1 %r2460, label %for.body.380, label %for.exit.382

plen.check_gc.406:                                ; preds = %for.body.380
  %r2474 = sub nuw nsw i64 %r2468, 8
  %r2475 = inttoptr i64 %r2474 to ptr
  %r2476 = load i8, ptr %r2475, align 1
  %r2477 = icmp eq i8 %r2476, 1
  %r2478 = icmp eq i8 %r2476, 3
  %r2479 = or i1 %r2477, %r2478
  %r2480 = sub nuw nsw i64 %r2468, 7
  %r2481 = inttoptr i64 %r2480 to ptr
  %r2482 = load i8, ptr %r2481, align 1
  %r2483 = and i8 %r2482, -128
  %r2484 = icmp eq i8 %r2483, 0
  %r2485 = and i1 %r2479, %r2484
  br i1 %r2485, label %plen.fast.407, label %plen.slow.408

plen.fast.407:                                    ; preds = %plen.check_gc.406
  %r2487 = inttoptr i64 %r2468 to ptr
  %r2488 = select i1 false, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r2487
  %r2489 = load i32, ptr %r2488, align 4
  %r2490 = uitofp i32 %r2489 to double
  br label %plen.merge.409

plen.slow.408:                                    ; preds = %plen.check_gc.406, %for.body.380
  %r2491 = lshr i64 %r2467, 48
  %r2492 = icmp eq i64 %r2491, 32765
  %r2493 = icmp uge i64 %r2468, 2199023255552
  %r2494 = icmp ult i64 %r2468, 140737488355328
  %r2495 = and i1 %r2492, %r2493
  %r2496 = and i1 %r2495, %r2494
  %r2497 = load ptr, ptr @perry_ic_test_json_source_token_length_ts__15, align 8
  br i1 %r2496, label %plen.ic.header.410, label %plen.ic.miss.422

plen.merge.409:                                   ; preds = %plen.ic.merge.423, %plen.fast.407
  %.41622 = phi ptr addrspace(1) [ %.31621, %plen.fast.407 ], [ %.51623, %plen.ic.merge.423 ]
  %.191548 = phi ptr addrspace(1) [ %.181547, %plen.fast.407 ], [ %.201549, %plen.ic.merge.423 ]
  %.191490 = phi ptr addrspace(1) [ %.181489, %plen.fast.407 ], [ %.201491, %plen.ic.merge.423 ]
  %.321416 = phi ptr addrspace(1) [ %.311415, %plen.fast.407 ], [ %.331417, %plen.ic.merge.423 ]
  %.321363 = phi ptr addrspace(1) [ %.311362, %plen.fast.407 ], [ %.331364, %plen.ic.merge.423 ]
  %.321310 = phi ptr addrspace(1) [ %.311309, %plen.fast.407 ], [ %.331311, %plen.ic.merge.423 ]
  %.32 = phi ptr addrspace(1) [ %.31, %plen.fast.407 ], [ %.33, %plen.ic.merge.423 ]
  %r2572 = phi double [ %r2490, %plen.fast.407 ], [ %r2571, %plen.ic.merge.423 ]
  %r2573 = fcmp oge double %r2465, 0xC1E0000000000000
  %r2574 = fcmp ole double %r2465, 0x41DFFFFFFFC00000
  %r2575 = fcmp oge double %r2572, 0xC1E0000000000000
  %r2576 = fcmp ole double %r2572, 0x41DFFFFFFFC00000
  %r2577 = and i1 %r2573, %r2574
  %r2578 = and i1 %r2575, %r2576
  %r2579 = and i1 %r2577, %r2578
  br i1 %r2579, label %mod.i32.convert.427, label %mod.f64.fallback.429

plen.ic.header.410:                               ; preds = %plen.slow.408
  %r2499 = sub nuw nsw i64 %r2468, 8
  %r2500 = inttoptr i64 %r2499 to ptr
  %r2501 = load i8, ptr %r2500, align 1
  %r2502 = icmp eq i8 %r2501, 2
  %r2503 = sub nuw nsw i64 %r2468, 7
  %r2504 = inttoptr i64 %r2503 to ptr
  %r2505 = load i8, ptr %r2504, align 1
  %r2506 = and i8 %r2505, -128
  %r2507 = icmp eq i8 %r2506, 0
  %r2508 = and i1 %r2502, %r2507
  br i1 %r2508, label %plen.elem.meta.424, label %plen.ic.miss.422

plen.ic.shape.411:                                ; preds = %plen.elem.store.425, %plen.elem.meta.424
  %r2498 = icmp ne ptr %r2497, null
  br i1 %r2498, label %plen.ic.shape.probe.412, label %plen.ic.miss.422

plen.ic.shape.probe.412:                          ; preds = %plen.ic.shape.411
  %r2520 = inttoptr i64 %r2468 to ptr
  %r2521 = load i32, ptr %r2520, align 4
  %r2522 = add nuw nsw i64 %r2468, 4
  %r2523 = inttoptr i64 %r2522 to ptr
  %r2524 = load i32, ptr %r2523, align 4
  %r2525 = zext i32 %r2521 to i64
  %r2526 = zext i32 %r2524 to i64
  %r2527 = shl nuw i64 %r2525, 32
  %r2528 = or i64 %r2527, %r2526
  %r2529 = getelementptr i64, ptr %r2497, i64 0
  %r2530 = load i64, ptr %r2529, align 8
  %r2531 = icmp ne i64 %r2530, 0
  br i1 %r2531, label %plen.ic.identity.413, label %plen.ic.miss.422

plen.ic.identity.413:                             ; preds = %plen.ic.shape.probe.412
  %r2532 = and i64 %r2530, -9223372036854775808
  %3 = icmp slt i64 %r2530, 0
  br i1 %3, label %plen.ic.family_meta.415, label %plen.ic.exact.414

plen.ic.exact.414:                                ; preds = %plen.ic.identity.413
  %r2534 = icmp eq i64 %r2528, %r2530
  br i1 %r2534, label %plen.ic.slot.417, label %plen.ic.miss.422

plen.ic.family_meta.415:                          ; preds = %plen.ic.identity.413
  %r2535 = add nuw nsw i64 %r2468, 8
  %r2536 = inttoptr i64 %r2535 to ptr
  %r2537 = load i64, ptr %r2536, align 8
  %r2538 = icmp ne i64 %r2537, 0
  br i1 %r2538, label %plen.ic.family_token.416, label %plen.ic.miss.422

plen.ic.family_token.416:                         ; preds = %plen.ic.family_meta.415
  %r2539 = inttoptr i64 %r2537 to ptr
  %r2540 = getelementptr i64, ptr %r2539, i64 6
  %r2541 = load i64, ptr %r2540, align 8
  %r2542 = icmp eq i64 %r2541, %r2530
  br i1 %r2542, label %plen.ic.slot.417, label %plen.ic.miss.422

plen.ic.slot.417:                                 ; preds = %plen.ic.family_token.416, %plen.ic.exact.414
  %r2543 = getelementptr i64, ptr %r2497, i64 1
  %r2544 = load i64, ptr %r2543, align 8
  %r2545 = getelementptr i64, ptr %r2497, i64 2
  %r2546 = load i64, ptr %r2545, align 8
  %r2547 = icmp ult i64 %r2544, %r2546
  br i1 %r2547, label %plen.ic.inline.418, label %plen.ic.spill_meta.419

plen.ic.inline.418:                               ; preds = %plen.ic.slot.417
  %r2548 = shl i64 %r2544, 3
  %r2549 = add i64 %r2548, 16
  %r2550 = add i64 %r2468, %r2549
  %r2551 = inttoptr i64 %r2550 to ptr
  %r2552 = load double, ptr %r2551, align 8
  br label %plen.ic.merge.423

plen.ic.spill_meta.419:                           ; preds = %plen.ic.slot.417
  %r2553 = add nuw nsw i64 %r2468, 8
  %r2554 = inttoptr i64 %r2553 to ptr
  %r2555 = load i64, ptr %r2554, align 8
  %r2556 = icmp ne i64 %r2555, 0
  br i1 %r2556, label %plen.ic.spill_ptr.420, label %plen.ic.miss.422

plen.ic.spill_ptr.420:                            ; preds = %plen.ic.spill_meta.419
  %r2557 = inttoptr i64 %r2555 to ptr
  %r2558 = getelementptr i64, ptr %r2557, i64 4
  %r2559 = load i64, ptr %r2558, align 8
  %r2560 = icmp ne i64 %r2559, 0
  %r2561 = select i1 %r2560, i64 %r2559, i64 %r2555
  %r2562 = inttoptr i64 %r2561 to ptr
  %r2563 = load i32, ptr %r2562, align 4
  %r2564 = zext i32 %r2563 to i64
  %r2565 = icmp ult i64 %r2544, %r2564
  %r2566 = and i1 %r2560, %r2565
  br i1 %r2566, label %plen.ic.spill_load.421, label %plen.ic.miss.422

plen.ic.spill_load.421:                           ; preds = %plen.ic.spill_ptr.420
  %r2567 = add nuw nsw i64 %r2544, 1
  %r2568 = getelementptr inbounds nuw i64, ptr %r2562, i64 %r2567
  %r2569 = load double, ptr %r2568, align 8
  br label %plen.ic.merge.423

plen.ic.miss.422:                                 ; preds = %plen.ic.spill_ptr.420, %plen.ic.spill_meta.419, %plen.ic.family_token.416, %plen.ic.family_meta.415, %plen.ic.exact.414, %plen.ic.shape.probe.412, %plen.ic.shape.411, %plen.ic.header.410, %plen.slow.408
  %statepoint_token666 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r2466, ptr @perry_ic_test_json_source_token_length_ts__15, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31621, ptr addrspace(1) %.311309, ptr addrspace(1) %.31, ptr addrspace(1) %.181489, ptr addrspace(1) %.311415, ptr addrspace(1) %.311362, ptr addrspace(1) %.181547) ]
  %r2570667 = call double @llvm.experimental.gc.result.f64(token %statepoint_token666)
  %r1053.1.relocated668 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token666, i32 0, i32 0) ; (%.31621, %.31621)
  %r48.0.base.relocated669 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token666, i32 1, i32 1) ; (%.311309, %.311309)
  %r55.0.base.relocated670 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token666, i32 2, i32 2) ; (%.31, %.31)
  %r1046.0.base.relocated671 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token666, i32 3, i32 3) ; (%.181489, %.181489)
  %r48.0.relocated672 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token666, i32 1, i32 4) ; (%.311309, %.311415)
  %r55.0.relocated673 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token666, i32 2, i32 5) ; (%.31, %.311362)
  %r1046.0.relocated674 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token666, i32 3, i32 6) ; (%.181489, %.181547)
  br label %plen.ic.merge.423

plen.ic.merge.423:                                ; preds = %plen.elem.length.426, %plen.ic.miss.422, %plen.ic.spill_load.421, %plen.ic.inline.418
  %.51623 = phi ptr addrspace(1) [ %.31621, %plen.elem.length.426 ], [ %.31621, %plen.ic.inline.418 ], [ %.31621, %plen.ic.spill_load.421 ], [ %r1053.1.relocated668, %plen.ic.miss.422 ]
  %.201549 = phi ptr addrspace(1) [ %.181547, %plen.elem.length.426 ], [ %.181547, %plen.ic.inline.418 ], [ %.181547, %plen.ic.spill_load.421 ], [ %r1046.0.relocated674, %plen.ic.miss.422 ]
  %.201491 = phi ptr addrspace(1) [ %.181489, %plen.elem.length.426 ], [ %.181489, %plen.ic.inline.418 ], [ %.181489, %plen.ic.spill_load.421 ], [ %r1046.0.base.relocated671, %plen.ic.miss.422 ]
  %.331417 = phi ptr addrspace(1) [ %.311415, %plen.elem.length.426 ], [ %.311415, %plen.ic.inline.418 ], [ %.311415, %plen.ic.spill_load.421 ], [ %r48.0.relocated672, %plen.ic.miss.422 ]
  %.331364 = phi ptr addrspace(1) [ %.311362, %plen.elem.length.426 ], [ %.311362, %plen.ic.inline.418 ], [ %.311362, %plen.ic.spill_load.421 ], [ %r55.0.relocated673, %plen.ic.miss.422 ]
  %.331311 = phi ptr addrspace(1) [ %.311309, %plen.elem.length.426 ], [ %.311309, %plen.ic.inline.418 ], [ %.311309, %plen.ic.spill_load.421 ], [ %r48.0.base.relocated669, %plen.ic.miss.422 ]
  %.33 = phi ptr addrspace(1) [ %.31, %plen.elem.length.426 ], [ %.31, %plen.ic.inline.418 ], [ %.31, %plen.ic.spill_load.421 ], [ %r55.0.base.relocated670, %plen.ic.miss.422 ]
  %r2571 = phi double [ %r2519, %plen.elem.length.426 ], [ %r2552, %plen.ic.inline.418 ], [ %r2569, %plen.ic.spill_load.421 ], [ %r2570667, %plen.ic.miss.422 ]
  br label %plen.merge.409

plen.elem.meta.424:                               ; preds = %plen.ic.header.410
  %r2509 = add nuw nsw i64 %r2468, 8
  %r2510 = inttoptr i64 %r2509 to ptr
  %r2511 = load i64, ptr %r2510, align 8
  %r2512 = icmp ne i64 %r2511, 0
  br i1 %r2512, label %plen.elem.store.425, label %plen.ic.shape.411

plen.elem.store.425:                              ; preds = %plen.elem.meta.424
  %r2513 = inttoptr i64 %r2511 to ptr
  %r2514 = getelementptr i64, ptr %r2513, i64 12
  %r2515 = load i64, ptr %r2514, align 8
  %r2516 = icmp ne i64 %r2515, 0
  br i1 %r2516, label %plen.elem.length.426, label %plen.ic.shape.411

plen.elem.length.426:                             ; preds = %plen.elem.store.425
  %r2517 = inttoptr i64 %r2515 to ptr
  %r2518 = load i32, ptr %r2517, align 4
  %r2519 = uitofp i32 %r2518 to double
  br label %plen.ic.merge.423

mod.i32.convert.427:                              ; preds = %plen.merge.409
  %r2580 = fptosi double %r2465 to i32
  %r2581 = fptosi double %r2572 to i32
  %r2582 = sitofp i32 %r2580 to double
  %r2583 = sitofp i32 %r2581 to double
  %r2584 = fcmp oeq double %r2582, %r2465
  %r2585 = fcmp oeq double %r2583, %r2572
  %r2586 = icmp ne i32 %r2581, 0
  %r2587 = and i1 %r2584, %r2585
  %r2588 = and i1 %r2587, %r2586
  br i1 %r2588, label %mod.i32.integer.428, label %mod.f64.fallback.429

mod.i32.integer.428:                              ; preds = %mod.i32.convert.427
  %r2589 = srem i32 %r2580, %r2581
  %r2590 = sitofp i32 %r2589 to double
  %r2591 = icmp eq i32 %r2589, 0
  %r2592 = bitcast double %r2465 to i64
  %r2593 = icmp slt i64 %r2592, 0
  %r2594 = and i1 %r2591, %r2593
  %r2595 = fneg double %r2590
  %r2596 = select i1 %r2594, double %r2595, double %r2590
  br label %mod.merge.430

mod.f64.fallback.429:                             ; preds = %mod.i32.convert.427, %plen.merge.409
  %r2597 = frem double %r2465, %r2572
  br label %mod.merge.430

mod.merge.430:                                    ; preds = %mod.f64.fallback.429, %mod.i32.integer.428
  %r2598 = phi double [ %r2596, %mod.i32.integer.428 ], [ %r2597, %mod.f64.fallback.429 ]
  %r2600.rs4i = ptrtoint ptr addrspace(1) %.191548 to i64
  %r2600.rs4o = call i64 asm "", "=r,0"(i64 %r2600.rs4i) #7
  %r2600 = bitcast i64 %r2600.rs4o to double
  %r2602 = bitcast double %r2600 to i64
  %r2603 = and i64 %r2602, 281474976710655
  %r2604 = lshr i64 %r2602, 48
  %r2605 = icmp eq i64 %r2604, 32765
  %r2606 = icmp ugt i64 %r2603, 1048575
  %r2607 = and i1 %r2605, %r2606
  br i1 %r2607, label %arr.guard.deref.435, label %arr.fallback.432

arr.fast.431:                                     ; preds = %arr.guard.range.437
  %r2663 = zext i32 %r2347.0 to i64
  %r2664 = shl nuw nsw i64 %r2663, 3
  %r2665 = add nuw nsw i64 %r2664, 8
  %r2666 = add i64 %r2622, %r2665
  %r2667 = inttoptr i64 %r2666 to ptr
  %r2668 = load double, ptr %r2667, align 8
  %r2669 = bitcast double %r2668 to i64
  %r2670 = icmp eq i64 %r2669, 9222246136947933200
  %r2672 = select i1 %r2670, double 0x7FFC000000000001, double %r2668
  br label %arr.merge.434

arr.fallback.432:                                 ; preds = %arr.guard.live.436, %arr.guard.deref.435, %mod.merge.430
  %r2661 = sitofp i32 %r2347.0 to double
  %statepoint_token675 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 5587713372188573712, double %r2600, double %r2661, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.41622, ptr addrspace(1) %.321310, ptr addrspace(1) %.32, ptr addrspace(1) %.191490, ptr addrspace(1) %.321416, ptr addrspace(1) %.321363, ptr addrspace(1) %.191548) ]
  %r2662676 = call double @llvm.experimental.gc.result.f64(token %statepoint_token675)
  %r1053.1.relocated677 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token675, i32 0, i32 0) ; (%.41622, %.41622)
  %r48.0.base.relocated678 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token675, i32 1, i32 1) ; (%.321310, %.321310)
  %r55.0.base.relocated679 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token675, i32 2, i32 2) ; (%.32, %.32)
  %r1046.0.base.relocated680 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token675, i32 3, i32 3) ; (%.191490, %.191490)
  %r48.0.relocated681 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token675, i32 1, i32 4) ; (%.321310, %.321416)
  %r55.0.relocated682 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token675, i32 2, i32 5) ; (%.32, %.321363)
  %r1046.0.relocated683 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token675, i32 3, i32 6) ; (%.191490, %.191548)
  br label %arr.merge.434

arr.guard.oob.433:                                ; preds = %arr.guard.range.437
  br label %arr.merge.434

arr.merge.434:                                    ; preds = %arr.guard.oob.433, %arr.fallback.432, %arr.fast.431
  %.61624 = phi ptr addrspace(1) [ %.41622, %arr.fast.431 ], [ %.41622, %arr.guard.oob.433 ], [ %r1053.1.relocated677, %arr.fallback.432 ]
  %.211550 = phi ptr addrspace(1) [ %.191548, %arr.fast.431 ], [ %.191548, %arr.guard.oob.433 ], [ %r1046.0.relocated683, %arr.fallback.432 ]
  %.211492 = phi ptr addrspace(1) [ %.191490, %arr.fast.431 ], [ %.191490, %arr.guard.oob.433 ], [ %r1046.0.base.relocated680, %arr.fallback.432 ]
  %.341418 = phi ptr addrspace(1) [ %.321416, %arr.fast.431 ], [ %.321416, %arr.guard.oob.433 ], [ %r48.0.relocated681, %arr.fallback.432 ]
  %.341365 = phi ptr addrspace(1) [ %.321363, %arr.fast.431 ], [ %.321363, %arr.guard.oob.433 ], [ %r55.0.relocated682, %arr.fallback.432 ]
  %.341312 = phi ptr addrspace(1) [ %.321310, %arr.fast.431 ], [ %.321310, %arr.guard.oob.433 ], [ %r48.0.base.relocated678, %arr.fallback.432 ]
  %.34 = phi ptr addrspace(1) [ %.32, %arr.fast.431 ], [ %.32, %arr.guard.oob.433 ], [ %r55.0.base.relocated679, %arr.fallback.432 ]
  %r2673 = phi double [ %r2672, %arr.fast.431 ], [ %r2662676, %arr.fallback.432 ], [ 0x7FFC000000000001, %arr.guard.oob.433 ]
  %rs4gc.b43 = bitcast double %r2673 to i64
  %rs4gc.s43 = inttoptr i64 %rs4gc.b43 to ptr addrspace(1)
  %r2674 = bitcast double %r2673 to i64
  %r2675 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2676 = icmp ne i32 %r2675, 0
  br i1 %r2676, label %shadow.root.barrier.438, label %shadow.root.barrier.done.439

arr.guard.deref.435:                              ; preds = %mod.merge.430
  %r2608 = bitcast double %r2600 to i64
  %r2609 = and i64 %r2608, 281474976710655
  %r2610 = sub nsw i64 %r2609, 8
  %r2611 = inttoptr i64 %r2610 to ptr
  %r2612 = load i8, ptr %r2611, align 1
  %r2613 = icmp eq i8 %r2612, 1
  %r2614 = sub nsw i64 %r2609, 7
  %r2615 = inttoptr i64 %r2614 to ptr
  %r2616 = load i8, ptr %r2615, align 1
  %r2617 = and i8 %r2616, -128
  %r2618 = icmp ne i8 %r2617, 0
  %r2619 = inttoptr i64 %r2609 to ptr
  %r2620 = load i64, ptr %r2619, align 8
  %r2621 = and i1 %r2613, %r2618
  %r2622 = select i1 %r2621, i64 %r2620, i64 %r2609
  %r2623 = lshr i64 %r2622, 48
  %r2624 = icmp eq i64 %r2623, 0
  %r2625 = icmp ugt i64 %r2622, 1048575
  %r2626 = and i1 %r2624, %r2625
  br i1 %r2626, label %arr.guard.live.436, label %arr.fallback.432

arr.guard.live.436:                               ; preds = %arr.guard.deref.435
  %r2627 = sub nuw i64 %r2622, 8
  %r2628 = inttoptr i64 %r2627 to ptr
  %r2629 = load i8, ptr %r2628, align 1
  %r2630 = icmp eq i8 %r2629, 1
  %r2631 = sub nuw i64 %r2622, 7
  %r2632 = inttoptr i64 %r2631 to ptr
  %r2633 = load i8, ptr %r2632, align 1
  %r2634 = and i8 %r2633, -128
  %r2635 = icmp eq i8 %r2634, 0
  %r2636 = sub nuw i64 %r2622, 6
  %r2637 = inttoptr i64 %r2636 to ptr
  %r2638 = load i16, ptr %r2637, align 2
  %r2639 = and i16 %r2638, 1024
  %r2640 = icmp eq i16 %r2639, 0
  %r2641 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2642 = icmp eq i8 %r2641, 0
  %r2643 = inttoptr i64 %r2622 to ptr
  %r2644 = load i32, ptr %r2643, align 4
  %r2645 = getelementptr i8, ptr %r2643, i64 4
  %r2646 = load i32, ptr %r2645, align 4
  %r2647 = icmp slt i32 %r2347.0, 0
  %r2648 = icmp eq i1 %r2647, false
  %r2650 = icmp ule i32 %r2644, 16000000
  %r2651 = icmp ule i32 %r2646, 16000000
  %r2652 = icmp ule i32 %r2644, %r2646
  %r2653 = and i1 %r2630, %r2635
  %r2654 = and i1 %r2653, %r2640
  %r2655 = and i1 %r2654, %r2642
  %r2656 = and i1 %r2655, %r2648
  %r2657 = and i1 %r2656, %r2650
  %r2658 = and i1 %r2657, %r2651
  %r2659 = and i1 %r2658, %r2652
  br i1 %r2659, label %arr.guard.range.437, label %arr.fallback.432

arr.guard.range.437:                              ; preds = %arr.guard.live.436
  %r2649 = icmp ult i32 %r2347.0, %r2644
  br i1 %r2649, label %arr.fast.431, label %arr.guard.oob.433

shadow.root.barrier.438:                          ; preds = %arr.merge.434
  call void @js_write_barrier_root_nanbox(i64 %r2674) #7
  br label %shadow.root.barrier.done.439

shadow.root.barrier.done.439:                     ; preds = %shadow.root.barrier.438, %arr.merge.434
  %r2677.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s43 to i64
  %r2677.rs4o = call i64 asm "", "=r,0"(i64 %r2677.rs4i) #7
  %r2677 = bitcast i64 %r2677.rs4o to double
  %r2678 = bitcast double %r2677 to i64
  %r2679 = and i64 %r2678, 281474976710655
  %r2680 = lshr i64 %r2678, 48
  %r2681 = and i64 %r2680, 65533
  %r2682 = icmp eq i64 %r2681, 32765
  br i1 %r2682, label %pget.recv_ok.441, label %pget.recv_other.445

pget.recv_sso.440:                                ; preds = %pget.recv_other.445
  %r2820 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r2821 = bitcast double %r2820 to i64
  %r2822 = and i64 %r2821, 281474976710655
  %statepoint_token684 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2678, i64 %r2822, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61624, ptr addrspace(1) %rs4gc.s43, ptr addrspace(1) %.341312, ptr addrspace(1) %.34, ptr addrspace(1) %.211492, ptr addrspace(1) %.341418, ptr addrspace(1) %.341365, ptr addrspace(1) %.211550) ]
  %r2823685 = call double @llvm.experimental.gc.result.f64(token %statepoint_token684)
  %r1053.1.relocated686 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token684, i32 0, i32 0) ; (%.61624, %.61624)
  %rs4gc.s43.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token684, i32 1, i32 1) ; (%rs4gc.s43, %rs4gc.s43)
  %r48.0.base.relocated687 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token684, i32 2, i32 2) ; (%.341312, %.341312)
  %r55.0.base.relocated688 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token684, i32 3, i32 3) ; (%.34, %.34)
  %r1046.0.base.relocated689 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token684, i32 4, i32 4) ; (%.211492, %.211492)
  %r48.0.relocated690 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token684, i32 2, i32 5) ; (%.341312, %.341418)
  %r55.0.relocated691 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token684, i32 3, i32 6) ; (%.34, %.341365)
  %r1046.0.relocated692 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token684, i32 4, i32 7) ; (%.211492, %.211550)
  br label %pget.recv_merge.444

pget.recv_ok.441:                                 ; preds = %shadow.root.barrier.done.439
  %r2689 = icmp ugt i64 %r2679, 1048575
  br i1 %r2689, label %pic.recv_hdr.462, label %pic.miss.cold.459

pget.recv_bad.442:                                ; preds = %pget.check_class_ref.446
  %r2812 = icmp eq i64 %r2678, 9222246136947933185
  %r2813 = icmp eq i64 %r2678, 9222246136947933186
  %r2814 = or i1 %r2812, %r2813
  br i1 %r2814, label %pget.throw_nullish.469, label %pget.recv_undef_return.470

pget.recv_class_ref.443:                          ; preds = %pget.check_class_ref.446
  %r2685 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r2686 = bitcast double %r2685 to i64
  %r2687 = and i64 %r2686, 281474976710655
  %statepoint_token693 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 5587713372188573713, i64 %r2678, i64 %r2687, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61624, ptr addrspace(1) %rs4gc.s43, ptr addrspace(1) %.341312, ptr addrspace(1) %.34, ptr addrspace(1) %.211492, ptr addrspace(1) %.341418, ptr addrspace(1) %.341365, ptr addrspace(1) %.211550) ]
  %r2688694 = call double @llvm.experimental.gc.result.f64(token %statepoint_token693)
  %r1053.1.relocated695 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token693, i32 0, i32 0) ; (%.61624, %.61624)
  %rs4gc.s43.relocated696 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token693, i32 1, i32 1) ; (%rs4gc.s43, %rs4gc.s43)
  %r48.0.base.relocated697 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token693, i32 2, i32 2) ; (%.341312, %.341312)
  %r55.0.base.relocated698 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token693, i32 3, i32 3) ; (%.34, %.34)
  %r1046.0.base.relocated699 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token693, i32 4, i32 4) ; (%.211492, %.211492)
  %r48.0.relocated700 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token693, i32 2, i32 5) ; (%.341312, %.341418)
  %r55.0.relocated701 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token693, i32 3, i32 6) ; (%.34, %.341365)
  %r1046.0.relocated702 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token693, i32 4, i32 7) ; (%.211492, %.211550)
  br label %pget.recv_merge.444

pget.recv_merge.444:                              ; preds = %pget.recv_undef_return.470, %pic.merge.461, %pget.recv_class_ref.443, %pget.recv_sso.440
  %.01648 = phi ptr addrspace(1) [ %.11649, %pic.merge.461 ], [ %rs4gc.s43.relocated, %pget.recv_sso.440 ], [ %rs4gc.s43.relocated696, %pget.recv_class_ref.443 ], [ %rs4gc.s43.relocated727, %pget.recv_undef_return.470 ]
  %.71625 = phi ptr addrspace(1) [ %.81626, %pic.merge.461 ], [ %r1053.1.relocated686, %pget.recv_sso.440 ], [ %r1053.1.relocated695, %pget.recv_class_ref.443 ], [ %r1053.1.relocated726, %pget.recv_undef_return.470 ]
  %.221551 = phi ptr addrspace(1) [ %.231552, %pic.merge.461 ], [ %r1046.0.relocated692, %pget.recv_sso.440 ], [ %r1046.0.relocated702, %pget.recv_class_ref.443 ], [ %r1046.0.relocated733, %pget.recv_undef_return.470 ]
  %.221493 = phi ptr addrspace(1) [ %.231494, %pic.merge.461 ], [ %r1046.0.base.relocated689, %pget.recv_sso.440 ], [ %r1046.0.base.relocated699, %pget.recv_class_ref.443 ], [ %r1046.0.base.relocated730, %pget.recv_undef_return.470 ]
  %.351419 = phi ptr addrspace(1) [ %.361420, %pic.merge.461 ], [ %r48.0.relocated690, %pget.recv_sso.440 ], [ %r48.0.relocated700, %pget.recv_class_ref.443 ], [ %r48.0.relocated731, %pget.recv_undef_return.470 ]
  %.351366 = phi ptr addrspace(1) [ %.361367, %pic.merge.461 ], [ %r55.0.relocated691, %pget.recv_sso.440 ], [ %r55.0.relocated701, %pget.recv_class_ref.443 ], [ %r55.0.relocated732, %pget.recv_undef_return.470 ]
  %.351313 = phi ptr addrspace(1) [ %.361314, %pic.merge.461 ], [ %r48.0.base.relocated687, %pget.recv_sso.440 ], [ %r48.0.base.relocated697, %pget.recv_class_ref.443 ], [ %r48.0.base.relocated728, %pget.recv_undef_return.470 ]
  %.35 = phi ptr addrspace(1) [ %.36, %pic.merge.461 ], [ %r55.0.base.relocated688, %pget.recv_sso.440 ], [ %r55.0.base.relocated698, %pget.recv_class_ref.443 ], [ %r55.0.base.relocated729, %pget.recv_undef_return.470 ]
  %r2824 = phi double [ %r2811, %pic.merge.461 ], [ %r2819725, %pget.recv_undef_return.470 ], [ %r2823685, %pget.recv_sso.440 ], [ %r2688694, %pget.recv_class_ref.443 ]
  %r2825 = bitcast double %r2824 to i64
  %rs4gc.s44 = inttoptr i64 %r2825 to ptr addrspace(1)
  %r2826.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s44 to i64
  %r2826 = call i64 asm "", "=r,0"(i64 %r2826.rs4i) #7
  %r2827 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2828 = icmp ne i32 %r2827, 0
  br i1 %r2828, label %shadow.root.barrier.471, label %shadow.root.barrier.done.472

pget.recv_other.445:                              ; preds = %shadow.root.barrier.done.439
  %r2683 = icmp eq i64 %r2680, 32761
  br i1 %r2683, label %pget.recv_sso.440, label %pget.check_class_ref.446

pget.check_class_ref.446:                         ; preds = %pget.recv_other.445
  %r2684 = icmp eq i64 %r2680, 32766
  br i1 %r2684, label %pget.recv_class_ref.443, label %pget.recv_bad.442

pic.hit.447:                                      ; preds = %pic.token.463
  %r2714 = getelementptr i64, ptr %r2699, i64 1
  %r2715 = load i64, ptr %r2714, align 8
  %r2716 = and i64 %r2715, 1073741824
  %r2717 = icmp ne i64 %r2716, 0
  br i1 %r2717, label %pic.hit.overflow.464, label %pic.hit.inline.465

pic.hit.live.448:                                 ; preds = %pic.hit.inline.465
  br label %pic.merge.461

pic.prefix.guard.449:                             ; preds = %pic.token.463
  %r2730 = getelementptr i64, ptr %r2699, i64 2
  %r2731 = load i64, ptr %r2730, align 8
  %r2732 = icmp ne i64 %r2731, 0
  br i1 %r2732, label %pic.prefix.meta.450, label %pic.miss.458

pic.prefix.meta.450:                              ; preds = %pic.prefix.guard.449
  %r2733 = add nuw nsw i64 %r2679, 8
  %r2734 = inttoptr i64 %r2733 to ptr
  %r2735 = load i64, ptr %r2734, align 8
  %r2736 = icmp ne i64 %r2735, 0
  br i1 %r2736, label %pic.prefix.token.451, label %pic.miss.458

pic.prefix.token.451:                             ; preds = %pic.prefix.meta.450
  %r2737 = inttoptr i64 %r2735 to ptr
  %r2738 = getelementptr i64, ptr %r2737, i64 6
  %r2739 = load i64, ptr %r2738, align 8
  %r2740 = icmp eq i64 %r2739, %r2731
  br i1 %r2740, label %pic.prefix.hit.452, label %pic.miss.458

pic.prefix.hit.452:                               ; preds = %pic.prefix.token.451
  %r2741 = getelementptr i64, ptr %r2699, i64 1
  %r2742 = load i64, ptr %r2741, align 8
  %r2743 = shl i64 %r2742, 3
  %r2744 = add nuw nsw i64 %r2679, 16
  %r2745 = add i64 %r2744, %r2743
  %r2746 = inttoptr i64 %r2745 to ptr
  %r2747 = load double, ptr %r2746, align 8
  br label %pic.merge.461

pic.desc.classify.453:                            ; preds = %pic.recv_hdr.462
  %r2703 = and i1 %r2693, %r2700
  br i1 %r2703, label %pic.desc.prefix.guard.454, label %pic.miss.cold.459

pic.desc.prefix.guard.454:                        ; preds = %pic.desc.classify.453
  %r2748 = getelementptr i64, ptr %r2699, i64 2
  %r2749 = load i64, ptr %r2748, align 8
  %r2750 = icmp ne i64 %r2749, 0
  br i1 %r2750, label %pic.desc.prefix.meta.455, label %pic.miss.cold.459

pic.desc.prefix.meta.455:                         ; preds = %pic.desc.prefix.guard.454
  %r2751 = add nuw nsw i64 %r2679, 8
  %r2752 = inttoptr i64 %r2751 to ptr
  %r2753 = load i64, ptr %r2752, align 8
  %r2754 = icmp ne i64 %r2753, 0
  br i1 %r2754, label %pic.desc.prefix.token.456, label %pic.miss.cold.459

pic.desc.prefix.token.456:                        ; preds = %pic.desc.prefix.meta.455
  %r2755 = inttoptr i64 %r2753 to ptr
  %r2756 = getelementptr i64, ptr %r2755, i64 6
  %r2757 = load i64, ptr %r2756, align 8
  %r2758 = icmp eq i64 %r2757, %r2749
  br i1 %r2758, label %pic.desc.prefix.hit.457, label %pic.miss.cold.459

pic.desc.prefix.hit.457:                          ; preds = %pic.desc.prefix.token.456
  %r2759 = getelementptr i64, ptr %r2699, i64 1
  %r2760 = load i64, ptr %r2759, align 8
  %r2761 = shl i64 %r2760, 3
  %r2762 = add nuw nsw i64 %r2679, 16
  %r2763 = add i64 %r2762, %r2761
  %r2764 = inttoptr i64 %r2763 to ptr
  %r2765 = load double, ptr %r2764, align 8
  br label %pic.merge.461

pic.miss.458:                                     ; preds = %pic.hit.inline.465, %pic.prefix.token.451, %pic.prefix.meta.450, %pic.prefix.guard.449
  %r2766 = getelementptr i64, ptr %r2699, i64 3
  %r2767 = load i64, ptr %r2766, align 8
  %r2768 = icmp sgt i64 %r2767, 0
  br i1 %r2768, label %pic.ways.466, label %pic.miss.call.460

pic.miss.cold.459:                                ; preds = %pic.desc.prefix.token.456, %pic.desc.prefix.meta.455, %pic.desc.prefix.guard.454, %pic.desc.classify.453, %pget.recv_ok.441
  br label %pic.miss.call.460

pic.miss.call.460:                                ; preds = %pic.way.load.467, %pic.ways.466, %pic.miss.cold.459, %pic.miss.458
  %r2807 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r2808 = bitcast double %r2807 to i64
  %r2809 = and i64 %r2808, 281474976710655
  %statepoint_token703 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r2679, i64 %r2809, ptr @perry_ic_test_json_source_token_length_ts__18, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61624, ptr addrspace(1) %rs4gc.s43, ptr addrspace(1) %.341312, ptr addrspace(1) %.34, ptr addrspace(1) %.211492, ptr addrspace(1) %.341418, ptr addrspace(1) %.341365, ptr addrspace(1) %.211550) ]
  %r2810704 = call double @llvm.experimental.gc.result.f64(token %statepoint_token703)
  %r1053.1.relocated705 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token703, i32 0, i32 0) ; (%.61624, %.61624)
  %rs4gc.s43.relocated706 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token703, i32 1, i32 1) ; (%rs4gc.s43, %rs4gc.s43)
  %r48.0.base.relocated707 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token703, i32 2, i32 2) ; (%.341312, %.341312)
  %r55.0.base.relocated708 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token703, i32 3, i32 3) ; (%.34, %.34)
  %r1046.0.base.relocated709 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token703, i32 4, i32 4) ; (%.211492, %.211492)
  %r48.0.relocated710 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token703, i32 2, i32 5) ; (%.341312, %.341418)
  %r55.0.relocated711 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token703, i32 3, i32 6) ; (%.34, %.341365)
  %r1046.0.relocated712 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token703, i32 4, i32 7) ; (%.211492, %.211550)
  br label %pic.merge.461

pic.merge.461:                                    ; preds = %pic.way.live.468, %pic.hit.overflow.464, %pic.miss.call.460, %pic.desc.prefix.hit.457, %pic.prefix.hit.452, %pic.hit.live.448
  %.11649 = phi ptr addrspace(1) [ %rs4gc.s43.relocated716, %pic.hit.overflow.464 ], [ %rs4gc.s43.relocated706, %pic.miss.call.460 ], [ %rs4gc.s43, %pic.way.live.468 ], [ %rs4gc.s43, %pic.hit.live.448 ], [ %rs4gc.s43, %pic.prefix.hit.452 ], [ %rs4gc.s43, %pic.desc.prefix.hit.457 ]
  %.81626 = phi ptr addrspace(1) [ %r1053.1.relocated715, %pic.hit.overflow.464 ], [ %r1053.1.relocated705, %pic.miss.call.460 ], [ %.61624, %pic.way.live.468 ], [ %.61624, %pic.hit.live.448 ], [ %.61624, %pic.prefix.hit.452 ], [ %.61624, %pic.desc.prefix.hit.457 ]
  %.231552 = phi ptr addrspace(1) [ %r1046.0.relocated722, %pic.hit.overflow.464 ], [ %r1046.0.relocated712, %pic.miss.call.460 ], [ %.211550, %pic.way.live.468 ], [ %.211550, %pic.hit.live.448 ], [ %.211550, %pic.prefix.hit.452 ], [ %.211550, %pic.desc.prefix.hit.457 ]
  %.231494 = phi ptr addrspace(1) [ %r1046.0.base.relocated719, %pic.hit.overflow.464 ], [ %r1046.0.base.relocated709, %pic.miss.call.460 ], [ %.211492, %pic.way.live.468 ], [ %.211492, %pic.hit.live.448 ], [ %.211492, %pic.prefix.hit.452 ], [ %.211492, %pic.desc.prefix.hit.457 ]
  %.361420 = phi ptr addrspace(1) [ %r48.0.relocated720, %pic.hit.overflow.464 ], [ %r48.0.relocated710, %pic.miss.call.460 ], [ %.341418, %pic.way.live.468 ], [ %.341418, %pic.hit.live.448 ], [ %.341418, %pic.prefix.hit.452 ], [ %.341418, %pic.desc.prefix.hit.457 ]
  %.361367 = phi ptr addrspace(1) [ %r55.0.relocated721, %pic.hit.overflow.464 ], [ %r55.0.relocated711, %pic.miss.call.460 ], [ %.341365, %pic.way.live.468 ], [ %.341365, %pic.hit.live.448 ], [ %.341365, %pic.prefix.hit.452 ], [ %.341365, %pic.desc.prefix.hit.457 ]
  %.361314 = phi ptr addrspace(1) [ %r48.0.base.relocated717, %pic.hit.overflow.464 ], [ %r48.0.base.relocated707, %pic.miss.call.460 ], [ %.341312, %pic.way.live.468 ], [ %.341312, %pic.hit.live.448 ], [ %.341312, %pic.prefix.hit.452 ], [ %.341312, %pic.desc.prefix.hit.457 ]
  %.36 = phi ptr addrspace(1) [ %r55.0.base.relocated718, %pic.hit.overflow.464 ], [ %r55.0.base.relocated708, %pic.miss.call.460 ], [ %.34, %pic.way.live.468 ], [ %.34, %pic.hit.live.448 ], [ %.34, %pic.prefix.hit.452 ], [ %.34, %pic.desc.prefix.hit.457 ]
  %r2811 = phi double [ %r2727, %pic.hit.live.448 ], [ %r2722714, %pic.hit.overflow.464 ], [ %r2747, %pic.prefix.hit.452 ], [ %r2765, %pic.desc.prefix.hit.457 ], [ %r2804, %pic.way.live.468 ], [ %r2810704, %pic.miss.call.460 ]
  br label %pget.recv_merge.444

pic.recv_hdr.462:                                 ; preds = %pget.recv_ok.441
  %r2690 = sub nuw nsw i64 %r2679, 8
  %r2691 = inttoptr i64 %r2690 to ptr
  %r2692 = load i8, ptr %r2691, align 1
  %r2693 = icmp eq i8 %r2692, 2
  %r2694 = sub nuw nsw i64 %r2679, 6
  %r2695 = inttoptr i64 %r2694 to ptr
  %r2696 = load i16, ptr %r2695, align 2
  %r2697 = and i16 %r2696, 2048
  %r2698 = icmp eq i16 %r2697, 0
  %r2699 = load ptr, ptr @perry_ic_test_json_source_token_length_ts__18, align 8
  %r2700 = icmp ne ptr %r2699, null
  %r2701 = and i1 %r2693, %r2698
  %r2702 = and i1 %r2701, %r2700
  br i1 %r2702, label %pic.token.463, label %pic.desc.classify.453

pic.token.463:                                    ; preds = %pic.recv_hdr.462
  %r2704 = add nuw nsw i64 %r2679, 4
  %r2705 = inttoptr i64 %r2704 to ptr
  %r2706 = load i32, ptr %r2705, align 4
  %r2707 = zext i32 %r2706 to i64
  %r2708 = or i64 %r2707, 4611686018427387904
  %r2709 = icmp ne i32 %r2706, 0
  %r2710 = getelementptr i64, ptr %r2699, i64 0
  %r2711 = load i64, ptr %r2710, align 8
  %r2712 = icmp eq i64 %r2708, %r2711
  %r2713 = and i1 %r2712, %r2709
  br i1 %r2713, label %pic.hit.447, label %pic.prefix.guard.449

pic.hit.overflow.464:                             ; preds = %pic.hit.447
  %r2718 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r2719 = bitcast double %r2718 to i64
  %r2720 = and i64 %r2719, 281474976710655
  %r2721 = trunc i64 %r2715 to i32
  %statepoint_token713 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r2679, i64 %r2720, i32 %r2721, ptr @perry_ic_test_json_source_token_length_ts__18, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61624, ptr addrspace(1) %rs4gc.s43, ptr addrspace(1) %.341312, ptr addrspace(1) %.34, ptr addrspace(1) %.211492, ptr addrspace(1) %.341418, ptr addrspace(1) %.341365, ptr addrspace(1) %.211550) ]
  %r2722714 = call double @llvm.experimental.gc.result.f64(token %statepoint_token713)
  %r1053.1.relocated715 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token713, i32 0, i32 0) ; (%.61624, %.61624)
  %rs4gc.s43.relocated716 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token713, i32 1, i32 1) ; (%rs4gc.s43, %rs4gc.s43)
  %r48.0.base.relocated717 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token713, i32 2, i32 2) ; (%.341312, %.341312)
  %r55.0.base.relocated718 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token713, i32 3, i32 3) ; (%.34, %.34)
  %r1046.0.base.relocated719 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token713, i32 4, i32 4) ; (%.211492, %.211492)
  %r48.0.relocated720 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token713, i32 2, i32 5) ; (%.341312, %.341418)
  %r55.0.relocated721 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token713, i32 3, i32 6) ; (%.34, %.341365)
  %r1046.0.relocated722 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token713, i32 4, i32 7) ; (%.211492, %.211550)
  br label %pic.merge.461

pic.hit.inline.465:                               ; preds = %pic.hit.447
  %r2723 = shl i64 %r2715, 3
  %r2724 = add nuw nsw i64 %r2679, 16
  %r2725 = add i64 %r2724, %r2723
  %r2726 = inttoptr i64 %r2725 to ptr
  %r2727 = load double, ptr %r2726, align 8
  %r2728 = bitcast double %r2727 to i64
  %r2729 = icmp eq i64 %r2728, 9222246136947933200
  br i1 %r2729, label %pic.miss.458, label %pic.hit.live.448

pic.ways.466:                                     ; preds = %pic.miss.458
  %r2769 = getelementptr i64, ptr %r2699, i64 4
  %r2770 = load i64, ptr %r2769, align 8
  %r2771 = icmp eq i64 %r2770, %r2708
  %r2772 = getelementptr i64, ptr %r2699, i64 5
  %r2773 = load i64, ptr %r2772, align 8
  %r2774 = select i1 %r2771, i64 %r2773, i64 0
  %r2775 = getelementptr i64, ptr %r2699, i64 6
  %r2776 = load i64, ptr %r2775, align 8
  %r2777 = icmp eq i64 %r2776, %r2708
  %r2778 = getelementptr i64, ptr %r2699, i64 7
  %r2779 = load i64, ptr %r2778, align 8
  %r2780 = select i1 %r2777, i64 %r2779, i64 0
  %r2781 = getelementptr i64, ptr %r2699, i64 8
  %r2782 = load i64, ptr %r2781, align 8
  %r2783 = icmp eq i64 %r2782, %r2708
  %r2784 = getelementptr i64, ptr %r2699, i64 9
  %r2785 = load i64, ptr %r2784, align 8
  %r2786 = select i1 %r2783, i64 %r2785, i64 0
  %r2787 = getelementptr i64, ptr %r2699, i64 10
  %r2788 = load i64, ptr %r2787, align 8
  %r2789 = icmp eq i64 %r2788, %r2708
  %r2790 = getelementptr i64, ptr %r2699, i64 11
  %r2791 = load i64, ptr %r2790, align 8
  %r2792 = select i1 %r2789, i64 %r2791, i64 0
  %r2793 = or i1 %r2771, %r2777
  %r2794 = select i1 %r2771, i64 %r2774, i64 %r2780
  %r2795 = or i1 %r2783, %r2789
  %r2796 = select i1 %r2783, i64 %r2786, i64 %r2792
  %r2797 = or i1 %r2793, %r2795
  %r2798 = select i1 %r2793, i64 %r2794, i64 %r2796
  %r2799 = and i1 %r2709, %r2797
  br i1 %r2799, label %pic.way.load.467, label %pic.miss.call.460

pic.way.load.467:                                 ; preds = %pic.ways.466
  %r2800 = shl i64 %r2798, 3
  %r2801 = add nuw nsw i64 %r2679, 16
  %r2802 = add i64 %r2801, %r2800
  %r2803 = inttoptr i64 %r2802 to ptr
  %r2804 = load double, ptr %r2803, align 8
  %r2805 = bitcast double %r2804 to i64
  %r2806 = icmp eq i64 %r2805, 9222246136947933200
  br i1 %r2806, label %pic.miss.call.460, label %pic.way.live.468

pic.way.live.468:                                 ; preds = %pic.way.load.467
  br label %pic.merge.461

pget.throw_nullish.469:                           ; preds = %pget.recv_bad.442
  %r2815 = zext i1 %r2813 to i32
  %statepoint_token723 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2815, ptr @test_json_source_token_length_ts_.str.10.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.470:                       ; preds = %pget.recv_bad.442
  %r2816 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r2817 = bitcast double %r2816 to i64
  %r2818 = and i64 %r2817, 281474976710655
  %statepoint_token724 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2678, i64 %r2818, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61624, ptr addrspace(1) %rs4gc.s43, ptr addrspace(1) %.341312, ptr addrspace(1) %.34, ptr addrspace(1) %.211492, ptr addrspace(1) %.341418, ptr addrspace(1) %.341365, ptr addrspace(1) %.211550) ]
  %r2819725 = call double @llvm.experimental.gc.result.f64(token %statepoint_token724)
  %r1053.1.relocated726 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token724, i32 0, i32 0) ; (%.61624, %.61624)
  %rs4gc.s43.relocated727 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token724, i32 1, i32 1) ; (%rs4gc.s43, %rs4gc.s43)
  %r48.0.base.relocated728 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token724, i32 2, i32 2) ; (%.341312, %.341312)
  %r55.0.base.relocated729 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token724, i32 3, i32 3) ; (%.34, %.34)
  %r1046.0.base.relocated730 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token724, i32 4, i32 4) ; (%.211492, %.211492)
  %r48.0.relocated731 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token724, i32 2, i32 5) ; (%.341312, %.341418)
  %r55.0.relocated732 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token724, i32 3, i32 6) ; (%.34, %.341365)
  %r1046.0.relocated733 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token724, i32 4, i32 7) ; (%.211492, %.211550)
  br label %pget.recv_merge.444

shadow.root.barrier.471:                          ; preds = %pget.recv_merge.444
  call void @js_write_barrier_root_nanbox(i64 %r2826) #7
  br label %shadow.root.barrier.done.472

shadow.root.barrier.done.472:                     ; preds = %shadow.root.barrier.471, %pget.recv_merge.444
  %r2829.rs4i = ptrtoint ptr addrspace(1) %.351366 to i64
  %r2829.rs4o = call i64 asm "", "=r,0"(i64 %r2829.rs4i) #7
  %r2829 = bitcast i64 %r2829.rs4o to double
  %r2831 = fcmp oge double %r2598, 0.000000e+00
  %r2832 = fcmp ole double %r2598, 0x41DFFFFFFFC00000
  %r2833 = and i1 %r2831, %r2832
  %r2834 = select i1 %r2833, double %r2598, double 0.000000e+00
  %r2835 = fptosi double %r2834 to i32
  %r2836 = sitofp i32 %r2835 to double
  %r2837 = fcmp oeq double %r2836, %r2598
  %r2838 = and i1 %r2833, %r2837
  %r2839 = bitcast double %r2598 to i64
  %r2840 = lshr i64 %r2839, 48
  %r2841 = icmp eq i64 %r2840, 32766
  %r2842 = trunc i64 %r2839 to i32
  %r2843 = icmp sge i32 %r2842, 0
  %r2844 = and i1 %r2841, %r2843
  %r2845 = or i1 %r2838, %r2844
  %r2846 = select i1 %r2841, i32 %r2842, i32 %r2835
  br i1 %r2845, label %aidx.canonical.473, label %aidx.runtime_key.474

aidx.canonical.473:                               ; preds = %shadow.root.barrier.done.472
  %r2847 = bitcast double %r2829 to i64
  %r2848 = and i64 %r2847, 281474976710655
  %r2849 = lshr i64 %r2847, 48
  %r2850 = icmp eq i64 %r2849, 32765
  %r2851 = icmp ugt i64 %r2848, 1048575
  %r2852 = and i1 %r2850, %r2851
  br i1 %r2852, label %aidx.dynamic.guard.deref.480, label %aidx.dynamic.fallback.477

aidx.runtime_key.474:                             ; preds = %shadow.root.barrier.done.472
  %r2919 = bitcast double %r2829 to i64
  %r2920 = and i64 %r2919, 281474976710655
  %statepoint_token734 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_array_get_index_or_string, i32 2, i32 0, i64 %r2920, double %r2598, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.71625, ptr addrspace(1) %.01648, ptr addrspace(1) %.351313, ptr addrspace(1) %.35, ptr addrspace(1) %.221493, ptr addrspace(1) %.351419, ptr addrspace(1) %rs4gc.s44, ptr addrspace(1) %.351366, ptr addrspace(1) %.221551) ]
  %r2921735 = call double @llvm.experimental.gc.result.f64(token %statepoint_token734)
  %r1053.1.relocated736 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token734, i32 0, i32 0) ; (%.71625, %.71625)
  %rs4gc.s43.relocated737 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token734, i32 1, i32 1) ; (%.01648, %.01648)
  %r48.0.base.relocated738 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token734, i32 2, i32 2) ; (%.351313, %.351313)
  %r55.0.base.relocated739 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token734, i32 3, i32 3) ; (%.35, %.35)
  %r1046.0.base.relocated740 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token734, i32 4, i32 4) ; (%.221493, %.221493)
  %r48.0.relocated741 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token734, i32 2, i32 5) ; (%.351313, %.351419)
  %rs4gc.s44.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token734, i32 6, i32 6) ; (%rs4gc.s44, %rs4gc.s44)
  %r55.0.relocated742 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token734, i32 3, i32 7) ; (%.35, %.351366)
  %r1046.0.relocated743 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token734, i32 4, i32 8) ; (%.221493, %.221551)
  br label %aidx.dynamic_merge.475

aidx.dynamic_merge.475:                           ; preds = %aidx.dynamic.merge.479, %aidx.runtime_key.474
  %.01657 = phi ptr addrspace(1) [ %.11658, %aidx.dynamic.merge.479 ], [ %rs4gc.s44.relocated, %aidx.runtime_key.474 ]
  %.21650 = phi ptr addrspace(1) [ %.31651, %aidx.dynamic.merge.479 ], [ %rs4gc.s43.relocated737, %aidx.runtime_key.474 ]
  %.91627 = phi ptr addrspace(1) [ %.101628, %aidx.dynamic.merge.479 ], [ %r1053.1.relocated736, %aidx.runtime_key.474 ]
  %.241553 = phi ptr addrspace(1) [ %.251554, %aidx.dynamic.merge.479 ], [ %r1046.0.relocated743, %aidx.runtime_key.474 ]
  %.241495 = phi ptr addrspace(1) [ %.251496, %aidx.dynamic.merge.479 ], [ %r1046.0.base.relocated740, %aidx.runtime_key.474 ]
  %.371421 = phi ptr addrspace(1) [ %.381422, %aidx.dynamic.merge.479 ], [ %r48.0.relocated741, %aidx.runtime_key.474 ]
  %.371368 = phi ptr addrspace(1) [ %.381369, %aidx.dynamic.merge.479 ], [ %r55.0.relocated742, %aidx.runtime_key.474 ]
  %.371315 = phi ptr addrspace(1) [ %.381316, %aidx.dynamic.merge.479 ], [ %r48.0.base.relocated738, %aidx.runtime_key.474 ]
  %.37 = phi ptr addrspace(1) [ %.38, %aidx.dynamic.merge.479 ], [ %r55.0.base.relocated739, %aidx.runtime_key.474 ]
  %r2922 = phi double [ %r2918, %aidx.dynamic.merge.479 ], [ %r2921735, %aidx.runtime_key.474 ]
  %r2923.rs4i = ptrtoint ptr addrspace(1) %.01657 to i64
  %r2923 = call i64 asm "", "=r,0"(i64 %r2923.rs4i) #7
  %r2924 = bitcast i64 %r2923 to double
  %r2925 = bitcast double %r2922 to i64
  %r2926 = and i64 %r2923, 9221120237041090560
  %r2927 = icmp ne i64 %r2926, 9221120237041090560
  %r2928 = and i64 %r2925, 9221120237041090560
  %r2929 = icmp ne i64 %r2928, 9221120237041090560
  %r2930 = and i1 %r2927, %r2929
  br i1 %r2930, label %dyncmp.num.483, label %dyncmp.slow.484

aidx.dynamic.fast.476:                            ; preds = %aidx.dynamic.guard.range.482
  %r2908 = zext i32 %r2846 to i64
  %r2909 = shl nuw nsw i64 %r2908, 3
  %r2910 = add nuw nsw i64 %r2909, 8
  %r2911 = add i64 %r2867, %r2910
  %r2912 = inttoptr i64 %r2911 to ptr
  %r2913 = load double, ptr %r2912, align 8
  %r2914 = bitcast double %r2913 to i64
  %r2915 = icmp eq i64 %r2914, 9222246136947933200
  %r2917 = select i1 %r2915, double 0x7FFC000000000001, double %r2913
  br label %aidx.dynamic.merge.479

aidx.dynamic.fallback.477:                        ; preds = %aidx.dynamic.guard.live.481, %aidx.dynamic.guard.deref.480, %aidx.canonical.473
  %r2906 = sitofp i32 %r2846 to double
  %statepoint_token744 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 5587713372188573715, double %r2829, double %r2906, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.71625, ptr addrspace(1) %.01648, ptr addrspace(1) %.351313, ptr addrspace(1) %.35, ptr addrspace(1) %.221493, ptr addrspace(1) %.351419, ptr addrspace(1) %rs4gc.s44, ptr addrspace(1) %.351366, ptr addrspace(1) %.221551) ]
  %r2907745 = call double @llvm.experimental.gc.result.f64(token %statepoint_token744)
  %r1053.1.relocated746 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token744, i32 0, i32 0) ; (%.71625, %.71625)
  %rs4gc.s43.relocated747 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token744, i32 1, i32 1) ; (%.01648, %.01648)
  %r48.0.base.relocated748 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token744, i32 2, i32 2) ; (%.351313, %.351313)
  %r55.0.base.relocated749 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token744, i32 3, i32 3) ; (%.35, %.35)
  %r1046.0.base.relocated750 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token744, i32 4, i32 4) ; (%.221493, %.221493)
  %r48.0.relocated751 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token744, i32 2, i32 5) ; (%.351313, %.351419)
  %rs4gc.s44.relocated752 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token744, i32 6, i32 6) ; (%rs4gc.s44, %rs4gc.s44)
  %r55.0.relocated753 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token744, i32 3, i32 7) ; (%.35, %.351366)
  %r1046.0.relocated754 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token744, i32 4, i32 8) ; (%.221493, %.221551)
  br label %aidx.dynamic.merge.479

aidx.dynamic.guard.oob.478:                       ; preds = %aidx.dynamic.guard.range.482
  br label %aidx.dynamic.merge.479

aidx.dynamic.merge.479:                           ; preds = %aidx.dynamic.guard.oob.478, %aidx.dynamic.fallback.477, %aidx.dynamic.fast.476
  %.11658 = phi ptr addrspace(1) [ %rs4gc.s44, %aidx.dynamic.fast.476 ], [ %rs4gc.s44, %aidx.dynamic.guard.oob.478 ], [ %rs4gc.s44.relocated752, %aidx.dynamic.fallback.477 ]
  %.31651 = phi ptr addrspace(1) [ %.01648, %aidx.dynamic.fast.476 ], [ %.01648, %aidx.dynamic.guard.oob.478 ], [ %rs4gc.s43.relocated747, %aidx.dynamic.fallback.477 ]
  %.101628 = phi ptr addrspace(1) [ %.71625, %aidx.dynamic.fast.476 ], [ %.71625, %aidx.dynamic.guard.oob.478 ], [ %r1053.1.relocated746, %aidx.dynamic.fallback.477 ]
  %.251554 = phi ptr addrspace(1) [ %.221551, %aidx.dynamic.fast.476 ], [ %.221551, %aidx.dynamic.guard.oob.478 ], [ %r1046.0.relocated754, %aidx.dynamic.fallback.477 ]
  %.251496 = phi ptr addrspace(1) [ %.221493, %aidx.dynamic.fast.476 ], [ %.221493, %aidx.dynamic.guard.oob.478 ], [ %r1046.0.base.relocated750, %aidx.dynamic.fallback.477 ]
  %.381422 = phi ptr addrspace(1) [ %.351419, %aidx.dynamic.fast.476 ], [ %.351419, %aidx.dynamic.guard.oob.478 ], [ %r48.0.relocated751, %aidx.dynamic.fallback.477 ]
  %.381369 = phi ptr addrspace(1) [ %.351366, %aidx.dynamic.fast.476 ], [ %.351366, %aidx.dynamic.guard.oob.478 ], [ %r55.0.relocated753, %aidx.dynamic.fallback.477 ]
  %.381316 = phi ptr addrspace(1) [ %.351313, %aidx.dynamic.fast.476 ], [ %.351313, %aidx.dynamic.guard.oob.478 ], [ %r48.0.base.relocated748, %aidx.dynamic.fallback.477 ]
  %.38 = phi ptr addrspace(1) [ %.35, %aidx.dynamic.fast.476 ], [ %.35, %aidx.dynamic.guard.oob.478 ], [ %r55.0.base.relocated749, %aidx.dynamic.fallback.477 ]
  %r2918 = phi double [ %r2917, %aidx.dynamic.fast.476 ], [ %r2907745, %aidx.dynamic.fallback.477 ], [ 0x7FFC000000000001, %aidx.dynamic.guard.oob.478 ]
  br label %aidx.dynamic_merge.475

aidx.dynamic.guard.deref.480:                     ; preds = %aidx.canonical.473
  %r2853 = bitcast double %r2829 to i64
  %r2854 = and i64 %r2853, 281474976710655
  %r2855 = sub nsw i64 %r2854, 8
  %r2856 = inttoptr i64 %r2855 to ptr
  %r2857 = load i8, ptr %r2856, align 1
  %r2858 = icmp eq i8 %r2857, 1
  %r2859 = sub nsw i64 %r2854, 7
  %r2860 = inttoptr i64 %r2859 to ptr
  %r2861 = load i8, ptr %r2860, align 1
  %r2862 = and i8 %r2861, -128
  %r2863 = icmp ne i8 %r2862, 0
  %r2864 = inttoptr i64 %r2854 to ptr
  %r2865 = load i64, ptr %r2864, align 8
  %r2866 = and i1 %r2858, %r2863
  %r2867 = select i1 %r2866, i64 %r2865, i64 %r2854
  %r2868 = lshr i64 %r2867, 48
  %r2869 = icmp eq i64 %r2868, 0
  %r2870 = icmp ugt i64 %r2867, 1048575
  %r2871 = and i1 %r2869, %r2870
  br i1 %r2871, label %aidx.dynamic.guard.live.481, label %aidx.dynamic.fallback.477

aidx.dynamic.guard.live.481:                      ; preds = %aidx.dynamic.guard.deref.480
  %r2872 = sub nuw i64 %r2867, 8
  %r2873 = inttoptr i64 %r2872 to ptr
  %r2874 = load i8, ptr %r2873, align 1
  %r2875 = icmp eq i8 %r2874, 1
  %r2876 = sub nuw i64 %r2867, 7
  %r2877 = inttoptr i64 %r2876 to ptr
  %r2878 = load i8, ptr %r2877, align 1
  %r2879 = and i8 %r2878, -128
  %r2880 = icmp eq i8 %r2879, 0
  %r2881 = sub nuw i64 %r2867, 6
  %r2882 = inttoptr i64 %r2881 to ptr
  %r2883 = load i16, ptr %r2882, align 2
  %r2884 = and i16 %r2883, 1024
  %r2885 = icmp eq i16 %r2884, 0
  %r2886 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2887 = icmp eq i8 %r2886, 0
  %r2888 = inttoptr i64 %r2867 to ptr
  %r2889 = load i32, ptr %r2888, align 4
  %r2890 = getelementptr i8, ptr %r2888, i64 4
  %r2891 = load i32, ptr %r2890, align 4
  %r2892 = icmp slt i32 %r2846, 0
  %r2893 = icmp eq i1 %r2892, false
  %r2895 = icmp ule i32 %r2889, 16000000
  %r2896 = icmp ule i32 %r2891, 16000000
  %r2897 = icmp ule i32 %r2889, %r2891
  %r2898 = and i1 %r2875, %r2880
  %r2899 = and i1 %r2898, %r2885
  %r2900 = and i1 %r2899, %r2887
  %r2901 = and i1 %r2900, %r2893
  %r2902 = and i1 %r2901, %r2895
  %r2903 = and i1 %r2902, %r2896
  %r2904 = and i1 %r2903, %r2897
  br i1 %r2904, label %aidx.dynamic.guard.range.482, label %aidx.dynamic.fallback.477

aidx.dynamic.guard.range.482:                     ; preds = %aidx.dynamic.guard.live.481
  %r2894 = icmp ult i32 %r2846, %r2889
  br i1 %r2894, label %aidx.dynamic.fast.476, label %aidx.dynamic.guard.oob.478

dyncmp.num.483:                                   ; preds = %aidx.dynamic_merge.475
  %r2931 = fcmp oeq double %r2924, %r2922
  %r2932 = select i1 %r2931, i64 9222246136947933188, i64 9222246136947933187
  br label %dyncmp.merge.485

dyncmp.slow.484:                                  ; preds = %aidx.dynamic_merge.475
  %statepoint_token755 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i64)) @js_eq, i32 2, i32 0, i64 %r2923, i64 %r2925, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.91627, ptr addrspace(1) %.21650, ptr addrspace(1) %.371315, ptr addrspace(1) %.37, ptr addrspace(1) %.241495, ptr addrspace(1) %.371421, ptr addrspace(1) %.371368, ptr addrspace(1) %.241553) ]
  %r2933756 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token755)
  %r1053.1.relocated757 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token755, i32 0, i32 0) ; (%.91627, %.91627)
  %rs4gc.s43.relocated758 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token755, i32 1, i32 1) ; (%.21650, %.21650)
  %r48.0.base.relocated759 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token755, i32 2, i32 2) ; (%.371315, %.371315)
  %r55.0.base.relocated760 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token755, i32 3, i32 3) ; (%.37, %.37)
  %r1046.0.base.relocated761 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token755, i32 4, i32 4) ; (%.241495, %.241495)
  %r48.0.relocated762 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token755, i32 2, i32 5) ; (%.371315, %.371421)
  %r55.0.relocated763 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token755, i32 3, i32 6) ; (%.37, %.371368)
  %r1046.0.relocated764 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token755, i32 4, i32 7) ; (%.241495, %.241553)
  br label %dyncmp.merge.485

dyncmp.merge.485:                                 ; preds = %dyncmp.slow.484, %dyncmp.num.483
  %.41652 = phi ptr addrspace(1) [ %.21650, %dyncmp.num.483 ], [ %rs4gc.s43.relocated758, %dyncmp.slow.484 ]
  %.111629 = phi ptr addrspace(1) [ %.91627, %dyncmp.num.483 ], [ %r1053.1.relocated757, %dyncmp.slow.484 ]
  %.261555 = phi ptr addrspace(1) [ %.241553, %dyncmp.num.483 ], [ %r1046.0.relocated764, %dyncmp.slow.484 ]
  %.261497 = phi ptr addrspace(1) [ %.241495, %dyncmp.num.483 ], [ %r1046.0.base.relocated761, %dyncmp.slow.484 ]
  %.391423 = phi ptr addrspace(1) [ %.371421, %dyncmp.num.483 ], [ %r48.0.relocated762, %dyncmp.slow.484 ]
  %.391370 = phi ptr addrspace(1) [ %.371368, %dyncmp.num.483 ], [ %r55.0.relocated763, %dyncmp.slow.484 ]
  %.391317 = phi ptr addrspace(1) [ %.371315, %dyncmp.num.483 ], [ %r48.0.base.relocated759, %dyncmp.slow.484 ]
  %.39 = phi ptr addrspace(1) [ %.37, %dyncmp.num.483 ], [ %r55.0.base.relocated760, %dyncmp.slow.484 ]
  %r2934 = phi i64 [ %r2932, %dyncmp.num.483 ], [ %r2933756, %dyncmp.slow.484 ]
  %r2935 = icmp eq i64 %r2934, 9222246136947933188
  %r2936 = xor i1 %r2935, true
  %r2937 = select i1 %r2936, i64 9222246136947933188, i64 9222246136947933187
  %r2938 = bitcast i64 %r2937 to double
  %r2939 = icmp eq i64 %r2937, 9222246136947933188
  br i1 %r2939, label %if.then.486, label %if.else.487

if.then.486:                                      ; preds = %dyncmp.merge.485
  %r2940 = load double, ptr @test_json_source_token_length_ts_.str.16.handle, align 8
  %statepoint_token765 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_error_new_from_value, i32 1, i32 0, double %r2940, i32 0, i32 0)
  %r2941766 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token765)
  %r2942 = or i64 %r2941766, 9222527611924643840
  %r2943 = bitcast i64 %r2942 to double
  %statepoint_token767 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r2943, i32 0, i32 0)
  unreachable

if.else.487:                                      ; preds = %dyncmp.merge.485
  br label %if.merge.488

if.merge.488:                                     ; preds = %if.else.487
  %r2945.rs4i = ptrtoint ptr addrspace(1) %.391423 to i64
  %r2945.rs4o = call i64 asm "", "=r,0"(i64 %r2945.rs4i) #7
  %r2945 = bitcast i64 %r2945.rs4o to double
  %r2947 = fcmp oge double %r2598, 0.000000e+00
  %r2948 = fcmp ole double %r2598, 0x41DFFFFFFFC00000
  %r2949 = and i1 %r2947, %r2948
  %r2950 = select i1 %r2949, double %r2598, double 0.000000e+00
  %r2951 = fptosi double %r2950 to i32
  %r2952 = sitofp i32 %r2951 to double
  %r2953 = fcmp oeq double %r2952, %r2598
  %r2954 = and i1 %r2949, %r2953
  %r2955 = bitcast double %r2598 to i64
  %r2956 = lshr i64 %r2955, 48
  %r2957 = icmp eq i64 %r2956, 32766
  %r2958 = trunc i64 %r2955 to i32
  %r2959 = icmp sge i32 %r2958, 0
  %r2960 = and i1 %r2957, %r2959
  %r2961 = or i1 %r2954, %r2960
  %r2962 = select i1 %r2957, i32 %r2958, i32 %r2951
  br i1 %r2961, label %aidx.canonical.489, label %aidx.runtime_key.490

aidx.canonical.489:                               ; preds = %if.merge.488
  %r2963 = bitcast double %r2945 to i64
  %r2964 = and i64 %r2963, 281474976710655
  %r2965 = lshr i64 %r2963, 48
  %r2966 = icmp eq i64 %r2965, 32765
  %r2967 = icmp ugt i64 %r2964, 1048575
  %r2968 = and i1 %r2966, %r2967
  br i1 %r2968, label %aidx.dynamic.guard.deref.496, label %aidx.dynamic.fallback.493

aidx.runtime_key.490:                             ; preds = %if.merge.488
  %r3035 = bitcast double %r2945 to i64
  %r3036 = and i64 %r3035, 281474976710655
  %statepoint_token768 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_array_get_index_or_string, i32 2, i32 0, i64 %r3036, double %r2598, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.111629, ptr addrspace(1) %.41652, ptr addrspace(1) %.391317, ptr addrspace(1) %.39, ptr addrspace(1) %.261497, ptr addrspace(1) %.391423, ptr addrspace(1) %.391370, ptr addrspace(1) %.261555) ]
  %r3037769 = call double @llvm.experimental.gc.result.f64(token %statepoint_token768)
  %r1053.1.relocated770 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token768, i32 0, i32 0) ; (%.111629, %.111629)
  %rs4gc.s43.relocated771 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token768, i32 1, i32 1) ; (%.41652, %.41652)
  %r48.0.base.relocated772 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token768, i32 2, i32 2) ; (%.391317, %.391317)
  %r55.0.base.relocated773 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token768, i32 3, i32 3) ; (%.39, %.39)
  %r1046.0.base.relocated774 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token768, i32 4, i32 4) ; (%.261497, %.261497)
  %r48.0.relocated775 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token768, i32 2, i32 5) ; (%.391317, %.391423)
  %r55.0.relocated776 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token768, i32 3, i32 6) ; (%.39, %.391370)
  %r1046.0.relocated777 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token768, i32 4, i32 7) ; (%.261497, %.261555)
  br label %aidx.dynamic_merge.491

aidx.dynamic_merge.491:                           ; preds = %aidx.dynamic.merge.495, %aidx.runtime_key.490
  %.51653 = phi ptr addrspace(1) [ %.61654, %aidx.dynamic.merge.495 ], [ %rs4gc.s43.relocated771, %aidx.runtime_key.490 ]
  %.121630 = phi ptr addrspace(1) [ %.131631, %aidx.dynamic.merge.495 ], [ %r1053.1.relocated770, %aidx.runtime_key.490 ]
  %.271556 = phi ptr addrspace(1) [ %.281557, %aidx.dynamic.merge.495 ], [ %r1046.0.relocated777, %aidx.runtime_key.490 ]
  %.271498 = phi ptr addrspace(1) [ %.281499, %aidx.dynamic.merge.495 ], [ %r1046.0.base.relocated774, %aidx.runtime_key.490 ]
  %.401424 = phi ptr addrspace(1) [ %.411425, %aidx.dynamic.merge.495 ], [ %r48.0.relocated775, %aidx.runtime_key.490 ]
  %.401371 = phi ptr addrspace(1) [ %.411372, %aidx.dynamic.merge.495 ], [ %r55.0.relocated776, %aidx.runtime_key.490 ]
  %.401318 = phi ptr addrspace(1) [ %.411319, %aidx.dynamic.merge.495 ], [ %r48.0.base.relocated772, %aidx.runtime_key.490 ]
  %.40 = phi ptr addrspace(1) [ %.41, %aidx.dynamic.merge.495 ], [ %r55.0.base.relocated773, %aidx.runtime_key.490 ]
  %r3038 = phi double [ %r3034, %aidx.dynamic.merge.495 ], [ %r3037769, %aidx.runtime_key.490 ]
  %statepoint_token778 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r3038, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.121630, ptr addrspace(1) %.401318, ptr addrspace(1) %.40, ptr addrspace(1) %.271498, ptr addrspace(1) %.51653, ptr addrspace(1) %.401424, ptr addrspace(1) %.401371, ptr addrspace(1) %.271556) ]
  %r3039779 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token778)
  %r1053.1.relocated780 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token778, i32 0, i32 0) ; (%.121630, %.121630)
  %r48.0.base.relocated781 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token778, i32 1, i32 1) ; (%.401318, %.401318)
  %r55.0.base.relocated782 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token778, i32 2, i32 2) ; (%.40, %.40)
  %r1046.0.base.relocated783 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token778, i32 3, i32 3) ; (%.271498, %.271498)
  %rs4gc.s43.relocated784 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token778, i32 4, i32 4) ; (%.51653, %.51653)
  %r48.0.relocated785 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token778, i32 1, i32 5) ; (%.401318, %.401424)
  %r55.0.relocated786 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token778, i32 2, i32 6) ; (%.40, %.401371)
  %r1046.0.relocated787 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token778, i32 3, i32 7) ; (%.271498, %.271556)
  %statepoint_token788 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r3039779, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1053.1.relocated780, ptr addrspace(1) %r48.0.base.relocated781, ptr addrspace(1) %r55.0.base.relocated782, ptr addrspace(1) %r1046.0.base.relocated783, ptr addrspace(1) %rs4gc.s43.relocated784, ptr addrspace(1) %r48.0.relocated785, ptr addrspace(1) %r55.0.relocated786, ptr addrspace(1) %r1046.0.relocated787) ]
  %r3040789 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token788)
  %r1053.1.relocated790 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token788, i32 0, i32 0) ; (%r1053.1.relocated780, %r1053.1.relocated780)
  %r48.0.base.relocated791 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token788, i32 1, i32 1) ; (%r48.0.base.relocated781, %r48.0.base.relocated781)
  %r55.0.base.relocated792 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token788, i32 2, i32 2) ; (%r55.0.base.relocated782, %r55.0.base.relocated782)
  %r1046.0.base.relocated793 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token788, i32 3, i32 3) ; (%r1046.0.base.relocated783, %r1046.0.base.relocated783)
  %rs4gc.s43.relocated794 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token788, i32 4, i32 4) ; (%rs4gc.s43.relocated784, %rs4gc.s43.relocated784)
  %r48.0.relocated795 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token788, i32 1, i32 5) ; (%r48.0.base.relocated781, %r48.0.relocated785)
  %r55.0.relocated796 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token788, i32 2, i32 6) ; (%r55.0.base.relocated782, %r55.0.relocated786)
  %r1046.0.relocated797 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token788, i32 3, i32 7) ; (%r1046.0.base.relocated783, %r1046.0.relocated787)
  %r3041 = bitcast i64 %r3040789 to double
  %rs4gc.b45 = bitcast double %r3041 to i64
  %rs4gc.s45 = inttoptr i64 %rs4gc.b45 to ptr addrspace(1)
  %r3042.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s45 to i64
  %r3042 = call i64 asm "", "=r,0"(i64 %r3042.rs4i) #7
  %r3043 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3044 = icmp ne i32 %r3043, 0
  br i1 %r3044, label %shadow.root.barrier.499, label %shadow.root.barrier.done.500

aidx.dynamic.fast.492:                            ; preds = %aidx.dynamic.guard.range.498
  %r3024 = zext i32 %r2962 to i64
  %r3025 = shl nuw nsw i64 %r3024, 3
  %r3026 = add nuw nsw i64 %r3025, 8
  %r3027 = add i64 %r2983, %r3026
  %r3028 = inttoptr i64 %r3027 to ptr
  %r3029 = load double, ptr %r3028, align 8
  %r3030 = bitcast double %r3029 to i64
  %r3031 = icmp eq i64 %r3030, 9222246136947933200
  %r3033 = select i1 %r3031, double 0x7FFC000000000001, double %r3029
  br label %aidx.dynamic.merge.495

aidx.dynamic.fallback.493:                        ; preds = %aidx.dynamic.guard.live.497, %aidx.dynamic.guard.deref.496, %aidx.canonical.489
  %r3022 = sitofp i32 %r2962 to double
  %statepoint_token798 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 5587713372188573716, double %r2945, double %r3022, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.111629, ptr addrspace(1) %.41652, ptr addrspace(1) %.391317, ptr addrspace(1) %.39, ptr addrspace(1) %.261497, ptr addrspace(1) %.391423, ptr addrspace(1) %.391370, ptr addrspace(1) %.261555) ]
  %r3023799 = call double @llvm.experimental.gc.result.f64(token %statepoint_token798)
  %r1053.1.relocated800 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token798, i32 0, i32 0) ; (%.111629, %.111629)
  %rs4gc.s43.relocated801 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token798, i32 1, i32 1) ; (%.41652, %.41652)
  %r48.0.base.relocated802 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token798, i32 2, i32 2) ; (%.391317, %.391317)
  %r55.0.base.relocated803 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token798, i32 3, i32 3) ; (%.39, %.39)
  %r1046.0.base.relocated804 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token798, i32 4, i32 4) ; (%.261497, %.261497)
  %r48.0.relocated805 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token798, i32 2, i32 5) ; (%.391317, %.391423)
  %r55.0.relocated806 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token798, i32 3, i32 6) ; (%.39, %.391370)
  %r1046.0.relocated807 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token798, i32 4, i32 7) ; (%.261497, %.261555)
  br label %aidx.dynamic.merge.495

aidx.dynamic.guard.oob.494:                       ; preds = %aidx.dynamic.guard.range.498
  br label %aidx.dynamic.merge.495

aidx.dynamic.merge.495:                           ; preds = %aidx.dynamic.guard.oob.494, %aidx.dynamic.fallback.493, %aidx.dynamic.fast.492
  %.61654 = phi ptr addrspace(1) [ %.41652, %aidx.dynamic.fast.492 ], [ %.41652, %aidx.dynamic.guard.oob.494 ], [ %rs4gc.s43.relocated801, %aidx.dynamic.fallback.493 ]
  %.131631 = phi ptr addrspace(1) [ %.111629, %aidx.dynamic.fast.492 ], [ %.111629, %aidx.dynamic.guard.oob.494 ], [ %r1053.1.relocated800, %aidx.dynamic.fallback.493 ]
  %.281557 = phi ptr addrspace(1) [ %.261555, %aidx.dynamic.fast.492 ], [ %.261555, %aidx.dynamic.guard.oob.494 ], [ %r1046.0.relocated807, %aidx.dynamic.fallback.493 ]
  %.281499 = phi ptr addrspace(1) [ %.261497, %aidx.dynamic.fast.492 ], [ %.261497, %aidx.dynamic.guard.oob.494 ], [ %r1046.0.base.relocated804, %aidx.dynamic.fallback.493 ]
  %.411425 = phi ptr addrspace(1) [ %.391423, %aidx.dynamic.fast.492 ], [ %.391423, %aidx.dynamic.guard.oob.494 ], [ %r48.0.relocated805, %aidx.dynamic.fallback.493 ]
  %.411372 = phi ptr addrspace(1) [ %.391370, %aidx.dynamic.fast.492 ], [ %.391370, %aidx.dynamic.guard.oob.494 ], [ %r55.0.relocated806, %aidx.dynamic.fallback.493 ]
  %.411319 = phi ptr addrspace(1) [ %.391317, %aidx.dynamic.fast.492 ], [ %.391317, %aidx.dynamic.guard.oob.494 ], [ %r48.0.base.relocated802, %aidx.dynamic.fallback.493 ]
  %.41 = phi ptr addrspace(1) [ %.39, %aidx.dynamic.fast.492 ], [ %.39, %aidx.dynamic.guard.oob.494 ], [ %r55.0.base.relocated803, %aidx.dynamic.fallback.493 ]
  %r3034 = phi double [ %r3033, %aidx.dynamic.fast.492 ], [ %r3023799, %aidx.dynamic.fallback.493 ], [ 0x7FFC000000000001, %aidx.dynamic.guard.oob.494 ]
  br label %aidx.dynamic_merge.491

aidx.dynamic.guard.deref.496:                     ; preds = %aidx.canonical.489
  %r2969 = bitcast double %r2945 to i64
  %r2970 = and i64 %r2969, 281474976710655
  %r2971 = sub nsw i64 %r2970, 8
  %r2972 = inttoptr i64 %r2971 to ptr
  %r2973 = load i8, ptr %r2972, align 1
  %r2974 = icmp eq i8 %r2973, 1
  %r2975 = sub nsw i64 %r2970, 7
  %r2976 = inttoptr i64 %r2975 to ptr
  %r2977 = load i8, ptr %r2976, align 1
  %r2978 = and i8 %r2977, -128
  %r2979 = icmp ne i8 %r2978, 0
  %r2980 = inttoptr i64 %r2970 to ptr
  %r2981 = load i64, ptr %r2980, align 8
  %r2982 = and i1 %r2974, %r2979
  %r2983 = select i1 %r2982, i64 %r2981, i64 %r2970
  %r2984 = lshr i64 %r2983, 48
  %r2985 = icmp eq i64 %r2984, 0
  %r2986 = icmp ugt i64 %r2983, 1048575
  %r2987 = and i1 %r2985, %r2986
  br i1 %r2987, label %aidx.dynamic.guard.live.497, label %aidx.dynamic.fallback.493

aidx.dynamic.guard.live.497:                      ; preds = %aidx.dynamic.guard.deref.496
  %r2988 = sub nuw i64 %r2983, 8
  %r2989 = inttoptr i64 %r2988 to ptr
  %r2990 = load i8, ptr %r2989, align 1
  %r2991 = icmp eq i8 %r2990, 1
  %r2992 = sub nuw i64 %r2983, 7
  %r2993 = inttoptr i64 %r2992 to ptr
  %r2994 = load i8, ptr %r2993, align 1
  %r2995 = and i8 %r2994, -128
  %r2996 = icmp eq i8 %r2995, 0
  %r2997 = sub nuw i64 %r2983, 6
  %r2998 = inttoptr i64 %r2997 to ptr
  %r2999 = load i16, ptr %r2998, align 2
  %r3000 = and i16 %r2999, 1024
  %r3001 = icmp eq i16 %r3000, 0
  %r3002 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r3003 = icmp eq i8 %r3002, 0
  %r3004 = inttoptr i64 %r2983 to ptr
  %r3005 = load i32, ptr %r3004, align 4
  %r3006 = getelementptr i8, ptr %r3004, i64 4
  %r3007 = load i32, ptr %r3006, align 4
  %r3008 = icmp slt i32 %r2962, 0
  %r3009 = icmp eq i1 %r3008, false
  %r3011 = icmp ule i32 %r3005, 16000000
  %r3012 = icmp ule i32 %r3007, 16000000
  %r3013 = icmp ule i32 %r3005, %r3007
  %r3014 = and i1 %r2991, %r2996
  %r3015 = and i1 %r3014, %r3001
  %r3016 = and i1 %r3015, %r3003
  %r3017 = and i1 %r3016, %r3009
  %r3018 = and i1 %r3017, %r3011
  %r3019 = and i1 %r3018, %r3012
  %r3020 = and i1 %r3019, %r3013
  br i1 %r3020, label %aidx.dynamic.guard.range.498, label %aidx.dynamic.fallback.493

aidx.dynamic.guard.range.498:                     ; preds = %aidx.dynamic.guard.live.497
  %r3010 = icmp ult i32 %r2962, %r3005
  br i1 %r3010, label %aidx.dynamic.fast.492, label %aidx.dynamic.guard.oob.494

shadow.root.barrier.499:                          ; preds = %aidx.dynamic_merge.491
  call void @js_write_barrier_root_nanbox(i64 %r3042) #7
  br label %shadow.root.barrier.done.500

shadow.root.barrier.done.500:                     ; preds = %shadow.root.barrier.499, %aidx.dynamic_merge.491
  %r3045.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s45 to i64
  %r3045.rs4o = call i64 asm "", "=r,0"(i64 %r3045.rs4i) #7
  %r3045 = bitcast i64 %r3045.rs4o to double
  %r3046 = bitcast double %r3045 to i64
  %r3047 = and i64 %r3046, 281474976710655
  %r3048 = lshr i64 %r3046, 48
  %r3049 = and i64 %r3048, 65533
  %r3050 = icmp eq i64 %r3049, 32765
  br i1 %r3050, label %pget.recv_ok.502, label %pget.recv_other.506

pget.recv_sso.501:                                ; preds = %pget.recv_other.506
  %r3188 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r3189 = bitcast double %r3188 to i64
  %r3190 = and i64 %r3189, 281474976710655
  %statepoint_token808 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3046, i64 %r3190, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s45, ptr addrspace(1) %r1053.1.relocated790, ptr addrspace(1) %r48.0.base.relocated791, ptr addrspace(1) %r55.0.base.relocated792, ptr addrspace(1) %r1046.0.base.relocated793, ptr addrspace(1) %rs4gc.s43.relocated794, ptr addrspace(1) %r48.0.relocated795, ptr addrspace(1) %r55.0.relocated796, ptr addrspace(1) %r1046.0.relocated797) ]
  %r3191809 = call double @llvm.experimental.gc.result.f64(token %statepoint_token808)
  %rs4gc.s45.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token808, i32 0, i32 0) ; (%rs4gc.s45, %rs4gc.s45)
  %r1053.1.relocated810 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token808, i32 1, i32 1) ; (%r1053.1.relocated790, %r1053.1.relocated790)
  %r48.0.base.relocated811 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token808, i32 2, i32 2) ; (%r48.0.base.relocated791, %r48.0.base.relocated791)
  %r55.0.base.relocated812 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token808, i32 3, i32 3) ; (%r55.0.base.relocated792, %r55.0.base.relocated792)
  %r1046.0.base.relocated813 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token808, i32 4, i32 4) ; (%r1046.0.base.relocated793, %r1046.0.base.relocated793)
  %rs4gc.s43.relocated814 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token808, i32 5, i32 5) ; (%rs4gc.s43.relocated794, %rs4gc.s43.relocated794)
  %r48.0.relocated815 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token808, i32 2, i32 6) ; (%r48.0.base.relocated791, %r48.0.relocated795)
  %r55.0.relocated816 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token808, i32 3, i32 7) ; (%r55.0.base.relocated792, %r55.0.relocated796)
  %r1046.0.relocated817 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token808, i32 4, i32 8) ; (%r1046.0.base.relocated793, %r1046.0.relocated797)
  br label %pget.recv_merge.505

pget.recv_ok.502:                                 ; preds = %shadow.root.barrier.done.500
  %r3057 = icmp ugt i64 %r3047, 1048575
  br i1 %r3057, label %pic.recv_hdr.523, label %pic.miss.cold.520

pget.recv_bad.503:                                ; preds = %pget.check_class_ref.507
  %r3180 = icmp eq i64 %r3046, 9222246136947933185
  %r3181 = icmp eq i64 %r3046, 9222246136947933186
  %r3182 = or i1 %r3180, %r3181
  br i1 %r3182, label %pget.throw_nullish.530, label %pget.recv_undef_return.531

pget.recv_class_ref.504:                          ; preds = %pget.check_class_ref.507
  %r3053 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r3054 = bitcast double %r3053 to i64
  %r3055 = and i64 %r3054, 281474976710655
  %statepoint_token818 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 5587713372188573717, i64 %r3046, i64 %r3055, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s45, ptr addrspace(1) %r1053.1.relocated790, ptr addrspace(1) %r48.0.base.relocated791, ptr addrspace(1) %r55.0.base.relocated792, ptr addrspace(1) %r1046.0.base.relocated793, ptr addrspace(1) %rs4gc.s43.relocated794, ptr addrspace(1) %r48.0.relocated795, ptr addrspace(1) %r55.0.relocated796, ptr addrspace(1) %r1046.0.relocated797) ]
  %r3056819 = call double @llvm.experimental.gc.result.f64(token %statepoint_token818)
  %rs4gc.s45.relocated820 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token818, i32 0, i32 0) ; (%rs4gc.s45, %rs4gc.s45)
  %r1053.1.relocated821 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token818, i32 1, i32 1) ; (%r1053.1.relocated790, %r1053.1.relocated790)
  %r48.0.base.relocated822 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token818, i32 2, i32 2) ; (%r48.0.base.relocated791, %r48.0.base.relocated791)
  %r55.0.base.relocated823 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token818, i32 3, i32 3) ; (%r55.0.base.relocated792, %r55.0.base.relocated792)
  %r1046.0.base.relocated824 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token818, i32 4, i32 4) ; (%r1046.0.base.relocated793, %r1046.0.base.relocated793)
  %rs4gc.s43.relocated825 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token818, i32 5, i32 5) ; (%rs4gc.s43.relocated794, %rs4gc.s43.relocated794)
  %r48.0.relocated826 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token818, i32 2, i32 6) ; (%r48.0.base.relocated791, %r48.0.relocated795)
  %r55.0.relocated827 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token818, i32 3, i32 7) ; (%r55.0.base.relocated792, %r55.0.relocated796)
  %r1046.0.relocated828 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token818, i32 4, i32 8) ; (%r1046.0.base.relocated793, %r1046.0.relocated797)
  br label %pget.recv_merge.505

pget.recv_merge.505:                              ; preds = %pget.recv_undef_return.531, %pic.merge.522, %pget.recv_class_ref.504, %pget.recv_sso.501
  %.01659 = phi ptr addrspace(1) [ %.11660, %pic.merge.522 ], [ %rs4gc.s45.relocated, %pget.recv_sso.501 ], [ %rs4gc.s45.relocated820, %pget.recv_class_ref.504 ], [ %rs4gc.s45.relocated854, %pget.recv_undef_return.531 ]
  %.71655 = phi ptr addrspace(1) [ %.81656, %pic.merge.522 ], [ %rs4gc.s43.relocated814, %pget.recv_sso.501 ], [ %rs4gc.s43.relocated825, %pget.recv_class_ref.504 ], [ %rs4gc.s43.relocated859, %pget.recv_undef_return.531 ]
  %.141632 = phi ptr addrspace(1) [ %.151633, %pic.merge.522 ], [ %r1053.1.relocated810, %pget.recv_sso.501 ], [ %r1053.1.relocated821, %pget.recv_class_ref.504 ], [ %r1053.1.relocated855, %pget.recv_undef_return.531 ]
  %.291558 = phi ptr addrspace(1) [ %.301559, %pic.merge.522 ], [ %r1046.0.relocated817, %pget.recv_sso.501 ], [ %r1046.0.relocated828, %pget.recv_class_ref.504 ], [ %r1046.0.relocated862, %pget.recv_undef_return.531 ]
  %.291500 = phi ptr addrspace(1) [ %.301501, %pic.merge.522 ], [ %r1046.0.base.relocated813, %pget.recv_sso.501 ], [ %r1046.0.base.relocated824, %pget.recv_class_ref.504 ], [ %r1046.0.base.relocated858, %pget.recv_undef_return.531 ]
  %.421426 = phi ptr addrspace(1) [ %.431427, %pic.merge.522 ], [ %r48.0.relocated815, %pget.recv_sso.501 ], [ %r48.0.relocated826, %pget.recv_class_ref.504 ], [ %r48.0.relocated860, %pget.recv_undef_return.531 ]
  %.421373 = phi ptr addrspace(1) [ %.431374, %pic.merge.522 ], [ %r55.0.relocated816, %pget.recv_sso.501 ], [ %r55.0.relocated827, %pget.recv_class_ref.504 ], [ %r55.0.relocated861, %pget.recv_undef_return.531 ]
  %.421320 = phi ptr addrspace(1) [ %.431321, %pic.merge.522 ], [ %r48.0.base.relocated811, %pget.recv_sso.501 ], [ %r48.0.base.relocated822, %pget.recv_class_ref.504 ], [ %r48.0.base.relocated856, %pget.recv_undef_return.531 ]
  %.42 = phi ptr addrspace(1) [ %.43, %pic.merge.522 ], [ %r55.0.base.relocated812, %pget.recv_sso.501 ], [ %r55.0.base.relocated823, %pget.recv_class_ref.504 ], [ %r55.0.base.relocated857, %pget.recv_undef_return.531 ]
  %r3192 = phi double [ %r3179, %pic.merge.522 ], [ %r3187853, %pget.recv_undef_return.531 ], [ %r3191809, %pget.recv_sso.501 ], [ %r3056819, %pget.recv_class_ref.504 ]
  %r3193 = bitcast double %r3192 to i64
  %rs4gc.s46 = inttoptr i64 %r3193 to ptr addrspace(1)
  %r3194.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s46 to i64
  %r3194 = call i64 asm "", "=r,0"(i64 %r3194.rs4i) #7
  %r3195 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3196 = icmp ne i32 %r3195, 0
  br i1 %r3196, label %shadow.root.barrier.532, label %shadow.root.barrier.done.533

pget.recv_other.506:                              ; preds = %shadow.root.barrier.done.500
  %r3051 = icmp eq i64 %r3048, 32761
  br i1 %r3051, label %pget.recv_sso.501, label %pget.check_class_ref.507

pget.check_class_ref.507:                         ; preds = %pget.recv_other.506
  %r3052 = icmp eq i64 %r3048, 32766
  br i1 %r3052, label %pget.recv_class_ref.504, label %pget.recv_bad.503

pic.hit.508:                                      ; preds = %pic.token.524
  %r3082 = getelementptr i64, ptr %r3067, i64 1
  %r3083 = load i64, ptr %r3082, align 8
  %r3084 = and i64 %r3083, 1073741824
  %r3085 = icmp ne i64 %r3084, 0
  br i1 %r3085, label %pic.hit.overflow.525, label %pic.hit.inline.526

pic.hit.live.509:                                 ; preds = %pic.hit.inline.526
  br label %pic.merge.522

pic.prefix.guard.510:                             ; preds = %pic.token.524
  %r3098 = getelementptr i64, ptr %r3067, i64 2
  %r3099 = load i64, ptr %r3098, align 8
  %r3100 = icmp ne i64 %r3099, 0
  br i1 %r3100, label %pic.prefix.meta.511, label %pic.miss.519

pic.prefix.meta.511:                              ; preds = %pic.prefix.guard.510
  %r3101 = add nuw nsw i64 %r3047, 8
  %r3102 = inttoptr i64 %r3101 to ptr
  %r3103 = load i64, ptr %r3102, align 8
  %r3104 = icmp ne i64 %r3103, 0
  br i1 %r3104, label %pic.prefix.token.512, label %pic.miss.519

pic.prefix.token.512:                             ; preds = %pic.prefix.meta.511
  %r3105 = inttoptr i64 %r3103 to ptr
  %r3106 = getelementptr i64, ptr %r3105, i64 6
  %r3107 = load i64, ptr %r3106, align 8
  %r3108 = icmp eq i64 %r3107, %r3099
  br i1 %r3108, label %pic.prefix.hit.513, label %pic.miss.519

pic.prefix.hit.513:                               ; preds = %pic.prefix.token.512
  %r3109 = getelementptr i64, ptr %r3067, i64 1
  %r3110 = load i64, ptr %r3109, align 8
  %r3111 = shl i64 %r3110, 3
  %r3112 = add nuw nsw i64 %r3047, 16
  %r3113 = add i64 %r3112, %r3111
  %r3114 = inttoptr i64 %r3113 to ptr
  %r3115 = load double, ptr %r3114, align 8
  br label %pic.merge.522

pic.desc.classify.514:                            ; preds = %pic.recv_hdr.523
  %r3071 = and i1 %r3061, %r3068
  br i1 %r3071, label %pic.desc.prefix.guard.515, label %pic.miss.cold.520

pic.desc.prefix.guard.515:                        ; preds = %pic.desc.classify.514
  %r3116 = getelementptr i64, ptr %r3067, i64 2
  %r3117 = load i64, ptr %r3116, align 8
  %r3118 = icmp ne i64 %r3117, 0
  br i1 %r3118, label %pic.desc.prefix.meta.516, label %pic.miss.cold.520

pic.desc.prefix.meta.516:                         ; preds = %pic.desc.prefix.guard.515
  %r3119 = add nuw nsw i64 %r3047, 8
  %r3120 = inttoptr i64 %r3119 to ptr
  %r3121 = load i64, ptr %r3120, align 8
  %r3122 = icmp ne i64 %r3121, 0
  br i1 %r3122, label %pic.desc.prefix.token.517, label %pic.miss.cold.520

pic.desc.prefix.token.517:                        ; preds = %pic.desc.prefix.meta.516
  %r3123 = inttoptr i64 %r3121 to ptr
  %r3124 = getelementptr i64, ptr %r3123, i64 6
  %r3125 = load i64, ptr %r3124, align 8
  %r3126 = icmp eq i64 %r3125, %r3117
  br i1 %r3126, label %pic.desc.prefix.hit.518, label %pic.miss.cold.520

pic.desc.prefix.hit.518:                          ; preds = %pic.desc.prefix.token.517
  %r3127 = getelementptr i64, ptr %r3067, i64 1
  %r3128 = load i64, ptr %r3127, align 8
  %r3129 = shl i64 %r3128, 3
  %r3130 = add nuw nsw i64 %r3047, 16
  %r3131 = add i64 %r3130, %r3129
  %r3132 = inttoptr i64 %r3131 to ptr
  %r3133 = load double, ptr %r3132, align 8
  br label %pic.merge.522

pic.miss.519:                                     ; preds = %pic.hit.inline.526, %pic.prefix.token.512, %pic.prefix.meta.511, %pic.prefix.guard.510
  %r3134 = getelementptr i64, ptr %r3067, i64 3
  %r3135 = load i64, ptr %r3134, align 8
  %r3136 = icmp sgt i64 %r3135, 0
  br i1 %r3136, label %pic.ways.527, label %pic.miss.call.521

pic.miss.cold.520:                                ; preds = %pic.desc.prefix.token.517, %pic.desc.prefix.meta.516, %pic.desc.prefix.guard.515, %pic.desc.classify.514, %pget.recv_ok.502
  br label %pic.miss.call.521

pic.miss.call.521:                                ; preds = %pic.way.load.528, %pic.ways.527, %pic.miss.cold.520, %pic.miss.519
  %r3175 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r3176 = bitcast double %r3175 to i64
  %r3177 = and i64 %r3176, 281474976710655
  %statepoint_token829 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r3047, i64 %r3177, ptr @perry_ic_test_json_source_token_length_ts__22, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s45, ptr addrspace(1) %r1053.1.relocated790, ptr addrspace(1) %r48.0.base.relocated791, ptr addrspace(1) %r55.0.base.relocated792, ptr addrspace(1) %r1046.0.base.relocated793, ptr addrspace(1) %rs4gc.s43.relocated794, ptr addrspace(1) %r48.0.relocated795, ptr addrspace(1) %r55.0.relocated796, ptr addrspace(1) %r1046.0.relocated797) ]
  %r3178830 = call double @llvm.experimental.gc.result.f64(token %statepoint_token829)
  %rs4gc.s45.relocated831 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token829, i32 0, i32 0) ; (%rs4gc.s45, %rs4gc.s45)
  %r1053.1.relocated832 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token829, i32 1, i32 1) ; (%r1053.1.relocated790, %r1053.1.relocated790)
  %r48.0.base.relocated833 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token829, i32 2, i32 2) ; (%r48.0.base.relocated791, %r48.0.base.relocated791)
  %r55.0.base.relocated834 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token829, i32 3, i32 3) ; (%r55.0.base.relocated792, %r55.0.base.relocated792)
  %r1046.0.base.relocated835 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token829, i32 4, i32 4) ; (%r1046.0.base.relocated793, %r1046.0.base.relocated793)
  %rs4gc.s43.relocated836 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token829, i32 5, i32 5) ; (%rs4gc.s43.relocated794, %rs4gc.s43.relocated794)
  %r48.0.relocated837 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token829, i32 2, i32 6) ; (%r48.0.base.relocated791, %r48.0.relocated795)
  %r55.0.relocated838 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token829, i32 3, i32 7) ; (%r55.0.base.relocated792, %r55.0.relocated796)
  %r1046.0.relocated839 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token829, i32 4, i32 8) ; (%r1046.0.base.relocated793, %r1046.0.relocated797)
  br label %pic.merge.522

pic.merge.522:                                    ; preds = %pic.way.live.529, %pic.hit.overflow.525, %pic.miss.call.521, %pic.desc.prefix.hit.518, %pic.prefix.hit.513, %pic.hit.live.509
  %.11660 = phi ptr addrspace(1) [ %rs4gc.s45.relocated842, %pic.hit.overflow.525 ], [ %rs4gc.s45.relocated831, %pic.miss.call.521 ], [ %rs4gc.s45, %pic.way.live.529 ], [ %rs4gc.s45, %pic.hit.live.509 ], [ %rs4gc.s45, %pic.prefix.hit.513 ], [ %rs4gc.s45, %pic.desc.prefix.hit.518 ]
  %.81656 = phi ptr addrspace(1) [ %rs4gc.s43.relocated847, %pic.hit.overflow.525 ], [ %rs4gc.s43.relocated836, %pic.miss.call.521 ], [ %rs4gc.s43.relocated794, %pic.way.live.529 ], [ %rs4gc.s43.relocated794, %pic.hit.live.509 ], [ %rs4gc.s43.relocated794, %pic.prefix.hit.513 ], [ %rs4gc.s43.relocated794, %pic.desc.prefix.hit.518 ]
  %.151633 = phi ptr addrspace(1) [ %r1053.1.relocated843, %pic.hit.overflow.525 ], [ %r1053.1.relocated832, %pic.miss.call.521 ], [ %r1053.1.relocated790, %pic.way.live.529 ], [ %r1053.1.relocated790, %pic.hit.live.509 ], [ %r1053.1.relocated790, %pic.prefix.hit.513 ], [ %r1053.1.relocated790, %pic.desc.prefix.hit.518 ]
  %.301559 = phi ptr addrspace(1) [ %r1046.0.relocated850, %pic.hit.overflow.525 ], [ %r1046.0.relocated839, %pic.miss.call.521 ], [ %r1046.0.relocated797, %pic.way.live.529 ], [ %r1046.0.relocated797, %pic.hit.live.509 ], [ %r1046.0.relocated797, %pic.prefix.hit.513 ], [ %r1046.0.relocated797, %pic.desc.prefix.hit.518 ]
  %.301501 = phi ptr addrspace(1) [ %r1046.0.base.relocated846, %pic.hit.overflow.525 ], [ %r1046.0.base.relocated835, %pic.miss.call.521 ], [ %r1046.0.base.relocated793, %pic.way.live.529 ], [ %r1046.0.base.relocated793, %pic.hit.live.509 ], [ %r1046.0.base.relocated793, %pic.prefix.hit.513 ], [ %r1046.0.base.relocated793, %pic.desc.prefix.hit.518 ]
  %.431427 = phi ptr addrspace(1) [ %r48.0.relocated848, %pic.hit.overflow.525 ], [ %r48.0.relocated837, %pic.miss.call.521 ], [ %r48.0.relocated795, %pic.way.live.529 ], [ %r48.0.relocated795, %pic.hit.live.509 ], [ %r48.0.relocated795, %pic.prefix.hit.513 ], [ %r48.0.relocated795, %pic.desc.prefix.hit.518 ]
  %.431374 = phi ptr addrspace(1) [ %r55.0.relocated849, %pic.hit.overflow.525 ], [ %r55.0.relocated838, %pic.miss.call.521 ], [ %r55.0.relocated796, %pic.way.live.529 ], [ %r55.0.relocated796, %pic.hit.live.509 ], [ %r55.0.relocated796, %pic.prefix.hit.513 ], [ %r55.0.relocated796, %pic.desc.prefix.hit.518 ]
  %.431321 = phi ptr addrspace(1) [ %r48.0.base.relocated844, %pic.hit.overflow.525 ], [ %r48.0.base.relocated833, %pic.miss.call.521 ], [ %r48.0.base.relocated791, %pic.way.live.529 ], [ %r48.0.base.relocated791, %pic.hit.live.509 ], [ %r48.0.base.relocated791, %pic.prefix.hit.513 ], [ %r48.0.base.relocated791, %pic.desc.prefix.hit.518 ]
  %.43 = phi ptr addrspace(1) [ %r55.0.base.relocated845, %pic.hit.overflow.525 ], [ %r55.0.base.relocated834, %pic.miss.call.521 ], [ %r55.0.base.relocated792, %pic.way.live.529 ], [ %r55.0.base.relocated792, %pic.hit.live.509 ], [ %r55.0.base.relocated792, %pic.prefix.hit.513 ], [ %r55.0.base.relocated792, %pic.desc.prefix.hit.518 ]
  %r3179 = phi double [ %r3095, %pic.hit.live.509 ], [ %r3090841, %pic.hit.overflow.525 ], [ %r3115, %pic.prefix.hit.513 ], [ %r3133, %pic.desc.prefix.hit.518 ], [ %r3172, %pic.way.live.529 ], [ %r3178830, %pic.miss.call.521 ]
  br label %pget.recv_merge.505

pic.recv_hdr.523:                                 ; preds = %pget.recv_ok.502
  %r3058 = sub nuw nsw i64 %r3047, 8
  %r3059 = inttoptr i64 %r3058 to ptr
  %r3060 = load i8, ptr %r3059, align 1
  %r3061 = icmp eq i8 %r3060, 2
  %r3062 = sub nuw nsw i64 %r3047, 6
  %r3063 = inttoptr i64 %r3062 to ptr
  %r3064 = load i16, ptr %r3063, align 2
  %r3065 = and i16 %r3064, 2048
  %r3066 = icmp eq i16 %r3065, 0
  %r3067 = load ptr, ptr @perry_ic_test_json_source_token_length_ts__22, align 8
  %r3068 = icmp ne ptr %r3067, null
  %r3069 = and i1 %r3061, %r3066
  %r3070 = and i1 %r3069, %r3068
  br i1 %r3070, label %pic.token.524, label %pic.desc.classify.514

pic.token.524:                                    ; preds = %pic.recv_hdr.523
  %r3072 = add nuw nsw i64 %r3047, 4
  %r3073 = inttoptr i64 %r3072 to ptr
  %r3074 = load i32, ptr %r3073, align 4
  %r3075 = zext i32 %r3074 to i64
  %r3076 = or i64 %r3075, 4611686018427387904
  %r3077 = icmp ne i32 %r3074, 0
  %r3078 = getelementptr i64, ptr %r3067, i64 0
  %r3079 = load i64, ptr %r3078, align 8
  %r3080 = icmp eq i64 %r3076, %r3079
  %r3081 = and i1 %r3080, %r3077
  br i1 %r3081, label %pic.hit.508, label %pic.prefix.guard.510

pic.hit.overflow.525:                             ; preds = %pic.hit.508
  %r3086 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r3087 = bitcast double %r3086 to i64
  %r3088 = and i64 %r3087, 281474976710655
  %r3089 = trunc i64 %r3083 to i32
  %statepoint_token840 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r3047, i64 %r3088, i32 %r3089, ptr @perry_ic_test_json_source_token_length_ts__22, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s45, ptr addrspace(1) %r1053.1.relocated790, ptr addrspace(1) %r48.0.base.relocated791, ptr addrspace(1) %r55.0.base.relocated792, ptr addrspace(1) %r1046.0.base.relocated793, ptr addrspace(1) %rs4gc.s43.relocated794, ptr addrspace(1) %r48.0.relocated795, ptr addrspace(1) %r55.0.relocated796, ptr addrspace(1) %r1046.0.relocated797) ]
  %r3090841 = call double @llvm.experimental.gc.result.f64(token %statepoint_token840)
  %rs4gc.s45.relocated842 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token840, i32 0, i32 0) ; (%rs4gc.s45, %rs4gc.s45)
  %r1053.1.relocated843 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token840, i32 1, i32 1) ; (%r1053.1.relocated790, %r1053.1.relocated790)
  %r48.0.base.relocated844 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token840, i32 2, i32 2) ; (%r48.0.base.relocated791, %r48.0.base.relocated791)
  %r55.0.base.relocated845 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token840, i32 3, i32 3) ; (%r55.0.base.relocated792, %r55.0.base.relocated792)
  %r1046.0.base.relocated846 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token840, i32 4, i32 4) ; (%r1046.0.base.relocated793, %r1046.0.base.relocated793)
  %rs4gc.s43.relocated847 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token840, i32 5, i32 5) ; (%rs4gc.s43.relocated794, %rs4gc.s43.relocated794)
  %r48.0.relocated848 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token840, i32 2, i32 6) ; (%r48.0.base.relocated791, %r48.0.relocated795)
  %r55.0.relocated849 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token840, i32 3, i32 7) ; (%r55.0.base.relocated792, %r55.0.relocated796)
  %r1046.0.relocated850 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token840, i32 4, i32 8) ; (%r1046.0.base.relocated793, %r1046.0.relocated797)
  br label %pic.merge.522

pic.hit.inline.526:                               ; preds = %pic.hit.508
  %r3091 = shl i64 %r3083, 3
  %r3092 = add nuw nsw i64 %r3047, 16
  %r3093 = add i64 %r3092, %r3091
  %r3094 = inttoptr i64 %r3093 to ptr
  %r3095 = load double, ptr %r3094, align 8
  %r3096 = bitcast double %r3095 to i64
  %r3097 = icmp eq i64 %r3096, 9222246136947933200
  br i1 %r3097, label %pic.miss.519, label %pic.hit.live.509

pic.ways.527:                                     ; preds = %pic.miss.519
  %r3137 = getelementptr i64, ptr %r3067, i64 4
  %r3138 = load i64, ptr %r3137, align 8
  %r3139 = icmp eq i64 %r3138, %r3076
  %r3140 = getelementptr i64, ptr %r3067, i64 5
  %r3141 = load i64, ptr %r3140, align 8
  %r3142 = select i1 %r3139, i64 %r3141, i64 0
  %r3143 = getelementptr i64, ptr %r3067, i64 6
  %r3144 = load i64, ptr %r3143, align 8
  %r3145 = icmp eq i64 %r3144, %r3076
  %r3146 = getelementptr i64, ptr %r3067, i64 7
  %r3147 = load i64, ptr %r3146, align 8
  %r3148 = select i1 %r3145, i64 %r3147, i64 0
  %r3149 = getelementptr i64, ptr %r3067, i64 8
  %r3150 = load i64, ptr %r3149, align 8
  %r3151 = icmp eq i64 %r3150, %r3076
  %r3152 = getelementptr i64, ptr %r3067, i64 9
  %r3153 = load i64, ptr %r3152, align 8
  %r3154 = select i1 %r3151, i64 %r3153, i64 0
  %r3155 = getelementptr i64, ptr %r3067, i64 10
  %r3156 = load i64, ptr %r3155, align 8
  %r3157 = icmp eq i64 %r3156, %r3076
  %r3158 = getelementptr i64, ptr %r3067, i64 11
  %r3159 = load i64, ptr %r3158, align 8
  %r3160 = select i1 %r3157, i64 %r3159, i64 0
  %r3161 = or i1 %r3139, %r3145
  %r3162 = select i1 %r3139, i64 %r3142, i64 %r3148
  %r3163 = or i1 %r3151, %r3157
  %r3164 = select i1 %r3151, i64 %r3154, i64 %r3160
  %r3165 = or i1 %r3161, %r3163
  %r3166 = select i1 %r3161, i64 %r3162, i64 %r3164
  %r3167 = and i1 %r3077, %r3165
  br i1 %r3167, label %pic.way.load.528, label %pic.miss.call.521

pic.way.load.528:                                 ; preds = %pic.ways.527
  %r3168 = shl i64 %r3166, 3
  %r3169 = add nuw nsw i64 %r3047, 16
  %r3170 = add i64 %r3169, %r3168
  %r3171 = inttoptr i64 %r3170 to ptr
  %r3172 = load double, ptr %r3171, align 8
  %r3173 = bitcast double %r3172 to i64
  %r3174 = icmp eq i64 %r3173, 9222246136947933200
  br i1 %r3174, label %pic.miss.call.521, label %pic.way.live.529

pic.way.live.529:                                 ; preds = %pic.way.load.528
  br label %pic.merge.522

pget.throw_nullish.530:                           ; preds = %pget.recv_bad.503
  %r3183 = zext i1 %r3181 to i32
  %statepoint_token851 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r3183, ptr @test_json_source_token_length_ts_.str.10.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.531:                       ; preds = %pget.recv_bad.503
  %r3184 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r3185 = bitcast double %r3184 to i64
  %r3186 = and i64 %r3185, 281474976710655
  %statepoint_token852 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3046, i64 %r3186, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s45, ptr addrspace(1) %r1053.1.relocated790, ptr addrspace(1) %r48.0.base.relocated791, ptr addrspace(1) %r55.0.base.relocated792, ptr addrspace(1) %r1046.0.base.relocated793, ptr addrspace(1) %rs4gc.s43.relocated794, ptr addrspace(1) %r48.0.relocated795, ptr addrspace(1) %r55.0.relocated796, ptr addrspace(1) %r1046.0.relocated797) ]
  %r3187853 = call double @llvm.experimental.gc.result.f64(token %statepoint_token852)
  %rs4gc.s45.relocated854 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token852, i32 0, i32 0) ; (%rs4gc.s45, %rs4gc.s45)
  %r1053.1.relocated855 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token852, i32 1, i32 1) ; (%r1053.1.relocated790, %r1053.1.relocated790)
  %r48.0.base.relocated856 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token852, i32 2, i32 2) ; (%r48.0.base.relocated791, %r48.0.base.relocated791)
  %r55.0.base.relocated857 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token852, i32 3, i32 3) ; (%r55.0.base.relocated792, %r55.0.base.relocated792)
  %r1046.0.base.relocated858 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token852, i32 4, i32 4) ; (%r1046.0.base.relocated793, %r1046.0.base.relocated793)
  %rs4gc.s43.relocated859 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token852, i32 5, i32 5) ; (%rs4gc.s43.relocated794, %rs4gc.s43.relocated794)
  %r48.0.relocated860 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token852, i32 2, i32 6) ; (%r48.0.base.relocated791, %r48.0.relocated795)
  %r55.0.relocated861 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token852, i32 3, i32 7) ; (%r55.0.base.relocated792, %r55.0.relocated796)
  %r1046.0.relocated862 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token852, i32 4, i32 8) ; (%r1046.0.base.relocated793, %r1046.0.relocated797)
  br label %pget.recv_merge.505

shadow.root.barrier.532:                          ; preds = %pget.recv_merge.505
  call void @js_write_barrier_root_nanbox(i64 %r3194) #7
  br label %shadow.root.barrier.done.533

shadow.root.barrier.done.533:                     ; preds = %shadow.root.barrier.532, %pget.recv_merge.505
  %r3197.rs4i = ptrtoint ptr addrspace(1) %.71655 to i64
  %r3197.rs4o = call i64 asm "", "=r,0"(i64 %r3197.rs4i) #7
  %r3197 = bitcast i64 %r3197.rs4o to double
  %r3198 = bitcast double %r3197 to i64
  %r3199 = and i64 %r3198, 281474976710655
  %r3200 = lshr i64 %r3198, 48
  %r3201 = and i64 %r3200, 65533
  %r3202 = icmp eq i64 %r3201, 32765
  br i1 %r3202, label %pget.recv_ok.535, label %pget.recv_other.539

pget.recv_sso.534:                                ; preds = %pget.recv_other.539
  %r3340 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r3341 = bitcast double %r3340 to i64
  %r3342 = and i64 %r3341, 281474976710655
  %statepoint_token863 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3198, i64 %r3342, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.421320, ptr addrspace(1) %.42, ptr addrspace(1) %.291500, ptr addrspace(1) %.01659, ptr addrspace(1) %.141632, ptr addrspace(1) %rs4gc.s46, ptr addrspace(1) %.421426, ptr addrspace(1) %.421373, ptr addrspace(1) %.291558) ]
  %r3343864 = call double @llvm.experimental.gc.result.f64(token %statepoint_token863)
  %r48.0.base.relocated865 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token863, i32 0, i32 0) ; (%.421320, %.421320)
  %r55.0.base.relocated866 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token863, i32 1, i32 1) ; (%.42, %.42)
  %r1046.0.base.relocated867 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token863, i32 2, i32 2) ; (%.291500, %.291500)
  %rs4gc.s45.relocated868 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token863, i32 3, i32 3) ; (%.01659, %.01659)
  %r1053.1.relocated869 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token863, i32 4, i32 4) ; (%.141632, %.141632)
  %rs4gc.s46.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token863, i32 5, i32 5) ; (%rs4gc.s46, %rs4gc.s46)
  %r48.0.relocated870 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token863, i32 0, i32 6) ; (%.421320, %.421426)
  %r55.0.relocated871 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token863, i32 1, i32 7) ; (%.42, %.421373)
  %r1046.0.relocated872 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token863, i32 2, i32 8) ; (%.291500, %.291558)
  br label %pget.recv_merge.538

pget.recv_ok.535:                                 ; preds = %shadow.root.barrier.done.533
  %r3209 = icmp ugt i64 %r3199, 1048575
  br i1 %r3209, label %pic.recv_hdr.556, label %pic.miss.cold.553

pget.recv_bad.536:                                ; preds = %pget.check_class_ref.540
  %r3332 = icmp eq i64 %r3198, 9222246136947933185
  %r3333 = icmp eq i64 %r3198, 9222246136947933186
  %r3334 = or i1 %r3332, %r3333
  br i1 %r3334, label %pget.throw_nullish.563, label %pget.recv_undef_return.564

pget.recv_class_ref.537:                          ; preds = %pget.check_class_ref.540
  %r3205 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r3206 = bitcast double %r3205 to i64
  %r3207 = and i64 %r3206, 281474976710655
  %statepoint_token873 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 5587713372188573719, i64 %r3198, i64 %r3207, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.421320, ptr addrspace(1) %.42, ptr addrspace(1) %.291500, ptr addrspace(1) %.01659, ptr addrspace(1) %.141632, ptr addrspace(1) %rs4gc.s46, ptr addrspace(1) %.421426, ptr addrspace(1) %.421373, ptr addrspace(1) %.291558) ]
  %r3208874 = call double @llvm.experimental.gc.result.f64(token %statepoint_token873)
  %r48.0.base.relocated875 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token873, i32 0, i32 0) ; (%.421320, %.421320)
  %r55.0.base.relocated876 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token873, i32 1, i32 1) ; (%.42, %.42)
  %r1046.0.base.relocated877 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token873, i32 2, i32 2) ; (%.291500, %.291500)
  %rs4gc.s45.relocated878 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token873, i32 3, i32 3) ; (%.01659, %.01659)
  %r1053.1.relocated879 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token873, i32 4, i32 4) ; (%.141632, %.141632)
  %rs4gc.s46.relocated880 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token873, i32 5, i32 5) ; (%rs4gc.s46, %rs4gc.s46)
  %r48.0.relocated881 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token873, i32 0, i32 6) ; (%.421320, %.421426)
  %r55.0.relocated882 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token873, i32 1, i32 7) ; (%.42, %.421373)
  %r1046.0.relocated883 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token873, i32 2, i32 8) ; (%.291500, %.291558)
  br label %pget.recv_merge.538

pget.recv_merge.538:                              ; preds = %pget.recv_undef_return.564, %pic.merge.555, %pget.recv_class_ref.537, %pget.recv_sso.534
  %.01664 = phi ptr addrspace(1) [ %.11665, %pic.merge.555 ], [ %rs4gc.s46.relocated, %pget.recv_sso.534 ], [ %rs4gc.s46.relocated880, %pget.recv_class_ref.537 ], [ %rs4gc.s46.relocated914, %pget.recv_undef_return.564 ]
  %.21661 = phi ptr addrspace(1) [ %.31662, %pic.merge.555 ], [ %rs4gc.s45.relocated868, %pget.recv_sso.534 ], [ %rs4gc.s45.relocated878, %pget.recv_class_ref.537 ], [ %rs4gc.s45.relocated912, %pget.recv_undef_return.564 ]
  %.161634 = phi ptr addrspace(1) [ %.171635, %pic.merge.555 ], [ %r1053.1.relocated869, %pget.recv_sso.534 ], [ %r1053.1.relocated879, %pget.recv_class_ref.537 ], [ %r1053.1.relocated913, %pget.recv_undef_return.564 ]
  %.311560 = phi ptr addrspace(1) [ %.321561, %pic.merge.555 ], [ %r1046.0.relocated872, %pget.recv_sso.534 ], [ %r1046.0.relocated883, %pget.recv_class_ref.537 ], [ %r1046.0.relocated917, %pget.recv_undef_return.564 ]
  %.311502 = phi ptr addrspace(1) [ %.321503, %pic.merge.555 ], [ %r1046.0.base.relocated867, %pget.recv_sso.534 ], [ %r1046.0.base.relocated877, %pget.recv_class_ref.537 ], [ %r1046.0.base.relocated911, %pget.recv_undef_return.564 ]
  %.441428 = phi ptr addrspace(1) [ %.451429, %pic.merge.555 ], [ %r48.0.relocated870, %pget.recv_sso.534 ], [ %r48.0.relocated881, %pget.recv_class_ref.537 ], [ %r48.0.relocated915, %pget.recv_undef_return.564 ]
  %.441375 = phi ptr addrspace(1) [ %.451376, %pic.merge.555 ], [ %r55.0.relocated871, %pget.recv_sso.534 ], [ %r55.0.relocated882, %pget.recv_class_ref.537 ], [ %r55.0.relocated916, %pget.recv_undef_return.564 ]
  %.441322 = phi ptr addrspace(1) [ %.451323, %pic.merge.555 ], [ %r48.0.base.relocated865, %pget.recv_sso.534 ], [ %r48.0.base.relocated875, %pget.recv_class_ref.537 ], [ %r48.0.base.relocated909, %pget.recv_undef_return.564 ]
  %.44 = phi ptr addrspace(1) [ %.45, %pic.merge.555 ], [ %r55.0.base.relocated866, %pget.recv_sso.534 ], [ %r55.0.base.relocated876, %pget.recv_class_ref.537 ], [ %r55.0.base.relocated910, %pget.recv_undef_return.564 ]
  %r3344 = phi double [ %r3331, %pic.merge.555 ], [ %r3339908, %pget.recv_undef_return.564 ], [ %r3343864, %pget.recv_sso.534 ], [ %r3208874, %pget.recv_class_ref.537 ]
  %r3345.rs4i = ptrtoint ptr addrspace(1) %.01664 to i64
  %r3345 = call i64 asm "", "=r,0"(i64 %r3345.rs4i) #7
  %r3346 = bitcast i64 %r3345 to double
  %r3347 = bitcast double %r3344 to i64
  %r3348 = icmp eq i64 %r3345, %r3347
  br i1 %r3348, label %anyeq.same.565, label %anyeq.diff.566

pget.recv_other.539:                              ; preds = %shadow.root.barrier.done.533
  %r3203 = icmp eq i64 %r3200, 32761
  br i1 %r3203, label %pget.recv_sso.534, label %pget.check_class_ref.540

pget.check_class_ref.540:                         ; preds = %pget.recv_other.539
  %r3204 = icmp eq i64 %r3200, 32766
  br i1 %r3204, label %pget.recv_class_ref.537, label %pget.recv_bad.536

pic.hit.541:                                      ; preds = %pic.token.557
  %r3234 = getelementptr i64, ptr %r3219, i64 1
  %r3235 = load i64, ptr %r3234, align 8
  %r3236 = and i64 %r3235, 1073741824
  %r3237 = icmp ne i64 %r3236, 0
  br i1 %r3237, label %pic.hit.overflow.558, label %pic.hit.inline.559

pic.hit.live.542:                                 ; preds = %pic.hit.inline.559
  br label %pic.merge.555

pic.prefix.guard.543:                             ; preds = %pic.token.557
  %r3250 = getelementptr i64, ptr %r3219, i64 2
  %r3251 = load i64, ptr %r3250, align 8
  %r3252 = icmp ne i64 %r3251, 0
  br i1 %r3252, label %pic.prefix.meta.544, label %pic.miss.552

pic.prefix.meta.544:                              ; preds = %pic.prefix.guard.543
  %r3253 = add nuw nsw i64 %r3199, 8
  %r3254 = inttoptr i64 %r3253 to ptr
  %r3255 = load i64, ptr %r3254, align 8
  %r3256 = icmp ne i64 %r3255, 0
  br i1 %r3256, label %pic.prefix.token.545, label %pic.miss.552

pic.prefix.token.545:                             ; preds = %pic.prefix.meta.544
  %r3257 = inttoptr i64 %r3255 to ptr
  %r3258 = getelementptr i64, ptr %r3257, i64 6
  %r3259 = load i64, ptr %r3258, align 8
  %r3260 = icmp eq i64 %r3259, %r3251
  br i1 %r3260, label %pic.prefix.hit.546, label %pic.miss.552

pic.prefix.hit.546:                               ; preds = %pic.prefix.token.545
  %r3261 = getelementptr i64, ptr %r3219, i64 1
  %r3262 = load i64, ptr %r3261, align 8
  %r3263 = shl i64 %r3262, 3
  %r3264 = add nuw nsw i64 %r3199, 16
  %r3265 = add i64 %r3264, %r3263
  %r3266 = inttoptr i64 %r3265 to ptr
  %r3267 = load double, ptr %r3266, align 8
  br label %pic.merge.555

pic.desc.classify.547:                            ; preds = %pic.recv_hdr.556
  %r3223 = and i1 %r3213, %r3220
  br i1 %r3223, label %pic.desc.prefix.guard.548, label %pic.miss.cold.553

pic.desc.prefix.guard.548:                        ; preds = %pic.desc.classify.547
  %r3268 = getelementptr i64, ptr %r3219, i64 2
  %r3269 = load i64, ptr %r3268, align 8
  %r3270 = icmp ne i64 %r3269, 0
  br i1 %r3270, label %pic.desc.prefix.meta.549, label %pic.miss.cold.553

pic.desc.prefix.meta.549:                         ; preds = %pic.desc.prefix.guard.548
  %r3271 = add nuw nsw i64 %r3199, 8
  %r3272 = inttoptr i64 %r3271 to ptr
  %r3273 = load i64, ptr %r3272, align 8
  %r3274 = icmp ne i64 %r3273, 0
  br i1 %r3274, label %pic.desc.prefix.token.550, label %pic.miss.cold.553

pic.desc.prefix.token.550:                        ; preds = %pic.desc.prefix.meta.549
  %r3275 = inttoptr i64 %r3273 to ptr
  %r3276 = getelementptr i64, ptr %r3275, i64 6
  %r3277 = load i64, ptr %r3276, align 8
  %r3278 = icmp eq i64 %r3277, %r3269
  br i1 %r3278, label %pic.desc.prefix.hit.551, label %pic.miss.cold.553

pic.desc.prefix.hit.551:                          ; preds = %pic.desc.prefix.token.550
  %r3279 = getelementptr i64, ptr %r3219, i64 1
  %r3280 = load i64, ptr %r3279, align 8
  %r3281 = shl i64 %r3280, 3
  %r3282 = add nuw nsw i64 %r3199, 16
  %r3283 = add i64 %r3282, %r3281
  %r3284 = inttoptr i64 %r3283 to ptr
  %r3285 = load double, ptr %r3284, align 8
  br label %pic.merge.555

pic.miss.552:                                     ; preds = %pic.hit.inline.559, %pic.prefix.token.545, %pic.prefix.meta.544, %pic.prefix.guard.543
  %r3286 = getelementptr i64, ptr %r3219, i64 3
  %r3287 = load i64, ptr %r3286, align 8
  %r3288 = icmp sgt i64 %r3287, 0
  br i1 %r3288, label %pic.ways.560, label %pic.miss.call.554

pic.miss.cold.553:                                ; preds = %pic.desc.prefix.token.550, %pic.desc.prefix.meta.549, %pic.desc.prefix.guard.548, %pic.desc.classify.547, %pget.recv_ok.535
  br label %pic.miss.call.554

pic.miss.call.554:                                ; preds = %pic.way.load.561, %pic.ways.560, %pic.miss.cold.553, %pic.miss.552
  %r3327 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r3328 = bitcast double %r3327 to i64
  %r3329 = and i64 %r3328, 281474976710655
  %statepoint_token884 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r3199, i64 %r3329, ptr @perry_ic_test_json_source_token_length_ts__24, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.421320, ptr addrspace(1) %.42, ptr addrspace(1) %.291500, ptr addrspace(1) %.01659, ptr addrspace(1) %.141632, ptr addrspace(1) %rs4gc.s46, ptr addrspace(1) %.421426, ptr addrspace(1) %.421373, ptr addrspace(1) %.291558) ]
  %r3330885 = call double @llvm.experimental.gc.result.f64(token %statepoint_token884)
  %r48.0.base.relocated886 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token884, i32 0, i32 0) ; (%.421320, %.421320)
  %r55.0.base.relocated887 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token884, i32 1, i32 1) ; (%.42, %.42)
  %r1046.0.base.relocated888 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token884, i32 2, i32 2) ; (%.291500, %.291500)
  %rs4gc.s45.relocated889 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token884, i32 3, i32 3) ; (%.01659, %.01659)
  %r1053.1.relocated890 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token884, i32 4, i32 4) ; (%.141632, %.141632)
  %rs4gc.s46.relocated891 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token884, i32 5, i32 5) ; (%rs4gc.s46, %rs4gc.s46)
  %r48.0.relocated892 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token884, i32 0, i32 6) ; (%.421320, %.421426)
  %r55.0.relocated893 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token884, i32 1, i32 7) ; (%.42, %.421373)
  %r1046.0.relocated894 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token884, i32 2, i32 8) ; (%.291500, %.291558)
  br label %pic.merge.555

pic.merge.555:                                    ; preds = %pic.way.live.562, %pic.hit.overflow.558, %pic.miss.call.554, %pic.desc.prefix.hit.551, %pic.prefix.hit.546, %pic.hit.live.542
  %.11665 = phi ptr addrspace(1) [ %rs4gc.s46.relocated902, %pic.hit.overflow.558 ], [ %rs4gc.s46.relocated891, %pic.miss.call.554 ], [ %rs4gc.s46, %pic.way.live.562 ], [ %rs4gc.s46, %pic.hit.live.542 ], [ %rs4gc.s46, %pic.prefix.hit.546 ], [ %rs4gc.s46, %pic.desc.prefix.hit.551 ]
  %.31662 = phi ptr addrspace(1) [ %rs4gc.s45.relocated900, %pic.hit.overflow.558 ], [ %rs4gc.s45.relocated889, %pic.miss.call.554 ], [ %.01659, %pic.way.live.562 ], [ %.01659, %pic.hit.live.542 ], [ %.01659, %pic.prefix.hit.546 ], [ %.01659, %pic.desc.prefix.hit.551 ]
  %.171635 = phi ptr addrspace(1) [ %r1053.1.relocated901, %pic.hit.overflow.558 ], [ %r1053.1.relocated890, %pic.miss.call.554 ], [ %.141632, %pic.way.live.562 ], [ %.141632, %pic.hit.live.542 ], [ %.141632, %pic.prefix.hit.546 ], [ %.141632, %pic.desc.prefix.hit.551 ]
  %.321561 = phi ptr addrspace(1) [ %r1046.0.relocated905, %pic.hit.overflow.558 ], [ %r1046.0.relocated894, %pic.miss.call.554 ], [ %.291558, %pic.way.live.562 ], [ %.291558, %pic.hit.live.542 ], [ %.291558, %pic.prefix.hit.546 ], [ %.291558, %pic.desc.prefix.hit.551 ]
  %.321503 = phi ptr addrspace(1) [ %r1046.0.base.relocated899, %pic.hit.overflow.558 ], [ %r1046.0.base.relocated888, %pic.miss.call.554 ], [ %.291500, %pic.way.live.562 ], [ %.291500, %pic.hit.live.542 ], [ %.291500, %pic.prefix.hit.546 ], [ %.291500, %pic.desc.prefix.hit.551 ]
  %.451429 = phi ptr addrspace(1) [ %r48.0.relocated903, %pic.hit.overflow.558 ], [ %r48.0.relocated892, %pic.miss.call.554 ], [ %.421426, %pic.way.live.562 ], [ %.421426, %pic.hit.live.542 ], [ %.421426, %pic.prefix.hit.546 ], [ %.421426, %pic.desc.prefix.hit.551 ]
  %.451376 = phi ptr addrspace(1) [ %r55.0.relocated904, %pic.hit.overflow.558 ], [ %r55.0.relocated893, %pic.miss.call.554 ], [ %.421373, %pic.way.live.562 ], [ %.421373, %pic.hit.live.542 ], [ %.421373, %pic.prefix.hit.546 ], [ %.421373, %pic.desc.prefix.hit.551 ]
  %.451323 = phi ptr addrspace(1) [ %r48.0.base.relocated897, %pic.hit.overflow.558 ], [ %r48.0.base.relocated886, %pic.miss.call.554 ], [ %.421320, %pic.way.live.562 ], [ %.421320, %pic.hit.live.542 ], [ %.421320, %pic.prefix.hit.546 ], [ %.421320, %pic.desc.prefix.hit.551 ]
  %.45 = phi ptr addrspace(1) [ %r55.0.base.relocated898, %pic.hit.overflow.558 ], [ %r55.0.base.relocated887, %pic.miss.call.554 ], [ %.42, %pic.way.live.562 ], [ %.42, %pic.hit.live.542 ], [ %.42, %pic.prefix.hit.546 ], [ %.42, %pic.desc.prefix.hit.551 ]
  %r3331 = phi double [ %r3247, %pic.hit.live.542 ], [ %r3242896, %pic.hit.overflow.558 ], [ %r3267, %pic.prefix.hit.546 ], [ %r3285, %pic.desc.prefix.hit.551 ], [ %r3324, %pic.way.live.562 ], [ %r3330885, %pic.miss.call.554 ]
  br label %pget.recv_merge.538

pic.recv_hdr.556:                                 ; preds = %pget.recv_ok.535
  %r3210 = sub nuw nsw i64 %r3199, 8
  %r3211 = inttoptr i64 %r3210 to ptr
  %r3212 = load i8, ptr %r3211, align 1
  %r3213 = icmp eq i8 %r3212, 2
  %r3214 = sub nuw nsw i64 %r3199, 6
  %r3215 = inttoptr i64 %r3214 to ptr
  %r3216 = load i16, ptr %r3215, align 2
  %r3217 = and i16 %r3216, 2048
  %r3218 = icmp eq i16 %r3217, 0
  %r3219 = load ptr, ptr @perry_ic_test_json_source_token_length_ts__24, align 8
  %r3220 = icmp ne ptr %r3219, null
  %r3221 = and i1 %r3213, %r3218
  %r3222 = and i1 %r3221, %r3220
  br i1 %r3222, label %pic.token.557, label %pic.desc.classify.547

pic.token.557:                                    ; preds = %pic.recv_hdr.556
  %r3224 = add nuw nsw i64 %r3199, 4
  %r3225 = inttoptr i64 %r3224 to ptr
  %r3226 = load i32, ptr %r3225, align 4
  %r3227 = zext i32 %r3226 to i64
  %r3228 = or i64 %r3227, 4611686018427387904
  %r3229 = icmp ne i32 %r3226, 0
  %r3230 = getelementptr i64, ptr %r3219, i64 0
  %r3231 = load i64, ptr %r3230, align 8
  %r3232 = icmp eq i64 %r3228, %r3231
  %r3233 = and i1 %r3232, %r3229
  br i1 %r3233, label %pic.hit.541, label %pic.prefix.guard.543

pic.hit.overflow.558:                             ; preds = %pic.hit.541
  %r3238 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r3239 = bitcast double %r3238 to i64
  %r3240 = and i64 %r3239, 281474976710655
  %r3241 = trunc i64 %r3235 to i32
  %statepoint_token895 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r3199, i64 %r3240, i32 %r3241, ptr @perry_ic_test_json_source_token_length_ts__24, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.421320, ptr addrspace(1) %.42, ptr addrspace(1) %.291500, ptr addrspace(1) %.01659, ptr addrspace(1) %.141632, ptr addrspace(1) %rs4gc.s46, ptr addrspace(1) %.421426, ptr addrspace(1) %.421373, ptr addrspace(1) %.291558) ]
  %r3242896 = call double @llvm.experimental.gc.result.f64(token %statepoint_token895)
  %r48.0.base.relocated897 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token895, i32 0, i32 0) ; (%.421320, %.421320)
  %r55.0.base.relocated898 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token895, i32 1, i32 1) ; (%.42, %.42)
  %r1046.0.base.relocated899 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token895, i32 2, i32 2) ; (%.291500, %.291500)
  %rs4gc.s45.relocated900 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token895, i32 3, i32 3) ; (%.01659, %.01659)
  %r1053.1.relocated901 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token895, i32 4, i32 4) ; (%.141632, %.141632)
  %rs4gc.s46.relocated902 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token895, i32 5, i32 5) ; (%rs4gc.s46, %rs4gc.s46)
  %r48.0.relocated903 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token895, i32 0, i32 6) ; (%.421320, %.421426)
  %r55.0.relocated904 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token895, i32 1, i32 7) ; (%.42, %.421373)
  %r1046.0.relocated905 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token895, i32 2, i32 8) ; (%.291500, %.291558)
  br label %pic.merge.555

pic.hit.inline.559:                               ; preds = %pic.hit.541
  %r3243 = shl i64 %r3235, 3
  %r3244 = add nuw nsw i64 %r3199, 16
  %r3245 = add i64 %r3244, %r3243
  %r3246 = inttoptr i64 %r3245 to ptr
  %r3247 = load double, ptr %r3246, align 8
  %r3248 = bitcast double %r3247 to i64
  %r3249 = icmp eq i64 %r3248, 9222246136947933200
  br i1 %r3249, label %pic.miss.552, label %pic.hit.live.542

pic.ways.560:                                     ; preds = %pic.miss.552
  %r3289 = getelementptr i64, ptr %r3219, i64 4
  %r3290 = load i64, ptr %r3289, align 8
  %r3291 = icmp eq i64 %r3290, %r3228
  %r3292 = getelementptr i64, ptr %r3219, i64 5
  %r3293 = load i64, ptr %r3292, align 8
  %r3294 = select i1 %r3291, i64 %r3293, i64 0
  %r3295 = getelementptr i64, ptr %r3219, i64 6
  %r3296 = load i64, ptr %r3295, align 8
  %r3297 = icmp eq i64 %r3296, %r3228
  %r3298 = getelementptr i64, ptr %r3219, i64 7
  %r3299 = load i64, ptr %r3298, align 8
  %r3300 = select i1 %r3297, i64 %r3299, i64 0
  %r3301 = getelementptr i64, ptr %r3219, i64 8
  %r3302 = load i64, ptr %r3301, align 8
  %r3303 = icmp eq i64 %r3302, %r3228
  %r3304 = getelementptr i64, ptr %r3219, i64 9
  %r3305 = load i64, ptr %r3304, align 8
  %r3306 = select i1 %r3303, i64 %r3305, i64 0
  %r3307 = getelementptr i64, ptr %r3219, i64 10
  %r3308 = load i64, ptr %r3307, align 8
  %r3309 = icmp eq i64 %r3308, %r3228
  %r3310 = getelementptr i64, ptr %r3219, i64 11
  %r3311 = load i64, ptr %r3310, align 8
  %r3312 = select i1 %r3309, i64 %r3311, i64 0
  %r3313 = or i1 %r3291, %r3297
  %r3314 = select i1 %r3291, i64 %r3294, i64 %r3300
  %r3315 = or i1 %r3303, %r3309
  %r3316 = select i1 %r3303, i64 %r3306, i64 %r3312
  %r3317 = or i1 %r3313, %r3315
  %r3318 = select i1 %r3313, i64 %r3314, i64 %r3316
  %r3319 = and i1 %r3229, %r3317
  br i1 %r3319, label %pic.way.load.561, label %pic.miss.call.554

pic.way.load.561:                                 ; preds = %pic.ways.560
  %r3320 = shl i64 %r3318, 3
  %r3321 = add nuw nsw i64 %r3199, 16
  %r3322 = add i64 %r3321, %r3320
  %r3323 = inttoptr i64 %r3322 to ptr
  %r3324 = load double, ptr %r3323, align 8
  %r3325 = bitcast double %r3324 to i64
  %r3326 = icmp eq i64 %r3325, 9222246136947933200
  br i1 %r3326, label %pic.miss.call.554, label %pic.way.live.562

pic.way.live.562:                                 ; preds = %pic.way.load.561
  br label %pic.merge.555

pget.throw_nullish.563:                           ; preds = %pget.recv_bad.536
  %r3335 = zext i1 %r3333 to i32
  %statepoint_token906 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r3335, ptr @test_json_source_token_length_ts_.str.10.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.564:                       ; preds = %pget.recv_bad.536
  %r3336 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r3337 = bitcast double %r3336 to i64
  %r3338 = and i64 %r3337, 281474976710655
  %statepoint_token907 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3198, i64 %r3338, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.421320, ptr addrspace(1) %.42, ptr addrspace(1) %.291500, ptr addrspace(1) %.01659, ptr addrspace(1) %.141632, ptr addrspace(1) %rs4gc.s46, ptr addrspace(1) %.421426, ptr addrspace(1) %.421373, ptr addrspace(1) %.291558) ]
  %r3339908 = call double @llvm.experimental.gc.result.f64(token %statepoint_token907)
  %r48.0.base.relocated909 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token907, i32 0, i32 0) ; (%.421320, %.421320)
  %r55.0.base.relocated910 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token907, i32 1, i32 1) ; (%.42, %.42)
  %r1046.0.base.relocated911 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token907, i32 2, i32 2) ; (%.291500, %.291500)
  %rs4gc.s45.relocated912 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token907, i32 3, i32 3) ; (%.01659, %.01659)
  %r1053.1.relocated913 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token907, i32 4, i32 4) ; (%.141632, %.141632)
  %rs4gc.s46.relocated914 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token907, i32 5, i32 5) ; (%rs4gc.s46, %rs4gc.s46)
  %r48.0.relocated915 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token907, i32 0, i32 6) ; (%.421320, %.421426)
  %r55.0.relocated916 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token907, i32 1, i32 7) ; (%.42, %.421373)
  %r1046.0.relocated917 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token907, i32 2, i32 8) ; (%.291500, %.291558)
  br label %pget.recv_merge.538

anyeq.same.565:                                   ; preds = %pget.recv_merge.538
  %r3349 = lshr i64 %r3345, 48
  %r3350 = icmp uge i64 %r3349, 32761
  %r3351 = icmp ule i64 %r3349, 32767
  %r3352 = and i1 %r3350, %r3351
  %r3353 = fcmp uno double %r3346, %r3346
  %r3354 = xor i1 %r3353, true
  %r3355 = or i1 %r3352, %r3354
  br i1 %r3355, label %anyeq.true.568, label %anyeq.slow.567

anyeq.diff.566:                                   ; preds = %pget.recv_merge.538
  %r3356 = and i64 %r3345, 9221120237041090560
  %r3357 = icmp ne i64 %r3356, 9221120237041090560
  %r3358 = and i64 %r3347, 9221120237041090560
  %r3359 = icmp ne i64 %r3358, 9221120237041090560
  %r3360 = and i1 %r3357, %r3359
  br i1 %r3360, label %anyeq.num.571, label %anyeq.tag.572

anyeq.slow.567:                                   ; preds = %anyeq.tag.572, %anyeq.same.565
  %statepoint_token918 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i64)) @js_eq, i32 2, i32 0, i64 %r3345, i64 %r3347, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.441322, ptr addrspace(1) %.44, ptr addrspace(1) %.311502, ptr addrspace(1) %.21661, ptr addrspace(1) %.161634, ptr addrspace(1) %.441428, ptr addrspace(1) %.441375, ptr addrspace(1) %.311560) ]
  %r3371919 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token918)
  %r48.0.base.relocated920 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token918, i32 0, i32 0) ; (%.441322, %.441322)
  %r55.0.base.relocated921 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token918, i32 1, i32 1) ; (%.44, %.44)
  %r1046.0.base.relocated922 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token918, i32 2, i32 2) ; (%.311502, %.311502)
  %rs4gc.s45.relocated923 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token918, i32 3, i32 3) ; (%.21661, %.21661)
  %r1053.1.relocated924 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token918, i32 4, i32 4) ; (%.161634, %.161634)
  %r48.0.relocated925 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token918, i32 0, i32 5) ; (%.441322, %.441428)
  %r55.0.relocated926 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token918, i32 1, i32 6) ; (%.44, %.441375)
  %r1046.0.relocated927 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token918, i32 2, i32 7) ; (%.311502, %.311560)
  br label %anyeq.merge.570

anyeq.true.568:                                   ; preds = %anyeq.num.571, %anyeq.same.565
  br label %anyeq.merge.570

anyeq.false.569:                                  ; preds = %anyeq.tag.572, %anyeq.num.571
  br label %anyeq.merge.570

anyeq.merge.570:                                  ; preds = %anyeq.false.569, %anyeq.true.568, %anyeq.slow.567
  %.41663 = phi ptr addrspace(1) [ %.21661, %anyeq.true.568 ], [ %rs4gc.s45.relocated923, %anyeq.slow.567 ], [ %.21661, %anyeq.false.569 ]
  %.181636 = phi ptr addrspace(1) [ %.161634, %anyeq.true.568 ], [ %r1053.1.relocated924, %anyeq.slow.567 ], [ %.161634, %anyeq.false.569 ]
  %.331562 = phi ptr addrspace(1) [ %.311560, %anyeq.true.568 ], [ %r1046.0.relocated927, %anyeq.slow.567 ], [ %.311560, %anyeq.false.569 ]
  %.331504 = phi ptr addrspace(1) [ %.311502, %anyeq.true.568 ], [ %r1046.0.base.relocated922, %anyeq.slow.567 ], [ %.311502, %anyeq.false.569 ]
  %.461430 = phi ptr addrspace(1) [ %.441428, %anyeq.true.568 ], [ %r48.0.relocated925, %anyeq.slow.567 ], [ %.441428, %anyeq.false.569 ]
  %.461377 = phi ptr addrspace(1) [ %.441375, %anyeq.true.568 ], [ %r55.0.relocated926, %anyeq.slow.567 ], [ %.441375, %anyeq.false.569 ]
  %.461324 = phi ptr addrspace(1) [ %.441322, %anyeq.true.568 ], [ %r48.0.base.relocated920, %anyeq.slow.567 ], [ %.441322, %anyeq.false.569 ]
  %.46 = phi ptr addrspace(1) [ %.44, %anyeq.true.568 ], [ %r55.0.base.relocated921, %anyeq.slow.567 ], [ %.44, %anyeq.false.569 ]
  %r3372 = phi i64 [ 9222246136947933188, %anyeq.true.568 ], [ 9222246136947933187, %anyeq.false.569 ], [ %r3371919, %anyeq.slow.567 ]
  %r3373 = bitcast i64 %r3372 to double
  %r3374 = icmp eq i64 %r3372, 9222246136947933188
  %r3375 = xor i1 %r3374, true
  %r3376 = select i1 %r3375, i64 9222246136947933188, i64 9222246136947933187
  %r3377 = bitcast i64 %r3376 to double
  %r3378 = icmp eq i64 %r3376, 9222246136947933188
  br i1 %r3378, label %if.then.573, label %if.else.574

anyeq.num.571:                                    ; preds = %anyeq.diff.566
  %r3361 = fcmp oeq double %r3346, %r3344
  br i1 %r3361, label %anyeq.true.568, label %anyeq.false.569

anyeq.tag.572:                                    ; preds = %anyeq.diff.566
  %r3362 = lshr i64 %r3345, 48
  %r3363 = lshr i64 %r3347, 48
  %r3364 = icmp eq i64 %r3362, 32761
  %r3365 = icmp eq i64 %r3363, 32761
  %r3366 = and i1 %r3364, %r3365
  %r3367 = icmp eq i64 %r3362, 32766
  %r3368 = icmp eq i64 %r3363, 32766
  %r3369 = and i1 %r3367, %r3368
  %r3370 = or i1 %r3366, %r3369
  br i1 %r3370, label %anyeq.false.569, label %anyeq.slow.567

if.then.573:                                      ; preds = %anyeq.merge.570
  %r3379 = load double, ptr @test_json_source_token_length_ts_.str.17.handle, align 8
  %statepoint_token928 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_error_new_from_value, i32 1, i32 0, double %r3379, i32 0, i32 0)
  %r3380929 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token928)
  %r3381 = or i64 %r3380929, 9222527611924643840
  %r3382 = bitcast i64 %r3381 to double
  %statepoint_token930 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r3382, i32 0, i32 0)
  unreachable

if.else.574:                                      ; preds = %anyeq.merge.570
  br label %if.merge.575

if.merge.575:                                     ; preds = %if.else.574
  %r3383.rs4i = ptrtoint ptr addrspace(1) %.181636 to i64
  %r3383.rs4o = call i64 asm "", "=r,0"(i64 %r3383.rs4i) #7
  %r3383 = bitcast i64 %r3383.rs4o to double
  %r3384 = bitcast double %r3383 to i64
  %rs4gc.s47 = inttoptr i64 %r3384 to ptr addrspace(1)
  %r3385.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s47 to i64
  %r3385 = call i64 asm "", "=r,0"(i64 %r3385.rs4i) #7
  %r3386 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3387 = icmp ne i32 %r3386, 0
  br i1 %r3387, label %shadow.root.barrier.576, label %shadow.root.barrier.done.577

shadow.root.barrier.576:                          ; preds = %if.merge.575
  call void @js_write_barrier_root_nanbox(i64 %r3385) #7
  br label %shadow.root.barrier.done.577

shadow.root.barrier.done.577:                     ; preds = %shadow.root.barrier.576, %if.merge.575
  %r3388.rs4i = ptrtoint ptr addrspace(1) %.41663 to i64
  %r3388.rs4o = call i64 asm "", "=r,0"(i64 %r3388.rs4i) #7
  %r3388 = bitcast i64 %r3388.rs4o to double
  %r3389 = bitcast double %r3388 to i64
  %r3390 = and i64 %r3389, 281474976710655
  %r3391 = lshr i64 %r3389, 48
  %r3392 = and i64 %r3391, 65533
  %r3393 = icmp eq i64 %r3392, 32765
  br i1 %r3393, label %pget.recv_ok.579, label %pget.recv_other.583

pget.recv_sso.578:                                ; preds = %pget.recv_other.583
  %r3531 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r3532 = bitcast double %r3531 to i64
  %r3533 = and i64 %r3532, 281474976710655
  %statepoint_token931 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3389, i64 %r3533, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s47, ptr addrspace(1) %.461324, ptr addrspace(1) %.46, ptr addrspace(1) %.331504, ptr addrspace(1) %.461430, ptr addrspace(1) %.461377, ptr addrspace(1) %.331562) ]
  %r3534932 = call double @llvm.experimental.gc.result.f64(token %statepoint_token931)
  %rs4gc.s47.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token931, i32 0, i32 0) ; (%rs4gc.s47, %rs4gc.s47)
  %r48.0.base.relocated933 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token931, i32 1, i32 1) ; (%.461324, %.461324)
  %r55.0.base.relocated934 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token931, i32 2, i32 2) ; (%.46, %.46)
  %r1046.0.base.relocated935 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token931, i32 3, i32 3) ; (%.331504, %.331504)
  %r48.0.relocated936 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token931, i32 1, i32 4) ; (%.461324, %.461430)
  %r55.0.relocated937 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token931, i32 2, i32 5) ; (%.46, %.461377)
  %r1046.0.relocated938 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token931, i32 3, i32 6) ; (%.331504, %.331562)
  br label %pget.recv_merge.582

pget.recv_ok.579:                                 ; preds = %shadow.root.barrier.done.577
  %r3400 = icmp ugt i64 %r3390, 1048575
  br i1 %r3400, label %pic.recv_hdr.600, label %pic.miss.cold.597

pget.recv_bad.580:                                ; preds = %pget.check_class_ref.584
  %r3523 = icmp eq i64 %r3389, 9222246136947933185
  %r3524 = icmp eq i64 %r3389, 9222246136947933186
  %r3525 = or i1 %r3523, %r3524
  br i1 %r3525, label %pget.throw_nullish.607, label %pget.recv_undef_return.608

pget.recv_class_ref.581:                          ; preds = %pget.check_class_ref.584
  %r3396 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r3397 = bitcast double %r3396 to i64
  %r3398 = and i64 %r3397, 281474976710655
  %statepoint_token939 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 5587713372188573721, i64 %r3389, i64 %r3398, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s47, ptr addrspace(1) %.461324, ptr addrspace(1) %.46, ptr addrspace(1) %.331504, ptr addrspace(1) %.461430, ptr addrspace(1) %.461377, ptr addrspace(1) %.331562) ]
  %r3399940 = call double @llvm.experimental.gc.result.f64(token %statepoint_token939)
  %rs4gc.s47.relocated941 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token939, i32 0, i32 0) ; (%rs4gc.s47, %rs4gc.s47)
  %r48.0.base.relocated942 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token939, i32 1, i32 1) ; (%.461324, %.461324)
  %r55.0.base.relocated943 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token939, i32 2, i32 2) ; (%.46, %.46)
  %r1046.0.base.relocated944 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token939, i32 3, i32 3) ; (%.331504, %.331504)
  %r48.0.relocated945 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token939, i32 1, i32 4) ; (%.461324, %.461430)
  %r55.0.relocated946 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token939, i32 2, i32 5) ; (%.46, %.461377)
  %r1046.0.relocated947 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token939, i32 3, i32 6) ; (%.331504, %.331562)
  br label %pget.recv_merge.582

pget.recv_merge.582:                              ; preds = %pget.recv_undef_return.608, %pic.merge.599, %pget.recv_class_ref.581, %pget.recv_sso.578
  %.01666 = phi ptr addrspace(1) [ %.11667, %pic.merge.599 ], [ %rs4gc.s47.relocated, %pget.recv_sso.578 ], [ %rs4gc.s47.relocated941, %pget.recv_class_ref.581 ], [ %rs4gc.s47.relocated969, %pget.recv_undef_return.608 ]
  %.341563 = phi ptr addrspace(1) [ %.351564, %pic.merge.599 ], [ %r1046.0.relocated938, %pget.recv_sso.578 ], [ %r1046.0.relocated947, %pget.recv_class_ref.581 ], [ %r1046.0.relocated975, %pget.recv_undef_return.608 ]
  %.341505 = phi ptr addrspace(1) [ %.351506, %pic.merge.599 ], [ %r1046.0.base.relocated935, %pget.recv_sso.578 ], [ %r1046.0.base.relocated944, %pget.recv_class_ref.581 ], [ %r1046.0.base.relocated972, %pget.recv_undef_return.608 ]
  %.471431 = phi ptr addrspace(1) [ %.481432, %pic.merge.599 ], [ %r48.0.relocated936, %pget.recv_sso.578 ], [ %r48.0.relocated945, %pget.recv_class_ref.581 ], [ %r48.0.relocated973, %pget.recv_undef_return.608 ]
  %.471378 = phi ptr addrspace(1) [ %.481379, %pic.merge.599 ], [ %r55.0.relocated937, %pget.recv_sso.578 ], [ %r55.0.relocated946, %pget.recv_class_ref.581 ], [ %r55.0.relocated974, %pget.recv_undef_return.608 ]
  %.471325 = phi ptr addrspace(1) [ %.481326, %pic.merge.599 ], [ %r48.0.base.relocated933, %pget.recv_sso.578 ], [ %r48.0.base.relocated942, %pget.recv_class_ref.581 ], [ %r48.0.base.relocated970, %pget.recv_undef_return.608 ]
  %.47 = phi ptr addrspace(1) [ %.48, %pic.merge.599 ], [ %r55.0.base.relocated934, %pget.recv_sso.578 ], [ %r55.0.base.relocated943, %pget.recv_class_ref.581 ], [ %r55.0.base.relocated971, %pget.recv_undef_return.608 ]
  %r3535 = phi double [ %r3522, %pic.merge.599 ], [ %r3530968, %pget.recv_undef_return.608 ], [ %r3534932, %pget.recv_sso.578 ], [ %r3399940, %pget.recv_class_ref.581 ]
  %r3536 = bitcast double %r3535 to i64
  %r3537 = and i64 %r3536, 281474976710655
  %r3538 = lshr i64 %r3536, 48
  %r3539 = and i64 %r3538, 65533
  %r3540 = icmp eq i64 %r3539, 32765
  br i1 %r3540, label %pget.recv_ok.610, label %pget.recv_other.615

pget.recv_other.583:                              ; preds = %shadow.root.barrier.done.577
  %r3394 = icmp eq i64 %r3391, 32761
  br i1 %r3394, label %pget.recv_sso.578, label %pget.check_class_ref.584

pget.check_class_ref.584:                         ; preds = %pget.recv_other.583
  %r3395 = icmp eq i64 %r3391, 32766
  br i1 %r3395, label %pget.recv_class_ref.581, label %pget.recv_bad.580

pic.hit.585:                                      ; preds = %pic.token.601
  %r3425 = getelementptr i64, ptr %r3410, i64 1
  %r3426 = load i64, ptr %r3425, align 8
  %r3427 = and i64 %r3426, 1073741824
  %r3428 = icmp ne i64 %r3427, 0
  br i1 %r3428, label %pic.hit.overflow.602, label %pic.hit.inline.603

pic.hit.live.586:                                 ; preds = %pic.hit.inline.603
  br label %pic.merge.599

pic.prefix.guard.587:                             ; preds = %pic.token.601
  %r3441 = getelementptr i64, ptr %r3410, i64 2
  %r3442 = load i64, ptr %r3441, align 8
  %r3443 = icmp ne i64 %r3442, 0
  br i1 %r3443, label %pic.prefix.meta.588, label %pic.miss.596

pic.prefix.meta.588:                              ; preds = %pic.prefix.guard.587
  %r3444 = add nuw nsw i64 %r3390, 8
  %r3445 = inttoptr i64 %r3444 to ptr
  %r3446 = load i64, ptr %r3445, align 8
  %r3447 = icmp ne i64 %r3446, 0
  br i1 %r3447, label %pic.prefix.token.589, label %pic.miss.596

pic.prefix.token.589:                             ; preds = %pic.prefix.meta.588
  %r3448 = inttoptr i64 %r3446 to ptr
  %r3449 = getelementptr i64, ptr %r3448, i64 6
  %r3450 = load i64, ptr %r3449, align 8
  %r3451 = icmp eq i64 %r3450, %r3442
  br i1 %r3451, label %pic.prefix.hit.590, label %pic.miss.596

pic.prefix.hit.590:                               ; preds = %pic.prefix.token.589
  %r3452 = getelementptr i64, ptr %r3410, i64 1
  %r3453 = load i64, ptr %r3452, align 8
  %r3454 = shl i64 %r3453, 3
  %r3455 = add nuw nsw i64 %r3390, 16
  %r3456 = add i64 %r3455, %r3454
  %r3457 = inttoptr i64 %r3456 to ptr
  %r3458 = load double, ptr %r3457, align 8
  br label %pic.merge.599

pic.desc.classify.591:                            ; preds = %pic.recv_hdr.600
  %r3414 = and i1 %r3404, %r3411
  br i1 %r3414, label %pic.desc.prefix.guard.592, label %pic.miss.cold.597

pic.desc.prefix.guard.592:                        ; preds = %pic.desc.classify.591
  %r3459 = getelementptr i64, ptr %r3410, i64 2
  %r3460 = load i64, ptr %r3459, align 8
  %r3461 = icmp ne i64 %r3460, 0
  br i1 %r3461, label %pic.desc.prefix.meta.593, label %pic.miss.cold.597

pic.desc.prefix.meta.593:                         ; preds = %pic.desc.prefix.guard.592
  %r3462 = add nuw nsw i64 %r3390, 8
  %r3463 = inttoptr i64 %r3462 to ptr
  %r3464 = load i64, ptr %r3463, align 8
  %r3465 = icmp ne i64 %r3464, 0
  br i1 %r3465, label %pic.desc.prefix.token.594, label %pic.miss.cold.597

pic.desc.prefix.token.594:                        ; preds = %pic.desc.prefix.meta.593
  %r3466 = inttoptr i64 %r3464 to ptr
  %r3467 = getelementptr i64, ptr %r3466, i64 6
  %r3468 = load i64, ptr %r3467, align 8
  %r3469 = icmp eq i64 %r3468, %r3460
  br i1 %r3469, label %pic.desc.prefix.hit.595, label %pic.miss.cold.597

pic.desc.prefix.hit.595:                          ; preds = %pic.desc.prefix.token.594
  %r3470 = getelementptr i64, ptr %r3410, i64 1
  %r3471 = load i64, ptr %r3470, align 8
  %r3472 = shl i64 %r3471, 3
  %r3473 = add nuw nsw i64 %r3390, 16
  %r3474 = add i64 %r3473, %r3472
  %r3475 = inttoptr i64 %r3474 to ptr
  %r3476 = load double, ptr %r3475, align 8
  br label %pic.merge.599

pic.miss.596:                                     ; preds = %pic.hit.inline.603, %pic.prefix.token.589, %pic.prefix.meta.588, %pic.prefix.guard.587
  %r3477 = getelementptr i64, ptr %r3410, i64 3
  %r3478 = load i64, ptr %r3477, align 8
  %r3479 = icmp sgt i64 %r3478, 0
  br i1 %r3479, label %pic.ways.604, label %pic.miss.call.598

pic.miss.cold.597:                                ; preds = %pic.desc.prefix.token.594, %pic.desc.prefix.meta.593, %pic.desc.prefix.guard.592, %pic.desc.classify.591, %pget.recv_ok.579
  br label %pic.miss.call.598

pic.miss.call.598:                                ; preds = %pic.way.load.605, %pic.ways.604, %pic.miss.cold.597, %pic.miss.596
  %r3518 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r3519 = bitcast double %r3518 to i64
  %r3520 = and i64 %r3519, 281474976710655
  %statepoint_token948 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r3390, i64 %r3520, ptr @perry_ic_test_json_source_token_length_ts__26, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s47, ptr addrspace(1) %.461324, ptr addrspace(1) %.46, ptr addrspace(1) %.331504, ptr addrspace(1) %.461430, ptr addrspace(1) %.461377, ptr addrspace(1) %.331562) ]
  %r3521949 = call double @llvm.experimental.gc.result.f64(token %statepoint_token948)
  %rs4gc.s47.relocated950 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token948, i32 0, i32 0) ; (%rs4gc.s47, %rs4gc.s47)
  %r48.0.base.relocated951 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token948, i32 1, i32 1) ; (%.461324, %.461324)
  %r55.0.base.relocated952 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token948, i32 2, i32 2) ; (%.46, %.46)
  %r1046.0.base.relocated953 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token948, i32 3, i32 3) ; (%.331504, %.331504)
  %r48.0.relocated954 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token948, i32 1, i32 4) ; (%.461324, %.461430)
  %r55.0.relocated955 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token948, i32 2, i32 5) ; (%.46, %.461377)
  %r1046.0.relocated956 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token948, i32 3, i32 6) ; (%.331504, %.331562)
  br label %pic.merge.599

pic.merge.599:                                    ; preds = %pic.way.live.606, %pic.hit.overflow.602, %pic.miss.call.598, %pic.desc.prefix.hit.595, %pic.prefix.hit.590, %pic.hit.live.586
  %.11667 = phi ptr addrspace(1) [ %rs4gc.s47.relocated959, %pic.hit.overflow.602 ], [ %rs4gc.s47.relocated950, %pic.miss.call.598 ], [ %rs4gc.s47, %pic.way.live.606 ], [ %rs4gc.s47, %pic.hit.live.586 ], [ %rs4gc.s47, %pic.prefix.hit.590 ], [ %rs4gc.s47, %pic.desc.prefix.hit.595 ]
  %.351564 = phi ptr addrspace(1) [ %r1046.0.relocated965, %pic.hit.overflow.602 ], [ %r1046.0.relocated956, %pic.miss.call.598 ], [ %.331562, %pic.way.live.606 ], [ %.331562, %pic.hit.live.586 ], [ %.331562, %pic.prefix.hit.590 ], [ %.331562, %pic.desc.prefix.hit.595 ]
  %.351506 = phi ptr addrspace(1) [ %r1046.0.base.relocated962, %pic.hit.overflow.602 ], [ %r1046.0.base.relocated953, %pic.miss.call.598 ], [ %.331504, %pic.way.live.606 ], [ %.331504, %pic.hit.live.586 ], [ %.331504, %pic.prefix.hit.590 ], [ %.331504, %pic.desc.prefix.hit.595 ]
  %.481432 = phi ptr addrspace(1) [ %r48.0.relocated963, %pic.hit.overflow.602 ], [ %r48.0.relocated954, %pic.miss.call.598 ], [ %.461430, %pic.way.live.606 ], [ %.461430, %pic.hit.live.586 ], [ %.461430, %pic.prefix.hit.590 ], [ %.461430, %pic.desc.prefix.hit.595 ]
  %.481379 = phi ptr addrspace(1) [ %r55.0.relocated964, %pic.hit.overflow.602 ], [ %r55.0.relocated955, %pic.miss.call.598 ], [ %.461377, %pic.way.live.606 ], [ %.461377, %pic.hit.live.586 ], [ %.461377, %pic.prefix.hit.590 ], [ %.461377, %pic.desc.prefix.hit.595 ]
  %.481326 = phi ptr addrspace(1) [ %r48.0.base.relocated960, %pic.hit.overflow.602 ], [ %r48.0.base.relocated951, %pic.miss.call.598 ], [ %.461324, %pic.way.live.606 ], [ %.461324, %pic.hit.live.586 ], [ %.461324, %pic.prefix.hit.590 ], [ %.461324, %pic.desc.prefix.hit.595 ]
  %.48 = phi ptr addrspace(1) [ %r55.0.base.relocated961, %pic.hit.overflow.602 ], [ %r55.0.base.relocated952, %pic.miss.call.598 ], [ %.46, %pic.way.live.606 ], [ %.46, %pic.hit.live.586 ], [ %.46, %pic.prefix.hit.590 ], [ %.46, %pic.desc.prefix.hit.595 ]
  %r3522 = phi double [ %r3438, %pic.hit.live.586 ], [ %r3433958, %pic.hit.overflow.602 ], [ %r3458, %pic.prefix.hit.590 ], [ %r3476, %pic.desc.prefix.hit.595 ], [ %r3515, %pic.way.live.606 ], [ %r3521949, %pic.miss.call.598 ]
  br label %pget.recv_merge.582

pic.recv_hdr.600:                                 ; preds = %pget.recv_ok.579
  %r3401 = sub nuw nsw i64 %r3390, 8
  %r3402 = inttoptr i64 %r3401 to ptr
  %r3403 = load i8, ptr %r3402, align 1
  %r3404 = icmp eq i8 %r3403, 2
  %r3405 = sub nuw nsw i64 %r3390, 6
  %r3406 = inttoptr i64 %r3405 to ptr
  %r3407 = load i16, ptr %r3406, align 2
  %r3408 = and i16 %r3407, 2048
  %r3409 = icmp eq i16 %r3408, 0
  %r3410 = load ptr, ptr @perry_ic_test_json_source_token_length_ts__26, align 8
  %r3411 = icmp ne ptr %r3410, null
  %r3412 = and i1 %r3404, %r3409
  %r3413 = and i1 %r3412, %r3411
  br i1 %r3413, label %pic.token.601, label %pic.desc.classify.591

pic.token.601:                                    ; preds = %pic.recv_hdr.600
  %r3415 = add nuw nsw i64 %r3390, 4
  %r3416 = inttoptr i64 %r3415 to ptr
  %r3417 = load i32, ptr %r3416, align 4
  %r3418 = zext i32 %r3417 to i64
  %r3419 = or i64 %r3418, 4611686018427387904
  %r3420 = icmp ne i32 %r3417, 0
  %r3421 = getelementptr i64, ptr %r3410, i64 0
  %r3422 = load i64, ptr %r3421, align 8
  %r3423 = icmp eq i64 %r3419, %r3422
  %r3424 = and i1 %r3423, %r3420
  br i1 %r3424, label %pic.hit.585, label %pic.prefix.guard.587

pic.hit.overflow.602:                             ; preds = %pic.hit.585
  %r3429 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r3430 = bitcast double %r3429 to i64
  %r3431 = and i64 %r3430, 281474976710655
  %r3432 = trunc i64 %r3426 to i32
  %statepoint_token957 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r3390, i64 %r3431, i32 %r3432, ptr @perry_ic_test_json_source_token_length_ts__26, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s47, ptr addrspace(1) %.461324, ptr addrspace(1) %.46, ptr addrspace(1) %.331504, ptr addrspace(1) %.461430, ptr addrspace(1) %.461377, ptr addrspace(1) %.331562) ]
  %r3433958 = call double @llvm.experimental.gc.result.f64(token %statepoint_token957)
  %rs4gc.s47.relocated959 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token957, i32 0, i32 0) ; (%rs4gc.s47, %rs4gc.s47)
  %r48.0.base.relocated960 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token957, i32 1, i32 1) ; (%.461324, %.461324)
  %r55.0.base.relocated961 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token957, i32 2, i32 2) ; (%.46, %.46)
  %r1046.0.base.relocated962 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token957, i32 3, i32 3) ; (%.331504, %.331504)
  %r48.0.relocated963 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token957, i32 1, i32 4) ; (%.461324, %.461430)
  %r55.0.relocated964 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token957, i32 2, i32 5) ; (%.46, %.461377)
  %r1046.0.relocated965 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token957, i32 3, i32 6) ; (%.331504, %.331562)
  br label %pic.merge.599

pic.hit.inline.603:                               ; preds = %pic.hit.585
  %r3434 = shl i64 %r3426, 3
  %r3435 = add nuw nsw i64 %r3390, 16
  %r3436 = add i64 %r3435, %r3434
  %r3437 = inttoptr i64 %r3436 to ptr
  %r3438 = load double, ptr %r3437, align 8
  %r3439 = bitcast double %r3438 to i64
  %r3440 = icmp eq i64 %r3439, 9222246136947933200
  br i1 %r3440, label %pic.miss.596, label %pic.hit.live.586

pic.ways.604:                                     ; preds = %pic.miss.596
  %r3480 = getelementptr i64, ptr %r3410, i64 4
  %r3481 = load i64, ptr %r3480, align 8
  %r3482 = icmp eq i64 %r3481, %r3419
  %r3483 = getelementptr i64, ptr %r3410, i64 5
  %r3484 = load i64, ptr %r3483, align 8
  %r3485 = select i1 %r3482, i64 %r3484, i64 0
  %r3486 = getelementptr i64, ptr %r3410, i64 6
  %r3487 = load i64, ptr %r3486, align 8
  %r3488 = icmp eq i64 %r3487, %r3419
  %r3489 = getelementptr i64, ptr %r3410, i64 7
  %r3490 = load i64, ptr %r3489, align 8
  %r3491 = select i1 %r3488, i64 %r3490, i64 0
  %r3492 = getelementptr i64, ptr %r3410, i64 8
  %r3493 = load i64, ptr %r3492, align 8
  %r3494 = icmp eq i64 %r3493, %r3419
  %r3495 = getelementptr i64, ptr %r3410, i64 9
  %r3496 = load i64, ptr %r3495, align 8
  %r3497 = select i1 %r3494, i64 %r3496, i64 0
  %r3498 = getelementptr i64, ptr %r3410, i64 10
  %r3499 = load i64, ptr %r3498, align 8
  %r3500 = icmp eq i64 %r3499, %r3419
  %r3501 = getelementptr i64, ptr %r3410, i64 11
  %r3502 = load i64, ptr %r3501, align 8
  %r3503 = select i1 %r3500, i64 %r3502, i64 0
  %r3504 = or i1 %r3482, %r3488
  %r3505 = select i1 %r3482, i64 %r3485, i64 %r3491
  %r3506 = or i1 %r3494, %r3500
  %r3507 = select i1 %r3494, i64 %r3497, i64 %r3503
  %r3508 = or i1 %r3504, %r3506
  %r3509 = select i1 %r3504, i64 %r3505, i64 %r3507
  %r3510 = and i1 %r3420, %r3508
  br i1 %r3510, label %pic.way.load.605, label %pic.miss.call.598

pic.way.load.605:                                 ; preds = %pic.ways.604
  %r3511 = shl i64 %r3509, 3
  %r3512 = add nuw nsw i64 %r3390, 16
  %r3513 = add i64 %r3512, %r3511
  %r3514 = inttoptr i64 %r3513 to ptr
  %r3515 = load double, ptr %r3514, align 8
  %r3516 = bitcast double %r3515 to i64
  %r3517 = icmp eq i64 %r3516, 9222246136947933200
  br i1 %r3517, label %pic.miss.call.598, label %pic.way.live.606

pic.way.live.606:                                 ; preds = %pic.way.load.605
  br label %pic.merge.599

pget.throw_nullish.607:                           ; preds = %pget.recv_bad.580
  %r3526 = zext i1 %r3524 to i32
  %statepoint_token966 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r3526, ptr @test_json_source_token_length_ts_.str.10.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.608:                       ; preds = %pget.recv_bad.580
  %r3527 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r3528 = bitcast double %r3527 to i64
  %r3529 = and i64 %r3528, 281474976710655
  %statepoint_token967 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3389, i64 %r3529, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s47, ptr addrspace(1) %.461324, ptr addrspace(1) %.46, ptr addrspace(1) %.331504, ptr addrspace(1) %.461430, ptr addrspace(1) %.461377, ptr addrspace(1) %.331562) ]
  %r3530968 = call double @llvm.experimental.gc.result.f64(token %statepoint_token967)
  %rs4gc.s47.relocated969 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token967, i32 0, i32 0) ; (%rs4gc.s47, %rs4gc.s47)
  %r48.0.base.relocated970 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token967, i32 1, i32 1) ; (%.461324, %.461324)
  %r55.0.base.relocated971 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token967, i32 2, i32 2) ; (%.46, %.46)
  %r1046.0.base.relocated972 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token967, i32 3, i32 3) ; (%.331504, %.331504)
  %r48.0.relocated973 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token967, i32 1, i32 4) ; (%.461324, %.461430)
  %r55.0.relocated974 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token967, i32 2, i32 5) ; (%.46, %.461377)
  %r1046.0.relocated975 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token967, i32 3, i32 6) ; (%.331504, %.331562)
  br label %pget.recv_merge.582

pget.recv_sso.609:                                ; preds = %pget.recv_other.615
  %r3679 = lshr i64 %r3536, 40
  %r3680 = and i64 %r3679, 255
  %r3681 = uitofp nneg i64 %r3680 to double
  br label %pget.recv_merge.613

pget.recv_ok.610:                                 ; preds = %pget.recv_merge.582
  %r3547 = icmp eq i64 %r3538, 32767
  br i1 %r3547, label %pget.strlen_heap.614, label %pget.recv_obj.617

pget.recv_bad.611:                                ; preds = %pget.check_class_ref.616
  %r3671 = icmp eq i64 %r3536, 9222246136947933185
  %r3672 = icmp eq i64 %r3536, 9222246136947933186
  %r3673 = or i1 %r3671, %r3672
  br i1 %r3673, label %pget.throw_nullish.640, label %pget.recv_undef_return.641

pget.recv_class_ref.612:                          ; preds = %pget.check_class_ref.616
  %r3543 = load double, ptr @test_json_source_token_length_ts_.str.12.handle, align 8
  %r3544 = bitcast double %r3543 to i64
  %r3545 = and i64 %r3544, 281474976710655
  %statepoint_token976 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 5587713372188573723, i64 %r3536, i64 %r3545, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.471325, ptr addrspace(1) %.47, ptr addrspace(1) %.341505, ptr addrspace(1) %.01666, ptr addrspace(1) %.471431, ptr addrspace(1) %.471378, ptr addrspace(1) %.341563) ]
  %r3546977 = call double @llvm.experimental.gc.result.f64(token %statepoint_token976)
  %r48.0.base.relocated978 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token976, i32 0, i32 0) ; (%.471325, %.471325)
  %r55.0.base.relocated979 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token976, i32 1, i32 1) ; (%.47, %.47)
  %r1046.0.base.relocated980 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token976, i32 2, i32 2) ; (%.341505, %.341505)
  %rs4gc.s47.relocated981 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token976, i32 3, i32 3) ; (%.01666, %.01666)
  %r48.0.relocated982 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token976, i32 0, i32 4) ; (%.471325, %.471431)
  %r55.0.relocated983 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token976, i32 1, i32 5) ; (%.47, %.471378)
  %r1046.0.relocated984 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token976, i32 2, i32 6) ; (%.341505, %.341563)
  br label %pget.recv_merge.613

pget.recv_merge.613:                              ; preds = %pget.recv_undef_return.641, %pic.merge.632, %pget.strlen_heap.614, %pget.recv_class_ref.612, %pget.recv_sso.609
  %.21668 = phi ptr addrspace(1) [ %.01666, %pget.strlen_heap.614 ], [ %.31669, %pic.merge.632 ], [ %.01666, %pget.recv_sso.609 ], [ %rs4gc.s47.relocated981, %pget.recv_class_ref.612 ], [ %rs4gc.s47.relocated1009, %pget.recv_undef_return.641 ]
  %.361565 = phi ptr addrspace(1) [ %.341563, %pget.strlen_heap.614 ], [ %.371566, %pic.merge.632 ], [ %.341563, %pget.recv_sso.609 ], [ %r1046.0.relocated984, %pget.recv_class_ref.612 ], [ %r1046.0.relocated1012, %pget.recv_undef_return.641 ]
  %.361507 = phi ptr addrspace(1) [ %.341505, %pget.strlen_heap.614 ], [ %.371508, %pic.merge.632 ], [ %.341505, %pget.recv_sso.609 ], [ %r1046.0.base.relocated980, %pget.recv_class_ref.612 ], [ %r1046.0.base.relocated1008, %pget.recv_undef_return.641 ]
  %.491433 = phi ptr addrspace(1) [ %.471431, %pget.strlen_heap.614 ], [ %.501434, %pic.merge.632 ], [ %.471431, %pget.recv_sso.609 ], [ %r48.0.relocated982, %pget.recv_class_ref.612 ], [ %r48.0.relocated1010, %pget.recv_undef_return.641 ]
  %.491380 = phi ptr addrspace(1) [ %.471378, %pget.strlen_heap.614 ], [ %.501381, %pic.merge.632 ], [ %.471378, %pget.recv_sso.609 ], [ %r55.0.relocated983, %pget.recv_class_ref.612 ], [ %r55.0.relocated1011, %pget.recv_undef_return.641 ]
  %.491327 = phi ptr addrspace(1) [ %.471325, %pget.strlen_heap.614 ], [ %.501328, %pic.merge.632 ], [ %.471325, %pget.recv_sso.609 ], [ %r48.0.base.relocated978, %pget.recv_class_ref.612 ], [ %r48.0.base.relocated1006, %pget.recv_undef_return.641 ]
  %.49 = phi ptr addrspace(1) [ %.47, %pget.strlen_heap.614 ], [ %.50, %pic.merge.632 ], [ %.47, %pget.recv_sso.609 ], [ %r55.0.base.relocated979, %pget.recv_class_ref.612 ], [ %r55.0.base.relocated1007, %pget.recv_undef_return.641 ]
  %r3687 = phi double [ %r3670, %pic.merge.632 ], [ %r36781005, %pget.recv_undef_return.641 ], [ %r3681, %pget.recv_sso.609 ], [ %r3546977, %pget.recv_class_ref.612 ], [ %r3686, %pget.strlen_heap.614 ]
  %r3688.rs4i = ptrtoint ptr addrspace(1) %.21668 to i64
  %r3688 = call i64 asm "", "=r,0"(i64 %r3688.rs4i) #7
  %r3689 = bitcast i64 %r3688 to double
  %r3690 = and i64 %r3688, -281474976710656
  %r3691 = icmp ult i64 %r3690, 9221401712017801216
  %r3692 = icmp ugt i64 %r3690, 9223090561878065152
  %r3693 = or i1 %r3691, %r3692
  %r3694 = bitcast double %r3687 to i64
  %r3695 = and i64 %r3694, -281474976710656
  %r3696 = icmp ult i64 %r3695, 9221401712017801216
  %r3697 = icmp ugt i64 %r3695, 9223090561878065152
  %r3698 = or i1 %r3696, %r3697
  %r3699 = and i1 %r3693, %r3698
  br i1 %r3699, label %guarded_add.numeric.642, label %guarded_add.dynamic.643

pget.strlen_heap.614:                             ; preds = %pget.recv_ok.610
  %r3682 = icmp ult i64 %r3537, 4096
  %r3683 = inttoptr i64 %r3537 to ptr
  %r3684 = select i1 %r3682, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r3683
  %r3685 = load i32, ptr %r3684, align 4
  %r3686 = uitofp i32 %r3685 to double
  br label %pget.recv_merge.613

pget.recv_other.615:                              ; preds = %pget.recv_merge.582
  %r3541 = icmp eq i64 %r3538, 32761
  br i1 %r3541, label %pget.recv_sso.609, label %pget.check_class_ref.616

pget.check_class_ref.616:                         ; preds = %pget.recv_other.615
  %r3542 = icmp eq i64 %r3538, 32766
  br i1 %r3542, label %pget.recv_class_ref.612, label %pget.recv_bad.611

pget.recv_obj.617:                                ; preds = %pget.recv_ok.610
  %r3548 = icmp ugt i64 %r3537, 1048575
  br i1 %r3548, label %pic.recv_hdr.633, label %pic.miss.cold.630

pic.hit.618:                                      ; preds = %pic.token.634
  %r3573 = getelementptr i64, ptr %r3558, i64 1
  %r3574 = load i64, ptr %r3573, align 8
  %r3575 = and i64 %r3574, 1073741824
  %r3576 = icmp ne i64 %r3575, 0
  br i1 %r3576, label %pic.hit.overflow.635, label %pic.hit.inline.636

pic.hit.live.619:                                 ; preds = %pic.hit.inline.636
  br label %pic.merge.632

pic.prefix.guard.620:                             ; preds = %pic.token.634
  %r3589 = getelementptr i64, ptr %r3558, i64 2
  %r3590 = load i64, ptr %r3589, align 8
  %r3591 = icmp ne i64 %r3590, 0
  br i1 %r3591, label %pic.prefix.meta.621, label %pic.miss.629

pic.prefix.meta.621:                              ; preds = %pic.prefix.guard.620
  %r3592 = add nuw nsw i64 %r3537, 8
  %r3593 = inttoptr i64 %r3592 to ptr
  %r3594 = load i64, ptr %r3593, align 8
  %r3595 = icmp ne i64 %r3594, 0
  br i1 %r3595, label %pic.prefix.token.622, label %pic.miss.629

pic.prefix.token.622:                             ; preds = %pic.prefix.meta.621
  %r3596 = inttoptr i64 %r3594 to ptr
  %r3597 = getelementptr i64, ptr %r3596, i64 6
  %r3598 = load i64, ptr %r3597, align 8
  %r3599 = icmp eq i64 %r3598, %r3590
  br i1 %r3599, label %pic.prefix.hit.623, label %pic.miss.629

pic.prefix.hit.623:                               ; preds = %pic.prefix.token.622
  %r3600 = getelementptr i64, ptr %r3558, i64 1
  %r3601 = load i64, ptr %r3600, align 8
  %r3602 = shl i64 %r3601, 3
  %r3603 = add nuw nsw i64 %r3537, 16
  %r3604 = add i64 %r3603, %r3602
  %r3605 = inttoptr i64 %r3604 to ptr
  %r3606 = load double, ptr %r3605, align 8
  br label %pic.merge.632

pic.desc.classify.624:                            ; preds = %pic.recv_hdr.633
  %r3562 = and i1 %r3552, %r3559
  br i1 %r3562, label %pic.desc.prefix.guard.625, label %pic.miss.cold.630

pic.desc.prefix.guard.625:                        ; preds = %pic.desc.classify.624
  %r3607 = getelementptr i64, ptr %r3558, i64 2
  %r3608 = load i64, ptr %r3607, align 8
  %r3609 = icmp ne i64 %r3608, 0
  br i1 %r3609, label %pic.desc.prefix.meta.626, label %pic.miss.cold.630

pic.desc.prefix.meta.626:                         ; preds = %pic.desc.prefix.guard.625
  %r3610 = add nuw nsw i64 %r3537, 8
  %r3611 = inttoptr i64 %r3610 to ptr
  %r3612 = load i64, ptr %r3611, align 8
  %r3613 = icmp ne i64 %r3612, 0
  br i1 %r3613, label %pic.desc.prefix.token.627, label %pic.miss.cold.630

pic.desc.prefix.token.627:                        ; preds = %pic.desc.prefix.meta.626
  %r3614 = inttoptr i64 %r3612 to ptr
  %r3615 = getelementptr i64, ptr %r3614, i64 6
  %r3616 = load i64, ptr %r3615, align 8
  %r3617 = icmp eq i64 %r3616, %r3608
  br i1 %r3617, label %pic.desc.prefix.hit.628, label %pic.miss.cold.630

pic.desc.prefix.hit.628:                          ; preds = %pic.desc.prefix.token.627
  %r3618 = getelementptr i64, ptr %r3558, i64 1
  %r3619 = load i64, ptr %r3618, align 8
  %r3620 = shl i64 %r3619, 3
  %r3621 = add nuw nsw i64 %r3537, 16
  %r3622 = add i64 %r3621, %r3620
  %r3623 = inttoptr i64 %r3622 to ptr
  %r3624 = load double, ptr %r3623, align 8
  br label %pic.merge.632

pic.miss.629:                                     ; preds = %pic.hit.inline.636, %pic.prefix.token.622, %pic.prefix.meta.621, %pic.prefix.guard.620
  %r3625 = getelementptr i64, ptr %r3558, i64 3
  %r3626 = load i64, ptr %r3625, align 8
  %r3627 = icmp sgt i64 %r3626, 0
  br i1 %r3627, label %pic.ways.637, label %pic.miss.call.631

pic.miss.cold.630:                                ; preds = %pic.desc.prefix.token.627, %pic.desc.prefix.meta.626, %pic.desc.prefix.guard.625, %pic.desc.classify.624, %pget.recv_obj.617
  br label %pic.miss.call.631

pic.miss.call.631:                                ; preds = %pic.way.load.638, %pic.ways.637, %pic.miss.cold.630, %pic.miss.629
  %r3666 = load double, ptr @test_json_source_token_length_ts_.str.12.handle, align 8
  %r3667 = bitcast double %r3666 to i64
  %r3668 = and i64 %r3667, 281474976710655
  %statepoint_token985 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r3537, i64 %r3668, ptr @perry_ic_test_json_source_token_length_ts__28, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.471325, ptr addrspace(1) %.47, ptr addrspace(1) %.341505, ptr addrspace(1) %.01666, ptr addrspace(1) %.471431, ptr addrspace(1) %.471378, ptr addrspace(1) %.341563) ]
  %r3669986 = call double @llvm.experimental.gc.result.f64(token %statepoint_token985)
  %r48.0.base.relocated987 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token985, i32 0, i32 0) ; (%.471325, %.471325)
  %r55.0.base.relocated988 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token985, i32 1, i32 1) ; (%.47, %.47)
  %r1046.0.base.relocated989 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token985, i32 2, i32 2) ; (%.341505, %.341505)
  %rs4gc.s47.relocated990 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token985, i32 3, i32 3) ; (%.01666, %.01666)
  %r48.0.relocated991 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token985, i32 0, i32 4) ; (%.471325, %.471431)
  %r55.0.relocated992 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token985, i32 1, i32 5) ; (%.47, %.471378)
  %r1046.0.relocated993 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token985, i32 2, i32 6) ; (%.341505, %.341563)
  br label %pic.merge.632

pic.merge.632:                                    ; preds = %pic.way.live.639, %pic.hit.overflow.635, %pic.miss.call.631, %pic.desc.prefix.hit.628, %pic.prefix.hit.623, %pic.hit.live.619
  %.31669 = phi ptr addrspace(1) [ %rs4gc.s47.relocated999, %pic.hit.overflow.635 ], [ %rs4gc.s47.relocated990, %pic.miss.call.631 ], [ %.01666, %pic.way.live.639 ], [ %.01666, %pic.hit.live.619 ], [ %.01666, %pic.prefix.hit.623 ], [ %.01666, %pic.desc.prefix.hit.628 ]
  %.371566 = phi ptr addrspace(1) [ %r1046.0.relocated1002, %pic.hit.overflow.635 ], [ %r1046.0.relocated993, %pic.miss.call.631 ], [ %.341563, %pic.way.live.639 ], [ %.341563, %pic.hit.live.619 ], [ %.341563, %pic.prefix.hit.623 ], [ %.341563, %pic.desc.prefix.hit.628 ]
  %.371508 = phi ptr addrspace(1) [ %r1046.0.base.relocated998, %pic.hit.overflow.635 ], [ %r1046.0.base.relocated989, %pic.miss.call.631 ], [ %.341505, %pic.way.live.639 ], [ %.341505, %pic.hit.live.619 ], [ %.341505, %pic.prefix.hit.623 ], [ %.341505, %pic.desc.prefix.hit.628 ]
  %.501434 = phi ptr addrspace(1) [ %r48.0.relocated1000, %pic.hit.overflow.635 ], [ %r48.0.relocated991, %pic.miss.call.631 ], [ %.471431, %pic.way.live.639 ], [ %.471431, %pic.hit.live.619 ], [ %.471431, %pic.prefix.hit.623 ], [ %.471431, %pic.desc.prefix.hit.628 ]
  %.501381 = phi ptr addrspace(1) [ %r55.0.relocated1001, %pic.hit.overflow.635 ], [ %r55.0.relocated992, %pic.miss.call.631 ], [ %.471378, %pic.way.live.639 ], [ %.471378, %pic.hit.live.619 ], [ %.471378, %pic.prefix.hit.623 ], [ %.471378, %pic.desc.prefix.hit.628 ]
  %.501328 = phi ptr addrspace(1) [ %r48.0.base.relocated996, %pic.hit.overflow.635 ], [ %r48.0.base.relocated987, %pic.miss.call.631 ], [ %.471325, %pic.way.live.639 ], [ %.471325, %pic.hit.live.619 ], [ %.471325, %pic.prefix.hit.623 ], [ %.471325, %pic.desc.prefix.hit.628 ]
  %.50 = phi ptr addrspace(1) [ %r55.0.base.relocated997, %pic.hit.overflow.635 ], [ %r55.0.base.relocated988, %pic.miss.call.631 ], [ %.47, %pic.way.live.639 ], [ %.47, %pic.hit.live.619 ], [ %.47, %pic.prefix.hit.623 ], [ %.47, %pic.desc.prefix.hit.628 ]
  %r3670 = phi double [ %r3586, %pic.hit.live.619 ], [ %r3581995, %pic.hit.overflow.635 ], [ %r3606, %pic.prefix.hit.623 ], [ %r3624, %pic.desc.prefix.hit.628 ], [ %r3663, %pic.way.live.639 ], [ %r3669986, %pic.miss.call.631 ]
  br label %pget.recv_merge.613

pic.recv_hdr.633:                                 ; preds = %pget.recv_obj.617
  %r3549 = sub nuw nsw i64 %r3537, 8
  %r3550 = inttoptr i64 %r3549 to ptr
  %r3551 = load i8, ptr %r3550, align 1
  %r3552 = icmp eq i8 %r3551, 2
  %r3553 = sub nuw nsw i64 %r3537, 6
  %r3554 = inttoptr i64 %r3553 to ptr
  %r3555 = load i16, ptr %r3554, align 2
  %r3556 = and i16 %r3555, 2048
  %r3557 = icmp eq i16 %r3556, 0
  %r3558 = load ptr, ptr @perry_ic_test_json_source_token_length_ts__28, align 8
  %r3559 = icmp ne ptr %r3558, null
  %r3560 = and i1 %r3552, %r3557
  %r3561 = and i1 %r3560, %r3559
  br i1 %r3561, label %pic.token.634, label %pic.desc.classify.624

pic.token.634:                                    ; preds = %pic.recv_hdr.633
  %r3563 = add nuw nsw i64 %r3537, 4
  %r3564 = inttoptr i64 %r3563 to ptr
  %r3565 = load i32, ptr %r3564, align 4
  %r3566 = zext i32 %r3565 to i64
  %r3567 = or i64 %r3566, 4611686018427387904
  %r3568 = icmp ne i32 %r3565, 0
  %r3569 = getelementptr i64, ptr %r3558, i64 0
  %r3570 = load i64, ptr %r3569, align 8
  %r3571 = icmp eq i64 %r3567, %r3570
  %r3572 = and i1 %r3571, %r3568
  br i1 %r3572, label %pic.hit.618, label %pic.prefix.guard.620

pic.hit.overflow.635:                             ; preds = %pic.hit.618
  %r3577 = load double, ptr @test_json_source_token_length_ts_.str.12.handle, align 8
  %r3578 = bitcast double %r3577 to i64
  %r3579 = and i64 %r3578, 281474976710655
  %r3580 = trunc i64 %r3574 to i32
  %statepoint_token994 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r3537, i64 %r3579, i32 %r3580, ptr @perry_ic_test_json_source_token_length_ts__28, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.471325, ptr addrspace(1) %.47, ptr addrspace(1) %.341505, ptr addrspace(1) %.01666, ptr addrspace(1) %.471431, ptr addrspace(1) %.471378, ptr addrspace(1) %.341563) ]
  %r3581995 = call double @llvm.experimental.gc.result.f64(token %statepoint_token994)
  %r48.0.base.relocated996 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token994, i32 0, i32 0) ; (%.471325, %.471325)
  %r55.0.base.relocated997 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token994, i32 1, i32 1) ; (%.47, %.47)
  %r1046.0.base.relocated998 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token994, i32 2, i32 2) ; (%.341505, %.341505)
  %rs4gc.s47.relocated999 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token994, i32 3, i32 3) ; (%.01666, %.01666)
  %r48.0.relocated1000 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token994, i32 0, i32 4) ; (%.471325, %.471431)
  %r55.0.relocated1001 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token994, i32 1, i32 5) ; (%.47, %.471378)
  %r1046.0.relocated1002 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token994, i32 2, i32 6) ; (%.341505, %.341563)
  br label %pic.merge.632

pic.hit.inline.636:                               ; preds = %pic.hit.618
  %r3582 = shl i64 %r3574, 3
  %r3583 = add nuw nsw i64 %r3537, 16
  %r3584 = add i64 %r3583, %r3582
  %r3585 = inttoptr i64 %r3584 to ptr
  %r3586 = load double, ptr %r3585, align 8
  %r3587 = bitcast double %r3586 to i64
  %r3588 = icmp eq i64 %r3587, 9222246136947933200
  br i1 %r3588, label %pic.miss.629, label %pic.hit.live.619

pic.ways.637:                                     ; preds = %pic.miss.629
  %r3628 = getelementptr i64, ptr %r3558, i64 4
  %r3629 = load i64, ptr %r3628, align 8
  %r3630 = icmp eq i64 %r3629, %r3567
  %r3631 = getelementptr i64, ptr %r3558, i64 5
  %r3632 = load i64, ptr %r3631, align 8
  %r3633 = select i1 %r3630, i64 %r3632, i64 0
  %r3634 = getelementptr i64, ptr %r3558, i64 6
  %r3635 = load i64, ptr %r3634, align 8
  %r3636 = icmp eq i64 %r3635, %r3567
  %r3637 = getelementptr i64, ptr %r3558, i64 7
  %r3638 = load i64, ptr %r3637, align 8
  %r3639 = select i1 %r3636, i64 %r3638, i64 0
  %r3640 = getelementptr i64, ptr %r3558, i64 8
  %r3641 = load i64, ptr %r3640, align 8
  %r3642 = icmp eq i64 %r3641, %r3567
  %r3643 = getelementptr i64, ptr %r3558, i64 9
  %r3644 = load i64, ptr %r3643, align 8
  %r3645 = select i1 %r3642, i64 %r3644, i64 0
  %r3646 = getelementptr i64, ptr %r3558, i64 10
  %r3647 = load i64, ptr %r3646, align 8
  %r3648 = icmp eq i64 %r3647, %r3567
  %r3649 = getelementptr i64, ptr %r3558, i64 11
  %r3650 = load i64, ptr %r3649, align 8
  %r3651 = select i1 %r3648, i64 %r3650, i64 0
  %r3652 = or i1 %r3630, %r3636
  %r3653 = select i1 %r3630, i64 %r3633, i64 %r3639
  %r3654 = or i1 %r3642, %r3648
  %r3655 = select i1 %r3642, i64 %r3645, i64 %r3651
  %r3656 = or i1 %r3652, %r3654
  %r3657 = select i1 %r3652, i64 %r3653, i64 %r3655
  %r3658 = and i1 %r3568, %r3656
  br i1 %r3658, label %pic.way.load.638, label %pic.miss.call.631

pic.way.load.638:                                 ; preds = %pic.ways.637
  %r3659 = shl i64 %r3657, 3
  %r3660 = add nuw nsw i64 %r3537, 16
  %r3661 = add i64 %r3660, %r3659
  %r3662 = inttoptr i64 %r3661 to ptr
  %r3663 = load double, ptr %r3662, align 8
  %r3664 = bitcast double %r3663 to i64
  %r3665 = icmp eq i64 %r3664, 9222246136947933200
  br i1 %r3665, label %pic.miss.call.631, label %pic.way.live.639

pic.way.live.639:                                 ; preds = %pic.way.load.638
  br label %pic.merge.632

pget.throw_nullish.640:                           ; preds = %pget.recv_bad.611
  %r3674 = zext i1 %r3672 to i32
  %statepoint_token1003 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r3674, ptr @test_json_source_token_length_ts_.str.12.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.641:                       ; preds = %pget.recv_bad.611
  %r3675 = load double, ptr @test_json_source_token_length_ts_.str.12.handle, align 8
  %r3676 = bitcast double %r3675 to i64
  %r3677 = and i64 %r3676, 281474976710655
  %statepoint_token1004 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3536, i64 %r3677, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.471325, ptr addrspace(1) %.47, ptr addrspace(1) %.341505, ptr addrspace(1) %.01666, ptr addrspace(1) %.471431, ptr addrspace(1) %.471378, ptr addrspace(1) %.341563) ]
  %r36781005 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1004)
  %r48.0.base.relocated1006 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1004, i32 0, i32 0) ; (%.471325, %.471325)
  %r55.0.base.relocated1007 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1004, i32 1, i32 1) ; (%.47, %.47)
  %r1046.0.base.relocated1008 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1004, i32 2, i32 2) ; (%.341505, %.341505)
  %rs4gc.s47.relocated1009 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1004, i32 3, i32 3) ; (%.01666, %.01666)
  %r48.0.relocated1010 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1004, i32 0, i32 4) ; (%.471325, %.471431)
  %r55.0.relocated1011 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1004, i32 1, i32 5) ; (%.47, %.471378)
  %r1046.0.relocated1012 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1004, i32 2, i32 6) ; (%.341505, %.341563)
  br label %pget.recv_merge.613

guarded_add.numeric.642:                          ; preds = %pget.recv_merge.613
  %r3700 = fadd double %r3689, %r3687
  br label %guarded_add.merge.644

guarded_add.dynamic.643:                          ; preds = %pget.recv_merge.613
  %statepoint_token1013 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r3689, double %r3687, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.491327, ptr addrspace(1) %.49, ptr addrspace(1) %.361507, ptr addrspace(1) %.491433, ptr addrspace(1) %.491380, ptr addrspace(1) %.361565) ]
  %r37011014 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1013)
  %r48.0.base.relocated1015 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1013, i32 0, i32 0) ; (%.491327, %.491327)
  %r55.0.base.relocated1016 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1013, i32 1, i32 1) ; (%.49, %.49)
  %r1046.0.base.relocated1017 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1013, i32 2, i32 2) ; (%.361507, %.361507)
  %r48.0.relocated1018 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1013, i32 0, i32 3) ; (%.491327, %.491433)
  %r55.0.relocated1019 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1013, i32 1, i32 4) ; (%.49, %.491380)
  %r1046.0.relocated1020 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1013, i32 2, i32 5) ; (%.361507, %.361565)
  br label %guarded_add.merge.644

guarded_add.merge.644:                            ; preds = %guarded_add.dynamic.643, %guarded_add.numeric.642
  %.381567 = phi ptr addrspace(1) [ %.361565, %guarded_add.numeric.642 ], [ %r1046.0.relocated1020, %guarded_add.dynamic.643 ]
  %.381509 = phi ptr addrspace(1) [ %.361507, %guarded_add.numeric.642 ], [ %r1046.0.base.relocated1017, %guarded_add.dynamic.643 ]
  %.511435 = phi ptr addrspace(1) [ %.491433, %guarded_add.numeric.642 ], [ %r48.0.relocated1018, %guarded_add.dynamic.643 ]
  %.511382 = phi ptr addrspace(1) [ %.491380, %guarded_add.numeric.642 ], [ %r55.0.relocated1019, %guarded_add.dynamic.643 ]
  %.511329 = phi ptr addrspace(1) [ %.491327, %guarded_add.numeric.642 ], [ %r48.0.base.relocated1015, %guarded_add.dynamic.643 ]
  %.51 = phi ptr addrspace(1) [ %.49, %guarded_add.numeric.642 ], [ %r55.0.base.relocated1016, %guarded_add.dynamic.643 ]
  %r3702 = phi double [ %r3700, %guarded_add.numeric.642 ], [ %r37011014, %guarded_add.dynamic.643 ]
  %rs4gc.b48 = bitcast double %r3702 to i64
  %rs4gc.s48 = inttoptr i64 %rs4gc.b48 to ptr addrspace(1)
  %r3703.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s48 to i64
  %r3703 = call i64 asm "", "=r,0"(i64 %r3703.rs4i) #7
  %r3704 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3705 = icmp ne i32 %r3704, 0
  br i1 %r3705, label %shadow.root.barrier.645, label %shadow.root.barrier.done.646

shadow.root.barrier.645:                          ; preds = %guarded_add.merge.644
  call void @js_write_barrier_root_nanbox(i64 %r3703) #7
  br label %shadow.root.barrier.done.646

shadow.root.barrier.done.646:                     ; preds = %shadow.root.barrier.645, %guarded_add.merge.644
  %r3706 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r3707 = icmp ne i32 %r3706, 0
  br i1 %r3707, label %gcpoll.647, label %gcpoll.done.648

gcpoll.647:                                       ; preds = %shadow.root.barrier.done.646
  %statepoint_token1021 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s48, ptr addrspace(1) %.511329, ptr addrspace(1) %.51, ptr addrspace(1) %.381509, ptr addrspace(1) %.511435, ptr addrspace(1) %.511382, ptr addrspace(1) %.381567) ]
  %rs4gc.s48.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1021, i32 0, i32 0) ; (%rs4gc.s48, %rs4gc.s48)
  %r48.0.base.relocated1022 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1021, i32 1, i32 1) ; (%.511329, %.511329)
  %r55.0.base.relocated1023 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1021, i32 2, i32 2) ; (%.51, %.51)
  %r1046.0.base.relocated1024 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1021, i32 3, i32 3) ; (%.381509, %.381509)
  %r48.0.relocated1025 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1021, i32 1, i32 4) ; (%.511329, %.511435)
  %r55.0.relocated1026 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1021, i32 2, i32 5) ; (%.51, %.511382)
  %r1046.0.relocated1027 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1021, i32 3, i32 6) ; (%.381509, %.381567)
  br label %gcpoll.done.648

gcpoll.done.648:                                  ; preds = %gcpoll.647, %shadow.root.barrier.done.646
  %.01670 = phi ptr addrspace(1) [ %rs4gc.s48.relocated, %gcpoll.647 ], [ %rs4gc.s48, %shadow.root.barrier.done.646 ]
  %.391568 = phi ptr addrspace(1) [ %r1046.0.relocated1027, %gcpoll.647 ], [ %.381567, %shadow.root.barrier.done.646 ]
  %.391510 = phi ptr addrspace(1) [ %r1046.0.base.relocated1024, %gcpoll.647 ], [ %.381509, %shadow.root.barrier.done.646 ]
  %.521436 = phi ptr addrspace(1) [ %r48.0.relocated1025, %gcpoll.647 ], [ %.511435, %shadow.root.barrier.done.646 ]
  %.521383 = phi ptr addrspace(1) [ %r55.0.relocated1026, %gcpoll.647 ], [ %.511382, %shadow.root.barrier.done.646 ]
  %.521330 = phi ptr addrspace(1) [ %r48.0.base.relocated1022, %gcpoll.647 ], [ %.511329, %shadow.root.barrier.done.646 ]
  %.52 = phi ptr addrspace(1) [ %r55.0.base.relocated1023, %gcpoll.647 ], [ %.51, %shadow.root.barrier.done.646 ]
  br label %for.update.381

for.cond.649:                                     ; preds = %for.update.651, %for.exit.382
  %.01618 = phi ptr addrspace(1) [ %.31621, %for.exit.382 ], [ %.271645, %for.update.651 ]
  %.151544 = phi ptr addrspace(1) [ %.181547, %for.exit.382 ], [ %.481577, %for.update.651 ]
  %.151486 = phi ptr addrspace(1) [ %.181489, %for.exit.382 ], [ %.481519, %for.update.651 ]
  %.281412 = phi ptr addrspace(1) [ %.311415, %for.exit.382 ], [ %.611445, %for.update.651 ]
  %.281306 = phi ptr addrspace(1) [ %.311309, %for.exit.382 ], [ %.61, %for.update.651 ]
  %r3712.0 = phi i32 [ 0, %for.exit.382 ], [ %r4243, %for.update.651 ]
  %r3714 = sitofp i32 %r3712.0 to double
  %r3715.rs4i = ptrtoint ptr addrspace(1) %.281412 to i64
  %r3715.rs4o = call i64 asm "", "=r,0"(i64 %r3715.rs4i) #7
  %r3715 = bitcast i64 %r3715.rs4o to double
  %r3716 = bitcast double %r3715 to i64
  %r3717 = and i64 %r3716, 281474976710655
  %r3718 = lshr i64 %r3716, 48
  %r3719 = and i64 %r3718, 65533
  %r3720 = icmp eq i64 %r3719, 32765
  %r3721 = icmp ugt i64 %r3717, 1048575
  %r3722 = and i1 %r3720, %r3721
  br i1 %r3722, label %plen.check_gc.653, label %plen.slow.655

for.body.650:                                     ; preds = %gcpoll.done.675
  %r3829.rs4i = ptrtoint ptr addrspace(1) %.551439 to i64
  %r3829.rs4o = call i64 asm "", "=r,0"(i64 %r3829.rs4i) #7
  %r3829 = bitcast i64 %r3829.rs4o to double
  %r3831 = bitcast double %r3829 to i64
  %r3832 = and i64 %r3831, 281474976710655
  %r3833 = lshr i64 %r3831, 48
  %r3834 = icmp eq i64 %r3833, 32765
  %r3835 = icmp ugt i64 %r3832, 1048575
  %r3836 = and i1 %r3834, %r3835
  br i1 %r3836, label %arr.guard.deref.680, label %arr.fallback.677

for.update.651:                                   ; preds = %gcpoll.done.760
  %r4243 = add i32 %r3712.0, 1
  %r4244 = sitofp i32 %r3712.0 to double
  %r4245 = sitofp i32 %r4243 to double
  br label %for.cond.649

for.exit.652:                                     ; preds = %gcpoll.done.675
  %statepoint_token1028 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.211639, ptr addrspace(1) %.421571, ptr addrspace(1) %.421513) ]
  %r42461029 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1028)
  %r1053.1.relocated1030 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1028, i32 0, i32 0) ; (%.211639, %.211639)
  %r1046.0.relocated1031 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1028, i32 2, i32 1) ; (%.421513, %.421571)
  %r1046.0.base.relocated1032 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1028, i32 2, i32 2) ; (%.421513, %.421513)
  %rs4gc.s49 = inttoptr i64 %r42461029 to ptr addrspace(1)
  %r4247.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s49 to i64
  %r4247 = call i64 asm "", "=r,0"(i64 %r4247.rs4i) #7
  %r4248 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4249 = icmp ne i32 %r4248, 0
  br i1 %r4249, label %shadow.root.barrier.761, label %shadow.root.barrier.done.762

plen.check_gc.653:                                ; preds = %for.cond.649
  %r3723 = sub nuw nsw i64 %r3717, 8
  %r3724 = inttoptr i64 %r3723 to ptr
  %r3725 = load i8, ptr %r3724, align 1
  %r3726 = icmp eq i8 %r3725, 1
  %r3727 = icmp eq i8 %r3725, 3
  %r3728 = or i1 %r3726, %r3727
  %r3729 = sub nuw nsw i64 %r3717, 7
  %r3730 = inttoptr i64 %r3729 to ptr
  %r3731 = load i8, ptr %r3730, align 1
  %r3732 = and i8 %r3731, -128
  %r3733 = icmp eq i8 %r3732, 0
  %r3734 = and i1 %r3728, %r3733
  br i1 %r3734, label %plen.fast.654, label %plen.slow.655

plen.fast.654:                                    ; preds = %plen.check_gc.653
  %r3736 = inttoptr i64 %r3717 to ptr
  %r3737 = select i1 false, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r3736
  %r3738 = load i32, ptr %r3737, align 4
  %r3739 = uitofp i32 %r3738 to double
  br label %plen.merge.656

plen.slow.655:                                    ; preds = %plen.check_gc.653, %for.cond.649
  %r3740 = lshr i64 %r3716, 48
  %r3741 = icmp eq i64 %r3740, 32765
  %r3742 = icmp uge i64 %r3717, 2199023255552
  %r3743 = icmp ult i64 %r3717, 140737488355328
  %r3744 = and i1 %r3741, %r3742
  %r3745 = and i1 %r3744, %r3743
  %r3746 = load ptr, ptr @perry_ic_test_json_source_token_length_ts__29, align 8
  br i1 %r3745, label %plen.ic.header.657, label %plen.ic.miss.669

plen.merge.656:                                   ; preds = %plen.ic.merge.670, %plen.fast.654
  %.191637 = phi ptr addrspace(1) [ %.01618, %plen.fast.654 ], [ %.201638, %plen.ic.merge.670 ]
  %.401569 = phi ptr addrspace(1) [ %.151544, %plen.fast.654 ], [ %.411570, %plen.ic.merge.670 ]
  %.401511 = phi ptr addrspace(1) [ %.151486, %plen.fast.654 ], [ %.411512, %plen.ic.merge.670 ]
  %.531437 = phi ptr addrspace(1) [ %.281412, %plen.fast.654 ], [ %.541438, %plen.ic.merge.670 ]
  %.53 = phi ptr addrspace(1) [ %.281306, %plen.fast.654 ], [ %.54, %plen.ic.merge.670 ]
  %r3821 = phi double [ %r3739, %plen.fast.654 ], [ %r3820, %plen.ic.merge.670 ]
  %r3822 = fcmp olt double %r3714, %r3821
  %r3823 = select i1 %r3822, i64 9222246136947933188, i64 9222246136947933187
  %r3824 = bitcast i64 %r3823 to double
  %r3826 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r3827 = icmp ne i32 %r3826, 0
  br i1 %r3827, label %gcpoll.674, label %gcpoll.done.675

plen.ic.header.657:                               ; preds = %plen.slow.655
  %r3748 = sub nuw nsw i64 %r3717, 8
  %r3749 = inttoptr i64 %r3748 to ptr
  %r3750 = load i8, ptr %r3749, align 1
  %r3751 = icmp eq i8 %r3750, 2
  %r3752 = sub nuw nsw i64 %r3717, 7
  %r3753 = inttoptr i64 %r3752 to ptr
  %r3754 = load i8, ptr %r3753, align 1
  %r3755 = and i8 %r3754, -128
  %r3756 = icmp eq i8 %r3755, 0
  %r3757 = and i1 %r3751, %r3756
  br i1 %r3757, label %plen.elem.meta.671, label %plen.ic.miss.669

plen.ic.shape.658:                                ; preds = %plen.elem.store.672, %plen.elem.meta.671
  %r3747 = icmp ne ptr %r3746, null
  br i1 %r3747, label %plen.ic.shape.probe.659, label %plen.ic.miss.669

plen.ic.shape.probe.659:                          ; preds = %plen.ic.shape.658
  %r3769 = inttoptr i64 %r3717 to ptr
  %r3770 = load i32, ptr %r3769, align 4
  %r3771 = add nuw nsw i64 %r3717, 4
  %r3772 = inttoptr i64 %r3771 to ptr
  %r3773 = load i32, ptr %r3772, align 4
  %r3774 = zext i32 %r3770 to i64
  %r3775 = zext i32 %r3773 to i64
  %r3776 = shl nuw i64 %r3774, 32
  %r3777 = or i64 %r3776, %r3775
  %r3778 = getelementptr i64, ptr %r3746, i64 0
  %r3779 = load i64, ptr %r3778, align 8
  %r3780 = icmp ne i64 %r3779, 0
  br i1 %r3780, label %plen.ic.identity.660, label %plen.ic.miss.669

plen.ic.identity.660:                             ; preds = %plen.ic.shape.probe.659
  %r3781 = and i64 %r3779, -9223372036854775808
  %4 = icmp slt i64 %r3779, 0
  br i1 %4, label %plen.ic.family_meta.662, label %plen.ic.exact.661

plen.ic.exact.661:                                ; preds = %plen.ic.identity.660
  %r3783 = icmp eq i64 %r3777, %r3779
  br i1 %r3783, label %plen.ic.slot.664, label %plen.ic.miss.669

plen.ic.family_meta.662:                          ; preds = %plen.ic.identity.660
  %r3784 = add nuw nsw i64 %r3717, 8
  %r3785 = inttoptr i64 %r3784 to ptr
  %r3786 = load i64, ptr %r3785, align 8
  %r3787 = icmp ne i64 %r3786, 0
  br i1 %r3787, label %plen.ic.family_token.663, label %plen.ic.miss.669

plen.ic.family_token.663:                         ; preds = %plen.ic.family_meta.662
  %r3788 = inttoptr i64 %r3786 to ptr
  %r3789 = getelementptr i64, ptr %r3788, i64 6
  %r3790 = load i64, ptr %r3789, align 8
  %r3791 = icmp eq i64 %r3790, %r3779
  br i1 %r3791, label %plen.ic.slot.664, label %plen.ic.miss.669

plen.ic.slot.664:                                 ; preds = %plen.ic.family_token.663, %plen.ic.exact.661
  %r3792 = getelementptr i64, ptr %r3746, i64 1
  %r3793 = load i64, ptr %r3792, align 8
  %r3794 = getelementptr i64, ptr %r3746, i64 2
  %r3795 = load i64, ptr %r3794, align 8
  %r3796 = icmp ult i64 %r3793, %r3795
  br i1 %r3796, label %plen.ic.inline.665, label %plen.ic.spill_meta.666

plen.ic.inline.665:                               ; preds = %plen.ic.slot.664
  %r3797 = shl i64 %r3793, 3
  %r3798 = add i64 %r3797, 16
  %r3799 = add i64 %r3717, %r3798
  %r3800 = inttoptr i64 %r3799 to ptr
  %r3801 = load double, ptr %r3800, align 8
  br label %plen.ic.merge.670

plen.ic.spill_meta.666:                           ; preds = %plen.ic.slot.664
  %r3802 = add nuw nsw i64 %r3717, 8
  %r3803 = inttoptr i64 %r3802 to ptr
  %r3804 = load i64, ptr %r3803, align 8
  %r3805 = icmp ne i64 %r3804, 0
  br i1 %r3805, label %plen.ic.spill_ptr.667, label %plen.ic.miss.669

plen.ic.spill_ptr.667:                            ; preds = %plen.ic.spill_meta.666
  %r3806 = inttoptr i64 %r3804 to ptr
  %r3807 = getelementptr i64, ptr %r3806, i64 4
  %r3808 = load i64, ptr %r3807, align 8
  %r3809 = icmp ne i64 %r3808, 0
  %r3810 = select i1 %r3809, i64 %r3808, i64 %r3804
  %r3811 = inttoptr i64 %r3810 to ptr
  %r3812 = load i32, ptr %r3811, align 4
  %r3813 = zext i32 %r3812 to i64
  %r3814 = icmp ult i64 %r3793, %r3813
  %r3815 = and i1 %r3809, %r3814
  br i1 %r3815, label %plen.ic.spill_load.668, label %plen.ic.miss.669

plen.ic.spill_load.668:                           ; preds = %plen.ic.spill_ptr.667
  %r3816 = add nuw nsw i64 %r3793, 1
  %r3817 = getelementptr inbounds nuw i64, ptr %r3811, i64 %r3816
  %r3818 = load double, ptr %r3817, align 8
  br label %plen.ic.merge.670

plen.ic.miss.669:                                 ; preds = %plen.ic.spill_ptr.667, %plen.ic.spill_meta.666, %plen.ic.family_token.663, %plen.ic.family_meta.662, %plen.ic.exact.661, %plen.ic.shape.probe.659, %plen.ic.shape.658, %plen.ic.header.657, %plen.slow.655
  %statepoint_token1033 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r3715, ptr @perry_ic_test_json_source_token_length_ts__29, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.281306, ptr addrspace(1) %.01618, ptr addrspace(1) %.151486, ptr addrspace(1) %.281412, ptr addrspace(1) %.151544) ]
  %r38191034 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1033)
  %r48.0.base.relocated1035 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1033, i32 0, i32 0) ; (%.281306, %.281306)
  %r1053.1.relocated1036 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1033, i32 1, i32 1) ; (%.01618, %.01618)
  %r1046.0.base.relocated1037 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1033, i32 2, i32 2) ; (%.151486, %.151486)
  %r48.0.relocated1038 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1033, i32 0, i32 3) ; (%.281306, %.281412)
  %r1046.0.relocated1039 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1033, i32 2, i32 4) ; (%.151486, %.151544)
  br label %plen.ic.merge.670

plen.ic.merge.670:                                ; preds = %plen.elem.length.673, %plen.ic.miss.669, %plen.ic.spill_load.668, %plen.ic.inline.665
  %.201638 = phi ptr addrspace(1) [ %.01618, %plen.elem.length.673 ], [ %.01618, %plen.ic.inline.665 ], [ %.01618, %plen.ic.spill_load.668 ], [ %r1053.1.relocated1036, %plen.ic.miss.669 ]
  %.411570 = phi ptr addrspace(1) [ %.151544, %plen.elem.length.673 ], [ %.151544, %plen.ic.inline.665 ], [ %.151544, %plen.ic.spill_load.668 ], [ %r1046.0.relocated1039, %plen.ic.miss.669 ]
  %.411512 = phi ptr addrspace(1) [ %.151486, %plen.elem.length.673 ], [ %.151486, %plen.ic.inline.665 ], [ %.151486, %plen.ic.spill_load.668 ], [ %r1046.0.base.relocated1037, %plen.ic.miss.669 ]
  %.541438 = phi ptr addrspace(1) [ %.281412, %plen.elem.length.673 ], [ %.281412, %plen.ic.inline.665 ], [ %.281412, %plen.ic.spill_load.668 ], [ %r48.0.relocated1038, %plen.ic.miss.669 ]
  %.54 = phi ptr addrspace(1) [ %.281306, %plen.elem.length.673 ], [ %.281306, %plen.ic.inline.665 ], [ %.281306, %plen.ic.spill_load.668 ], [ %r48.0.base.relocated1035, %plen.ic.miss.669 ]
  %r3820 = phi double [ %r3768, %plen.elem.length.673 ], [ %r3801, %plen.ic.inline.665 ], [ %r3818, %plen.ic.spill_load.668 ], [ %r38191034, %plen.ic.miss.669 ]
  br label %plen.merge.656

plen.elem.meta.671:                               ; preds = %plen.ic.header.657
  %r3758 = add nuw nsw i64 %r3717, 8
  %r3759 = inttoptr i64 %r3758 to ptr
  %r3760 = load i64, ptr %r3759, align 8
  %r3761 = icmp ne i64 %r3760, 0
  br i1 %r3761, label %plen.elem.store.672, label %plen.ic.shape.658

plen.elem.store.672:                              ; preds = %plen.elem.meta.671
  %r3762 = inttoptr i64 %r3760 to ptr
  %r3763 = getelementptr i64, ptr %r3762, i64 12
  %r3764 = load i64, ptr %r3763, align 8
  %r3765 = icmp ne i64 %r3764, 0
  br i1 %r3765, label %plen.elem.length.673, label %plen.ic.shape.658

plen.elem.length.673:                             ; preds = %plen.elem.store.672
  %r3766 = inttoptr i64 %r3764 to ptr
  %r3767 = load i32, ptr %r3766, align 4
  %r3768 = uitofp i32 %r3767 to double
  br label %plen.ic.merge.670

gcpoll.674:                                       ; preds = %plen.merge.656
  %statepoint_token1040 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.53, ptr addrspace(1) %.191637, ptr addrspace(1) %.401511, ptr addrspace(1) %.531437, ptr addrspace(1) %.401569) ]
  %r48.0.base.relocated1041 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1040, i32 0, i32 0) ; (%.53, %.53)
  %r1053.1.relocated1042 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1040, i32 1, i32 1) ; (%.191637, %.191637)
  %r1046.0.base.relocated1043 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1040, i32 2, i32 2) ; (%.401511, %.401511)
  %r48.0.relocated1044 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1040, i32 0, i32 3) ; (%.53, %.531437)
  %r1046.0.relocated1045 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1040, i32 2, i32 4) ; (%.401511, %.401569)
  br label %gcpoll.done.675

gcpoll.done.675:                                  ; preds = %gcpoll.674, %plen.merge.656
  %.211639 = phi ptr addrspace(1) [ %r1053.1.relocated1042, %gcpoll.674 ], [ %.191637, %plen.merge.656 ]
  %.421571 = phi ptr addrspace(1) [ %r1046.0.relocated1045, %gcpoll.674 ], [ %.401569, %plen.merge.656 ]
  %.421513 = phi ptr addrspace(1) [ %r1046.0.base.relocated1043, %gcpoll.674 ], [ %.401511, %plen.merge.656 ]
  %.551439 = phi ptr addrspace(1) [ %r48.0.relocated1044, %gcpoll.674 ], [ %.531437, %plen.merge.656 ]
  %.55 = phi ptr addrspace(1) [ %r48.0.base.relocated1041, %gcpoll.674 ], [ %.53, %plen.merge.656 ]
  %r3825 = icmp eq i64 %r3823, 9222246136947933188
  br i1 %r3825, label %for.body.650, label %for.exit.652

arr.fast.676:                                     ; preds = %arr.guard.range.682
  %r3892 = zext i32 %r3712.0 to i64
  %r3893 = shl nuw nsw i64 %r3892, 3
  %r3894 = add nuw nsw i64 %r3893, 8
  %r3895 = add i64 %r3851, %r3894
  %r3896 = inttoptr i64 %r3895 to ptr
  %r3897 = load double, ptr %r3896, align 8
  %r3898 = bitcast double %r3897 to i64
  %r3899 = icmp eq i64 %r3898, 9222246136947933200
  %r3901 = select i1 %r3899, double 0x7FFC000000000001, double %r3897
  br label %arr.merge.679

arr.fallback.677:                                 ; preds = %arr.guard.live.681, %arr.guard.deref.680, %for.body.650
  %r3890 = sitofp i32 %r3712.0 to double
  %statepoint_token1046 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 5587713372188573726, double %r3829, double %r3890, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.55, ptr addrspace(1) %.211639, ptr addrspace(1) %.421513, ptr addrspace(1) %.551439, ptr addrspace(1) %.421571) ]
  %r38911047 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1046)
  %r48.0.base.relocated1048 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1046, i32 0, i32 0) ; (%.55, %.55)
  %r1053.1.relocated1049 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1046, i32 1, i32 1) ; (%.211639, %.211639)
  %r1046.0.base.relocated1050 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1046, i32 2, i32 2) ; (%.421513, %.421513)
  %r48.0.relocated1051 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1046, i32 0, i32 3) ; (%.55, %.551439)
  %r1046.0.relocated1052 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1046, i32 2, i32 4) ; (%.421513, %.421571)
  br label %arr.merge.679

arr.guard.oob.678:                                ; preds = %arr.guard.range.682
  br label %arr.merge.679

arr.merge.679:                                    ; preds = %arr.guard.oob.678, %arr.fallback.677, %arr.fast.676
  %.221640 = phi ptr addrspace(1) [ %.211639, %arr.fast.676 ], [ %.211639, %arr.guard.oob.678 ], [ %r1053.1.relocated1049, %arr.fallback.677 ]
  %.431572 = phi ptr addrspace(1) [ %.421571, %arr.fast.676 ], [ %.421571, %arr.guard.oob.678 ], [ %r1046.0.relocated1052, %arr.fallback.677 ]
  %.431514 = phi ptr addrspace(1) [ %.421513, %arr.fast.676 ], [ %.421513, %arr.guard.oob.678 ], [ %r1046.0.base.relocated1050, %arr.fallback.677 ]
  %.561440 = phi ptr addrspace(1) [ %.551439, %arr.fast.676 ], [ %.551439, %arr.guard.oob.678 ], [ %r48.0.relocated1051, %arr.fallback.677 ]
  %.56 = phi ptr addrspace(1) [ %.55, %arr.fast.676 ], [ %.55, %arr.guard.oob.678 ], [ %r48.0.base.relocated1048, %arr.fallback.677 ]
  %r3902 = phi double [ %r3901, %arr.fast.676 ], [ %r38911047, %arr.fallback.677 ], [ 0x7FFC000000000001, %arr.guard.oob.678 ]
  %statepoint_token1053 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r3902, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.56, ptr addrspace(1) %.221640, ptr addrspace(1) %.431514, ptr addrspace(1) %.561440, ptr addrspace(1) %.431572) ]
  %r39031054 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1053)
  %r48.0.base.relocated1055 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1053, i32 0, i32 0) ; (%.56, %.56)
  %r1053.1.relocated1056 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1053, i32 1, i32 1) ; (%.221640, %.221640)
  %r1046.0.base.relocated1057 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1053, i32 2, i32 2) ; (%.431514, %.431514)
  %r48.0.relocated1058 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1053, i32 0, i32 3) ; (%.56, %.561440)
  %r1046.0.relocated1059 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1053, i32 2, i32 4) ; (%.431514, %.431572)
  %statepoint_token1060 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r39031054, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.0.base.relocated1055, ptr addrspace(1) %r1053.1.relocated1056, ptr addrspace(1) %r1046.0.base.relocated1057, ptr addrspace(1) %r48.0.relocated1058, ptr addrspace(1) %r1046.0.relocated1059) ]
  %r39041061 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1060)
  %r48.0.base.relocated1062 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1060, i32 0, i32 0) ; (%r48.0.base.relocated1055, %r48.0.base.relocated1055)
  %r1053.1.relocated1063 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1060, i32 1, i32 1) ; (%r1053.1.relocated1056, %r1053.1.relocated1056)
  %r1046.0.base.relocated1064 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1060, i32 2, i32 2) ; (%r1046.0.base.relocated1057, %r1046.0.base.relocated1057)
  %r48.0.relocated1065 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1060, i32 0, i32 3) ; (%r48.0.base.relocated1055, %r48.0.relocated1058)
  %r1046.0.relocated1066 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1060, i32 2, i32 4) ; (%r1046.0.base.relocated1057, %r1046.0.relocated1059)
  %r3905 = bitcast i64 %r39041061 to double
  %rs4gc.b50 = bitcast double %r3905 to i64
  %rs4gc.s50 = inttoptr i64 %rs4gc.b50 to ptr addrspace(1)
  %r3906.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s50 to i64
  %r3906 = call i64 asm "", "=r,0"(i64 %r3906.rs4i) #7
  %r3907 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3908 = icmp ne i32 %r3907, 0
  br i1 %r3908, label %shadow.root.barrier.683, label %shadow.root.barrier.done.684

arr.guard.deref.680:                              ; preds = %for.body.650
  %r3837 = bitcast double %r3829 to i64
  %r3838 = and i64 %r3837, 281474976710655
  %r3839 = sub nsw i64 %r3838, 8
  %r3840 = inttoptr i64 %r3839 to ptr
  %r3841 = load i8, ptr %r3840, align 1
  %r3842 = icmp eq i8 %r3841, 1
  %r3843 = sub nsw i64 %r3838, 7
  %r3844 = inttoptr i64 %r3843 to ptr
  %r3845 = load i8, ptr %r3844, align 1
  %r3846 = and i8 %r3845, -128
  %r3847 = icmp ne i8 %r3846, 0
  %r3848 = inttoptr i64 %r3838 to ptr
  %r3849 = load i64, ptr %r3848, align 8
  %r3850 = and i1 %r3842, %r3847
  %r3851 = select i1 %r3850, i64 %r3849, i64 %r3838
  %r3852 = lshr i64 %r3851, 48
  %r3853 = icmp eq i64 %r3852, 0
  %r3854 = icmp ugt i64 %r3851, 1048575
  %r3855 = and i1 %r3853, %r3854
  br i1 %r3855, label %arr.guard.live.681, label %arr.fallback.677

arr.guard.live.681:                               ; preds = %arr.guard.deref.680
  %r3856 = sub nuw i64 %r3851, 8
  %r3857 = inttoptr i64 %r3856 to ptr
  %r3858 = load i8, ptr %r3857, align 1
  %r3859 = icmp eq i8 %r3858, 1
  %r3860 = sub nuw i64 %r3851, 7
  %r3861 = inttoptr i64 %r3860 to ptr
  %r3862 = load i8, ptr %r3861, align 1
  %r3863 = and i8 %r3862, -128
  %r3864 = icmp eq i8 %r3863, 0
  %r3865 = sub nuw i64 %r3851, 6
  %r3866 = inttoptr i64 %r3865 to ptr
  %r3867 = load i16, ptr %r3866, align 2
  %r3868 = and i16 %r3867, 1024
  %r3869 = icmp eq i16 %r3868, 0
  %r3870 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r3871 = icmp eq i8 %r3870, 0
  %r3872 = inttoptr i64 %r3851 to ptr
  %r3873 = load i32, ptr %r3872, align 4
  %r3874 = getelementptr i8, ptr %r3872, i64 4
  %r3875 = load i32, ptr %r3874, align 4
  %r3876 = icmp slt i32 %r3712.0, 0
  %r3877 = icmp eq i1 %r3876, false
  %r3879 = icmp ule i32 %r3873, 16000000
  %r3880 = icmp ule i32 %r3875, 16000000
  %r3881 = icmp ule i32 %r3873, %r3875
  %r3882 = and i1 %r3859, %r3864
  %r3883 = and i1 %r3882, %r3869
  %r3884 = and i1 %r3883, %r3871
  %r3885 = and i1 %r3884, %r3877
  %r3886 = and i1 %r3885, %r3879
  %r3887 = and i1 %r3886, %r3880
  %r3888 = and i1 %r3887, %r3881
  br i1 %r3888, label %arr.guard.range.682, label %arr.fallback.677

arr.guard.range.682:                              ; preds = %arr.guard.live.681
  %r3878 = icmp ult i32 %r3712.0, %r3873
  br i1 %r3878, label %arr.fast.676, label %arr.guard.oob.678

shadow.root.barrier.683:                          ; preds = %arr.merge.679
  call void @js_write_barrier_root_nanbox(i64 %r3906) #7
  br label %shadow.root.barrier.done.684

shadow.root.barrier.done.684:                     ; preds = %shadow.root.barrier.683, %arr.merge.679
  %statepoint_token1067 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 4, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50, ptr addrspace(1) %r48.0.base.relocated1062, ptr addrspace(1) %r1053.1.relocated1063, ptr addrspace(1) %r1046.0.base.relocated1064, ptr addrspace(1) %r48.0.relocated1065, ptr addrspace(1) %r1046.0.relocated1066) ]
  %r39091068 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1067)
  %rs4gc.s50.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1067, i32 0, i32 0) ; (%rs4gc.s50, %rs4gc.s50)
  %r48.0.base.relocated1069 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1067, i32 1, i32 1) ; (%r48.0.base.relocated1062, %r48.0.base.relocated1062)
  %r1053.1.relocated1070 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1067, i32 2, i32 2) ; (%r1053.1.relocated1063, %r1053.1.relocated1063)
  %r1046.0.base.relocated1071 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1067, i32 3, i32 3) ; (%r1046.0.base.relocated1064, %r1046.0.base.relocated1064)
  %r48.0.relocated1072 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1067, i32 1, i32 4) ; (%r48.0.base.relocated1062, %r48.0.relocated1065)
  %r1046.0.relocated1073 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1067, i32 3, i32 5) ; (%r1046.0.base.relocated1064, %r1046.0.relocated1066)
  %rs4gc.s51 = inttoptr i64 %r39091068 to ptr addrspace(1)
  %r3910.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s51 to i64
  %r3910 = call i64 asm "", "=r,0"(i64 %r3910.rs4i) #7
  %r3911 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3912 = icmp ne i32 %r3911, 0
  br i1 %r3912, label %shadow.root.barrier.685, label %shadow.root.barrier.done.686

shadow.root.barrier.685:                          ; preds = %shadow.root.barrier.done.684
  call void @js_write_barrier_root_nanbox(i64 %r3910) #7
  br label %shadow.root.barrier.done.686

shadow.root.barrier.done.686:                     ; preds = %shadow.root.barrier.685, %shadow.root.barrier.done.684
  %r3913 = load double, ptr @test_json_source_token_length_ts_.str.18.handle, align 8
  %r3914.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s51 to i64
  %r3914 = call i64 asm "", "=r,0"(i64 %r3914.rs4i) #7
  %statepoint_token1074 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3914, double %r3913, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50.relocated, ptr addrspace(1) %r48.0.base.relocated1069, ptr addrspace(1) %r1053.1.relocated1070, ptr addrspace(1) %r1046.0.base.relocated1071, ptr addrspace(1) %r48.0.relocated1072, ptr addrspace(1) %r1046.0.relocated1073) ]
  %r39151075 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1074)
  %rs4gc.s50.relocated1076 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1074, i32 0, i32 0) ; (%rs4gc.s50.relocated, %rs4gc.s50.relocated)
  %r48.0.base.relocated1077 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1074, i32 1, i32 1) ; (%r48.0.base.relocated1069, %r48.0.base.relocated1069)
  %r1053.1.relocated1078 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1074, i32 2, i32 2) ; (%r1053.1.relocated1070, %r1053.1.relocated1070)
  %r1046.0.base.relocated1079 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1074, i32 3, i32 3) ; (%r1046.0.base.relocated1071, %r1046.0.base.relocated1071)
  %r48.0.relocated1080 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1074, i32 1, i32 4) ; (%r48.0.base.relocated1069, %r48.0.relocated1072)
  %r1046.0.relocated1081 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1074, i32 3, i32 5) ; (%r1046.0.base.relocated1071, %r1046.0.relocated1073)
  %rs4gc.s52 = inttoptr i64 %r39151075 to ptr addrspace(1)
  %r3916.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s52 to i64
  %r3916 = call i64 asm "", "=r,0"(i64 %r3916.rs4i) #7
  %r3917 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3918 = icmp ne i32 %r3917, 0
  br i1 %r3918, label %shadow.root.barrier.687, label %shadow.root.barrier.done.688

shadow.root.barrier.687:                          ; preds = %shadow.root.barrier.done.686
  call void @js_write_barrier_root_nanbox(i64 %r3916) #7
  br label %shadow.root.barrier.done.688

shadow.root.barrier.done.688:                     ; preds = %shadow.root.barrier.687, %shadow.root.barrier.done.686
  %r3920 = sitofp i32 %r3712.0 to double
  %r3921.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s52 to i64
  %r3921 = call i64 asm "", "=r,0"(i64 %r3921.rs4i) #7
  %statepoint_token1082 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3921, double %r3920, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50.relocated1076, ptr addrspace(1) %r48.0.base.relocated1077, ptr addrspace(1) %r1053.1.relocated1078, ptr addrspace(1) %r1046.0.base.relocated1079, ptr addrspace(1) %r48.0.relocated1080, ptr addrspace(1) %r1046.0.relocated1081) ]
  %r39221083 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1082)
  %rs4gc.s50.relocated1084 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1082, i32 0, i32 0) ; (%rs4gc.s50.relocated1076, %rs4gc.s50.relocated1076)
  %r48.0.base.relocated1085 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1082, i32 1, i32 1) ; (%r48.0.base.relocated1077, %r48.0.base.relocated1077)
  %r1053.1.relocated1086 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1082, i32 2, i32 2) ; (%r1053.1.relocated1078, %r1053.1.relocated1078)
  %r1046.0.base.relocated1087 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1082, i32 3, i32 3) ; (%r1046.0.base.relocated1079, %r1046.0.base.relocated1079)
  %r48.0.relocated1088 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1082, i32 1, i32 4) ; (%r48.0.base.relocated1077, %r48.0.relocated1080)
  %r1046.0.relocated1089 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1082, i32 3, i32 5) ; (%r1046.0.base.relocated1079, %r1046.0.relocated1081)
  %rs4gc.s53 = inttoptr i64 %r39221083 to ptr addrspace(1)
  %r3923.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s53 to i64
  %r3923 = call i64 asm "", "=r,0"(i64 %r3923.rs4i) #7
  %r3924 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3925 = icmp ne i32 %r3924, 0
  br i1 %r3925, label %shadow.root.barrier.689, label %shadow.root.barrier.done.690

shadow.root.barrier.689:                          ; preds = %shadow.root.barrier.done.688
  call void @js_write_barrier_root_nanbox(i64 %r3923) #7
  br label %shadow.root.barrier.done.690

shadow.root.barrier.done.690:                     ; preds = %shadow.root.barrier.689, %shadow.root.barrier.done.688
  %r3926.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s50.relocated1084 to i64
  %r3926.rs4o = call i64 asm "", "=r,0"(i64 %r3926.rs4i) #7
  %r3926 = bitcast i64 %r3926.rs4o to double
  %r3927 = bitcast double %r3926 to i64
  %r3928 = and i64 %r3927, 281474976710655
  %r3929 = lshr i64 %r3927, 48
  %r3930 = and i64 %r3929, 65533
  %r3931 = icmp eq i64 %r3930, 32765
  br i1 %r3931, label %pget.recv_ok.692, label %pget.recv_other.696

pget.recv_sso.691:                                ; preds = %pget.recv_other.696
  %r4069 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r4070 = bitcast double %r4069 to i64
  %r4071 = and i64 %r4070, 281474976710655
  %statepoint_token1090 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3927, i64 %r4071, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50.relocated1084, ptr addrspace(1) %rs4gc.s53, ptr addrspace(1) %r48.0.base.relocated1085, ptr addrspace(1) %r1053.1.relocated1086, ptr addrspace(1) %r1046.0.base.relocated1087, ptr addrspace(1) %r48.0.relocated1088, ptr addrspace(1) %r1046.0.relocated1089) ]
  %r40721091 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1090)
  %rs4gc.s50.relocated1092 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1090, i32 0, i32 0) ; (%rs4gc.s50.relocated1084, %rs4gc.s50.relocated1084)
  %rs4gc.s53.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1090, i32 1, i32 1) ; (%rs4gc.s53, %rs4gc.s53)
  %r48.0.base.relocated1093 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1090, i32 2, i32 2) ; (%r48.0.base.relocated1085, %r48.0.base.relocated1085)
  %r1053.1.relocated1094 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1090, i32 3, i32 3) ; (%r1053.1.relocated1086, %r1053.1.relocated1086)
  %r1046.0.base.relocated1095 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1090, i32 4, i32 4) ; (%r1046.0.base.relocated1087, %r1046.0.base.relocated1087)
  %r48.0.relocated1096 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1090, i32 2, i32 5) ; (%r48.0.base.relocated1085, %r48.0.relocated1088)
  %r1046.0.relocated1097 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1090, i32 4, i32 6) ; (%r1046.0.base.relocated1087, %r1046.0.relocated1089)
  br label %pget.recv_merge.695

pget.recv_ok.692:                                 ; preds = %shadow.root.barrier.done.690
  %r3938 = icmp ugt i64 %r3928, 1048575
  br i1 %r3938, label %pic.recv_hdr.713, label %pic.miss.cold.710

pget.recv_bad.693:                                ; preds = %pget.check_class_ref.697
  %r4061 = icmp eq i64 %r3927, 9222246136947933185
  %r4062 = icmp eq i64 %r3927, 9222246136947933186
  %r4063 = or i1 %r4061, %r4062
  br i1 %r4063, label %pget.throw_nullish.720, label %pget.recv_undef_return.721

pget.recv_class_ref.694:                          ; preds = %pget.check_class_ref.697
  %r3934 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r3935 = bitcast double %r3934 to i64
  %r3936 = and i64 %r3935, 281474976710655
  %statepoint_token1098 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 5587713372188573727, i64 %r3927, i64 %r3936, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50.relocated1084, ptr addrspace(1) %rs4gc.s53, ptr addrspace(1) %r48.0.base.relocated1085, ptr addrspace(1) %r1053.1.relocated1086, ptr addrspace(1) %r1046.0.base.relocated1087, ptr addrspace(1) %r48.0.relocated1088, ptr addrspace(1) %r1046.0.relocated1089) ]
  %r39371099 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1098)
  %rs4gc.s50.relocated1100 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1098, i32 0, i32 0) ; (%rs4gc.s50.relocated1084, %rs4gc.s50.relocated1084)
  %rs4gc.s53.relocated1101 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1098, i32 1, i32 1) ; (%rs4gc.s53, %rs4gc.s53)
  %r48.0.base.relocated1102 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1098, i32 2, i32 2) ; (%r48.0.base.relocated1085, %r48.0.base.relocated1085)
  %r1053.1.relocated1103 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1098, i32 3, i32 3) ; (%r1053.1.relocated1086, %r1053.1.relocated1086)
  %r1046.0.base.relocated1104 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1098, i32 4, i32 4) ; (%r1046.0.base.relocated1087, %r1046.0.base.relocated1087)
  %r48.0.relocated1105 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1098, i32 2, i32 5) ; (%r48.0.base.relocated1085, %r48.0.relocated1088)
  %r1046.0.relocated1106 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1098, i32 4, i32 6) ; (%r1046.0.base.relocated1087, %r1046.0.relocated1089)
  br label %pget.recv_merge.695

pget.recv_merge.695:                              ; preds = %pget.recv_undef_return.721, %pic.merge.712, %pget.recv_class_ref.694, %pget.recv_sso.691
  %.01675 = phi ptr addrspace(1) [ %.11676, %pic.merge.712 ], [ %rs4gc.s53.relocated, %pget.recv_sso.691 ], [ %rs4gc.s53.relocated1101, %pget.recv_class_ref.694 ], [ %rs4gc.s53.relocated1129, %pget.recv_undef_return.721 ]
  %.01671 = phi ptr addrspace(1) [ %.11672, %pic.merge.712 ], [ %rs4gc.s50.relocated1092, %pget.recv_sso.691 ], [ %rs4gc.s50.relocated1100, %pget.recv_class_ref.694 ], [ %rs4gc.s50.relocated1128, %pget.recv_undef_return.721 ]
  %.231641 = phi ptr addrspace(1) [ %.241642, %pic.merge.712 ], [ %r1053.1.relocated1094, %pget.recv_sso.691 ], [ %r1053.1.relocated1103, %pget.recv_class_ref.694 ], [ %r1053.1.relocated1131, %pget.recv_undef_return.721 ]
  %.441573 = phi ptr addrspace(1) [ %.451574, %pic.merge.712 ], [ %r1046.0.relocated1097, %pget.recv_sso.691 ], [ %r1046.0.relocated1106, %pget.recv_class_ref.694 ], [ %r1046.0.relocated1134, %pget.recv_undef_return.721 ]
  %.441515 = phi ptr addrspace(1) [ %.451516, %pic.merge.712 ], [ %r1046.0.base.relocated1095, %pget.recv_sso.691 ], [ %r1046.0.base.relocated1104, %pget.recv_class_ref.694 ], [ %r1046.0.base.relocated1132, %pget.recv_undef_return.721 ]
  %.571441 = phi ptr addrspace(1) [ %.581442, %pic.merge.712 ], [ %r48.0.relocated1096, %pget.recv_sso.691 ], [ %r48.0.relocated1105, %pget.recv_class_ref.694 ], [ %r48.0.relocated1133, %pget.recv_undef_return.721 ]
  %.57 = phi ptr addrspace(1) [ %.58, %pic.merge.712 ], [ %r48.0.base.relocated1093, %pget.recv_sso.691 ], [ %r48.0.base.relocated1102, %pget.recv_class_ref.694 ], [ %r48.0.base.relocated1130, %pget.recv_undef_return.721 ]
  %r4073 = phi double [ %r4060, %pic.merge.712 ], [ %r40681127, %pget.recv_undef_return.721 ], [ %r40721091, %pget.recv_sso.691 ], [ %r39371099, %pget.recv_class_ref.694 ]
  %r4074 = bitcast double %r4073 to i64
  %r4075 = and i64 %r4074, 281474976710655
  %r4076 = lshr i64 %r4074, 48
  %r4077 = and i64 %r4076, 65533
  %r4078 = icmp eq i64 %r4077, 32765
  br i1 %r4078, label %pget.recv_ok.723, label %pget.recv_other.728

pget.recv_other.696:                              ; preds = %shadow.root.barrier.done.690
  %r3932 = icmp eq i64 %r3929, 32761
  br i1 %r3932, label %pget.recv_sso.691, label %pget.check_class_ref.697

pget.check_class_ref.697:                         ; preds = %pget.recv_other.696
  %r3933 = icmp eq i64 %r3929, 32766
  br i1 %r3933, label %pget.recv_class_ref.694, label %pget.recv_bad.693

pic.hit.698:                                      ; preds = %pic.token.714
  %r3963 = getelementptr i64, ptr %r3948, i64 1
  %r3964 = load i64, ptr %r3963, align 8
  %r3965 = and i64 %r3964, 1073741824
  %r3966 = icmp ne i64 %r3965, 0
  br i1 %r3966, label %pic.hit.overflow.715, label %pic.hit.inline.716

pic.hit.live.699:                                 ; preds = %pic.hit.inline.716
  br label %pic.merge.712

pic.prefix.guard.700:                             ; preds = %pic.token.714
  %r3979 = getelementptr i64, ptr %r3948, i64 2
  %r3980 = load i64, ptr %r3979, align 8
  %r3981 = icmp ne i64 %r3980, 0
  br i1 %r3981, label %pic.prefix.meta.701, label %pic.miss.709

pic.prefix.meta.701:                              ; preds = %pic.prefix.guard.700
  %r3982 = add nuw nsw i64 %r3928, 8
  %r3983 = inttoptr i64 %r3982 to ptr
  %r3984 = load i64, ptr %r3983, align 8
  %r3985 = icmp ne i64 %r3984, 0
  br i1 %r3985, label %pic.prefix.token.702, label %pic.miss.709

pic.prefix.token.702:                             ; preds = %pic.prefix.meta.701
  %r3986 = inttoptr i64 %r3984 to ptr
  %r3987 = getelementptr i64, ptr %r3986, i64 6
  %r3988 = load i64, ptr %r3987, align 8
  %r3989 = icmp eq i64 %r3988, %r3980
  br i1 %r3989, label %pic.prefix.hit.703, label %pic.miss.709

pic.prefix.hit.703:                               ; preds = %pic.prefix.token.702
  %r3990 = getelementptr i64, ptr %r3948, i64 1
  %r3991 = load i64, ptr %r3990, align 8
  %r3992 = shl i64 %r3991, 3
  %r3993 = add nuw nsw i64 %r3928, 16
  %r3994 = add i64 %r3993, %r3992
  %r3995 = inttoptr i64 %r3994 to ptr
  %r3996 = load double, ptr %r3995, align 8
  br label %pic.merge.712

pic.desc.classify.704:                            ; preds = %pic.recv_hdr.713
  %r3952 = and i1 %r3942, %r3949
  br i1 %r3952, label %pic.desc.prefix.guard.705, label %pic.miss.cold.710

pic.desc.prefix.guard.705:                        ; preds = %pic.desc.classify.704
  %r3997 = getelementptr i64, ptr %r3948, i64 2
  %r3998 = load i64, ptr %r3997, align 8
  %r3999 = icmp ne i64 %r3998, 0
  br i1 %r3999, label %pic.desc.prefix.meta.706, label %pic.miss.cold.710

pic.desc.prefix.meta.706:                         ; preds = %pic.desc.prefix.guard.705
  %r4000 = add nuw nsw i64 %r3928, 8
  %r4001 = inttoptr i64 %r4000 to ptr
  %r4002 = load i64, ptr %r4001, align 8
  %r4003 = icmp ne i64 %r4002, 0
  br i1 %r4003, label %pic.desc.prefix.token.707, label %pic.miss.cold.710

pic.desc.prefix.token.707:                        ; preds = %pic.desc.prefix.meta.706
  %r4004 = inttoptr i64 %r4002 to ptr
  %r4005 = getelementptr i64, ptr %r4004, i64 6
  %r4006 = load i64, ptr %r4005, align 8
  %r4007 = icmp eq i64 %r4006, %r3998
  br i1 %r4007, label %pic.desc.prefix.hit.708, label %pic.miss.cold.710

pic.desc.prefix.hit.708:                          ; preds = %pic.desc.prefix.token.707
  %r4008 = getelementptr i64, ptr %r3948, i64 1
  %r4009 = load i64, ptr %r4008, align 8
  %r4010 = shl i64 %r4009, 3
  %r4011 = add nuw nsw i64 %r3928, 16
  %r4012 = add i64 %r4011, %r4010
  %r4013 = inttoptr i64 %r4012 to ptr
  %r4014 = load double, ptr %r4013, align 8
  br label %pic.merge.712

pic.miss.709:                                     ; preds = %pic.hit.inline.716, %pic.prefix.token.702, %pic.prefix.meta.701, %pic.prefix.guard.700
  %r4015 = getelementptr i64, ptr %r3948, i64 3
  %r4016 = load i64, ptr %r4015, align 8
  %r4017 = icmp sgt i64 %r4016, 0
  br i1 %r4017, label %pic.ways.717, label %pic.miss.call.711

pic.miss.cold.710:                                ; preds = %pic.desc.prefix.token.707, %pic.desc.prefix.meta.706, %pic.desc.prefix.guard.705, %pic.desc.classify.704, %pget.recv_ok.692
  br label %pic.miss.call.711

pic.miss.call.711:                                ; preds = %pic.way.load.718, %pic.ways.717, %pic.miss.cold.710, %pic.miss.709
  %r4056 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r4057 = bitcast double %r4056 to i64
  %r4058 = and i64 %r4057, 281474976710655
  %statepoint_token1107 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r3928, i64 %r4058, ptr @perry_ic_test_json_source_token_length_ts__32, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50.relocated1084, ptr addrspace(1) %rs4gc.s53, ptr addrspace(1) %r48.0.base.relocated1085, ptr addrspace(1) %r1053.1.relocated1086, ptr addrspace(1) %r1046.0.base.relocated1087, ptr addrspace(1) %r48.0.relocated1088, ptr addrspace(1) %r1046.0.relocated1089) ]
  %r40591108 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1107)
  %rs4gc.s50.relocated1109 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1107, i32 0, i32 0) ; (%rs4gc.s50.relocated1084, %rs4gc.s50.relocated1084)
  %rs4gc.s53.relocated1110 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1107, i32 1, i32 1) ; (%rs4gc.s53, %rs4gc.s53)
  %r48.0.base.relocated1111 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1107, i32 2, i32 2) ; (%r48.0.base.relocated1085, %r48.0.base.relocated1085)
  %r1053.1.relocated1112 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1107, i32 3, i32 3) ; (%r1053.1.relocated1086, %r1053.1.relocated1086)
  %r1046.0.base.relocated1113 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1107, i32 4, i32 4) ; (%r1046.0.base.relocated1087, %r1046.0.base.relocated1087)
  %r48.0.relocated1114 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1107, i32 2, i32 5) ; (%r48.0.base.relocated1085, %r48.0.relocated1088)
  %r1046.0.relocated1115 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1107, i32 4, i32 6) ; (%r1046.0.base.relocated1087, %r1046.0.relocated1089)
  br label %pic.merge.712

pic.merge.712:                                    ; preds = %pic.way.live.719, %pic.hit.overflow.715, %pic.miss.call.711, %pic.desc.prefix.hit.708, %pic.prefix.hit.703, %pic.hit.live.699
  %.11676 = phi ptr addrspace(1) [ %rs4gc.s53.relocated1119, %pic.hit.overflow.715 ], [ %rs4gc.s53.relocated1110, %pic.miss.call.711 ], [ %rs4gc.s53, %pic.way.live.719 ], [ %rs4gc.s53, %pic.hit.live.699 ], [ %rs4gc.s53, %pic.prefix.hit.703 ], [ %rs4gc.s53, %pic.desc.prefix.hit.708 ]
  %.11672 = phi ptr addrspace(1) [ %rs4gc.s50.relocated1118, %pic.hit.overflow.715 ], [ %rs4gc.s50.relocated1109, %pic.miss.call.711 ], [ %rs4gc.s50.relocated1084, %pic.way.live.719 ], [ %rs4gc.s50.relocated1084, %pic.hit.live.699 ], [ %rs4gc.s50.relocated1084, %pic.prefix.hit.703 ], [ %rs4gc.s50.relocated1084, %pic.desc.prefix.hit.708 ]
  %.241642 = phi ptr addrspace(1) [ %r1053.1.relocated1121, %pic.hit.overflow.715 ], [ %r1053.1.relocated1112, %pic.miss.call.711 ], [ %r1053.1.relocated1086, %pic.way.live.719 ], [ %r1053.1.relocated1086, %pic.hit.live.699 ], [ %r1053.1.relocated1086, %pic.prefix.hit.703 ], [ %r1053.1.relocated1086, %pic.desc.prefix.hit.708 ]
  %.451574 = phi ptr addrspace(1) [ %r1046.0.relocated1124, %pic.hit.overflow.715 ], [ %r1046.0.relocated1115, %pic.miss.call.711 ], [ %r1046.0.relocated1089, %pic.way.live.719 ], [ %r1046.0.relocated1089, %pic.hit.live.699 ], [ %r1046.0.relocated1089, %pic.prefix.hit.703 ], [ %r1046.0.relocated1089, %pic.desc.prefix.hit.708 ]
  %.451516 = phi ptr addrspace(1) [ %r1046.0.base.relocated1122, %pic.hit.overflow.715 ], [ %r1046.0.base.relocated1113, %pic.miss.call.711 ], [ %r1046.0.base.relocated1087, %pic.way.live.719 ], [ %r1046.0.base.relocated1087, %pic.hit.live.699 ], [ %r1046.0.base.relocated1087, %pic.prefix.hit.703 ], [ %r1046.0.base.relocated1087, %pic.desc.prefix.hit.708 ]
  %.581442 = phi ptr addrspace(1) [ %r48.0.relocated1123, %pic.hit.overflow.715 ], [ %r48.0.relocated1114, %pic.miss.call.711 ], [ %r48.0.relocated1088, %pic.way.live.719 ], [ %r48.0.relocated1088, %pic.hit.live.699 ], [ %r48.0.relocated1088, %pic.prefix.hit.703 ], [ %r48.0.relocated1088, %pic.desc.prefix.hit.708 ]
  %.58 = phi ptr addrspace(1) [ %r48.0.base.relocated1120, %pic.hit.overflow.715 ], [ %r48.0.base.relocated1111, %pic.miss.call.711 ], [ %r48.0.base.relocated1085, %pic.way.live.719 ], [ %r48.0.base.relocated1085, %pic.hit.live.699 ], [ %r48.0.base.relocated1085, %pic.prefix.hit.703 ], [ %r48.0.base.relocated1085, %pic.desc.prefix.hit.708 ]
  %r4060 = phi double [ %r3976, %pic.hit.live.699 ], [ %r39711117, %pic.hit.overflow.715 ], [ %r3996, %pic.prefix.hit.703 ], [ %r4014, %pic.desc.prefix.hit.708 ], [ %r4053, %pic.way.live.719 ], [ %r40591108, %pic.miss.call.711 ]
  br label %pget.recv_merge.695

pic.recv_hdr.713:                                 ; preds = %pget.recv_ok.692
  %r3939 = sub nuw nsw i64 %r3928, 8
  %r3940 = inttoptr i64 %r3939 to ptr
  %r3941 = load i8, ptr %r3940, align 1
  %r3942 = icmp eq i8 %r3941, 2
  %r3943 = sub nuw nsw i64 %r3928, 6
  %r3944 = inttoptr i64 %r3943 to ptr
  %r3945 = load i16, ptr %r3944, align 2
  %r3946 = and i16 %r3945, 2048
  %r3947 = icmp eq i16 %r3946, 0
  %r3948 = load ptr, ptr @perry_ic_test_json_source_token_length_ts__32, align 8
  %r3949 = icmp ne ptr %r3948, null
  %r3950 = and i1 %r3942, %r3947
  %r3951 = and i1 %r3950, %r3949
  br i1 %r3951, label %pic.token.714, label %pic.desc.classify.704

pic.token.714:                                    ; preds = %pic.recv_hdr.713
  %r3953 = add nuw nsw i64 %r3928, 4
  %r3954 = inttoptr i64 %r3953 to ptr
  %r3955 = load i32, ptr %r3954, align 4
  %r3956 = zext i32 %r3955 to i64
  %r3957 = or i64 %r3956, 4611686018427387904
  %r3958 = icmp ne i32 %r3955, 0
  %r3959 = getelementptr i64, ptr %r3948, i64 0
  %r3960 = load i64, ptr %r3959, align 8
  %r3961 = icmp eq i64 %r3957, %r3960
  %r3962 = and i1 %r3961, %r3958
  br i1 %r3962, label %pic.hit.698, label %pic.prefix.guard.700

pic.hit.overflow.715:                             ; preds = %pic.hit.698
  %r3967 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r3968 = bitcast double %r3967 to i64
  %r3969 = and i64 %r3968, 281474976710655
  %r3970 = trunc i64 %r3964 to i32
  %statepoint_token1116 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r3928, i64 %r3969, i32 %r3970, ptr @perry_ic_test_json_source_token_length_ts__32, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50.relocated1084, ptr addrspace(1) %rs4gc.s53, ptr addrspace(1) %r48.0.base.relocated1085, ptr addrspace(1) %r1053.1.relocated1086, ptr addrspace(1) %r1046.0.base.relocated1087, ptr addrspace(1) %r48.0.relocated1088, ptr addrspace(1) %r1046.0.relocated1089) ]
  %r39711117 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1116)
  %rs4gc.s50.relocated1118 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1116, i32 0, i32 0) ; (%rs4gc.s50.relocated1084, %rs4gc.s50.relocated1084)
  %rs4gc.s53.relocated1119 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1116, i32 1, i32 1) ; (%rs4gc.s53, %rs4gc.s53)
  %r48.0.base.relocated1120 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1116, i32 2, i32 2) ; (%r48.0.base.relocated1085, %r48.0.base.relocated1085)
  %r1053.1.relocated1121 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1116, i32 3, i32 3) ; (%r1053.1.relocated1086, %r1053.1.relocated1086)
  %r1046.0.base.relocated1122 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1116, i32 4, i32 4) ; (%r1046.0.base.relocated1087, %r1046.0.base.relocated1087)
  %r48.0.relocated1123 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1116, i32 2, i32 5) ; (%r48.0.base.relocated1085, %r48.0.relocated1088)
  %r1046.0.relocated1124 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1116, i32 4, i32 6) ; (%r1046.0.base.relocated1087, %r1046.0.relocated1089)
  br label %pic.merge.712

pic.hit.inline.716:                               ; preds = %pic.hit.698
  %r3972 = shl i64 %r3964, 3
  %r3973 = add nuw nsw i64 %r3928, 16
  %r3974 = add i64 %r3973, %r3972
  %r3975 = inttoptr i64 %r3974 to ptr
  %r3976 = load double, ptr %r3975, align 8
  %r3977 = bitcast double %r3976 to i64
  %r3978 = icmp eq i64 %r3977, 9222246136947933200
  br i1 %r3978, label %pic.miss.709, label %pic.hit.live.699

pic.ways.717:                                     ; preds = %pic.miss.709
  %r4018 = getelementptr i64, ptr %r3948, i64 4
  %r4019 = load i64, ptr %r4018, align 8
  %r4020 = icmp eq i64 %r4019, %r3957
  %r4021 = getelementptr i64, ptr %r3948, i64 5
  %r4022 = load i64, ptr %r4021, align 8
  %r4023 = select i1 %r4020, i64 %r4022, i64 0
  %r4024 = getelementptr i64, ptr %r3948, i64 6
  %r4025 = load i64, ptr %r4024, align 8
  %r4026 = icmp eq i64 %r4025, %r3957
  %r4027 = getelementptr i64, ptr %r3948, i64 7
  %r4028 = load i64, ptr %r4027, align 8
  %r4029 = select i1 %r4026, i64 %r4028, i64 0
  %r4030 = getelementptr i64, ptr %r3948, i64 8
  %r4031 = load i64, ptr %r4030, align 8
  %r4032 = icmp eq i64 %r4031, %r3957
  %r4033 = getelementptr i64, ptr %r3948, i64 9
  %r4034 = load i64, ptr %r4033, align 8
  %r4035 = select i1 %r4032, i64 %r4034, i64 0
  %r4036 = getelementptr i64, ptr %r3948, i64 10
  %r4037 = load i64, ptr %r4036, align 8
  %r4038 = icmp eq i64 %r4037, %r3957
  %r4039 = getelementptr i64, ptr %r3948, i64 11
  %r4040 = load i64, ptr %r4039, align 8
  %r4041 = select i1 %r4038, i64 %r4040, i64 0
  %r4042 = or i1 %r4020, %r4026
  %r4043 = select i1 %r4020, i64 %r4023, i64 %r4029
  %r4044 = or i1 %r4032, %r4038
  %r4045 = select i1 %r4032, i64 %r4035, i64 %r4041
  %r4046 = or i1 %r4042, %r4044
  %r4047 = select i1 %r4042, i64 %r4043, i64 %r4045
  %r4048 = and i1 %r3958, %r4046
  br i1 %r4048, label %pic.way.load.718, label %pic.miss.call.711

pic.way.load.718:                                 ; preds = %pic.ways.717
  %r4049 = shl i64 %r4047, 3
  %r4050 = add nuw nsw i64 %r3928, 16
  %r4051 = add i64 %r4050, %r4049
  %r4052 = inttoptr i64 %r4051 to ptr
  %r4053 = load double, ptr %r4052, align 8
  %r4054 = bitcast double %r4053 to i64
  %r4055 = icmp eq i64 %r4054, 9222246136947933200
  br i1 %r4055, label %pic.miss.call.711, label %pic.way.live.719

pic.way.live.719:                                 ; preds = %pic.way.load.718
  br label %pic.merge.712

pget.throw_nullish.720:                           ; preds = %pget.recv_bad.693
  %r4064 = zext i1 %r4062 to i32
  %statepoint_token1125 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r4064, ptr @test_json_source_token_length_ts_.str.10.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.721:                       ; preds = %pget.recv_bad.693
  %r4065 = load double, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  %r4066 = bitcast double %r4065 to i64
  %r4067 = and i64 %r4066, 281474976710655
  %statepoint_token1126 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3927, i64 %r4067, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50.relocated1084, ptr addrspace(1) %rs4gc.s53, ptr addrspace(1) %r48.0.base.relocated1085, ptr addrspace(1) %r1053.1.relocated1086, ptr addrspace(1) %r1046.0.base.relocated1087, ptr addrspace(1) %r48.0.relocated1088, ptr addrspace(1) %r1046.0.relocated1089) ]
  %r40681127 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1126)
  %rs4gc.s50.relocated1128 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1126, i32 0, i32 0) ; (%rs4gc.s50.relocated1084, %rs4gc.s50.relocated1084)
  %rs4gc.s53.relocated1129 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1126, i32 1, i32 1) ; (%rs4gc.s53, %rs4gc.s53)
  %r48.0.base.relocated1130 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1126, i32 2, i32 2) ; (%r48.0.base.relocated1085, %r48.0.base.relocated1085)
  %r1053.1.relocated1131 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1126, i32 3, i32 3) ; (%r1053.1.relocated1086, %r1053.1.relocated1086)
  %r1046.0.base.relocated1132 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1126, i32 4, i32 4) ; (%r1046.0.base.relocated1087, %r1046.0.base.relocated1087)
  %r48.0.relocated1133 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1126, i32 2, i32 5) ; (%r48.0.base.relocated1085, %r48.0.relocated1088)
  %r1046.0.relocated1134 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1126, i32 4, i32 6) ; (%r1046.0.base.relocated1087, %r1046.0.relocated1089)
  br label %pget.recv_merge.695

pget.recv_sso.722:                                ; preds = %pget.recv_other.728
  %r4217 = lshr i64 %r4074, 40
  %r4218 = and i64 %r4217, 255
  %r4219 = uitofp nneg i64 %r4218 to double
  br label %pget.recv_merge.726

pget.recv_ok.723:                                 ; preds = %pget.recv_merge.695
  %r4085 = icmp eq i64 %r4076, 32767
  br i1 %r4085, label %pget.strlen_heap.727, label %pget.recv_obj.730

pget.recv_bad.724:                                ; preds = %pget.check_class_ref.729
  %r4209 = icmp eq i64 %r4074, 9222246136947933185
  %r4210 = icmp eq i64 %r4074, 9222246136947933186
  %r4211 = or i1 %r4209, %r4210
  br i1 %r4211, label %pget.throw_nullish.753, label %pget.recv_undef_return.754

pget.recv_class_ref.725:                          ; preds = %pget.check_class_ref.729
  %r4081 = load double, ptr @test_json_source_token_length_ts_.str.12.handle, align 8
  %r4082 = bitcast double %r4081 to i64
  %r4083 = and i64 %r4082, 281474976710655
  %statepoint_token1135 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 5587713372188573729, i64 %r4074, i64 %r4083, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01671, ptr addrspace(1) %.57, ptr addrspace(1) %.231641, ptr addrspace(1) %.441515, ptr addrspace(1) %.01675, ptr addrspace(1) %.571441, ptr addrspace(1) %.441573) ]
  %r40841136 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1135)
  %rs4gc.s50.relocated1137 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1135, i32 0, i32 0) ; (%.01671, %.01671)
  %r48.0.base.relocated1138 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1135, i32 1, i32 1) ; (%.57, %.57)
  %r1053.1.relocated1139 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1135, i32 2, i32 2) ; (%.231641, %.231641)
  %r1046.0.base.relocated1140 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1135, i32 3, i32 3) ; (%.441515, %.441515)
  %rs4gc.s53.relocated1141 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1135, i32 4, i32 4) ; (%.01675, %.01675)
  %r48.0.relocated1142 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1135, i32 1, i32 5) ; (%.57, %.571441)
  %r1046.0.relocated1143 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1135, i32 3, i32 6) ; (%.441515, %.441573)
  br label %pget.recv_merge.726

pget.recv_merge.726:                              ; preds = %pget.recv_undef_return.754, %pic.merge.745, %pget.strlen_heap.727, %pget.recv_class_ref.725, %pget.recv_sso.722
  %.21677 = phi ptr addrspace(1) [ %.01675, %pget.strlen_heap.727 ], [ %.31678, %pic.merge.745 ], [ %.01675, %pget.recv_sso.722 ], [ %rs4gc.s53.relocated1141, %pget.recv_class_ref.725 ], [ %rs4gc.s53.relocated1177, %pget.recv_undef_return.754 ]
  %.21673 = phi ptr addrspace(1) [ %.01671, %pget.strlen_heap.727 ], [ %.31674, %pic.merge.745 ], [ %.01671, %pget.recv_sso.722 ], [ %rs4gc.s50.relocated1137, %pget.recv_class_ref.725 ], [ %rs4gc.s50.relocated1173, %pget.recv_undef_return.754 ]
  %.251643 = phi ptr addrspace(1) [ %.231641, %pget.strlen_heap.727 ], [ %.261644, %pic.merge.745 ], [ %.231641, %pget.recv_sso.722 ], [ %r1053.1.relocated1139, %pget.recv_class_ref.725 ], [ %r1053.1.relocated1175, %pget.recv_undef_return.754 ]
  %.461575 = phi ptr addrspace(1) [ %.441573, %pget.strlen_heap.727 ], [ %.471576, %pic.merge.745 ], [ %.441573, %pget.recv_sso.722 ], [ %r1046.0.relocated1143, %pget.recv_class_ref.725 ], [ %r1046.0.relocated1179, %pget.recv_undef_return.754 ]
  %.461517 = phi ptr addrspace(1) [ %.441515, %pget.strlen_heap.727 ], [ %.471518, %pic.merge.745 ], [ %.441515, %pget.recv_sso.722 ], [ %r1046.0.base.relocated1140, %pget.recv_class_ref.725 ], [ %r1046.0.base.relocated1176, %pget.recv_undef_return.754 ]
  %.591443 = phi ptr addrspace(1) [ %.571441, %pget.strlen_heap.727 ], [ %.601444, %pic.merge.745 ], [ %.571441, %pget.recv_sso.722 ], [ %r48.0.relocated1142, %pget.recv_class_ref.725 ], [ %r48.0.relocated1178, %pget.recv_undef_return.754 ]
  %.59 = phi ptr addrspace(1) [ %.57, %pget.strlen_heap.727 ], [ %.60, %pic.merge.745 ], [ %.57, %pget.recv_sso.722 ], [ %r48.0.base.relocated1138, %pget.recv_class_ref.725 ], [ %r48.0.base.relocated1174, %pget.recv_undef_return.754 ]
  %r4225 = phi double [ %r4208, %pic.merge.745 ], [ %r42161172, %pget.recv_undef_return.754 ], [ %r4219, %pget.recv_sso.722 ], [ %r40841136, %pget.recv_class_ref.725 ], [ %r4224, %pget.strlen_heap.727 ]
  %r4226.rs4i = ptrtoint ptr addrspace(1) %.21677 to i64
  %r4226 = call i64 asm "", "=r,0"(i64 %r4226.rs4i) #7
  %statepoint_token1144 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4226, double %r4225, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.59, ptr addrspace(1) %.251643, ptr addrspace(1) %.461517, ptr addrspace(1) %.21673, ptr addrspace(1) %.591443, ptr addrspace(1) %.461575) ]
  %r42271145 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1144)
  %r48.0.base.relocated1146 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1144, i32 0, i32 0) ; (%.59, %.59)
  %r1053.1.relocated1147 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1144, i32 1, i32 1) ; (%.251643, %.251643)
  %r1046.0.base.relocated1148 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1144, i32 2, i32 2) ; (%.461517, %.461517)
  %rs4gc.s50.relocated1149 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1144, i32 3, i32 3) ; (%.21673, %.21673)
  %r48.0.relocated1150 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1144, i32 0, i32 4) ; (%.59, %.591443)
  %r1046.0.relocated1151 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1144, i32 2, i32 5) ; (%.461517, %.461575)
  %rs4gc.s54 = inttoptr i64 %r42271145 to ptr addrspace(1)
  %r4228.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s54 to i64
  %r4228 = call i64 asm "", "=r,0"(i64 %r4228.rs4i) #7
  %r4229 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4230 = icmp ne i32 %r4229, 0
  br i1 %r4230, label %shadow.root.barrier.755, label %shadow.root.barrier.done.756

pget.strlen_heap.727:                             ; preds = %pget.recv_ok.723
  %r4220 = icmp ult i64 %r4075, 4096
  %r4221 = inttoptr i64 %r4075 to ptr
  %r4222 = select i1 %r4220, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r4221
  %r4223 = load i32, ptr %r4222, align 4
  %r4224 = uitofp i32 %r4223 to double
  br label %pget.recv_merge.726

pget.recv_other.728:                              ; preds = %pget.recv_merge.695
  %r4079 = icmp eq i64 %r4076, 32761
  br i1 %r4079, label %pget.recv_sso.722, label %pget.check_class_ref.729

pget.check_class_ref.729:                         ; preds = %pget.recv_other.728
  %r4080 = icmp eq i64 %r4076, 32766
  br i1 %r4080, label %pget.recv_class_ref.725, label %pget.recv_bad.724

pget.recv_obj.730:                                ; preds = %pget.recv_ok.723
  %r4086 = icmp ugt i64 %r4075, 1048575
  br i1 %r4086, label %pic.recv_hdr.746, label %pic.miss.cold.743

pic.hit.731:                                      ; preds = %pic.token.747
  %r4111 = getelementptr i64, ptr %r4096, i64 1
  %r4112 = load i64, ptr %r4111, align 8
  %r4113 = and i64 %r4112, 1073741824
  %r4114 = icmp ne i64 %r4113, 0
  br i1 %r4114, label %pic.hit.overflow.748, label %pic.hit.inline.749

pic.hit.live.732:                                 ; preds = %pic.hit.inline.749
  br label %pic.merge.745

pic.prefix.guard.733:                             ; preds = %pic.token.747
  %r4127 = getelementptr i64, ptr %r4096, i64 2
  %r4128 = load i64, ptr %r4127, align 8
  %r4129 = icmp ne i64 %r4128, 0
  br i1 %r4129, label %pic.prefix.meta.734, label %pic.miss.742

pic.prefix.meta.734:                              ; preds = %pic.prefix.guard.733
  %r4130 = add nuw nsw i64 %r4075, 8
  %r4131 = inttoptr i64 %r4130 to ptr
  %r4132 = load i64, ptr %r4131, align 8
  %r4133 = icmp ne i64 %r4132, 0
  br i1 %r4133, label %pic.prefix.token.735, label %pic.miss.742

pic.prefix.token.735:                             ; preds = %pic.prefix.meta.734
  %r4134 = inttoptr i64 %r4132 to ptr
  %r4135 = getelementptr i64, ptr %r4134, i64 6
  %r4136 = load i64, ptr %r4135, align 8
  %r4137 = icmp eq i64 %r4136, %r4128
  br i1 %r4137, label %pic.prefix.hit.736, label %pic.miss.742

pic.prefix.hit.736:                               ; preds = %pic.prefix.token.735
  %r4138 = getelementptr i64, ptr %r4096, i64 1
  %r4139 = load i64, ptr %r4138, align 8
  %r4140 = shl i64 %r4139, 3
  %r4141 = add nuw nsw i64 %r4075, 16
  %r4142 = add i64 %r4141, %r4140
  %r4143 = inttoptr i64 %r4142 to ptr
  %r4144 = load double, ptr %r4143, align 8
  br label %pic.merge.745

pic.desc.classify.737:                            ; preds = %pic.recv_hdr.746
  %r4100 = and i1 %r4090, %r4097
  br i1 %r4100, label %pic.desc.prefix.guard.738, label %pic.miss.cold.743

pic.desc.prefix.guard.738:                        ; preds = %pic.desc.classify.737
  %r4145 = getelementptr i64, ptr %r4096, i64 2
  %r4146 = load i64, ptr %r4145, align 8
  %r4147 = icmp ne i64 %r4146, 0
  br i1 %r4147, label %pic.desc.prefix.meta.739, label %pic.miss.cold.743

pic.desc.prefix.meta.739:                         ; preds = %pic.desc.prefix.guard.738
  %r4148 = add nuw nsw i64 %r4075, 8
  %r4149 = inttoptr i64 %r4148 to ptr
  %r4150 = load i64, ptr %r4149, align 8
  %r4151 = icmp ne i64 %r4150, 0
  br i1 %r4151, label %pic.desc.prefix.token.740, label %pic.miss.cold.743

pic.desc.prefix.token.740:                        ; preds = %pic.desc.prefix.meta.739
  %r4152 = inttoptr i64 %r4150 to ptr
  %r4153 = getelementptr i64, ptr %r4152, i64 6
  %r4154 = load i64, ptr %r4153, align 8
  %r4155 = icmp eq i64 %r4154, %r4146
  br i1 %r4155, label %pic.desc.prefix.hit.741, label %pic.miss.cold.743

pic.desc.prefix.hit.741:                          ; preds = %pic.desc.prefix.token.740
  %r4156 = getelementptr i64, ptr %r4096, i64 1
  %r4157 = load i64, ptr %r4156, align 8
  %r4158 = shl i64 %r4157, 3
  %r4159 = add nuw nsw i64 %r4075, 16
  %r4160 = add i64 %r4159, %r4158
  %r4161 = inttoptr i64 %r4160 to ptr
  %r4162 = load double, ptr %r4161, align 8
  br label %pic.merge.745

pic.miss.742:                                     ; preds = %pic.hit.inline.749, %pic.prefix.token.735, %pic.prefix.meta.734, %pic.prefix.guard.733
  %r4163 = getelementptr i64, ptr %r4096, i64 3
  %r4164 = load i64, ptr %r4163, align 8
  %r4165 = icmp sgt i64 %r4164, 0
  br i1 %r4165, label %pic.ways.750, label %pic.miss.call.744

pic.miss.cold.743:                                ; preds = %pic.desc.prefix.token.740, %pic.desc.prefix.meta.739, %pic.desc.prefix.guard.738, %pic.desc.classify.737, %pget.recv_obj.730
  br label %pic.miss.call.744

pic.miss.call.744:                                ; preds = %pic.way.load.751, %pic.ways.750, %pic.miss.cold.743, %pic.miss.742
  %r4204 = load double, ptr @test_json_source_token_length_ts_.str.12.handle, align 8
  %r4205 = bitcast double %r4204 to i64
  %r4206 = and i64 %r4205, 281474976710655
  %statepoint_token1152 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r4075, i64 %r4206, ptr @perry_ic_test_json_source_token_length_ts__34, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01671, ptr addrspace(1) %.57, ptr addrspace(1) %.231641, ptr addrspace(1) %.441515, ptr addrspace(1) %.01675, ptr addrspace(1) %.571441, ptr addrspace(1) %.441573) ]
  %r42071153 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1152)
  %rs4gc.s50.relocated1154 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1152, i32 0, i32 0) ; (%.01671, %.01671)
  %r48.0.base.relocated1155 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1152, i32 1, i32 1) ; (%.57, %.57)
  %r1053.1.relocated1156 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1152, i32 2, i32 2) ; (%.231641, %.231641)
  %r1046.0.base.relocated1157 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1152, i32 3, i32 3) ; (%.441515, %.441515)
  %rs4gc.s53.relocated1158 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1152, i32 4, i32 4) ; (%.01675, %.01675)
  %r48.0.relocated1159 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1152, i32 1, i32 5) ; (%.57, %.571441)
  %r1046.0.relocated1160 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1152, i32 3, i32 6) ; (%.441515, %.441573)
  br label %pic.merge.745

pic.merge.745:                                    ; preds = %pic.way.live.752, %pic.hit.overflow.748, %pic.miss.call.744, %pic.desc.prefix.hit.741, %pic.prefix.hit.736, %pic.hit.live.732
  %.31678 = phi ptr addrspace(1) [ %rs4gc.s53.relocated1167, %pic.hit.overflow.748 ], [ %rs4gc.s53.relocated1158, %pic.miss.call.744 ], [ %.01675, %pic.way.live.752 ], [ %.01675, %pic.hit.live.732 ], [ %.01675, %pic.prefix.hit.736 ], [ %.01675, %pic.desc.prefix.hit.741 ]
  %.31674 = phi ptr addrspace(1) [ %rs4gc.s50.relocated1163, %pic.hit.overflow.748 ], [ %rs4gc.s50.relocated1154, %pic.miss.call.744 ], [ %.01671, %pic.way.live.752 ], [ %.01671, %pic.hit.live.732 ], [ %.01671, %pic.prefix.hit.736 ], [ %.01671, %pic.desc.prefix.hit.741 ]
  %.261644 = phi ptr addrspace(1) [ %r1053.1.relocated1165, %pic.hit.overflow.748 ], [ %r1053.1.relocated1156, %pic.miss.call.744 ], [ %.231641, %pic.way.live.752 ], [ %.231641, %pic.hit.live.732 ], [ %.231641, %pic.prefix.hit.736 ], [ %.231641, %pic.desc.prefix.hit.741 ]
  %.471576 = phi ptr addrspace(1) [ %r1046.0.relocated1169, %pic.hit.overflow.748 ], [ %r1046.0.relocated1160, %pic.miss.call.744 ], [ %.441573, %pic.way.live.752 ], [ %.441573, %pic.hit.live.732 ], [ %.441573, %pic.prefix.hit.736 ], [ %.441573, %pic.desc.prefix.hit.741 ]
  %.471518 = phi ptr addrspace(1) [ %r1046.0.base.relocated1166, %pic.hit.overflow.748 ], [ %r1046.0.base.relocated1157, %pic.miss.call.744 ], [ %.441515, %pic.way.live.752 ], [ %.441515, %pic.hit.live.732 ], [ %.441515, %pic.prefix.hit.736 ], [ %.441515, %pic.desc.prefix.hit.741 ]
  %.601444 = phi ptr addrspace(1) [ %r48.0.relocated1168, %pic.hit.overflow.748 ], [ %r48.0.relocated1159, %pic.miss.call.744 ], [ %.571441, %pic.way.live.752 ], [ %.571441, %pic.hit.live.732 ], [ %.571441, %pic.prefix.hit.736 ], [ %.571441, %pic.desc.prefix.hit.741 ]
  %.60 = phi ptr addrspace(1) [ %r48.0.base.relocated1164, %pic.hit.overflow.748 ], [ %r48.0.base.relocated1155, %pic.miss.call.744 ], [ %.57, %pic.way.live.752 ], [ %.57, %pic.hit.live.732 ], [ %.57, %pic.prefix.hit.736 ], [ %.57, %pic.desc.prefix.hit.741 ]
  %r4208 = phi double [ %r4124, %pic.hit.live.732 ], [ %r41191162, %pic.hit.overflow.748 ], [ %r4144, %pic.prefix.hit.736 ], [ %r4162, %pic.desc.prefix.hit.741 ], [ %r4201, %pic.way.live.752 ], [ %r42071153, %pic.miss.call.744 ]
  br label %pget.recv_merge.726

pic.recv_hdr.746:                                 ; preds = %pget.recv_obj.730
  %r4087 = sub nuw nsw i64 %r4075, 8
  %r4088 = inttoptr i64 %r4087 to ptr
  %r4089 = load i8, ptr %r4088, align 1
  %r4090 = icmp eq i8 %r4089, 2
  %r4091 = sub nuw nsw i64 %r4075, 6
  %r4092 = inttoptr i64 %r4091 to ptr
  %r4093 = load i16, ptr %r4092, align 2
  %r4094 = and i16 %r4093, 2048
  %r4095 = icmp eq i16 %r4094, 0
  %r4096 = load ptr, ptr @perry_ic_test_json_source_token_length_ts__34, align 8
  %r4097 = icmp ne ptr %r4096, null
  %r4098 = and i1 %r4090, %r4095
  %r4099 = and i1 %r4098, %r4097
  br i1 %r4099, label %pic.token.747, label %pic.desc.classify.737

pic.token.747:                                    ; preds = %pic.recv_hdr.746
  %r4101 = add nuw nsw i64 %r4075, 4
  %r4102 = inttoptr i64 %r4101 to ptr
  %r4103 = load i32, ptr %r4102, align 4
  %r4104 = zext i32 %r4103 to i64
  %r4105 = or i64 %r4104, 4611686018427387904
  %r4106 = icmp ne i32 %r4103, 0
  %r4107 = getelementptr i64, ptr %r4096, i64 0
  %r4108 = load i64, ptr %r4107, align 8
  %r4109 = icmp eq i64 %r4105, %r4108
  %r4110 = and i1 %r4109, %r4106
  br i1 %r4110, label %pic.hit.731, label %pic.prefix.guard.733

pic.hit.overflow.748:                             ; preds = %pic.hit.731
  %r4115 = load double, ptr @test_json_source_token_length_ts_.str.12.handle, align 8
  %r4116 = bitcast double %r4115 to i64
  %r4117 = and i64 %r4116, 281474976710655
  %r4118 = trunc i64 %r4112 to i32
  %statepoint_token1161 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r4075, i64 %r4117, i32 %r4118, ptr @perry_ic_test_json_source_token_length_ts__34, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01671, ptr addrspace(1) %.57, ptr addrspace(1) %.231641, ptr addrspace(1) %.441515, ptr addrspace(1) %.01675, ptr addrspace(1) %.571441, ptr addrspace(1) %.441573) ]
  %r41191162 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1161)
  %rs4gc.s50.relocated1163 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1161, i32 0, i32 0) ; (%.01671, %.01671)
  %r48.0.base.relocated1164 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1161, i32 1, i32 1) ; (%.57, %.57)
  %r1053.1.relocated1165 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1161, i32 2, i32 2) ; (%.231641, %.231641)
  %r1046.0.base.relocated1166 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1161, i32 3, i32 3) ; (%.441515, %.441515)
  %rs4gc.s53.relocated1167 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1161, i32 4, i32 4) ; (%.01675, %.01675)
  %r48.0.relocated1168 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1161, i32 1, i32 5) ; (%.57, %.571441)
  %r1046.0.relocated1169 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1161, i32 3, i32 6) ; (%.441515, %.441573)
  br label %pic.merge.745

pic.hit.inline.749:                               ; preds = %pic.hit.731
  %r4120 = shl i64 %r4112, 3
  %r4121 = add nuw nsw i64 %r4075, 16
  %r4122 = add i64 %r4121, %r4120
  %r4123 = inttoptr i64 %r4122 to ptr
  %r4124 = load double, ptr %r4123, align 8
  %r4125 = bitcast double %r4124 to i64
  %r4126 = icmp eq i64 %r4125, 9222246136947933200
  br i1 %r4126, label %pic.miss.742, label %pic.hit.live.732

pic.ways.750:                                     ; preds = %pic.miss.742
  %r4166 = getelementptr i64, ptr %r4096, i64 4
  %r4167 = load i64, ptr %r4166, align 8
  %r4168 = icmp eq i64 %r4167, %r4105
  %r4169 = getelementptr i64, ptr %r4096, i64 5
  %r4170 = load i64, ptr %r4169, align 8
  %r4171 = select i1 %r4168, i64 %r4170, i64 0
  %r4172 = getelementptr i64, ptr %r4096, i64 6
  %r4173 = load i64, ptr %r4172, align 8
  %r4174 = icmp eq i64 %r4173, %r4105
  %r4175 = getelementptr i64, ptr %r4096, i64 7
  %r4176 = load i64, ptr %r4175, align 8
  %r4177 = select i1 %r4174, i64 %r4176, i64 0
  %r4178 = getelementptr i64, ptr %r4096, i64 8
  %r4179 = load i64, ptr %r4178, align 8
  %r4180 = icmp eq i64 %r4179, %r4105
  %r4181 = getelementptr i64, ptr %r4096, i64 9
  %r4182 = load i64, ptr %r4181, align 8
  %r4183 = select i1 %r4180, i64 %r4182, i64 0
  %r4184 = getelementptr i64, ptr %r4096, i64 10
  %r4185 = load i64, ptr %r4184, align 8
  %r4186 = icmp eq i64 %r4185, %r4105
  %r4187 = getelementptr i64, ptr %r4096, i64 11
  %r4188 = load i64, ptr %r4187, align 8
  %r4189 = select i1 %r4186, i64 %r4188, i64 0
  %r4190 = or i1 %r4168, %r4174
  %r4191 = select i1 %r4168, i64 %r4171, i64 %r4177
  %r4192 = or i1 %r4180, %r4186
  %r4193 = select i1 %r4180, i64 %r4183, i64 %r4189
  %r4194 = or i1 %r4190, %r4192
  %r4195 = select i1 %r4190, i64 %r4191, i64 %r4193
  %r4196 = and i1 %r4106, %r4194
  br i1 %r4196, label %pic.way.load.751, label %pic.miss.call.744

pic.way.load.751:                                 ; preds = %pic.ways.750
  %r4197 = shl i64 %r4195, 3
  %r4198 = add nuw nsw i64 %r4075, 16
  %r4199 = add i64 %r4198, %r4197
  %r4200 = inttoptr i64 %r4199 to ptr
  %r4201 = load double, ptr %r4200, align 8
  %r4202 = bitcast double %r4201 to i64
  %r4203 = icmp eq i64 %r4202, 9222246136947933200
  br i1 %r4203, label %pic.miss.call.744, label %pic.way.live.752

pic.way.live.752:                                 ; preds = %pic.way.load.751
  br label %pic.merge.745

pget.throw_nullish.753:                           ; preds = %pget.recv_bad.724
  %r4212 = zext i1 %r4210 to i32
  %statepoint_token1170 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r4212, ptr @test_json_source_token_length_ts_.str.12.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.754:                       ; preds = %pget.recv_bad.724
  %r4213 = load double, ptr @test_json_source_token_length_ts_.str.12.handle, align 8
  %r4214 = bitcast double %r4213 to i64
  %r4215 = and i64 %r4214, 281474976710655
  %statepoint_token1171 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r4074, i64 %r4215, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01671, ptr addrspace(1) %.57, ptr addrspace(1) %.231641, ptr addrspace(1) %.441515, ptr addrspace(1) %.01675, ptr addrspace(1) %.571441, ptr addrspace(1) %.441573) ]
  %r42161172 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1171)
  %rs4gc.s50.relocated1173 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1171, i32 0, i32 0) ; (%.01671, %.01671)
  %r48.0.base.relocated1174 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1171, i32 1, i32 1) ; (%.57, %.57)
  %r1053.1.relocated1175 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1171, i32 2, i32 2) ; (%.231641, %.231641)
  %r1046.0.base.relocated1176 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1171, i32 3, i32 3) ; (%.441515, %.441515)
  %rs4gc.s53.relocated1177 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1171, i32 4, i32 4) ; (%.01675, %.01675)
  %r48.0.relocated1178 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1171, i32 1, i32 5) ; (%.57, %.571441)
  %r1046.0.relocated1179 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1171, i32 3, i32 6) ; (%.441515, %.441573)
  br label %pget.recv_merge.726

shadow.root.barrier.755:                          ; preds = %pget.recv_merge.726
  call void @js_write_barrier_root_nanbox(i64 %r4228) #7
  br label %shadow.root.barrier.done.756

shadow.root.barrier.done.756:                     ; preds = %shadow.root.barrier.755, %pget.recv_merge.726
  %r4231.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s50.relocated1149 to i64
  %r4231.rs4o = call i64 asm "", "=r,0"(i64 %r4231.rs4i) #7
  %r4231 = bitcast i64 %r4231.rs4o to double
  %statepoint_token1180 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r4231, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.0.base.relocated1146, ptr addrspace(1) %r1053.1.relocated1147, ptr addrspace(1) %r1046.0.base.relocated1148, ptr addrspace(1) %r48.0.relocated1150, ptr addrspace(1) %r1046.0.relocated1151, ptr addrspace(1) %rs4gc.s54) ]
  %r42321181 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1180)
  %r48.0.base.relocated1182 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1180, i32 0, i32 0) ; (%r48.0.base.relocated1146, %r48.0.base.relocated1146)
  %r1053.1.relocated1183 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1180, i32 1, i32 1) ; (%r1053.1.relocated1147, %r1053.1.relocated1147)
  %r1046.0.base.relocated1184 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1180, i32 2, i32 2) ; (%r1046.0.base.relocated1148, %r1046.0.base.relocated1148)
  %r48.0.relocated1185 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1180, i32 0, i32 3) ; (%r48.0.base.relocated1146, %r48.0.relocated1150)
  %r1046.0.relocated1186 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1180, i32 2, i32 4) ; (%r1046.0.base.relocated1148, %r1046.0.relocated1151)
  %rs4gc.s54.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1180, i32 5, i32 5) ; (%rs4gc.s54, %rs4gc.s54)
  %r4233 = bitcast i64 %r42321181 to double
  %r4234.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s54.relocated to i64
  %r4234 = call i64 asm "", "=r,0"(i64 %r4234.rs4i) #7
  %statepoint_token1187 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4234, double %r4233, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.0.base.relocated1182, ptr addrspace(1) %r1053.1.relocated1183, ptr addrspace(1) %r1046.0.base.relocated1184, ptr addrspace(1) %r48.0.relocated1185, ptr addrspace(1) %r1046.0.relocated1186) ]
  %r42351188 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1187)
  %r48.0.base.relocated1189 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1187, i32 0, i32 0) ; (%r48.0.base.relocated1182, %r48.0.base.relocated1182)
  %r1053.1.relocated1190 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1187, i32 1, i32 1) ; (%r1053.1.relocated1183, %r1053.1.relocated1183)
  %r1046.0.base.relocated1191 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1187, i32 2, i32 2) ; (%r1046.0.base.relocated1184, %r1046.0.base.relocated1184)
  %r48.0.relocated1192 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1187, i32 0, i32 3) ; (%r48.0.base.relocated1182, %r48.0.relocated1185)
  %r1046.0.relocated1193 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1187, i32 2, i32 4) ; (%r1046.0.base.relocated1184, %r1046.0.relocated1186)
  %rs4gc.s55 = inttoptr i64 %r42351188 to ptr addrspace(1)
  %r4236.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s55 to i64
  %r4236 = call i64 asm "", "=r,0"(i64 %r4236.rs4i) #7
  %r4237 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4238 = icmp ne i32 %r4237, 0
  br i1 %r4238, label %shadow.root.barrier.757, label %shadow.root.barrier.done.758

shadow.root.barrier.757:                          ; preds = %shadow.root.barrier.done.756
  call void @js_write_barrier_root_nanbox(i64 %r4236) #7
  br label %shadow.root.barrier.done.758

shadow.root.barrier.done.758:                     ; preds = %shadow.root.barrier.757, %shadow.root.barrier.done.756
  %r4239.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s55 to i64
  %r4239 = call i64 asm "", "=r,0"(i64 %r4239.rs4i) #7
  %statepoint_token1194 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r4239, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.0.base.relocated1189, ptr addrspace(1) %r1053.1.relocated1190, ptr addrspace(1) %r1046.0.base.relocated1191, ptr addrspace(1) %r48.0.relocated1192, ptr addrspace(1) %r1046.0.relocated1193) ]
  %r48.0.base.relocated1195 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1194, i32 0, i32 0) ; (%r48.0.base.relocated1189, %r48.0.base.relocated1189)
  %r1053.1.relocated1196 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1194, i32 1, i32 1) ; (%r1053.1.relocated1190, %r1053.1.relocated1190)
  %r1046.0.base.relocated1197 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1194, i32 2, i32 2) ; (%r1046.0.base.relocated1191, %r1046.0.base.relocated1191)
  %r48.0.relocated1198 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1194, i32 0, i32 3) ; (%r48.0.base.relocated1189, %r48.0.relocated1192)
  %r1046.0.relocated1199 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1194, i32 2, i32 4) ; (%r1046.0.base.relocated1191, %r1046.0.relocated1193)
  %r4240 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r4241 = icmp ne i32 %r4240, 0
  br i1 %r4241, label %gcpoll.759, label %gcpoll.done.760

gcpoll.759:                                       ; preds = %shadow.root.barrier.done.758
  %statepoint_token1200 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.0.base.relocated1195, ptr addrspace(1) %r1053.1.relocated1196, ptr addrspace(1) %r1046.0.base.relocated1197, ptr addrspace(1) %r48.0.relocated1198, ptr addrspace(1) %r1046.0.relocated1199) ]
  %r48.0.base.relocated1201 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1200, i32 0, i32 0) ; (%r48.0.base.relocated1195, %r48.0.base.relocated1195)
  %r1053.1.relocated1202 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1200, i32 1, i32 1) ; (%r1053.1.relocated1196, %r1053.1.relocated1196)
  %r1046.0.base.relocated1203 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1200, i32 2, i32 2) ; (%r1046.0.base.relocated1197, %r1046.0.base.relocated1197)
  %r48.0.relocated1204 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1200, i32 0, i32 3) ; (%r48.0.base.relocated1195, %r48.0.relocated1198)
  %r1046.0.relocated1205 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1200, i32 2, i32 4) ; (%r1046.0.base.relocated1197, %r1046.0.relocated1199)
  br label %gcpoll.done.760

gcpoll.done.760:                                  ; preds = %gcpoll.759, %shadow.root.barrier.done.758
  %.271645 = phi ptr addrspace(1) [ %r1053.1.relocated1202, %gcpoll.759 ], [ %r1053.1.relocated1196, %shadow.root.barrier.done.758 ]
  %.481577 = phi ptr addrspace(1) [ %r1046.0.relocated1205, %gcpoll.759 ], [ %r1046.0.relocated1199, %shadow.root.barrier.done.758 ]
  %.481519 = phi ptr addrspace(1) [ %r1046.0.base.relocated1203, %gcpoll.759 ], [ %r1046.0.base.relocated1197, %shadow.root.barrier.done.758 ]
  %.611445 = phi ptr addrspace(1) [ %r48.0.relocated1204, %gcpoll.759 ], [ %r48.0.relocated1198, %shadow.root.barrier.done.758 ]
  %.61 = phi ptr addrspace(1) [ %r48.0.base.relocated1201, %gcpoll.759 ], [ %r48.0.base.relocated1195, %shadow.root.barrier.done.758 ]
  br label %for.update.651

shadow.root.barrier.761:                          ; preds = %for.exit.652
  call void @js_write_barrier_root_nanbox(i64 %r4247) #7
  br label %shadow.root.barrier.done.762

shadow.root.barrier.done.762:                     ; preds = %shadow.root.barrier.761, %for.exit.652
  %r4250 = load double, ptr @test_json_source_token_length_ts_.str.19.handle, align 8
  %r4251.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s49 to i64
  %r4251 = call i64 asm "", "=r,0"(i64 %r4251.rs4i) #7
  %statepoint_token1206 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4251, double %r4250, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1053.1.relocated1030, ptr addrspace(1) %r1046.0.relocated1031, ptr addrspace(1) %r1046.0.base.relocated1032) ]
  %r42521207 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1206)
  %r1053.1.relocated1208 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1206, i32 0, i32 0) ; (%r1053.1.relocated1030, %r1053.1.relocated1030)
  %r1046.0.relocated1209 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1206, i32 2, i32 1) ; (%r1046.0.base.relocated1032, %r1046.0.relocated1031)
  %r1046.0.base.relocated1210 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1206, i32 2, i32 2) ; (%r1046.0.base.relocated1032, %r1046.0.base.relocated1032)
  %rs4gc.s56 = inttoptr i64 %r42521207 to ptr addrspace(1)
  %r4253.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s56 to i64
  %r4253 = call i64 asm "", "=r,0"(i64 %r4253.rs4i) #7
  %r4254 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4255 = icmp ne i32 %r4254, 0
  br i1 %r4255, label %shadow.root.barrier.763, label %shadow.root.barrier.done.764

shadow.root.barrier.763:                          ; preds = %shadow.root.barrier.done.762
  call void @js_write_barrier_root_nanbox(i64 %r4253) #7
  br label %shadow.root.barrier.done.764

shadow.root.barrier.done.764:                     ; preds = %shadow.root.barrier.763, %shadow.root.barrier.done.762
  %r4256.rs4i = ptrtoint ptr addrspace(1) %r1046.0.relocated1209 to i64
  %r4256.rs4o = call i64 asm "", "=r,0"(i64 %r4256.rs4i) #7
  %r4256 = bitcast i64 %r4256.rs4o to double
  %r4257 = bitcast double %r4256 to i64
  %r4258 = and i64 %r4257, 281474976710655
  %r4259 = lshr i64 %r4257, 48
  %r4260 = and i64 %r4259, 65533
  %r4261 = icmp eq i64 %r4260, 32765
  %r4262 = icmp ugt i64 %r4258, 1048575
  %r4263 = and i1 %r4261, %r4262
  br i1 %r4263, label %plen.check_gc.765, label %plen.slow.767

plen.check_gc.765:                                ; preds = %shadow.root.barrier.done.764
  %r4264 = sub nuw nsw i64 %r4258, 8
  %r4265 = inttoptr i64 %r4264 to ptr
  %r4266 = load i8, ptr %r4265, align 1
  %r4267 = icmp eq i8 %r4266, 1
  %r4268 = icmp eq i8 %r4266, 3
  %r4269 = or i1 %r4267, %r4268
  %r4270 = sub nuw nsw i64 %r4258, 7
  %r4271 = inttoptr i64 %r4270 to ptr
  %r4272 = load i8, ptr %r4271, align 1
  %r4273 = and i8 %r4272, -128
  %r4274 = icmp eq i8 %r4273, 0
  %r4275 = and i1 %r4269, %r4274
  br i1 %r4275, label %plen.fast.766, label %plen.slow.767

plen.fast.766:                                    ; preds = %plen.check_gc.765
  %r4277 = inttoptr i64 %r4258 to ptr
  %r4278 = select i1 false, ptr @perry_null_guard_zero_test_json_source_token_length_ts, ptr %r4277
  %r4279 = load i32, ptr %r4278, align 4
  %r4280 = uitofp i32 %r4279 to double
  br label %plen.merge.768

plen.slow.767:                                    ; preds = %plen.check_gc.765, %shadow.root.barrier.done.764
  %r4281 = lshr i64 %r4257, 48
  %r4282 = icmp eq i64 %r4281, 32765
  %r4283 = icmp uge i64 %r4258, 2199023255552
  %r4284 = icmp ult i64 %r4258, 140737488355328
  %r4285 = and i1 %r4282, %r4283
  %r4286 = and i1 %r4285, %r4284
  %r4287 = load ptr, ptr @perry_ic_test_json_source_token_length_ts__35, align 8
  br i1 %r4286, label %plen.ic.header.769, label %plen.ic.miss.781

plen.merge.768:                                   ; preds = %plen.ic.merge.782, %plen.fast.766
  %.01679 = phi ptr addrspace(1) [ %rs4gc.s56, %plen.fast.766 ], [ %.11680, %plen.ic.merge.782 ]
  %.281646 = phi ptr addrspace(1) [ %r1053.1.relocated1208, %plen.fast.766 ], [ %.291647, %plen.ic.merge.782 ]
  %r4362 = phi double [ %r4280, %plen.fast.766 ], [ %r4361, %plen.ic.merge.782 ]
  %r4363.rs4i = ptrtoint ptr addrspace(1) %.01679 to i64
  %r4363 = call i64 asm "", "=r,0"(i64 %r4363.rs4i) #7
  %statepoint_token1211 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4363, double %r4362, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.281646) ]
  %r43641212 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1211)
  %r1053.1.relocated1213 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1211, i32 0, i32 0) ; (%.281646, %.281646)
  %rs4gc.s57 = inttoptr i64 %r43641212 to ptr addrspace(1)
  %r4365.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s57 to i64
  %r4365 = call i64 asm "", "=r,0"(i64 %r4365.rs4i) #7
  %r4366 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4367 = icmp ne i32 %r4366, 0
  br i1 %r4367, label %shadow.root.barrier.786, label %shadow.root.barrier.done.787

plen.ic.header.769:                               ; preds = %plen.slow.767
  %r4289 = sub nuw nsw i64 %r4258, 8
  %r4290 = inttoptr i64 %r4289 to ptr
  %r4291 = load i8, ptr %r4290, align 1
  %r4292 = icmp eq i8 %r4291, 2
  %r4293 = sub nuw nsw i64 %r4258, 7
  %r4294 = inttoptr i64 %r4293 to ptr
  %r4295 = load i8, ptr %r4294, align 1
  %r4296 = and i8 %r4295, -128
  %r4297 = icmp eq i8 %r4296, 0
  %r4298 = and i1 %r4292, %r4297
  br i1 %r4298, label %plen.elem.meta.783, label %plen.ic.miss.781

plen.ic.shape.770:                                ; preds = %plen.elem.store.784, %plen.elem.meta.783
  %r4288 = icmp ne ptr %r4287, null
  br i1 %r4288, label %plen.ic.shape.probe.771, label %plen.ic.miss.781

plen.ic.shape.probe.771:                          ; preds = %plen.ic.shape.770
  %r4310 = inttoptr i64 %r4258 to ptr
  %r4311 = load i32, ptr %r4310, align 4
  %r4312 = add nuw nsw i64 %r4258, 4
  %r4313 = inttoptr i64 %r4312 to ptr
  %r4314 = load i32, ptr %r4313, align 4
  %r4315 = zext i32 %r4311 to i64
  %r4316 = zext i32 %r4314 to i64
  %r4317 = shl nuw i64 %r4315, 32
  %r4318 = or i64 %r4317, %r4316
  %r4319 = getelementptr i64, ptr %r4287, i64 0
  %r4320 = load i64, ptr %r4319, align 8
  %r4321 = icmp ne i64 %r4320, 0
  br i1 %r4321, label %plen.ic.identity.772, label %plen.ic.miss.781

plen.ic.identity.772:                             ; preds = %plen.ic.shape.probe.771
  %r4322 = and i64 %r4320, -9223372036854775808
  %5 = icmp slt i64 %r4320, 0
  br i1 %5, label %plen.ic.family_meta.774, label %plen.ic.exact.773

plen.ic.exact.773:                                ; preds = %plen.ic.identity.772
  %r4324 = icmp eq i64 %r4318, %r4320
  br i1 %r4324, label %plen.ic.slot.776, label %plen.ic.miss.781

plen.ic.family_meta.774:                          ; preds = %plen.ic.identity.772
  %r4325 = add nuw nsw i64 %r4258, 8
  %r4326 = inttoptr i64 %r4325 to ptr
  %r4327 = load i64, ptr %r4326, align 8
  %r4328 = icmp ne i64 %r4327, 0
  br i1 %r4328, label %plen.ic.family_token.775, label %plen.ic.miss.781

plen.ic.family_token.775:                         ; preds = %plen.ic.family_meta.774
  %r4329 = inttoptr i64 %r4327 to ptr
  %r4330 = getelementptr i64, ptr %r4329, i64 6
  %r4331 = load i64, ptr %r4330, align 8
  %r4332 = icmp eq i64 %r4331, %r4320
  br i1 %r4332, label %plen.ic.slot.776, label %plen.ic.miss.781

plen.ic.slot.776:                                 ; preds = %plen.ic.family_token.775, %plen.ic.exact.773
  %r4333 = getelementptr i64, ptr %r4287, i64 1
  %r4334 = load i64, ptr %r4333, align 8
  %r4335 = getelementptr i64, ptr %r4287, i64 2
  %r4336 = load i64, ptr %r4335, align 8
  %r4337 = icmp ult i64 %r4334, %r4336
  br i1 %r4337, label %plen.ic.inline.777, label %plen.ic.spill_meta.778

plen.ic.inline.777:                               ; preds = %plen.ic.slot.776
  %r4338 = shl i64 %r4334, 3
  %r4339 = add i64 %r4338, 16
  %r4340 = add i64 %r4258, %r4339
  %r4341 = inttoptr i64 %r4340 to ptr
  %r4342 = load double, ptr %r4341, align 8
  br label %plen.ic.merge.782

plen.ic.spill_meta.778:                           ; preds = %plen.ic.slot.776
  %r4343 = add nuw nsw i64 %r4258, 8
  %r4344 = inttoptr i64 %r4343 to ptr
  %r4345 = load i64, ptr %r4344, align 8
  %r4346 = icmp ne i64 %r4345, 0
  br i1 %r4346, label %plen.ic.spill_ptr.779, label %plen.ic.miss.781

plen.ic.spill_ptr.779:                            ; preds = %plen.ic.spill_meta.778
  %r4347 = inttoptr i64 %r4345 to ptr
  %r4348 = getelementptr i64, ptr %r4347, i64 4
  %r4349 = load i64, ptr %r4348, align 8
  %r4350 = icmp ne i64 %r4349, 0
  %r4351 = select i1 %r4350, i64 %r4349, i64 %r4345
  %r4352 = inttoptr i64 %r4351 to ptr
  %r4353 = load i32, ptr %r4352, align 4
  %r4354 = zext i32 %r4353 to i64
  %r4355 = icmp ult i64 %r4334, %r4354
  %r4356 = and i1 %r4350, %r4355
  br i1 %r4356, label %plen.ic.spill_load.780, label %plen.ic.miss.781

plen.ic.spill_load.780:                           ; preds = %plen.ic.spill_ptr.779
  %r4357 = add nuw nsw i64 %r4334, 1
  %r4358 = getelementptr inbounds nuw i64, ptr %r4352, i64 %r4357
  %r4359 = load double, ptr %r4358, align 8
  br label %plen.ic.merge.782

plen.ic.miss.781:                                 ; preds = %plen.ic.spill_ptr.779, %plen.ic.spill_meta.778, %plen.ic.family_token.775, %plen.ic.family_meta.774, %plen.ic.exact.773, %plen.ic.shape.probe.771, %plen.ic.shape.770, %plen.ic.header.769, %plen.slow.767
  %statepoint_token1214 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r4256, ptr @perry_ic_test_json_source_token_length_ts__35, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1053.1.relocated1208, ptr addrspace(1) %rs4gc.s56) ]
  %r43601215 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1214)
  %r1053.1.relocated1216 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1214, i32 0, i32 0) ; (%r1053.1.relocated1208, %r1053.1.relocated1208)
  %rs4gc.s56.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1214, i32 1, i32 1) ; (%rs4gc.s56, %rs4gc.s56)
  br label %plen.ic.merge.782

plen.ic.merge.782:                                ; preds = %plen.elem.length.785, %plen.ic.miss.781, %plen.ic.spill_load.780, %plen.ic.inline.777
  %.11680 = phi ptr addrspace(1) [ %rs4gc.s56, %plen.elem.length.785 ], [ %rs4gc.s56, %plen.ic.inline.777 ], [ %rs4gc.s56, %plen.ic.spill_load.780 ], [ %rs4gc.s56.relocated, %plen.ic.miss.781 ]
  %.291647 = phi ptr addrspace(1) [ %r1053.1.relocated1208, %plen.elem.length.785 ], [ %r1053.1.relocated1208, %plen.ic.inline.777 ], [ %r1053.1.relocated1208, %plen.ic.spill_load.780 ], [ %r1053.1.relocated1216, %plen.ic.miss.781 ]
  %r4361 = phi double [ %r4309, %plen.elem.length.785 ], [ %r4342, %plen.ic.inline.777 ], [ %r4359, %plen.ic.spill_load.780 ], [ %r43601215, %plen.ic.miss.781 ]
  br label %plen.merge.768

plen.elem.meta.783:                               ; preds = %plen.ic.header.769
  %r4299 = add nuw nsw i64 %r4258, 8
  %r4300 = inttoptr i64 %r4299 to ptr
  %r4301 = load i64, ptr %r4300, align 8
  %r4302 = icmp ne i64 %r4301, 0
  br i1 %r4302, label %plen.elem.store.784, label %plen.ic.shape.770

plen.elem.store.784:                              ; preds = %plen.elem.meta.783
  %r4303 = inttoptr i64 %r4301 to ptr
  %r4304 = getelementptr i64, ptr %r4303, i64 12
  %r4305 = load i64, ptr %r4304, align 8
  %r4306 = icmp ne i64 %r4305, 0
  br i1 %r4306, label %plen.elem.length.785, label %plen.ic.shape.770

plen.elem.length.785:                             ; preds = %plen.elem.store.784
  %r4307 = inttoptr i64 %r4305 to ptr
  %r4308 = load i32, ptr %r4307, align 4
  %r4309 = uitofp i32 %r4308 to double
  br label %plen.ic.merge.782

shadow.root.barrier.786:                          ; preds = %plen.merge.768
  call void @js_write_barrier_root_nanbox(i64 %r4365) #7
  br label %shadow.root.barrier.done.787

shadow.root.barrier.done.787:                     ; preds = %shadow.root.barrier.786, %plen.merge.768
  %r4368.rs4i = ptrtoint ptr addrspace(1) %r1053.1.relocated1213 to i64
  %r4368.rs4o = call i64 asm "", "=r,0"(i64 %r4368.rs4i) #7
  %r4368 = bitcast i64 %r4368.rs4o to double
  %r4369.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s57 to i64
  %r4369 = call i64 asm "", "=r,0"(i64 %r4369.rs4i) #7
  %statepoint_token1217 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4369, double %r4368, i32 0, i32 0)
  %r43701218 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1217)
  %rs4gc.s58 = inttoptr i64 %r43701218 to ptr addrspace(1)
  %r4371.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s58 to i64
  %r4371 = call i64 asm "", "=r,0"(i64 %r4371.rs4i) #7
  %r4372 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4373 = icmp ne i32 %r4372, 0
  br i1 %r4373, label %shadow.root.barrier.788, label %shadow.root.barrier.done.789

shadow.root.barrier.788:                          ; preds = %shadow.root.barrier.done.787
  call void @js_write_barrier_root_nanbox(i64 %r4371) #7
  br label %shadow.root.barrier.done.789

shadow.root.barrier.done.789:                     ; preds = %shadow.root.barrier.788, %shadow.root.barrier.done.787
  %r4374.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s58 to i64
  %r4374 = call i64 asm "", "=r,0"(i64 %r4374.rs4i) #7
  %statepoint_token1219 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r4374, i32 0, i32 0)
  %statepoint_token1220 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token1221 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token1222 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token1223 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token1224 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.790

event_loop.header.790:                            ; preds = %event_loop.body_wait.795, %event_loop.body_check.794, %shadow.root.barrier.done.789
  %statepoint_token1225 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_event_loop_host_driven, i32 0, i32 0, i32 0, i32 0)
  %r43791226 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token1225)
  %r4380 = icmp ne i32 %r43791226, 0
  br i1 %r4380, label %event_loop.host_return.792, label %event_loop.check_pending.791

event_loop.check_pending.791:                     ; preds = %event_loop.header.790
  %statepoint_token1227 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r43811228 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token1227)
  %statepoint_token1229 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r43821230 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token1229)
  %statepoint_token1231 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r43831232 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token1231)
  %statepoint_token1233 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r43841234 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token1233)
  %statepoint_token1235 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r43851236 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token1235)
  %statepoint_token1237 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r43861238 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token1237)
  %r4387 = or i32 %r43811228, %r43821230
  %r4388 = or i32 %r43831232, %r43841234
  %r4389 = or i32 %r4388, %r43851236
  %r4390 = or i32 %r4387, %r4389
  %r4391 = or i32 %r4390, 0
  %r4392 = or i32 %r4391, %r43861238
  %r4393 = icmp ne i32 %r4392, 0
  br i1 %r4393, label %event_loop.body.793, label %event_loop.exit.796

event_loop.host_return.792:                       ; preds = %event_loop.header.790
  call void @js_typed_feedback_maybe_dump_trace() #7
  ret i32 0

event_loop.body.793:                              ; preds = %event_loop.check_pending.791
  %statepoint_token1239 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token1240 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.body_check.794

event_loop.body_check.794:                        ; preds = %event_loop.body.793
  %statepoint_token1241 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r43951242 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token1241)
  %statepoint_token1243 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r43961244 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token1243)
  %statepoint_token1245 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r43971246 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token1245)
  %statepoint_token1247 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r43981248 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token1247)
  %statepoint_token1249 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r43991250 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token1249)
  %statepoint_token1251 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r44001252 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token1251)
  %r4401 = or i32 %r43951242, %r43961244
  %r4402 = or i32 %r43971246, %r43981248
  %r4403 = or i32 %r4402, %r43991250
  %r4404 = or i32 %r4401, %r4403
  %r4405 = or i32 %r4404, 0
  %r4406 = or i32 %r4405, %r44001252
  %r4407 = icmp ne i32 %r4406, 0
  br i1 %r4407, label %event_loop.body_wait.795, label %event_loop.header.790

event_loop.body_wait.795:                         ; preds = %event_loop.body_check.794
  %statepoint_token1253 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_wait_for_event, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.790

event_loop.exit.796:                              ; preds = %event_loop.check_pending.791
  %statepoint_token1254 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_emit_before_exit_pending, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token1255 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token1256 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_exit_sequence, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token1257 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_finalization_exit, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token1258 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_promise_jobs, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token1259 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_trace_events_flush_output, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token1260 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_promise_report_unhandled_rejections, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token1261 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_release_current_thread_collection_side_allocations, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token1262 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_process_pending_exit_code, i32 0, i32 0, i32 0, i32 0)
  %r44101263 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token1262)
  call void @js_typed_feedback_maybe_dump_trace() #7
  ret i32 %r44101263
}

; Function Attrs: optsize
define void @__perry_init_strings_test_json_source_token_length_ts_chunk0() #6 {
entry.0:
  %r1 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.0.bytes, i32 11)
  %r2 = call double @js_nanbox_string(i64 %r1)
  store double %r2, ptr @test_json_source_token_length_ts_.str.0.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.0.handle to i64))
  %r4 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.1.bytes, i32 12)
  %r5 = call double @js_nanbox_string(i64 %r4)
  store double %r5, ptr @test_json_source_token_length_ts_.str.1.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.1.handle to i64))
  %r7 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.2.bytes, i32 12)
  %r8 = call double @js_nanbox_string(i64 %r7)
  store double %r8, ptr @test_json_source_token_length_ts_.str.2.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.2.handle to i64))
  %r10 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.3.bytes, i32 6)
  %r11 = call double @js_nanbox_string(i64 %r10)
  store double %r11, ptr @test_json_source_token_length_ts_.str.3.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.3.handle to i64))
  %r13 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.4.bytes, i32 9)
  %r14 = call double @js_nanbox_string(i64 %r13)
  store double %r14, ptr @test_json_source_token_length_ts_.str.4.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.4.handle to i64))
  %r16 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.5.bytes, i32 2)
  %r17 = call double @js_nanbox_string(i64 %r16)
  store double %r17, ptr @test_json_source_token_length_ts_.str.5.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.5.handle to i64))
  %r19 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.6.bytes, i32 6)
  %r20 = call double @js_nanbox_string(i64 %r19)
  store double %r20, ptr @test_json_source_token_length_ts_.str.6.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.6.handle to i64))
  %r22 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.7.bytes, i32 16)
  %r23 = call double @js_nanbox_string(i64 %r22)
  store double %r23, ptr @test_json_source_token_length_ts_.str.7.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.7.handle to i64))
  %r25 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.8.bytes, i32 5)
  %r26 = call double @js_nanbox_string(i64 %r25)
  store double %r26, ptr @test_json_source_token_length_ts_.str.8.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.8.handle to i64))
  %r28 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.9.bytes, i32 1)
  %r29 = call double @js_nanbox_string(i64 %r28)
  store double %r29, ptr @test_json_source_token_length_ts_.str.9.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.9.handle to i64))
  %r31 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.10.bytes, i32 4)
  %r32 = call double @js_nanbox_string(i64 %r31)
  store double %r32, ptr @test_json_source_token_length_ts_.str.10.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.10.handle to i64))
  %r34 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.11.bytes, i32 20)
  %r35 = call double @js_nanbox_string(i64 %r34)
  store double %r35, ptr @test_json_source_token_length_ts_.str.11.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.11.handle to i64))
  %r37 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.12.bytes, i32 6)
  %r38 = call double @js_nanbox_string(i64 %r37)
  store double %r38, ptr @test_json_source_token_length_ts_.str.12.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.12.handle to i64))
  %r40 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.13.bytes, i32 32)
  %r41 = call double @js_nanbox_string(i64 %r40)
  store double %r41, ptr @test_json_source_token_length_ts_.str.13.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.13.handle to i64))
  %r43 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.14.bytes, i32 2)
  %r44 = call double @js_nanbox_string(i64 %r43)
  store double %r44, ptr @test_json_source_token_length_ts_.str.14.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.14.handle to i64))
  %r46 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.15.bytes, i32 13)
  %r47 = call double @js_nanbox_string(i64 %r46)
  store double %r47, ptr @test_json_source_token_length_ts_.str.15.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.15.handle to i64))
  %r49 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.16.bytes, i32 23)
  %r50 = call double @js_nanbox_string(i64 %r49)
  store double %r50, ptr @test_json_source_token_length_ts_.str.16.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.16.handle to i64))
  %r52 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.17.bytes, i32 23)
  %r53 = call double @js_nanbox_string(i64 %r52)
  store double %r53, ptr @test_json_source_token_length_ts_.str.17.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.17.handle to i64))
  %r55 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.18.bytes, i32 6)
  %r56 = call double @js_nanbox_string(i64 %r55)
  store double %r56, ptr @test_json_source_token_length_ts_.str.18.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.18.handle to i64))
  %r58 = call i64 @js_string_from_bytes(ptr @test_json_source_token_length_ts_.str.19.bytes, i32 8)
  %r59 = call double @js_nanbox_string(i64 %r58)
  store double %r59, ptr @test_json_source_token_length_ts_.str.19.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_source_token_length_ts_.str.19.handle to i64))
  ret void
}

; Function Attrs: optsize
define void @__perry_init_strings_test_json_source_token_length_ts() #6 {
entry.0:
  call void @__perry_init_strings_test_json_source_token_length_ts_chunk0()
  ret void
}

declare void @__tmp_use(...)

attributes #0 = { nounwind willreturn }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { optsize "frame-pointer"="non-leaf" }
attributes #7 = { "gc-leaf-function" }

!0 = !{}
