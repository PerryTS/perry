
benchmarks/json_performance/.work/source-length-hint-r27/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001006c66d0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len>:
1006c66d0:     	stp	x26, x25, [sp, #-0x50]!
1006c66d4:     	stp	x24, x23, [sp, #0x10]
1006c66d8:     	stp	x22, x21, [sp, #0x20]
1006c66dc:     	stp	x20, x19, [sp, #0x30]
1006c66e0:     	stp	x29, x30, [sp, #0x40]
1006c66e4:     	add	x29, sp, #0x40
1006c66e8:     	subs	x21, x1, x4
1006c66ec:     	ccmp	x2, #0x0, #0x4, hs
1006c66f0:     	b.eq	0x1006c6748 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x78>
1006c66f4:     	cmp	x21, #0x100
1006c66f8:     	b.hi	0x1006c6748 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x78>
1006c66fc:     	adds	x8, x3, #0x1
1006c6700:     	b.hs	0x1006c6748 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x78>
1006c6704:     	add	x22, x8, x4
1006c6708:     	subs	x20, x1, x22
1006c670c:     	ccmp	x22, x8, #0x0, hi
1006c6710:     	b.lo	0x1006c6748 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x78>
1006c6714:     	cmp	x3, x1
1006c6718:     	b.hs	0x1006c67f0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x120>
1006c671c:     	ldrb	w9, [x0, x3]
1006c6720:     	cmp	w9, #0x22
1006c6724:     	b.ne	0x1006c6748 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x78>
1006c6728:     	ldrb	w9, [x0, x22]
1006c672c:     	cmp	w9, #0x22
1006c6730:     	b.ne	0x1006c6748 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x78>
1006c6734:     	ldr	w9, [x2, #0x4]
1006c6738:     	add	x10, x2, #0x14
1006c673c:     	cmp	x10, x0
1006c6740:     	ccmp	x1, x9, #0x0, eq
1006c6744:     	b.eq	0x1006c6764 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x94>
1006c6748:     	mov	w0, #0x0                ; =0
1006c674c:     	ldp	x29, x30, [sp, #0x40]
1006c6750:     	ldp	x20, x19, [sp, #0x30]
1006c6754:     	ldp	x22, x21, [sp, #0x20]
1006c6758:     	ldp	x24, x23, [sp, #0x10]
1006c675c:     	ldp	x26, x25, [sp], #0x50
1006c6760:     	ret
1006c6764:     	mov	x25, x4
1006c6768:     	mov	x26, x3
1006c676c:     	mov	x23, x2
1006c6770:     	mov	x19, x1
1006c6774:     	mov	x24, x0
1006c6778:     	mov	x1, x8
1006c677c:     	bl	0x10077fd58 <__RNvNvNtNtCsjgY6bXVaRmE_4core5slice5ascii8is_ascii7runtime>
1006c6780:     	cbz	w0, 0x1006c674c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x7c>
1006c6784:     	add	x0, x24, x22
1006c6788:     	mov	x1, x20
1006c678c:     	bl	0x10077fd58 <__RNvNvNtNtCsjgY6bXVaRmE_4core5slice5ascii8is_ascii7runtime>
1006c6790:     	cbz	w0, 0x1006c674c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x7c>
1006c6794:     	add	x0, x25, x26
1006c6798:     	cmp	x0, x19
1006c679c:     	b.hs	0x1006c6800 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x130>
1006c67a0:     	ldrb	w9, [x24, x0]
1006c67a4:     	cmp	w9, #0xbf
1006c67a8:     	b.hi	0x1006c6748 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x78>
1006c67ac:     	mov	x8, x19
1006c67b0:     	sub	x0, x22, #0x2
1006c67b4:     	cmp	x0, x19
1006c67b8:     	b.hs	0x1006c6800 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x130>
1006c67bc:     	ldrb	w9, [x24, x0]
1006c67c0:     	cmp	w9, #0xdf
1006c67c4:     	b.hi	0x1006c6748 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x78>
1006c67c8:     	sub	x0, x22, #0x3
1006c67cc:     	cmp	x0, x8
1006c67d0:     	b.hs	0x1006c6800 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x130>
1006c67d4:     	ldrb	w8, [x24, x0]
1006c67d8:     	cmp	w8, #0xef
1006c67dc:     	b.hi	0x1006c6748 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x78>
1006c67e0:     	ldr	w8, [x23]
1006c67e4:     	subs	w1, w8, w21
1006c67e8:     	cset	w0, hs
1006c67ec:     	b	0x1006c674c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x7c>
1006c67f0:     	adrp	x2, 0x100f1c000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots10stack_maps17LAST_REWRITE_WALK+0x6470>
1006c67f4:     	add	x2, x2, #0x648
1006c67f8:     	mov	x0, x3
1006c67fc:     	bl	0x100b12d0c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
1006c6800:     	adrp	x2, 0x100f1c000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots10stack_maps17LAST_REWRITE_WALK+0x6470>
1006c6804:     	add	x2, x2, #0x660
1006c6808:     	mov	x1, x19
1006c680c:     	bl	0x100b12d0c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
