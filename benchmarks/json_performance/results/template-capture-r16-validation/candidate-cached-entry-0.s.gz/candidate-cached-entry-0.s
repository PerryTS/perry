
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/template-capture-r16/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001004eb1dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template>:
1004eb1dc:     	stp	x28, x27, [sp, #-0x60]!
1004eb1e0:     	stp	x26, x25, [sp, #0x10]
1004eb1e4:     	stp	x24, x23, [sp, #0x20]
1004eb1e8:     	stp	x22, x21, [sp, #0x30]
1004eb1ec:     	stp	x20, x19, [sp, #0x40]
1004eb1f0:     	stp	x29, x30, [sp, #0x50]
1004eb1f4:     	add	x29, sp, #0x50
1004eb1f8:     	sub	sp, sp, #0x330
1004eb1fc:     	sub	x8, x1, #0x801
1004eb200:     	cmn	x8, #0x7c0
1004eb204:     	b.lo	0x1004eb308 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x12c>
1004eb208:     	adrp	x19, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1004eb20c:     	ldr	w20, [x19, #0x578]
1004eb210:     	adrp	x23, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eb214:     	cmp	w20, #0x300
1004eb218:     	b.hs	0x1004eb354 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x178>
1004eb21c:     	ldr	x8, [x23, #0x48]
1004eb220:     	cmn	x8, #0x1
1004eb224:     	b.eq	0x1004eb330 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x154>
1004eb228:     	mrs	x9, TPIDRRO_EL0
1004eb22c:     	and	x9, x9, #0xfffffffffffffff8
1004eb230:     	ldr	x8, [x9, x8, lsl #3]
1004eb234:     	cbz	x8, 0x1004eb330 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x154>
1004eb238:     	add	x8, x8, x20, lsl #3
1004eb23c:     	ldr	x8, [x8, #0x1e8]
1004eb240:     	cbz	x8, 0x1004eb354 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x178>
1004eb244:     	ldr	x9, [x8]
1004eb248:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1004eb24c:     	cmp	x9, x10
1004eb250:     	b.hs	0x1004eb388 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x1ac>
1004eb254:     	ldrb	w9, [x8, #0x8]
1004eb258:     	cmp	w9, #0x2
1004eb25c:     	b.eq	0x1004eb308 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x12c>
1004eb260:     	ldr	x9, [x8, #0x248]
1004eb264:     	cmp	x9, x0
1004eb268:     	b.ne	0x1004eb308 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x12c>
1004eb26c:     	ldrh	w8, [x8, #0x25c]
1004eb270:     	cmp	x1, x8
1004eb274:     	b.ne	0x1004eb308 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x12c>
1004eb278:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eb27c:     	ldr	w20, [x8, #0x948]
1004eb280:     	cmp	w20, #0x300
1004eb284:     	b.hs	0x1004eb6cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4f0>
1004eb288:     	ldr	x8, [x23, #0x48]
1004eb28c:     	cmn	x8, #0x1
1004eb290:     	b.eq	0x1004eb6bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4e0>
1004eb294:     	mrs	x9, TPIDRRO_EL0
1004eb298:     	and	x9, x9, #0xfffffffffffffff8
1004eb29c:     	ldr	x0, [x9, x8, lsl #3]
1004eb2a0:     	cbz	x0, 0x1004eb6bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4e0>
1004eb2a4:     	add	x8, x0, x20, lsl #3
1004eb2a8:     	ldr	x0, [x8, #0x1e8]
1004eb2ac:     	cbz	x0, 0x1004eb6cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4f0>
1004eb2b0:     	ldrb	w8, [x0]
1004eb2b4:     	cbnz	w8, 0x1004eb6e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x504>
1004eb2b8:     	ldr	w19, [x19, #0x578]
1004eb2bc:     	cmp	w19, #0x300
1004eb2c0:     	b.hs	0x1004eb704 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x528>
1004eb2c4:     	ldr	x8, [x23, #0x48]
1004eb2c8:     	cmn	x8, #0x1
1004eb2cc:     	b.eq	0x1004eb6f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x518>
1004eb2d0:     	mrs	x9, TPIDRRO_EL0
1004eb2d4:     	and	x9, x9, #0xfffffffffffffff8
1004eb2d8:     	ldr	x0, [x9, x8, lsl #3]
1004eb2dc:     	cbz	x0, 0x1004eb6f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x518>
1004eb2e0:     	add	x8, x0, x19, lsl #3
1004eb2e4:     	ldr	x22, [x8, #0x1e8]
1004eb2e8:     	cbz	x22, 0x1004eb704 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x528>
1004eb2ec:     	ldr	x8, [x22]
1004eb2f0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1004eb2f4:     	cmp	x8, x9
1004eb2f8:     	b.hs	0x1004eb724 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x548>
1004eb2fc:     	ldrb	w20, [x22, #0x8]
1004eb300:     	cmp	w20, #0x2
1004eb304:     	b.ne	0x1004eb394 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x1b8>
1004eb308:     	mov	x0, #0x0                ; =0
1004eb30c:     	mov	x1, x19
1004eb310:     	add	sp, sp, #0x330
1004eb314:     	ldp	x29, x30, [sp, #0x50]
1004eb318:     	ldp	x20, x19, [sp, #0x40]
1004eb31c:     	ldp	x22, x21, [sp, #0x30]
1004eb320:     	ldp	x24, x23, [sp, #0x20]
1004eb324:     	ldp	x26, x25, [sp, #0x10]
1004eb328:     	ldp	x28, x27, [sp], #0x60
1004eb32c:     	ret
1004eb330:     	mov	x22, x1
1004eb334:     	mov	x21, x0
1004eb338:     	bl	0x100b3d17c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb33c:     	mov	x1, x22
1004eb340:     	mov	x8, x0
1004eb344:     	mov	x0, x21
1004eb348:     	add	x8, x8, x20, lsl #3
1004eb34c:     	ldr	x8, [x8, #0x1e8]
1004eb350:     	cbnz	x8, 0x1004eb244 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x68>
1004eb354:     	adrp	x8, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1004eb358:     	add	x8, x8, #0xfb8
1004eb35c:     	mov	x20, x0
1004eb360:     	mov	x0, x8
1004eb364:     	mov	x21, x1
1004eb368:     	bl	0x100b3a99c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1004eb36c:     	mov	x1, x21
1004eb370:     	mov	x8, x0
1004eb374:     	mov	x0, x20
1004eb378:     	ldr	x9, [x8]
1004eb37c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1004eb380:     	cmp	x9, x10
1004eb384:     	b.lo	0x1004eb254 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x78>
1004eb388:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004eb38c:     	add	x0, x0, #0xd40
1004eb390:     	bl	0x100b104dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1004eb394:     	add	x19, sp, #0x20
1004eb398:     	orr	x0, x19, #0x1
1004eb39c:     	add	x1, x22, #0x9
1004eb3a0:     	mov	w2, #0x247              ; =583
1004eb3a4:     	bl	0x100b5fbac <_writev+0x100b5fbac>
1004eb3a8:     	ldr	x10, [x22, #0x250]
1004eb3ac:     	ldr	w11, [x22, #0x258]
1004eb3b0:     	ldrh	w8, [x22, #0x25c]
1004eb3b4:     	ldrb	w21, [x22, #0x25e]
1004eb3b8:     	ldrb	w9, [x22, #0x25f]
1004eb3bc:     	strb	w20, [sp, #0x20]
1004eb3c0:     	str	x10, [sp, #0x8]
1004eb3c4:     	str	x10, [sp, #0x268]
1004eb3c8:     	str	w11, [sp, #0x4]
1004eb3cc:     	str	w11, [sp, #0x270]
1004eb3d0:     	strh	w8, [sp, #0x274]
1004eb3d4:     	strb	w21, [sp, #0x276]
1004eb3d8:     	strb	w9, [sp, #0x277]
1004eb3dc:     	bl	0x10027f544 <__RNvMs7_NtNtCs3gRpqoBkMHm_13perry_runtime2gc6policyNtB5_15GcSuppressScope3new>
1004eb3e0:     	str	w0, [sp]
1004eb3e4:     	add	x0, sp, #0x278
1004eb3e8:     	bl	0x100235bf8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime5arena12constructionNtB2_17ConstructionBatch3new>
1004eb3ec:     	adrp	x1, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x70f0>
1004eb3f0:     	add	x1, x1, #0x9f0
1004eb3f4:     	sub	x0, x29, #0xf0
1004eb3f8:     	mov	w2, #0x40               ; =64
1004eb3fc:     	bl	0x100b5fbd0 <_writev+0x100b5fbd0>
1004eb400:     	cmp	w21, #0x9
1004eb404:     	b.hs	0x1004eb7bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5e0>
1004eb408:     	str	x21, [sp, #0x10]
1004eb40c:     	cbz	w21, 0x1004eb5c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3e8>
1004eb410:     	mov	x27, #0x0               ; =0
1004eb414:     	mov	w8, #0x48               ; =72
1004eb418:     	ldr	x9, [sp, #0x10]
1004eb41c:     	umaddl	x28, w9, w8, x19
1004eb420:     	add	x8, sp, #0x20
1004eb424:     	ldr	x9, [sp, #0x278]
1004eb428:     	str	x9, [sp, #0x18]
1004eb42c:     	mov	x22, #0x7ffd000000000000 ; =9222527611924643840
1004eb430:     	mov	x20, #-0x3000000000000  ; =-844424930131968
1004eb434:     	mov	x21, #0x7fff000000000000 ; =9223090561878065152
1004eb438:     	mov	x19, #0x7ff9000000000000 ; =9221401712017801216
1004eb43c:     	sub	x23, x29, #0xf0
1004eb440:     	mov	x26, x8
1004eb444:     	b	0x1004eb460 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x284>
1004eb448:     	ldr	x8, [x8, #0x8]
1004eb44c:     	str	x8, [x23, x27, lsl #3]
1004eb450:     	add	x27, x27, #0x1
1004eb454:     	mov	x8, x26
1004eb458:     	cmp	x26, x28
1004eb45c:     	b.eq	0x1004eb5c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3e8>
1004eb460:     	ldrb	w9, [x26], #0x48
1004eb464:     	tbz	w9, #0x0, 0x1004eb448 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x26c>
1004eb468:     	ldur	q0, [x8, #0x8]
1004eb46c:     	ldur	q1, [x8, #0x18]
1004eb470:     	stp	q0, q1, [x29, #-0xb0]
1004eb474:     	ldur	q0, [x8, #0x28]
1004eb478:     	ldur	q1, [x8, #0x38]
1004eb47c:     	stp	q0, q1, [x29, #-0x90]
1004eb480:     	ldrb	w25, [x8, #0x1]
1004eb484:     	sub	x0, x29, #0x68
1004eb488:     	add	x1, sp, #0x278
1004eb48c:     	mov	x2, x25
1004eb490:     	bl	0x100233650 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray3new>
1004eb494:     	cmp	w25, #0x9
1004eb498:     	b.hs	0x1004eb7a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5c8>
1004eb49c:     	ldur	x24, [x29, #-0x68]
1004eb4a0:     	cbz	w25, 0x1004eb59c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3c0>
1004eb4a4:     	lsl	x25, x25, #3
1004eb4a8:     	sub	x23, x29, #0xb0
1004eb4ac:     	b	0x1004eb504 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x328>
1004eb4b0:     	add	x9, x24, w8, uxtw #3
1004eb4b4:     	str	x2, [x9, #0x8]
1004eb4b8:     	and	x9, x2, x20
1004eb4bc:     	cmp	x9, x22
1004eb4c0:     	cset	w9, eq
1004eb4c4:     	ldurb	w10, [x29, #-0x5f]
1004eb4c8:     	orr	w9, w10, w9
1004eb4cc:     	sturb	w9, [x29, #-0x5f]
1004eb4d0:     	ldurb	w9, [x29, #-0x5e]
1004eb4d4:     	csel	w9, w9, wzr, eq
1004eb4d8:     	sturb	w9, [x29, #-0x5e]
1004eb4dc:     	and	x9, x2, #0xffff000000000000
1004eb4e0:     	cmp	x9, x21
1004eb4e4:     	ccmp	x2, x19, #0x0, ls
1004eb4e8:     	ldurb	w9, [x29, #-0x5d]
1004eb4ec:     	csel	w9, w9, wzr, lo
1004eb4f0:     	sturb	w9, [x29, #-0x5d]
1004eb4f4:     	add	w8, w8, #0x1
1004eb4f8:     	str	w8, [x24]
1004eb4fc:     	subs	x25, x25, #0x8
1004eb500:     	b.eq	0x1004eb594 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3b8>
1004eb504:     	ldr	x2, [x23], #0x8
1004eb508:     	ldp	w8, w9, [x24]
1004eb50c:     	cmp	w8, w9
1004eb510:     	b.eq	0x1004eb56c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x390>
1004eb514:     	ldurb	w9, [x29, #-0x60]
1004eb518:     	tbnz	w9, #0x0, 0x1004eb4b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x2d4>
1004eb51c:     	ldr	w9, [x24, #0x4]
1004eb520:     	cmp	w8, w9
1004eb524:     	b.hs	0x1004eb54c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x370>
1004eb528:     	mov	w1, w8
1004eb52c:     	mov	x0, x24
1004eb530:     	bl	0x10052706c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array15header_gc_slots27note_array_slot_layout_only>
1004eb534:     	ldr	w8, [x24]
1004eb538:     	add	w8, w8, #0x1
1004eb53c:     	str	w8, [x24]
1004eb540:     	subs	x25, x25, #0x8
1004eb544:     	b.ne	0x1004eb504 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x328>
1004eb548:     	b	0x1004eb594 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3b8>
1004eb54c:     	fmov	d0, x2
1004eb550:     	mov	x0, x24
1004eb554:     	bl	0x1007c83e8 <_js_array_push_f64>
1004eb558:     	mov	x24, x0
1004eb55c:     	stur	x0, [x29, #-0x68]
1004eb560:     	subs	x25, x25, #0x8
1004eb564:     	b.ne	0x1004eb504 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x328>
1004eb568:     	b	0x1004eb594 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3b8>
1004eb56c:     	sub	x0, x29, #0x68
1004eb570:     	add	x1, sp, #0x278
1004eb574:     	mov	x24, x2
1004eb578:     	bl	0x100b3880c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray4grow>
1004eb57c:     	mov	x2, x24
1004eb580:     	ldur	x24, [x29, #-0x68]
1004eb584:     	ldr	w8, [x24]
1004eb588:     	ldurb	w9, [x29, #-0x60]
1004eb58c:     	tbnz	w9, #0x0, 0x1004eb4b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x2d4>
1004eb590:     	b	0x1004eb51c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x340>
1004eb594:     	ldur	x24, [x29, #-0x68]
1004eb598:     	sub	x23, x29, #0xf0
1004eb59c:     	sub	x0, x29, #0x68
1004eb5a0:     	ldr	x1, [sp, #0x18]
1004eb5a4:     	bl	0x10023348c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray13finish_layout>
1004eb5a8:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1004eb5ac:     	bfxil	x8, x24, #0, #48
1004eb5b0:     	str	x8, [x23, x27, lsl #3]
1004eb5b4:     	add	x27, x27, #0x1
1004eb5b8:     	mov	x8, x26
1004eb5bc:     	cmp	x26, x28
1004eb5c0:     	b.ne	0x1004eb460 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x284>
1004eb5c4:     	add	x0, sp, #0x278
1004eb5c8:     	sub	x3, x29, #0xf0
1004eb5cc:     	ldp	x1, x4, [sp, #0x8]
1004eb5d0:     	ldr	w2, [sp, #0x4]
1004eb5d4:     	bl	0x1005ba388 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
1004eb5d8:     	adrp	x21, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eb5dc:     	ldr	w8, [sp]
1004eb5e0:     	tbz	w8, #0x0, 0x1004eb648 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x46c>
1004eb5e4:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
1004eb5e8:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1004eb5ec:     	ldr	x8, [x8, #0x758]
1004eb5f0:     	cbnz	x8, 0x1004eb69c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4c0>
1004eb5f4:     	bfxil	x19, x0, #0, #48
1004eb5f8:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eb5fc:     	ldr	w20, [x8, #0x930]
1004eb600:     	cmp	w20, #0x300
1004eb604:     	b.hs	0x1004eb740 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x564>
1004eb608:     	ldr	x8, [x21, #0x48]
1004eb60c:     	cmn	x8, #0x1
1004eb610:     	b.eq	0x1004eb730 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x554>
1004eb614:     	mrs	x9, TPIDRRO_EL0
1004eb618:     	and	x9, x9, #0xfffffffffffffff8
1004eb61c:     	ldr	x0, [x9, x8, lsl #3]
1004eb620:     	cbz	x0, 0x1004eb730 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x554>
1004eb624:     	add	x8, x0, x20, lsl #3
1004eb628:     	ldr	x0, [x8, #0x1e8]
1004eb62c:     	cbz	x0, 0x1004eb740 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x564>
1004eb630:     	ldrb	w8, [x0]
1004eb634:     	cbz	w8, 0x1004eb754 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x578>
1004eb638:     	sub	w8, w8, #0x1
1004eb63c:     	strb	w8, [x0]
1004eb640:     	mov	w0, #0x1                ; =1
1004eb644:     	b	0x1004eb30c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x130>
1004eb648:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1004eb64c:     	ldr	w19, [x8, #0x308]
1004eb650:     	cmp	w19, #0x300
1004eb654:     	b.hs	0x1004eb784 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5a8>
1004eb658:     	ldr	x8, [x21, #0x48]
1004eb65c:     	cmn	x8, #0x1
1004eb660:     	b.eq	0x1004eb768 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x58c>
1004eb664:     	mrs	x9, TPIDRRO_EL0
1004eb668:     	and	x9, x9, #0xfffffffffffffff8
1004eb66c:     	ldr	x8, [x9, x8, lsl #3]
1004eb670:     	cbz	x8, 0x1004eb768 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x58c>
1004eb674:     	add	x8, x8, x19, lsl #3
1004eb678:     	ldr	x8, [x8, #0x1e8]
1004eb67c:     	cbz	x8, 0x1004eb784 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5a8>
1004eb680:     	ldrb	w9, [x8]
1004eb684:     	and	w9, w9, #0xfffffffd
1004eb688:     	strb	w9, [x8]
1004eb68c:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
1004eb690:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1004eb694:     	ldr	x8, [x8, #0x758]
1004eb698:     	cbz	x8, 0x1004eb5f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x418>
1004eb69c:     	mov	x20, x0
1004eb6a0:     	bl	0x100b4383c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
1004eb6a4:     	bfxil	x19, x20, #0, #48
1004eb6a8:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eb6ac:     	ldr	w20, [x8, #0x930]
1004eb6b0:     	cmp	w20, #0x300
1004eb6b4:     	b.lo	0x1004eb608 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x42c>
1004eb6b8:     	b	0x1004eb740 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x564>
1004eb6bc:     	bl	0x100b3d17c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb6c0:     	add	x8, x0, x20, lsl #3
1004eb6c4:     	ldr	x0, [x8, #0x1e8]
1004eb6c8:     	cbnz	x0, 0x1004eb2b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0xd4>
1004eb6cc:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
1004eb6d0:     	add	x0, x0, #0xca8
1004eb6d4:     	bl	0x100b3a9e8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004eb6d8:     	ldrb	w8, [x0]
1004eb6dc:     	cbz	w8, 0x1004eb2b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0xdc>
1004eb6e0:     	bl	0x100b4211c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
1004eb6e4:     	ldr	w19, [x19, #0x578]
1004eb6e8:     	cmp	w19, #0x300
1004eb6ec:     	b.lo	0x1004eb2c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0xe8>
1004eb6f0:     	b	0x1004eb704 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x528>
1004eb6f4:     	bl	0x100b3d17c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb6f8:     	add	x8, x0, x19, lsl #3
1004eb6fc:     	ldr	x22, [x8, #0x1e8]
1004eb700:     	cbnz	x22, 0x1004eb2ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x110>
1004eb704:     	adrp	x0, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1004eb708:     	add	x0, x0, #0xfb8
1004eb70c:     	bl	0x100b3a99c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1004eb710:     	mov	x22, x0
1004eb714:     	ldr	x8, [x0]
1004eb718:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1004eb71c:     	cmp	x8, x9
1004eb720:     	b.lo	0x1004eb2fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x120>
1004eb724:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004eb728:     	add	x0, x0, #0xd58
1004eb72c:     	bl	0x100b104dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1004eb730:     	bl	0x100b3d17c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb734:     	add	x8, x0, x20, lsl #3
1004eb738:     	ldr	x0, [x8, #0x1e8]
1004eb73c:     	cbnz	x0, 0x1004eb630 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x454>
1004eb740:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
1004eb744:     	add	x0, x0, #0xc78
1004eb748:     	bl	0x100b3a9e8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004eb74c:     	ldrb	w8, [x0]
1004eb750:     	cbnz	w8, 0x1004eb638 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x45c>
1004eb754:     	mov	w8, #0x3f               ; =63
1004eb758:     	strb	w8, [x0]
1004eb75c:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
1004eb760:     	mov	w0, #0x1                ; =1
1004eb764:     	b	0x1004eb30c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x130>
1004eb768:     	mov	x20, x0
1004eb76c:     	bl	0x100b3d17c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb770:     	mov	x8, x0
1004eb774:     	mov	x0, x20
1004eb778:     	add	x8, x8, x19, lsl #3
1004eb77c:     	ldr	x8, [x8, #0x1e8]
1004eb780:     	cbnz	x8, 0x1004eb680 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4a4>
1004eb784:     	adrp	x8, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
1004eb788:     	add	x8, x8, #0xcd8
1004eb78c:     	mov	x19, x0
1004eb790:     	mov	x0, x8
1004eb794:     	bl	0x100b3a9e8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004eb798:     	mov	x8, x0
1004eb79c:     	mov	x0, x19
1004eb7a0:     	b	0x1004eb680 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4a4>
1004eb7a4:     	adrp	x3, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1004eb7a8:     	add	x3, x3, #0xfe8
1004eb7ac:     	mov	x0, #0x0                ; =0
1004eb7b0:     	mov	x1, x25
1004eb7b4:     	mov	w2, #0x8                ; =8
1004eb7b8:     	bl	0x100b107cc <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1004eb7bc:     	adrp	x3, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1004eb7c0:     	add	x3, x3, #0x0
1004eb7c4:     	mov	x0, #0x0                ; =0
1004eb7c8:     	mov	x1, x21
1004eb7cc:     	mov	w2, #0x8                ; =8
1004eb7d0:     	bl	0x100b107cc <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
