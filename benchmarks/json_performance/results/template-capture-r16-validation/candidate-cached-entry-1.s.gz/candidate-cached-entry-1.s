
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/template-capture-r16/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100503938 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>:
100503938:     	stp	x28, x27, [sp, #-0x60]!
10050393c:     	stp	x26, x25, [sp, #0x10]
100503940:     	stp	x24, x23, [sp, #0x20]
100503944:     	stp	x22, x21, [sp, #0x30]
100503948:     	stp	x20, x19, [sp, #0x40]
10050394c:     	stp	x29, x30, [sp, #0x50]
100503950:     	add	x29, sp, #0x50
100503954:     	sub	sp, sp, #0x1a0
100503958:     	mov	x19, x1
10050395c:     	mov	x21, x0
100503960:     	bl	0x1004eb1dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template>
100503964:     	cmp	x0, #0x1
100503968:     	b.ne	0x100503994 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5c>
10050396c:     	mov	x23, x1
100503970:     	mov	x0, x23
100503974:     	add	sp, sp, #0x1a0
100503978:     	ldp	x29, x30, [sp, #0x50]
10050397c:     	ldp	x20, x19, [sp, #0x40]
100503980:     	ldp	x22, x21, [sp, #0x30]
100503984:     	ldp	x24, x23, [sp, #0x20]
100503988:     	ldp	x26, x25, [sp, #0x10]
10050398c:     	ldp	x28, x27, [sp], #0x60
100503990:     	ret
100503994:     	add	x24, x21, #0x14
100503998:     	cmp	x19, #0x2
10050399c:     	b.ne	0x1005039b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7c>
1005039a0:     	ldrh	w8, [x24]
1005039a4:     	mov	w9, #0x7d7b             ; =32123
1005039a8:     	cmp	w8, w9
1005039ac:     	b.ne	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005039b0:     	b	0x100503a4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x114>
1005039b4:     	cmp	x19, #0x3
1005039b8:     	b.hs	0x100503a20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe8>
1005039bc:     	add	x0, sp, #0xa0
1005039c0:     	add	x1, x21, #0x14
1005039c4:     	mov	x2, x19
1005039c8:     	bl	0x1004f3c18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object6decode>
1005039cc:     	ldr	w8, [sp, #0xa0]
1005039d0:     	tbz	w8, #0x0, 0x100503b24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1ec>
1005039d4:     	add	x8, sp, #0xa0
1005039d8:     	ldr	x9, [sp, #0x128]
1005039dc:     	str	x9, [sp, #0x90]
1005039e0:     	ldur	q0, [x8, #0x48]
1005039e4:     	ldur	q1, [x8, #0x58]
1005039e8:     	stp	q0, q1, [sp, #0x50]
1005039ec:     	ldur	q0, [x8, #0x68]
1005039f0:     	ldur	q1, [x8, #0x78]
1005039f4:     	stp	q0, q1, [sp, #0x70]
1005039f8:     	ldur	q0, [x8, #0x8]
1005039fc:     	ldur	q1, [x8, #0x18]
100503a00:     	stp	q0, q1, [sp, #0x10]
100503a04:     	ldur	q0, [x8, #0x28]
100503a08:     	ldur	q1, [x8, #0x38]
100503a0c:     	stp	q0, q1, [sp, #0x30]
100503a10:     	add	x0, sp, #0x10
100503a14:     	bl	0x1004f43c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object8allocate>
100503a18:     	tbnz	w0, #0x0, 0x10050396c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x34>
100503a1c:     	b	0x100503b24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1ec>
100503a20:     	ldrb	w20, [x24]
100503a24:     	cmp	w20, #0x20
100503a28:     	b.hi	0x100503a6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x134>
100503a2c:     	mov	x8, #0x2600             ; =9728
100503a30:     	movk	x8, #0x1, lsl #32
100503a34:     	lsr	x8, x8, x20
100503a38:     	tbz	w8, #0x0, 0x100503a6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x134>
100503a3c:     	add	x0, x21, #0x14
100503a40:     	mov	x1, x19
100503a44:     	bl	0x1004ea3a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty19padded_empty_object>
100503a48:     	tbz	w0, #0x0, 0x100503a98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x160>
100503a4c:     	add	sp, sp, #0x1a0
100503a50:     	ldp	x29, x30, [sp, #0x50]
100503a54:     	ldp	x20, x19, [sp, #0x40]
100503a58:     	ldp	x22, x21, [sp, #0x30]
100503a5c:     	ldp	x24, x23, [sp, #0x20]
100503a60:     	ldp	x26, x25, [sp, #0x10]
100503a64:     	ldp	x28, x27, [sp], #0x60
100503a68:     	b	0x1004ea480 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100503a6c:     	cmp	w20, #0x7b
100503a70:     	b.ne	0x100503a98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x160>
100503a74:     	ldrb	w8, [x21, #0x15]
100503a78:     	cmp	w8, #0x20
100503a7c:     	b.hi	0x100503a90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x158>
100503a80:     	mov	x9, #0x2600             ; =9728
100503a84:     	movk	x9, #0x1, lsl #32
100503a88:     	lsr	x9, x9, x8
100503a8c:     	tbnz	w9, #0x0, 0x100503a3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104>
100503a90:     	cmp	w8, #0x7d
100503a94:     	b.eq	0x100503a3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104>
100503a98:     	cmp	x19, #0x41
100503a9c:     	b.hs	0x100503b24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1ec>
100503aa0:     	cmp	w20, #0x7b
100503aa4:     	ccmp	x19, #0x7, #0x0, eq
100503aa8:     	b.lo	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503aac:     	add	x8, x24, x19
100503ab0:     	ldurb	w8, [x8, #-0x1]
100503ab4:     	cmp	w8, #0x7d
100503ab8:     	b.ne	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503abc:     	ldrb	w8, [x21, #0x15]
100503ac0:     	cmp	w8, #0x22
100503ac4:     	b.ne	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503ac8:     	sub	x9, x19, #0x1
100503acc:     	mov	x22, x21
100503ad0:     	ldrb	w25, [x22, #0x16]!
100503ad4:     	cmp	w25, #0x22
100503ad8:     	b.ne	0x100503b68 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x230>
100503adc:     	mov	w23, #0x0               ; =0
100503ae0:     	mov	w28, #0x0               ; =0
100503ae4:     	mov	w27, #0x0               ; =0
100503ae8:     	mov	w26, #0x0               ; =0
100503aec:     	mov	x20, #0x0               ; =0
100503af0:     	cmp	w25, #0x22
100503af4:     	b.ne	0x100503b94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x25c>
100503af8:     	add	x8, sp, #0xa0
100503afc:     	mov	x0, x22
100503b00:     	mov	x1, x20
100503b04:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100503b08:     	sub	x11, x19, #0x1
100503b0c:     	ldr	w8, [sp, #0xa0]
100503b10:     	tbnz	w8, #0x0, 0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503b14:     	cmp	w25, #0x22
100503b18:     	b.ne	0x100503c38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x300>
100503b1c:     	mov	x8, #0x0                ; =0
100503b20:     	b	0x100503c6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100503b24:     	adrp	x8, 0x100f7d000 <__MergedGlobals+0xb8>
100503b28:     	add	x8, x8, #0x2d8
100503b2c:     	ldapr	x8, [x8]
100503b30:     	cbnz	x8, 0x100503d04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3cc>
100503b34:     	adrp	x8, 0x100f7d000 <__MergedGlobals+0xb8>
100503b38:     	ldrb	w8, [x8, #0x2e0]
100503b3c:     	adrp	x12, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100503b40:     	adrp	x27, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
100503b44:     	cbz	w8, 0x100503d1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3e4>
100503b48:     	cmp	w8, #0x1
100503b4c:     	b.ne	0x100503d58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x420>
100503b50:     	mov	w28, #0x1               ; =1
100503b54:     	mov	w8, #0x1000000          ; =16777216
100503b58:     	mov	w22, #0x1               ; =1
100503b5c:     	cmp	x19, x8
100503b60:     	b.hi	0x100503d5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x424>
100503b64:     	b	0x100503e40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x508>
100503b68:     	cmp	x9, #0x3
100503b6c:     	b.eq	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503b70:     	ldrb	w8, [x21, #0x17]
100503b74:     	cmp	w8, #0x22
100503b78:     	b.ne	0x100503c0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x2d4>
100503b7c:     	mov	w28, #0x0               ; =0
100503b80:     	mov	w27, #0x0               ; =0
100503b84:     	mov	w26, #0x0               ; =0
100503b88:     	mov	w23, #0x1               ; =1
100503b8c:     	mov	w20, #0x1               ; =1
100503b90:     	b	0x100503af0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100503b94:     	ldrb	w8, [x22]
100503b98:     	cmp	w8, #0x20
100503b9c:     	b.lo	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503ba0:     	cmp	w8, #0x5c
100503ba4:     	b.eq	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503ba8:     	tbnz	w23, #0x0, 0x100503af8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100503bac:     	ldrb	w8, [x21, #0x17]
100503bb0:     	cmp	w8, #0x20
100503bb4:     	b.lo	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503bb8:     	cmp	w8, #0x5c
100503bbc:     	b.eq	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503bc0:     	tbnz	w28, #0x0, 0x100503af8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100503bc4:     	ldrb	w8, [x21, #0x18]
100503bc8:     	cmp	w8, #0x20
100503bcc:     	b.lo	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503bd0:     	cmp	w8, #0x5c
100503bd4:     	b.eq	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503bd8:     	tbnz	w27, #0x0, 0x100503af8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100503bdc:     	ldrb	w8, [x21, #0x19]
100503be0:     	cmp	w8, #0x20
100503be4:     	b.lo	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503be8:     	cmp	w8, #0x5c
100503bec:     	b.eq	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503bf0:     	tbnz	w26, #0x0, 0x100503af8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100503bf4:     	ldrb	w8, [x21, #0x1a]
100503bf8:     	cmp	w8, #0x20
100503bfc:     	b.lo	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c00:     	cmp	w8, #0x5c
100503c04:     	b.ne	0x100503af8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100503c08:     	b	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c0c:     	cmp	x9, #0x4
100503c10:     	b.eq	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c14:     	ldrb	w8, [x21, #0x18]
100503c18:     	cmp	w8, #0x22
100503c1c:     	b.ne	0x100503cd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3a0>
100503c20:     	mov	w23, #0x0               ; =0
100503c24:     	mov	w27, #0x0               ; =0
100503c28:     	mov	w26, #0x0               ; =0
100503c2c:     	mov	w28, #0x1               ; =1
100503c30:     	mov	w20, #0x2               ; =2
100503c34:     	b	0x100503af0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100503c38:     	ldrb	w8, [x22]
100503c3c:     	tbnz	w23, #0x0, 0x100503c6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100503c40:     	ldrb	w9, [x21, #0x17]
100503c44:     	orr	x8, x8, x9, lsl #8
100503c48:     	tbnz	w28, #0x0, 0x100503c6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100503c4c:     	ldrb	w9, [x21, #0x18]
100503c50:     	orr	x8, x8, x9, lsl #16
100503c54:     	tbnz	w27, #0x0, 0x100503c6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100503c58:     	ldrb	w9, [x21, #0x19]
100503c5c:     	orr	x8, x8, x9, lsl #24
100503c60:     	tbnz	w26, #0x0, 0x100503c6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100503c64:     	ldrb	w9, [x21, #0x1a]
100503c68:     	orr	x8, x8, x9, lsl #32
100503c6c:     	add	x9, x20, #0x3
100503c70:     	cmp	x9, x19
100503c74:     	b.hs	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c78:     	ldrb	w9, [x24, x9]
100503c7c:     	cmp	w9, #0x3a
100503c80:     	b.ne	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c84:     	add	x10, x20, #0x4
100503c88:     	subs	x9, x11, x10
100503c8c:     	b.lo	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c90:     	b.eq	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c94:     	orr	x25, x8, x20, lsl #40
100503c98:     	mov	x26, #0x7ff9000000000000 ; =9221401712017801216
100503c9c:     	add	x8, x24, x10
100503ca0:     	mov	x10, #0x2600            ; =9728
100503ca4:     	movk	x10, #0x1, lsl #32
100503ca8:     	mov	x11, x9
100503cac:     	mov	x12, x8
100503cb0:     	b	0x100503cc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x388>
100503cb4:     	add	x12, x12, #0x1
100503cb8:     	subs	x11, x11, #0x1
100503cbc:     	b.eq	0x100504b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x122c>
100503cc0:     	ldrb	w13, [x12]
100503cc4:     	cmp	w13, #0x20
100503cc8:     	b.hi	0x100503cb4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x37c>
100503ccc:     	lsr	x13, x10, x13
100503cd0:     	tbz	w13, #0x0, 0x100503cb4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x37c>
100503cd4:     	b	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503cd8:     	cmp	x9, #0x5
100503cdc:     	b.eq	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503ce0:     	ldrb	w8, [x21, #0x19]
100503ce4:     	cmp	w8, #0x22
100503ce8:     	b.ne	0x100504ab0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1178>
100503cec:     	mov	w23, #0x0               ; =0
100503cf0:     	mov	w28, #0x0               ; =0
100503cf4:     	mov	w26, #0x0               ; =0
100503cf8:     	mov	w27, #0x1               ; =1
100503cfc:     	mov	w20, #0x3               ; =3
100503d00:     	b	0x100503af0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100503d04:     	bl	0x100b16b84 <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockNtNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api8TapeModeE10initializeNCINvB2_11get_or_initNCNvBV_18tape_mode_from_env0E0zEBZ_>
100503d08:     	adrp	x8, 0x100f7d000 <__MergedGlobals+0xb8>
100503d0c:     	ldrb	w8, [x8, #0x2e0]
100503d10:     	adrp	x12, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100503d14:     	adrp	x27, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
100503d18:     	cbnz	w8, 0x100503b48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x210>
100503d1c:     	sub	x8, x19, #0x400
100503d20:     	mov	w9, #0xfffc00           ; =16776192
100503d24:     	cmp	x8, x9
100503d28:     	b.hi	0x100503d58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x420>
100503d2c:     	mov	x8, #0x0                ; =0
100503d30:     	mov	x9, #0x2600             ; =9728
100503d34:     	movk	x9, #0x1, lsl #32
100503d38:     	ldrb	w10, [x24, x8]
100503d3c:     	cmp	w10, #0x20
100503d40:     	b.hi	0x100504238 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x900>
100503d44:     	lsr	x11, x9, x10
100503d48:     	tbz	w11, #0x0, 0x100504238 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x900>
100503d4c:     	add	x8, x8, #0x1
100503d50:     	cmp	x19, x8
100503d54:     	b.ne	0x100503d38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x400>
100503d58:     	mov	w22, #0x0               ; =0
100503d5c:     	ldr	w20, [x12, #0x560]
100503d60:     	cmp	w20, #0x300
100503d64:     	b.hs	0x100504210 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8d8>
100503d68:     	ldr	x8, [x27, #0x48]
100503d6c:     	cmn	x8, #0x1
100503d70:     	b.eq	0x100504200 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8c8>
100503d74:     	mrs	x9, TPIDRRO_EL0
100503d78:     	and	x9, x9, #0xfffffffffffffff8
100503d7c:     	ldr	x0, [x9, x8, lsl #3]
100503d80:     	cbz	x0, 0x100504200 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8c8>
100503d84:     	add	x8, x0, x20, lsl #3
100503d88:     	ldr	x0, [x8, #0x1e8]
100503d8c:     	cbz	x0, 0x100504210 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8d8>
100503d90:     	ldr	x8, [x0]
100503d94:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100503d98:     	cmp	x8, x9
100503d9c:     	b.hs	0x10050422c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8f4>
100503da0:     	ldrb	w8, [x0, #0x24]
100503da4:     	cmp	w8, #0x2
100503da8:     	b.eq	0x100503db8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x480>
100503dac:     	ldr	x9, [x0, #0x8]
100503db0:     	cmp	x9, x21
100503db4:     	b.eq	0x100503e20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4e8>
100503db8:     	cmp	x19, #0x3e9
100503dbc:     	b.lo	0x100503e3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100503dc0:     	mov	x8, #0x0                ; =0
100503dc4:     	mov	x9, #0x2600             ; =9728
100503dc8:     	movk	x9, #0x1, lsl #32
100503dcc:     	add	x10, x21, x8
100503dd0:     	ldrb	w10, [x10, #0x14]
100503dd4:     	cmp	w10, #0x20
100503dd8:     	b.hi	0x100503df4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4bc>
100503ddc:     	lsr	x11, x9, x10
100503de0:     	tbz	w11, #0x0, 0x100503df4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4bc>
100503de4:     	add	x8, x8, #0x1
100503de8:     	cmp	x19, x8
100503dec:     	b.ne	0x100503dcc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x494>
100503df0:     	b	0x100503e3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100503df4:     	cmp	w10, #0x5b
100503df8:     	b.eq	0x100503e04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4cc>
100503dfc:     	cmp	w10, #0x7b
100503e00:     	b.ne	0x100503e3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100503e04:     	add	x0, x21, #0x14
100503e08:     	mov	x1, x19
100503e0c:     	mov	w2, #0x3e8              ; =1000
100503e10:     	bl	0x1006c2854 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser12depth_blocks21nesting_depth_exceeds>
100503e14:     	cbz	w0, 0x100503e3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100503e18:     	mov	x0, x21
100503e1c:     	b	0x100504a70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1138>
100503e20:     	ldr	w9, [x0, #0x18]
100503e24:     	cmp	x19, x9
100503e28:     	cset	w9, eq
100503e2c:     	and	w8, w9, w8
100503e30:     	cmp	x19, #0x3e9
100503e34:     	csinc	w8, w8, wzr, hs
100503e38:     	tbz	w8, #0x0, 0x100503dc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x488>
100503e3c:     	mov	w28, #0x0               ; =0
100503e40:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100503e44:     	add	x0, x0, #0xce8
100503e48:     	ldr	x8, [x0]
100503e4c:     	blr	x8
100503e50:     	mov	x20, x0
100503e54:     	ldrb	w8, [x0, #0x20]
100503e58:     	cbnz	w8, 0x1005049c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1090>
100503e5c:     	ldr	x8, [x20]
100503e60:     	cbnz	x8, 0x100504a44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
100503e64:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
100503e68:     	bfxil	x23, x21, #0, #48
100503e6c:     	mov	x8, #-0x1               ; =-1
100503e70:     	str	x8, [x20]
100503e74:     	ldr	x21, [x20, #0x18]
100503e78:     	ldr	x8, [x20, #0x8]
100503e7c:     	cmp	x21, x8
100503e80:     	b.eq	0x1005041c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x88c>
100503e84:     	ldr	x8, [x20, #0x10]
100503e88:     	str	x23, [x8, x21, lsl #3]
100503e8c:     	add	x8, x21, #0x1
100503e90:     	str	x8, [x20, #0x18]
100503e94:     	ldr	x8, [x20]
100503e98:     	add	x8, x8, #0x1
100503e9c:     	str	x8, [x20]
100503ea0:     	adrp	x24, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
100503ea4:     	ldr	w23, [x24, #0x948]
100503ea8:     	cmp	w23, #0x300
100503eac:     	b.hs	0x1005041e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8a8>
100503eb0:     	ldr	x8, [x27, #0x48]
100503eb4:     	cmn	x8, #0x1
100503eb8:     	b.eq	0x1005041d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x898>
100503ebc:     	mrs	x9, TPIDRRO_EL0
100503ec0:     	and	x9, x9, #0xfffffffffffffff8
100503ec4:     	ldr	x0, [x9, x8, lsl #3]
100503ec8:     	cbz	x0, 0x1005041d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x898>
100503ecc:     	add	x8, x0, x23, lsl #3
100503ed0:     	ldr	x0, [x8, #0x1e8]
100503ed4:     	cbz	x0, 0x1005041e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8a8>
100503ed8:     	ldrb	w8, [x0]
100503edc:     	cbnz	w8, 0x1005041f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8bc>
100503ee0:     	tbz	w22, #0x0, 0x100504568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100503ee4:     	ldrb	w8, [x20, #0x20]
100503ee8:     	cbnz	w8, 0x100504a80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1148>
100503eec:     	ldr	x8, [x20]
100503ef0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100503ef4:     	cmp	x8, x9
100503ef8:     	b.hs	0x100504bc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100503efc:     	add	x9, x8, #0x1
100503f00:     	str	x9, [x20]
100503f04:     	ldr	x9, [x20, #0x18]
100503f08:     	cmp	x21, x9
100503f0c:     	b.hs	0x100503f20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5e8>
100503f10:     	ldr	x9, [x20, #0x10]
100503f14:     	ldr	x9, [x9, x21, lsl #3]
100503f18:     	and	x23, x9, #0xffffffffffff
100503f1c:     	b	0x100503f24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5ec>
100503f20:     	mov	w23, #0x1               ; =1
100503f24:     	str	x8, [x20]
100503f28:     	adrp	x0, 0x100f84000 <__RNvNCNKNvNtCs3gRpqoBkMHm_13perry_runtime7process29PROCESS_FINALIZATION_EXIT_RAN0s_023___RUST_STD_INTERNAL_VAL>
100503f2c:     	add	x0, x0, #0x168
100503f30:     	ldr	x8, [x0]
100503f34:     	blr	x8
100503f38:     	mov	x22, x0
100503f3c:     	ldrb	w8, [x0, #0x30]
100503f40:     	cmp	w8, #0x1
100503f44:     	b.ne	0x100504a50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1118>
100503f48:     	ldr	x8, [x22]
100503f4c:     	mov	x10, #-0x1              ; =-1
100503f50:     	mov	x9, x22
100503f54:     	str	x10, [x9], #0x8
100503f58:     	cmn	x8, #0x1
100503f5c:     	b.eq	0x100503f7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x644>
100503f60:     	add	x10, sp, #0xa0
100503f64:     	ldp	q0, q1, [x9]
100503f68:     	ldr	x9, [x9, #0x20]
100503f6c:     	stur	x9, [x10, #0x28]
100503f70:     	stur	q1, [x10, #0x18]
100503f74:     	stur	q0, [x10, #0x8]
100503f78:     	b	0x100503f90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x658>
100503f7c:     	mov	x8, #0x0                ; =0
100503f80:     	mov	w9, #0x4                ; =4
100503f84:     	stp	x9, xzr, [sp, #0xa8]
100503f88:     	stp	xzr, x9, [sp, #0xb8]
100503f8c:     	str	xzr, [sp, #0xc8]
100503f90:     	str	x8, [sp, #0xa0]
100503f94:     	stur	xzr, [x29, #-0x78]
100503f98:     	add	x8, sp, #0xa0
100503f9c:     	add	x0, x23, #0x14
100503fa0:     	add	x2, sp, #0xa0
100503fa4:     	add	x3, x8, #0x18
100503fa8:     	sub	x4, x29, #0x78
100503fac:     	mov	x1, x19
100503fb0:     	bl	0x10014e764 <__RINvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15build_tape_intoKb1_EB4_>
100503fb4:     	tbz	w0, #0x0, 0x1005040c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x78c>
100503fb8:     	ldur	x23, [x29, #-0x78]
100503fbc:     	ldr	w24, [x24, #0x948]
100503fc0:     	cmp	w24, #0x300
100503fc4:     	b.hs	0x1005048dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfa4>
100503fc8:     	ldr	x8, [x27, #0x48]
100503fcc:     	cmn	x8, #0x1
100503fd0:     	b.eq	0x1005048cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf94>
100503fd4:     	mrs	x9, TPIDRRO_EL0
100503fd8:     	and	x9, x9, #0xfffffffffffffff8
100503fdc:     	ldr	x0, [x9, x8, lsl #3]
100503fe0:     	cbz	x0, 0x1005048cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf94>
100503fe4:     	add	x8, x0, x24, lsl #3
100503fe8:     	ldr	x0, [x8, #0x1e8]
100503fec:     	cbz	x0, 0x1005048dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfa4>
100503ff0:     	ldrb	w8, [x0]
100503ff4:     	cbnz	w8, 0x1005048f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfb8>
100503ff8:     	bl	0x1004edac0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
100503ffc:     	bl	0x100457940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy16gc_check_trigger>
100504000:     	mov	x0, x19
100504004:     	bl	0x10022fa2c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation5begin>
100504008:     	mov	x24, x0
10050400c:     	mov	x25, x1
100504010:     	bl	0x100457754 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy11gc_suppress>
100504014:     	ldrb	w8, [x20, #0x20]
100504018:     	cbnz	w8, 0x100504b0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11d4>
10050401c:     	ldr	x8, [x20]
100504020:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504024:     	cmp	x8, x9
100504028:     	b.hs	0x100504bc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
10050402c:     	add	x9, x8, #0x1
100504030:     	str	x9, [x20]
100504034:     	ldr	x9, [x20, #0x18]
100504038:     	cmp	x21, x9
10050403c:     	b.hs	0x10050415c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x824>
100504040:     	ldr	x9, [x20, #0x10]
100504044:     	ldr	x9, [x9, x21, lsl #3]
100504048:     	and	x2, x9, #0xffffffffffff
10050404c:     	stp	x25, x24, [sp]
100504050:     	str	x8, [x20]
100504054:     	add	x26, x2, #0x14
100504058:     	cmp	x23, #0x3e8
10050405c:     	b.hi	0x100504174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x83c>
100504060:     	ldp	x24, x25, [sp, #0xa8]
100504064:     	cbz	x25, 0x100504190 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x858>
100504068:     	ldrb	w8, [x24, #0x8]
10050406c:     	cmp	w8, #0x3
100504070:     	b.ne	0x100504190 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x858>
100504074:     	ldr	w8, [x24, #0x4]
100504078:     	cmp	w8, #0x2
10050407c:     	b.lo	0x100504260 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x928>
100504080:     	mov	w1, #0x0                ; =0
100504084:     	mov	w0, #0x1                ; =1
100504088:     	mov	w9, #0xc                ; =12
10050408c:     	b	0x1005040a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x768>
100504090:     	add	x0, x0, #0x1
100504094:     	add	w1, w1, #0x1
100504098:     	cmp	x0, x8
10050409c:     	b.hs	0x100504264 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x92c>
1005040a0:     	cmp	x0, x25
1005040a4:     	b.hs	0x100504cc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1388>
1005040a8:     	madd	x10, x0, x9, x24
1005040ac:     	ldrb	w11, [x10, #0x8]
1005040b0:     	orr	w11, w11, #0x2
1005040b4:     	cmp	w11, #0x3
1005040b8:     	b.ne	0x100504090 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x758>
1005040bc:     	ldr	w0, [x10, #0x4]
1005040c0:     	b	0x100504090 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x758>
1005040c4:     	str	xzr, [sp, #0xb0]
1005040c8:     	str	xzr, [sp, #0xc8]
1005040cc:     	ldr	x8, [sp, #0xa0]
1005040d0:     	add	x9, x8, x8, lsl #1
1005040d4:     	lsl	x9, x9, #2
1005040d8:     	cmp	x9, #0x100, lsl #12     ; =0x100000
1005040dc:     	b.ls	0x1005040f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7c0>
1005040e0:     	cbz	x8, 0x1005040ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7b4>
1005040e4:     	ldr	x0, [sp, #0xa8]
1005040e8:     	bl	0x100b5cd00 <_mi_free>
1005040ec:     	mov	w8, #0x4                ; =4
1005040f0:     	stp	xzr, x8, [sp, #0xa0]
1005040f4:     	str	xzr, [sp, #0xb0]
1005040f8:     	ldr	x8, [sp, #0xb8]
1005040fc:     	lsl	x9, x8, #2
100504100:     	cmp	x9, #0x10, lsl #12      ; =0x10000
100504104:     	b.ls	0x100504120 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7e8>
100504108:     	cbz	x8, 0x100504114 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7dc>
10050410c:     	ldr	x0, [sp, #0xc0]
100504110:     	bl	0x100b5cd00 <_mi_free>
100504114:     	mov	w8, #0x4                ; =4
100504118:     	stp	xzr, x8, [sp, #0xb8]
10050411c:     	str	xzr, [sp, #0xc8]
100504120:     	ldp	x8, x0, [x22]
100504124:     	ldp	x24, x23, [x22, #0x18]
100504128:     	ldp	q1, q0, [sp, #0xb0]
10050412c:     	ldr	q2, [sp, #0xa0]
100504130:     	stp	q2, q1, [x22]
100504134:     	str	q0, [x22, #0x20]
100504138:     	cmn	x8, #0x1
10050413c:     	b.eq	0x100504154 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x81c>
100504140:     	cbz	x8, 0x100504148 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x810>
100504144:     	bl	0x100b5cd00 <_mi_free>
100504148:     	cbz	x24, 0x100504154 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x81c>
10050414c:     	mov	x0, x23
100504150:     	bl	0x100b5cd00 <_mi_free>
100504154:     	ldrb	w8, [x20, #0x20]
100504158:     	b	0x10050448c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb54>
10050415c:     	mov	w2, #0x1                ; =1
100504160:     	stp	x25, x24, [sp]
100504164:     	str	x8, [x20]
100504168:     	add	x26, x2, #0x14
10050416c:     	cmp	x23, #0x3e8
100504170:     	b.ls	0x100504060 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x728>
100504174:     	ldp	x0, x1, [sp, #0xa8]
100504178:     	mov	x2, x26
10050417c:     	mov	x3, x19
100504180:     	bl	0x100686314 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape9iterative21materialize_iterative>
100504184:     	tbz	w0, #0x0, 0x1005041bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x884>
100504188:     	mov	x25, x1
10050418c:     	b	0x1005042b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x97c>
100504190:     	bl	0x100288f98 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
100504194:     	stp	x0, xzr, [x29, #-0x70]
100504198:     	stp	x24, x25, [sp, #0x10]
10050419c:     	stp	x26, x19, [sp, #0x20]
1005041a0:     	add	x0, sp, #0x10
1005041a4:     	sub	x1, x29, #0x68
1005041a8:     	bl	0x100375960 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24materialize_value_source>
1005041ac:     	mov	x25, x0
1005041b0:     	sub	x0, x29, #0x70
1005041b4:     	bl	0x1001649fc <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
1005041b8:     	b	0x1005042b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x97c>
1005041bc:     	mov	w25, #0x0               ; =0
1005041c0:     	b	0x1005042fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9c4>
1005041c4:     	add	x0, x20, #0x8
1005041c8:     	bl	0x100b39a6c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1005041cc:     	b	0x100503e84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x54c>
1005041d0:     	bl	0x100b3d17c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005041d4:     	add	x8, x0, x23, lsl #3
1005041d8:     	ldr	x0, [x8, #0x1e8]
1005041dc:     	cbnz	x0, 0x100503ed8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5a0>
1005041e0:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
1005041e4:     	add	x0, x0, #0xca8
1005041e8:     	bl	0x100b3a9e8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1005041ec:     	ldrb	w8, [x0]
1005041f0:     	cbz	w8, 0x100503ee0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5a8>
1005041f4:     	bl	0x100b4211c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
1005041f8:     	tbnz	w22, #0x0, 0x100503ee4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5ac>
1005041fc:     	b	0x100504568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100504200:     	bl	0x100b3d17c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100504204:     	add	x8, x0, x20, lsl #3
100504208:     	ldr	x0, [x8, #0x1e8]
10050420c:     	cbnz	x0, 0x100503d90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x458>
100504210:     	adrp	x0, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
100504214:     	add	x0, x0, #0xfa0
100504218:     	bl	0x100b3a99c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10050421c:     	ldr	x8, [x0]
100504220:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504224:     	cmp	x8, x9
100504228:     	b.lo	0x100503da0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x468>
10050422c:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100504230:     	add	x0, x0, #0xd10
100504234:     	bl	0x100b104dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100504238:     	cmp	w10, #0x5b
10050423c:     	cset	w22, eq
100504240:     	mov	w8, #0x1000000          ; =16777216
100504244:     	cmp	x19, x8
100504248:     	mov	w8, #0x5b               ; =91
10050424c:     	ccmp	w10, w8, #0x0, ls
100504250:     	b.ne	0x100503d5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x424>
100504254:     	mov	w28, #0x1               ; =1
100504258:     	mov	w22, #0x1               ; =1
10050425c:     	b	0x100503e40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x508>
100504260:     	mov	w1, #0x0                ; =0
100504264:     	ldr	x8, [sp, #0xa0]
100504268:     	add	x8, x8, x8, lsl #1
10050426c:     	lsl	x8, x8, #2
100504270:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100504274:     	b.ls	0x100504298 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x960>
100504278:     	ldr	q0, [sp, #0xa0]
10050427c:     	str	q0, [sp, #0x10]
100504280:     	ldr	x8, [sp, #0xb0]
100504284:     	str	x8, [sp, #0x20]
100504288:     	mov	w8, #0x4                ; =4
10050428c:     	stp	xzr, x8, [sp, #0xa0]
100504290:     	str	xzr, [sp, #0xb0]
100504294:     	b	0x1005042a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x96c>
100504298:     	stp	x24, x25, [sp, #0x18]
10050429c:     	mov	x8, #-0x1               ; =-1
1005042a0:     	str	x8, [sp, #0x10]
1005042a4:     	add	x0, sp, #0x10
1005042a8:     	bl	0x100374ab0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24alloc_lazy_array_backing>
1005042ac:     	mov	x25, #0x7ffd000000000000 ; =9222527611924643840
1005042b0:     	bfxil	x25, x0, #0, #48
1005042b4:     	ldrb	w8, [x20, #0x20]
1005042b8:     	cbnz	w8, 0x100504b3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1204>
1005042bc:     	ldr	x8, [x20]
1005042c0:     	cbnz	x8, 0x100504a44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
1005042c4:     	mov	x8, #-0x1               ; =-1
1005042c8:     	str	x8, [x20]
1005042cc:     	ldr	x26, [x20, #0x18]
1005042d0:     	ldr	x8, [x20, #0x8]
1005042d4:     	cmp	x26, x8
1005042d8:     	b.eq	0x10050496c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1034>
1005042dc:     	ldr	x8, [x20, #0x10]
1005042e0:     	str	x25, [x8, x26, lsl #3]
1005042e4:     	add	x8, x26, #0x1
1005042e8:     	str	x8, [x20, #0x18]
1005042ec:     	ldr	x8, [x20]
1005042f0:     	add	x8, x8, #0x1
1005042f4:     	str	x8, [x20]
1005042f8:     	mov	w25, #0x1               ; =1
1005042fc:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100504300:     	ldr	w24, [x8, #0x308]
100504304:     	cmp	w24, #0x300
100504308:     	b.hs	0x100504908 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfd0>
10050430c:     	ldr	x8, [x27, #0x48]
100504310:     	cmn	x8, #0x1
100504314:     	b.eq	0x1005048f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfc0>
100504318:     	mrs	x9, TPIDRRO_EL0
10050431c:     	and	x9, x9, #0xfffffffffffffff8
100504320:     	ldr	x0, [x9, x8, lsl #3]
100504324:     	cbz	x0, 0x1005048f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfc0>
100504328:     	add	x8, x0, x24, lsl #3
10050432c:     	ldr	x0, [x8, #0x1e8]
100504330:     	cbz	x0, 0x100504908 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfd0>
100504334:     	ldrb	w8, [x0]
100504338:     	and	w8, w8, #0xfffffffd
10050433c:     	strb	w8, [x0]
100504340:     	mov	w0, #0x0                ; =0
100504344:     	bl	0x10045b080 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy28gc_bump_malloc_trigger_inner>
100504348:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
10050434c:     	ldr	w24, [x8, #0x590]
100504350:     	cmp	w24, #0x300
100504354:     	b.hs	0x100504928 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xff0>
100504358:     	ldr	x8, [x27, #0x48]
10050435c:     	cmn	x8, #0x1
100504360:     	b.eq	0x100504918 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfe0>
100504364:     	mrs	x9, TPIDRRO_EL0
100504368:     	and	x9, x9, #0xfffffffffffffff8
10050436c:     	ldr	x0, [x9, x8, lsl #3]
100504370:     	cbz	x0, 0x100504918 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfe0>
100504374:     	add	x8, x0, x24, lsl #3
100504378:     	ldr	x0, [x8, #0x1e8]
10050437c:     	cbz	x0, 0x100504928 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xff0>
100504380:     	ldr	x8, [x0]
100504384:     	lsr	x8, x8, #25
100504388:     	cbz	x8, 0x100504940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1008>
10050438c:     	bl	0x10045ce34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100504390:     	cmp	x23, #0x3e8
100504394:     	b.hi	0x100504948 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1010>
100504398:     	ldp	x1, x0, [sp]
10050439c:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
1005043a0:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1005043a4:     	ldr	x8, [x8, #0x758]
1005043a8:     	cbnz	x8, 0x100504960 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1028>
1005043ac:     	tbz	w25, #0x0, 0x1005043f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xabc>
1005043b0:     	ldrb	w8, [x20, #0x20]
1005043b4:     	cbnz	w8, 0x100504b98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1260>
1005043b8:     	ldr	x8, [x20]
1005043bc:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1005043c0:     	cmp	x8, x9
1005043c4:     	b.hs	0x100504bc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
1005043c8:     	add	x9, x8, #0x1
1005043cc:     	str	x9, [x20]
1005043d0:     	ldr	x9, [x20, #0x18]
1005043d4:     	cmp	x26, x9
1005043d8:     	b.hs	0x1005043e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xab0>
1005043dc:     	ldr	x9, [x20, #0x10]
1005043e0:     	ldr	x23, [x9, x26, lsl #3]
1005043e4:     	b	0x1005043f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xab8>
1005043e8:     	mov	x23, #0x1               ; =1
1005043ec:     	movk	x23, #0x7ffc, lsl #48
1005043f0:     	str	x8, [x20]
1005043f4:     	str	xzr, [sp, #0xb0]
1005043f8:     	str	xzr, [sp, #0xc8]
1005043fc:     	ldr	x8, [sp, #0xa0]
100504400:     	add	x9, x8, x8, lsl #1
100504404:     	lsl	x9, x9, #2
100504408:     	cmp	x9, #0x100, lsl #12     ; =0x100000
10050440c:     	b.ls	0x100504428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xaf0>
100504410:     	cbz	x8, 0x10050441c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xae4>
100504414:     	ldr	x0, [sp, #0xa8]
100504418:     	bl	0x100b5cd00 <_mi_free>
10050441c:     	mov	w8, #0x4                ; =4
100504420:     	stp	xzr, x8, [sp, #0xa0]
100504424:     	str	xzr, [sp, #0xb0]
100504428:     	ldr	x8, [sp, #0xb8]
10050442c:     	lsl	x9, x8, #2
100504430:     	cmp	x9, #0x10, lsl #12      ; =0x10000
100504434:     	b.ls	0x100504450 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb18>
100504438:     	cbz	x8, 0x100504444 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb0c>
10050443c:     	ldr	x0, [sp, #0xc0]
100504440:     	bl	0x100b5cd00 <_mi_free>
100504444:     	mov	w8, #0x4                ; =4
100504448:     	stp	xzr, x8, [sp, #0xb8]
10050444c:     	str	xzr, [sp, #0xc8]
100504450:     	ldp	x8, x0, [x22]
100504454:     	ldp	x26, x24, [x22, #0x18]
100504458:     	ldp	q1, q0, [sp, #0xb0]
10050445c:     	ldr	q2, [sp, #0xa0]
100504460:     	stp	q2, q1, [x22]
100504464:     	str	q0, [x22, #0x20]
100504468:     	cmn	x8, #0x1
10050446c:     	b.eq	0x10050451c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbe4>
100504470:     	cbz	x8, 0x100504478 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb40>
100504474:     	bl	0x100b5cd00 <_mi_free>
100504478:     	cbz	x26, 0x10050451c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbe4>
10050447c:     	mov	x0, x24
100504480:     	bl	0x100b5cd00 <_mi_free>
100504484:     	ldrb	w8, [x20, #0x20]
100504488:     	tbnz	w25, #0x0, 0x100504524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbec>
10050448c:     	cbnz	w8, 0x100504adc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11a4>
100504490:     	ldr	x8, [x20]
100504494:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504498:     	cmp	x8, x9
10050449c:     	b.hs	0x100504bc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
1005044a0:     	add	x9, x8, #0x1
1005044a4:     	str	x9, [x20]
1005044a8:     	ldr	x9, [x20, #0x18]
1005044ac:     	cmp	x21, x9
1005044b0:     	b.hs	0x1005044d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb9c>
1005044b4:     	ldr	x9, [x20, #0x10]
1005044b8:     	ldr	x9, [x9, x21, lsl #3]
1005044bc:     	and	x22, x9, #0xffffffffffff
1005044c0:     	str	x8, [x20]
1005044c4:     	cmp	x19, #0x3e8
1005044c8:     	csel	w8, wzr, w28, ls
1005044cc:     	cbnz	w8, 0x1005044e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbb0>
1005044d0:     	b	0x100504568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
1005044d4:     	mov	w22, #0x1               ; =1
1005044d8:     	str	x8, [x20]
1005044dc:     	cmp	x19, #0x3e8
1005044e0:     	csel	w8, wzr, w28, ls
1005044e4:     	cbz	w8, 0x100504568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
1005044e8:     	mov	x8, #0x0                ; =0
1005044ec:     	mov	x9, #0x2600             ; =9728
1005044f0:     	movk	x9, #0x1, lsl #32
1005044f4:     	add	x10, x22, x8
1005044f8:     	ldrb	w10, [x10, #0x14]
1005044fc:     	cmp	w10, #0x20
100504500:     	b.hi	0x100504544 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc0c>
100504504:     	lsr	x11, x9, x10
100504508:     	tbz	w11, #0x0, 0x100504544 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc0c>
10050450c:     	add	x8, x8, #0x1
100504510:     	cmp	x19, x8
100504514:     	b.ne	0x1005044f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbbc>
100504518:     	b	0x100504568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
10050451c:     	ldrb	w8, [x20, #0x20]
100504520:     	cbz	w25, 0x10050448c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb54>
100504524:     	cbnz	w8, 0x100504bd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1298>
100504528:     	ldr	x8, [x20]
10050452c:     	cbnz	x8, 0x100504c74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x133c>
100504530:     	ldr	x8, [x20, #0x18]
100504534:     	cmp	x21, x8
100504538:     	b.hi	0x100503970 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
10050453c:     	str	x21, [x20, #0x18]
100504540:     	b	0x100503970 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100504544:     	cmp	w10, #0x5b
100504548:     	b.eq	0x100504554 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc1c>
10050454c:     	cmp	w10, #0x7b
100504550:     	b.ne	0x100504568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100504554:     	add	x0, x22, #0x14
100504558:     	mov	x1, x19
10050455c:     	mov	w2, #0x3e8              ; =1000
100504560:     	bl	0x1006c2854 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser12depth_blocks21nesting_depth_exceeds>
100504564:     	cbnz	w0, 0x100504a64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x112c>
100504568:     	bl	0x1004edac0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
10050456c:     	bl	0x100457940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy16gc_check_trigger>
100504570:     	mov	x0, x19
100504574:     	bl	0x10022fa2c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation5begin>
100504578:     	mov	x24, x0
10050457c:     	mov	x22, x1
100504580:     	bl	0x100457754 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy11gc_suppress>
100504584:     	ldrb	w8, [x20, #0x20]
100504588:     	cbnz	w8, 0x1005049f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10b8>
10050458c:     	ldr	x8, [x20]
100504590:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504594:     	cmp	x8, x9
100504598:     	b.hs	0x100504bc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
10050459c:     	add	x9, x8, #0x1
1005045a0:     	str	x9, [x20]
1005045a4:     	ldr	x9, [x20, #0x18]
1005045a8:     	cmp	x21, x9
1005045ac:     	b.hs	0x1005045c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc8c>
1005045b0:     	ldr	x9, [x20, #0x10]
1005045b4:     	ldr	x9, [x9, x21, lsl #3]
1005045b8:     	and	x25, x9, #0xffffffffffff
1005045bc:     	add	x1, x25, #0x14
1005045c0:     	b	0x1005045cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc94>
1005045c4:     	mov	w25, #0x1               ; =1
1005045c8:     	mov	w1, #0x15               ; =21
1005045cc:     	str	x8, [x20]
1005045d0:     	add	x0, sp, #0xa0
1005045d4:     	mov	x2, x19
1005045d8:     	mov	x3, x25
1005045dc:     	bl	0x10024530c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23new_batched_from_string>
1005045e0:     	add	x0, sp, #0xa0
1005045e4:     	bl	0x100242448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value>
1005045e8:     	mov	x23, x0
1005045ec:     	ldp	x26, x28, [sp, #0x108]
1005045f0:     	cmp	x28, x26
1005045f4:     	b.hs	0x100504628 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcf0>
1005045f8:     	ldr	x8, [sp, #0x100]
1005045fc:     	mov	x9, #0x2600             ; =9728
100504600:     	movk	x9, #0x1, lsl #32
100504604:     	ldrb	w10, [x8, x28]
100504608:     	cmp	w10, #0x20
10050460c:     	b.hi	0x100504628 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcf0>
100504610:     	lsr	x10, x9, x10
100504614:     	tbz	w10, #0x0, 0x100504628 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcf0>
100504618:     	add	x28, x28, #0x1
10050461c:     	cmp	x26, x28
100504620:     	b.ne	0x100504604 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xccc>
100504624:     	mov	x28, x26
100504628:     	ldrb	w8, [sp, #0x176]
10050462c:     	tbnz	w8, #0x0, 0x100504978 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1040>
100504630:     	cmp	x28, x26
100504634:     	b.ne	0x100504984 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104c>
100504638:     	ldrb	w8, [sp, #0x174]
10050463c:     	tbz	w8, #0x0, 0x100504984 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104c>
100504640:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100504644:     	ldr	w26, [x8, #0x560]
100504648:     	cmp	w26, #0x300
10050464c:     	b.hs	0x1005047e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xeac>
100504650:     	ldr	x8, [x27, #0x48]
100504654:     	cmn	x8, #0x1
100504658:     	b.eq	0x1005047d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe9c>
10050465c:     	mrs	x9, TPIDRRO_EL0
100504660:     	and	x9, x9, #0xfffffffffffffff8
100504664:     	ldr	x0, [x9, x8, lsl #3]
100504668:     	cbz	x0, 0x1005047d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe9c>
10050466c:     	add	x8, x0, x26, lsl #3
100504670:     	ldr	x0, [x8, #0x1e8]
100504674:     	cbz	x0, 0x1005047e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xeac>
100504678:     	ldr	x8, [x0]
10050467c:     	cbnz	x8, 0x1005047f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xec0>
100504680:     	ldrb	w8, [x0, #0x24]
100504684:     	cmp	w8, #0x2
100504688:     	b.eq	0x1005046ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd74>
10050468c:     	ldr	x8, [x0, #0x8]
100504690:     	cmp	x8, x25
100504694:     	b.ne	0x1005046ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd74>
100504698:     	ldr	w8, [x0, #0x18]
10050469c:     	cmp	x19, x8
1005046a0:     	b.ne	0x1005046ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd74>
1005046a4:     	mov	w8, #0x1                ; =1
1005046a8:     	strb	w8, [x0, #0x24]
1005046ac:     	mov	x0, x25
1005046b0:     	mov	x1, x19
1005046b4:     	mov	x2, x23
1005046b8:     	bl	0x1004eabc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template>
1005046bc:     	ldrb	w8, [x20, #0x20]
1005046c0:     	cbnz	w8, 0x100504a20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10e8>
1005046c4:     	ldr	x8, [x20]
1005046c8:     	cbnz	x8, 0x100504a44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
1005046cc:     	mov	x8, #-0x1               ; =-1
1005046d0:     	str	x8, [x20]
1005046d4:     	ldr	x19, [x20, #0x18]
1005046d8:     	ldr	x8, [x20, #0x8]
1005046dc:     	cmp	x19, x8
1005046e0:     	b.eq	0x100504804 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xecc>
1005046e4:     	ldr	x8, [x20, #0x10]
1005046e8:     	str	x23, [x8, x19, lsl #3]
1005046ec:     	add	x8, x19, #0x1
1005046f0:     	str	x8, [x20, #0x18]
1005046f4:     	ldr	x8, [x20]
1005046f8:     	add	x8, x8, #0x1
1005046fc:     	str	x8, [x20]
100504700:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100504704:     	ldr	w19, [x8, #0x308]
100504708:     	cmp	w19, #0x300
10050470c:     	b.hs	0x100504820 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xee8>
100504710:     	ldr	x8, [x27, #0x48]
100504714:     	cmn	x8, #0x1
100504718:     	b.eq	0x100504810 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xed8>
10050471c:     	mrs	x9, TPIDRRO_EL0
100504720:     	and	x9, x9, #0xfffffffffffffff8
100504724:     	ldr	x0, [x9, x8, lsl #3]
100504728:     	cbz	x0, 0x100504810 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xed8>
10050472c:     	add	x8, x0, x19, lsl #3
100504730:     	ldr	x0, [x8, #0x1e8]
100504734:     	cbz	x0, 0x100504820 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xee8>
100504738:     	ldrb	w8, [x0]
10050473c:     	and	w8, w8, #0xfffffffd
100504740:     	strb	w8, [x0]
100504744:     	mov	w0, #0x0                ; =0
100504748:     	bl	0x10045b080 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy28gc_bump_malloc_trigger_inner>
10050474c:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100504750:     	ldr	w19, [x8, #0x590]
100504754:     	cmp	w19, #0x300
100504758:     	b.hs	0x100504840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf08>
10050475c:     	ldr	x8, [x27, #0x48]
100504760:     	cmn	x8, #0x1
100504764:     	b.eq	0x100504830 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xef8>
100504768:     	mrs	x9, TPIDRRO_EL0
10050476c:     	and	x9, x9, #0xfffffffffffffff8
100504770:     	ldr	x0, [x9, x8, lsl #3]
100504774:     	cbz	x0, 0x100504830 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xef8>
100504778:     	add	x8, x0, x19, lsl #3
10050477c:     	ldr	x0, [x8, #0x1e8]
100504780:     	cbz	x0, 0x100504840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf08>
100504784:     	ldr	x8, [x0]
100504788:     	lsr	x8, x8, #25
10050478c:     	cbz	x8, 0x100504858 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf20>
100504790:     	bl	0x10045ce34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100504794:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100504798:     	mov	x0, x24
10050479c:     	mov	x1, x22
1005047a0:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
1005047a4:     	ldrb	w8, [x20, #0x20]
1005047a8:     	cbz	w8, 0x100504870 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf38>
1005047ac:     	cmp	w8, #0x2
1005047b0:     	b.eq	0x100504bd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
1005047b4:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
1005047b8:     	add	x1, x1, #0x518
1005047bc:     	mov	x0, x20
1005047c0:     	bl	0x100a1e1dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1005047c4:     	strb	wzr, [x20, #0x20]
1005047c8:     	ldr	x8, [x20]
1005047cc:     	cbz	x8, 0x100504878 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf40>
1005047d0:     	b	0x100504c74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x133c>
1005047d4:     	bl	0x100b3d17c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005047d8:     	add	x8, x0, x26, lsl #3
1005047dc:     	ldr	x0, [x8, #0x1e8]
1005047e0:     	cbnz	x0, 0x100504678 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd40>
1005047e4:     	adrp	x0, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1005047e8:     	add	x0, x0, #0xfa0
1005047ec:     	bl	0x100b3a99c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1005047f0:     	ldr	x8, [x0]
1005047f4:     	cbz	x8, 0x100504680 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd48>
1005047f8:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1005047fc:     	add	x0, x0, #0xcf8
100504800:     	bl	0x100b104ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100504804:     	add	x0, x20, #0x8
100504808:     	bl	0x100b39a6c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10050480c:     	b	0x1005046e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xdac>
100504810:     	bl	0x100b3d17c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100504814:     	add	x8, x0, x19, lsl #3
100504818:     	ldr	x0, [x8, #0x1e8]
10050481c:     	cbnz	x0, 0x100504738 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe00>
100504820:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
100504824:     	add	x0, x0, #0xcd8
100504828:     	bl	0x100b3a9e8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
10050482c:     	b	0x100504738 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe00>
100504830:     	bl	0x100b3d17c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100504834:     	add	x8, x0, x19, lsl #3
100504838:     	ldr	x0, [x8, #0x1e8]
10050483c:     	cbnz	x0, 0x100504784 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe4c>
100504840:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100504844:     	add	x0, x0, #0x78
100504848:     	bl	0x100b3a99c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10050484c:     	ldr	x8, [x0]
100504850:     	lsr	x8, x8, #25
100504854:     	cbnz	x8, 0x100504790 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe58>
100504858:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
10050485c:     	mov	x0, x24
100504860:     	mov	x1, x22
100504864:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100504868:     	ldrb	w8, [x20, #0x20]
10050486c:     	cbnz	w8, 0x1005047ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe74>
100504870:     	ldr	x8, [x20]
100504874:     	cbnz	x8, 0x100504c74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x133c>
100504878:     	ldr	x8, [x20, #0x18]
10050487c:     	cmp	x21, x8
100504880:     	b.ls	0x1005048a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf70>
100504884:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100504888:     	ldr	x8, [x8, #0x758]
10050488c:     	cbnz	x8, 0x1005048b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf80>
100504890:     	ldr	x8, [sp, #0xd8]
100504894:     	cmp	x8, #0x1
100504898:     	b.lt	0x100503970 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
10050489c:     	ldr	x0, [sp, #0xe0]
1005048a0:     	bl	0x100b5cd00 <_mi_free>
1005048a4:     	b	0x100503970 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
1005048a8:     	str	x21, [x20, #0x18]
1005048ac:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1005048b0:     	ldr	x8, [x8, #0x758]
1005048b4:     	cbz	x8, 0x100504890 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf58>
1005048b8:     	bl	0x100b4383c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
1005048bc:     	ldr	x8, [sp, #0xd8]
1005048c0:     	cmp	x8, #0x1
1005048c4:     	b.ge	0x10050489c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf64>
1005048c8:     	b	0x100503970 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
1005048cc:     	bl	0x100b3d17c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005048d0:     	add	x8, x0, x24, lsl #3
1005048d4:     	ldr	x0, [x8, #0x1e8]
1005048d8:     	cbnz	x0, 0x100503ff0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6b8>
1005048dc:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
1005048e0:     	add	x0, x0, #0xca8
1005048e4:     	bl	0x100b3a9e8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1005048e8:     	ldrb	w8, [x0]
1005048ec:     	cbz	w8, 0x100503ff8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6c0>
1005048f0:     	bl	0x100b4211c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
1005048f4:     	b	0x100503ff8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6c0>
1005048f8:     	bl	0x100b3d17c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005048fc:     	add	x8, x0, x24, lsl #3
100504900:     	ldr	x0, [x8, #0x1e8]
100504904:     	cbnz	x0, 0x100504334 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9fc>
100504908:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
10050490c:     	add	x0, x0, #0xcd8
100504910:     	bl	0x100b3a9e8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
100504914:     	b	0x100504334 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9fc>
100504918:     	bl	0x100b3d17c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10050491c:     	add	x8, x0, x24, lsl #3
100504920:     	ldr	x0, [x8, #0x1e8]
100504924:     	cbnz	x0, 0x100504380 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa48>
100504928:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10050492c:     	add	x0, x0, #0x78
100504930:     	bl	0x100b3a99c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100504934:     	ldr	x8, [x0]
100504938:     	lsr	x8, x8, #25
10050493c:     	cbnz	x8, 0x10050438c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa54>
100504940:     	cmp	x23, #0x3e8
100504944:     	b.ls	0x100504398 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa60>
100504948:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
10050494c:     	ldp	x1, x0, [sp]
100504950:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100504954:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100504958:     	ldr	x8, [x8, #0x758]
10050495c:     	cbz	x8, 0x1005043ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa74>
100504960:     	bl	0x100b4383c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
100504964:     	tbnz	w25, #0x0, 0x1005043b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa78>
100504968:     	b	0x1005043f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xabc>
10050496c:     	add	x0, x20, #0x8
100504970:     	bl	0x100b39a6c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100504974:     	b	0x1005042dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9a4>
100504978:     	bl	0x100b43610 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar15clear_key_cache>
10050497c:     	cmp	x28, x26
100504980:     	b.eq	0x100504638 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd00>
100504984:     	mov	x0, x23
100504988:     	bl	0x1003259cc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15parse_root_push>
10050498c:     	bl	0x1004578bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy13gc_unsuppress>
100504990:     	bl	0x1004eda24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat26finish_parse_gc_accounting>
100504994:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100504998:     	mov	x0, x24
10050499c:     	mov	x1, x22
1005049a0:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
1005049a4:     	mov	x0, x21
1005049a8:     	bl	0x100325bdc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json18parse_root_restore>
1005049ac:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1005049b0:     	ldr	x8, [x8, #0x758]
1005049b4:     	cbnz	x8, 0x100504f1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15e4>
1005049b8:     	adrp	x0, 0x100c73000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x719c>
1005049bc:     	add	x0, x0, #0x320
1005049c0:     	mov	w1, #0x21               ; =33
1005049c4:     	bl	0x1005063e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
1005049c8:     	cmp	w8, #0x2
1005049cc:     	b.eq	0x100504bd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
1005049d0:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
1005049d4:     	add	x1, x1, #0x518
1005049d8:     	mov	x0, x20
1005049dc:     	bl	0x100a1e1dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1005049e0:     	strb	wzr, [x20, #0x20]
1005049e4:     	ldr	x8, [x20]
1005049e8:     	cbz	x8, 0x100503e64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x52c>
1005049ec:     	b	0x100504a44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
1005049f0:     	cmp	w8, #0x2
1005049f4:     	b.eq	0x100504bd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
1005049f8:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
1005049fc:     	add	x1, x1, #0x518
100504a00:     	mov	x0, x20
100504a04:     	bl	0x100a1e1dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504a08:     	strb	wzr, [x20, #0x20]
100504a0c:     	ldr	x8, [x20]
100504a10:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504a14:     	cmp	x8, x9
100504a18:     	b.lo	0x10050459c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc64>
100504a1c:     	b	0x100504bc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100504a20:     	cmp	w8, #0x2
100504a24:     	b.eq	0x100504bd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504a28:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504a2c:     	add	x1, x1, #0x518
100504a30:     	mov	x0, x20
100504a34:     	bl	0x100a1e1dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504a38:     	strb	wzr, [x20, #0x20]
100504a3c:     	ldr	x8, [x20]
100504a40:     	cbz	x8, 0x1005046cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd94>
100504a44:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100504a48:     	add	x0, x0, #0x428
100504a4c:     	bl	0x100b104ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100504a50:     	mov	x0, x22
100504a54:     	bl	0x100b1c2ac <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11TapeScratchEEuE16get_or_init_slowNvNvB2b_12TAPE_SCRATCH27___rust_std_internal_init_fnEB2d_>
100504a58:     	mov	x22, x0
100504a5c:     	cbnz	x0, 0x100503f48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x610>
100504a60:     	b	0x100504bd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504a64:     	mov	x0, x21
100504a68:     	bl	0x100325bdc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json18parse_root_restore>
100504a6c:     	mov	x0, x22
100504a70:     	mov	x1, x19
100504a74:     	bl	0x100b43b78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api19parse_deep_or_throw>
100504a78:     	mov	x23, x0
100504a7c:     	b	0x100503970 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100504a80:     	cmp	w8, #0x2
100504a84:     	b.eq	0x100504bd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504a88:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504a8c:     	add	x1, x1, #0x518
100504a90:     	mov	x0, x20
100504a94:     	bl	0x100a1e1dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504a98:     	strb	wzr, [x20, #0x20]
100504a9c:     	ldr	x8, [x20]
100504aa0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504aa4:     	cmp	x8, x9
100504aa8:     	b.lo	0x100503efc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5c4>
100504aac:     	b	0x100504bc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100504ab0:     	cmp	x9, #0x6
100504ab4:     	b.eq	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504ab8:     	ldrb	w8, [x21, #0x1a]
100504abc:     	cmp	w8, #0x22
100504ac0:     	b.ne	0x100504be4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12ac>
100504ac4:     	mov	w23, #0x0               ; =0
100504ac8:     	mov	w28, #0x0               ; =0
100504acc:     	mov	w27, #0x0               ; =0
100504ad0:     	mov	w26, #0x1               ; =1
100504ad4:     	mov	w20, #0x4               ; =4
100504ad8:     	b	0x100503af0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100504adc:     	cmp	w8, #0x2
100504ae0:     	b.eq	0x100504bd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504ae4:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504ae8:     	add	x1, x1, #0x518
100504aec:     	mov	x0, x20
100504af0:     	bl	0x100a1e1dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504af4:     	strb	wzr, [x20, #0x20]
100504af8:     	ldr	x8, [x20]
100504afc:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504b00:     	cmp	x8, x9
100504b04:     	b.lo	0x1005044a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb68>
100504b08:     	b	0x100504bc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100504b0c:     	cmp	w8, #0x2
100504b10:     	b.eq	0x100504bd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504b14:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504b18:     	add	x1, x1, #0x518
100504b1c:     	mov	x0, x20
100504b20:     	bl	0x100a1e1dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504b24:     	strb	wzr, [x20, #0x20]
100504b28:     	ldr	x8, [x20]
100504b2c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504b30:     	cmp	x8, x9
100504b34:     	b.lo	0x10050402c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6f4>
100504b38:     	b	0x100504bc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100504b3c:     	cmp	w8, #0x2
100504b40:     	b.eq	0x100504bd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504b44:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504b48:     	add	x1, x1, #0x518
100504b4c:     	mov	x0, x20
100504b50:     	bl	0x100a1e1dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504b54:     	strb	wzr, [x20, #0x20]
100504b58:     	ldr	x8, [x20]
100504b5c:     	cbz	x8, 0x1005042c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x98c>
100504b60:     	b	0x100504a44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
100504b64:     	cmp	x9, #0x1
100504b68:     	b.ne	0x100504c14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12dc>
100504b6c:     	ldrb	w8, [x8]
100504b70:     	sub	w9, w8, #0x30
100504b74:     	cmp	w9, #0xa
100504b78:     	b.hs	0x100504c18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12e0>
100504b7c:     	and	w8, w9, #0xff
100504b80:     	ucvtf	d0, w8
100504b84:     	fmov	x1, d0
100504b88:     	orr	x0, x25, x26
100504b8c:     	bl	0x1004f3bf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object18allocate_one_field>
100504b90:     	tbnz	w0, #0x0, 0x10050396c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x34>
100504b94:     	b	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504b98:     	cmp	w8, #0x2
100504b9c:     	b.eq	0x100504bd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504ba0:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504ba4:     	add	x1, x1, #0x518
100504ba8:     	mov	x0, x20
100504bac:     	bl	0x100a1e1dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504bb0:     	strb	wzr, [x20, #0x20]
100504bb4:     	ldr	x8, [x20]
100504bb8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504bbc:     	cmp	x8, x9
100504bc0:     	b.lo	0x1005043c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa90>
100504bc4:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100504bc8:     	add	x0, x0, #0x3f8
100504bcc:     	bl	0x100b104dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100504bd0:     	cmp	w8, #0x2
100504bd4:     	b.ne	0x100504c58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1320>
100504bd8:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100504bdc:     	add	x0, x0, #0xc18
100504be0:     	bl	0x100b5635c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100504be4:     	sub	x8, x19, #0x1
100504be8:     	cmp	x8, #0x7
100504bec:     	b.eq	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504bf0:     	ldrb	w8, [x21, #0x1b]
100504bf4:     	cmp	w8, #0x22
100504bf8:     	b.ne	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504bfc:     	mov	w23, #0x0               ; =0
100504c00:     	mov	w28, #0x0               ; =0
100504c04:     	mov	w27, #0x0               ; =0
100504c08:     	mov	w26, #0x0               ; =0
100504c0c:     	mov	w20, #0x5               ; =5
100504c10:     	b	0x100503af0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100504c14:     	ldrb	w8, [x8]
100504c18:     	orr	w8, w8, #0x20
100504c1c:     	cmp	w8, #0x7b
100504c20:     	b.eq	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504c24:     	sub	x11, x19, #0x5
100504c28:     	mov	x10, #0x2600            ; =9728
100504c2c:     	movk	x10, #0x1, lsl #32
100504c30:     	add	x8, x21, x20
100504c34:     	ldrb	w9, [x8, #0x18]
100504c38:     	cmp	w9, #0x20
100504c3c:     	b.hi	0x100504c80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1348>
100504c40:     	lsr	x12, x10, x9
100504c44:     	tbz	w12, #0x0, 0x100504c80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1348>
100504c48:     	add	x20, x20, #0x1
100504c4c:     	cmp	x11, x20
100504c50:     	b.ne	0x100504c30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12f8>
100504c54:     	b	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504c58:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504c5c:     	add	x1, x1, #0x518
100504c60:     	mov	x0, x20
100504c64:     	bl	0x100a1e1dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504c68:     	strb	wzr, [x20, #0x20]
100504c6c:     	ldr	x8, [x20]
100504c70:     	cbz	x8, 0x100504530 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbf8>
100504c74:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100504c78:     	add	x0, x0, #0x488
100504c7c:     	bl	0x100b104ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100504c80:     	cmp	x11, x20
100504c84:     	b.eq	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504c88:     	add	x13, x21, #0x12
100504c8c:     	mov	x14, #0x2600            ; =9728
100504c90:     	movk	x14, #0x1, lsl #32
100504c94:     	mov	x10, x20
100504c98:     	ldrb	w12, [x13, x19]
100504c9c:     	cmp	w12, #0x20
100504ca0:     	b.hi	0x100504cd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1398>
100504ca4:     	lsr	x15, x14, x12
100504ca8:     	tbz	w15, #0x0, 0x100504cd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1398>
100504cac:     	sub	x13, x13, #0x1
100504cb0:     	add	x10, x10, #0x1
100504cb4:     	cmp	x11, x10
100504cb8:     	b.ne	0x100504c98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1360>
100504cbc:     	b	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504cc0:     	adrp	x2, 0x100f07000 <__RNvNtCs3gRpqoBkMHm_13perry_runtime7promise28ITER_RESULT_VALUE_IS_RAW_I32+0x40>
100504cc4:     	add	x2, x2, #0x170
100504cc8:     	mov	x1, x25
100504ccc:     	bl	0x100b1060c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100504cd0:     	sub	x11, x19, x10
100504cd4:     	sub	x1, x11, #0x5
100504cd8:     	cmp	x1, #0x4
100504cdc:     	b.eq	0x100504d48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1410>
100504ce0:     	cmp	x1, #0x5
100504ce4:     	b.ne	0x100504d50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1418>
100504ce8:     	cmp	w9, #0x22
100504cec:     	b.eq	0x100504d7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1444>
100504cf0:     	cmp	w9, #0x2d
100504cf4:     	b.eq	0x100504d6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1434>
100504cf8:     	cmp	w9, #0x66
100504cfc:     	b.ne	0x100504d60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1428>
100504d00:     	add	x8, x21, x20
100504d04:     	ldrb	w9, [x8, #0x19]
100504d08:     	cmp	w9, #0x61
100504d0c:     	b.ne	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d10:     	ldrb	w8, [x8, #0x1a]
100504d14:     	cmp	w8, #0x6c
100504d18:     	b.ne	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d1c:     	add	x8, x21, x20
100504d20:     	ldrb	w9, [x8, #0x1b]
100504d24:     	cmp	w9, #0x73
100504d28:     	b.ne	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d2c:     	ldrb	w8, [x8, #0x1c]
100504d30:     	cmp	w8, #0x65
100504d34:     	b.ne	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d38:     	mov	x8, #0x1                ; =1
100504d3c:     	movk	x8, #0x7ffc, lsl #48
100504d40:     	orr	x1, x8, #0x2
100504d44:     	b	0x100504b88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100504d48:     	cmp	w9, #0x6d
100504d4c:     	b.gt	0x100504de8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14b0>
100504d50:     	cmp	w9, #0x22
100504d54:     	b.eq	0x100504d7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1444>
100504d58:     	cmp	w9, #0x2d
100504d5c:     	b.eq	0x100504d6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1434>
100504d60:     	sub	w9, w9, #0x30
100504d64:     	cmp	w9, #0xa
100504d68:     	b.hs	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d6c:     	add	x0, x8, #0x18
100504d70:     	bl	0x1004eb7d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar12parse_number>
100504d74:     	tbz	w0, #0x0, 0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d78:     	b	0x100504b88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100504d7c:     	sub	x8, x19, #0x6
100504d80:     	cmp	x8, x10
100504d84:     	b.eq	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d88:     	cmp	x1, #0x7
100504d8c:     	b.hi	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d90:     	cmp	w12, #0x22
100504d94:     	b.ne	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d98:     	sub	x23, x11, #0x7
100504d9c:     	sub	x8, x19, #0x7
100504da0:     	add	x9, x21, x20
100504da4:     	add	x22, x9, #0x19
100504da8:     	cmp	x8, x10
100504dac:     	b.ne	0x100504e70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1538>
100504db0:     	add	x8, sp, #0xa0
100504db4:     	mov	x0, x22
100504db8:     	mov	x1, x23
100504dbc:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100504dc0:     	ldr	x8, [sp, #0xa0]
100504dc4:     	cbnz	x8, 0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504dc8:     	cmp	x23, #0x2
100504dcc:     	b.gt	0x100504ea0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1568>
100504dd0:     	cbz	x23, 0x100504ebc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1584>
100504dd4:     	cmp	x23, #0x1
100504dd8:     	b.ne	0x100504ec4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x158c>
100504ddc:     	ldrb	w8, [x22]
100504de0:     	mov	x9, #0x10000000000      ; =1099511627776
100504de4:     	b	0x100504f10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
100504de8:     	cmp	w9, #0x74
100504dec:     	b.eq	0x100504e34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14fc>
100504df0:     	cmp	w9, #0x6e
100504df4:     	b.ne	0x100504d60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1428>
100504df8:     	add	x8, x21, x20
100504dfc:     	ldrb	w9, [x8, #0x19]
100504e00:     	cmp	w9, #0x75
100504e04:     	b.ne	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e08:     	ldrb	w8, [x8, #0x1a]
100504e0c:     	cmp	w8, #0x6c
100504e10:     	b.ne	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e14:     	add	x8, x21, x20
100504e18:     	ldrb	w8, [x8, #0x1b]
100504e1c:     	cmp	w8, #0x6c
100504e20:     	b.ne	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e24:     	mov	x8, #0x1                ; =1
100504e28:     	movk	x8, #0x7ffc, lsl #48
100504e2c:     	add	x1, x8, #0x1
100504e30:     	b	0x100504b88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100504e34:     	add	x8, x21, x20
100504e38:     	ldrb	w9, [x8, #0x19]
100504e3c:     	cmp	w9, #0x72
100504e40:     	b.ne	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e44:     	ldrb	w8, [x8, #0x1a]
100504e48:     	cmp	w8, #0x75
100504e4c:     	b.ne	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e50:     	add	x8, x21, x20
100504e54:     	ldrb	w8, [x8, #0x1b]
100504e58:     	cmp	w8, #0x65
100504e5c:     	b.ne	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e60:     	mov	x8, #0x1                ; =1
100504e64:     	movk	x8, #0x7ffc, lsl #48
100504e68:     	add	x1, x8, #0x3
100504e6c:     	b	0x100504b88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100504e70:     	mov	x8, x23
100504e74:     	mov	x9, x22
100504e78:     	ldrb	w10, [x9], #0x1
100504e7c:     	cmp	w10, #0x20
100504e80:     	b.lo	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e84:     	cmp	w10, #0x22
100504e88:     	b.eq	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e8c:     	cmp	w10, #0x5c
100504e90:     	b.eq	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e94:     	subs	x8, x8, #0x1
100504e98:     	b.ne	0x100504e78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1540>
100504e9c:     	b	0x100504db0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1478>
100504ea0:     	cmp	x23, #0x3
100504ea4:     	b.eq	0x100504edc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15a4>
100504ea8:     	cmp	x23, #0x4
100504eac:     	b.ne	0x100504efc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15c4>
100504eb0:     	ldr	w8, [x22]
100504eb4:     	mov	x9, #0x40000000000      ; =4398046511104
100504eb8:     	b	0x100504f10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
100504ebc:     	mov	x1, #0x7ff9000000000000 ; =9221401712017801216
100504ec0:     	b	0x100504b88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100504ec4:     	ldrb	w8, [x22]
100504ec8:     	add	x9, x21, x20
100504ecc:     	ldrb	w9, [x9, #0x1a]
100504ed0:     	orr	x8, x8, x9, lsl #8
100504ed4:     	mov	x9, #0x20000000000      ; =2199023255552
100504ed8:     	b	0x100504f10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
100504edc:     	ldrb	w8, [x22]
100504ee0:     	add	x9, x21, x20
100504ee4:     	ldrb	w10, [x9, #0x1a]
100504ee8:     	ldrb	w9, [x9, #0x1b]
100504eec:     	orr	x8, x8, x10, lsl #8
100504ef0:     	orr	x8, x8, x9, lsl #16
100504ef4:     	mov	x9, #0x30000000000      ; =3298534883328
100504ef8:     	b	0x100504f10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
100504efc:     	ldr	w8, [x22]
100504f00:     	add	x9, x21, x20
100504f04:     	ldrb	w9, [x9, #0x1d]
100504f08:     	orr	x8, x8, x9, lsl #32
100504f0c:     	mov	x9, #0x50000000000      ; =5497558138880
100504f10:     	movk	x9, #0x7ff9, lsl #48
100504f14:     	orr	x1, x8, x9
100504f18:     	b	0x100504b88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100504f1c:     	bl	0x100b4383c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
100504f20:     	adrp	x0, 0x100c73000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x719c>
100504f24:     	add	x0, x0, #0x320
100504f28:     	mov	w1, #0x21               ; =33
100504f2c:     	bl	0x1005063e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
