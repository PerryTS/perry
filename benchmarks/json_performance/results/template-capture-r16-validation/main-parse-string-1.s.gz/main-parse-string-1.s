
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/template-capture-r16/main-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001005e8a84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>:
1005e8a84:     	sub	sp, sp, #0x60
1005e8a88:     	stp	x24, x23, [sp, #0x20]
1005e8a8c:     	stp	x22, x21, [sp, #0x30]
1005e8a90:     	stp	x20, x19, [sp, #0x40]
1005e8a94:     	stp	x29, x30, [sp, #0x50]
1005e8a98:     	add	x29, sp, #0x50
1005e8a9c:     	mov	x19, x1
1005e8aa0:     	cmp	x2, #0x40
1005e8aa4:     	b.hs	0x1005e8bd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x154>
1005e8aa8:     	ands	x8, x2, #0x38
1005e8aac:     	b.eq	0x1005e8ad0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4c>
1005e8ab0:     	and	x9, x2, #0x38
1005e8ab4:     	neg	x9, x9
1005e8ab8:     	mov	x10, x19
1005e8abc:     	ldr	x11, [x10], #0x8
1005e8ac0:     	tst	x11, #0x8080808080808080
1005e8ac4:     	b.ne	0x1005e8b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8ac8:     	adds	x9, x9, #0x8
1005e8acc:     	b.ne	0x1005e8abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x38>
1005e8ad0:     	mov	x20, x2
1005e8ad4:     	and	x9, x2, #0x7
1005e8ad8:     	cbz	x9, 0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8adc:     	add	x8, x19, x8
1005e8ae0:     	ldrsb	w10, [x8]
1005e8ae4:     	tbnz	w10, #0x1f, 0x1005e8b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8ae8:     	mov	x20, x2
1005e8aec:     	cmp	x9, #0x1
1005e8af0:     	b.eq	0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8af4:     	ldrsb	w10, [x8, #0x1]
1005e8af8:     	tbnz	w10, #0x1f, 0x1005e8b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8afc:     	mov	x20, x2
1005e8b00:     	cmp	x9, #0x2
1005e8b04:     	b.eq	0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8b08:     	ldrsb	w10, [x8, #0x2]
1005e8b0c:     	tbnz	w10, #0x1f, 0x1005e8b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8b10:     	mov	x20, x2
1005e8b14:     	cmp	x9, #0x3
1005e8b18:     	b.eq	0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8b1c:     	ldrsb	w10, [x8, #0x3]
1005e8b20:     	tbnz	w10, #0x1f, 0x1005e8b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8b24:     	mov	x20, x2
1005e8b28:     	cmp	x9, #0x4
1005e8b2c:     	b.eq	0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8b30:     	ldrsb	w10, [x8, #0x4]
1005e8b34:     	tbnz	w10, #0x1f, 0x1005e8b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8b38:     	mov	x20, x2
1005e8b3c:     	cmp	x9, #0x5
1005e8b40:     	b.eq	0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8b44:     	ldrsb	w10, [x8, #0x5]
1005e8b48:     	tbnz	w10, #0x1f, 0x1005e8b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8b4c:     	mov	x20, x2
1005e8b50:     	cmp	x9, #0x6
1005e8b54:     	b.eq	0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8b58:     	ldrsb	w8, [x8, #0x6]
1005e8b5c:     	mov	x20, x2
1005e8b60:     	tbz	w8, #0x1f, 0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8b64:     	cbz	w2, 0x1005e8c64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1e0>
1005e8b68:     	mov	x20, x2
1005e8b6c:     	mov	w21, w2
1005e8b70:     	cbz	x21, 0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8b74:     	mov	x8, x19
1005e8b78:     	ands	x9, x2, #0x3
1005e8b7c:     	b.eq	0x1005e8b98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x114>
1005e8b80:     	mov	x8, x19
1005e8b84:     	ldrsb	w10, [x8]
1005e8b88:     	tbnz	w10, #0x1f, 0x1005e8c7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005e8b8c:     	add	x8, x8, #0x1
1005e8b90:     	subs	x9, x9, #0x1
1005e8b94:     	b.ne	0x1005e8b84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x100>
1005e8b98:     	mov	x20, x2
1005e8b9c:     	cmp	x21, #0x4
1005e8ba0:     	b.lo	0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8ba4:     	add	x9, x19, x21
1005e8ba8:     	ldrsb	w10, [x8]
1005e8bac:     	tbnz	w10, #0x1f, 0x1005e8c7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005e8bb0:     	ldrsb	w10, [x8, #0x1]
1005e8bb4:     	tbnz	w10, #0x1f, 0x1005e8c7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005e8bb8:     	ldrsb	w10, [x8, #0x2]
1005e8bbc:     	tbnz	w10, #0x1f, 0x1005e8c7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005e8bc0:     	ldrsb	w10, [x8, #0x3]
1005e8bc4:     	tbnz	w10, #0x1f, 0x1005e8c7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005e8bc8:     	add	x8, x8, #0x4
1005e8bcc:     	cmp	x8, x9
1005e8bd0:     	b.ne	0x1005e8ba8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x124>
1005e8bd4:     	b	0x1005e8c5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1d8>
1005e8bd8:     	and	x8, x2, #0x7fffffffffffffc0
1005e8bdc:     	add	x8, x19, x8
1005e8be0:     	mov	x9, x19
1005e8be4:     	ldp	q0, q1, [x9]
1005e8be8:     	ldp	q2, q3, [x9, #0x20]
1005e8bec:     	orr.16b	v0, v1, v0
1005e8bf0:     	orr.16b	v1, v2, v3
1005e8bf4:     	orr.16b	v0, v0, v1
1005e8bf8:     	umaxv.16b	b0, v0
1005e8bfc:     	fmov	w10, s0
1005e8c00:     	tbnz	w10, #0x7, 0x1005e8b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8c04:     	add	x9, x9, #0x40
1005e8c08:     	cmp	x9, x8
1005e8c0c:     	b.ne	0x1005e8be4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x160>
1005e8c10:     	ands	x9, x2, #0x30
1005e8c14:     	b.eq	0x1005e8c38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1b4>
1005e8c18:     	mov	x10, x9
1005e8c1c:     	mov	x11, x8
1005e8c20:     	ldr	q0, [x11], #0x10
1005e8c24:     	umaxv.16b	b0, v0
1005e8c28:     	fmov	w12, s0
1005e8c2c:     	tbnz	w12, #0x7, 0x1005e8b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8c30:     	subs	x10, x10, #0x10
1005e8c34:     	b.ne	0x1005e8c20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x19c>
1005e8c38:     	mov	x20, x2
1005e8c3c:     	and	x10, x2, #0xf
1005e8c40:     	cbz	x10, 0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8c44:     	add	x8, x8, x9
1005e8c48:     	ldrsb	w9, [x8]
1005e8c4c:     	tbnz	w9, #0x1f, 0x1005e8b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8c50:     	add	x8, x8, #0x1
1005e8c54:     	subs	x10, x10, #0x1
1005e8c58:     	b.ne	0x1005e8c48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1c4>
1005e8c5c:     	mov	x20, x2
1005e8c60:     	b	0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8c64:     	mov	w20, #0x0               ; =0
1005e8c68:     	mov	w8, #0x14               ; =20
1005e8c6c:     	orr	x8, x2, x8
1005e8c70:     	ldr	x9, [x0]
1005e8c74:     	cbnz	x9, 0x1005e8d4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x2c8>
1005e8c78:     	b	0x1005e8d88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005e8c7c:     	mov	x22, x0
1005e8c80:     	mov	x23, x2
1005e8c84:     	cmp	w2, #0x3f
1005e8c88:     	b.ls	0x1005e8dd4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x350>
1005e8c8c:     	mov	x0, x19
1005e8c90:     	mov	x1, x21
1005e8c94:     	bl	0x1005e84a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
1005e8c98:     	mov	x20, x0
1005e8c9c:     	mov	x2, x23
1005e8ca0:     	mov	x0, x22
1005e8ca4:     	lsr	w8, w2, #19
1005e8ca8:     	cbz	w8, 0x1005e8d40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x2bc>
1005e8cac:     	mov	w23, w2
1005e8cb0:     	add	x0, x23, #0x14
1005e8cb4:     	mov	w1, #0x3                ; =3
1005e8cb8:     	mov	x22, x2
1005e8cbc:     	bl	0x100455f00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
1005e8cc0:     	mov	x21, x0
1005e8cc4:     	stp	w20, w22, [x0]
1005e8cc8:     	str	w22, [x0, #0x8]
1005e8ccc:     	mov	x8, #0x200000000        ; =8589934592
1005e8cd0:     	stur	x8, [x0, #0xc]
1005e8cd4:     	add	x0, x0, #0x14
1005e8cd8:     	mov	x1, x19
1005e8cdc:     	mov	x2, x22
1005e8ce0:     	bl	0x100b5fbac <_writev+0x100b5fbac>
1005e8ce4:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1005e8ce8:     	ldr	w19, [x8, #0x590]
1005e8cec:     	cmp	w19, #0x300
1005e8cf0:     	b.hs	0x1005e8ed8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x454>
1005e8cf4:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1005e8cf8:     	ldr	x8, [x8, #0x48]
1005e8cfc:     	cmn	x8, #0x1
1005e8d00:     	b.eq	0x1005e8ec8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x444>
1005e8d04:     	mrs	x9, TPIDRRO_EL0
1005e8d08:     	and	x9, x9, #0xfffffffffffffff8
1005e8d0c:     	ldr	x0, [x9, x8, lsl #3]
1005e8d10:     	cbz	x0, 0x1005e8ec8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x444>
1005e8d14:     	add	x8, x0, x19, lsl #3
1005e8d18:     	ldr	x0, [x8, #0x1e8]
1005e8d1c:     	cbz	x0, 0x1005e8ed8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x454>
1005e8d20:     	ldr	x8, [x0]
1005e8d24:     	adds	x8, x8, x23
1005e8d28:     	csinv	x8, x8, xzr, lo
1005e8d2c:     	str	x8, [x0]
1005e8d30:     	lsr	x8, x8, #25
1005e8d34:     	cbz	x8, 0x1005e8db8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x334>
1005e8d38:     	bl	0x10045ce34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
1005e8d3c:     	b	0x1005e8db8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x334>
1005e8d40:     	add	x8, x2, #0x14
1005e8d44:     	ldr	x9, [x0]
1005e8d48:     	cbz	x9, 0x1005e8d88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005e8d4c:     	add	x9, x8, #0xf
1005e8d50:     	and	x9, x9, #0xfffffffffffffff8
1005e8d54:     	cmp	x9, #0x4, lsl #12       ; =0x4000
1005e8d58:     	b.hi	0x1005e8d88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005e8d5c:     	ldr	x10, [x0, #0x10]
1005e8d60:     	ldrb	w10, [x10]
1005e8d64:     	tbnz	w10, #0x0, 0x1005e8d88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005e8d68:     	ldr	x10, [x0, #0x8]
1005e8d6c:     	ldp	x11, x12, [x10, #0x8]
1005e8d70:     	add	x11, x11, #0x7
1005e8d74:     	and	x11, x11, #0xfffffffffffffff8
1005e8d78:     	subs	x12, x12, x11
1005e8d7c:     	csel	x12, xzr, x12, lo
1005e8d80:     	cmp	x9, x12
1005e8d84:     	b.ls	0x1005e8e60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x3dc>
1005e8d88:     	mov	x0, x2
1005e8d8c:     	mov	x22, x2
1005e8d90:     	bl	0x100348d2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
1005e8d94:     	mov	x21, x0
1005e8d98:     	mov	x0, x1
1005e8d9c:     	stp	w20, w22, [x21]
1005e8da0:     	str	w22, [x21, #0x8]
1005e8da4:     	mov	x8, #0x200000000        ; =8589934592
1005e8da8:     	stur	x8, [x21, #0xc]
1005e8dac:     	mov	x1, x19
1005e8db0:     	mov	x2, x22
1005e8db4:     	bl	0x100b5fbac <_writev+0x100b5fbac>
1005e8db8:     	mov	x0, x21
1005e8dbc:     	ldp	x29, x30, [sp, #0x50]
1005e8dc0:     	ldp	x20, x19, [sp, #0x40]
1005e8dc4:     	ldp	x22, x21, [sp, #0x30]
1005e8dc8:     	ldp	x24, x23, [sp, #0x20]
1005e8dcc:     	add	sp, sp, #0x60
1005e8dd0:     	ret
1005e8dd4:     	add	x8, sp, #0x8
1005e8dd8:     	mov	x0, x19
1005e8ddc:     	mov	x1, x21
1005e8de0:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
1005e8de4:     	ldr	x8, [sp, #0x8]
1005e8de8:     	cbz	x8, 0x1005e8ea0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x41c>
1005e8dec:     	mov	w20, #0x0               ; =0
1005e8df0:     	mov	x8, #0x0                ; =0
1005e8df4:     	mov	w9, #0x2                ; =2
1005e8df8:     	mov	w10, #0x3               ; =3
1005e8dfc:     	mov	w11, #0x4               ; =4
1005e8e00:     	mov	x2, x23
1005e8e04:     	mov	x0, x22
1005e8e08:     	b	0x1005e8e20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x39c>
1005e8e0c:     	add	w20, w20, #0x1
1005e8e10:     	mov	w12, #0x1               ; =1
1005e8e14:     	add	x8, x12, x8
1005e8e18:     	cmp	x8, x21
1005e8e1c:     	b.hs	0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8e20:     	ldrsb	w12, [x19, x8]
1005e8e24:     	tbz	w12, #0x1f, 0x1005e8e0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x388>
1005e8e28:     	and	w12, w12, #0xff
1005e8e2c:     	cmp	w12, #0xc0
1005e8e30:     	b.lo	0x1005e8e10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x38c>
1005e8e34:     	cmp	w12, #0xf0
1005e8e38:     	add	w13, w20, #0x2
1005e8e3c:     	csel	x14, x10, x11, lo
1005e8e40:     	csinc	w13, w13, w20, hs
1005e8e44:     	cmp	w12, #0xe0
1005e8e48:     	csel	x12, x9, x14, lo
1005e8e4c:     	csinc	w20, w13, w20, hs
1005e8e50:     	add	x8, x12, x8
1005e8e54:     	cmp	x8, x21
1005e8e58:     	b.lo	0x1005e8e20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x39c>
1005e8e5c:     	b	0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8e60:     	ldr	x12, [x10]
1005e8e64:     	add	x22, x12, x11
1005e8e68:     	add	x11, x11, x9
1005e8e6c:     	str	x11, [x10, #0x8]
1005e8e70:     	mov	w10, #0x203             ; =515
1005e8e74:     	stp	w10, w9, [x22]
1005e8e78:     	add	x21, x22, #0x8
1005e8e7c:     	sub	x10, x9, #0x8
1005e8e80:     	subs	x10, x10, x8
1005e8e84:     	csel	x1, xzr, x10, lo
1005e8e88:     	b.ls	0x1005e8f2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4a8>
1005e8e8c:     	cmp	x1, #0x9
1005e8e90:     	b.hs	0x1005e8f1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x498>
1005e8e94:     	add	x8, x22, x9
1005e8e98:     	stur	xzr, [x8, #-0x8]
1005e8e9c:     	b	0x1005e8f2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4a8>
1005e8ea0:     	ldr	x8, [sp, #0x18]
1005e8ea4:     	mov	x2, x23
1005e8ea8:     	mov	x0, x22
1005e8eac:     	cbz	x8, 0x1005e8f00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x47c>
1005e8eb0:     	ldr	x9, [sp, #0x10]
1005e8eb4:     	cmp	x8, #0x8
1005e8eb8:     	b.hs	0x1005e8f08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x484>
1005e8ebc:     	mov	x10, #0x0               ; =0
1005e8ec0:     	mov	w20, #0x0               ; =0
1005e8ec4:     	b	0x1005e91fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x778>
1005e8ec8:     	bl	0x100b3d13c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005e8ecc:     	add	x8, x0, x19, lsl #3
1005e8ed0:     	ldr	x0, [x8, #0x1e8]
1005e8ed4:     	cbnz	x0, 0x1005e8d20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x29c>
1005e8ed8:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1005e8edc:     	add	x0, x0, #0x78
1005e8ee0:     	bl	0x100b3a95c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1005e8ee4:     	ldr	x8, [x0]
1005e8ee8:     	adds	x8, x8, x23
1005e8eec:     	csinv	x8, x8, xzr, lo
1005e8ef0:     	str	x8, [x0]
1005e8ef4:     	lsr	x8, x8, #25
1005e8ef8:     	cbnz	x8, 0x1005e8d38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x2b4>
1005e8efc:     	b	0x1005e8db8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x334>
1005e8f00:     	mov	w20, #0x0               ; =0
1005e8f04:     	b	0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8f08:     	cmp	x8, #0x20
1005e8f0c:     	b.hs	0x1005e8f48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4c4>
1005e8f10:     	mov	x10, #0x0               ; =0
1005e8f14:     	mov	w20, #0x0               ; =0
1005e8f18:     	b	0x1005e914c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x6c8>
1005e8f1c:     	add	x0, x21, x8
1005e8f20:     	mov	x23, x2
1005e8f24:     	bl	0x100b5f6e4 <_writev+0x100b5f6e4>
1005e8f28:     	mov	x2, x23
1005e8f2c:     	stp	w20, w2, [x22, #0x8]
1005e8f30:     	str	w2, [x22, #0x10]
1005e8f34:     	mov	x8, #0x200000000        ; =8589934592
1005e8f38:     	stur	x8, [x22, #0x14]
1005e8f3c:     	add	x0, x22, #0x1c
1005e8f40:     	mov	x1, x19
1005e8f44:     	b	0x1005e8db4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x330>
1005e8f48:     	movi.2d	v0, #0000000000000000
1005e8f4c:     	and	x11, x8, #0x18
1005e8f50:     	movi.16b	v1, #0xf0
1005e8f54:     	and	x10, x8, #0xffffffffffffffe0
1005e8f58:     	movi.4s	v2, #0x2
1005e8f5c:     	add	x12, x9, #0x10
1005e8f60:     	movi.16b	v4, #0xc0
1005e8f64:     	and	x13, x8, #0xffffffffffffffe0
1005e8f68:     	movi.2d	v3, #0000000000000000
1005e8f6c:     	movi.2d	v6, #0000000000000000
1005e8f70:     	movi.2d	v5, #0000000000000000
1005e8f74:     	movi.2d	v7, #0000000000000000
1005e8f78:     	movi.2d	v16, #0000000000000000
1005e8f7c:     	movi.2d	v17, #0000000000000000
1005e8f80:     	movi.2d	v18, #0000000000000000
1005e8f84:     	ldp	q20, q19, [x12, #-0x10]
1005e8f88:     	cmhi.16b	v21, v1, v20
1005e8f8c:     	sshll2.8h	v22, v21, #0x0
1005e8f90:     	sshll2.4s	v23, v22, #0x0
1005e8f94:     	sshll.4s	v24, v22, #0x0
1005e8f98:     	sshll.8h	v21, v21, #0x0
1005e8f9c:     	sshll2.4s	v25, v21, #0x0
1005e8fa0:     	sshll.4s	v26, v21, #0x0
1005e8fa4:     	cmhi.16b	v27, v1, v19
1005e8fa8:     	sshll2.8h	v28, v27, #0x0
1005e8fac:     	sshll2.4s	v29, v28, #0x0
1005e8fb0:     	sshll.4s	v30, v28, #0x0
1005e8fb4:     	sshll.8h	v27, v27, #0x0
1005e8fb8:     	sshll2.4s	v31, v27, #0x0
1005e8fbc:     	bic.16b	v26, v2, v26
1005e8fc0:     	ssubw.4s	v26, v26, v21
1005e8fc4:     	bic.16b	v25, v2, v25
1005e8fc8:     	ssubw2.4s	v25, v25, v21
1005e8fcc:     	sshll.4s	v21, v27, #0x0
1005e8fd0:     	bic.16b	v24, v2, v24
1005e8fd4:     	ssubw.4s	v24, v24, v22
1005e8fd8:     	bic.16b	v23, v2, v23
1005e8fdc:     	ssubw2.4s	v22, v23, v22
1005e8fe0:     	bic.16b	v21, v2, v21
1005e8fe4:     	ssubw.4s	v21, v21, v27
1005e8fe8:     	bic.16b	v23, v2, v31
1005e8fec:     	ssubw2.4s	v23, v23, v27
1005e8ff0:     	bic.16b	v27, v2, v30
1005e8ff4:     	ssubw.4s	v27, v27, v28
1005e8ff8:     	bic.16b	v29, v2, v29
1005e8ffc:     	ssubw2.4s	v28, v29, v28
1005e9000:     	cmgt.16b	v29, v4, v20
1005e9004:     	sshll2.8h	v30, v29, #0x0
1005e9008:     	ushll2.4s	v31, v30, #0x0
1005e900c:     	bic.16b	v22, v22, v31
1005e9010:     	cmlt.16b	v20, v20, #0
1005e9014:     	sshll.8h	v29, v29, #0x0
1005e9018:     	ushll.4s	v30, v30, #0x0
1005e901c:     	bic.16b	v24, v24, v30
1005e9020:     	ushll2.4s	v30, v29, #0x0
1005e9024:     	bic.16b	v25, v25, v30
1005e9028:     	sshll2.8h	v30, v20, #0x0
1005e902c:     	sshll.8h	v20, v20, #0x0
1005e9030:     	ushll.4s	v29, v29, #0x0
1005e9034:     	bic.16b	v26, v26, v29
1005e9038:     	sshll.4s	v29, v20, #0x0
1005e903c:     	and.16b	v26, v26, v29
1005e9040:     	mvn.16b	v29, v29
1005e9044:     	sub.4s	v26, v26, v29
1005e9048:     	sshll2.4s	v29, v30, #0x0
1005e904c:     	sshll.4s	v30, v30, #0x0
1005e9050:     	sshll2.4s	v20, v20, #0x0
1005e9054:     	and.16b	v25, v25, v20
1005e9058:     	mvn.16b	v20, v20
1005e905c:     	sub.4s	v20, v25, v20
1005e9060:     	cmgt.16b	v25, v4, v19
1005e9064:     	and.16b	v24, v24, v30
1005e9068:     	mvn.16b	v30, v30
1005e906c:     	sub.4s	v24, v24, v30
1005e9070:     	sshll2.8h	v30, v25, #0x0
1005e9074:     	and.16b	v22, v22, v29
1005e9078:     	mvn.16b	v29, v29
1005e907c:     	sub.4s	v22, v22, v29
1005e9080:     	ushll2.4s	v29, v30, #0x0
1005e9084:     	bic.16b	v28, v28, v29
1005e9088:     	cmlt.16b	v19, v19, #0
1005e908c:     	sshll.8h	v25, v25, #0x0
1005e9090:     	ushll.4s	v29, v30, #0x0
1005e9094:     	bic.16b	v27, v27, v29
1005e9098:     	ushll2.4s	v29, v25, #0x0
1005e909c:     	bic.16b	v23, v23, v29
1005e90a0:     	sshll.8h	v29, v19, #0x0
1005e90a4:     	ushll.4s	v25, v25, #0x0
1005e90a8:     	bic.16b	v21, v21, v25
1005e90ac:     	sshll.4s	v25, v29, #0x0
1005e90b0:     	and.16b	v21, v21, v25
1005e90b4:     	mvn.16b	v25, v25
1005e90b8:     	sub.4s	v21, v21, v25
1005e90bc:     	sshll2.8h	v19, v19, #0x0
1005e90c0:     	sshll2.4s	v25, v29, #0x0
1005e90c4:     	and.16b	v23, v23, v25
1005e90c8:     	mvn.16b	v25, v25
1005e90cc:     	sub.4s	v23, v23, v25
1005e90d0:     	sshll.4s	v25, v19, #0x0
1005e90d4:     	and.16b	v27, v27, v25
1005e90d8:     	mvn.16b	v25, v25
1005e90dc:     	sub.4s	v25, v27, v25
1005e90e0:     	sshll2.4s	v19, v19, #0x0
1005e90e4:     	and.16b	v27, v28, v19
1005e90e8:     	mvn.16b	v19, v19
1005e90ec:     	sub.4s	v19, v27, v19
1005e90f0:     	add.4s	v7, v22, v7
1005e90f4:     	add.4s	v5, v24, v5
1005e90f8:     	add.4s	v6, v20, v6
1005e90fc:     	add.4s	v3, v26, v3
1005e9100:     	add.4s	v18, v19, v18
1005e9104:     	add.4s	v17, v25, v17
1005e9108:     	add.4s	v0, v23, v0
1005e910c:     	add.4s	v16, v21, v16
1005e9110:     	add	x12, x12, #0x20
1005e9114:     	subs	x13, x13, #0x20
1005e9118:     	b.ne	0x1005e8f84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x500>
1005e911c:     	add.4s	v0, v0, v6
1005e9120:     	add.4s	v1, v18, v7
1005e9124:     	add.4s	v2, v16, v3
1005e9128:     	add.4s	v3, v17, v5
1005e912c:     	add.4s	v2, v2, v3
1005e9130:     	add.4s	v0, v0, v1
1005e9134:     	add.4s	v0, v2, v0
1005e9138:     	addv.4s	s0, v0
1005e913c:     	fmov	w20, s0
1005e9140:     	cmp	x8, x10
1005e9144:     	b.eq	0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e9148:     	cbz	x11, 0x1005e91fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x778>
1005e914c:     	mov	x12, x10
1005e9150:     	and	x10, x8, #0xfffffffffffffff8
1005e9154:     	movi.2d	v0, #0000000000000000
1005e9158:     	mov.s	v0[0], w20
1005e915c:     	movi.2d	v1, #0000000000000000
1005e9160:     	sub	x11, x12, x10
1005e9164:     	add	x12, x9, x12
1005e9168:     	movi.8b	v2, #0xf0
1005e916c:     	movi.4s	v3, #0x2
1005e9170:     	movi.8b	v4, #0xc0
1005e9174:     	ldr	d5, [x12], #0x8
1005e9178:     	sshll.8h	v6, v5, #0x0
1005e917c:     	cmlt.8h	v6, v6, #0
1005e9180:     	sshll2.4s	v7, v6, #0x0
1005e9184:     	sshll.4s	v6, v6, #0x0
1005e9188:     	cmhi.8b	v16, v2, v5
1005e918c:     	sshll.8h	v16, v16, #0x0
1005e9190:     	sshll2.4s	v17, v16, #0x0
1005e9194:     	sshll.4s	v18, v16, #0x0
1005e9198:     	bic.16b	v18, v3, v18
1005e919c:     	ssubw.4s	v18, v18, v16
1005e91a0:     	bic.16b	v17, v3, v17
1005e91a4:     	ssubw2.4s	v16, v17, v16
1005e91a8:     	cmgt.8b	v5, v4, v5
1005e91ac:     	sshll.8h	v5, v5, #0x0
1005e91b0:     	ushll.4s	v17, v5, #0x0
1005e91b4:     	ushll2.4s	v5, v5, #0x0
1005e91b8:     	bic.16b	v5, v16, v5
1005e91bc:     	bic.16b	v16, v18, v17
1005e91c0:     	and.16b	v16, v16, v6
1005e91c4:     	mvn.16b	v6, v6
1005e91c8:     	sub.4s	v6, v16, v6
1005e91cc:     	and.16b	v5, v5, v7
1005e91d0:     	mvn.16b	v7, v7
1005e91d4:     	sub.4s	v5, v5, v7
1005e91d8:     	add.4s	v1, v5, v1
1005e91dc:     	add.4s	v0, v6, v0
1005e91e0:     	adds	x11, x11, #0x8
1005e91e4:     	b.ne	0x1005e9174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x6f0>
1005e91e8:     	add.4s	v0, v0, v1
1005e91ec:     	addv.4s	s0, v0
1005e91f0:     	fmov	w20, s0
1005e91f4:     	cmp	x8, x10
1005e91f8:     	b.eq	0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e91fc:     	sub	x8, x8, x10
1005e9200:     	add	x9, x9, x10
1005e9204:     	mov	w10, #0x1               ; =1
1005e9208:     	ldrsb	w11, [x9], #0x1
1005e920c:     	and	w12, w11, #0xff
1005e9210:     	cmp	w12, #0xf0
1005e9214:     	cinc	w13, w10, hs
1005e9218:     	cmp	w12, #0xc0
1005e921c:     	csel	w12, wzr, w13, lo
1005e9220:     	tst	w11, #0x80000000
1005e9224:     	csinc	w11, w12, wzr, ne
1005e9228:     	add	w20, w11, w20
1005e922c:     	subs	x8, x8, #0x1
1005e9230:     	b.ne	0x1005e9208 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x784>
1005e9234:     	b	0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
