
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/template-capture-r16/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001004eabc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template>:
1004eabc0:     	stp	x28, x27, [sp, #-0x60]!
1004eabc4:     	stp	x26, x25, [sp, #0x10]
1004eabc8:     	stp	x24, x23, [sp, #0x20]
1004eabcc:     	stp	x22, x21, [sp, #0x30]
1004eabd0:     	stp	x20, x19, [sp, #0x40]
1004eabd4:     	stp	x29, x30, [sp, #0x50]
1004eabd8:     	add	x29, sp, #0x50
1004eabdc:     	sub	sp, sp, #0x500
1004eabe0:     	ldr	xzr, [sp]
1004eabe4:     	sub	x8, x1, #0x41
1004eabe8:     	lsr	x9, x2, #48
1004eabec:     	mov	w10, #0x7ffd            ; =32765
1004eabf0:     	cmp	x9, x10
1004eabf4:     	mov	w9, #0x7bf              ; =1983
1004eabf8:     	ccmp	x8, x9, #0x2, eq
1004eabfc:     	ccmp	x0, #0x0, #0x4, ls
1004eac00:     	b.eq	0x1004eb174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5b4>
1004eac04:     	and	x23, x2, #0xffffffffffff
1004eac08:     	ldurb	w8, [x23, #-0x8]
1004eac0c:     	cmp	w8, #0x2
1004eac10:     	b.ne	0x1004eb174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5b4>
1004eac14:     	ldr	w8, [x23, #0x4]
1004eac18:     	mov	w9, #-0x40000000        ; =-1073741824
1004eac1c:     	cmp	w8, w9
1004eac20:     	csel	w8, w8, wzr, lt
1004eac24:     	str	x0, [sp, #0x10]
1004eac28:     	mov	x0, x8
1004eac2c:     	mov	x19, x1
1004eac30:     	bl	0x1005e32a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
1004eac34:     	ldr	x9, [sp, #0x10]
1004eac38:     	tst	w0, #0x1
1004eac3c:     	csel	w20, w1, wzr, ne
1004eac40:     	cmp	w20, #0x8
1004eac44:     	b.hi	0x1004eb174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5b4>
1004eac48:     	mov	x8, x19
1004eac4c:     	add	x25, sp, #0x270
1004eac50:     	adrp	x10, 0x100c73000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x719c>
1004eac54:     	add	x10, x10, #0xc0
1004eac58:     	ldp	q0, q1, [x10]
1004eac5c:     	stp	q0, q1, [x25]
1004eac60:     	ldp	q2, q3, [x10, #0x20]
1004eac64:     	stp	q2, q3, [x25, #0x20]
1004eac68:     	str	xzr, [sp, #0x2b0]
1004eac6c:     	str	xzr, [sp, #0x2f8]
1004eac70:     	stur	q0, [x25, #0x48]
1004eac74:     	stur	q1, [x25, #0x58]
1004eac78:     	stur	q2, [x25, #0x68]
1004eac7c:     	stur	q3, [x25, #0x78]
1004eac80:     	stp	q0, q1, [x25, #0x90]
1004eac84:     	stp	q2, q3, [x25, #0xb0]
1004eac88:     	add	x26, sp, #0x270
1004eac8c:     	add	x10, x26, #0xd8
1004eac90:     	str	q3, [x10, #0x30]
1004eac94:     	str	xzr, [sp, #0x340]
1004eac98:     	str	xzr, [sp, #0x388]
1004eac9c:     	stur	q2, [x25, #0xf8]
1004eaca0:     	stur	q1, [x25, #0xe8]
1004eaca4:     	stur	q0, [x25, #0xd8]
1004eaca8:     	stp	q2, q3, [x25, #0x140]
1004eacac:     	stp	q0, q1, [x25, #0x120]
1004eacb0:     	add	x10, x26, #0x168
1004eacb4:     	stp	q0, q1, [x10]
1004eacb8:     	stp	q2, q3, [x10, #0x20]
1004eacbc:     	str	xzr, [sp, #0x3d0]
1004eacc0:     	str	xzr, [sp, #0x418]
1004eacc4:     	stp	q2, q3, [x25, #0x1d0]
1004eacc8:     	stp	q0, q1, [x25, #0x1b0]
1004eaccc:     	add	x10, x26, #0x1f8
1004eacd0:     	stp	q2, q3, [x10, #0x20]
1004eacd4:     	stp	q0, q1, [x10]
1004eacd8:     	str	xzr, [sp, #0x460]
1004eacdc:     	str	xzr, [sp, #0x4a8]
1004eace0:     	str	x9, [sp, #0x258]
1004eace4:     	strh	w8, [sp, #0x26c]
1004eace8:     	str	xzr, [sp, #0x260]
1004eacec:     	str	wzr, [sp, #0x268]
1004eacf0:     	add	x19, sp, #0x18
1004eacf4:     	add	x0, sp, #0x18
1004eacf8:     	add	x1, sp, #0x270
1004eacfc:     	mov	w2, #0x240              ; =576
1004ead00:     	bl	0x100b5fbac <_writev+0x100b5fbac>
1004ead04:     	strb	w20, [sp, #0x26e]
1004ead08:     	add	w8, w20, w20, lsl #3
1004ead0c:     	lsl	w21, w8, #3
1004ead10:     	str	w20, [sp, #0xc]
1004ead14:     	cbz	w20, 0x1004eaef8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x338>
1004ead18:     	add	x27, x23, #0x10
1004ead1c:     	add	x28, x19, x21
1004ead20:     	add	x19, sp, #0x18
1004ead24:     	mov	w24, #0x7ffd            ; =32765
1004ead28:     	b	0x1004ead6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x1ac>
1004ead2c:     	mov	w10, #0x0               ; =0
1004ead30:     	ldp	q0, q1, [x25, #0x240]
1004ead34:     	stp	q0, q1, [x25]
1004ead38:     	ldr	q2, [x25, #0x260]
1004ead3c:     	str	q2, [x25, #0x20]
1004ead40:     	ldur	x11, [x29, #-0x70]
1004ead44:     	strb	w10, [x19]
1004ead48:     	strb	w8, [x19, #0x1]
1004ead4c:     	str	x9, [x19, #0x8]
1004ead50:     	stp	q0, q1, [x19, #0x10]
1004ead54:     	str	q2, [x19, #0x30]
1004ead58:     	str	x11, [x19, #0x40]
1004ead5c:     	add	x19, x19, #0x48
1004ead60:     	str	x11, [sp, #0x2a0]
1004ead64:     	cmp	x19, x28
1004ead68:     	b.eq	0x1004eaef8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x338>
1004ead6c:     	ldr	x9, [x27], #0x8
1004ead70:     	cmp	x24, x9, lsr #48
1004ead74:     	b.ne	0x1004ead2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x16c>
1004ead78:     	and	x20, x9, #0xffffffffffff
1004ead7c:     	ldurb	w8, [x20, #-0x8]
1004ead80:     	cmp	w8, #0x1
1004ead84:     	b.ne	0x1004eb174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5b4>
1004ead88:     	ldr	w22, [x20]
1004ead8c:     	cmp	w22, #0x8
1004ead90:     	b.hi	0x1004eb174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5b4>
1004ead94:     	add	x0, sp, #0x270
1004ead98:     	adrp	x1, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x70f0>
1004ead9c:     	add	x1, x1, #0x9f0
1004eada0:     	mov	w2, #0x40               ; =64
1004eada4:     	bl	0x100b5fbd0 <_writev+0x100b5fbd0>
1004eada8:     	cbz	w22, 0x1004eaecc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x30c>
1004eadac:     	mov	x0, x20
1004eadb0:     	mov	w1, #0x0                ; =0
1004eadb4:     	bl	0x1007bb990 <_js_array_get_f64>
1004eadb8:     	fmov	x8, d0
1004eadbc:     	cmp	x24, x8, lsr #48
1004eadc0:     	b.eq	0x1004eb174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5b4>
1004eadc4:     	str	d0, [sp, #0x270]
1004eadc8:     	cmp	w22, #0x1
1004eadcc:     	b.eq	0x1004eaec4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x304>
1004eadd0:     	mov	x0, x20
1004eadd4:     	mov	w1, #0x1                ; =1
1004eadd8:     	bl	0x1007bb990 <_js_array_get_f64>
1004eaddc:     	fmov	x8, d0
1004eade0:     	cmp	x24, x8, lsr #48
1004eade4:     	b.eq	0x1004eb174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5b4>
1004eade8:     	str	d0, [sp, #0x278]
1004eadec:     	cmp	w22, #0x2
1004eadf0:     	b.eq	0x1004eaec4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x304>
1004eadf4:     	mov	x0, x20
1004eadf8:     	mov	w1, #0x2                ; =2
1004eadfc:     	bl	0x1007bb990 <_js_array_get_f64>
1004eae00:     	fmov	x8, d0
1004eae04:     	cmp	x24, x8, lsr #48
1004eae08:     	b.eq	0x1004eb174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5b4>
1004eae0c:     	str	d0, [sp, #0x280]
1004eae10:     	cmp	w22, #0x3
1004eae14:     	b.eq	0x1004eaec4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x304>
1004eae18:     	mov	x0, x20
1004eae1c:     	mov	w1, #0x3                ; =3
1004eae20:     	bl	0x1007bb990 <_js_array_get_f64>
1004eae24:     	fmov	x8, d0
1004eae28:     	cmp	x24, x8, lsr #48
1004eae2c:     	b.eq	0x1004eb174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5b4>
1004eae30:     	str	d0, [sp, #0x288]
1004eae34:     	cmp	w22, #0x4
1004eae38:     	b.eq	0x1004eaec4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x304>
1004eae3c:     	mov	x0, x20
1004eae40:     	mov	w1, #0x4                ; =4
1004eae44:     	bl	0x1007bb990 <_js_array_get_f64>
1004eae48:     	fmov	x8, d0
1004eae4c:     	cmp	x24, x8, lsr #48
1004eae50:     	b.eq	0x1004eb174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5b4>
1004eae54:     	str	d0, [sp, #0x290]
1004eae58:     	cmp	w22, #0x5
1004eae5c:     	b.eq	0x1004eaec4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x304>
1004eae60:     	mov	x0, x20
1004eae64:     	mov	w1, #0x5                ; =5
1004eae68:     	bl	0x1007bb990 <_js_array_get_f64>
1004eae6c:     	fmov	x8, d0
1004eae70:     	cmp	x24, x8, lsr #48
1004eae74:     	b.eq	0x1004eb174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5b4>
1004eae78:     	str	d0, [sp, #0x298]
1004eae7c:     	cmp	w22, #0x6
1004eae80:     	b.eq	0x1004eaec4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x304>
1004eae84:     	mov	x0, x20
1004eae88:     	mov	w1, #0x6                ; =6
1004eae8c:     	bl	0x1007bb990 <_js_array_get_f64>
1004eae90:     	fmov	x8, d0
1004eae94:     	cmp	x24, x8, lsr #48
1004eae98:     	b.eq	0x1004eb174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5b4>
1004eae9c:     	str	d0, [sp, #0x2a0]
1004eaea0:     	cmp	w22, #0x7
1004eaea4:     	b.eq	0x1004eaec4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x304>
1004eaea8:     	mov	x0, x20
1004eaeac:     	mov	w1, #0x7                ; =7
1004eaeb0:     	bl	0x1007bb990 <_js_array_get_f64>
1004eaeb4:     	fmov	x8, d0
1004eaeb8:     	cmp	x24, x8, lsr #48
1004eaebc:     	b.eq	0x1004eb174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5b4>
1004eaec0:     	str	d0, [sp, #0x2a8]
1004eaec4:     	ldr	w8, [x20]
1004eaec8:     	b	0x1004eaed0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x310>
1004eaecc:     	mov	w8, #0x0                ; =0
1004eaed0:     	ldr	x9, [sp, #0x270]
1004eaed4:     	ldur	q0, [x26, #0x8]
1004eaed8:     	ldur	q1, [x26, #0x18]
1004eaedc:     	stp	q0, q1, [x25, #0x240]
1004eaee0:     	ldur	q0, [x26, #0x28]
1004eaee4:     	str	q0, [x25, #0x260]
1004eaee8:     	ldur	x10, [x26, #0x38]
1004eaeec:     	stur	x10, [x29, #-0x70]
1004eaef0:     	mov	w10, #0x1               ; =1
1004eaef4:     	b	0x1004ead30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x170>
1004eaef8:     	ldr	w22, [x23, #0x4]
1004eaefc:     	mov	w8, #-0x40000000        ; =-1073741824
1004eaf00:     	cmp	w22, w8
1004eaf04:     	csel	w19, w22, w8, lt
1004eaf08:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eaf0c:     	ldr	w24, [x8, #0x800]
1004eaf10:     	adrp	x20, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eaf14:     	cmp	w24, #0x300
1004eaf18:     	ldr	x8, [sp, #0x10]
1004eaf1c:     	b.hs	0x1004eafb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3f8>
1004eaf20:     	ldr	x9, [x20, #0x48]
1004eaf24:     	cmn	x9, #0x1
1004eaf28:     	b.eq	0x1004eafa4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3e4>
1004eaf2c:     	mrs	x10, TPIDRRO_EL0
1004eaf30:     	and	x10, x10, #0xfffffffffffffff8
1004eaf34:     	ldr	x0, [x10, x9, lsl #3]
1004eaf38:     	cbz	x0, 0x1004eafa4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3e4>
1004eaf3c:     	add	x9, x0, x24, lsl #3
1004eaf40:     	ldr	x0, [x9, #0x1e8]
1004eaf44:     	cbz	x0, 0x1004eafb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3f8>
1004eaf48:     	ldr	x0, [x0]
1004eaf4c:     	cbz	x0, 0x1004eafd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x410>
1004eaf50:     	mov	w9, #-0x40000001        ; =-1073741825
1004eaf54:     	cmp	w22, w9
1004eaf58:     	ldr	w22, [sp, #0xc]
1004eaf5c:     	b.gt	0x1004eafe8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x428>
1004eaf60:     	ldr	x11, [x0, #0x51d0]
1004eaf64:     	and	w9, w19, #0x3fffffff
1004eaf68:     	lsr	x10, x9, #15
1004eaf6c:     	cmp	x10, x11
1004eaf70:     	b.hs	0x1004eafe8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x428>
1004eaf74:     	ldr	x11, [x0, #0x51c8]
1004eaf78:     	ldr	x10, [x11, x10, lsl #3]
1004eaf7c:     	cbz	x10, 0x1004eafe8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x428>
1004eaf80:     	ubfx	x11, x9, #5, #10
1004eaf84:     	ldr	x10, [x10, x11, lsl #3]
1004eaf88:     	cbz	x10, 0x1004eafe8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x428>
1004eaf8c:     	and	x9, x9, #0x1f
1004eaf90:     	add	x9, x10, x9, lsl #5
1004eaf94:     	ldrb	w10, [x9, #0x1c]
1004eaf98:     	tbz	w10, #0x0, 0x1004eafe8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x428>
1004eaf9c:     	ldr	x19, [x9]
1004eafa0:     	b	0x1004eafec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x42c>
1004eafa4:     	bl	0x100b3d17c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eafa8:     	ldr	x8, [sp, #0x10]
1004eafac:     	add	x9, x0, x24, lsl #3
1004eafb0:     	ldr	x0, [x9, #0x1e8]
1004eafb4:     	cbnz	x0, 0x1004eaf48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x388>
1004eafb8:     	adrp	x0, 0x100f06000 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json25PARSE_KEY_CACHE_OVERSIZED+0x3b0>
1004eafbc:     	add	x0, x0, #0x578
1004eafc0:     	bl	0x100b3a99c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1004eafc4:     	ldr	x8, [sp, #0x10]
1004eafc8:     	ldr	x0, [x0]
1004eafcc:     	cbnz	x0, 0x1004eaf50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x390>
1004eafd0:     	bl	0x100b3c620 <__RNvNtCs3gRpqoBkMHm_13perry_runtime5state10init_state>
1004eafd4:     	ldr	x8, [sp, #0x10]
1004eafd8:     	mov	w9, #-0x40000001        ; =-1073741825
1004eafdc:     	cmp	w22, w9
1004eafe0:     	ldr	w22, [sp, #0xc]
1004eafe4:     	b.le	0x1004eaf60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3a0>
1004eafe8:     	mov	x19, #0x0               ; =0
1004eafec:     	str	x19, [sp, #0x260]
1004eaff0:     	ldr	w9, [x23, #0x4]
1004eaff4:     	mov	w10, #-0x40000000       ; =-1073741824
1004eaff8:     	cmp	w9, w10
1004eaffc:     	csel	w9, w9, wzr, lt
1004eb000:     	str	w9, [sp, #0x268]
1004eb004:     	adrp	x23, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf85c>
1004eb008:     	ldr	w9, [x23, #0x7a4]
1004eb00c:     	cbz	w9, 0x1004eb01c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x45c>
1004eb010:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
1004eb014:     	bfxil	x0, x8, #0, #48
1004eb018:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb01c:     	cbz	x19, 0x1004eb030 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x470>
1004eb020:     	ldr	w8, [x23, #0x7a4]
1004eb024:     	cbz	w8, 0x1004eb030 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x470>
1004eb028:     	mov	x0, x19
1004eb02c:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb030:     	cbz	w22, 0x1004eb128 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x568>
1004eb034:     	add	x8, sp, #0x18
1004eb038:     	add	x22, x8, #0x20
1004eb03c:     	b	0x1004eb04c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x48c>
1004eb040:     	add	x22, x22, #0x48
1004eb044:     	subs	x21, x21, #0x48
1004eb048:     	b.eq	0x1004eb128 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x568>
1004eb04c:     	ldurb	w8, [x22, #-0x20]
1004eb050:     	tbz	w8, #0x0, 0x1004eb114 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x554>
1004eb054:     	ldurb	w19, [x22, #-0x1f]
1004eb058:     	cmp	w19, #0x9
1004eb05c:     	b.hs	0x1004eb1c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x604>
1004eb060:     	cbz	w19, 0x1004eb040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x480>
1004eb064:     	ldur	x0, [x22, #-0x18]
1004eb068:     	ldr	w8, [x23, #0x7a4]
1004eb06c:     	cbz	w8, 0x1004eb074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x4b4>
1004eb070:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb074:     	cmp	w19, #0x1
1004eb078:     	b.eq	0x1004eb040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x480>
1004eb07c:     	ldur	x0, [x22, #-0x10]
1004eb080:     	ldr	w8, [x23, #0x7a4]
1004eb084:     	cbz	w8, 0x1004eb08c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x4cc>
1004eb088:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb08c:     	cmp	w19, #0x2
1004eb090:     	b.eq	0x1004eb040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x480>
1004eb094:     	ldur	x0, [x22, #-0x8]
1004eb098:     	ldr	w8, [x23, #0x7a4]
1004eb09c:     	cbz	w8, 0x1004eb0a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x4e4>
1004eb0a0:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb0a4:     	cmp	w19, #0x3
1004eb0a8:     	b.eq	0x1004eb040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x480>
1004eb0ac:     	ldr	x0, [x22]
1004eb0b0:     	ldr	w8, [x23, #0x7a4]
1004eb0b4:     	cbz	w8, 0x1004eb0bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x4fc>
1004eb0b8:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb0bc:     	cmp	w19, #0x4
1004eb0c0:     	b.eq	0x1004eb040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x480>
1004eb0c4:     	ldr	x0, [x22, #0x8]
1004eb0c8:     	ldr	w8, [x23, #0x7a4]
1004eb0cc:     	cbz	w8, 0x1004eb0d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x514>
1004eb0d0:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb0d4:     	cmp	w19, #0x5
1004eb0d8:     	b.eq	0x1004eb040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x480>
1004eb0dc:     	ldr	x0, [x22, #0x10]
1004eb0e0:     	ldr	w8, [x23, #0x7a4]
1004eb0e4:     	cbz	w8, 0x1004eb0ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x52c>
1004eb0e8:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb0ec:     	cmp	w19, #0x6
1004eb0f0:     	b.eq	0x1004eb040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x480>
1004eb0f4:     	ldr	x0, [x22, #0x18]
1004eb0f8:     	ldr	w8, [x23, #0x7a4]
1004eb0fc:     	cbz	w8, 0x1004eb104 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x544>
1004eb100:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb104:     	cmp	w19, #0x7
1004eb108:     	b.eq	0x1004eb040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x480>
1004eb10c:     	ldr	x0, [x22, #0x20]
1004eb110:     	b	0x1004eb118 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x558>
1004eb114:     	ldur	x0, [x22, #-0x18]
1004eb118:     	ldr	w8, [x23, #0x7a4]
1004eb11c:     	cbz	w8, 0x1004eb040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x480>
1004eb120:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb124:     	b	0x1004eb040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x480>
1004eb128:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1004eb12c:     	ldr	w19, [x8, #0x578]
1004eb130:     	cmp	w19, #0x300
1004eb134:     	b.hs	0x1004eb1a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5e4>
1004eb138:     	ldr	x8, [x20, #0x48]
1004eb13c:     	cmn	x8, #0x1
1004eb140:     	b.eq	0x1004eb194 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5d4>
1004eb144:     	mrs	x9, TPIDRRO_EL0
1004eb148:     	and	x9, x9, #0xfffffffffffffff8
1004eb14c:     	ldr	x0, [x9, x8, lsl #3]
1004eb150:     	cbz	x0, 0x1004eb194 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5d4>
1004eb154:     	add	x8, x0, x19, lsl #3
1004eb158:     	ldr	x0, [x8, #0x1e8]
1004eb15c:     	cbz	x0, 0x1004eb1a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5e4>
1004eb160:     	ldr	x8, [x0], #0x8
1004eb164:     	cbnz	x8, 0x1004eb1b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5f8>
1004eb168:     	add	x1, sp, #0x18
1004eb16c:     	mov	w2, #0x258              ; =600
1004eb170:     	bl	0x100b5fbac <_writev+0x100b5fbac>
1004eb174:     	add	sp, sp, #0x500
1004eb178:     	ldp	x29, x30, [sp, #0x50]
1004eb17c:     	ldp	x20, x19, [sp, #0x40]
1004eb180:     	ldp	x22, x21, [sp, #0x30]
1004eb184:     	ldp	x24, x23, [sp, #0x20]
1004eb188:     	ldp	x26, x25, [sp, #0x10]
1004eb18c:     	ldp	x28, x27, [sp], #0x60
1004eb190:     	ret
1004eb194:     	bl	0x100b3d17c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb198:     	add	x8, x0, x19, lsl #3
1004eb19c:     	ldr	x0, [x8, #0x1e8]
1004eb1a0:     	cbnz	x0, 0x1004eb160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5a0>
1004eb1a4:     	adrp	x0, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1004eb1a8:     	add	x0, x0, #0xfb8
1004eb1ac:     	bl	0x100b3a99c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1004eb1b0:     	ldr	x8, [x0], #0x8
1004eb1b4:     	cbz	x8, 0x1004eb168 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5a8>
1004eb1b8:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004eb1bc:     	add	x0, x0, #0xd28
1004eb1c0:     	bl	0x100b104ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1004eb1c4:     	adrp	x3, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1004eb1c8:     	add	x3, x3, #0xfd0
1004eb1cc:     	mov	x0, #0x0                ; =0
1004eb1d0:     	mov	x1, x19
1004eb1d4:     	mov	w2, #0x8                ; =8
1004eb1d8:     	bl	0x100b107cc <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
