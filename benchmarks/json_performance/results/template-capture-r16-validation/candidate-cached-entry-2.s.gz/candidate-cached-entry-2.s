
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/template-capture-r16/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100842694 <_js_json_parse>:
100842694:     	stp	x29, x30, [sp, #-0x10]!
100842698:     	mov	x29, sp
10084269c:     	cbz	x0, 0x1008426f4 <_js_json_parse+0x60>
1008426a0:     	ldr	w1, [x0, #0x4]
1008426a4:     	cmp	w1, #0x2
1008426a8:     	b.eq	0x1008426b8 <_js_json_parse+0x24>
1008426ac:     	cbz	w1, 0x1008426f4 <_js_json_parse+0x60>
1008426b0:     	ldrb	w8, [x0, #0x14]
1008426b4:     	b	0x1008426d8 <_js_json_parse+0x44>
1008426b8:     	ldrb	w8, [x0, #0x14]
1008426bc:     	cmp	w8, #0x7b
1008426c0:     	b.ne	0x1008426d8 <_js_json_parse+0x44>
1008426c4:     	ldrb	w8, [x0, #0x15]
1008426c8:     	cmp	w8, #0x7d
1008426cc:     	b.ne	0x1008426e4 <_js_json_parse+0x50>
1008426d0:     	ldp	x29, x30, [sp], #0x10
1008426d4:     	b	0x1004ea480 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
1008426d8:     	orr	w8, w8, #0x20
1008426dc:     	cmp	w8, #0x7b
1008426e0:     	b.ne	0x1008426ec <_js_json_parse+0x58>
1008426e4:     	ldp	x29, x30, [sp], #0x10
1008426e8:     	b	0x100503938 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
1008426ec:     	ldp	x29, x30, [sp], #0x10
1008426f0:     	b	0x100505fb4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
1008426f4:     	adrp	x0, 0x100c73000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x719c>
1008426f8:     	add	x0, x0, #0x341
1008426fc:     	mov	w1, #0x1c               ; =28
100842700:     	bl	0x1005063e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
