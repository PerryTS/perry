
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/template-capture-r16/main-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001004eabc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template>:
1004eabc0:     	stp	x28, x27, [sp, #-0x60]!
1004eabc4:     	stp	x26, x25, [sp, #0x10]
1004eabc8:     	stp	x24, x23, [sp, #0x20]
1004eabcc:     	stp	x22, x21, [sp, #0x30]
1004eabd0:     	stp	x20, x19, [sp, #0x40]
1004eabd4:     	stp	x29, x30, [sp, #0x50]
1004eabd8:     	add	x29, sp, #0x50
1004eabdc:     	sub	sp, sp, #0x500
1004eabe0:     	ldr	xzr, [sp]
1004eabe4:     	sub	x8, x1, #0x41
1004eabe8:     	lsr	x9, x2, #48
1004eabec:     	mov	w10, #0x7ffd            ; =32765
1004eabf0:     	cmp	x9, x10
1004eabf4:     	mov	w9, #0x7bf              ; =1983
1004eabf8:     	ccmp	x8, x9, #0x2, eq
1004eabfc:     	ccmp	x0, #0x0, #0x4, ls
1004eac00:     	b.eq	0x1004eb168 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5a8>
1004eac04:     	and	x21, x2, #0xffffffffffff
1004eac08:     	ldurb	w8, [x21, #-0x8]
1004eac0c:     	cmp	w8, #0x2
1004eac10:     	b.ne	0x1004eb168 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5a8>
1004eac14:     	mov	x20, x1
1004eac18:     	mov	x19, x0
1004eac1c:     	ldr	w8, [x21, #0x4]
1004eac20:     	mov	w9, #-0x40000000        ; =-1073741824
1004eac24:     	cmp	w8, w9
1004eac28:     	csel	w0, w8, wzr, lt
1004eac2c:     	bl	0x1005e3264 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
1004eac30:     	tst	w0, #0x1
1004eac34:     	csel	w11, w1, wzr, ne
1004eac38:     	cmp	w11, #0x8
1004eac3c:     	b.hi	0x1004eb168 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5a8>
1004eac40:     	str	x21, [sp, #0x8]
1004eac44:     	add	x9, sp, #0x10
1004eac48:     	str	xzr, [sp, #0x50]
1004eac4c:     	adrp	x8, 0x100c73000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x719c>
1004eac50:     	add	x8, x8, #0xc0
1004eac54:     	ldp	q0, q1, [x8]
1004eac58:     	stp	q0, q1, [sp, #0x10]
1004eac5c:     	ldp	q2, q3, [x8, #0x20]
1004eac60:     	stp	q2, q3, [sp, #0x30]
1004eac64:     	str	xzr, [sp, #0x98]
1004eac68:     	stur	q0, [sp, #0x58]
1004eac6c:     	stur	q1, [sp, #0x68]
1004eac70:     	stur	q2, [sp, #0x78]
1004eac74:     	stur	q3, [sp, #0x88]
1004eac78:     	stp	q0, q1, [sp, #0xa0]
1004eac7c:     	stp	q2, q3, [sp, #0xc0]
1004eac80:     	add	x8, sp, #0x10
1004eac84:     	add	x10, x8, #0xd8
1004eac88:     	str	q3, [x10, #0x30]
1004eac8c:     	str	xzr, [sp, #0xe0]
1004eac90:     	str	xzr, [sp, #0x128]
1004eac94:     	stur	q2, [x9, #0xf8]
1004eac98:     	stur	q1, [x9, #0xe8]
1004eac9c:     	stur	q0, [x9, #0xd8]
1004eaca0:     	stp	q2, q3, [sp, #0x150]
1004eaca4:     	stp	q0, q1, [sp, #0x130]
1004eaca8:     	add	x9, x8, #0x168
1004eacac:     	stp	q0, q1, [x9]
1004eacb0:     	stp	q2, q3, [x9, #0x20]
1004eacb4:     	str	xzr, [sp, #0x170]
1004eacb8:     	str	xzr, [sp, #0x1b8]
1004eacbc:     	stp	q2, q3, [sp, #0x1e0]
1004eacc0:     	stp	q0, q1, [sp, #0x1c0]
1004eacc4:     	add	x9, x8, #0x1f8
1004eacc8:     	stp	q2, q3, [x9, #0x20]
1004eaccc:     	stp	q0, q1, [x9]
1004eacd0:     	add	w9, w11, w11, lsl #3
1004eacd4:     	lsl	w23, w9, #3
1004eacd8:     	str	xzr, [sp, #0x200]
1004eacdc:     	str	xzr, [sp, #0x248]
1004eace0:     	str	w11, [sp, #0x4]
1004eace4:     	cbz	w11, 0x1004eaed0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x310>
1004eace8:     	ldr	x9, [sp, #0x8]
1004eacec:     	add	x26, x9, #0x10
1004eacf0:     	add	x27, x8, x23
1004eacf4:     	add	x28, sp, #0x250
1004eacf8:     	add	x21, sp, #0x10
1004eacfc:     	mov	w24, #0x7ffd            ; =32765
1004ead00:     	b	0x1004ead44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x184>
1004ead04:     	mov	w10, #0x0               ; =0
1004ead08:     	ldp	q0, q1, [x29, #-0xa0]
1004ead0c:     	stp	q0, q1, [sp, #0x250]
1004ead10:     	ldur	q2, [x29, #-0x80]
1004ead14:     	str	q2, [sp, #0x270]
1004ead18:     	ldur	x11, [x29, #-0x70]
1004ead1c:     	strb	w10, [x21]
1004ead20:     	strb	w8, [x21, #0x1]
1004ead24:     	str	x9, [x21, #0x8]
1004ead28:     	stp	q0, q1, [x21, #0x10]
1004ead2c:     	str	q2, [x21, #0x30]
1004ead30:     	str	x11, [x21, #0x40]
1004ead34:     	add	x21, x21, #0x48
1004ead38:     	str	x11, [sp, #0x280]
1004ead3c:     	cmp	x21, x27
1004ead40:     	b.eq	0x1004eaed0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x310>
1004ead44:     	ldr	x9, [x26], #0x8
1004ead48:     	cmp	x24, x9, lsr #48
1004ead4c:     	b.ne	0x1004ead04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x144>
1004ead50:     	and	x22, x9, #0xffffffffffff
1004ead54:     	ldurb	w8, [x22, #-0x8]
1004ead58:     	cmp	w8, #0x1
1004ead5c:     	b.ne	0x1004eb168 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5a8>
1004ead60:     	ldr	w25, [x22]
1004ead64:     	cmp	w25, #0x8
1004ead68:     	b.hi	0x1004eb168 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5a8>
1004ead6c:     	add	x0, sp, #0x250
1004ead70:     	adrp	x1, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x70f0>
1004ead74:     	add	x1, x1, #0x9f0
1004ead78:     	mov	w2, #0x40               ; =64
1004ead7c:     	bl	0x100b5fbd0 <_writev+0x100b5fbd0>
1004ead80:     	cbz	w25, 0x1004eaea4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x2e4>
1004ead84:     	mov	x0, x22
1004ead88:     	mov	w1, #0x0                ; =0
1004ead8c:     	bl	0x1007bb950 <_js_array_get_f64>
1004ead90:     	fmov	x8, d0
1004ead94:     	cmp	x24, x8, lsr #48
1004ead98:     	b.eq	0x1004eb168 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5a8>
1004ead9c:     	str	d0, [sp, #0x250]
1004eada0:     	cmp	w25, #0x1
1004eada4:     	b.eq	0x1004eae9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x2dc>
1004eada8:     	mov	x0, x22
1004eadac:     	mov	w1, #0x1                ; =1
1004eadb0:     	bl	0x1007bb950 <_js_array_get_f64>
1004eadb4:     	fmov	x8, d0
1004eadb8:     	cmp	x24, x8, lsr #48
1004eadbc:     	b.eq	0x1004eb168 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5a8>
1004eadc0:     	str	d0, [sp, #0x258]
1004eadc4:     	cmp	w25, #0x2
1004eadc8:     	b.eq	0x1004eae9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x2dc>
1004eadcc:     	mov	x0, x22
1004eadd0:     	mov	w1, #0x2                ; =2
1004eadd4:     	bl	0x1007bb950 <_js_array_get_f64>
1004eadd8:     	fmov	x8, d0
1004eaddc:     	cmp	x24, x8, lsr #48
1004eade0:     	b.eq	0x1004eb168 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5a8>
1004eade4:     	str	d0, [sp, #0x260]
1004eade8:     	cmp	w25, #0x3
1004eadec:     	b.eq	0x1004eae9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x2dc>
1004eadf0:     	mov	x0, x22
1004eadf4:     	mov	w1, #0x3                ; =3
1004eadf8:     	bl	0x1007bb950 <_js_array_get_f64>
1004eadfc:     	fmov	x8, d0
1004eae00:     	cmp	x24, x8, lsr #48
1004eae04:     	b.eq	0x1004eb168 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5a8>
1004eae08:     	str	d0, [sp, #0x268]
1004eae0c:     	cmp	w25, #0x4
1004eae10:     	b.eq	0x1004eae9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x2dc>
1004eae14:     	mov	x0, x22
1004eae18:     	mov	w1, #0x4                ; =4
1004eae1c:     	bl	0x1007bb950 <_js_array_get_f64>
1004eae20:     	fmov	x8, d0
1004eae24:     	cmp	x24, x8, lsr #48
1004eae28:     	b.eq	0x1004eb168 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5a8>
1004eae2c:     	str	d0, [sp, #0x270]
1004eae30:     	cmp	w25, #0x5
1004eae34:     	b.eq	0x1004eae9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x2dc>
1004eae38:     	mov	x0, x22
1004eae3c:     	mov	w1, #0x5                ; =5
1004eae40:     	bl	0x1007bb950 <_js_array_get_f64>
1004eae44:     	fmov	x8, d0
1004eae48:     	cmp	x24, x8, lsr #48
1004eae4c:     	b.eq	0x1004eb168 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5a8>
1004eae50:     	str	d0, [sp, #0x278]
1004eae54:     	cmp	w25, #0x6
1004eae58:     	b.eq	0x1004eae9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x2dc>
1004eae5c:     	mov	x0, x22
1004eae60:     	mov	w1, #0x6                ; =6
1004eae64:     	bl	0x1007bb950 <_js_array_get_f64>
1004eae68:     	fmov	x8, d0
1004eae6c:     	cmp	x24, x8, lsr #48
1004eae70:     	b.eq	0x1004eb168 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5a8>
1004eae74:     	str	d0, [sp, #0x280]
1004eae78:     	cmp	w25, #0x7
1004eae7c:     	b.eq	0x1004eae9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x2dc>
1004eae80:     	mov	x0, x22
1004eae84:     	mov	w1, #0x7                ; =7
1004eae88:     	bl	0x1007bb950 <_js_array_get_f64>
1004eae8c:     	fmov	x8, d0
1004eae90:     	cmp	x24, x8, lsr #48
1004eae94:     	b.eq	0x1004eb168 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5a8>
1004eae98:     	str	d0, [sp, #0x288]
1004eae9c:     	ldr	w8, [x22]
1004eaea0:     	b	0x1004eaea8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x2e8>
1004eaea4:     	mov	w8, #0x0                ; =0
1004eaea8:     	ldr	x9, [sp, #0x250]
1004eaeac:     	ldur	q0, [x28, #0x8]
1004eaeb0:     	ldur	q1, [x28, #0x18]
1004eaeb4:     	stp	q0, q1, [x29, #-0xa0]
1004eaeb8:     	ldur	q0, [x28, #0x28]
1004eaebc:     	stur	q0, [x29, #-0x80]
1004eaec0:     	ldur	x10, [x28, #0x38]
1004eaec4:     	stur	x10, [x29, #-0x70]
1004eaec8:     	mov	w10, #0x1               ; =1
1004eaecc:     	b	0x1004ead08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x148>
1004eaed0:     	ldr	x26, [sp, #0x8]
1004eaed4:     	ldr	w24, [x26, #0x4]
1004eaed8:     	mov	w8, #-0x40000000        ; =-1073741824
1004eaedc:     	cmp	w24, w8
1004eaee0:     	csel	w21, w24, w8, lt
1004eaee4:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eaee8:     	ldr	w25, [x8, #0x800]
1004eaeec:     	adrp	x22, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eaef0:     	cmp	w25, #0x300
1004eaef4:     	b.hs	0x1004eaf88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3c8>
1004eaef8:     	ldr	x8, [x22, #0x48]
1004eaefc:     	cmn	x8, #0x1
1004eaf00:     	b.eq	0x1004eaf78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3b8>
1004eaf04:     	mrs	x9, TPIDRRO_EL0
1004eaf08:     	and	x9, x9, #0xfffffffffffffff8
1004eaf0c:     	ldr	x0, [x9, x8, lsl #3]
1004eaf10:     	cbz	x0, 0x1004eaf78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3b8>
1004eaf14:     	add	x8, x0, x25, lsl #3
1004eaf18:     	ldr	x0, [x8, #0x1e8]
1004eaf1c:     	cbz	x0, 0x1004eaf88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3c8>
1004eaf20:     	ldr	x0, [x0]
1004eaf24:     	cbz	x0, 0x1004eaf9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3dc>
1004eaf28:     	mov	w8, #-0x40000001        ; =-1073741825
1004eaf2c:     	cmp	w24, w8
1004eaf30:     	b.gt	0x1004eafac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3ec>
1004eaf34:     	ldr	x10, [x0, #0x51d0]
1004eaf38:     	and	w8, w21, #0x3fffffff
1004eaf3c:     	lsr	x9, x8, #15
1004eaf40:     	cmp	x9, x10
1004eaf44:     	b.hs	0x1004eafac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3ec>
1004eaf48:     	ldr	x10, [x0, #0x51c8]
1004eaf4c:     	ldr	x9, [x10, x9, lsl #3]
1004eaf50:     	cbz	x9, 0x1004eafac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3ec>
1004eaf54:     	ubfx	x10, x8, #5, #10
1004eaf58:     	ldr	x9, [x9, x10, lsl #3]
1004eaf5c:     	cbz	x9, 0x1004eafac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3ec>
1004eaf60:     	and	x8, x8, #0x1f
1004eaf64:     	add	x8, x9, x8, lsl #5
1004eaf68:     	ldrb	w9, [x8, #0x1c]
1004eaf6c:     	tbz	w9, #0x0, 0x1004eafac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3ec>
1004eaf70:     	ldr	x21, [x8]
1004eaf74:     	b	0x1004eafb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3f0>
1004eaf78:     	bl	0x100b3d13c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eaf7c:     	add	x8, x0, x25, lsl #3
1004eaf80:     	ldr	x0, [x8, #0x1e8]
1004eaf84:     	cbnz	x0, 0x1004eaf20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x360>
1004eaf88:     	adrp	x0, 0x100f06000 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json25PARSE_KEY_CACHE_OVERSIZED+0x3b0>
1004eaf8c:     	add	x0, x0, #0x578
1004eaf90:     	bl	0x100b3a95c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1004eaf94:     	ldr	x0, [x0]
1004eaf98:     	cbnz	x0, 0x1004eaf28 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x368>
1004eaf9c:     	bl	0x100b3c5e0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime5state10init_state>
1004eafa0:     	mov	w8, #-0x40000001        ; =-1073741825
1004eafa4:     	cmp	w24, w8
1004eafa8:     	b.le	0x1004eaf34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x374>
1004eafac:     	mov	x21, #0x0               ; =0
1004eafb0:     	ldr	w8, [x26, #0x4]
1004eafb4:     	mov	w9, #-0x40000000        ; =-1073741824
1004eafb8:     	cmp	w8, w9
1004eafbc:     	csel	w24, w8, wzr, lt
1004eafc0:     	add	x0, sp, #0x250
1004eafc4:     	add	x1, sp, #0x10
1004eafc8:     	mov	w2, #0x240              ; =576
1004eafcc:     	bl	0x100b5fbac <_writev+0x100b5fbac>
1004eafd0:     	str	x19, [sp, #0x490]
1004eafd4:     	strh	w20, [sp, #0x4a4]
1004eafd8:     	str	x21, [sp, #0x498]
1004eafdc:     	str	w24, [sp, #0x4a0]
1004eafe0:     	ldr	w24, [sp, #0x4]
1004eafe4:     	strb	w24, [sp, #0x4a6]
1004eafe8:     	adrp	x20, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf85c>
1004eafec:     	ldr	w8, [x20, #0x7a4]
1004eaff0:     	cbz	w8, 0x1004eb000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x440>
1004eaff4:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
1004eaff8:     	bfxil	x0, x19, #0, #48
1004eaffc:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb000:     	cbz	x21, 0x1004eb014 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x454>
1004eb004:     	ldr	w8, [x20, #0x7a4]
1004eb008:     	cbz	w8, 0x1004eb014 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x454>
1004eb00c:     	mov	x0, x21
1004eb010:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb014:     	cbz	w24, 0x1004eb11c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x55c>
1004eb018:     	add	x8, sp, #0x250
1004eb01c:     	add	x21, x8, #0x8
1004eb020:     	b	0x1004eb030 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x470>
1004eb024:     	add	x21, x21, #0x48
1004eb028:     	subs	x23, x23, #0x48
1004eb02c:     	b.eq	0x1004eb11c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x55c>
1004eb030:     	ldurb	w8, [x21, #-0x8]
1004eb034:     	tbz	w8, #0x0, 0x1004eb108 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x548>
1004eb038:     	ldp	q0, q1, [x21]
1004eb03c:     	stp	q0, q1, [x29, #-0xa0]
1004eb040:     	ldp	q0, q1, [x21, #0x20]
1004eb044:     	stp	q0, q1, [x29, #-0x80]
1004eb048:     	ldurb	w19, [x21, #-0x7]
1004eb04c:     	cmp	w19, #0x9
1004eb050:     	b.hs	0x1004eb1b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5f8>
1004eb054:     	cbz	w19, 0x1004eb024 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x464>
1004eb058:     	ldur	x0, [x29, #-0xa0]
1004eb05c:     	ldr	w8, [x20, #0x7a4]
1004eb060:     	cbz	w8, 0x1004eb068 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x4a8>
1004eb064:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb068:     	cmp	w19, #0x1
1004eb06c:     	b.eq	0x1004eb024 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x464>
1004eb070:     	ldur	x0, [x29, #-0x98]
1004eb074:     	ldr	w8, [x20, #0x7a4]
1004eb078:     	cbz	w8, 0x1004eb080 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x4c0>
1004eb07c:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb080:     	cmp	w19, #0x2
1004eb084:     	b.eq	0x1004eb024 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x464>
1004eb088:     	ldur	x0, [x29, #-0x90]
1004eb08c:     	ldr	w8, [x20, #0x7a4]
1004eb090:     	cbz	w8, 0x1004eb098 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x4d8>
1004eb094:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb098:     	cmp	w19, #0x3
1004eb09c:     	b.eq	0x1004eb024 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x464>
1004eb0a0:     	ldur	x0, [x29, #-0x88]
1004eb0a4:     	ldr	w8, [x20, #0x7a4]
1004eb0a8:     	cbz	w8, 0x1004eb0b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x4f0>
1004eb0ac:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb0b0:     	cmp	w19, #0x4
1004eb0b4:     	b.eq	0x1004eb024 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x464>
1004eb0b8:     	ldur	x0, [x29, #-0x80]
1004eb0bc:     	ldr	w8, [x20, #0x7a4]
1004eb0c0:     	cbz	w8, 0x1004eb0c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x508>
1004eb0c4:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb0c8:     	cmp	w19, #0x5
1004eb0cc:     	b.eq	0x1004eb024 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x464>
1004eb0d0:     	ldur	x0, [x29, #-0x78]
1004eb0d4:     	ldr	w8, [x20, #0x7a4]
1004eb0d8:     	cbz	w8, 0x1004eb0e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x520>
1004eb0dc:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb0e0:     	cmp	w19, #0x6
1004eb0e4:     	b.eq	0x1004eb024 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x464>
1004eb0e8:     	ldur	x0, [x29, #-0x70]
1004eb0ec:     	ldr	w8, [x20, #0x7a4]
1004eb0f0:     	cbz	w8, 0x1004eb0f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x538>
1004eb0f4:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb0f8:     	cmp	w19, #0x7
1004eb0fc:     	b.eq	0x1004eb024 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x464>
1004eb100:     	ldur	x0, [x29, #-0x68]
1004eb104:     	b	0x1004eb10c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x54c>
1004eb108:     	ldr	x0, [x21]
1004eb10c:     	ldr	w8, [x20, #0x7a4]
1004eb110:     	cbz	w8, 0x1004eb024 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x464>
1004eb114:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004eb118:     	b	0x1004eb024 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x464>
1004eb11c:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1004eb120:     	ldr	w19, [x8, #0x578]
1004eb124:     	cmp	w19, #0x300
1004eb128:     	b.hs	0x1004eb198 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5d8>
1004eb12c:     	ldr	x8, [x22, #0x48]
1004eb130:     	cmn	x8, #0x1
1004eb134:     	b.eq	0x1004eb188 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5c8>
1004eb138:     	mrs	x9, TPIDRRO_EL0
1004eb13c:     	and	x9, x9, #0xfffffffffffffff8
1004eb140:     	ldr	x0, [x9, x8, lsl #3]
1004eb144:     	cbz	x0, 0x1004eb188 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5c8>
1004eb148:     	add	x8, x0, x19, lsl #3
1004eb14c:     	ldr	x0, [x8, #0x1e8]
1004eb150:     	cbz	x0, 0x1004eb198 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5d8>
1004eb154:     	ldr	x8, [x0], #0x8
1004eb158:     	cbnz	x8, 0x1004eb1ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5ec>
1004eb15c:     	add	x1, sp, #0x250
1004eb160:     	mov	w2, #0x258              ; =600
1004eb164:     	bl	0x100b5fbac <_writev+0x100b5fbac>
1004eb168:     	add	sp, sp, #0x500
1004eb16c:     	ldp	x29, x30, [sp, #0x50]
1004eb170:     	ldp	x20, x19, [sp, #0x40]
1004eb174:     	ldp	x22, x21, [sp, #0x30]
1004eb178:     	ldp	x24, x23, [sp, #0x20]
1004eb17c:     	ldp	x26, x25, [sp, #0x10]
1004eb180:     	ldp	x28, x27, [sp], #0x60
1004eb184:     	ret
1004eb188:     	bl	0x100b3d13c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb18c:     	add	x8, x0, x19, lsl #3
1004eb190:     	ldr	x0, [x8, #0x1e8]
1004eb194:     	cbnz	x0, 0x1004eb154 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x594>
1004eb198:     	adrp	x0, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1004eb19c:     	add	x0, x0, #0xfb8
1004eb1a0:     	bl	0x100b3a95c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1004eb1a4:     	ldr	x8, [x0], #0x8
1004eb1a8:     	cbz	x8, 0x1004eb15c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x59c>
1004eb1ac:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004eb1b0:     	add	x0, x0, #0xd28
1004eb1b4:     	bl	0x100b1046c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1004eb1b8:     	adrp	x3, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1004eb1bc:     	add	x3, x3, #0xfd0
1004eb1c0:     	mov	x0, #0x0                ; =0
1004eb1c4:     	mov	x1, x19
1004eb1c8:     	mov	w2, #0x8                ; =8
1004eb1cc:     	bl	0x100b1078c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
