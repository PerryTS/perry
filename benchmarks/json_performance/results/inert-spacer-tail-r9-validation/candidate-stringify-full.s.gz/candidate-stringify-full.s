
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/inert-spacer-tail-r9/candidate-options:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001008430c4 <_js_json_stringify_full>:
1008430c4:     	sub	sp, sp, #0x130
1008430c8:     	stp	d9, d8, [sp, #0xc0]
1008430cc:     	stp	x28, x27, [sp, #0xd0]
1008430d0:     	stp	x26, x25, [sp, #0xe0]
1008430d4:     	stp	x24, x23, [sp, #0xf0]
1008430d8:     	stp	x22, x21, [sp, #0x100]
1008430dc:     	stp	x20, x19, [sp, #0x110]
1008430e0:     	stp	x29, x30, [sp, #0x120]
1008430e4:     	add	x29, sp, #0x120
1008430e8:     	mov.16b	v9, v2
1008430ec:     	mov.16b	v8, v0
1008430f0:     	fmov	x20, d8
1008430f4:     	fmov	x22, d1
1008430f8:     	fmov	x21, d9
1008430fc:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100843100:     	add	x27, x22, x8
100843104:     	cmp	x27, #0x2
100843108:     	add	x8, x21, x8
10084310c:     	ccmp	x8, #0x3, #0x2, lo
100843110:     	cset	w23, lo
100843114:     	b.hs	0x10084318c <_js_json_stringify_full+0xc8>
100843118:     	mov	x0, x20
10084311c:     	bl	0x1004ee9fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small13try_primitive>
100843120:     	cmp	x0, #0x1
100843124:     	b.eq	0x1008431ac <_js_json_stringify_full+0xe8>
100843128:     	mov	w8, #0x7fff             ; =32767
10084312c:     	cmp	x8, x20, lsr #48
100843130:     	b.ne	0x100843168 <_js_json_stringify_full+0xa4>
100843134:     	and	x8, x20, #0xffffffffffff
100843138:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
10084313c:     	mov	x10, #0x7fffffffffff    ; =140737488355327
100843140:     	movk	x10, #0xffef, lsl #16
100843144:     	cmp	x9, x10
100843148:     	b.hi	0x100843168 <_js_json_stringify_full+0xa4>
10084314c:     	ldr	w8, [x8, #0x4]
100843150:     	cmp	w8, #0x40
100843154:     	b.lo	0x100843168 <_js_json_stringify_full+0xa4>
100843158:     	and	x0, x20, #0xffffffffffff
10084315c:     	bl	0x1004f0c0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100843160:     	cmp	x0, #0x1
100843164:     	b.eq	0x1008432f8 <_js_json_stringify_full+0x234>
100843168:     	mov	x0, x20
10084316c:     	bl	0x1004f5ec0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output10try_object>
100843170:     	cmp	x0, #0x1
100843174:     	b.eq	0x1008431ac <_js_json_stringify_full+0xe8>
100843178:     	mov	x0, x20
10084317c:     	bl	0x1004ebf80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat10try_object>
100843180:     	cmp	x0, #0x1
100843184:     	b.eq	0x1008431ac <_js_json_stringify_full+0xe8>
100843188:     	b	0x1008431b4 <_js_json_stringify_full+0xf0>
10084318c:     	cmp	x27, #0x1
100843190:     	ccmp	x8, #0x3, #0x0, ls
100843194:     	b.lo	0x1008431b4 <_js_json_stringify_full+0xf0>
100843198:     	mov	x0, x20
10084319c:     	mov	x1, x21
1008431a0:     	bl	0x1004eefac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer>
1008431a4:     	cmp	x0, #0x1
1008431a8:     	b.ne	0x1008431b4 <_js_json_stringify_full+0xf0>
1008431ac:     	mov	x19, x1
1008431b0:     	b	0x100844360 <_js_json_stringify_full+0x129c>
1008431b4:     	mov	x19, #0x1               ; =1
1008431b8:     	movk	x19, #0x7ffc, lsl #48
1008431bc:     	cmp	x20, x19
1008431c0:     	b.eq	0x100844360 <_js_json_stringify_full+0x129c>
1008431c4:     	and	x24, x20, #0xffff000000000000
1008431c8:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008431cc:     	cmp	x24, x8
1008431d0:     	b.ne	0x100843208 <_js_json_stringify_full+0x144>
1008431d4:     	and	x8, x20, #0xffffffffffff
1008431d8:     	cmp	x8, #0x100, lsl #12     ; =0x100000
1008431dc:     	b.lo	0x1008431f4 <_js_json_stringify_full+0x130>
1008431e0:     	ldr	w8, [x8, #0xc]
1008431e4:     	mov	w9, #0x4f53             ; =20307
1008431e8:     	movk	w9, #0x434c, lsl #16
1008431ec:     	cmp	w8, w9
1008431f0:     	b.eq	0x100844360 <_js_json_stringify_full+0x129c>
1008431f4:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008431f8:     	cmp	x24, x8
1008431fc:     	b.ne	0x100843234 <_js_json_stringify_full+0x170>
100843200:     	and	x0, x20, #0xffffffffffff
100843204:     	b	0x10084325c <_js_json_stringify_full+0x198>
100843208:     	lsr	x8, x20, #52
10084320c:     	cbnz	x8, 0x1008432e4 <_js_json_stringify_full+0x220>
100843210:     	and	x8, x20, #0x7
100843214:     	cbz	x20, 0x100843240 <_js_json_stringify_full+0x17c>
100843218:     	cbnz	x8, 0x100843240 <_js_json_stringify_full+0x17c>
10084321c:     	mov	x0, x20
100843220:     	bl	0x10050ca38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100843224:     	mov	x8, x20
100843228:     	tbnz	w0, #0x0, 0x1008431d8 <_js_json_stringify_full+0x114>
10084322c:     	mov	x8, #0x0                ; =0
100843230:     	b	0x100843240 <_js_json_stringify_full+0x17c>
100843234:     	lsr	x8, x20, #52
100843238:     	cbnz	x8, 0x1008432e4 <_js_json_stringify_full+0x220>
10084323c:     	and	x8, x20, #0x7
100843240:     	cbz	x20, 0x1008432e4 <_js_json_stringify_full+0x220>
100843244:     	cbnz	x8, 0x1008432e4 <_js_json_stringify_full+0x220>
100843248:     	mov	x0, x20
10084324c:     	bl	0x10050ca38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100843250:     	mov	x8, x0
100843254:     	mov	x0, x20
100843258:     	tbz	w8, #0x0, 0x1008432e4 <_js_json_stringify_full+0x220>
10084325c:     	cmp	x0, #0x100, lsl #12     ; =0x100000
100843260:     	b.lo	0x1008432e4 <_js_json_stringify_full+0x220>
100843264:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100843268:     	add	x8, x8, #0xf70
10084326c:     	ldaprb	w8, [x8]
100843270:     	cbz	w8, 0x1008432e4 <_js_json_stringify_full+0x220>
100843274:     	lsr	x8, x0, #3
100843278:     	mov	x9, #0x7c15             ; =31765
10084327c:     	movk	x9, #0x7f4a, lsl #16
100843280:     	movk	x9, #0x79b9, lsl #32
100843284:     	movk	x9, #0x9e37, lsl #48
100843288:     	mul	x8, x8, x9
10084328c:     	lsr	x10, x8, #54
100843290:     	lsr	x11, x8, #60
100843294:     	adrp	x9, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100843298:     	add	x9, x9, #0xef0
10084329c:     	add	x11, x9, x11, lsl #3
1008432a0:     	ldapr	x11, [x11]
1008432a4:     	lsr	x10, x11, x10
1008432a8:     	tbz	w10, #0x0, 0x1008432e4 <_js_json_stringify_full+0x220>
1008432ac:     	lsr	x10, x8, #44
1008432b0:     	ubfx	x11, x8, #50, #4
1008432b4:     	add	x11, x9, x11, lsl #3
1008432b8:     	ldapr	x11, [x11]
1008432bc:     	lsr	x10, x11, x10
1008432c0:     	tbz	w10, #0x0, 0x1008432e4 <_js_json_stringify_full+0x220>
1008432c4:     	lsr	x10, x8, #34
1008432c8:     	ubfx	x8, x8, #40, #4
1008432cc:     	add	x8, x9, x8, lsl #3
1008432d0:     	ldapr	x8, [x8]
1008432d4:     	lsr	x8, x8, x10
1008432d8:     	tbz	w8, #0x0, 0x1008432e4 <_js_json_stringify_full+0x220>
1008432dc:     	bl	0x10034a16c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
1008432e0:     	tbnz	w0, #0x0, 0x100844360 <_js_json_stringify_full+0x129c>
1008432e4:     	tbz	w23, #0x0, 0x100843304 <_js_json_stringify_full+0x240>
1008432e8:     	mov.16b	v0, v8
1008432ec:     	bl	0x1004eb4bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
1008432f0:     	cmp	x0, #0x1
1008432f4:     	b.ne	0x100843304 <_js_json_stringify_full+0x240>
1008432f8:     	mov	x19, #0x7fff000000000000 ; =9223090561878065152
1008432fc:     	bfxil	x19, x1, #0, #48
100843300:     	b	0x100844360 <_js_json_stringify_full+0x129c>
100843304:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100843308:     	cmp	x24, x8
10084330c:     	b.ne	0x10084335c <_js_json_stringify_full+0x298>
100843310:     	ands	x23, x20, #0xffffffffffff
100843314:     	b.eq	0x10084335c <_js_json_stringify_full+0x298>
100843318:     	mov	x0, x23
10084331c:     	bl	0x10050ca38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100843320:     	cbz	w0, 0x10084335c <_js_json_stringify_full+0x298>
100843324:     	ldurb	w8, [x23, #-0x8]
100843328:     	cmp	w8, #0x9
10084332c:     	b.ne	0x10084335c <_js_json_stringify_full+0x298>
100843330:     	ldr	w8, [x23, #0x4]
100843334:     	mov	w9, #0x5841             ; =22593
100843338:     	movk	w9, #0x4c5a, lsl #16
10084333c:     	cmp	w8, w9
100843340:     	b.ne	0x10084335c <_js_json_stringify_full+0x298>
100843344:     	mov	x0, x23
100843348:     	bl	0x10068579c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
10084334c:     	cbz	x0, 0x10084335c <_js_json_stringify_full+0x298>
100843350:     	mov	x20, #0x7ffd000000000000 ; =9222527611924643840
100843354:     	bfxil	x20, x0, #0, #48
100843358:     	fmov	d8, x20
10084335c:     	mov	w8, #0x7ffd             ; =32765
100843360:     	cmp	x8, x21, lsr #48
100843364:     	b.ne	0x100843378 <_js_json_stringify_full+0x2b4>
100843368:     	and	x1, x21, #0xffffffffffff
10084336c:     	cmp	x1, #0x100, lsl #12     ; =0x100000
100843370:     	b.hs	0x10084338c <_js_json_stringify_full+0x2c8>
100843374:     	b	0x1008433e0 <_js_json_stringify_full+0x31c>
100843378:     	sub	x8, x21, #0x100, lsl #12 ; =0x100000
10084337c:     	mov	x9, #0xfffffff00000     ; =281474975662080
100843380:     	mov	x1, x21
100843384:     	cmp	x8, x9
100843388:     	b.hs	0x1008433e0 <_js_json_stringify_full+0x31c>
10084338c:     	lsr	x8, x1, #47
100843390:     	cbnz	x8, 0x1008433e0 <_js_json_stringify_full+0x31c>
100843394:     	add	x0, sp, #0x68
100843398:     	bl	0x10076b5ac <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
10084339c:     	ldr	w8, [sp, #0x68]
1008433a0:     	tbz	w8, #0x0, 0x1008433e0 <_js_json_stringify_full+0x31c>
1008433a4:     	ldr	w8, [sp, #0x70]
1008433a8:     	mov	w9, #-0xff30            ; =-65328
1008433ac:     	cmp	w8, w9
1008433b0:     	b.eq	0x1008433d4 <_js_json_stringify_full+0x310>
1008433b4:     	mov	w9, #-0xff2f            ; =-65327
1008433b8:     	cmp	w8, w9
1008433bc:     	b.ne	0x1008433e0 <_js_json_stringify_full+0x31c>
1008433c0:     	mov.16b	v0, v9
1008433c4:     	bl	0x1008459fc <_js_jsvalue_to_string>
1008433c8:     	mov	x21, #0x7fff000000000000 ; =9223090561878065152
1008433cc:     	bfxil	x21, x0, #0, #48
1008433d0:     	b	0x1008433e0 <_js_json_stringify_full+0x31c>
1008433d4:     	mov.16b	v0, v9
1008433d8:     	bl	0x10086cfa0 <_js_number_coerce>
1008433dc:     	fmov	x21, d0
1008433e0:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
1008433e4:     	add	x8, x21, x8
1008433e8:     	cmp	x8, #0x3
1008433ec:     	b.hs	0x100843418 <_js_json_stringify_full+0x354>
1008433f0:     	mov	x21, #0x0               ; =0
1008433f4:     	mov	w8, #0x1                ; =1
1008433f8:     	stp	xzr, x8, [sp, #0x30]
1008433fc:     	str	xzr, [sp, #0x40]
100843400:     	cmp	x27, #0x2
100843404:     	b.hs	0x100843448 <_js_json_stringify_full+0x384>
100843408:     	mov	w24, #0x0               ; =0
10084340c:     	mov	x27, #-0x1              ; =-1
100843410:     	mov	w26, #0x1               ; =1
100843414:     	b	0x100843bf0 <_js_json_stringify_full+0xb2c>
100843418:     	and	x8, x21, #0xffff000000000000
10084341c:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100843420:     	cmp	x8, x9
100843424:     	b.eq	0x100843590 <_js_json_stringify_full+0x4cc>
100843428:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10084342c:     	cmp	x8, x9
100843430:     	b.ne	0x10084361c <_js_json_stringify_full+0x558>
100843434:     	and	x8, x21, #0xffffffffffff
100843438:     	cmp	x8, #0x1, lsl #12       ; =0x1000
10084343c:     	b.hs	0x100843664 <_js_json_stringify_full+0x5a0>
100843440:     	mov	x9, #0x0                ; =0
100843444:     	b	0x10084366c <_js_json_stringify_full+0x5a8>
100843448:     	and	x27, x22, #0xffff000000000000
10084344c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100843450:     	cmp	x27, x8
100843454:     	b.ne	0x100843568 <_js_json_stringify_full+0x4a4>
100843458:     	and	x25, x22, #0xffffffffffff
10084345c:     	cmp	x25, #0x100, lsl #12    ; =0x100000
100843460:     	b.lo	0x100843bc4 <_js_json_stringify_full+0xb00>
100843464:     	mov	x0, x25
100843468:     	bl	0x100507f40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
10084346c:     	tbnz	w0, #0x0, 0x100843bc4 <_js_json_stringify_full+0xb00>
100843470:     	lsr	x8, x25, #51
100843474:     	cmp	x8, #0xfff
100843478:     	b.lo	0x100843498 <_js_json_stringify_full+0x3d4>
10084347c:     	mov	x28, x21
100843480:     	mov	w8, #0x7ffc             ; =32764
100843484:     	cmp	x8, x25, lsr #48
100843488:     	b.eq	0x100843a00 <_js_json_stringify_full+0x93c>
10084348c:     	ands	x25, x25, #0xffffffffffff
100843490:     	b.eq	0x100843a00 <_js_json_stringify_full+0x93c>
100843494:     	mov	x21, x28
100843498:     	and	x8, x25, #0xfffffffffff00000
10084349c:     	lsr	x9, x25, #47
1008434a0:     	cmp	x9, #0x0
1008434a4:     	ccmp	x8, #0x0, #0x4, eq
1008434a8:     	b.eq	0x100843bc4 <_js_json_stringify_full+0xb00>
1008434ac:     	tst	x25, #0x3
1008434b0:     	ccmp	x25, #0x7, #0x0, eq
1008434b4:     	b.ls	0x100843900 <_js_json_stringify_full+0x83c>
1008434b8:     	adrp	x8, 0x100f7c000 <_perry_global_options_worker_ts__1>
1008434bc:     	ldr	x8, [x8, #0x48]
1008434c0:     	cmn	x8, #0x1
1008434c4:     	b.eq	0x100843850 <_js_json_stringify_full+0x78c>
1008434c8:     	mrs	x9, TPIDRRO_EL0
1008434cc:     	and	x9, x9, #0xfffffffffffffff8
1008434d0:     	ldr	x0, [x9, x8, lsl #3]
1008434d4:     	cbz	x0, 0x100843850 <_js_json_stringify_full+0x78c>
1008434d8:     	lsr	x1, x25, #20
1008434dc:     	ldr	x8, [x0, #0x10]
1008434e0:     	ldrb	w9, [x8]
1008434e4:     	cmp	w9, #0x2
1008434e8:     	b.ne	0x100843868 <_js_json_stringify_full+0x7a4>
1008434ec:     	ldrb	w9, [x8, #0x88]
1008434f0:     	tbz	w9, #0x0, 0x100843510 <_js_json_stringify_full+0x44c>
1008434f4:     	ldr	x9, [x8, #0x80]
1008434f8:     	cmp	x9, x1
1008434fc:     	b.ne	0x100843510 <_js_json_stringify_full+0x44c>
100843500:     	ldp	x9, x10, [x8, #0x60]
100843504:     	cmp	x9, x25
100843508:     	ccmp	x10, x25, #0x0, ls
10084350c:     	b.hi	0x100843848 <_js_json_stringify_full+0x784>
100843510:     	ldrb	w9, [x8, #0xb8]
100843514:     	cbz	w9, 0x100843534 <_js_json_stringify_full+0x470>
100843518:     	ldr	x9, [x8, #0xb0]
10084351c:     	cmp	x9, x1
100843520:     	b.ne	0x100843534 <_js_json_stringify_full+0x470>
100843524:     	ldp	x9, x10, [x8, #0x90]
100843528:     	cmp	x9, x25
10084352c:     	ccmp	x10, x25, #0x0, ls
100843530:     	b.hi	0x100843a54 <_js_json_stringify_full+0x990>
100843534:     	ldrb	w9, [x8, #0xe8]
100843538:     	cbz	w9, 0x100843814 <_js_json_stringify_full+0x750>
10084353c:     	ldr	x9, [x8, #0xe0]
100843540:     	cmp	x9, x1
100843544:     	b.ne	0x100843814 <_js_json_stringify_full+0x750>
100843548:     	ldr	x9, [x8, #0xc0]
10084354c:     	cmp	x9, x25
100843550:     	b.hi	0x100843814 <_js_json_stringify_full+0x750>
100843554:     	ldr	x9, [x8, #0xc8]
100843558:     	cmp	x9, x25
10084355c:     	b.ls	0x100843814 <_js_json_stringify_full+0x750>
100843560:     	add	x9, x8, #0xc0
100843564:     	b	0x100843a58 <_js_json_stringify_full+0x994>
100843568:     	lsr	x8, x22, #52
10084356c:     	cbnz	x8, 0x100843408 <_js_json_stringify_full+0x344>
100843570:     	cbz	x22, 0x100843a18 <_js_json_stringify_full+0x954>
100843574:     	and	x8, x22, #0x7
100843578:     	cbnz	x8, 0x100843a18 <_js_json_stringify_full+0x954>
10084357c:     	mov	x0, x22
100843580:     	bl	0x10050ca38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100843584:     	mov	x25, x22
100843588:     	cbnz	w0, 0x10084345c <_js_json_stringify_full+0x398>
10084358c:     	b	0x100843a18 <_js_json_stringify_full+0x954>
100843590:     	sturb	wzr, [x29, #-0x7c]
100843594:     	stur	wzr, [x29, #-0x80]
100843598:     	ubfx	x1, x21, #40, #8
10084359c:     	cbz	x1, 0x1008435ec <_js_json_stringify_full+0x528>
1008435a0:     	sturb	w21, [x29, #-0x80]
1008435a4:     	cmp	x1, #0x1
1008435a8:     	b.eq	0x1008435ec <_js_json_stringify_full+0x528>
1008435ac:     	lsr	x8, x21, #8
1008435b0:     	sturb	w8, [x29, #-0x7f]
1008435b4:     	cmp	x1, #0x2
1008435b8:     	b.eq	0x1008435ec <_js_json_stringify_full+0x528>
1008435bc:     	lsr	x8, x21, #16
1008435c0:     	sturb	w8, [x29, #-0x7e]
1008435c4:     	cmp	x1, #0x3
1008435c8:     	b.eq	0x1008435ec <_js_json_stringify_full+0x528>
1008435cc:     	lsr	x8, x21, #24
1008435d0:     	sturb	w8, [x29, #-0x7d]
1008435d4:     	cmp	x1, #0x4
1008435d8:     	b.eq	0x1008435ec <_js_json_stringify_full+0x528>
1008435dc:     	lsr	x8, x21, #32
1008435e0:     	sturb	w8, [x29, #-0x7c]
1008435e4:     	cmp	x1, #0x5
1008435e8:     	b.ne	0x100844d94 <_js_json_stringify_full+0x1cd0>
1008435ec:     	add	x8, sp, #0x68
1008435f0:     	sub	x0, x29, #0x80
1008435f4:     	bl	0x10002b398 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
1008435f8:     	ldr	w8, [sp, #0x68]
1008435fc:     	ldp	x9, x21, [sp, #0x70]
100843600:     	cmp	w8, #0x0
100843604:     	csinc	x23, x9, xzr, eq
100843608:     	csel	x25, xzr, x21, ne
10084360c:     	tbz	x25, #0x3f, 0x10084374c <_js_json_stringify_full+0x688>
100843610:     	mov	x0, #0x0                ; =0
100843614:     	mov	x1, x21
100843618:     	bl	0x100b0f6c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084361c:     	add	x8, x19, #0x3
100843620:     	cmp	x21, x8
100843624:     	b.eq	0x1008433f0 <_js_json_stringify_full+0x32c>
100843628:     	fmov	d0, x21
10084362c:     	fcvtzu	x8, d0
100843630:     	mov	w9, #0xa                ; =10
100843634:     	cmp	x8, #0xa
100843638:     	csel	x3, x8, x9, lo
10084363c:     	adrp	x1, 0x100c40000 <_PERRY_EMPTY_STRING+0x1764>
100843640:     	add	x1, x1, #0xa2c
100843644:     	add	x0, sp, #0x68
100843648:     	mov	w2, #0x1                ; =1
10084364c:     	bl	0x10022dcb4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
100843650:     	ldr	x21, [sp, #0x78]
100843654:     	str	x21, [sp, #0x40]
100843658:     	ldur	q0, [sp, #0x68]
10084365c:     	str	q0, [sp, #0x30]
100843660:     	b	0x100843400 <_js_json_stringify_full+0x33c>
100843664:     	ldr	w21, [x8, #0x4]
100843668:     	add	x9, x8, #0x14
10084366c:     	mov	x14, #0x0               ; =0
100843670:     	mov	x8, #0x0                ; =0
100843674:     	cmp	x9, #0x0
100843678:     	csel	x24, xzr, x21, eq
10084367c:     	csinc	x23, x9, xzr, ne
100843680:     	add	x9, x23, x24
100843684:     	mov	w10, #0x1               ; =1
100843688:     	mov	x11, x23
10084368c:     	b	0x1008436bc <_js_json_stringify_full+0x5f8>
100843690:     	add	x12, x11, #0x2
100843694:     	bfi	w15, w13, #6, #5
100843698:     	mov	x13, x15
10084369c:     	sub	x11, x25, x11
1008436a0:     	add	x14, x11, x12
1008436a4:     	cmp	w13, #0x10, lsl #12     ; =0x10000
1008436a8:     	cinc	x11, x10, hs
1008436ac:     	add	x8, x11, x8
1008436b0:     	mov	x11, x12
1008436b4:     	cmp	x8, #0xa
1008436b8:     	b.hi	0x100843774 <_js_json_stringify_full+0x6b0>
1008436bc:     	cmp	x11, x9
1008436c0:     	b.eq	0x100843724 <_js_json_stringify_full+0x660>
1008436c4:     	mov	x25, x14
1008436c8:     	mov	x12, x11
1008436cc:     	ldrsb	w14, [x12], #0x1
1008436d0:     	and	w13, w14, #0xff
1008436d4:     	tbz	w14, #0x1f, 0x10084369c <_js_json_stringify_full+0x5d8>
1008436d8:     	ldrb	w12, [x11, #0x1]
1008436dc:     	and	w15, w12, #0x3f
1008436e0:     	cmp	w13, #0xe0
1008436e4:     	b.lo	0x100843690 <_js_json_stringify_full+0x5cc>
1008436e8:     	and	w14, w13, #0x1f
1008436ec:     	ldrb	w12, [x11, #0x2]
1008436f0:     	and	w12, w12, #0x3f
1008436f4:     	orr	w15, w12, w15, lsl #6
1008436f8:     	cmp	w13, #0xf0
1008436fc:     	b.lo	0x100843718 <_js_json_stringify_full+0x654>
100843700:     	add	x12, x11, #0x4
100843704:     	ldrb	w13, [x11, #0x3]
100843708:     	and	w13, w13, #0x3f
10084370c:     	orr	w13, w13, w15, lsl #6
100843710:     	bfi	w13, w14, #18, #3
100843714:     	b	0x10084369c <_js_json_stringify_full+0x5d8>
100843718:     	add	x12, x11, #0x3
10084371c:     	orr	w13, w15, w14, lsl #12
100843720:     	b	0x10084369c <_js_json_stringify_full+0x5d8>
100843724:     	cbz	x24, 0x1008437a8 <_js_json_stringify_full+0x6e4>
100843728:     	mov	x0, x24
10084372c:     	mov	w1, #0x1                ; =1
100843730:     	bl	0x100b5c548 <_mi_malloc_aligned>
100843734:     	cbz	x0, 0x100844d7c <_js_json_stringify_full+0x1cb8>
100843738:     	mov	x26, x0
10084373c:     	mov	x1, x23
100843740:     	mov	x2, x24
100843744:     	bl	0x100b5f16c <_writev+0x100b5f16c>
100843748:     	b	0x1008437b0 <_js_json_stringify_full+0x6ec>
10084374c:     	cbz	x25, 0x1008437bc <_js_json_stringify_full+0x6f8>
100843750:     	mov	x0, x25
100843754:     	mov	w1, #0x1                ; =1
100843758:     	bl	0x100b5c548 <_mi_malloc_aligned>
10084375c:     	cbz	x0, 0x100844d88 <_js_json_stringify_full+0x1cc4>
100843760:     	mov	x24, x0
100843764:     	mov	x1, x23
100843768:     	mov	x2, x25
10084376c:     	bl	0x100b5f16c <_writev+0x100b5f16c>
100843770:     	b	0x1008437c4 <_js_json_stringify_full+0x700>
100843774:     	cbz	x25, 0x1008437a8 <_js_json_stringify_full+0x6e4>
100843778:     	cmp	x25, x24
10084377c:     	b.hs	0x1008437d0 <_js_json_stringify_full+0x70c>
100843780:     	ldrsb	w8, [x23, x25]
100843784:     	cmn	w8, #0x40
100843788:     	b.ge	0x1008437d4 <_js_json_stringify_full+0x710>
10084378c:     	adrp	x4, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
100843790:     	add	x4, x4, #0x2b8
100843794:     	mov	x0, x23
100843798:     	mov	x1, x24
10084379c:     	mov	x2, #0x0                ; =0
1008437a0:     	mov	x3, x25
1008437a4:     	bl	0x100b0fa38 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
1008437a8:     	mov	x21, #0x0               ; =0
1008437ac:     	mov	w26, #0x1               ; =1
1008437b0:     	stp	x21, x26, [sp, #0x30]
1008437b4:     	str	x21, [sp, #0x40]
1008437b8:     	b	0x100843400 <_js_json_stringify_full+0x33c>
1008437bc:     	mov	x21, #0x0               ; =0
1008437c0:     	mov	w24, #0x1               ; =1
1008437c4:     	stp	x21, x24, [sp, #0x30]
1008437c8:     	str	x21, [sp, #0x40]
1008437cc:     	b	0x100843400 <_js_json_stringify_full+0x33c>
1008437d0:     	b.ne	0x10084378c <_js_json_stringify_full+0x6c8>
1008437d4:     	tbz	x25, #0x3f, 0x1008437e4 <_js_json_stringify_full+0x720>
1008437d8:     	mov	x0, #0x0                ; =0
1008437dc:     	mov	x1, x25
1008437e0:     	bl	0x100b0f6c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1008437e4:     	mov	x0, x25
1008437e8:     	mov	w1, #0x1                ; =1
1008437ec:     	bl	0x100b5c548 <_mi_malloc_aligned>
1008437f0:     	mov	x26, x0
1008437f4:     	mov	w0, #0x1                ; =1
1008437f8:     	cbz	x26, 0x1008437dc <_js_json_stringify_full+0x718>
1008437fc:     	mov	x0, x26
100843800:     	mov	x1, x23
100843804:     	mov	x2, x25
100843808:     	bl	0x100b5f16c <_writev+0x100b5f16c>
10084380c:     	mov	x21, x25
100843810:     	b	0x1008437b0 <_js_json_stringify_full+0x6ec>
100843814:     	ldrb	w9, [x8, #0x118]
100843818:     	cbz	w9, 0x1008438c8 <_js_json_stringify_full+0x804>
10084381c:     	ldr	x9, [x8, #0x110]
100843820:     	cmp	x9, x1
100843824:     	b.ne	0x1008438c8 <_js_json_stringify_full+0x804>
100843828:     	ldr	x9, [x8, #0xf0]
10084382c:     	cmp	x9, x25
100843830:     	b.hi	0x1008438c8 <_js_json_stringify_full+0x804>
100843834:     	ldr	x9, [x8, #0xf8]
100843838:     	cmp	x9, x25
10084383c:     	b.ls	0x1008438c8 <_js_json_stringify_full+0x804>
100843840:     	add	x9, x8, #0xf0
100843844:     	b	0x100843a58 <_js_json_stringify_full+0x994>
100843848:     	add	x9, x8, #0x60
10084384c:     	b	0x100843a58 <_js_json_stringify_full+0x994>
100843850:     	bl	0x100b3c6fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100843854:     	lsr	x1, x25, #20
100843858:     	ldr	x8, [x0, #0x10]
10084385c:     	ldrb	w9, [x8]
100843860:     	cmp	w9, #0x2
100843864:     	b.eq	0x1008434ec <_js_json_stringify_full+0x428>
100843868:     	ldr	x9, [x8, #0x8]
10084386c:     	ldr	x10, [x8, #0x28]
100843870:     	sub	x9, x1, x9
100843874:     	cmp	x9, x10
100843878:     	b.hs	0x1008438bc <_js_json_stringify_full+0x7f8>
10084387c:     	ldr	x10, [x8, #0x20]
100843880:     	mov	w11, #0x28              ; =40
100843884:     	madd	x9, x9, x11, x10
100843888:     	ldr	x10, [x9]
10084388c:     	ldr	x11, [x8, #0x10]
100843890:     	cmp	x10, x11
100843894:     	b.ne	0x1008438c8 <_js_json_stringify_full+0x804>
100843898:     	ldp	x10, x11, [x9, #0x8]
10084389c:     	cmp	x10, x25
1008438a0:     	ccmp	x11, x25, #0x0, ls
1008438a4:     	b.ls	0x1008438c8 <_js_json_stringify_full+0x804>
1008438a8:     	ldr	x10, [x8, #0x30]
1008438ac:     	add	x10, x10, #0x1
1008438b0:     	str	x10, [x8, #0x30]
1008438b4:     	add	x8, x9, #0x21
1008438b8:     	b	0x100843a68 <_js_json_stringify_full+0x9a4>
1008438bc:     	ldr	x9, [x8, #0x58]
1008438c0:     	add	x9, x9, #0x1
1008438c4:     	str	x9, [x8, #0x58]
1008438c8:     	ldr	x9, [x8, #0x38]
1008438cc:     	add	x9, x9, #0x1
1008438d0:     	str	x9, [x8, #0x38]
1008438d4:     	mov	x0, x25
1008438d8:     	bl	0x10051bc48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1008438dc:     	and	w8, w0, #0xff
1008438e0:     	cbz	w8, 0x100843900 <_js_json_stringify_full+0x83c>
1008438e4:     	ldurb	w8, [x25, #-0x8]
1008438e8:     	ldurb	w9, [x25, #-0x7]
1008438ec:     	mov	w10, #0x82              ; =130
1008438f0:     	and	w9, w9, w10
1008438f4:     	cmp	w9, #0x2
1008438f8:     	ccmp	w8, #0x1, #0x0, eq
1008438fc:     	b.eq	0x10084399c <_js_json_stringify_full+0x8d8>
100843900:     	mov	x0, x25
100843904:     	bl	0x1005782c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100843908:     	mov	x26, x0
10084390c:     	cbz	x0, 0x100843938 <_js_json_stringify_full+0x874>
100843910:     	ldrb	w8, [x26]
100843914:     	cmp	w8, #0x1
100843918:     	b.ne	0x100843958 <_js_json_stringify_full+0x894>
10084391c:     	ldrsb	w8, [x26, #0x1]
100843920:     	tbnz	w8, #0x1f, 0x1008439c4 <_js_json_stringify_full+0x900>
100843924:     	mov	x0, x26
100843928:     	ldp	w9, w8, [x25]
10084392c:     	cmp	w9, w8
100843930:     	b.ls	0x100843af4 <_js_json_stringify_full+0xa30>
100843934:     	b	0x100843adc <_js_json_stringify_full+0xa18>
100843938:     	mov	x0, x25
10084393c:     	bl	0x100586734 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100843940:     	tbnz	w0, #0x0, 0x100843950 <_js_json_stringify_full+0x88c>
100843944:     	mov	x0, x25
100843948:     	bl	0x1002a1608 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
10084394c:     	tbz	w0, #0x0, 0x100843bc4 <_js_json_stringify_full+0xb00>
100843950:     	mov	x0, #0x0                ; =0
100843954:     	b	0x100843acc <_js_json_stringify_full+0xa08>
100843958:     	mov	x0, x26
10084395c:     	cmp	w8, #0x1
100843960:     	b.eq	0x100843acc <_js_json_stringify_full+0xa08>
100843964:     	mov	x28, x21
100843968:     	cmp	w8, #0x9
10084396c:     	b.ne	0x100843a00 <_js_json_stringify_full+0x93c>
100843970:     	ldr	w8, [x25, #0x4]
100843974:     	mov	w9, #0x5841             ; =22593
100843978:     	movk	w9, #0x4c5a, lsl #16
10084397c:     	cmp	w8, w9
100843980:     	b.ne	0x100843a00 <_js_json_stringify_full+0x93c>
100843984:     	mov	x0, x25
100843988:     	bl	0x1003730f0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
10084398c:     	mov	x25, x0
100843990:     	mov	x21, x28
100843994:     	cbnz	x0, 0x100843b1c <_js_json_stringify_full+0xa58>
100843998:     	b	0x100843a00 <_js_json_stringify_full+0x93c>
10084399c:     	ldr	w8, [x25]
1008439a0:     	mov	w9, #0xe100             ; =57600
1008439a4:     	movk	w9, #0x5f5, lsl #16
1008439a8:     	orr	w9, w9, #0x1
1008439ac:     	cmp	w8, w9
1008439b0:     	b.hs	0x100843900 <_js_json_stringify_full+0x83c>
1008439b4:     	ldr	w9, [x25, #0x4]
1008439b8:     	cmp	w8, w9
1008439bc:     	b.ls	0x100843b1c <_js_json_stringify_full+0xa58>
1008439c0:     	b	0x100843900 <_js_json_stringify_full+0x83c>
1008439c4:     	ldr	x25, [x26, #0x8]
1008439c8:     	mov	x0, x25
1008439cc:     	bl	0x1005782c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1008439d0:     	cbz	x0, 0x100843bc4 <_js_json_stringify_full+0xb00>
1008439d4:     	mov	x28, x21
1008439d8:     	ldrb	w8, [x0]
1008439dc:     	cmp	w8, #0x1
1008439e0:     	b.ne	0x100843a00 <_js_json_stringify_full+0x93c>
1008439e4:     	ldrsb	w8, [x0, #0x1]
1008439e8:     	tbnz	w8, #0x1f, 0x100843a78 <_js_json_stringify_full+0x9b4>
1008439ec:     	mov	x21, x28
1008439f0:     	ldp	w9, w8, [x25]
1008439f4:     	cmp	w9, w8
1008439f8:     	b.hi	0x100843adc <_js_json_stringify_full+0xa18>
1008439fc:     	b	0x100843af4 <_js_json_stringify_full+0xa30>
100843a00:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100843a04:     	cmp	x27, x8
100843a08:     	b.eq	0x100843bd4 <_js_json_stringify_full+0xb10>
100843a0c:     	lsr	x8, x22, #52
100843a10:     	mov	x21, x28
100843a14:     	cbnz	x8, 0x100843be4 <_js_json_stringify_full+0xb20>
100843a18:     	mov	w24, #0x0               ; =0
100843a1c:     	mov	w26, #0x1               ; =1
100843a20:     	cbz	x22, 0x100843a40 <_js_json_stringify_full+0x97c>
100843a24:     	and	x8, x22, #0x7
100843a28:     	cbnz	x8, 0x100843a40 <_js_json_stringify_full+0x97c>
100843a2c:     	mov	x0, x22
100843a30:     	bl	0x10050ca38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100843a34:     	tbz	w0, #0x0, 0x100843a48 <_js_json_stringify_full+0x984>
100843a38:     	mov	x8, x22
100843a3c:     	b	0x100843bdc <_js_json_stringify_full+0xb18>
100843a40:     	mov	x27, #-0x1              ; =-1
100843a44:     	b	0x100843bf0 <_js_json_stringify_full+0xb2c>
100843a48:     	mov	w24, #0x0               ; =0
100843a4c:     	mov	x27, #-0x1              ; =-1
100843a50:     	b	0x100843bf0 <_js_json_stringify_full+0xb2c>
100843a54:     	add	x9, x8, #0x90
100843a58:     	ldr	x10, [x8, #0x30]
100843a5c:     	add	x10, x10, #0x1
100843a60:     	str	x10, [x8, #0x30]
100843a64:     	add	x8, x9, #0x19
100843a68:     	ldrb	w8, [x8]
100843a6c:     	cmp	w8, #0xff
100843a70:     	b.ne	0x1008438e0 <_js_json_stringify_full+0x81c>
100843a74:     	b	0x1008438d4 <_js_json_stringify_full+0x810>
100843a78:     	mov	w21, #0x1               ; =1
100843a7c:     	ldr	x25, [x0, #0x8]
100843a80:     	mov	x0, x25
100843a84:     	bl	0x1005782c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100843a88:     	cbz	x0, 0x100843bc8 <_js_json_stringify_full+0xb04>
100843a8c:     	ldrb	w8, [x0]
100843a90:     	cmp	w8, #0x1
100843a94:     	b.ne	0x100843bc8 <_js_json_stringify_full+0xb04>
100843a98:     	cmp	w21, #0x3f
100843a9c:     	b.hi	0x100843bc8 <_js_json_stringify_full+0xb04>
100843aa0:     	add	w21, w21, #0x1
100843aa4:     	ldrsb	w8, [x0, #0x1]
100843aa8:     	tbnz	w8, #0x1f, 0x100843a7c <_js_json_stringify_full+0x9b8>
100843aac:     	str	x25, [x26, #0x8]
100843ab0:     	ldrb	w8, [x26, #0x1]
100843ab4:     	orr	w8, w8, #0x80
100843ab8:     	strb	w8, [x26, #0x1]
100843abc:     	ldrb	w8, [x0]
100843ac0:     	mov	x21, x28
100843ac4:     	cmp	w8, #0x1
100843ac8:     	b.ne	0x100843964 <_js_json_stringify_full+0x8a0>
100843acc:     	ldp	w9, w8, [x25]
100843ad0:     	cmp	w9, w8
100843ad4:     	b.ls	0x100843af4 <_js_json_stringify_full+0xa30>
100843ad8:     	cbz	x26, 0x100843b04 <_js_json_stringify_full+0xa40>
100843adc:     	ldr	w9, [x0, #0x4]
100843ae0:     	ubfiz	x8, x8, #3, #32
100843ae4:     	add	x8, x8, #0x10
100843ae8:     	cmp	x8, x9
100843aec:     	b.eq	0x100843b1c <_js_json_stringify_full+0xa58>
100843af0:     	b	0x100843b04 <_js_json_stringify_full+0xa40>
100843af4:     	mov	w8, #0xe100             ; =57600
100843af8:     	movk	w8, #0x5f5, lsl #16
100843afc:     	cmp	w9, w8
100843b00:     	b.ls	0x100843b1c <_js_json_stringify_full+0xa58>
100843b04:     	mov	x0, x25
100843b08:     	bl	0x100586734 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100843b0c:     	tbnz	w0, #0x0, 0x100843b1c <_js_json_stringify_full+0xa58>
100843b10:     	mov	x0, x25
100843b14:     	bl	0x1002a1608 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
100843b18:     	tbz	w0, #0x0, 0x100843bc4 <_js_json_stringify_full+0xb00>
100843b1c:     	ldp	w8, w9, [x25]
100843b20:     	sub	w10, w9, #0x1
100843b24:     	mov	w11, #0x270e            ; =9998
100843b28:     	cmp	w10, w11
100843b2c:     	ccmp	w8, w9, #0x2, ls
100843b30:     	b.hi	0x100843bc4 <_js_json_stringify_full+0xb00>
100843b34:     	and	x8, x22, #0xffffffffffff
100843b38:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100843b3c:     	cmp	x27, x9
100843b40:     	csel	x23, x8, x22, eq
100843b44:     	lsr	x9, x23, #51
100843b48:     	cmp	x9, #0xfff
100843b4c:     	b.lo	0x100843b68 <_js_json_stringify_full+0xaa4>
100843b50:     	lsr	x9, x23, #48
100843b54:     	mov	w10, #0x7ffc            ; =32764
100843b58:     	cmp	x9, x10
100843b5c:     	ccmp	x8, #0x0, #0x4, ne
100843b60:     	and	x23, x22, #0xffffffffffff
100843b64:     	b.eq	0x100844938 <_js_json_stringify_full+0x1874>
100843b68:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
100843b6c:     	mov	x9, #0x7fffffffffff     ; =140737488355327
100843b70:     	movk	x9, #0xffef, lsl #16
100843b74:     	cmp	x8, x9
100843b78:     	b.hi	0x100844938 <_js_json_stringify_full+0x1874>
100843b7c:     	tst	x23, #0x3
100843b80:     	mov	x28, x23
100843b84:     	b.eq	0x100844430 <_js_json_stringify_full+0x136c>
100843b88:     	mov	x0, x23
100843b8c:     	bl	0x1005782c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100843b90:     	str	x21, [sp, #0x10]
100843b94:     	cbz	x0, 0x1008444bc <_js_json_stringify_full+0x13f8>
100843b98:     	ldrb	w8, [x0]
100843b9c:     	cmp	w8, #0x1
100843ba0:     	b.ne	0x1008444d4 <_js_json_stringify_full+0x1410>
100843ba4:     	ldrsb	w8, [x0, #0x1]
100843ba8:     	tbnz	w8, #0x1f, 0x100844614 <_js_json_stringify_full+0x1550>
100843bac:     	mov	x23, x28
100843bb0:     	ldp	w9, w8, [x28]
100843bb4:     	cmp	w9, w8
100843bb8:     	ldr	x21, [sp, #0x10]
100843bbc:     	b.hi	0x1008446c4 <_js_json_stringify_full+0x1600>
100843bc0:     	b	0x100844700 <_js_json_stringify_full+0x163c>
100843bc4:     	mov	x28, x21
100843bc8:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100843bcc:     	cmp	x27, x8
100843bd0:     	b.ne	0x100843a0c <_js_json_stringify_full+0x948>
100843bd4:     	and	x8, x22, #0xffffffffffff
100843bd8:     	mov	x21, x28
100843bdc:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100843be0:     	b.hs	0x100844150 <_js_json_stringify_full+0x108c>
100843be4:     	mov	w24, #0x0               ; =0
100843be8:     	mov	x27, #-0x1              ; =-1
100843bec:     	mov	w26, #0x1               ; =1
100843bf0:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100843bf4:     	add	x0, x0, #0xd78
100843bf8:     	ldr	x8, [x0]
100843bfc:     	blr	x8
100843c00:     	mov	x22, x0
100843c04:     	ldr	w28, [x0]
100843c08:     	add	w8, w28, #0x1
100843c0c:     	str	w8, [x0]
100843c10:     	cbz	w28, 0x100843c80 <_js_json_stringify_full+0xbbc>
100843c14:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100843c18:     	add	x0, x0, #0xd00
100843c1c:     	ldr	x8, [x0]
100843c20:     	blr	x8
100843c24:     	ldrb	w8, [x0, #0x20]
100843c28:     	cmp	w8, #0x1
100843c2c:     	b.ne	0x1008445fc <_js_json_stringify_full+0x1538>
100843c30:     	ldr	x8, [x0]
100843c34:     	cbnz	x8, 0x100844608 <_js_json_stringify_full+0x1544>
100843c38:     	mov	x8, #-0x1               ; =-1
100843c3c:     	str	x8, [x0]
100843c40:     	ldr	x25, [x0, #0x18]
100843c44:     	ldr	x8, [x0, #0x8]
100843c48:     	cmp	x25, x8
100843c4c:     	b.eq	0x100844388 <_js_json_stringify_full+0x12c4>
100843c50:     	ldr	x8, [x0, #0x10]
100843c54:     	mov	w9, #0x18               ; =24
100843c58:     	madd	x8, x25, x9, x8
100843c5c:     	mov	w9, #0x8                ; =8
100843c60:     	stp	xzr, x9, [x8]
100843c64:     	str	xzr, [x8, #0x10]
100843c68:     	add	x8, x25, #0x1
100843c6c:     	str	x8, [x0, #0x18]
100843c70:     	ldr	x8, [x0]
100843c74:     	add	x8, x8, #0x1
100843c78:     	str	x8, [x0]
100843c7c:     	b	0x100843ce8 <_js_json_stringify_full+0xc24>
100843c80:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100843c84:     	add	x0, x0, #0xdc0
100843c88:     	ldr	x8, [x0]
100843c8c:     	blr	x8
100843c90:     	strb	wzr, [x0]
100843c94:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100843c98:     	add	x0, x0, #0xdf0
100843c9c:     	ldr	x8, [x0]
100843ca0:     	blr	x8
100843ca4:     	strb	wzr, [x0]
100843ca8:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100843cac:     	ldr	w25, [x8, #0x5a8]
100843cb0:     	cmp	w25, #0x300
100843cb4:     	b.hs	0x1008443f8 <_js_json_stringify_full+0x1334>
100843cb8:     	adrp	x8, 0x100f7c000 <_perry_global_options_worker_ts__1>
100843cbc:     	ldr	x8, [x8, #0x48]
100843cc0:     	cmn	x8, #0x1
100843cc4:     	b.eq	0x1008443e8 <_js_json_stringify_full+0x1324>
100843cc8:     	mrs	x9, TPIDRRO_EL0
100843ccc:     	and	x9, x9, #0xfffffffffffffff8
100843cd0:     	ldr	x0, [x9, x8, lsl #3]
100843cd4:     	cbz	x0, 0x1008443e8 <_js_json_stringify_full+0x1324>
100843cd8:     	add	x8, x0, x25, lsl #3
100843cdc:     	ldr	x0, [x8, #0x1e8]
100843ce0:     	cbz	x0, 0x1008443f8 <_js_json_stringify_full+0x1334>
100843ce4:     	str	xzr, [x0]
100843ce8:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100843cec:     	add	x0, x0, #0xd30
100843cf0:     	ldr	x8, [x0]
100843cf4:     	blr	x8
100843cf8:     	mov	x25, x0
100843cfc:     	ldrb	w8, [x0, #0x18]
100843d00:     	cmp	w8, #0x1
100843d04:     	b.ne	0x10084451c <_js_json_stringify_full+0x1458>
100843d08:     	ldr	x8, [x0]
100843d0c:     	mov	x9, #-0x1               ; =-1
100843d10:     	str	x9, [x0]
100843d14:     	cmn	x8, #0x2
100843d18:     	b.eq	0x1008447f0 <_js_json_stringify_full+0x172c>
100843d1c:     	cmn	x8, #0x1
100843d20:     	b.eq	0x100843df8 <_js_json_stringify_full+0xd34>
100843d24:     	sub	x9, x29, #0x80
100843d28:     	ldur	q0, [x0, #0x8]
100843d2c:     	stur	q0, [x9, #0x8]
100843d30:     	stur	x8, [x29, #-0x80]
100843d34:     	tbz	w26, #0x0, 0x100843e0c <_js_json_stringify_full+0xd48>
100843d38:     	tbz	w24, #0x0, 0x100843efc <_js_json_stringify_full+0xe38>
100843d3c:     	bl	0x100288ad8 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
100843d40:     	str	x0, [sp, #0x50]
100843d44:     	mov	x10, #0x7ffd000000000000 ; =9222527611924643840
100843d48:     	mov	w8, #0x1                ; =1
100843d4c:     	ldr	x9, [sp, #0x20]
100843d50:     	stp	x9, x10, [sp, #0x70]
100843d54:     	str	x8, [sp, #0x68]
100843d58:     	add	x0, sp, #0x68
100843d5c:     	bl	0x100288be0 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
100843d60:     	mov	x21, x0
100843d64:     	str	x0, [sp, #0x58]
100843d68:     	mov	w0, #0x0                ; =0
100843d6c:     	bl	0x1003488ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100843d70:     	stp	xzr, xzr, [x0]
100843d74:     	str	wzr, [x0, #0x10]
100843d78:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100843d7c:     	bfxil	x8, x0, #0, #48
100843d80:     	fmov	d0, x8
100843d84:     	bl	0x1002087e4 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
100843d88:     	mov	x20, x0
100843d8c:     	adrp	x24, 0x100f7c000 <_perry_global_options_worker_ts__1>
100843d90:     	ldr	x8, [x24, #0x48]
100843d94:     	cmn	x8, #0x1
100843d98:     	b.eq	0x100843fa8 <_js_json_stringify_full+0xee4>
100843d9c:     	mrs	x9, TPIDRRO_EL0
100843da0:     	and	x9, x9, #0xfffffffffffffff8
100843da4:     	ldr	x8, [x9, x8, lsl #3]
100843da8:     	cbz	x8, 0x100843fa8 <_js_json_stringify_full+0xee4>
100843dac:     	ldr	x8, [x8, #0x19e8]
100843db0:     	cbz	x8, 0x100843fa8 <_js_json_stringify_full+0xee4>
100843db4:     	ldr	x9, [x8]
100843db8:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100843dbc:     	cmp	x9, x10
100843dc0:     	b.hs	0x1008447d8 <_js_json_stringify_full+0x1714>
100843dc4:     	add	x10, x9, #0x1
100843dc8:     	str	x10, [x8]
100843dcc:     	ldr	x10, [x8, #0x18]
100843dd0:     	cmp	x20, x10
100843dd4:     	b.hs	0x1008447e4 <_js_json_stringify_full+0x1720>
100843dd8:     	ldr	x10, [x8, #0x10]
100843ddc:     	mov	w11, #0x18              ; =24
100843de0:     	madd	x10, x20, x11, x10
100843de4:     	ldr	x11, [x10]
100843de8:     	cbnz	x11, 0x1008447fc <_js_json_stringify_full+0x1738>
100843dec:     	ldr	x0, [x10, #0x8]
100843df0:     	str	x9, [x8]
100843df4:     	b	0x100843fb0 <_js_json_stringify_full+0xeec>
100843df8:     	mov	x8, #0x0                ; =0
100843dfc:     	mov	w9, #0x1                ; =1
100843e00:     	stp	x9, xzr, [x29, #-0x78]
100843e04:     	stur	x8, [x29, #-0x80]
100843e08:     	tbnz	w26, #0x0, 0x100843d38 <_js_json_stringify_full+0xc74>
100843e0c:     	cmp	x21, #0x0
100843e10:     	cset	w6, ne
100843e14:     	ldp	x3, x4, [sp, #0x38]
100843e18:     	sub	x2, x29, #0x80
100843e1c:     	mov.16b	v0, v8
100843e20:     	ldr	x24, [sp, #0x28]
100843e24:     	mov	x0, x24
100843e28:     	mov	x1, x23
100843e2c:     	mov	x5, #0x0                ; =0
100843e30:     	bl	0x100500780 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
100843e34:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100843e38:     	add	x0, x0, #0xd90
100843e3c:     	ldr	x8, [x0]
100843e40:     	blr	x8
100843e44:     	ldrb	w8, [x0, #0x20]
100843e48:     	cbnz	w8, 0x100844764 <_js_json_stringify_full+0x16a0>
100843e4c:     	ldr	x8, [x0]
100843e50:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100843e54:     	cmp	x8, x9
100843e58:     	b.hs	0x100844798 <_js_json_stringify_full+0x16d4>
100843e5c:     	ldr	x9, [x0, #0x18]
100843e60:     	cbz	x9, 0x100843e6c <_js_json_stringify_full+0xda8>
100843e64:     	cbnz	x8, 0x1008447a4 <_js_json_stringify_full+0x16e0>
100843e68:     	str	xzr, [x0, #0x18]
100843e6c:     	ldp	x0, x1, [x29, #-0x78]
100843e70:     	cmp	x1, #0x5
100843e74:     	b.hi	0x100843edc <_js_json_stringify_full+0xe18>
100843e78:     	cbz	x1, 0x100844148 <_js_json_stringify_full+0x1084>
100843e7c:     	ldrsb	w8, [x0]
100843e80:     	tbnz	w8, #0x1f, 0x100843edc <_js_json_stringify_full+0xe18>
100843e84:     	cmp	x1, #0x1
100843e88:     	b.eq	0x100843ec4 <_js_json_stringify_full+0xe00>
100843e8c:     	ldrsb	w8, [x0, #0x1]
100843e90:     	tbnz	w8, #0x1f, 0x100843edc <_js_json_stringify_full+0xe18>
100843e94:     	cmp	x1, #0x2
100843e98:     	b.eq	0x100843ec4 <_js_json_stringify_full+0xe00>
100843e9c:     	ldrsb	w8, [x0, #0x2]
100843ea0:     	tbnz	w8, #0x1f, 0x100843edc <_js_json_stringify_full+0xe18>
100843ea4:     	cmp	x1, #0x3
100843ea8:     	b.eq	0x100843ec4 <_js_json_stringify_full+0xe00>
100843eac:     	ldrsb	w8, [x0, #0x3]
100843eb0:     	tbnz	w8, #0x1f, 0x100843edc <_js_json_stringify_full+0xe18>
100843eb4:     	cmp	x1, #0x4
100843eb8:     	b.eq	0x100843ec4 <_js_json_stringify_full+0xe00>
100843ebc:     	ldrsb	w8, [x0, #0x4]
100843ec0:     	tbnz	w8, #0x1f, 0x100843edc <_js_json_stringify_full+0xe18>
100843ec4:     	cmp	x1, #0x4
100843ec8:     	b.hs	0x1008441f4 <_js_json_stringify_full+0x1130>
100843ecc:     	mov	x10, #0x0               ; =0
100843ed0:     	mov	x9, #0x0                ; =0
100843ed4:     	mov	x8, x0
100843ed8:     	b	0x100844284 <_js_json_stringify_full+0x11c0>
100843edc:     	bl	0x1003275d0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
100843ee0:     	mov	x19, #0x7fff000000000000 ; =9223090561878065152
100843ee4:     	bfxil	x19, x0, #0, #48
100843ee8:     	ldp	x21, x0, [x29, #-0x80]
100843eec:     	ldrb	w8, [x25, #0x18]
100843ef0:     	cmp	w8, #0x1
100843ef4:     	b.eq	0x1008442c0 <_js_json_stringify_full+0x11fc>
100843ef8:     	b	0x1008445a8 <_js_json_stringify_full+0x14e4>
100843efc:     	mov	w0, #0x0                ; =0
100843f00:     	bl	0x1003488ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100843f04:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100843f08:     	bfxil	x8, x0, #0, #48
100843f0c:     	fmov	d1, x8
100843f10:     	stp	xzr, xzr, [x0]
100843f14:     	str	wzr, [x0, #0x10]
100843f18:     	mov.16b	v0, v8
100843f1c:     	bl	0x1004fd9bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100843f20:     	mov.16b	v8, v0
100843f24:     	fmov	x26, d8
100843f28:     	cmp	x26, x19
100843f2c:     	b.eq	0x100843f48 <_js_json_stringify_full+0xe84>
100843f30:     	mov	x0, x26
100843f34:     	bl	0x100507b7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify16is_closure_value>
100843f38:     	tbnz	w0, #0x0, 0x100843f48 <_js_json_stringify_full+0xe84>
100843f3c:     	mov	x0, x26
100843f40:     	bl	0x100506d94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
100843f44:     	tbz	w0, #0x0, 0x1008443b8 <_js_json_stringify_full+0x12f4>
100843f48:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100843f4c:     	add	x0, x0, #0xd90
100843f50:     	ldr	x8, [x0]
100843f54:     	blr	x8
100843f58:     	ldrb	w8, [x0, #0x20]
100843f5c:     	ldr	x24, [sp, #0x28]
100843f60:     	cbnz	w8, 0x1008447e8 <_js_json_stringify_full+0x1724>
100843f64:     	ldr	x8, [x0]
100843f68:     	cbnz	x8, 0x100844d3c <_js_json_stringify_full+0x1c78>
100843f6c:     	str	xzr, [x0, #0x18]
100843f70:     	ldp	x21, x20, [x29, #-0x80]
100843f74:     	ldrb	w8, [x25, #0x18]
100843f78:     	cmp	w8, #0x1
100843f7c:     	b.ne	0x1008447b0 <_js_json_stringify_full+0x16ec>
100843f80:     	ldp	x8, x0, [x25]
100843f84:     	stp	x21, x20, [x25]
100843f88:     	str	xzr, [x25, #0x10]
100843f8c:     	sub	x8, x8, #0x1
100843f90:     	cmn	x8, #0x2
100843f94:     	b.hs	0x100843f9c <_js_json_stringify_full+0xed8>
100843f98:     	bl	0x100b5c2c0 <_mi_free>
100843f9c:     	cbz	w28, 0x100844194 <_js_json_stringify_full+0x10d0>
100843fa0:     	bl	0x1003257a8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100843fa4:     	b	0x100844198 <_js_json_stringify_full+0x10d4>
100843fa8:     	mov	x0, x20
100843fac:     	bl	0x1001399f0 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100843fb0:     	fmov	d1, x0
100843fb4:     	mov.16b	v0, v8
100843fb8:     	bl	0x1004fd9bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100843fbc:     	mov.16b	v8, v0
100843fc0:     	ldr	x8, [x24, #0x48]
100843fc4:     	cmn	x8, #0x1
100843fc8:     	b.eq	0x10084402c <_js_json_stringify_full+0xf68>
100843fcc:     	mrs	x9, TPIDRRO_EL0
100843fd0:     	and	x9, x9, #0xfffffffffffffff8
100843fd4:     	ldr	x8, [x9, x8, lsl #3]
100843fd8:     	cbz	x8, 0x10084402c <_js_json_stringify_full+0xf68>
100843fdc:     	ldr	x8, [x8, #0x19e8]
100843fe0:     	cbz	x8, 0x10084402c <_js_json_stringify_full+0xf68>
100843fe4:     	ldr	x9, [x8]
100843fe8:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100843fec:     	cmp	x9, x10
100843ff0:     	b.hs	0x1008447d8 <_js_json_stringify_full+0x1714>
100843ff4:     	add	x10, x9, #0x1
100843ff8:     	str	x10, [x8]
100843ffc:     	ldr	x10, [x8, #0x18]
100844000:     	cmp	x21, x10
100844004:     	b.hs	0x1008447e4 <_js_json_stringify_full+0x1720>
100844008:     	ldr	x10, [x8, #0x10]
10084400c:     	mov	w11, #0x18              ; =24
100844010:     	madd	x10, x21, x11, x10
100844014:     	ldr	x11, [x10]
100844018:     	cmp	x11, #0x1
10084401c:     	b.ne	0x100844d54 <_js_json_stringify_full+0x1c90>
100844020:     	ldr	x21, [x10, #0x8]
100844024:     	str	x9, [x8]
100844028:     	b	0x100844038 <_js_json_stringify_full+0xf74>
10084402c:     	mov	x0, x21
100844030:     	bl	0x100139918 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
100844034:     	mov	x21, x0
100844038:     	ldr	x8, [x24, #0x48]
10084403c:     	cmn	x8, #0x1
100844040:     	b.eq	0x1008440a4 <_js_json_stringify_full+0xfe0>
100844044:     	mrs	x9, TPIDRRO_EL0
100844048:     	and	x9, x9, #0xfffffffffffffff8
10084404c:     	ldr	x8, [x9, x8, lsl #3]
100844050:     	cbz	x8, 0x1008440a4 <_js_json_stringify_full+0xfe0>
100844054:     	ldr	x8, [x8, #0x19e8]
100844058:     	ldr	x24, [sp, #0x28]
10084405c:     	cbz	x8, 0x1008443ac <_js_json_stringify_full+0x12e8>
100844060:     	ldr	x9, [x8]
100844064:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100844068:     	cmp	x9, x10
10084406c:     	b.hs	0x1008447d8 <_js_json_stringify_full+0x1714>
100844070:     	add	x10, x9, #0x1
100844074:     	str	x10, [x8]
100844078:     	ldr	x10, [x8, #0x18]
10084407c:     	cmp	x20, x10
100844080:     	b.hs	0x1008447e4 <_js_json_stringify_full+0x1720>
100844084:     	ldr	x10, [x8, #0x10]
100844088:     	mov	w11, #0x18              ; =24
10084408c:     	madd	x10, x20, x11, x10
100844090:     	ldr	x11, [x10]
100844094:     	cbnz	x11, 0x1008447fc <_js_json_stringify_full+0x1738>
100844098:     	ldr	x0, [x10, #0x8]
10084409c:     	str	x9, [x8]
1008440a0:     	b	0x1008440b0 <_js_json_stringify_full+0xfec>
1008440a4:     	mov	x0, x20
1008440a8:     	bl	0x1001399f0 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
1008440ac:     	ldr	x24, [sp, #0x28]
1008440b0:     	fmov	d9, x0
1008440b4:     	mov.16b	v0, v8
1008440b8:     	bl	0x1004fd4f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
1008440bc:     	mov.16b	v2, v0
1008440c0:     	mov	x0, x21
1008440c4:     	mov.16b	v0, v9
1008440c8:     	mov.16b	v1, v8
1008440cc:     	bl	0x1004fd7d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
1008440d0:     	str	d0, [sp, #0x60]
1008440d4:     	fmov	x20, d0
1008440d8:     	cmp	x20, x19
1008440dc:     	b.ne	0x1008440f8 <_js_json_stringify_full+0x1034>
1008440e0:     	bl	0x100139d0c <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecjEEE4withNCNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22js_json_stringify_fulls1_0uEB2j_>
1008440e4:     	ldp	x0, x1, [x29, #-0x80]
1008440e8:     	bl	0x100326e54 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json21restore_stringify_buf>
1008440ec:     	cbz	w28, 0x1008441a8 <_js_json_stringify_full+0x10e4>
1008440f0:     	bl	0x1003257a8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
1008440f4:     	b	0x1008441ac <_js_json_stringify_full+0x10e8>
1008440f8:     	sub	x0, x29, #0x80
1008440fc:     	bl	0x1004fdd38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
100844100:     	tbnz	w0, #0x0, 0x10084413c <_js_json_stringify_full+0x1078>
100844104:     	mov	x0, x20
100844108:     	bl	0x1003254ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
10084410c:     	cmp	x0, #0x1
100844110:     	b.ne	0x100844d48 <_js_json_stringify_full+0x1c84>
100844114:     	add	x8, sp, #0x88
100844118:     	add	x9, sp, #0x60
10084411c:     	stp	x8, x9, [sp, #0x68]
100844120:     	sub	x8, x29, #0x80
100844124:     	add	x9, sp, #0x30
100844128:     	str	x8, [sp, #0x78]
10084412c:     	stp	x9, x1, [sp, #0x80]
100844130:     	add	x0, sp, #0x58
100844134:     	add	x1, sp, #0x68
100844138:     	bl	0x100141450 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
10084413c:     	add	x0, sp, #0x50
100844140:     	bl	0x10016453c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100844144:     	b	0x100843e34 <_js_json_stringify_full+0xd70>
100844148:     	mov	x10, #0x0               ; =0
10084414c:     	b	0x1008442a4 <_js_json_stringify_full+0x11e0>
100844150:     	mov	x9, #-0x1               ; =-1
100844154:     	ldr	w8, [x8, #0xc]
100844158:     	mov	w10, #0x4f53            ; =20307
10084415c:     	movk	w10, #0x434c, lsl #16
100844160:     	and	x11, x22, #0xffffffffffff
100844164:     	mov	x12, #0x7ffd000000000000 ; =9222527611924643840
100844168:     	cmp	x27, x12
10084416c:     	csel	x11, x11, x22, eq
100844170:     	mov	x12, #-0x1              ; =-1
100844174:     	mov	w13, #0x1               ; =1
100844178:     	cmp	w8, w10
10084417c:     	csinc	w26, w13, wzr, eq
100844180:     	csel	x27, x9, x12, ne
100844184:     	cset	w24, eq
100844188:     	csel	x8, x8, x11, ne
10084418c:     	str	x8, [sp, #0x20]
100844190:     	b	0x100843bf0 <_js_json_stringify_full+0xb2c>
100844194:     	bl	0x1003255d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100844198:     	ldr	w8, [x22]
10084419c:     	sub	w8, w8, #0x1
1008441a0:     	str	w8, [x22]
1008441a4:     	b	0x1008441c0 <_js_json_stringify_full+0x10fc>
1008441a8:     	bl	0x1003255d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
1008441ac:     	ldr	w8, [x22]
1008441b0:     	sub	w8, w8, #0x1
1008441b4:     	str	w8, [x22]
1008441b8:     	add	x0, sp, #0x50
1008441bc:     	bl	0x10016453c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
1008441c0:     	cmn	x27, #0x1
1008441c4:     	b.eq	0x100844350 <_js_json_stringify_full+0x128c>
1008441c8:     	cbz	x23, 0x100844344 <_js_json_stringify_full+0x1280>
1008441cc:     	add	x20, x24, #0x8
1008441d0:     	b	0x1008441e0 <_js_json_stringify_full+0x111c>
1008441d4:     	add	x20, x20, #0x18
1008441d8:     	subs	x23, x23, #0x1
1008441dc:     	b.eq	0x100844344 <_js_json_stringify_full+0x1280>
1008441e0:     	ldur	x8, [x20, #-0x8]
1008441e4:     	cbz	x8, 0x1008441d4 <_js_json_stringify_full+0x1110>
1008441e8:     	ldr	x0, [x20]
1008441ec:     	bl	0x100b5c2c0 <_mi_free>
1008441f0:     	b	0x1008441d4 <_js_json_stringify_full+0x1110>
1008441f4:     	and	x9, x1, #0x4
1008441f8:     	add	x8, x0, x9
1008441fc:     	adrp	x10, 0x100c96000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4b20>
100844200:     	ldr	q0, [x10, #0xd50]
100844204:     	adrp	x10, 0x100c36000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x3332a>
100844208:     	ldr	q2, [x10, #0xc50]
10084420c:     	movi.2d	v1, #0000000000000000
100844210:     	movi.2d	v3, #0x000000000000ff
100844214:     	mov	w10, #0x4               ; =4
100844218:     	dup.2d	v4, x10
10084421c:     	mov	x10, x0
100844220:     	and	x11, x1, #0x4
100844224:     	movi.2d	v5, #0000000000000000
100844228:     	ldr	s6, [x10], #0x4
10084422c:     	ushll.8h	v6, v6, #0x0
100844230:     	ushll.4s	v6, v6, #0x0
100844234:     	ushll2.2d	v7, v6, #0x0
100844238:     	and.16b	v7, v7, v3
10084423c:     	ushll.2d	v6, v6, #0x0
100844240:     	and.16b	v6, v6, v3
100844244:     	shl.2d	v16, v0, #0x3
100844248:     	shl.2d	v17, v2, #0x3
10084424c:     	ushl.2d	v6, v6, v17
100844250:     	ushl.2d	v7, v7, v16
100844254:     	orr.16b	v1, v7, v1
100844258:     	orr.16b	v5, v6, v5
10084425c:     	add.2d	v0, v0, v4
100844260:     	add.2d	v2, v2, v4
100844264:     	subs	x11, x11, #0x4
100844268:     	b.ne	0x100844228 <_js_json_stringify_full+0x1164>
10084426c:     	orr.16b	v0, v5, v1
100844270:     	mov	d1, v0[1]
100844274:     	orr.8b	v0, v0, v1
100844278:     	fmov	x10, d0
10084427c:     	cmp	x1, x9
100844280:     	b.eq	0x1008442a4 <_js_json_stringify_full+0x11e0>
100844284:     	add	x11, x0, x1
100844288:     	lsl	x9, x9, #3
10084428c:     	ldrb	w12, [x8], #0x1
100844290:     	lsl	x12, x12, x9
100844294:     	orr	x10, x12, x10
100844298:     	add	x9, x9, #0x8
10084429c:     	cmp	x8, x11
1008442a0:     	b.ne	0x10084428c <_js_json_stringify_full+0x11c8>
1008442a4:     	orr	x8, x10, x1, lsl #40
1008442a8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1008442ac:     	orr	x19, x8, x9
1008442b0:     	ldur	x21, [x29, #-0x80]
1008442b4:     	ldrb	w8, [x25, #0x18]
1008442b8:     	cmp	w8, #0x1
1008442bc:     	b.ne	0x1008445a8 <_js_json_stringify_full+0x14e4>
1008442c0:     	ldp	x9, x8, [x25]
1008442c4:     	stp	x21, x0, [x25]
1008442c8:     	str	xzr, [x25, #0x10]
1008442cc:     	sub	x9, x9, #0x1
1008442d0:     	cmn	x9, #0x2
1008442d4:     	b.hs	0x1008442e0 <_js_json_stringify_full+0x121c>
1008442d8:     	mov	x0, x8
1008442dc:     	bl	0x100b5c2c0 <_mi_free>
1008442e0:     	cbz	w28, 0x100844300 <_js_json_stringify_full+0x123c>
1008442e4:     	bl	0x1003257a8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
1008442e8:     	ldr	w8, [x22]
1008442ec:     	sub	w8, w8, #0x1
1008442f0:     	str	w8, [x22]
1008442f4:     	cmn	x27, #0x1
1008442f8:     	b.ne	0x100844318 <_js_json_stringify_full+0x1254>
1008442fc:     	b	0x100844350 <_js_json_stringify_full+0x128c>
100844300:     	bl	0x1003255d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100844304:     	ldr	w8, [x22]
100844308:     	sub	w8, w8, #0x1
10084430c:     	str	w8, [x22]
100844310:     	cmn	x27, #0x1
100844314:     	b.eq	0x100844350 <_js_json_stringify_full+0x128c>
100844318:     	cbz	x23, 0x100844344 <_js_json_stringify_full+0x1280>
10084431c:     	add	x20, x24, #0x8
100844320:     	b	0x100844330 <_js_json_stringify_full+0x126c>
100844324:     	add	x20, x20, #0x18
100844328:     	subs	x23, x23, #0x1
10084432c:     	b.eq	0x100844344 <_js_json_stringify_full+0x1280>
100844330:     	ldur	x8, [x20, #-0x8]
100844334:     	cbz	x8, 0x100844324 <_js_json_stringify_full+0x1260>
100844338:     	ldr	x0, [x20]
10084433c:     	bl	0x100b5c2c0 <_mi_free>
100844340:     	b	0x100844324 <_js_json_stringify_full+0x1260>
100844344:     	cbz	x27, 0x100844350 <_js_json_stringify_full+0x128c>
100844348:     	mov	x0, x24
10084434c:     	bl	0x100b5c2c0 <_mi_free>
100844350:     	ldr	x8, [sp, #0x30]
100844354:     	cbz	x8, 0x100844360 <_js_json_stringify_full+0x129c>
100844358:     	ldr	x0, [sp, #0x38]
10084435c:     	bl	0x100b5c2c0 <_mi_free>
100844360:     	mov	x0, x19
100844364:     	ldp	x29, x30, [sp, #0x120]
100844368:     	ldp	x20, x19, [sp, #0x110]
10084436c:     	ldp	x22, x21, [sp, #0x100]
100844370:     	ldp	x24, x23, [sp, #0xf0]
100844374:     	ldp	x26, x25, [sp, #0xe0]
100844378:     	ldp	x28, x27, [sp, #0xd0]
10084437c:     	ldp	d9, d8, [sp, #0xc0]
100844380:     	add	sp, sp, #0x130
100844384:     	ret
100844388:     	str	x27, [sp, #0x18]
10084438c:     	mov	x27, x21
100844390:     	mov	x21, x0
100844394:     	add	x0, x0, #0x8
100844398:     	bl	0x100b39050 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10084439c:     	mov	x0, x21
1008443a0:     	mov	x21, x27
1008443a4:     	ldr	x27, [sp, #0x18]
1008443a8:     	b	0x100843c50 <_js_json_stringify_full+0xb8c>
1008443ac:     	mov	x0, x20
1008443b0:     	bl	0x1001399f0 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
1008443b4:     	b	0x1008440b0 <_js_json_stringify_full+0xfec>
1008443b8:     	cmp	x20, x26
1008443bc:     	ldr	x24, [sp, #0x28]
1008443c0:     	b.eq	0x1008443cc <_js_json_stringify_full+0x1308>
1008443c4:     	mov.16b	v0, v8
1008443c8:     	bl	0x10050c16c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
1008443cc:     	cbz	x21, 0x100844408 <_js_json_stringify_full+0x1344>
1008443d0:     	ldp	x1, x2, [sp, #0x38]
1008443d4:     	sub	x0, x29, #0x80
1008443d8:     	mov.16b	v0, v8
1008443dc:     	mov	x3, #0x0                ; =0
1008443e0:     	bl	0x1004fe828 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
1008443e4:     	b	0x100844418 <_js_json_stringify_full+0x1354>
1008443e8:     	bl	0x100b3c6fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1008443ec:     	add	x8, x0, x25, lsl #3
1008443f0:     	ldr	x0, [x8, #0x1e8]
1008443f4:     	cbnz	x0, 0x100843ce4 <_js_json_stringify_full+0xc20>
1008443f8:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
1008443fc:     	add	x0, x0, #0x180
100844400:     	bl	0x100b39f1c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100844404:     	b	0x100843ce4 <_js_json_stringify_full+0xc20>
100844408:     	sub	x1, x29, #0x80
10084440c:     	mov.16b	v0, v8
100844410:     	mov	w0, #0x0                ; =0
100844414:     	bl	0x100506e6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
100844418:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10084441c:     	add	x0, x0, #0xdc0
100844420:     	ldr	x8, [x0]
100844424:     	blr	x8
100844428:     	strb	wzr, [x0]
10084442c:     	b	0x100843e34 <_js_json_stringify_full+0xd70>
100844430:     	adrp	x8, 0x100f7c000 <_perry_global_options_worker_ts__1>
100844434:     	ldr	x8, [x8, #0x48]
100844438:     	cmn	x8, #0x1
10084443c:     	b.eq	0x100844824 <_js_json_stringify_full+0x1760>
100844440:     	mrs	x9, TPIDRRO_EL0
100844444:     	and	x9, x9, #0xfffffffffffffff8
100844448:     	ldr	x0, [x9, x8, lsl #3]
10084444c:     	cbz	x0, 0x100844824 <_js_json_stringify_full+0x1760>
100844450:     	lsr	x1, x23, #20
100844454:     	ldr	x8, [x0, #0x10]
100844458:     	ldrb	w9, [x8]
10084445c:     	cmp	w9, #0x2
100844460:     	b.ne	0x10084483c <_js_json_stringify_full+0x1778>
100844464:     	ldrb	w9, [x8, #0x88]
100844468:     	tbz	w9, #0x0, 0x100844488 <_js_json_stringify_full+0x13c4>
10084446c:     	ldr	x9, [x8, #0x80]
100844470:     	cmp	x9, x1
100844474:     	b.ne	0x100844488 <_js_json_stringify_full+0x13c4>
100844478:     	ldp	x9, x10, [x8, #0x60]
10084447c:     	cmp	x9, x28
100844480:     	ccmp	x10, x28, #0x0, ls
100844484:     	b.hi	0x10084480c <_js_json_stringify_full+0x1748>
100844488:     	ldrb	w9, [x8, #0xb8]
10084448c:     	cbz	w9, 0x100844574 <_js_json_stringify_full+0x14b0>
100844490:     	ldr	x9, [x8, #0xb0]
100844494:     	cmp	x9, x1
100844498:     	b.ne	0x100844574 <_js_json_stringify_full+0x14b0>
10084449c:     	ldr	x9, [x8, #0x90]
1008444a0:     	cmp	x9, x28
1008444a4:     	b.hi	0x100844574 <_js_json_stringify_full+0x14b0>
1008444a8:     	ldr	x9, [x8, #0x98]
1008444ac:     	cmp	x9, x28
1008444b0:     	b.ls	0x100844574 <_js_json_stringify_full+0x14b0>
1008444b4:     	add	x9, x8, #0x90
1008444b8:     	b	0x100844810 <_js_json_stringify_full+0x174c>
1008444bc:     	str	x0, [sp, #0x18]
1008444c0:     	mov	x0, x23
1008444c4:     	bl	0x100586734 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1008444c8:     	tbz	w0, #0x0, 0x10084452c <_js_json_stringify_full+0x1468>
1008444cc:     	mov	x0, #0x0                ; =0
1008444d0:     	b	0x1008446ac <_js_json_stringify_full+0x15e8>
1008444d4:     	str	x0, [sp, #0x18]
1008444d8:     	cmp	w8, #0x1
1008444dc:     	b.eq	0x1008446ac <_js_json_stringify_full+0x15e8>
1008444e0:     	cmp	w8, #0x9
1008444e4:     	b.ne	0x1008446dc <_js_json_stringify_full+0x1618>
1008444e8:     	ldr	w8, [x28, #0x4]
1008444ec:     	mov	w9, #0x5841             ; =22593
1008444f0:     	movk	w9, #0x4c5a, lsl #16
1008444f4:     	cmp	w8, w9
1008444f8:     	b.ne	0x1008446dc <_js_json_stringify_full+0x1618>
1008444fc:     	mov	x0, x28
100844500:     	bl	0x1003730f0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
100844504:     	mov	x23, x0
100844508:     	ldr	x21, [sp, #0x10]
10084450c:     	cbnz	x0, 0x100844910 <_js_json_stringify_full+0x184c>
100844510:     	mov	w26, #0x0               ; =0
100844514:     	mov	x27, #0x0               ; =0
100844518:     	b	0x100844944 <_js_json_stringify_full+0x1880>
10084451c:     	mov	x0, x25
100844520:     	bl	0x100b1b8c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100844524:     	cbnz	x0, 0x100843d08 <_js_json_stringify_full+0xc44>
100844528:     	b	0x1008447f0 <_js_json_stringify_full+0x172c>
10084452c:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100844530:     	add	x8, x8, #0xe80
100844534:     	ldaprb	w8, [x8]
100844538:     	cbz	w8, 0x1008446dc <_js_json_stringify_full+0x1618>
10084453c:     	adrp	x8, 0x100f7c000 <_perry_global_options_worker_ts__1>
100844540:     	add	x8, x8, #0x58
100844544:     	ldapr	x8, [x8]
100844548:     	cmp	x8, x28
10084454c:     	b.hi	0x1008446dc <_js_json_stringify_full+0x1618>
100844550:     	adrp	x8, 0x100f7c000 <_perry_global_options_worker_ts__1>
100844554:     	add	x8, x8, #0x60
100844558:     	ldapr	x8, [x8]
10084455c:     	cmp	x8, x28
100844560:     	b.lo	0x1008446dc <_js_json_stringify_full+0x1618>
100844564:     	mov	x0, x28
100844568:     	bl	0x1002a2338 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
10084456c:     	tbnz	w0, #0x0, 0x1008444cc <_js_json_stringify_full+0x1408>
100844570:     	b	0x1008446dc <_js_json_stringify_full+0x1618>
100844574:     	ldrb	w9, [x8, #0xe8]
100844578:     	cbz	w9, 0x1008445c4 <_js_json_stringify_full+0x1500>
10084457c:     	ldr	x9, [x8, #0xe0]
100844580:     	cmp	x9, x1
100844584:     	b.ne	0x1008445c4 <_js_json_stringify_full+0x1500>
100844588:     	ldr	x9, [x8, #0xc0]
10084458c:     	cmp	x9, x28
100844590:     	b.hi	0x1008445c4 <_js_json_stringify_full+0x1500>
100844594:     	ldr	x9, [x8, #0xc8]
100844598:     	cmp	x9, x28
10084459c:     	b.ls	0x1008445c4 <_js_json_stringify_full+0x1500>
1008445a0:     	add	x9, x8, #0xc0
1008445a4:     	b	0x100844810 <_js_json_stringify_full+0x174c>
1008445a8:     	mov	x20, x0
1008445ac:     	mov	x0, x25
1008445b0:     	bl	0x100b1b8c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008445b4:     	mov	x25, x0
1008445b8:     	mov	x0, x20
1008445bc:     	cbnz	x25, 0x1008442c0 <_js_json_stringify_full+0x11fc>
1008445c0:     	b	0x1008447c0 <_js_json_stringify_full+0x16fc>
1008445c4:     	ldrb	w9, [x8, #0x118]
1008445c8:     	mov	x23, x28
1008445cc:     	cbz	w9, 0x1008448b4 <_js_json_stringify_full+0x17f0>
1008445d0:     	ldr	x9, [x8, #0x110]
1008445d4:     	cmp	x9, x1
1008445d8:     	b.ne	0x1008448b4 <_js_json_stringify_full+0x17f0>
1008445dc:     	ldr	x9, [x8, #0xf0]
1008445e0:     	cmp	x9, x23
1008445e4:     	b.hi	0x1008448b4 <_js_json_stringify_full+0x17f0>
1008445e8:     	ldr	x9, [x8, #0xf8]
1008445ec:     	cmp	x9, x23
1008445f0:     	b.ls	0x1008448b4 <_js_json_stringify_full+0x17f0>
1008445f4:     	add	x9, x8, #0xf0
1008445f8:     	b	0x100844810 <_js_json_stringify_full+0x174c>
1008445fc:     	bl	0x100b1ba24 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100844600:     	cbnz	x0, 0x100843c30 <_js_json_stringify_full+0xb6c>
100844604:     	b	0x1008447f0 <_js_json_stringify_full+0x172c>
100844608:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
10084460c:     	add	x0, x0, #0x440
100844610:     	bl	0x100b0fa6c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100844614:     	str	x0, [sp, #0x18]
100844618:     	ldr	x0, [x0, #0x8]
10084461c:     	mov	x28, x0
100844620:     	bl	0x1005782c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100844624:     	cbz	x0, 0x1008446dc <_js_json_stringify_full+0x1618>
100844628:     	ldrb	w8, [x0]
10084462c:     	cmp	w8, #0x1
100844630:     	b.ne	0x1008446dc <_js_json_stringify_full+0x1618>
100844634:     	ldrsb	w8, [x0, #0x1]
100844638:     	tbz	w8, #0x1f, 0x100843bac <_js_json_stringify_full+0xae8>
10084463c:     	mov	w25, #0x1               ; =1
100844640:     	mov	w8, #0x8                ; =8
100844644:     	str	x8, [sp, #0x28]
100844648:     	ldr	x0, [x0, #0x8]
10084464c:     	mov	x28, x0
100844650:     	bl	0x1005782c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100844654:     	cbz	x0, 0x100844d64 <_js_json_stringify_full+0x1ca0>
100844658:     	mov	x27, #0x0               ; =0
10084465c:     	mov	w26, #0x0               ; =0
100844660:     	ldrb	w8, [x0]
100844664:     	mov	x23, #0x0               ; =0
100844668:     	mov	w24, #0x0               ; =0
10084466c:     	cmp	w8, #0x1
100844670:     	b.ne	0x100844d74 <_js_json_stringify_full+0x1cb0>
100844674:     	cmp	w25, #0x3f
100844678:     	ldr	x21, [sp, #0x10]
10084467c:     	b.hi	0x100843bf0 <_js_json_stringify_full+0xb2c>
100844680:     	add	w25, w25, #0x1
100844684:     	ldrsb	w8, [x0, #0x1]
100844688:     	tbnz	w8, #0x1f, 0x100844648 <_js_json_stringify_full+0x1584>
10084468c:     	ldr	x9, [sp, #0x18]
100844690:     	str	x28, [x9, #0x8]
100844694:     	ldrb	w8, [x9, #0x1]
100844698:     	orr	w8, w8, #0x80
10084469c:     	strb	w8, [x9, #0x1]
1008446a0:     	ldrb	w8, [x0]
1008446a4:     	cmp	w8, #0x1
1008446a8:     	b.ne	0x1008444e0 <_js_json_stringify_full+0x141c>
1008446ac:     	mov	x23, x28
1008446b0:     	ldp	w9, w8, [x28]
1008446b4:     	cmp	w9, w8
1008446b8:     	b.ls	0x1008446fc <_js_json_stringify_full+0x1638>
1008446bc:     	ldp	x21, x9, [sp, #0x10]
1008446c0:     	cbz	x9, 0x100844710 <_js_json_stringify_full+0x164c>
1008446c4:     	ldr	w9, [x0, #0x4]
1008446c8:     	ubfiz	x8, x8, #3, #32
1008446cc:     	add	x8, x8, #0x10
1008446d0:     	cmp	x8, x9
1008446d4:     	b.ne	0x100844710 <_js_json_stringify_full+0x164c>
1008446d8:     	b	0x100844910 <_js_json_stringify_full+0x184c>
1008446dc:     	mov	w26, #0x0               ; =0
1008446e0:     	mov	x27, #0x0               ; =0
1008446e4:     	mov	x23, #0x0               ; =0
1008446e8:     	mov	w24, #0x0               ; =0
1008446ec:     	mov	w8, #0x8                ; =8
1008446f0:     	str	x8, [sp, #0x28]
1008446f4:     	ldr	x21, [sp, #0x10]
1008446f8:     	b	0x100843bf0 <_js_json_stringify_full+0xb2c>
1008446fc:     	ldr	x21, [sp, #0x10]
100844700:     	mov	w8, #0xe100             ; =57600
100844704:     	movk	w8, #0x5f5, lsl #16
100844708:     	cmp	w9, w8
10084470c:     	b.ls	0x100844910 <_js_json_stringify_full+0x184c>
100844710:     	mov	x0, x23
100844714:     	bl	0x100586734 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100844718:     	tbnz	w0, #0x0, 0x100844910 <_js_json_stringify_full+0x184c>
10084471c:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100844720:     	add	x8, x8, #0xe80
100844724:     	ldaprb	w8, [x8]
100844728:     	cbz	w8, 0x100844938 <_js_json_stringify_full+0x1874>
10084472c:     	adrp	x8, 0x100f7c000 <_perry_global_options_worker_ts__1>
100844730:     	add	x8, x8, #0x58
100844734:     	ldapr	x8, [x8]
100844738:     	cmp	x8, x23
10084473c:     	b.hi	0x100844938 <_js_json_stringify_full+0x1874>
100844740:     	adrp	x8, 0x100f7c000 <_perry_global_options_worker_ts__1>
100844744:     	add	x8, x8, #0x60
100844748:     	ldapr	x8, [x8]
10084474c:     	cmp	x8, x23
100844750:     	b.lo	0x100844938 <_js_json_stringify_full+0x1874>
100844754:     	mov	x0, x23
100844758:     	bl	0x1002a2338 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
10084475c:     	tbnz	w0, #0x0, 0x100844910 <_js_json_stringify_full+0x184c>
100844760:     	b	0x100844938 <_js_json_stringify_full+0x1874>
100844764:     	cmp	w8, #0x1
100844768:     	b.ne	0x1008447f0 <_js_json_stringify_full+0x172c>
10084476c:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100844770:     	add	x1, x1, #0x58
100844774:     	mov	x19, x0
100844778:     	bl	0x100a1d79c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084477c:     	mov	x0, x19
100844780:     	strb	wzr, [x19, #0x20]
100844784:     	ldr	x24, [sp, #0x28]
100844788:     	ldr	x8, [x19]
10084478c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100844790:     	cmp	x8, x9
100844794:     	b.lo	0x100843e5c <_js_json_stringify_full+0xd98>
100844798:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084479c:     	add	x0, x0, #0xea8
1008447a0:     	bl	0x100b0fa9c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1008447a4:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008447a8:     	add	x0, x0, #0xec0
1008447ac:     	bl	0x100b0fa6c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008447b0:     	mov	x0, x25
1008447b4:     	bl	0x100b1b8c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008447b8:     	mov	x25, x0
1008447bc:     	cbnz	x0, 0x100843f80 <_js_json_stringify_full+0xebc>
1008447c0:     	cbz	x21, 0x1008447f0 <_js_json_stringify_full+0x172c>
1008447c4:     	mov	x0, x20
1008447c8:     	bl	0x100b5c2c0 <_mi_free>
1008447cc:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
1008447d0:     	add	x0, x0, #0xc18
1008447d4:     	bl	0x100b5591c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
1008447d8:     	adrp	x0, 0x100ef3000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
1008447dc:     	add	x0, x0, #0xd70
1008447e0:     	bl	0x100b0fa9c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1008447e4:     	bl	0x100b48c54 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
1008447e8:     	cmp	w8, #0x2
1008447ec:     	b.ne	0x100844d18 <_js_json_stringify_full+0x1c54>
1008447f0:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
1008447f4:     	add	x0, x0, #0xc18
1008447f8:     	bl	0x100b5591c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
1008447fc:     	adrp	x0, 0x100c3f000 <_PERRY_EMPTY_STRING+0x764>
100844800:     	add	x0, x0, #0x7c0
100844804:     	mov	w1, #0xf                ; =15
100844808:     	bl	0x100b48c1c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
10084480c:     	add	x9, x8, #0x60
100844810:     	ldr	x10, [x8, #0x30]
100844814:     	add	x10, x10, #0x1
100844818:     	str	x10, [x8, #0x30]
10084481c:     	add	x8, x9, #0x19
100844820:     	b	0x100844890 <_js_json_stringify_full+0x17cc>
100844824:     	bl	0x100b3c6fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100844828:     	lsr	x1, x23, #20
10084482c:     	ldr	x8, [x0, #0x10]
100844830:     	ldrb	w9, [x8]
100844834:     	cmp	w9, #0x2
100844838:     	b.eq	0x100844464 <_js_json_stringify_full+0x13a0>
10084483c:     	ldr	x9, [x8, #0x8]
100844840:     	ldr	x10, [x8, #0x28]
100844844:     	sub	x9, x1, x9
100844848:     	cmp	x9, x10
10084484c:     	b.hs	0x1008448a4 <_js_json_stringify_full+0x17e0>
100844850:     	ldr	x10, [x8, #0x20]
100844854:     	mov	w11, #0x28              ; =40
100844858:     	madd	x9, x9, x11, x10
10084485c:     	ldr	x10, [x9]
100844860:     	ldr	x11, [x8, #0x10]
100844864:     	cmp	x10, x11
100844868:     	mov	x23, x28
10084486c:     	b.ne	0x1008448b4 <_js_json_stringify_full+0x17f0>
100844870:     	ldp	x10, x11, [x9, #0x8]
100844874:     	cmp	x10, x23
100844878:     	ccmp	x11, x23, #0x0, ls
10084487c:     	b.ls	0x1008448b4 <_js_json_stringify_full+0x17f0>
100844880:     	ldr	x10, [x8, #0x30]
100844884:     	add	x10, x10, #0x1
100844888:     	str	x10, [x8, #0x30]
10084488c:     	add	x8, x9, #0x21
100844890:     	ldrb	w8, [x8]
100844894:     	cmp	w8, #0xff
100844898:     	mov	x23, x28
10084489c:     	b.ne	0x1008448cc <_js_json_stringify_full+0x1808>
1008448a0:     	b	0x1008448c0 <_js_json_stringify_full+0x17fc>
1008448a4:     	ldr	x9, [x8, #0x58]
1008448a8:     	add	x9, x9, #0x1
1008448ac:     	str	x9, [x8, #0x58]
1008448b0:     	mov	x23, x28
1008448b4:     	ldr	x9, [x8, #0x38]
1008448b8:     	add	x9, x9, #0x1
1008448bc:     	str	x9, [x8, #0x38]
1008448c0:     	mov	x0, x23
1008448c4:     	bl	0x10051bc48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1008448c8:     	and	w8, w0, #0xff
1008448cc:     	cbz	w8, 0x100843b88 <_js_json_stringify_full+0xac4>
1008448d0:     	ldurb	w8, [x23, #-0x8]
1008448d4:     	ldurb	w9, [x23, #-0x7]
1008448d8:     	mov	w10, #0x82              ; =130
1008448dc:     	and	w9, w9, w10
1008448e0:     	cmp	w9, #0x2
1008448e4:     	ccmp	w8, #0x1, #0x0, eq
1008448e8:     	b.ne	0x100843b88 <_js_json_stringify_full+0xac4>
1008448ec:     	ldr	w8, [x23]
1008448f0:     	mov	w9, #0xe100             ; =57600
1008448f4:     	movk	w9, #0x5f5, lsl #16
1008448f8:     	orr	w9, w9, #0x1
1008448fc:     	cmp	w8, w9
100844900:     	b.hs	0x100843b88 <_js_json_stringify_full+0xac4>
100844904:     	ldr	w9, [x23, #0x4]
100844908:     	cmp	w8, w9
10084490c:     	b.hi	0x100843b88 <_js_json_stringify_full+0xac4>
100844910:     	ldr	w9, [x23], #0x8
100844914:     	mov	w8, #0x8                ; =8
100844918:     	stp	xzr, x8, [sp, #0x88]
10084491c:     	str	xzr, [sp, #0x98]
100844920:     	str	x9, [sp, #0x28]
100844924:     	cbz	w9, 0x100844938 <_js_json_stringify_full+0x1874>
100844928:     	mov	x28, x21
10084492c:     	mov	x25, #0x0               ; =0
100844930:     	str	x23, [sp, #0x8]
100844934:     	b	0x100844984 <_js_json_stringify_full+0x18c0>
100844938:     	mov	w26, #0x0               ; =0
10084493c:     	mov	x27, #0x0               ; =0
100844940:     	mov	x23, #0x0               ; =0
100844944:     	mov	w24, #0x0               ; =0
100844948:     	mov	w8, #0x8                ; =8
10084494c:     	str	x8, [sp, #0x28]
100844950:     	b	0x100843bf0 <_js_json_stringify_full+0xb2c>
100844954:     	mov	w8, #0x18               ; =24
100844958:     	madd	x8, x21, x8, x25
10084495c:     	ldp	x9, x25, [sp, #0x18]
100844960:     	stp	x9, x27, [x8]
100844964:     	str	x24, [x8, #0x10]
100844968:     	add	x8, x21, #0x1
10084496c:     	str	x8, [sp, #0x98]
100844970:     	ldr	x23, [sp, #0x8]
100844974:     	add	x25, x25, #0x1
100844978:     	ldr	x8, [sp, #0x28]
10084497c:     	cmp	x25, x8
100844980:     	b.eq	0x100844cdc <_js_json_stringify_full+0x1c18>
100844984:     	ldr	d9, [x23, x25, lsl #3]
100844988:     	fmov	x26, d9
10084498c:     	and	x21, x26, #0xffff000000000000
100844990:     	mov	x8, #0x7ff9000000000000 ; =9221401712017801216
100844994:     	cmp	x21, x8
100844998:     	b.eq	0x1008449dc <_js_json_stringify_full+0x1918>
10084499c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
1008449a0:     	cmp	x21, x8
1008449a4:     	b.ne	0x100844a60 <_js_json_stringify_full+0x199c>
1008449a8:     	and	x21, x26, #0xffffffffffff
1008449ac:     	cmp	x21, #0x1, lsl #12      ; =0x1000
1008449b0:     	b.lo	0x100844974 <_js_json_stringify_full+0x18b0>
1008449b4:     	ldr	w24, [x21, #0x4]
1008449b8:     	str	x25, [sp, #0x20]
1008449bc:     	cbz	w24, 0x100844b60 <_js_json_stringify_full+0x1a9c>
1008449c0:     	mov	x0, x24
1008449c4:     	mov	w1, #0x1                ; =1
1008449c8:     	bl	0x100b5c548 <_mi_malloc_aligned>
1008449cc:     	cbz	x0, 0x100844d7c <_js_json_stringify_full+0x1cb8>
1008449d0:     	mov	x27, x0
1008449d4:     	add	x1, x21, #0x14
1008449d8:     	b	0x100844b30 <_js_json_stringify_full+0x1a6c>
1008449dc:     	strb	wzr, [sp, #0x64]
1008449e0:     	str	wzr, [sp, #0x60]
1008449e4:     	ubfx	x1, x26, #40, #8
1008449e8:     	cbz	x1, 0x100844a38 <_js_json_stringify_full+0x1974>
1008449ec:     	strb	w26, [sp, #0x60]
1008449f0:     	cmp	x1, #0x1
1008449f4:     	b.eq	0x100844a38 <_js_json_stringify_full+0x1974>
1008449f8:     	lsr	x8, x26, #8
1008449fc:     	strb	w8, [sp, #0x61]
100844a00:     	cmp	x1, #0x2
100844a04:     	b.eq	0x100844a38 <_js_json_stringify_full+0x1974>
100844a08:     	lsr	x8, x26, #16
100844a0c:     	strb	w8, [sp, #0x62]
100844a10:     	cmp	x1, #0x3
100844a14:     	b.eq	0x100844a38 <_js_json_stringify_full+0x1974>
100844a18:     	lsr	x8, x26, #24
100844a1c:     	strb	w8, [sp, #0x63]
100844a20:     	cmp	x1, #0x4
100844a24:     	b.eq	0x100844a38 <_js_json_stringify_full+0x1974>
100844a28:     	lsr	x8, x26, #32
100844a2c:     	strb	w8, [sp, #0x64]
100844a30:     	cmp	x1, #0x5
100844a34:     	b.ne	0x100844d94 <_js_json_stringify_full+0x1cd0>
100844a38:     	add	x8, sp, #0x68
100844a3c:     	add	x0, sp, #0x60
100844a40:     	bl	0x10002b398 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100844a44:     	ldr	x8, [sp, #0x68]
100844a48:     	cbz	x8, 0x100844aa0 <_js_json_stringify_full+0x19dc>
100844a4c:     	mov	x21, #-0x1              ; =-1
100844a50:     	stur	x21, [x29, #-0x80]
100844a54:     	cmn	x21, #0x1
100844a58:     	b.ne	0x100844c00 <_js_json_stringify_full+0x1b3c>
100844a5c:     	b	0x100844974 <_js_json_stringify_full+0x18b0>
100844a60:     	lsr	x8, x26, #52
100844a64:     	cmp	x8, #0x0
100844a68:     	and	x8, x26, #0x7
100844a6c:     	ccmp	x26, #0x0, #0x4, eq
100844a70:     	ccmp	x8, #0x0, #0x0, ne
100844a74:     	b.eq	0x100844b40 <_js_json_stringify_full+0x1a7c>
100844a78:     	mov	w8, #0x7ffe0000         ; =2147352576
100844a7c:     	cmp	x8, x26, lsr #32
100844a80:     	b.ne	0x100844ae4 <_js_json_stringify_full+0x1a20>
100844a84:     	sub	x0, x29, #0x80
100844a88:     	mov	x1, x26
100844a8c:     	bl	0x100787900 <__RNvXs1K_NtCsctvjasLqLe9_5alloc6stringlNtB6_12SpecToString14spec_to_string>
100844a90:     	ldur	x21, [x29, #-0x80]
100844a94:     	cmn	x21, #0x1
100844a98:     	b.ne	0x100844c00 <_js_json_stringify_full+0x1b3c>
100844a9c:     	b	0x100844974 <_js_json_stringify_full+0x18b0>
100844aa0:     	ldr	x21, [sp, #0x78]
100844aa4:     	tbnz	x21, #0x3f, 0x100844cd0 <_js_json_stringify_full+0x1c0c>
100844aa8:     	mov	x23, x21
100844aac:     	cbz	x21, 0x100844be4 <_js_json_stringify_full+0x1b20>
100844ab0:     	ldr	x27, [sp, #0x70]
100844ab4:     	mov	x21, x23
100844ab8:     	mov	x0, x23
100844abc:     	mov	w1, #0x1                ; =1
100844ac0:     	bl	0x100b5c548 <_mi_malloc_aligned>
100844ac4:     	mov	x24, x0
100844ac8:     	mov	w0, #0x1                ; =1
100844acc:     	cbz	x24, 0x100844d8c <_js_json_stringify_full+0x1cc8>
100844ad0:     	mov	x0, x24
100844ad4:     	mov	x1, x27
100844ad8:     	mov	x2, x21
100844adc:     	bl	0x100b5f16c <_writev+0x100b5f16c>
100844ae0:     	b	0x100844be8 <_js_json_stringify_full+0x1b24>
100844ae4:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100844ae8:     	cmp	x21, x8
100844aec:     	mov	x8, #0x7ff9000000000000 ; =9221401712017801216
100844af0:     	ccmp	x26, x8, #0x0, ls
100844af4:     	b.hs	0x100844b74 <_js_json_stringify_full+0x1ab0>
100844af8:     	mov.16b	v0, v9
100844afc:     	bl	0x10086efac <_js_number_to_string>
100844b00:     	cmp	x0, #0x1, lsl #12       ; =0x1000
100844b04:     	b.lo	0x100844974 <_js_json_stringify_full+0x18b0>
100844b08:     	mov	x26, x0
100844b0c:     	str	x25, [sp, #0x20]
100844b10:     	ldr	w24, [x0, #0x4]
100844b14:     	cbz	w24, 0x100844b60 <_js_json_stringify_full+0x1a9c>
100844b18:     	mov	x0, x24
100844b1c:     	mov	w1, #0x1                ; =1
100844b20:     	bl	0x100b5c548 <_mi_malloc_aligned>
100844b24:     	cbz	x0, 0x100844d7c <_js_json_stringify_full+0x1cb8>
100844b28:     	mov	x27, x0
100844b2c:     	add	x1, x26, #0x14
100844b30:     	mov	x0, x27
100844b34:     	mov	x2, x24
100844b38:     	bl	0x100b5f16c <_writev+0x100b5f16c>
100844b3c:     	b	0x100844b64 <_js_json_stringify_full+0x1aa0>
100844b40:     	mov	x0, x26
100844b44:     	bl	0x10050ca38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100844b48:     	tbz	w0, #0x0, 0x100844a78 <_js_json_stringify_full+0x19b4>
100844b4c:     	cmp	x26, #0x1, lsl #12      ; =0x1000
100844b50:     	b.lo	0x100844974 <_js_json_stringify_full+0x18b0>
100844b54:     	str	x25, [sp, #0x20]
100844b58:     	ldr	w24, [x26, #0x4]
100844b5c:     	cbnz	w24, 0x100844b18 <_js_json_stringify_full+0x1a54>
100844b60:     	mov	w27, #0x1               ; =1
100844b64:     	stp	x24, x27, [x29, #-0x80]
100844b68:     	str	x24, [sp, #0x18]
100844b6c:     	stur	x24, [x29, #-0x70]
100844b70:     	b	0x100844c08 <_js_json_stringify_full+0x1b44>
100844b74:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100844b78:     	cmp	x21, x8
100844b7c:     	b.ne	0x100844970 <_js_json_stringify_full+0x18ac>
100844b80:     	and	x1, x26, #0xffffffffffff
100844b84:     	sub	x8, x1, #0x100, lsl #12 ; =0x100000
100844b88:     	mov	x9, #0x7fffffffffff     ; =140737488355327
100844b8c:     	movk	x9, #0xffef, lsl #16
100844b90:     	cmp	x8, x9
100844b94:     	b.hi	0x100844970 <_js_json_stringify_full+0x18ac>
100844b98:     	add	x0, sp, #0x68
100844b9c:     	bl	0x10076b5ac <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
100844ba0:     	ldr	w8, [sp, #0x68]
100844ba4:     	tbz	w8, #0x0, 0x100844970 <_js_json_stringify_full+0x18ac>
100844ba8:     	ldr	w8, [sp, #0x70]
100844bac:     	mov	w9, #0x8068             ; =32872
100844bb0:     	movk	w9, #0x7fff, lsl #16
100844bb4:     	cmp	w9, w8, lsr #1
100844bb8:     	b.ne	0x100844970 <_js_json_stringify_full+0x18ac>
100844bbc:     	mov.16b	v0, v9
100844bc0:     	bl	0x1008459fc <_js_jsvalue_to_string>
100844bc4:     	cmp	x0, #0x1, lsl #12       ; =0x1000
100844bc8:     	b.hs	0x100844c80 <_js_json_stringify_full+0x1bbc>
100844bcc:     	mov	x21, #-0x1              ; =-1
100844bd0:     	stur	x21, [x29, #-0x80]
100844bd4:     	ldr	x23, [sp, #0x8]
100844bd8:     	cmn	x21, #0x1
100844bdc:     	b.ne	0x100844c00 <_js_json_stringify_full+0x1b3c>
100844be0:     	b	0x100844974 <_js_json_stringify_full+0x18b0>
100844be4:     	mov	w24, #0x1               ; =1
100844be8:     	mov	x21, x23
100844bec:     	stp	x23, x24, [x29, #-0x80]
100844bf0:     	stur	x23, [x29, #-0x70]
100844bf4:     	ldr	x23, [sp, #0x8]
100844bf8:     	cmn	x21, #0x1
100844bfc:     	b.eq	0x100844974 <_js_json_stringify_full+0x18b0>
100844c00:     	stp	x21, x25, [sp, #0x18]
100844c04:     	ldp	x27, x24, [x29, #-0x78]
100844c08:     	ldp	x25, x21, [sp, #0x90]
100844c0c:     	cbz	x21, 0x100844c64 <_js_json_stringify_full+0x1ba0>
100844c10:     	add	x8, x21, x21, lsl #1
100844c14:     	lsl	x26, x8, #3
100844c18:     	add	x23, x25, #0x10
100844c1c:     	b	0x100844c2c <_js_json_stringify_full+0x1b68>
100844c20:     	add	x23, x23, #0x18
100844c24:     	subs	x26, x26, #0x18
100844c28:     	b.eq	0x100844c64 <_js_json_stringify_full+0x1ba0>
100844c2c:     	ldr	x8, [x23]
100844c30:     	cmp	x8, x24
100844c34:     	b.ne	0x100844c20 <_js_json_stringify_full+0x1b5c>
100844c38:     	ldur	x0, [x23, #-0x8]
100844c3c:     	mov	x1, x27
100844c40:     	mov	x2, x24
100844c44:     	bl	0x100b5f160 <_writev+0x100b5f160>
100844c48:     	cbnz	w0, 0x100844c20 <_js_json_stringify_full+0x1b5c>
100844c4c:     	ldr	x23, [sp, #0x8]
100844c50:     	ldp	x8, x25, [sp, #0x18]
100844c54:     	cbz	x8, 0x100844974 <_js_json_stringify_full+0x18b0>
100844c58:     	mov	x0, x27
100844c5c:     	bl	0x100b5c2c0 <_mi_free>
100844c60:     	b	0x100844974 <_js_json_stringify_full+0x18b0>
100844c64:     	ldr	x8, [sp, #0x88]
100844c68:     	cmp	x21, x8
100844c6c:     	b.ne	0x100844954 <_js_json_stringify_full+0x1890>
100844c70:     	add	x0, sp, #0x88
100844c74:     	bl	0x100b552dc <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecNtNtNtCs8BpVhDwHqJW_3std3ffi6os_str8OsStringE8grow_oneBS_>
100844c78:     	ldr	x25, [sp, #0x90]
100844c7c:     	b	0x100844954 <_js_json_stringify_full+0x1890>
100844c80:     	mov	x24, x0
100844c84:     	ldr	w8, [x0, #0x4]
100844c88:     	mov	x21, x8
100844c8c:     	cbz	w8, 0x100844cb4 <_js_json_stringify_full+0x1bf0>
100844c90:     	mov	x0, x21
100844c94:     	mov	w1, #0x1                ; =1
100844c98:     	bl	0x100b5c548 <_mi_malloc_aligned>
100844c9c:     	cbz	x0, 0x100844da8 <_js_json_stringify_full+0x1ce4>
100844ca0:     	mov	x27, x0
100844ca4:     	add	x1, x24, #0x14
100844ca8:     	mov	x2, x21
100844cac:     	bl	0x100b5f16c <_writev+0x100b5f16c>
100844cb0:     	b	0x100844cb8 <_js_json_stringify_full+0x1bf4>
100844cb4:     	mov	w27, #0x1               ; =1
100844cb8:     	stp	x21, x27, [x29, #-0x80]
100844cbc:     	stur	x21, [x29, #-0x70]
100844cc0:     	ldr	x23, [sp, #0x8]
100844cc4:     	cmn	x21, #0x1
100844cc8:     	b.ne	0x100844c00 <_js_json_stringify_full+0x1b3c>
100844ccc:     	b	0x100844974 <_js_json_stringify_full+0x18b0>
100844cd0:     	mov	x0, #0x0                ; =0
100844cd4:     	mov	x1, x21
100844cd8:     	bl	0x100b0f6c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100844cdc:     	ldp	x8, x9, [sp, #0x88]
100844ce0:     	str	x9, [sp, #0x28]
100844ce4:     	ldr	x23, [sp, #0x98]
100844ce8:     	cmn	x8, #0x1
100844cec:     	b.eq	0x100844d04 <_js_json_stringify_full+0x1c40>
100844cf0:     	mov	x27, x8
100844cf4:     	mov	w26, #0x0               ; =0
100844cf8:     	mov	w24, #0x0               ; =0
100844cfc:     	mov	x21, x28
100844d00:     	b	0x100843bf0 <_js_json_stringify_full+0xb2c>
100844d04:     	and	x27, x22, #0xffff000000000000
100844d08:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100844d0c:     	cmp	x27, x8
100844d10:     	b.eq	0x100843bd4 <_js_json_stringify_full+0xb10>
100844d14:     	b	0x100843a0c <_js_json_stringify_full+0x948>
100844d18:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100844d1c:     	add	x1, x1, #0x58
100844d20:     	mov	x20, x0
100844d24:     	bl	0x100a1d79c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100844d28:     	mov	x0, x20
100844d2c:     	strb	wzr, [x20, #0x20]
100844d30:     	ldr	x24, [sp, #0x28]
100844d34:     	ldr	x8, [x20]
100844d38:     	cbz	x8, 0x100843f6c <_js_json_stringify_full+0xea8>
100844d3c:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100844d40:     	add	x0, x0, #0xe90
100844d44:     	bl	0x100b0fa6c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100844d48:     	adrp	x0, 0x100f2b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x190>
100844d4c:     	add	x0, x0, #0x848
100844d50:     	bl	0x100b0fb30 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100844d54:     	adrp	x0, 0x100c3f000 <_PERRY_EMPTY_STRING+0x764>
100844d58:     	add	x0, x0, #0x4f7
100844d5c:     	mov	w1, #0xb                ; =11
100844d60:     	bl	0x100b48c1c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100844d64:     	mov	w26, #0x0               ; =0
100844d68:     	mov	x27, #0x0               ; =0
100844d6c:     	mov	x23, #0x0               ; =0
100844d70:     	mov	w24, #0x0               ; =0
100844d74:     	ldr	x21, [sp, #0x10]
100844d78:     	b	0x100843bf0 <_js_json_stringify_full+0xb2c>
100844d7c:     	mov	w0, #0x1                ; =1
100844d80:     	mov	x1, x24
100844d84:     	bl	0x100b0f6c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100844d88:     	mov	w0, #0x1                ; =1
100844d8c:     	mov	x1, x21
100844d90:     	bl	0x100b0f6c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100844d94:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100844d98:     	add	x2, x2, #0x3c8
100844d9c:     	mov	w0, #0x5                ; =5
100844da0:     	mov	w1, #0x5                ; =5
100844da4:     	bl	0x100b0fbcc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100844da8:     	mov	w0, #0x1                ; =1
100844dac:     	mov	x1, x21
100844db0:     	bl	0x100b0f6c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
