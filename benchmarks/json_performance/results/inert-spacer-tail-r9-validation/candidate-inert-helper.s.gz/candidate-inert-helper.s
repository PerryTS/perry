
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/inert-spacer-tail-r9/candidate-options:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001004eefac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer>:
1004eefac:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1004eefb0:     	cmp	x1, x8
1004eefb4:     	mov	x8, #0x4                ; =4
1004eefb8:     	movk	x8, #0x7ffc, lsl #48
1004eefbc:     	ccmp	x1, x8, #0x4, ne
1004eefc0:     	ccmp	x1, #0x0, #0x4, ne
1004eefc4:     	b.ne	0x1004ef058 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0xac>
1004eefc8:     	stp	x20, x19, [sp, #-0x20]!
1004eefcc:     	stp	x29, x30, [sp, #0x10]
1004eefd0:     	add	x29, sp, #0x10
1004eefd4:     	mov	x19, x0
1004eefd8:     	bl	0x1004ee9fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small13try_primitive>
1004eefdc:     	cmp	x0, #0x1
1004eefe0:     	b.eq	0x1004ef04c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0xa0>
1004eefe4:     	mov	w8, #0x7fff             ; =32767
1004eefe8:     	cmp	x8, x19, lsr #48
1004eefec:     	b.ne	0x1004ef034 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x88>
1004eeff0:     	and	x8, x19, #0xffffffffffff
1004eeff4:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
1004eeff8:     	mov	x10, #0x7fffffffffff    ; =140737488355327
1004eeffc:     	movk	x10, #0xffef, lsl #16
1004ef000:     	cmp	x9, x10
1004ef004:     	b.hi	0x1004ef034 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x88>
1004ef008:     	ldr	w8, [x8, #0x4]
1004ef00c:     	cmp	w8, #0x40
1004ef010:     	b.lo	0x1004ef034 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x88>
1004ef014:     	and	x0, x19, #0xffffffffffff
1004ef018:     	bl	0x1004f0c0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
1004ef01c:     	tbz	w0, #0x0, 0x1004ef034 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x88>
1004ef020:     	mov	x8, x1
1004ef024:     	mov	x1, #0x7fff000000000000 ; =9223090561878065152
1004ef028:     	bfxil	x1, x8, #0, #48
1004ef02c:     	mov	w0, #0x1                ; =1
1004ef030:     	b	0x1004ef04c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0xa0>
1004ef034:     	mov	x0, x19
1004ef038:     	bl	0x1004f5ec0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output10try_object>
1004ef03c:     	cmp	x0, #0x1
1004ef040:     	b.eq	0x1004ef04c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0xa0>
1004ef044:     	mov	x0, x19
1004ef048:     	bl	0x1004ebf80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat10try_object>
1004ef04c:     	ldp	x29, x30, [sp, #0x10]
1004ef050:     	ldp	x20, x19, [sp], #0x20
1004ef054:     	ret
1004ef058:     	mov	x0, #0x0                ; =0
1004ef05c:     	ret
