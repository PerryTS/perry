; ModuleID = '/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/stringify-entry-r7/ir-r5-options/.perry-trace/llvm/options_worker_ts.ll'
source_filename = "perry_module"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx15.0.0"

module asm ".no_dead_strip __LLVM_StackMaps"

@options_worker_ts_.str.0 = private unnamed_addr constant [119 x i8] c"/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/stringify-entry-r7/options-worker.ts\00"
@options_worker_ts_.str.0.bytes = private unnamed_addr constant [5 x i8] c"zero\00"
@options_worker_ts_.str.1.bytes = private unnamed_addr constant [7 x i8] c"length\00"
@options_worker_ts_.str.2.bytes = private unnamed_addr constant [7 x i8] c"pretty\00"
@options_worker_ts_.str.3.bytes = private unnamed_addr constant [5 x i8] c"keys\00"
@options_worker_ts_.str.4.bytes = private unnamed_addr constant [9 x i8] c"callback\00"
@options_worker_ts_.str.5.bytes = private unnamed_addr constant [3 x i8] c"fs\00"
@options_worker_ts_.str.6.bytes = private unnamed_addr constant [13 x i8] c"readFileSync\00"
@options_worker_ts_.str.7.bytes = private unnamed_addr constant [5 x i8] c"utf8\00"
@options_worker_ts_.str.8.bytes = private unnamed_addr constant [9 x i8] c"{\22data\22:\00"
@options_worker_ts_.str.9.bytes = private unnamed_addr constant [2 x i8] c"}\00"
@options_worker_ts_.str.10.bytes = private unnamed_addr constant [5 x i8] c"data\00"
@options_worker_ts_.str.11.bytes = private unnamed_addr constant [3 x i8] c"id\00"
@options_worker_ts_.str.12.bytes = private unnamed_addr constant [5 x i8] c"name\00"
@options_worker_ts_.str.13.bytes = private unnamed_addr constant [6 x i8] c"email\00"
@options_worker_ts_.str.14.bytes = private unnamed_addr constant [7 x i8] c"active\00"
@options_worker_ts_.str.15.bytes = private unnamed_addr constant [6 x i8] c"score\00"
@options_worker_ts_.str.16.bytes = private unnamed_addr constant [5 x i8] c"tags\00"
@options_worker_ts_.str.17.bytes = private unnamed_addr constant [4 x i8] c"rss\00"
@options_worker_ts_.str.18.bytes = private unnamed_addr constant [7 x i8] c"RESULT\00"
@options_worker_ts_.str.19.bytes = private unnamed_addr constant [5 x i8] c"user\00"
@options_worker_ts_.str.20.bytes = private unnamed_addr constant [7 x i8] c"system\00"
@options_worker_ts_.str.21.bytes = private unnamed_addr constant [7 x i8] c"verify\00"
@options_worker_ts_.str.22.bytes = private unnamed_addr constant [7 x i8] c"VERIFY\00"
@options_worker_ts_.str.23.bytes = private unnamed_addr constant [5 x i8] c"KEEP\00"
@options_worker_ts_.str.1 = private unnamed_addr constant [9 x i8] c"identity\00"
@options_worker_ts_.str.2 = private unnamed_addr constant [4 x i8] c"run\00"
@options_worker_ts_.str.3 = private unnamed_addr constant [66 x i8] c"function identity(key: string, value: any): any { return value; }\00"
@options_worker_ts_.str.4 = private unnamed_addr constant [872 x i8] c"function run(count: number): number {\0A    let sum = 0;\0A    if (operation === 'zero') {\0A        for (let i = 0; i < count; i++) {\0A            const result = JSON.stringify(input, null, 0);\0A            sum += result.length; last = result;\0A        }\0A    } else if (operation === 'pretty') {\0A        for (let i = 0; i < count; i++) {\0A            const result = JSON.stringify(input, null, 2);\0A            sum += result.length; last = result;\0A        }\0A    } else if (operation === 'keys') {\0A        for (let i = 0; i < count; i++) {\0A            const result = JSON.stringify(input, keys);\0A            sum += result.length; last = result;\0A        }\0A    } else if (operation === 'callback') {\0A        for (let i = 0; i < count; i++) {\0A            const result = JSON.stringify(input, identity);\0A            sum += result.length; last = result;\0A        }\0A    }\0A    return sum;\0A}\00"
@PERRY_SYMBOL_PROPERTY_IC_EPOCH = external global i64
@PERRY_GC_POLL_ARMED = external global i32
@PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD = external global [65536 x i8]
@PERRY_PER_OBJECT_LAYOUTS_ANY = external global i32
@PERRY_LAYOUT_ADDR_FILTER = external global [64 x i64]
@PERRY_YOUNG_LAYOUT_RECORDS = external global i32
@PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED = external global i8
@PERRY_ARRAY_PROTO_ITERATOR_PATCHED = external global i8
@PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT = external global i32
@PERRY_HOT_TSD_KEY = external global i64
@PERRY_TA_KIND_CACHE = external global [64 x i64]
@PERRY_U8_INLINE_CACHE = external global [64 x i64]
@PERRY_TA_VIEW_GUARD = external global i64
@perry_null_guard_zero_options_worker_ts = internal global i32 0
@perry_global_options_worker_ts__1 = global double 0x7FFC000000000001
@perry_global_options_worker_ts__4 = global double 0x7FFC000000000001
@perry_global_options_worker_ts__5 = global double 0x7FFC000000000001
@perry_global_options_worker_ts__6 = global double 0x7FFC000000000001
@perry_ic_options_worker_ts__1 = private global ptr null
@perry_ic_options_worker_ts__3 = private global ptr null
@perry_ic_options_worker_ts__5 = private global ptr null
@perry_ic_options_worker_ts__7 = private global ptr null
@perry_ic_options_worker_ts__9 = private global ptr null
@perry_ic_options_worker_ts__11 = private global ptr null
@perry_ic_options_worker_ts__13 = private global ptr null
@perry_ic_options_worker_ts__15 = private global ptr null
@perry_ic_options_worker_ts__21 = private global ptr null
@perry_ic_options_worker_ts__23 = private global ptr null
@perry_ic_options_worker_ts__25 = private global ptr null
@perry_ic_options_worker_ts__27 = private global ptr null
@perry_ic_options_worker_ts__29 = private global ptr null
@perry_ic_options_worker_ts__31 = private global ptr null
@perry_ic_options_worker_ts__33 = private global ptr null
@options_worker_ts_.str.0.handle = internal global double 0.000000e+00
@options_worker_ts_.str.1.handle = internal global double 0.000000e+00
@options_worker_ts_.str.2.handle = internal global double 0.000000e+00
@options_worker_ts_.str.3.handle = internal global double 0.000000e+00
@options_worker_ts_.str.4.handle = internal global double 0.000000e+00
@options_worker_ts_.str.5.handle = internal global double 0.000000e+00
@options_worker_ts_.str.6.handle = internal global double 0.000000e+00
@options_worker_ts_.str.7.handle = internal global double 0.000000e+00
@options_worker_ts_.str.8.handle = internal global double 0.000000e+00
@options_worker_ts_.str.9.handle = internal global double 0.000000e+00
@options_worker_ts_.str.10.handle = internal global double 0.000000e+00
@options_worker_ts_.str.11.handle = internal global double 0.000000e+00
@options_worker_ts_.str.12.handle = internal global double 0.000000e+00
@options_worker_ts_.str.13.handle = internal global double 0.000000e+00
@options_worker_ts_.str.14.handle = internal global double 0.000000e+00
@options_worker_ts_.str.15.handle = internal global double 0.000000e+00
@options_worker_ts_.str.16.handle = internal global double 0.000000e+00
@options_worker_ts_.str.17.handle = internal global double 0.000000e+00
@options_worker_ts_.str.18.handle = internal global double 0.000000e+00
@options_worker_ts_.str.19.handle = internal global double 0.000000e+00
@options_worker_ts_.str.20.handle = internal global double 0.000000e+00
@options_worker_ts_.str.21.handle = internal global double 0.000000e+00
@options_worker_ts_.str.22.handle = internal global double 0.000000e+00
@options_worker_ts_.str.23.handle = internal global double 0.000000e+00

declare void @js_gc_init()

declare void @js_typed_feedback_maybe_dump_trace()

declare void @js_set_process_entry_path(ptr, i32)

declare void @js_stdlib_init_dispatch()

declare void @perry_app_group_init(ptr, i32)

declare void @perry_update_notify_startup(ptr, i32)

declare void @perry_macos_bundle_chdir()

declare i32 @perry_i18n_locale_index_for(i64, i32)

declare void @perry_i18n_init(ptr, ptr, i32, i32)

declare void @perry_i18n_set_currencies(ptr, i32)

declare i32 @perry_i18n_plural_category(i32, double)

declare void @js_register_function_name_static(ptr, ptr, i32)

declare void @js_register_function_name(ptr, ptr, i32)

declare void @js_register_function_source_static(ptr, ptr, i32, i32)

declare void @js_register_function_source(ptr, ptr, i32, i32)

declare void @js_console_log_dynamic(double)

declare void @js_console_log_number(double)

declare void @js_console_error_dynamic(double)

declare void @js_console_error_number(double)

declare void @js_console_warn_dynamic(double)

declare void @js_console_warn_number(double)

declare void @js_console_dir_with_options(double, double)

declare double @js_console_method_by_value(double)

declare double @js_nanbox_string(i64)

; Function Attrs: nounwind willreturn
declare double @js_nanbox_pointer(i64) #0

; Function Attrs: nounwind willreturn
declare i64 @js_nanbox_get_pointer(double) #0

declare double @js_native_handle_new_owned(i64, i64, i32, i32, ptr, ptr, i64)

declare double @js_native_handle_new_borrowed(i64, i64, i32, i32, ptr, i64)

declare i64 @js_native_handle_unwrap(double, i64, i32, i32, i32)

declare i64 @js_string_from_bytes(ptr, i32)

declare i64 @js_string_from_wtf8_bytes(ptr, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_is_truthy(double) #0

declare double @js_native_abi_check_f64(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_f64_arg_guard(double) #0

declare double @js_typed_f64_arg_to_raw(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_string_arg_guard(double) #0

declare i64 @js_typed_string_arg_to_raw(double)

declare i32 @js_param_type_guard(double, ptr, i32)

declare float @js_native_abi_check_f32(double)

declare i8 @js_native_abi_check_i8(double)

declare i16 @js_native_abi_check_i16(double)

declare i32 @js_native_abi_check_i32(double)

declare i64 @js_native_abi_check_i64(double)

declare i8 @js_native_abi_check_u8(double)

declare i16 @js_native_abi_check_u16(double)

declare i32 @js_native_abi_check_u32(double)

declare i64 @js_native_abi_check_u64(double)

declare i64 @js_native_abi_check_usize(double)

declare i64 @js_native_abi_check_isize(double)

declare double @js_native_abi_materialize_i64(i64)

declare double @js_native_abi_materialize_u64(i64)

declare i64 @js_native_abi_check_string_ptr(double)

declare i64 @js_native_abi_check_ptr(double)

declare ptr @js_native_abi_check_buffer_data_ptr(double)

declare i64 @js_native_abi_check_buffer_byte_len(double)

declare i64 @js_native_abi_check_promise(double)

declare i64 @js_native_abi_check_pod_object(double)

declare double @js_date_now()

declare void @js_gc_register_global_root(i64)

declare i64 @js_string_concat(i64, i64)

declare double @js_string_concat_box(double, double)

declare i64 @js_jsvalue_to_string(double)

declare i64 @js_jsvalue_to_string_method(double)

declare i64 @js_jsvalue_to_string_coerce(double)

declare i64 @js_string_concat_value(i64, double)

declare double @js_string_concat_site_value(i64, i64, double)

declare i64 @js_value_concat_string(double, i64)

declare double @js_string_concat_value_box(i64, double)

declare double @js_string_add_value(double, double)

declare double @js_value_add_string(double, double)

declare i64 @js_string_concat_chain(i64, i32)

declare i64 @js_string_append_chain(i64, i32)

declare i64 @js_string_append(i64, i64)

declare i64 @js_string_append_known_heap(i64, i64)

declare i32 @js_string_index_of(i64, i64)

declare i32 @js_string_index_of_from(i64, i64, i32)

declare i32 @js_string_position_to_index(double)

declare i64 @js_string_slice(i64, i32, i32)

declare i64 @js_string_substring(i64, i32, i32)

declare i64 @js_string_substr(i64, double, double)

declare i64 @js_string_split(i64, i64)

declare i64 @js_string_split_n(i64, i64, i32)

declare double @js_string_split_part_value(i64, i64, i32)

declare double @js_string_split_part_utf16_length(i64, i64, i32)

declare double @js_string_to_upper_case_split_part_utf16_length(i64, i64, i32)

declare i32 @js_string_to_upper_case_index_of(i64, i64)

declare i64 @js_string_split_value(i64, double, double)

declare double @js_math_trunc(double)

declare double @js_math_round(double)

declare double @js_math_sign(double)

declare double @js_math_imul(double, double)

declare double @js_math_pow(double, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.ceil.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.copysign.f64(double, double) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.aarch64.fjcvtzs(double) #3

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #5

declare i64 @js_json_stringify(double, i32)

declare i64 @js_map_alloc(i32)

declare i64 @js_text_encoder_encode_into_llvm(double, double)

declare i64 @js_value_typeof(double)

declare i32 @js_value_typeof_tag(double)

declare i32 @js_string_starts_with(i64, i64)

declare i32 @js_string_ends_with(i64, i64)

declare i64 @js_string_search_value_to_string(double, i32)

declare i32 @js_string_starts_with_at(i64, i64, i32)

declare i32 @js_string_ends_with_at(i64, i64, i32)

declare i64 @js_closure_alloc(ptr, i32)

declare i64 @js_closure_alloc_init(ptr, i32, ptr)

declare i64 @js_closure_alloc_singleton(ptr)

declare i64 @js_closure_alloc_with_captures_singleton(ptr, i32, ptr)

declare void @js_closure_set_capture_bits(i64, i32, i64)

declare void @js_closure_set_box_capture_ptr(i64, i32, i64)

declare i64 @js_closure_get_capture_bits(i64, i32)

declare void @js_closure_set_capture_f64(i64, i32, double)

declare double @js_closure_get_capture_f64(i64, i32)

declare void @js_register_closure_rest(ptr, i32)

declare void @js_register_closure_synthetic_arguments(ptr, i32)

declare void @js_register_closure_rest_and_arguments(ptr, i32)

declare void @js_register_closure_arity(ptr, i32)

declare void @js_register_closure_length(ptr, i32)

declare void @js_register_closure_arrow_function(ptr)

declare void @js_register_closure_trusted_direct(ptr, ptr, i32, i64)

declare void @js_register_closure_versioned_loop_direct(ptr, ptr, i32, i64)

declare ptr @js_closure_resolve_versioned_loop_direct_call(i64, i32)

declare void @js_register_closure_strict_function(ptr)

declare void @js_register_closure_async_function(ptr)

declare void @js_register_closure_generator_function(ptr)

declare void @js_register_closure_async_generator_function(ptr)

declare i64 @js_closure_unbox_callee_checked(double)

declare i64 @js_closure_unbox_callee_checked_rebind(double, double)

declare double @js_closure_call0(i64)

declare double @js_closure_call1(i64, double)

declare double @js_closure_call1_receiverless(i64, double)

declare double @js_closure_call2(i64, double, double)

declare double @js_closure_call3(i64, double, double, double)

declare ptr @js_closure_resolve_arrow_direct_call(i64, i32)

declare double @js_closure_call4(i64, double, double, double, double)

declare double @js_closure_call5(i64, double, double, double, double, double)

declare double @js_closure_call6(i64, double, double, double, double, double, double)

declare double @js_closure_call7(i64, double, double, double, double, double, double, double)

declare double @js_closure_call8(i64, double, double, double, double, double, double, double, double)

declare double @js_closure_call9(i64, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call10(i64, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call11(i64, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call12(i64, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call13(i64, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call14(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call15(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call16(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare i64 @js_array_map(i64, i64)

declare void @js_array_map_discard(i64, i64)

declare i64 @js_array_filter(i64, i64)

declare i64 @js_array_concat(i64, i64)

declare i64 @js_array_concat_new(i64, i64)

declare i64 @js_error_new()

declare i64 @js_error_new_with_message(i64)

declare i64 @js_error_new_from_value(double)

declare i64 @js_error_new_kind_from_value(i32, double)

declare i64 @js_error_new_with_cause_from_value(double, double)

declare i64 @js_error_new_kind_with_options_from_value(i32, double, double)

declare double @js_assert_assertion_error_ctor(double)

declare double @js_assert_assert_ctor(double)

declare void @js_throw_type_error_property_access(i32, ptr, i64)

declare void @js_throw_type_error_not_a_function(ptr, i64, ptr, i64)

declare void @js_throw_error_with_code(ptr, i64, ptr, i64, i32)

declare i64 @js_map_set(i64, double, double)

declare i64 @js_map_set_string_number(i64, i64, double)

declare i64 @js_map_set_string_key(i64, i64, double)

declare i64 @js_map_set_string_i32(i64, i64, i32)

declare i64 @js_map_set_string_u32(i64, i64, i32)

declare i64 @js_map_set_string_f32(i64, i64, float)

declare i64 @js_map_set_string_bool(i64, i64, i32)

declare i64 @js_map_set_string_string(i64, i64, i64)

declare i64 @js_map_set_number_key(i64, double, double)

declare double @js_map_get(i64, double)

declare double @js_declared_map_get(double, double)

declare double @js_map_get_string_key(i64, i64)

declare double @js_map_get_number_key(i64, double)

declare i32 @js_map_has(i64, double)

declare i32 @js_map_has_string_key(i64, i64)

declare i32 @js_map_has_number_key(i64, double)

declare i32 @js_map_delete(i64, double)

declare i32 @js_map_delete_string_key(i64, i64)

declare i32 @js_map_delete_number_key(i64, double)

declare i64 @js_object_keys(i64)

declare i64 @js_object_keys_value(double)

declare i64 @js_for_in_keys_value(double)

declare i64 @js_for_in_keys_stable_value(double)

declare double @js_is_finite(double)

declare i32 @js_is_undefined_or_bare_nan(double)

declare double @js_math_min_array(i64)

declare double @js_math_max_array(i64)

declare double @js_math_min2(double, double)

declare double @js_math_max2(double, double)

declare i64 @js_string_coerce(double)

declare i64 @js_string_coerce_method_this(double, ptr, i64)

declare i64 @js_array_slice(i64, i32, i32)

declare i64 @js_array_slice_values(i64, double, double)

declare double @js_array_shift_f64(i64)

declare i64 @js_set_alloc(i32)

declare i64 @js_set_from_array(i64)

declare i64 @js_set_from_iterable(double)

declare i64 @js_map_from_array(i64)

declare i64 @js_map_from_iterable(double)

declare double @js_object_has_property(double, double)

declare double @js_in_operator(double, double)

declare double @js_private_brand_check(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_guard(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_brand_add(double, i32)

declare double @js_private_field_add(double, i32, double, double)

declare double @js_class_field_add(double, double, double)

declare double @js_class_computed_field_key(double, i32, ptr, i64)

declare double @js_fs_to_unix_timestamp(double)

declare i32 @js_fs_write_file_sync(double, double)

declare i32 @js_fs_write_file_sync_options(double, double, double)

declare i32 @js_fs_append_file_sync(double, double)

declare i32 @js_fs_append_file_sync_options(double, double, double)

declare i32 @js_fs_exists_sync(double)

declare i64 @js_fs_read_file_sync(double)

declare double @js_fs_read_file_dispatch(double, double)

declare double @js_fs_open_as_blob(double, double)

declare double @js_fs_promises_read_file(double, double)

declare double @js_fs_promises_write_file(double, double, double)

declare double @js_fs_promises_append_file(double, double, double)

declare double @js_fs_promises_mkdir(double, double)

declare double @js_fs_promises_rmdir(double, double)

declare i32 @js_fs_mkdir_sync(double)

declare i32 @js_fs_mkdir_sync_options(double, double)

declare i32 @js_fs_unlink_sync(double)

declare double @js_fs_readdir_sync(double, double)

declare double @js_fs_stat_sync(double)

declare double @js_fs_stat_sync_options(double, double)

declare double @js_fs_lstat_sync(double)

declare double @js_fs_lstat_sync_options(double, double)

declare i32 @js_fs_rename_sync(double, double)

declare i32 @js_fs_copy_file_sync(double, double)

declare i32 @js_fs_copy_file_sync_flags(double, double, double)

declare i32 @js_fs_cp_sync(double, double)

declare i32 @js_fs_cp_sync_options(double, double, double)

declare i32 @js_fs_chmod_sync(double, double)

declare i32 @js_fs_chown_sync(double, double, double)

declare i32 @js_fs_lchown_sync(double, double, double)

declare i32 @js_fs_lchmod_sync(double, double)

declare i32 @js_fs_truncate_sync(double, double)

declare i32 @js_fs_ftruncate_sync(double, double)

declare i32 @js_fs_fsync_sync(double)

declare i32 @js_fs_fdatasync_sync(double)

declare i32 @js_fs_fchmod_sync(double, double)

declare i32 @js_fs_fchown_sync(double, double, double)

declare double @js_fs_fstat_sync(double)

declare double @js_fs_fstat_sync_options(double, double)

declare i32 @js_fs_utimes_sync(double, double, double)

declare i32 @js_fs_lutimes_sync(double, double, double)

declare i32 @js_fs_futimes_sync(double, double, double)

declare double @js_fs_readv_sync(double, double, double)

declare double @js_fs_writev_sync(double, double, double)

declare double @js_fs_statfs_sync(double)

declare double @js_fs_statfs_sync_options(double, double)

declare double @js_fs_opendir_sync(double)

declare double @js_fs_glob_sync(double)

declare double @js_fs_glob_sync_options(double, double)

declare i32 @js_fs_link_sync(double, double)

declare i32 @js_fs_symlink_sync(double, double)

declare double @js_fs_symlink_callback(double, double, double, double)

declare i64 @js_fs_readlink_sync(double)

declare i64 @js_fs_readlink_sync_options(double, double)

declare double @js_fs_readlink_dispatch(double, double)

declare double @js_fs_open_sync(double, double)

declare i32 @js_fs_close_sync(double)

declare double @js_fs_read_sync(double, double, double, double, double)

declare double @js_fs_read_sync_options(double, double, double)

declare double @js_fs_write_sync(double, double)

declare double @js_fs_write_string_sync_options(double, double, double)

declare double @js_fs_write_buffer_sync(double, double, double, double, double)

declare double @js_fs_write_sync_options_dispatch(double, double, double)

declare i32 @js_fs_access_sync(double)

declare i32 @js_fs_access_sync_mode(double, double)

declare double @js_fs_access_sync_throw(double)

declare double @js_fs_access_sync_throw_mode(double, double)

declare i64 @js_fs_realpath_sync(double)

declare double @js_fs_realpath_dispatch(double, double)

declare i64 @js_fs_mkdtemp_sync(double)

declare i64 @js_fs_mkdtemp_sync_options(double, double)

declare double @js_fs_mkdtemp_dispatch(double, double)

declare double @js_fs_mkdtemp_disposable_sync(double, double)

declare i32 @js_fs_rmdir_sync(double)

declare i32 @js_fs_rmdir_sync_options(double, double)

declare i32 @js_fs_rm_recursive(double)

declare i32 @js_fs_rm_recursive_options(double, double)

declare double @js_fs_create_write_stream(double, double)

declare double @js_fs_create_read_stream(double, double)

declare double @js_fs_utf8_stream_new(double)

declare double @js_fs_utf8_stream_call_without_new(double)

declare double @js_fs_utf8_stream_write(double, double)

declare double @js_fs_utf8_stream_flush(double, double)

declare double @js_fs_utf8_stream_flush_sync(double)

declare double @js_fs_utf8_stream_end(double, double)

declare double @js_fs_utf8_stream_destroy(double)

declare double @js_fs_utf8_stream_reopen(double, double)

declare double @js_fs_utf8_stream_on(double, double, double)

declare double @js_fs_utf8_stream_once(double, double, double)

declare double @js_fs_utf8_stream_off(double, double, double)

declare double @js_fs_utf8_stream_remove_all(double, double)

declare double @js_fs_utf8_stream_listener_count(double, double)

declare double @js_fs_utf8_stream_emit(double, double, double)

declare double @js_fs_read_file_callback(double, double, double)

declare double @js_fs_stats_is_file(double)

declare double @js_fs_stats_is_directory(double)

declare i64 @js_fs_read_file_binary(double)

declare double @js_number_coerce(double)

declare double @js_math_to_number(double)

declare i64 @js_set_add(i64, double)

declare i64 @js_set_add_string(i64, i64)

declare i64 @js_set_add_number(i64, double)

declare i64 @js_set_add_i32(i64, i32)

declare i64 @js_set_add_u32(i64, i32)

declare i64 @js_set_add_f32(i64, float)

declare i64 @js_set_add_bool(i64, i32)

declare i32 @js_set_has(i64, double)

declare double @js_readonly_set_has(double, double)

declare i32 @js_set_has_string(i64, i64)

declare i32 @js_set_has_number(i64, double)

declare i32 @js_set_has_i32(i64, i32)

declare i32 @js_set_has_u32(i64, i32)

declare i32 @js_set_has_f32(i64, float)

declare i32 @js_set_has_bool(i64, i32)

declare i32 @js_set_delete(i64, double)

declare i32 @js_set_delete_string(i64, i64)

declare i32 @js_set_delete_number(i64, double)

declare i32 @js_set_delete_i32(i64, i32)

declare i32 @js_set_delete_u32(i64, i32)

declare i32 @js_set_delete_f32(i64, float)

declare i32 @js_set_delete_bool(i64, i32)

declare i32 @js_set_size(i64)

declare i64 @js_set_union(i64, double)

declare i64 @js_set_intersection(i64, double)

declare i64 @js_set_difference(i64, double)

declare i64 @js_set_symmetric_difference(i64, double)

declare i32 @js_set_is_subset_of(i64, double)

declare i32 @js_set_is_superset_of(i64, double)

declare i32 @js_set_is_disjoint_from(i64, double)

declare i64 @js_string_to_lower_case(i64)

declare i64 @js_string_to_upper_case(i64)

declare i64 @js_string_to_locale_lower_case(i64, double)

declare i64 @js_string_to_locale_upper_case(i64, double)

declare void @js_string_validate_collator_args(double, double)

declare i64 @js_string_trim(i64)

declare i64 @js_string_trim_start(i64)

declare i64 @js_string_trim_end(i64)

declare i64 @js_string_big(i64)

declare i64 @js_string_blink(i64)

declare i64 @js_string_bold(i64)

declare i64 @js_string_fixed(i64)

declare i64 @js_string_italics(i64)

declare i64 @js_string_small(i64)

declare i64 @js_string_strike(i64)

declare i64 @js_string_sub(i64)

declare i64 @js_string_sup(i64)

declare i64 @js_string_anchor(i64, i64)

declare i64 @js_string_link(i64, i64)

declare i64 @js_string_fontcolor(i64, i64)

declare i64 @js_string_fontsize(i64, i64)

declare i64 @js_string_char_at(i64, i32)

declare double @js_string_index_get(i64, double)

declare double @js_string_index_get_boxed(double, double)

declare i32 @js_string_index_to_i32(double)

declare i32 @js_string_end_index_to_i32(double, i32)

declare double @js_typed_feedback_object_get_field_by_value_f64(i64, i64, double)

declare double @js_dyn_index_get(double, double)

declare double @js_packed_arraylike_index_get(double, double, ptr)

declare i32 @js_packed_arraylike_loop_guard(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_guard_live(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_revalidate_live(double, double, i32, ptr)

declare double @js_dyn_index_set(double, double, double)

declare double @js_dyn_index_set_strict(double, double, double, i32)

declare i64 @js_string_to_char_array(i64)

declare i64 @js_string_repeat(i64, double)

declare i64 @js_string_replace_string(i64, i64, i64)

declare i64 @js_string_replace_all_string(i64, i64, i64)

declare i32 @js_string_equals(i64, i64)

declare i32 @js_string_compare(i64, i64)

declare i32 @js_jsvalue_equals(double, double)

declare i32 @js_string_compare_value(double, double)

declare i64 @js_jsvalue_to_string_radix(double, double)

declare double @js_math_random()

declare double @js_webassembly_validate(double)

declare double @js_webassembly_compile(double)

declare double @js_webassembly_module_new(double)

declare double @js_webassembly_module_exports(double)

declare double @js_webassembly_module_imports(double)

declare double @js_webassembly_module_custom_sections(double, double)

declare double @js_webassembly_instantiate(double, double)

declare double @js_wasi_emit_warning()

declare double @js_webassembly_call_export_0(double, double)

declare double @js_webassembly_call_export_1(double, double, double)

declare double @js_webassembly_call_export_2(double, double, double, double)

declare double @js_webassembly_call_export_3(double, double, double, double, double)

declare double @js_webassembly_call_export_4(double, double, double, double, double, double)

declare void @js_console_log_spread(i64)

declare void @js_console_info_spread(i64)

declare void @js_console_debug_spread(i64)

declare void @js_console_error_spread(i64)

declare void @js_console_warn_spread(i64)

declare double @js_util_format(i64)

declare double @js_util_format_with_options(double, i64)

declare double @js_util_inspect(double, double)

declare double @js_util_debuglog(double, double)

declare double @js_util_diff(double, double)

declare double @js_util_inherits(double, double)

declare double @js_util_is_deep_strict_equal(double, double)

declare double @js_util_strip_vt_control_characters(double)

declare double @js_util_style_text(double, double, double)

declare double @js_util_get_call_sites(double, double)

declare double @js_util_promisify(double)

declare double @js_util_callbackify(double)

declare double @js_util_deprecate(double, double, double)

declare double @js_util_aborted(double, double)

declare double @js_util_transferable_abort_controller()

declare double @js_util_transferable_abort_signal(double)

declare double @js_util_parse_args(double)

declare double @js_boxed_number_new(double)

declare double @js_boxed_string_new(double, i32)

declare double @js_boxed_boolean_new(double)

declare double @js_util_types_is_arguments_object(double)

declare double @js_util_types_is_promise(double)

declare double @js_util_types_is_big_int_object(double)

declare double @js_util_types_is_symbol_object(double)

declare double @js_util_types_is_array_buffer(double)

declare double @js_util_types_is_shared_array_buffer(double)

declare double @js_util_types_is_any_array_buffer(double)

declare double @js_util_types_is_array_buffer_view(double)

declare double @js_util_types_is_data_view(double)

declare double @js_util_types_is_typed_array(double)

declare double @js_util_types_is_uint8_array(double)

declare double @js_util_types_is_int8_array(double)

declare double @js_util_types_is_int16_array(double)

declare double @js_util_types_is_uint16_array(double)

declare double @js_util_types_is_int32_array(double)

declare double @js_util_types_is_uint32_array(double)

declare double @js_util_types_is_float16_array(double)

declare double @js_util_types_is_float32_array(double)

declare double @js_util_types_is_float64_array(double)

declare double @js_util_types_is_uint8_clamped_array(double)

declare double @js_util_types_is_big_int64_array(double)

declare double @js_util_types_is_big_uint64_array(double)

declare double @js_util_types_is_map(double)

declare double @js_util_types_is_weak_map(double)

declare double @js_util_types_is_set(double)

declare double @js_util_types_is_weak_set(double)

declare double @js_util_types_is_date(double)

declare double @js_util_types_is_reg_exp(double)

declare double @js_util_types_is_async_function(double)

declare double @js_util_types_is_generator_function(double)

declare double @js_util_types_is_generator_object(double)

declare double @js_util_types_is_native_error(double)

declare double @js_util_types_is_number_object(double)

declare double @js_util_types_is_string_object(double)

declare double @js_util_types_is_boolean_object(double)

declare double @js_util_types_is_boxed_primitive(double)

declare double @js_util_types_is_external(double)

declare double @js_util_types_is_module_namespace_object(double)

declare double @js_util_types_is_key_object(double)

declare double @js_util_types_is_crypto_key(double)

declare double @js_util_types_is_proxy(double)

declare double @js_util_types_is_map_iterator(double)

declare double @js_util_types_is_set_iterator(double)

declare double @js_data_view_new(double, double, double)

declare double @js_data_view_get_direct(double, double, double, i32, i32)

declare double @js_data_view_set_direct(double, double, double, double, i32, i32)

declare i64 @js_getenv(i64)

declare double @js_getenv_value(i64)

declare void @js_setenv(i64, double)

declare void @js_removeenv(i64)

declare double @js_process_exit_code_get()

declare double @js_process_exit_code_set(double)

declare void @js_console_table(double)

declare void @js_console_table_with_properties(double, double)

declare void @js_console_trace(double)

declare void @js_console_trace_spread(i64)

declare i64 @js_process_cwd()

declare i64 @js_process_argv()

declare double @js_process_pid()

declare double @js_process_ppid()

declare double @js_process_uptime()

declare i64 @js_process_version()

declare double @js_process_versions()

declare double @js_process_memory_usage()

declare double @js_bigint_as_int_n_call(double, double)

declare double @js_bigint_as_uint_n_call(double, double)

declare double @js_v8_serialize(double)

declare double @js_v8_deserialize(double)

declare double @js_v8_get_heap_statistics()

declare double @js_v8_get_heap_code_statistics()

declare double @js_v8_get_heap_space_statistics()

declare double @js_v8_cached_data_version_tag()

declare double @js_v8_get_heap_snapshot(double)

declare double @js_v8_write_heap_snapshot(double, double)

declare double @js_v8_gc_profiler_new()

declare double @js_v8_gc_profiler_start(double)

declare double @js_v8_gc_profiler_stop(double)

declare double @js_v8_gc_profiler_report()

declare double @js_v8_serializer_new(double)

declare double @js_v8_deserializer_new(double)

declare double @js_v8_noop_undefined()

declare double @js_v8_is_building_snapshot()

declare double @js_v8_namespace(ptr, i64)

declare double @js_v8_throw_not_building_snapshot()

declare double @js_v8_promise_hook_register()

declare double @js_v8_promise_hooks_on_init(double)

declare double @js_v8_promise_hooks_on_before(double)

declare double @js_v8_promise_hooks_on_after(double)

declare double @js_v8_promise_hooks_on_settled(double)

declare double @js_v8_promise_hooks_create_hook(double)

declare double @js_process_thread_cpu_usage(double)

declare double @js_process_available_memory()

declare double @js_process_constrained_memory()

declare double @js_process_source_maps_enabled()

declare double @js_process_set_source_maps_enabled(double)

declare double @js_process_has_uncaught_exception_capture_callback()

declare double @js_process_set_uncaught_exception_capture_callback(double)

declare double @js_process_add_uncaught_exception_capture_callback(double)

declare double @js_process_getuid()

declare double @js_process_geteuid()

declare double @js_process_getgid()

declare double @js_process_getegid()

declare void @js_process_emit_warning(double, double, double)

declare double @js_process_cpu_usage(double)

declare double @js_process_resource_usage()

declare double @js_process_active_resources_info()

declare double @js_process_env()

declare double @js_process_hrtime_bigint()

declare double @js_process_hrtime(double)

declare double @js_process_title()

declare void @js_process_set_title(double)

declare void @js_process_chdir(i64)

declare void @js_process_chdir_jsv(double)

declare double @js_process_kill(double, double)

declare void @js_process_exit(double)

declare void @js_process_abort()

declare double @js_process_umask()

declare double @js_process_umask_set(double)

declare double @js_process_on(i64, i64)

declare double @js_process_add_listener(i64, i64)

declare double @js_process_once(i64, i64)

declare double @js_process_prepend_listener(i64, i64)

declare double @js_process_prepend_once_listener(i64, i64)

declare double @js_process_emit(i64, i64)

declare void @js_process_emit_before_exit(double)

declare void @js_process_emit_before_exit_pending()

declare void @js_process_run_exit_sequence()

declare void @js_process_run_finalization_exit()

declare void @js_trace_events_flush_output()

declare void @js_promise_report_unhandled_rejections()

declare i32 @js_process_pending_exit_code()

declare void @js_gc_release_current_thread_collection_side_allocations()

declare double @js_process_remove_listener(i64, i64)

declare double @js_process_off(i64, i64)

declare double @js_process_remove_all_listeners(i64)

declare double @js_process_listener_count(i64, i64)

declare i64 @js_process_listeners(i64)

declare i64 @js_process_raw_listeners(i64)

declare i64 @js_process_event_names()

declare double @js_process_set_max_listeners(double)

declare double @js_process_get_max_listeners()

declare double @js_process_get_builtin_module(double)

declare double @js_process_get_builtin_module_devirt(double)

declare double @js_process_execve(double, double, double)

declare double @js_module_is_builtin(double)

declare double @js_module_find_package_json(double, double, double)

declare double @js_module_find_source_map(double)

declare double @js_module_source_map_new(double, double)

declare double @js_module_register(double, double, double)

declare double @js_module_register_hooks(double)

declare void @js_process_next_tick(i64, i64)

declare double @js_process_stdin()

declare double @js_process_stdout()

declare double @js_process_stderr()

declare double @js_readline_set_raw_mode(double)

declare void @js_readline_stdin_on(i64, i64)

declare double @js_readline_stdin_remove_listener(i64, i64)

declare double @js_readline_stdin_pause()

declare double @js_readline_stdin_resume()

declare double @js_readline_stdin_unref()

declare double @js_readline_stdin_ref()

declare double @js_readline_stdin_destroy()

declare double @js_tty_isatty(double)

declare double @js_tty_read_stream_new(double)

declare double @js_tty_write_stream_new(double)

declare double @js_wasi_constructor_call(double)

declare double @js_process_stdin_isatty()

declare double @js_process_stdout_isatty()

declare double @js_process_stderr_isatty()

declare double @js_process_stdout_columns()

declare double @js_process_stdout_rows()

declare double @js_process_stdout_on(i64, i64)

declare i64 @js_os_platform()

declare i64 @js_os_arch()

declare i64 @js_os_type()

declare i64 @js_os_release()

declare i64 @js_os_hostname()

declare i64 @js_os_eol()

declare double @js_os_available_parallelism()

declare i64 @js_os_endianness()

declare i64 @js_os_dev_null()

declare i64 @js_os_machine()

declare i64 @js_os_loadavg()

declare i64 @js_os_version()

declare i64 @js_box_alloc_bits(i64)

declare i64 @js_box_get_bits(i64)

declare i64 @js_box_get_bits_named(i64, double)

declare void @js_box_set_bits(i64, i64)

declare i64 @js_box_get_bits_trusted(i64)

declare i64 @js_box_get_bits_trusted_named(i64, double)

declare void @js_box_set_bits_trusted_no_barrier(i64, i64)

declare i64 @js_box_alloc(double)

declare double @js_box_get(i64)

declare void @js_box_set(i64, double)

declare i64 @js_i32_box_alloc(i32)

declare i32 @js_i32_box_get(i64)

declare void @js_i32_box_set(i64, i32)

declare void @js_box_release(i64)

declare void @js_i32_box_release(i64)

declare void @js_bool_box_release(i64)

declare i64 @js_bool_box_alloc(i32)

declare i32 @js_bool_box_get(i64)

declare void @js_bool_box_set(i64, i32)

declare i64 @js_arguments_object_alloc(double, double, i32)

declare void @js_arguments_object_map_index(i64, i32, i64)

declare i64 @js_array_like_to_array(double)

declare i32 @js_object_get_class_id(i64)

declare i64 @js_object_alloc_with_parent(i32, i32, i32)

declare i64 @js_object_alloc_class_with_keys(i32, i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_dynamic_parent(i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_inline_keys(i32, i32, i32, i64)

declare i64 @js_object_alloc_class_inline_keys_stamped(i32, i32, i32, i64, i32)

declare i64 @js_build_class_keys_array(i32, i32, ptr, i32)

declare i32 @js_object_shape_id_for_keys(i64, i32)

declare i32 @js_gc_typed_shape_id_for_keys(i32, i64, i32, ptr, i32, ptr, i32)

declare ptr @js_inline_arena_state()

declare ptr @js_inline_arena_slow_alloc(ptr, i64, i64)

declare i32 @js_object_delete_field(i64, i64)

declare i32 @js_object_delete_field_value(double, i64)

declare i32 @js_object_delete_dynamic_value(double, double)

declare double @js_delete_result(i32, i32)

declare i64 @js_eq(i64, i64)

declare i64 @js_loose_eq(i64, i64)

declare i64 @js_number_to_fixed(double, double)

declare i64 @js_string_replace_regex(i64, i64, i64)

declare i64 @js_string_replace_all_regex(i64, i64, i64)

declare double @js_array_at(i64, double)

declare double @js_date_get_time(double)

declare double @js_date_get_full_year(double)

declare double @js_date_get_month(double)

declare double @js_date_get_date(double)

declare double @js_date_get_day(double)

declare double @js_date_get_hours(double)

declare double @js_date_get_minutes(double)

declare double @js_date_get_seconds(double)

declare double @js_date_get_milliseconds(double)

declare double @js_date_get_utc_day(double)

declare double @js_date_get_utc_full_year(double)

declare double @js_date_get_utc_month(double)

declare double @js_date_get_utc_date(double)

declare double @js_date_get_utc_hours(double)

declare double @js_date_get_utc_minutes(double)

declare double @js_date_get_utc_seconds(double)

declare double @js_date_get_utc_milliseconds(double)

declare double @js_date_value_of(double)

declare double @js_date_get_timezone_offset(double)

declare double @js_date_coerce_number(double)

declare double @js_rel_lt(double, double)

declare double @js_rel_le(double, double)

declare double @js_rel_gt(double, double)

declare double @js_rel_ge(double, double)

declare i64 @js_date_to_string(double)

declare i64 @js_date_to_iso_string(double)

declare i64 @js_date_to_iso_string_or_throw(double)

declare double @js_date_new_from_timestamp(double)

declare double @js_date_new_from_value(double)

declare i32 @js_array_indexOf_f64(i64, double)

declare i64 @js_array_indexOf_jsvalue(i64, double, double, i32)

declare i64 @js_array_last_index_of_jsvalue(i64, double, double, i32)

declare i32 @js_array_includes_f64(i64, double)

declare i32 @js_array_includes_jsvalue(i64, double, double, i32)

declare i32 @js_map_size(i64)

declare void @js_map_clear(i64)

declare void @js_set_clear(i64)

declare i64 @js_map_entries(i64)

declare i64 @js_map_keys(i64)

declare i64 @js_map_values(i64)

declare double @js_map_entry_key_at(i64, i32)

declare double @js_map_entry_value_at(i64, i32)

declare double @js_map_entry_key_raw_at(i64, i32)

declare double @js_map_entry_value_raw_at(i64, i32)

declare double @js_set_value_raw_at(i64, i32)

declare double @js_map_find_key_index(double, double)

declare double @js_set_find_value_index(double, double)

declare double @js_map_cursor_next(double, double, double)

declare double @js_map_compaction_epoch(double)

declare double @js_set_cursor_next(double, double, double)

declare double @js_set_compaction_epoch(double)

declare void @js_map_foreach(i64, double, double)

declare void @js_set_foreach(i64, double, double)

declare i64 @js_map_entries_iter_obj(i64)

declare i64 @js_map_keys_iter_obj(i64)

declare i64 @js_map_values_iter_obj(i64)

declare i64 @js_set_values_iter_obj(i64)

declare i64 @js_set_keys_iter_obj(i64)

declare i64 @js_set_entries_iter_obj(i64)

declare i64 @js_set_to_array(i64)

declare double @js_set_value_at(i64, i32)

declare i64 @js_array_splice(i64, i32, i32, ptr, i32, ptr)

declare i32 @js_array_splice_delete_count(double)

declare double @js_parse_int(i64, double)

declare double @js_parse_float(i64)

declare double @js_array_reduce(i64, i64, i32, double)

declare double @js_array_reduce_right(i64, i64, i32, double)

declare i64 @js_array_sort_default(i64)

declare i64 @js_array_reverse(i64)

declare double @js_array_reverse_value(double)

declare i64 @js_array_flat(i64)

declare i64 @js_array_flat_depth(i64, double)

declare i64 @js_array_flatMap(i64, i64)

declare i64 @js_array_sort_with_comparator(i64, i64)

declare i64 @js_validate_array_comparator(double)

declare i64 @js_validate_array_callback(double)

declare i64 @js_validate_array_map_callback(i64, double)

declare i64 @js_array_to_reversed(i64)

declare i64 @js_array_to_sorted_default(i64)

declare i64 @js_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_array_to_spliced(i64, double, double, ptr, i32)

declare i64 @js_array_with(i64, double, double)

declare i64 @js_array_copy_within(i64, double, double, i32, double)

declare double @js_array_copy_within_value(double, double, double, i32, double)

declare i64 @js_regexp_new(i64, i64)

declare i64 @js_regexp_new_site(i64, i64, i64)

declare i64 @js_regexp_new_factory_site(i64, i64, i64, i64)

declare i64 @js_regexp_site_test_new(i64, i64, i64)

declare double @js_regexp_site_factory_call_value(i64, double)

declare double @js_regexp_site_factory_call_method(i64, double, double)

declare double @js_regexp_site_test_get_method(i64, double)

declare double @js_regexp_site_test_dispatch(i64, double, double, double)

declare i64 @js_regexp_construct(double, double)

declare i64 @js_regexp_construct_call(double, double)

declare i32 @js_regexp_test(i64, i64)

declare double @js_regexp_escape(double)

declare i64 @js_get_string_pointer_unified(double)

declare i32 @js_switch_strict_equals(double, double)

declare i64 @js_value_to_str_ptr_for_ffi(double)

declare void @js_string_addref(i64)

declare void @js_string_addref_if_heap_string(double)

declare i64 @js_bigint_from_string(ptr, i32)

declare i64 @js_bigint_from_f64(double)

declare i64 @js_bigint_from_i128_parts(i64, i64)

declare i32 @js_bigint_cmp(i64, i64)

declare double @js_dynamic_add(double, double)

declare double @js_to_numeric(double)

declare double @js_numeric_step(double, i32)

declare i64 @js_box_capture_cell_ptr(i64)

declare double @js_dynamic_string_or_number_add(double, double)

declare double @js_dynamic_sub(double, double)

declare double @js_dynamic_mul(double, double)

declare double @js_dynamic_div(double, double)

declare double @js_dynamic_mod(double, double)

declare double @js_dynamic_bitand(double, double)

declare double @js_dynamic_bitor(double, double)

declare double @js_dynamic_bitxor(double, double)

declare double @js_dynamic_shl(double, double)

declare double @js_dynamic_shr(double, double)

declare double @js_dynamic_bitnot(double)

declare double @js_dynamic_pow(double, double)

declare double @js_dynamic_ushr(double, double)

declare double @js_instanceof(double, i32)

declare double @js_instanceof_dynamic(double, double)

declare double @js_instanceof_noncallable_rhs()

declare void @js_register_class_extends_error(i32)

declare void @js_register_class_extends_data_view(i32)

declare void @js_register_class_extends_typed_array(i32)

declare void @js_register_class_id(i32)

declare void @js_register_class_name(i32, ptr, i32)

declare void @js_register_class_source(i32, ptr, i32)

declare void @js_register_class_length(i32, i32)

declare void @js_register_anon_shape_class_id(i32)

declare double @js_get_global_this_builtin_value(ptr, i64)

declare double @js_promise_static_function_value(ptr, i64)

declare double @js_builtin_prototype_method_value(ptr, i64, ptr, i64)

declare void @js_register_class_parent(i32, i32)

declare void @js_register_class_generic_origin(i32, i32)

declare void @js_register_class_parent_dynamic(i32, double)

declare double @js_get_dynamic_parent_value(i32)

declare void @js_class_register_capture_values(i32, ptr, i64)

declare void @js_class_object_refresh_capture_values(double, i64, double)

declare void @js_tdz_suppress_begin()

declare void @js_tdz_suppress_end()

declare double @js_class_capture_value(i32, i32)

declare double @js_class_capture_value_for_receiver(double, i32, i32)

declare double @js_class_capture_value_or(i32, i32, double)

declare double @js_param_or_class_capture_value(double, i32, i32)

declare void @js_super_construct_apply(i32, double, double)

declare double @js_super_method_call_dynamic(i32, ptr, i64, double, ptr, i64)

declare double @js_super_method_call_dynamic_apply(i32, ptr, i64, double, double)

declare i64 @js_array_push_spread_any(i64, double)

declare i32 @js_set_function_prototype(double, double)

declare double @js_set_prototype_property(double, double, i32)

declare void @js_register_prototype_method(i32, ptr, i64, double)

declare i32 @js_register_function_prototype_method(double, ptr, i64, double)

declare double @js_new_function_construct(double, ptr, i64)

declare double @js_function_ctor_from_strings(ptr, i64)

declare double @js_new_function_construct_apply(double, double)

declare double @js_throw_not_a_constructor()

declare double @js_new_target_value()

declare double @js_get_function_prototype_method(double, ptr, i64)

declare double @js_function_prototype_value_for_read(double)

declare i64 @js_typeerror_new(i64)

declare i64 @js_rangeerror_new(i64)

declare i64 @js_syntaxerror_new(i64)

declare i64 @js_referenceerror_new(i64)

declare double @js_throw_symbol_constructor_type_error()

declare double @js_throw_bigint_constructor_type_error()

declare double @js_throw_strict_eval_arguments_syntax_error()

declare double @js_throw_eval_syntax_error(double)

declare double @js_throw_restricted_function_property_assignment()

declare double @js_throw_math_constructor_type_error()

declare double @js_throw_json_constructor_type_error()

declare double @js_webcrypto_illegal_constructor()

declare double @js_throw_type_error_const_assignment(double)

declare double @js_throw_reference_error_unresolvable_assignment(double)

declare double @js_throw_reference_error_unresolved_get()

declare double @js_with_implicit_unset()

declare double @js_with_implicit_read(double, double)

declare double @js_iterator_result_validate(double)

declare double @js_for_of_next(double)

declare double @js_segments_view_open(double, double)

declare double @js_segments_view_next(double)

declare double @js_segments_view_code_point_at(double, double)

declare double @js_segments_view_segment(double)

declare double @js_segments_view_regexp_test(double, double)

declare double @js_global_get_or_throw_unresolved(double)

declare double @js_module_ambient_require()

declare double @js_module_ambient_require_apply(double)

declare double @js_module_dynamic_import_fallback(double)

declare double @js_module_dynamic_import_deferred(double, double)

declare double @js_module_create_require_devirt(double)

declare double @js_global_get_optional(double)

declare double @js_global_update(double, double, double)

declare double @js_global_assign_existing_or_throw(double, double)

declare double @js_throw_reference_error_this_before_super()

declare double @js_throw_reference_error_super_delete()

declare double @js_throw_reference_error_unresolved_assignment()

declare i64 @js_evalerror_new(i64)

declare i64 @js_urierror_new(i64)

declare i64 @js_weakmap_new()

declare i64 @js_weakset_new()

declare double @js_weakmap_init_iterable(double, double)

declare double @js_weakset_init_iterable(double, double)

declare double @js_weakmap_set(double, double, double)

declare double @js_weakmap_get(double, double)

declare double @js_weakmap_has(double, double)

declare double @js_weakmap_delete(double, double)

declare double @js_weakset_add(double, double)

declare double @js_weakset_has(double, double)

declare double @js_weakset_delete(double, double)

declare double @js_weak_throw_primitive()

declare i64 @js_buffer_from_string(i64, i32)

declare i32 @js_encoding_tag_from_value(double)

declare i64 @js_value_to_string_with_encoding(double, i32)

declare i64 @js_value_to_string_with_encoding_or_radix(double, i32, double)

declare i64 @js_object_values(i64)

declare i64 @js_object_values_value(double)

declare i64 @js_object_entries(i64)

declare i64 @js_object_entries_value(double)

declare i64 @js_path_join(i64, i64)

declare i64 @js_path_win32_join(i64, i64)

declare i64 @js_path_win32_dirname(i64)

declare i64 @js_path_win32_basename(i64)

declare i64 @js_path_win32_basename_ext(i64, i64)

declare i64 @js_path_win32_extname(i64)

declare i32 @js_path_win32_is_absolute(i64)

declare i64 @js_path_win32_normalize(i64)

declare i64 @js_path_win32_parse(i64)

declare i64 @js_path_win32_format(double)

declare i64 @js_path_win32_relative(i64, i64)

declare i64 @js_path_win32_relative_checked(double, double)

declare i64 @js_path_win32_resolve(i64)

declare i64 @js_path_win32_resolve_join(i64, i64)

declare i64 @js_path_win32_to_namespaced_path(i64)

declare double @js_path_win32_to_namespaced_path_value(double)

declare i32 @js_path_win32_matches_glob(i64, i64)

declare i64 @js_path_win32_sep_get()

declare i64 @js_path_win32_delimiter_get()

declare i64 @js_path_dirname(i64)

declare i64 @js_path_resolve(i64)

declare i64 @js_path_relative(i64, i64)

declare i64 @js_path_relative_checked(double, double)

declare i64 @js_path_to_namespaced_path(i64)

declare double @js_path_to_namespaced_path_value(double)

declare i32 @js_path_matches_glob(i64, i64)

declare i64 @js_path_resolve_join(i64, i64)

declare i64 @js_path_arg_header(double)

declare i64 @js_path_join_value(double, double)

declare i64 @js_path_win32_join_value(double, double)

declare i64 @js_path_resolve_join_value(double, double)

declare i64 @js_path_win32_resolve_join_value(double, double)

declare i64 @js_path_basename_ext_value(double, double)

declare i64 @js_path_win32_basename_ext_value(double, double)

declare i32 @js_path_matches_glob_value(double, double)

declare i32 @js_path_win32_matches_glob_value(double, double)

declare double @js_object_from_entries(double)

declare i64 @js_string_match(i64, i64)

declare i64 @js_string_match_all(i64, i64)

declare i64 @js_string_match_all_value(i64, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log2.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log10.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.exp.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sin.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.cos.f64(double) #1

declare i64 @js_path_basename(i64)

declare i64 @js_path_basename_ext(i64, i64)

declare i64 @js_path_extname(i64)

declare i64 @js_path_sep_get()

declare i64 @js_path_delimiter_get()

declare i64 @js_path_parse(i64)

declare i64 @js_json_parse(i64)

declare double @js_array_index_own_number(double, i32, ptr, i64)

declare double @js_json_lazy_index_scalar(double, double, ptr, i64)

declare i64 @js_json_text_to_string(double)

declare double @js_json_raw_json(double)

declare double @js_json_is_raw_json(double)

declare i64 @js_json_parse_or_null(i64)

declare i64 @js_json_parse_typed_array(i64, i64, i32, i32)

declare i64 @js_date_to_date_string(double)

declare i64 @js_date_to_time_string(double)

declare i64 @js_date_to_utc_string(double)

declare i64 @js_date_to_locale_date_string(double)

declare i64 @js_date_to_locale_time_string(double)

declare i64 @js_date_to_json(double)

declare i64 @js_regexp_exec(i64, i64)

declare i64 @js_number_to_precision(double, double)

declare i64 @js_number_to_exponential(double, double)

declare double @js_date_new()

declare double @js_number_is_integer(double)

declare double @js_number_is_nan(double)

declare double @js_number_is_safe_integer(double)

declare double @js_date_parse(i64)

declare double @js_date_utc(ptr, i32)

declare double @js_date_new_local_components(double, double, double, double, double, double, double)

declare double @js_date_apply_setter(double, i32, i32, ptr, i32)

declare double @js_math_clz32(double)

declare double @js_math_cbrt(double)

declare double @js_math_fround(double)

declare double @js_math_f16round(double)

declare double @js_math_sinh(double)

declare double @js_math_cosh(double)

declare double @js_math_tanh(double)

declare double @js_math_asinh(double)

declare double @js_math_acosh(double)

declare double @js_math_atanh(double)

declare double @js_math_hypot(double, double)

declare double @js_object_is(double, double)

declare i64 @js_path_normalize(i64)

declare i64 @js_path_format(double)

declare i32 @js_path_is_absolute(i64)

declare i64 @js_encode_uri(double)

declare i64 @js_decode_uri(double)

declare i64 @js_encode_uri_component(double)

declare i64 @js_decode_uri_component(double)

declare i64 @js_text_encoder_new()

declare i64 @js_text_decoder_new(double, double, double)

declare i64 @js_text_encoder_encode_llvm(double)

declare i64 @js_text_decoder_decode_llvm(double, double)

declare i64 @js_text_decoder_encoding(double)

declare double @js_text_decoder_fatal(double)

declare double @js_text_decoder_ignore_bom(double)

declare void @js_queue_microtask(i64)

declare void @js_queue_next_tick(i64)

declare void @js_queue_next_tick_args(i64, ptr, i32)

declare void @js_drain_queued_microtasks()

declare i64 @js_uint8array_from_array(i64)

declare i64 @js_uint8array_alloc(i32)

declare i64 @js_uint8array_new(double)

declare i64 @js_uint8array_view(double, double, double)

declare i64 @js_typed_array_new_empty(i32, i32)

declare i64 @js_typed_array_new_from_array(i32, i64)

declare i64 @js_typed_array_new(i32, double)

declare i64 @js_typed_array_view(i32, double, double, double)

declare i32 @js_typed_array_length(i64)

declare double @js_typed_array_get(i64, i32)

declare i32 @js_typed_array_read_int32(i64, i32)

declare double @js_typed_array_read_f64(i64, i32)

declare double @js_u8_buffer_read_f64(i64, i32)

declare double @js_typed_array_index_get_dynamic(i64, double)

declare double @js_typed_array_at(i64, double)

declare void @js_typed_array_set(i64, i32, double)

declare double @js_typed_array_index_set_dynamic(i64, double, double)

declare i32 @js_uint8array_get(i64, i32)

declare double @js_uint8array_index_get_value(i64, i32)

declare void @js_uint8array_set(i64, i32, i32)

declare i64 @js_native_arena_alloc(i64)

declare i64 @js_native_arena_view(i64, i32, i64, i64)

declare i64 @js_native_pod_view(i64, i64, i64, i64, i64, i64)

declare double @js_native_pod_view_length(double)

declare ptr @js_native_abi_check_pod_view_data_ptr(double, i64)

declare i64 @js_native_abi_check_pod_view_record_count(double, i64)

declare void @js_native_arena_dispose(i64)

declare void @js_native_memory_fill_u32(i64, double)

declare void @js_native_memory_copy(i64, i64)

declare i64 @js_typed_array_to_reversed(i64)

declare i64 @js_typed_array_to_sorted_default(i64)

declare i64 @js_typed_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_typed_array_with(i64, double, double)

declare double @js_typed_array_find_last(i64, i64)

declare double @js_typed_array_find_last_index(i64, i64)

declare double @js_typed_array_set_from(i64, double, double)

declare i64 @js_typed_array_subarray(i64, i32, double, i32, double)

declare double @js_object_has_own(double, double)

declare double @js_object_property_is_enumerable(double, double)

declare double @js_object_define_getter(double, double, double)

declare double @js_object_define_setter(double, double, double)

declare double @js_object_lookup_getter(double, double)

declare double @js_object_lookup_setter(double, double)

declare double @js_object_get_own_field_or_undef(double, ptr, i64)

declare double @js_unresolved_namespace_stub()

declare double @js_node_submodule_export_as_function(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace_member(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace(ptr, i32)

declare void @js_node_submod_install_vm()

declare void @js_node_submod_install_timers()

declare void @js_node_submod_install_timers_promises()

declare void @js_node_submod_install_fs_promises()

declare void @js_node_submod_install_readline_promises()

declare void @js_node_submod_install_stream_promises()

declare void @js_node_submod_install_stream_consumers()

declare void @js_node_submod_install_stream_web()

declare void @js_node_submod_install_hono_jsx_server()

declare void @js_node_submod_install_hono_jsx_streaming()

declare void @js_node_submod_install_sys()

declare void @js_node_submod_install_diagnostics_channel()

declare void @js_node_submod_install_trace_events()

declare void @js_node_submod_install_test()

declare void @js_node_submod_install_test_reporters()

declare void @js_node_submod_install_all()

declare void @js_node_submod_enable_install_all()

declare double @js_unresolved_default_call()

declare double @js_get_global_this()

declare double @js_module_top_this()

declare double @js_global_or_console_property_by_name(i64)

declare void @js_class_register_static_symbol(i32, double, double)

declare void @js_register_class_computed_method(i64, double, i64, i64, i64, i64, i64)

declare void @js_register_class_computed_accessor(i64, double, i64, i64, i64, i64)

declare void @js_class_register_static_field(i32, ptr, i64, double, ptr)

declare double @js_object_define_property(double, double, double)

declare double @js_object_define_get_accessor(double, double, double)

declare double @js_object_get_own_property_descriptor(double, double)

declare double @js_object_get_own_property_descriptors(double)

declare double @js_object_get_own_property_names(double)

declare double @js_symbol_new(double)

declare double @js_symbol_new_empty()

declare double @js_symbol_for(double)

declare double @js_symbol_computed_member(double, double)

declare double @js_symbol_key_for(double)

declare double @js_symbol_description(double)

declare i64 @js_symbol_to_string(double)

declare i32 @js_symbol_equals(double, double)

declare i32 @js_is_symbol(double)

declare i64 @js_object_get_own_property_symbols(double)

declare double @js_object_set_symbol_property(double, double, double)

declare double @js_to_property_key(double)

declare double @js_object_set_property_key(double, double, double)

declare double @js_object_get_property_key(double, double)

declare double @js_object_set_property_key_method(double, double, double)

declare double @js_object_super_get(double, double, double)

declare double @js_object_super_put_value_set(double, double, double, double, i32)

declare double @js_object_super_call(double, double, double, ptr, i64)

declare double @js_object_literal_infer_computed_function_name(double, double)

declare double @js_object_get_symbol_property(double, double)

declare double @js_object_get_symbol_property_ic_miss(double, double, ptr)

declare double @js_object_get_symbol_then_field_ic_miss(double, double, ptr, i64, ptr, ptr)

declare double @js_object_create(double)

declare double @js_object_create_with_props(double, double)

declare double @js_object_freeze(double)

declare double @js_object_seal(double)

declare double @js_object_prevent_extensions(double)

declare void @js_object_copy_own_fields(i64, double)

declare double @js_object_assign_validate_target(double)

declare double @js_object_assign_one(double, double)

declare double @js_string_at(i64, i32)

declare double @js_string_code_point_at(i64, i32)

declare i64 @js_string_from_code_point(double)

declare i64 @js_string_raw(double, double)

declare i64 @js_string_from_char_code(double)

declare i64 @js_string_from_char_code_array(double)

declare double @js_string_char_code_at(i64, i32)

declare i32 @js_string_last_index_of(i64, i64)

declare i32 @js_string_last_index_of_from(i64, i64, double, i32)

declare double @js_string_locale_compare(i64, i64)

declare double @js_string_locale_compare_opts(i64, i64, double)

declare i64 @js_string_normalize(i64, double)

declare i64 @js_string_pad_start(i64, double, i64)

declare i64 @js_string_pad_end(i64, double, i64)

declare i64 @js_string_pad_fill(double)

declare double @js_string_is_well_formed(i64)

declare i64 @js_string_to_well_formed(i64)

declare i32 @js_string_search_regex(i64, i64)

declare i32 @js_string_search_value(i64, double)

declare i64 @js_string_match_value(i64, double)

declare double @js_regexp_exec_get_index()

declare i64 @js_regexp_exec_get_groups()

declare double @js_regexp_get_last_index(i64)

declare void @js_regexp_set_last_index(i64, double)

declare i64 @js_regexp_get_source(i64)

declare i64 @js_regexp_get_flags(i64)

declare i64 @js_string_replace_regex_named(i64, i64, i64)

declare i64 @js_string_replace_all_regex_named(i64, i64, i64)

declare i64 @js_string_replace_string_fn(i64, i64, double)

declare i64 @js_string_replace_string_dyn(i64, i64, double)

declare i64 @js_string_replace_all_string_dyn(i64, i64, double)

declare i64 @js_string_replace_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_all_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_string_fn(i64, i64, double)

declare i64 @js_string_replace_regex_fn(i64, i64, double)

declare i64 @js_string_replace_all_regex_fn(i64, i64, double)

declare double @js_structured_clone(double)

declare double @js_structured_clone_with_options(double, double)

declare double @js_generator_attach_prototype(double, i32)

declare double @js_generator_attach_closure_prototype(double, i64)

declare i64 @js_weakref_new(double)

declare double @js_weakref_deref(double)

declare i64 @js_finreg_new(double)

declare double @js_finreg_register(double, double, double, double)

declare double @js_finreg_unregister(double, double)

declare i64 @js_atob(double)

declare i64 @js_btoa(double)

declare double @js_object_is_frozen(double)

declare double @js_object_is_sealed(double)

declare double @js_object_is_extensible(double)

declare i64 @js_aggregateerror_new(i64, i64)

declare i64 @js_error_new_with_cause(i64, double)

declare i64 @js_aggregateerror_new_full(double, i64, double)

declare i64 @js_error_new_kind_with_options(i32, i64, double)

declare double @js_error_is_error(double)

declare i64 @js_error_get_errors(i64)

declare i64 @js_crypto_sha256(i64)

declare i64 @js_crypto_sha256_bytes(i64)

declare i64 @js_crypto_md5(i64)

declare i64 @js_crypto_hmac_sha256(i64, i64)

declare i64 @js_crypto_hmac_sha256_bytes(i64, i64)

declare void @js_runtime_validate_string_arg(double, ptr, i32)

declare void @js_set_call_location(ptr, i64, i32)

declare void @js_runtime_validate_crypto_key_arg(double, ptr, i32)

declare void @js_runtime_validate_integer_arg(double, ptr, i32, double, double)

declare i64 @js_crypto_pbkdf2_bytes(i64, i64, double, double, i64)

declare double @js_crypto_pbkdf2_async_alg(i64, i64, double, double, i64, double)

declare i64 @js_crypto_argon2_sync(i64, double)

declare double @js_crypto_argon2_async(i64, double, double)

declare i64 @js_crypto_encapsulate(double)

declare double @js_crypto_encapsulate_async(double, double)

declare i64 @js_crypto_decapsulate(double, double)

declare double @js_crypto_decapsulate_async(double, double, double)

declare i64 @js_crypto_hkdf_bytes_alg(i64, i64, i64, i64, double)

declare double @js_crypto_hkdf_async_alg(i64, i64, i64, i64, double, double)

declare i64 @js_crypto_scrypt_bytes(i64, i64, double, double)

declare double @js_crypto_scrypt_async(i64, i64, double, double, double)

declare i64 @js_crypto_sign_rsa_sha256(i64, i64, double)

declare double @js_crypto_sign_async(i64, i64, double, double)

declare double @js_crypto_verify_rsa_sha256(i64, i64, double, i64)

declare double @js_crypto_verify_async(i64, i64, double, i64, double)

declare i64 @js_crypto_public_encrypt(i64, i64)

declare i64 @js_crypto_private_decrypt(i64, i64)

declare i64 @js_crypto_private_encrypt(i64, i64)

declare i64 @js_crypto_public_decrypt(i64, i64)

declare i64 @js_crypto_create_public_key(i64)

declare i64 @js_crypto_create_private_key_value(double)

declare i64 @js_crypto_create_public_key_value(double)

declare i64 @js_crypto_generate_key_pair_sync_rsa(double)

declare i64 @js_crypto_generate_key_pair_sync_ec_p256(double)

declare i64 @js_crypto_generate_key_pair_sync_ed25519(double)

declare i64 @js_crypto_generate_key_pair_sync_x25519(double)

declare double @js_crypto_generate_key_pair_async(i64, double, double)

declare i64 @js_crypto_diffie_hellman(double)

declare double @js_crypto_get_cipher_info(double, double)

declare i64 @js_crypto_get_curves()

declare i64 @js_crypto_secure_heap_used()

declare i64 @js_crypto_random_bytes_buffer(double)

declare double @js_crypto_random_bytes_async(double, double)

declare i64 @js_crypto_random_uuid(double)

declare i64 @js_crypto_random_uuidv7()

declare double @js_crypto_random_int(double, double)

declare double @js_crypto_random_int_async(double, double, double)

declare double @js_crypto_timing_safe_equal(double, double)

declare i64 @js_crypto_get_hashes()

declare i64 @js_crypto_get_ciphers()

declare double @js_crypto_generate_prime_sync(double, double)

declare double @js_crypto_generate_prime_async(double, double, double)

declare double @js_crypto_check_prime_sync(double, double)

declare double @js_crypto_check_prime_async(double, double, double)

declare i64 @js_crypto_create_secret_key(i64, i64)

declare i64 @js_crypto_generate_key_sync(i64, double)

declare double @js_crypto_generate_key_async(i64, double, double)

declare i64 @js_webcrypto_digest(double, double)

declare i64 @js_webcrypto_import_key(double, double, double, double, double)

declare i64 @js_webcrypto_export_key(double, double)

declare i64 @js_webcrypto_sign(double, double, double)

declare i64 @js_webcrypto_verify(double, double, double, double)

declare i64 @js_webcrypto_derive_bits(double, double, double)

declare i64 @js_webcrypto_derive_key(double, double, double, double, double)

declare i64 @js_webcrypto_encrypt(double, double, double)

declare i64 @js_webcrypto_decrypt(double, double, double)

declare i64 @js_webcrypto_generate_key(double, double, double)

declare i64 @js_webcrypto_wrap_key(double, double, double, double)

declare i64 @js_webcrypto_unwrap_key(double, double, double, double, double, double, double)

declare i64 @js_zlib_create_brotli_decompress(double)

declare double @js_crypto_random_fill_sync(double, double, double)

declare double @js_crypto_random_fill_async(double, double, double, double)

declare double @js_crypto_create_hash(i64)

declare double @js_crypto_create_hash_options(i64, double)

declare double @js_crypto_x509_new(i64)

declare double @js_crypto_certificate_verify_spkac(double)

declare double @js_crypto_certificate_export_public_key(double)

declare double @js_crypto_certificate_export_challenge(double)

declare double @js_crypto_create_sign(i64)

declare double @js_crypto_create_verify(i64)

declare double @js_crypto_create_ecdh(i64)

declare double @js_crypto_create_diffie_hellman(double, double, double)

declare double @js_crypto_get_diffie_hellman(double)

declare double @js_crypto_ecdh_convert_key(double, double, double, double, double)

declare double @js_crypto_create_hmac(i64, i64)

declare i64 @js_buffer_alloc(i32, i32)

declare i64 @js_buffer_alloc_fill_value(i32, double, i32)

declare i64 @js_array_buffer_new(i32)

declare i64 @js_shared_array_buffer_new(i32)

declare i64 @js_array_buffer_new_value(double)

declare i64 @js_shared_array_buffer_new_value(double)

declare i64 @js_json_stringify_full(double, double, double)

declare i64 @js_json_parse_with_reviver(i64, i64)

declare double @js_array_find(i64, i64)

declare i32 @js_array_findIndex(i64, i64)

declare double @js_array_find_last(i64, i64)

declare i32 @js_array_find_last_index(i64, i64)

declare double @js_array_some(i64, i64)

declare double @js_array_some_captureless(i64, ptr)

declare double @js_array_every(i64, i64)

declare i32 @js_promise_state(i64)

declare double @js_promise_value(i64)

declare double @js_promise_reason(i64)

declare i32 @js_value_is_promise(double)

declare double @js_assimilate_thenable(double)

declare i32 @js_promise_run_microtasks()

declare i32 @js_promise_run_microtasks_event_loop()

declare i32 @js_promise_run_microtasks_await_loop()

declare i32 @js_await_loop_tick_timers()

declare void @js_mark_entry_module_esm()

declare i32 @js_promise_run_promise_jobs()

declare void @js_run_stdlib_pump()

declare void @js_sleep_ms(double)

declare void @js_wait_for_event()

declare i32 @js_event_loop_host_driven()

declare void @js_unsettled_top_level_await_exit()

declare void @js_throw(double)

declare void @js_eh_try_push()

declare i32 @perry_eh_personality(...)

declare void @js_try_end()

declare double @js_get_exception()

declare void @js_clear_exception()

declare i32 @js_has_exception()

declare void @js_enter_finally()

declare void @js_leave_finally()

declare double @js_await_any_promise(double)

declare i64 @js_promise_new()

declare i64 @js_promise_new_with_executor(i64)

declare i32 @js_timer_tick()

declare i32 @js_timer_tick_if_refed()

declare i32 @js_callback_timer_tick()

declare i32 @js_interval_timer_tick()

declare i32 @js_timer_has_pending()

declare i32 @js_callback_timer_has_pending()

declare i32 @js_interval_timer_has_pending()

declare i32 @js_stdlib_has_active_handles()

declare i32 @js_bun_ffi_has_active_threadsafe_callbacks()

declare i32 @js_microtasks_pending()

declare i64 @js_timer_validate_callback(double, i32)

declare i64 @js_set_timeout_callback(i64, double)

declare i64 @js_set_timeout_callback_args(i64, double, ptr, i32)

declare i64 @js_set_immediate_callback(i64)

declare i64 @js_set_immediate_callback_args(i64, ptr, i32)

declare i64 @setInterval(i64, double)

declare i64 @js_set_interval_callback_args(i64, double, ptr, i32)

declare void @clearTimeout(i64)

declare void @clearInterval(i64)

declare void @clearImmediate(i64)

declare void @js_clear_timeout_value(double)

declare void @js_clear_interval_value(double)

declare void @js_clear_immediate_value(double)

declare i64 @js_buffer_from_array(i64)

declare i64 @js_buffer_from_arraybuffer_slice(i64, i32, i32)

declare i32 @js_buffer_length(i64)

declare i32 @js_buffer_get(i64, i32)

declare double @js_buffer_index_get_value(i64, i32)

declare ptr @js_native_buffer_data_ptr(double)

declare i64 @js_native_buffer_byte_len(double)

declare void @js_console_time(i64)

declare void @js_console_time_end(i64)

declare void @js_console_time_log(i64)

declare void @js_console_time_value(double)

declare void @js_console_time_end_value(double)

declare void @js_console_time_log_value(double)

declare void @js_console_time_log_spread(double, i64)

declare void @js_console_count(i64)

declare void @js_console_count_reset(i64)

declare void @js_console_count_value(double)

declare void @js_console_count_reset_value(double)

declare double @js_console_new(double)

declare double @js_console_new2(double, double)

declare void @js_console_group_begin()

declare void @js_console_group_end()

declare void @js_console_clear()

declare void @js_console_noop()

declare double @js_native_call_method(double, ptr, i64, ptr, i64)

declare double @js_native_call_method_by_id(double, i64, ptr, i64)

declare double @js_native_call_method_apply(double, ptr, i64, i64)

declare double @js_native_call_method_apply_by_id(double, i64, i64)

declare double @js_native_call_method_str_key(double, i64, ptr, i64)

declare double @js_native_call_method_value(double, double, ptr, i64)

declare double @js_native_call_method_value_apply(double, double, i64)

declare void @js_promise_resolve(i64, double)

declare void @js_promise_reject(i64, double)

declare void @js_promise_mark_internally_handled(i64)

declare i64 @js_promise_resolved(double)

declare i64 @js_async_fn_result(double)

declare i64 @js_promise_rejected(double)

declare double @js_create_namespace(i32, ptr, ptr, ptr, ptr)

declare double @js_finalize_namespace(double)

declare i64 @js_promise_then(i64, i64, i64)

declare i64 @js_promise_resolved_then(double, i64, i64)

declare i64 @js_promise_finally(i64, i64)

declare double @js_promise_then_checked(double, double, double)

declare double @js_promise_catch_checked(double, double)

declare double @js_promise_finally_checked(double, double)

declare i64 @js_promise_closure_arg(double)

declare i64 @js_promise_all(i64)

declare i64 @js_promise_race(i64)

declare i64 @js_promise_any(i64)

declare i64 @js_promise_all_settled(i64)

declare i64 @js_promise_all_iterable(double)

declare i64 @js_promise_race_iterable(double)

declare i64 @js_promise_any_iterable(double)

declare i64 @js_promise_all_settled_iterable(double)

declare i64 @js_promise_with_resolvers()

declare i64 @js_promise_try(double, i64)

declare i64 @js_array_unshift_f64(i64, double)

declare i64 @js_array_unshift_variadic(i64, ptr, i32)

declare i64 @js_array_entries(i64)

declare i64 @js_array_keys(i64)

declare i64 @js_array_values(i64)

declare i64 @js_array_entries_iter_obj(i64)

declare i64 @js_array_keys_iter_obj(i64)

declare i64 @js_array_values_iter_obj(i64)

declare double @js_response_new(i64, double, i64, double)

declare double @js_fetch_unwrap_handle(double)

declare double @js_response_body_init_reset()

declare i64 @js_response_body_init_ptr(double)

declare double @js_headers_new()

declare double @js_headers_set(double, i64, i64)

declare double @js_headers_append(double, i64, i64)

declare i64 @js_headers_get(double, i64)

declare double @js_headers_get_set_cookie(double)

declare double @js_headers_has(double, i64)

declare double @js_headers_delete(double, i64)

declare double @js_headers_for_each(double, double)

declare double @js_headers_keys(double)

declare double @js_headers_values(double)

declare double @js_headers_entries(double)

declare double @js_headers_init_from_value(double, double)

declare double @js_headers_method_value(double, i64, i64)

declare double @js_request_new(i64, i64, i64, double, i64, i64, i64, i64, i64, i64, i64, double, i64, double)

declare double @js_request_new_from_init(i64, double)

declare i64 @js_request_get_url(double)

declare i64 @js_request_input_to_url(double)

declare i64 @js_request_get_method(double)

declare double @js_request_get_body(double)

declare double @js_request_body_used(double)

declare i64 @js_request_get_destination(double)

declare i64 @js_request_get_referrer(double)

declare i64 @js_request_get_referrer_policy(double)

declare i64 @js_request_get_mode(double)

declare i64 @js_request_get_credentials(double)

declare i64 @js_request_get_cache(double)

declare i64 @js_request_get_redirect(double)

declare i64 @js_request_get_integrity(double)

declare double @js_request_get_keepalive(double)

declare i64 @js_request_get_duplex(double)

declare double @js_request_get_signal(double)

declare double @js_request_get_headers(double)

declare i64 @js_request_text(double)

declare i64 @js_request_json(double)

declare i64 @js_request_array_buffer(double)

declare i64 @js_request_blob(double)

declare i64 @js_request_bytes(double)

declare i64 @js_request_form_data(double)

declare double @js_request_clone(double)

declare double @js_fetch_response_status(double)

declare i64 @js_fetch_response_status_text(double)

declare double @js_fetch_response_ok(double)

declare i64 @js_fetch_response_type(double)

declare i64 @js_fetch_response_url(double)

declare double @js_fetch_response_redirected(double)

declare double @js_response_body_used(double)

declare i64 @js_fetch_response_text(double)

declare i64 @js_fetch_response_json(double)

declare double @js_response_get_headers(double)

declare double @js_response_clone(double)

declare i64 @js_response_array_buffer(double)

declare i64 @js_response_blob(double)

declare i64 @js_response_bytes(double)

declare i64 @js_response_form_data(double)

declare double @js_form_data_new()

declare double @js_form_data_append(double, double, double, double)

declare double @js_form_data_set(double, double, double, double)

declare double @js_form_data_delete(double, i64)

declare double @js_form_data_get(double, i64)

declare double @js_form_data_get_all(double, i64)

declare double @js_form_data_has(double, i64)

declare double @js_form_data_entries(double)

declare double @js_form_data_keys(double)

declare double @js_form_data_values(double)

declare double @js_form_data_for_each(double, double)

declare double @js_blob_size(double)

declare i64 @js_blob_type(double)

declare i64 @js_blob_array_buffer(double)

declare i64 @js_blob_bytes(double)

declare i64 @js_blob_text(double)

declare double @js_blob_slice(double, double, double, i64)

declare double @js_blob_new(double, double)

declare double @js_file_new(double, double, double, double)

declare i64 @js_file_name(double)

declare double @js_file_last_modified(double)

declare i64 @js_url_create_object_url(double)

declare void @js_url_revoke_object_url(double)

declare double @js_buffer_resolve_object_url(double)

declare double @js_response_static_json(double, double, i64, double)

declare double @js_response_static_redirect(i64, double)

declare double @js_response_static_error()

declare double @js_blob_stream(double)

declare double @js_response_body(double)

declare double @js_readable_stream_new(double, double, double, double)

declare double @js_readable_stream_new_with_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_with_strategy_and_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_from_source_object(double, double)

declare double @js_readable_stream_get_reader(double)

declare double @js_readable_stream_get_reader_with_options(double, double)

declare double @js_readable_stream_get_byob_reader(double)

declare double @js_readable_stream_controller_byob_request(double)

declare double @js_readable_stream_from_iterable(double)

declare double @js_readable_stream_locked(double)

declare i64 @js_readable_stream_cancel(double, double)

declare double @js_readable_stream_tee(double)

declare i64 @js_readable_stream_pipe_to(double, double, double)

declare double @js_readable_stream_pipe_through(double, double, double)

declare double @js_readable_stream_pipe_through_validate(double, double, double, double)

declare double @js_readable_stream_controller_enqueue(double, double)

declare double @js_readable_stream_controller_close(double)

declare double @js_readable_stream_controller_error(double, double)

declare double @js_readable_stream_controller_desired_size(double)

declare i64 @js_reader_read(double)

declare i64 @js_reader_read_with_view(double, double)

declare double @js_reader_release_lock(double)

declare i64 @js_reader_closed(double)

declare i64 @js_reader_cancel(double, double)

declare double @js_writable_stream_new(double, double, double, double, double)

declare double @js_writable_stream_new_with_sink_type(double, double, double, double, double, double)

declare double @js_writable_stream_new_from_sink_object(double, double)

declare double @js_writable_stream_throw_invalid_sink()

declare double @js_writable_stream_get_writer(double)

declare double @js_writable_stream_locked(double)

declare i64 @js_writable_stream_close(double)

declare i64 @js_writable_stream_abort(double, double)

declare i64 @js_writer_write(double, double)

declare i64 @js_writer_close(double)

declare i64 @js_writer_abort(double, double)

declare double @js_writer_release_lock(double)

declare i64 @js_writer_closed(double)

declare i64 @js_writer_ready(double)

declare double @js_writer_desired_size(double)

declare double @js_transform_stream_new(double, double, double, double, double)

declare double @js_transform_stream_new_from_transformer_object(double, double, double)

declare double @js_transform_stream_readable(double)

declare double @js_transform_stream_writable(double)

declare double @js_text_encoding_stream_new()

declare double @js_text_encoder_stream_new()

declare double @js_text_decoder_stream_new()

declare double @js_stream_web_text_encoder_stream_new()

declare double @js_stream_web_text_decoder_stream_new(double, double)

declare double @js_stream_web_compression_stream_new(double)

declare double @js_stream_web_decompression_stream_new(double)

declare double @js_streams_strategy_high_water_mark(double)

declare double @js_count_queuing_strategy_new(double)

declare double @js_byte_length_queuing_strategy_new(double)

declare double @js_stream_unwrap_handle(double)

declare double @js_readable_stream_subclass_init(double, double, double, double, double)

declare double @js_writable_stream_subclass_init(double, double, double, double, double)

declare double @js_transform_stream_subclass_init(double, double, double, double)

declare double @js_request_subclass_init(double, double, double)

declare double @js_response_subclass_init(double, double, double)

declare double @js_fetch_or_value_super(double, double, ptr, i64)

declare double @js_builtin_subclass_construct(i32, ptr, i64, ptr, i64)

declare i64 @js_abort_controller_new()

declare i64 @js_abort_controller_signal(i64)

declare void @js_abort_controller_abort(i64)

declare void @js_abort_controller_abort_reason(i64, double)

declare void @js_abort_signal_add_listener(i64, double, double)

declare i64 @js_abort_signal_timeout(double)

declare i64 @js_abort_signal_abort(double)

declare i64 @js_abort_signal_any(i64)

declare double @js_abort_signal_throw_if_aborted(i64)

declare i64 @js_event_target_new()

declare i64 @js_event_new(double, double, i32)

declare double @js_event_subclass_init(double, double, double, i32, i32)

declare i64 @js_custom_event_new(double, double, i32)

declare i64 @js_dom_exception_new(double, double)

declare double @js_dom_exception_subclass_init(double, double, double)

declare void @js_event_target_add_event_listener(i64, i64, i64)

declare void @js_event_target_add_event_listener_with_options(i64, i64, i64, double)

declare void @js_event_target_remove_event_listener(i64, i64, i64)

declare void @js_event_target_remove_event_listener_with_options(i64, i64, i64, double)

declare double @js_event_target_dispatch_event(i64, double)

declare i32 @js_event_target_is_event_target(i64)

declare i64 @js_event_target_get_event_listeners(i64, i64)

declare double @js_event_target_get_max_listeners(i64)

declare i32 @js_event_target_set_max_listeners(i64, double)

declare double @js_message_channel_new()

declare double @js_message_port_constructor_error()

declare double @js_broadcast_channel_new(double)

declare i64 @js_array_alloc(i32)

declare i64 @js_tagged_template_register_raw(i64, i64)

declare i64 @js_tagged_template_get_or_init(i64, i64, i64)

declare i64 @js_template_raw(i64)

declare i64 @js_array_create()

declare i64 @js_array_constructor_single(double)

declare i64 @js_array_alloc_literal(i32)

declare i64 @js_array_from_values(ptr, i32)

declare double @js_value_from_const_descriptor(ptr, i32)

declare i64 @js_array_push_f64(i64, double)

declare i64 @js_array_push_u31_with_length(i64, i32, ptr)

declare i64 @js_array_push_f64_spec(i64, double)

declare void @js_array_push_guard(i64)

declare i64 @js_array_push_hole(i64)

declare i64 @js_array_numeric_push_f64_unboxed(i64, double)

declare i64 @js_array_push_spread_f64(i64, i64)

declare double @js_array_get_f64(i64, i32)

declare i32 @js_array_ensure_element_shape(i64)

declare double @js_array_get_index_or_string(i64, double)

declare double @js_array_numeric_get_f64_unboxed(i64, i32)

declare void @js_array_set_f64(i64, i32, double)

declare i32 @js_array_numeric_set_f64_unboxed(i64, i32, double)

declare i64 @js_array_set_f64_extend(i64, i32, double)

declare i64 @js_array_set_f64_extend_strict(i64, i32, double)

declare i64 @js_array_fill_f64_const_extend(i64, i32, double)

declare i64 @js_array_fill_f64_iota_extend(i64, i32)

declare i64 @js_array_fill_f64_const_len_extend(i64, double)

declare i64 @js_array_fill_f64_iota_len_extend(i64)

declare i64 @js_array_numeric_range_add(double, double, double, double)

declare i64 @js_array_numeric_range_add_len(double, double, double)

declare i64 @js_array_fill_range_strided_tagged(double, double, double, double, i64)

declare i64 @js_array_set_string_key(i64, i64, double)

declare i64 @js_array_set_index_or_string(i64, double, double)

declare i64 @js_array_mark_arguments_object(i64)

declare i32 @js_array_mark_numeric_f64_layout(i64)

declare i32 @js_array_is_numeric_f64_layout(i64)

declare void @js_array_clear_numeric_layout(i64)

; Function Attrs: nounwind willreturn
declare double @js_array_numeric_value_to_raw_f64(double) #0

declare double @js_array_refresh_local_head(double)

declare void @js_array_note_numeric_write(i64, i64)

declare void @js_array_declare_all_pointer_elements(i64)

declare i32 @js_array_length(i64)

declare double @js_array_is_array(double)

declare double @js_value_length_f64(double)

declare double @js_value_length_property_f64(double)

declare double @js_value_length_property_ic_f64(double, ptr)

declare nonnull ptr @js_shadow_frame_enter(i32)

declare i64 @js_shadow_frame_push(i32)

declare void @js_shadow_frame_pop(i64)

declare void @js_shadow_slot_set(i32, i64)

declare void @js_shadow_slot_bind(i32, ptr)

declare void @js_gc_write_barriers_emitted(i32)

declare i32 @js_gc_temp_root_push(i64)

declare i64 @js_gc_temp_root_get(i32)

declare void @js_gc_temp_root_set(i32, i64)

declare void @js_gc_temp_root_truncate(i32)

declare void @js_array_push_f64_temp_rooted(i32, double)

declare void @js_gc_loop_safepoint()

declare void @js_write_barrier(i64, i64)

declare void @js_write_barrier_slot(i64, i64, i64)

declare i64 @js_array_live_head(i64)

declare void @js_write_barrier_slot_validated_parent(i64, i64, i64)

declare void @js_write_barrier_root_nanbox(i64)

declare void @js_write_barrier_root_heap_word(i64)

declare void @js_gc_note_slot_layout(i64, i32, i64)

declare void @js_gc_note_slot_layout_aware(i64, i32, i64, i64)

declare void @js_gc_init_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_declare_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_forget_object_layout(i64)

declare double @js_array_pop_f64(i64)

declare i64 @js_array_join(i64, i64)

declare i64 @js_array_join_value(i64, double)

declare void @js_array_forEach(i64, i64)

declare i64 @js_array_fill(i64, double)

declare i64 @js_array_fill_range(i64, double, double, double)

declare double @js_array_fill_generic(double, double, i32, double, i32, double)

declare i32 @js_array_delete(i64, i32)

declare void @js_array_set_length(i64, double)

declare void @js_array_set_length_strict(i64, double)

declare i64 @js_array_clone(i64)

declare i32 @js_short_packed_spread_values(double, ptr)

declare i64 @js_spread_tail_fallback_args(ptr, i64, double)

declare i64 @js_array_from_value(double)

declare i64 @js_array_from_arraylike_holey_value(double)

declare double @js_iterator_from(double)

declare i64 @js_array_from_mapped(double, double, double)

declare i64 @js_array_concat_variadic(i64, ptr, i32)

declare double @js_arraylike_forEach(double, double, double)

declare double @js_arraylike_map(double, double, double)

declare double @js_arraylike_filter(double, double, double)

declare double @js_arraylike_some(double, double, double)

declare double @js_arraylike_every(double, double, double)

declare double @js_arraylike_find(double, double, double)

declare double @js_arraylike_findIndex(double, double, double)

declare double @js_arraylike_findLast(double, double, double)

declare double @js_arraylike_findLastIndex(double, double, double)

declare double @js_arraylike_reduce(double, double, i32, double)

declare double @js_arraylike_reduceRight(double, double, i32, double)

declare double @js_arraylike_indexOf(double, double, double, i32)

declare double @js_arraylike_lastIndexOf(double, double, double, i32)

declare double @js_arraylike_includes(double, double, double, i32)

declare double @js_arraylike_at(double, double)

declare double @js_arraylike_join(double, double)

declare double @js_arraylike_flat(double, double)

declare double @js_arraylike_slice(double, double, i32, double, i32)

declare double @js_arraylike_sort(double, double)

declare double @js_arraylike_splice(double, ptr, i32)

declare double @js_arraylike_concat(double, ptr, i32)

declare double @js_arraylike_pop(double)

declare double @js_arraylike_shift(double)

declare double @js_arraylike_push(double, ptr, i32)

declare double @js_arraylike_unshift(double, ptr, i32)

declare i64 @js_array_clone_for_spread(double)

declare i64 @js_array_spread_append(i64, double)

declare i64 @js_iterator_to_array(double)

declare double @js_iterator_next_result(double)

declare double @js_iterator_close_if_not_done(double, double)

declare double @js_iterator_rest_to_array(double, double)

declare double @js_get_iterator(double)

declare double @js_get_async_iterator(double)

declare double @js_for_of_to_array(double)

declare i64 @js_object_alloc(i32, i32)

declare double @js_object_coerce(double)

declare void @js_object_mark_class(i64)

declare void @js_class_object_pin_parent(i64, i32)

declare i64 @js_object_alloc_with_shape(i32, i32, ptr, i32)

declare void @js_object_set_field(i64, i32, i64)

declare i64 @js_object_get_field(i64, i32)

declare void @js_object_set_field_by_name(i64, i64, double)

declare void @js_object_set_field_by_property_id(i64, i64, double)

declare void @js_object_set_field_by_name_nonenum(i64, i64, double)

declare void @js_error_subclass_default_init(double, double)

declare void @js_object_set_field_by_name_nonconfigurable(i64, i64, double)

declare void @js_error_apply_cause_to_object(i64, double)

declare void @js_error_subclass_capture_stack(double)

declare i32 @js_with_has_binding(double, i64)

declare double @js_with_get_binding(double, i64)

declare double @js_with_set_binding(double, i64, double, i32)

declare i32 @js_with_delete_binding(double, i64)

declare i32 @js_pod_scalar_write_compatible(double, i32)

declare void @js_typed_feedback_register_site(i64, i32, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64)

declare void @js_typed_feedback_record_guard_pass(i64)

declare void @js_typed_feedback_record_guard_fail(i64)

declare void @js_typed_feedback_record_fallback_call(i64)

declare void @js_typed_feedback_observe_property_get(i64, i64, i64)

declare void @js_typed_feedback_observe_property_set(i64, i64, i64)

declare double @js_typed_feedback_object_get_field_by_name_f64(i64, i64, i64)

declare void @js_typed_feedback_object_set_field_by_name(i64, i64, i64, double)

declare void @js_typed_feedback_object_set_field_by_name_fast(i64, i64, i64, double)

declare i32 @js_typed_feedback_class_field_set_guard(i64, double, i32, i32, i64, i32, double, i32)

declare void @js_class_field_set_fallback(i64, i64, i64, double)

declare void @js_class_field_set_ic(i64, double, i32, i32, i64, i32, double, i32)

declare i32 @js_typed_feedback_class_field_get_guard(i64, double, i32, i32, i64, i32, i32)

declare double @js_class_field_get_ic(i64, double, i32, i32, i64, i32, i32)

declare double @js_typed_feedback_native_call_method(i64, double, ptr, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_by_id(i64, double, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_apply(i64, double, ptr, i64, i64)

declare double @js_typed_feedback_native_call_method_apply_by_id(i64, double, i64, i64)

declare i32 @js_typed_feedback_method_direct_call_guard(i64, double, i32, i32, ptr, i64, ptr)

declare i32 @js_method_direct_shape_guard(double, i32, i32, i32)

declare i32 @js_method_direct_shape_class(double, ptr, i32)

declare i32 @js_typed_feedback_closure_direct_call_guard(i64, double, ptr, i32, i32)

declare i64 @js_closure_exact_func_guard(double, ptr)

declare i64 @js_object_own_method_cache_miss(double, i32, i32, ptr, i64, ptr, ptr)

declare void @js_typed_feedback_object_set_unboxed_f64_field(i64, i64, i32, i64, double)

declare double @js_typed_feedback_observe_helper_return(i64, double)

declare void @js_object_set_index_polymorphic(i64, double, double)

declare double @js_object_get_index_polymorphic(i64, double)

declare double @js_object_get_field_by_name_f64(i64, i64)

declare double @js_object_get_field_by_name_boxed(double, i64)

declare double @js_object_get_field_by_property_id_f64(i64, i64)

declare double @js_native_module_property_by_name(ptr, i64, ptr, i64)

declare double @js_native_module_esm_export_value(double, double)

declare double @js_native_module_named_esm_export_value(double, double)

declare double @js_create_native_module_namespace(ptr, i64)

declare void @js_nm_install_assert()

declare void @js_nm_install_async_hooks()

declare void @js_nm_install_bigint()

declare void @js_nm_install_buffer()

declare void @js_bun_tcp_nm_install()

declare void @js_nm_install_bun()

declare void @js_nm_install_bun_ffi()

declare void @js_nm_install_child_process()

declare void @js_nm_install_cluster()

declare void @js_nm_install_console()

declare void @js_nm_install_crypto()

declare void @js_nm_install_dgram()

declare void @js_nm_install_dns()

declare void @js_nm_install_domain()

declare void @js_nm_install_events()

declare void @js_nm_install_fs()

declare void @js_nm_install_http()

declare void @js_nm_install_inspector()

declare void @js_nm_install_module()

declare void @js_nm_install_net()

declare void @js_nm_install_node_pty()

declare void @js_nm_install_os()

declare void @js_nm_install_path()

declare void @js_nm_install_perf()

declare void @js_nm_install_process()

declare void @js_nm_install_punycode()

declare void @js_nm_install_querystring()

declare void @js_nm_install_readline()

declare void @js_nm_install_repl()

declare void @js_nm_install_sea()

declare void @js_nm_install_sqlite()

declare void @js_nm_install_stream()

declare void @js_nm_install_timers()

declare void @js_nm_install_tls()

declare void @js_nm_install_tty()

declare void @js_nm_install_url()

declare void @js_nm_install_util()

declare void @js_nm_install_v8()

declare void @js_nm_install_vm()

declare void @js_nm_install_wasi()

declare void @js_nm_install_zlib()

declare void @js_nm_install_all()

declare double @js_object_get_field_ic_miss(i64, i64, ptr)

declare double @js_object_get_field_ic(i64, i64, i64, ptr)

declare i64 @js_object_rest(i64, i64)

declare double @js_require_object_coercible(double)

declare double @js_require_json_disk(double)

declare double @js_require_resolve_node_modules(double, double)

declare void @js_globalthis_seed_async_local_storage()

declare void @js_register_path_module_partial(double, double)

declare void @js_register_path_module(double, double)

declare void @js_link_path_module_parent(double)

declare void @js_run_module_init_catching(i64)

declare double @js_require_path_module(double)

declare double @js_has_path_module(double)

declare void @js_register_path_init(ptr, i64, i64)

declare i64 @js_array_alloc_with_length(i32)

declare void @js_array_set_f64_unchecked(i64, i32, double)

declare double @js_typed_feedback_array_get_f64(i64, i64, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_get_guard(i64, double, i32, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_get_guard(i64, double, i32, i32) #0

declare i32 @js_typed_feedback_packed_f64_array_loop_guard(i64, double)

declare i32 @js_string_array_range_loop_guard(double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense_i32(i64, double, i32, i32)

declare i32 @js_typed_feedback_masked_window_ta_kind(i64, double, i32, i32)

declare i64 @js_typed_array_masked_window_data_ptr(double)

declare i64 @js_packed_ecs_u32_loop_guard(double, double, double, double, double, double, i32, ptr)

declare i32 @js_typed_feedback_packed_u32_array_loop_guard(i64, double)

declare double @js_typed_feedback_array_index_get_fallback_boxed(i64, double, double)

declare void @js_typed_feedback_array_set_f64(i64, i64, i32, double)

declare i64 @js_typed_feedback_array_set_f64_extend(i64, i64, i32, double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_push_guard(i64, double, double) #0

declare double @js_typed_feedback_array_index_set_fallback_boxed(i64, double, double, double, i32)

declare void @js_typed_feedback_observe_array_element(i64, i64, i32)

declare i64 @js_typed_feedback_array_set_string_key(i64, i64, i64, double)

declare i64 @js_typed_feedback_array_set_index_or_string(i64, i64, double, double, i32)

declare void @js_typed_feedback_object_set_index_polymorphic(i64, i64, double, double)

declare double @js_proxy_new(double, double)

declare double @js_proxy_revocable(double, double)

declare void @js_proxy_revoke(double)

declare i32 @js_proxy_is_revoked(double)

declare i32 @js_proxy_is_proxy(double)

declare double @js_proxy_target(double)

declare double @js_proxy_get(double, double)

declare double @js_proxy_set(double, double, double)

declare double @js_proxy_has(double, double)

declare double @js_proxy_delete(double, double)

declare double @js_proxy_apply(double, double, double)

declare double @js_proxy_construct(double, double, double)

declare double @js_reflect_construct(double, double, double)

declare double @js_reflect_get(double, double, double)

declare double @js_reflect_set(double, double, double, double)

declare double @js_put_value_set(double, double, double, double, i32)

declare i32 @js_transition_ic_spill_append(double, i64, i32, double)

declare ptr @perry_transition_cache_base()

declare void @js_transition_ic_note_hit()

declare double @js_put_value_set_dyn_ic(ptr, double, double, double, i32)

declare double @js_put_value_set_ic_miss(double, i64, double, i32, ptr, i32)

declare i32 @js_put_value_set_ic_overflow_store(double, i64, i32, double)

declare double @js_object_get_field_ic_overflow_load(i64, i64, i32, ptr)

declare double @js_put_value_set_ic_poly_tail(ptr, double, i64, double, i32)

declare i64 @js_object_array_numeric_write_guard(double, double, double, double, double, i32, i32)

declare i64 @js_object_array_numeric_write_range_guard(double, double, double, double, double, i32, i32, i32)

declare double @js_super_put_value_set(i32, double, double, double, i32)

declare double @js_super_accessor_get(i32, double, double)

declare double @js_reflect_has(double, double)

declare double @js_reflect_delete(double, double)

declare double @js_reflect_own_keys(double)

declare double @js_reflect_apply(double, double, double)

declare double @js_reflect_define_property(double, double, double)

declare double @js_reflect_get_own_property_descriptor(double, double)

declare double @js_reflect_get_prototype_of(double)

declare double @js_reflect_set_prototype_of(double, double)

declare double @js_reflect_is_extensible(double)

declare double @js_reflect_prevent_extensions(double)

declare double @js_reflect_define_metadata(double, double, double, double)

declare double @js_reflect_get_metadata(double, double, double)

declare double @js_reflect_get_own_metadata(double, double, double)

declare double @js_reflect_has_metadata(double, double, double)

declare double @js_reflect_has_own_metadata(double, double, double)

declare double @js_reflect_get_metadata_keys(double, double)

declare double @js_reflect_get_own_metadata_keys(double, double)

declare double @js_reflect_delete_metadata(double, double, double)

declare double @js_http_server_construct_with_this(double, double, double)

declare double @js_https_server_construct_with_this(double, double, double)

declare i64 @js_net_socket_set_encoding(i64, i64)

declare double @js_vm_create_context(double, double)

declare double @js_vm_create_script_branded(double, double)

declare double @js_vm_module_call()

declare double @js_vm_module_constructor_error()

declare double @js_repl_start(double)

declare double @js_repl_repl_server_new(double)

declare double @js_repl_recoverable_new(double)

declare double @js_worker_threads_worker_new(i64, double)

declare double @js_worker_threads_worker_post_message(i64, double)

declare double @js_worker_threads_worker_on(i64, double, i64)

declare double @js_worker_threads_worker_once(i64, double, i64)

declare double @js_worker_threads_worker_off(i64, double, i64)

declare double @js_worker_threads_worker_add_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_remove_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_terminate(i64)

declare double @js_worker_threads_worker_ref(i64)

declare double @js_worker_threads_worker_unref(i64)

declare double @js_worker_threads_worker_get_heap_statistics(i64)

declare double @js_worker_threads_worker_cpu_usage(i64, double)

declare double @js_worker_threads_worker_get_heap_snapshot(i64, double)

declare double @js_worker_threads_worker_start_cpu_profile(i64)

declare double @js_worker_threads_worker_start_heap_profile(i64)

declare i64 @js_http_client_request_end(i64, double)

declare i64 @js_http_client_request_write(i64, double)

declare i64 @js_http_client_request_end_full(i64, double, i64, i64)

declare double @js_http_client_request_write_full(i64, double, i64, i64)

declare i64 @js_http_set_timeout_full(i64, double, i64)

declare i64 @js_http_client_request_method(i64)

declare i64 @js_http_client_request_protocol(i64)

declare i64 @js_http_client_request_host(i64)

declare i64 @js_http_client_request_path(i64)

declare double @js_http_client_request_listener_count(i64, i64)

declare double @js_http_client_request_get_header(i64, i64)

declare double @js_http_client_request_has_header(i64, i64)

declare double @js_http_client_request_remove_header(i64, i64)

declare double @js_http_client_request_get_header_names(i64)

declare double @js_http_client_request_get_headers(i64)

declare double @js_http_client_request_get_raw_header_names(i64)

declare double @js_http_client_request_abort(i64)

declare i64 @js_http_client_request_destroy(i64, double)

declare double @js_http_client_request_noop_undefined(i64, double, double)

declare double @js_http_client_request_aborted(i64)

declare double @js_http_client_request_destroyed(i64)

declare double @js_http_client_request_finished(i64)

declare double @js_http_client_request_reused_socket(i64)

declare double @js_http_client_request_max_headers_count(i64)

declare double @js_http_client_request_writable_ended(i64)

declare double @js_http_client_request_writable_finished(i64)

declare double @js_http_client_request_socket(i64)

declare i64 @js_http_get(double, i64)

declare i64 @js_http_get_overload(i64)

declare i64 @js_http_request_overload(i64)

declare i64 @js_https_get_overload(i64)

declare i64 @js_https_request_overload(i64)

declare i64 @js_http_on(i64, i64, i64)

declare i64 @js_http_once(i64, i64, i64)

declare i64 @js_http_request(double, i64)

declare i64 @js_http_request_body(i64)

declare double @js_http_request_body_length(i64)

declare i64 @js_http_request_content_type(i64)

declare double @js_http_request_has_header(i64, i64)

declare i64 @js_http_request_header(i64, i64)

declare i64 @js_http_request_headers_all(i64)

declare double @js_http_request_id(i64)

declare double @js_http_request_is_method(i64, i64)

declare i64 @js_http_request_method(i64)

declare i64 @js_http_request_path(i64)

declare i64 @js_http_request_query(i64)

declare i64 @js_http_request_query_all(i64)

declare i64 @js_http_request_query_param(i64, i64)

declare double @js_http_respond_error(i64, double, i64)

declare double @js_http_respond_html(i64, double, i64)

declare double @js_http_respond_json(i64, double, i64)

declare double @js_http_respond_not_found(i64)

declare double @js_http_respond_redirect(i64, i64, double)

declare i64 @js_http_respond_status_text(double)

declare double @js_http_respond_text(i64, double, i64)

declare double @js_http_respond_with_headers(i64, double, i64, i64)

declare double @js_http_response_headers(i64)

declare double @js_http_response_trailers(i64)

declare double @js_http_incoming_message_socket(i64)

declare double @js_http_incoming_message_req(i64)

declare i64 @js_http_incoming_message_set_encoding(i64, i64)

declare i64 @js_http_server_accept_v2(i64)

declare double @js_http_server_close(i64)

declare i64 @js_http_server_create(double)

declare i64 @js_http_set_header(i64, i64, i64)

declare i64 @js_http_set_timeout(i64, double)

declare double @js_http_status_code(i64)

declare i64 @js_http_status_message(i64)

declare i64 @js_http_agent_new(double)

declare i64 @js_https_agent_new(double)

declare i64 @js_http_agent_get_name(i64, double)

declare i64 @js_http_agent_noop_self(i64)

declare double @js_http_agent_max_sockets(i64)

declare double @js_http_agent_max_free_sockets(i64)

declare double @js_http_agent_max_total_sockets(i64)

declare double @js_http_agent_keep_alive_msecs(i64)

declare double @js_http_agent_keep_alive(i64)

declare i64 @js_http_agent_protocol(i64)

declare double @js_http_agent_default_port(i64)

declare void @js_http_agent_set_protocol(i64, i64)

declare i64 @js_http_agent_destroy(i64)

declare double @js_http_agent_destroyed(i64)

declare double @js_http_agent_sockets(i64)

declare double @js_http_agent_free_sockets(i64)

declare double @js_http_agent_requests(i64)

declare void @js_http_agent_set_max_sockets(i64, double)

declare void @js_http_agent_set_max_free_sockets(i64, double)

declare void @js_http_agent_set_max_total_sockets(i64, double)

declare void @js_http_agent_set_keep_alive(i64, double)

declare void @js_http_agent_set_keep_alive_msecs(i64, double)

declare void @js_http_agent_set_create_connection(i64, i64)

declare void @js_http_agent_set_create_socket(i64, i64)

declare i64 @js_http_agent_create_connection(i64)

declare i64 @js_http_agent_create_socket(i64)

declare i64 @js_https_get(double, i64)

declare i64 @js_https_request(double, i64)

declare i64 @js_node_http_create_server(i64)

declare i64 @js_node_http_server_listen(i64, i64)

declare void @js_node_http_server_close(i64, i64)

declare void @js_node_http_server_close_all_connections(i64)

declare void @js_node_http_server_close_idle_connections(i64)

declare i64 @js_node_http_server_address_json(i64)

declare i32 @js_node_http_server_listening(i64)

declare double @js_node_http_server_listening_value(i64)

declare double @js_node_http_server_on(i64, i64, i64)

declare i64 @js_node_http_im_method(i64)

declare i64 @js_node_http_im_url(i64)

declare i64 @js_node_http_im_http_version(i64)

declare i64 @js_node_http_im_headers_json(i64)

declare i64 @js_node_http_im_raw_headers_json(i64)

declare i64 @js_node_http_im_headers_distinct_json(i64)

declare i64 @js_node_http_im_trailers_json(i64)

declare i64 @js_node_http_im_raw_trailers_json(i64)

declare i64 @js_node_http_im_trailers_distinct_json(i64)

declare i32 @js_node_http_im_complete(i64)

declare i32 @js_node_http_im_aborted(i64)

declare i32 @js_node_http_im_destroyed(i64)

declare i64 @js_node_http_im_remote_address(i64)

declare double @js_node_http_im_remote_port(i64)

declare void @js_node_http_im_pause(i64)

declare void @js_node_http_im_resume(i64)

declare void @js_node_http_im_destroy(i64)

declare double @js_node_http_im_on(i64, i64, i64)

declare double @js_node_http_im_once(i64, i64, i64)

declare double @js_node_http_im_read(i64)

declare i64 @js_node_http_im_set_timeout(i64, double, i64)

declare void @js_node_http_res_set_status(i64, double)

declare double @js_node_http_res_get_status(i64)

declare void @js_node_http_res_set_status_message(i64, i64)

declare void @js_node_http_res_set_header(i64, i64, double)

declare i64 @js_node_http_res_set_header_self(i64, i64, double)

declare double @js_node_http_res_get_header(i64, i64)

declare void @js_node_http_res_remove_header(i64, i64)

declare i32 @js_node_http_res_has_header(i64, i64)

declare double @js_node_http_res_has_header_value(i64, i64)

declare i64 @js_node_http_res_get_headers_json(i64)

declare i64 @js_node_http_res_get_header_names_json(i64)

declare i64 @js_node_http_res_append_header(i64, i64, i64)

declare i64 @js_node_http_res_set_headers(i64, double)

declare double @js_node_http_res_get_status_message(i64)

declare i32 @js_node_http_res_headers_sent(i64)

declare i32 @js_node_http_res_writable_ended(i64)

declare i32 @js_node_http_res_writable_finished(i64)

declare i32 @js_node_http_res_finished(i64)

declare i32 @js_node_http_res_send_date(i64)

declare void @js_node_http_res_set_send_date(i64, double)

declare i32 @js_node_http_res_strict_content_length(i64)

declare void @js_node_http_res_set_strict_content_length(i64, double)

declare i64 @js_node_http_res_req_handle(i64)

declare void @js_node_http_res_write_head(i64, double, i64, i64)

declare i32 @js_node_http_res_write(i64, double)

declare double @js_node_http_res_write_full(i64, double, i64, i64)

declare void @js_node_http_res_add_trailers(i64, double)

declare void @js_node_http_res_end(i64, double)

declare void @js_node_http_res_end_full(i64, double, i64, i64)

declare void @js_node_http_res_flush_headers(i64)

declare void @js_node_http_res_cork(i64)

declare void @js_node_http_res_uncork(i64)

declare i64 @js_node_http_res_set_timeout(i64, double, i64)

declare void @js_node_http_res_write_early_hints(i64, double, i64)

declare void @js_node_http_res_write_continue(i64)

declare void @js_node_http_res_write_processing(i64)

declare double @js_node_http_res_on(i64, i64, i64)

declare i64 @js_node_https_create_server(double, i64)

declare i64 @js_node_https_server_listen(i64, i64)

declare void @js_node_https_server_close(i64, i64)

declare void @js_node_https_server_close_all_connections(i64)

declare void @js_node_https_server_close_idle_connections(i64)

declare i64 @js_node_https_server_address_json(i64)

declare double @js_node_https_server_on(i64, i64, i64)

declare double @js_node_https_server_listening_value(i64)

declare double @js_node_https_server_headers_timeout(i64)

declare double @js_node_https_server_set_headers_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout(i64)

declare double @js_node_https_server_set_keep_alive_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout_buffer(i64)

declare double @js_node_https_server_set_keep_alive_timeout_buffer(i64, double)

declare double @js_node_https_server_request_timeout(i64)

declare double @js_node_https_server_set_request_timeout(i64, double)

declare double @js_node_https_server_idle_timeout(i64)

declare double @js_node_https_server_set_idle_timeout(i64, double)

declare double @js_node_https_server_max_headers_count(i64)

declare double @js_node_https_server_set_max_headers_count(i64, double)

declare double @js_node_https_server_max_requests_per_socket(i64)

declare double @js_node_https_server_set_max_requests_per_socket(i64, double)

declare i64 @js_node_https_server_set_timeout_method(i64, double, i64)

declare i64 @js_node_http2_create_server(double, double)

declare i64 @js_node_http2_create_secure_server(double, i64)

declare i64 @js_node_http2_connect(double, double, i64)

declare i64 @js_node_http2_server_listen(i64, i64)

declare void @js_node_http2_server_close(i64, i64)

declare i64 @js_node_http2_server_address_json(i64)

declare double @js_node_http2_server_on(i64, i64, i64)

declare i64 @js_node_http2_get_default_settings()

declare i64 @js_node_http2_get_packed_settings(i64)

declare i64 @js_node_http2_get_unpacked_settings(i64)

declare i64 @js_pg_client_connect(i64)

declare i64 @js_pg_client_end(i64)

declare i64 @js_pg_client_new(i64)

declare i64 @js_pg_client_query(i64, i64)

declare i64 @js_pg_client_query_params(i64, i64, i64)

declare i64 @js_pg_connect(i64)

declare i64 @js_pg_create_pool(i64)

declare i64 @js_pg_pool_end(i64)

declare i64 @js_pg_pool_new(i64)

declare i64 @js_pg_pool_query(i64, i64)

declare i64 @js_ioredis_connect(i64)

declare i64 @js_ioredis_decr(i64, i64)

declare i64 @js_ioredis_del(i64, i64)

declare void @js_ioredis_disconnect(i64)

declare i64 @js_ioredis_exists(i64, i64)

declare i64 @js_ioredis_expire(i64, i64, double)

declare i64 @js_ioredis_get(i64, i64)

declare i64 @js_ioredis_hdel(i64, i64, i64)

declare i64 @js_ioredis_hget(i64, i64, i64)

declare i64 @js_ioredis_hgetall(i64, i64)

declare i64 @js_ioredis_hlen(i64, i64)

declare i64 @js_ioredis_hset(i64, i64, i64, i64)

declare i64 @js_ioredis_incr(i64, i64)

declare i64 @js_ioredis_new(i64)

declare i64 @js_ioredis_ping(i64)

declare i64 @js_ioredis_quit(i64)

declare i64 @js_ioredis_set(i64, i64, i64)

declare i64 @js_ioredis_setex(i64, i64, double, i64)

declare i64 @js_mongodb_client_close(i64)

declare i64 @js_mongodb_client_connect(i64)

declare i64 @js_mongodb_client_db(i64, i64)

declare i64 @js_mongodb_client_list_databases(i64)

declare i64 @js_mongodb_client_new(i64)

declare i64 @js_mongodb_collection_count_value(i64, double)

declare i64 @js_mongodb_collection_delete_many_value(i64, double)

declare i64 @js_mongodb_collection_delete_one_value(i64, double)

declare i64 @js_mongodb_collection_find_one_value(i64, double)

declare i64 @js_mongodb_collection_find_value(i64, double)

declare i64 @js_mongodb_collection_insert_many_value(i64, double)

declare i64 @js_mongodb_collection_insert_one_value(i64, double)

declare i64 @js_mongodb_collection_update_many_value(i64, double, double)

declare i64 @js_mongodb_collection_update_one_value(i64, double, double)

declare i64 @js_mongodb_collection_count(i64, i64)

declare i64 @js_mongodb_collection_delete_many(i64, i64)

declare i64 @js_mongodb_collection_delete_one(i64, i64)

declare i64 @js_mongodb_collection_find(i64, i64)

declare i64 @js_mongodb_collection_find_one(i64, i64)

declare i64 @js_mongodb_collection_insert_many(i64, i64)

declare i64 @js_mongodb_collection_insert_one(i64, i64)

declare i64 @js_mongodb_collection_update_many(i64, i64, i64)

declare i64 @js_mongodb_collection_update_one(i64, i64, i64)

declare i64 @js_mongodb_connect(i64)

declare i64 @js_mongodb_db_collection(i64, i64)

declare i64 @js_mongodb_db_list_collections(i64)

declare void @js_sqlite_close(i64)

declare void @js_sqlite_exec(i64, i64)

declare i64 @js_sqlite_open(i64)

declare i64 @js_sqlite_pragma(i64, i64, i64)

declare i64 @js_sqlite_prepare(i64, i64)

declare i64 @js_sqlite_stmt_all(i64, i64)

declare i64 @js_sqlite_stmt_columns(i64)

declare i64 @js_sqlite_stmt_get(i64, i64)

declare i64 @js_sqlite_stmt_run(i64, i64)

declare i64 @js_sqlite_transaction(i64, i64)

declare void @js_sqlite_transaction_commit(i64)

declare void @js_sqlite_transaction_rollback(i64)

declare i64 @js_bun_sqlite_database_call(double, double)

declare i64 @js_bun_sqlite_database_new(double, double)

declare i64 @js_bun_sqlite_database_query(i64, double)

declare i64 @js_bun_sqlite_database_run(i64, double, i64)

declare i64 @js_bun_sqlite_database_filename(i64)

declare i64 @js_bun_sqlite_database_transaction(i64, double)

declare i64 @js_bun_sqlite_statement_values(i64, i64)

declare double @js_bun_sqlite_statement_safe_integers(i64, double)

declare void @js_bun_sqlite_statement_finalize(i64)

declare i64 @js_node_sqlite_backup(double, double, double)

declare i64 @js_node_sqlite_database_sync_call(double, double)

declare i64 @js_node_sqlite_database_sync_new(double, double)

declare i32 @js_node_sqlite_database_sync_open(i64)

declare i32 @js_node_sqlite_database_sync_close(i64)

declare i32 @js_node_sqlite_database_sync_dispose(i64)

declare i32 @js_node_sqlite_database_sync_exec(i64, double)

declare i64 @js_node_sqlite_database_sync_prepare(i64, double, double)

declare i32 @js_node_sqlite_database_sync_function(i64, double, double, double)

declare i32 @js_node_sqlite_database_sync_aggregate(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_defensive(i64, double)

declare i32 @js_node_sqlite_database_sync_set_authorizer(i64, double)

declare i64 @js_node_sqlite_database_sync_create_tag_store(i64, double)

declare i64 @js_node_sqlite_database_sync_create_session(i64, double)

declare double @js_node_sqlite_database_sync_apply_changeset(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_load_extension(i64, double)

declare i32 @js_node_sqlite_database_sync_load_extension(i64, double)

declare double @js_node_sqlite_database_sync_location(i64, double)

declare double @js_node_sqlite_database_sync_is_open(i64)

declare double @js_node_sqlite_database_sync_is_transaction(i64)

declare i64 @js_node_sqlite_database_sync_limits(i64)

declare i64 @js_node_sqlite_statement_sync_call(double, double)

declare i64 @js_node_sqlite_statement_sync_new(double, double)

declare i64 @js_node_sqlite_statement_sync_run(i64, i64)

declare double @js_node_sqlite_statement_sync_get(i64, i64)

declare i64 @js_node_sqlite_statement_sync_all(i64, i64)

declare double @js_node_sqlite_statement_sync_iterate(i64, i64)

declare i64 @js_node_sqlite_statement_sync_columns(i64)

declare i32 @js_node_sqlite_statement_sync_set_read_bigints(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_return_arrays(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_bare_named_parameters(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_unknown_named_parameters(i64, double)

declare i64 @js_node_sqlite_statement_sync_source_sql(i64)

declare i64 @js_node_sqlite_statement_sync_expanded_sql(i64)

declare i64 @js_node_sqlite_sql_tag_store_run(i64, i64)

declare double @js_node_sqlite_sql_tag_store_get(i64, i64)

declare i64 @js_node_sqlite_sql_tag_store_all(i64, i64)

declare double @js_node_sqlite_sql_tag_store_iterate(i64, i64)

declare i32 @js_node_sqlite_sql_tag_store_clear(i64)

declare double @js_node_sqlite_sql_tag_store_size(i64)

declare double @js_node_sqlite_sql_tag_store_capacity(i64)

declare i64 @js_node_sqlite_sql_tag_store_db(i64)

declare i64 @js_node_sqlite_session_call(double, double)

declare i64 @js_node_sqlite_session_new(double, double)

declare i64 @js_node_sqlite_session_changeset(i64)

declare i64 @js_node_sqlite_session_patchset(i64)

declare i32 @js_node_sqlite_session_close(i64)

declare i32 @js_node_sqlite_session_dispose(i64)

declare i64 @js_os_cpus()

declare double @js_os_freemem()

declare i64 @js_os_homedir()

declare i64 @js_os_network_interfaces()

declare i64 @js_os_tmpdir()

declare double @js_os_totalmem()

declare double @js_os_uptime()

declare i64 @js_os_user_info()

declare i64 @js_os_user_info_buffer()

declare i64 @js_os_user_info_options(i64)

declare i64 @js_crypto_aes256_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_encrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_encrypt(i64, i64, i64)

declare double @js_crypto_create_cipheriv(i64, i64, i64, double)

declare double @js_crypto_create_decipheriv(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sha256(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sync(i64, i64, i64, i64, double)

declare i64 @js_crypto_pbkdf2(i64, i64, double, double)

declare i64 @js_crypto_random_bytes_hex(double)

declare i64 @js_crypto_random_nonce()

declare i64 @js_crypto_scrypt(i64, i64, double)

declare double @js_crypto_generate_key_pair_sync(i64, i64)

declare i64 @js_crypto_scrypt_custom(i64, i64, double, double, double, double)

declare i64 @js_crypto_x25519_keypair()

declare i64 @js_crypto_x25519_shared_secret(i64, i64)

declare i64 @js_keccak256_native(i64)

declare i64 @js_keccak256_native_bytes(i64)

declare i64 @js_nanoid(double)

declare i64 @js_nanoid_custom(i64, double)

declare i64 @js_argon2_hash(i64)

declare i64 @js_argon2_hash_options(i64, i64)

declare i64 @js_argon2_verify(i64, i64)

declare i64 @js_bcrypt_compare(i64, i64)

declare double @js_bcrypt_compare_sync(i64, i64)

declare i64 @js_bcrypt_gen_salt(double)

declare i64 @js_bcrypt_hash(i64, double)

declare i64 @js_bcrypt_hash_sync(i64, double)

declare i64 @js_ads_interstitial_load(i64)

declare i64 @js_ads_interstitial_show()

declare i64 @js_ads_rewarded_load(i64)

declare i64 @js_ads_rewarded_show()

declare double @js_ads_banner_create(i64, i64)

declare void @js_ads_banner_destroy(double)

declare i64 @js_ads_request_consent()

declare i64 @js_perry_read_embedded(double)

declare i64 @js_perry_embedded_files()

declare double @js_thread_parallel_map(double, double)

declare double @js_thread_parallel_filter(double, double)

declare double @js_thread_spawn(double)

declare double @js_perry_native_i8(double)

declare double @js_perry_native_i16(double)

declare double @js_perry_native_u8(double)

declare double @js_perry_native_u16(double)

declare double @js_perry_native_i32(double)

declare double @js_perry_native_i64(double)

declare double @js_perry_native_u32(double)

declare double @js_perry_native_u64(double)

declare double @js_perry_native_usize(double)

declare double @js_perry_native_isize(double)

declare double @js_perry_native_f32(double)

declare double @js_perry_native_f64(double)

declare i64 @js_jwt_decode(i64)

declare i64 @js_jwt_sign(i64, i64, double, i64)

declare i64 @js_jwt_sign_es256(i64, i64, double, i64)

declare i64 @js_jwt_sign_rs256(i64, i64, double, i64)

declare i64 @js_jwt_verify(i64, i64)

declare i64 @js_jwt_verify_es256(i64, i64)

declare i64 @js_jwt_verify_rs256(i64, i64)

declare i64 @js_jwt_sign_dyn(i64, i64, i64, double, i64)

declare i64 @js_jwt_verify_dyn(i64, i64, i64)

declare i64 @js_jwt_sign_dyn_opts(i64, i64, double)

declare i64 @js_jwt_verify_dyn_opts(i64, i64, double)

declare double @js_axios_create(i64)

declare i64 @js_axios_delete(i64)

declare i64 @js_axios_get(i64)

declare i64 @js_axios_head(i64)

declare i64 @js_axios_options(i64)

declare i64 @js_axios_post(i64, double)

declare i64 @js_axios_put(i64, double)

declare i64 @js_axios_patch(i64, double)

declare i64 @js_axios_request(i64)

declare double @js_axios_response_status(i64)

declare i64 @js_axios_response_status_text(i64)

declare i64 @js_axios_response_data(i64)

declare double @js_axios_response_data_parsed(i64)

declare i64 @js_sharp_auto_orient(i64)

declare i64 @js_sharp_avif(i64, double)

declare i64 @js_sharp_blur(i64, double)

declare i64 @js_sharp_composite(i64, double)

declare i64 @js_sharp_extend(i64, double)

declare i64 @js_sharp_extract(i64, double)

declare i64 @js_sharp_flip(i64)

declare i64 @js_sharp_flop(i64)

declare i64 @js_sharp_from_buffer(i64, double)

declare i64 @js_sharp_from_file(i64)

declare i64 @js_sharp_from_input(i64)

declare i64 @js_sharp_grayscale(i64)

declare i64 @js_sharp_metadata(i64)

declare i64 @js_sharp_sharpen(i64)

declare i64 @js_sharp_trim(i64)

declare i64 @js_sharp_negate(i64)

declare i64 @js_sharp_quality(i64, double)

declare i64 @js_sharp_resize(i64, double, double)

declare i64 @js_sharp_rotate(i64, double)

declare i64 @js_sharp_to_buffer(i64)

declare i64 @js_sharp_to_file(i64, i64)

declare i64 @js_sharp_to_format(i64, i64)

declare void @js_cron_clear_interval(i64)

declare void @js_cron_clear_timeout(i64)

declare i64 @js_cron_describe(i64)

declare double @js_cron_job_is_running(i64)

declare i64 @js_cron_job_new(i64, i64, double)

declare void @js_cron_job_start(i64)

declare void @js_cron_job_stop(i64)

declare i64 @js_cron_next_date(i64)

declare i64 @js_cron_next_dates(i64, double)

declare i64 @js_cron_schedule(i64, i64)

declare i64 @js_cron_set_interval(double, double)

declare i64 @js_cron_set_timeout(double, double)

declare i32 @js_cron_timer_has_pending()

declare i32 @js_cron_timer_tick()

declare double @js_cron_validate(i64)

declare i64 @js_async_hooks_create_hook(double)

declare double @js_async_hooks_execution_async_id()

declare double @js_async_hooks_trigger_async_id()

declare double @js_async_hooks_execution_async_resource()

declare i64 @js_async_hook_enable(i64)

declare i64 @js_async_hook_disable(i64)

declare i64 @js_async_resource_new(double, double)

declare double @js_async_resource_subclass_init(double, double, double)

declare double @js_async_resource_async_id(i64)

declare double @js_async_resource_trigger_async_id(i64)

declare i64 @js_async_resource_emit_destroy(i64)

declare double @js_async_resource_run_in_async_scope(i64, double, double, i64)

declare i64 @js_async_resource_bind(i64, double, double)

declare i64 @js_async_resource_static_bind(i64, double)

declare void @js_async_local_storage_disable(i64)

declare void @js_async_local_storage_enter_with(i64, double)

declare double @js_async_local_storage_exit(i64, double, i64)

declare double @js_async_local_storage_get_store(i64)

declare i64 @js_async_local_storage_new()

declare double @js_async_local_storage_subclass_init(double)

declare double @js_async_local_storage_run(i64, double, double, i64)

declare i64 @js_disposable_stack_new()

declare i64 @js_async_disposable_stack_new()

declare double @js_suppressed_error_new(double, double, double)

declare i64 @js_zlib_deflate_sync(i64, double)

declare void @js_zlib_deflate(double, double)

declare i64 @js_zlib_gunzip_sync(i64)

declare void @js_zlib_gunzip(double, double)

declare i64 @js_zlib_gzip_sync(i64, double)

declare void @js_zlib_gzip(double, double)

declare i64 @js_zlib_inflate_sync(i64)

declare void @js_zlib_inflate(double, double)

declare i64 @js_zlib_deflate_raw_sync(double, double)

declare void @js_zlib_deflate_raw(double, double)

declare i64 @js_zlib_inflate_raw_sync(double)

declare void @js_zlib_inflate_raw(double, double)

declare i64 @js_zlib_unzip_sync(double)

declare void @js_zlib_unzip(double, double)

declare double @js_zlib_crc32(double, double)

declare i64 @js_zlib_brotli_compress_sync(i64)

declare i64 @js_zlib_brotli_decompress_sync(i64)

declare void @js_zlib_brotli_compress(double, double)

declare void @js_zlib_brotli_decompress(double, double)

declare i64 @js_zlib_zstd_compress_sync(double, double)

declare i64 @js_zlib_zstd_decompress_sync(double, double)

declare void @js_zlib_zstd_compress(double, double)

declare void @js_zlib_zstd_decompress(double, double)

declare i64 @js_zlib_create_gzip(double)

declare i64 @js_zlib_create_gunzip(double)

declare i64 @js_zlib_create_deflate(double)

declare i64 @js_zlib_create_inflate(double)

declare i64 @js_zlib_create_deflate_raw(double)

declare i64 @js_zlib_create_inflate_raw(double)

declare i64 @js_zlib_create_unzip(double)

declare i64 @js_zlib_create_brotli_compress(double)

declare i64 @js_zlib_create_zstd_compress(double)

declare i64 @js_zlib_create_zstd_decompress(double)

declare i64 @js_buffer_alloc_unsafe(i32)

declare i32 @js_buffer_byte_length(i64)

declare i32 @js_buffer_byte_length_value(double, double)

declare i64 @js_buffer_concat(i64)

declare i64 @js_buffer_concat_with_length(i64, double)

declare i32 @js_buffer_validate_size(double)

declare i64 @js_buffer_validate_concat_list(double)

declare i32 @js_buffer_copy(i64, i64, i32, i32, i32)

declare i32 @js_buffer_equals(i64, i64)

declare i64 @js_buffer_fill(i64, i32)

declare i64 @js_buffer_from_value(i64, i32)

declare double @js_buffer_is_ascii(double)

declare i32 @js_buffer_is_buffer(i64)

declare i32 @js_buffer_is_node_buffer(i64)

declare i32 @js_buffer_is_encoding(double)

declare double @js_buffer_is_utf8(double)

declare void @js_buffer_print(i64)

declare void @js_buffer_set(i64, i32, i32)

declare void @js_buffer_set_from(i64, i64, i32)

declare i64 @js_buffer_slice(i64, i32, i32)

declare i64 @js_buffer_to_string(i64, i32)

declare i64 @js_buffer_transcode(double, double, double)

declare i32 @js_buffer_write(i64, i64, i32, i32)

declare double @js_child_process_exec_sync(i64, i64)

declare double @js_child_process_exec(i64, double, double)

declare i64 @js_child_process_get_process_status(double)

declare i32 @js_child_process_kill_process(double)

declare i64 @js_child_process_spawn_background(double, i64, double, double)

declare i64 @js_child_process_spawn_sync(i64, i64, i64)

declare double @js_child_process_spawn_streams(i64, i64, i64)

declare double @js_pty_spawn(i64, i64, i64)

declare double @js_child_process_fork(i64, i64, i64)

declare double @js_child_process_exec_file(i64, double, double, double)

declare double @js_child_process_exec_file_sync(i64, double, double)

declare double @js_child_process_validate_command(double, ptr, i32)

declare double @js_child_process_validate_args(double)

declare double @js_child_process_validate_options(double, i32, i32)

declare double @js_child_process_validate_fork_module(double)

declare double @js_child_process_validate_spawn_args(double, i32, i32)

declare double @js_child_process_new()

declare i64 @js_cheerio_load(i64)

declare i64 @js_cheerio_load_fragment(i64)

declare i64 @js_cheerio_select(i64, i64)

declare i64 @js_cheerio_selection_attr(i64, i64)

declare i64 @js_cheerio_selection_attrs(i64, i64)

declare i64 @js_cheerio_selection_children(i64, i64)

declare i64 @js_cheerio_selection_eq(i64, double)

declare i64 @js_cheerio_selection_find(i64, i64)

declare i64 @js_cheerio_selection_first(i64)

declare double @js_cheerio_selection_has_class(i64, i64)

declare i64 @js_cheerio_selection_html(i64)

declare double @js_cheerio_selection_is(i64, i64)

declare i64 @js_cheerio_selection_last(i64)

declare double @js_cheerio_selection_length(i64)

declare i64 @js_cheerio_selection_parent(i64)

declare i64 @js_cheerio_selection_text(i64)

declare i64 @js_cheerio_selection_texts(i64)

declare i64 @js_cheerio_selection_to_array(i64)

declare double @js_url_file_url_to_path(double, double)

declare double @js_url_file_url_to_path_buffer(double, double)

declare double @js_url_get_hash(i64)

declare double @js_url_get_host(i64)

declare double @js_url_get_hostname(i64)

declare double @js_url_get_href(i64)

declare double @js_url_get_origin(i64)

declare double @js_url_get_pathname(i64)

declare double @js_url_get_port(i64)

declare double @js_url_get_protocol(i64)

declare double @js_url_get_search(i64)

declare double @js_url_get_search_params(i64)

declare i64 @js_url_new(i64)

declare i64 @js_url_new_with_base(i64, i64)

declare i64 @js_url_pattern_new(double, double)

declare double @js_url_pattern_constructor_call(double, double)

declare i32 @js_url_can_parse(i64)

declare i32 @js_url_can_parse_with_base(i64, i64)

declare i64 @js_url_parse(i64)

declare i64 @js_url_parse_with_base(i64, i64)

declare void @js_url_set_pathname(i64, double)

declare void @js_url_set_search(i64, double)

declare void @js_url_set_hash(i64, double)

declare void @js_url_set_protocol(i64, double)

declare void @js_url_set_hostname(i64, double)

declare void @js_url_set_port(i64, double)

declare void @js_url_set_username(i64, double)

declare void @js_url_set_password(i64, double)

declare void @js_url_set_href(i64, double)

declare double @js_url_search_params_has2(i64, double, double)

declare void @js_url_search_params_delete2(i64, double, double)

declare double @js_url_search_params_throw_missing_args(i32)

declare void @js_url_search_params_append(i64, double, double)

declare void @js_url_search_params_delete(i64, double)

declare i64 @js_url_search_params_get(i64, double)

declare double @js_url_search_params_get_all(i64, double)

declare double @js_url_search_params_has(i64, double)

declare i64 @js_url_search_params_new(i64)

declare i64 @js_url_search_params_new_any(double)

declare i64 @js_url_search_params_new_empty()

declare double @js_url_search_params_subclass_init(double, double)

declare void @js_url_search_params_set(i64, double, double)

declare i64 @js_url_search_params_to_string(i64)

declare i32 @js_url_search_params_size(i64)

declare double @js_url_search_params_entries_arr(i64)

declare double @js_url_search_params_keys_arr(i64)

declare double @js_url_search_params_values_arr(i64)

declare void @js_url_search_params_sort(i64)

declare void @js_url_search_params_for_each(i64, double, double)

declare i64 @js_url_coerce_string(double)

declare double @js_url_path_to_file_url(double, double)

declare double @js_url_domain_to_ascii(double)

declare double @js_url_domain_to_unicode(double)

declare double @js_url_to_http_options(double)

declare double @js_url_legacy_url_new()

declare double @js_url_format(double, double)

declare double @js_url_legacy_parse(double, double, double)

declare double @js_url_legacy_resolve(double, double)

declare double @js_url_legacy_resolve_object(double, double)

declare void @js_ws_close(i64)

declare i64 @js_ws_connect(i64)

declare double @js_ws_connect_start(double)

declare i64 @js_ws_handle_to_i64(double)

declare double @js_ws_is_open(i64)

declare double @js_ws_message_count(i64)

declare double @js_ws_ready_state(i64)

declare i64 @js_ws_on(i64, i64, i64)

declare i64 @js_ws_receive(i64)

declare void @js_ws_send(i64, i64)

declare void @js_ws_send_to_client(double, i64)

declare void @js_ws_close_client(double)

declare void @js_ws_send_client_i64(i64, i64)

declare void @js_ws_close_client_i64(i64)

declare i64 @js_ws_on_client_i64(i64, i64, i64)

declare void @js_ws_server_close(i64)

declare double @js_ws_server_clients(i64)

declare double @js_ws_server_address(i64)

declare i32 @js_ws_server_emit(i64, i64, double, double)

declare i64 @js_ws_server_new(double)

declare void @js_ws_handle_upgrade(i64, double, double, double, i64)

declare i64 @js_ws_wait_for_message(i64, double)

declare i64 @js_pdf_create_pdf(double)

declare void @js_pdf_add_text(i64, i64, double, double, double)

declare void @js_pdf_add_line(i64, double, double, double, double)

declare void @js_pdf_new_page(i64)

declare void @js_pdf_save(i64)

declare i64 @js_commander_action(i64, i64)

declare i64 @js_commander_command(i64, i64)

declare i64 @js_commander_description(i64, i64)

declare i64 @js_commander_get_option(i64, i64)

declare double @js_commander_get_option_bool(i64, i64)

declare double @js_commander_get_option_number(i64, i64)

declare i64 @js_commander_name(i64, i64)

declare i64 @js_commander_new()

declare i64 @js_commander_option(i64, i64, i64, i64)

declare i64 @js_commander_opts(i64)

declare i64 @js_commander_parse(i64, double)

declare i64 @js_commander_required_option(i64, i64, i64, i64)

declare i64 @js_commander_version(i64, i64)

declare double @js_dotenv_config()

declare double @js_dotenv_config_path(i64)

declare i64 @js_dotenv_parse(i64)

declare double @js_datefns_add_days(double, double)

declare double @js_datefns_add_months(double, double)

declare double @js_datefns_add_years(double, double)

declare double @js_datefns_difference_in_days(double, double)

declare double @js_datefns_difference_in_hours(double, double)

declare double @js_datefns_difference_in_minutes(double, double)

declare double @js_datefns_end_of_day(double)

declare i64 @js_datefns_format(double, i64)

declare double @js_datefns_is_after(double, double)

declare double @js_datefns_is_before(double, double)

declare double @js_datefns_parse_iso(i64)

declare double @js_datefns_start_of_day(double)

declare double @js_dayjs_add(i64, double, i64)

declare double @js_dayjs_date(i64)

declare double @js_dayjs_day(i64)

declare double @js_dayjs_diff(i64, i64, i64)

declare double @js_dayjs_end_of(i64, i64)

declare double @js_dayjs_factory(i64)

declare i64 @js_dayjs_format(i64, i64)

declare double @js_dayjs_from_timestamp(double)

declare double @js_dayjs_hour(i64)

declare double @js_dayjs_is_after(i64, i64)

declare double @js_dayjs_is_before(i64, i64)

declare double @js_dayjs_is_same(i64, i64)

declare double @js_dayjs_is_valid(i64)

declare double @js_dayjs_millisecond(i64)

declare double @js_dayjs_minute(i64)

declare double @js_dayjs_month(i64)

declare double @js_dayjs_now()

declare double @js_dayjs_parse(i64)

declare double @js_dayjs_second(i64)

declare double @js_dayjs_start_of(i64, i64)

declare double @js_dayjs_subtract(i64, double, i64)

declare i64 @js_dayjs_to_iso_string(i64)

declare double @js_dayjs_unix(i64)

declare double @js_dayjs_value_of(i64)

declare double @js_dayjs_year(i64)

declare double @js_moment_add(i64, double, i64)

declare double @js_moment_clone(i64)

declare double @js_moment_date(i64)

declare double @js_moment_day(i64)

declare double @js_moment_diff(i64, i64, i64)

declare double @js_moment_end_of(i64, i64)

declare double @js_moment_factory(i64)

declare i64 @js_moment_format(i64, i64)

declare i64 @js_moment_from_now(i64)

declare double @js_moment_from_timestamp(double)

declare double @js_moment_hour(i64)

declare double @js_moment_is_after(i64, i64)

declare double @js_moment_is_before(i64, i64)

declare double @js_moment_is_between(i64, i64, i64)

declare double @js_moment_is_same(i64, i64, i64)

declare double @js_moment_is_valid(i64)

declare double @js_moment_millisecond(i64)

declare double @js_moment_minute(i64)

declare double @js_moment_month(i64)

declare double @js_moment_now()

declare double @js_moment_parse(i64)

declare double @js_moment_second(i64)

declare double @js_moment_start_of(i64, i64)

declare double @js_moment_subtract(i64, double, i64)

declare double @js_moment_to_date(i64)

declare i64 @js_moment_to_iso_string(i64)

declare double @js_moment_unix(i64)

declare double @js_moment_value_of(i64)

declare double @js_moment_year(i64)

declare i64 @js_decimal_abs(i64)

declare i64 @js_decimal_ceil(i64)

declare double @js_decimal_cmp(i64, i64)

declare double @js_decimal_cmp_value(i64, double)

declare i64 @js_decimal_coerce_to_handle(double)

declare i64 @js_decimal_div(i64, i64)

declare i64 @js_decimal_div_number(i64, double)

declare i64 @js_decimal_div_value(i64, double)

declare double @js_decimal_eq(i64, i64)

declare double @js_decimal_eq_value(i64, double)

declare i64 @js_decimal_floor(i64)

declare i64 @js_decimal_from_number(double)

declare i64 @js_decimal_from_string(i64)

declare double @js_decimal_gt(i64, i64)

declare double @js_decimal_gt_value(i64, double)

declare double @js_decimal_gte(i64, i64)

declare double @js_decimal_gte_value(i64, double)

declare double @js_decimal_is_negative(i64)

declare double @js_decimal_is_positive(i64)

declare double @js_decimal_is_zero(i64)

declare double @js_decimal_lt(i64, i64)

declare double @js_decimal_lt_value(i64, double)

declare double @js_decimal_lte(i64, i64)

declare double @js_decimal_lte_value(i64, double)

declare i64 @js_decimal_minus(i64, i64)

declare i64 @js_decimal_minus_number(i64, double)

declare i64 @js_decimal_minus_value(i64, double)

declare i64 @js_decimal_mod(i64, i64)

declare i64 @js_decimal_mod_value(i64, double)

declare i64 @js_decimal_neg(i64)

declare i64 @js_decimal_plus(i64, i64)

declare i64 @js_decimal_plus_number(i64, double)

declare i64 @js_decimal_plus_value(i64, double)

declare i64 @js_decimal_pow(i64, double)

declare i64 @js_decimal_round(i64)

declare i64 @js_decimal_sqrt(i64)

declare i64 @js_decimal_times(i64, i64)

declare i64 @js_decimal_times_number(i64, double)

declare i64 @js_decimal_times_value(i64, double)

declare i64 @js_decimal_to_fixed(i64, double)

declare double @js_decimal_to_number(i64)

declare i64 @js_decimal_to_string(i64)

declare i64 @js_ethers_format_ether(i64)

declare i64 @js_ethers_format_units(i64, double)

declare i64 @js_ethers_get_address(i64)

declare i64 @js_ethers_parse_ether(i64)

declare i64 @js_ethers_parse_units(i64, double)

declare i64 @js_lodash_camel_case(i64)

declare i64 @js_lodash_capitalize(i64)

declare i64 @js_lodash_chunk(i64, double)

declare double @js_lodash_clamp(double, double, double)

declare i64 @js_lodash_compact(i64)

declare i64 @js_lodash_concat(i64, i64)

declare i64 @js_lodash_difference(i64, i64)

declare i64 @js_lodash_drop(i64, double)

declare i64 @js_lodash_drop_right(i64, double)

declare double @js_lodash_ends_with(i64, i64)

declare i64 @js_lodash_escape(i64)

declare double @js_lodash_first(i64)

declare i64 @js_lodash_flatten(i64)

declare double @js_lodash_in_range(double, double, double)

declare double @js_lodash_includes(i64, i64)

declare i64 @js_lodash_initial(i64)

declare i64 @js_lodash_kebab_case(i64)

declare double @js_lodash_last(i64)

declare i64 @js_lodash_lower_case(i64)

declare i64 @js_lodash_lower_first(i64)

declare double @js_lodash_max(i64)

declare double @js_lodash_max_by(i64, double)

declare double @js_lodash_mean(i64)

declare double @js_lodash_mean_by(i64, double)

declare double @js_lodash_min(i64)

declare double @js_lodash_min_by(i64, double)

declare i64 @js_lodash_pad(i64, double)

declare i64 @js_lodash_pad_end(i64, double)

declare i64 @js_lodash_pad_start(i64, double)

declare double @js_lodash_random(double, double)

declare i64 @js_lodash_repeat(i64, double)

declare i64 @js_lodash_replace(i64, i64, i64)

declare i64 @js_lodash_reverse(i64)

declare double @js_lodash_size(i64)

declare i64 @js_lodash_snake_case(i64)

declare i64 @js_lodash_split(i64, i64)

declare i64 @js_lodash_start_case(i64)

declare double @js_lodash_starts_with(i64, i64)

declare double @js_lodash_sum(i64)

declare double @js_lodash_sum_by(i64, double)

declare i64 @js_lodash_tail(i64)

declare i64 @js_lodash_take(i64, double)

declare i64 @js_lodash_take_right(i64, double)

declare i64 @js_lodash_trim(i64)

declare i64 @js_lodash_trim_end(i64)

declare i64 @js_lodash_trim_start(i64)

declare i64 @js_lodash_truncate(i64, double)

declare i64 @js_lodash_unescape(i64)

declare i64 @js_lodash_uniq(i64)

declare i64 @js_lodash_upper_case(i64)

declare i64 @js_lodash_upper_first(i64)

declare void @js_lru_cache_clear(i64)

declare double @js_lru_cache_delete(i64, double)

declare double @js_lru_cache_get(i64, double)

declare double @js_lru_cache_has(i64, double)

declare i64 @js_lru_cache_new(double)

declare double @js_lru_cache_peek(i64, double)

declare i64 @js_lru_cache_set(i64, double, double)

declare double @js_lru_cache_size(i64)

declare double @js_event_emitter_subclass_init(double)

declare double @js_event_emitter_async_resource_subclass_init(double, double)

declare double @js_array_subclass_init(double, double)

declare double @js_array_subclass_init_args(double, ptr, i64)

declare double @js_map_set_subclass_init(double, i32, double)

declare double @js_weak_collection_subclass_init(double, i32, double)

declare double @js_promise_subclass_init(double, double)

declare double @js_node_stream_readable_new(double)

declare double @js_node_stream_readable_subclass_init(double, double)

declare double @js_node_stream_writable_new(double)

declare double @js_node_stream_writable_subclass_init(double, double)

declare double @js_node_stream_duplex_new(double)

declare double @js_node_stream_duplex_subclass_init(double, double)

declare double @js_node_stream_transform_new(double)

declare double @js_node_stream_transform_subclass_init(double, double)

declare double @js_node_stream_passthrough_new(double)

declare double @js_node_stream_readable_from(double)

declare double @js_node_stream_readable_from_options(double, double)

declare double @js_node_stream_duplex_from_options(double, double)

declare double @js_node_stream_is_disturbed(double)

declare double @js_node_stream_is_errored(double)

declare double @js_node_stream_is_readable(double)

declare double @js_node_stream_is_writable(double)

declare double @js_node_stream_is_array_buffer_view(double)

declare double @js_node_stream_is_uint8_array(double)

declare double @js_node_stream_is_destroyed(double)

declare double @js_node_stream_uint8_array_to_buffer(double)

declare double @js_node_stream_get_default_hwm(double)

declare double @js_node_stream_set_default_hwm(double, double)

declare double @js_node_stream_add_abort_signal(double, double)

declare double @js_node_stream_compose(i64)

declare double @js_node_stream_pipeline(i64)

declare double @js_node_stream_finished(i64)

declare double @js_node_stream_duplex_pair(double)

declare double @js_node_stream_readable_to_web(double)

declare double @js_node_stream_writable_to_web(double)

declare double @js_node_stream_duplex_to_web(double)

declare double @js_node_stream_readable_from_web(double, double)

declare double @js_node_stream_writable_from_web(double, double)

declare double @js_node_stream_duplex_from_web(double, double)

declare double @js_node_stream_to_web(double)

declare double @js_node_stream_from_web(double)

declare double @js_node_stream_method_readable_aborted(i64)

declare double @js_node_stream_method_closed(i64)

declare double @js_node_stream_method_errored(i64)

declare double @js_node_stream_method_readable_did_read(i64)

declare double @js_node_stream_method_destroyed(i64)

declare double @js_node_stream_method_destroy(i64, double)

declare double @js_node_stream_method_pause(i64)

declare double @js_node_stream_method_readable(i64)

declare double @js_node_stream_method_readable_length(i64)

declare double @js_node_stream_method_readable_flowing(i64)

declare double @js_node_stream_method_readable_ended(i64)

declare double @js_node_stream_method_readable_object_mode(i64)

declare double @js_node_stream_method_pipe(i64, double, double)

declare double @js_node_stream_method_unpipe(i64, double)

declare double @js_node_stream_method_is_paused(i64)

declare double @js_node_stream_method_resume(i64)

declare double @js_node_stream_method_readable_encoding(i64)

declare double @js_node_stream_method_cork(i64)

declare double @js_node_stream_method_uncork(i64)

declare double @js_node_stream_method_writable_corked(i64)

declare double @js_node_stream_method_writable_length(i64)

declare double @js_node_stream_method_writable_need_drain(i64)

declare double @js_node_stream_method_writable(i64)

declare double @js_node_stream_method_writable_ended(i64)

declare double @js_node_stream_method_writable_finished(i64)

declare double @js_node_stream_method_allow_half_open(i64)

declare double @js_node_stream_method_set_encoding(i64, double)

declare double @js_node_stream_method_writable_object_mode(i64)

declare double @js_event_emitter_emit(i64, i64, i64)

declare double @js_event_emitter_emit0(i64, i64)

declare double @js_event_emitter_listener_count(i64, i64, i64)

declare i64 @js_event_emitter_new()

declare i64 @js_event_emitter_new_with_options(double)

declare i64 @js_event_emitter_on(i64, i64, i64)

declare i64 @js_event_emitter_once(i64, i64, i64)

declare i64 @js_event_emitter_prepend_listener(i64, i64, i64)

declare i64 @js_event_emitter_prepend_once_listener(i64, i64, i64)

declare i64 @js_event_emitter_remove_all_listeners(i64, i64)

declare i64 @js_event_emitter_remove_listener(i64, i64, i64)

declare i64 @js_event_emitter_set_max_listeners(i64, double)

declare double @js_event_emitter_get_max_listeners(i64)

declare i64 @js_event_emitter_event_names(i64)

declare i64 @js_event_emitter_listeners(i64, i64)

declare i64 @js_event_emitter_raw_listeners(i64, i64)

declare double @js_event_emitter_domain_value(i64)

declare i64 @js_event_emitter_async_resource_new(double)

declare double @js_event_emitter_async_resource_call(double)

declare double @js_event_emitter_async_resource_async_id(i64)

declare double @js_event_emitter_async_resource_trigger_async_id(i64)

declare double @js_event_emitter_async_resource_async_resource(i64)

declare double @js_event_emitter_async_resource_emit_destroy(i64)

declare i64 @js_events_once(double, i64, double)

declare i64 @js_events_on(double, i64, double)

declare i64 @js_events_add_abort_listener(double, double)

declare i64 @js_events_get_event_listeners(double, i64)

declare double @js_events_listener_count(double, i64)

declare double @js_events_get_max_listeners(double)

declare double @js_events_set_max_listeners(double, i64)

declare double @js_events_init()

declare i64 @js_domain_create()

declare i64 @js_domain_on(i64, i64, i64)

declare double @js_domain_emit(i64, i64, i64)

declare double @js_domain_run(i64, double, i64)

declare double @js_domain_bind(i64, double)

declare double @js_domain_intercept(i64, double)

declare i64 @js_domain_add(i64, double)

declare i64 @js_domain_remove(i64, double)

declare double @js_domain_enter(i64)

declare double @js_domain_exit(i64)

declare i64 @js_string_decoder_new(i64)

declare double @js_string_decoder_write(i64, double)

declare double @js_string_decoder_end(i64, double)

declare double @js_querystring_escape(double)

declare double @js_querystring_unescape(double)

declare i64 @js_querystring_unescape_buffer(double, double)

declare i64 @js_querystring_parse(double, double, double, double)

declare double @js_querystring_stringify(double, double, double, double)

declare i32 @js_fastify_add_hook(i64, i64, i64)

declare i32 @js_fastify_all(i64, i64, i64)

declare i64 @js_fastify_create()

declare i64 @js_fastify_create_with_opts(double)

declare double @js_fastify_ctx_html(i64, i64, double)

declare double @js_fastify_ctx_json(i64, double, double)

declare double @js_fastify_ctx_redirect(i64, i64, double)

declare double @js_fastify_ctx_text(i64, i64, double)

declare i32 @js_fastify_delete(i64, i64, i64)

declare i32 @js_fastify_get(i64, i64, i64)

declare i32 @js_fastify_head(i64, i64, i64)

declare void @js_fastify_listen(i64, double, i64)

declare void @js_fastify_app_close(i64)

declare i64 @js_fastify_app_server(i64)

declare void @js_fastify_app_on(i64, i64, i64)

declare i32 @js_fastify_options(i64, i64, i64)

declare i32 @js_fastify_patch(i64, i64, i64)

declare i32 @js_fastify_post(i64, i64, i64)

declare i32 @js_fastify_put(i64, i64, i64)

declare i32 @js_fastify_register(i64, i64, double)

declare i64 @js_fastify_reply_header(i64, i64, i64)

declare i32 @js_fastify_reply_send(i64, double)

declare i64 @js_fastify_reply_status(i64, double)

declare i64 @js_fastify_reply_type(i64, i64)

declare i64 @js_fastify_req_body(i64)

declare double @js_fastify_req_get_user_data(i64)

declare i64 @js_fastify_req_header(i64, i64)

declare i64 @js_fastify_req_headers(i64)

declare double @js_fastify_req_json(i64)

declare i64 @js_fastify_req_method(i64)

declare i64 @js_fastify_req_param(i64, i64)

declare i64 @js_fastify_req_params(i64)

declare i64 @js_fastify_req_query(i64)

declare double @js_fastify_req_query_object(i64)

declare void @js_fastify_req_set_user_data(i64, double)

declare i64 @js_fastify_req_url(i64)

declare i32 @js_fastify_route(i64, i64, i64, i64)

declare i32 @js_fastify_set_error_handler(i64, i64)

declare double @js_nodemailer_create_transport(i64)

declare i64 @js_nodemailer_send_mail(i64, i64)

declare i64 @js_nodemailer_verify(i64)

declare i64 @js_ratelimit_block(i64, i64, double)

declare i64 @js_ratelimit_consume(i64, i64, double)

declare i64 @js_ratelimit_create(i64)

declare i64 @js_ratelimit_delete(i64, i64)

declare i64 @js_ratelimit_get(i64, i64)

declare i64 @js_ratelimit_new_from_options(i64)

declare i64 @js_ratelimit_penalty(i64, i64, double)

declare i64 @js_ratelimit_reward(i64, i64, double)

declare double @js_validator_contains(i64, i64)

declare double @js_validator_equals(i64, i64)

declare double @js_validator_is_alpha(i64)

declare double @js_validator_is_alphanumeric(i64)

declare double @js_validator_is_email(i64)

declare double @js_validator_is_empty(i64)

declare double @js_validator_is_float(i64)

declare double @js_validator_is_hexadecimal(i64)

declare double @js_validator_is_int(i64)

declare double @js_validator_is_json(i64)

declare double @js_validator_is_length(i64, double, double)

declare double @js_validator_is_lowercase(i64)

declare double @js_validator_is_numeric(i64)

declare double @js_validator_is_uppercase(i64)

declare double @js_validator_is_url(i64)

declare double @js_validator_is_uuid(i64)

declare i64 @js_date_to_locale_string(double)

declare i64 @js_number_to_locale_string(double)

declare double @js_value_to_locale_string(double)

declare i64 @js_string_split_regex(i64, i64)

declare i32 @js_object_delete_dynamic(i64, double)

declare double @js_object_get_prototype_of(double)

declare double @js_object_set_prototype_of(double, double)

declare double @js_object_define_properties(double, double)

declare double @js_math_acos(double)

declare double @js_math_asin(double)

declare double @js_math_atan(double)

declare double @js_math_atan2(double, double)

declare double @js_math_cos(double)

declare double @js_math_expm1(double)

declare double @js_math_log(double)

declare double @js_math_log10(double)

declare double @js_math_log1p(double)

declare double @js_math_log2(double)

declare double @js_math_sin(double)

declare double @js_math_tan(double)

declare double @js_atomics_load(ptr, double, double)

declare double @js_atomics_is_lock_free(ptr, double)

declare double @js_atomics_store(ptr, double, double, double)

declare double @js_atomics_add(ptr, double, double, double)

declare double @js_atomics_sub(ptr, double, double, double)

declare double @js_atomics_and(ptr, double, double, double)

declare double @js_atomics_or(ptr, double, double, double)

declare double @js_atomics_xor(ptr, double, double, double)

declare double @js_atomics_exchange(ptr, double, double, double)

declare double @js_atomics_compare_exchange(ptr, double, double, double, double)

declare double @js_atomics_notify(ptr, double, double, double)

declare double @js_atomics_wait(ptr, double, double, double, double)

declare double @js_atomics_wait_async(ptr, double, double, double, double)

declare double @js_number_is_finite(double)

declare double @js_json_get_bool(i64, i64)

declare double @js_json_get_number(i64, i64)

declare i64 @js_json_get_string(i64, i64)

declare double @js_json_is_valid(i64)

declare i64 @js_json_stringify_bool(double)

declare i64 @js_json_stringify_null()

declare i64 @js_json_stringify_number(double)

declare i64 @js_json_stringify_string(i64)

declare void @js_set_property(double, i64, i64, double)

declare i64 @js_error_get_message(i64)

declare double @js_await_js_promise(double)

declare i64 @js_text_decoder_decode(i64)

declare i64 @js_text_encoder_encode(double)

declare double @js_call_function(i64, i64, i64, i64, i64)

declare double @js_call_method(double, i64, i64, i64, i64)

declare double @js_call_value(double, i64, i64)

declare double @js_closure_call_array(i64, ptr, i64)

declare double @js_closure_call_apply_with_spread(double, ptr, i64, i64)

declare double @js_create_callback(i64, i64, i64)

declare double @js_dynamic_neg(double)

declare double @js_dynamic_pos(double)

declare i32 @js_dynamic_string_equals(double, double)

declare double @js_is_nan(double)

declare i32 @js_jsvalue_compare(double, double)

declare i32 @js_jsvalue_loose_equals(double, double)

declare void @js_gc_collect()

declare void @js_console_assert(double, i64)

declare void @js_console_assert_spread(double, i64)

declare void @js_console_group(i64)

declare double @js_console_context(double)

declare double @js_console_create_task(double)

declare i64 @js_fetch_input_ptr(double)

declare i64 @js_fetch_get(i64)

declare i64 @js_fetch_get_with_auth(i64, i64)

declare i64 @js_fetch_post(i64, i64, i64)

declare i64 @js_fetch_post_with_auth(i64, i64, i64)

declare double @js_fetch_stream_close(double)

declare i64 @js_fetch_stream_poll(double)

declare double @js_fetch_stream_start(i64, i64, i64, i64)

declare double @js_fetch_stream_status(double)

declare i64 @js_fetch_text(i64)

declare i64 @js_fetch_with_options(i64, i64, i64, i64)

declare void @js_fetch_set_pending_signal(double)

declare i64 @js_fetch_headers_to_json(double)

declare double @js_net_create_connection(i32, i64, i64)

declare i64 @js_net_create_server(i64, i64)

declare i64 @js_ext_net_create_server(i64, i64)

declare i64 @js_ext_net_socket_connect(double, double, double)

declare double @js_net_normalize_args(double)

declare double @js_net_create_server_handle_stub(double, double, double, double, double)

declare void @js_net_validate_create_server_options(double)

declare i64 @js_net_socket_set_timeout(i64, double, i64)

declare void @js_net_server_listen(i64, double, double, double)

declare void @js_net_server_close(i64, i64)

declare i64 @js_net_server_address(i64)

declare void @js_net_server_on(i64, i64, i64)

declare double @js_net_server_get_listening(i64)

declare double @js_net_server_get_connections(i64)

declare double @js_net_server_get_max_connections(i64)

declare double @js_net_server_set_max_connections(i64, double)

declare double @js_net_server_get_drop_max_connection(i64)

declare double @js_net_server_set_drop_max_connection(i64, double)

declare i64 @js_net_block_list_new()

declare double @js_net_block_list_is_block_list(double)

declare double @js_net_block_list_add_address(i64, i64, i64)

declare double @js_net_block_list_add_range(i64, i64, i64, i64)

declare double @js_net_block_list_add_subnet(i64, i64, double, i64)

declare double @js_net_block_list_check(i64, i64, i64)

declare double @js_net_block_list_to_json(i64)

declare i64 @js_net_block_list_rules(i64)

declare double @js_net_block_list_from_json(i64, double)

declare i64 @js_net_socket_address_new(double)

declare double @js_net_socket_address_parse(i64)

declare i64 @js_net_socket_address_get_address(i64)

declare i64 @js_net_socket_address_get_family(i64)

declare double @js_net_socket_address_get_port(i64)

declare double @js_net_socket_address_get_flowlabel(i64)

declare double @js_net_socket_get_type_of_service(i64)

declare i64 @js_net_socket_set_type_of_service(i64, double)

declare i64 @js_net_socket_address(i64)

declare i64 @js_net_socket_once(i64, i64, i64)

declare i64 @js_ext_net_socket_once(i64, i64, i64)

declare void @js_ext_net_socket_on(i64, i64, i64)

declare i64 @js_ext_tls_connect(double, double, double, double)

declare i64 @js_net_socket_remove_listener(i64, i64, i64)

declare i64 @js_net_socket_remove_all_listeners(i64, i64)

declare double @js_net_socket_listener_count(i64, i64)

declare i64 @js_net_socket_event_names(i64)

declare i64 @js_net_socket_reset_and_destroy(i64)

declare i64 @js_net_server_once(i64, i64, i64)

declare i64 @js_net_server_remove_listener(i64, i64, i64)

declare i64 @js_net_server_remove_all_listeners(i64, i64)

declare double @js_net_server_listener_count(i64, i64)

declare i64 @js_net_server_event_names(i64)

declare double @js_performance_now()

declare double @js_perf_mark(double, double)

declare double @js_perf_measure(double, double, double)

declare double @js_perf_get_entries()

declare double @js_perf_get_entries_by_type(double)

declare double @js_perf_get_entries_by_name(double, double)

declare double @js_perf_clear_marks(double)

declare double @js_perf_clear_measures(double)

declare double @js_perf_event_loop_utilization(double, double)

declare double @js_perf_to_json()

declare double @js_perf_clear_resource_timings()

declare double @js_perf_set_resource_timing_buffer_size(double)

declare double @js_perf_mark_resource_timing(double, double, double, double, double, double, double, double)

declare double @js_perf_timerify(double, double)

declare double @js_perf_observer_new(double)

declare double @js_perf_observer_observe(double, double)

declare double @js_perf_observer_disconnect(double)

declare double @js_perf_observer_take_records(double)

declare double @js_perf_monitor_event_loop_delay(double)

declare double @js_perf_create_histogram(double)

declare double @js_iter_result_set(double, i32)

declare double @js_iter_result_set_f64(double, i32)

declare double @js_iter_result_set_i32(i32, i32)

declare double @js_iter_result_set_i1(i32, i32)

declare double @js_iter_result_get_value()

declare double @js_iter_result_get_value_f64()

declare i32 @js_iter_result_get_value_i32()

declare i32 @js_iter_result_get_value_i1()

declare double @js_iter_result_get_done()

declare i64 @js_async_step_chain(double, i64)

declare i64 @js_async_step_done(double, i64)

declare i64 @js_get_current_step_closure()

declare double @js_async_first_call(double)

declare double @js_async_generator_resume(double, double, double)

declare void @js_register_class_getter(i64, i64, i64, i64)

declare void @js_register_class_setter(i64, i64, i64, i64)

declare void @js_register_class_string_member_order(i64, i64, i64, i64, i64)

declare void @js_register_class_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_getter(i64, i64, i64, i64)

declare void @js_register_class_static_setter(i64, i64, i64, i64)

declare void @js_register_class_method(i64, i64, i64, i64, i64, i64, i64)

declare void @js_register_class_constructor(i64, i64, i64, i64)

declare void @js_register_class_constructor_flags(i64, i64, i64)

declare void @js_register_class_static_method(i64, i64, i64, i64, i64, i64)

declare double @js_class_static_method_call(double, i64, i64, ptr, i64)

declare double @js_class_method_bind(double, i64, i64)

declare double @js_class_method_snapshot_bind(double, i64, i64)

declare double @js_class_method_bind_by_id(double, i64)

declare double @js_class_lexical_binding_get(double)

declare double @js_class_lexical_binding_set(double, double)

declare double @js_class_prototype_method_value(double, double)

declare double @js_implicit_this_get()

declare double @js_implicit_this_get_sloppy()

declare double @js_implicit_this_set(double)

declare double @js_static_this_resolve(double)

declare void @js_static_this_arm_classref(i32)

declare void @js_static_this_arm_value(double)

declare double @js_ctor_return_override(double, double, i32)

declare double @js_new_target_get()

declare double @js_new_target_set(double)

declare void @js_derived_super_scope_push(ptr)

declare void @js_derived_super_scope_pop()

declare double @js_derived_super_bind_current()

declare double @js_derived_this_check_current()

declare double @js_get_export(i64, i64, i64)

declare double @js_get_property(double, i64, i64)

declare i64 @js_load_module(i64, i64)

declare double @js_module_dynamic_import_apply_hooks(double)

declare double @js_native_call_method_nullsafe(double, i64, i64, i64, i64)

declare double @js_native_call_value(double, i64, i64)

declare double @js_new_from_handle(double, i64, i64)

declare double @js_new_instance(i64, i64, i64, i64, i64)

declare void @js_runtime_init()

declare double @js_object_set_symbol_method(double, double, double)

declare double @js_object_set_method_by_name(double, double, double)

declare double @js_object_define_accessor(double, double, double, double)

declare double @js_object_literal_set_computed(double, double, double)

declare double @js_object_literal_to_property_key(double)

declare double @js_object_literal_set_prototype(double, double)

declare double @js_to_primitive(double, i32)

declare void @js_register_class_has_instance(i32, i64)

declare void @js_register_class_to_string_tag(i32, i64)

declare double @js_object_to_string(double)

declare double @js_object_group_by(double, double)

declare double @js_map_group_by(double, double)

declare double @js_array_from_async(double, double, double)

declare double @js_jsx(double, double)

declare double @js_jsxs(double, double)

declare i64 @js_node_http_server_ref(i64)

declare i64 @js_node_http_server_unref(i64)

declare i64 @js_node_https_server_ref(i64)

declare i64 @js_node_https_server_unref(i64)

declare double @js_http_client_request_flush_headers(i64, double, double)

declare double @js_node_http_im_http_version_major(i64)

declare double @js_node_http_im_http_version_minor(i64)

declare i64 @js_node_http_im_pause_self(i64)

declare i64 @js_node_http_im_resume_self(i64)

declare i64 @js_commander_args_array(i64)

declare i64 @js_commander_argument(i64, i64)

declare double @__ic_decl_1()

declare double @__ic_decl_3()

declare double @__ic_decl_5()

declare double @__ic_decl_7()

declare double @__ic_decl_9()

declare double @__ic_decl_11()

declare double @__ic_decl_13()

declare double @__ic_decl_15()

declare double @__ic_decl_21()

declare double @__ic_decl_23()

declare double @__ic_decl_25()

declare double @__ic_decl_27()

declare double @__ic_decl_29()

declare double @__ic_decl_31()

declare double @__ic_decl_33()

declare token @llvm.experimental.gc.statepoint.p0(i64 immarg, i32 immarg, ptr, i32 immarg, i32 immarg, ...)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token, i32 immarg, i32 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.experimental.gc.result.i1(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i8 @llvm.experimental.gc.result.i8(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i16 @llvm.experimental.gc.result.i16(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.experimental.gc.result.i32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i64 @llvm.experimental.gc.result.i64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i128 @llvm.experimental.gc.result.i128(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.experimental.gc.result.f32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare double @llvm.experimental.gc.result.f64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr @llvm.experimental.gc.result.p0(token) #3

; Function Attrs: optsize
define internal double @"perry_fn_options_worker_ts__identity$spec_b_b"(double %arg13, double %arg14) #6 gc "statepoint-example" {
entry.0:
  %rs4gc.b1 = bitcast double %arg13 to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg14 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %r3.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r3.rs4o = call i64 asm "", "=r,0"(i64 %r3.rs4i) #9
  %r3 = bitcast i64 %r3.rs4o to double
  ret double %r3
}

; Function Attrs: optsize
define internal double @"perry_fn_options_worker_ts__run$spec_b"(double %arg15) #6 gc "statepoint-example" {
entry.0:
  %rs4gc.b5 = bitcast double %arg15 to i64
  %rs4gc.s5 = inttoptr i64 %rs4gc.b5 to ptr addrspace(1)
  %r3 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r4 = load double, ptr @options_worker_ts_.str.0.handle, align 8
  %r5 = bitcast double %r3 to i64
  %r6 = bitcast double %r4 to i64
  %r7 = icmp eq i64 %r5, %r6
  br i1 %r7, label %streqlit.true.7, label %streqlit.sso.1

streqlit.sso.1:                                   ; preds = %entry.0
  %r8 = icmp eq i64 %r5, 9221406111934080378
  br i1 %r8, label %streqlit.true.7, label %streqlit.tag.2

streqlit.tag.2:                                   ; preds = %streqlit.sso.1
  %r9 = lshr i64 %r5, 48
  %r10 = icmp eq i64 %r9, 32767
  %r11 = and i64 %r5, 281474976710655
  %r12 = icmp ugt i64 %r11, 4095
  %r13 = and i1 %r10, %r12
  br i1 %r13, label %streqlit.len.3, label %streqlit.false.8

streqlit.len.3:                                   ; preds = %streqlit.tag.2
  %r14 = inttoptr i64 %r11 to ptr
  %r15 = getelementptr inbounds nuw i8, ptr %r14, i64 4
  %r16 = load i32, ptr %r15, align 4
  %r17 = icmp eq i32 %r16, 4
  br i1 %r17, label %streqlit.b0.4, label %streqlit.false.8

streqlit.b0.4:                                    ; preds = %streqlit.len.3
  %r18 = getelementptr inbounds nuw i8, ptr %r14, i64 20
  %r19 = load i8, ptr %r18, align 1
  %r20 = icmp eq i8 %r19, 122
  br i1 %r20, label %streqlit.bl.5, label %streqlit.false.8

streqlit.bl.5:                                    ; preds = %streqlit.b0.4
  %r21 = getelementptr inbounds nuw i8, ptr %r14, i64 23
  %r22 = load i8, ptr %r21, align 1
  %r23 = icmp eq i8 %r22, 111
  br i1 %r23, label %streqlit.slow.6, label %streqlit.false.8

streqlit.slow.6:                                  ; preds = %streqlit.bl.5
  %r24 = and i64 %r6, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r11, i64 %r24, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5) ]
  %r254 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token)
  %rs4gc.s5.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s5, %rs4gc.s5)
  %r26 = icmp ne i32 %r254, 0
  br label %streqlit.merge.9

streqlit.true.7:                                  ; preds = %streqlit.sso.1, %entry.0
  br label %streqlit.merge.9

streqlit.false.8:                                 ; preds = %streqlit.bl.5, %streqlit.b0.4, %streqlit.len.3, %streqlit.tag.2
  br label %streqlit.merge.9

streqlit.merge.9:                                 ; preds = %streqlit.false.8, %streqlit.true.7, %streqlit.slow.6
  %.0 = phi ptr addrspace(1) [ %rs4gc.s5, %streqlit.true.7 ], [ %rs4gc.s5.relocated, %streqlit.slow.6 ], [ %rs4gc.s5, %streqlit.false.8 ]
  %r27 = phi i1 [ true, %streqlit.true.7 ], [ false, %streqlit.false.8 ], [ %r26, %streqlit.slow.6 ]
  %r28 = select i1 %r27, i64 9222246136947933188, i64 9222246136947933187
  %r29 = bitcast i64 %r28 to double
  %r30 = icmp eq i64 %r28, 9222246136947933188
  br i1 %r30, label %if.then.10, label %if.else.11

if.then.10:                                       ; preds = %streqlit.merge.9
  %r35.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r35.rs4o = call i64 asm "", "=r,0"(i64 %r35.rs4i) #9
  %r35 = bitcast i64 %r35.rs4o to double
  %r36 = bitcast double %r35 to i64
  %r37 = and i64 %r36, -281474976710656
  %r38 = icmp ult i64 %r37, 9221401712017801216
  %r39 = icmp ugt i64 %r37, 9223090561878065152
  %r40 = or i1 %r38, %r39
  br i1 %r40, label %for.bound_i32.number.13, label %for.bound_i32.merge.15

if.else.11:                                       ; preds = %streqlit.merge.9
  %r258 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r259 = load double, ptr @options_worker_ts_.str.2.handle, align 8
  %r260 = bitcast double %r258 to i64
  %r261 = bitcast double %r259 to i64
  %r262 = icmp eq i64 %r260, %r261
  br i1 %r262, label %streqlit.true.75, label %streqlit.tag.70

if.merge.12:                                      ; preds = %if.merge.80, %for.exit.21
  %r2.0 = phi double [ %r2.1, %for.exit.21 ], [ %r2.2, %if.merge.80 ]
  ret double %r2.0

for.bound_i32.number.13:                          ; preds = %if.then.10
  %r41 = fcmp oge double %r35, 0xC1E0000000000000
  %r42 = fcmp ole double %r35, 0x41DFFFFFFFC00000
  %r43 = and i1 %r41, %r42
  br i1 %r43, label %for.bound_i32.convert.14, label %for.bound_i32.merge.15

for.bound_i32.convert.14:                         ; preds = %for.bound_i32.number.13
  %r44 = fptosi double %r35 to i32
  %r45 = sitofp i32 %r44 to double
  %r46 = fcmp oeq double %r45, %r35
  br i1 %r46, label %for.counter_i32.range.16, label %for.bound_i32.merge.15

for.bound_i32.merge.15:                           ; preds = %for.counter_i32.convert.17, %for.bound_i32.convert.14, %for.bound_i32.number.13, %if.then.10
  %r34.0 = phi i32 [ %r44, %for.counter_i32.convert.17 ], [ 0, %if.then.10 ], [ %r44, %for.bound_i32.convert.14 ], [ 0, %for.bound_i32.number.13 ]
  %r33.0 = phi i1 [ true, %for.counter_i32.convert.17 ], [ false, %if.then.10 ], [ false, %for.bound_i32.convert.14 ], [ false, %for.bound_i32.number.13 ]
  br label %for.cond.18

for.counter_i32.range.16:                         ; preds = %for.bound_i32.convert.14
  br label %for.counter_i32.convert.17

for.counter_i32.convert.17:                       ; preds = %for.counter_i32.range.16
  br label %for.bound_i32.merge.15

for.cond.18:                                      ; preds = %for.update.20, %for.bound_i32.merge.15
  %.1 = phi ptr addrspace(1) [ %.0, %for.bound_i32.merge.15 ], [ %.7, %for.update.20 ]
  %r32.1 = phi i32 [ 0, %for.bound_i32.merge.15 ], [ %r257, %for.update.20 ]
  %r31.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.15 ], [ %r255, %for.update.20 ]
  %r2.1 = phi double [ 0.000000e+00, %for.bound_i32.merge.15 ], [ %r246, %for.update.20 ]
  br i1 %r33.0, label %for.cond.fast.22, label %for.cond.slow.23

for.body.19:                                      ; preds = %gcpoll.done.25, %for.cond.fast.22
  %.2 = phi ptr addrspace(1) [ %.1, %for.cond.fast.22 ], [ %.3, %gcpoll.done.25 ]
  %r67 = load double, ptr @perry_global_options_worker_ts__4, align 8
  %statepoint_token5 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r67, double 0x7FFC000000000002, double 0.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r6810 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token5)
  %rs4gc.s5.relocated11 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token5, i32 0, i32 0) ; (%.2, %.2)
  %r69 = bitcast i64 %r6810 to double
  %rs4gc.b6 = bitcast double %r69 to i64
  %rs4gc.s6 = inttoptr i64 %rs4gc.b6 to ptr addrspace(1)
  %r70.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r70 = call i64 asm "", "=r,0"(i64 %r70.rs4i) #9
  %r71 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r72 = icmp ne i32 %r71, 0
  br i1 %r72, label %shadow.root.barrier.26, label %shadow.root.barrier.done.27

for.update.20:                                    ; preds = %gcpoll.done.69
  %r255 = fadd double %r31.0, 1.000000e+00
  %r257 = add i32 %r32.1, 1
  br label %for.cond.18

for.exit.21:                                      ; preds = %gcpoll.done.25, %for.cond.fast.22
  br label %if.merge.12

for.cond.fast.22:                                 ; preds = %for.cond.18
  %r57 = icmp slt i32 %r32.1, %r34.0
  br i1 %r57, label %for.body.19, label %for.exit.21

for.cond.slow.23:                                 ; preds = %for.cond.18
  %r59.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r59.rs4o = call i64 asm "", "=r,0"(i64 %r59.rs4i) #9
  %r59 = bitcast i64 %r59.rs4o to double
  %r60 = fcmp olt double %r31.0, %r59
  %r61 = select i1 %r60, i64 9222246136947933188, i64 9222246136947933187
  %r62 = bitcast i64 %r61 to double
  %r64 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r65 = icmp ne i32 %r64, 0
  br i1 %r65, label %gcpoll.24, label %gcpoll.done.25

gcpoll.24:                                        ; preds = %for.cond.slow.23
  %statepoint_token12 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1) ]
  %rs4gc.s5.relocated13 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token12, i32 0, i32 0) ; (%.1, %.1)
  br label %gcpoll.done.25

gcpoll.done.25:                                   ; preds = %gcpoll.24, %for.cond.slow.23
  %.3 = phi ptr addrspace(1) [ %rs4gc.s5.relocated13, %gcpoll.24 ], [ %.1, %for.cond.slow.23 ]
  %r63 = icmp eq i64 %r61, 9222246136947933188
  br i1 %r63, label %for.body.19, label %for.exit.21

shadow.root.barrier.26:                           ; preds = %for.body.19
  call void @js_write_barrier_root_nanbox(i64 %r70) #9
  br label %shadow.root.barrier.done.27

shadow.root.barrier.done.27:                      ; preds = %shadow.root.barrier.26, %for.body.19
  %r74 = bitcast double %r2.1 to i64
  %rs4gc.s7 = inttoptr i64 %r74 to ptr addrspace(1)
  %r76.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7 to i64
  %r76 = call i64 asm "", "=r,0"(i64 %r76.rs4i) #9
  %r77 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r78 = icmp ne i32 %r77, 0
  br i1 %r78, label %shadow.root.barrier.28, label %shadow.root.barrier.done.29

shadow.root.barrier.28:                           ; preds = %shadow.root.barrier.done.27
  call void @js_write_barrier_root_nanbox(i64 %r76) #9
  br label %shadow.root.barrier.done.29

shadow.root.barrier.done.29:                      ; preds = %shadow.root.barrier.28, %shadow.root.barrier.done.27
  %r79.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r79.rs4o = call i64 asm "", "=r,0"(i64 %r79.rs4i) #9
  %r79 = bitcast i64 %r79.rs4o to double
  %r80 = bitcast double %r79 to i64
  %r81 = and i64 %r80, 281474976710655
  %r82 = lshr i64 %r80, 48
  %r83 = and i64 %r82, 65533
  %r84 = icmp eq i64 %r83, 32765
  br i1 %r84, label %pget.recv_ok.31, label %pget.recv_other.36

pget.recv_sso.30:                                 ; preds = %pget.recv_other.36
  %r223 = lshr i64 %r80, 40
  %r224 = and i64 %r223, 255
  %r225 = uitofp nneg i64 %r224 to double
  br label %pget.recv_merge.34

pget.recv_ok.31:                                  ; preds = %shadow.root.barrier.done.29
  %r91 = icmp eq i64 %r82, 32767
  br i1 %r91, label %pget.strlen_heap.35, label %pget.recv_obj.38

pget.recv_bad.32:                                 ; preds = %pget.check_class_ref.37
  %r215 = icmp eq i64 %r80, 9222246136947933185
  %r216 = icmp eq i64 %r80, 9222246136947933186
  %r217 = or i1 %r215, %r216
  br i1 %r217, label %pget.throw_nullish.61, label %pget.recv_undef_return.62

pget.recv_class_ref.33:                           ; preds = %pget.check_class_ref.37
  %r87 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r88 = bitcast double %r87 to i64
  %r89 = and i64 %r88, 281474976710655
  %statepoint_token14 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532864, i64 %r80, i64 %r89, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated11, ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %rs4gc.s7) ]
  %r9015 = call double @llvm.experimental.gc.result.f64(token %statepoint_token14)
  %rs4gc.s5.relocated16 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token14, i32 0, i32 0) ; (%rs4gc.s5.relocated11, %rs4gc.s5.relocated11)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token14, i32 1, i32 1) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token14, i32 2, i32 2) ; (%rs4gc.s7, %rs4gc.s7)
  br label %pget.recv_merge.34

pget.recv_merge.34:                               ; preds = %pget.recv_undef_return.62, %pic.merge.53, %pget.strlen_heap.35, %pget.recv_class_ref.33, %pget.recv_sso.30
  %.0144 = phi ptr addrspace(1) [ %rs4gc.s7, %pget.strlen_heap.35 ], [ %.1145, %pic.merge.53 ], [ %rs4gc.s7, %pget.recv_sso.30 ], [ %rs4gc.s7.relocated, %pget.recv_class_ref.33 ], [ %rs4gc.s7.relocated32, %pget.recv_undef_return.62 ]
  %.0141 = phi ptr addrspace(1) [ %rs4gc.s6, %pget.strlen_heap.35 ], [ %.1142, %pic.merge.53 ], [ %rs4gc.s6, %pget.recv_sso.30 ], [ %rs4gc.s6.relocated, %pget.recv_class_ref.33 ], [ %rs4gc.s6.relocated31, %pget.recv_undef_return.62 ]
  %.4 = phi ptr addrspace(1) [ %rs4gc.s5.relocated11, %pget.strlen_heap.35 ], [ %.5, %pic.merge.53 ], [ %rs4gc.s5.relocated11, %pget.recv_sso.30 ], [ %rs4gc.s5.relocated16, %pget.recv_class_ref.33 ], [ %rs4gc.s5.relocated30, %pget.recv_undef_return.62 ]
  %r231 = phi double [ %r214, %pic.merge.53 ], [ %r22229, %pget.recv_undef_return.62 ], [ %r225, %pget.recv_sso.30 ], [ %r9015, %pget.recv_class_ref.33 ], [ %r230, %pget.strlen_heap.35 ]
  %r232.rs4i = ptrtoint ptr addrspace(1) %.0144 to i64
  %r232 = call i64 asm "", "=r,0"(i64 %r232.rs4i) #9
  %r233 = bitcast i64 %r232 to double
  %r234 = and i64 %r232, -281474976710656
  %r235 = icmp ult i64 %r234, 9221401712017801216
  %r236 = icmp ugt i64 %r234, 9223090561878065152
  %r237 = or i1 %r235, %r236
  %r238 = bitcast double %r231 to i64
  %r239 = and i64 %r238, -281474976710656
  %r240 = icmp ult i64 %r239, 9221401712017801216
  %r241 = icmp ugt i64 %r239, 9223090561878065152
  %r242 = or i1 %r240, %r241
  %r243 = and i1 %r237, %r242
  br i1 %r243, label %guarded_add.numeric.63, label %guarded_add.dynamic.64

pget.strlen_heap.35:                              ; preds = %pget.recv_ok.31
  %r226 = icmp ult i64 %r81, 4096
  %r227 = inttoptr i64 %r81 to ptr
  %r228 = select i1 %r226, ptr @perry_null_guard_zero_options_worker_ts, ptr %r227
  %r229 = load i32, ptr %r228, align 4
  %r230 = uitofp i32 %r229 to double
  br label %pget.recv_merge.34

pget.recv_other.36:                               ; preds = %shadow.root.barrier.done.29
  %r85 = icmp eq i64 %r82, 32761
  br i1 %r85, label %pget.recv_sso.30, label %pget.check_class_ref.37

pget.check_class_ref.37:                          ; preds = %pget.recv_other.36
  %r86 = icmp eq i64 %r82, 32766
  br i1 %r86, label %pget.recv_class_ref.33, label %pget.recv_bad.32

pget.recv_obj.38:                                 ; preds = %pget.recv_ok.31
  %r92 = icmp ugt i64 %r81, 1048575
  br i1 %r92, label %pic.recv_hdr.54, label %pic.miss.cold.51

pic.hit.39:                                       ; preds = %pic.token.55
  %r117 = getelementptr i64, ptr %r102, i64 1
  %r118 = load i64, ptr %r117, align 8
  %r119 = and i64 %r118, 1073741824
  %r120 = icmp ne i64 %r119, 0
  br i1 %r120, label %pic.hit.overflow.56, label %pic.hit.inline.57

pic.hit.live.40:                                  ; preds = %pic.hit.inline.57
  br label %pic.merge.53

pic.prefix.guard.41:                              ; preds = %pic.token.55
  %r133 = getelementptr i64, ptr %r102, i64 2
  %r134 = load i64, ptr %r133, align 8
  %r135 = icmp ne i64 %r134, 0
  br i1 %r135, label %pic.prefix.meta.42, label %pic.miss.50

pic.prefix.meta.42:                               ; preds = %pic.prefix.guard.41
  %r136 = add nuw nsw i64 %r81, 8
  %r137 = inttoptr i64 %r136 to ptr
  %r138 = load i64, ptr %r137, align 8
  %r139 = icmp ne i64 %r138, 0
  br i1 %r139, label %pic.prefix.token.43, label %pic.miss.50

pic.prefix.token.43:                              ; preds = %pic.prefix.meta.42
  %r140 = inttoptr i64 %r138 to ptr
  %r141 = getelementptr i64, ptr %r140, i64 6
  %r142 = load i64, ptr %r141, align 8
  %r143 = icmp eq i64 %r142, %r134
  br i1 %r143, label %pic.prefix.hit.44, label %pic.miss.50

pic.prefix.hit.44:                                ; preds = %pic.prefix.token.43
  %r144 = getelementptr i64, ptr %r102, i64 1
  %r145 = load i64, ptr %r144, align 8
  %r146 = shl i64 %r145, 3
  %r147 = add nuw nsw i64 %r81, 16
  %r148 = add i64 %r147, %r146
  %r149 = inttoptr i64 %r148 to ptr
  %r150 = load double, ptr %r149, align 8
  br label %pic.merge.53

pic.desc.classify.45:                             ; preds = %pic.recv_hdr.54
  %r106 = and i1 %r96, %r103
  br i1 %r106, label %pic.desc.prefix.guard.46, label %pic.miss.cold.51

pic.desc.prefix.guard.46:                         ; preds = %pic.desc.classify.45
  %r151 = getelementptr i64, ptr %r102, i64 2
  %r152 = load i64, ptr %r151, align 8
  %r153 = icmp ne i64 %r152, 0
  br i1 %r153, label %pic.desc.prefix.meta.47, label %pic.miss.cold.51

pic.desc.prefix.meta.47:                          ; preds = %pic.desc.prefix.guard.46
  %r154 = add nuw nsw i64 %r81, 8
  %r155 = inttoptr i64 %r154 to ptr
  %r156 = load i64, ptr %r155, align 8
  %r157 = icmp ne i64 %r156, 0
  br i1 %r157, label %pic.desc.prefix.token.48, label %pic.miss.cold.51

pic.desc.prefix.token.48:                         ; preds = %pic.desc.prefix.meta.47
  %r158 = inttoptr i64 %r156 to ptr
  %r159 = getelementptr i64, ptr %r158, i64 6
  %r160 = load i64, ptr %r159, align 8
  %r161 = icmp eq i64 %r160, %r152
  br i1 %r161, label %pic.desc.prefix.hit.49, label %pic.miss.cold.51

pic.desc.prefix.hit.49:                           ; preds = %pic.desc.prefix.token.48
  %r162 = getelementptr i64, ptr %r102, i64 1
  %r163 = load i64, ptr %r162, align 8
  %r164 = shl i64 %r163, 3
  %r165 = add nuw nsw i64 %r81, 16
  %r166 = add i64 %r165, %r164
  %r167 = inttoptr i64 %r166 to ptr
  %r168 = load double, ptr %r167, align 8
  br label %pic.merge.53

pic.miss.50:                                      ; preds = %pic.hit.inline.57, %pic.prefix.token.43, %pic.prefix.meta.42, %pic.prefix.guard.41
  %r169 = getelementptr i64, ptr %r102, i64 3
  %r170 = load i64, ptr %r169, align 8
  %r171 = icmp sgt i64 %r170, 0
  br i1 %r171, label %pic.ways.58, label %pic.miss.call.52

pic.miss.cold.51:                                 ; preds = %pic.desc.prefix.token.48, %pic.desc.prefix.meta.47, %pic.desc.prefix.guard.46, %pic.desc.classify.45, %pget.recv_obj.38
  br label %pic.miss.call.52

pic.miss.call.52:                                 ; preds = %pic.way.load.59, %pic.ways.58, %pic.miss.cold.51, %pic.miss.50
  %r210 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r211 = bitcast double %r210 to i64
  %r212 = and i64 %r211, 281474976710655
  %statepoint_token17 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r81, i64 %r212, ptr @perry_ic_options_worker_ts__1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated11, ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %rs4gc.s7) ]
  %r21318 = call double @llvm.experimental.gc.result.f64(token %statepoint_token17)
  %rs4gc.s5.relocated19 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token17, i32 0, i32 0) ; (%rs4gc.s5.relocated11, %rs4gc.s5.relocated11)
  %rs4gc.s6.relocated20 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token17, i32 1, i32 1) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s7.relocated21 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token17, i32 2, i32 2) ; (%rs4gc.s7, %rs4gc.s7)
  br label %pic.merge.53

pic.merge.53:                                     ; preds = %pic.way.live.60, %pic.hit.overflow.56, %pic.miss.call.52, %pic.desc.prefix.hit.49, %pic.prefix.hit.44, %pic.hit.live.40
  %.1145 = phi ptr addrspace(1) [ %rs4gc.s7.relocated26, %pic.hit.overflow.56 ], [ %rs4gc.s7.relocated21, %pic.miss.call.52 ], [ %rs4gc.s7, %pic.way.live.60 ], [ %rs4gc.s7, %pic.hit.live.40 ], [ %rs4gc.s7, %pic.prefix.hit.44 ], [ %rs4gc.s7, %pic.desc.prefix.hit.49 ]
  %.1142 = phi ptr addrspace(1) [ %rs4gc.s6.relocated25, %pic.hit.overflow.56 ], [ %rs4gc.s6.relocated20, %pic.miss.call.52 ], [ %rs4gc.s6, %pic.way.live.60 ], [ %rs4gc.s6, %pic.hit.live.40 ], [ %rs4gc.s6, %pic.prefix.hit.44 ], [ %rs4gc.s6, %pic.desc.prefix.hit.49 ]
  %.5 = phi ptr addrspace(1) [ %rs4gc.s5.relocated24, %pic.hit.overflow.56 ], [ %rs4gc.s5.relocated19, %pic.miss.call.52 ], [ %rs4gc.s5.relocated11, %pic.way.live.60 ], [ %rs4gc.s5.relocated11, %pic.hit.live.40 ], [ %rs4gc.s5.relocated11, %pic.prefix.hit.44 ], [ %rs4gc.s5.relocated11, %pic.desc.prefix.hit.49 ]
  %r214 = phi double [ %r130, %pic.hit.live.40 ], [ %r12523, %pic.hit.overflow.56 ], [ %r150, %pic.prefix.hit.44 ], [ %r168, %pic.desc.prefix.hit.49 ], [ %r207, %pic.way.live.60 ], [ %r21318, %pic.miss.call.52 ]
  br label %pget.recv_merge.34

pic.recv_hdr.54:                                  ; preds = %pget.recv_obj.38
  %r93 = sub nuw nsw i64 %r81, 8
  %r94 = inttoptr i64 %r93 to ptr
  %r95 = load i8, ptr %r94, align 1
  %r96 = icmp eq i8 %r95, 2
  %r97 = sub nuw nsw i64 %r81, 6
  %r98 = inttoptr i64 %r97 to ptr
  %r99 = load i16, ptr %r98, align 2
  %r100 = and i16 %r99, 2048
  %r101 = icmp eq i16 %r100, 0
  %r102 = load ptr, ptr @perry_ic_options_worker_ts__1, align 8
  %r103 = icmp ne ptr %r102, null
  %r104 = and i1 %r96, %r101
  %r105 = and i1 %r104, %r103
  br i1 %r105, label %pic.token.55, label %pic.desc.classify.45

pic.token.55:                                     ; preds = %pic.recv_hdr.54
  %r107 = add nuw nsw i64 %r81, 4
  %r108 = inttoptr i64 %r107 to ptr
  %r109 = load i32, ptr %r108, align 4
  %r110 = zext i32 %r109 to i64
  %r111 = or i64 %r110, 4611686018427387904
  %r112 = icmp ne i32 %r109, 0
  %r113 = getelementptr i64, ptr %r102, i64 0
  %r114 = load i64, ptr %r113, align 8
  %r115 = icmp eq i64 %r111, %r114
  %r116 = and i1 %r115, %r112
  br i1 %r116, label %pic.hit.39, label %pic.prefix.guard.41

pic.hit.overflow.56:                              ; preds = %pic.hit.39
  %r121 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r122 = bitcast double %r121 to i64
  %r123 = and i64 %r122, 281474976710655
  %r124 = trunc i64 %r118 to i32
  %statepoint_token22 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r81, i64 %r123, i32 %r124, ptr @perry_ic_options_worker_ts__1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated11, ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %rs4gc.s7) ]
  %r12523 = call double @llvm.experimental.gc.result.f64(token %statepoint_token22)
  %rs4gc.s5.relocated24 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token22, i32 0, i32 0) ; (%rs4gc.s5.relocated11, %rs4gc.s5.relocated11)
  %rs4gc.s6.relocated25 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token22, i32 1, i32 1) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s7.relocated26 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token22, i32 2, i32 2) ; (%rs4gc.s7, %rs4gc.s7)
  br label %pic.merge.53

pic.hit.inline.57:                                ; preds = %pic.hit.39
  %r126 = shl i64 %r118, 3
  %r127 = add nuw nsw i64 %r81, 16
  %r128 = add i64 %r127, %r126
  %r129 = inttoptr i64 %r128 to ptr
  %r130 = load double, ptr %r129, align 8
  %r131 = bitcast double %r130 to i64
  %r132 = icmp eq i64 %r131, 9222246136947933200
  br i1 %r132, label %pic.miss.50, label %pic.hit.live.40

pic.ways.58:                                      ; preds = %pic.miss.50
  %r172 = getelementptr i64, ptr %r102, i64 4
  %r173 = load i64, ptr %r172, align 8
  %r174 = icmp eq i64 %r173, %r111
  %r175 = getelementptr i64, ptr %r102, i64 5
  %r176 = load i64, ptr %r175, align 8
  %r177 = select i1 %r174, i64 %r176, i64 0
  %r178 = getelementptr i64, ptr %r102, i64 6
  %r179 = load i64, ptr %r178, align 8
  %r180 = icmp eq i64 %r179, %r111
  %r181 = getelementptr i64, ptr %r102, i64 7
  %r182 = load i64, ptr %r181, align 8
  %r183 = select i1 %r180, i64 %r182, i64 0
  %r184 = getelementptr i64, ptr %r102, i64 8
  %r185 = load i64, ptr %r184, align 8
  %r186 = icmp eq i64 %r185, %r111
  %r187 = getelementptr i64, ptr %r102, i64 9
  %r188 = load i64, ptr %r187, align 8
  %r189 = select i1 %r186, i64 %r188, i64 0
  %r190 = getelementptr i64, ptr %r102, i64 10
  %r191 = load i64, ptr %r190, align 8
  %r192 = icmp eq i64 %r191, %r111
  %r193 = getelementptr i64, ptr %r102, i64 11
  %r194 = load i64, ptr %r193, align 8
  %r195 = select i1 %r192, i64 %r194, i64 0
  %r196 = or i1 %r174, %r180
  %r197 = select i1 %r174, i64 %r177, i64 %r183
  %r198 = or i1 %r186, %r192
  %r199 = select i1 %r186, i64 %r189, i64 %r195
  %r200 = or i1 %r196, %r198
  %r201 = select i1 %r196, i64 %r197, i64 %r199
  %r202 = and i1 %r112, %r200
  br i1 %r202, label %pic.way.load.59, label %pic.miss.call.52

pic.way.load.59:                                  ; preds = %pic.ways.58
  %r203 = shl i64 %r201, 3
  %r204 = add nuw nsw i64 %r81, 16
  %r205 = add i64 %r204, %r203
  %r206 = inttoptr i64 %r205 to ptr
  %r207 = load double, ptr %r206, align 8
  %r208 = bitcast double %r207 to i64
  %r209 = icmp eq i64 %r208, 9222246136947933200
  br i1 %r209, label %pic.miss.call.52, label %pic.way.live.60

pic.way.live.60:                                  ; preds = %pic.way.load.59
  br label %pic.merge.53

pget.throw_nullish.61:                            ; preds = %pget.recv_bad.32
  %r218 = zext i1 %r216 to i32
  %statepoint_token27 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r218, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.62:                        ; preds = %pget.recv_bad.32
  %r219 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r220 = bitcast double %r219 to i64
  %r221 = and i64 %r220, 281474976710655
  %statepoint_token28 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r80, i64 %r221, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated11, ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %rs4gc.s7) ]
  %r22229 = call double @llvm.experimental.gc.result.f64(token %statepoint_token28)
  %rs4gc.s5.relocated30 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token28, i32 0, i32 0) ; (%rs4gc.s5.relocated11, %rs4gc.s5.relocated11)
  %rs4gc.s6.relocated31 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token28, i32 1, i32 1) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s7.relocated32 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token28, i32 2, i32 2) ; (%rs4gc.s7, %rs4gc.s7)
  br label %pget.recv_merge.34

guarded_add.numeric.63:                           ; preds = %pget.recv_merge.34
  %r244 = fadd double %r233, %r231
  br label %guarded_add.merge.65

guarded_add.dynamic.64:                           ; preds = %pget.recv_merge.34
  %statepoint_token33 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r233, double %r231, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4, ptr addrspace(1) %.0141) ]
  %r24534 = call double @llvm.experimental.gc.result.f64(token %statepoint_token33)
  %rs4gc.s5.relocated35 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token33, i32 0, i32 0) ; (%.4, %.4)
  %rs4gc.s6.relocated36 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token33, i32 1, i32 1) ; (%.0141, %.0141)
  br label %guarded_add.merge.65

guarded_add.merge.65:                             ; preds = %guarded_add.dynamic.64, %guarded_add.numeric.63
  %.2143 = phi ptr addrspace(1) [ %.0141, %guarded_add.numeric.63 ], [ %rs4gc.s6.relocated36, %guarded_add.dynamic.64 ]
  %.6 = phi ptr addrspace(1) [ %.4, %guarded_add.numeric.63 ], [ %rs4gc.s5.relocated35, %guarded_add.dynamic.64 ]
  %r246 = phi double [ %r244, %guarded_add.numeric.63 ], [ %r24534, %guarded_add.dynamic.64 ]
  %r247.rs4i = ptrtoint ptr addrspace(1) %.2143 to i64
  %r247.rs4o = call i64 asm "", "=r,0"(i64 %r247.rs4i) #9
  %r247 = bitcast i64 %r247.rs4o to double
  %r248 = bitcast double %r247 to i64
  %r249 = and i64 %r248, -281474976710656
  %r250 = icmp ne i64 %r249, 9223090561878065152
  br i1 %r250, label %str_addref.done.67, label %str_addref.call.66

str_addref.call.66:                               ; preds = %guarded_add.merge.65
  call void @js_string_addref_if_heap_string(double %r247) #9
  br label %str_addref.done.67

str_addref.done.67:                               ; preds = %str_addref.call.66, %guarded_add.merge.65
  %r1038.rs4i = ptrtoint ptr addrspace(1) %.2143 to i64
  %r1038.rs4o = call i64 asm "", "=r,0"(i64 %r1038.rs4i) #9
  %r1038 = bitcast i64 %r1038.rs4o to double
  store double %r1038, ptr @perry_global_options_worker_ts__6, align 8
  %r1037.rs4i = ptrtoint ptr addrspace(1) %.2143 to i64
  %r1037.rs4o = call i64 asm "", "=r,0"(i64 %r1037.rs4i) #9
  %r1037 = bitcast i64 %r1037.rs4o to double
  %r251 = bitcast double %r1037 to i64
  %r1035.rs4i = ptrtoint ptr addrspace(1) %.2143 to i64
  %r1035.rs4o = call i64 asm "", "=r,0"(i64 %r1035.rs4i) #9
  %r1035 = bitcast i64 %r1035.rs4o to double
  %r1036 = bitcast double %r1035 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1036) #9
  %r252 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r253 = icmp ne i32 %r252, 0
  br i1 %r253, label %gcpoll.68, label %gcpoll.done.69

gcpoll.68:                                        ; preds = %str_addref.done.67
  %statepoint_token37 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6) ]
  %rs4gc.s5.relocated38 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token37, i32 0, i32 0) ; (%.6, %.6)
  br label %gcpoll.done.69

gcpoll.done.69:                                   ; preds = %gcpoll.68, %str_addref.done.67
  %.7 = phi ptr addrspace(1) [ %rs4gc.s5.relocated38, %gcpoll.68 ], [ %.6, %str_addref.done.67 ]
  br label %for.update.20

streqlit.tag.70:                                  ; preds = %if.else.11
  %r263 = lshr i64 %r260, 48
  %r264 = icmp eq i64 %r263, 32767
  %r265 = and i64 %r260, 281474976710655
  %r266 = icmp ugt i64 %r265, 4095
  %r267 = and i1 %r264, %r266
  br i1 %r267, label %streqlit.len.71, label %streqlit.false.76

streqlit.len.71:                                  ; preds = %streqlit.tag.70
  %r268 = inttoptr i64 %r265 to ptr
  %r269 = getelementptr inbounds nuw i8, ptr %r268, i64 4
  %r270 = load i32, ptr %r269, align 4
  %r271 = icmp eq i32 %r270, 6
  br i1 %r271, label %streqlit.b0.72, label %streqlit.false.76

streqlit.b0.72:                                   ; preds = %streqlit.len.71
  %r272 = getelementptr inbounds nuw i8, ptr %r268, i64 20
  %r273 = load i8, ptr %r272, align 1
  %r274 = icmp eq i8 %r273, 112
  br i1 %r274, label %streqlit.bl.73, label %streqlit.false.76

streqlit.bl.73:                                   ; preds = %streqlit.b0.72
  %r275 = getelementptr inbounds nuw i8, ptr %r268, i64 25
  %r276 = load i8, ptr %r275, align 1
  %r277 = icmp eq i8 %r276, 121
  br i1 %r277, label %streqlit.slow.74, label %streqlit.false.76

streqlit.slow.74:                                 ; preds = %streqlit.bl.73
  %r278 = and i64 %r261, 281474976710655
  %statepoint_token39 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r265, i64 %r278, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0) ]
  %r27940 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token39)
  %rs4gc.s5.relocated41 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token39, i32 0, i32 0) ; (%.0, %.0)
  %r280 = icmp ne i32 %r27940, 0
  br label %streqlit.merge.77

streqlit.true.75:                                 ; preds = %if.else.11
  br label %streqlit.merge.77

streqlit.false.76:                                ; preds = %streqlit.bl.73, %streqlit.b0.72, %streqlit.len.71, %streqlit.tag.70
  br label %streqlit.merge.77

streqlit.merge.77:                                ; preds = %streqlit.false.76, %streqlit.true.75, %streqlit.slow.74
  %.8 = phi ptr addrspace(1) [ %.0, %streqlit.true.75 ], [ %rs4gc.s5.relocated41, %streqlit.slow.74 ], [ %.0, %streqlit.false.76 ]
  %r281 = phi i1 [ true, %streqlit.true.75 ], [ false, %streqlit.false.76 ], [ %r280, %streqlit.slow.74 ]
  %r282 = select i1 %r281, i64 9222246136947933188, i64 9222246136947933187
  %r283 = bitcast i64 %r282 to double
  %r284 = icmp eq i64 %r282, 9222246136947933188
  br i1 %r284, label %if.then.78, label %if.else.79

if.then.78:                                       ; preds = %streqlit.merge.77
  %r289.rs4i = ptrtoint ptr addrspace(1) %.8 to i64
  %r289.rs4o = call i64 asm "", "=r,0"(i64 %r289.rs4i) #9
  %r289 = bitcast i64 %r289.rs4o to double
  %r290 = bitcast double %r289 to i64
  %r291 = and i64 %r290, -281474976710656
  %r292 = icmp ult i64 %r291, 9221401712017801216
  %r293 = icmp ugt i64 %r291, 9223090561878065152
  %r294 = or i1 %r292, %r293
  br i1 %r294, label %for.bound_i32.number.81, label %for.bound_i32.merge.83

if.else.79:                                       ; preds = %streqlit.merge.77
  %r511 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r512 = load double, ptr @options_worker_ts_.str.3.handle, align 8
  %r513 = bitcast double %r511 to i64
  %r514 = bitcast double %r512 to i64
  %r515 = icmp eq i64 %r513, %r514
  br i1 %r515, label %streqlit.true.144, label %streqlit.sso.138

if.merge.80:                                      ; preds = %if.merge.149, %for.exit.89
  %r2.2 = phi double [ %r2.3, %for.exit.89 ], [ %r2.4, %if.merge.149 ]
  br label %if.merge.12

for.bound_i32.number.81:                          ; preds = %if.then.78
  %r295 = fcmp oge double %r289, 0xC1E0000000000000
  %r296 = fcmp ole double %r289, 0x41DFFFFFFFC00000
  %r297 = and i1 %r295, %r296
  br i1 %r297, label %for.bound_i32.convert.82, label %for.bound_i32.merge.83

for.bound_i32.convert.82:                         ; preds = %for.bound_i32.number.81
  %r298 = fptosi double %r289 to i32
  %r299 = sitofp i32 %r298 to double
  %r300 = fcmp oeq double %r299, %r289
  br i1 %r300, label %for.counter_i32.range.84, label %for.bound_i32.merge.83

for.bound_i32.merge.83:                           ; preds = %for.counter_i32.convert.85, %for.bound_i32.convert.82, %for.bound_i32.number.81, %if.then.78
  %r288.0 = phi i32 [ %r298, %for.counter_i32.convert.85 ], [ 0, %if.then.78 ], [ %r298, %for.bound_i32.convert.82 ], [ 0, %for.bound_i32.number.81 ]
  %r287.0 = phi i1 [ true, %for.counter_i32.convert.85 ], [ false, %if.then.78 ], [ false, %for.bound_i32.convert.82 ], [ false, %for.bound_i32.number.81 ]
  br label %for.cond.86

for.counter_i32.range.84:                         ; preds = %for.bound_i32.convert.82
  br label %for.counter_i32.convert.85

for.counter_i32.convert.85:                       ; preds = %for.counter_i32.range.84
  br label %for.bound_i32.merge.83

for.cond.86:                                      ; preds = %for.update.88, %for.bound_i32.merge.83
  %.9 = phi ptr addrspace(1) [ %.8, %for.bound_i32.merge.83 ], [ %.15, %for.update.88 ]
  %r286.1 = phi i32 [ 0, %for.bound_i32.merge.83 ], [ %r510, %for.update.88 ]
  %r285.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.83 ], [ %r508, %for.update.88 ]
  %r2.3 = phi double [ 0.000000e+00, %for.bound_i32.merge.83 ], [ %r499, %for.update.88 ]
  br i1 %r287.0, label %for.cond.fast.90, label %for.cond.slow.91

for.body.87:                                      ; preds = %gcpoll.done.93, %for.cond.fast.90
  %.10 = phi ptr addrspace(1) [ %.9, %for.cond.fast.90 ], [ %.11, %gcpoll.done.93 ]
  %r321 = load double, ptr @perry_global_options_worker_ts__4, align 8
  %statepoint_token42 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r321, double 0x7FFC000000000002, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10) ]
  %r32243 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token42)
  %rs4gc.s5.relocated44 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token42, i32 0, i32 0) ; (%.10, %.10)
  %r323 = bitcast i64 %r32243 to double
  %rs4gc.b8 = bitcast double %r323 to i64
  %rs4gc.s8 = inttoptr i64 %rs4gc.b8 to ptr addrspace(1)
  %r324.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r324 = call i64 asm "", "=r,0"(i64 %r324.rs4i) #9
  %r325 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r326 = icmp ne i32 %r325, 0
  br i1 %r326, label %shadow.root.barrier.94, label %shadow.root.barrier.done.95

for.update.88:                                    ; preds = %gcpoll.done.137
  %r508 = fadd double %r285.0, 1.000000e+00
  %r510 = add i32 %r286.1, 1
  br label %for.cond.86

for.exit.89:                                      ; preds = %gcpoll.done.93, %for.cond.fast.90
  br label %if.merge.80

for.cond.fast.90:                                 ; preds = %for.cond.86
  %r311 = icmp slt i32 %r286.1, %r288.0
  br i1 %r311, label %for.body.87, label %for.exit.89

for.cond.slow.91:                                 ; preds = %for.cond.86
  %r313.rs4i = ptrtoint ptr addrspace(1) %.9 to i64
  %r313.rs4o = call i64 asm "", "=r,0"(i64 %r313.rs4i) #9
  %r313 = bitcast i64 %r313.rs4o to double
  %r314 = fcmp olt double %r285.0, %r313
  %r315 = select i1 %r314, i64 9222246136947933188, i64 9222246136947933187
  %r316 = bitcast i64 %r315 to double
  %r318 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r319 = icmp ne i32 %r318, 0
  br i1 %r319, label %gcpoll.92, label %gcpoll.done.93

gcpoll.92:                                        ; preds = %for.cond.slow.91
  %statepoint_token45 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.9) ]
  %rs4gc.s5.relocated46 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token45, i32 0, i32 0) ; (%.9, %.9)
  br label %gcpoll.done.93

gcpoll.done.93:                                   ; preds = %gcpoll.92, %for.cond.slow.91
  %.11 = phi ptr addrspace(1) [ %rs4gc.s5.relocated46, %gcpoll.92 ], [ %.9, %for.cond.slow.91 ]
  %r317 = icmp eq i64 %r315, 9222246136947933188
  br i1 %r317, label %for.body.87, label %for.exit.89

shadow.root.barrier.94:                           ; preds = %for.body.87
  call void @js_write_barrier_root_nanbox(i64 %r324) #9
  br label %shadow.root.barrier.done.95

shadow.root.barrier.done.95:                      ; preds = %shadow.root.barrier.94, %for.body.87
  %r328 = bitcast double %r2.3 to i64
  %rs4gc.s9 = inttoptr i64 %r328 to ptr addrspace(1)
  %r329.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9 to i64
  %r329 = call i64 asm "", "=r,0"(i64 %r329.rs4i) #9
  %r330 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r331 = icmp ne i32 %r330, 0
  br i1 %r331, label %shadow.root.barrier.96, label %shadow.root.barrier.done.97

shadow.root.barrier.96:                           ; preds = %shadow.root.barrier.done.95
  call void @js_write_barrier_root_nanbox(i64 %r329) #9
  br label %shadow.root.barrier.done.97

shadow.root.barrier.done.97:                      ; preds = %shadow.root.barrier.96, %shadow.root.barrier.done.95
  %r332.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r332.rs4o = call i64 asm "", "=r,0"(i64 %r332.rs4i) #9
  %r332 = bitcast i64 %r332.rs4o to double
  %r333 = bitcast double %r332 to i64
  %r334 = and i64 %r333, 281474976710655
  %r335 = lshr i64 %r333, 48
  %r336 = and i64 %r335, 65533
  %r337 = icmp eq i64 %r336, 32765
  br i1 %r337, label %pget.recv_ok.99, label %pget.recv_other.104

pget.recv_sso.98:                                 ; preds = %pget.recv_other.104
  %r476 = lshr i64 %r333, 40
  %r477 = and i64 %r476, 255
  %r478 = uitofp nneg i64 %r477 to double
  br label %pget.recv_merge.102

pget.recv_ok.99:                                  ; preds = %shadow.root.barrier.done.97
  %r344 = icmp eq i64 %r335, 32767
  br i1 %r344, label %pget.strlen_heap.103, label %pget.recv_obj.106

pget.recv_bad.100:                                ; preds = %pget.check_class_ref.105
  %r468 = icmp eq i64 %r333, 9222246136947933185
  %r469 = icmp eq i64 %r333, 9222246136947933186
  %r470 = or i1 %r468, %r469
  br i1 %r470, label %pget.throw_nullish.129, label %pget.recv_undef_return.130

pget.recv_class_ref.101:                          ; preds = %pget.check_class_ref.105
  %r340 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r341 = bitcast double %r340 to i64
  %r342 = and i64 %r341, 281474976710655
  %statepoint_token47 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532866, i64 %r333, i64 %r342, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated44, ptr addrspace(1) %rs4gc.s8, ptr addrspace(1) %rs4gc.s9) ]
  %r34348 = call double @llvm.experimental.gc.result.f64(token %statepoint_token47)
  %rs4gc.s5.relocated49 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token47, i32 0, i32 0) ; (%rs4gc.s5.relocated44, %rs4gc.s5.relocated44)
  %rs4gc.s8.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token47, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.s9.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token47, i32 2, i32 2) ; (%rs4gc.s9, %rs4gc.s9)
  br label %pget.recv_merge.102

pget.recv_merge.102:                              ; preds = %pget.recv_undef_return.130, %pic.merge.121, %pget.strlen_heap.103, %pget.recv_class_ref.101, %pget.recv_sso.98
  %.0149 = phi ptr addrspace(1) [ %rs4gc.s9, %pget.strlen_heap.103 ], [ %.1150, %pic.merge.121 ], [ %rs4gc.s9, %pget.recv_sso.98 ], [ %rs4gc.s9.relocated, %pget.recv_class_ref.101 ], [ %rs4gc.s9.relocated65, %pget.recv_undef_return.130 ]
  %.0146 = phi ptr addrspace(1) [ %rs4gc.s8, %pget.strlen_heap.103 ], [ %.1147, %pic.merge.121 ], [ %rs4gc.s8, %pget.recv_sso.98 ], [ %rs4gc.s8.relocated, %pget.recv_class_ref.101 ], [ %rs4gc.s8.relocated64, %pget.recv_undef_return.130 ]
  %.12 = phi ptr addrspace(1) [ %rs4gc.s5.relocated44, %pget.strlen_heap.103 ], [ %.13, %pic.merge.121 ], [ %rs4gc.s5.relocated44, %pget.recv_sso.98 ], [ %rs4gc.s5.relocated49, %pget.recv_class_ref.101 ], [ %rs4gc.s5.relocated63, %pget.recv_undef_return.130 ]
  %r484 = phi double [ %r467, %pic.merge.121 ], [ %r47562, %pget.recv_undef_return.130 ], [ %r478, %pget.recv_sso.98 ], [ %r34348, %pget.recv_class_ref.101 ], [ %r483, %pget.strlen_heap.103 ]
  %r485.rs4i = ptrtoint ptr addrspace(1) %.0149 to i64
  %r485 = call i64 asm "", "=r,0"(i64 %r485.rs4i) #9
  %r486 = bitcast i64 %r485 to double
  %r487 = and i64 %r485, -281474976710656
  %r488 = icmp ult i64 %r487, 9221401712017801216
  %r489 = icmp ugt i64 %r487, 9223090561878065152
  %r490 = or i1 %r488, %r489
  %r491 = bitcast double %r484 to i64
  %r492 = and i64 %r491, -281474976710656
  %r493 = icmp ult i64 %r492, 9221401712017801216
  %r494 = icmp ugt i64 %r492, 9223090561878065152
  %r495 = or i1 %r493, %r494
  %r496 = and i1 %r490, %r495
  br i1 %r496, label %guarded_add.numeric.131, label %guarded_add.dynamic.132

pget.strlen_heap.103:                             ; preds = %pget.recv_ok.99
  %r479 = icmp ult i64 %r334, 4096
  %r480 = inttoptr i64 %r334 to ptr
  %r481 = select i1 %r479, ptr @perry_null_guard_zero_options_worker_ts, ptr %r480
  %r482 = load i32, ptr %r481, align 4
  %r483 = uitofp i32 %r482 to double
  br label %pget.recv_merge.102

pget.recv_other.104:                              ; preds = %shadow.root.barrier.done.97
  %r338 = icmp eq i64 %r335, 32761
  br i1 %r338, label %pget.recv_sso.98, label %pget.check_class_ref.105

pget.check_class_ref.105:                         ; preds = %pget.recv_other.104
  %r339 = icmp eq i64 %r335, 32766
  br i1 %r339, label %pget.recv_class_ref.101, label %pget.recv_bad.100

pget.recv_obj.106:                                ; preds = %pget.recv_ok.99
  %r345 = icmp ugt i64 %r334, 1048575
  br i1 %r345, label %pic.recv_hdr.122, label %pic.miss.cold.119

pic.hit.107:                                      ; preds = %pic.token.123
  %r370 = getelementptr i64, ptr %r355, i64 1
  %r371 = load i64, ptr %r370, align 8
  %r372 = and i64 %r371, 1073741824
  %r373 = icmp ne i64 %r372, 0
  br i1 %r373, label %pic.hit.overflow.124, label %pic.hit.inline.125

pic.hit.live.108:                                 ; preds = %pic.hit.inline.125
  br label %pic.merge.121

pic.prefix.guard.109:                             ; preds = %pic.token.123
  %r386 = getelementptr i64, ptr %r355, i64 2
  %r387 = load i64, ptr %r386, align 8
  %r388 = icmp ne i64 %r387, 0
  br i1 %r388, label %pic.prefix.meta.110, label %pic.miss.118

pic.prefix.meta.110:                              ; preds = %pic.prefix.guard.109
  %r389 = add nuw nsw i64 %r334, 8
  %r390 = inttoptr i64 %r389 to ptr
  %r391 = load i64, ptr %r390, align 8
  %r392 = icmp ne i64 %r391, 0
  br i1 %r392, label %pic.prefix.token.111, label %pic.miss.118

pic.prefix.token.111:                             ; preds = %pic.prefix.meta.110
  %r393 = inttoptr i64 %r391 to ptr
  %r394 = getelementptr i64, ptr %r393, i64 6
  %r395 = load i64, ptr %r394, align 8
  %r396 = icmp eq i64 %r395, %r387
  br i1 %r396, label %pic.prefix.hit.112, label %pic.miss.118

pic.prefix.hit.112:                               ; preds = %pic.prefix.token.111
  %r397 = getelementptr i64, ptr %r355, i64 1
  %r398 = load i64, ptr %r397, align 8
  %r399 = shl i64 %r398, 3
  %r400 = add nuw nsw i64 %r334, 16
  %r401 = add i64 %r400, %r399
  %r402 = inttoptr i64 %r401 to ptr
  %r403 = load double, ptr %r402, align 8
  br label %pic.merge.121

pic.desc.classify.113:                            ; preds = %pic.recv_hdr.122
  %r359 = and i1 %r349, %r356
  br i1 %r359, label %pic.desc.prefix.guard.114, label %pic.miss.cold.119

pic.desc.prefix.guard.114:                        ; preds = %pic.desc.classify.113
  %r404 = getelementptr i64, ptr %r355, i64 2
  %r405 = load i64, ptr %r404, align 8
  %r406 = icmp ne i64 %r405, 0
  br i1 %r406, label %pic.desc.prefix.meta.115, label %pic.miss.cold.119

pic.desc.prefix.meta.115:                         ; preds = %pic.desc.prefix.guard.114
  %r407 = add nuw nsw i64 %r334, 8
  %r408 = inttoptr i64 %r407 to ptr
  %r409 = load i64, ptr %r408, align 8
  %r410 = icmp ne i64 %r409, 0
  br i1 %r410, label %pic.desc.prefix.token.116, label %pic.miss.cold.119

pic.desc.prefix.token.116:                        ; preds = %pic.desc.prefix.meta.115
  %r411 = inttoptr i64 %r409 to ptr
  %r412 = getelementptr i64, ptr %r411, i64 6
  %r413 = load i64, ptr %r412, align 8
  %r414 = icmp eq i64 %r413, %r405
  br i1 %r414, label %pic.desc.prefix.hit.117, label %pic.miss.cold.119

pic.desc.prefix.hit.117:                          ; preds = %pic.desc.prefix.token.116
  %r415 = getelementptr i64, ptr %r355, i64 1
  %r416 = load i64, ptr %r415, align 8
  %r417 = shl i64 %r416, 3
  %r418 = add nuw nsw i64 %r334, 16
  %r419 = add i64 %r418, %r417
  %r420 = inttoptr i64 %r419 to ptr
  %r421 = load double, ptr %r420, align 8
  br label %pic.merge.121

pic.miss.118:                                     ; preds = %pic.hit.inline.125, %pic.prefix.token.111, %pic.prefix.meta.110, %pic.prefix.guard.109
  %r422 = getelementptr i64, ptr %r355, i64 3
  %r423 = load i64, ptr %r422, align 8
  %r424 = icmp sgt i64 %r423, 0
  br i1 %r424, label %pic.ways.126, label %pic.miss.call.120

pic.miss.cold.119:                                ; preds = %pic.desc.prefix.token.116, %pic.desc.prefix.meta.115, %pic.desc.prefix.guard.114, %pic.desc.classify.113, %pget.recv_obj.106
  br label %pic.miss.call.120

pic.miss.call.120:                                ; preds = %pic.way.load.127, %pic.ways.126, %pic.miss.cold.119, %pic.miss.118
  %r463 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r464 = bitcast double %r463 to i64
  %r465 = and i64 %r464, 281474976710655
  %statepoint_token50 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r334, i64 %r465, ptr @perry_ic_options_worker_ts__3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated44, ptr addrspace(1) %rs4gc.s8, ptr addrspace(1) %rs4gc.s9) ]
  %r46651 = call double @llvm.experimental.gc.result.f64(token %statepoint_token50)
  %rs4gc.s5.relocated52 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token50, i32 0, i32 0) ; (%rs4gc.s5.relocated44, %rs4gc.s5.relocated44)
  %rs4gc.s8.relocated53 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token50, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.s9.relocated54 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token50, i32 2, i32 2) ; (%rs4gc.s9, %rs4gc.s9)
  br label %pic.merge.121

pic.merge.121:                                    ; preds = %pic.way.live.128, %pic.hit.overflow.124, %pic.miss.call.120, %pic.desc.prefix.hit.117, %pic.prefix.hit.112, %pic.hit.live.108
  %.1150 = phi ptr addrspace(1) [ %rs4gc.s9.relocated59, %pic.hit.overflow.124 ], [ %rs4gc.s9.relocated54, %pic.miss.call.120 ], [ %rs4gc.s9, %pic.way.live.128 ], [ %rs4gc.s9, %pic.hit.live.108 ], [ %rs4gc.s9, %pic.prefix.hit.112 ], [ %rs4gc.s9, %pic.desc.prefix.hit.117 ]
  %.1147 = phi ptr addrspace(1) [ %rs4gc.s8.relocated58, %pic.hit.overflow.124 ], [ %rs4gc.s8.relocated53, %pic.miss.call.120 ], [ %rs4gc.s8, %pic.way.live.128 ], [ %rs4gc.s8, %pic.hit.live.108 ], [ %rs4gc.s8, %pic.prefix.hit.112 ], [ %rs4gc.s8, %pic.desc.prefix.hit.117 ]
  %.13 = phi ptr addrspace(1) [ %rs4gc.s5.relocated57, %pic.hit.overflow.124 ], [ %rs4gc.s5.relocated52, %pic.miss.call.120 ], [ %rs4gc.s5.relocated44, %pic.way.live.128 ], [ %rs4gc.s5.relocated44, %pic.hit.live.108 ], [ %rs4gc.s5.relocated44, %pic.prefix.hit.112 ], [ %rs4gc.s5.relocated44, %pic.desc.prefix.hit.117 ]
  %r467 = phi double [ %r383, %pic.hit.live.108 ], [ %r37856, %pic.hit.overflow.124 ], [ %r403, %pic.prefix.hit.112 ], [ %r421, %pic.desc.prefix.hit.117 ], [ %r460, %pic.way.live.128 ], [ %r46651, %pic.miss.call.120 ]
  br label %pget.recv_merge.102

pic.recv_hdr.122:                                 ; preds = %pget.recv_obj.106
  %r346 = sub nuw nsw i64 %r334, 8
  %r347 = inttoptr i64 %r346 to ptr
  %r348 = load i8, ptr %r347, align 1
  %r349 = icmp eq i8 %r348, 2
  %r350 = sub nuw nsw i64 %r334, 6
  %r351 = inttoptr i64 %r350 to ptr
  %r352 = load i16, ptr %r351, align 2
  %r353 = and i16 %r352, 2048
  %r354 = icmp eq i16 %r353, 0
  %r355 = load ptr, ptr @perry_ic_options_worker_ts__3, align 8
  %r356 = icmp ne ptr %r355, null
  %r357 = and i1 %r349, %r354
  %r358 = and i1 %r357, %r356
  br i1 %r358, label %pic.token.123, label %pic.desc.classify.113

pic.token.123:                                    ; preds = %pic.recv_hdr.122
  %r360 = add nuw nsw i64 %r334, 4
  %r361 = inttoptr i64 %r360 to ptr
  %r362 = load i32, ptr %r361, align 4
  %r363 = zext i32 %r362 to i64
  %r364 = or i64 %r363, 4611686018427387904
  %r365 = icmp ne i32 %r362, 0
  %r366 = getelementptr i64, ptr %r355, i64 0
  %r367 = load i64, ptr %r366, align 8
  %r368 = icmp eq i64 %r364, %r367
  %r369 = and i1 %r368, %r365
  br i1 %r369, label %pic.hit.107, label %pic.prefix.guard.109

pic.hit.overflow.124:                             ; preds = %pic.hit.107
  %r374 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r375 = bitcast double %r374 to i64
  %r376 = and i64 %r375, 281474976710655
  %r377 = trunc i64 %r371 to i32
  %statepoint_token55 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r334, i64 %r376, i32 %r377, ptr @perry_ic_options_worker_ts__3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated44, ptr addrspace(1) %rs4gc.s8, ptr addrspace(1) %rs4gc.s9) ]
  %r37856 = call double @llvm.experimental.gc.result.f64(token %statepoint_token55)
  %rs4gc.s5.relocated57 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token55, i32 0, i32 0) ; (%rs4gc.s5.relocated44, %rs4gc.s5.relocated44)
  %rs4gc.s8.relocated58 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token55, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.s9.relocated59 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token55, i32 2, i32 2) ; (%rs4gc.s9, %rs4gc.s9)
  br label %pic.merge.121

pic.hit.inline.125:                               ; preds = %pic.hit.107
  %r379 = shl i64 %r371, 3
  %r380 = add nuw nsw i64 %r334, 16
  %r381 = add i64 %r380, %r379
  %r382 = inttoptr i64 %r381 to ptr
  %r383 = load double, ptr %r382, align 8
  %r384 = bitcast double %r383 to i64
  %r385 = icmp eq i64 %r384, 9222246136947933200
  br i1 %r385, label %pic.miss.118, label %pic.hit.live.108

pic.ways.126:                                     ; preds = %pic.miss.118
  %r425 = getelementptr i64, ptr %r355, i64 4
  %r426 = load i64, ptr %r425, align 8
  %r427 = icmp eq i64 %r426, %r364
  %r428 = getelementptr i64, ptr %r355, i64 5
  %r429 = load i64, ptr %r428, align 8
  %r430 = select i1 %r427, i64 %r429, i64 0
  %r431 = getelementptr i64, ptr %r355, i64 6
  %r432 = load i64, ptr %r431, align 8
  %r433 = icmp eq i64 %r432, %r364
  %r434 = getelementptr i64, ptr %r355, i64 7
  %r435 = load i64, ptr %r434, align 8
  %r436 = select i1 %r433, i64 %r435, i64 0
  %r437 = getelementptr i64, ptr %r355, i64 8
  %r438 = load i64, ptr %r437, align 8
  %r439 = icmp eq i64 %r438, %r364
  %r440 = getelementptr i64, ptr %r355, i64 9
  %r441 = load i64, ptr %r440, align 8
  %r442 = select i1 %r439, i64 %r441, i64 0
  %r443 = getelementptr i64, ptr %r355, i64 10
  %r444 = load i64, ptr %r443, align 8
  %r445 = icmp eq i64 %r444, %r364
  %r446 = getelementptr i64, ptr %r355, i64 11
  %r447 = load i64, ptr %r446, align 8
  %r448 = select i1 %r445, i64 %r447, i64 0
  %r449 = or i1 %r427, %r433
  %r450 = select i1 %r427, i64 %r430, i64 %r436
  %r451 = or i1 %r439, %r445
  %r452 = select i1 %r439, i64 %r442, i64 %r448
  %r453 = or i1 %r449, %r451
  %r454 = select i1 %r449, i64 %r450, i64 %r452
  %r455 = and i1 %r365, %r453
  br i1 %r455, label %pic.way.load.127, label %pic.miss.call.120

pic.way.load.127:                                 ; preds = %pic.ways.126
  %r456 = shl i64 %r454, 3
  %r457 = add nuw nsw i64 %r334, 16
  %r458 = add i64 %r457, %r456
  %r459 = inttoptr i64 %r458 to ptr
  %r460 = load double, ptr %r459, align 8
  %r461 = bitcast double %r460 to i64
  %r462 = icmp eq i64 %r461, 9222246136947933200
  br i1 %r462, label %pic.miss.call.120, label %pic.way.live.128

pic.way.live.128:                                 ; preds = %pic.way.load.127
  br label %pic.merge.121

pget.throw_nullish.129:                           ; preds = %pget.recv_bad.100
  %r471 = zext i1 %r469 to i32
  %statepoint_token60 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r471, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.130:                       ; preds = %pget.recv_bad.100
  %r472 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r473 = bitcast double %r472 to i64
  %r474 = and i64 %r473, 281474976710655
  %statepoint_token61 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r333, i64 %r474, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated44, ptr addrspace(1) %rs4gc.s8, ptr addrspace(1) %rs4gc.s9) ]
  %r47562 = call double @llvm.experimental.gc.result.f64(token %statepoint_token61)
  %rs4gc.s5.relocated63 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token61, i32 0, i32 0) ; (%rs4gc.s5.relocated44, %rs4gc.s5.relocated44)
  %rs4gc.s8.relocated64 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token61, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.s9.relocated65 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token61, i32 2, i32 2) ; (%rs4gc.s9, %rs4gc.s9)
  br label %pget.recv_merge.102

guarded_add.numeric.131:                          ; preds = %pget.recv_merge.102
  %r497 = fadd double %r486, %r484
  br label %guarded_add.merge.133

guarded_add.dynamic.132:                          ; preds = %pget.recv_merge.102
  %statepoint_token66 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r486, double %r484, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.12, ptr addrspace(1) %.0146) ]
  %r49867 = call double @llvm.experimental.gc.result.f64(token %statepoint_token66)
  %rs4gc.s5.relocated68 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token66, i32 0, i32 0) ; (%.12, %.12)
  %rs4gc.s8.relocated69 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token66, i32 1, i32 1) ; (%.0146, %.0146)
  br label %guarded_add.merge.133

guarded_add.merge.133:                            ; preds = %guarded_add.dynamic.132, %guarded_add.numeric.131
  %.2148 = phi ptr addrspace(1) [ %.0146, %guarded_add.numeric.131 ], [ %rs4gc.s8.relocated69, %guarded_add.dynamic.132 ]
  %.14 = phi ptr addrspace(1) [ %.12, %guarded_add.numeric.131 ], [ %rs4gc.s5.relocated68, %guarded_add.dynamic.132 ]
  %r499 = phi double [ %r497, %guarded_add.numeric.131 ], [ %r49867, %guarded_add.dynamic.132 ]
  %r500.rs4i = ptrtoint ptr addrspace(1) %.2148 to i64
  %r500.rs4o = call i64 asm "", "=r,0"(i64 %r500.rs4i) #9
  %r500 = bitcast i64 %r500.rs4o to double
  %r501 = bitcast double %r500 to i64
  %r502 = and i64 %r501, -281474976710656
  %r503 = icmp ne i64 %r502, 9223090561878065152
  br i1 %r503, label %str_addref.done.135, label %str_addref.call.134

str_addref.call.134:                              ; preds = %guarded_add.merge.133
  call void @js_string_addref_if_heap_string(double %r500) #9
  br label %str_addref.done.135

str_addref.done.135:                              ; preds = %str_addref.call.134, %guarded_add.merge.133
  %r1034.rs4i = ptrtoint ptr addrspace(1) %.2148 to i64
  %r1034.rs4o = call i64 asm "", "=r,0"(i64 %r1034.rs4i) #9
  %r1034 = bitcast i64 %r1034.rs4o to double
  store double %r1034, ptr @perry_global_options_worker_ts__6, align 8
  %r1033.rs4i = ptrtoint ptr addrspace(1) %.2148 to i64
  %r1033.rs4o = call i64 asm "", "=r,0"(i64 %r1033.rs4i) #9
  %r1033 = bitcast i64 %r1033.rs4o to double
  %r504 = bitcast double %r1033 to i64
  %r1031.rs4i = ptrtoint ptr addrspace(1) %.2148 to i64
  %r1031.rs4o = call i64 asm "", "=r,0"(i64 %r1031.rs4i) #9
  %r1031 = bitcast i64 %r1031.rs4o to double
  %r1032 = bitcast double %r1031 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1032) #9
  %r505 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r506 = icmp ne i32 %r505, 0
  br i1 %r506, label %gcpoll.136, label %gcpoll.done.137

gcpoll.136:                                       ; preds = %str_addref.done.135
  %statepoint_token70 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.14) ]
  %rs4gc.s5.relocated71 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token70, i32 0, i32 0) ; (%.14, %.14)
  br label %gcpoll.done.137

gcpoll.done.137:                                  ; preds = %gcpoll.136, %str_addref.done.135
  %.15 = phi ptr addrspace(1) [ %rs4gc.s5.relocated71, %gcpoll.136 ], [ %.14, %str_addref.done.135 ]
  br label %for.update.88

streqlit.sso.138:                                 ; preds = %if.else.79
  %r516 = icmp eq i64 %r513, 9221406112001647979
  br i1 %r516, label %streqlit.true.144, label %streqlit.tag.139

streqlit.tag.139:                                 ; preds = %streqlit.sso.138
  %r517 = lshr i64 %r513, 48
  %r518 = icmp eq i64 %r517, 32767
  %r519 = and i64 %r513, 281474976710655
  %r520 = icmp ugt i64 %r519, 4095
  %r521 = and i1 %r518, %r520
  br i1 %r521, label %streqlit.len.140, label %streqlit.false.145

streqlit.len.140:                                 ; preds = %streqlit.tag.139
  %r522 = inttoptr i64 %r519 to ptr
  %r523 = getelementptr inbounds nuw i8, ptr %r522, i64 4
  %r524 = load i32, ptr %r523, align 4
  %r525 = icmp eq i32 %r524, 4
  br i1 %r525, label %streqlit.b0.141, label %streqlit.false.145

streqlit.b0.141:                                  ; preds = %streqlit.len.140
  %r526 = getelementptr inbounds nuw i8, ptr %r522, i64 20
  %r527 = load i8, ptr %r526, align 1
  %r528 = icmp eq i8 %r527, 107
  br i1 %r528, label %streqlit.bl.142, label %streqlit.false.145

streqlit.bl.142:                                  ; preds = %streqlit.b0.141
  %r529 = getelementptr inbounds nuw i8, ptr %r522, i64 23
  %r530 = load i8, ptr %r529, align 1
  %r531 = icmp eq i8 %r530, 115
  br i1 %r531, label %streqlit.slow.143, label %streqlit.false.145

streqlit.slow.143:                                ; preds = %streqlit.bl.142
  %r532 = and i64 %r514, 281474976710655
  %statepoint_token72 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r519, i64 %r532, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.8) ]
  %r53373 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token72)
  %rs4gc.s5.relocated74 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token72, i32 0, i32 0) ; (%.8, %.8)
  %r534 = icmp ne i32 %r53373, 0
  br label %streqlit.merge.146

streqlit.true.144:                                ; preds = %streqlit.sso.138, %if.else.79
  br label %streqlit.merge.146

streqlit.false.145:                               ; preds = %streqlit.bl.142, %streqlit.b0.141, %streqlit.len.140, %streqlit.tag.139
  br label %streqlit.merge.146

streqlit.merge.146:                               ; preds = %streqlit.false.145, %streqlit.true.144, %streqlit.slow.143
  %.16 = phi ptr addrspace(1) [ %.8, %streqlit.true.144 ], [ %rs4gc.s5.relocated74, %streqlit.slow.143 ], [ %.8, %streqlit.false.145 ]
  %r535 = phi i1 [ true, %streqlit.true.144 ], [ false, %streqlit.false.145 ], [ %r534, %streqlit.slow.143 ]
  %r536 = select i1 %r535, i64 9222246136947933188, i64 9222246136947933187
  %r537 = bitcast i64 %r536 to double
  %r538 = icmp eq i64 %r536, 9222246136947933188
  br i1 %r538, label %if.then.147, label %if.else.148

if.then.147:                                      ; preds = %streqlit.merge.146
  %r543.rs4i = ptrtoint ptr addrspace(1) %.16 to i64
  %r543.rs4o = call i64 asm "", "=r,0"(i64 %r543.rs4i) #9
  %r543 = bitcast i64 %r543.rs4o to double
  %r544 = bitcast double %r543 to i64
  %r545 = and i64 %r544, -281474976710656
  %r546 = icmp ult i64 %r545, 9221401712017801216
  %r547 = icmp ugt i64 %r545, 9223090561878065152
  %r548 = or i1 %r546, %r547
  br i1 %r548, label %for.bound_i32.number.150, label %for.bound_i32.merge.152

if.else.148:                                      ; preds = %streqlit.merge.146
  %r766 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r767 = load double, ptr @options_worker_ts_.str.4.handle, align 8
  %r768 = bitcast double %r766 to i64
  %r769 = bitcast double %r767 to i64
  %r770 = icmp eq i64 %r768, %r769
  br i1 %r770, label %streqlit.true.212, label %streqlit.tag.207

if.merge.149:                                     ; preds = %if.merge.217, %for.exit.158
  %r2.4 = phi double [ %r2.5, %for.exit.158 ], [ %r2.6, %if.merge.217 ]
  br label %if.merge.80

for.bound_i32.number.150:                         ; preds = %if.then.147
  %r549 = fcmp oge double %r543, 0xC1E0000000000000
  %r550 = fcmp ole double %r543, 0x41DFFFFFFFC00000
  %r551 = and i1 %r549, %r550
  br i1 %r551, label %for.bound_i32.convert.151, label %for.bound_i32.merge.152

for.bound_i32.convert.151:                        ; preds = %for.bound_i32.number.150
  %r552 = fptosi double %r543 to i32
  %r553 = sitofp i32 %r552 to double
  %r554 = fcmp oeq double %r553, %r543
  br i1 %r554, label %for.counter_i32.range.153, label %for.bound_i32.merge.152

for.bound_i32.merge.152:                          ; preds = %for.counter_i32.convert.154, %for.bound_i32.convert.151, %for.bound_i32.number.150, %if.then.147
  %r542.0 = phi i32 [ %r552, %for.counter_i32.convert.154 ], [ 0, %if.then.147 ], [ %r552, %for.bound_i32.convert.151 ], [ 0, %for.bound_i32.number.150 ]
  %r541.0 = phi i1 [ true, %for.counter_i32.convert.154 ], [ false, %if.then.147 ], [ false, %for.bound_i32.convert.151 ], [ false, %for.bound_i32.number.150 ]
  br label %for.cond.155

for.counter_i32.range.153:                        ; preds = %for.bound_i32.convert.151
  br label %for.counter_i32.convert.154

for.counter_i32.convert.154:                      ; preds = %for.counter_i32.range.153
  br label %for.bound_i32.merge.152

for.cond.155:                                     ; preds = %for.update.157, %for.bound_i32.merge.152
  %.17 = phi ptr addrspace(1) [ %.16, %for.bound_i32.merge.152 ], [ %.23, %for.update.157 ]
  %r540.1 = phi i32 [ 0, %for.bound_i32.merge.152 ], [ %r765, %for.update.157 ]
  %r539.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.152 ], [ %r763, %for.update.157 ]
  %r2.5 = phi double [ 0.000000e+00, %for.bound_i32.merge.152 ], [ %r754, %for.update.157 ]
  br i1 %r541.0, label %for.cond.fast.159, label %for.cond.slow.160

for.body.156:                                     ; preds = %gcpoll.done.162, %for.cond.fast.159
  %.18 = phi ptr addrspace(1) [ %.17, %for.cond.fast.159 ], [ %.19, %gcpoll.done.162 ]
  %r575 = load double, ptr @perry_global_options_worker_ts__4, align 8
  %r576 = load double, ptr @perry_global_options_worker_ts__5, align 8
  %statepoint_token75 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r575, double %r576, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.18) ]
  %r57776 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token75)
  %rs4gc.s5.relocated77 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token75, i32 0, i32 0) ; (%.18, %.18)
  %r578 = bitcast i64 %r57776 to double
  %rs4gc.b10 = bitcast double %r578 to i64
  %rs4gc.s10 = inttoptr i64 %rs4gc.b10 to ptr addrspace(1)
  %r579.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r579 = call i64 asm "", "=r,0"(i64 %r579.rs4i) #9
  %r580 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r581 = icmp ne i32 %r580, 0
  br i1 %r581, label %shadow.root.barrier.163, label %shadow.root.barrier.done.164

for.update.157:                                   ; preds = %gcpoll.done.206
  %r763 = fadd double %r539.0, 1.000000e+00
  %r765 = add i32 %r540.1, 1
  br label %for.cond.155

for.exit.158:                                     ; preds = %gcpoll.done.162, %for.cond.fast.159
  br label %if.merge.149

for.cond.fast.159:                                ; preds = %for.cond.155
  %r565 = icmp slt i32 %r540.1, %r542.0
  br i1 %r565, label %for.body.156, label %for.exit.158

for.cond.slow.160:                                ; preds = %for.cond.155
  %r567.rs4i = ptrtoint ptr addrspace(1) %.17 to i64
  %r567.rs4o = call i64 asm "", "=r,0"(i64 %r567.rs4i) #9
  %r567 = bitcast i64 %r567.rs4o to double
  %r568 = fcmp olt double %r539.0, %r567
  %r569 = select i1 %r568, i64 9222246136947933188, i64 9222246136947933187
  %r570 = bitcast i64 %r569 to double
  %r572 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r573 = icmp ne i32 %r572, 0
  br i1 %r573, label %gcpoll.161, label %gcpoll.done.162

gcpoll.161:                                       ; preds = %for.cond.slow.160
  %statepoint_token78 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.17) ]
  %rs4gc.s5.relocated79 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token78, i32 0, i32 0) ; (%.17, %.17)
  br label %gcpoll.done.162

gcpoll.done.162:                                  ; preds = %gcpoll.161, %for.cond.slow.160
  %.19 = phi ptr addrspace(1) [ %rs4gc.s5.relocated79, %gcpoll.161 ], [ %.17, %for.cond.slow.160 ]
  %r571 = icmp eq i64 %r569, 9222246136947933188
  br i1 %r571, label %for.body.156, label %for.exit.158

shadow.root.barrier.163:                          ; preds = %for.body.156
  call void @js_write_barrier_root_nanbox(i64 %r579) #9
  br label %shadow.root.barrier.done.164

shadow.root.barrier.done.164:                     ; preds = %shadow.root.barrier.163, %for.body.156
  %r583 = bitcast double %r2.5 to i64
  %rs4gc.s11 = inttoptr i64 %r583 to ptr addrspace(1)
  %r584.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s11 to i64
  %r584 = call i64 asm "", "=r,0"(i64 %r584.rs4i) #9
  %r585 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r586 = icmp ne i32 %r585, 0
  br i1 %r586, label %shadow.root.barrier.165, label %shadow.root.barrier.done.166

shadow.root.barrier.165:                          ; preds = %shadow.root.barrier.done.164
  call void @js_write_barrier_root_nanbox(i64 %r584) #9
  br label %shadow.root.barrier.done.166

shadow.root.barrier.done.166:                     ; preds = %shadow.root.barrier.165, %shadow.root.barrier.done.164
  %r587.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r587.rs4o = call i64 asm "", "=r,0"(i64 %r587.rs4i) #9
  %r587 = bitcast i64 %r587.rs4o to double
  %r588 = bitcast double %r587 to i64
  %r589 = and i64 %r588, 281474976710655
  %r590 = lshr i64 %r588, 48
  %r591 = and i64 %r590, 65533
  %r592 = icmp eq i64 %r591, 32765
  br i1 %r592, label %pget.recv_ok.168, label %pget.recv_other.173

pget.recv_sso.167:                                ; preds = %pget.recv_other.173
  %r731 = lshr i64 %r588, 40
  %r732 = and i64 %r731, 255
  %r733 = uitofp nneg i64 %r732 to double
  br label %pget.recv_merge.171

pget.recv_ok.168:                                 ; preds = %shadow.root.barrier.done.166
  %r599 = icmp eq i64 %r590, 32767
  br i1 %r599, label %pget.strlen_heap.172, label %pget.recv_obj.175

pget.recv_bad.169:                                ; preds = %pget.check_class_ref.174
  %r723 = icmp eq i64 %r588, 9222246136947933185
  %r724 = icmp eq i64 %r588, 9222246136947933186
  %r725 = or i1 %r723, %r724
  br i1 %r725, label %pget.throw_nullish.198, label %pget.recv_undef_return.199

pget.recv_class_ref.170:                          ; preds = %pget.check_class_ref.174
  %r595 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r596 = bitcast double %r595 to i64
  %r597 = and i64 %r596, 281474976710655
  %statepoint_token80 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532868, i64 %r588, i64 %r597, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated77, ptr addrspace(1) %rs4gc.s10, ptr addrspace(1) %rs4gc.s11) ]
  %r59881 = call double @llvm.experimental.gc.result.f64(token %statepoint_token80)
  %rs4gc.s5.relocated82 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token80, i32 0, i32 0) ; (%rs4gc.s5.relocated77, %rs4gc.s5.relocated77)
  %rs4gc.s10.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token80, i32 1, i32 1) ; (%rs4gc.s10, %rs4gc.s10)
  %rs4gc.s11.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token80, i32 2, i32 2) ; (%rs4gc.s11, %rs4gc.s11)
  br label %pget.recv_merge.171

pget.recv_merge.171:                              ; preds = %pget.recv_undef_return.199, %pic.merge.190, %pget.strlen_heap.172, %pget.recv_class_ref.170, %pget.recv_sso.167
  %.0154 = phi ptr addrspace(1) [ %rs4gc.s11, %pget.strlen_heap.172 ], [ %.1155, %pic.merge.190 ], [ %rs4gc.s11, %pget.recv_sso.167 ], [ %rs4gc.s11.relocated, %pget.recv_class_ref.170 ], [ %rs4gc.s11.relocated98, %pget.recv_undef_return.199 ]
  %.0151 = phi ptr addrspace(1) [ %rs4gc.s10, %pget.strlen_heap.172 ], [ %.1152, %pic.merge.190 ], [ %rs4gc.s10, %pget.recv_sso.167 ], [ %rs4gc.s10.relocated, %pget.recv_class_ref.170 ], [ %rs4gc.s10.relocated97, %pget.recv_undef_return.199 ]
  %.20 = phi ptr addrspace(1) [ %rs4gc.s5.relocated77, %pget.strlen_heap.172 ], [ %.21, %pic.merge.190 ], [ %rs4gc.s5.relocated77, %pget.recv_sso.167 ], [ %rs4gc.s5.relocated82, %pget.recv_class_ref.170 ], [ %rs4gc.s5.relocated96, %pget.recv_undef_return.199 ]
  %r739 = phi double [ %r722, %pic.merge.190 ], [ %r73095, %pget.recv_undef_return.199 ], [ %r733, %pget.recv_sso.167 ], [ %r59881, %pget.recv_class_ref.170 ], [ %r738, %pget.strlen_heap.172 ]
  %r740.rs4i = ptrtoint ptr addrspace(1) %.0154 to i64
  %r740 = call i64 asm "", "=r,0"(i64 %r740.rs4i) #9
  %r741 = bitcast i64 %r740 to double
  %r742 = and i64 %r740, -281474976710656
  %r743 = icmp ult i64 %r742, 9221401712017801216
  %r744 = icmp ugt i64 %r742, 9223090561878065152
  %r745 = or i1 %r743, %r744
  %r746 = bitcast double %r739 to i64
  %r747 = and i64 %r746, -281474976710656
  %r748 = icmp ult i64 %r747, 9221401712017801216
  %r749 = icmp ugt i64 %r747, 9223090561878065152
  %r750 = or i1 %r748, %r749
  %r751 = and i1 %r745, %r750
  br i1 %r751, label %guarded_add.numeric.200, label %guarded_add.dynamic.201

pget.strlen_heap.172:                             ; preds = %pget.recv_ok.168
  %r734 = icmp ult i64 %r589, 4096
  %r735 = inttoptr i64 %r589 to ptr
  %r736 = select i1 %r734, ptr @perry_null_guard_zero_options_worker_ts, ptr %r735
  %r737 = load i32, ptr %r736, align 4
  %r738 = uitofp i32 %r737 to double
  br label %pget.recv_merge.171

pget.recv_other.173:                              ; preds = %shadow.root.barrier.done.166
  %r593 = icmp eq i64 %r590, 32761
  br i1 %r593, label %pget.recv_sso.167, label %pget.check_class_ref.174

pget.check_class_ref.174:                         ; preds = %pget.recv_other.173
  %r594 = icmp eq i64 %r590, 32766
  br i1 %r594, label %pget.recv_class_ref.170, label %pget.recv_bad.169

pget.recv_obj.175:                                ; preds = %pget.recv_ok.168
  %r600 = icmp ugt i64 %r589, 1048575
  br i1 %r600, label %pic.recv_hdr.191, label %pic.miss.cold.188

pic.hit.176:                                      ; preds = %pic.token.192
  %r625 = getelementptr i64, ptr %r610, i64 1
  %r626 = load i64, ptr %r625, align 8
  %r627 = and i64 %r626, 1073741824
  %r628 = icmp ne i64 %r627, 0
  br i1 %r628, label %pic.hit.overflow.193, label %pic.hit.inline.194

pic.hit.live.177:                                 ; preds = %pic.hit.inline.194
  br label %pic.merge.190

pic.prefix.guard.178:                             ; preds = %pic.token.192
  %r641 = getelementptr i64, ptr %r610, i64 2
  %r642 = load i64, ptr %r641, align 8
  %r643 = icmp ne i64 %r642, 0
  br i1 %r643, label %pic.prefix.meta.179, label %pic.miss.187

pic.prefix.meta.179:                              ; preds = %pic.prefix.guard.178
  %r644 = add nuw nsw i64 %r589, 8
  %r645 = inttoptr i64 %r644 to ptr
  %r646 = load i64, ptr %r645, align 8
  %r647 = icmp ne i64 %r646, 0
  br i1 %r647, label %pic.prefix.token.180, label %pic.miss.187

pic.prefix.token.180:                             ; preds = %pic.prefix.meta.179
  %r648 = inttoptr i64 %r646 to ptr
  %r649 = getelementptr i64, ptr %r648, i64 6
  %r650 = load i64, ptr %r649, align 8
  %r651 = icmp eq i64 %r650, %r642
  br i1 %r651, label %pic.prefix.hit.181, label %pic.miss.187

pic.prefix.hit.181:                               ; preds = %pic.prefix.token.180
  %r652 = getelementptr i64, ptr %r610, i64 1
  %r653 = load i64, ptr %r652, align 8
  %r654 = shl i64 %r653, 3
  %r655 = add nuw nsw i64 %r589, 16
  %r656 = add i64 %r655, %r654
  %r657 = inttoptr i64 %r656 to ptr
  %r658 = load double, ptr %r657, align 8
  br label %pic.merge.190

pic.desc.classify.182:                            ; preds = %pic.recv_hdr.191
  %r614 = and i1 %r604, %r611
  br i1 %r614, label %pic.desc.prefix.guard.183, label %pic.miss.cold.188

pic.desc.prefix.guard.183:                        ; preds = %pic.desc.classify.182
  %r659 = getelementptr i64, ptr %r610, i64 2
  %r660 = load i64, ptr %r659, align 8
  %r661 = icmp ne i64 %r660, 0
  br i1 %r661, label %pic.desc.prefix.meta.184, label %pic.miss.cold.188

pic.desc.prefix.meta.184:                         ; preds = %pic.desc.prefix.guard.183
  %r662 = add nuw nsw i64 %r589, 8
  %r663 = inttoptr i64 %r662 to ptr
  %r664 = load i64, ptr %r663, align 8
  %r665 = icmp ne i64 %r664, 0
  br i1 %r665, label %pic.desc.prefix.token.185, label %pic.miss.cold.188

pic.desc.prefix.token.185:                        ; preds = %pic.desc.prefix.meta.184
  %r666 = inttoptr i64 %r664 to ptr
  %r667 = getelementptr i64, ptr %r666, i64 6
  %r668 = load i64, ptr %r667, align 8
  %r669 = icmp eq i64 %r668, %r660
  br i1 %r669, label %pic.desc.prefix.hit.186, label %pic.miss.cold.188

pic.desc.prefix.hit.186:                          ; preds = %pic.desc.prefix.token.185
  %r670 = getelementptr i64, ptr %r610, i64 1
  %r671 = load i64, ptr %r670, align 8
  %r672 = shl i64 %r671, 3
  %r673 = add nuw nsw i64 %r589, 16
  %r674 = add i64 %r673, %r672
  %r675 = inttoptr i64 %r674 to ptr
  %r676 = load double, ptr %r675, align 8
  br label %pic.merge.190

pic.miss.187:                                     ; preds = %pic.hit.inline.194, %pic.prefix.token.180, %pic.prefix.meta.179, %pic.prefix.guard.178
  %r677 = getelementptr i64, ptr %r610, i64 3
  %r678 = load i64, ptr %r677, align 8
  %r679 = icmp sgt i64 %r678, 0
  br i1 %r679, label %pic.ways.195, label %pic.miss.call.189

pic.miss.cold.188:                                ; preds = %pic.desc.prefix.token.185, %pic.desc.prefix.meta.184, %pic.desc.prefix.guard.183, %pic.desc.classify.182, %pget.recv_obj.175
  br label %pic.miss.call.189

pic.miss.call.189:                                ; preds = %pic.way.load.196, %pic.ways.195, %pic.miss.cold.188, %pic.miss.187
  %r718 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r719 = bitcast double %r718 to i64
  %r720 = and i64 %r719, 281474976710655
  %statepoint_token83 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r589, i64 %r720, ptr @perry_ic_options_worker_ts__5, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated77, ptr addrspace(1) %rs4gc.s10, ptr addrspace(1) %rs4gc.s11) ]
  %r72184 = call double @llvm.experimental.gc.result.f64(token %statepoint_token83)
  %rs4gc.s5.relocated85 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token83, i32 0, i32 0) ; (%rs4gc.s5.relocated77, %rs4gc.s5.relocated77)
  %rs4gc.s10.relocated86 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token83, i32 1, i32 1) ; (%rs4gc.s10, %rs4gc.s10)
  %rs4gc.s11.relocated87 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token83, i32 2, i32 2) ; (%rs4gc.s11, %rs4gc.s11)
  br label %pic.merge.190

pic.merge.190:                                    ; preds = %pic.way.live.197, %pic.hit.overflow.193, %pic.miss.call.189, %pic.desc.prefix.hit.186, %pic.prefix.hit.181, %pic.hit.live.177
  %.1155 = phi ptr addrspace(1) [ %rs4gc.s11.relocated92, %pic.hit.overflow.193 ], [ %rs4gc.s11.relocated87, %pic.miss.call.189 ], [ %rs4gc.s11, %pic.way.live.197 ], [ %rs4gc.s11, %pic.hit.live.177 ], [ %rs4gc.s11, %pic.prefix.hit.181 ], [ %rs4gc.s11, %pic.desc.prefix.hit.186 ]
  %.1152 = phi ptr addrspace(1) [ %rs4gc.s10.relocated91, %pic.hit.overflow.193 ], [ %rs4gc.s10.relocated86, %pic.miss.call.189 ], [ %rs4gc.s10, %pic.way.live.197 ], [ %rs4gc.s10, %pic.hit.live.177 ], [ %rs4gc.s10, %pic.prefix.hit.181 ], [ %rs4gc.s10, %pic.desc.prefix.hit.186 ]
  %.21 = phi ptr addrspace(1) [ %rs4gc.s5.relocated90, %pic.hit.overflow.193 ], [ %rs4gc.s5.relocated85, %pic.miss.call.189 ], [ %rs4gc.s5.relocated77, %pic.way.live.197 ], [ %rs4gc.s5.relocated77, %pic.hit.live.177 ], [ %rs4gc.s5.relocated77, %pic.prefix.hit.181 ], [ %rs4gc.s5.relocated77, %pic.desc.prefix.hit.186 ]
  %r722 = phi double [ %r638, %pic.hit.live.177 ], [ %r63389, %pic.hit.overflow.193 ], [ %r658, %pic.prefix.hit.181 ], [ %r676, %pic.desc.prefix.hit.186 ], [ %r715, %pic.way.live.197 ], [ %r72184, %pic.miss.call.189 ]
  br label %pget.recv_merge.171

pic.recv_hdr.191:                                 ; preds = %pget.recv_obj.175
  %r601 = sub nuw nsw i64 %r589, 8
  %r602 = inttoptr i64 %r601 to ptr
  %r603 = load i8, ptr %r602, align 1
  %r604 = icmp eq i8 %r603, 2
  %r605 = sub nuw nsw i64 %r589, 6
  %r606 = inttoptr i64 %r605 to ptr
  %r607 = load i16, ptr %r606, align 2
  %r608 = and i16 %r607, 2048
  %r609 = icmp eq i16 %r608, 0
  %r610 = load ptr, ptr @perry_ic_options_worker_ts__5, align 8
  %r611 = icmp ne ptr %r610, null
  %r612 = and i1 %r604, %r609
  %r613 = and i1 %r612, %r611
  br i1 %r613, label %pic.token.192, label %pic.desc.classify.182

pic.token.192:                                    ; preds = %pic.recv_hdr.191
  %r615 = add nuw nsw i64 %r589, 4
  %r616 = inttoptr i64 %r615 to ptr
  %r617 = load i32, ptr %r616, align 4
  %r618 = zext i32 %r617 to i64
  %r619 = or i64 %r618, 4611686018427387904
  %r620 = icmp ne i32 %r617, 0
  %r621 = getelementptr i64, ptr %r610, i64 0
  %r622 = load i64, ptr %r621, align 8
  %r623 = icmp eq i64 %r619, %r622
  %r624 = and i1 %r623, %r620
  br i1 %r624, label %pic.hit.176, label %pic.prefix.guard.178

pic.hit.overflow.193:                             ; preds = %pic.hit.176
  %r629 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r630 = bitcast double %r629 to i64
  %r631 = and i64 %r630, 281474976710655
  %r632 = trunc i64 %r626 to i32
  %statepoint_token88 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r589, i64 %r631, i32 %r632, ptr @perry_ic_options_worker_ts__5, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated77, ptr addrspace(1) %rs4gc.s10, ptr addrspace(1) %rs4gc.s11) ]
  %r63389 = call double @llvm.experimental.gc.result.f64(token %statepoint_token88)
  %rs4gc.s5.relocated90 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token88, i32 0, i32 0) ; (%rs4gc.s5.relocated77, %rs4gc.s5.relocated77)
  %rs4gc.s10.relocated91 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token88, i32 1, i32 1) ; (%rs4gc.s10, %rs4gc.s10)
  %rs4gc.s11.relocated92 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token88, i32 2, i32 2) ; (%rs4gc.s11, %rs4gc.s11)
  br label %pic.merge.190

pic.hit.inline.194:                               ; preds = %pic.hit.176
  %r634 = shl i64 %r626, 3
  %r635 = add nuw nsw i64 %r589, 16
  %r636 = add i64 %r635, %r634
  %r637 = inttoptr i64 %r636 to ptr
  %r638 = load double, ptr %r637, align 8
  %r639 = bitcast double %r638 to i64
  %r640 = icmp eq i64 %r639, 9222246136947933200
  br i1 %r640, label %pic.miss.187, label %pic.hit.live.177

pic.ways.195:                                     ; preds = %pic.miss.187
  %r680 = getelementptr i64, ptr %r610, i64 4
  %r681 = load i64, ptr %r680, align 8
  %r682 = icmp eq i64 %r681, %r619
  %r683 = getelementptr i64, ptr %r610, i64 5
  %r684 = load i64, ptr %r683, align 8
  %r685 = select i1 %r682, i64 %r684, i64 0
  %r686 = getelementptr i64, ptr %r610, i64 6
  %r687 = load i64, ptr %r686, align 8
  %r688 = icmp eq i64 %r687, %r619
  %r689 = getelementptr i64, ptr %r610, i64 7
  %r690 = load i64, ptr %r689, align 8
  %r691 = select i1 %r688, i64 %r690, i64 0
  %r692 = getelementptr i64, ptr %r610, i64 8
  %r693 = load i64, ptr %r692, align 8
  %r694 = icmp eq i64 %r693, %r619
  %r695 = getelementptr i64, ptr %r610, i64 9
  %r696 = load i64, ptr %r695, align 8
  %r697 = select i1 %r694, i64 %r696, i64 0
  %r698 = getelementptr i64, ptr %r610, i64 10
  %r699 = load i64, ptr %r698, align 8
  %r700 = icmp eq i64 %r699, %r619
  %r701 = getelementptr i64, ptr %r610, i64 11
  %r702 = load i64, ptr %r701, align 8
  %r703 = select i1 %r700, i64 %r702, i64 0
  %r704 = or i1 %r682, %r688
  %r705 = select i1 %r682, i64 %r685, i64 %r691
  %r706 = or i1 %r694, %r700
  %r707 = select i1 %r694, i64 %r697, i64 %r703
  %r708 = or i1 %r704, %r706
  %r709 = select i1 %r704, i64 %r705, i64 %r707
  %r710 = and i1 %r620, %r708
  br i1 %r710, label %pic.way.load.196, label %pic.miss.call.189

pic.way.load.196:                                 ; preds = %pic.ways.195
  %r711 = shl i64 %r709, 3
  %r712 = add nuw nsw i64 %r589, 16
  %r713 = add i64 %r712, %r711
  %r714 = inttoptr i64 %r713 to ptr
  %r715 = load double, ptr %r714, align 8
  %r716 = bitcast double %r715 to i64
  %r717 = icmp eq i64 %r716, 9222246136947933200
  br i1 %r717, label %pic.miss.call.189, label %pic.way.live.197

pic.way.live.197:                                 ; preds = %pic.way.load.196
  br label %pic.merge.190

pget.throw_nullish.198:                           ; preds = %pget.recv_bad.169
  %r726 = zext i1 %r724 to i32
  %statepoint_token93 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r726, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.199:                       ; preds = %pget.recv_bad.169
  %r727 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r728 = bitcast double %r727 to i64
  %r729 = and i64 %r728, 281474976710655
  %statepoint_token94 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r588, i64 %r729, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated77, ptr addrspace(1) %rs4gc.s10, ptr addrspace(1) %rs4gc.s11) ]
  %r73095 = call double @llvm.experimental.gc.result.f64(token %statepoint_token94)
  %rs4gc.s5.relocated96 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 0, i32 0) ; (%rs4gc.s5.relocated77, %rs4gc.s5.relocated77)
  %rs4gc.s10.relocated97 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 1, i32 1) ; (%rs4gc.s10, %rs4gc.s10)
  %rs4gc.s11.relocated98 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 2, i32 2) ; (%rs4gc.s11, %rs4gc.s11)
  br label %pget.recv_merge.171

guarded_add.numeric.200:                          ; preds = %pget.recv_merge.171
  %r752 = fadd double %r741, %r739
  br label %guarded_add.merge.202

guarded_add.dynamic.201:                          ; preds = %pget.recv_merge.171
  %statepoint_token99 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r741, double %r739, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.20, ptr addrspace(1) %.0151) ]
  %r753100 = call double @llvm.experimental.gc.result.f64(token %statepoint_token99)
  %rs4gc.s5.relocated101 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token99, i32 0, i32 0) ; (%.20, %.20)
  %rs4gc.s10.relocated102 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token99, i32 1, i32 1) ; (%.0151, %.0151)
  br label %guarded_add.merge.202

guarded_add.merge.202:                            ; preds = %guarded_add.dynamic.201, %guarded_add.numeric.200
  %.2153 = phi ptr addrspace(1) [ %.0151, %guarded_add.numeric.200 ], [ %rs4gc.s10.relocated102, %guarded_add.dynamic.201 ]
  %.22 = phi ptr addrspace(1) [ %.20, %guarded_add.numeric.200 ], [ %rs4gc.s5.relocated101, %guarded_add.dynamic.201 ]
  %r754 = phi double [ %r752, %guarded_add.numeric.200 ], [ %r753100, %guarded_add.dynamic.201 ]
  %r755.rs4i = ptrtoint ptr addrspace(1) %.2153 to i64
  %r755.rs4o = call i64 asm "", "=r,0"(i64 %r755.rs4i) #9
  %r755 = bitcast i64 %r755.rs4o to double
  %r756 = bitcast double %r755 to i64
  %r757 = and i64 %r756, -281474976710656
  %r758 = icmp ne i64 %r757, 9223090561878065152
  br i1 %r758, label %str_addref.done.204, label %str_addref.call.203

str_addref.call.203:                              ; preds = %guarded_add.merge.202
  call void @js_string_addref_if_heap_string(double %r755) #9
  br label %str_addref.done.204

str_addref.done.204:                              ; preds = %str_addref.call.203, %guarded_add.merge.202
  %r1030.rs4i = ptrtoint ptr addrspace(1) %.2153 to i64
  %r1030.rs4o = call i64 asm "", "=r,0"(i64 %r1030.rs4i) #9
  %r1030 = bitcast i64 %r1030.rs4o to double
  store double %r1030, ptr @perry_global_options_worker_ts__6, align 8
  %r1029.rs4i = ptrtoint ptr addrspace(1) %.2153 to i64
  %r1029.rs4o = call i64 asm "", "=r,0"(i64 %r1029.rs4i) #9
  %r1029 = bitcast i64 %r1029.rs4o to double
  %r759 = bitcast double %r1029 to i64
  %r1027.rs4i = ptrtoint ptr addrspace(1) %.2153 to i64
  %r1027.rs4o = call i64 asm "", "=r,0"(i64 %r1027.rs4i) #9
  %r1027 = bitcast i64 %r1027.rs4o to double
  %r1028 = bitcast double %r1027 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1028) #9
  %r760 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r761 = icmp ne i32 %r760, 0
  br i1 %r761, label %gcpoll.205, label %gcpoll.done.206

gcpoll.205:                                       ; preds = %str_addref.done.204
  %statepoint_token103 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.22) ]
  %rs4gc.s5.relocated104 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token103, i32 0, i32 0) ; (%.22, %.22)
  br label %gcpoll.done.206

gcpoll.done.206:                                  ; preds = %gcpoll.205, %str_addref.done.204
  %.23 = phi ptr addrspace(1) [ %rs4gc.s5.relocated104, %gcpoll.205 ], [ %.22, %str_addref.done.204 ]
  br label %for.update.157

streqlit.tag.207:                                 ; preds = %if.else.148
  %r771 = lshr i64 %r768, 48
  %r772 = icmp eq i64 %r771, 32767
  %r773 = and i64 %r768, 281474976710655
  %r774 = icmp ugt i64 %r773, 4095
  %r775 = and i1 %r772, %r774
  br i1 %r775, label %streqlit.len.208, label %streqlit.false.213

streqlit.len.208:                                 ; preds = %streqlit.tag.207
  %r776 = inttoptr i64 %r773 to ptr
  %r777 = getelementptr inbounds nuw i8, ptr %r776, i64 4
  %r778 = load i32, ptr %r777, align 4
  %r779 = icmp eq i32 %r778, 8
  br i1 %r779, label %streqlit.b0.209, label %streqlit.false.213

streqlit.b0.209:                                  ; preds = %streqlit.len.208
  %r780 = getelementptr inbounds nuw i8, ptr %r776, i64 20
  %r781 = load i8, ptr %r780, align 1
  %r782 = icmp eq i8 %r781, 99
  br i1 %r782, label %streqlit.bl.210, label %streqlit.false.213

streqlit.bl.210:                                  ; preds = %streqlit.b0.209
  %r783 = getelementptr inbounds nuw i8, ptr %r776, i64 27
  %r784 = load i8, ptr %r783, align 1
  %r785 = icmp eq i8 %r784, 107
  br i1 %r785, label %streqlit.slow.211, label %streqlit.false.213

streqlit.slow.211:                                ; preds = %streqlit.bl.210
  %r786 = and i64 %r769, 281474976710655
  %statepoint_token105 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r773, i64 %r786, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.16) ]
  %r787106 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token105)
  %rs4gc.s5.relocated107 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 0, i32 0) ; (%.16, %.16)
  %r788 = icmp ne i32 %r787106, 0
  br label %streqlit.merge.214

streqlit.true.212:                                ; preds = %if.else.148
  br label %streqlit.merge.214

streqlit.false.213:                               ; preds = %streqlit.bl.210, %streqlit.b0.209, %streqlit.len.208, %streqlit.tag.207
  br label %streqlit.merge.214

streqlit.merge.214:                               ; preds = %streqlit.false.213, %streqlit.true.212, %streqlit.slow.211
  %.24 = phi ptr addrspace(1) [ %.16, %streqlit.true.212 ], [ %rs4gc.s5.relocated107, %streqlit.slow.211 ], [ %.16, %streqlit.false.213 ]
  %r789 = phi i1 [ true, %streqlit.true.212 ], [ false, %streqlit.false.213 ], [ %r788, %streqlit.slow.211 ]
  %r790 = select i1 %r789, i64 9222246136947933188, i64 9222246136947933187
  %r791 = bitcast i64 %r790 to double
  %r792 = icmp eq i64 %r790, 9222246136947933188
  br i1 %r792, label %if.then.215, label %if.else.216

if.then.215:                                      ; preds = %streqlit.merge.214
  %r797.rs4i = ptrtoint ptr addrspace(1) %.24 to i64
  %r797.rs4o = call i64 asm "", "=r,0"(i64 %r797.rs4i) #9
  %r797 = bitcast i64 %r797.rs4o to double
  %r798 = bitcast double %r797 to i64
  %r799 = and i64 %r798, -281474976710656
  %r800 = icmp ult i64 %r799, 9221401712017801216
  %r801 = icmp ugt i64 %r799, 9223090561878065152
  %r802 = or i1 %r800, %r801
  br i1 %r802, label %for.bound_i32.number.218, label %for.bound_i32.merge.220

if.else.216:                                      ; preds = %streqlit.merge.214
  br label %if.merge.217

if.merge.217:                                     ; preds = %for.exit.226, %if.else.216
  %r2.6 = phi double [ %r2.7, %for.exit.226 ], [ 0.000000e+00, %if.else.216 ]
  br label %if.merge.149

for.bound_i32.number.218:                         ; preds = %if.then.215
  %r803 = fcmp oge double %r797, 0xC1E0000000000000
  %r804 = fcmp ole double %r797, 0x41DFFFFFFFC00000
  %r805 = and i1 %r803, %r804
  br i1 %r805, label %for.bound_i32.convert.219, label %for.bound_i32.merge.220

for.bound_i32.convert.219:                        ; preds = %for.bound_i32.number.218
  %r806 = fptosi double %r797 to i32
  %r807 = sitofp i32 %r806 to double
  %r808 = fcmp oeq double %r807, %r797
  br i1 %r808, label %for.counter_i32.range.221, label %for.bound_i32.merge.220

for.bound_i32.merge.220:                          ; preds = %for.counter_i32.convert.222, %for.bound_i32.convert.219, %for.bound_i32.number.218, %if.then.215
  %r796.0 = phi i32 [ %r806, %for.counter_i32.convert.222 ], [ 0, %if.then.215 ], [ %r806, %for.bound_i32.convert.219 ], [ 0, %for.bound_i32.number.218 ]
  %r795.0 = phi i1 [ true, %for.counter_i32.convert.222 ], [ false, %if.then.215 ], [ false, %for.bound_i32.convert.219 ], [ false, %for.bound_i32.number.218 ]
  br label %for.cond.223

for.counter_i32.range.221:                        ; preds = %for.bound_i32.convert.219
  br label %for.counter_i32.convert.222

for.counter_i32.convert.222:                      ; preds = %for.counter_i32.range.221
  br label %for.bound_i32.merge.220

for.cond.223:                                     ; preds = %for.update.225, %for.bound_i32.merge.220
  %.25 = phi ptr addrspace(1) [ %.24, %for.bound_i32.merge.220 ], [ %.31, %for.update.225 ]
  %r794.1 = phi i32 [ 0, %for.bound_i32.merge.220 ], [ %r1021, %for.update.225 ]
  %r793.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.220 ], [ %r1019, %for.update.225 ]
  %r2.7 = phi double [ 0.000000e+00, %for.bound_i32.merge.220 ], [ %r1010, %for.update.225 ]
  br i1 %r795.0, label %for.cond.fast.227, label %for.cond.slow.228

for.body.224:                                     ; preds = %gcpoll.done.230, %for.cond.fast.227
  %.26 = phi ptr addrspace(1) [ %.25, %for.cond.fast.227 ], [ %.27, %gcpoll.done.230 ]
  %r829 = load double, ptr @perry_global_options_worker_ts__4, align 8
  %statepoint_token108 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (ptr)) @js_closure_alloc_singleton, i32 1, i32 0, ptr @__perry_wrap_perry_fn_options_worker_ts__identity, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.26) ]
  %r830109 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token108)
  %rs4gc.s5.relocated110 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 0, i32 0) ; (%.26, %.26)
  %r831 = or i64 %r830109, 9222527611924643840
  %r832 = bitcast i64 %r831 to double
  %statepoint_token111 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r829, double %r832, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated110) ]
  %r833112 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token111)
  %rs4gc.s5.relocated113 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token111, i32 0, i32 0) ; (%rs4gc.s5.relocated110, %rs4gc.s5.relocated110)
  %r834 = bitcast i64 %r833112 to double
  %rs4gc.b12 = bitcast double %r834 to i64
  %rs4gc.s12 = inttoptr i64 %rs4gc.b12 to ptr addrspace(1)
  %r835.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12 to i64
  %r835 = call i64 asm "", "=r,0"(i64 %r835.rs4i) #9
  %r836 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r837 = icmp ne i32 %r836, 0
  br i1 %r837, label %shadow.root.barrier.231, label %shadow.root.barrier.done.232

for.update.225:                                   ; preds = %gcpoll.done.274
  %r1019 = fadd double %r793.0, 1.000000e+00
  %r1021 = add i32 %r794.1, 1
  br label %for.cond.223

for.exit.226:                                     ; preds = %gcpoll.done.230, %for.cond.fast.227
  br label %if.merge.217

for.cond.fast.227:                                ; preds = %for.cond.223
  %r819 = icmp slt i32 %r794.1, %r796.0
  br i1 %r819, label %for.body.224, label %for.exit.226

for.cond.slow.228:                                ; preds = %for.cond.223
  %r821.rs4i = ptrtoint ptr addrspace(1) %.25 to i64
  %r821.rs4o = call i64 asm "", "=r,0"(i64 %r821.rs4i) #9
  %r821 = bitcast i64 %r821.rs4o to double
  %r822 = fcmp olt double %r793.0, %r821
  %r823 = select i1 %r822, i64 9222246136947933188, i64 9222246136947933187
  %r824 = bitcast i64 %r823 to double
  %r826 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r827 = icmp ne i32 %r826, 0
  br i1 %r827, label %gcpoll.229, label %gcpoll.done.230

gcpoll.229:                                       ; preds = %for.cond.slow.228
  %statepoint_token114 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.25) ]
  %rs4gc.s5.relocated115 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token114, i32 0, i32 0) ; (%.25, %.25)
  br label %gcpoll.done.230

gcpoll.done.230:                                  ; preds = %gcpoll.229, %for.cond.slow.228
  %.27 = phi ptr addrspace(1) [ %rs4gc.s5.relocated115, %gcpoll.229 ], [ %.25, %for.cond.slow.228 ]
  %r825 = icmp eq i64 %r823, 9222246136947933188
  br i1 %r825, label %for.body.224, label %for.exit.226

shadow.root.barrier.231:                          ; preds = %for.body.224
  call void @js_write_barrier_root_nanbox(i64 %r835) #9
  br label %shadow.root.barrier.done.232

shadow.root.barrier.done.232:                     ; preds = %shadow.root.barrier.231, %for.body.224
  %r839 = bitcast double %r2.7 to i64
  %rs4gc.s13 = inttoptr i64 %r839 to ptr addrspace(1)
  %r840.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13 to i64
  %r840 = call i64 asm "", "=r,0"(i64 %r840.rs4i) #9
  %r841 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r842 = icmp ne i32 %r841, 0
  br i1 %r842, label %shadow.root.barrier.233, label %shadow.root.barrier.done.234

shadow.root.barrier.233:                          ; preds = %shadow.root.barrier.done.232
  call void @js_write_barrier_root_nanbox(i64 %r840) #9
  br label %shadow.root.barrier.done.234

shadow.root.barrier.done.234:                     ; preds = %shadow.root.barrier.233, %shadow.root.barrier.done.232
  %r843.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12 to i64
  %r843.rs4o = call i64 asm "", "=r,0"(i64 %r843.rs4i) #9
  %r843 = bitcast i64 %r843.rs4o to double
  %r844 = bitcast double %r843 to i64
  %r845 = and i64 %r844, 281474976710655
  %r846 = lshr i64 %r844, 48
  %r847 = and i64 %r846, 65533
  %r848 = icmp eq i64 %r847, 32765
  br i1 %r848, label %pget.recv_ok.236, label %pget.recv_other.241

pget.recv_sso.235:                                ; preds = %pget.recv_other.241
  %r987 = lshr i64 %r844, 40
  %r988 = and i64 %r987, 255
  %r989 = uitofp nneg i64 %r988 to double
  br label %pget.recv_merge.239

pget.recv_ok.236:                                 ; preds = %shadow.root.barrier.done.234
  %r855 = icmp eq i64 %r846, 32767
  br i1 %r855, label %pget.strlen_heap.240, label %pget.recv_obj.243

pget.recv_bad.237:                                ; preds = %pget.check_class_ref.242
  %r979 = icmp eq i64 %r844, 9222246136947933185
  %r980 = icmp eq i64 %r844, 9222246136947933186
  %r981 = or i1 %r979, %r980
  br i1 %r981, label %pget.throw_nullish.266, label %pget.recv_undef_return.267

pget.recv_class_ref.238:                          ; preds = %pget.check_class_ref.242
  %r851 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r852 = bitcast double %r851 to i64
  %r853 = and i64 %r852, 281474976710655
  %statepoint_token116 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532870, i64 %r844, i64 %r853, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated113, ptr addrspace(1) %rs4gc.s12, ptr addrspace(1) %rs4gc.s13) ]
  %r854117 = call double @llvm.experimental.gc.result.f64(token %statepoint_token116)
  %rs4gc.s5.relocated118 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 0, i32 0) ; (%rs4gc.s5.relocated113, %rs4gc.s5.relocated113)
  %rs4gc.s12.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 1, i32 1) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 2, i32 2) ; (%rs4gc.s13, %rs4gc.s13)
  br label %pget.recv_merge.239

pget.recv_merge.239:                              ; preds = %pget.recv_undef_return.267, %pic.merge.258, %pget.strlen_heap.240, %pget.recv_class_ref.238, %pget.recv_sso.235
  %.0159 = phi ptr addrspace(1) [ %rs4gc.s13, %pget.strlen_heap.240 ], [ %.1160, %pic.merge.258 ], [ %rs4gc.s13, %pget.recv_sso.235 ], [ %rs4gc.s13.relocated, %pget.recv_class_ref.238 ], [ %rs4gc.s13.relocated134, %pget.recv_undef_return.267 ]
  %.0156 = phi ptr addrspace(1) [ %rs4gc.s12, %pget.strlen_heap.240 ], [ %.1157, %pic.merge.258 ], [ %rs4gc.s12, %pget.recv_sso.235 ], [ %rs4gc.s12.relocated, %pget.recv_class_ref.238 ], [ %rs4gc.s12.relocated133, %pget.recv_undef_return.267 ]
  %.28 = phi ptr addrspace(1) [ %rs4gc.s5.relocated113, %pget.strlen_heap.240 ], [ %.29, %pic.merge.258 ], [ %rs4gc.s5.relocated113, %pget.recv_sso.235 ], [ %rs4gc.s5.relocated118, %pget.recv_class_ref.238 ], [ %rs4gc.s5.relocated132, %pget.recv_undef_return.267 ]
  %r995 = phi double [ %r978, %pic.merge.258 ], [ %r986131, %pget.recv_undef_return.267 ], [ %r989, %pget.recv_sso.235 ], [ %r854117, %pget.recv_class_ref.238 ], [ %r994, %pget.strlen_heap.240 ]
  %r996.rs4i = ptrtoint ptr addrspace(1) %.0159 to i64
  %r996 = call i64 asm "", "=r,0"(i64 %r996.rs4i) #9
  %r997 = bitcast i64 %r996 to double
  %r998 = and i64 %r996, -281474976710656
  %r999 = icmp ult i64 %r998, 9221401712017801216
  %r1000 = icmp ugt i64 %r998, 9223090561878065152
  %r1001 = or i1 %r999, %r1000
  %r1002 = bitcast double %r995 to i64
  %r1003 = and i64 %r1002, -281474976710656
  %r1004 = icmp ult i64 %r1003, 9221401712017801216
  %r1005 = icmp ugt i64 %r1003, 9223090561878065152
  %r1006 = or i1 %r1004, %r1005
  %r1007 = and i1 %r1001, %r1006
  br i1 %r1007, label %guarded_add.numeric.268, label %guarded_add.dynamic.269

pget.strlen_heap.240:                             ; preds = %pget.recv_ok.236
  %r990 = icmp ult i64 %r845, 4096
  %r991 = inttoptr i64 %r845 to ptr
  %r992 = select i1 %r990, ptr @perry_null_guard_zero_options_worker_ts, ptr %r991
  %r993 = load i32, ptr %r992, align 4
  %r994 = uitofp i32 %r993 to double
  br label %pget.recv_merge.239

pget.recv_other.241:                              ; preds = %shadow.root.barrier.done.234
  %r849 = icmp eq i64 %r846, 32761
  br i1 %r849, label %pget.recv_sso.235, label %pget.check_class_ref.242

pget.check_class_ref.242:                         ; preds = %pget.recv_other.241
  %r850 = icmp eq i64 %r846, 32766
  br i1 %r850, label %pget.recv_class_ref.238, label %pget.recv_bad.237

pget.recv_obj.243:                                ; preds = %pget.recv_ok.236
  %r856 = icmp ugt i64 %r845, 1048575
  br i1 %r856, label %pic.recv_hdr.259, label %pic.miss.cold.256

pic.hit.244:                                      ; preds = %pic.token.260
  %r881 = getelementptr i64, ptr %r866, i64 1
  %r882 = load i64, ptr %r881, align 8
  %r883 = and i64 %r882, 1073741824
  %r884 = icmp ne i64 %r883, 0
  br i1 %r884, label %pic.hit.overflow.261, label %pic.hit.inline.262

pic.hit.live.245:                                 ; preds = %pic.hit.inline.262
  br label %pic.merge.258

pic.prefix.guard.246:                             ; preds = %pic.token.260
  %r897 = getelementptr i64, ptr %r866, i64 2
  %r898 = load i64, ptr %r897, align 8
  %r899 = icmp ne i64 %r898, 0
  br i1 %r899, label %pic.prefix.meta.247, label %pic.miss.255

pic.prefix.meta.247:                              ; preds = %pic.prefix.guard.246
  %r900 = add nuw nsw i64 %r845, 8
  %r901 = inttoptr i64 %r900 to ptr
  %r902 = load i64, ptr %r901, align 8
  %r903 = icmp ne i64 %r902, 0
  br i1 %r903, label %pic.prefix.token.248, label %pic.miss.255

pic.prefix.token.248:                             ; preds = %pic.prefix.meta.247
  %r904 = inttoptr i64 %r902 to ptr
  %r905 = getelementptr i64, ptr %r904, i64 6
  %r906 = load i64, ptr %r905, align 8
  %r907 = icmp eq i64 %r906, %r898
  br i1 %r907, label %pic.prefix.hit.249, label %pic.miss.255

pic.prefix.hit.249:                               ; preds = %pic.prefix.token.248
  %r908 = getelementptr i64, ptr %r866, i64 1
  %r909 = load i64, ptr %r908, align 8
  %r910 = shl i64 %r909, 3
  %r911 = add nuw nsw i64 %r845, 16
  %r912 = add i64 %r911, %r910
  %r913 = inttoptr i64 %r912 to ptr
  %r914 = load double, ptr %r913, align 8
  br label %pic.merge.258

pic.desc.classify.250:                            ; preds = %pic.recv_hdr.259
  %r870 = and i1 %r860, %r867
  br i1 %r870, label %pic.desc.prefix.guard.251, label %pic.miss.cold.256

pic.desc.prefix.guard.251:                        ; preds = %pic.desc.classify.250
  %r915 = getelementptr i64, ptr %r866, i64 2
  %r916 = load i64, ptr %r915, align 8
  %r917 = icmp ne i64 %r916, 0
  br i1 %r917, label %pic.desc.prefix.meta.252, label %pic.miss.cold.256

pic.desc.prefix.meta.252:                         ; preds = %pic.desc.prefix.guard.251
  %r918 = add nuw nsw i64 %r845, 8
  %r919 = inttoptr i64 %r918 to ptr
  %r920 = load i64, ptr %r919, align 8
  %r921 = icmp ne i64 %r920, 0
  br i1 %r921, label %pic.desc.prefix.token.253, label %pic.miss.cold.256

pic.desc.prefix.token.253:                        ; preds = %pic.desc.prefix.meta.252
  %r922 = inttoptr i64 %r920 to ptr
  %r923 = getelementptr i64, ptr %r922, i64 6
  %r924 = load i64, ptr %r923, align 8
  %r925 = icmp eq i64 %r924, %r916
  br i1 %r925, label %pic.desc.prefix.hit.254, label %pic.miss.cold.256

pic.desc.prefix.hit.254:                          ; preds = %pic.desc.prefix.token.253
  %r926 = getelementptr i64, ptr %r866, i64 1
  %r927 = load i64, ptr %r926, align 8
  %r928 = shl i64 %r927, 3
  %r929 = add nuw nsw i64 %r845, 16
  %r930 = add i64 %r929, %r928
  %r931 = inttoptr i64 %r930 to ptr
  %r932 = load double, ptr %r931, align 8
  br label %pic.merge.258

pic.miss.255:                                     ; preds = %pic.hit.inline.262, %pic.prefix.token.248, %pic.prefix.meta.247, %pic.prefix.guard.246
  %r933 = getelementptr i64, ptr %r866, i64 3
  %r934 = load i64, ptr %r933, align 8
  %r935 = icmp sgt i64 %r934, 0
  br i1 %r935, label %pic.ways.263, label %pic.miss.call.257

pic.miss.cold.256:                                ; preds = %pic.desc.prefix.token.253, %pic.desc.prefix.meta.252, %pic.desc.prefix.guard.251, %pic.desc.classify.250, %pget.recv_obj.243
  br label %pic.miss.call.257

pic.miss.call.257:                                ; preds = %pic.way.load.264, %pic.ways.263, %pic.miss.cold.256, %pic.miss.255
  %r974 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r975 = bitcast double %r974 to i64
  %r976 = and i64 %r975, 281474976710655
  %statepoint_token119 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r845, i64 %r976, ptr @perry_ic_options_worker_ts__7, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated113, ptr addrspace(1) %rs4gc.s12, ptr addrspace(1) %rs4gc.s13) ]
  %r977120 = call double @llvm.experimental.gc.result.f64(token %statepoint_token119)
  %rs4gc.s5.relocated121 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token119, i32 0, i32 0) ; (%rs4gc.s5.relocated113, %rs4gc.s5.relocated113)
  %rs4gc.s12.relocated122 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token119, i32 1, i32 1) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13.relocated123 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token119, i32 2, i32 2) ; (%rs4gc.s13, %rs4gc.s13)
  br label %pic.merge.258

pic.merge.258:                                    ; preds = %pic.way.live.265, %pic.hit.overflow.261, %pic.miss.call.257, %pic.desc.prefix.hit.254, %pic.prefix.hit.249, %pic.hit.live.245
  %.1160 = phi ptr addrspace(1) [ %rs4gc.s13.relocated128, %pic.hit.overflow.261 ], [ %rs4gc.s13.relocated123, %pic.miss.call.257 ], [ %rs4gc.s13, %pic.way.live.265 ], [ %rs4gc.s13, %pic.hit.live.245 ], [ %rs4gc.s13, %pic.prefix.hit.249 ], [ %rs4gc.s13, %pic.desc.prefix.hit.254 ]
  %.1157 = phi ptr addrspace(1) [ %rs4gc.s12.relocated127, %pic.hit.overflow.261 ], [ %rs4gc.s12.relocated122, %pic.miss.call.257 ], [ %rs4gc.s12, %pic.way.live.265 ], [ %rs4gc.s12, %pic.hit.live.245 ], [ %rs4gc.s12, %pic.prefix.hit.249 ], [ %rs4gc.s12, %pic.desc.prefix.hit.254 ]
  %.29 = phi ptr addrspace(1) [ %rs4gc.s5.relocated126, %pic.hit.overflow.261 ], [ %rs4gc.s5.relocated121, %pic.miss.call.257 ], [ %rs4gc.s5.relocated113, %pic.way.live.265 ], [ %rs4gc.s5.relocated113, %pic.hit.live.245 ], [ %rs4gc.s5.relocated113, %pic.prefix.hit.249 ], [ %rs4gc.s5.relocated113, %pic.desc.prefix.hit.254 ]
  %r978 = phi double [ %r894, %pic.hit.live.245 ], [ %r889125, %pic.hit.overflow.261 ], [ %r914, %pic.prefix.hit.249 ], [ %r932, %pic.desc.prefix.hit.254 ], [ %r971, %pic.way.live.265 ], [ %r977120, %pic.miss.call.257 ]
  br label %pget.recv_merge.239

pic.recv_hdr.259:                                 ; preds = %pget.recv_obj.243
  %r857 = sub nuw nsw i64 %r845, 8
  %r858 = inttoptr i64 %r857 to ptr
  %r859 = load i8, ptr %r858, align 1
  %r860 = icmp eq i8 %r859, 2
  %r861 = sub nuw nsw i64 %r845, 6
  %r862 = inttoptr i64 %r861 to ptr
  %r863 = load i16, ptr %r862, align 2
  %r864 = and i16 %r863, 2048
  %r865 = icmp eq i16 %r864, 0
  %r866 = load ptr, ptr @perry_ic_options_worker_ts__7, align 8
  %r867 = icmp ne ptr %r866, null
  %r868 = and i1 %r860, %r865
  %r869 = and i1 %r868, %r867
  br i1 %r869, label %pic.token.260, label %pic.desc.classify.250

pic.token.260:                                    ; preds = %pic.recv_hdr.259
  %r871 = add nuw nsw i64 %r845, 4
  %r872 = inttoptr i64 %r871 to ptr
  %r873 = load i32, ptr %r872, align 4
  %r874 = zext i32 %r873 to i64
  %r875 = or i64 %r874, 4611686018427387904
  %r876 = icmp ne i32 %r873, 0
  %r877 = getelementptr i64, ptr %r866, i64 0
  %r878 = load i64, ptr %r877, align 8
  %r879 = icmp eq i64 %r875, %r878
  %r880 = and i1 %r879, %r876
  br i1 %r880, label %pic.hit.244, label %pic.prefix.guard.246

pic.hit.overflow.261:                             ; preds = %pic.hit.244
  %r885 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r886 = bitcast double %r885 to i64
  %r887 = and i64 %r886, 281474976710655
  %r888 = trunc i64 %r882 to i32
  %statepoint_token124 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r845, i64 %r887, i32 %r888, ptr @perry_ic_options_worker_ts__7, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated113, ptr addrspace(1) %rs4gc.s12, ptr addrspace(1) %rs4gc.s13) ]
  %r889125 = call double @llvm.experimental.gc.result.f64(token %statepoint_token124)
  %rs4gc.s5.relocated126 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token124, i32 0, i32 0) ; (%rs4gc.s5.relocated113, %rs4gc.s5.relocated113)
  %rs4gc.s12.relocated127 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token124, i32 1, i32 1) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13.relocated128 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token124, i32 2, i32 2) ; (%rs4gc.s13, %rs4gc.s13)
  br label %pic.merge.258

pic.hit.inline.262:                               ; preds = %pic.hit.244
  %r890 = shl i64 %r882, 3
  %r891 = add nuw nsw i64 %r845, 16
  %r892 = add i64 %r891, %r890
  %r893 = inttoptr i64 %r892 to ptr
  %r894 = load double, ptr %r893, align 8
  %r895 = bitcast double %r894 to i64
  %r896 = icmp eq i64 %r895, 9222246136947933200
  br i1 %r896, label %pic.miss.255, label %pic.hit.live.245

pic.ways.263:                                     ; preds = %pic.miss.255
  %r936 = getelementptr i64, ptr %r866, i64 4
  %r937 = load i64, ptr %r936, align 8
  %r938 = icmp eq i64 %r937, %r875
  %r939 = getelementptr i64, ptr %r866, i64 5
  %r940 = load i64, ptr %r939, align 8
  %r941 = select i1 %r938, i64 %r940, i64 0
  %r942 = getelementptr i64, ptr %r866, i64 6
  %r943 = load i64, ptr %r942, align 8
  %r944 = icmp eq i64 %r943, %r875
  %r945 = getelementptr i64, ptr %r866, i64 7
  %r946 = load i64, ptr %r945, align 8
  %r947 = select i1 %r944, i64 %r946, i64 0
  %r948 = getelementptr i64, ptr %r866, i64 8
  %r949 = load i64, ptr %r948, align 8
  %r950 = icmp eq i64 %r949, %r875
  %r951 = getelementptr i64, ptr %r866, i64 9
  %r952 = load i64, ptr %r951, align 8
  %r953 = select i1 %r950, i64 %r952, i64 0
  %r954 = getelementptr i64, ptr %r866, i64 10
  %r955 = load i64, ptr %r954, align 8
  %r956 = icmp eq i64 %r955, %r875
  %r957 = getelementptr i64, ptr %r866, i64 11
  %r958 = load i64, ptr %r957, align 8
  %r959 = select i1 %r956, i64 %r958, i64 0
  %r960 = or i1 %r938, %r944
  %r961 = select i1 %r938, i64 %r941, i64 %r947
  %r962 = or i1 %r950, %r956
  %r963 = select i1 %r950, i64 %r953, i64 %r959
  %r964 = or i1 %r960, %r962
  %r965 = select i1 %r960, i64 %r961, i64 %r963
  %r966 = and i1 %r876, %r964
  br i1 %r966, label %pic.way.load.264, label %pic.miss.call.257

pic.way.load.264:                                 ; preds = %pic.ways.263
  %r967 = shl i64 %r965, 3
  %r968 = add nuw nsw i64 %r845, 16
  %r969 = add i64 %r968, %r967
  %r970 = inttoptr i64 %r969 to ptr
  %r971 = load double, ptr %r970, align 8
  %r972 = bitcast double %r971 to i64
  %r973 = icmp eq i64 %r972, 9222246136947933200
  br i1 %r973, label %pic.miss.call.257, label %pic.way.live.265

pic.way.live.265:                                 ; preds = %pic.way.load.264
  br label %pic.merge.258

pget.throw_nullish.266:                           ; preds = %pget.recv_bad.237
  %r982 = zext i1 %r980 to i32
  %statepoint_token129 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r982, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.267:                       ; preds = %pget.recv_bad.237
  %r983 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r984 = bitcast double %r983 to i64
  %r985 = and i64 %r984, 281474976710655
  %statepoint_token130 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r844, i64 %r985, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated113, ptr addrspace(1) %rs4gc.s12, ptr addrspace(1) %rs4gc.s13) ]
  %r986131 = call double @llvm.experimental.gc.result.f64(token %statepoint_token130)
  %rs4gc.s5.relocated132 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token130, i32 0, i32 0) ; (%rs4gc.s5.relocated113, %rs4gc.s5.relocated113)
  %rs4gc.s12.relocated133 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token130, i32 1, i32 1) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13.relocated134 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token130, i32 2, i32 2) ; (%rs4gc.s13, %rs4gc.s13)
  br label %pget.recv_merge.239

guarded_add.numeric.268:                          ; preds = %pget.recv_merge.239
  %r1008 = fadd double %r997, %r995
  br label %guarded_add.merge.270

guarded_add.dynamic.269:                          ; preds = %pget.recv_merge.239
  %statepoint_token135 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r997, double %r995, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.28, ptr addrspace(1) %.0156) ]
  %r1009136 = call double @llvm.experimental.gc.result.f64(token %statepoint_token135)
  %rs4gc.s5.relocated137 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 0, i32 0) ; (%.28, %.28)
  %rs4gc.s12.relocated138 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 1, i32 1) ; (%.0156, %.0156)
  br label %guarded_add.merge.270

guarded_add.merge.270:                            ; preds = %guarded_add.dynamic.269, %guarded_add.numeric.268
  %.2158 = phi ptr addrspace(1) [ %.0156, %guarded_add.numeric.268 ], [ %rs4gc.s12.relocated138, %guarded_add.dynamic.269 ]
  %.30 = phi ptr addrspace(1) [ %.28, %guarded_add.numeric.268 ], [ %rs4gc.s5.relocated137, %guarded_add.dynamic.269 ]
  %r1010 = phi double [ %r1008, %guarded_add.numeric.268 ], [ %r1009136, %guarded_add.dynamic.269 ]
  %r1011.rs4i = ptrtoint ptr addrspace(1) %.2158 to i64
  %r1011.rs4o = call i64 asm "", "=r,0"(i64 %r1011.rs4i) #9
  %r1011 = bitcast i64 %r1011.rs4o to double
  %r1012 = bitcast double %r1011 to i64
  %r1013 = and i64 %r1012, -281474976710656
  %r1014 = icmp ne i64 %r1013, 9223090561878065152
  br i1 %r1014, label %str_addref.done.272, label %str_addref.call.271

str_addref.call.271:                              ; preds = %guarded_add.merge.270
  call void @js_string_addref_if_heap_string(double %r1011) #9
  br label %str_addref.done.272

str_addref.done.272:                              ; preds = %str_addref.call.271, %guarded_add.merge.270
  %r1026.rs4i = ptrtoint ptr addrspace(1) %.2158 to i64
  %r1026.rs4o = call i64 asm "", "=r,0"(i64 %r1026.rs4i) #9
  %r1026 = bitcast i64 %r1026.rs4o to double
  store double %r1026, ptr @perry_global_options_worker_ts__6, align 8
  %r1025.rs4i = ptrtoint ptr addrspace(1) %.2158 to i64
  %r1025.rs4o = call i64 asm "", "=r,0"(i64 %r1025.rs4i) #9
  %r1025 = bitcast i64 %r1025.rs4o to double
  %r1015 = bitcast double %r1025 to i64
  %r1023.rs4i = ptrtoint ptr addrspace(1) %.2158 to i64
  %r1023.rs4o = call i64 asm "", "=r,0"(i64 %r1023.rs4i) #9
  %r1023 = bitcast i64 %r1023.rs4o to double
  %r1024 = bitcast double %r1023 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1024) #9
  %r1016 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1017 = icmp ne i32 %r1016, 0
  br i1 %r1017, label %gcpoll.273, label %gcpoll.done.274

gcpoll.273:                                       ; preds = %str_addref.done.272
  %statepoint_token139 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.30) ]
  %rs4gc.s5.relocated140 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token139, i32 0, i32 0) ; (%.30, %.30)
  br label %gcpoll.done.274

gcpoll.done.274:                                  ; preds = %gcpoll.273, %str_addref.done.272
  %.31 = phi ptr addrspace(1) [ %rs4gc.s5.relocated140, %gcpoll.273 ], [ %.30, %str_addref.done.272 ]
  br label %for.update.225
}

; Function Attrs: inlinehint optsize
define internal double @"perry_fn_options_worker_ts__identity$generic"(double %arg13, double %arg14) #7 gc "statepoint-example" {
entry.0:
  %rs4gc.b1 = bitcast double %arg13 to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg14 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %r3.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r3.rs4o = call i64 asm "", "=r,0"(i64 %r3.rs4i) #9
  %r3 = bitcast i64 %r3.rs4o to double
  ret double %r3
}

; Function Attrs: noinline optsize
define double @perry_fn_options_worker_ts__identity(double %arg13, double %arg14) #8 {
entry.0:
  %r1 = call i32 @js_typed_string_arg_guard(double %arg13)
  %r2 = icmp ne i32 %r1, 0
  br i1 %r2, label %spec_public.fast.1, label %spec_public.fallback.2

spec_public.fast.1:                               ; preds = %entry.0
  %r3 = call double @"perry_fn_options_worker_ts__identity$spec_b_b"(double %arg13, double %arg14)
  ret double %r3

spec_public.fallback.2:                           ; preds = %entry.0
  %r4 = call double @"perry_fn_options_worker_ts__identity$generic"(double %arg13, double %arg14)
  ret double %r4
}

; Function Attrs: optsize
define internal double @"perry_fn_options_worker_ts__run$generic"(double %arg15) #6 gc "statepoint-example" {
entry.0:
  %rs4gc.b5 = bitcast double %arg15 to i64
  %rs4gc.s5 = inttoptr i64 %rs4gc.b5 to ptr addrspace(1)
  %r3 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r4 = load double, ptr @options_worker_ts_.str.0.handle, align 8
  %r5 = bitcast double %r3 to i64
  %r6 = bitcast double %r4 to i64
  %r7 = icmp eq i64 %r5, %r6
  br i1 %r7, label %streqlit.true.7, label %streqlit.sso.1

streqlit.sso.1:                                   ; preds = %entry.0
  %r8 = icmp eq i64 %r5, 9221406111934080378
  br i1 %r8, label %streqlit.true.7, label %streqlit.tag.2

streqlit.tag.2:                                   ; preds = %streqlit.sso.1
  %r9 = lshr i64 %r5, 48
  %r10 = icmp eq i64 %r9, 32767
  %r11 = and i64 %r5, 281474976710655
  %r12 = icmp ugt i64 %r11, 4095
  %r13 = and i1 %r10, %r12
  br i1 %r13, label %streqlit.len.3, label %streqlit.false.8

streqlit.len.3:                                   ; preds = %streqlit.tag.2
  %r14 = inttoptr i64 %r11 to ptr
  %r15 = getelementptr inbounds nuw i8, ptr %r14, i64 4
  %r16 = load i32, ptr %r15, align 4
  %r17 = icmp eq i32 %r16, 4
  br i1 %r17, label %streqlit.b0.4, label %streqlit.false.8

streqlit.b0.4:                                    ; preds = %streqlit.len.3
  %r18 = getelementptr inbounds nuw i8, ptr %r14, i64 20
  %r19 = load i8, ptr %r18, align 1
  %r20 = icmp eq i8 %r19, 122
  br i1 %r20, label %streqlit.bl.5, label %streqlit.false.8

streqlit.bl.5:                                    ; preds = %streqlit.b0.4
  %r21 = getelementptr inbounds nuw i8, ptr %r14, i64 23
  %r22 = load i8, ptr %r21, align 1
  %r23 = icmp eq i8 %r22, 111
  br i1 %r23, label %streqlit.slow.6, label %streqlit.false.8

streqlit.slow.6:                                  ; preds = %streqlit.bl.5
  %r24 = and i64 %r6, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r11, i64 %r24, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5) ]
  %r2510 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token)
  %rs4gc.s5.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s5, %rs4gc.s5)
  %r26 = icmp ne i32 %r2510, 0
  br label %streqlit.merge.9

streqlit.true.7:                                  ; preds = %streqlit.sso.1, %entry.0
  br label %streqlit.merge.9

streqlit.false.8:                                 ; preds = %streqlit.bl.5, %streqlit.b0.4, %streqlit.len.3, %streqlit.tag.2
  br label %streqlit.merge.9

streqlit.merge.9:                                 ; preds = %streqlit.false.8, %streqlit.true.7, %streqlit.slow.6
  %.0 = phi ptr addrspace(1) [ %rs4gc.s5, %streqlit.true.7 ], [ %rs4gc.s5.relocated, %streqlit.slow.6 ], [ %rs4gc.s5, %streqlit.false.8 ]
  %r27 = phi i1 [ true, %streqlit.true.7 ], [ false, %streqlit.false.8 ], [ %r26, %streqlit.slow.6 ]
  %r28 = select i1 %r27, i64 9222246136947933188, i64 9222246136947933187
  %r29 = bitcast i64 %r28 to double
  %r30 = icmp eq i64 %r28, 9222246136947933188
  br i1 %r30, label %if.then.10, label %if.else.11

if.then.10:                                       ; preds = %streqlit.merge.9
  %r35.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r35.rs4o = call i64 asm "", "=r,0"(i64 %r35.rs4i) #9
  %r35 = bitcast i64 %r35.rs4o to double
  %r36 = bitcast double %r35 to i64
  %r37 = and i64 %r36, -281474976710656
  %r38 = icmp ult i64 %r37, 9221401712017801216
  %r39 = icmp ugt i64 %r37, 9223090561878065152
  %r40 = or i1 %r38, %r39
  br i1 %r40, label %for.bound_i32.number.13, label %for.bound_i32.merge.15

if.else.11:                                       ; preds = %streqlit.merge.9
  %r287 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r288 = load double, ptr @options_worker_ts_.str.2.handle, align 8
  %r289 = bitcast double %r287 to i64
  %r290 = bitcast double %r288 to i64
  %r291 = icmp eq i64 %r289, %r290
  br i1 %r291, label %streqlit.true.78, label %streqlit.tag.73

if.merge.12:                                      ; preds = %if.merge.83, %for.exit.21
  %r2.0 = phi double [ %r2.1, %for.exit.21 ], [ %r2.2, %if.merge.83 ]
  ret double %r2.0

for.bound_i32.number.13:                          ; preds = %if.then.10
  %r41 = fcmp oge double %r35, 0xC1E0000000000000
  %r42 = fcmp ole double %r35, 0x41DFFFFFFFC00000
  %r43 = and i1 %r41, %r42
  br i1 %r43, label %for.bound_i32.convert.14, label %for.bound_i32.merge.15

for.bound_i32.convert.14:                         ; preds = %for.bound_i32.number.13
  %r44 = fptosi double %r35 to i32
  %r45 = sitofp i32 %r44 to double
  %r46 = fcmp oeq double %r45, %r35
  br i1 %r46, label %for.counter_i32.range.16, label %for.bound_i32.merge.15

for.bound_i32.merge.15:                           ; preds = %for.counter_i32.convert.17, %for.bound_i32.convert.14, %for.bound_i32.number.13, %if.then.10
  %r34.0 = phi i32 [ %r44, %for.counter_i32.convert.17 ], [ 0, %if.then.10 ], [ %r44, %for.bound_i32.convert.14 ], [ 0, %for.bound_i32.number.13 ]
  %r33.0 = phi i1 [ true, %for.counter_i32.convert.17 ], [ false, %if.then.10 ], [ false, %for.bound_i32.convert.14 ], [ false, %for.bound_i32.number.13 ]
  br label %for.cond.18

for.counter_i32.range.16:                         ; preds = %for.bound_i32.convert.14
  br label %for.counter_i32.convert.17

for.counter_i32.convert.17:                       ; preds = %for.counter_i32.range.16
  br label %for.bound_i32.merge.15

for.cond.18:                                      ; preds = %for.update.20, %for.bound_i32.merge.15
  %.1 = phi ptr addrspace(1) [ %.0, %for.bound_i32.merge.15 ], [ %.8, %for.update.20 ]
  %r32.1 = phi i32 [ 0, %for.bound_i32.merge.15 ], [ %r286, %for.update.20 ]
  %r31.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.15 ], [ %r284, %for.update.20 ]
  %r2.1 = phi double [ 0.000000e+00, %for.bound_i32.merge.15 ], [ %r275, %for.update.20 ]
  br i1 %r33.0, label %for.cond.fast.22, label %for.cond.slow.23

for.body.19:                                      ; preds = %gcpoll.done.28, %for.cond.fast.22
  %.2 = phi ptr addrspace(1) [ %.1, %for.cond.fast.22 ], [ %.4, %gcpoll.done.28 ]
  %r96 = load double, ptr @perry_global_options_worker_ts__4, align 8
  %statepoint_token11 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r96, double 0x7FFC000000000002, double 0.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r9712 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token11)
  %rs4gc.s5.relocated13 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token11, i32 0, i32 0) ; (%.2, %.2)
  %r98 = bitcast i64 %r9712 to double
  %rs4gc.b6 = bitcast double %r98 to i64
  %rs4gc.s6 = inttoptr i64 %rs4gc.b6 to ptr addrspace(1)
  %r99.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r99 = call i64 asm "", "=r,0"(i64 %r99.rs4i) #9
  %r100 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r101 = icmp ne i32 %r100, 0
  br i1 %r101, label %shadow.root.barrier.29, label %shadow.root.barrier.done.30

for.update.20:                                    ; preds = %gcpoll.done.72
  %r284 = fadd double %r31.0, 1.000000e+00
  %r286 = add i32 %r32.1, 1
  br label %for.cond.18

for.exit.21:                                      ; preds = %gcpoll.done.28, %for.cond.fast.22
  br label %if.merge.12

for.cond.fast.22:                                 ; preds = %for.cond.18
  %r57 = icmp slt i32 %r32.1, %r34.0
  br i1 %r57, label %for.body.19, label %for.exit.21

for.cond.slow.23:                                 ; preds = %for.cond.18
  %r59.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r59.rs4o = call i64 asm "", "=r,0"(i64 %r59.rs4i) #9
  %r59 = bitcast i64 %r59.rs4o to double
  %r60 = bitcast double %r59 to i64
  %r61 = lshr i64 %r60, 48
  %r62 = icmp ult i64 %r61, 32761
  %r63 = icmp ugt i64 %r61, 32767
  %r64 = or i1 %r62, %r63
  %r65 = icmp eq i64 %r61, 32766
  %r66 = icmp eq i64 %r60, 9222246136947933185
  %r67 = icmp eq i64 %r60, 9222246136947933186
  %r68 = icmp eq i64 %r60, 9222246136947933187
  %r69 = icmp eq i64 %r60, 9222246136947933188
  %r70 = or i1 %r67, %r68
  %r71 = or i1 %r64, %r65
  %r72 = or i1 %r71, %r66
  %r73 = or i1 %r72, %r70
  %r74 = or i1 %r73, %r69
  br i1 %r74, label %relnum.fast.24, label %relnum.slow.25

relnum.fast.24:                                   ; preds = %for.cond.slow.23
  %r75 = trunc i64 %r60 to i32
  %r76 = sitofp i32 %r75 to double
  %r77 = select i1 %r65, double %r76, double %r59
  %r78 = select i1 %r70, double 0.000000e+00, double %r77
  %r79 = select i1 %r69, double 1.000000e+00, double %r78
  %r80 = bitcast double %r31.0 to i64
  %r81 = lshr i64 %r80, 48
  %r82 = icmp eq i64 %r81, 32766
  %r83 = trunc i64 %r80 to i32
  %r84 = sitofp i32 %r83 to double
  %r85 = select i1 %r82, double %r84, double %r31.0
  %r86 = fcmp olt double %r85, %r79
  %r87 = select i1 %r86, i64 9222246136947933188, i64 9222246136947933187
  %r88 = bitcast i64 %r87 to double
  br label %relnum.merge.26

relnum.slow.25:                                   ; preds = %for.cond.slow.23
  %statepoint_token14 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_rel_lt, i32 2, i32 0, double %r31.0, double %r59, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1) ]
  %r8915 = call double @llvm.experimental.gc.result.f64(token %statepoint_token14)
  %rs4gc.s5.relocated16 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token14, i32 0, i32 0) ; (%.1, %.1)
  br label %relnum.merge.26

relnum.merge.26:                                  ; preds = %relnum.slow.25, %relnum.fast.24
  %.3 = phi ptr addrspace(1) [ %.1, %relnum.fast.24 ], [ %rs4gc.s5.relocated16, %relnum.slow.25 ]
  %r90 = phi double [ %r88, %relnum.fast.24 ], [ %r8915, %relnum.slow.25 ]
  %r91 = bitcast double %r90 to i64
  %r93 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r94 = icmp ne i32 %r93, 0
  br i1 %r94, label %gcpoll.27, label %gcpoll.done.28

gcpoll.27:                                        ; preds = %relnum.merge.26
  %statepoint_token17 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3) ]
  %rs4gc.s5.relocated18 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token17, i32 0, i32 0) ; (%.3, %.3)
  br label %gcpoll.done.28

gcpoll.done.28:                                   ; preds = %gcpoll.27, %relnum.merge.26
  %.4 = phi ptr addrspace(1) [ %rs4gc.s5.relocated18, %gcpoll.27 ], [ %.3, %relnum.merge.26 ]
  %r92 = icmp eq i64 %r91, 9222246136947933188
  br i1 %r92, label %for.body.19, label %for.exit.21

shadow.root.barrier.29:                           ; preds = %for.body.19
  call void @js_write_barrier_root_nanbox(i64 %r99) #9
  br label %shadow.root.barrier.done.30

shadow.root.barrier.done.30:                      ; preds = %shadow.root.barrier.29, %for.body.19
  %r103 = bitcast double %r2.1 to i64
  %rs4gc.s7 = inttoptr i64 %r103 to ptr addrspace(1)
  %r105.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7 to i64
  %r105 = call i64 asm "", "=r,0"(i64 %r105.rs4i) #9
  %r106 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r107 = icmp ne i32 %r106, 0
  br i1 %r107, label %shadow.root.barrier.31, label %shadow.root.barrier.done.32

shadow.root.barrier.31:                           ; preds = %shadow.root.barrier.done.30
  call void @js_write_barrier_root_nanbox(i64 %r105) #9
  br label %shadow.root.barrier.done.32

shadow.root.barrier.done.32:                      ; preds = %shadow.root.barrier.31, %shadow.root.barrier.done.30
  %r108.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r108.rs4o = call i64 asm "", "=r,0"(i64 %r108.rs4i) #9
  %r108 = bitcast i64 %r108.rs4o to double
  %r109 = bitcast double %r108 to i64
  %r110 = and i64 %r109, 281474976710655
  %r111 = lshr i64 %r109, 48
  %r112 = and i64 %r111, 65533
  %r113 = icmp eq i64 %r112, 32765
  br i1 %r113, label %pget.recv_ok.34, label %pget.recv_other.39

pget.recv_sso.33:                                 ; preds = %pget.recv_other.39
  %r252 = lshr i64 %r109, 40
  %r253 = and i64 %r252, 255
  %r254 = uitofp nneg i64 %r253 to double
  br label %pget.recv_merge.37

pget.recv_ok.34:                                  ; preds = %shadow.root.barrier.done.32
  %r120 = icmp eq i64 %r111, 32767
  br i1 %r120, label %pget.strlen_heap.38, label %pget.recv_obj.41

pget.recv_bad.35:                                 ; preds = %pget.check_class_ref.40
  %r244 = icmp eq i64 %r109, 9222246136947933185
  %r245 = icmp eq i64 %r109, 9222246136947933186
  %r246 = or i1 %r244, %r245
  br i1 %r246, label %pget.throw_nullish.64, label %pget.recv_undef_return.65

pget.recv_class_ref.36:                           ; preds = %pget.check_class_ref.40
  %r116 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r117 = bitcast double %r116 to i64
  %r118 = and i64 %r117, 281474976710655
  %statepoint_token19 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532872, i64 %r109, i64 %r118, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated13, ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %rs4gc.s7) ]
  %r11920 = call double @llvm.experimental.gc.result.f64(token %statepoint_token19)
  %rs4gc.s5.relocated21 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 0, i32 0) ; (%rs4gc.s5.relocated13, %rs4gc.s5.relocated13)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 1, i32 1) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 2, i32 2) ; (%rs4gc.s7, %rs4gc.s7)
  br label %pget.recv_merge.37

pget.recv_merge.37:                               ; preds = %pget.recv_undef_return.65, %pic.merge.56, %pget.strlen_heap.38, %pget.recv_class_ref.36, %pget.recv_sso.33
  %.0158 = phi ptr addrspace(1) [ %rs4gc.s7, %pget.strlen_heap.38 ], [ %.1159, %pic.merge.56 ], [ %rs4gc.s7, %pget.recv_sso.33 ], [ %rs4gc.s7.relocated, %pget.recv_class_ref.36 ], [ %rs4gc.s7.relocated37, %pget.recv_undef_return.65 ]
  %.0155 = phi ptr addrspace(1) [ %rs4gc.s6, %pget.strlen_heap.38 ], [ %.1156, %pic.merge.56 ], [ %rs4gc.s6, %pget.recv_sso.33 ], [ %rs4gc.s6.relocated, %pget.recv_class_ref.36 ], [ %rs4gc.s6.relocated36, %pget.recv_undef_return.65 ]
  %.5 = phi ptr addrspace(1) [ %rs4gc.s5.relocated13, %pget.strlen_heap.38 ], [ %.6, %pic.merge.56 ], [ %rs4gc.s5.relocated13, %pget.recv_sso.33 ], [ %rs4gc.s5.relocated21, %pget.recv_class_ref.36 ], [ %rs4gc.s5.relocated35, %pget.recv_undef_return.65 ]
  %r260 = phi double [ %r243, %pic.merge.56 ], [ %r25134, %pget.recv_undef_return.65 ], [ %r254, %pget.recv_sso.33 ], [ %r11920, %pget.recv_class_ref.36 ], [ %r259, %pget.strlen_heap.38 ]
  %r261.rs4i = ptrtoint ptr addrspace(1) %.0158 to i64
  %r261 = call i64 asm "", "=r,0"(i64 %r261.rs4i) #9
  %r262 = bitcast i64 %r261 to double
  %r263 = and i64 %r261, -281474976710656
  %r264 = icmp ult i64 %r263, 9221401712017801216
  %r265 = icmp ugt i64 %r263, 9223090561878065152
  %r266 = or i1 %r264, %r265
  %r267 = bitcast double %r260 to i64
  %r268 = and i64 %r267, -281474976710656
  %r269 = icmp ult i64 %r268, 9221401712017801216
  %r270 = icmp ugt i64 %r268, 9223090561878065152
  %r271 = or i1 %r269, %r270
  %r272 = and i1 %r266, %r271
  br i1 %r272, label %guarded_add.numeric.66, label %guarded_add.dynamic.67

pget.strlen_heap.38:                              ; preds = %pget.recv_ok.34
  %r255 = icmp ult i64 %r110, 4096
  %r256 = inttoptr i64 %r110 to ptr
  %r257 = select i1 %r255, ptr @perry_null_guard_zero_options_worker_ts, ptr %r256
  %r258 = load i32, ptr %r257, align 4
  %r259 = uitofp i32 %r258 to double
  br label %pget.recv_merge.37

pget.recv_other.39:                               ; preds = %shadow.root.barrier.done.32
  %r114 = icmp eq i64 %r111, 32761
  br i1 %r114, label %pget.recv_sso.33, label %pget.check_class_ref.40

pget.check_class_ref.40:                          ; preds = %pget.recv_other.39
  %r115 = icmp eq i64 %r111, 32766
  br i1 %r115, label %pget.recv_class_ref.36, label %pget.recv_bad.35

pget.recv_obj.41:                                 ; preds = %pget.recv_ok.34
  %r121 = icmp ugt i64 %r110, 1048575
  br i1 %r121, label %pic.recv_hdr.57, label %pic.miss.cold.54

pic.hit.42:                                       ; preds = %pic.token.58
  %r146 = getelementptr i64, ptr %r131, i64 1
  %r147 = load i64, ptr %r146, align 8
  %r148 = and i64 %r147, 1073741824
  %r149 = icmp ne i64 %r148, 0
  br i1 %r149, label %pic.hit.overflow.59, label %pic.hit.inline.60

pic.hit.live.43:                                  ; preds = %pic.hit.inline.60
  br label %pic.merge.56

pic.prefix.guard.44:                              ; preds = %pic.token.58
  %r162 = getelementptr i64, ptr %r131, i64 2
  %r163 = load i64, ptr %r162, align 8
  %r164 = icmp ne i64 %r163, 0
  br i1 %r164, label %pic.prefix.meta.45, label %pic.miss.53

pic.prefix.meta.45:                               ; preds = %pic.prefix.guard.44
  %r165 = add nuw nsw i64 %r110, 8
  %r166 = inttoptr i64 %r165 to ptr
  %r167 = load i64, ptr %r166, align 8
  %r168 = icmp ne i64 %r167, 0
  br i1 %r168, label %pic.prefix.token.46, label %pic.miss.53

pic.prefix.token.46:                              ; preds = %pic.prefix.meta.45
  %r169 = inttoptr i64 %r167 to ptr
  %r170 = getelementptr i64, ptr %r169, i64 6
  %r171 = load i64, ptr %r170, align 8
  %r172 = icmp eq i64 %r171, %r163
  br i1 %r172, label %pic.prefix.hit.47, label %pic.miss.53

pic.prefix.hit.47:                                ; preds = %pic.prefix.token.46
  %r173 = getelementptr i64, ptr %r131, i64 1
  %r174 = load i64, ptr %r173, align 8
  %r175 = shl i64 %r174, 3
  %r176 = add nuw nsw i64 %r110, 16
  %r177 = add i64 %r176, %r175
  %r178 = inttoptr i64 %r177 to ptr
  %r179 = load double, ptr %r178, align 8
  br label %pic.merge.56

pic.desc.classify.48:                             ; preds = %pic.recv_hdr.57
  %r135 = and i1 %r125, %r132
  br i1 %r135, label %pic.desc.prefix.guard.49, label %pic.miss.cold.54

pic.desc.prefix.guard.49:                         ; preds = %pic.desc.classify.48
  %r180 = getelementptr i64, ptr %r131, i64 2
  %r181 = load i64, ptr %r180, align 8
  %r182 = icmp ne i64 %r181, 0
  br i1 %r182, label %pic.desc.prefix.meta.50, label %pic.miss.cold.54

pic.desc.prefix.meta.50:                          ; preds = %pic.desc.prefix.guard.49
  %r183 = add nuw nsw i64 %r110, 8
  %r184 = inttoptr i64 %r183 to ptr
  %r185 = load i64, ptr %r184, align 8
  %r186 = icmp ne i64 %r185, 0
  br i1 %r186, label %pic.desc.prefix.token.51, label %pic.miss.cold.54

pic.desc.prefix.token.51:                         ; preds = %pic.desc.prefix.meta.50
  %r187 = inttoptr i64 %r185 to ptr
  %r188 = getelementptr i64, ptr %r187, i64 6
  %r189 = load i64, ptr %r188, align 8
  %r190 = icmp eq i64 %r189, %r181
  br i1 %r190, label %pic.desc.prefix.hit.52, label %pic.miss.cold.54

pic.desc.prefix.hit.52:                           ; preds = %pic.desc.prefix.token.51
  %r191 = getelementptr i64, ptr %r131, i64 1
  %r192 = load i64, ptr %r191, align 8
  %r193 = shl i64 %r192, 3
  %r194 = add nuw nsw i64 %r110, 16
  %r195 = add i64 %r194, %r193
  %r196 = inttoptr i64 %r195 to ptr
  %r197 = load double, ptr %r196, align 8
  br label %pic.merge.56

pic.miss.53:                                      ; preds = %pic.hit.inline.60, %pic.prefix.token.46, %pic.prefix.meta.45, %pic.prefix.guard.44
  %r198 = getelementptr i64, ptr %r131, i64 3
  %r199 = load i64, ptr %r198, align 8
  %r200 = icmp sgt i64 %r199, 0
  br i1 %r200, label %pic.ways.61, label %pic.miss.call.55

pic.miss.cold.54:                                 ; preds = %pic.desc.prefix.token.51, %pic.desc.prefix.meta.50, %pic.desc.prefix.guard.49, %pic.desc.classify.48, %pget.recv_obj.41
  br label %pic.miss.call.55

pic.miss.call.55:                                 ; preds = %pic.way.load.62, %pic.ways.61, %pic.miss.cold.54, %pic.miss.53
  %r239 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r240 = bitcast double %r239 to i64
  %r241 = and i64 %r240, 281474976710655
  %statepoint_token22 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r110, i64 %r241, ptr @perry_ic_options_worker_ts__9, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated13, ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %rs4gc.s7) ]
  %r24223 = call double @llvm.experimental.gc.result.f64(token %statepoint_token22)
  %rs4gc.s5.relocated24 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token22, i32 0, i32 0) ; (%rs4gc.s5.relocated13, %rs4gc.s5.relocated13)
  %rs4gc.s6.relocated25 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token22, i32 1, i32 1) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s7.relocated26 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token22, i32 2, i32 2) ; (%rs4gc.s7, %rs4gc.s7)
  br label %pic.merge.56

pic.merge.56:                                     ; preds = %pic.way.live.63, %pic.hit.overflow.59, %pic.miss.call.55, %pic.desc.prefix.hit.52, %pic.prefix.hit.47, %pic.hit.live.43
  %.1159 = phi ptr addrspace(1) [ %rs4gc.s7.relocated31, %pic.hit.overflow.59 ], [ %rs4gc.s7.relocated26, %pic.miss.call.55 ], [ %rs4gc.s7, %pic.way.live.63 ], [ %rs4gc.s7, %pic.hit.live.43 ], [ %rs4gc.s7, %pic.prefix.hit.47 ], [ %rs4gc.s7, %pic.desc.prefix.hit.52 ]
  %.1156 = phi ptr addrspace(1) [ %rs4gc.s6.relocated30, %pic.hit.overflow.59 ], [ %rs4gc.s6.relocated25, %pic.miss.call.55 ], [ %rs4gc.s6, %pic.way.live.63 ], [ %rs4gc.s6, %pic.hit.live.43 ], [ %rs4gc.s6, %pic.prefix.hit.47 ], [ %rs4gc.s6, %pic.desc.prefix.hit.52 ]
  %.6 = phi ptr addrspace(1) [ %rs4gc.s5.relocated29, %pic.hit.overflow.59 ], [ %rs4gc.s5.relocated24, %pic.miss.call.55 ], [ %rs4gc.s5.relocated13, %pic.way.live.63 ], [ %rs4gc.s5.relocated13, %pic.hit.live.43 ], [ %rs4gc.s5.relocated13, %pic.prefix.hit.47 ], [ %rs4gc.s5.relocated13, %pic.desc.prefix.hit.52 ]
  %r243 = phi double [ %r159, %pic.hit.live.43 ], [ %r15428, %pic.hit.overflow.59 ], [ %r179, %pic.prefix.hit.47 ], [ %r197, %pic.desc.prefix.hit.52 ], [ %r236, %pic.way.live.63 ], [ %r24223, %pic.miss.call.55 ]
  br label %pget.recv_merge.37

pic.recv_hdr.57:                                  ; preds = %pget.recv_obj.41
  %r122 = sub nuw nsw i64 %r110, 8
  %r123 = inttoptr i64 %r122 to ptr
  %r124 = load i8, ptr %r123, align 1
  %r125 = icmp eq i8 %r124, 2
  %r126 = sub nuw nsw i64 %r110, 6
  %r127 = inttoptr i64 %r126 to ptr
  %r128 = load i16, ptr %r127, align 2
  %r129 = and i16 %r128, 2048
  %r130 = icmp eq i16 %r129, 0
  %r131 = load ptr, ptr @perry_ic_options_worker_ts__9, align 8
  %r132 = icmp ne ptr %r131, null
  %r133 = and i1 %r125, %r130
  %r134 = and i1 %r133, %r132
  br i1 %r134, label %pic.token.58, label %pic.desc.classify.48

pic.token.58:                                     ; preds = %pic.recv_hdr.57
  %r136 = add nuw nsw i64 %r110, 4
  %r137 = inttoptr i64 %r136 to ptr
  %r138 = load i32, ptr %r137, align 4
  %r139 = zext i32 %r138 to i64
  %r140 = or i64 %r139, 4611686018427387904
  %r141 = icmp ne i32 %r138, 0
  %r142 = getelementptr i64, ptr %r131, i64 0
  %r143 = load i64, ptr %r142, align 8
  %r144 = icmp eq i64 %r140, %r143
  %r145 = and i1 %r144, %r141
  br i1 %r145, label %pic.hit.42, label %pic.prefix.guard.44

pic.hit.overflow.59:                              ; preds = %pic.hit.42
  %r150 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r151 = bitcast double %r150 to i64
  %r152 = and i64 %r151, 281474976710655
  %r153 = trunc i64 %r147 to i32
  %statepoint_token27 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r110, i64 %r152, i32 %r153, ptr @perry_ic_options_worker_ts__9, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated13, ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %rs4gc.s7) ]
  %r15428 = call double @llvm.experimental.gc.result.f64(token %statepoint_token27)
  %rs4gc.s5.relocated29 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token27, i32 0, i32 0) ; (%rs4gc.s5.relocated13, %rs4gc.s5.relocated13)
  %rs4gc.s6.relocated30 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token27, i32 1, i32 1) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s7.relocated31 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token27, i32 2, i32 2) ; (%rs4gc.s7, %rs4gc.s7)
  br label %pic.merge.56

pic.hit.inline.60:                                ; preds = %pic.hit.42
  %r155 = shl i64 %r147, 3
  %r156 = add nuw nsw i64 %r110, 16
  %r157 = add i64 %r156, %r155
  %r158 = inttoptr i64 %r157 to ptr
  %r159 = load double, ptr %r158, align 8
  %r160 = bitcast double %r159 to i64
  %r161 = icmp eq i64 %r160, 9222246136947933200
  br i1 %r161, label %pic.miss.53, label %pic.hit.live.43

pic.ways.61:                                      ; preds = %pic.miss.53
  %r201 = getelementptr i64, ptr %r131, i64 4
  %r202 = load i64, ptr %r201, align 8
  %r203 = icmp eq i64 %r202, %r140
  %r204 = getelementptr i64, ptr %r131, i64 5
  %r205 = load i64, ptr %r204, align 8
  %r206 = select i1 %r203, i64 %r205, i64 0
  %r207 = getelementptr i64, ptr %r131, i64 6
  %r208 = load i64, ptr %r207, align 8
  %r209 = icmp eq i64 %r208, %r140
  %r210 = getelementptr i64, ptr %r131, i64 7
  %r211 = load i64, ptr %r210, align 8
  %r212 = select i1 %r209, i64 %r211, i64 0
  %r213 = getelementptr i64, ptr %r131, i64 8
  %r214 = load i64, ptr %r213, align 8
  %r215 = icmp eq i64 %r214, %r140
  %r216 = getelementptr i64, ptr %r131, i64 9
  %r217 = load i64, ptr %r216, align 8
  %r218 = select i1 %r215, i64 %r217, i64 0
  %r219 = getelementptr i64, ptr %r131, i64 10
  %r220 = load i64, ptr %r219, align 8
  %r221 = icmp eq i64 %r220, %r140
  %r222 = getelementptr i64, ptr %r131, i64 11
  %r223 = load i64, ptr %r222, align 8
  %r224 = select i1 %r221, i64 %r223, i64 0
  %r225 = or i1 %r203, %r209
  %r226 = select i1 %r203, i64 %r206, i64 %r212
  %r227 = or i1 %r215, %r221
  %r228 = select i1 %r215, i64 %r218, i64 %r224
  %r229 = or i1 %r225, %r227
  %r230 = select i1 %r225, i64 %r226, i64 %r228
  %r231 = and i1 %r141, %r229
  br i1 %r231, label %pic.way.load.62, label %pic.miss.call.55

pic.way.load.62:                                  ; preds = %pic.ways.61
  %r232 = shl i64 %r230, 3
  %r233 = add nuw nsw i64 %r110, 16
  %r234 = add i64 %r233, %r232
  %r235 = inttoptr i64 %r234 to ptr
  %r236 = load double, ptr %r235, align 8
  %r237 = bitcast double %r236 to i64
  %r238 = icmp eq i64 %r237, 9222246136947933200
  br i1 %r238, label %pic.miss.call.55, label %pic.way.live.63

pic.way.live.63:                                  ; preds = %pic.way.load.62
  br label %pic.merge.56

pget.throw_nullish.64:                            ; preds = %pget.recv_bad.35
  %r247 = zext i1 %r245 to i32
  %statepoint_token32 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r247, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.65:                        ; preds = %pget.recv_bad.35
  %r248 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r249 = bitcast double %r248 to i64
  %r250 = and i64 %r249, 281474976710655
  %statepoint_token33 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r109, i64 %r250, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated13, ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %rs4gc.s7) ]
  %r25134 = call double @llvm.experimental.gc.result.f64(token %statepoint_token33)
  %rs4gc.s5.relocated35 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token33, i32 0, i32 0) ; (%rs4gc.s5.relocated13, %rs4gc.s5.relocated13)
  %rs4gc.s6.relocated36 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token33, i32 1, i32 1) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s7.relocated37 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token33, i32 2, i32 2) ; (%rs4gc.s7, %rs4gc.s7)
  br label %pget.recv_merge.37

guarded_add.numeric.66:                           ; preds = %pget.recv_merge.37
  %r273 = fadd double %r262, %r260
  br label %guarded_add.merge.68

guarded_add.dynamic.67:                           ; preds = %pget.recv_merge.37
  %statepoint_token38 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r262, double %r260, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5, ptr addrspace(1) %.0155) ]
  %r27439 = call double @llvm.experimental.gc.result.f64(token %statepoint_token38)
  %rs4gc.s5.relocated40 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token38, i32 0, i32 0) ; (%.5, %.5)
  %rs4gc.s6.relocated41 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token38, i32 1, i32 1) ; (%.0155, %.0155)
  br label %guarded_add.merge.68

guarded_add.merge.68:                             ; preds = %guarded_add.dynamic.67, %guarded_add.numeric.66
  %.2157 = phi ptr addrspace(1) [ %.0155, %guarded_add.numeric.66 ], [ %rs4gc.s6.relocated41, %guarded_add.dynamic.67 ]
  %.7 = phi ptr addrspace(1) [ %.5, %guarded_add.numeric.66 ], [ %rs4gc.s5.relocated40, %guarded_add.dynamic.67 ]
  %r275 = phi double [ %r273, %guarded_add.numeric.66 ], [ %r27439, %guarded_add.dynamic.67 ]
  %r276.rs4i = ptrtoint ptr addrspace(1) %.2157 to i64
  %r276.rs4o = call i64 asm "", "=r,0"(i64 %r276.rs4i) #9
  %r276 = bitcast i64 %r276.rs4o to double
  %r277 = bitcast double %r276 to i64
  %r278 = and i64 %r277, -281474976710656
  %r279 = icmp ne i64 %r278, 9223090561878065152
  br i1 %r279, label %str_addref.done.70, label %str_addref.call.69

str_addref.call.69:                               ; preds = %guarded_add.merge.68
  call void @js_string_addref_if_heap_string(double %r276) #9
  br label %str_addref.done.70

str_addref.done.70:                               ; preds = %str_addref.call.69, %guarded_add.merge.68
  %r1154.rs4i = ptrtoint ptr addrspace(1) %.2157 to i64
  %r1154.rs4o = call i64 asm "", "=r,0"(i64 %r1154.rs4i) #9
  %r1154 = bitcast i64 %r1154.rs4o to double
  store double %r1154, ptr @perry_global_options_worker_ts__6, align 8
  %r1153.rs4i = ptrtoint ptr addrspace(1) %.2157 to i64
  %r1153.rs4o = call i64 asm "", "=r,0"(i64 %r1153.rs4i) #9
  %r1153 = bitcast i64 %r1153.rs4o to double
  %r280 = bitcast double %r1153 to i64
  %r1151.rs4i = ptrtoint ptr addrspace(1) %.2157 to i64
  %r1151.rs4o = call i64 asm "", "=r,0"(i64 %r1151.rs4i) #9
  %r1151 = bitcast i64 %r1151.rs4o to double
  %r1152 = bitcast double %r1151 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1152) #9
  %r281 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r282 = icmp ne i32 %r281, 0
  br i1 %r282, label %gcpoll.71, label %gcpoll.done.72

gcpoll.71:                                        ; preds = %str_addref.done.70
  %statepoint_token42 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.7) ]
  %rs4gc.s5.relocated43 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token42, i32 0, i32 0) ; (%.7, %.7)
  br label %gcpoll.done.72

gcpoll.done.72:                                   ; preds = %gcpoll.71, %str_addref.done.70
  %.8 = phi ptr addrspace(1) [ %rs4gc.s5.relocated43, %gcpoll.71 ], [ %.7, %str_addref.done.70 ]
  br label %for.update.20

streqlit.tag.73:                                  ; preds = %if.else.11
  %r292 = lshr i64 %r289, 48
  %r293 = icmp eq i64 %r292, 32767
  %r294 = and i64 %r289, 281474976710655
  %r295 = icmp ugt i64 %r294, 4095
  %r296 = and i1 %r293, %r295
  br i1 %r296, label %streqlit.len.74, label %streqlit.false.79

streqlit.len.74:                                  ; preds = %streqlit.tag.73
  %r297 = inttoptr i64 %r294 to ptr
  %r298 = getelementptr inbounds nuw i8, ptr %r297, i64 4
  %r299 = load i32, ptr %r298, align 4
  %r300 = icmp eq i32 %r299, 6
  br i1 %r300, label %streqlit.b0.75, label %streqlit.false.79

streqlit.b0.75:                                   ; preds = %streqlit.len.74
  %r301 = getelementptr inbounds nuw i8, ptr %r297, i64 20
  %r302 = load i8, ptr %r301, align 1
  %r303 = icmp eq i8 %r302, 112
  br i1 %r303, label %streqlit.bl.76, label %streqlit.false.79

streqlit.bl.76:                                   ; preds = %streqlit.b0.75
  %r304 = getelementptr inbounds nuw i8, ptr %r297, i64 25
  %r305 = load i8, ptr %r304, align 1
  %r306 = icmp eq i8 %r305, 121
  br i1 %r306, label %streqlit.slow.77, label %streqlit.false.79

streqlit.slow.77:                                 ; preds = %streqlit.bl.76
  %r307 = and i64 %r290, 281474976710655
  %statepoint_token44 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r294, i64 %r307, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0) ]
  %r30845 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token44)
  %rs4gc.s5.relocated46 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token44, i32 0, i32 0) ; (%.0, %.0)
  %r309 = icmp ne i32 %r30845, 0
  br label %streqlit.merge.80

streqlit.true.78:                                 ; preds = %if.else.11
  br label %streqlit.merge.80

streqlit.false.79:                                ; preds = %streqlit.bl.76, %streqlit.b0.75, %streqlit.len.74, %streqlit.tag.73
  br label %streqlit.merge.80

streqlit.merge.80:                                ; preds = %streqlit.false.79, %streqlit.true.78, %streqlit.slow.77
  %.9 = phi ptr addrspace(1) [ %.0, %streqlit.true.78 ], [ %rs4gc.s5.relocated46, %streqlit.slow.77 ], [ %.0, %streqlit.false.79 ]
  %r310 = phi i1 [ true, %streqlit.true.78 ], [ false, %streqlit.false.79 ], [ %r309, %streqlit.slow.77 ]
  %r311 = select i1 %r310, i64 9222246136947933188, i64 9222246136947933187
  %r312 = bitcast i64 %r311 to double
  %r313 = icmp eq i64 %r311, 9222246136947933188
  br i1 %r313, label %if.then.81, label %if.else.82

if.then.81:                                       ; preds = %streqlit.merge.80
  %r318.rs4i = ptrtoint ptr addrspace(1) %.9 to i64
  %r318.rs4o = call i64 asm "", "=r,0"(i64 %r318.rs4i) #9
  %r318 = bitcast i64 %r318.rs4o to double
  %r319 = bitcast double %r318 to i64
  %r320 = and i64 %r319, -281474976710656
  %r321 = icmp ult i64 %r320, 9221401712017801216
  %r322 = icmp ugt i64 %r320, 9223090561878065152
  %r323 = or i1 %r321, %r322
  br i1 %r323, label %for.bound_i32.number.84, label %for.bound_i32.merge.86

if.else.82:                                       ; preds = %streqlit.merge.80
  %r569 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r570 = load double, ptr @options_worker_ts_.str.3.handle, align 8
  %r571 = bitcast double %r569 to i64
  %r572 = bitcast double %r570 to i64
  %r573 = icmp eq i64 %r571, %r572
  br i1 %r573, label %streqlit.true.150, label %streqlit.sso.144

if.merge.83:                                      ; preds = %if.merge.155, %for.exit.92
  %r2.2 = phi double [ %r2.3, %for.exit.92 ], [ %r2.4, %if.merge.155 ]
  br label %if.merge.12

for.bound_i32.number.84:                          ; preds = %if.then.81
  %r324 = fcmp oge double %r318, 0xC1E0000000000000
  %r325 = fcmp ole double %r318, 0x41DFFFFFFFC00000
  %r326 = and i1 %r324, %r325
  br i1 %r326, label %for.bound_i32.convert.85, label %for.bound_i32.merge.86

for.bound_i32.convert.85:                         ; preds = %for.bound_i32.number.84
  %r327 = fptosi double %r318 to i32
  %r328 = sitofp i32 %r327 to double
  %r329 = fcmp oeq double %r328, %r318
  br i1 %r329, label %for.counter_i32.range.87, label %for.bound_i32.merge.86

for.bound_i32.merge.86:                           ; preds = %for.counter_i32.convert.88, %for.bound_i32.convert.85, %for.bound_i32.number.84, %if.then.81
  %r317.0 = phi i32 [ %r327, %for.counter_i32.convert.88 ], [ 0, %if.then.81 ], [ %r327, %for.bound_i32.convert.85 ], [ 0, %for.bound_i32.number.84 ]
  %r316.0 = phi i1 [ true, %for.counter_i32.convert.88 ], [ false, %if.then.81 ], [ false, %for.bound_i32.convert.85 ], [ false, %for.bound_i32.number.84 ]
  br label %for.cond.89

for.counter_i32.range.87:                         ; preds = %for.bound_i32.convert.85
  br label %for.counter_i32.convert.88

for.counter_i32.convert.88:                       ; preds = %for.counter_i32.range.87
  br label %for.bound_i32.merge.86

for.cond.89:                                      ; preds = %for.update.91, %for.bound_i32.merge.86
  %.10 = phi ptr addrspace(1) [ %.9, %for.bound_i32.merge.86 ], [ %.17, %for.update.91 ]
  %r315.1 = phi i32 [ 0, %for.bound_i32.merge.86 ], [ %r568, %for.update.91 ]
  %r314.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.86 ], [ %r566, %for.update.91 ]
  %r2.3 = phi double [ 0.000000e+00, %for.bound_i32.merge.86 ], [ %r557, %for.update.91 ]
  br i1 %r316.0, label %for.cond.fast.93, label %for.cond.slow.94

for.body.90:                                      ; preds = %gcpoll.done.99, %for.cond.fast.93
  %.11 = phi ptr addrspace(1) [ %.10, %for.cond.fast.93 ], [ %.13, %gcpoll.done.99 ]
  %r379 = load double, ptr @perry_global_options_worker_ts__4, align 8
  %statepoint_token47 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r379, double 0x7FFC000000000002, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11) ]
  %r38048 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token47)
  %rs4gc.s5.relocated49 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token47, i32 0, i32 0) ; (%.11, %.11)
  %r381 = bitcast i64 %r38048 to double
  %rs4gc.b8 = bitcast double %r381 to i64
  %rs4gc.s8 = inttoptr i64 %rs4gc.b8 to ptr addrspace(1)
  %r382.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r382 = call i64 asm "", "=r,0"(i64 %r382.rs4i) #9
  %r383 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r384 = icmp ne i32 %r383, 0
  br i1 %r384, label %shadow.root.barrier.100, label %shadow.root.barrier.done.101

for.update.91:                                    ; preds = %gcpoll.done.143
  %r566 = fadd double %r314.0, 1.000000e+00
  %r568 = add i32 %r315.1, 1
  br label %for.cond.89

for.exit.92:                                      ; preds = %gcpoll.done.99, %for.cond.fast.93
  br label %if.merge.83

for.cond.fast.93:                                 ; preds = %for.cond.89
  %r340 = icmp slt i32 %r315.1, %r317.0
  br i1 %r340, label %for.body.90, label %for.exit.92

for.cond.slow.94:                                 ; preds = %for.cond.89
  %r342.rs4i = ptrtoint ptr addrspace(1) %.10 to i64
  %r342.rs4o = call i64 asm "", "=r,0"(i64 %r342.rs4i) #9
  %r342 = bitcast i64 %r342.rs4o to double
  %r343 = bitcast double %r342 to i64
  %r344 = lshr i64 %r343, 48
  %r345 = icmp ult i64 %r344, 32761
  %r346 = icmp ugt i64 %r344, 32767
  %r347 = or i1 %r345, %r346
  %r348 = icmp eq i64 %r344, 32766
  %r349 = icmp eq i64 %r343, 9222246136947933185
  %r350 = icmp eq i64 %r343, 9222246136947933186
  %r351 = icmp eq i64 %r343, 9222246136947933187
  %r352 = icmp eq i64 %r343, 9222246136947933188
  %r353 = or i1 %r350, %r351
  %r354 = or i1 %r347, %r348
  %r355 = or i1 %r354, %r349
  %r356 = or i1 %r355, %r353
  %r357 = or i1 %r356, %r352
  br i1 %r357, label %relnum.fast.95, label %relnum.slow.96

relnum.fast.95:                                   ; preds = %for.cond.slow.94
  %r358 = trunc i64 %r343 to i32
  %r359 = sitofp i32 %r358 to double
  %r360 = select i1 %r348, double %r359, double %r342
  %r361 = select i1 %r353, double 0.000000e+00, double %r360
  %r362 = select i1 %r352, double 1.000000e+00, double %r361
  %r363 = bitcast double %r314.0 to i64
  %r364 = lshr i64 %r363, 48
  %r365 = icmp eq i64 %r364, 32766
  %r366 = trunc i64 %r363 to i32
  %r367 = sitofp i32 %r366 to double
  %r368 = select i1 %r365, double %r367, double %r314.0
  %r369 = fcmp olt double %r368, %r362
  %r370 = select i1 %r369, i64 9222246136947933188, i64 9222246136947933187
  %r371 = bitcast i64 %r370 to double
  br label %relnum.merge.97

relnum.slow.96:                                   ; preds = %for.cond.slow.94
  %statepoint_token50 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_rel_lt, i32 2, i32 0, double %r314.0, double %r342, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10) ]
  %r37251 = call double @llvm.experimental.gc.result.f64(token %statepoint_token50)
  %rs4gc.s5.relocated52 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token50, i32 0, i32 0) ; (%.10, %.10)
  br label %relnum.merge.97

relnum.merge.97:                                  ; preds = %relnum.slow.96, %relnum.fast.95
  %.12 = phi ptr addrspace(1) [ %.10, %relnum.fast.95 ], [ %rs4gc.s5.relocated52, %relnum.slow.96 ]
  %r373 = phi double [ %r371, %relnum.fast.95 ], [ %r37251, %relnum.slow.96 ]
  %r374 = bitcast double %r373 to i64
  %r376 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r377 = icmp ne i32 %r376, 0
  br i1 %r377, label %gcpoll.98, label %gcpoll.done.99

gcpoll.98:                                        ; preds = %relnum.merge.97
  %statepoint_token53 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.12) ]
  %rs4gc.s5.relocated54 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token53, i32 0, i32 0) ; (%.12, %.12)
  br label %gcpoll.done.99

gcpoll.done.99:                                   ; preds = %gcpoll.98, %relnum.merge.97
  %.13 = phi ptr addrspace(1) [ %rs4gc.s5.relocated54, %gcpoll.98 ], [ %.12, %relnum.merge.97 ]
  %r375 = icmp eq i64 %r374, 9222246136947933188
  br i1 %r375, label %for.body.90, label %for.exit.92

shadow.root.barrier.100:                          ; preds = %for.body.90
  call void @js_write_barrier_root_nanbox(i64 %r382) #9
  br label %shadow.root.barrier.done.101

shadow.root.barrier.done.101:                     ; preds = %shadow.root.barrier.100, %for.body.90
  %r386 = bitcast double %r2.3 to i64
  %rs4gc.s9 = inttoptr i64 %r386 to ptr addrspace(1)
  %r387.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9 to i64
  %r387 = call i64 asm "", "=r,0"(i64 %r387.rs4i) #9
  %r388 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r389 = icmp ne i32 %r388, 0
  br i1 %r389, label %shadow.root.barrier.102, label %shadow.root.barrier.done.103

shadow.root.barrier.102:                          ; preds = %shadow.root.barrier.done.101
  call void @js_write_barrier_root_nanbox(i64 %r387) #9
  br label %shadow.root.barrier.done.103

shadow.root.barrier.done.103:                     ; preds = %shadow.root.barrier.102, %shadow.root.barrier.done.101
  %r390.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r390.rs4o = call i64 asm "", "=r,0"(i64 %r390.rs4i) #9
  %r390 = bitcast i64 %r390.rs4o to double
  %r391 = bitcast double %r390 to i64
  %r392 = and i64 %r391, 281474976710655
  %r393 = lshr i64 %r391, 48
  %r394 = and i64 %r393, 65533
  %r395 = icmp eq i64 %r394, 32765
  br i1 %r395, label %pget.recv_ok.105, label %pget.recv_other.110

pget.recv_sso.104:                                ; preds = %pget.recv_other.110
  %r534 = lshr i64 %r391, 40
  %r535 = and i64 %r534, 255
  %r536 = uitofp nneg i64 %r535 to double
  br label %pget.recv_merge.108

pget.recv_ok.105:                                 ; preds = %shadow.root.barrier.done.103
  %r402 = icmp eq i64 %r393, 32767
  br i1 %r402, label %pget.strlen_heap.109, label %pget.recv_obj.112

pget.recv_bad.106:                                ; preds = %pget.check_class_ref.111
  %r526 = icmp eq i64 %r391, 9222246136947933185
  %r527 = icmp eq i64 %r391, 9222246136947933186
  %r528 = or i1 %r526, %r527
  br i1 %r528, label %pget.throw_nullish.135, label %pget.recv_undef_return.136

pget.recv_class_ref.107:                          ; preds = %pget.check_class_ref.111
  %r398 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r399 = bitcast double %r398 to i64
  %r400 = and i64 %r399, 281474976710655
  %statepoint_token55 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532874, i64 %r391, i64 %r400, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated49, ptr addrspace(1) %rs4gc.s8, ptr addrspace(1) %rs4gc.s9) ]
  %r40156 = call double @llvm.experimental.gc.result.f64(token %statepoint_token55)
  %rs4gc.s5.relocated57 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token55, i32 0, i32 0) ; (%rs4gc.s5.relocated49, %rs4gc.s5.relocated49)
  %rs4gc.s8.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token55, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.s9.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token55, i32 2, i32 2) ; (%rs4gc.s9, %rs4gc.s9)
  br label %pget.recv_merge.108

pget.recv_merge.108:                              ; preds = %pget.recv_undef_return.136, %pic.merge.127, %pget.strlen_heap.109, %pget.recv_class_ref.107, %pget.recv_sso.104
  %.0163 = phi ptr addrspace(1) [ %rs4gc.s9, %pget.strlen_heap.109 ], [ %.1164, %pic.merge.127 ], [ %rs4gc.s9, %pget.recv_sso.104 ], [ %rs4gc.s9.relocated, %pget.recv_class_ref.107 ], [ %rs4gc.s9.relocated73, %pget.recv_undef_return.136 ]
  %.0160 = phi ptr addrspace(1) [ %rs4gc.s8, %pget.strlen_heap.109 ], [ %.1161, %pic.merge.127 ], [ %rs4gc.s8, %pget.recv_sso.104 ], [ %rs4gc.s8.relocated, %pget.recv_class_ref.107 ], [ %rs4gc.s8.relocated72, %pget.recv_undef_return.136 ]
  %.14 = phi ptr addrspace(1) [ %rs4gc.s5.relocated49, %pget.strlen_heap.109 ], [ %.15, %pic.merge.127 ], [ %rs4gc.s5.relocated49, %pget.recv_sso.104 ], [ %rs4gc.s5.relocated57, %pget.recv_class_ref.107 ], [ %rs4gc.s5.relocated71, %pget.recv_undef_return.136 ]
  %r542 = phi double [ %r525, %pic.merge.127 ], [ %r53370, %pget.recv_undef_return.136 ], [ %r536, %pget.recv_sso.104 ], [ %r40156, %pget.recv_class_ref.107 ], [ %r541, %pget.strlen_heap.109 ]
  %r543.rs4i = ptrtoint ptr addrspace(1) %.0163 to i64
  %r543 = call i64 asm "", "=r,0"(i64 %r543.rs4i) #9
  %r544 = bitcast i64 %r543 to double
  %r545 = and i64 %r543, -281474976710656
  %r546 = icmp ult i64 %r545, 9221401712017801216
  %r547 = icmp ugt i64 %r545, 9223090561878065152
  %r548 = or i1 %r546, %r547
  %r549 = bitcast double %r542 to i64
  %r550 = and i64 %r549, -281474976710656
  %r551 = icmp ult i64 %r550, 9221401712017801216
  %r552 = icmp ugt i64 %r550, 9223090561878065152
  %r553 = or i1 %r551, %r552
  %r554 = and i1 %r548, %r553
  br i1 %r554, label %guarded_add.numeric.137, label %guarded_add.dynamic.138

pget.strlen_heap.109:                             ; preds = %pget.recv_ok.105
  %r537 = icmp ult i64 %r392, 4096
  %r538 = inttoptr i64 %r392 to ptr
  %r539 = select i1 %r537, ptr @perry_null_guard_zero_options_worker_ts, ptr %r538
  %r540 = load i32, ptr %r539, align 4
  %r541 = uitofp i32 %r540 to double
  br label %pget.recv_merge.108

pget.recv_other.110:                              ; preds = %shadow.root.barrier.done.103
  %r396 = icmp eq i64 %r393, 32761
  br i1 %r396, label %pget.recv_sso.104, label %pget.check_class_ref.111

pget.check_class_ref.111:                         ; preds = %pget.recv_other.110
  %r397 = icmp eq i64 %r393, 32766
  br i1 %r397, label %pget.recv_class_ref.107, label %pget.recv_bad.106

pget.recv_obj.112:                                ; preds = %pget.recv_ok.105
  %r403 = icmp ugt i64 %r392, 1048575
  br i1 %r403, label %pic.recv_hdr.128, label %pic.miss.cold.125

pic.hit.113:                                      ; preds = %pic.token.129
  %r428 = getelementptr i64, ptr %r413, i64 1
  %r429 = load i64, ptr %r428, align 8
  %r430 = and i64 %r429, 1073741824
  %r431 = icmp ne i64 %r430, 0
  br i1 %r431, label %pic.hit.overflow.130, label %pic.hit.inline.131

pic.hit.live.114:                                 ; preds = %pic.hit.inline.131
  br label %pic.merge.127

pic.prefix.guard.115:                             ; preds = %pic.token.129
  %r444 = getelementptr i64, ptr %r413, i64 2
  %r445 = load i64, ptr %r444, align 8
  %r446 = icmp ne i64 %r445, 0
  br i1 %r446, label %pic.prefix.meta.116, label %pic.miss.124

pic.prefix.meta.116:                              ; preds = %pic.prefix.guard.115
  %r447 = add nuw nsw i64 %r392, 8
  %r448 = inttoptr i64 %r447 to ptr
  %r449 = load i64, ptr %r448, align 8
  %r450 = icmp ne i64 %r449, 0
  br i1 %r450, label %pic.prefix.token.117, label %pic.miss.124

pic.prefix.token.117:                             ; preds = %pic.prefix.meta.116
  %r451 = inttoptr i64 %r449 to ptr
  %r452 = getelementptr i64, ptr %r451, i64 6
  %r453 = load i64, ptr %r452, align 8
  %r454 = icmp eq i64 %r453, %r445
  br i1 %r454, label %pic.prefix.hit.118, label %pic.miss.124

pic.prefix.hit.118:                               ; preds = %pic.prefix.token.117
  %r455 = getelementptr i64, ptr %r413, i64 1
  %r456 = load i64, ptr %r455, align 8
  %r457 = shl i64 %r456, 3
  %r458 = add nuw nsw i64 %r392, 16
  %r459 = add i64 %r458, %r457
  %r460 = inttoptr i64 %r459 to ptr
  %r461 = load double, ptr %r460, align 8
  br label %pic.merge.127

pic.desc.classify.119:                            ; preds = %pic.recv_hdr.128
  %r417 = and i1 %r407, %r414
  br i1 %r417, label %pic.desc.prefix.guard.120, label %pic.miss.cold.125

pic.desc.prefix.guard.120:                        ; preds = %pic.desc.classify.119
  %r462 = getelementptr i64, ptr %r413, i64 2
  %r463 = load i64, ptr %r462, align 8
  %r464 = icmp ne i64 %r463, 0
  br i1 %r464, label %pic.desc.prefix.meta.121, label %pic.miss.cold.125

pic.desc.prefix.meta.121:                         ; preds = %pic.desc.prefix.guard.120
  %r465 = add nuw nsw i64 %r392, 8
  %r466 = inttoptr i64 %r465 to ptr
  %r467 = load i64, ptr %r466, align 8
  %r468 = icmp ne i64 %r467, 0
  br i1 %r468, label %pic.desc.prefix.token.122, label %pic.miss.cold.125

pic.desc.prefix.token.122:                        ; preds = %pic.desc.prefix.meta.121
  %r469 = inttoptr i64 %r467 to ptr
  %r470 = getelementptr i64, ptr %r469, i64 6
  %r471 = load i64, ptr %r470, align 8
  %r472 = icmp eq i64 %r471, %r463
  br i1 %r472, label %pic.desc.prefix.hit.123, label %pic.miss.cold.125

pic.desc.prefix.hit.123:                          ; preds = %pic.desc.prefix.token.122
  %r473 = getelementptr i64, ptr %r413, i64 1
  %r474 = load i64, ptr %r473, align 8
  %r475 = shl i64 %r474, 3
  %r476 = add nuw nsw i64 %r392, 16
  %r477 = add i64 %r476, %r475
  %r478 = inttoptr i64 %r477 to ptr
  %r479 = load double, ptr %r478, align 8
  br label %pic.merge.127

pic.miss.124:                                     ; preds = %pic.hit.inline.131, %pic.prefix.token.117, %pic.prefix.meta.116, %pic.prefix.guard.115
  %r480 = getelementptr i64, ptr %r413, i64 3
  %r481 = load i64, ptr %r480, align 8
  %r482 = icmp sgt i64 %r481, 0
  br i1 %r482, label %pic.ways.132, label %pic.miss.call.126

pic.miss.cold.125:                                ; preds = %pic.desc.prefix.token.122, %pic.desc.prefix.meta.121, %pic.desc.prefix.guard.120, %pic.desc.classify.119, %pget.recv_obj.112
  br label %pic.miss.call.126

pic.miss.call.126:                                ; preds = %pic.way.load.133, %pic.ways.132, %pic.miss.cold.125, %pic.miss.124
  %r521 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r522 = bitcast double %r521 to i64
  %r523 = and i64 %r522, 281474976710655
  %statepoint_token58 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r392, i64 %r523, ptr @perry_ic_options_worker_ts__11, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated49, ptr addrspace(1) %rs4gc.s8, ptr addrspace(1) %rs4gc.s9) ]
  %r52459 = call double @llvm.experimental.gc.result.f64(token %statepoint_token58)
  %rs4gc.s5.relocated60 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token58, i32 0, i32 0) ; (%rs4gc.s5.relocated49, %rs4gc.s5.relocated49)
  %rs4gc.s8.relocated61 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token58, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.s9.relocated62 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token58, i32 2, i32 2) ; (%rs4gc.s9, %rs4gc.s9)
  br label %pic.merge.127

pic.merge.127:                                    ; preds = %pic.way.live.134, %pic.hit.overflow.130, %pic.miss.call.126, %pic.desc.prefix.hit.123, %pic.prefix.hit.118, %pic.hit.live.114
  %.1164 = phi ptr addrspace(1) [ %rs4gc.s9.relocated67, %pic.hit.overflow.130 ], [ %rs4gc.s9.relocated62, %pic.miss.call.126 ], [ %rs4gc.s9, %pic.way.live.134 ], [ %rs4gc.s9, %pic.hit.live.114 ], [ %rs4gc.s9, %pic.prefix.hit.118 ], [ %rs4gc.s9, %pic.desc.prefix.hit.123 ]
  %.1161 = phi ptr addrspace(1) [ %rs4gc.s8.relocated66, %pic.hit.overflow.130 ], [ %rs4gc.s8.relocated61, %pic.miss.call.126 ], [ %rs4gc.s8, %pic.way.live.134 ], [ %rs4gc.s8, %pic.hit.live.114 ], [ %rs4gc.s8, %pic.prefix.hit.118 ], [ %rs4gc.s8, %pic.desc.prefix.hit.123 ]
  %.15 = phi ptr addrspace(1) [ %rs4gc.s5.relocated65, %pic.hit.overflow.130 ], [ %rs4gc.s5.relocated60, %pic.miss.call.126 ], [ %rs4gc.s5.relocated49, %pic.way.live.134 ], [ %rs4gc.s5.relocated49, %pic.hit.live.114 ], [ %rs4gc.s5.relocated49, %pic.prefix.hit.118 ], [ %rs4gc.s5.relocated49, %pic.desc.prefix.hit.123 ]
  %r525 = phi double [ %r441, %pic.hit.live.114 ], [ %r43664, %pic.hit.overflow.130 ], [ %r461, %pic.prefix.hit.118 ], [ %r479, %pic.desc.prefix.hit.123 ], [ %r518, %pic.way.live.134 ], [ %r52459, %pic.miss.call.126 ]
  br label %pget.recv_merge.108

pic.recv_hdr.128:                                 ; preds = %pget.recv_obj.112
  %r404 = sub nuw nsw i64 %r392, 8
  %r405 = inttoptr i64 %r404 to ptr
  %r406 = load i8, ptr %r405, align 1
  %r407 = icmp eq i8 %r406, 2
  %r408 = sub nuw nsw i64 %r392, 6
  %r409 = inttoptr i64 %r408 to ptr
  %r410 = load i16, ptr %r409, align 2
  %r411 = and i16 %r410, 2048
  %r412 = icmp eq i16 %r411, 0
  %r413 = load ptr, ptr @perry_ic_options_worker_ts__11, align 8
  %r414 = icmp ne ptr %r413, null
  %r415 = and i1 %r407, %r412
  %r416 = and i1 %r415, %r414
  br i1 %r416, label %pic.token.129, label %pic.desc.classify.119

pic.token.129:                                    ; preds = %pic.recv_hdr.128
  %r418 = add nuw nsw i64 %r392, 4
  %r419 = inttoptr i64 %r418 to ptr
  %r420 = load i32, ptr %r419, align 4
  %r421 = zext i32 %r420 to i64
  %r422 = or i64 %r421, 4611686018427387904
  %r423 = icmp ne i32 %r420, 0
  %r424 = getelementptr i64, ptr %r413, i64 0
  %r425 = load i64, ptr %r424, align 8
  %r426 = icmp eq i64 %r422, %r425
  %r427 = and i1 %r426, %r423
  br i1 %r427, label %pic.hit.113, label %pic.prefix.guard.115

pic.hit.overflow.130:                             ; preds = %pic.hit.113
  %r432 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r433 = bitcast double %r432 to i64
  %r434 = and i64 %r433, 281474976710655
  %r435 = trunc i64 %r429 to i32
  %statepoint_token63 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r392, i64 %r434, i32 %r435, ptr @perry_ic_options_worker_ts__11, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated49, ptr addrspace(1) %rs4gc.s8, ptr addrspace(1) %rs4gc.s9) ]
  %r43664 = call double @llvm.experimental.gc.result.f64(token %statepoint_token63)
  %rs4gc.s5.relocated65 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token63, i32 0, i32 0) ; (%rs4gc.s5.relocated49, %rs4gc.s5.relocated49)
  %rs4gc.s8.relocated66 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token63, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.s9.relocated67 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token63, i32 2, i32 2) ; (%rs4gc.s9, %rs4gc.s9)
  br label %pic.merge.127

pic.hit.inline.131:                               ; preds = %pic.hit.113
  %r437 = shl i64 %r429, 3
  %r438 = add nuw nsw i64 %r392, 16
  %r439 = add i64 %r438, %r437
  %r440 = inttoptr i64 %r439 to ptr
  %r441 = load double, ptr %r440, align 8
  %r442 = bitcast double %r441 to i64
  %r443 = icmp eq i64 %r442, 9222246136947933200
  br i1 %r443, label %pic.miss.124, label %pic.hit.live.114

pic.ways.132:                                     ; preds = %pic.miss.124
  %r483 = getelementptr i64, ptr %r413, i64 4
  %r484 = load i64, ptr %r483, align 8
  %r485 = icmp eq i64 %r484, %r422
  %r486 = getelementptr i64, ptr %r413, i64 5
  %r487 = load i64, ptr %r486, align 8
  %r488 = select i1 %r485, i64 %r487, i64 0
  %r489 = getelementptr i64, ptr %r413, i64 6
  %r490 = load i64, ptr %r489, align 8
  %r491 = icmp eq i64 %r490, %r422
  %r492 = getelementptr i64, ptr %r413, i64 7
  %r493 = load i64, ptr %r492, align 8
  %r494 = select i1 %r491, i64 %r493, i64 0
  %r495 = getelementptr i64, ptr %r413, i64 8
  %r496 = load i64, ptr %r495, align 8
  %r497 = icmp eq i64 %r496, %r422
  %r498 = getelementptr i64, ptr %r413, i64 9
  %r499 = load i64, ptr %r498, align 8
  %r500 = select i1 %r497, i64 %r499, i64 0
  %r501 = getelementptr i64, ptr %r413, i64 10
  %r502 = load i64, ptr %r501, align 8
  %r503 = icmp eq i64 %r502, %r422
  %r504 = getelementptr i64, ptr %r413, i64 11
  %r505 = load i64, ptr %r504, align 8
  %r506 = select i1 %r503, i64 %r505, i64 0
  %r507 = or i1 %r485, %r491
  %r508 = select i1 %r485, i64 %r488, i64 %r494
  %r509 = or i1 %r497, %r503
  %r510 = select i1 %r497, i64 %r500, i64 %r506
  %r511 = or i1 %r507, %r509
  %r512 = select i1 %r507, i64 %r508, i64 %r510
  %r513 = and i1 %r423, %r511
  br i1 %r513, label %pic.way.load.133, label %pic.miss.call.126

pic.way.load.133:                                 ; preds = %pic.ways.132
  %r514 = shl i64 %r512, 3
  %r515 = add nuw nsw i64 %r392, 16
  %r516 = add i64 %r515, %r514
  %r517 = inttoptr i64 %r516 to ptr
  %r518 = load double, ptr %r517, align 8
  %r519 = bitcast double %r518 to i64
  %r520 = icmp eq i64 %r519, 9222246136947933200
  br i1 %r520, label %pic.miss.call.126, label %pic.way.live.134

pic.way.live.134:                                 ; preds = %pic.way.load.133
  br label %pic.merge.127

pget.throw_nullish.135:                           ; preds = %pget.recv_bad.106
  %r529 = zext i1 %r527 to i32
  %statepoint_token68 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r529, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.136:                       ; preds = %pget.recv_bad.106
  %r530 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r531 = bitcast double %r530 to i64
  %r532 = and i64 %r531, 281474976710655
  %statepoint_token69 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r391, i64 %r532, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated49, ptr addrspace(1) %rs4gc.s8, ptr addrspace(1) %rs4gc.s9) ]
  %r53370 = call double @llvm.experimental.gc.result.f64(token %statepoint_token69)
  %rs4gc.s5.relocated71 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token69, i32 0, i32 0) ; (%rs4gc.s5.relocated49, %rs4gc.s5.relocated49)
  %rs4gc.s8.relocated72 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token69, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.s9.relocated73 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token69, i32 2, i32 2) ; (%rs4gc.s9, %rs4gc.s9)
  br label %pget.recv_merge.108

guarded_add.numeric.137:                          ; preds = %pget.recv_merge.108
  %r555 = fadd double %r544, %r542
  br label %guarded_add.merge.139

guarded_add.dynamic.138:                          ; preds = %pget.recv_merge.108
  %statepoint_token74 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r544, double %r542, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.14, ptr addrspace(1) %.0160) ]
  %r55675 = call double @llvm.experimental.gc.result.f64(token %statepoint_token74)
  %rs4gc.s5.relocated76 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token74, i32 0, i32 0) ; (%.14, %.14)
  %rs4gc.s8.relocated77 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token74, i32 1, i32 1) ; (%.0160, %.0160)
  br label %guarded_add.merge.139

guarded_add.merge.139:                            ; preds = %guarded_add.dynamic.138, %guarded_add.numeric.137
  %.2162 = phi ptr addrspace(1) [ %.0160, %guarded_add.numeric.137 ], [ %rs4gc.s8.relocated77, %guarded_add.dynamic.138 ]
  %.16 = phi ptr addrspace(1) [ %.14, %guarded_add.numeric.137 ], [ %rs4gc.s5.relocated76, %guarded_add.dynamic.138 ]
  %r557 = phi double [ %r555, %guarded_add.numeric.137 ], [ %r55675, %guarded_add.dynamic.138 ]
  %r558.rs4i = ptrtoint ptr addrspace(1) %.2162 to i64
  %r558.rs4o = call i64 asm "", "=r,0"(i64 %r558.rs4i) #9
  %r558 = bitcast i64 %r558.rs4o to double
  %r559 = bitcast double %r558 to i64
  %r560 = and i64 %r559, -281474976710656
  %r561 = icmp ne i64 %r560, 9223090561878065152
  br i1 %r561, label %str_addref.done.141, label %str_addref.call.140

str_addref.call.140:                              ; preds = %guarded_add.merge.139
  call void @js_string_addref_if_heap_string(double %r558) #9
  br label %str_addref.done.141

str_addref.done.141:                              ; preds = %str_addref.call.140, %guarded_add.merge.139
  %r1150.rs4i = ptrtoint ptr addrspace(1) %.2162 to i64
  %r1150.rs4o = call i64 asm "", "=r,0"(i64 %r1150.rs4i) #9
  %r1150 = bitcast i64 %r1150.rs4o to double
  store double %r1150, ptr @perry_global_options_worker_ts__6, align 8
  %r1149.rs4i = ptrtoint ptr addrspace(1) %.2162 to i64
  %r1149.rs4o = call i64 asm "", "=r,0"(i64 %r1149.rs4i) #9
  %r1149 = bitcast i64 %r1149.rs4o to double
  %r562 = bitcast double %r1149 to i64
  %r1147.rs4i = ptrtoint ptr addrspace(1) %.2162 to i64
  %r1147.rs4o = call i64 asm "", "=r,0"(i64 %r1147.rs4i) #9
  %r1147 = bitcast i64 %r1147.rs4o to double
  %r1148 = bitcast double %r1147 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1148) #9
  %r563 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r564 = icmp ne i32 %r563, 0
  br i1 %r564, label %gcpoll.142, label %gcpoll.done.143

gcpoll.142:                                       ; preds = %str_addref.done.141
  %statepoint_token78 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.16) ]
  %rs4gc.s5.relocated79 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token78, i32 0, i32 0) ; (%.16, %.16)
  br label %gcpoll.done.143

gcpoll.done.143:                                  ; preds = %gcpoll.142, %str_addref.done.141
  %.17 = phi ptr addrspace(1) [ %rs4gc.s5.relocated79, %gcpoll.142 ], [ %.16, %str_addref.done.141 ]
  br label %for.update.91

streqlit.sso.144:                                 ; preds = %if.else.82
  %r574 = icmp eq i64 %r571, 9221406112001647979
  br i1 %r574, label %streqlit.true.150, label %streqlit.tag.145

streqlit.tag.145:                                 ; preds = %streqlit.sso.144
  %r575 = lshr i64 %r571, 48
  %r576 = icmp eq i64 %r575, 32767
  %r577 = and i64 %r571, 281474976710655
  %r578 = icmp ugt i64 %r577, 4095
  %r579 = and i1 %r576, %r578
  br i1 %r579, label %streqlit.len.146, label %streqlit.false.151

streqlit.len.146:                                 ; preds = %streqlit.tag.145
  %r580 = inttoptr i64 %r577 to ptr
  %r581 = getelementptr inbounds nuw i8, ptr %r580, i64 4
  %r582 = load i32, ptr %r581, align 4
  %r583 = icmp eq i32 %r582, 4
  br i1 %r583, label %streqlit.b0.147, label %streqlit.false.151

streqlit.b0.147:                                  ; preds = %streqlit.len.146
  %r584 = getelementptr inbounds nuw i8, ptr %r580, i64 20
  %r585 = load i8, ptr %r584, align 1
  %r586 = icmp eq i8 %r585, 107
  br i1 %r586, label %streqlit.bl.148, label %streqlit.false.151

streqlit.bl.148:                                  ; preds = %streqlit.b0.147
  %r587 = getelementptr inbounds nuw i8, ptr %r580, i64 23
  %r588 = load i8, ptr %r587, align 1
  %r589 = icmp eq i8 %r588, 115
  br i1 %r589, label %streqlit.slow.149, label %streqlit.false.151

streqlit.slow.149:                                ; preds = %streqlit.bl.148
  %r590 = and i64 %r572, 281474976710655
  %statepoint_token80 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r577, i64 %r590, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.9) ]
  %r59181 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token80)
  %rs4gc.s5.relocated82 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token80, i32 0, i32 0) ; (%.9, %.9)
  %r592 = icmp ne i32 %r59181, 0
  br label %streqlit.merge.152

streqlit.true.150:                                ; preds = %streqlit.sso.144, %if.else.82
  br label %streqlit.merge.152

streqlit.false.151:                               ; preds = %streqlit.bl.148, %streqlit.b0.147, %streqlit.len.146, %streqlit.tag.145
  br label %streqlit.merge.152

streqlit.merge.152:                               ; preds = %streqlit.false.151, %streqlit.true.150, %streqlit.slow.149
  %.18 = phi ptr addrspace(1) [ %.9, %streqlit.true.150 ], [ %rs4gc.s5.relocated82, %streqlit.slow.149 ], [ %.9, %streqlit.false.151 ]
  %r593 = phi i1 [ true, %streqlit.true.150 ], [ false, %streqlit.false.151 ], [ %r592, %streqlit.slow.149 ]
  %r594 = select i1 %r593, i64 9222246136947933188, i64 9222246136947933187
  %r595 = bitcast i64 %r594 to double
  %r596 = icmp eq i64 %r594, 9222246136947933188
  br i1 %r596, label %if.then.153, label %if.else.154

if.then.153:                                      ; preds = %streqlit.merge.152
  %r601.rs4i = ptrtoint ptr addrspace(1) %.18 to i64
  %r601.rs4o = call i64 asm "", "=r,0"(i64 %r601.rs4i) #9
  %r601 = bitcast i64 %r601.rs4o to double
  %r602 = bitcast double %r601 to i64
  %r603 = and i64 %r602, -281474976710656
  %r604 = icmp ult i64 %r603, 9221401712017801216
  %r605 = icmp ugt i64 %r603, 9223090561878065152
  %r606 = or i1 %r604, %r605
  br i1 %r606, label %for.bound_i32.number.156, label %for.bound_i32.merge.158

if.else.154:                                      ; preds = %streqlit.merge.152
  %r853 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r854 = load double, ptr @options_worker_ts_.str.4.handle, align 8
  %r855 = bitcast double %r853 to i64
  %r856 = bitcast double %r854 to i64
  %r857 = icmp eq i64 %r855, %r856
  br i1 %r857, label %streqlit.true.221, label %streqlit.tag.216

if.merge.155:                                     ; preds = %if.merge.226, %for.exit.164
  %r2.4 = phi double [ %r2.5, %for.exit.164 ], [ %r2.6, %if.merge.226 ]
  br label %if.merge.83

for.bound_i32.number.156:                         ; preds = %if.then.153
  %r607 = fcmp oge double %r601, 0xC1E0000000000000
  %r608 = fcmp ole double %r601, 0x41DFFFFFFFC00000
  %r609 = and i1 %r607, %r608
  br i1 %r609, label %for.bound_i32.convert.157, label %for.bound_i32.merge.158

for.bound_i32.convert.157:                        ; preds = %for.bound_i32.number.156
  %r610 = fptosi double %r601 to i32
  %r611 = sitofp i32 %r610 to double
  %r612 = fcmp oeq double %r611, %r601
  br i1 %r612, label %for.counter_i32.range.159, label %for.bound_i32.merge.158

for.bound_i32.merge.158:                          ; preds = %for.counter_i32.convert.160, %for.bound_i32.convert.157, %for.bound_i32.number.156, %if.then.153
  %r600.0 = phi i32 [ %r610, %for.counter_i32.convert.160 ], [ 0, %if.then.153 ], [ %r610, %for.bound_i32.convert.157 ], [ 0, %for.bound_i32.number.156 ]
  %r599.0 = phi i1 [ true, %for.counter_i32.convert.160 ], [ false, %if.then.153 ], [ false, %for.bound_i32.convert.157 ], [ false, %for.bound_i32.number.156 ]
  br label %for.cond.161

for.counter_i32.range.159:                        ; preds = %for.bound_i32.convert.157
  br label %for.counter_i32.convert.160

for.counter_i32.convert.160:                      ; preds = %for.counter_i32.range.159
  br label %for.bound_i32.merge.158

for.cond.161:                                     ; preds = %for.update.163, %for.bound_i32.merge.158
  %.19 = phi ptr addrspace(1) [ %.18, %for.bound_i32.merge.158 ], [ %.26, %for.update.163 ]
  %r598.1 = phi i32 [ 0, %for.bound_i32.merge.158 ], [ %r852, %for.update.163 ]
  %r597.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.158 ], [ %r850, %for.update.163 ]
  %r2.5 = phi double [ 0.000000e+00, %for.bound_i32.merge.158 ], [ %r841, %for.update.163 ]
  br i1 %r599.0, label %for.cond.fast.165, label %for.cond.slow.166

for.body.162:                                     ; preds = %gcpoll.done.171, %for.cond.fast.165
  %.20 = phi ptr addrspace(1) [ %.19, %for.cond.fast.165 ], [ %.22, %gcpoll.done.171 ]
  %r662 = load double, ptr @perry_global_options_worker_ts__4, align 8
  %r663 = load double, ptr @perry_global_options_worker_ts__5, align 8
  %statepoint_token83 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r662, double %r663, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.20) ]
  %r66484 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token83)
  %rs4gc.s5.relocated85 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token83, i32 0, i32 0) ; (%.20, %.20)
  %r665 = bitcast i64 %r66484 to double
  %rs4gc.b10 = bitcast double %r665 to i64
  %rs4gc.s10 = inttoptr i64 %rs4gc.b10 to ptr addrspace(1)
  %r666.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r666 = call i64 asm "", "=r,0"(i64 %r666.rs4i) #9
  %r667 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r668 = icmp ne i32 %r667, 0
  br i1 %r668, label %shadow.root.barrier.172, label %shadow.root.barrier.done.173

for.update.163:                                   ; preds = %gcpoll.done.215
  %r850 = fadd double %r597.0, 1.000000e+00
  %r852 = add i32 %r598.1, 1
  br label %for.cond.161

for.exit.164:                                     ; preds = %gcpoll.done.171, %for.cond.fast.165
  br label %if.merge.155

for.cond.fast.165:                                ; preds = %for.cond.161
  %r623 = icmp slt i32 %r598.1, %r600.0
  br i1 %r623, label %for.body.162, label %for.exit.164

for.cond.slow.166:                                ; preds = %for.cond.161
  %r625.rs4i = ptrtoint ptr addrspace(1) %.19 to i64
  %r625.rs4o = call i64 asm "", "=r,0"(i64 %r625.rs4i) #9
  %r625 = bitcast i64 %r625.rs4o to double
  %r626 = bitcast double %r625 to i64
  %r627 = lshr i64 %r626, 48
  %r628 = icmp ult i64 %r627, 32761
  %r629 = icmp ugt i64 %r627, 32767
  %r630 = or i1 %r628, %r629
  %r631 = icmp eq i64 %r627, 32766
  %r632 = icmp eq i64 %r626, 9222246136947933185
  %r633 = icmp eq i64 %r626, 9222246136947933186
  %r634 = icmp eq i64 %r626, 9222246136947933187
  %r635 = icmp eq i64 %r626, 9222246136947933188
  %r636 = or i1 %r633, %r634
  %r637 = or i1 %r630, %r631
  %r638 = or i1 %r637, %r632
  %r639 = or i1 %r638, %r636
  %r640 = or i1 %r639, %r635
  br i1 %r640, label %relnum.fast.167, label %relnum.slow.168

relnum.fast.167:                                  ; preds = %for.cond.slow.166
  %r641 = trunc i64 %r626 to i32
  %r642 = sitofp i32 %r641 to double
  %r643 = select i1 %r631, double %r642, double %r625
  %r644 = select i1 %r636, double 0.000000e+00, double %r643
  %r645 = select i1 %r635, double 1.000000e+00, double %r644
  %r646 = bitcast double %r597.0 to i64
  %r647 = lshr i64 %r646, 48
  %r648 = icmp eq i64 %r647, 32766
  %r649 = trunc i64 %r646 to i32
  %r650 = sitofp i32 %r649 to double
  %r651 = select i1 %r648, double %r650, double %r597.0
  %r652 = fcmp olt double %r651, %r645
  %r653 = select i1 %r652, i64 9222246136947933188, i64 9222246136947933187
  %r654 = bitcast i64 %r653 to double
  br label %relnum.merge.169

relnum.slow.168:                                  ; preds = %for.cond.slow.166
  %statepoint_token86 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_rel_lt, i32 2, i32 0, double %r597.0, double %r625, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.19) ]
  %r65587 = call double @llvm.experimental.gc.result.f64(token %statepoint_token86)
  %rs4gc.s5.relocated88 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token86, i32 0, i32 0) ; (%.19, %.19)
  br label %relnum.merge.169

relnum.merge.169:                                 ; preds = %relnum.slow.168, %relnum.fast.167
  %.21 = phi ptr addrspace(1) [ %.19, %relnum.fast.167 ], [ %rs4gc.s5.relocated88, %relnum.slow.168 ]
  %r656 = phi double [ %r654, %relnum.fast.167 ], [ %r65587, %relnum.slow.168 ]
  %r657 = bitcast double %r656 to i64
  %r659 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r660 = icmp ne i32 %r659, 0
  br i1 %r660, label %gcpoll.170, label %gcpoll.done.171

gcpoll.170:                                       ; preds = %relnum.merge.169
  %statepoint_token89 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.21) ]
  %rs4gc.s5.relocated90 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token89, i32 0, i32 0) ; (%.21, %.21)
  br label %gcpoll.done.171

gcpoll.done.171:                                  ; preds = %gcpoll.170, %relnum.merge.169
  %.22 = phi ptr addrspace(1) [ %rs4gc.s5.relocated90, %gcpoll.170 ], [ %.21, %relnum.merge.169 ]
  %r658 = icmp eq i64 %r657, 9222246136947933188
  br i1 %r658, label %for.body.162, label %for.exit.164

shadow.root.barrier.172:                          ; preds = %for.body.162
  call void @js_write_barrier_root_nanbox(i64 %r666) #9
  br label %shadow.root.barrier.done.173

shadow.root.barrier.done.173:                     ; preds = %shadow.root.barrier.172, %for.body.162
  %r670 = bitcast double %r2.5 to i64
  %rs4gc.s11 = inttoptr i64 %r670 to ptr addrspace(1)
  %r671.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s11 to i64
  %r671 = call i64 asm "", "=r,0"(i64 %r671.rs4i) #9
  %r672 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r673 = icmp ne i32 %r672, 0
  br i1 %r673, label %shadow.root.barrier.174, label %shadow.root.barrier.done.175

shadow.root.barrier.174:                          ; preds = %shadow.root.barrier.done.173
  call void @js_write_barrier_root_nanbox(i64 %r671) #9
  br label %shadow.root.barrier.done.175

shadow.root.barrier.done.175:                     ; preds = %shadow.root.barrier.174, %shadow.root.barrier.done.173
  %r674.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r674.rs4o = call i64 asm "", "=r,0"(i64 %r674.rs4i) #9
  %r674 = bitcast i64 %r674.rs4o to double
  %r675 = bitcast double %r674 to i64
  %r676 = and i64 %r675, 281474976710655
  %r677 = lshr i64 %r675, 48
  %r678 = and i64 %r677, 65533
  %r679 = icmp eq i64 %r678, 32765
  br i1 %r679, label %pget.recv_ok.177, label %pget.recv_other.182

pget.recv_sso.176:                                ; preds = %pget.recv_other.182
  %r818 = lshr i64 %r675, 40
  %r819 = and i64 %r818, 255
  %r820 = uitofp nneg i64 %r819 to double
  br label %pget.recv_merge.180

pget.recv_ok.177:                                 ; preds = %shadow.root.barrier.done.175
  %r686 = icmp eq i64 %r677, 32767
  br i1 %r686, label %pget.strlen_heap.181, label %pget.recv_obj.184

pget.recv_bad.178:                                ; preds = %pget.check_class_ref.183
  %r810 = icmp eq i64 %r675, 9222246136947933185
  %r811 = icmp eq i64 %r675, 9222246136947933186
  %r812 = or i1 %r810, %r811
  br i1 %r812, label %pget.throw_nullish.207, label %pget.recv_undef_return.208

pget.recv_class_ref.179:                          ; preds = %pget.check_class_ref.183
  %r682 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r683 = bitcast double %r682 to i64
  %r684 = and i64 %r683, 281474976710655
  %statepoint_token91 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532876, i64 %r675, i64 %r684, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated85, ptr addrspace(1) %rs4gc.s10, ptr addrspace(1) %rs4gc.s11) ]
  %r68592 = call double @llvm.experimental.gc.result.f64(token %statepoint_token91)
  %rs4gc.s5.relocated93 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token91, i32 0, i32 0) ; (%rs4gc.s5.relocated85, %rs4gc.s5.relocated85)
  %rs4gc.s10.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token91, i32 1, i32 1) ; (%rs4gc.s10, %rs4gc.s10)
  %rs4gc.s11.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token91, i32 2, i32 2) ; (%rs4gc.s11, %rs4gc.s11)
  br label %pget.recv_merge.180

pget.recv_merge.180:                              ; preds = %pget.recv_undef_return.208, %pic.merge.199, %pget.strlen_heap.181, %pget.recv_class_ref.179, %pget.recv_sso.176
  %.0168 = phi ptr addrspace(1) [ %rs4gc.s11, %pget.strlen_heap.181 ], [ %.1169, %pic.merge.199 ], [ %rs4gc.s11, %pget.recv_sso.176 ], [ %rs4gc.s11.relocated, %pget.recv_class_ref.179 ], [ %rs4gc.s11.relocated109, %pget.recv_undef_return.208 ]
  %.0165 = phi ptr addrspace(1) [ %rs4gc.s10, %pget.strlen_heap.181 ], [ %.1166, %pic.merge.199 ], [ %rs4gc.s10, %pget.recv_sso.176 ], [ %rs4gc.s10.relocated, %pget.recv_class_ref.179 ], [ %rs4gc.s10.relocated108, %pget.recv_undef_return.208 ]
  %.23 = phi ptr addrspace(1) [ %rs4gc.s5.relocated85, %pget.strlen_heap.181 ], [ %.24, %pic.merge.199 ], [ %rs4gc.s5.relocated85, %pget.recv_sso.176 ], [ %rs4gc.s5.relocated93, %pget.recv_class_ref.179 ], [ %rs4gc.s5.relocated107, %pget.recv_undef_return.208 ]
  %r826 = phi double [ %r809, %pic.merge.199 ], [ %r817106, %pget.recv_undef_return.208 ], [ %r820, %pget.recv_sso.176 ], [ %r68592, %pget.recv_class_ref.179 ], [ %r825, %pget.strlen_heap.181 ]
  %r827.rs4i = ptrtoint ptr addrspace(1) %.0168 to i64
  %r827 = call i64 asm "", "=r,0"(i64 %r827.rs4i) #9
  %r828 = bitcast i64 %r827 to double
  %r829 = and i64 %r827, -281474976710656
  %r830 = icmp ult i64 %r829, 9221401712017801216
  %r831 = icmp ugt i64 %r829, 9223090561878065152
  %r832 = or i1 %r830, %r831
  %r833 = bitcast double %r826 to i64
  %r834 = and i64 %r833, -281474976710656
  %r835 = icmp ult i64 %r834, 9221401712017801216
  %r836 = icmp ugt i64 %r834, 9223090561878065152
  %r837 = or i1 %r835, %r836
  %r838 = and i1 %r832, %r837
  br i1 %r838, label %guarded_add.numeric.209, label %guarded_add.dynamic.210

pget.strlen_heap.181:                             ; preds = %pget.recv_ok.177
  %r821 = icmp ult i64 %r676, 4096
  %r822 = inttoptr i64 %r676 to ptr
  %r823 = select i1 %r821, ptr @perry_null_guard_zero_options_worker_ts, ptr %r822
  %r824 = load i32, ptr %r823, align 4
  %r825 = uitofp i32 %r824 to double
  br label %pget.recv_merge.180

pget.recv_other.182:                              ; preds = %shadow.root.barrier.done.175
  %r680 = icmp eq i64 %r677, 32761
  br i1 %r680, label %pget.recv_sso.176, label %pget.check_class_ref.183

pget.check_class_ref.183:                         ; preds = %pget.recv_other.182
  %r681 = icmp eq i64 %r677, 32766
  br i1 %r681, label %pget.recv_class_ref.179, label %pget.recv_bad.178

pget.recv_obj.184:                                ; preds = %pget.recv_ok.177
  %r687 = icmp ugt i64 %r676, 1048575
  br i1 %r687, label %pic.recv_hdr.200, label %pic.miss.cold.197

pic.hit.185:                                      ; preds = %pic.token.201
  %r712 = getelementptr i64, ptr %r697, i64 1
  %r713 = load i64, ptr %r712, align 8
  %r714 = and i64 %r713, 1073741824
  %r715 = icmp ne i64 %r714, 0
  br i1 %r715, label %pic.hit.overflow.202, label %pic.hit.inline.203

pic.hit.live.186:                                 ; preds = %pic.hit.inline.203
  br label %pic.merge.199

pic.prefix.guard.187:                             ; preds = %pic.token.201
  %r728 = getelementptr i64, ptr %r697, i64 2
  %r729 = load i64, ptr %r728, align 8
  %r730 = icmp ne i64 %r729, 0
  br i1 %r730, label %pic.prefix.meta.188, label %pic.miss.196

pic.prefix.meta.188:                              ; preds = %pic.prefix.guard.187
  %r731 = add nuw nsw i64 %r676, 8
  %r732 = inttoptr i64 %r731 to ptr
  %r733 = load i64, ptr %r732, align 8
  %r734 = icmp ne i64 %r733, 0
  br i1 %r734, label %pic.prefix.token.189, label %pic.miss.196

pic.prefix.token.189:                             ; preds = %pic.prefix.meta.188
  %r735 = inttoptr i64 %r733 to ptr
  %r736 = getelementptr i64, ptr %r735, i64 6
  %r737 = load i64, ptr %r736, align 8
  %r738 = icmp eq i64 %r737, %r729
  br i1 %r738, label %pic.prefix.hit.190, label %pic.miss.196

pic.prefix.hit.190:                               ; preds = %pic.prefix.token.189
  %r739 = getelementptr i64, ptr %r697, i64 1
  %r740 = load i64, ptr %r739, align 8
  %r741 = shl i64 %r740, 3
  %r742 = add nuw nsw i64 %r676, 16
  %r743 = add i64 %r742, %r741
  %r744 = inttoptr i64 %r743 to ptr
  %r745 = load double, ptr %r744, align 8
  br label %pic.merge.199

pic.desc.classify.191:                            ; preds = %pic.recv_hdr.200
  %r701 = and i1 %r691, %r698
  br i1 %r701, label %pic.desc.prefix.guard.192, label %pic.miss.cold.197

pic.desc.prefix.guard.192:                        ; preds = %pic.desc.classify.191
  %r746 = getelementptr i64, ptr %r697, i64 2
  %r747 = load i64, ptr %r746, align 8
  %r748 = icmp ne i64 %r747, 0
  br i1 %r748, label %pic.desc.prefix.meta.193, label %pic.miss.cold.197

pic.desc.prefix.meta.193:                         ; preds = %pic.desc.prefix.guard.192
  %r749 = add nuw nsw i64 %r676, 8
  %r750 = inttoptr i64 %r749 to ptr
  %r751 = load i64, ptr %r750, align 8
  %r752 = icmp ne i64 %r751, 0
  br i1 %r752, label %pic.desc.prefix.token.194, label %pic.miss.cold.197

pic.desc.prefix.token.194:                        ; preds = %pic.desc.prefix.meta.193
  %r753 = inttoptr i64 %r751 to ptr
  %r754 = getelementptr i64, ptr %r753, i64 6
  %r755 = load i64, ptr %r754, align 8
  %r756 = icmp eq i64 %r755, %r747
  br i1 %r756, label %pic.desc.prefix.hit.195, label %pic.miss.cold.197

pic.desc.prefix.hit.195:                          ; preds = %pic.desc.prefix.token.194
  %r757 = getelementptr i64, ptr %r697, i64 1
  %r758 = load i64, ptr %r757, align 8
  %r759 = shl i64 %r758, 3
  %r760 = add nuw nsw i64 %r676, 16
  %r761 = add i64 %r760, %r759
  %r762 = inttoptr i64 %r761 to ptr
  %r763 = load double, ptr %r762, align 8
  br label %pic.merge.199

pic.miss.196:                                     ; preds = %pic.hit.inline.203, %pic.prefix.token.189, %pic.prefix.meta.188, %pic.prefix.guard.187
  %r764 = getelementptr i64, ptr %r697, i64 3
  %r765 = load i64, ptr %r764, align 8
  %r766 = icmp sgt i64 %r765, 0
  br i1 %r766, label %pic.ways.204, label %pic.miss.call.198

pic.miss.cold.197:                                ; preds = %pic.desc.prefix.token.194, %pic.desc.prefix.meta.193, %pic.desc.prefix.guard.192, %pic.desc.classify.191, %pget.recv_obj.184
  br label %pic.miss.call.198

pic.miss.call.198:                                ; preds = %pic.way.load.205, %pic.ways.204, %pic.miss.cold.197, %pic.miss.196
  %r805 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r806 = bitcast double %r805 to i64
  %r807 = and i64 %r806, 281474976710655
  %statepoint_token94 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r676, i64 %r807, ptr @perry_ic_options_worker_ts__13, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated85, ptr addrspace(1) %rs4gc.s10, ptr addrspace(1) %rs4gc.s11) ]
  %r80895 = call double @llvm.experimental.gc.result.f64(token %statepoint_token94)
  %rs4gc.s5.relocated96 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 0, i32 0) ; (%rs4gc.s5.relocated85, %rs4gc.s5.relocated85)
  %rs4gc.s10.relocated97 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 1, i32 1) ; (%rs4gc.s10, %rs4gc.s10)
  %rs4gc.s11.relocated98 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 2, i32 2) ; (%rs4gc.s11, %rs4gc.s11)
  br label %pic.merge.199

pic.merge.199:                                    ; preds = %pic.way.live.206, %pic.hit.overflow.202, %pic.miss.call.198, %pic.desc.prefix.hit.195, %pic.prefix.hit.190, %pic.hit.live.186
  %.1169 = phi ptr addrspace(1) [ %rs4gc.s11.relocated103, %pic.hit.overflow.202 ], [ %rs4gc.s11.relocated98, %pic.miss.call.198 ], [ %rs4gc.s11, %pic.way.live.206 ], [ %rs4gc.s11, %pic.hit.live.186 ], [ %rs4gc.s11, %pic.prefix.hit.190 ], [ %rs4gc.s11, %pic.desc.prefix.hit.195 ]
  %.1166 = phi ptr addrspace(1) [ %rs4gc.s10.relocated102, %pic.hit.overflow.202 ], [ %rs4gc.s10.relocated97, %pic.miss.call.198 ], [ %rs4gc.s10, %pic.way.live.206 ], [ %rs4gc.s10, %pic.hit.live.186 ], [ %rs4gc.s10, %pic.prefix.hit.190 ], [ %rs4gc.s10, %pic.desc.prefix.hit.195 ]
  %.24 = phi ptr addrspace(1) [ %rs4gc.s5.relocated101, %pic.hit.overflow.202 ], [ %rs4gc.s5.relocated96, %pic.miss.call.198 ], [ %rs4gc.s5.relocated85, %pic.way.live.206 ], [ %rs4gc.s5.relocated85, %pic.hit.live.186 ], [ %rs4gc.s5.relocated85, %pic.prefix.hit.190 ], [ %rs4gc.s5.relocated85, %pic.desc.prefix.hit.195 ]
  %r809 = phi double [ %r725, %pic.hit.live.186 ], [ %r720100, %pic.hit.overflow.202 ], [ %r745, %pic.prefix.hit.190 ], [ %r763, %pic.desc.prefix.hit.195 ], [ %r802, %pic.way.live.206 ], [ %r80895, %pic.miss.call.198 ]
  br label %pget.recv_merge.180

pic.recv_hdr.200:                                 ; preds = %pget.recv_obj.184
  %r688 = sub nuw nsw i64 %r676, 8
  %r689 = inttoptr i64 %r688 to ptr
  %r690 = load i8, ptr %r689, align 1
  %r691 = icmp eq i8 %r690, 2
  %r692 = sub nuw nsw i64 %r676, 6
  %r693 = inttoptr i64 %r692 to ptr
  %r694 = load i16, ptr %r693, align 2
  %r695 = and i16 %r694, 2048
  %r696 = icmp eq i16 %r695, 0
  %r697 = load ptr, ptr @perry_ic_options_worker_ts__13, align 8
  %r698 = icmp ne ptr %r697, null
  %r699 = and i1 %r691, %r696
  %r700 = and i1 %r699, %r698
  br i1 %r700, label %pic.token.201, label %pic.desc.classify.191

pic.token.201:                                    ; preds = %pic.recv_hdr.200
  %r702 = add nuw nsw i64 %r676, 4
  %r703 = inttoptr i64 %r702 to ptr
  %r704 = load i32, ptr %r703, align 4
  %r705 = zext i32 %r704 to i64
  %r706 = or i64 %r705, 4611686018427387904
  %r707 = icmp ne i32 %r704, 0
  %r708 = getelementptr i64, ptr %r697, i64 0
  %r709 = load i64, ptr %r708, align 8
  %r710 = icmp eq i64 %r706, %r709
  %r711 = and i1 %r710, %r707
  br i1 %r711, label %pic.hit.185, label %pic.prefix.guard.187

pic.hit.overflow.202:                             ; preds = %pic.hit.185
  %r716 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r717 = bitcast double %r716 to i64
  %r718 = and i64 %r717, 281474976710655
  %r719 = trunc i64 %r713 to i32
  %statepoint_token99 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r676, i64 %r718, i32 %r719, ptr @perry_ic_options_worker_ts__13, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated85, ptr addrspace(1) %rs4gc.s10, ptr addrspace(1) %rs4gc.s11) ]
  %r720100 = call double @llvm.experimental.gc.result.f64(token %statepoint_token99)
  %rs4gc.s5.relocated101 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token99, i32 0, i32 0) ; (%rs4gc.s5.relocated85, %rs4gc.s5.relocated85)
  %rs4gc.s10.relocated102 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token99, i32 1, i32 1) ; (%rs4gc.s10, %rs4gc.s10)
  %rs4gc.s11.relocated103 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token99, i32 2, i32 2) ; (%rs4gc.s11, %rs4gc.s11)
  br label %pic.merge.199

pic.hit.inline.203:                               ; preds = %pic.hit.185
  %r721 = shl i64 %r713, 3
  %r722 = add nuw nsw i64 %r676, 16
  %r723 = add i64 %r722, %r721
  %r724 = inttoptr i64 %r723 to ptr
  %r725 = load double, ptr %r724, align 8
  %r726 = bitcast double %r725 to i64
  %r727 = icmp eq i64 %r726, 9222246136947933200
  br i1 %r727, label %pic.miss.196, label %pic.hit.live.186

pic.ways.204:                                     ; preds = %pic.miss.196
  %r767 = getelementptr i64, ptr %r697, i64 4
  %r768 = load i64, ptr %r767, align 8
  %r769 = icmp eq i64 %r768, %r706
  %r770 = getelementptr i64, ptr %r697, i64 5
  %r771 = load i64, ptr %r770, align 8
  %r772 = select i1 %r769, i64 %r771, i64 0
  %r773 = getelementptr i64, ptr %r697, i64 6
  %r774 = load i64, ptr %r773, align 8
  %r775 = icmp eq i64 %r774, %r706
  %r776 = getelementptr i64, ptr %r697, i64 7
  %r777 = load i64, ptr %r776, align 8
  %r778 = select i1 %r775, i64 %r777, i64 0
  %r779 = getelementptr i64, ptr %r697, i64 8
  %r780 = load i64, ptr %r779, align 8
  %r781 = icmp eq i64 %r780, %r706
  %r782 = getelementptr i64, ptr %r697, i64 9
  %r783 = load i64, ptr %r782, align 8
  %r784 = select i1 %r781, i64 %r783, i64 0
  %r785 = getelementptr i64, ptr %r697, i64 10
  %r786 = load i64, ptr %r785, align 8
  %r787 = icmp eq i64 %r786, %r706
  %r788 = getelementptr i64, ptr %r697, i64 11
  %r789 = load i64, ptr %r788, align 8
  %r790 = select i1 %r787, i64 %r789, i64 0
  %r791 = or i1 %r769, %r775
  %r792 = select i1 %r769, i64 %r772, i64 %r778
  %r793 = or i1 %r781, %r787
  %r794 = select i1 %r781, i64 %r784, i64 %r790
  %r795 = or i1 %r791, %r793
  %r796 = select i1 %r791, i64 %r792, i64 %r794
  %r797 = and i1 %r707, %r795
  br i1 %r797, label %pic.way.load.205, label %pic.miss.call.198

pic.way.load.205:                                 ; preds = %pic.ways.204
  %r798 = shl i64 %r796, 3
  %r799 = add nuw nsw i64 %r676, 16
  %r800 = add i64 %r799, %r798
  %r801 = inttoptr i64 %r800 to ptr
  %r802 = load double, ptr %r801, align 8
  %r803 = bitcast double %r802 to i64
  %r804 = icmp eq i64 %r803, 9222246136947933200
  br i1 %r804, label %pic.miss.call.198, label %pic.way.live.206

pic.way.live.206:                                 ; preds = %pic.way.load.205
  br label %pic.merge.199

pget.throw_nullish.207:                           ; preds = %pget.recv_bad.178
  %r813 = zext i1 %r811 to i32
  %statepoint_token104 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r813, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.208:                       ; preds = %pget.recv_bad.178
  %r814 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r815 = bitcast double %r814 to i64
  %r816 = and i64 %r815, 281474976710655
  %statepoint_token105 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r675, i64 %r816, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated85, ptr addrspace(1) %rs4gc.s10, ptr addrspace(1) %rs4gc.s11) ]
  %r817106 = call double @llvm.experimental.gc.result.f64(token %statepoint_token105)
  %rs4gc.s5.relocated107 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 0, i32 0) ; (%rs4gc.s5.relocated85, %rs4gc.s5.relocated85)
  %rs4gc.s10.relocated108 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 1, i32 1) ; (%rs4gc.s10, %rs4gc.s10)
  %rs4gc.s11.relocated109 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 2, i32 2) ; (%rs4gc.s11, %rs4gc.s11)
  br label %pget.recv_merge.180

guarded_add.numeric.209:                          ; preds = %pget.recv_merge.180
  %r839 = fadd double %r828, %r826
  br label %guarded_add.merge.211

guarded_add.dynamic.210:                          ; preds = %pget.recv_merge.180
  %statepoint_token110 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r828, double %r826, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.23, ptr addrspace(1) %.0165) ]
  %r840111 = call double @llvm.experimental.gc.result.f64(token %statepoint_token110)
  %rs4gc.s5.relocated112 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token110, i32 0, i32 0) ; (%.23, %.23)
  %rs4gc.s10.relocated113 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token110, i32 1, i32 1) ; (%.0165, %.0165)
  br label %guarded_add.merge.211

guarded_add.merge.211:                            ; preds = %guarded_add.dynamic.210, %guarded_add.numeric.209
  %.2167 = phi ptr addrspace(1) [ %.0165, %guarded_add.numeric.209 ], [ %rs4gc.s10.relocated113, %guarded_add.dynamic.210 ]
  %.25 = phi ptr addrspace(1) [ %.23, %guarded_add.numeric.209 ], [ %rs4gc.s5.relocated112, %guarded_add.dynamic.210 ]
  %r841 = phi double [ %r839, %guarded_add.numeric.209 ], [ %r840111, %guarded_add.dynamic.210 ]
  %r842.rs4i = ptrtoint ptr addrspace(1) %.2167 to i64
  %r842.rs4o = call i64 asm "", "=r,0"(i64 %r842.rs4i) #9
  %r842 = bitcast i64 %r842.rs4o to double
  %r843 = bitcast double %r842 to i64
  %r844 = and i64 %r843, -281474976710656
  %r845 = icmp ne i64 %r844, 9223090561878065152
  br i1 %r845, label %str_addref.done.213, label %str_addref.call.212

str_addref.call.212:                              ; preds = %guarded_add.merge.211
  call void @js_string_addref_if_heap_string(double %r842) #9
  br label %str_addref.done.213

str_addref.done.213:                              ; preds = %str_addref.call.212, %guarded_add.merge.211
  %r1146.rs4i = ptrtoint ptr addrspace(1) %.2167 to i64
  %r1146.rs4o = call i64 asm "", "=r,0"(i64 %r1146.rs4i) #9
  %r1146 = bitcast i64 %r1146.rs4o to double
  store double %r1146, ptr @perry_global_options_worker_ts__6, align 8
  %r1145.rs4i = ptrtoint ptr addrspace(1) %.2167 to i64
  %r1145.rs4o = call i64 asm "", "=r,0"(i64 %r1145.rs4i) #9
  %r1145 = bitcast i64 %r1145.rs4o to double
  %r846 = bitcast double %r1145 to i64
  %r1143.rs4i = ptrtoint ptr addrspace(1) %.2167 to i64
  %r1143.rs4o = call i64 asm "", "=r,0"(i64 %r1143.rs4i) #9
  %r1143 = bitcast i64 %r1143.rs4o to double
  %r1144 = bitcast double %r1143 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1144) #9
  %r847 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r848 = icmp ne i32 %r847, 0
  br i1 %r848, label %gcpoll.214, label %gcpoll.done.215

gcpoll.214:                                       ; preds = %str_addref.done.213
  %statepoint_token114 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.25) ]
  %rs4gc.s5.relocated115 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token114, i32 0, i32 0) ; (%.25, %.25)
  br label %gcpoll.done.215

gcpoll.done.215:                                  ; preds = %gcpoll.214, %str_addref.done.213
  %.26 = phi ptr addrspace(1) [ %rs4gc.s5.relocated115, %gcpoll.214 ], [ %.25, %str_addref.done.213 ]
  br label %for.update.163

streqlit.tag.216:                                 ; preds = %if.else.154
  %r858 = lshr i64 %r855, 48
  %r859 = icmp eq i64 %r858, 32767
  %r860 = and i64 %r855, 281474976710655
  %r861 = icmp ugt i64 %r860, 4095
  %r862 = and i1 %r859, %r861
  br i1 %r862, label %streqlit.len.217, label %streqlit.false.222

streqlit.len.217:                                 ; preds = %streqlit.tag.216
  %r863 = inttoptr i64 %r860 to ptr
  %r864 = getelementptr inbounds nuw i8, ptr %r863, i64 4
  %r865 = load i32, ptr %r864, align 4
  %r866 = icmp eq i32 %r865, 8
  br i1 %r866, label %streqlit.b0.218, label %streqlit.false.222

streqlit.b0.218:                                  ; preds = %streqlit.len.217
  %r867 = getelementptr inbounds nuw i8, ptr %r863, i64 20
  %r868 = load i8, ptr %r867, align 1
  %r869 = icmp eq i8 %r868, 99
  br i1 %r869, label %streqlit.bl.219, label %streqlit.false.222

streqlit.bl.219:                                  ; preds = %streqlit.b0.218
  %r870 = getelementptr inbounds nuw i8, ptr %r863, i64 27
  %r871 = load i8, ptr %r870, align 1
  %r872 = icmp eq i8 %r871, 107
  br i1 %r872, label %streqlit.slow.220, label %streqlit.false.222

streqlit.slow.220:                                ; preds = %streqlit.bl.219
  %r873 = and i64 %r856, 281474976710655
  %statepoint_token116 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r860, i64 %r873, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.18) ]
  %r874117 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token116)
  %rs4gc.s5.relocated118 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 0, i32 0) ; (%.18, %.18)
  %r875 = icmp ne i32 %r874117, 0
  br label %streqlit.merge.223

streqlit.true.221:                                ; preds = %if.else.154
  br label %streqlit.merge.223

streqlit.false.222:                               ; preds = %streqlit.bl.219, %streqlit.b0.218, %streqlit.len.217, %streqlit.tag.216
  br label %streqlit.merge.223

streqlit.merge.223:                               ; preds = %streqlit.false.222, %streqlit.true.221, %streqlit.slow.220
  %.27 = phi ptr addrspace(1) [ %.18, %streqlit.true.221 ], [ %rs4gc.s5.relocated118, %streqlit.slow.220 ], [ %.18, %streqlit.false.222 ]
  %r876 = phi i1 [ true, %streqlit.true.221 ], [ false, %streqlit.false.222 ], [ %r875, %streqlit.slow.220 ]
  %r877 = select i1 %r876, i64 9222246136947933188, i64 9222246136947933187
  %r878 = bitcast i64 %r877 to double
  %r879 = icmp eq i64 %r877, 9222246136947933188
  br i1 %r879, label %if.then.224, label %if.else.225

if.then.224:                                      ; preds = %streqlit.merge.223
  %r884.rs4i = ptrtoint ptr addrspace(1) %.27 to i64
  %r884.rs4o = call i64 asm "", "=r,0"(i64 %r884.rs4i) #9
  %r884 = bitcast i64 %r884.rs4o to double
  %r885 = bitcast double %r884 to i64
  %r886 = and i64 %r885, -281474976710656
  %r887 = icmp ult i64 %r886, 9221401712017801216
  %r888 = icmp ugt i64 %r886, 9223090561878065152
  %r889 = or i1 %r887, %r888
  br i1 %r889, label %for.bound_i32.number.227, label %for.bound_i32.merge.229

if.else.225:                                      ; preds = %streqlit.merge.223
  br label %if.merge.226

if.merge.226:                                     ; preds = %for.exit.235, %if.else.225
  %r2.6 = phi double [ %r2.7, %for.exit.235 ], [ 0.000000e+00, %if.else.225 ]
  br label %if.merge.155

for.bound_i32.number.227:                         ; preds = %if.then.224
  %r890 = fcmp oge double %r884, 0xC1E0000000000000
  %r891 = fcmp ole double %r884, 0x41DFFFFFFFC00000
  %r892 = and i1 %r890, %r891
  br i1 %r892, label %for.bound_i32.convert.228, label %for.bound_i32.merge.229

for.bound_i32.convert.228:                        ; preds = %for.bound_i32.number.227
  %r893 = fptosi double %r884 to i32
  %r894 = sitofp i32 %r893 to double
  %r895 = fcmp oeq double %r894, %r884
  br i1 %r895, label %for.counter_i32.range.230, label %for.bound_i32.merge.229

for.bound_i32.merge.229:                          ; preds = %for.counter_i32.convert.231, %for.bound_i32.convert.228, %for.bound_i32.number.227, %if.then.224
  %r883.0 = phi i32 [ %r893, %for.counter_i32.convert.231 ], [ 0, %if.then.224 ], [ %r893, %for.bound_i32.convert.228 ], [ 0, %for.bound_i32.number.227 ]
  %r882.0 = phi i1 [ true, %for.counter_i32.convert.231 ], [ false, %if.then.224 ], [ false, %for.bound_i32.convert.228 ], [ false, %for.bound_i32.number.227 ]
  br label %for.cond.232

for.counter_i32.range.230:                        ; preds = %for.bound_i32.convert.228
  br label %for.counter_i32.convert.231

for.counter_i32.convert.231:                      ; preds = %for.counter_i32.range.230
  br label %for.bound_i32.merge.229

for.cond.232:                                     ; preds = %for.update.234, %for.bound_i32.merge.229
  %.28 = phi ptr addrspace(1) [ %.27, %for.bound_i32.merge.229 ], [ %.35, %for.update.234 ]
  %r881.1 = phi i32 [ 0, %for.bound_i32.merge.229 ], [ %r1137, %for.update.234 ]
  %r880.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.229 ], [ %r1135, %for.update.234 ]
  %r2.7 = phi double [ 0.000000e+00, %for.bound_i32.merge.229 ], [ %r1126, %for.update.234 ]
  br i1 %r882.0, label %for.cond.fast.236, label %for.cond.slow.237

for.body.233:                                     ; preds = %gcpoll.done.242, %for.cond.fast.236
  %.29 = phi ptr addrspace(1) [ %.28, %for.cond.fast.236 ], [ %.31, %gcpoll.done.242 ]
  %r945 = load double, ptr @perry_global_options_worker_ts__4, align 8
  %statepoint_token119 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (ptr)) @js_closure_alloc_singleton, i32 1, i32 0, ptr @__perry_wrap_perry_fn_options_worker_ts__identity, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.29) ]
  %r946120 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token119)
  %rs4gc.s5.relocated121 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token119, i32 0, i32 0) ; (%.29, %.29)
  %r947 = or i64 %r946120, 9222527611924643840
  %r948 = bitcast i64 %r947 to double
  %statepoint_token122 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r945, double %r948, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated121) ]
  %r949123 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token122)
  %rs4gc.s5.relocated124 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token122, i32 0, i32 0) ; (%rs4gc.s5.relocated121, %rs4gc.s5.relocated121)
  %r950 = bitcast i64 %r949123 to double
  %rs4gc.b12 = bitcast double %r950 to i64
  %rs4gc.s12 = inttoptr i64 %rs4gc.b12 to ptr addrspace(1)
  %r951.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12 to i64
  %r951 = call i64 asm "", "=r,0"(i64 %r951.rs4i) #9
  %r952 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r953 = icmp ne i32 %r952, 0
  br i1 %r953, label %shadow.root.barrier.243, label %shadow.root.barrier.done.244

for.update.234:                                   ; preds = %gcpoll.done.286
  %r1135 = fadd double %r880.0, 1.000000e+00
  %r1137 = add i32 %r881.1, 1
  br label %for.cond.232

for.exit.235:                                     ; preds = %gcpoll.done.242, %for.cond.fast.236
  br label %if.merge.226

for.cond.fast.236:                                ; preds = %for.cond.232
  %r906 = icmp slt i32 %r881.1, %r883.0
  br i1 %r906, label %for.body.233, label %for.exit.235

for.cond.slow.237:                                ; preds = %for.cond.232
  %r908.rs4i = ptrtoint ptr addrspace(1) %.28 to i64
  %r908.rs4o = call i64 asm "", "=r,0"(i64 %r908.rs4i) #9
  %r908 = bitcast i64 %r908.rs4o to double
  %r909 = bitcast double %r908 to i64
  %r910 = lshr i64 %r909, 48
  %r911 = icmp ult i64 %r910, 32761
  %r912 = icmp ugt i64 %r910, 32767
  %r913 = or i1 %r911, %r912
  %r914 = icmp eq i64 %r910, 32766
  %r915 = icmp eq i64 %r909, 9222246136947933185
  %r916 = icmp eq i64 %r909, 9222246136947933186
  %r917 = icmp eq i64 %r909, 9222246136947933187
  %r918 = icmp eq i64 %r909, 9222246136947933188
  %r919 = or i1 %r916, %r917
  %r920 = or i1 %r913, %r914
  %r921 = or i1 %r920, %r915
  %r922 = or i1 %r921, %r919
  %r923 = or i1 %r922, %r918
  br i1 %r923, label %relnum.fast.238, label %relnum.slow.239

relnum.fast.238:                                  ; preds = %for.cond.slow.237
  %r924 = trunc i64 %r909 to i32
  %r925 = sitofp i32 %r924 to double
  %r926 = select i1 %r914, double %r925, double %r908
  %r927 = select i1 %r919, double 0.000000e+00, double %r926
  %r928 = select i1 %r918, double 1.000000e+00, double %r927
  %r929 = bitcast double %r880.0 to i64
  %r930 = lshr i64 %r929, 48
  %r931 = icmp eq i64 %r930, 32766
  %r932 = trunc i64 %r929 to i32
  %r933 = sitofp i32 %r932 to double
  %r934 = select i1 %r931, double %r933, double %r880.0
  %r935 = fcmp olt double %r934, %r928
  %r936 = select i1 %r935, i64 9222246136947933188, i64 9222246136947933187
  %r937 = bitcast i64 %r936 to double
  br label %relnum.merge.240

relnum.slow.239:                                  ; preds = %for.cond.slow.237
  %statepoint_token125 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_rel_lt, i32 2, i32 0, double %r880.0, double %r908, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.28) ]
  %r938126 = call double @llvm.experimental.gc.result.f64(token %statepoint_token125)
  %rs4gc.s5.relocated127 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token125, i32 0, i32 0) ; (%.28, %.28)
  br label %relnum.merge.240

relnum.merge.240:                                 ; preds = %relnum.slow.239, %relnum.fast.238
  %.30 = phi ptr addrspace(1) [ %.28, %relnum.fast.238 ], [ %rs4gc.s5.relocated127, %relnum.slow.239 ]
  %r939 = phi double [ %r937, %relnum.fast.238 ], [ %r938126, %relnum.slow.239 ]
  %r940 = bitcast double %r939 to i64
  %r942 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r943 = icmp ne i32 %r942, 0
  br i1 %r943, label %gcpoll.241, label %gcpoll.done.242

gcpoll.241:                                       ; preds = %relnum.merge.240
  %statepoint_token128 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.30) ]
  %rs4gc.s5.relocated129 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token128, i32 0, i32 0) ; (%.30, %.30)
  br label %gcpoll.done.242

gcpoll.done.242:                                  ; preds = %gcpoll.241, %relnum.merge.240
  %.31 = phi ptr addrspace(1) [ %rs4gc.s5.relocated129, %gcpoll.241 ], [ %.30, %relnum.merge.240 ]
  %r941 = icmp eq i64 %r940, 9222246136947933188
  br i1 %r941, label %for.body.233, label %for.exit.235

shadow.root.barrier.243:                          ; preds = %for.body.233
  call void @js_write_barrier_root_nanbox(i64 %r951) #9
  br label %shadow.root.barrier.done.244

shadow.root.barrier.done.244:                     ; preds = %shadow.root.barrier.243, %for.body.233
  %r955 = bitcast double %r2.7 to i64
  %rs4gc.s13 = inttoptr i64 %r955 to ptr addrspace(1)
  %r956.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13 to i64
  %r956 = call i64 asm "", "=r,0"(i64 %r956.rs4i) #9
  %r957 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r958 = icmp ne i32 %r957, 0
  br i1 %r958, label %shadow.root.barrier.245, label %shadow.root.barrier.done.246

shadow.root.barrier.245:                          ; preds = %shadow.root.barrier.done.244
  call void @js_write_barrier_root_nanbox(i64 %r956) #9
  br label %shadow.root.barrier.done.246

shadow.root.barrier.done.246:                     ; preds = %shadow.root.barrier.245, %shadow.root.barrier.done.244
  %r959.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12 to i64
  %r959.rs4o = call i64 asm "", "=r,0"(i64 %r959.rs4i) #9
  %r959 = bitcast i64 %r959.rs4o to double
  %r960 = bitcast double %r959 to i64
  %r961 = and i64 %r960, 281474976710655
  %r962 = lshr i64 %r960, 48
  %r963 = and i64 %r962, 65533
  %r964 = icmp eq i64 %r963, 32765
  br i1 %r964, label %pget.recv_ok.248, label %pget.recv_other.253

pget.recv_sso.247:                                ; preds = %pget.recv_other.253
  %r1103 = lshr i64 %r960, 40
  %r1104 = and i64 %r1103, 255
  %r1105 = uitofp nneg i64 %r1104 to double
  br label %pget.recv_merge.251

pget.recv_ok.248:                                 ; preds = %shadow.root.barrier.done.246
  %r971 = icmp eq i64 %r962, 32767
  br i1 %r971, label %pget.strlen_heap.252, label %pget.recv_obj.255

pget.recv_bad.249:                                ; preds = %pget.check_class_ref.254
  %r1095 = icmp eq i64 %r960, 9222246136947933185
  %r1096 = icmp eq i64 %r960, 9222246136947933186
  %r1097 = or i1 %r1095, %r1096
  br i1 %r1097, label %pget.throw_nullish.278, label %pget.recv_undef_return.279

pget.recv_class_ref.250:                          ; preds = %pget.check_class_ref.254
  %r967 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r968 = bitcast double %r967 to i64
  %r969 = and i64 %r968, 281474976710655
  %statepoint_token130 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532878, i64 %r960, i64 %r969, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated124, ptr addrspace(1) %rs4gc.s12, ptr addrspace(1) %rs4gc.s13) ]
  %r970131 = call double @llvm.experimental.gc.result.f64(token %statepoint_token130)
  %rs4gc.s5.relocated132 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token130, i32 0, i32 0) ; (%rs4gc.s5.relocated124, %rs4gc.s5.relocated124)
  %rs4gc.s12.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token130, i32 1, i32 1) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token130, i32 2, i32 2) ; (%rs4gc.s13, %rs4gc.s13)
  br label %pget.recv_merge.251

pget.recv_merge.251:                              ; preds = %pget.recv_undef_return.279, %pic.merge.270, %pget.strlen_heap.252, %pget.recv_class_ref.250, %pget.recv_sso.247
  %.0173 = phi ptr addrspace(1) [ %rs4gc.s13, %pget.strlen_heap.252 ], [ %.1174, %pic.merge.270 ], [ %rs4gc.s13, %pget.recv_sso.247 ], [ %rs4gc.s13.relocated, %pget.recv_class_ref.250 ], [ %rs4gc.s13.relocated148, %pget.recv_undef_return.279 ]
  %.0170 = phi ptr addrspace(1) [ %rs4gc.s12, %pget.strlen_heap.252 ], [ %.1171, %pic.merge.270 ], [ %rs4gc.s12, %pget.recv_sso.247 ], [ %rs4gc.s12.relocated, %pget.recv_class_ref.250 ], [ %rs4gc.s12.relocated147, %pget.recv_undef_return.279 ]
  %.32 = phi ptr addrspace(1) [ %rs4gc.s5.relocated124, %pget.strlen_heap.252 ], [ %.33, %pic.merge.270 ], [ %rs4gc.s5.relocated124, %pget.recv_sso.247 ], [ %rs4gc.s5.relocated132, %pget.recv_class_ref.250 ], [ %rs4gc.s5.relocated146, %pget.recv_undef_return.279 ]
  %r1111 = phi double [ %r1094, %pic.merge.270 ], [ %r1102145, %pget.recv_undef_return.279 ], [ %r1105, %pget.recv_sso.247 ], [ %r970131, %pget.recv_class_ref.250 ], [ %r1110, %pget.strlen_heap.252 ]
  %r1112.rs4i = ptrtoint ptr addrspace(1) %.0173 to i64
  %r1112 = call i64 asm "", "=r,0"(i64 %r1112.rs4i) #9
  %r1113 = bitcast i64 %r1112 to double
  %r1114 = and i64 %r1112, -281474976710656
  %r1115 = icmp ult i64 %r1114, 9221401712017801216
  %r1116 = icmp ugt i64 %r1114, 9223090561878065152
  %r1117 = or i1 %r1115, %r1116
  %r1118 = bitcast double %r1111 to i64
  %r1119 = and i64 %r1118, -281474976710656
  %r1120 = icmp ult i64 %r1119, 9221401712017801216
  %r1121 = icmp ugt i64 %r1119, 9223090561878065152
  %r1122 = or i1 %r1120, %r1121
  %r1123 = and i1 %r1117, %r1122
  br i1 %r1123, label %guarded_add.numeric.280, label %guarded_add.dynamic.281

pget.strlen_heap.252:                             ; preds = %pget.recv_ok.248
  %r1106 = icmp ult i64 %r961, 4096
  %r1107 = inttoptr i64 %r961 to ptr
  %r1108 = select i1 %r1106, ptr @perry_null_guard_zero_options_worker_ts, ptr %r1107
  %r1109 = load i32, ptr %r1108, align 4
  %r1110 = uitofp i32 %r1109 to double
  br label %pget.recv_merge.251

pget.recv_other.253:                              ; preds = %shadow.root.barrier.done.246
  %r965 = icmp eq i64 %r962, 32761
  br i1 %r965, label %pget.recv_sso.247, label %pget.check_class_ref.254

pget.check_class_ref.254:                         ; preds = %pget.recv_other.253
  %r966 = icmp eq i64 %r962, 32766
  br i1 %r966, label %pget.recv_class_ref.250, label %pget.recv_bad.249

pget.recv_obj.255:                                ; preds = %pget.recv_ok.248
  %r972 = icmp ugt i64 %r961, 1048575
  br i1 %r972, label %pic.recv_hdr.271, label %pic.miss.cold.268

pic.hit.256:                                      ; preds = %pic.token.272
  %r997 = getelementptr i64, ptr %r982, i64 1
  %r998 = load i64, ptr %r997, align 8
  %r999 = and i64 %r998, 1073741824
  %r1000 = icmp ne i64 %r999, 0
  br i1 %r1000, label %pic.hit.overflow.273, label %pic.hit.inline.274

pic.hit.live.257:                                 ; preds = %pic.hit.inline.274
  br label %pic.merge.270

pic.prefix.guard.258:                             ; preds = %pic.token.272
  %r1013 = getelementptr i64, ptr %r982, i64 2
  %r1014 = load i64, ptr %r1013, align 8
  %r1015 = icmp ne i64 %r1014, 0
  br i1 %r1015, label %pic.prefix.meta.259, label %pic.miss.267

pic.prefix.meta.259:                              ; preds = %pic.prefix.guard.258
  %r1016 = add nuw nsw i64 %r961, 8
  %r1017 = inttoptr i64 %r1016 to ptr
  %r1018 = load i64, ptr %r1017, align 8
  %r1019 = icmp ne i64 %r1018, 0
  br i1 %r1019, label %pic.prefix.token.260, label %pic.miss.267

pic.prefix.token.260:                             ; preds = %pic.prefix.meta.259
  %r1020 = inttoptr i64 %r1018 to ptr
  %r1021 = getelementptr i64, ptr %r1020, i64 6
  %r1022 = load i64, ptr %r1021, align 8
  %r1023 = icmp eq i64 %r1022, %r1014
  br i1 %r1023, label %pic.prefix.hit.261, label %pic.miss.267

pic.prefix.hit.261:                               ; preds = %pic.prefix.token.260
  %r1024 = getelementptr i64, ptr %r982, i64 1
  %r1025 = load i64, ptr %r1024, align 8
  %r1026 = shl i64 %r1025, 3
  %r1027 = add nuw nsw i64 %r961, 16
  %r1028 = add i64 %r1027, %r1026
  %r1029 = inttoptr i64 %r1028 to ptr
  %r1030 = load double, ptr %r1029, align 8
  br label %pic.merge.270

pic.desc.classify.262:                            ; preds = %pic.recv_hdr.271
  %r986 = and i1 %r976, %r983
  br i1 %r986, label %pic.desc.prefix.guard.263, label %pic.miss.cold.268

pic.desc.prefix.guard.263:                        ; preds = %pic.desc.classify.262
  %r1031 = getelementptr i64, ptr %r982, i64 2
  %r1032 = load i64, ptr %r1031, align 8
  %r1033 = icmp ne i64 %r1032, 0
  br i1 %r1033, label %pic.desc.prefix.meta.264, label %pic.miss.cold.268

pic.desc.prefix.meta.264:                         ; preds = %pic.desc.prefix.guard.263
  %r1034 = add nuw nsw i64 %r961, 8
  %r1035 = inttoptr i64 %r1034 to ptr
  %r1036 = load i64, ptr %r1035, align 8
  %r1037 = icmp ne i64 %r1036, 0
  br i1 %r1037, label %pic.desc.prefix.token.265, label %pic.miss.cold.268

pic.desc.prefix.token.265:                        ; preds = %pic.desc.prefix.meta.264
  %r1038 = inttoptr i64 %r1036 to ptr
  %r1039 = getelementptr i64, ptr %r1038, i64 6
  %r1040 = load i64, ptr %r1039, align 8
  %r1041 = icmp eq i64 %r1040, %r1032
  br i1 %r1041, label %pic.desc.prefix.hit.266, label %pic.miss.cold.268

pic.desc.prefix.hit.266:                          ; preds = %pic.desc.prefix.token.265
  %r1042 = getelementptr i64, ptr %r982, i64 1
  %r1043 = load i64, ptr %r1042, align 8
  %r1044 = shl i64 %r1043, 3
  %r1045 = add nuw nsw i64 %r961, 16
  %r1046 = add i64 %r1045, %r1044
  %r1047 = inttoptr i64 %r1046 to ptr
  %r1048 = load double, ptr %r1047, align 8
  br label %pic.merge.270

pic.miss.267:                                     ; preds = %pic.hit.inline.274, %pic.prefix.token.260, %pic.prefix.meta.259, %pic.prefix.guard.258
  %r1049 = getelementptr i64, ptr %r982, i64 3
  %r1050 = load i64, ptr %r1049, align 8
  %r1051 = icmp sgt i64 %r1050, 0
  br i1 %r1051, label %pic.ways.275, label %pic.miss.call.269

pic.miss.cold.268:                                ; preds = %pic.desc.prefix.token.265, %pic.desc.prefix.meta.264, %pic.desc.prefix.guard.263, %pic.desc.classify.262, %pget.recv_obj.255
  br label %pic.miss.call.269

pic.miss.call.269:                                ; preds = %pic.way.load.276, %pic.ways.275, %pic.miss.cold.268, %pic.miss.267
  %r1090 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1091 = bitcast double %r1090 to i64
  %r1092 = and i64 %r1091, 281474976710655
  %statepoint_token133 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r961, i64 %r1092, ptr @perry_ic_options_worker_ts__15, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated124, ptr addrspace(1) %rs4gc.s12, ptr addrspace(1) %rs4gc.s13) ]
  %r1093134 = call double @llvm.experimental.gc.result.f64(token %statepoint_token133)
  %rs4gc.s5.relocated135 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token133, i32 0, i32 0) ; (%rs4gc.s5.relocated124, %rs4gc.s5.relocated124)
  %rs4gc.s12.relocated136 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token133, i32 1, i32 1) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13.relocated137 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token133, i32 2, i32 2) ; (%rs4gc.s13, %rs4gc.s13)
  br label %pic.merge.270

pic.merge.270:                                    ; preds = %pic.way.live.277, %pic.hit.overflow.273, %pic.miss.call.269, %pic.desc.prefix.hit.266, %pic.prefix.hit.261, %pic.hit.live.257
  %.1174 = phi ptr addrspace(1) [ %rs4gc.s13.relocated142, %pic.hit.overflow.273 ], [ %rs4gc.s13.relocated137, %pic.miss.call.269 ], [ %rs4gc.s13, %pic.way.live.277 ], [ %rs4gc.s13, %pic.hit.live.257 ], [ %rs4gc.s13, %pic.prefix.hit.261 ], [ %rs4gc.s13, %pic.desc.prefix.hit.266 ]
  %.1171 = phi ptr addrspace(1) [ %rs4gc.s12.relocated141, %pic.hit.overflow.273 ], [ %rs4gc.s12.relocated136, %pic.miss.call.269 ], [ %rs4gc.s12, %pic.way.live.277 ], [ %rs4gc.s12, %pic.hit.live.257 ], [ %rs4gc.s12, %pic.prefix.hit.261 ], [ %rs4gc.s12, %pic.desc.prefix.hit.266 ]
  %.33 = phi ptr addrspace(1) [ %rs4gc.s5.relocated140, %pic.hit.overflow.273 ], [ %rs4gc.s5.relocated135, %pic.miss.call.269 ], [ %rs4gc.s5.relocated124, %pic.way.live.277 ], [ %rs4gc.s5.relocated124, %pic.hit.live.257 ], [ %rs4gc.s5.relocated124, %pic.prefix.hit.261 ], [ %rs4gc.s5.relocated124, %pic.desc.prefix.hit.266 ]
  %r1094 = phi double [ %r1010, %pic.hit.live.257 ], [ %r1005139, %pic.hit.overflow.273 ], [ %r1030, %pic.prefix.hit.261 ], [ %r1048, %pic.desc.prefix.hit.266 ], [ %r1087, %pic.way.live.277 ], [ %r1093134, %pic.miss.call.269 ]
  br label %pget.recv_merge.251

pic.recv_hdr.271:                                 ; preds = %pget.recv_obj.255
  %r973 = sub nuw nsw i64 %r961, 8
  %r974 = inttoptr i64 %r973 to ptr
  %r975 = load i8, ptr %r974, align 1
  %r976 = icmp eq i8 %r975, 2
  %r977 = sub nuw nsw i64 %r961, 6
  %r978 = inttoptr i64 %r977 to ptr
  %r979 = load i16, ptr %r978, align 2
  %r980 = and i16 %r979, 2048
  %r981 = icmp eq i16 %r980, 0
  %r982 = load ptr, ptr @perry_ic_options_worker_ts__15, align 8
  %r983 = icmp ne ptr %r982, null
  %r984 = and i1 %r976, %r981
  %r985 = and i1 %r984, %r983
  br i1 %r985, label %pic.token.272, label %pic.desc.classify.262

pic.token.272:                                    ; preds = %pic.recv_hdr.271
  %r987 = add nuw nsw i64 %r961, 4
  %r988 = inttoptr i64 %r987 to ptr
  %r989 = load i32, ptr %r988, align 4
  %r990 = zext i32 %r989 to i64
  %r991 = or i64 %r990, 4611686018427387904
  %r992 = icmp ne i32 %r989, 0
  %r993 = getelementptr i64, ptr %r982, i64 0
  %r994 = load i64, ptr %r993, align 8
  %r995 = icmp eq i64 %r991, %r994
  %r996 = and i1 %r995, %r992
  br i1 %r996, label %pic.hit.256, label %pic.prefix.guard.258

pic.hit.overflow.273:                             ; preds = %pic.hit.256
  %r1001 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1002 = bitcast double %r1001 to i64
  %r1003 = and i64 %r1002, 281474976710655
  %r1004 = trunc i64 %r998 to i32
  %statepoint_token138 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r961, i64 %r1003, i32 %r1004, ptr @perry_ic_options_worker_ts__15, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated124, ptr addrspace(1) %rs4gc.s12, ptr addrspace(1) %rs4gc.s13) ]
  %r1005139 = call double @llvm.experimental.gc.result.f64(token %statepoint_token138)
  %rs4gc.s5.relocated140 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token138, i32 0, i32 0) ; (%rs4gc.s5.relocated124, %rs4gc.s5.relocated124)
  %rs4gc.s12.relocated141 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token138, i32 1, i32 1) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13.relocated142 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token138, i32 2, i32 2) ; (%rs4gc.s13, %rs4gc.s13)
  br label %pic.merge.270

pic.hit.inline.274:                               ; preds = %pic.hit.256
  %r1006 = shl i64 %r998, 3
  %r1007 = add nuw nsw i64 %r961, 16
  %r1008 = add i64 %r1007, %r1006
  %r1009 = inttoptr i64 %r1008 to ptr
  %r1010 = load double, ptr %r1009, align 8
  %r1011 = bitcast double %r1010 to i64
  %r1012 = icmp eq i64 %r1011, 9222246136947933200
  br i1 %r1012, label %pic.miss.267, label %pic.hit.live.257

pic.ways.275:                                     ; preds = %pic.miss.267
  %r1052 = getelementptr i64, ptr %r982, i64 4
  %r1053 = load i64, ptr %r1052, align 8
  %r1054 = icmp eq i64 %r1053, %r991
  %r1055 = getelementptr i64, ptr %r982, i64 5
  %r1056 = load i64, ptr %r1055, align 8
  %r1057 = select i1 %r1054, i64 %r1056, i64 0
  %r1058 = getelementptr i64, ptr %r982, i64 6
  %r1059 = load i64, ptr %r1058, align 8
  %r1060 = icmp eq i64 %r1059, %r991
  %r1061 = getelementptr i64, ptr %r982, i64 7
  %r1062 = load i64, ptr %r1061, align 8
  %r1063 = select i1 %r1060, i64 %r1062, i64 0
  %r1064 = getelementptr i64, ptr %r982, i64 8
  %r1065 = load i64, ptr %r1064, align 8
  %r1066 = icmp eq i64 %r1065, %r991
  %r1067 = getelementptr i64, ptr %r982, i64 9
  %r1068 = load i64, ptr %r1067, align 8
  %r1069 = select i1 %r1066, i64 %r1068, i64 0
  %r1070 = getelementptr i64, ptr %r982, i64 10
  %r1071 = load i64, ptr %r1070, align 8
  %r1072 = icmp eq i64 %r1071, %r991
  %r1073 = getelementptr i64, ptr %r982, i64 11
  %r1074 = load i64, ptr %r1073, align 8
  %r1075 = select i1 %r1072, i64 %r1074, i64 0
  %r1076 = or i1 %r1054, %r1060
  %r1077 = select i1 %r1054, i64 %r1057, i64 %r1063
  %r1078 = or i1 %r1066, %r1072
  %r1079 = select i1 %r1066, i64 %r1069, i64 %r1075
  %r1080 = or i1 %r1076, %r1078
  %r1081 = select i1 %r1076, i64 %r1077, i64 %r1079
  %r1082 = and i1 %r992, %r1080
  br i1 %r1082, label %pic.way.load.276, label %pic.miss.call.269

pic.way.load.276:                                 ; preds = %pic.ways.275
  %r1083 = shl i64 %r1081, 3
  %r1084 = add nuw nsw i64 %r961, 16
  %r1085 = add i64 %r1084, %r1083
  %r1086 = inttoptr i64 %r1085 to ptr
  %r1087 = load double, ptr %r1086, align 8
  %r1088 = bitcast double %r1087 to i64
  %r1089 = icmp eq i64 %r1088, 9222246136947933200
  br i1 %r1089, label %pic.miss.call.269, label %pic.way.live.277

pic.way.live.277:                                 ; preds = %pic.way.load.276
  br label %pic.merge.270

pget.throw_nullish.278:                           ; preds = %pget.recv_bad.249
  %r1098 = zext i1 %r1096 to i32
  %statepoint_token143 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1098, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.279:                       ; preds = %pget.recv_bad.249
  %r1099 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1100 = bitcast double %r1099 to i64
  %r1101 = and i64 %r1100, 281474976710655
  %statepoint_token144 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r960, i64 %r1101, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated124, ptr addrspace(1) %rs4gc.s12, ptr addrspace(1) %rs4gc.s13) ]
  %r1102145 = call double @llvm.experimental.gc.result.f64(token %statepoint_token144)
  %rs4gc.s5.relocated146 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token144, i32 0, i32 0) ; (%rs4gc.s5.relocated124, %rs4gc.s5.relocated124)
  %rs4gc.s12.relocated147 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token144, i32 1, i32 1) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13.relocated148 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token144, i32 2, i32 2) ; (%rs4gc.s13, %rs4gc.s13)
  br label %pget.recv_merge.251

guarded_add.numeric.280:                          ; preds = %pget.recv_merge.251
  %r1124 = fadd double %r1113, %r1111
  br label %guarded_add.merge.282

guarded_add.dynamic.281:                          ; preds = %pget.recv_merge.251
  %statepoint_token149 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r1113, double %r1111, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.32, ptr addrspace(1) %.0170) ]
  %r1125150 = call double @llvm.experimental.gc.result.f64(token %statepoint_token149)
  %rs4gc.s5.relocated151 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token149, i32 0, i32 0) ; (%.32, %.32)
  %rs4gc.s12.relocated152 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token149, i32 1, i32 1) ; (%.0170, %.0170)
  br label %guarded_add.merge.282

guarded_add.merge.282:                            ; preds = %guarded_add.dynamic.281, %guarded_add.numeric.280
  %.2172 = phi ptr addrspace(1) [ %.0170, %guarded_add.numeric.280 ], [ %rs4gc.s12.relocated152, %guarded_add.dynamic.281 ]
  %.34 = phi ptr addrspace(1) [ %.32, %guarded_add.numeric.280 ], [ %rs4gc.s5.relocated151, %guarded_add.dynamic.281 ]
  %r1126 = phi double [ %r1124, %guarded_add.numeric.280 ], [ %r1125150, %guarded_add.dynamic.281 ]
  %r1127.rs4i = ptrtoint ptr addrspace(1) %.2172 to i64
  %r1127.rs4o = call i64 asm "", "=r,0"(i64 %r1127.rs4i) #9
  %r1127 = bitcast i64 %r1127.rs4o to double
  %r1128 = bitcast double %r1127 to i64
  %r1129 = and i64 %r1128, -281474976710656
  %r1130 = icmp ne i64 %r1129, 9223090561878065152
  br i1 %r1130, label %str_addref.done.284, label %str_addref.call.283

str_addref.call.283:                              ; preds = %guarded_add.merge.282
  call void @js_string_addref_if_heap_string(double %r1127) #9
  br label %str_addref.done.284

str_addref.done.284:                              ; preds = %str_addref.call.283, %guarded_add.merge.282
  %r1142.rs4i = ptrtoint ptr addrspace(1) %.2172 to i64
  %r1142.rs4o = call i64 asm "", "=r,0"(i64 %r1142.rs4i) #9
  %r1142 = bitcast i64 %r1142.rs4o to double
  store double %r1142, ptr @perry_global_options_worker_ts__6, align 8
  %r1141.rs4i = ptrtoint ptr addrspace(1) %.2172 to i64
  %r1141.rs4o = call i64 asm "", "=r,0"(i64 %r1141.rs4i) #9
  %r1141 = bitcast i64 %r1141.rs4o to double
  %r1131 = bitcast double %r1141 to i64
  %r1139.rs4i = ptrtoint ptr addrspace(1) %.2172 to i64
  %r1139.rs4o = call i64 asm "", "=r,0"(i64 %r1139.rs4i) #9
  %r1139 = bitcast i64 %r1139.rs4o to double
  %r1140 = bitcast double %r1139 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1140) #9
  %r1132 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1133 = icmp ne i32 %r1132, 0
  br i1 %r1133, label %gcpoll.285, label %gcpoll.done.286

gcpoll.285:                                       ; preds = %str_addref.done.284
  %statepoint_token153 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.34) ]
  %rs4gc.s5.relocated154 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token153, i32 0, i32 0) ; (%.34, %.34)
  br label %gcpoll.done.286

gcpoll.done.286:                                  ; preds = %gcpoll.285, %str_addref.done.284
  %.35 = phi ptr addrspace(1) [ %rs4gc.s5.relocated154, %gcpoll.285 ], [ %.34, %str_addref.done.284 ]
  br label %for.update.234
}

; Function Attrs: noinline optsize
define double @perry_fn_options_worker_ts__run(double %arg15) #8 {
entry.0:
  %r1 = bitcast double %arg15 to i64
  %r2 = lshr i64 %r1, 48
  %r3 = icmp ult i64 %r2, 32761
  %r4 = icmp ugt i64 %r2, 32767
  %r5 = or i1 %r3, %r4
  %r6 = and i64 %r1, -4294967296
  %r7 = icmp eq i64 %r6, 9222809086901354496
  %r8 = or i1 %r5, %r7
  br i1 %r8, label %spec_public.fast.1, label %spec_public.fallback.2

spec_public.fast.1:                               ; preds = %entry.0
  %r9 = call double @"perry_fn_options_worker_ts__run$spec_b"(double %arg15)
  ret double %r9

spec_public.fallback.2:                           ; preds = %entry.0
  %r10 = call double @"perry_fn_options_worker_ts__run$generic"(double %arg15)
  ret double %r10
}

; Function Attrs: optsize
define double @__perry_wrap_perry_fn_options_worker_ts__identity(i64 %this_closure, double %a0, double %a1) #6 {
entry.0:
  %r1 = call double @perry_fn_options_worker_ts__identity(double %a0, double %a1)
  ret double %r1
}

; Function Attrs: optsize
define double @__perry_wrap_perry_fn_options_worker_ts__run(i64 %this_closure, double %a0) #6 {
entry.0:
  %r1 = call double @perry_fn_options_worker_ts__run(double %a0)
  ret double %r1
}

; Function Attrs: optsize
define internal double @__perry_wrap_perry_unknown_func_options_worker_ts(i64 %this_closure, double %a0, double %a1, double %a2, double %a3, double %a4) #6 {
entry.0:
  ret double 0x7FFC000000000001
}

; Function Attrs: optsize
define void @options_worker_ts__init() #6 {
entry.0:
  ret void
}

; Function Attrs: optsize
define i32 @main() #6 gc "statepoint-example" {
entry.0:
  %r318 = alloca [32 x double], align 8
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (ptr, i32)) @js_set_process_entry_path, i32 2, i32 0, ptr @options_worker_ts_.str.0, i32 118, i32 0, i32 0)
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_init, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token2 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32)) @js_gc_write_barriers_emitted, i32 1, i32 0, i32 1, i32 0, i32 0)
  %statepoint_token3 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @perry_macos_bundle_chdir, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token4 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @__perry_init_strings_options_worker_ts, i32 0, i32 0, i32 0, i32 0)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_global_options_worker_ts__1 to i64)) #9
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_global_options_worker_ts__4 to i64)) #9
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_global_options_worker_ts__5 to i64)) #9
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_global_options_worker_ts__6 to i64)) #9
  %statepoint_token5 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_mark_entry_module_esm, i32 0, i32 0, i32 0, i32 0)
  %r5 = load double, ptr @options_worker_ts_.str.5.handle, align 8
  %r6 = load double, ptr @options_worker_ts_.str.6.handle, align 8
  %statepoint_token6 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_native_module_named_esm_export_value, i32 2, i32 0, double %r5, double %r6, i32 0, i32 0)
  %statepoint_token7 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0)
  %r9100 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token7)
  %r10 = or i64 %r9100, 9222527611924643840
  %r11 = bitcast i64 %r10 to double
  %r12 = and i64 %r10, 281474976710655
  %r13 = lshr i64 %r10, 48
  %r14 = icmp eq i64 %r13, 32765
  %r15 = icmp ugt i64 %r12, 1048575
  %r16 = and i1 %r14, %r15
  br i1 %r16, label %arr.guard.deref.5, label %arr.fallback.2

arr.fast.1:                                       ; preds = %arr.guard.range.7
  %r75 = add i64 %r31, 24
  %r76 = inttoptr i64 %r75 to ptr
  %r77 = load double, ptr %r76, align 8
  %r78 = bitcast double %r77 to i64
  %r79 = icmp eq i64 %r78, 9222246136947933200
  %r81 = select i1 %r79, double 0x7FFC000000000001, double %r77
  br label %arr.merge.4

arr.fallback.2:                                   ; preds = %arr.guard.live.6, %arr.guard.deref.5, %entry.0
  %statepoint_token101 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 7760974052394532880, double %r11, double 2.000000e+00, i32 0, i32 0)
  %r71102 = call double @llvm.experimental.gc.result.f64(token %statepoint_token101)
  br label %arr.merge.4

arr.guard.oob.3:                                  ; preds = %arr.guard.range.7
  br label %arr.merge.4

arr.merge.4:                                      ; preds = %arr.guard.oob.3, %arr.fallback.2, %arr.fast.1
  %r82 = phi double [ %r81, %arr.fast.1 ], [ %r71102, %arr.fallback.2 ], [ 0x7FFC000000000001, %arr.guard.oob.3 ]
  %r83 = load double, ptr @options_worker_ts_.str.7.handle, align 8
  %statepoint_token103 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_fs_read_file_dispatch, i32 2, i32 0, double %r82, double %r83, i32 0, i32 0)
  %r84104 = call double @llvm.experimental.gc.result.f64(token %statepoint_token103)
  %rs4gc.b6 = bitcast double %r84104 to i64
  %rs4gc.s6 = inttoptr i64 %rs4gc.b6 to ptr addrspace(1)
  %r85.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r85 = call i64 asm "", "=r,0"(i64 %r85.rs4i) #9
  %r86 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r87 = icmp ne i32 %r86, 0
  br i1 %r87, label %shadow.root.barrier.8, label %shadow.root.barrier.done.9

arr.guard.deref.5:                                ; preds = %entry.0
  %r17 = bitcast double %r11 to i64
  %r18 = and i64 %r17, 281474976710655
  %r19 = sub nsw i64 %r18, 8
  %r20 = inttoptr i64 %r19 to ptr
  %r21 = load i8, ptr %r20, align 1
  %r22 = icmp eq i8 %r21, 1
  %r23 = sub nsw i64 %r18, 7
  %r24 = inttoptr i64 %r23 to ptr
  %r25 = load i8, ptr %r24, align 1
  %r26 = and i8 %r25, -128
  %r27 = icmp ne i8 %r26, 0
  %r28 = inttoptr i64 %r18 to ptr
  %r29 = load i64, ptr %r28, align 8
  %r30 = and i1 %r22, %r27
  %r31 = select i1 %r30, i64 %r29, i64 %r18
  %r32 = lshr i64 %r31, 48
  %r33 = icmp eq i64 %r32, 0
  %r34 = icmp ugt i64 %r31, 1048575
  %r35 = and i1 %r33, %r34
  br i1 %r35, label %arr.guard.live.6, label %arr.fallback.2

arr.guard.live.6:                                 ; preds = %arr.guard.deref.5
  %r36 = sub nuw i64 %r31, 8
  %r37 = inttoptr i64 %r36 to ptr
  %r38 = load i8, ptr %r37, align 1
  %r39 = icmp eq i8 %r38, 1
  %r40 = sub nuw i64 %r31, 7
  %r41 = inttoptr i64 %r40 to ptr
  %r42 = load i8, ptr %r41, align 1
  %r43 = and i8 %r42, -128
  %r44 = icmp eq i8 %r43, 0
  %r45 = sub nuw i64 %r31, 6
  %r46 = inttoptr i64 %r45 to ptr
  %r47 = load i16, ptr %r46, align 2
  %r48 = and i16 %r47, 1024
  %r49 = icmp eq i16 %r48, 0
  %r50 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r51 = icmp eq i8 %r50, 0
  %r52 = inttoptr i64 %r31 to ptr
  %r53 = load i32, ptr %r52, align 4
  %r54 = getelementptr i8, ptr %r52, i64 4
  %r55 = load i32, ptr %r54, align 4
  %r59 = icmp ule i32 %r53, 16000000
  %r60 = icmp ule i32 %r55, 16000000
  %r61 = icmp ule i32 %r53, %r55
  %r62 = and i1 %r39, %r44
  %r63 = and i1 %r62, %r49
  %r64 = and i1 %r63, %r51
  %r66 = and i1 %r64, %r59
  %r67 = and i1 %r66, %r60
  %r68 = and i1 %r67, %r61
  br i1 %r68, label %arr.guard.range.7, label %arr.fallback.2

arr.guard.range.7:                                ; preds = %arr.guard.live.6
  %r58 = icmp ult i32 2, %r53
  br i1 %r58, label %arr.fast.1, label %arr.guard.oob.3

shadow.root.barrier.8:                            ; preds = %arr.merge.4
  call void @js_write_barrier_root_nanbox(i64 %r85) #9
  br label %shadow.root.barrier.done.9

shadow.root.barrier.done.9:                       ; preds = %shadow.root.barrier.8, %arr.merge.4
  %statepoint_token105 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6) ]
  %r88106 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token105)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 0, i32 0) ; (%rs4gc.s6, %rs4gc.s6)
  %r89 = or i64 %r88106, 9222527611924643840
  %r90 = bitcast i64 %r89 to double
  %r91 = and i64 %r89, 281474976710655
  %r92 = lshr i64 %r89, 48
  %r93 = icmp eq i64 %r92, 32765
  %r94 = icmp ugt i64 %r91, 1048575
  %r95 = and i1 %r93, %r94
  br i1 %r95, label %arr.guard.deref.14, label %arr.fallback.11

arr.fast.10:                                      ; preds = %arr.guard.range.16
  %r154 = add i64 %r110, 32
  %r155 = inttoptr i64 %r154 to ptr
  %r156 = load double, ptr %r155, align 8
  %r157 = bitcast double %r156 to i64
  %r158 = icmp eq i64 %r157, 9222246136947933200
  %r160 = select i1 %r158, double 0x7FFC000000000001, double %r156
  br label %arr.merge.13

arr.fallback.11:                                  ; preds = %arr.guard.live.15, %arr.guard.deref.14, %shadow.root.barrier.done.9
  %statepoint_token107 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 7760974052394532881, double %r90, double 3.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6.relocated) ]
  %r150108 = call double @llvm.experimental.gc.result.f64(token %statepoint_token107)
  %rs4gc.s6.relocated109 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token107, i32 0, i32 0) ; (%rs4gc.s6.relocated, %rs4gc.s6.relocated)
  br label %arr.merge.13

arr.guard.oob.12:                                 ; preds = %arr.guard.range.16
  br label %arr.merge.13

arr.merge.13:                                     ; preds = %arr.guard.oob.12, %arr.fallback.11, %arr.fast.10
  %.0 = phi ptr addrspace(1) [ %rs4gc.s6.relocated, %arr.fast.10 ], [ %rs4gc.s6.relocated, %arr.guard.oob.12 ], [ %rs4gc.s6.relocated109, %arr.fallback.11 ]
  %r161 = phi double [ %r160, %arr.fast.10 ], [ %r150108, %arr.fallback.11 ], [ 0x7FFC000000000001, %arr.guard.oob.12 ]
  store double %r161, ptr @perry_global_options_worker_ts__1, align 8
  %r162 = bitcast double %r161 to i64
  call void @js_write_barrier_root_nanbox(i64 %r162) #9
  %statepoint_token110 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0) ]
  %r164111 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token110)
  %rs4gc.s6.relocated112 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token110, i32 0, i32 0) ; (%.0, %.0)
  %r165 = or i64 %r164111, 9222527611924643840
  %r166 = bitcast i64 %r165 to double
  %r167 = and i64 %r165, 281474976710655
  %r168 = lshr i64 %r165, 48
  %r169 = icmp eq i64 %r168, 32765
  %r170 = icmp ugt i64 %r167, 1048575
  %r171 = and i1 %r169, %r170
  br i1 %r171, label %arr.guard.deref.21, label %arr.fallback.18

arr.guard.deref.14:                               ; preds = %shadow.root.barrier.done.9
  %r96 = bitcast double %r90 to i64
  %r97 = and i64 %r96, 281474976710655
  %r98 = sub nsw i64 %r97, 8
  %r99 = inttoptr i64 %r98 to ptr
  %r100 = load i8, ptr %r99, align 1
  %r101 = icmp eq i8 %r100, 1
  %r102 = sub nsw i64 %r97, 7
  %r103 = inttoptr i64 %r102 to ptr
  %r104 = load i8, ptr %r103, align 1
  %r105 = and i8 %r104, -128
  %r106 = icmp ne i8 %r105, 0
  %r107 = inttoptr i64 %r97 to ptr
  %r108 = load i64, ptr %r107, align 8
  %r109 = and i1 %r101, %r106
  %r110 = select i1 %r109, i64 %r108, i64 %r97
  %r111 = lshr i64 %r110, 48
  %r112 = icmp eq i64 %r111, 0
  %r113 = icmp ugt i64 %r110, 1048575
  %r114 = and i1 %r112, %r113
  br i1 %r114, label %arr.guard.live.15, label %arr.fallback.11

arr.guard.live.15:                                ; preds = %arr.guard.deref.14
  %r115 = sub nuw i64 %r110, 8
  %r116 = inttoptr i64 %r115 to ptr
  %r117 = load i8, ptr %r116, align 1
  %r118 = icmp eq i8 %r117, 1
  %r119 = sub nuw i64 %r110, 7
  %r120 = inttoptr i64 %r119 to ptr
  %r121 = load i8, ptr %r120, align 1
  %r122 = and i8 %r121, -128
  %r123 = icmp eq i8 %r122, 0
  %r124 = sub nuw i64 %r110, 6
  %r125 = inttoptr i64 %r124 to ptr
  %r126 = load i16, ptr %r125, align 2
  %r127 = and i16 %r126, 1024
  %r128 = icmp eq i16 %r127, 0
  %r129 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r130 = icmp eq i8 %r129, 0
  %r131 = inttoptr i64 %r110 to ptr
  %r132 = load i32, ptr %r131, align 4
  %r133 = getelementptr i8, ptr %r131, i64 4
  %r134 = load i32, ptr %r133, align 4
  %r138 = icmp ule i32 %r132, 16000000
  %r139 = icmp ule i32 %r134, 16000000
  %r140 = icmp ule i32 %r132, %r134
  %r141 = and i1 %r118, %r123
  %r142 = and i1 %r141, %r128
  %r143 = and i1 %r142, %r130
  %r145 = and i1 %r143, %r138
  %r146 = and i1 %r145, %r139
  %r147 = and i1 %r146, %r140
  br i1 %r147, label %arr.guard.range.16, label %arr.fallback.11

arr.guard.range.16:                               ; preds = %arr.guard.live.15
  %r137 = icmp ult i32 3, %r132
  br i1 %r137, label %arr.fast.10, label %arr.guard.oob.12

arr.fast.17:                                      ; preds = %arr.guard.range.23
  %r230 = add i64 %r186, 40
  %r231 = inttoptr i64 %r230 to ptr
  %r232 = load double, ptr %r231, align 8
  %r233 = bitcast double %r232 to i64
  %r234 = icmp eq i64 %r233, 9222246136947933200
  %r236 = select i1 %r234, double 0x7FFC000000000001, double %r232
  br label %arr.merge.20

arr.fallback.18:                                  ; preds = %arr.guard.live.22, %arr.guard.deref.21, %arr.merge.13
  %statepoint_token113 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 7760974052394532882, double %r166, double 4.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6.relocated112) ]
  %r226114 = call double @llvm.experimental.gc.result.f64(token %statepoint_token113)
  %rs4gc.s6.relocated115 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token113, i32 0, i32 0) ; (%rs4gc.s6.relocated112, %rs4gc.s6.relocated112)
  br label %arr.merge.20

arr.guard.oob.19:                                 ; preds = %arr.guard.range.23
  br label %arr.merge.20

arr.merge.20:                                     ; preds = %arr.guard.oob.19, %arr.fallback.18, %arr.fast.17
  %.1 = phi ptr addrspace(1) [ %rs4gc.s6.relocated112, %arr.fast.17 ], [ %rs4gc.s6.relocated112, %arr.guard.oob.19 ], [ %rs4gc.s6.relocated115, %arr.fallback.18 ]
  %r237 = phi double [ %r236, %arr.fast.17 ], [ %r226114, %arr.fallback.18 ], [ 0x7FFC000000000001, %arr.guard.oob.19 ]
  %statepoint_token116 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_number_coerce, i32 1, i32 0, double %r237, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1) ]
  %r238117 = call double @llvm.experimental.gc.result.f64(token %statepoint_token116)
  %rs4gc.s6.relocated118 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 0, i32 0) ; (%.1, %.1)
  %statepoint_token119 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6.relocated118) ]
  %r240120 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token119)
  %rs4gc.s6.relocated121 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token119, i32 0, i32 0) ; (%rs4gc.s6.relocated118, %rs4gc.s6.relocated118)
  %r241 = or i64 %r240120, 9222527611924643840
  %r242 = bitcast i64 %r241 to double
  %r243 = and i64 %r241, 281474976710655
  %r244 = lshr i64 %r241, 48
  %r245 = icmp eq i64 %r244, 32765
  %r246 = icmp ugt i64 %r243, 1048575
  %r247 = and i1 %r245, %r246
  br i1 %r247, label %arr.guard.deref.28, label %arr.fallback.25

arr.guard.deref.21:                               ; preds = %arr.merge.13
  %r172 = bitcast double %r166 to i64
  %r173 = and i64 %r172, 281474976710655
  %r174 = sub nsw i64 %r173, 8
  %r175 = inttoptr i64 %r174 to ptr
  %r176 = load i8, ptr %r175, align 1
  %r177 = icmp eq i8 %r176, 1
  %r178 = sub nsw i64 %r173, 7
  %r179 = inttoptr i64 %r178 to ptr
  %r180 = load i8, ptr %r179, align 1
  %r181 = and i8 %r180, -128
  %r182 = icmp ne i8 %r181, 0
  %r183 = inttoptr i64 %r173 to ptr
  %r184 = load i64, ptr %r183, align 8
  %r185 = and i1 %r177, %r182
  %r186 = select i1 %r185, i64 %r184, i64 %r173
  %r187 = lshr i64 %r186, 48
  %r188 = icmp eq i64 %r187, 0
  %r189 = icmp ugt i64 %r186, 1048575
  %r190 = and i1 %r188, %r189
  br i1 %r190, label %arr.guard.live.22, label %arr.fallback.18

arr.guard.live.22:                                ; preds = %arr.guard.deref.21
  %r191 = sub nuw i64 %r186, 8
  %r192 = inttoptr i64 %r191 to ptr
  %r193 = load i8, ptr %r192, align 1
  %r194 = icmp eq i8 %r193, 1
  %r195 = sub nuw i64 %r186, 7
  %r196 = inttoptr i64 %r195 to ptr
  %r197 = load i8, ptr %r196, align 1
  %r198 = and i8 %r197, -128
  %r199 = icmp eq i8 %r198, 0
  %r200 = sub nuw i64 %r186, 6
  %r201 = inttoptr i64 %r200 to ptr
  %r202 = load i16, ptr %r201, align 2
  %r203 = and i16 %r202, 1024
  %r204 = icmp eq i16 %r203, 0
  %r205 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r206 = icmp eq i8 %r205, 0
  %r207 = inttoptr i64 %r186 to ptr
  %r208 = load i32, ptr %r207, align 4
  %r209 = getelementptr i8, ptr %r207, i64 4
  %r210 = load i32, ptr %r209, align 4
  %r214 = icmp ule i32 %r208, 16000000
  %r215 = icmp ule i32 %r210, 16000000
  %r216 = icmp ule i32 %r208, %r210
  %r217 = and i1 %r194, %r199
  %r218 = and i1 %r217, %r204
  %r219 = and i1 %r218, %r206
  %r221 = and i1 %r219, %r214
  %r222 = and i1 %r221, %r215
  %r223 = and i1 %r222, %r216
  br i1 %r223, label %arr.guard.range.23, label %arr.fallback.18

arr.guard.range.23:                               ; preds = %arr.guard.live.22
  %r213 = icmp ult i32 4, %r208
  br i1 %r213, label %arr.fast.17, label %arr.guard.oob.19

arr.fast.24:                                      ; preds = %arr.guard.range.30
  %r306 = add i64 %r262, 48
  %r307 = inttoptr i64 %r306 to ptr
  %r308 = load double, ptr %r307, align 8
  %r309 = bitcast double %r308 to i64
  %r310 = icmp eq i64 %r309, 9222246136947933200
  %r312 = select i1 %r310, double 0x7FFC000000000001, double %r308
  br label %arr.merge.27

arr.fallback.25:                                  ; preds = %arr.guard.live.29, %arr.guard.deref.28, %arr.merge.20
  %statepoint_token122 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 7760974052394532883, double %r242, double 5.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6.relocated121) ]
  %r302123 = call double @llvm.experimental.gc.result.f64(token %statepoint_token122)
  %rs4gc.s6.relocated124 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token122, i32 0, i32 0) ; (%rs4gc.s6.relocated121, %rs4gc.s6.relocated121)
  br label %arr.merge.27

arr.guard.oob.26:                                 ; preds = %arr.guard.range.30
  br label %arr.merge.27

arr.merge.27:                                     ; preds = %arr.guard.oob.26, %arr.fallback.25, %arr.fast.24
  %.2 = phi ptr addrspace(1) [ %rs4gc.s6.relocated121, %arr.fast.24 ], [ %rs4gc.s6.relocated121, %arr.guard.oob.26 ], [ %rs4gc.s6.relocated124, %arr.fallback.25 ]
  %r313 = phi double [ %r312, %arr.fast.24 ], [ %r302123, %arr.fallback.25 ], [ 0x7FFC000000000001, %arr.guard.oob.26 ]
  %statepoint_token125 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_number_coerce, i32 1, i32 0, double %r313, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r314126 = call double @llvm.experimental.gc.result.f64(token %statepoint_token125)
  %rs4gc.s6.relocated127 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token125, i32 0, i32 0) ; (%.2, %.2)
  %r315 = load double, ptr @options_worker_ts_.str.8.handle, align 8
  %r316.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6.relocated127 to i64
  %r316.rs4o = call i64 asm "", "=r,0"(i64 %r316.rs4i) #9
  %r316 = bitcast i64 %r316.rs4o to double
  %r317 = load double, ptr @options_worker_ts_.str.9.handle, align 8
  %r319 = getelementptr double, ptr %r318, i64 0
  store double %r315, ptr %r319, align 8
  %r320 = getelementptr double, ptr %r318, i64 1
  store double %r316, ptr %r320, align 8
  %r321 = getelementptr double, ptr %r318, i64 2
  store double %r317, ptr %r321, align 8
  %r322 = ptrtoint ptr %r318 to i64
  %statepoint_token128 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r322, i32 3, i32 0, i32 0)
  %r323129 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token128)
  %r324 = or i64 %r323129, 9223090561878065152
  %r325 = bitcast i64 %r324 to double
  %statepoint_token130 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r325, i32 0, i32 0)
  %r326131 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token130)
  %statepoint_token132 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r326131, i32 0, i32 0)
  %r327133 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token132)
  %r328 = bitcast i64 %r327133 to double
  %r329 = and i64 %r327133, 281474976710655
  %r330 = lshr i64 %r327133, 48
  %r331 = and i64 %r330, 65533
  %r332 = icmp eq i64 %r331, 32765
  br i1 %r332, label %pget.recv_ok.32, label %pget.recv_other.36

arr.guard.deref.28:                               ; preds = %arr.merge.20
  %r248 = bitcast double %r242 to i64
  %r249 = and i64 %r248, 281474976710655
  %r250 = sub nsw i64 %r249, 8
  %r251 = inttoptr i64 %r250 to ptr
  %r252 = load i8, ptr %r251, align 1
  %r253 = icmp eq i8 %r252, 1
  %r254 = sub nsw i64 %r249, 7
  %r255 = inttoptr i64 %r254 to ptr
  %r256 = load i8, ptr %r255, align 1
  %r257 = and i8 %r256, -128
  %r258 = icmp ne i8 %r257, 0
  %r259 = inttoptr i64 %r249 to ptr
  %r260 = load i64, ptr %r259, align 8
  %r261 = and i1 %r253, %r258
  %r262 = select i1 %r261, i64 %r260, i64 %r249
  %r263 = lshr i64 %r262, 48
  %r264 = icmp eq i64 %r263, 0
  %r265 = icmp ugt i64 %r262, 1048575
  %r266 = and i1 %r264, %r265
  br i1 %r266, label %arr.guard.live.29, label %arr.fallback.25

arr.guard.live.29:                                ; preds = %arr.guard.deref.28
  %r267 = sub nuw i64 %r262, 8
  %r268 = inttoptr i64 %r267 to ptr
  %r269 = load i8, ptr %r268, align 1
  %r270 = icmp eq i8 %r269, 1
  %r271 = sub nuw i64 %r262, 7
  %r272 = inttoptr i64 %r271 to ptr
  %r273 = load i8, ptr %r272, align 1
  %r274 = and i8 %r273, -128
  %r275 = icmp eq i8 %r274, 0
  %r276 = sub nuw i64 %r262, 6
  %r277 = inttoptr i64 %r276 to ptr
  %r278 = load i16, ptr %r277, align 2
  %r279 = and i16 %r278, 1024
  %r280 = icmp eq i16 %r279, 0
  %r281 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r282 = icmp eq i8 %r281, 0
  %r283 = inttoptr i64 %r262 to ptr
  %r284 = load i32, ptr %r283, align 4
  %r285 = getelementptr i8, ptr %r283, i64 4
  %r286 = load i32, ptr %r285, align 4
  %r290 = icmp ule i32 %r284, 16000000
  %r291 = icmp ule i32 %r286, 16000000
  %r292 = icmp ule i32 %r284, %r286
  %r293 = and i1 %r270, %r275
  %r294 = and i1 %r293, %r280
  %r295 = and i1 %r294, %r282
  %r297 = and i1 %r295, %r290
  %r298 = and i1 %r297, %r291
  %r299 = and i1 %r298, %r292
  br i1 %r299, label %arr.guard.range.30, label %arr.fallback.25

arr.guard.range.30:                               ; preds = %arr.guard.live.29
  %r289 = icmp ult i32 5, %r284
  br i1 %r289, label %arr.fast.24, label %arr.guard.oob.26

pget.recv_sso.31:                                 ; preds = %pget.recv_other.36
  %r470 = load double, ptr @options_worker_ts_.str.10.handle, align 8
  %r471 = bitcast double %r470 to i64
  %r472 = and i64 %r471, 281474976710655
  %statepoint_token134 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r327133, i64 %r472, i32 0, i32 0)
  %r473135 = call double @llvm.experimental.gc.result.f64(token %statepoint_token134)
  br label %pget.recv_merge.35

pget.recv_ok.32:                                  ; preds = %arr.merge.27
  %r339 = icmp ugt i64 %r329, 1048575
  br i1 %r339, label %pic.recv_hdr.53, label %pic.miss.cold.50

pget.recv_bad.33:                                 ; preds = %pget.check_class_ref.37
  %r462 = icmp eq i64 %r327133, 9222246136947933185
  %r463 = icmp eq i64 %r327133, 9222246136947933186
  %r464 = or i1 %r462, %r463
  br i1 %r464, label %pget.throw_nullish.60, label %pget.recv_undef_return.61

pget.recv_class_ref.34:                           ; preds = %pget.check_class_ref.37
  %r335 = load double, ptr @options_worker_ts_.str.10.handle, align 8
  %r336 = bitcast double %r335 to i64
  %r337 = and i64 %r336, 281474976710655
  %statepoint_token136 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532884, i64 %r327133, i64 %r337, i32 0, i32 0)
  %r338137 = call double @llvm.experimental.gc.result.f64(token %statepoint_token136)
  br label %pget.recv_merge.35

pget.recv_merge.35:                               ; preds = %pget.recv_undef_return.61, %pic.merge.52, %pget.recv_class_ref.34, %pget.recv_sso.31
  %r474 = phi double [ %r461, %pic.merge.52 ], [ %r469144, %pget.recv_undef_return.61 ], [ %r473135, %pget.recv_sso.31 ], [ %r338137, %pget.recv_class_ref.34 ]
  store double %r474, ptr @perry_global_options_worker_ts__4, align 8
  %r475 = bitcast double %r474 to i64
  call void @js_write_barrier_root_nanbox(i64 %r475) #9
  %r476 = load double, ptr @options_worker_ts_.str.11.handle, align 8
  %r477 = load double, ptr @options_worker_ts_.str.12.handle, align 8
  %r478 = load double, ptr @options_worker_ts_.str.13.handle, align 8
  %r479 = load double, ptr @options_worker_ts_.str.14.handle, align 8
  %r480 = load double, ptr @options_worker_ts_.str.15.handle, align 8
  %r481 = load double, ptr @options_worker_ts_.str.16.handle, align 8
  br label %arena_state.init.62

pget.recv_other.36:                               ; preds = %arr.merge.27
  %r333 = icmp eq i64 %r330, 32761
  br i1 %r333, label %pget.recv_sso.31, label %pget.check_class_ref.37

pget.check_class_ref.37:                          ; preds = %pget.recv_other.36
  %r334 = icmp eq i64 %r330, 32766
  br i1 %r334, label %pget.recv_class_ref.34, label %pget.recv_bad.33

pic.hit.38:                                       ; preds = %pic.token.54
  %r364 = getelementptr i64, ptr %r349, i64 1
  %r365 = load i64, ptr %r364, align 8
  %r366 = and i64 %r365, 1073741824
  %r367 = icmp ne i64 %r366, 0
  br i1 %r367, label %pic.hit.overflow.55, label %pic.hit.inline.56

pic.hit.live.39:                                  ; preds = %pic.hit.inline.56
  br label %pic.merge.52

pic.prefix.guard.40:                              ; preds = %pic.token.54
  %r380 = getelementptr i64, ptr %r349, i64 2
  %r381 = load i64, ptr %r380, align 8
  %r382 = icmp ne i64 %r381, 0
  br i1 %r382, label %pic.prefix.meta.41, label %pic.miss.49

pic.prefix.meta.41:                               ; preds = %pic.prefix.guard.40
  %r383 = add nuw nsw i64 %r329, 8
  %r384 = inttoptr i64 %r383 to ptr
  %r385 = load i64, ptr %r384, align 8
  %r386 = icmp ne i64 %r385, 0
  br i1 %r386, label %pic.prefix.token.42, label %pic.miss.49

pic.prefix.token.42:                              ; preds = %pic.prefix.meta.41
  %r387 = inttoptr i64 %r385 to ptr
  %r388 = getelementptr i64, ptr %r387, i64 6
  %r389 = load i64, ptr %r388, align 8
  %r390 = icmp eq i64 %r389, %r381
  br i1 %r390, label %pic.prefix.hit.43, label %pic.miss.49

pic.prefix.hit.43:                                ; preds = %pic.prefix.token.42
  %r391 = getelementptr i64, ptr %r349, i64 1
  %r392 = load i64, ptr %r391, align 8
  %r393 = shl i64 %r392, 3
  %r394 = add nuw nsw i64 %r329, 16
  %r395 = add i64 %r394, %r393
  %r396 = inttoptr i64 %r395 to ptr
  %r397 = load double, ptr %r396, align 8
  br label %pic.merge.52

pic.desc.classify.44:                             ; preds = %pic.recv_hdr.53
  %r353 = and i1 %r343, %r350
  br i1 %r353, label %pic.desc.prefix.guard.45, label %pic.miss.cold.50

pic.desc.prefix.guard.45:                         ; preds = %pic.desc.classify.44
  %r398 = getelementptr i64, ptr %r349, i64 2
  %r399 = load i64, ptr %r398, align 8
  %r400 = icmp ne i64 %r399, 0
  br i1 %r400, label %pic.desc.prefix.meta.46, label %pic.miss.cold.50

pic.desc.prefix.meta.46:                          ; preds = %pic.desc.prefix.guard.45
  %r401 = add nuw nsw i64 %r329, 8
  %r402 = inttoptr i64 %r401 to ptr
  %r403 = load i64, ptr %r402, align 8
  %r404 = icmp ne i64 %r403, 0
  br i1 %r404, label %pic.desc.prefix.token.47, label %pic.miss.cold.50

pic.desc.prefix.token.47:                         ; preds = %pic.desc.prefix.meta.46
  %r405 = inttoptr i64 %r403 to ptr
  %r406 = getelementptr i64, ptr %r405, i64 6
  %r407 = load i64, ptr %r406, align 8
  %r408 = icmp eq i64 %r407, %r399
  br i1 %r408, label %pic.desc.prefix.hit.48, label %pic.miss.cold.50

pic.desc.prefix.hit.48:                           ; preds = %pic.desc.prefix.token.47
  %r409 = getelementptr i64, ptr %r349, i64 1
  %r410 = load i64, ptr %r409, align 8
  %r411 = shl i64 %r410, 3
  %r412 = add nuw nsw i64 %r329, 16
  %r413 = add i64 %r412, %r411
  %r414 = inttoptr i64 %r413 to ptr
  %r415 = load double, ptr %r414, align 8
  br label %pic.merge.52

pic.miss.49:                                      ; preds = %pic.hit.inline.56, %pic.prefix.token.42, %pic.prefix.meta.41, %pic.prefix.guard.40
  %r416 = getelementptr i64, ptr %r349, i64 3
  %r417 = load i64, ptr %r416, align 8
  %r418 = icmp sgt i64 %r417, 0
  br i1 %r418, label %pic.ways.57, label %pic.miss.call.51

pic.miss.cold.50:                                 ; preds = %pic.desc.prefix.token.47, %pic.desc.prefix.meta.46, %pic.desc.prefix.guard.45, %pic.desc.classify.44, %pget.recv_ok.32
  br label %pic.miss.call.51

pic.miss.call.51:                                 ; preds = %pic.way.load.58, %pic.ways.57, %pic.miss.cold.50, %pic.miss.49
  %r457 = load double, ptr @options_worker_ts_.str.10.handle, align 8
  %r458 = bitcast double %r457 to i64
  %r459 = and i64 %r458, 281474976710655
  %statepoint_token138 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r329, i64 %r459, ptr @perry_ic_options_worker_ts__21, i32 0, i32 0)
  %r460139 = call double @llvm.experimental.gc.result.f64(token %statepoint_token138)
  br label %pic.merge.52

pic.merge.52:                                     ; preds = %pic.way.live.59, %pic.hit.overflow.55, %pic.miss.call.51, %pic.desc.prefix.hit.48, %pic.prefix.hit.43, %pic.hit.live.39
  %r461 = phi double [ %r377, %pic.hit.live.39 ], [ %r372141, %pic.hit.overflow.55 ], [ %r397, %pic.prefix.hit.43 ], [ %r415, %pic.desc.prefix.hit.48 ], [ %r454, %pic.way.live.59 ], [ %r460139, %pic.miss.call.51 ]
  br label %pget.recv_merge.35

pic.recv_hdr.53:                                  ; preds = %pget.recv_ok.32
  %r340 = sub nuw nsw i64 %r329, 8
  %r341 = inttoptr i64 %r340 to ptr
  %r342 = load i8, ptr %r341, align 1
  %r343 = icmp eq i8 %r342, 2
  %r344 = sub nuw nsw i64 %r329, 6
  %r345 = inttoptr i64 %r344 to ptr
  %r346 = load i16, ptr %r345, align 2
  %r347 = and i16 %r346, 2048
  %r348 = icmp eq i16 %r347, 0
  %r349 = load ptr, ptr @perry_ic_options_worker_ts__21, align 8
  %r350 = icmp ne ptr %r349, null
  %r351 = and i1 %r343, %r348
  %r352 = and i1 %r351, %r350
  br i1 %r352, label %pic.token.54, label %pic.desc.classify.44

pic.token.54:                                     ; preds = %pic.recv_hdr.53
  %r354 = add nuw nsw i64 %r329, 4
  %r355 = inttoptr i64 %r354 to ptr
  %r356 = load i32, ptr %r355, align 4
  %r357 = zext i32 %r356 to i64
  %r358 = or i64 %r357, 4611686018427387904
  %r359 = icmp ne i32 %r356, 0
  %r360 = getelementptr i64, ptr %r349, i64 0
  %r361 = load i64, ptr %r360, align 8
  %r362 = icmp eq i64 %r358, %r361
  %r363 = and i1 %r362, %r359
  br i1 %r363, label %pic.hit.38, label %pic.prefix.guard.40

pic.hit.overflow.55:                              ; preds = %pic.hit.38
  %r368 = load double, ptr @options_worker_ts_.str.10.handle, align 8
  %r369 = bitcast double %r368 to i64
  %r370 = and i64 %r369, 281474976710655
  %r371 = trunc i64 %r365 to i32
  %statepoint_token140 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r329, i64 %r370, i32 %r371, ptr @perry_ic_options_worker_ts__21, i32 0, i32 0)
  %r372141 = call double @llvm.experimental.gc.result.f64(token %statepoint_token140)
  br label %pic.merge.52

pic.hit.inline.56:                                ; preds = %pic.hit.38
  %r373 = shl i64 %r365, 3
  %r374 = add nuw nsw i64 %r329, 16
  %r375 = add i64 %r374, %r373
  %r376 = inttoptr i64 %r375 to ptr
  %r377 = load double, ptr %r376, align 8
  %r378 = bitcast double %r377 to i64
  %r379 = icmp eq i64 %r378, 9222246136947933200
  br i1 %r379, label %pic.miss.49, label %pic.hit.live.39

pic.ways.57:                                      ; preds = %pic.miss.49
  %r419 = getelementptr i64, ptr %r349, i64 4
  %r420 = load i64, ptr %r419, align 8
  %r421 = icmp eq i64 %r420, %r358
  %r422 = getelementptr i64, ptr %r349, i64 5
  %r423 = load i64, ptr %r422, align 8
  %r424 = select i1 %r421, i64 %r423, i64 0
  %r425 = getelementptr i64, ptr %r349, i64 6
  %r426 = load i64, ptr %r425, align 8
  %r427 = icmp eq i64 %r426, %r358
  %r428 = getelementptr i64, ptr %r349, i64 7
  %r429 = load i64, ptr %r428, align 8
  %r430 = select i1 %r427, i64 %r429, i64 0
  %r431 = getelementptr i64, ptr %r349, i64 8
  %r432 = load i64, ptr %r431, align 8
  %r433 = icmp eq i64 %r432, %r358
  %r434 = getelementptr i64, ptr %r349, i64 9
  %r435 = load i64, ptr %r434, align 8
  %r436 = select i1 %r433, i64 %r435, i64 0
  %r437 = getelementptr i64, ptr %r349, i64 10
  %r438 = load i64, ptr %r437, align 8
  %r439 = icmp eq i64 %r438, %r358
  %r440 = getelementptr i64, ptr %r349, i64 11
  %r441 = load i64, ptr %r440, align 8
  %r442 = select i1 %r439, i64 %r441, i64 0
  %r443 = or i1 %r421, %r427
  %r444 = select i1 %r421, i64 %r424, i64 %r430
  %r445 = or i1 %r433, %r439
  %r446 = select i1 %r433, i64 %r436, i64 %r442
  %r447 = or i1 %r443, %r445
  %r448 = select i1 %r443, i64 %r444, i64 %r446
  %r449 = and i1 %r359, %r447
  br i1 %r449, label %pic.way.load.58, label %pic.miss.call.51

pic.way.load.58:                                  ; preds = %pic.ways.57
  %r450 = shl i64 %r448, 3
  %r451 = add nuw nsw i64 %r329, 16
  %r452 = add i64 %r451, %r450
  %r453 = inttoptr i64 %r452 to ptr
  %r454 = load double, ptr %r453, align 8
  %r455 = bitcast double %r454 to i64
  %r456 = icmp eq i64 %r455, 9222246136947933200
  br i1 %r456, label %pic.miss.call.51, label %pic.way.live.59

pic.way.live.59:                                  ; preds = %pic.way.load.58
  br label %pic.merge.52

pget.throw_nullish.60:                            ; preds = %pget.recv_bad.33
  %r465 = zext i1 %r463 to i32
  %statepoint_token142 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r465, ptr @options_worker_ts_.str.10.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.61:                        ; preds = %pget.recv_bad.33
  %r466 = load double, ptr @options_worker_ts_.str.10.handle, align 8
  %r467 = bitcast double %r466 to i64
  %r468 = and i64 %r467, 281474976710655
  %statepoint_token143 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r327133, i64 %r468, i32 0, i32 0)
  %r469144 = call double @llvm.experimental.gc.result.f64(token %statepoint_token143)
  br label %pget.recv_merge.35

arena_state.init.62:                              ; preds = %pget.recv_merge.35
  %r485 = load atomic i64, ptr @PERRY_HOT_TSD_KEY monotonic, align 8
  %r486 = icmp ne i64 %r485, -1
  br i1 %r486, label %arena_state.hot_tls.tsd.64, label %arena_state.hot_tls.slow.66

arena_state.ready.63:                             ; preds = %arena_state.hot_tls.resolved.68
  %r501 = getelementptr i8, ptr %r499, i64 8
  %r502 = load i64, ptr %r501, align 8
  %r503 = add i64 %r502, 64
  %r504 = getelementptr i8, ptr %r499, i64 16
  %r505 = load i64, ptr %r504, align 8
  %r506 = icmp ule i64 %r503, %r505
  br i1 %r506, label %arrlit.fast.69, label %arrlit.slow.70

arena_state.hot_tls.tsd.64:                       ; preds = %arena_state.init.62
  %r487 = call i64 asm sideeffect "mrs $0, tpidrro_el0", "=r"() #9
  %r488 = and i64 %r487, -8
  %r489 = shl i64 %r485, 3
  %r490 = add i64 %r488, %r489
  %r491 = inttoptr i64 %r490 to ptr
  %r492 = load ptr, ptr %r491, align 8
  %r493 = icmp ne ptr %r492, null
  br i1 %r493, label %arena_state.hot_tls.fast.65, label %arena_state.hot_tls.slow.66

arena_state.hot_tls.fast.65:                      ; preds = %arena_state.hot_tls.tsd.64
  %r494 = getelementptr i8, ptr %r492, i64 8
  %r495 = load ptr, ptr %r494, align 8
  %r496 = load ptr, ptr %r495, align 8
  %r497 = icmp ne ptr %r496, null
  br i1 %r497, label %arena_state.hot_tls.ready.67, label %arena_state.hot_tls.slow.66

arena_state.hot_tls.slow.66:                      ; preds = %arena_state.hot_tls.fast.65, %arena_state.hot_tls.tsd.64, %arena_state.init.62
  %statepoint_token145 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr ()) @js_inline_arena_state, i32 0, i32 0, i32 0, i32 0)
  %r498146 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token145)
  br label %arena_state.hot_tls.resolved.68

arena_state.hot_tls.ready.67:                     ; preds = %arena_state.hot_tls.fast.65
  br label %arena_state.hot_tls.resolved.68

arena_state.hot_tls.resolved.68:                  ; preds = %arena_state.hot_tls.ready.67, %arena_state.hot_tls.slow.66
  %r499 = phi ptr [ %r495, %arena_state.hot_tls.ready.67 ], [ %r498146, %arena_state.hot_tls.slow.66 ]
  br label %arena_state.ready.63

arrlit.fast.69:                                   ; preds = %arena_state.ready.63
  store i64 %r503, ptr %r501, align 8
  %r507 = load ptr, ptr %r499, align 8
  %r508 = getelementptr i8, ptr %r507, i64 %r502
  br label %arrlit.merge.71

arrlit.slow.70:                                   ; preds = %arena_state.ready.63
  %statepoint_token147 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr (ptr, i64, i64)) @js_inline_arena_slow_alloc, i32 3, i32 0, ptr %r499, i64 64, i64 8, i32 0, i32 0)
  %r509148 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token147)
  br label %arrlit.merge.71

arrlit.merge.71:                                  ; preds = %arrlit.slow.70, %arrlit.fast.69
  %r510 = phi ptr [ %r508, %arrlit.fast.69 ], [ %r509148, %arrlit.slow.70 ]
  store i64 275951649281, ptr %r510, align 8
  %r511 = getelementptr i8, ptr %r510, i64 8
  store i64 25769803782, ptr %r511, align 8
  %r512 = getelementptr i8, ptr %r510, i64 8
  %r513 = ptrtoint ptr %r512 to i64
  %r514 = getelementptr inbounds nuw i8, ptr %r510, i64 16
  %r1789 = load double, ptr @options_worker_ts_.str.11.handle, align 8
  store double %r1789, ptr %r514, align 8
  %r1788 = load double, ptr @options_worker_ts_.str.11.handle, align 8
  call void @js_string_addref_if_heap_string(double %r1788) #9
  %r1787 = load double, ptr @options_worker_ts_.str.11.handle, align 8
  %r515 = bitcast double %r1787 to i64
  %r1785 = load double, ptr @options_worker_ts_.str.11.handle, align 8
  %r1786 = bitcast double %r1785 to i64
  call void @js_gc_note_slot_layout(i64 %r513, i32 0, i64 %r1786) #9
  %r516 = getelementptr inbounds nuw i8, ptr %r510, i64 24
  %r1784 = load double, ptr @options_worker_ts_.str.12.handle, align 8
  store double %r1784, ptr %r516, align 8
  %r1783 = load double, ptr @options_worker_ts_.str.12.handle, align 8
  call void @js_string_addref_if_heap_string(double %r1783) #9
  %r1782 = load double, ptr @options_worker_ts_.str.12.handle, align 8
  %r517 = bitcast double %r1782 to i64
  %r1780 = load double, ptr @options_worker_ts_.str.12.handle, align 8
  %r1781 = bitcast double %r1780 to i64
  call void @js_gc_note_slot_layout(i64 %r513, i32 1, i64 %r1781) #9
  %r518 = getelementptr inbounds nuw i8, ptr %r510, i64 32
  %r1779 = load double, ptr @options_worker_ts_.str.13.handle, align 8
  store double %r1779, ptr %r518, align 8
  %r1778 = load double, ptr @options_worker_ts_.str.13.handle, align 8
  call void @js_string_addref_if_heap_string(double %r1778) #9
  %r1777 = load double, ptr @options_worker_ts_.str.13.handle, align 8
  %r519 = bitcast double %r1777 to i64
  %r1775 = load double, ptr @options_worker_ts_.str.13.handle, align 8
  %r1776 = bitcast double %r1775 to i64
  call void @js_gc_note_slot_layout(i64 %r513, i32 2, i64 %r1776) #9
  %r520 = getelementptr inbounds nuw i8, ptr %r510, i64 40
  %r1774 = load double, ptr @options_worker_ts_.str.14.handle, align 8
  store double %r1774, ptr %r520, align 8
  %r1773 = load double, ptr @options_worker_ts_.str.14.handle, align 8
  call void @js_string_addref_if_heap_string(double %r1773) #9
  %r1772 = load double, ptr @options_worker_ts_.str.14.handle, align 8
  %r521 = bitcast double %r1772 to i64
  %r1770 = load double, ptr @options_worker_ts_.str.14.handle, align 8
  %r1771 = bitcast double %r1770 to i64
  call void @js_gc_note_slot_layout(i64 %r513, i32 3, i64 %r1771) #9
  %r522 = getelementptr inbounds nuw i8, ptr %r510, i64 48
  %r1769 = load double, ptr @options_worker_ts_.str.15.handle, align 8
  store double %r1769, ptr %r522, align 8
  %r1768 = load double, ptr @options_worker_ts_.str.15.handle, align 8
  call void @js_string_addref_if_heap_string(double %r1768) #9
  %r1767 = load double, ptr @options_worker_ts_.str.15.handle, align 8
  %r523 = bitcast double %r1767 to i64
  %r1765 = load double, ptr @options_worker_ts_.str.15.handle, align 8
  %r1766 = bitcast double %r1765 to i64
  call void @js_gc_note_slot_layout(i64 %r513, i32 4, i64 %r1766) #9
  %r524 = getelementptr inbounds nuw i8, ptr %r510, i64 56
  %r1764 = load double, ptr @options_worker_ts_.str.16.handle, align 8
  store double %r1764, ptr %r524, align 8
  %r1763 = load double, ptr @options_worker_ts_.str.16.handle, align 8
  call void @js_string_addref_if_heap_string(double %r1763) #9
  %r1762 = load double, ptr @options_worker_ts_.str.16.handle, align 8
  %r525 = bitcast double %r1762 to i64
  %r1760 = load double, ptr @options_worker_ts_.str.16.handle, align 8
  %r1761 = bitcast double %r1760 to i64
  call void @js_gc_note_slot_layout(i64 %r513, i32 5, i64 %r1761) #9
  %r526 = or i64 %r513, 9222527611924643840
  %r527 = bitcast i64 %r526 to double
  store double %r527, ptr @perry_global_options_worker_ts__5, align 8
  call void @js_write_barrier_root_nanbox(i64 %r526) #9
  store double 0x7FFC000000000002, ptr @perry_global_options_worker_ts__6, align 8
  call void @js_write_barrier_root_nanbox(i64 9222246136947933186) #9
  %statepoint_token149 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @"perry_fn_options_worker_ts__run$spec_b", i32 1, i32 0, double %r314126, i32 0, i32 0)
  %r531150 = call double @llvm.experimental.gc.result.f64(token %statepoint_token149)
  %rs4gc.b7 = bitcast double %r531150 to i64
  %rs4gc.s7 = inttoptr i64 %rs4gc.b7 to ptr addrspace(1)
  %r532.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7 to i64
  %r532 = call i64 asm "", "=r,0"(i64 %r532.rs4i) #9
  %r533 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r534 = icmp ne i32 %r533, 0
  br i1 %r534, label %shadow.root.barrier.72, label %shadow.root.barrier.done.73

shadow.root.barrier.72:                           ; preds = %arrlit.merge.71
  call void @js_write_barrier_root_nanbox(i64 %r532) #9
  br label %shadow.root.barrier.done.73

shadow.root.barrier.done.73:                      ; preds = %shadow.root.barrier.72, %arrlit.merge.71
  %statepoint_token151 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_process_memory_usage, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7) ]
  %r536152 = call double @llvm.experimental.gc.result.f64(token %statepoint_token151)
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token151, i32 0, i32 0) ; (%rs4gc.s7, %rs4gc.s7)
  %r537 = bitcast double %r536152 to i64
  %r538 = and i64 %r537, 281474976710655
  %r539 = lshr i64 %r537, 48
  %r540 = and i64 %r539, 65533
  %r541 = icmp eq i64 %r540, 32765
  br i1 %r541, label %pget.recv_ok.75, label %pget.recv_other.79

pget.recv_sso.74:                                 ; preds = %pget.recv_other.79
  %r679 = load double, ptr @options_worker_ts_.str.17.handle, align 8
  %r680 = bitcast double %r679 to i64
  %r681 = and i64 %r680, 281474976710655
  %statepoint_token153 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r537, i64 %r681, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated) ]
  %r682154 = call double @llvm.experimental.gc.result.f64(token %statepoint_token153)
  %rs4gc.s7.relocated155 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token153, i32 0, i32 0) ; (%rs4gc.s7.relocated, %rs4gc.s7.relocated)
  br label %pget.recv_merge.78

pget.recv_ok.75:                                  ; preds = %shadow.root.barrier.done.73
  %r548 = icmp ugt i64 %r538, 1048575
  br i1 %r548, label %pic.recv_hdr.96, label %pic.miss.cold.93

pget.recv_bad.76:                                 ; preds = %pget.check_class_ref.80
  %r671 = icmp eq i64 %r537, 9222246136947933185
  %r672 = icmp eq i64 %r537, 9222246136947933186
  %r673 = or i1 %r671, %r672
  br i1 %r673, label %pget.throw_nullish.103, label %pget.recv_undef_return.104

pget.recv_class_ref.77:                           ; preds = %pget.check_class_ref.80
  %r544 = load double, ptr @options_worker_ts_.str.17.handle, align 8
  %r545 = bitcast double %r544 to i64
  %r546 = and i64 %r545, 281474976710655
  %statepoint_token156 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532886, i64 %r537, i64 %r546, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated) ]
  %r547157 = call double @llvm.experimental.gc.result.f64(token %statepoint_token156)
  %rs4gc.s7.relocated158 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token156, i32 0, i32 0) ; (%rs4gc.s7.relocated, %rs4gc.s7.relocated)
  br label %pget.recv_merge.78

pget.recv_merge.78:                               ; preds = %pget.recv_undef_return.104, %pic.merge.95, %pget.recv_class_ref.77, %pget.recv_sso.74
  %.0473 = phi ptr addrspace(1) [ %.1474, %pic.merge.95 ], [ %rs4gc.s7.relocated155, %pget.recv_sso.74 ], [ %rs4gc.s7.relocated158, %pget.recv_class_ref.77 ], [ %rs4gc.s7.relocated168, %pget.recv_undef_return.104 ]
  %r683 = phi double [ %r670, %pic.merge.95 ], [ %r678167, %pget.recv_undef_return.104 ], [ %r682154, %pget.recv_sso.74 ], [ %r547157, %pget.recv_class_ref.77 ]
  %rs4gc.b8 = bitcast double %r683 to i64
  %rs4gc.s8 = inttoptr i64 %rs4gc.b8 to ptr addrspace(1)
  %r684.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r684 = call i64 asm "", "=r,0"(i64 %r684.rs4i) #9
  %r685 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r686 = icmp ne i32 %r685, 0
  br i1 %r686, label %shadow.root.barrier.105, label %shadow.root.barrier.done.106

pget.recv_other.79:                               ; preds = %shadow.root.barrier.done.73
  %r542 = icmp eq i64 %r539, 32761
  br i1 %r542, label %pget.recv_sso.74, label %pget.check_class_ref.80

pget.check_class_ref.80:                          ; preds = %pget.recv_other.79
  %r543 = icmp eq i64 %r539, 32766
  br i1 %r543, label %pget.recv_class_ref.77, label %pget.recv_bad.76

pic.hit.81:                                       ; preds = %pic.token.97
  %r573 = getelementptr i64, ptr %r558, i64 1
  %r574 = load i64, ptr %r573, align 8
  %r575 = and i64 %r574, 1073741824
  %r576 = icmp ne i64 %r575, 0
  br i1 %r576, label %pic.hit.overflow.98, label %pic.hit.inline.99

pic.hit.live.82:                                  ; preds = %pic.hit.inline.99
  br label %pic.merge.95

pic.prefix.guard.83:                              ; preds = %pic.token.97
  %r589 = getelementptr i64, ptr %r558, i64 2
  %r590 = load i64, ptr %r589, align 8
  %r591 = icmp ne i64 %r590, 0
  br i1 %r591, label %pic.prefix.meta.84, label %pic.miss.92

pic.prefix.meta.84:                               ; preds = %pic.prefix.guard.83
  %r592 = add nuw nsw i64 %r538, 8
  %r593 = inttoptr i64 %r592 to ptr
  %r594 = load i64, ptr %r593, align 8
  %r595 = icmp ne i64 %r594, 0
  br i1 %r595, label %pic.prefix.token.85, label %pic.miss.92

pic.prefix.token.85:                              ; preds = %pic.prefix.meta.84
  %r596 = inttoptr i64 %r594 to ptr
  %r597 = getelementptr i64, ptr %r596, i64 6
  %r598 = load i64, ptr %r597, align 8
  %r599 = icmp eq i64 %r598, %r590
  br i1 %r599, label %pic.prefix.hit.86, label %pic.miss.92

pic.prefix.hit.86:                                ; preds = %pic.prefix.token.85
  %r600 = getelementptr i64, ptr %r558, i64 1
  %r601 = load i64, ptr %r600, align 8
  %r602 = shl i64 %r601, 3
  %r603 = add nuw nsw i64 %r538, 16
  %r604 = add i64 %r603, %r602
  %r605 = inttoptr i64 %r604 to ptr
  %r606 = load double, ptr %r605, align 8
  br label %pic.merge.95

pic.desc.classify.87:                             ; preds = %pic.recv_hdr.96
  %r562 = and i1 %r552, %r559
  br i1 %r562, label %pic.desc.prefix.guard.88, label %pic.miss.cold.93

pic.desc.prefix.guard.88:                         ; preds = %pic.desc.classify.87
  %r607 = getelementptr i64, ptr %r558, i64 2
  %r608 = load i64, ptr %r607, align 8
  %r609 = icmp ne i64 %r608, 0
  br i1 %r609, label %pic.desc.prefix.meta.89, label %pic.miss.cold.93

pic.desc.prefix.meta.89:                          ; preds = %pic.desc.prefix.guard.88
  %r610 = add nuw nsw i64 %r538, 8
  %r611 = inttoptr i64 %r610 to ptr
  %r612 = load i64, ptr %r611, align 8
  %r613 = icmp ne i64 %r612, 0
  br i1 %r613, label %pic.desc.prefix.token.90, label %pic.miss.cold.93

pic.desc.prefix.token.90:                         ; preds = %pic.desc.prefix.meta.89
  %r614 = inttoptr i64 %r612 to ptr
  %r615 = getelementptr i64, ptr %r614, i64 6
  %r616 = load i64, ptr %r615, align 8
  %r617 = icmp eq i64 %r616, %r608
  br i1 %r617, label %pic.desc.prefix.hit.91, label %pic.miss.cold.93

pic.desc.prefix.hit.91:                           ; preds = %pic.desc.prefix.token.90
  %r618 = getelementptr i64, ptr %r558, i64 1
  %r619 = load i64, ptr %r618, align 8
  %r620 = shl i64 %r619, 3
  %r621 = add nuw nsw i64 %r538, 16
  %r622 = add i64 %r621, %r620
  %r623 = inttoptr i64 %r622 to ptr
  %r624 = load double, ptr %r623, align 8
  br label %pic.merge.95

pic.miss.92:                                      ; preds = %pic.hit.inline.99, %pic.prefix.token.85, %pic.prefix.meta.84, %pic.prefix.guard.83
  %r625 = getelementptr i64, ptr %r558, i64 3
  %r626 = load i64, ptr %r625, align 8
  %r627 = icmp sgt i64 %r626, 0
  br i1 %r627, label %pic.ways.100, label %pic.miss.call.94

pic.miss.cold.93:                                 ; preds = %pic.desc.prefix.token.90, %pic.desc.prefix.meta.89, %pic.desc.prefix.guard.88, %pic.desc.classify.87, %pget.recv_ok.75
  br label %pic.miss.call.94

pic.miss.call.94:                                 ; preds = %pic.way.load.101, %pic.ways.100, %pic.miss.cold.93, %pic.miss.92
  %r666 = load double, ptr @options_worker_ts_.str.17.handle, align 8
  %r667 = bitcast double %r666 to i64
  %r668 = and i64 %r667, 281474976710655
  %statepoint_token159 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r538, i64 %r668, ptr @perry_ic_options_worker_ts__23, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated) ]
  %r669160 = call double @llvm.experimental.gc.result.f64(token %statepoint_token159)
  %rs4gc.s7.relocated161 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token159, i32 0, i32 0) ; (%rs4gc.s7.relocated, %rs4gc.s7.relocated)
  br label %pic.merge.95

pic.merge.95:                                     ; preds = %pic.way.live.102, %pic.hit.overflow.98, %pic.miss.call.94, %pic.desc.prefix.hit.91, %pic.prefix.hit.86, %pic.hit.live.82
  %.1474 = phi ptr addrspace(1) [ %rs4gc.s7.relocated164, %pic.hit.overflow.98 ], [ %rs4gc.s7.relocated161, %pic.miss.call.94 ], [ %rs4gc.s7.relocated, %pic.way.live.102 ], [ %rs4gc.s7.relocated, %pic.hit.live.82 ], [ %rs4gc.s7.relocated, %pic.prefix.hit.86 ], [ %rs4gc.s7.relocated, %pic.desc.prefix.hit.91 ]
  %r670 = phi double [ %r586, %pic.hit.live.82 ], [ %r581163, %pic.hit.overflow.98 ], [ %r606, %pic.prefix.hit.86 ], [ %r624, %pic.desc.prefix.hit.91 ], [ %r663, %pic.way.live.102 ], [ %r669160, %pic.miss.call.94 ]
  br label %pget.recv_merge.78

pic.recv_hdr.96:                                  ; preds = %pget.recv_ok.75
  %r549 = sub nuw nsw i64 %r538, 8
  %r550 = inttoptr i64 %r549 to ptr
  %r551 = load i8, ptr %r550, align 1
  %r552 = icmp eq i8 %r551, 2
  %r553 = sub nuw nsw i64 %r538, 6
  %r554 = inttoptr i64 %r553 to ptr
  %r555 = load i16, ptr %r554, align 2
  %r556 = and i16 %r555, 2048
  %r557 = icmp eq i16 %r556, 0
  %r558 = load ptr, ptr @perry_ic_options_worker_ts__23, align 8
  %r559 = icmp ne ptr %r558, null
  %r560 = and i1 %r552, %r557
  %r561 = and i1 %r560, %r559
  br i1 %r561, label %pic.token.97, label %pic.desc.classify.87

pic.token.97:                                     ; preds = %pic.recv_hdr.96
  %r563 = add nuw nsw i64 %r538, 4
  %r564 = inttoptr i64 %r563 to ptr
  %r565 = load i32, ptr %r564, align 4
  %r566 = zext i32 %r565 to i64
  %r567 = or i64 %r566, 4611686018427387904
  %r568 = icmp ne i32 %r565, 0
  %r569 = getelementptr i64, ptr %r558, i64 0
  %r570 = load i64, ptr %r569, align 8
  %r571 = icmp eq i64 %r567, %r570
  %r572 = and i1 %r571, %r568
  br i1 %r572, label %pic.hit.81, label %pic.prefix.guard.83

pic.hit.overflow.98:                              ; preds = %pic.hit.81
  %r577 = load double, ptr @options_worker_ts_.str.17.handle, align 8
  %r578 = bitcast double %r577 to i64
  %r579 = and i64 %r578, 281474976710655
  %r580 = trunc i64 %r574 to i32
  %statepoint_token162 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r538, i64 %r579, i32 %r580, ptr @perry_ic_options_worker_ts__23, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated) ]
  %r581163 = call double @llvm.experimental.gc.result.f64(token %statepoint_token162)
  %rs4gc.s7.relocated164 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token162, i32 0, i32 0) ; (%rs4gc.s7.relocated, %rs4gc.s7.relocated)
  br label %pic.merge.95

pic.hit.inline.99:                                ; preds = %pic.hit.81
  %r582 = shl i64 %r574, 3
  %r583 = add nuw nsw i64 %r538, 16
  %r584 = add i64 %r583, %r582
  %r585 = inttoptr i64 %r584 to ptr
  %r586 = load double, ptr %r585, align 8
  %r587 = bitcast double %r586 to i64
  %r588 = icmp eq i64 %r587, 9222246136947933200
  br i1 %r588, label %pic.miss.92, label %pic.hit.live.82

pic.ways.100:                                     ; preds = %pic.miss.92
  %r628 = getelementptr i64, ptr %r558, i64 4
  %r629 = load i64, ptr %r628, align 8
  %r630 = icmp eq i64 %r629, %r567
  %r631 = getelementptr i64, ptr %r558, i64 5
  %r632 = load i64, ptr %r631, align 8
  %r633 = select i1 %r630, i64 %r632, i64 0
  %r634 = getelementptr i64, ptr %r558, i64 6
  %r635 = load i64, ptr %r634, align 8
  %r636 = icmp eq i64 %r635, %r567
  %r637 = getelementptr i64, ptr %r558, i64 7
  %r638 = load i64, ptr %r637, align 8
  %r639 = select i1 %r636, i64 %r638, i64 0
  %r640 = getelementptr i64, ptr %r558, i64 8
  %r641 = load i64, ptr %r640, align 8
  %r642 = icmp eq i64 %r641, %r567
  %r643 = getelementptr i64, ptr %r558, i64 9
  %r644 = load i64, ptr %r643, align 8
  %r645 = select i1 %r642, i64 %r644, i64 0
  %r646 = getelementptr i64, ptr %r558, i64 10
  %r647 = load i64, ptr %r646, align 8
  %r648 = icmp eq i64 %r647, %r567
  %r649 = getelementptr i64, ptr %r558, i64 11
  %r650 = load i64, ptr %r649, align 8
  %r651 = select i1 %r648, i64 %r650, i64 0
  %r652 = or i1 %r630, %r636
  %r653 = select i1 %r630, i64 %r633, i64 %r639
  %r654 = or i1 %r642, %r648
  %r655 = select i1 %r642, i64 %r645, i64 %r651
  %r656 = or i1 %r652, %r654
  %r657 = select i1 %r652, i64 %r653, i64 %r655
  %r658 = and i1 %r568, %r656
  br i1 %r658, label %pic.way.load.101, label %pic.miss.call.94

pic.way.load.101:                                 ; preds = %pic.ways.100
  %r659 = shl i64 %r657, 3
  %r660 = add nuw nsw i64 %r538, 16
  %r661 = add i64 %r660, %r659
  %r662 = inttoptr i64 %r661 to ptr
  %r663 = load double, ptr %r662, align 8
  %r664 = bitcast double %r663 to i64
  %r665 = icmp eq i64 %r664, 9222246136947933200
  br i1 %r665, label %pic.miss.call.94, label %pic.way.live.102

pic.way.live.102:                                 ; preds = %pic.way.load.101
  br label %pic.merge.95

pget.throw_nullish.103:                           ; preds = %pget.recv_bad.76
  %r674 = zext i1 %r672 to i32
  %statepoint_token165 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r674, ptr @options_worker_ts_.str.17.bytes, i64 3, i32 0, i32 0)
  unreachable

pget.recv_undef_return.104:                       ; preds = %pget.recv_bad.76
  %r675 = load double, ptr @options_worker_ts_.str.17.handle, align 8
  %r676 = bitcast double %r675 to i64
  %r677 = and i64 %r676, 281474976710655
  %statepoint_token166 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r537, i64 %r677, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated) ]
  %r678167 = call double @llvm.experimental.gc.result.f64(token %statepoint_token166)
  %rs4gc.s7.relocated168 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token166, i32 0, i32 0) ; (%rs4gc.s7.relocated, %rs4gc.s7.relocated)
  br label %pget.recv_merge.78

shadow.root.barrier.105:                          ; preds = %pget.recv_merge.78
  call void @js_write_barrier_root_nanbox(i64 %r684) #9
  br label %shadow.root.barrier.done.106

shadow.root.barrier.done.106:                     ; preds = %shadow.root.barrier.105, %pget.recv_merge.78
  %statepoint_token169 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_process_cpu_usage, i32 1, i32 0, double 0x7FFC000000000001, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0473, ptr addrspace(1) %rs4gc.s8) ]
  %r688170 = call double @llvm.experimental.gc.result.f64(token %statepoint_token169)
  %rs4gc.s7.relocated171 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 0, i32 0) ; (%.0473, %.0473)
  %rs4gc.s8.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.b9 = bitcast double %r688170 to i64
  %rs4gc.s9 = inttoptr i64 %rs4gc.b9 to ptr addrspace(1)
  %r689.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9 to i64
  %r689 = call i64 asm "", "=r,0"(i64 %r689.rs4i) #9
  %r690 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r691 = icmp ne i32 %r690, 0
  br i1 %r691, label %shadow.root.barrier.107, label %shadow.root.barrier.done.108

shadow.root.barrier.107:                          ; preds = %shadow.root.barrier.done.106
  call void @js_write_barrier_root_nanbox(i64 %r689) #9
  br label %shadow.root.barrier.done.108

shadow.root.barrier.done.108:                     ; preds = %shadow.root.barrier.107, %shadow.root.barrier.done.106
  %statepoint_token172 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_performance_now, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated, ptr addrspace(1) %rs4gc.s9, ptr addrspace(1) %rs4gc.s7.relocated171) ]
  %r693173 = call double @llvm.experimental.gc.result.f64(token %statepoint_token172)
  %rs4gc.s8.relocated174 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token172, i32 0, i32 0) ; (%rs4gc.s8.relocated, %rs4gc.s8.relocated)
  %rs4gc.s9.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token172, i32 1, i32 1) ; (%rs4gc.s9, %rs4gc.s9)
  %rs4gc.s7.relocated175 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token172, i32 2, i32 2) ; (%rs4gc.s7.relocated171, %rs4gc.s7.relocated171)
  %r694.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7.relocated175 to i64
  %r694.rs4o = call i64 asm "", "=r,0"(i64 %r694.rs4i) #9
  %r694 = bitcast i64 %r694.rs4o to double
  %r695 = bitcast double %r694 to i64
  %rs4gc.s10 = inttoptr i64 %r695 to ptr addrspace(1)
  %r697.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r697 = call i64 asm "", "=r,0"(i64 %r697.rs4i) #9
  %r698 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r699 = icmp ne i32 %r698, 0
  br i1 %r699, label %shadow.root.barrier.109, label %shadow.root.barrier.done.110

shadow.root.barrier.109:                          ; preds = %shadow.root.barrier.done.108
  call void @js_write_barrier_root_nanbox(i64 %r697) #9
  br label %shadow.root.barrier.done.110

shadow.root.barrier.done.110:                     ; preds = %shadow.root.barrier.109, %shadow.root.barrier.done.108
  %statepoint_token176 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @"perry_fn_options_worker_ts__run$spec_b", i32 1, i32 0, double %r238117, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated174, ptr addrspace(1) %rs4gc.s9.relocated, ptr addrspace(1) %rs4gc.s10) ]
  %r701177 = call double @llvm.experimental.gc.result.f64(token %statepoint_token176)
  %rs4gc.s8.relocated178 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token176, i32 0, i32 0) ; (%rs4gc.s8.relocated174, %rs4gc.s8.relocated174)
  %rs4gc.s9.relocated179 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token176, i32 1, i32 1) ; (%rs4gc.s9.relocated, %rs4gc.s9.relocated)
  %rs4gc.s10.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token176, i32 2, i32 2) ; (%rs4gc.s10, %rs4gc.s10)
  %r702.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10.relocated to i64
  %r702 = call i64 asm "", "=r,0"(i64 %r702.rs4i) #9
  %r703 = bitcast i64 %r702 to double
  %r704 = and i64 %r702, -281474976710656
  %r705 = icmp ult i64 %r704, 9221401712017801216
  %r706 = icmp ugt i64 %r704, 9223090561878065152
  %r707 = or i1 %r705, %r706
  %r708 = bitcast double %r701177 to i64
  %r709 = and i64 %r708, -281474976710656
  %r710 = icmp ult i64 %r709, 9221401712017801216
  %r711 = icmp ugt i64 %r709, 9223090561878065152
  %r712 = or i1 %r710, %r711
  %r713 = and i1 %r707, %r712
  br i1 %r713, label %guarded_add.numeric.111, label %guarded_add.dynamic.112

guarded_add.numeric.111:                          ; preds = %shadow.root.barrier.done.110
  %r714 = fadd double %r703, %r701177
  br label %guarded_add.merge.113

guarded_add.dynamic.112:                          ; preds = %shadow.root.barrier.done.110
  %statepoint_token180 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r703, double %r701177, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated178, ptr addrspace(1) %rs4gc.s9.relocated179) ]
  %r715181 = call double @llvm.experimental.gc.result.f64(token %statepoint_token180)
  %rs4gc.s8.relocated182 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token180, i32 0, i32 0) ; (%rs4gc.s8.relocated178, %rs4gc.s8.relocated178)
  %rs4gc.s9.relocated183 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token180, i32 1, i32 1) ; (%rs4gc.s9.relocated179, %rs4gc.s9.relocated179)
  br label %guarded_add.merge.113

guarded_add.merge.113:                            ; preds = %guarded_add.dynamic.112, %guarded_add.numeric.111
  %.0478 = phi ptr addrspace(1) [ %rs4gc.s9.relocated179, %guarded_add.numeric.111 ], [ %rs4gc.s9.relocated183, %guarded_add.dynamic.112 ]
  %.0475 = phi ptr addrspace(1) [ %rs4gc.s8.relocated178, %guarded_add.numeric.111 ], [ %rs4gc.s8.relocated182, %guarded_add.dynamic.112 ]
  %r716 = phi double [ %r714, %guarded_add.numeric.111 ], [ %r715181, %guarded_add.dynamic.112 ]
  %rs4gc.b11 = bitcast double %r716 to i64
  %rs4gc.s11 = inttoptr i64 %rs4gc.b11 to ptr addrspace(1)
  %r717.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s11 to i64
  %r717 = call i64 asm "", "=r,0"(i64 %r717.rs4i) #9
  %r718 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r719 = icmp ne i32 %r718, 0
  br i1 %r719, label %shadow.root.barrier.114, label %shadow.root.barrier.done.115

shadow.root.barrier.114:                          ; preds = %guarded_add.merge.113
  call void @js_write_barrier_root_nanbox(i64 %r717) #9
  br label %shadow.root.barrier.done.115

shadow.root.barrier.done.115:                     ; preds = %shadow.root.barrier.114, %guarded_add.merge.113
  %statepoint_token184 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_performance_now, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11, ptr addrspace(1) %.0475, ptr addrspace(1) %.0478) ]
  %r721185 = call double @llvm.experimental.gc.result.f64(token %statepoint_token184)
  %rs4gc.s11.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token184, i32 0, i32 0) ; (%rs4gc.s11, %rs4gc.s11)
  %rs4gc.s8.relocated186 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token184, i32 1, i32 1) ; (%.0475, %.0475)
  %rs4gc.s9.relocated187 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token184, i32 2, i32 2) ; (%.0478, %.0478)
  %r723 = bitcast double %r721185 to i64
  %r724 = and i64 %r723, -281474976710656
  %r725 = icmp ult i64 %r724, 9221401712017801216
  %r726 = icmp ugt i64 %r724, 9223090561878065152
  %r727 = or i1 %r725, %r726
  %r728 = bitcast double %r693173 to i64
  %r729 = and i64 %r728, -281474976710656
  %r730 = icmp ult i64 %r729, 9221401712017801216
  %r731 = icmp ugt i64 %r729, 9223090561878065152
  %r732 = or i1 %r730, %r731
  %r733 = and i1 %r727, %r732
  br i1 %r733, label %guarded_arith.numeric.116, label %guarded_arith.dynamic.117

guarded_arith.numeric.116:                        ; preds = %shadow.root.barrier.done.115
  %r734 = fsub double %r721185, %r693173
  br label %guarded_arith.merge.118

guarded_arith.dynamic.117:                        ; preds = %shadow.root.barrier.done.115
  %statepoint_token188 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_sub, i32 2, i32 0, double %r721185, double %r693173, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated, ptr addrspace(1) %rs4gc.s8.relocated186, ptr addrspace(1) %rs4gc.s9.relocated187) ]
  %r735189 = call double @llvm.experimental.gc.result.f64(token %statepoint_token188)
  %rs4gc.s11.relocated190 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token188, i32 0, i32 0) ; (%rs4gc.s11.relocated, %rs4gc.s11.relocated)
  %rs4gc.s8.relocated191 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token188, i32 1, i32 1) ; (%rs4gc.s8.relocated186, %rs4gc.s8.relocated186)
  %rs4gc.s9.relocated192 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token188, i32 2, i32 2) ; (%rs4gc.s9.relocated187, %rs4gc.s9.relocated187)
  br label %guarded_arith.merge.118

guarded_arith.merge.118:                          ; preds = %guarded_arith.dynamic.117, %guarded_arith.numeric.116
  %.0487 = phi ptr addrspace(1) [ %rs4gc.s11.relocated, %guarded_arith.numeric.116 ], [ %rs4gc.s11.relocated190, %guarded_arith.dynamic.117 ]
  %.1479 = phi ptr addrspace(1) [ %rs4gc.s9.relocated187, %guarded_arith.numeric.116 ], [ %rs4gc.s9.relocated192, %guarded_arith.dynamic.117 ]
  %.1476 = phi ptr addrspace(1) [ %rs4gc.s8.relocated186, %guarded_arith.numeric.116 ], [ %rs4gc.s8.relocated191, %guarded_arith.dynamic.117 ]
  %r736 = phi double [ %r734, %guarded_arith.numeric.116 ], [ %r735189, %guarded_arith.dynamic.117 ]
  %statepoint_token193 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_process_cpu_usage, i32 1, i32 0, double 0x7FFC000000000001, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0487, ptr addrspace(1) %.1476, ptr addrspace(1) %.1479) ]
  %r738194 = call double @llvm.experimental.gc.result.f64(token %statepoint_token193)
  %rs4gc.s11.relocated195 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token193, i32 0, i32 0) ; (%.0487, %.0487)
  %rs4gc.s8.relocated196 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token193, i32 1, i32 1) ; (%.1476, %.1476)
  %rs4gc.s9.relocated197 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token193, i32 2, i32 2) ; (%.1479, %.1479)
  %rs4gc.b12 = bitcast double %r738194 to i64
  %rs4gc.s12 = inttoptr i64 %rs4gc.b12 to ptr addrspace(1)
  %r739.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12 to i64
  %r739 = call i64 asm "", "=r,0"(i64 %r739.rs4i) #9
  %r740 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r741 = icmp ne i32 %r740, 0
  br i1 %r741, label %shadow.root.barrier.119, label %shadow.root.barrier.done.120

shadow.root.barrier.119:                          ; preds = %guarded_arith.merge.118
  call void @js_write_barrier_root_nanbox(i64 %r739) #9
  br label %shadow.root.barrier.done.120

shadow.root.barrier.done.120:                     ; preds = %shadow.root.barrier.119, %guarded_arith.merge.118
  %statepoint_token198 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated195, ptr addrspace(1) %rs4gc.s8.relocated196, ptr addrspace(1) %rs4gc.s9.relocated197, ptr addrspace(1) %rs4gc.s12) ]
  %r742199 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token198)
  %rs4gc.s11.relocated200 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token198, i32 0, i32 0) ; (%rs4gc.s11.relocated195, %rs4gc.s11.relocated195)
  %rs4gc.s8.relocated201 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token198, i32 1, i32 1) ; (%rs4gc.s8.relocated196, %rs4gc.s8.relocated196)
  %rs4gc.s9.relocated202 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token198, i32 2, i32 2) ; (%rs4gc.s9.relocated197, %rs4gc.s9.relocated197)
  %rs4gc.s12.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token198, i32 3, i32 3) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13 = inttoptr i64 %r742199 to ptr addrspace(1)
  %r743.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13 to i64
  %r743 = call i64 asm "", "=r,0"(i64 %r743.rs4i) #9
  %r744 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r745 = icmp ne i32 %r744, 0
  br i1 %r745, label %shadow.root.barrier.121, label %shadow.root.barrier.done.122

shadow.root.barrier.121:                          ; preds = %shadow.root.barrier.done.120
  call void @js_write_barrier_root_nanbox(i64 %r743) #9
  br label %shadow.root.barrier.done.122

shadow.root.barrier.done.122:                     ; preds = %shadow.root.barrier.121, %shadow.root.barrier.done.120
  %r746 = load double, ptr @options_worker_ts_.str.18.handle, align 8
  %r747.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13 to i64
  %r747 = call i64 asm "", "=r,0"(i64 %r747.rs4i) #9
  %statepoint_token203 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r747, double %r746, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated200, ptr addrspace(1) %rs4gc.s8.relocated201, ptr addrspace(1) %rs4gc.s9.relocated202, ptr addrspace(1) %rs4gc.s12.relocated) ]
  %r748204 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token203)
  %rs4gc.s11.relocated205 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 0, i32 0) ; (%rs4gc.s11.relocated200, %rs4gc.s11.relocated200)
  %rs4gc.s8.relocated206 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 1, i32 1) ; (%rs4gc.s8.relocated201, %rs4gc.s8.relocated201)
  %rs4gc.s9.relocated207 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 2, i32 2) ; (%rs4gc.s9.relocated202, %rs4gc.s9.relocated202)
  %rs4gc.s12.relocated208 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 3, i32 3) ; (%rs4gc.s12.relocated, %rs4gc.s12.relocated)
  %rs4gc.s14 = inttoptr i64 %r748204 to ptr addrspace(1)
  %r749.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r749 = call i64 asm "", "=r,0"(i64 %r749.rs4i) #9
  %r750 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r751 = icmp ne i32 %r750, 0
  br i1 %r751, label %shadow.root.barrier.123, label %shadow.root.barrier.done.124

shadow.root.barrier.123:                          ; preds = %shadow.root.barrier.done.122
  call void @js_write_barrier_root_nanbox(i64 %r749) #9
  br label %shadow.root.barrier.done.124

shadow.root.barrier.done.124:                     ; preds = %shadow.root.barrier.123, %shadow.root.barrier.done.122
  %r753.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r753 = call i64 asm "", "=r,0"(i64 %r753.rs4i) #9
  %statepoint_token209 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r753, double %r736, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated205, ptr addrspace(1) %rs4gc.s8.relocated206, ptr addrspace(1) %rs4gc.s9.relocated207, ptr addrspace(1) %rs4gc.s12.relocated208) ]
  %r754210 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token209)
  %rs4gc.s11.relocated211 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token209, i32 0, i32 0) ; (%rs4gc.s11.relocated205, %rs4gc.s11.relocated205)
  %rs4gc.s8.relocated212 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token209, i32 1, i32 1) ; (%rs4gc.s8.relocated206, %rs4gc.s8.relocated206)
  %rs4gc.s9.relocated213 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token209, i32 2, i32 2) ; (%rs4gc.s9.relocated207, %rs4gc.s9.relocated207)
  %rs4gc.s12.relocated214 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token209, i32 3, i32 3) ; (%rs4gc.s12.relocated208, %rs4gc.s12.relocated208)
  %rs4gc.s15 = inttoptr i64 %r754210 to ptr addrspace(1)
  %r755.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15 to i64
  %r755 = call i64 asm "", "=r,0"(i64 %r755.rs4i) #9
  %r756 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r757 = icmp ne i32 %r756, 0
  br i1 %r757, label %shadow.root.barrier.125, label %shadow.root.barrier.done.126

shadow.root.barrier.125:                          ; preds = %shadow.root.barrier.done.124
  call void @js_write_barrier_root_nanbox(i64 %r755) #9
  br label %shadow.root.barrier.done.126

shadow.root.barrier.done.126:                     ; preds = %shadow.root.barrier.125, %shadow.root.barrier.done.124
  %r758.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12.relocated214 to i64
  %r758.rs4o = call i64 asm "", "=r,0"(i64 %r758.rs4i) #9
  %r758 = bitcast i64 %r758.rs4o to double
  %r759 = bitcast double %r758 to i64
  %r760 = and i64 %r759, 281474976710655
  %r761 = lshr i64 %r759, 48
  %r762 = and i64 %r761, 65533
  %r763 = icmp eq i64 %r762, 32765
  br i1 %r763, label %pget.recv_ok.128, label %pget.recv_other.132

pget.recv_sso.127:                                ; preds = %pget.recv_other.132
  %r901 = load double, ptr @options_worker_ts_.str.19.handle, align 8
  %r902 = bitcast double %r901 to i64
  %r903 = and i64 %r902, 281474976710655
  %statepoint_token215 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r759, i64 %r903, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated211, ptr addrspace(1) %rs4gc.s8.relocated212, ptr addrspace(1) %rs4gc.s9.relocated213, ptr addrspace(1) %rs4gc.s12.relocated214, ptr addrspace(1) %rs4gc.s15) ]
  %r904216 = call double @llvm.experimental.gc.result.f64(token %statepoint_token215)
  %rs4gc.s11.relocated217 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token215, i32 0, i32 0) ; (%rs4gc.s11.relocated211, %rs4gc.s11.relocated211)
  %rs4gc.s8.relocated218 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token215, i32 1, i32 1) ; (%rs4gc.s8.relocated212, %rs4gc.s8.relocated212)
  %rs4gc.s9.relocated219 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token215, i32 2, i32 2) ; (%rs4gc.s9.relocated213, %rs4gc.s9.relocated213)
  %rs4gc.s12.relocated220 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token215, i32 3, i32 3) ; (%rs4gc.s12.relocated214, %rs4gc.s12.relocated214)
  %rs4gc.s15.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token215, i32 4, i32 4) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pget.recv_merge.131

pget.recv_ok.128:                                 ; preds = %shadow.root.barrier.done.126
  %r770 = icmp ugt i64 %r760, 1048575
  br i1 %r770, label %pic.recv_hdr.149, label %pic.miss.cold.146

pget.recv_bad.129:                                ; preds = %pget.check_class_ref.133
  %r893 = icmp eq i64 %r759, 9222246136947933185
  %r894 = icmp eq i64 %r759, 9222246136947933186
  %r895 = or i1 %r893, %r894
  br i1 %r895, label %pget.throw_nullish.156, label %pget.recv_undef_return.157

pget.recv_class_ref.130:                          ; preds = %pget.check_class_ref.133
  %r766 = load double, ptr @options_worker_ts_.str.19.handle, align 8
  %r767 = bitcast double %r766 to i64
  %r768 = and i64 %r767, 281474976710655
  %statepoint_token221 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532888, i64 %r759, i64 %r768, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated211, ptr addrspace(1) %rs4gc.s8.relocated212, ptr addrspace(1) %rs4gc.s9.relocated213, ptr addrspace(1) %rs4gc.s12.relocated214, ptr addrspace(1) %rs4gc.s15) ]
  %r769222 = call double @llvm.experimental.gc.result.f64(token %statepoint_token221)
  %rs4gc.s11.relocated223 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token221, i32 0, i32 0) ; (%rs4gc.s11.relocated211, %rs4gc.s11.relocated211)
  %rs4gc.s8.relocated224 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token221, i32 1, i32 1) ; (%rs4gc.s8.relocated212, %rs4gc.s8.relocated212)
  %rs4gc.s9.relocated225 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token221, i32 2, i32 2) ; (%rs4gc.s9.relocated213, %rs4gc.s9.relocated213)
  %rs4gc.s12.relocated226 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token221, i32 3, i32 3) ; (%rs4gc.s12.relocated214, %rs4gc.s12.relocated214)
  %rs4gc.s15.relocated227 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token221, i32 4, i32 4) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pget.recv_merge.131

pget.recv_merge.131:                              ; preds = %pget.recv_undef_return.157, %pic.merge.148, %pget.recv_class_ref.130, %pget.recv_sso.127
  %.0504 = phi ptr addrspace(1) [ %.1505, %pic.merge.148 ], [ %rs4gc.s15.relocated, %pget.recv_sso.127 ], [ %rs4gc.s15.relocated227, %pget.recv_class_ref.130 ], [ %rs4gc.s15.relocated249, %pget.recv_undef_return.157 ]
  %.0499 = phi ptr addrspace(1) [ %.1500, %pic.merge.148 ], [ %rs4gc.s12.relocated220, %pget.recv_sso.127 ], [ %rs4gc.s12.relocated226, %pget.recv_class_ref.130 ], [ %rs4gc.s12.relocated248, %pget.recv_undef_return.157 ]
  %.1488 = phi ptr addrspace(1) [ %.2489, %pic.merge.148 ], [ %rs4gc.s11.relocated217, %pget.recv_sso.127 ], [ %rs4gc.s11.relocated223, %pget.recv_class_ref.130 ], [ %rs4gc.s11.relocated245, %pget.recv_undef_return.157 ]
  %.2480 = phi ptr addrspace(1) [ %.3481, %pic.merge.148 ], [ %rs4gc.s9.relocated219, %pget.recv_sso.127 ], [ %rs4gc.s9.relocated225, %pget.recv_class_ref.130 ], [ %rs4gc.s9.relocated247, %pget.recv_undef_return.157 ]
  %.2477 = phi ptr addrspace(1) [ %.3, %pic.merge.148 ], [ %rs4gc.s8.relocated218, %pget.recv_sso.127 ], [ %rs4gc.s8.relocated224, %pget.recv_class_ref.130 ], [ %rs4gc.s8.relocated246, %pget.recv_undef_return.157 ]
  %r905 = phi double [ %r892, %pic.merge.148 ], [ %r900244, %pget.recv_undef_return.157 ], [ %r904216, %pget.recv_sso.127 ], [ %r769222, %pget.recv_class_ref.130 ]
  %r906 = bitcast double %r905 to i64
  %rs4gc.s16 = inttoptr i64 %r906 to ptr addrspace(1)
  %r908.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16 to i64
  %r908 = call i64 asm "", "=r,0"(i64 %r908.rs4i) #9
  %r909 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r910 = icmp ne i32 %r909, 0
  br i1 %r910, label %shadow.root.barrier.158, label %shadow.root.barrier.done.159

pget.recv_other.132:                              ; preds = %shadow.root.barrier.done.126
  %r764 = icmp eq i64 %r761, 32761
  br i1 %r764, label %pget.recv_sso.127, label %pget.check_class_ref.133

pget.check_class_ref.133:                         ; preds = %pget.recv_other.132
  %r765 = icmp eq i64 %r761, 32766
  br i1 %r765, label %pget.recv_class_ref.130, label %pget.recv_bad.129

pic.hit.134:                                      ; preds = %pic.token.150
  %r795 = getelementptr i64, ptr %r780, i64 1
  %r796 = load i64, ptr %r795, align 8
  %r797 = and i64 %r796, 1073741824
  %r798 = icmp ne i64 %r797, 0
  br i1 %r798, label %pic.hit.overflow.151, label %pic.hit.inline.152

pic.hit.live.135:                                 ; preds = %pic.hit.inline.152
  br label %pic.merge.148

pic.prefix.guard.136:                             ; preds = %pic.token.150
  %r811 = getelementptr i64, ptr %r780, i64 2
  %r812 = load i64, ptr %r811, align 8
  %r813 = icmp ne i64 %r812, 0
  br i1 %r813, label %pic.prefix.meta.137, label %pic.miss.145

pic.prefix.meta.137:                              ; preds = %pic.prefix.guard.136
  %r814 = add nuw nsw i64 %r760, 8
  %r815 = inttoptr i64 %r814 to ptr
  %r816 = load i64, ptr %r815, align 8
  %r817 = icmp ne i64 %r816, 0
  br i1 %r817, label %pic.prefix.token.138, label %pic.miss.145

pic.prefix.token.138:                             ; preds = %pic.prefix.meta.137
  %r818 = inttoptr i64 %r816 to ptr
  %r819 = getelementptr i64, ptr %r818, i64 6
  %r820 = load i64, ptr %r819, align 8
  %r821 = icmp eq i64 %r820, %r812
  br i1 %r821, label %pic.prefix.hit.139, label %pic.miss.145

pic.prefix.hit.139:                               ; preds = %pic.prefix.token.138
  %r822 = getelementptr i64, ptr %r780, i64 1
  %r823 = load i64, ptr %r822, align 8
  %r824 = shl i64 %r823, 3
  %r825 = add nuw nsw i64 %r760, 16
  %r826 = add i64 %r825, %r824
  %r827 = inttoptr i64 %r826 to ptr
  %r828 = load double, ptr %r827, align 8
  br label %pic.merge.148

pic.desc.classify.140:                            ; preds = %pic.recv_hdr.149
  %r784 = and i1 %r774, %r781
  br i1 %r784, label %pic.desc.prefix.guard.141, label %pic.miss.cold.146

pic.desc.prefix.guard.141:                        ; preds = %pic.desc.classify.140
  %r829 = getelementptr i64, ptr %r780, i64 2
  %r830 = load i64, ptr %r829, align 8
  %r831 = icmp ne i64 %r830, 0
  br i1 %r831, label %pic.desc.prefix.meta.142, label %pic.miss.cold.146

pic.desc.prefix.meta.142:                         ; preds = %pic.desc.prefix.guard.141
  %r832 = add nuw nsw i64 %r760, 8
  %r833 = inttoptr i64 %r832 to ptr
  %r834 = load i64, ptr %r833, align 8
  %r835 = icmp ne i64 %r834, 0
  br i1 %r835, label %pic.desc.prefix.token.143, label %pic.miss.cold.146

pic.desc.prefix.token.143:                        ; preds = %pic.desc.prefix.meta.142
  %r836 = inttoptr i64 %r834 to ptr
  %r837 = getelementptr i64, ptr %r836, i64 6
  %r838 = load i64, ptr %r837, align 8
  %r839 = icmp eq i64 %r838, %r830
  br i1 %r839, label %pic.desc.prefix.hit.144, label %pic.miss.cold.146

pic.desc.prefix.hit.144:                          ; preds = %pic.desc.prefix.token.143
  %r840 = getelementptr i64, ptr %r780, i64 1
  %r841 = load i64, ptr %r840, align 8
  %r842 = shl i64 %r841, 3
  %r843 = add nuw nsw i64 %r760, 16
  %r844 = add i64 %r843, %r842
  %r845 = inttoptr i64 %r844 to ptr
  %r846 = load double, ptr %r845, align 8
  br label %pic.merge.148

pic.miss.145:                                     ; preds = %pic.hit.inline.152, %pic.prefix.token.138, %pic.prefix.meta.137, %pic.prefix.guard.136
  %r847 = getelementptr i64, ptr %r780, i64 3
  %r848 = load i64, ptr %r847, align 8
  %r849 = icmp sgt i64 %r848, 0
  br i1 %r849, label %pic.ways.153, label %pic.miss.call.147

pic.miss.cold.146:                                ; preds = %pic.desc.prefix.token.143, %pic.desc.prefix.meta.142, %pic.desc.prefix.guard.141, %pic.desc.classify.140, %pget.recv_ok.128
  br label %pic.miss.call.147

pic.miss.call.147:                                ; preds = %pic.way.load.154, %pic.ways.153, %pic.miss.cold.146, %pic.miss.145
  %r888 = load double, ptr @options_worker_ts_.str.19.handle, align 8
  %r889 = bitcast double %r888 to i64
  %r890 = and i64 %r889, 281474976710655
  %statepoint_token228 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r760, i64 %r890, ptr @perry_ic_options_worker_ts__25, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated211, ptr addrspace(1) %rs4gc.s8.relocated212, ptr addrspace(1) %rs4gc.s9.relocated213, ptr addrspace(1) %rs4gc.s12.relocated214, ptr addrspace(1) %rs4gc.s15) ]
  %r891229 = call double @llvm.experimental.gc.result.f64(token %statepoint_token228)
  %rs4gc.s11.relocated230 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token228, i32 0, i32 0) ; (%rs4gc.s11.relocated211, %rs4gc.s11.relocated211)
  %rs4gc.s8.relocated231 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token228, i32 1, i32 1) ; (%rs4gc.s8.relocated212, %rs4gc.s8.relocated212)
  %rs4gc.s9.relocated232 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token228, i32 2, i32 2) ; (%rs4gc.s9.relocated213, %rs4gc.s9.relocated213)
  %rs4gc.s12.relocated233 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token228, i32 3, i32 3) ; (%rs4gc.s12.relocated214, %rs4gc.s12.relocated214)
  %rs4gc.s15.relocated234 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token228, i32 4, i32 4) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pic.merge.148

pic.merge.148:                                    ; preds = %pic.way.live.155, %pic.hit.overflow.151, %pic.miss.call.147, %pic.desc.prefix.hit.144, %pic.prefix.hit.139, %pic.hit.live.135
  %.1505 = phi ptr addrspace(1) [ %rs4gc.s15.relocated241, %pic.hit.overflow.151 ], [ %rs4gc.s15.relocated234, %pic.miss.call.147 ], [ %rs4gc.s15, %pic.way.live.155 ], [ %rs4gc.s15, %pic.hit.live.135 ], [ %rs4gc.s15, %pic.prefix.hit.139 ], [ %rs4gc.s15, %pic.desc.prefix.hit.144 ]
  %.1500 = phi ptr addrspace(1) [ %rs4gc.s12.relocated240, %pic.hit.overflow.151 ], [ %rs4gc.s12.relocated233, %pic.miss.call.147 ], [ %rs4gc.s12.relocated214, %pic.way.live.155 ], [ %rs4gc.s12.relocated214, %pic.hit.live.135 ], [ %rs4gc.s12.relocated214, %pic.prefix.hit.139 ], [ %rs4gc.s12.relocated214, %pic.desc.prefix.hit.144 ]
  %.2489 = phi ptr addrspace(1) [ %rs4gc.s11.relocated237, %pic.hit.overflow.151 ], [ %rs4gc.s11.relocated230, %pic.miss.call.147 ], [ %rs4gc.s11.relocated211, %pic.way.live.155 ], [ %rs4gc.s11.relocated211, %pic.hit.live.135 ], [ %rs4gc.s11.relocated211, %pic.prefix.hit.139 ], [ %rs4gc.s11.relocated211, %pic.desc.prefix.hit.144 ]
  %.3481 = phi ptr addrspace(1) [ %rs4gc.s9.relocated239, %pic.hit.overflow.151 ], [ %rs4gc.s9.relocated232, %pic.miss.call.147 ], [ %rs4gc.s9.relocated213, %pic.way.live.155 ], [ %rs4gc.s9.relocated213, %pic.hit.live.135 ], [ %rs4gc.s9.relocated213, %pic.prefix.hit.139 ], [ %rs4gc.s9.relocated213, %pic.desc.prefix.hit.144 ]
  %.3 = phi ptr addrspace(1) [ %rs4gc.s8.relocated238, %pic.hit.overflow.151 ], [ %rs4gc.s8.relocated231, %pic.miss.call.147 ], [ %rs4gc.s8.relocated212, %pic.way.live.155 ], [ %rs4gc.s8.relocated212, %pic.hit.live.135 ], [ %rs4gc.s8.relocated212, %pic.prefix.hit.139 ], [ %rs4gc.s8.relocated212, %pic.desc.prefix.hit.144 ]
  %r892 = phi double [ %r808, %pic.hit.live.135 ], [ %r803236, %pic.hit.overflow.151 ], [ %r828, %pic.prefix.hit.139 ], [ %r846, %pic.desc.prefix.hit.144 ], [ %r885, %pic.way.live.155 ], [ %r891229, %pic.miss.call.147 ]
  br label %pget.recv_merge.131

pic.recv_hdr.149:                                 ; preds = %pget.recv_ok.128
  %r771 = sub nuw nsw i64 %r760, 8
  %r772 = inttoptr i64 %r771 to ptr
  %r773 = load i8, ptr %r772, align 1
  %r774 = icmp eq i8 %r773, 2
  %r775 = sub nuw nsw i64 %r760, 6
  %r776 = inttoptr i64 %r775 to ptr
  %r777 = load i16, ptr %r776, align 2
  %r778 = and i16 %r777, 2048
  %r779 = icmp eq i16 %r778, 0
  %r780 = load ptr, ptr @perry_ic_options_worker_ts__25, align 8
  %r781 = icmp ne ptr %r780, null
  %r782 = and i1 %r774, %r779
  %r783 = and i1 %r782, %r781
  br i1 %r783, label %pic.token.150, label %pic.desc.classify.140

pic.token.150:                                    ; preds = %pic.recv_hdr.149
  %r785 = add nuw nsw i64 %r760, 4
  %r786 = inttoptr i64 %r785 to ptr
  %r787 = load i32, ptr %r786, align 4
  %r788 = zext i32 %r787 to i64
  %r789 = or i64 %r788, 4611686018427387904
  %r790 = icmp ne i32 %r787, 0
  %r791 = getelementptr i64, ptr %r780, i64 0
  %r792 = load i64, ptr %r791, align 8
  %r793 = icmp eq i64 %r789, %r792
  %r794 = and i1 %r793, %r790
  br i1 %r794, label %pic.hit.134, label %pic.prefix.guard.136

pic.hit.overflow.151:                             ; preds = %pic.hit.134
  %r799 = load double, ptr @options_worker_ts_.str.19.handle, align 8
  %r800 = bitcast double %r799 to i64
  %r801 = and i64 %r800, 281474976710655
  %r802 = trunc i64 %r796 to i32
  %statepoint_token235 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r760, i64 %r801, i32 %r802, ptr @perry_ic_options_worker_ts__25, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated211, ptr addrspace(1) %rs4gc.s8.relocated212, ptr addrspace(1) %rs4gc.s9.relocated213, ptr addrspace(1) %rs4gc.s12.relocated214, ptr addrspace(1) %rs4gc.s15) ]
  %r803236 = call double @llvm.experimental.gc.result.f64(token %statepoint_token235)
  %rs4gc.s11.relocated237 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 0, i32 0) ; (%rs4gc.s11.relocated211, %rs4gc.s11.relocated211)
  %rs4gc.s8.relocated238 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 1, i32 1) ; (%rs4gc.s8.relocated212, %rs4gc.s8.relocated212)
  %rs4gc.s9.relocated239 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 2, i32 2) ; (%rs4gc.s9.relocated213, %rs4gc.s9.relocated213)
  %rs4gc.s12.relocated240 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 3, i32 3) ; (%rs4gc.s12.relocated214, %rs4gc.s12.relocated214)
  %rs4gc.s15.relocated241 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 4, i32 4) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pic.merge.148

pic.hit.inline.152:                               ; preds = %pic.hit.134
  %r804 = shl i64 %r796, 3
  %r805 = add nuw nsw i64 %r760, 16
  %r806 = add i64 %r805, %r804
  %r807 = inttoptr i64 %r806 to ptr
  %r808 = load double, ptr %r807, align 8
  %r809 = bitcast double %r808 to i64
  %r810 = icmp eq i64 %r809, 9222246136947933200
  br i1 %r810, label %pic.miss.145, label %pic.hit.live.135

pic.ways.153:                                     ; preds = %pic.miss.145
  %r850 = getelementptr i64, ptr %r780, i64 4
  %r851 = load i64, ptr %r850, align 8
  %r852 = icmp eq i64 %r851, %r789
  %r853 = getelementptr i64, ptr %r780, i64 5
  %r854 = load i64, ptr %r853, align 8
  %r855 = select i1 %r852, i64 %r854, i64 0
  %r856 = getelementptr i64, ptr %r780, i64 6
  %r857 = load i64, ptr %r856, align 8
  %r858 = icmp eq i64 %r857, %r789
  %r859 = getelementptr i64, ptr %r780, i64 7
  %r860 = load i64, ptr %r859, align 8
  %r861 = select i1 %r858, i64 %r860, i64 0
  %r862 = getelementptr i64, ptr %r780, i64 8
  %r863 = load i64, ptr %r862, align 8
  %r864 = icmp eq i64 %r863, %r789
  %r865 = getelementptr i64, ptr %r780, i64 9
  %r866 = load i64, ptr %r865, align 8
  %r867 = select i1 %r864, i64 %r866, i64 0
  %r868 = getelementptr i64, ptr %r780, i64 10
  %r869 = load i64, ptr %r868, align 8
  %r870 = icmp eq i64 %r869, %r789
  %r871 = getelementptr i64, ptr %r780, i64 11
  %r872 = load i64, ptr %r871, align 8
  %r873 = select i1 %r870, i64 %r872, i64 0
  %r874 = or i1 %r852, %r858
  %r875 = select i1 %r852, i64 %r855, i64 %r861
  %r876 = or i1 %r864, %r870
  %r877 = select i1 %r864, i64 %r867, i64 %r873
  %r878 = or i1 %r874, %r876
  %r879 = select i1 %r874, i64 %r875, i64 %r877
  %r880 = and i1 %r790, %r878
  br i1 %r880, label %pic.way.load.154, label %pic.miss.call.147

pic.way.load.154:                                 ; preds = %pic.ways.153
  %r881 = shl i64 %r879, 3
  %r882 = add nuw nsw i64 %r760, 16
  %r883 = add i64 %r882, %r881
  %r884 = inttoptr i64 %r883 to ptr
  %r885 = load double, ptr %r884, align 8
  %r886 = bitcast double %r885 to i64
  %r887 = icmp eq i64 %r886, 9222246136947933200
  br i1 %r887, label %pic.miss.call.147, label %pic.way.live.155

pic.way.live.155:                                 ; preds = %pic.way.load.154
  br label %pic.merge.148

pget.throw_nullish.156:                           ; preds = %pget.recv_bad.129
  %r896 = zext i1 %r894 to i32
  %statepoint_token242 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r896, ptr @options_worker_ts_.str.19.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.157:                       ; preds = %pget.recv_bad.129
  %r897 = load double, ptr @options_worker_ts_.str.19.handle, align 8
  %r898 = bitcast double %r897 to i64
  %r899 = and i64 %r898, 281474976710655
  %statepoint_token243 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r759, i64 %r899, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated211, ptr addrspace(1) %rs4gc.s8.relocated212, ptr addrspace(1) %rs4gc.s9.relocated213, ptr addrspace(1) %rs4gc.s12.relocated214, ptr addrspace(1) %rs4gc.s15) ]
  %r900244 = call double @llvm.experimental.gc.result.f64(token %statepoint_token243)
  %rs4gc.s11.relocated245 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token243, i32 0, i32 0) ; (%rs4gc.s11.relocated211, %rs4gc.s11.relocated211)
  %rs4gc.s8.relocated246 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token243, i32 1, i32 1) ; (%rs4gc.s8.relocated212, %rs4gc.s8.relocated212)
  %rs4gc.s9.relocated247 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token243, i32 2, i32 2) ; (%rs4gc.s9.relocated213, %rs4gc.s9.relocated213)
  %rs4gc.s12.relocated248 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token243, i32 3, i32 3) ; (%rs4gc.s12.relocated214, %rs4gc.s12.relocated214)
  %rs4gc.s15.relocated249 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token243, i32 4, i32 4) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pget.recv_merge.131

shadow.root.barrier.158:                          ; preds = %pget.recv_merge.131
  call void @js_write_barrier_root_nanbox(i64 %r908) #9
  br label %shadow.root.barrier.done.159

shadow.root.barrier.done.159:                     ; preds = %shadow.root.barrier.158, %pget.recv_merge.131
  %r911.rs4i = ptrtoint ptr addrspace(1) %.2480 to i64
  %r911.rs4o = call i64 asm "", "=r,0"(i64 %r911.rs4i) #9
  %r911 = bitcast i64 %r911.rs4o to double
  %r912 = bitcast double %r911 to i64
  %r913 = and i64 %r912, 281474976710655
  %r914 = lshr i64 %r912, 48
  %r915 = and i64 %r914, 65533
  %r916 = icmp eq i64 %r915, 32765
  br i1 %r916, label %pget.recv_ok.161, label %pget.recv_other.165

pget.recv_sso.160:                                ; preds = %pget.recv_other.165
  %r1054 = load double, ptr @options_worker_ts_.str.19.handle, align 8
  %r1055 = bitcast double %r1054 to i64
  %r1056 = and i64 %r1055, 281474976710655
  %statepoint_token250 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r912, i64 %r1056, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1488, ptr addrspace(1) %.2477, ptr addrspace(1) %.2480, ptr addrspace(1) %.0499, ptr addrspace(1) %.0504, ptr addrspace(1) %rs4gc.s16) ]
  %r1057251 = call double @llvm.experimental.gc.result.f64(token %statepoint_token250)
  %rs4gc.s11.relocated252 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token250, i32 0, i32 0) ; (%.1488, %.1488)
  %rs4gc.s8.relocated253 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token250, i32 1, i32 1) ; (%.2477, %.2477)
  %rs4gc.s9.relocated254 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token250, i32 2, i32 2) ; (%.2480, %.2480)
  %rs4gc.s12.relocated255 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token250, i32 3, i32 3) ; (%.0499, %.0499)
  %rs4gc.s15.relocated256 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token250, i32 4, i32 4) ; (%.0504, %.0504)
  %rs4gc.s16.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token250, i32 5, i32 5) ; (%rs4gc.s16, %rs4gc.s16)
  br label %pget.recv_merge.164

pget.recv_ok.161:                                 ; preds = %shadow.root.barrier.done.159
  %r923 = icmp ugt i64 %r913, 1048575
  br i1 %r923, label %pic.recv_hdr.182, label %pic.miss.cold.179

pget.recv_bad.162:                                ; preds = %pget.check_class_ref.166
  %r1046 = icmp eq i64 %r912, 9222246136947933185
  %r1047 = icmp eq i64 %r912, 9222246136947933186
  %r1048 = or i1 %r1046, %r1047
  br i1 %r1048, label %pget.throw_nullish.189, label %pget.recv_undef_return.190

pget.recv_class_ref.163:                          ; preds = %pget.check_class_ref.166
  %r919 = load double, ptr @options_worker_ts_.str.19.handle, align 8
  %r920 = bitcast double %r919 to i64
  %r921 = and i64 %r920, 281474976710655
  %statepoint_token257 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532890, i64 %r912, i64 %r921, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1488, ptr addrspace(1) %.2477, ptr addrspace(1) %.2480, ptr addrspace(1) %.0499, ptr addrspace(1) %.0504, ptr addrspace(1) %rs4gc.s16) ]
  %r922258 = call double @llvm.experimental.gc.result.f64(token %statepoint_token257)
  %rs4gc.s11.relocated259 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token257, i32 0, i32 0) ; (%.1488, %.1488)
  %rs4gc.s8.relocated260 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token257, i32 1, i32 1) ; (%.2477, %.2477)
  %rs4gc.s9.relocated261 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token257, i32 2, i32 2) ; (%.2480, %.2480)
  %rs4gc.s12.relocated262 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token257, i32 3, i32 3) ; (%.0499, %.0499)
  %rs4gc.s15.relocated263 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token257, i32 4, i32 4) ; (%.0504, %.0504)
  %rs4gc.s16.relocated264 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token257, i32 5, i32 5) ; (%rs4gc.s16, %rs4gc.s16)
  br label %pget.recv_merge.164

pget.recv_merge.164:                              ; preds = %pget.recv_undef_return.190, %pic.merge.181, %pget.recv_class_ref.163, %pget.recv_sso.160
  %.0509 = phi ptr addrspace(1) [ %.1510, %pic.merge.181 ], [ %rs4gc.s16.relocated, %pget.recv_sso.160 ], [ %rs4gc.s16.relocated264, %pget.recv_class_ref.163 ], [ %rs4gc.s16.relocated289, %pget.recv_undef_return.190 ]
  %.2506 = phi ptr addrspace(1) [ %.3507, %pic.merge.181 ], [ %rs4gc.s15.relocated256, %pget.recv_sso.160 ], [ %rs4gc.s15.relocated263, %pget.recv_class_ref.163 ], [ %rs4gc.s15.relocated288, %pget.recv_undef_return.190 ]
  %.2501 = phi ptr addrspace(1) [ %.3502, %pic.merge.181 ], [ %rs4gc.s12.relocated255, %pget.recv_sso.160 ], [ %rs4gc.s12.relocated262, %pget.recv_class_ref.163 ], [ %rs4gc.s12.relocated287, %pget.recv_undef_return.190 ]
  %.3490 = phi ptr addrspace(1) [ %.4491, %pic.merge.181 ], [ %rs4gc.s11.relocated252, %pget.recv_sso.160 ], [ %rs4gc.s11.relocated259, %pget.recv_class_ref.163 ], [ %rs4gc.s11.relocated284, %pget.recv_undef_return.190 ]
  %.4482 = phi ptr addrspace(1) [ %.5483, %pic.merge.181 ], [ %rs4gc.s9.relocated254, %pget.recv_sso.160 ], [ %rs4gc.s9.relocated261, %pget.recv_class_ref.163 ], [ %rs4gc.s9.relocated286, %pget.recv_undef_return.190 ]
  %.4 = phi ptr addrspace(1) [ %.5, %pic.merge.181 ], [ %rs4gc.s8.relocated253, %pget.recv_sso.160 ], [ %rs4gc.s8.relocated260, %pget.recv_class_ref.163 ], [ %rs4gc.s8.relocated285, %pget.recv_undef_return.190 ]
  %r1058 = phi double [ %r1045, %pic.merge.181 ], [ %r1053283, %pget.recv_undef_return.190 ], [ %r1057251, %pget.recv_sso.160 ], [ %r922258, %pget.recv_class_ref.163 ]
  %r1059.rs4i = ptrtoint ptr addrspace(1) %.0509 to i64
  %r1059 = call i64 asm "", "=r,0"(i64 %r1059.rs4i) #9
  %r1060 = bitcast i64 %r1059 to double
  %r1061 = and i64 %r1059, -281474976710656
  %r1062 = icmp ult i64 %r1061, 9221401712017801216
  %r1063 = icmp ugt i64 %r1061, 9223090561878065152
  %r1064 = or i1 %r1062, %r1063
  %r1065 = bitcast double %r1058 to i64
  %r1066 = and i64 %r1065, -281474976710656
  %r1067 = icmp ult i64 %r1066, 9221401712017801216
  %r1068 = icmp ugt i64 %r1066, 9223090561878065152
  %r1069 = or i1 %r1067, %r1068
  %r1070 = and i1 %r1064, %r1069
  br i1 %r1070, label %guarded_arith.numeric.191, label %guarded_arith.dynamic.192

pget.recv_other.165:                              ; preds = %shadow.root.barrier.done.159
  %r917 = icmp eq i64 %r914, 32761
  br i1 %r917, label %pget.recv_sso.160, label %pget.check_class_ref.166

pget.check_class_ref.166:                         ; preds = %pget.recv_other.165
  %r918 = icmp eq i64 %r914, 32766
  br i1 %r918, label %pget.recv_class_ref.163, label %pget.recv_bad.162

pic.hit.167:                                      ; preds = %pic.token.183
  %r948 = getelementptr i64, ptr %r933, i64 1
  %r949 = load i64, ptr %r948, align 8
  %r950 = and i64 %r949, 1073741824
  %r951 = icmp ne i64 %r950, 0
  br i1 %r951, label %pic.hit.overflow.184, label %pic.hit.inline.185

pic.hit.live.168:                                 ; preds = %pic.hit.inline.185
  br label %pic.merge.181

pic.prefix.guard.169:                             ; preds = %pic.token.183
  %r964 = getelementptr i64, ptr %r933, i64 2
  %r965 = load i64, ptr %r964, align 8
  %r966 = icmp ne i64 %r965, 0
  br i1 %r966, label %pic.prefix.meta.170, label %pic.miss.178

pic.prefix.meta.170:                              ; preds = %pic.prefix.guard.169
  %r967 = add nuw nsw i64 %r913, 8
  %r968 = inttoptr i64 %r967 to ptr
  %r969 = load i64, ptr %r968, align 8
  %r970 = icmp ne i64 %r969, 0
  br i1 %r970, label %pic.prefix.token.171, label %pic.miss.178

pic.prefix.token.171:                             ; preds = %pic.prefix.meta.170
  %r971 = inttoptr i64 %r969 to ptr
  %r972 = getelementptr i64, ptr %r971, i64 6
  %r973 = load i64, ptr %r972, align 8
  %r974 = icmp eq i64 %r973, %r965
  br i1 %r974, label %pic.prefix.hit.172, label %pic.miss.178

pic.prefix.hit.172:                               ; preds = %pic.prefix.token.171
  %r975 = getelementptr i64, ptr %r933, i64 1
  %r976 = load i64, ptr %r975, align 8
  %r977 = shl i64 %r976, 3
  %r978 = add nuw nsw i64 %r913, 16
  %r979 = add i64 %r978, %r977
  %r980 = inttoptr i64 %r979 to ptr
  %r981 = load double, ptr %r980, align 8
  br label %pic.merge.181

pic.desc.classify.173:                            ; preds = %pic.recv_hdr.182
  %r937 = and i1 %r927, %r934
  br i1 %r937, label %pic.desc.prefix.guard.174, label %pic.miss.cold.179

pic.desc.prefix.guard.174:                        ; preds = %pic.desc.classify.173
  %r982 = getelementptr i64, ptr %r933, i64 2
  %r983 = load i64, ptr %r982, align 8
  %r984 = icmp ne i64 %r983, 0
  br i1 %r984, label %pic.desc.prefix.meta.175, label %pic.miss.cold.179

pic.desc.prefix.meta.175:                         ; preds = %pic.desc.prefix.guard.174
  %r985 = add nuw nsw i64 %r913, 8
  %r986 = inttoptr i64 %r985 to ptr
  %r987 = load i64, ptr %r986, align 8
  %r988 = icmp ne i64 %r987, 0
  br i1 %r988, label %pic.desc.prefix.token.176, label %pic.miss.cold.179

pic.desc.prefix.token.176:                        ; preds = %pic.desc.prefix.meta.175
  %r989 = inttoptr i64 %r987 to ptr
  %r990 = getelementptr i64, ptr %r989, i64 6
  %r991 = load i64, ptr %r990, align 8
  %r992 = icmp eq i64 %r991, %r983
  br i1 %r992, label %pic.desc.prefix.hit.177, label %pic.miss.cold.179

pic.desc.prefix.hit.177:                          ; preds = %pic.desc.prefix.token.176
  %r993 = getelementptr i64, ptr %r933, i64 1
  %r994 = load i64, ptr %r993, align 8
  %r995 = shl i64 %r994, 3
  %r996 = add nuw nsw i64 %r913, 16
  %r997 = add i64 %r996, %r995
  %r998 = inttoptr i64 %r997 to ptr
  %r999 = load double, ptr %r998, align 8
  br label %pic.merge.181

pic.miss.178:                                     ; preds = %pic.hit.inline.185, %pic.prefix.token.171, %pic.prefix.meta.170, %pic.prefix.guard.169
  %r1000 = getelementptr i64, ptr %r933, i64 3
  %r1001 = load i64, ptr %r1000, align 8
  %r1002 = icmp sgt i64 %r1001, 0
  br i1 %r1002, label %pic.ways.186, label %pic.miss.call.180

pic.miss.cold.179:                                ; preds = %pic.desc.prefix.token.176, %pic.desc.prefix.meta.175, %pic.desc.prefix.guard.174, %pic.desc.classify.173, %pget.recv_ok.161
  br label %pic.miss.call.180

pic.miss.call.180:                                ; preds = %pic.way.load.187, %pic.ways.186, %pic.miss.cold.179, %pic.miss.178
  %r1041 = load double, ptr @options_worker_ts_.str.19.handle, align 8
  %r1042 = bitcast double %r1041 to i64
  %r1043 = and i64 %r1042, 281474976710655
  %statepoint_token265 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r913, i64 %r1043, ptr @perry_ic_options_worker_ts__27, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1488, ptr addrspace(1) %.2477, ptr addrspace(1) %.2480, ptr addrspace(1) %.0499, ptr addrspace(1) %.0504, ptr addrspace(1) %rs4gc.s16) ]
  %r1044266 = call double @llvm.experimental.gc.result.f64(token %statepoint_token265)
  %rs4gc.s11.relocated267 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token265, i32 0, i32 0) ; (%.1488, %.1488)
  %rs4gc.s8.relocated268 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token265, i32 1, i32 1) ; (%.2477, %.2477)
  %rs4gc.s9.relocated269 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token265, i32 2, i32 2) ; (%.2480, %.2480)
  %rs4gc.s12.relocated270 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token265, i32 3, i32 3) ; (%.0499, %.0499)
  %rs4gc.s15.relocated271 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token265, i32 4, i32 4) ; (%.0504, %.0504)
  %rs4gc.s16.relocated272 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token265, i32 5, i32 5) ; (%rs4gc.s16, %rs4gc.s16)
  br label %pic.merge.181

pic.merge.181:                                    ; preds = %pic.way.live.188, %pic.hit.overflow.184, %pic.miss.call.180, %pic.desc.prefix.hit.177, %pic.prefix.hit.172, %pic.hit.live.168
  %.1510 = phi ptr addrspace(1) [ %rs4gc.s16.relocated280, %pic.hit.overflow.184 ], [ %rs4gc.s16.relocated272, %pic.miss.call.180 ], [ %rs4gc.s16, %pic.way.live.188 ], [ %rs4gc.s16, %pic.hit.live.168 ], [ %rs4gc.s16, %pic.prefix.hit.172 ], [ %rs4gc.s16, %pic.desc.prefix.hit.177 ]
  %.3507 = phi ptr addrspace(1) [ %rs4gc.s15.relocated279, %pic.hit.overflow.184 ], [ %rs4gc.s15.relocated271, %pic.miss.call.180 ], [ %.0504, %pic.way.live.188 ], [ %.0504, %pic.hit.live.168 ], [ %.0504, %pic.prefix.hit.172 ], [ %.0504, %pic.desc.prefix.hit.177 ]
  %.3502 = phi ptr addrspace(1) [ %rs4gc.s12.relocated278, %pic.hit.overflow.184 ], [ %rs4gc.s12.relocated270, %pic.miss.call.180 ], [ %.0499, %pic.way.live.188 ], [ %.0499, %pic.hit.live.168 ], [ %.0499, %pic.prefix.hit.172 ], [ %.0499, %pic.desc.prefix.hit.177 ]
  %.4491 = phi ptr addrspace(1) [ %rs4gc.s11.relocated275, %pic.hit.overflow.184 ], [ %rs4gc.s11.relocated267, %pic.miss.call.180 ], [ %.1488, %pic.way.live.188 ], [ %.1488, %pic.hit.live.168 ], [ %.1488, %pic.prefix.hit.172 ], [ %.1488, %pic.desc.prefix.hit.177 ]
  %.5483 = phi ptr addrspace(1) [ %rs4gc.s9.relocated277, %pic.hit.overflow.184 ], [ %rs4gc.s9.relocated269, %pic.miss.call.180 ], [ %.2480, %pic.way.live.188 ], [ %.2480, %pic.hit.live.168 ], [ %.2480, %pic.prefix.hit.172 ], [ %.2480, %pic.desc.prefix.hit.177 ]
  %.5 = phi ptr addrspace(1) [ %rs4gc.s8.relocated276, %pic.hit.overflow.184 ], [ %rs4gc.s8.relocated268, %pic.miss.call.180 ], [ %.2477, %pic.way.live.188 ], [ %.2477, %pic.hit.live.168 ], [ %.2477, %pic.prefix.hit.172 ], [ %.2477, %pic.desc.prefix.hit.177 ]
  %r1045 = phi double [ %r961, %pic.hit.live.168 ], [ %r956274, %pic.hit.overflow.184 ], [ %r981, %pic.prefix.hit.172 ], [ %r999, %pic.desc.prefix.hit.177 ], [ %r1038, %pic.way.live.188 ], [ %r1044266, %pic.miss.call.180 ]
  br label %pget.recv_merge.164

pic.recv_hdr.182:                                 ; preds = %pget.recv_ok.161
  %r924 = sub nuw nsw i64 %r913, 8
  %r925 = inttoptr i64 %r924 to ptr
  %r926 = load i8, ptr %r925, align 1
  %r927 = icmp eq i8 %r926, 2
  %r928 = sub nuw nsw i64 %r913, 6
  %r929 = inttoptr i64 %r928 to ptr
  %r930 = load i16, ptr %r929, align 2
  %r931 = and i16 %r930, 2048
  %r932 = icmp eq i16 %r931, 0
  %r933 = load ptr, ptr @perry_ic_options_worker_ts__27, align 8
  %r934 = icmp ne ptr %r933, null
  %r935 = and i1 %r927, %r932
  %r936 = and i1 %r935, %r934
  br i1 %r936, label %pic.token.183, label %pic.desc.classify.173

pic.token.183:                                    ; preds = %pic.recv_hdr.182
  %r938 = add nuw nsw i64 %r913, 4
  %r939 = inttoptr i64 %r938 to ptr
  %r940 = load i32, ptr %r939, align 4
  %r941 = zext i32 %r940 to i64
  %r942 = or i64 %r941, 4611686018427387904
  %r943 = icmp ne i32 %r940, 0
  %r944 = getelementptr i64, ptr %r933, i64 0
  %r945 = load i64, ptr %r944, align 8
  %r946 = icmp eq i64 %r942, %r945
  %r947 = and i1 %r946, %r943
  br i1 %r947, label %pic.hit.167, label %pic.prefix.guard.169

pic.hit.overflow.184:                             ; preds = %pic.hit.167
  %r952 = load double, ptr @options_worker_ts_.str.19.handle, align 8
  %r953 = bitcast double %r952 to i64
  %r954 = and i64 %r953, 281474976710655
  %r955 = trunc i64 %r949 to i32
  %statepoint_token273 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r913, i64 %r954, i32 %r955, ptr @perry_ic_options_worker_ts__27, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1488, ptr addrspace(1) %.2477, ptr addrspace(1) %.2480, ptr addrspace(1) %.0499, ptr addrspace(1) %.0504, ptr addrspace(1) %rs4gc.s16) ]
  %r956274 = call double @llvm.experimental.gc.result.f64(token %statepoint_token273)
  %rs4gc.s11.relocated275 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token273, i32 0, i32 0) ; (%.1488, %.1488)
  %rs4gc.s8.relocated276 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token273, i32 1, i32 1) ; (%.2477, %.2477)
  %rs4gc.s9.relocated277 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token273, i32 2, i32 2) ; (%.2480, %.2480)
  %rs4gc.s12.relocated278 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token273, i32 3, i32 3) ; (%.0499, %.0499)
  %rs4gc.s15.relocated279 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token273, i32 4, i32 4) ; (%.0504, %.0504)
  %rs4gc.s16.relocated280 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token273, i32 5, i32 5) ; (%rs4gc.s16, %rs4gc.s16)
  br label %pic.merge.181

pic.hit.inline.185:                               ; preds = %pic.hit.167
  %r957 = shl i64 %r949, 3
  %r958 = add nuw nsw i64 %r913, 16
  %r959 = add i64 %r958, %r957
  %r960 = inttoptr i64 %r959 to ptr
  %r961 = load double, ptr %r960, align 8
  %r962 = bitcast double %r961 to i64
  %r963 = icmp eq i64 %r962, 9222246136947933200
  br i1 %r963, label %pic.miss.178, label %pic.hit.live.168

pic.ways.186:                                     ; preds = %pic.miss.178
  %r1003 = getelementptr i64, ptr %r933, i64 4
  %r1004 = load i64, ptr %r1003, align 8
  %r1005 = icmp eq i64 %r1004, %r942
  %r1006 = getelementptr i64, ptr %r933, i64 5
  %r1007 = load i64, ptr %r1006, align 8
  %r1008 = select i1 %r1005, i64 %r1007, i64 0
  %r1009 = getelementptr i64, ptr %r933, i64 6
  %r1010 = load i64, ptr %r1009, align 8
  %r1011 = icmp eq i64 %r1010, %r942
  %r1012 = getelementptr i64, ptr %r933, i64 7
  %r1013 = load i64, ptr %r1012, align 8
  %r1014 = select i1 %r1011, i64 %r1013, i64 0
  %r1015 = getelementptr i64, ptr %r933, i64 8
  %r1016 = load i64, ptr %r1015, align 8
  %r1017 = icmp eq i64 %r1016, %r942
  %r1018 = getelementptr i64, ptr %r933, i64 9
  %r1019 = load i64, ptr %r1018, align 8
  %r1020 = select i1 %r1017, i64 %r1019, i64 0
  %r1021 = getelementptr i64, ptr %r933, i64 10
  %r1022 = load i64, ptr %r1021, align 8
  %r1023 = icmp eq i64 %r1022, %r942
  %r1024 = getelementptr i64, ptr %r933, i64 11
  %r1025 = load i64, ptr %r1024, align 8
  %r1026 = select i1 %r1023, i64 %r1025, i64 0
  %r1027 = or i1 %r1005, %r1011
  %r1028 = select i1 %r1005, i64 %r1008, i64 %r1014
  %r1029 = or i1 %r1017, %r1023
  %r1030 = select i1 %r1017, i64 %r1020, i64 %r1026
  %r1031 = or i1 %r1027, %r1029
  %r1032 = select i1 %r1027, i64 %r1028, i64 %r1030
  %r1033 = and i1 %r943, %r1031
  br i1 %r1033, label %pic.way.load.187, label %pic.miss.call.180

pic.way.load.187:                                 ; preds = %pic.ways.186
  %r1034 = shl i64 %r1032, 3
  %r1035 = add nuw nsw i64 %r913, 16
  %r1036 = add i64 %r1035, %r1034
  %r1037 = inttoptr i64 %r1036 to ptr
  %r1038 = load double, ptr %r1037, align 8
  %r1039 = bitcast double %r1038 to i64
  %r1040 = icmp eq i64 %r1039, 9222246136947933200
  br i1 %r1040, label %pic.miss.call.180, label %pic.way.live.188

pic.way.live.188:                                 ; preds = %pic.way.load.187
  br label %pic.merge.181

pget.throw_nullish.189:                           ; preds = %pget.recv_bad.162
  %r1049 = zext i1 %r1047 to i32
  %statepoint_token281 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1049, ptr @options_worker_ts_.str.19.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.190:                       ; preds = %pget.recv_bad.162
  %r1050 = load double, ptr @options_worker_ts_.str.19.handle, align 8
  %r1051 = bitcast double %r1050 to i64
  %r1052 = and i64 %r1051, 281474976710655
  %statepoint_token282 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r912, i64 %r1052, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1488, ptr addrspace(1) %.2477, ptr addrspace(1) %.2480, ptr addrspace(1) %.0499, ptr addrspace(1) %.0504, ptr addrspace(1) %rs4gc.s16) ]
  %r1053283 = call double @llvm.experimental.gc.result.f64(token %statepoint_token282)
  %rs4gc.s11.relocated284 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token282, i32 0, i32 0) ; (%.1488, %.1488)
  %rs4gc.s8.relocated285 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token282, i32 1, i32 1) ; (%.2477, %.2477)
  %rs4gc.s9.relocated286 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token282, i32 2, i32 2) ; (%.2480, %.2480)
  %rs4gc.s12.relocated287 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token282, i32 3, i32 3) ; (%.0499, %.0499)
  %rs4gc.s15.relocated288 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token282, i32 4, i32 4) ; (%.0504, %.0504)
  %rs4gc.s16.relocated289 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token282, i32 5, i32 5) ; (%rs4gc.s16, %rs4gc.s16)
  br label %pget.recv_merge.164

guarded_arith.numeric.191:                        ; preds = %pget.recv_merge.164
  %r1071 = fsub double %r1060, %r1058
  br label %guarded_arith.merge.193

guarded_arith.dynamic.192:                        ; preds = %pget.recv_merge.164
  %statepoint_token290 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_sub, i32 2, i32 0, double %r1060, double %r1058, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3490, ptr addrspace(1) %.4, ptr addrspace(1) %.4482, ptr addrspace(1) %.2501, ptr addrspace(1) %.2506) ]
  %r1072291 = call double @llvm.experimental.gc.result.f64(token %statepoint_token290)
  %rs4gc.s11.relocated292 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token290, i32 0, i32 0) ; (%.3490, %.3490)
  %rs4gc.s8.relocated293 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token290, i32 1, i32 1) ; (%.4, %.4)
  %rs4gc.s9.relocated294 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token290, i32 2, i32 2) ; (%.4482, %.4482)
  %rs4gc.s12.relocated295 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token290, i32 3, i32 3) ; (%.2501, %.2501)
  %rs4gc.s15.relocated296 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token290, i32 4, i32 4) ; (%.2506, %.2506)
  br label %guarded_arith.merge.193

guarded_arith.merge.193:                          ; preds = %guarded_arith.dynamic.192, %guarded_arith.numeric.191
  %.4508 = phi ptr addrspace(1) [ %.2506, %guarded_arith.numeric.191 ], [ %rs4gc.s15.relocated296, %guarded_arith.dynamic.192 ]
  %.4503 = phi ptr addrspace(1) [ %.2501, %guarded_arith.numeric.191 ], [ %rs4gc.s12.relocated295, %guarded_arith.dynamic.192 ]
  %.5492 = phi ptr addrspace(1) [ %.3490, %guarded_arith.numeric.191 ], [ %rs4gc.s11.relocated292, %guarded_arith.dynamic.192 ]
  %.6484 = phi ptr addrspace(1) [ %.4482, %guarded_arith.numeric.191 ], [ %rs4gc.s9.relocated294, %guarded_arith.dynamic.192 ]
  %.6 = phi ptr addrspace(1) [ %.4, %guarded_arith.numeric.191 ], [ %rs4gc.s8.relocated293, %guarded_arith.dynamic.192 ]
  %r1073 = phi double [ %r1071, %guarded_arith.numeric.191 ], [ %r1072291, %guarded_arith.dynamic.192 ]
  %r1074.rs4i = ptrtoint ptr addrspace(1) %.4508 to i64
  %r1074 = call i64 asm "", "=r,0"(i64 %r1074.rs4i) #9
  %statepoint_token297 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1074, double %r1073, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5492, ptr addrspace(1) %.6, ptr addrspace(1) %.6484, ptr addrspace(1) %.4503) ]
  %r1075298 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token297)
  %rs4gc.s11.relocated299 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token297, i32 0, i32 0) ; (%.5492, %.5492)
  %rs4gc.s8.relocated300 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token297, i32 1, i32 1) ; (%.6, %.6)
  %rs4gc.s9.relocated301 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token297, i32 2, i32 2) ; (%.6484, %.6484)
  %rs4gc.s12.relocated302 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token297, i32 3, i32 3) ; (%.4503, %.4503)
  %rs4gc.s17 = inttoptr i64 %r1075298 to ptr addrspace(1)
  %r1076.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17 to i64
  %r1076 = call i64 asm "", "=r,0"(i64 %r1076.rs4i) #9
  %r1077 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1078 = icmp ne i32 %r1077, 0
  br i1 %r1078, label %shadow.root.barrier.194, label %shadow.root.barrier.done.195

shadow.root.barrier.194:                          ; preds = %guarded_arith.merge.193
  call void @js_write_barrier_root_nanbox(i64 %r1076) #9
  br label %shadow.root.barrier.done.195

shadow.root.barrier.done.195:                     ; preds = %shadow.root.barrier.194, %guarded_arith.merge.193
  %r1079.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12.relocated302 to i64
  %r1079.rs4o = call i64 asm "", "=r,0"(i64 %r1079.rs4i) #9
  %r1079 = bitcast i64 %r1079.rs4o to double
  %r1080 = bitcast double %r1079 to i64
  %r1081 = and i64 %r1080, 281474976710655
  %r1082 = lshr i64 %r1080, 48
  %r1083 = and i64 %r1082, 65533
  %r1084 = icmp eq i64 %r1083, 32765
  br i1 %r1084, label %pget.recv_ok.197, label %pget.recv_other.201

pget.recv_sso.196:                                ; preds = %pget.recv_other.201
  %r1222 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r1223 = bitcast double %r1222 to i64
  %r1224 = and i64 %r1223, 281474976710655
  %statepoint_token303 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1080, i64 %r1224, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated299, ptr addrspace(1) %rs4gc.s8.relocated300, ptr addrspace(1) %rs4gc.s17, ptr addrspace(1) %rs4gc.s9.relocated301) ]
  %r1225304 = call double @llvm.experimental.gc.result.f64(token %statepoint_token303)
  %rs4gc.s11.relocated305 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token303, i32 0, i32 0) ; (%rs4gc.s11.relocated299, %rs4gc.s11.relocated299)
  %rs4gc.s8.relocated306 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token303, i32 1, i32 1) ; (%rs4gc.s8.relocated300, %rs4gc.s8.relocated300)
  %rs4gc.s17.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token303, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  %rs4gc.s9.relocated307 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token303, i32 3, i32 3) ; (%rs4gc.s9.relocated301, %rs4gc.s9.relocated301)
  br label %pget.recv_merge.200

pget.recv_ok.197:                                 ; preds = %shadow.root.barrier.done.195
  %r1091 = icmp ugt i64 %r1081, 1048575
  br i1 %r1091, label %pic.recv_hdr.218, label %pic.miss.cold.215

pget.recv_bad.198:                                ; preds = %pget.check_class_ref.202
  %r1214 = icmp eq i64 %r1080, 9222246136947933185
  %r1215 = icmp eq i64 %r1080, 9222246136947933186
  %r1216 = or i1 %r1214, %r1215
  br i1 %r1216, label %pget.throw_nullish.225, label %pget.recv_undef_return.226

pget.recv_class_ref.199:                          ; preds = %pget.check_class_ref.202
  %r1087 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r1088 = bitcast double %r1087 to i64
  %r1089 = and i64 %r1088, 281474976710655
  %statepoint_token308 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532892, i64 %r1080, i64 %r1089, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated299, ptr addrspace(1) %rs4gc.s8.relocated300, ptr addrspace(1) %rs4gc.s17, ptr addrspace(1) %rs4gc.s9.relocated301) ]
  %r1090309 = call double @llvm.experimental.gc.result.f64(token %statepoint_token308)
  %rs4gc.s11.relocated310 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token308, i32 0, i32 0) ; (%rs4gc.s11.relocated299, %rs4gc.s11.relocated299)
  %rs4gc.s8.relocated311 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token308, i32 1, i32 1) ; (%rs4gc.s8.relocated300, %rs4gc.s8.relocated300)
  %rs4gc.s17.relocated312 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token308, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  %rs4gc.s9.relocated313 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token308, i32 3, i32 3) ; (%rs4gc.s9.relocated301, %rs4gc.s9.relocated301)
  br label %pget.recv_merge.200

pget.recv_merge.200:                              ; preds = %pget.recv_undef_return.226, %pic.merge.217, %pget.recv_class_ref.199, %pget.recv_sso.196
  %.0511 = phi ptr addrspace(1) [ %.1512, %pic.merge.217 ], [ %rs4gc.s17.relocated, %pget.recv_sso.196 ], [ %rs4gc.s17.relocated312, %pget.recv_class_ref.199 ], [ %rs4gc.s17.relocated331, %pget.recv_undef_return.226 ]
  %.6493 = phi ptr addrspace(1) [ %.7494, %pic.merge.217 ], [ %rs4gc.s11.relocated305, %pget.recv_sso.196 ], [ %rs4gc.s11.relocated310, %pget.recv_class_ref.199 ], [ %rs4gc.s11.relocated329, %pget.recv_undef_return.226 ]
  %.7485 = phi ptr addrspace(1) [ %.8486, %pic.merge.217 ], [ %rs4gc.s9.relocated307, %pget.recv_sso.196 ], [ %rs4gc.s9.relocated313, %pget.recv_class_ref.199 ], [ %rs4gc.s9.relocated332, %pget.recv_undef_return.226 ]
  %.7 = phi ptr addrspace(1) [ %.8, %pic.merge.217 ], [ %rs4gc.s8.relocated306, %pget.recv_sso.196 ], [ %rs4gc.s8.relocated311, %pget.recv_class_ref.199 ], [ %rs4gc.s8.relocated330, %pget.recv_undef_return.226 ]
  %r1226 = phi double [ %r1213, %pic.merge.217 ], [ %r1221328, %pget.recv_undef_return.226 ], [ %r1225304, %pget.recv_sso.196 ], [ %r1090309, %pget.recv_class_ref.199 ]
  %r1227 = bitcast double %r1226 to i64
  %rs4gc.s18 = inttoptr i64 %r1227 to ptr addrspace(1)
  %r1228.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r1228 = call i64 asm "", "=r,0"(i64 %r1228.rs4i) #9
  %r1229 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1230 = icmp ne i32 %r1229, 0
  br i1 %r1230, label %shadow.root.barrier.227, label %shadow.root.barrier.done.228

pget.recv_other.201:                              ; preds = %shadow.root.barrier.done.195
  %r1085 = icmp eq i64 %r1082, 32761
  br i1 %r1085, label %pget.recv_sso.196, label %pget.check_class_ref.202

pget.check_class_ref.202:                         ; preds = %pget.recv_other.201
  %r1086 = icmp eq i64 %r1082, 32766
  br i1 %r1086, label %pget.recv_class_ref.199, label %pget.recv_bad.198

pic.hit.203:                                      ; preds = %pic.token.219
  %r1116 = getelementptr i64, ptr %r1101, i64 1
  %r1117 = load i64, ptr %r1116, align 8
  %r1118 = and i64 %r1117, 1073741824
  %r1119 = icmp ne i64 %r1118, 0
  br i1 %r1119, label %pic.hit.overflow.220, label %pic.hit.inline.221

pic.hit.live.204:                                 ; preds = %pic.hit.inline.221
  br label %pic.merge.217

pic.prefix.guard.205:                             ; preds = %pic.token.219
  %r1132 = getelementptr i64, ptr %r1101, i64 2
  %r1133 = load i64, ptr %r1132, align 8
  %r1134 = icmp ne i64 %r1133, 0
  br i1 %r1134, label %pic.prefix.meta.206, label %pic.miss.214

pic.prefix.meta.206:                              ; preds = %pic.prefix.guard.205
  %r1135 = add nuw nsw i64 %r1081, 8
  %r1136 = inttoptr i64 %r1135 to ptr
  %r1137 = load i64, ptr %r1136, align 8
  %r1138 = icmp ne i64 %r1137, 0
  br i1 %r1138, label %pic.prefix.token.207, label %pic.miss.214

pic.prefix.token.207:                             ; preds = %pic.prefix.meta.206
  %r1139 = inttoptr i64 %r1137 to ptr
  %r1140 = getelementptr i64, ptr %r1139, i64 6
  %r1141 = load i64, ptr %r1140, align 8
  %r1142 = icmp eq i64 %r1141, %r1133
  br i1 %r1142, label %pic.prefix.hit.208, label %pic.miss.214

pic.prefix.hit.208:                               ; preds = %pic.prefix.token.207
  %r1143 = getelementptr i64, ptr %r1101, i64 1
  %r1144 = load i64, ptr %r1143, align 8
  %r1145 = shl i64 %r1144, 3
  %r1146 = add nuw nsw i64 %r1081, 16
  %r1147 = add i64 %r1146, %r1145
  %r1148 = inttoptr i64 %r1147 to ptr
  %r1149 = load double, ptr %r1148, align 8
  br label %pic.merge.217

pic.desc.classify.209:                            ; preds = %pic.recv_hdr.218
  %r1105 = and i1 %r1095, %r1102
  br i1 %r1105, label %pic.desc.prefix.guard.210, label %pic.miss.cold.215

pic.desc.prefix.guard.210:                        ; preds = %pic.desc.classify.209
  %r1150 = getelementptr i64, ptr %r1101, i64 2
  %r1151 = load i64, ptr %r1150, align 8
  %r1152 = icmp ne i64 %r1151, 0
  br i1 %r1152, label %pic.desc.prefix.meta.211, label %pic.miss.cold.215

pic.desc.prefix.meta.211:                         ; preds = %pic.desc.prefix.guard.210
  %r1153 = add nuw nsw i64 %r1081, 8
  %r1154 = inttoptr i64 %r1153 to ptr
  %r1155 = load i64, ptr %r1154, align 8
  %r1156 = icmp ne i64 %r1155, 0
  br i1 %r1156, label %pic.desc.prefix.token.212, label %pic.miss.cold.215

pic.desc.prefix.token.212:                        ; preds = %pic.desc.prefix.meta.211
  %r1157 = inttoptr i64 %r1155 to ptr
  %r1158 = getelementptr i64, ptr %r1157, i64 6
  %r1159 = load i64, ptr %r1158, align 8
  %r1160 = icmp eq i64 %r1159, %r1151
  br i1 %r1160, label %pic.desc.prefix.hit.213, label %pic.miss.cold.215

pic.desc.prefix.hit.213:                          ; preds = %pic.desc.prefix.token.212
  %r1161 = getelementptr i64, ptr %r1101, i64 1
  %r1162 = load i64, ptr %r1161, align 8
  %r1163 = shl i64 %r1162, 3
  %r1164 = add nuw nsw i64 %r1081, 16
  %r1165 = add i64 %r1164, %r1163
  %r1166 = inttoptr i64 %r1165 to ptr
  %r1167 = load double, ptr %r1166, align 8
  br label %pic.merge.217

pic.miss.214:                                     ; preds = %pic.hit.inline.221, %pic.prefix.token.207, %pic.prefix.meta.206, %pic.prefix.guard.205
  %r1168 = getelementptr i64, ptr %r1101, i64 3
  %r1169 = load i64, ptr %r1168, align 8
  %r1170 = icmp sgt i64 %r1169, 0
  br i1 %r1170, label %pic.ways.222, label %pic.miss.call.216

pic.miss.cold.215:                                ; preds = %pic.desc.prefix.token.212, %pic.desc.prefix.meta.211, %pic.desc.prefix.guard.210, %pic.desc.classify.209, %pget.recv_ok.197
  br label %pic.miss.call.216

pic.miss.call.216:                                ; preds = %pic.way.load.223, %pic.ways.222, %pic.miss.cold.215, %pic.miss.214
  %r1209 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r1210 = bitcast double %r1209 to i64
  %r1211 = and i64 %r1210, 281474976710655
  %statepoint_token314 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1081, i64 %r1211, ptr @perry_ic_options_worker_ts__29, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated299, ptr addrspace(1) %rs4gc.s8.relocated300, ptr addrspace(1) %rs4gc.s17, ptr addrspace(1) %rs4gc.s9.relocated301) ]
  %r1212315 = call double @llvm.experimental.gc.result.f64(token %statepoint_token314)
  %rs4gc.s11.relocated316 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 0, i32 0) ; (%rs4gc.s11.relocated299, %rs4gc.s11.relocated299)
  %rs4gc.s8.relocated317 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 1, i32 1) ; (%rs4gc.s8.relocated300, %rs4gc.s8.relocated300)
  %rs4gc.s17.relocated318 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  %rs4gc.s9.relocated319 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 3, i32 3) ; (%rs4gc.s9.relocated301, %rs4gc.s9.relocated301)
  br label %pic.merge.217

pic.merge.217:                                    ; preds = %pic.way.live.224, %pic.hit.overflow.220, %pic.miss.call.216, %pic.desc.prefix.hit.213, %pic.prefix.hit.208, %pic.hit.live.204
  %.1512 = phi ptr addrspace(1) [ %rs4gc.s17.relocated324, %pic.hit.overflow.220 ], [ %rs4gc.s17.relocated318, %pic.miss.call.216 ], [ %rs4gc.s17, %pic.way.live.224 ], [ %rs4gc.s17, %pic.hit.live.204 ], [ %rs4gc.s17, %pic.prefix.hit.208 ], [ %rs4gc.s17, %pic.desc.prefix.hit.213 ]
  %.7494 = phi ptr addrspace(1) [ %rs4gc.s11.relocated322, %pic.hit.overflow.220 ], [ %rs4gc.s11.relocated316, %pic.miss.call.216 ], [ %rs4gc.s11.relocated299, %pic.way.live.224 ], [ %rs4gc.s11.relocated299, %pic.hit.live.204 ], [ %rs4gc.s11.relocated299, %pic.prefix.hit.208 ], [ %rs4gc.s11.relocated299, %pic.desc.prefix.hit.213 ]
  %.8486 = phi ptr addrspace(1) [ %rs4gc.s9.relocated325, %pic.hit.overflow.220 ], [ %rs4gc.s9.relocated319, %pic.miss.call.216 ], [ %rs4gc.s9.relocated301, %pic.way.live.224 ], [ %rs4gc.s9.relocated301, %pic.hit.live.204 ], [ %rs4gc.s9.relocated301, %pic.prefix.hit.208 ], [ %rs4gc.s9.relocated301, %pic.desc.prefix.hit.213 ]
  %.8 = phi ptr addrspace(1) [ %rs4gc.s8.relocated323, %pic.hit.overflow.220 ], [ %rs4gc.s8.relocated317, %pic.miss.call.216 ], [ %rs4gc.s8.relocated300, %pic.way.live.224 ], [ %rs4gc.s8.relocated300, %pic.hit.live.204 ], [ %rs4gc.s8.relocated300, %pic.prefix.hit.208 ], [ %rs4gc.s8.relocated300, %pic.desc.prefix.hit.213 ]
  %r1213 = phi double [ %r1129, %pic.hit.live.204 ], [ %r1124321, %pic.hit.overflow.220 ], [ %r1149, %pic.prefix.hit.208 ], [ %r1167, %pic.desc.prefix.hit.213 ], [ %r1206, %pic.way.live.224 ], [ %r1212315, %pic.miss.call.216 ]
  br label %pget.recv_merge.200

pic.recv_hdr.218:                                 ; preds = %pget.recv_ok.197
  %r1092 = sub nuw nsw i64 %r1081, 8
  %r1093 = inttoptr i64 %r1092 to ptr
  %r1094 = load i8, ptr %r1093, align 1
  %r1095 = icmp eq i8 %r1094, 2
  %r1096 = sub nuw nsw i64 %r1081, 6
  %r1097 = inttoptr i64 %r1096 to ptr
  %r1098 = load i16, ptr %r1097, align 2
  %r1099 = and i16 %r1098, 2048
  %r1100 = icmp eq i16 %r1099, 0
  %r1101 = load ptr, ptr @perry_ic_options_worker_ts__29, align 8
  %r1102 = icmp ne ptr %r1101, null
  %r1103 = and i1 %r1095, %r1100
  %r1104 = and i1 %r1103, %r1102
  br i1 %r1104, label %pic.token.219, label %pic.desc.classify.209

pic.token.219:                                    ; preds = %pic.recv_hdr.218
  %r1106 = add nuw nsw i64 %r1081, 4
  %r1107 = inttoptr i64 %r1106 to ptr
  %r1108 = load i32, ptr %r1107, align 4
  %r1109 = zext i32 %r1108 to i64
  %r1110 = or i64 %r1109, 4611686018427387904
  %r1111 = icmp ne i32 %r1108, 0
  %r1112 = getelementptr i64, ptr %r1101, i64 0
  %r1113 = load i64, ptr %r1112, align 8
  %r1114 = icmp eq i64 %r1110, %r1113
  %r1115 = and i1 %r1114, %r1111
  br i1 %r1115, label %pic.hit.203, label %pic.prefix.guard.205

pic.hit.overflow.220:                             ; preds = %pic.hit.203
  %r1120 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r1121 = bitcast double %r1120 to i64
  %r1122 = and i64 %r1121, 281474976710655
  %r1123 = trunc i64 %r1117 to i32
  %statepoint_token320 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1081, i64 %r1122, i32 %r1123, ptr @perry_ic_options_worker_ts__29, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated299, ptr addrspace(1) %rs4gc.s8.relocated300, ptr addrspace(1) %rs4gc.s17, ptr addrspace(1) %rs4gc.s9.relocated301) ]
  %r1124321 = call double @llvm.experimental.gc.result.f64(token %statepoint_token320)
  %rs4gc.s11.relocated322 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token320, i32 0, i32 0) ; (%rs4gc.s11.relocated299, %rs4gc.s11.relocated299)
  %rs4gc.s8.relocated323 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token320, i32 1, i32 1) ; (%rs4gc.s8.relocated300, %rs4gc.s8.relocated300)
  %rs4gc.s17.relocated324 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token320, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  %rs4gc.s9.relocated325 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token320, i32 3, i32 3) ; (%rs4gc.s9.relocated301, %rs4gc.s9.relocated301)
  br label %pic.merge.217

pic.hit.inline.221:                               ; preds = %pic.hit.203
  %r1125 = shl i64 %r1117, 3
  %r1126 = add nuw nsw i64 %r1081, 16
  %r1127 = add i64 %r1126, %r1125
  %r1128 = inttoptr i64 %r1127 to ptr
  %r1129 = load double, ptr %r1128, align 8
  %r1130 = bitcast double %r1129 to i64
  %r1131 = icmp eq i64 %r1130, 9222246136947933200
  br i1 %r1131, label %pic.miss.214, label %pic.hit.live.204

pic.ways.222:                                     ; preds = %pic.miss.214
  %r1171 = getelementptr i64, ptr %r1101, i64 4
  %r1172 = load i64, ptr %r1171, align 8
  %r1173 = icmp eq i64 %r1172, %r1110
  %r1174 = getelementptr i64, ptr %r1101, i64 5
  %r1175 = load i64, ptr %r1174, align 8
  %r1176 = select i1 %r1173, i64 %r1175, i64 0
  %r1177 = getelementptr i64, ptr %r1101, i64 6
  %r1178 = load i64, ptr %r1177, align 8
  %r1179 = icmp eq i64 %r1178, %r1110
  %r1180 = getelementptr i64, ptr %r1101, i64 7
  %r1181 = load i64, ptr %r1180, align 8
  %r1182 = select i1 %r1179, i64 %r1181, i64 0
  %r1183 = getelementptr i64, ptr %r1101, i64 8
  %r1184 = load i64, ptr %r1183, align 8
  %r1185 = icmp eq i64 %r1184, %r1110
  %r1186 = getelementptr i64, ptr %r1101, i64 9
  %r1187 = load i64, ptr %r1186, align 8
  %r1188 = select i1 %r1185, i64 %r1187, i64 0
  %r1189 = getelementptr i64, ptr %r1101, i64 10
  %r1190 = load i64, ptr %r1189, align 8
  %r1191 = icmp eq i64 %r1190, %r1110
  %r1192 = getelementptr i64, ptr %r1101, i64 11
  %r1193 = load i64, ptr %r1192, align 8
  %r1194 = select i1 %r1191, i64 %r1193, i64 0
  %r1195 = or i1 %r1173, %r1179
  %r1196 = select i1 %r1173, i64 %r1176, i64 %r1182
  %r1197 = or i1 %r1185, %r1191
  %r1198 = select i1 %r1185, i64 %r1188, i64 %r1194
  %r1199 = or i1 %r1195, %r1197
  %r1200 = select i1 %r1195, i64 %r1196, i64 %r1198
  %r1201 = and i1 %r1111, %r1199
  br i1 %r1201, label %pic.way.load.223, label %pic.miss.call.216

pic.way.load.223:                                 ; preds = %pic.ways.222
  %r1202 = shl i64 %r1200, 3
  %r1203 = add nuw nsw i64 %r1081, 16
  %r1204 = add i64 %r1203, %r1202
  %r1205 = inttoptr i64 %r1204 to ptr
  %r1206 = load double, ptr %r1205, align 8
  %r1207 = bitcast double %r1206 to i64
  %r1208 = icmp eq i64 %r1207, 9222246136947933200
  br i1 %r1208, label %pic.miss.call.216, label %pic.way.live.224

pic.way.live.224:                                 ; preds = %pic.way.load.223
  br label %pic.merge.217

pget.throw_nullish.225:                           ; preds = %pget.recv_bad.198
  %r1217 = zext i1 %r1215 to i32
  %statepoint_token326 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1217, ptr @options_worker_ts_.str.20.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.226:                       ; preds = %pget.recv_bad.198
  %r1218 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r1219 = bitcast double %r1218 to i64
  %r1220 = and i64 %r1219, 281474976710655
  %statepoint_token327 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1080, i64 %r1220, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated299, ptr addrspace(1) %rs4gc.s8.relocated300, ptr addrspace(1) %rs4gc.s17, ptr addrspace(1) %rs4gc.s9.relocated301) ]
  %r1221328 = call double @llvm.experimental.gc.result.f64(token %statepoint_token327)
  %rs4gc.s11.relocated329 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token327, i32 0, i32 0) ; (%rs4gc.s11.relocated299, %rs4gc.s11.relocated299)
  %rs4gc.s8.relocated330 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token327, i32 1, i32 1) ; (%rs4gc.s8.relocated300, %rs4gc.s8.relocated300)
  %rs4gc.s17.relocated331 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token327, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  %rs4gc.s9.relocated332 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token327, i32 3, i32 3) ; (%rs4gc.s9.relocated301, %rs4gc.s9.relocated301)
  br label %pget.recv_merge.200

shadow.root.barrier.227:                          ; preds = %pget.recv_merge.200
  call void @js_write_barrier_root_nanbox(i64 %r1228) #9
  br label %shadow.root.barrier.done.228

shadow.root.barrier.done.228:                     ; preds = %shadow.root.barrier.227, %pget.recv_merge.200
  %r1231.rs4i = ptrtoint ptr addrspace(1) %.7485 to i64
  %r1231.rs4o = call i64 asm "", "=r,0"(i64 %r1231.rs4i) #9
  %r1231 = bitcast i64 %r1231.rs4o to double
  %r1232 = bitcast double %r1231 to i64
  %r1233 = and i64 %r1232, 281474976710655
  %r1234 = lshr i64 %r1232, 48
  %r1235 = and i64 %r1234, 65533
  %r1236 = icmp eq i64 %r1235, 32765
  br i1 %r1236, label %pget.recv_ok.230, label %pget.recv_other.234

pget.recv_sso.229:                                ; preds = %pget.recv_other.234
  %r1374 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r1375 = bitcast double %r1374 to i64
  %r1376 = and i64 %r1375, 281474976710655
  %statepoint_token333 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1232, i64 %r1376, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6493, ptr addrspace(1) %.7, ptr addrspace(1) %.0511, ptr addrspace(1) %rs4gc.s18) ]
  %r1377334 = call double @llvm.experimental.gc.result.f64(token %statepoint_token333)
  %rs4gc.s11.relocated335 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token333, i32 0, i32 0) ; (%.6493, %.6493)
  %rs4gc.s8.relocated336 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token333, i32 1, i32 1) ; (%.7, %.7)
  %rs4gc.s17.relocated337 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token333, i32 2, i32 2) ; (%.0511, %.0511)
  %rs4gc.s18.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token333, i32 3, i32 3) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pget.recv_merge.233

pget.recv_ok.230:                                 ; preds = %shadow.root.barrier.done.228
  %r1243 = icmp ugt i64 %r1233, 1048575
  br i1 %r1243, label %pic.recv_hdr.251, label %pic.miss.cold.248

pget.recv_bad.231:                                ; preds = %pget.check_class_ref.235
  %r1366 = icmp eq i64 %r1232, 9222246136947933185
  %r1367 = icmp eq i64 %r1232, 9222246136947933186
  %r1368 = or i1 %r1366, %r1367
  br i1 %r1368, label %pget.throw_nullish.258, label %pget.recv_undef_return.259

pget.recv_class_ref.232:                          ; preds = %pget.check_class_ref.235
  %r1239 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r1240 = bitcast double %r1239 to i64
  %r1241 = and i64 %r1240, 281474976710655
  %statepoint_token338 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532894, i64 %r1232, i64 %r1241, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6493, ptr addrspace(1) %.7, ptr addrspace(1) %.0511, ptr addrspace(1) %rs4gc.s18) ]
  %r1242339 = call double @llvm.experimental.gc.result.f64(token %statepoint_token338)
  %rs4gc.s11.relocated340 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token338, i32 0, i32 0) ; (%.6493, %.6493)
  %rs4gc.s8.relocated341 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token338, i32 1, i32 1) ; (%.7, %.7)
  %rs4gc.s17.relocated342 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token338, i32 2, i32 2) ; (%.0511, %.0511)
  %rs4gc.s18.relocated343 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token338, i32 3, i32 3) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pget.recv_merge.233

pget.recv_merge.233:                              ; preds = %pget.recv_undef_return.259, %pic.merge.250, %pget.recv_class_ref.232, %pget.recv_sso.229
  %.0516 = phi ptr addrspace(1) [ %.1517, %pic.merge.250 ], [ %rs4gc.s18.relocated, %pget.recv_sso.229 ], [ %rs4gc.s18.relocated343, %pget.recv_class_ref.232 ], [ %rs4gc.s18.relocated362, %pget.recv_undef_return.259 ]
  %.2513 = phi ptr addrspace(1) [ %.3514, %pic.merge.250 ], [ %rs4gc.s17.relocated337, %pget.recv_sso.229 ], [ %rs4gc.s17.relocated342, %pget.recv_class_ref.232 ], [ %rs4gc.s17.relocated361, %pget.recv_undef_return.259 ]
  %.8495 = phi ptr addrspace(1) [ %.9496, %pic.merge.250 ], [ %rs4gc.s11.relocated335, %pget.recv_sso.229 ], [ %rs4gc.s11.relocated340, %pget.recv_class_ref.232 ], [ %rs4gc.s11.relocated359, %pget.recv_undef_return.259 ]
  %.9 = phi ptr addrspace(1) [ %.10, %pic.merge.250 ], [ %rs4gc.s8.relocated336, %pget.recv_sso.229 ], [ %rs4gc.s8.relocated341, %pget.recv_class_ref.232 ], [ %rs4gc.s8.relocated360, %pget.recv_undef_return.259 ]
  %r1378 = phi double [ %r1365, %pic.merge.250 ], [ %r1373358, %pget.recv_undef_return.259 ], [ %r1377334, %pget.recv_sso.229 ], [ %r1242339, %pget.recv_class_ref.232 ]
  %r1379.rs4i = ptrtoint ptr addrspace(1) %.0516 to i64
  %r1379 = call i64 asm "", "=r,0"(i64 %r1379.rs4i) #9
  %r1380 = bitcast i64 %r1379 to double
  %r1381 = and i64 %r1379, -281474976710656
  %r1382 = icmp ult i64 %r1381, 9221401712017801216
  %r1383 = icmp ugt i64 %r1381, 9223090561878065152
  %r1384 = or i1 %r1382, %r1383
  %r1385 = bitcast double %r1378 to i64
  %r1386 = and i64 %r1385, -281474976710656
  %r1387 = icmp ult i64 %r1386, 9221401712017801216
  %r1388 = icmp ugt i64 %r1386, 9223090561878065152
  %r1389 = or i1 %r1387, %r1388
  %r1390 = and i1 %r1384, %r1389
  br i1 %r1390, label %guarded_arith.numeric.260, label %guarded_arith.dynamic.261

pget.recv_other.234:                              ; preds = %shadow.root.barrier.done.228
  %r1237 = icmp eq i64 %r1234, 32761
  br i1 %r1237, label %pget.recv_sso.229, label %pget.check_class_ref.235

pget.check_class_ref.235:                         ; preds = %pget.recv_other.234
  %r1238 = icmp eq i64 %r1234, 32766
  br i1 %r1238, label %pget.recv_class_ref.232, label %pget.recv_bad.231

pic.hit.236:                                      ; preds = %pic.token.252
  %r1268 = getelementptr i64, ptr %r1253, i64 1
  %r1269 = load i64, ptr %r1268, align 8
  %r1270 = and i64 %r1269, 1073741824
  %r1271 = icmp ne i64 %r1270, 0
  br i1 %r1271, label %pic.hit.overflow.253, label %pic.hit.inline.254

pic.hit.live.237:                                 ; preds = %pic.hit.inline.254
  br label %pic.merge.250

pic.prefix.guard.238:                             ; preds = %pic.token.252
  %r1284 = getelementptr i64, ptr %r1253, i64 2
  %r1285 = load i64, ptr %r1284, align 8
  %r1286 = icmp ne i64 %r1285, 0
  br i1 %r1286, label %pic.prefix.meta.239, label %pic.miss.247

pic.prefix.meta.239:                              ; preds = %pic.prefix.guard.238
  %r1287 = add nuw nsw i64 %r1233, 8
  %r1288 = inttoptr i64 %r1287 to ptr
  %r1289 = load i64, ptr %r1288, align 8
  %r1290 = icmp ne i64 %r1289, 0
  br i1 %r1290, label %pic.prefix.token.240, label %pic.miss.247

pic.prefix.token.240:                             ; preds = %pic.prefix.meta.239
  %r1291 = inttoptr i64 %r1289 to ptr
  %r1292 = getelementptr i64, ptr %r1291, i64 6
  %r1293 = load i64, ptr %r1292, align 8
  %r1294 = icmp eq i64 %r1293, %r1285
  br i1 %r1294, label %pic.prefix.hit.241, label %pic.miss.247

pic.prefix.hit.241:                               ; preds = %pic.prefix.token.240
  %r1295 = getelementptr i64, ptr %r1253, i64 1
  %r1296 = load i64, ptr %r1295, align 8
  %r1297 = shl i64 %r1296, 3
  %r1298 = add nuw nsw i64 %r1233, 16
  %r1299 = add i64 %r1298, %r1297
  %r1300 = inttoptr i64 %r1299 to ptr
  %r1301 = load double, ptr %r1300, align 8
  br label %pic.merge.250

pic.desc.classify.242:                            ; preds = %pic.recv_hdr.251
  %r1257 = and i1 %r1247, %r1254
  br i1 %r1257, label %pic.desc.prefix.guard.243, label %pic.miss.cold.248

pic.desc.prefix.guard.243:                        ; preds = %pic.desc.classify.242
  %r1302 = getelementptr i64, ptr %r1253, i64 2
  %r1303 = load i64, ptr %r1302, align 8
  %r1304 = icmp ne i64 %r1303, 0
  br i1 %r1304, label %pic.desc.prefix.meta.244, label %pic.miss.cold.248

pic.desc.prefix.meta.244:                         ; preds = %pic.desc.prefix.guard.243
  %r1305 = add nuw nsw i64 %r1233, 8
  %r1306 = inttoptr i64 %r1305 to ptr
  %r1307 = load i64, ptr %r1306, align 8
  %r1308 = icmp ne i64 %r1307, 0
  br i1 %r1308, label %pic.desc.prefix.token.245, label %pic.miss.cold.248

pic.desc.prefix.token.245:                        ; preds = %pic.desc.prefix.meta.244
  %r1309 = inttoptr i64 %r1307 to ptr
  %r1310 = getelementptr i64, ptr %r1309, i64 6
  %r1311 = load i64, ptr %r1310, align 8
  %r1312 = icmp eq i64 %r1311, %r1303
  br i1 %r1312, label %pic.desc.prefix.hit.246, label %pic.miss.cold.248

pic.desc.prefix.hit.246:                          ; preds = %pic.desc.prefix.token.245
  %r1313 = getelementptr i64, ptr %r1253, i64 1
  %r1314 = load i64, ptr %r1313, align 8
  %r1315 = shl i64 %r1314, 3
  %r1316 = add nuw nsw i64 %r1233, 16
  %r1317 = add i64 %r1316, %r1315
  %r1318 = inttoptr i64 %r1317 to ptr
  %r1319 = load double, ptr %r1318, align 8
  br label %pic.merge.250

pic.miss.247:                                     ; preds = %pic.hit.inline.254, %pic.prefix.token.240, %pic.prefix.meta.239, %pic.prefix.guard.238
  %r1320 = getelementptr i64, ptr %r1253, i64 3
  %r1321 = load i64, ptr %r1320, align 8
  %r1322 = icmp sgt i64 %r1321, 0
  br i1 %r1322, label %pic.ways.255, label %pic.miss.call.249

pic.miss.cold.248:                                ; preds = %pic.desc.prefix.token.245, %pic.desc.prefix.meta.244, %pic.desc.prefix.guard.243, %pic.desc.classify.242, %pget.recv_ok.230
  br label %pic.miss.call.249

pic.miss.call.249:                                ; preds = %pic.way.load.256, %pic.ways.255, %pic.miss.cold.248, %pic.miss.247
  %r1361 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r1362 = bitcast double %r1361 to i64
  %r1363 = and i64 %r1362, 281474976710655
  %statepoint_token344 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1233, i64 %r1363, ptr @perry_ic_options_worker_ts__31, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6493, ptr addrspace(1) %.7, ptr addrspace(1) %.0511, ptr addrspace(1) %rs4gc.s18) ]
  %r1364345 = call double @llvm.experimental.gc.result.f64(token %statepoint_token344)
  %rs4gc.s11.relocated346 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token344, i32 0, i32 0) ; (%.6493, %.6493)
  %rs4gc.s8.relocated347 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token344, i32 1, i32 1) ; (%.7, %.7)
  %rs4gc.s17.relocated348 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token344, i32 2, i32 2) ; (%.0511, %.0511)
  %rs4gc.s18.relocated349 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token344, i32 3, i32 3) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pic.merge.250

pic.merge.250:                                    ; preds = %pic.way.live.257, %pic.hit.overflow.253, %pic.miss.call.249, %pic.desc.prefix.hit.246, %pic.prefix.hit.241, %pic.hit.live.237
  %.1517 = phi ptr addrspace(1) [ %rs4gc.s18.relocated355, %pic.hit.overflow.253 ], [ %rs4gc.s18.relocated349, %pic.miss.call.249 ], [ %rs4gc.s18, %pic.way.live.257 ], [ %rs4gc.s18, %pic.hit.live.237 ], [ %rs4gc.s18, %pic.prefix.hit.241 ], [ %rs4gc.s18, %pic.desc.prefix.hit.246 ]
  %.3514 = phi ptr addrspace(1) [ %rs4gc.s17.relocated354, %pic.hit.overflow.253 ], [ %rs4gc.s17.relocated348, %pic.miss.call.249 ], [ %.0511, %pic.way.live.257 ], [ %.0511, %pic.hit.live.237 ], [ %.0511, %pic.prefix.hit.241 ], [ %.0511, %pic.desc.prefix.hit.246 ]
  %.9496 = phi ptr addrspace(1) [ %rs4gc.s11.relocated352, %pic.hit.overflow.253 ], [ %rs4gc.s11.relocated346, %pic.miss.call.249 ], [ %.6493, %pic.way.live.257 ], [ %.6493, %pic.hit.live.237 ], [ %.6493, %pic.prefix.hit.241 ], [ %.6493, %pic.desc.prefix.hit.246 ]
  %.10 = phi ptr addrspace(1) [ %rs4gc.s8.relocated353, %pic.hit.overflow.253 ], [ %rs4gc.s8.relocated347, %pic.miss.call.249 ], [ %.7, %pic.way.live.257 ], [ %.7, %pic.hit.live.237 ], [ %.7, %pic.prefix.hit.241 ], [ %.7, %pic.desc.prefix.hit.246 ]
  %r1365 = phi double [ %r1281, %pic.hit.live.237 ], [ %r1276351, %pic.hit.overflow.253 ], [ %r1301, %pic.prefix.hit.241 ], [ %r1319, %pic.desc.prefix.hit.246 ], [ %r1358, %pic.way.live.257 ], [ %r1364345, %pic.miss.call.249 ]
  br label %pget.recv_merge.233

pic.recv_hdr.251:                                 ; preds = %pget.recv_ok.230
  %r1244 = sub nuw nsw i64 %r1233, 8
  %r1245 = inttoptr i64 %r1244 to ptr
  %r1246 = load i8, ptr %r1245, align 1
  %r1247 = icmp eq i8 %r1246, 2
  %r1248 = sub nuw nsw i64 %r1233, 6
  %r1249 = inttoptr i64 %r1248 to ptr
  %r1250 = load i16, ptr %r1249, align 2
  %r1251 = and i16 %r1250, 2048
  %r1252 = icmp eq i16 %r1251, 0
  %r1253 = load ptr, ptr @perry_ic_options_worker_ts__31, align 8
  %r1254 = icmp ne ptr %r1253, null
  %r1255 = and i1 %r1247, %r1252
  %r1256 = and i1 %r1255, %r1254
  br i1 %r1256, label %pic.token.252, label %pic.desc.classify.242

pic.token.252:                                    ; preds = %pic.recv_hdr.251
  %r1258 = add nuw nsw i64 %r1233, 4
  %r1259 = inttoptr i64 %r1258 to ptr
  %r1260 = load i32, ptr %r1259, align 4
  %r1261 = zext i32 %r1260 to i64
  %r1262 = or i64 %r1261, 4611686018427387904
  %r1263 = icmp ne i32 %r1260, 0
  %r1264 = getelementptr i64, ptr %r1253, i64 0
  %r1265 = load i64, ptr %r1264, align 8
  %r1266 = icmp eq i64 %r1262, %r1265
  %r1267 = and i1 %r1266, %r1263
  br i1 %r1267, label %pic.hit.236, label %pic.prefix.guard.238

pic.hit.overflow.253:                             ; preds = %pic.hit.236
  %r1272 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r1273 = bitcast double %r1272 to i64
  %r1274 = and i64 %r1273, 281474976710655
  %r1275 = trunc i64 %r1269 to i32
  %statepoint_token350 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1233, i64 %r1274, i32 %r1275, ptr @perry_ic_options_worker_ts__31, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6493, ptr addrspace(1) %.7, ptr addrspace(1) %.0511, ptr addrspace(1) %rs4gc.s18) ]
  %r1276351 = call double @llvm.experimental.gc.result.f64(token %statepoint_token350)
  %rs4gc.s11.relocated352 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token350, i32 0, i32 0) ; (%.6493, %.6493)
  %rs4gc.s8.relocated353 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token350, i32 1, i32 1) ; (%.7, %.7)
  %rs4gc.s17.relocated354 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token350, i32 2, i32 2) ; (%.0511, %.0511)
  %rs4gc.s18.relocated355 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token350, i32 3, i32 3) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pic.merge.250

pic.hit.inline.254:                               ; preds = %pic.hit.236
  %r1277 = shl i64 %r1269, 3
  %r1278 = add nuw nsw i64 %r1233, 16
  %r1279 = add i64 %r1278, %r1277
  %r1280 = inttoptr i64 %r1279 to ptr
  %r1281 = load double, ptr %r1280, align 8
  %r1282 = bitcast double %r1281 to i64
  %r1283 = icmp eq i64 %r1282, 9222246136947933200
  br i1 %r1283, label %pic.miss.247, label %pic.hit.live.237

pic.ways.255:                                     ; preds = %pic.miss.247
  %r1323 = getelementptr i64, ptr %r1253, i64 4
  %r1324 = load i64, ptr %r1323, align 8
  %r1325 = icmp eq i64 %r1324, %r1262
  %r1326 = getelementptr i64, ptr %r1253, i64 5
  %r1327 = load i64, ptr %r1326, align 8
  %r1328 = select i1 %r1325, i64 %r1327, i64 0
  %r1329 = getelementptr i64, ptr %r1253, i64 6
  %r1330 = load i64, ptr %r1329, align 8
  %r1331 = icmp eq i64 %r1330, %r1262
  %r1332 = getelementptr i64, ptr %r1253, i64 7
  %r1333 = load i64, ptr %r1332, align 8
  %r1334 = select i1 %r1331, i64 %r1333, i64 0
  %r1335 = getelementptr i64, ptr %r1253, i64 8
  %r1336 = load i64, ptr %r1335, align 8
  %r1337 = icmp eq i64 %r1336, %r1262
  %r1338 = getelementptr i64, ptr %r1253, i64 9
  %r1339 = load i64, ptr %r1338, align 8
  %r1340 = select i1 %r1337, i64 %r1339, i64 0
  %r1341 = getelementptr i64, ptr %r1253, i64 10
  %r1342 = load i64, ptr %r1341, align 8
  %r1343 = icmp eq i64 %r1342, %r1262
  %r1344 = getelementptr i64, ptr %r1253, i64 11
  %r1345 = load i64, ptr %r1344, align 8
  %r1346 = select i1 %r1343, i64 %r1345, i64 0
  %r1347 = or i1 %r1325, %r1331
  %r1348 = select i1 %r1325, i64 %r1328, i64 %r1334
  %r1349 = or i1 %r1337, %r1343
  %r1350 = select i1 %r1337, i64 %r1340, i64 %r1346
  %r1351 = or i1 %r1347, %r1349
  %r1352 = select i1 %r1347, i64 %r1348, i64 %r1350
  %r1353 = and i1 %r1263, %r1351
  br i1 %r1353, label %pic.way.load.256, label %pic.miss.call.249

pic.way.load.256:                                 ; preds = %pic.ways.255
  %r1354 = shl i64 %r1352, 3
  %r1355 = add nuw nsw i64 %r1233, 16
  %r1356 = add i64 %r1355, %r1354
  %r1357 = inttoptr i64 %r1356 to ptr
  %r1358 = load double, ptr %r1357, align 8
  %r1359 = bitcast double %r1358 to i64
  %r1360 = icmp eq i64 %r1359, 9222246136947933200
  br i1 %r1360, label %pic.miss.call.249, label %pic.way.live.257

pic.way.live.257:                                 ; preds = %pic.way.load.256
  br label %pic.merge.250

pget.throw_nullish.258:                           ; preds = %pget.recv_bad.231
  %r1369 = zext i1 %r1367 to i32
  %statepoint_token356 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1369, ptr @options_worker_ts_.str.20.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.259:                       ; preds = %pget.recv_bad.231
  %r1370 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r1371 = bitcast double %r1370 to i64
  %r1372 = and i64 %r1371, 281474976710655
  %statepoint_token357 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1232, i64 %r1372, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6493, ptr addrspace(1) %.7, ptr addrspace(1) %.0511, ptr addrspace(1) %rs4gc.s18) ]
  %r1373358 = call double @llvm.experimental.gc.result.f64(token %statepoint_token357)
  %rs4gc.s11.relocated359 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token357, i32 0, i32 0) ; (%.6493, %.6493)
  %rs4gc.s8.relocated360 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token357, i32 1, i32 1) ; (%.7, %.7)
  %rs4gc.s17.relocated361 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token357, i32 2, i32 2) ; (%.0511, %.0511)
  %rs4gc.s18.relocated362 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token357, i32 3, i32 3) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pget.recv_merge.233

guarded_arith.numeric.260:                        ; preds = %pget.recv_merge.233
  %r1391 = fsub double %r1380, %r1378
  br label %guarded_arith.merge.262

guarded_arith.dynamic.261:                        ; preds = %pget.recv_merge.233
  %statepoint_token363 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_sub, i32 2, i32 0, double %r1380, double %r1378, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.8495, ptr addrspace(1) %.9, ptr addrspace(1) %.2513) ]
  %r1392364 = call double @llvm.experimental.gc.result.f64(token %statepoint_token363)
  %rs4gc.s11.relocated365 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token363, i32 0, i32 0) ; (%.8495, %.8495)
  %rs4gc.s8.relocated366 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token363, i32 1, i32 1) ; (%.9, %.9)
  %rs4gc.s17.relocated367 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token363, i32 2, i32 2) ; (%.2513, %.2513)
  br label %guarded_arith.merge.262

guarded_arith.merge.262:                          ; preds = %guarded_arith.dynamic.261, %guarded_arith.numeric.260
  %.4515 = phi ptr addrspace(1) [ %.2513, %guarded_arith.numeric.260 ], [ %rs4gc.s17.relocated367, %guarded_arith.dynamic.261 ]
  %.10497 = phi ptr addrspace(1) [ %.8495, %guarded_arith.numeric.260 ], [ %rs4gc.s11.relocated365, %guarded_arith.dynamic.261 ]
  %.11 = phi ptr addrspace(1) [ %.9, %guarded_arith.numeric.260 ], [ %rs4gc.s8.relocated366, %guarded_arith.dynamic.261 ]
  %r1393 = phi double [ %r1391, %guarded_arith.numeric.260 ], [ %r1392364, %guarded_arith.dynamic.261 ]
  %r1394.rs4i = ptrtoint ptr addrspace(1) %.4515 to i64
  %r1394 = call i64 asm "", "=r,0"(i64 %r1394.rs4i) #9
  %statepoint_token368 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1394, double %r1393, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10497, ptr addrspace(1) %.11) ]
  %r1395369 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token368)
  %rs4gc.s11.relocated370 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token368, i32 0, i32 0) ; (%.10497, %.10497)
  %rs4gc.s8.relocated371 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token368, i32 1, i32 1) ; (%.11, %.11)
  %rs4gc.s19 = inttoptr i64 %r1395369 to ptr addrspace(1)
  %r1396.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19 to i64
  %r1396 = call i64 asm "", "=r,0"(i64 %r1396.rs4i) #9
  %r1397 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1398 = icmp ne i32 %r1397, 0
  br i1 %r1398, label %shadow.root.barrier.263, label %shadow.root.barrier.done.264

shadow.root.barrier.263:                          ; preds = %guarded_arith.merge.262
  call void @js_write_barrier_root_nanbox(i64 %r1396) #9
  br label %shadow.root.barrier.done.264

shadow.root.barrier.done.264:                     ; preds = %shadow.root.barrier.263, %guarded_arith.merge.262
  %r1399.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8.relocated371 to i64
  %r1399.rs4o = call i64 asm "", "=r,0"(i64 %r1399.rs4i) #9
  %r1399 = bitcast i64 %r1399.rs4o to double
  %r1400.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19 to i64
  %r1400 = call i64 asm "", "=r,0"(i64 %r1400.rs4i) #9
  %statepoint_token372 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1400, double %r1399, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated370) ]
  %r1401373 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token372)
  %rs4gc.s11.relocated374 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token372, i32 0, i32 0) ; (%rs4gc.s11.relocated370, %rs4gc.s11.relocated370)
  %rs4gc.s20 = inttoptr i64 %r1401373 to ptr addrspace(1)
  %r1402.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20 to i64
  %r1402 = call i64 asm "", "=r,0"(i64 %r1402.rs4i) #9
  %r1403 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1404 = icmp ne i32 %r1403, 0
  br i1 %r1404, label %shadow.root.barrier.265, label %shadow.root.barrier.done.266

shadow.root.barrier.265:                          ; preds = %shadow.root.barrier.done.264
  call void @js_write_barrier_root_nanbox(i64 %r1402) #9
  br label %shadow.root.barrier.done.266

shadow.root.barrier.done.266:                     ; preds = %shadow.root.barrier.265, %shadow.root.barrier.done.264
  %statepoint_token375 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_process_memory_usage, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated374, ptr addrspace(1) %rs4gc.s20) ]
  %r1405376 = call double @llvm.experimental.gc.result.f64(token %statepoint_token375)
  %rs4gc.s11.relocated377 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token375, i32 0, i32 0) ; (%rs4gc.s11.relocated374, %rs4gc.s11.relocated374)
  %rs4gc.s20.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token375, i32 1, i32 1) ; (%rs4gc.s20, %rs4gc.s20)
  %r1406 = bitcast double %r1405376 to i64
  %r1407 = and i64 %r1406, 281474976710655
  %r1408 = lshr i64 %r1406, 48
  %r1409 = and i64 %r1408, 65533
  %r1410 = icmp eq i64 %r1409, 32765
  br i1 %r1410, label %pget.recv_ok.268, label %pget.recv_other.272

pget.recv_sso.267:                                ; preds = %pget.recv_other.272
  %r1548 = load double, ptr @options_worker_ts_.str.17.handle, align 8
  %r1549 = bitcast double %r1548 to i64
  %r1550 = and i64 %r1549, 281474976710655
  %statepoint_token378 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1406, i64 %r1550, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated377, ptr addrspace(1) %rs4gc.s20.relocated) ]
  %r1551379 = call double @llvm.experimental.gc.result.f64(token %statepoint_token378)
  %rs4gc.s11.relocated380 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token378, i32 0, i32 0) ; (%rs4gc.s11.relocated377, %rs4gc.s11.relocated377)
  %rs4gc.s20.relocated381 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token378, i32 1, i32 1) ; (%rs4gc.s20.relocated, %rs4gc.s20.relocated)
  br label %pget.recv_merge.271

pget.recv_ok.268:                                 ; preds = %shadow.root.barrier.done.266
  %r1417 = icmp ugt i64 %r1407, 1048575
  br i1 %r1417, label %pic.recv_hdr.289, label %pic.miss.cold.286

pget.recv_bad.269:                                ; preds = %pget.check_class_ref.273
  %r1540 = icmp eq i64 %r1406, 9222246136947933185
  %r1541 = icmp eq i64 %r1406, 9222246136947933186
  %r1542 = or i1 %r1540, %r1541
  br i1 %r1542, label %pget.throw_nullish.296, label %pget.recv_undef_return.297

pget.recv_class_ref.270:                          ; preds = %pget.check_class_ref.273
  %r1413 = load double, ptr @options_worker_ts_.str.17.handle, align 8
  %r1414 = bitcast double %r1413 to i64
  %r1415 = and i64 %r1414, 281474976710655
  %statepoint_token382 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532896, i64 %r1406, i64 %r1415, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated377, ptr addrspace(1) %rs4gc.s20.relocated) ]
  %r1416383 = call double @llvm.experimental.gc.result.f64(token %statepoint_token382)
  %rs4gc.s11.relocated384 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token382, i32 0, i32 0) ; (%rs4gc.s11.relocated377, %rs4gc.s11.relocated377)
  %rs4gc.s20.relocated385 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token382, i32 1, i32 1) ; (%rs4gc.s20.relocated, %rs4gc.s20.relocated)
  br label %pget.recv_merge.271

pget.recv_merge.271:                              ; preds = %pget.recv_undef_return.297, %pic.merge.288, %pget.recv_class_ref.270, %pget.recv_sso.267
  %.0518 = phi ptr addrspace(1) [ %.1519, %pic.merge.288 ], [ %rs4gc.s20.relocated381, %pget.recv_sso.267 ], [ %rs4gc.s20.relocated385, %pget.recv_class_ref.270 ], [ %rs4gc.s20.relocated401, %pget.recv_undef_return.297 ]
  %.11498 = phi ptr addrspace(1) [ %.12, %pic.merge.288 ], [ %rs4gc.s11.relocated380, %pget.recv_sso.267 ], [ %rs4gc.s11.relocated384, %pget.recv_class_ref.270 ], [ %rs4gc.s11.relocated400, %pget.recv_undef_return.297 ]
  %r1552 = phi double [ %r1539, %pic.merge.288 ], [ %r1547399, %pget.recv_undef_return.297 ], [ %r1551379, %pget.recv_sso.267 ], [ %r1416383, %pget.recv_class_ref.270 ]
  %r1553.rs4i = ptrtoint ptr addrspace(1) %.0518 to i64
  %r1553 = call i64 asm "", "=r,0"(i64 %r1553.rs4i) #9
  %statepoint_token386 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1553, double %r1552, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11498) ]
  %r1554387 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token386)
  %rs4gc.s11.relocated388 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token386, i32 0, i32 0) ; (%.11498, %.11498)
  %rs4gc.s21 = inttoptr i64 %r1554387 to ptr addrspace(1)
  %r1555.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r1555 = call i64 asm "", "=r,0"(i64 %r1555.rs4i) #9
  %r1556 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1557 = icmp ne i32 %r1556, 0
  br i1 %r1557, label %shadow.root.barrier.298, label %shadow.root.barrier.done.299

pget.recv_other.272:                              ; preds = %shadow.root.barrier.done.266
  %r1411 = icmp eq i64 %r1408, 32761
  br i1 %r1411, label %pget.recv_sso.267, label %pget.check_class_ref.273

pget.check_class_ref.273:                         ; preds = %pget.recv_other.272
  %r1412 = icmp eq i64 %r1408, 32766
  br i1 %r1412, label %pget.recv_class_ref.270, label %pget.recv_bad.269

pic.hit.274:                                      ; preds = %pic.token.290
  %r1442 = getelementptr i64, ptr %r1427, i64 1
  %r1443 = load i64, ptr %r1442, align 8
  %r1444 = and i64 %r1443, 1073741824
  %r1445 = icmp ne i64 %r1444, 0
  br i1 %r1445, label %pic.hit.overflow.291, label %pic.hit.inline.292

pic.hit.live.275:                                 ; preds = %pic.hit.inline.292
  br label %pic.merge.288

pic.prefix.guard.276:                             ; preds = %pic.token.290
  %r1458 = getelementptr i64, ptr %r1427, i64 2
  %r1459 = load i64, ptr %r1458, align 8
  %r1460 = icmp ne i64 %r1459, 0
  br i1 %r1460, label %pic.prefix.meta.277, label %pic.miss.285

pic.prefix.meta.277:                              ; preds = %pic.prefix.guard.276
  %r1461 = add nuw nsw i64 %r1407, 8
  %r1462 = inttoptr i64 %r1461 to ptr
  %r1463 = load i64, ptr %r1462, align 8
  %r1464 = icmp ne i64 %r1463, 0
  br i1 %r1464, label %pic.prefix.token.278, label %pic.miss.285

pic.prefix.token.278:                             ; preds = %pic.prefix.meta.277
  %r1465 = inttoptr i64 %r1463 to ptr
  %r1466 = getelementptr i64, ptr %r1465, i64 6
  %r1467 = load i64, ptr %r1466, align 8
  %r1468 = icmp eq i64 %r1467, %r1459
  br i1 %r1468, label %pic.prefix.hit.279, label %pic.miss.285

pic.prefix.hit.279:                               ; preds = %pic.prefix.token.278
  %r1469 = getelementptr i64, ptr %r1427, i64 1
  %r1470 = load i64, ptr %r1469, align 8
  %r1471 = shl i64 %r1470, 3
  %r1472 = add nuw nsw i64 %r1407, 16
  %r1473 = add i64 %r1472, %r1471
  %r1474 = inttoptr i64 %r1473 to ptr
  %r1475 = load double, ptr %r1474, align 8
  br label %pic.merge.288

pic.desc.classify.280:                            ; preds = %pic.recv_hdr.289
  %r1431 = and i1 %r1421, %r1428
  br i1 %r1431, label %pic.desc.prefix.guard.281, label %pic.miss.cold.286

pic.desc.prefix.guard.281:                        ; preds = %pic.desc.classify.280
  %r1476 = getelementptr i64, ptr %r1427, i64 2
  %r1477 = load i64, ptr %r1476, align 8
  %r1478 = icmp ne i64 %r1477, 0
  br i1 %r1478, label %pic.desc.prefix.meta.282, label %pic.miss.cold.286

pic.desc.prefix.meta.282:                         ; preds = %pic.desc.prefix.guard.281
  %r1479 = add nuw nsw i64 %r1407, 8
  %r1480 = inttoptr i64 %r1479 to ptr
  %r1481 = load i64, ptr %r1480, align 8
  %r1482 = icmp ne i64 %r1481, 0
  br i1 %r1482, label %pic.desc.prefix.token.283, label %pic.miss.cold.286

pic.desc.prefix.token.283:                        ; preds = %pic.desc.prefix.meta.282
  %r1483 = inttoptr i64 %r1481 to ptr
  %r1484 = getelementptr i64, ptr %r1483, i64 6
  %r1485 = load i64, ptr %r1484, align 8
  %r1486 = icmp eq i64 %r1485, %r1477
  br i1 %r1486, label %pic.desc.prefix.hit.284, label %pic.miss.cold.286

pic.desc.prefix.hit.284:                          ; preds = %pic.desc.prefix.token.283
  %r1487 = getelementptr i64, ptr %r1427, i64 1
  %r1488 = load i64, ptr %r1487, align 8
  %r1489 = shl i64 %r1488, 3
  %r1490 = add nuw nsw i64 %r1407, 16
  %r1491 = add i64 %r1490, %r1489
  %r1492 = inttoptr i64 %r1491 to ptr
  %r1493 = load double, ptr %r1492, align 8
  br label %pic.merge.288

pic.miss.285:                                     ; preds = %pic.hit.inline.292, %pic.prefix.token.278, %pic.prefix.meta.277, %pic.prefix.guard.276
  %r1494 = getelementptr i64, ptr %r1427, i64 3
  %r1495 = load i64, ptr %r1494, align 8
  %r1496 = icmp sgt i64 %r1495, 0
  br i1 %r1496, label %pic.ways.293, label %pic.miss.call.287

pic.miss.cold.286:                                ; preds = %pic.desc.prefix.token.283, %pic.desc.prefix.meta.282, %pic.desc.prefix.guard.281, %pic.desc.classify.280, %pget.recv_ok.268
  br label %pic.miss.call.287

pic.miss.call.287:                                ; preds = %pic.way.load.294, %pic.ways.293, %pic.miss.cold.286, %pic.miss.285
  %r1535 = load double, ptr @options_worker_ts_.str.17.handle, align 8
  %r1536 = bitcast double %r1535 to i64
  %r1537 = and i64 %r1536, 281474976710655
  %statepoint_token389 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1407, i64 %r1537, ptr @perry_ic_options_worker_ts__33, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated377, ptr addrspace(1) %rs4gc.s20.relocated) ]
  %r1538390 = call double @llvm.experimental.gc.result.f64(token %statepoint_token389)
  %rs4gc.s11.relocated391 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token389, i32 0, i32 0) ; (%rs4gc.s11.relocated377, %rs4gc.s11.relocated377)
  %rs4gc.s20.relocated392 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token389, i32 1, i32 1) ; (%rs4gc.s20.relocated, %rs4gc.s20.relocated)
  br label %pic.merge.288

pic.merge.288:                                    ; preds = %pic.way.live.295, %pic.hit.overflow.291, %pic.miss.call.287, %pic.desc.prefix.hit.284, %pic.prefix.hit.279, %pic.hit.live.275
  %.1519 = phi ptr addrspace(1) [ %rs4gc.s20.relocated396, %pic.hit.overflow.291 ], [ %rs4gc.s20.relocated392, %pic.miss.call.287 ], [ %rs4gc.s20.relocated, %pic.way.live.295 ], [ %rs4gc.s20.relocated, %pic.hit.live.275 ], [ %rs4gc.s20.relocated, %pic.prefix.hit.279 ], [ %rs4gc.s20.relocated, %pic.desc.prefix.hit.284 ]
  %.12 = phi ptr addrspace(1) [ %rs4gc.s11.relocated395, %pic.hit.overflow.291 ], [ %rs4gc.s11.relocated391, %pic.miss.call.287 ], [ %rs4gc.s11.relocated377, %pic.way.live.295 ], [ %rs4gc.s11.relocated377, %pic.hit.live.275 ], [ %rs4gc.s11.relocated377, %pic.prefix.hit.279 ], [ %rs4gc.s11.relocated377, %pic.desc.prefix.hit.284 ]
  %r1539 = phi double [ %r1455, %pic.hit.live.275 ], [ %r1450394, %pic.hit.overflow.291 ], [ %r1475, %pic.prefix.hit.279 ], [ %r1493, %pic.desc.prefix.hit.284 ], [ %r1532, %pic.way.live.295 ], [ %r1538390, %pic.miss.call.287 ]
  br label %pget.recv_merge.271

pic.recv_hdr.289:                                 ; preds = %pget.recv_ok.268
  %r1418 = sub nuw nsw i64 %r1407, 8
  %r1419 = inttoptr i64 %r1418 to ptr
  %r1420 = load i8, ptr %r1419, align 1
  %r1421 = icmp eq i8 %r1420, 2
  %r1422 = sub nuw nsw i64 %r1407, 6
  %r1423 = inttoptr i64 %r1422 to ptr
  %r1424 = load i16, ptr %r1423, align 2
  %r1425 = and i16 %r1424, 2048
  %r1426 = icmp eq i16 %r1425, 0
  %r1427 = load ptr, ptr @perry_ic_options_worker_ts__33, align 8
  %r1428 = icmp ne ptr %r1427, null
  %r1429 = and i1 %r1421, %r1426
  %r1430 = and i1 %r1429, %r1428
  br i1 %r1430, label %pic.token.290, label %pic.desc.classify.280

pic.token.290:                                    ; preds = %pic.recv_hdr.289
  %r1432 = add nuw nsw i64 %r1407, 4
  %r1433 = inttoptr i64 %r1432 to ptr
  %r1434 = load i32, ptr %r1433, align 4
  %r1435 = zext i32 %r1434 to i64
  %r1436 = or i64 %r1435, 4611686018427387904
  %r1437 = icmp ne i32 %r1434, 0
  %r1438 = getelementptr i64, ptr %r1427, i64 0
  %r1439 = load i64, ptr %r1438, align 8
  %r1440 = icmp eq i64 %r1436, %r1439
  %r1441 = and i1 %r1440, %r1437
  br i1 %r1441, label %pic.hit.274, label %pic.prefix.guard.276

pic.hit.overflow.291:                             ; preds = %pic.hit.274
  %r1446 = load double, ptr @options_worker_ts_.str.17.handle, align 8
  %r1447 = bitcast double %r1446 to i64
  %r1448 = and i64 %r1447, 281474976710655
  %r1449 = trunc i64 %r1443 to i32
  %statepoint_token393 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1407, i64 %r1448, i32 %r1449, ptr @perry_ic_options_worker_ts__33, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated377, ptr addrspace(1) %rs4gc.s20.relocated) ]
  %r1450394 = call double @llvm.experimental.gc.result.f64(token %statepoint_token393)
  %rs4gc.s11.relocated395 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token393, i32 0, i32 0) ; (%rs4gc.s11.relocated377, %rs4gc.s11.relocated377)
  %rs4gc.s20.relocated396 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token393, i32 1, i32 1) ; (%rs4gc.s20.relocated, %rs4gc.s20.relocated)
  br label %pic.merge.288

pic.hit.inline.292:                               ; preds = %pic.hit.274
  %r1451 = shl i64 %r1443, 3
  %r1452 = add nuw nsw i64 %r1407, 16
  %r1453 = add i64 %r1452, %r1451
  %r1454 = inttoptr i64 %r1453 to ptr
  %r1455 = load double, ptr %r1454, align 8
  %r1456 = bitcast double %r1455 to i64
  %r1457 = icmp eq i64 %r1456, 9222246136947933200
  br i1 %r1457, label %pic.miss.285, label %pic.hit.live.275

pic.ways.293:                                     ; preds = %pic.miss.285
  %r1497 = getelementptr i64, ptr %r1427, i64 4
  %r1498 = load i64, ptr %r1497, align 8
  %r1499 = icmp eq i64 %r1498, %r1436
  %r1500 = getelementptr i64, ptr %r1427, i64 5
  %r1501 = load i64, ptr %r1500, align 8
  %r1502 = select i1 %r1499, i64 %r1501, i64 0
  %r1503 = getelementptr i64, ptr %r1427, i64 6
  %r1504 = load i64, ptr %r1503, align 8
  %r1505 = icmp eq i64 %r1504, %r1436
  %r1506 = getelementptr i64, ptr %r1427, i64 7
  %r1507 = load i64, ptr %r1506, align 8
  %r1508 = select i1 %r1505, i64 %r1507, i64 0
  %r1509 = getelementptr i64, ptr %r1427, i64 8
  %r1510 = load i64, ptr %r1509, align 8
  %r1511 = icmp eq i64 %r1510, %r1436
  %r1512 = getelementptr i64, ptr %r1427, i64 9
  %r1513 = load i64, ptr %r1512, align 8
  %r1514 = select i1 %r1511, i64 %r1513, i64 0
  %r1515 = getelementptr i64, ptr %r1427, i64 10
  %r1516 = load i64, ptr %r1515, align 8
  %r1517 = icmp eq i64 %r1516, %r1436
  %r1518 = getelementptr i64, ptr %r1427, i64 11
  %r1519 = load i64, ptr %r1518, align 8
  %r1520 = select i1 %r1517, i64 %r1519, i64 0
  %r1521 = or i1 %r1499, %r1505
  %r1522 = select i1 %r1499, i64 %r1502, i64 %r1508
  %r1523 = or i1 %r1511, %r1517
  %r1524 = select i1 %r1511, i64 %r1514, i64 %r1520
  %r1525 = or i1 %r1521, %r1523
  %r1526 = select i1 %r1521, i64 %r1522, i64 %r1524
  %r1527 = and i1 %r1437, %r1525
  br i1 %r1527, label %pic.way.load.294, label %pic.miss.call.287

pic.way.load.294:                                 ; preds = %pic.ways.293
  %r1528 = shl i64 %r1526, 3
  %r1529 = add nuw nsw i64 %r1407, 16
  %r1530 = add i64 %r1529, %r1528
  %r1531 = inttoptr i64 %r1530 to ptr
  %r1532 = load double, ptr %r1531, align 8
  %r1533 = bitcast double %r1532 to i64
  %r1534 = icmp eq i64 %r1533, 9222246136947933200
  br i1 %r1534, label %pic.miss.call.287, label %pic.way.live.295

pic.way.live.295:                                 ; preds = %pic.way.load.294
  br label %pic.merge.288

pget.throw_nullish.296:                           ; preds = %pget.recv_bad.269
  %r1543 = zext i1 %r1541 to i32
  %statepoint_token397 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1543, ptr @options_worker_ts_.str.17.bytes, i64 3, i32 0, i32 0)
  unreachable

pget.recv_undef_return.297:                       ; preds = %pget.recv_bad.269
  %r1544 = load double, ptr @options_worker_ts_.str.17.handle, align 8
  %r1545 = bitcast double %r1544 to i64
  %r1546 = and i64 %r1545, 281474976710655
  %statepoint_token398 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1406, i64 %r1546, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated377, ptr addrspace(1) %rs4gc.s20.relocated) ]
  %r1547399 = call double @llvm.experimental.gc.result.f64(token %statepoint_token398)
  %rs4gc.s11.relocated400 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token398, i32 0, i32 0) ; (%rs4gc.s11.relocated377, %rs4gc.s11.relocated377)
  %rs4gc.s20.relocated401 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token398, i32 1, i32 1) ; (%rs4gc.s20.relocated, %rs4gc.s20.relocated)
  br label %pget.recv_merge.271

shadow.root.barrier.298:                          ; preds = %pget.recv_merge.271
  call void @js_write_barrier_root_nanbox(i64 %r1555) #9
  br label %shadow.root.barrier.done.299

shadow.root.barrier.done.299:                     ; preds = %shadow.root.barrier.298, %pget.recv_merge.271
  %r1558.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s11.relocated388 to i64
  %r1558.rs4o = call i64 asm "", "=r,0"(i64 %r1558.rs4i) #9
  %r1558 = bitcast i64 %r1558.rs4o to double
  %r1559.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r1559 = call i64 asm "", "=r,0"(i64 %r1559.rs4i) #9
  %statepoint_token402 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1559, double %r1558, i32 0, i32 0)
  %r1560403 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token402)
  %rs4gc.s22 = inttoptr i64 %r1560403 to ptr addrspace(1)
  %r1561.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s22 to i64
  %r1561 = call i64 asm "", "=r,0"(i64 %r1561.rs4i) #9
  %r1562 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1563 = icmp ne i32 %r1562, 0
  br i1 %r1563, label %shadow.root.barrier.300, label %shadow.root.barrier.done.301

shadow.root.barrier.300:                          ; preds = %shadow.root.barrier.done.299
  call void @js_write_barrier_root_nanbox(i64 %r1561) #9
  br label %shadow.root.barrier.done.301

shadow.root.barrier.done.301:                     ; preds = %shadow.root.barrier.300, %shadow.root.barrier.done.299
  %r1564.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s22 to i64
  %r1564 = call i64 asm "", "=r,0"(i64 %r1564.rs4i) #9
  %statepoint_token404 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1564, double 0.000000e+00, i32 0, i32 0)
  %r1565405 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token404)
  %rs4gc.s23 = inttoptr i64 %r1565405 to ptr addrspace(1)
  %r1566.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s23 to i64
  %r1566 = call i64 asm "", "=r,0"(i64 %r1566.rs4i) #9
  %r1567 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1568 = icmp ne i32 %r1567, 0
  br i1 %r1568, label %shadow.root.barrier.302, label %shadow.root.barrier.done.303

shadow.root.barrier.302:                          ; preds = %shadow.root.barrier.done.301
  call void @js_write_barrier_root_nanbox(i64 %r1566) #9
  br label %shadow.root.barrier.done.303

shadow.root.barrier.done.303:                     ; preds = %shadow.root.barrier.302, %shadow.root.barrier.done.301
  %r1569.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s23 to i64
  %r1569 = call i64 asm "", "=r,0"(i64 %r1569.rs4i) #9
  %statepoint_token406 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r1569, i32 0, i32 0)
  %statepoint_token407 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0)
  %r1570408 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token407)
  %r1571 = or i64 %r1570408, 9222527611924643840
  %r1572 = bitcast i64 %r1571 to double
  %r1573 = and i64 %r1571, 281474976710655
  %r1574 = lshr i64 %r1571, 48
  %r1575 = icmp eq i64 %r1574, 32765
  %r1576 = icmp ugt i64 %r1573, 1048575
  %r1577 = and i1 %r1575, %r1576
  br i1 %r1577, label %arr.guard.deref.308, label %arr.fallback.305

arr.fast.304:                                     ; preds = %arr.guard.range.310
  %r1636 = add i64 %r1592, 56
  %r1637 = inttoptr i64 %r1636 to ptr
  %r1638 = load double, ptr %r1637, align 8
  %r1639 = bitcast double %r1638 to i64
  %r1640 = icmp eq i64 %r1639, 9222246136947933200
  %r1642 = select i1 %r1640, double 0x7FFC000000000001, double %r1638
  br label %arr.merge.307

arr.fallback.305:                                 ; preds = %arr.guard.live.309, %arr.guard.deref.308, %shadow.root.barrier.done.303
  %statepoint_token409 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 7760974052394532898, double %r1572, double 6.000000e+00, i32 0, i32 0)
  %r1632410 = call double @llvm.experimental.gc.result.f64(token %statepoint_token409)
  br label %arr.merge.307

arr.guard.oob.306:                                ; preds = %arr.guard.range.310
  br label %arr.merge.307

arr.merge.307:                                    ; preds = %arr.guard.oob.306, %arr.fallback.305, %arr.fast.304
  %r1643 = phi double [ %r1642, %arr.fast.304 ], [ %r1632410, %arr.fallback.305 ], [ 0x7FFC000000000001, %arr.guard.oob.306 ]
  %r1644 = load double, ptr @options_worker_ts_.str.21.handle, align 8
  %r1645 = bitcast double %r1643 to i64
  %r1646 = bitcast double %r1644 to i64
  %r1647 = icmp eq i64 %r1645, %r1646
  br i1 %r1647, label %streqlit.true.316, label %streqlit.tag.311

arr.guard.deref.308:                              ; preds = %shadow.root.barrier.done.303
  %r1578 = bitcast double %r1572 to i64
  %r1579 = and i64 %r1578, 281474976710655
  %r1580 = sub nsw i64 %r1579, 8
  %r1581 = inttoptr i64 %r1580 to ptr
  %r1582 = load i8, ptr %r1581, align 1
  %r1583 = icmp eq i8 %r1582, 1
  %r1584 = sub nsw i64 %r1579, 7
  %r1585 = inttoptr i64 %r1584 to ptr
  %r1586 = load i8, ptr %r1585, align 1
  %r1587 = and i8 %r1586, -128
  %r1588 = icmp ne i8 %r1587, 0
  %r1589 = inttoptr i64 %r1579 to ptr
  %r1590 = load i64, ptr %r1589, align 8
  %r1591 = and i1 %r1583, %r1588
  %r1592 = select i1 %r1591, i64 %r1590, i64 %r1579
  %r1593 = lshr i64 %r1592, 48
  %r1594 = icmp eq i64 %r1593, 0
  %r1595 = icmp ugt i64 %r1592, 1048575
  %r1596 = and i1 %r1594, %r1595
  br i1 %r1596, label %arr.guard.live.309, label %arr.fallback.305

arr.guard.live.309:                               ; preds = %arr.guard.deref.308
  %r1597 = sub nuw i64 %r1592, 8
  %r1598 = inttoptr i64 %r1597 to ptr
  %r1599 = load i8, ptr %r1598, align 1
  %r1600 = icmp eq i8 %r1599, 1
  %r1601 = sub nuw i64 %r1592, 7
  %r1602 = inttoptr i64 %r1601 to ptr
  %r1603 = load i8, ptr %r1602, align 1
  %r1604 = and i8 %r1603, -128
  %r1605 = icmp eq i8 %r1604, 0
  %r1606 = sub nuw i64 %r1592, 6
  %r1607 = inttoptr i64 %r1606 to ptr
  %r1608 = load i16, ptr %r1607, align 2
  %r1609 = and i16 %r1608, 1024
  %r1610 = icmp eq i16 %r1609, 0
  %r1611 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1612 = icmp eq i8 %r1611, 0
  %r1613 = inttoptr i64 %r1592 to ptr
  %r1614 = load i32, ptr %r1613, align 4
  %r1615 = getelementptr i8, ptr %r1613, i64 4
  %r1616 = load i32, ptr %r1615, align 4
  %r1620 = icmp ule i32 %r1614, 16000000
  %r1621 = icmp ule i32 %r1616, 16000000
  %r1622 = icmp ule i32 %r1614, %r1616
  %r1623 = and i1 %r1600, %r1605
  %r1624 = and i1 %r1623, %r1610
  %r1625 = and i1 %r1624, %r1612
  %r1627 = and i1 %r1625, %r1620
  %r1628 = and i1 %r1627, %r1621
  %r1629 = and i1 %r1628, %r1622
  br i1 %r1629, label %arr.guard.range.310, label %arr.fallback.305

arr.guard.range.310:                              ; preds = %arr.guard.live.309
  %r1619 = icmp ult i32 6, %r1614
  br i1 %r1619, label %arr.fast.304, label %arr.guard.oob.306

streqlit.tag.311:                                 ; preds = %arr.merge.307
  %r1648 = lshr i64 %r1645, 48
  %r1649 = icmp eq i64 %r1648, 32767
  %r1650 = and i64 %r1645, 281474976710655
  %r1651 = icmp ugt i64 %r1650, 4095
  %r1652 = and i1 %r1649, %r1651
  br i1 %r1652, label %streqlit.len.312, label %streqlit.false.317

streqlit.len.312:                                 ; preds = %streqlit.tag.311
  %r1653 = inttoptr i64 %r1650 to ptr
  %r1654 = getelementptr inbounds nuw i8, ptr %r1653, i64 4
  %r1655 = load i32, ptr %r1654, align 4
  %r1656 = icmp eq i32 %r1655, 6
  br i1 %r1656, label %streqlit.b0.313, label %streqlit.false.317

streqlit.b0.313:                                  ; preds = %streqlit.len.312
  %r1657 = getelementptr inbounds nuw i8, ptr %r1653, i64 20
  %r1658 = load i8, ptr %r1657, align 1
  %r1659 = icmp eq i8 %r1658, 118
  br i1 %r1659, label %streqlit.bl.314, label %streqlit.false.317

streqlit.bl.314:                                  ; preds = %streqlit.b0.313
  %r1660 = getelementptr inbounds nuw i8, ptr %r1653, i64 25
  %r1661 = load i8, ptr %r1660, align 1
  %r1662 = icmp eq i8 %r1661, 121
  br i1 %r1662, label %streqlit.slow.315, label %streqlit.false.317

streqlit.slow.315:                                ; preds = %streqlit.bl.314
  %r1663 = and i64 %r1646, 281474976710655
  %statepoint_token411 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r1650, i64 %r1663, i32 0, i32 0)
  %r1664412 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token411)
  %r1665 = icmp ne i32 %r1664412, 0
  br label %streqlit.merge.318

streqlit.true.316:                                ; preds = %arr.merge.307
  br label %streqlit.merge.318

streqlit.false.317:                               ; preds = %streqlit.bl.314, %streqlit.b0.313, %streqlit.len.312, %streqlit.tag.311
  br label %streqlit.merge.318

streqlit.merge.318:                               ; preds = %streqlit.false.317, %streqlit.true.316, %streqlit.slow.315
  %r1666 = phi i1 [ true, %streqlit.true.316 ], [ false, %streqlit.false.317 ], [ %r1665, %streqlit.slow.315 ]
  %r1667 = select i1 %r1666, i64 9222246136947933188, i64 9222246136947933187
  %r1668 = bitcast i64 %r1667 to double
  %r1669 = icmp eq i64 %r1667, 9222246136947933188
  br i1 %r1669, label %if.then.319, label %if.else.320

if.then.319:                                      ; preds = %streqlit.merge.318
  %statepoint_token413 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 2, i32 0, i32 0)
  %r1670414 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token413)
  %rs4gc.s24 = inttoptr i64 %r1670414 to ptr addrspace(1)
  %r1671.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24 to i64
  %r1671 = call i64 asm "", "=r,0"(i64 %r1671.rs4i) #9
  %r1672 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1673 = icmp ne i32 %r1672, 0
  br i1 %r1673, label %shadow.root.barrier.322, label %shadow.root.barrier.done.323

if.else.320:                                      ; preds = %streqlit.merge.318
  br label %if.merge.321

if.merge.321:                                     ; preds = %shadow.root.barrier.done.327, %if.else.320
  %statepoint_token415 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0)
  %r1687416 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token415)
  %rs4gc.s25 = inttoptr i64 %r1687416 to ptr addrspace(1)
  %r1688.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s25 to i64
  %r1688 = call i64 asm "", "=r,0"(i64 %r1688.rs4i) #9
  %r1689 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1690 = icmp ne i32 %r1689, 0
  br i1 %r1690, label %shadow.root.barrier.328, label %shadow.root.barrier.done.329

shadow.root.barrier.322:                          ; preds = %if.then.319
  call void @js_write_barrier_root_nanbox(i64 %r1671) #9
  br label %shadow.root.barrier.done.323

shadow.root.barrier.done.323:                     ; preds = %shadow.root.barrier.322, %if.then.319
  %r1674 = load double, ptr @options_worker_ts_.str.22.handle, align 8
  %r1675.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24 to i64
  %r1675 = call i64 asm "", "=r,0"(i64 %r1675.rs4i) #9
  %statepoint_token417 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1675, double %r1674, i32 0, i32 0)
  %r1676418 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token417)
  %rs4gc.s26 = inttoptr i64 %r1676418 to ptr addrspace(1)
  %r1677.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s26 to i64
  %r1677 = call i64 asm "", "=r,0"(i64 %r1677.rs4i) #9
  %r1678 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1679 = icmp ne i32 %r1678, 0
  br i1 %r1679, label %shadow.root.barrier.324, label %shadow.root.barrier.done.325

shadow.root.barrier.324:                          ; preds = %shadow.root.barrier.done.323
  call void @js_write_barrier_root_nanbox(i64 %r1677) #9
  br label %shadow.root.barrier.done.325

shadow.root.barrier.done.325:                     ; preds = %shadow.root.barrier.324, %shadow.root.barrier.done.323
  %r1680 = load double, ptr @perry_global_options_worker_ts__6, align 8
  %r1681.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s26 to i64
  %r1681 = call i64 asm "", "=r,0"(i64 %r1681.rs4i) #9
  %statepoint_token419 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1681, double %r1680, i32 0, i32 0)
  %r1682420 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token419)
  %rs4gc.s27 = inttoptr i64 %r1682420 to ptr addrspace(1)
  %r1683.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s27 to i64
  %r1683 = call i64 asm "", "=r,0"(i64 %r1683.rs4i) #9
  %r1684 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1685 = icmp ne i32 %r1684, 0
  br i1 %r1685, label %shadow.root.barrier.326, label %shadow.root.barrier.done.327

shadow.root.barrier.326:                          ; preds = %shadow.root.barrier.done.325
  call void @js_write_barrier_root_nanbox(i64 %r1683) #9
  br label %shadow.root.barrier.done.327

shadow.root.barrier.done.327:                     ; preds = %shadow.root.barrier.326, %shadow.root.barrier.done.325
  %r1686.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s27 to i64
  %r1686 = call i64 asm "", "=r,0"(i64 %r1686.rs4i) #9
  %statepoint_token421 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r1686, i32 0, i32 0)
  br label %if.merge.321

shadow.root.barrier.328:                          ; preds = %if.merge.321
  call void @js_write_barrier_root_nanbox(i64 %r1688) #9
  br label %shadow.root.barrier.done.329

shadow.root.barrier.done.329:                     ; preds = %shadow.root.barrier.328, %if.merge.321
  %r1691 = load double, ptr @options_worker_ts_.str.23.handle, align 8
  %r1692.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s25 to i64
  %r1692 = call i64 asm "", "=r,0"(i64 %r1692.rs4i) #9
  %statepoint_token422 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1692, double %r1691, i32 0, i32 0)
  %r1693423 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token422)
  %rs4gc.s28 = inttoptr i64 %r1693423 to ptr addrspace(1)
  %r1694.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s28 to i64
  %r1694 = call i64 asm "", "=r,0"(i64 %r1694.rs4i) #9
  %r1695 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1696 = icmp ne i32 %r1695, 0
  br i1 %r1696, label %shadow.root.barrier.330, label %shadow.root.barrier.done.331

shadow.root.barrier.330:                          ; preds = %shadow.root.barrier.done.329
  call void @js_write_barrier_root_nanbox(i64 %r1694) #9
  br label %shadow.root.barrier.done.331

shadow.root.barrier.done.331:                     ; preds = %shadow.root.barrier.330, %shadow.root.barrier.done.329
  %r1697 = load double, ptr @perry_global_options_worker_ts__4, align 8
  %r1698 = bitcast double %r1697 to i64
  %r1700 = icmp eq i64 %r1698, 9222246136947933186
  %r1701 = select i1 %r1700, i64 9222246136947933188, i64 9222246136947933187
  %r1702 = bitcast i64 %r1701 to double
  %r1703 = icmp eq i64 %r1701, 9222246136947933188
  br i1 %r1703, label %ternary.then.332, label %ternary.else.333

ternary.then.332:                                 ; preds = %shadow.root.barrier.done.331
  br label %ternary.merge.334

ternary.else.333:                                 ; preds = %shadow.root.barrier.done.331
  br label %ternary.merge.334

ternary.merge.334:                                ; preds = %ternary.else.333, %ternary.then.332
  %r1704 = phi double [ 0.000000e+00, %ternary.then.332 ], [ 1.000000e+00, %ternary.else.333 ]
  %r1705.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s28 to i64
  %r1705 = call i64 asm "", "=r,0"(i64 %r1705.rs4i) #9
  %statepoint_token424 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1705, double %r1704, i32 0, i32 0)
  %r1706425 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token424)
  %rs4gc.s29 = inttoptr i64 %r1706425 to ptr addrspace(1)
  %r1707.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s29 to i64
  %r1707 = call i64 asm "", "=r,0"(i64 %r1707.rs4i) #9
  %r1708 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1709 = icmp ne i32 %r1708, 0
  br i1 %r1709, label %shadow.root.barrier.335, label %shadow.root.barrier.done.336

shadow.root.barrier.335:                          ; preds = %ternary.merge.334
  call void @js_write_barrier_root_nanbox(i64 %r1707) #9
  br label %shadow.root.barrier.done.336

shadow.root.barrier.done.336:                     ; preds = %shadow.root.barrier.335, %ternary.merge.334
  %r1710 = load double, ptr @perry_global_options_worker_ts__6, align 8
  %r1711 = bitcast double %r1710 to i64
  %r1713 = icmp eq i64 %r1711, 9222246136947933186
  %r1714 = select i1 %r1713, i64 9222246136947933188, i64 9222246136947933187
  %r1715 = bitcast i64 %r1714 to double
  %r1716 = icmp eq i64 %r1714, 9222246136947933188
  br i1 %r1716, label %ternary.then.337, label %ternary.else.338

ternary.then.337:                                 ; preds = %shadow.root.barrier.done.336
  br label %ternary.merge.339

ternary.else.338:                                 ; preds = %shadow.root.barrier.done.336
  br label %ternary.merge.339

ternary.merge.339:                                ; preds = %ternary.else.338, %ternary.then.337
  %r1717 = phi double [ 0.000000e+00, %ternary.then.337 ], [ 1.000000e+00, %ternary.else.338 ]
  %r1718.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s29 to i64
  %r1718 = call i64 asm "", "=r,0"(i64 %r1718.rs4i) #9
  %statepoint_token426 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1718, double %r1717, i32 0, i32 0)
  %r1719427 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token426)
  %rs4gc.s30 = inttoptr i64 %r1719427 to ptr addrspace(1)
  %r1720.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s30 to i64
  %r1720 = call i64 asm "", "=r,0"(i64 %r1720.rs4i) #9
  %r1721 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1722 = icmp ne i32 %r1721, 0
  br i1 %r1722, label %shadow.root.barrier.340, label %shadow.root.barrier.done.341

shadow.root.barrier.340:                          ; preds = %ternary.merge.339
  call void @js_write_barrier_root_nanbox(i64 %r1720) #9
  br label %shadow.root.barrier.done.341

shadow.root.barrier.done.341:                     ; preds = %shadow.root.barrier.340, %ternary.merge.339
  %r1723.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s30 to i64
  %r1723 = call i64 asm "", "=r,0"(i64 %r1723.rs4i) #9
  %statepoint_token428 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r1723, i32 0, i32 0)
  %statepoint_token429 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token430 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token431 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token432 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token433 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.342

event_loop.header.342:                            ; preds = %event_loop.body_wait.347, %event_loop.body_check.346, %shadow.root.barrier.done.341
  %statepoint_token434 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_event_loop_host_driven, i32 0, i32 0, i32 0, i32 0)
  %r1728435 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token434)
  %r1729 = icmp ne i32 %r1728435, 0
  br i1 %r1729, label %event_loop.host_return.344, label %event_loop.check_pending.343

event_loop.check_pending.343:                     ; preds = %event_loop.header.342
  %statepoint_token436 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1730437 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token436)
  %statepoint_token438 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1731439 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token438)
  %statepoint_token440 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1732441 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token440)
  %statepoint_token442 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r1733443 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token442)
  %statepoint_token444 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r1734445 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token444)
  %statepoint_token446 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r1735447 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token446)
  %r1736 = or i32 %r1730437, %r1731439
  %r1737 = or i32 %r1732441, %r1733443
  %r1738 = or i32 %r1737, %r1734445
  %r1739 = or i32 %r1736, %r1738
  %r1740 = or i32 %r1739, 0
  %r1741 = or i32 %r1740, %r1735447
  %r1742 = icmp ne i32 %r1741, 0
  br i1 %r1742, label %event_loop.body.345, label %event_loop.exit.348

event_loop.host_return.344:                       ; preds = %event_loop.header.342
  call void @js_typed_feedback_maybe_dump_trace() #9
  ret i32 0

event_loop.body.345:                              ; preds = %event_loop.check_pending.343
  %statepoint_token448 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token449 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.body_check.346

event_loop.body_check.346:                        ; preds = %event_loop.body.345
  %statepoint_token450 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1744451 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token450)
  %statepoint_token452 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1745453 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token452)
  %statepoint_token454 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1746455 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token454)
  %statepoint_token456 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r1747457 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token456)
  %statepoint_token458 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r1748459 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token458)
  %statepoint_token460 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r1749461 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token460)
  %r1750 = or i32 %r1744451, %r1745453
  %r1751 = or i32 %r1746455, %r1747457
  %r1752 = or i32 %r1751, %r1748459
  %r1753 = or i32 %r1750, %r1752
  %r1754 = or i32 %r1753, 0
  %r1755 = or i32 %r1754, %r1749461
  %r1756 = icmp ne i32 %r1755, 0
  br i1 %r1756, label %event_loop.body_wait.347, label %event_loop.header.342

event_loop.body_wait.347:                         ; preds = %event_loop.body_check.346
  %statepoint_token462 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_wait_for_event, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.342

event_loop.exit.348:                              ; preds = %event_loop.check_pending.343
  %statepoint_token463 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_emit_before_exit_pending, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token464 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token465 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_exit_sequence, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token466 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_finalization_exit, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token467 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_promise_jobs, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token468 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_trace_events_flush_output, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token469 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_promise_report_unhandled_rejections, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token470 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_release_current_thread_collection_side_allocations, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token471 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_process_pending_exit_code, i32 0, i32 0, i32 0, i32 0)
  %r1759472 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token471)
  call void @js_typed_feedback_maybe_dump_trace() #9
  ret i32 %r1759472
}

; Function Attrs: optsize
define void @__perry_init_strings_options_worker_ts_chunk0() #6 {
entry.0:
  %r1 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.0.bytes, i32 4)
  %r2 = call double @js_nanbox_string(i64 %r1)
  store double %r2, ptr @options_worker_ts_.str.0.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.0.handle to i64))
  %r4 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.1.bytes, i32 6)
  %r5 = call double @js_nanbox_string(i64 %r4)
  store double %r5, ptr @options_worker_ts_.str.1.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.1.handle to i64))
  %r7 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.2.bytes, i32 6)
  %r8 = call double @js_nanbox_string(i64 %r7)
  store double %r8, ptr @options_worker_ts_.str.2.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.2.handle to i64))
  %r10 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.3.bytes, i32 4)
  %r11 = call double @js_nanbox_string(i64 %r10)
  store double %r11, ptr @options_worker_ts_.str.3.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.3.handle to i64))
  %r13 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.4.bytes, i32 8)
  %r14 = call double @js_nanbox_string(i64 %r13)
  store double %r14, ptr @options_worker_ts_.str.4.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.4.handle to i64))
  %r16 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.5.bytes, i32 2)
  %r17 = call double @js_nanbox_string(i64 %r16)
  store double %r17, ptr @options_worker_ts_.str.5.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.5.handle to i64))
  %r19 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.6.bytes, i32 12)
  %r20 = call double @js_nanbox_string(i64 %r19)
  store double %r20, ptr @options_worker_ts_.str.6.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.6.handle to i64))
  %r22 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.7.bytes, i32 4)
  %r23 = call double @js_nanbox_string(i64 %r22)
  store double %r23, ptr @options_worker_ts_.str.7.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.7.handle to i64))
  %r25 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.8.bytes, i32 8)
  %r26 = call double @js_nanbox_string(i64 %r25)
  store double %r26, ptr @options_worker_ts_.str.8.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.8.handle to i64))
  %r28 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.9.bytes, i32 1)
  %r29 = call double @js_nanbox_string(i64 %r28)
  store double %r29, ptr @options_worker_ts_.str.9.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.9.handle to i64))
  %r31 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.10.bytes, i32 4)
  %r32 = call double @js_nanbox_string(i64 %r31)
  store double %r32, ptr @options_worker_ts_.str.10.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.10.handle to i64))
  %r34 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.11.bytes, i32 2)
  %r35 = call double @js_nanbox_string(i64 %r34)
  store double %r35, ptr @options_worker_ts_.str.11.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.11.handle to i64))
  %r37 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.12.bytes, i32 4)
  %r38 = call double @js_nanbox_string(i64 %r37)
  store double %r38, ptr @options_worker_ts_.str.12.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.12.handle to i64))
  %r40 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.13.bytes, i32 5)
  %r41 = call double @js_nanbox_string(i64 %r40)
  store double %r41, ptr @options_worker_ts_.str.13.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.13.handle to i64))
  %r43 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.14.bytes, i32 6)
  %r44 = call double @js_nanbox_string(i64 %r43)
  store double %r44, ptr @options_worker_ts_.str.14.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.14.handle to i64))
  %r46 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.15.bytes, i32 5)
  %r47 = call double @js_nanbox_string(i64 %r46)
  store double %r47, ptr @options_worker_ts_.str.15.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.15.handle to i64))
  %r49 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.16.bytes, i32 4)
  %r50 = call double @js_nanbox_string(i64 %r49)
  store double %r50, ptr @options_worker_ts_.str.16.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.16.handle to i64))
  %r52 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.17.bytes, i32 3)
  %r53 = call double @js_nanbox_string(i64 %r52)
  store double %r53, ptr @options_worker_ts_.str.17.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.17.handle to i64))
  %r55 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.18.bytes, i32 6)
  %r56 = call double @js_nanbox_string(i64 %r55)
  store double %r56, ptr @options_worker_ts_.str.18.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.18.handle to i64))
  %r58 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.19.bytes, i32 4)
  %r59 = call double @js_nanbox_string(i64 %r58)
  store double %r59, ptr @options_worker_ts_.str.19.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.19.handle to i64))
  %r61 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.20.bytes, i32 6)
  %r62 = call double @js_nanbox_string(i64 %r61)
  store double %r62, ptr @options_worker_ts_.str.20.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.20.handle to i64))
  %r64 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.21.bytes, i32 6)
  %r65 = call double @js_nanbox_string(i64 %r64)
  store double %r65, ptr @options_worker_ts_.str.21.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.21.handle to i64))
  %r67 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.22.bytes, i32 6)
  %r68 = call double @js_nanbox_string(i64 %r67)
  store double %r68, ptr @options_worker_ts_.str.22.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.22.handle to i64))
  %r70 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.23.bytes, i32 4)
  %r71 = call double @js_nanbox_string(i64 %r70)
  store double %r71, ptr @options_worker_ts_.str.23.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.23.handle to i64))
  call void @js_register_function_name_static(ptr @__perry_wrap_perry_fn_options_worker_ts__identity, ptr @options_worker_ts_.str.1, i32 8)
  call void @js_register_function_name_static(ptr @__perry_wrap_perry_fn_options_worker_ts__run, ptr @options_worker_ts_.str.2, i32 3)
  call void @js_register_function_name_static(ptr @perry_fn_options_worker_ts__identity, ptr @options_worker_ts_.str.1, i32 8)
  call void @js_register_function_name_static(ptr @perry_fn_options_worker_ts__run, ptr @options_worker_ts_.str.2, i32 3)
  call void @js_register_function_source_static(ptr @__perry_wrap_perry_fn_options_worker_ts__identity, ptr @options_worker_ts_.str.3, i32 65, i32 0)
  call void @js_register_function_source_static(ptr @__perry_wrap_perry_fn_options_worker_ts__run, ptr @options_worker_ts_.str.4, i32 871, i32 0)
  call void @js_register_closure_arity(ptr @__perry_wrap_perry_fn_options_worker_ts__identity, i32 2)
  call void @js_register_closure_arity(ptr @__perry_wrap_perry_fn_options_worker_ts__run, i32 1)
  call void @js_register_closure_length(ptr @__perry_wrap_perry_fn_options_worker_ts__identity, i32 2)
  call void @js_register_closure_length(ptr @__perry_wrap_perry_fn_options_worker_ts__run, i32 1)
  call void @js_register_closure_strict_function(ptr @__perry_wrap_perry_fn_options_worker_ts__identity)
  call void @js_register_closure_strict_function(ptr @__perry_wrap_perry_fn_options_worker_ts__run)
  ret void
}

; Function Attrs: optsize
define void @__perry_init_strings_options_worker_ts() #6 {
entry.0:
  call void @__perry_init_strings_options_worker_ts_chunk0()
  ret void
}

declare void @__tmp_use(...)

attributes #0 = { nounwind willreturn }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { optsize "frame-pointer"="non-leaf" }
attributes #7 = { inlinehint optsize "frame-pointer"="non-leaf" }
attributes #8 = { noinline optsize "frame-pointer"="non-leaf" }
attributes #9 = { "gc-leaf-function" }
