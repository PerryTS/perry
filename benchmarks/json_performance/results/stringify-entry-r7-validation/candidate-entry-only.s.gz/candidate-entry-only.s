<_js_json_stringify_full>:
100847dc0:     	sub	sp, sp, #0xa0
100847dc4:     	stp	d11, d10, [sp, #0x40]
100847dc8:     	stp	d9, d8, [sp, #0x50]
100847dcc:     	stp	x24, x23, [sp, #0x60]
100847dd0:     	stp	x22, x21, [sp, #0x70]
100847dd4:     	stp	x20, x19, [sp, #0x80]
100847dd8:     	stp	x29, x30, [sp, #0x90]
100847ddc:     	add	x29, sp, #0x90
100847de0:     	fmov	x9, d1
100847de4:     	fmov	x8, d2
100847de8:     	mov	x10, #-0x7ffc000000000001 ; =-9222246136947933185
100847dec:     	add	x11, x8, x10
100847df0:     	add	x21, x9, x10
100847df4:     	cmp	x11, #0x1
100847df8:     	b.hi	0x100847e0c <_js_json_stringify_full+0x4c>
100847dfc:     	cmp	x21, #0x2
100847e00:     	b.lo	0x100847e2c <_js_json_stringify_full+0x6c>
100847e04:     	mov	w8, #0x1                ; =1
100847e08:     	b	0x100848704 <_js_json_stringify_full+0x944>
100847e0c:     	cmp	x21, #0x2
100847e10:     	cset	w9, lo
100847e14:     	mov	x10, #0x3               ; =3
100847e18:     	movk	x10, #0x7ffc, lsl #48
100847e1c:     	cmp	x8, x10
100847e20:     	cset	w8, eq
100847e24:     	csel	w9, wzr, w9, ne
100847e28:     	tbz	w9, #0x0, 0x100848704 <_js_json_stringify_full+0x944>
100847e2c:     	fmov	x8, d0
100847e30:     	mov	x9, #-0x2               ; =-2
100847e34:     	movk	x9, #0x8003, lsl #48
100847e38:     	add	x9, x8, x9
100847e3c:     	cmp	x9, #0x3
100847e40:     	b.hs	0x100847e70 <_js_json_stringify_full+0xb0>
100847e44:     	adrp	x8, 0x100c9a000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4e30>
100847e48:     	add	x8, x8, #0x758
100847e4c:     	ldr	x0, [x8, x9, lsl #3]
100847e50:     	ldp	x29, x30, [sp, #0x90]
100847e54:     	ldp	x20, x19, [sp, #0x80]
100847e58:     	ldp	x22, x21, [sp, #0x70]
100847e5c:     	ldp	x24, x23, [sp, #0x60]
100847e60:     	ldp	d9, d8, [sp, #0x50]
100847e64:     	ldp	d11, d10, [sp, #0x40]
100847e68:     	add	sp, sp, #0xa0
100847e6c:     	ret
100847e70:     	strb	wzr, [sp, #0x14]
100847e74:     	str	wzr, [sp, #0x10]
100847e78:     	and	x9, x8, #0xffff000000000000
100847e7c:     	mov	x10, #0x7fff000000000000 ; =9223090561878065152
100847e80:     	cmp	x9, x10
100847e84:     	b.eq	0x100847ef8 <_js_json_stringify_full+0x138>
100847e88:     	mov	x10, #0x7ff9000000000000 ; =9221401712017801216
100847e8c:     	cmp	x9, x10
100847e90:     	b.ne	0x1008482ec <_js_json_stringify_full+0x52c>
100847e94:     	ubfx	x11, x8, #40, #8
100847e98:     	cbz	x11, 0x100847ee8 <_js_json_stringify_full+0x128>
100847e9c:     	strb	w8, [sp, #0x10]
100847ea0:     	cmp	x11, #0x1
100847ea4:     	b.eq	0x100847ee8 <_js_json_stringify_full+0x128>
100847ea8:     	lsr	x10, x8, #8
100847eac:     	strb	w10, [sp, #0x11]
100847eb0:     	cmp	x11, #0x2
100847eb4:     	b.eq	0x100847ee8 <_js_json_stringify_full+0x128>
100847eb8:     	lsr	x10, x8, #16
100847ebc:     	strb	w10, [sp, #0x12]
100847ec0:     	cmp	x11, #0x3
100847ec4:     	b.eq	0x100847ee8 <_js_json_stringify_full+0x128>
100847ec8:     	lsr	x10, x8, #24
100847ecc:     	strb	w10, [sp, #0x13]
100847ed0:     	cmp	x11, #0x4
100847ed4:     	b.eq	0x100847ee8 <_js_json_stringify_full+0x128>
100847ed8:     	lsr	x10, x8, #32
100847edc:     	strb	w10, [sp, #0x14]
100847ee0:     	cmp	x11, #0x5
100847ee4:     	b.ne	0x10084872c <_js_json_stringify_full+0x96c>
100847ee8:     	add	x13, sp, #0x10
100847eec:     	cmp	w11, #0x3
100847ef0:     	b.ls	0x100847f10 <_js_json_stringify_full+0x150>
100847ef4:     	b	0x1008482ec <_js_json_stringify_full+0x52c>
100847ef8:     	ands	x10, x8, #0xffffffffffff
100847efc:     	b.eq	0x100847e04 <_js_json_stringify_full+0x44>
100847f00:     	add	x13, x10, #0x14
100847f04:     	ldr	w11, [x10, #0x4]
100847f08:     	cmp	w11, #0x3
100847f0c:     	b.hi	0x1008482ec <_js_json_stringify_full+0x52c>
100847f10:     	stur	wzr, [sp, #0x19]
100847f14:     	mov	w10, #0x22              ; =34
100847f18:     	strb	w10, [sp, #0x18]
100847f1c:     	cbz	w11, 0x100847f54 <_js_json_stringify_full+0x194>
100847f20:     	add	x12, sp, #0x18
100847f24:     	ldrb	w14, [x13]
100847f28:     	sxtb	w16, w14
100847f2c:     	cmp	w14, #0xb
100847f30:     	b.le	0x100847f5c <_js_json_stringify_full+0x19c>
100847f34:     	cmp	w14, #0x21
100847f38:     	b.gt	0x100847f7c <_js_json_stringify_full+0x1bc>
100847f3c:     	cmp	w14, #0xc
100847f40:     	b.eq	0x100847fb0 <_js_json_stringify_full+0x1f0>
100847f44:     	cmp	w14, #0xd
100847f48:     	b.ne	0x100847f8c <_js_json_stringify_full+0x1cc>
100847f4c:     	mov	w16, #0x72              ; =114
100847f50:     	b	0x100847fbc <_js_json_stringify_full+0x1fc>
100847f54:     	mov	w12, #0x1               ; =1
100847f58:     	b	0x100847fe4 <_js_json_stringify_full+0x224>
100847f5c:     	cmp	w14, #0x8
100847f60:     	b.eq	0x100847fa8 <_js_json_stringify_full+0x1e8>
100847f64:     	cmp	w14, #0x9
100847f68:     	b.eq	0x100847fb8 <_js_json_stringify_full+0x1f8>
100847f6c:     	cmp	w14, #0xa
100847f70:     	b.ne	0x100847f8c <_js_json_stringify_full+0x1cc>
100847f74:     	mov	w16, #0x6e              ; =110
100847f78:     	b	0x100847fbc <_js_json_stringify_full+0x1fc>
100847f7c:     	cmp	w14, #0x22
100847f80:     	b.eq	0x100847fbc <_js_json_stringify_full+0x1fc>
100847f84:     	cmp	w14, #0x5c
100847f88:     	b.eq	0x100847fbc <_js_json_stringify_full+0x1fc>
100847f8c:     	cmp	w16, #0x20
100847f90:     	b.lt	0x1008482ec <_js_json_stringify_full+0x52c>
100847f94:     	mov	w15, #0x0               ; =0
100847f98:     	add	x14, x12, #0x2
100847f9c:     	mov	w12, #0x2               ; =2
100847fa0:     	mov	w17, #0x1               ; =1
100847fa4:     	b	0x100847fd4 <_js_json_stringify_full+0x214>
100847fa8:     	mov	w16, #0x62              ; =98
100847fac:     	b	0x100847fbc <_js_json_stringify_full+0x1fc>
100847fb0:     	mov	w16, #0x66              ; =102
100847fb4:     	b	0x100847fbc <_js_json_stringify_full+0x1fc>
100847fb8:     	mov	w16, #0x74              ; =116
100847fbc:     	add	x14, x12, #0x3
100847fc0:     	mov	w12, #0x5c              ; =92
100847fc4:     	strb	w12, [sp, #0x19]
100847fc8:     	mov	w15, #0x1               ; =1
100847fcc:     	mov	w12, #0x3               ; =3
100847fd0:     	mov	w17, #0x2               ; =2
100847fd4:     	add	x0, sp, #0x18
100847fd8:     	strb	w16, [x0, x17]
100847fdc:     	cmp	w11, #0x1
100847fe0:     	b.ne	0x100848024 <_js_json_stringify_full+0x264>
100847fe4:     	add	x9, sp, #0x18
100847fe8:     	strb	w10, [x9, x12]
100847fec:     	add	x8, x12, #0x1
100847ff0:     	cmp	x12, #0x3
100847ff4:     	b.hs	0x100848008 <_js_json_stringify_full+0x248>
100847ff8:     	mov	x15, #0x0               ; =0
100847ffc:     	mov	x11, #0x0               ; =0
100848000:     	add	x10, sp, #0x18
100848004:     	b	0x10084825c <_js_json_stringify_full+0x49c>
100848008:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4e30>
10084800c:     	adrp	x13, 0x100c3a000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x3363a>
100848010:     	cmp	x12, #0xf
100848014:     	b.hs	0x100848054 <_js_json_stringify_full+0x294>
100848018:     	mov	x11, #0x0               ; =0
10084801c:     	mov	x15, #0x0               ; =0
100848020:     	b	0x1008481c0 <_js_json_stringify_full+0x400>
100848024:     	ldrb	w17, [x13, #0x1]
100848028:     	sxtb	w16, w17
10084802c:     	cmp	w17, #0xb
100848030:     	b.le	0x10084828c <_js_json_stringify_full+0x4cc>
100848034:     	cmp	w17, #0x21
100848038:     	b.gt	0x1008482ac <_js_json_stringify_full+0x4ec>
10084803c:     	cmp	w17, #0xc
100848040:     	b.eq	0x1008482dc <_js_json_stringify_full+0x51c>
100848044:     	cmp	w17, #0xd
100848048:     	b.ne	0x1008482bc <_js_json_stringify_full+0x4fc>
10084804c:     	mov	w16, #0x72              ; =114
100848050:     	b	0x1008482e8 <_js_json_stringify_full+0x528>
100848054:     	and	x12, x8, #0xc
100848058:     	and	x11, x8, #0x10
10084805c:     	add	x15, sp, #0x18
100848060:     	add	x10, x15, x11
100848064:     	adrp	x16, 0x100c9b000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e30>
100848068:     	ldr	q0, [x16, #0x8d0]
10084806c:     	adrp	x16, 0x100c9b000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e30>
100848070:     	ldr	q1, [x16, #0x8e0]
100848074:     	adrp	x16, 0x100c9b000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e30>
100848078:     	ldr	q2, [x16, #0x8f0]
10084807c:     	adrp	x16, 0x100c9b000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e30>
100848080:     	ldr	q3, [x16, #0x900]
100848084:     	adrp	x16, 0x100c9b000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e30>
100848088:     	ldr	q4, [x16, #0x910]
10084808c:     	movi.2d	v5, #0000000000000000
100848090:     	adrp	x16, 0x100c9b000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e30>
100848094:     	ldr	q6, [x16, #0x920]
100848098:     	mov	w16, #0x10              ; =16
10084809c:     	dup.2d	v7, x16
1008480a0:     	and	x16, x8, #0x10
1008480a4:     	movi.2d	v16, #0000000000000000
1008480a8:     	ldr	q19, [x14, #0xa40]
1008480ac:     	movi.2d	v18, #0000000000000000
1008480b0:     	movi.2d	v17, #0000000000000000
1008480b4:     	ldr	q23, [x13, #0x940]
1008480b8:     	movi.2d	v22, #0000000000000000
1008480bc:     	movi.2d	v20, #0000000000000000
1008480c0:     	movi.2d	v24, #0000000000000000
1008480c4:     	movi.2d	v21, #0000000000000000
1008480c8:     	ldr	q25, [x15], #0x10
1008480cc:     	ushll.8h	v26, v25, #0x0
1008480d0:     	ushll2.4s	v27, v26, #0x0
1008480d4:     	ushll2.2d	v28, v27, #0x0
1008480d8:     	ushll2.8h	v25, v25, #0x0
1008480dc:     	ushll.4s	v29, v25, #0x0
1008480e0:     	ushll2.2d	v30, v29, #0x0
1008480e4:     	ushll.2d	v29, v29, #0x0
1008480e8:     	ushll.2d	v27, v27, #0x0
1008480ec:     	ushll.4s	v26, v26, #0x0
1008480f0:     	ushll2.2d	v31, v26, #0x0
1008480f4:     	ushll2.4s	v25, v25, #0x0
1008480f8:     	ushll.2d	v8, v25, #0x0
1008480fc:     	ushll.2d	v26, v26, #0x0
100848100:     	ushll2.2d	v25, v25, #0x0
100848104:     	shl.2d	v9, v0, #0x3
100848108:     	ushl.2d	v25, v25, v9
10084810c:     	shl.2d	v9, v23, #0x3
100848110:     	ushl.2d	v26, v26, v9
100848114:     	shl.2d	v9, v1, #0x3
100848118:     	ushl.2d	v8, v8, v9
10084811c:     	shl.2d	v9, v19, #0x3
100848120:     	ushl.2d	v31, v31, v9
100848124:     	shl.2d	v9, v6, #0x3
100848128:     	ushl.2d	v27, v27, v9
10084812c:     	shl.2d	v9, v3, #0x3
100848130:     	ushl.2d	v29, v29, v9
100848134:     	shl.2d	v9, v2, #0x3
100848138:     	ushl.2d	v30, v30, v9
10084813c:     	shl.2d	v9, v4, #0x3
100848140:     	ushl.2d	v28, v28, v9
100848144:     	orr.16b	v17, v28, v17
100848148:     	orr.16b	v20, v30, v20
10084814c:     	orr.16b	v22, v29, v22
100848150:     	orr.16b	v18, v27, v18
100848154:     	orr.16b	v5, v31, v5
100848158:     	orr.16b	v24, v8, v24
10084815c:     	orr.16b	v16, v26, v16
100848160:     	orr.16b	v21, v25, v21
100848164:     	add.2d	v6, v6, v7
100848168:     	add.2d	v19, v19, v7
10084816c:     	add.2d	v23, v23, v7
100848170:     	add.2d	v4, v4, v7
100848174:     	add.2d	v3, v3, v7
100848178:     	add.2d	v2, v2, v7
10084817c:     	add.2d	v1, v1, v7
100848180:     	add.2d	v0, v0, v7
100848184:     	subs	x16, x16, #0x10
100848188:     	b.ne	0x1008480c8 <_js_json_stringify_full+0x308>
10084818c:     	orr.16b	v0, v16, v22
100848190:     	orr.16b	v1, v18, v24
100848194:     	orr.16b	v0, v0, v1
100848198:     	orr.16b	v1, v5, v20
10084819c:     	orr.16b	v2, v17, v21
1008481a0:     	orr.16b	v1, v1, v2
1008481a4:     	orr.16b	v0, v0, v1
1008481a8:     	mov	d1, v0[1]
1008481ac:     	orr.8b	v0, v0, v1
1008481b0:     	fmov	x15, d0
1008481b4:     	cmp	x8, x11
1008481b8:     	b.eq	0x10084827c <_js_json_stringify_full+0x4bc>
1008481bc:     	cbz	x12, 0x10084825c <_js_json_stringify_full+0x49c>
1008481c0:     	mov	x16, x11
1008481c4:     	and	x11, x8, #0x1c
1008481c8:     	add	x17, sp, #0x18
1008481cc:     	add	x10, x17, x11
1008481d0:     	fmov	d0, x15
1008481d4:     	movi.2d	v1, #0000000000000000
1008481d8:     	dup.2d	v3, x16
1008481dc:     	ldr	q2, [x14, #0xa40]
1008481e0:     	orr.16b	v2, v3, v2
1008481e4:     	ldr	q4, [x13, #0x940]
1008481e8:     	orr.16b	v3, v3, v4
1008481ec:     	sub	x12, x16, x11
1008481f0:     	add	x13, x17, x16
1008481f4:     	movi.2d	v4, #0x000000000000ff
1008481f8:     	mov	w14, #0x4               ; =4
1008481fc:     	dup.2d	v5, x14
100848200:     	ldr	s6, [x13], #0x4
100848204:     	ushll.8h	v6, v6, #0x0
100848208:     	ushll.4s	v6, v6, #0x0
10084820c:     	ushll2.2d	v7, v6, #0x0
100848210:     	and.16b	v7, v7, v4
100848214:     	ushll.2d	v6, v6, #0x0
100848218:     	and.16b	v6, v6, v4
10084821c:     	shl.2d	v16, v2, #0x3
100848220:     	shl.2d	v17, v3, #0x3
100848224:     	ushl.2d	v6, v6, v17
100848228:     	ushl.2d	v7, v7, v16
10084822c:     	orr.16b	v1, v7, v1
100848230:     	orr.16b	v0, v6, v0
100848234:     	add.2d	v2, v2, v5
100848238:     	add.2d	v3, v3, v5
10084823c:     	adds	x12, x12, #0x4
100848240:     	b.ne	0x100848200 <_js_json_stringify_full+0x440>
100848244:     	orr.16b	v0, v0, v1
100848248:     	mov	d1, v0[1]
10084824c:     	orr.8b	v0, v0, v1
100848250:     	fmov	x15, d0
100848254:     	cmp	x8, x11
100848258:     	b.eq	0x10084827c <_js_json_stringify_full+0x4bc>
10084825c:     	add	x9, x9, x8
100848260:     	lsl	x11, x11, #3
100848264:     	ldrb	w12, [x10], #0x1
100848268:     	lsl	x12, x12, x11
10084826c:     	orr	x15, x12, x15
100848270:     	add	x11, x11, #0x8
100848274:     	cmp	x10, x9
100848278:     	b.ne	0x100848264 <_js_json_stringify_full+0x4a4>
10084827c:     	orr	x8, x15, x8, lsl #40
100848280:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100848284:     	orr	x0, x8, x9
100848288:     	b	0x100847e50 <_js_json_stringify_full+0x90>
10084828c:     	cmp	w17, #0x8
100848290:     	b.eq	0x1008482d4 <_js_json_stringify_full+0x514>
100848294:     	cmp	w17, #0x9
100848298:     	b.eq	0x1008482e4 <_js_json_stringify_full+0x524>
10084829c:     	cmp	w17, #0xa
1008482a0:     	b.ne	0x1008482bc <_js_json_stringify_full+0x4fc>
1008482a4:     	mov	w16, #0x6e              ; =110
1008482a8:     	b	0x1008482e8 <_js_json_stringify_full+0x528>
1008482ac:     	cmp	w17, #0x22
1008482b0:     	b.eq	0x1008482e8 <_js_json_stringify_full+0x528>
1008482b4:     	cmp	w17, #0x5c
1008482b8:     	b.eq	0x1008482e8 <_js_json_stringify_full+0x528>
1008482bc:     	cmp	w16, #0x20
1008482c0:     	b.lt	0x1008482ec <_js_json_stringify_full+0x52c>
1008482c4:     	add	x14, sp, #0x18
1008482c8:     	strb	w16, [x14, x12]
1008482cc:     	add	x12, x12, #0x1
1008482d0:     	b	0x100848430 <_js_json_stringify_full+0x670>
1008482d4:     	mov	w16, #0x62              ; =98
1008482d8:     	b	0x1008482e8 <_js_json_stringify_full+0x528>
1008482dc:     	mov	w16, #0x66              ; =102
1008482e0:     	b	0x1008482e8 <_js_json_stringify_full+0x528>
1008482e4:     	mov	w16, #0x74              ; =116
1008482e8:     	tbz	w15, #0x0, 0x10084841c <_js_json_stringify_full+0x65c>
1008482ec:     	mov	x10, #0x7ffd000000000000 ; =9222527611924643840
1008482f0:     	cmp	x9, x10
1008482f4:     	b.eq	0x100848358 <_js_json_stringify_full+0x598>
1008482f8:     	mov	x10, #0x7fff000000000000 ; =9223090561878065152
1008482fc:     	cmp	x9, x10
100848300:     	b.ne	0x100847e04 <_js_json_stringify_full+0x44>
100848304:     	and	x0, x8, #0xffffffffffff
100848308:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
10084830c:     	mov	x9, #0x7fffffffffff     ; =140737488355327
100848310:     	movk	x9, #0xffef, lsl #16
100848314:     	cmp	x8, x9
100848318:     	b.hi	0x100847e04 <_js_json_stringify_full+0x44>
10084831c:     	ldr	w8, [x0, #0x4]
100848320:     	cmp	w8, #0x40
100848324:     	b.lo	0x100847e04 <_js_json_stringify_full+0x44>
100848328:     	mov.16b	v8, v2
10084832c:     	mov.16b	v10, v1
100848330:     	mov.16b	v9, v0
100848334:     	bl	0x1004f3068 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json16stringify_string17quote_heap_string>
100848338:     	mov.16b	v0, v9
10084833c:     	mov.16b	v1, v10
100848340:     	mov.16b	v2, v8
100848344:     	cmp	x0, #0x1
100848348:     	b.ne	0x100847e04 <_js_json_stringify_full+0x44>
10084834c:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100848350:     	bfxil	x0, x1, #0, #48
100848354:     	b	0x100847e50 <_js_json_stringify_full+0x90>
100848358:     	mov.16b	v8, v0
10084835c:     	mov.16b	v9, v1
100848360:     	mov.16b	v10, v2
100848364:     	and	x19, x8, #0xffffffffffff
100848368:     	mov	x0, x19
10084836c:     	bl	0x10057c3c0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100848370:     	cbz	x0, 0x1008483a4 <_js_json_stringify_full+0x5e4>
100848374:     	ldrb	w8, [x0]
100848378:     	cmp	w8, #0x2
10084837c:     	b.ne	0x1008483a4 <_js_json_stringify_full+0x5e4>
100848380:     	ldrsb	w8, [x0, #0x1]
100848384:     	tbnz	w8, #0x1f, 0x1008483a4 <_js_json_stringify_full+0x5e4>
100848388:     	ldrh	w8, [x0, #0x2]
10084838c:     	tbnz	w8, #0xb, 0x1008483a4 <_js_json_stringify_full+0x5e4>
100848390:     	ldr	w8, [x0, #0x4]
100848394:     	cmp	w8, #0x18
100848398:     	b.lo	0x1008483a4 <_js_json_stringify_full+0x5e4>
10084839c:     	ldr	w8, [x19]
1008483a0:     	cbz	w8, 0x1008484b8 <_js_json_stringify_full+0x6f8>
1008483a4:     	mov	x0, x19
1008483a8:     	bl	0x10057c3c0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1008483ac:     	mov.16b	v2, v10
1008483b0:     	mov.16b	v1, v9
1008483b4:     	mov.16b	v0, v8
1008483b8:     	cbz	x0, 0x100847e04 <_js_json_stringify_full+0x44>
1008483bc:     	ldrb	w8, [x0]
1008483c0:     	cmp	w8, #0x2
1008483c4:     	b.ne	0x100847e04 <_js_json_stringify_full+0x44>
1008483c8:     	ldrh	w8, [x0, #0x2]
1008483cc:     	tbnz	w8, #0xb, 0x100847e04 <_js_json_stringify_full+0x44>
1008483d0:     	ldr	w8, [x0, #0x4]
1008483d4:     	cmp	w8, #0x18
1008483d8:     	b.lo	0x100847e04 <_js_json_stringify_full+0x44>
1008483dc:     	ldr	w8, [x19]
1008483e0:     	cbnz	w8, 0x100847e04 <_js_json_stringify_full+0x44>
1008483e4:     	mov	x22, x0
1008483e8:     	mov	x0, x19
1008483ec:     	bl	0x100348000 <__RNvNtCs2EcWOpJ680c_13perry_runtime6object17object_keys_array>
1008483f0:     	cbz	x0, 0x100848510 <_js_json_stringify_full+0x750>
1008483f4:     	ldr	w20, [x0]
1008483f8:     	cmp	w20, #0x4
1008483fc:     	mov.16b	v2, v10
100848400:     	mov.16b	v1, v9
100848404:     	mov.16b	v0, v8
100848408:     	b.hi	0x100847e04 <_js_json_stringify_full+0x44>
10084840c:     	ldr	w8, [x0, #0x4]
100848410:     	cmp	w20, w8
100848414:     	b.hi	0x100847e04 <_js_json_stringify_full+0x44>
100848418:     	b	0x100848520 <_js_json_stringify_full+0x760>
10084841c:     	add	x15, sp, #0x18
100848420:     	mov	w17, #0x5c              ; =92
100848424:     	strb	w17, [x15, x12]
100848428:     	add	x12, x12, #0x2
10084842c:     	strb	w16, [x14, #0x1]
100848430:     	cmp	w11, #0x2
100848434:     	b.eq	0x100847fe4 <_js_json_stringify_full+0x224>
100848438:     	ldrb	w13, [x13, #0x2]
10084843c:     	sxtb	w11, w13
100848440:     	cmp	w13, #0xb
100848444:     	b.le	0x100848468 <_js_json_stringify_full+0x6a8>
100848448:     	cmp	w13, #0x21
10084844c:     	b.gt	0x100848488 <_js_json_stringify_full+0x6c8>
100848450:     	cmp	w13, #0xc
100848454:     	b.eq	0x1008484e0 <_js_json_stringify_full+0x720>
100848458:     	cmp	w13, #0xd
10084845c:     	b.ne	0x100848498 <_js_json_stringify_full+0x6d8>
100848460:     	mov	w11, #0x72              ; =114
100848464:     	b	0x1008484ec <_js_json_stringify_full+0x72c>
100848468:     	cmp	w13, #0x8
10084846c:     	b.eq	0x1008484d8 <_js_json_stringify_full+0x718>
100848470:     	cmp	w13, #0x9
100848474:     	b.eq	0x1008484e8 <_js_json_stringify_full+0x728>
100848478:     	cmp	w13, #0xa
10084847c:     	b.ne	0x100848498 <_js_json_stringify_full+0x6d8>
100848480:     	mov	w11, #0x6e              ; =110
100848484:     	b	0x1008484ec <_js_json_stringify_full+0x72c>
100848488:     	cmp	w13, #0x22
10084848c:     	b.eq	0x1008484ec <_js_json_stringify_full+0x72c>
100848490:     	cmp	w13, #0x5c
100848494:     	b.eq	0x1008484ec <_js_json_stringify_full+0x72c>
100848498:     	cmp	x12, #0x3
10084849c:     	mov	w13, #0x20              ; =32
1008484a0:     	ccmp	w11, w13, #0x8, ls
1008484a4:     	b.lt	0x1008482ec <_js_json_stringify_full+0x52c>
1008484a8:     	add	x8, sp, #0x18
1008484ac:     	strb	w11, [x8, x12]
1008484b0:     	add	x12, x12, #0x1
1008484b4:     	b	0x100847fe4 <_js_json_stringify_full+0x224>
1008484b8:     	mov	x1, x0
1008484bc:     	mov	x0, x19
1008484c0:     	mov	x22, x1
1008484c4:     	bl	0x1004f91c0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json23stringify_record_output20emit_repeated_output>
1008484c8:     	cmp	x0, #0x1
1008484cc:     	b.ne	0x1008485e8 <_js_json_stringify_full+0x828>
1008484d0:     	mov	x0, x1
1008484d4:     	b	0x100847e50 <_js_json_stringify_full+0x90>
1008484d8:     	mov	w11, #0x62              ; =98
1008484dc:     	b	0x1008484ec <_js_json_stringify_full+0x72c>
1008484e0:     	mov	w11, #0x66              ; =102
1008484e4:     	b	0x1008484ec <_js_json_stringify_full+0x72c>
1008484e8:     	mov	w11, #0x74              ; =116
1008484ec:     	cmp	x12, #0x2
1008484f0:     	b.hi	0x1008482ec <_js_json_stringify_full+0x52c>
1008484f4:     	add	x8, sp, #0x18
1008484f8:     	add	x8, x8, x12
1008484fc:     	add	x12, x12, #0x2
100848500:     	mov	w9, #0x5c               ; =92
100848504:     	strb	w9, [x8]
100848508:     	strb	w11, [x8, #0x1]
10084850c:     	b	0x100847fe4 <_js_json_stringify_full+0x224>
100848510:     	mov	x20, #0x0               ; =0
100848514:     	mov.16b	v2, v10
100848518:     	mov.16b	v1, v9
10084851c:     	mov.16b	v0, v8
100848520:     	ldr	w8, [x22, #0x4]
100848524:     	lsl	x9, x20, #3
100848528:     	add	x9, x9, #0x18
10084852c:     	cmp	x9, x8
100848530:     	b.hi	0x100847e04 <_js_json_stringify_full+0x44>
100848534:     	ldr	w8, [x19, #0x4]
100848538:     	mov	w9, #-0x40000000        ; =-1073741824
10084853c:     	nop
100848540:     	cmp	w8, w9
100848544:     	csel	w8, w8, wzr, lt
100848548:     	mov	x22, x0
10084854c:     	mov	x0, x8
100848550:     	bl	0x1005e70a4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
100848554:     	mov.16b	v0, v8
100848558:     	mov.16b	v1, v9
10084855c:     	mov.16b	v2, v10
100848560:     	mov	w9, #0x2                ; =2
100848564:     	cmp	w1, #0x2
100848568:     	csel	w10, w1, w9, hi
10084856c:     	tst	w0, #0x1
100848570:     	csel	x8, x10, x9, ne
100848574:     	cmp	x20, x8
100848578:     	b.hi	0x100847e04 <_js_json_stringify_full+0x44>
10084857c:     	cbz	x20, 0x100848694 <_js_json_stringify_full+0x8d4>
100848580:     	mov	x0, x22
100848584:     	mov	x1, x20
100848588:     	bl	0x1004f0180 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
10084858c:     	mov.16b	v2, v10
100848590:     	mov.16b	v1, v9
100848594:     	mov.16b	v0, v8
100848598:     	tbz	w0, #0x0, 0x100847e04 <_js_json_stringify_full+0x44>
10084859c:     	str	x21, [sp, #0x8]
1008485a0:     	cmp	x20, #0x1
1008485a4:     	b.eq	0x1008486b0 <_js_json_stringify_full+0x8f0>
1008485a8:     	cmp	x20, #0x2
1008485ac:     	b.ne	0x1008486d8 <_js_json_stringify_full+0x918>
1008485b0:     	mov	x21, #0x0               ; =0
1008485b4:     	add	x22, x19, #0x10
1008485b8:     	mov	w8, #0x1                ; =1
1008485bc:     	mov	x23, x8
1008485c0:     	ldr	x1, [x22, x21, lsl #3]
1008485c4:     	add	x0, sp, #0x18
1008485c8:     	bl	0x1004f01d4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
1008485cc:     	ldr	w8, [sp, #0x18]
1008485d0:     	cmn	w8, #0x1
1008485d4:     	b.ne	0x1008486bc <_js_json_stringify_full+0x8fc>
1008485d8:     	mov	w8, #0x0                ; =0
1008485dc:     	mov	w21, #0x1               ; =1
1008485e0:     	tbnz	w23, #0x0, 0x1008485bc <_js_json_stringify_full+0x7fc>
1008485e4:     	b	0x1008486d8 <_js_json_stringify_full+0x918>
1008485e8:     	mov	x0, x19
1008485ec:     	bl	0x100348000 <__RNvNtCs2EcWOpJ680c_13perry_runtime6object17object_keys_array>
1008485f0:     	cbz	x0, 0x10084867c <_js_json_stringify_full+0x8bc>
1008485f4:     	ldr	w20, [x0]
1008485f8:     	cbz	w20, 0x10084867c <_js_json_stringify_full+0x8bc>
1008485fc:     	cmp	w20, #0x8
100848600:     	b.hi	0x1008483a4 <_js_json_stringify_full+0x5e4>
100848604:     	ldr	w8, [x0, #0x4]
100848608:     	cmp	w20, w8
10084860c:     	b.hi	0x1008483a4 <_js_json_stringify_full+0x5e4>
100848610:     	ldr	w8, [x22, #0x4]
100848614:     	lsl	x9, x20, #3
100848618:     	add	x9, x9, #0x18
10084861c:     	cmp	x9, x8
100848620:     	b.hi	0x1008483a4 <_js_json_stringify_full+0x5e4>
100848624:     	ldr	w8, [x19, #0x4]
100848628:     	mov	w9, #-0x40000000        ; =-1073741824
10084862c:     	cmp	w8, w9
100848630:     	csel	w8, w8, wzr, lt
100848634:     	mov	x22, x0
100848638:     	mov	x0, x8
10084863c:     	bl	0x1005e70a4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
100848640:     	mov	w9, #0x2                ; =2
100848644:     	cmp	w1, #0x2
100848648:     	csel	w10, w1, w9, hi
10084864c:     	tst	w0, #0x1
100848650:     	csel	w8, w10, w9, ne
100848654:     	cmp	w20, w8
100848658:     	b.hi	0x1008483a4 <_js_json_stringify_full+0x5e4>
10084865c:     	mov	x0, x22
100848660:     	mov	x1, x20
100848664:     	bl	0x1004f0180 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
100848668:     	cbz	w0, 0x1008483a4 <_js_json_stringify_full+0x5e4>
10084866c:     	mov	x0, x19
100848670:     	mov	x1, x20
100848674:     	bl	0x1004f8300 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json23stringify_record_output11emit_record>
100848678:     	b	0x100848684 <_js_json_stringify_full+0x8c4>
10084867c:     	mov	x0, x19
100848680:     	bl	0x1004f9080 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json23stringify_record_output17emit_empty_object>
100848684:     	mov	x8, x0
100848688:     	mov	x0, x1
10084868c:     	tbnz	w8, #0x0, 0x100847e50 <_js_json_stringify_full+0x90>
100848690:     	b	0x1008483a4 <_js_json_stringify_full+0x5e4>
100848694:     	mov	x0, x19
100848698:     	bl	0x1004f8130 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
10084869c:     	mov	w8, w0
1008486a0:     	mov	x0, #0x7d7b             ; =32123
1008486a4:     	movk	x0, #0x200, lsl #32
1008486a8:     	movk	x0, #0x7ff9, lsl #48
1008486ac:     	b	0x1008486f0 <_js_json_stringify_full+0x930>
1008486b0:     	mov	x0, x19
1008486b4:     	bl	0x1004efd80 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat21emit_one_field_object>
1008486b8:     	b	0x1008486e4 <_js_json_stringify_full+0x924>
1008486bc:     	add	x2, sp, #0x18
1008486c0:     	mov	x0, x19
1008486c4:     	mov	x1, x21
1008486c8:     	bl	0x1004f0580 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
1008486cc:     	mov	x8, x0
1008486d0:     	tbnz	w8, #0x0, 0x1008484d0 <_js_json_stringify_full+0x710>
1008486d4:     	mov	w20, #0x2               ; =2
1008486d8:     	mov	x0, x19
1008486dc:     	mov	x1, x20
1008486e0:     	bl	0x1004eec00 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat11emit_object>
1008486e4:     	mov	x8, x0
1008486e8:     	mov	x0, x1
1008486ec:     	ldr	x21, [sp, #0x8]
1008486f0:     	tbnz	w8, #0x0, 0x100847e50 <_js_json_stringify_full+0x90>
1008486f4:     	mov	w8, #0x1                ; =1
1008486f8:     	mov.16b	v2, v10
1008486fc:     	mov.16b	v1, v9
100848700:     	mov.16b	v0, v8
100848704:     	cmp	x21, #0x2
100848708:     	csel	w0, wzr, w8, hs
10084870c:     	ldp	x29, x30, [sp, #0x90]
100848710:     	ldp	x20, x19, [sp, #0x80]
100848714:     	ldp	x22, x21, [sp, #0x70]
100848718:     	ldp	x24, x23, [sp, #0x60]
10084871c:     	ldp	d9, d8, [sp, #0x50]
100848720:     	ldp	d11, d10, [sp, #0x40]
100848724:     	add	sp, sp, #0xa0
100848728:     	b	0x100501688 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback>
10084872c:     	adrp	x2, 0x100ef8000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100848730:     	add	x2, x2, #0x3c8
100848734:     	mov	w0, #0x5                ; =5
100848738:     	mov	w1, #0x5                ; =5
10084873c:     	bl	0x100b138cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
		...
