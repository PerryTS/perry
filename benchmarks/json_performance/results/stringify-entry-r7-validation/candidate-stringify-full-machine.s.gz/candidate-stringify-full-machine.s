
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/stringify-entry-r7/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100144210 <__RINvMs2_NtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer23stringify_full_fallbacks3_0EBc_>:
100144210:     	stp	x20, x19, [sp, #-0x20]!
100144214:     	stp	x29, x30, [sp, #0x10]
100144218:     	add	x29, sp, #0x10
10014421c:     	mov	x19, x1
100144220:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100144224:     	ldr	x8, [x8, #0x48]
100144228:     	cmn	x8, #0x1
10014422c:     	b.eq	0x100144294 <__RINvMs2_NtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer23stringify_full_fallbacks3_0EBc_+0x84>
100144230:     	mrs	x9, TPIDRRO_EL0
100144234:     	and	x9, x9, #0xfffffffffffffff8
100144238:     	ldr	x8, [x9, x8, lsl #3]
10014423c:     	cbz	x8, 0x100144294 <__RINvMs2_NtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer23stringify_full_fallbacks3_0EBc_+0x84>
100144240:     	ldr	x8, [x8, #0x19e8]
100144244:     	ldr	x0, [x0]
100144248:     	cbz	x8, 0x100144298 <__RINvMs2_NtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer23stringify_full_fallbacks3_0EBc_+0x88>
10014424c:     	ldr	x9, [x8]
100144250:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100144254:     	cmp	x9, x10
100144258:     	b.hs	0x1001442c4 <__RINvMs2_NtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer23stringify_full_fallbacks3_0EBc_+0xb4>
10014425c:     	add	x10, x9, #0x1
100144260:     	str	x10, [x8]
100144264:     	ldr	x10, [x8, #0x18]
100144268:     	cmp	x0, x10
10014426c:     	b.hs	0x1001442d0 <__RINvMs2_NtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer23stringify_full_fallbacks3_0EBc_+0xc0>
100144270:     	ldr	x10, [x8, #0x10]
100144274:     	mov	w11, #0x18              ; =24
100144278:     	madd	x10, x0, x11, x10
10014427c:     	ldr	x11, [x10]
100144280:     	cmp	x11, #0x1
100144284:     	b.ne	0x1001442d4 <__RINvMs2_NtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer23stringify_full_fallbacks3_0EBc_+0xc4>
100144288:     	ldr	x1, [x10, #0x8]
10014428c:     	str	x9, [x8]
100144290:     	b	0x1001442a0 <__RINvMs2_NtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer23stringify_full_fallbacks3_0EBc_+0x90>
100144294:     	ldr	x0, [x0]
100144298:     	bl	0x10013c5d0 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
10014429c:     	mov	x1, x0
1001442a0:     	ldp	x8, x9, [x19]
1001442a4:     	ldr	x0, [x8]
1001442a8:     	ldr	d0, [x9]
1001442ac:     	ldp	x2, x8, [x19, #0x10]
1001442b0:     	ldp	x3, x4, [x8, #0x8]
1001442b4:     	mov	x5, #0x0                ; =0
1001442b8:     	ldp	x29, x30, [sp, #0x10]
1001442bc:     	ldp	x20, x19, [sp], #0x20
1001442c0:     	b	0x100503ec4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer30dispatch_pointer_with_replacer>
1001442c4:     	adrp	x0, 0x100ef7000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
1001442c8:     	add	x0, x0, #0xd70
1001442cc:     	bl	0x100b1379c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1001442d0:     	bl	0x100b4c954 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
1001442d4:     	adrp	x0, 0x100c43000 <_PERRY_EMPTY_STRING+0xa74>
1001442d8:     	add	x0, x0, #0x1e7
1001442dc:     	mov	w1, #0xb                ; =11
1001442e0:     	bl	0x100b4c91c <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>

0000000100501688 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback>:
100501688:     	sub	sp, sp, #0x130
10050168c:     	stp	d11, d10, [sp, #0xb0]
100501690:     	stp	d9, d8, [sp, #0xc0]
100501694:     	stp	x28, x27, [sp, #0xd0]
100501698:     	stp	x26, x25, [sp, #0xe0]
10050169c:     	stp	x24, x23, [sp, #0xf0]
1005016a0:     	stp	x22, x21, [sp, #0x100]
1005016a4:     	stp	x20, x19, [sp, #0x110]
1005016a8:     	stp	x29, x30, [sp, #0x120]
1005016ac:     	add	x29, sp, #0x120
1005016b0:     	mov.16b	v8, v0
1005016b4:     	mov	x19, #0x1               ; =1
1005016b8:     	movk	x19, #0x7ffc, lsl #48
1005016bc:     	fmov	x20, d8
1005016c0:     	cmp	x20, x19
1005016c4:     	b.eq	0x100503084 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19fc>
1005016c8:     	mov.16b	v10, v2
1005016cc:     	mov.16b	v9, v1
1005016d0:     	and	x21, x20, #0xffff000000000000
1005016d4:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1005016d8:     	cmp	x21, x8
1005016dc:     	b.ne	0x100501714 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x8c>
1005016e0:     	and	x9, x20, #0xffffffffffff
1005016e4:     	cmp	x9, #0x100, lsl #12     ; =0x100000
1005016e8:     	b.lo	0x100501700 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x78>
1005016ec:     	ldr	w8, [x9, #0xc]
1005016f0:     	mov	w9, #0x4f53             ; =20307
1005016f4:     	movk	w9, #0x434c, lsl #16
1005016f8:     	cmp	w8, w9
1005016fc:     	b.eq	0x100503084 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19fc>
100501700:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100501704:     	cmp	x21, x8
100501708:     	b.ne	0x10050174c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xc4>
10050170c:     	and	x8, x20, #0xffffffffffff
100501710:     	b	0x10050177c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xf4>
100501714:     	lsr	x8, x20, #52
100501718:     	cbnz	x8, 0x100501814 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x18c>
10050171c:     	and	x8, x20, #0x7
100501720:     	cbz	x20, 0x100501758 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xd0>
100501724:     	cbnz	x8, 0x100501758 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xd0>
100501728:     	mov	x22, x0
10050172c:     	mov	x0, x20
100501730:     	bl	0x100510a38 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100501734:     	mov	x8, x0
100501738:     	mov	x0, x22
10050173c:     	mov	x9, x20
100501740:     	tbnz	w8, #0x0, 0x1005016e4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x5c>
100501744:     	mov	x8, #0x0                ; =0
100501748:     	b	0x100501758 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xd0>
10050174c:     	lsr	x8, x20, #52
100501750:     	cbnz	x8, 0x100501814 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x18c>
100501754:     	and	x8, x20, #0x7
100501758:     	cbz	x20, 0x100501814 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x18c>
10050175c:     	cbnz	x8, 0x100501814 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x18c>
100501760:     	mov	x22, x0
100501764:     	mov	x0, x20
100501768:     	bl	0x100510a38 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10050176c:     	mov	x9, x0
100501770:     	mov	x0, x22
100501774:     	mov	x8, x20
100501778:     	tbz	w9, #0x0, 0x100501814 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x18c>
10050177c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100501780:     	b.lo	0x100501814 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x18c>
100501784:     	adrp	x9, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
100501788:     	add	x9, x9, #0xfb0
10050178c:     	ldaprb	w9, [x9]
100501790:     	cbz	w9, 0x100501814 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x18c>
100501794:     	lsr	x9, x8, #3
100501798:     	mov	x10, #0x7c15            ; =31765
10050179c:     	movk	x10, #0x7f4a, lsl #16
1005017a0:     	movk	x10, #0x79b9, lsl #32
1005017a4:     	movk	x10, #0x9e37, lsl #48
1005017a8:     	mul	x9, x9, x10
1005017ac:     	lsr	x11, x9, #54
1005017b0:     	lsr	x12, x9, #60
1005017b4:     	adrp	x10, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1005017b8:     	add	x10, x10, #0xf30
1005017bc:     	add	x12, x10, x12, lsl #3
1005017c0:     	ldapr	x12, [x12]
1005017c4:     	lsr	x11, x12, x11
1005017c8:     	tbz	w11, #0x0, 0x100501814 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x18c>
1005017cc:     	lsr	x11, x9, #44
1005017d0:     	ubfx	x12, x9, #50, #4
1005017d4:     	add	x12, x10, x12, lsl #3
1005017d8:     	ldapr	x12, [x12]
1005017dc:     	lsr	x11, x12, x11
1005017e0:     	tbz	w11, #0x0, 0x100501814 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x18c>
1005017e4:     	lsr	x11, x9, #34
1005017e8:     	ubfx	x9, x9, #40, #4
1005017ec:     	add	x9, x10, x9, lsl #3
1005017f0:     	ldapr	x9, [x9]
1005017f4:     	lsr	x9, x9, x11
1005017f8:     	tbz	w9, #0x0, 0x100501814 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x18c>
1005017fc:     	mov	x22, x0
100501800:     	mov	x0, x8
100501804:     	bl	0x10034cdec <__RNvNtCs2EcWOpJ680c_13perry_runtime6symbol25is_registered_symbol_slow>
100501808:     	mov	x8, x0
10050180c:     	mov	x0, x22
100501810:     	tbnz	w8, #0x0, 0x100503084 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19fc>
100501814:     	tbz	w0, #0x0, 0x100501834 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1ac>
100501818:     	mov.16b	v0, v8
10050181c:     	bl	0x1004ee13c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100501820:     	cmp	x0, #0x1
100501824:     	b.ne	0x100501834 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1ac>
100501828:     	mov	x19, #0x7fff000000000000 ; =9223090561878065152
10050182c:     	bfxil	x19, x1, #0, #48
100501830:     	b	0x100503084 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19fc>
100501834:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100501838:     	cmp	x21, x8
10050183c:     	b.ne	0x10050188c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x204>
100501840:     	ands	x21, x20, #0xffffffffffff
100501844:     	b.eq	0x10050188c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x204>
100501848:     	mov	x0, x21
10050184c:     	bl	0x100510a38 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100501850:     	cbz	w0, 0x10050188c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x204>
100501854:     	ldurb	w8, [x21, #-0x8]
100501858:     	cmp	w8, #0x9
10050185c:     	b.ne	0x10050188c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x204>
100501860:     	ldr	w8, [x21, #0x4]
100501864:     	mov	w9, #0x5841             ; =22593
100501868:     	movk	w9, #0x4c5a, lsl #16
10050186c:     	cmp	w8, w9
100501870:     	b.ne	0x10050188c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x204>
100501874:     	mov	x0, x21
100501878:     	bl	0x10068a454 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime9json_tape8mutation26resolve_materialized_array>
10050187c:     	cbz	x0, 0x10050188c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x204>
100501880:     	mov	x20, #0x7ffd000000000000 ; =9222527611924643840
100501884:     	bfxil	x20, x0, #0, #48
100501888:     	fmov	d8, x20
10050188c:     	fmov	x21, d10
100501890:     	mov	w8, #0x7ffd             ; =32765
100501894:     	cmp	x8, x21, lsr #48
100501898:     	b.ne	0x1005018ac <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x224>
10050189c:     	and	x1, x21, #0xffffffffffff
1005018a0:     	cmp	x1, #0x100, lsl #12     ; =0x100000
1005018a4:     	b.hs	0x1005018c0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x238>
1005018a8:     	b	0x100501914 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x28c>
1005018ac:     	sub	x8, x21, #0x100, lsl #12 ; =0x100000
1005018b0:     	mov	x9, #0xfffffff00000     ; =281474975662080
1005018b4:     	mov	x1, x21
1005018b8:     	cmp	x8, x9
1005018bc:     	b.hs	0x100501914 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x28c>
1005018c0:     	lsr	x8, x1, #47
1005018c4:     	cbnz	x8, 0x100501914 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x28c>
1005018c8:     	add	x0, sp, #0x58
1005018cc:     	bl	0x10077026c <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
1005018d0:     	ldr	w8, [sp, #0x58]
1005018d4:     	tbz	w8, #0x0, 0x100501914 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x28c>
1005018d8:     	ldr	w8, [sp, #0x60]
1005018dc:     	mov	w9, #-0xff30            ; =-65328
1005018e0:     	cmp	w8, w9
1005018e4:     	b.eq	0x100501908 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x280>
1005018e8:     	mov	w9, #-0xff2f            ; =-65327
1005018ec:     	cmp	w8, w9
1005018f0:     	b.ne	0x100501914 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x28c>
1005018f4:     	mov.16b	v0, v10
1005018f8:     	bl	0x10084937c <_js_jsvalue_to_string>
1005018fc:     	mov	x21, #0x7fff000000000000 ; =9223090561878065152
100501900:     	bfxil	x21, x0, #0, #48
100501904:     	b	0x100501914 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x28c>
100501908:     	mov.16b	v0, v10
10050190c:     	bl	0x100870920 <_js_number_coerce>
100501910:     	fmov	x21, d0
100501914:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100501918:     	add	x8, x21, x8
10050191c:     	cmp	x8, #0x3
100501920:     	b.hs	0x100501964 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x2dc>
100501924:     	mov	x21, #0x0               ; =0
100501928:     	mov	w8, #0x1                ; =1
10050192c:     	stp	xzr, x8, [sp, #0x20]
100501930:     	str	xzr, [sp, #0x30]
100501934:     	fmov	x22, d9
100501938:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
10050193c:     	add	x8, x22, x8
100501940:     	cmp	x8, #0x2
100501944:     	b.hs	0x100501994 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x30c>
100501948:     	mov	x23, #0x0               ; =0
10050194c:     	mov	w28, #0x0               ; =0
100501950:     	mov	x26, #-0x1              ; =-1
100501954:     	mov	w24, #0x1               ; =1
100501958:     	mov	w8, #0x8                ; =8
10050195c:     	str	x8, [sp, #0x18]
100501960:     	b	0x1005028bc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1234>
100501964:     	and	x8, x21, #0xffff000000000000
100501968:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10050196c:     	cmp	x8, x9
100501970:     	b.eq	0x100501ad8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x450>
100501974:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100501978:     	cmp	x8, x9
10050197c:     	b.ne	0x100501b64 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x4dc>
100501980:     	and	x8, x21, #0xffffffffffff
100501984:     	cmp	x8, #0x1, lsl #12       ; =0x1000
100501988:     	b.hs	0x100501bbc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x534>
10050198c:     	mov	x9, #0x0                ; =0
100501990:     	b	0x100501bc4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x53c>
100501994:     	and	x27, x22, #0xffff000000000000
100501998:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10050199c:     	cmp	x27, x8
1005019a0:     	b.ne	0x100501aac <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x424>
1005019a4:     	and	x25, x22, #0xffffffffffff
1005019a8:     	cmp	x25, #0x100, lsl #12    ; =0x100000
1005019ac:     	b.lo	0x10050207c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9f4>
1005019b0:     	mov	x0, x25
1005019b4:     	bl	0x10050bf40 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify17is_object_pointer>
1005019b8:     	tbnz	w0, #0x0, 0x10050207c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9f4>
1005019bc:     	lsr	x8, x25, #51
1005019c0:     	cmp	x8, #0xfff
1005019c4:     	b.lo	0x1005019dc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x354>
1005019c8:     	mov	w8, #0x7ffc             ; =32764
1005019cc:     	cmp	x8, x25, lsr #48
1005019d0:     	b.eq	0x10050207c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9f4>
1005019d4:     	ands	x25, x25, #0xffffffffffff
1005019d8:     	b.eq	0x10050207c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9f4>
1005019dc:     	and	x8, x25, #0xfffffffffff00000
1005019e0:     	lsr	x9, x25, #47
1005019e4:     	cmp	x9, #0x0
1005019e8:     	ccmp	x8, #0x0, #0x4, eq
1005019ec:     	b.eq	0x10050207c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9f4>
1005019f0:     	tst	x25, #0x3
1005019f4:     	ccmp	x25, #0x7, #0x0, eq
1005019f8:     	b.ls	0x100501e5c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x7d4>
1005019fc:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100501a00:     	ldr	x8, [x8, #0x48]
100501a04:     	cmn	x8, #0x1
100501a08:     	b.eq	0x100501dac <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x724>
100501a0c:     	mrs	x9, TPIDRRO_EL0
100501a10:     	and	x9, x9, #0xfffffffffffffff8
100501a14:     	ldr	x0, [x9, x8, lsl #3]
100501a18:     	cbz	x0, 0x100501dac <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x724>
100501a1c:     	lsr	x1, x25, #20
100501a20:     	ldr	x8, [x0, #0x10]
100501a24:     	ldrb	w9, [x8]
100501a28:     	cmp	w9, #0x2
100501a2c:     	b.ne	0x100501dc4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x73c>
100501a30:     	ldrb	w9, [x8, #0x88]
100501a34:     	tbz	w9, #0x0, 0x100501a54 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x3cc>
100501a38:     	ldr	x9, [x8, #0x80]
100501a3c:     	cmp	x9, x1
100501a40:     	b.ne	0x100501a54 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x3cc>
100501a44:     	ldp	x9, x10, [x8, #0x60]
100501a48:     	cmp	x9, x25
100501a4c:     	ccmp	x10, x25, #0x0, ls
100501a50:     	b.hi	0x100501da4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x71c>
100501a54:     	ldrb	w9, [x8, #0xb8]
100501a58:     	cbz	w9, 0x100501a78 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x3f0>
100501a5c:     	ldr	x9, [x8, #0xb0]
100501a60:     	cmp	x9, x1
100501a64:     	b.ne	0x100501a78 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x3f0>
100501a68:     	ldp	x9, x10, [x8, #0x90]
100501a6c:     	cmp	x9, x25
100501a70:     	ccmp	x10, x25, #0x0, ls
100501a74:     	b.hi	0x100502178 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xaf0>
100501a78:     	ldrb	w9, [x8, #0xe8]
100501a7c:     	cbz	w9, 0x100501d70 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x6e8>
100501a80:     	ldr	x9, [x8, #0xe0]
100501a84:     	cmp	x9, x1
100501a88:     	b.ne	0x100501d70 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x6e8>
100501a8c:     	ldr	x9, [x8, #0xc0]
100501a90:     	cmp	x9, x25
100501a94:     	b.hi	0x100501d70 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x6e8>
100501a98:     	ldr	x9, [x8, #0xc8]
100501a9c:     	cmp	x9, x25
100501aa0:     	b.ls	0x100501d70 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x6e8>
100501aa4:     	add	x9, x8, #0xc0
100501aa8:     	b	0x10050217c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xaf4>
100501aac:     	lsr	x8, x22, #52
100501ab0:     	cbnz	x8, 0x100501bac <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x524>
100501ab4:     	and	x8, x22, #0x7
100501ab8:     	cbz	x22, 0x100501d28 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x6a0>
100501abc:     	cbnz	x8, 0x100502838 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x11b0>
100501ac0:     	mov	x0, x22
100501ac4:     	bl	0x100510a38 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100501ac8:     	mov	x25, x22
100501acc:     	cbnz	w0, 0x1005019a8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x320>
100501ad0:     	mov	x8, #0x0                ; =0
100501ad4:     	b	0x100502838 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x11b0>
100501ad8:     	strb	wzr, [sp, #0x94]
100501adc:     	str	wzr, [sp, #0x90]
100501ae0:     	ubfx	x1, x21, #40, #8
100501ae4:     	cbz	x1, 0x100501b34 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x4ac>
100501ae8:     	strb	w21, [sp, #0x90]
100501aec:     	cmp	x1, #0x1
100501af0:     	b.eq	0x100501b34 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x4ac>
100501af4:     	lsr	x8, x21, #8
100501af8:     	strb	w8, [sp, #0x91]
100501afc:     	cmp	x1, #0x2
100501b00:     	b.eq	0x100501b34 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x4ac>
100501b04:     	lsr	x8, x21, #16
100501b08:     	strb	w8, [sp, #0x92]
100501b0c:     	cmp	x1, #0x3
100501b10:     	b.eq	0x100501b34 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x4ac>
100501b14:     	lsr	x8, x21, #24
100501b18:     	strb	w8, [sp, #0x93]
100501b1c:     	cmp	x1, #0x4
100501b20:     	b.eq	0x100501b34 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x4ac>
100501b24:     	lsr	x8, x21, #32
100501b28:     	strb	w8, [sp, #0x94]
100501b2c:     	cmp	x1, #0x5
100501b30:     	b.ne	0x100503388 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1d00>
100501b34:     	add	x8, sp, #0x58
100501b38:     	add	x0, sp, #0x90
100501b3c:     	bl	0x10002e158 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100501b40:     	ldr	w8, [sp, #0x58]
100501b44:     	ldp	x9, x21, [sp, #0x60]
100501b48:     	cmp	w8, #0x0
100501b4c:     	csel	x22, xzr, x21, ne
100501b50:     	csinc	x24, x9, xzr, eq
100501b54:     	tbz	x22, #0x3f, 0x100501ca4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x61c>
100501b58:     	mov	x0, #0x0                ; =0
100501b5c:     	mov	x1, x21
100501b60:     	bl	0x100b133c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100501b64:     	add	x8, x19, #0x3
100501b68:     	cmp	x21, x8
100501b6c:     	b.eq	0x100501924 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x29c>
100501b70:     	fmov	d0, x21
100501b74:     	fcvtzu	x8, d0
100501b78:     	mov	w9, #0xa                ; =10
100501b7c:     	cmp	x8, #0xa
100501b80:     	csel	x3, x8, x9, lo
100501b84:     	adrp	x1, 0x100c44000 <_PERRY_EMPTY_STRING+0x1a74>
100501b88:     	add	x1, x1, #0x71b
100501b8c:     	add	x0, sp, #0x58
100501b90:     	mov	w2, #0x1                ; =1
100501b94:     	bl	0x100230a74 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs2EcWOpJ680c_13perry_runtime>
100501b98:     	ldr	x21, [sp, #0x68]
100501b9c:     	str	x21, [sp, #0x30]
100501ba0:     	ldur	q0, [sp, #0x58]
100501ba4:     	str	q0, [sp, #0x20]
100501ba8:     	b	0x100501934 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x2ac>
100501bac:     	mov	w28, #0x0               ; =0
100501bb0:     	mov	x26, #-0x1              ; =-1
100501bb4:     	mov	w24, #0x1               ; =1
100501bb8:     	b	0x1005028bc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1234>
100501bbc:     	ldr	w21, [x8, #0x4]
100501bc0:     	add	x9, x8, #0x14
100501bc4:     	mov	x14, #0x0               ; =0
100501bc8:     	mov	x8, #0x0                ; =0
100501bcc:     	cmp	x9, #0x0
100501bd0:     	csel	x23, xzr, x21, eq
100501bd4:     	csinc	x22, x9, xzr, ne
100501bd8:     	add	x9, x22, x23
100501bdc:     	mov	w10, #0x1               ; =1
100501be0:     	mov	x11, x22
100501be4:     	b	0x100501c14 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x58c>
100501be8:     	add	x12, x11, #0x2
100501bec:     	bfi	w15, w13, #6, #5
100501bf0:     	mov	x13, x15
100501bf4:     	sub	x11, x24, x11
100501bf8:     	add	x14, x11, x12
100501bfc:     	cmp	w13, #0x10, lsl #12     ; =0x10000
100501c00:     	cinc	x11, x10, hs
100501c04:     	add	x8, x11, x8
100501c08:     	mov	x11, x12
100501c0c:     	cmp	x8, #0xa
100501c10:     	b.hi	0x100501ccc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x644>
100501c14:     	cmp	x11, x9
100501c18:     	b.eq	0x100501c7c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x5f4>
100501c1c:     	mov	x24, x14
100501c20:     	mov	x12, x11
100501c24:     	ldrsb	w14, [x12], #0x1
100501c28:     	and	w13, w14, #0xff
100501c2c:     	tbz	w14, #0x1f, 0x100501bf4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x56c>
100501c30:     	ldrb	w12, [x11, #0x1]
100501c34:     	and	w15, w12, #0x3f
100501c38:     	cmp	w13, #0xe0
100501c3c:     	b.lo	0x100501be8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x560>
100501c40:     	and	w14, w13, #0x1f
100501c44:     	ldrb	w12, [x11, #0x2]
100501c48:     	and	w12, w12, #0x3f
100501c4c:     	orr	w15, w12, w15, lsl #6
100501c50:     	cmp	w13, #0xf0
100501c54:     	b.lo	0x100501c70 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x5e8>
100501c58:     	add	x12, x11, #0x4
100501c5c:     	ldrb	w13, [x11, #0x3]
100501c60:     	and	w13, w13, #0x3f
100501c64:     	orr	w13, w13, w15, lsl #6
100501c68:     	bfi	w13, w14, #18, #3
100501c6c:     	b	0x100501bf4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x56c>
100501c70:     	add	x12, x11, #0x3
100501c74:     	orr	w13, w15, w14, lsl #12
100501c78:     	b	0x100501bf4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x56c>
100501c7c:     	cbz	x23, 0x100501d00 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x678>
100501c80:     	mov	x0, x23
100501c84:     	mov	w1, #0x1                ; =1
100501c88:     	bl	0x100b60248 <_mi_malloc_aligned>
100501c8c:     	cbz	x0, 0x100503370 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1ce8>
100501c90:     	mov	x25, x0
100501c94:     	mov	x1, x22
100501c98:     	mov	x2, x23
100501c9c:     	bl	0x100b62e6c <_writev+0x100b62e6c>
100501ca0:     	b	0x100501d08 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x680>
100501ca4:     	cbz	x22, 0x100501d14 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x68c>
100501ca8:     	mov	x0, x22
100501cac:     	mov	w1, #0x1                ; =1
100501cb0:     	bl	0x100b60248 <_mi_malloc_aligned>
100501cb4:     	cbz	x0, 0x10050337c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1cf4>
100501cb8:     	mov	x23, x0
100501cbc:     	mov	x1, x24
100501cc0:     	mov	x2, x22
100501cc4:     	bl	0x100b62e6c <_writev+0x100b62e6c>
100501cc8:     	b	0x100501d1c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x694>
100501ccc:     	cbz	x24, 0x100501d00 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x678>
100501cd0:     	cmp	x24, x23
100501cd4:     	b.hs	0x100501d2c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x6a4>
100501cd8:     	ldrsb	w8, [x22, x24]
100501cdc:     	cmn	w8, #0x40
100501ce0:     	b.ge	0x100501d30 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x6a8>
100501ce4:     	adrp	x4, 0x100f10000 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100501ce8:     	add	x4, x4, #0x288
100501cec:     	mov	x0, x22
100501cf0:     	mov	x1, x23
100501cf4:     	mov	x2, #0x0                ; =0
100501cf8:     	mov	x3, x24
100501cfc:     	bl	0x100b13738 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
100501d00:     	mov	x21, #0x0               ; =0
100501d04:     	mov	w25, #0x1               ; =1
100501d08:     	stp	x21, x25, [sp, #0x20]
100501d0c:     	str	x21, [sp, #0x30]
100501d10:     	b	0x100501934 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x2ac>
100501d14:     	mov	x21, #0x0               ; =0
100501d18:     	mov	w23, #0x1               ; =1
100501d1c:     	stp	x21, x23, [sp, #0x20]
100501d20:     	str	x21, [sp, #0x30]
100501d24:     	b	0x100501934 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x2ac>
100501d28:     	b	0x100502838 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x11b0>
100501d2c:     	b.ne	0x100501ce4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x65c>
100501d30:     	tbz	x24, #0x3f, 0x100501d40 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x6b8>
100501d34:     	mov	x0, #0x0                ; =0
100501d38:     	mov	x1, x24
100501d3c:     	bl	0x100b133c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100501d40:     	mov	x0, x24
100501d44:     	mov	w1, #0x1                ; =1
100501d48:     	bl	0x100b60248 <_mi_malloc_aligned>
100501d4c:     	mov	x25, x0
100501d50:     	mov	w0, #0x1                ; =1
100501d54:     	cbz	x25, 0x100501d38 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x6b0>
100501d58:     	mov	x0, x25
100501d5c:     	mov	x1, x22
100501d60:     	mov	x2, x24
100501d64:     	bl	0x100b62e6c <_writev+0x100b62e6c>
100501d68:     	mov	x21, x24
100501d6c:     	b	0x100501d08 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x680>
100501d70:     	ldrb	w9, [x8, #0x118]
100501d74:     	cbz	w9, 0x100501e24 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x79c>
100501d78:     	ldr	x9, [x8, #0x110]
100501d7c:     	cmp	x9, x1
100501d80:     	b.ne	0x100501e24 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x79c>
100501d84:     	ldr	x9, [x8, #0xf0]
100501d88:     	cmp	x9, x25
100501d8c:     	b.hi	0x100501e24 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x79c>
100501d90:     	ldr	x9, [x8, #0xf8]
100501d94:     	cmp	x9, x25
100501d98:     	b.ls	0x100501e24 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x79c>
100501d9c:     	add	x9, x8, #0xf0
100501da0:     	b	0x10050217c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xaf4>
100501da4:     	add	x9, x8, #0x60
100501da8:     	b	0x10050217c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xaf4>
100501dac:     	bl	0x100b403fc <__RNvNtCs2EcWOpJ680c_13perry_runtime7tls_hot12hot_uncached>
100501db0:     	lsr	x1, x25, #20
100501db4:     	ldr	x8, [x0, #0x10]
100501db8:     	ldrb	w9, [x8]
100501dbc:     	cmp	w9, #0x2
100501dc0:     	b.eq	0x100501a30 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x3a8>
100501dc4:     	ldr	x9, [x8, #0x8]
100501dc8:     	ldr	x10, [x8, #0x28]
100501dcc:     	sub	x9, x1, x9
100501dd0:     	cmp	x9, x10
100501dd4:     	b.hs	0x100501e18 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x790>
100501dd8:     	ldr	x10, [x8, #0x20]
100501ddc:     	mov	w11, #0x28              ; =40
100501de0:     	madd	x9, x9, x11, x10
100501de4:     	ldr	x10, [x9]
100501de8:     	ldr	x11, [x8, #0x10]
100501dec:     	cmp	x10, x11
100501df0:     	b.ne	0x100501e24 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x79c>
100501df4:     	ldp	x10, x11, [x9, #0x8]
100501df8:     	cmp	x10, x25
100501dfc:     	ccmp	x11, x25, #0x0, ls
100501e00:     	b.ls	0x100501e24 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x79c>
100501e04:     	ldr	x10, [x8, #0x30]
100501e08:     	add	x10, x10, #0x1
100501e0c:     	str	x10, [x8, #0x30]
100501e10:     	add	x8, x9, #0x21
100501e14:     	b	0x10050218c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xb04>
100501e18:     	ldr	x9, [x8, #0x58]
100501e1c:     	add	x9, x9, #0x1
100501e20:     	str	x9, [x8, #0x58]
100501e24:     	ldr	x9, [x8, #0x38]
100501e28:     	add	x9, x9, #0x1
100501e2c:     	str	x9, [x8, #0x38]
100501e30:     	mov	x0, x25
100501e34:     	bl	0x10051fc48 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
100501e38:     	and	w8, w0, #0xff
100501e3c:     	cbz	w8, 0x100501e5c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x7d4>
100501e40:     	ldurb	w8, [x25, #-0x8]
100501e44:     	ldurb	w9, [x25, #-0x7]
100501e48:     	mov	w10, #0x82              ; =130
100501e4c:     	and	w9, w9, w10
100501e50:     	cmp	w9, #0x2
100501e54:     	ccmp	w8, #0x1, #0x0, eq
100501e58:     	b.eq	0x100501ef0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x868>
100501e5c:     	mov	x0, x25
100501e60:     	bl	0x10057c3c0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100501e64:     	mov	x26, x0
100501e68:     	cbz	x0, 0x100501e94 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x80c>
100501e6c:     	ldrb	w8, [x26]
100501e70:     	cmp	w8, #0x1
100501e74:     	b.ne	0x100501eb4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x82c>
100501e78:     	ldrsb	w8, [x26, #0x1]
100501e7c:     	tbnz	w8, #0x1f, 0x100501f18 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x890>
100501e80:     	mov	x0, x26
100501e84:     	ldp	w9, w8, [x25]
100501e88:     	cmp	w9, w8
100501e8c:     	b.hi	0x100501f9c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x914>
100501e90:     	b	0x100501fb4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x92c>
100501e94:     	mov	x0, x25
100501e98:     	bl	0x10058abf4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime6buffer6header20is_registered_buffer>
100501e9c:     	tbnz	w0, #0x0, 0x100501eac <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x824>
100501ea0:     	mov	x0, x25
100501ea4:     	bl	0x1002a43c8 <__RNvNtCs2EcWOpJ680c_13perry_runtime10typedarray23lookup_typed_array_kind>
100501ea8:     	tbz	w0, #0x0, 0x10050207c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9f4>
100501eac:     	mov	x0, #0x0                ; =0
100501eb0:     	b	0x100501f8c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x904>
100501eb4:     	mov	x0, x26
100501eb8:     	cmp	w8, #0x1
100501ebc:     	b.eq	0x100501f8c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x904>
100501ec0:     	cmp	w8, #0x9
100501ec4:     	b.ne	0x10050207c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9f4>
100501ec8:     	ldr	w8, [x25, #0x4]
100501ecc:     	mov	w9, #0x5841             ; =22593
100501ed0:     	movk	w9, #0x4c5a, lsl #16
100501ed4:     	cmp	w8, w9
100501ed8:     	b.ne	0x10050207c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9f4>
100501edc:     	mov	x0, x25
100501ee0:     	bl	0x100375d70 <__RNvNtCs2EcWOpJ680c_13perry_runtime9json_tape22force_materialize_lazy>
100501ee4:     	mov	x25, x0
100501ee8:     	cbnz	x0, 0x100501fdc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x954>
100501eec:     	b	0x10050207c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9f4>
100501ef0:     	ldr	w8, [x25]
100501ef4:     	mov	w9, #0xe100             ; =57600
100501ef8:     	movk	w9, #0x5f5, lsl #16
100501efc:     	orr	w9, w9, #0x1
100501f00:     	cmp	w8, w9
100501f04:     	b.hs	0x100501e5c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x7d4>
100501f08:     	ldr	w9, [x25, #0x4]
100501f0c:     	cmp	w8, w9
100501f10:     	b.ls	0x100501fdc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x954>
100501f14:     	b	0x100501e5c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x7d4>
100501f18:     	ldr	x25, [x26, #0x8]
100501f1c:     	mov	x0, x25
100501f20:     	bl	0x10057c3c0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100501f24:     	cbz	x0, 0x10050207c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9f4>
100501f28:     	ldrb	w8, [x0]
100501f2c:     	cmp	w8, #0x1
100501f30:     	b.ne	0x10050207c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9f4>
100501f34:     	ldrsb	w8, [x0, #0x1]
100501f38:     	tbz	w8, #0x1f, 0x100501e84 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x7fc>
100501f3c:     	mov	w24, #0x1               ; =1
100501f40:     	ldr	x25, [x0, #0x8]
100501f44:     	mov	x0, x25
100501f48:     	bl	0x10057c3c0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100501f4c:     	cbz	x0, 0x10050207c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9f4>
100501f50:     	ldrb	w8, [x0]
100501f54:     	cmp	w8, #0x1
100501f58:     	b.ne	0x10050207c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9f4>
100501f5c:     	cmp	w24, #0x3f
100501f60:     	b.hi	0x10050207c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9f4>
100501f64:     	add	w24, w24, #0x1
100501f68:     	ldrsb	w8, [x0, #0x1]
100501f6c:     	tbnz	w8, #0x1f, 0x100501f40 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x8b8>
100501f70:     	str	x25, [x26, #0x8]
100501f74:     	ldrb	w8, [x26, #0x1]
100501f78:     	orr	w8, w8, #0x80
100501f7c:     	strb	w8, [x26, #0x1]
100501f80:     	ldrb	w8, [x0]
100501f84:     	cmp	w8, #0x1
100501f88:     	b.ne	0x100501ec0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x838>
100501f8c:     	ldp	w9, w8, [x25]
100501f90:     	cmp	w9, w8
100501f94:     	b.ls	0x100501fb4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x92c>
100501f98:     	cbz	x26, 0x100501fc4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x93c>
100501f9c:     	ldr	w9, [x0, #0x4]
100501fa0:     	ubfiz	x8, x8, #3, #32
100501fa4:     	add	x8, x8, #0x10
100501fa8:     	cmp	x8, x9
100501fac:     	b.eq	0x100501fdc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x954>
100501fb0:     	b	0x100501fc4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x93c>
100501fb4:     	mov	w8, #0xe100             ; =57600
100501fb8:     	movk	w8, #0x5f5, lsl #16
100501fbc:     	cmp	w9, w8
100501fc0:     	b.ls	0x100501fdc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x954>
100501fc4:     	mov	x0, x25
100501fc8:     	bl	0x10058abf4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime6buffer6header20is_registered_buffer>
100501fcc:     	tbnz	w0, #0x0, 0x100501fdc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x954>
100501fd0:     	mov	x0, x25
100501fd4:     	bl	0x1002a43c8 <__RNvNtCs2EcWOpJ680c_13perry_runtime10typedarray23lookup_typed_array_kind>
100501fd8:     	tbz	w0, #0x0, 0x10050207c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9f4>
100501fdc:     	ldp	w8, w9, [x25]
100501fe0:     	sub	w10, w9, #0x1
100501fe4:     	mov	w11, #0x270e            ; =9998
100501fe8:     	cmp	w10, w11
100501fec:     	ccmp	w8, w9, #0x2, ls
100501ff0:     	b.hi	0x10050207c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9f4>
100501ff4:     	and	x8, x22, #0xffffffffffff
100501ff8:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100501ffc:     	cmp	x27, x9
100502000:     	csel	x25, x8, x22, eq
100502004:     	lsr	x9, x25, #51
100502008:     	cmp	x9, #0xfff
10050200c:     	b.lo	0x100502028 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9a0>
100502010:     	lsr	x9, x25, #48
100502014:     	mov	w10, #0x7ffc            ; =32764
100502018:     	cmp	x9, x10
10050201c:     	ccmp	x8, #0x0, #0x4, ne
100502020:     	and	x25, x22, #0xffffffffffff
100502024:     	b.eq	0x100502320 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xc98>
100502028:     	sub	x8, x25, #0x100, lsl #12 ; =0x100000
10050202c:     	mov	x9, #0x7fffffffffff     ; =140737488355327
100502030:     	movk	x9, #0xffef, lsl #16
100502034:     	cmp	x8, x9
100502038:     	b.hi	0x100502320 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xc98>
10050203c:     	tst	x25, #0x3
100502040:     	b.eq	0x100502098 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xa10>
100502044:     	mov	x0, x25
100502048:     	bl	0x10057c3c0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10050204c:     	mov	x27, x0
100502050:     	cbz	x0, 0x100502128 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xaa0>
100502054:     	ldrb	w8, [x27]
100502058:     	cmp	w8, #0x1
10050205c:     	b.ne	0x10050213c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xab4>
100502060:     	ldrsb	w8, [x27, #0x1]
100502064:     	tbnz	w8, #0x1f, 0x100502280 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xbf8>
100502068:     	mov	x0, x27
10050206c:     	ldp	w9, w8, [x25]
100502070:     	cmp	w9, w8
100502074:     	b.hi	0x1005021fc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xb74>
100502078:     	b	0x1005022b8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xc30>
10050207c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100502080:     	cmp	x27, x8
100502084:     	b.ne	0x10050282c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x11a4>
100502088:     	and	x8, x22, #0xffffffffffff
10050208c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100502090:     	b.lo	0x100502864 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x11dc>
100502094:     	b	0x100502874 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x11ec>
100502098:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
10050209c:     	ldr	x8, [x8, #0x48]
1005020a0:     	cmn	x8, #0x1
1005020a4:     	b.eq	0x100502370 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xce8>
1005020a8:     	mrs	x9, TPIDRRO_EL0
1005020ac:     	and	x9, x9, #0xfffffffffffffff8
1005020b0:     	ldr	x0, [x9, x8, lsl #3]
1005020b4:     	cbz	x0, 0x100502370 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xce8>
1005020b8:     	lsr	x1, x25, #20
1005020bc:     	ldr	x8, [x0, #0x10]
1005020c0:     	ldrb	w9, [x8]
1005020c4:     	cmp	w9, #0x2
1005020c8:     	b.ne	0x100502388 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xd00>
1005020cc:     	ldrb	w9, [x8, #0x88]
1005020d0:     	tbz	w9, #0x0, 0x1005020f0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xa68>
1005020d4:     	ldr	x9, [x8, #0x80]
1005020d8:     	cmp	x9, x1
1005020dc:     	b.ne	0x1005020f0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xa68>
1005020e0:     	ldp	x9, x10, [x8, #0x60]
1005020e4:     	cmp	x9, x25
1005020e8:     	ccmp	x10, x25, #0x0, ls
1005020ec:     	b.hi	0x100502354 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xccc>
1005020f0:     	mov	x11, x21
1005020f4:     	ldrb	w9, [x8, #0xb8]
1005020f8:     	cbz	w9, 0x100502214 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xb8c>
1005020fc:     	ldr	x9, [x8, #0xb0]
100502100:     	cmp	x9, x1
100502104:     	b.ne	0x100502214 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xb8c>
100502108:     	ldr	x9, [x8, #0x90]
10050210c:     	cmp	x9, x25
100502110:     	b.hi	0x100502214 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xb8c>
100502114:     	ldr	x9, [x8, #0x98]
100502118:     	cmp	x9, x25
10050211c:     	b.ls	0x100502214 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xb8c>
100502120:     	add	x9, x8, #0x90
100502124:     	b	0x10050235c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xcd4>
100502128:     	mov	x0, x25
10050212c:     	bl	0x10058abf4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime6buffer6header20is_registered_buffer>
100502130:     	tbz	w0, #0x0, 0x10050219c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xb14>
100502134:     	mov	x0, #0x0                ; =0
100502138:     	b	0x1005021ec <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xb64>
10050213c:     	mov	x0, x27
100502140:     	cmp	w8, #0x1
100502144:     	b.eq	0x1005021ec <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xb64>
100502148:     	cmp	w8, #0x9
10050214c:     	b.ne	0x100502320 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xc98>
100502150:     	ldr	w8, [x25, #0x4]
100502154:     	mov	w9, #0x5841             ; =22593
100502158:     	movk	w9, #0x4c5a, lsl #16
10050215c:     	cmp	w8, w9
100502160:     	b.ne	0x100502320 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xc98>
100502164:     	mov	x0, x25
100502168:     	bl	0x100375d70 <__RNvNtCs2EcWOpJ680c_13perry_runtime9json_tape22force_materialize_lazy>
10050216c:     	mov	x25, x0
100502170:     	cbnz	x0, 0x100502458 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xdd0>
100502174:     	b	0x100502320 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xc98>
100502178:     	add	x9, x8, #0x90
10050217c:     	ldr	x10, [x8, #0x30]
100502180:     	add	x10, x10, #0x1
100502184:     	str	x10, [x8, #0x30]
100502188:     	add	x8, x9, #0x19
10050218c:     	ldrb	w8, [x8]
100502190:     	cmp	w8, #0xff
100502194:     	b.ne	0x100501e3c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x7b4>
100502198:     	b	0x100501e30 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x7a8>
10050219c:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1005021a0:     	add	x8, x8, #0xec0
1005021a4:     	ldaprb	w8, [x8]
1005021a8:     	cbz	w8, 0x100502320 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xc98>
1005021ac:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1005021b0:     	add	x8, x8, #0x58
1005021b4:     	ldapr	x8, [x8]
1005021b8:     	cmp	x8, x25
1005021bc:     	b.hi	0x100502320 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xc98>
1005021c0:     	mov	x23, x25
1005021c4:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1005021c8:     	add	x8, x8, #0x60
1005021cc:     	ldapr	x8, [x8]
1005021d0:     	cmp	x8, x25
1005021d4:     	b.lo	0x100502320 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xc98>
1005021d8:     	mov	x0, x23
1005021dc:     	bl	0x1002a50f8 <__RNvNtCs2EcWOpJ680c_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1005021e0:     	tbz	w0, #0x0, 0x100502320 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xc98>
1005021e4:     	mov	x0, #0x0                ; =0
1005021e8:     	mov	x25, x23
1005021ec:     	ldp	w9, w8, [x25]
1005021f0:     	cmp	w9, w8
1005021f4:     	b.ls	0x1005022b8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xc30>
1005021f8:     	cbz	x27, 0x1005022c8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xc40>
1005021fc:     	ldr	w9, [x0, #0x4]
100502200:     	ubfiz	x8, x8, #3, #32
100502204:     	add	x8, x8, #0x10
100502208:     	cmp	x8, x9
10050220c:     	b.ne	0x1005022c8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xc40>
100502210:     	b	0x100502458 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xdd0>
100502214:     	ldrb	w9, [x8, #0xe8]
100502218:     	cbz	w9, 0x100502248 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xbc0>
10050221c:     	ldr	x9, [x8, #0xe0]
100502220:     	cmp	x9, x1
100502224:     	b.ne	0x100502248 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xbc0>
100502228:     	ldr	x9, [x8, #0xc0]
10050222c:     	cmp	x9, x25
100502230:     	b.hi	0x100502248 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xbc0>
100502234:     	ldr	x9, [x8, #0xc8]
100502238:     	cmp	x9, x25
10050223c:     	b.ls	0x100502248 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xbc0>
100502240:     	add	x9, x8, #0xc0
100502244:     	b	0x10050235c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xcd4>
100502248:     	ldrb	w9, [x8, #0x118]
10050224c:     	mov	x21, x11
100502250:     	cbz	w9, 0x1005023fc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xd74>
100502254:     	ldr	x9, [x8, #0x110]
100502258:     	cmp	x9, x1
10050225c:     	b.ne	0x1005023fc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xd74>
100502260:     	ldr	x9, [x8, #0xf0]
100502264:     	cmp	x9, x25
100502268:     	b.hi	0x1005023fc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xd74>
10050226c:     	ldr	x9, [x8, #0xf8]
100502270:     	cmp	x9, x25
100502274:     	b.ls	0x1005023fc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xd74>
100502278:     	add	x9, x8, #0xf0
10050227c:     	b	0x10050235c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xcd4>
100502280:     	str	x21, [sp, #0x10]
100502284:     	ldr	x0, [x27, #0x8]
100502288:     	mov	x25, x0
10050228c:     	bl	0x10057c3c0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100502290:     	cbz	x0, 0x100502334 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xcac>
100502294:     	ldrb	w8, [x0]
100502298:     	cmp	w8, #0x1
10050229c:     	b.ne	0x100502334 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xcac>
1005022a0:     	ldrsb	w8, [x0, #0x1]
1005022a4:     	tbnz	w8, #0x1f, 0x100503298 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1c10>
1005022a8:     	ldr	x21, [sp, #0x10]
1005022ac:     	ldp	w9, w8, [x25]
1005022b0:     	cmp	w9, w8
1005022b4:     	b.hi	0x1005021fc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xb74>
1005022b8:     	mov	w8, #0xe100             ; =57600
1005022bc:     	movk	w8, #0x5f5, lsl #16
1005022c0:     	cmp	w9, w8
1005022c4:     	b.ls	0x100502458 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xdd0>
1005022c8:     	mov	x0, x25
1005022cc:     	bl	0x10058abf4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime6buffer6header20is_registered_buffer>
1005022d0:     	tbnz	w0, #0x0, 0x100502458 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xdd0>
1005022d4:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1005022d8:     	add	x8, x8, #0xec0
1005022dc:     	ldaprb	w8, [x8]
1005022e0:     	cbz	w8, 0x100502320 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xc98>
1005022e4:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1005022e8:     	add	x8, x8, #0x58
1005022ec:     	ldapr	x8, [x8]
1005022f0:     	cmp	x8, x25
1005022f4:     	b.hi	0x100502320 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xc98>
1005022f8:     	mov	x9, x25
1005022fc:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100502300:     	add	x8, x8, #0x60
100502304:     	ldapr	x8, [x8]
100502308:     	cmp	x8, x25
10050230c:     	b.lo	0x100502320 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xc98>
100502310:     	mov	x25, x9
100502314:     	mov	x0, x9
100502318:     	bl	0x1002a50f8 <__RNvNtCs2EcWOpJ680c_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
10050231c:     	tbnz	w0, #0x0, 0x100502458 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xdd0>
100502320:     	mov	w24, #0x0               ; =0
100502324:     	mov	x26, #0x0               ; =0
100502328:     	mov	x23, #0x0               ; =0
10050232c:     	mov	w28, #0x0               ; =0
100502330:     	b	0x100501958 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x2d0>
100502334:     	mov	w24, #0x0               ; =0
100502338:     	mov	x26, #0x0               ; =0
10050233c:     	mov	x23, #0x0               ; =0
100502340:     	mov	w28, #0x0               ; =0
100502344:     	mov	w8, #0x8                ; =8
100502348:     	str	x8, [sp, #0x18]
10050234c:     	ldr	x21, [sp, #0x10]
100502350:     	b	0x1005028bc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1234>
100502354:     	mov	x11, x21
100502358:     	add	x9, x8, #0x60
10050235c:     	ldr	x10, [x8, #0x30]
100502360:     	add	x10, x10, #0x1
100502364:     	str	x10, [x8, #0x30]
100502368:     	add	x8, x9, #0x19
10050236c:     	b	0x1005023dc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xd54>
100502370:     	bl	0x100b403fc <__RNvNtCs2EcWOpJ680c_13perry_runtime7tls_hot12hot_uncached>
100502374:     	lsr	x1, x25, #20
100502378:     	ldr	x8, [x0, #0x10]
10050237c:     	ldrb	w9, [x8]
100502380:     	cmp	w9, #0x2
100502384:     	b.eq	0x1005020cc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xa44>
100502388:     	ldr	x9, [x8, #0x8]
10050238c:     	ldr	x10, [x8, #0x28]
100502390:     	sub	x9, x1, x9
100502394:     	cmp	x9, x10
100502398:     	b.hs	0x1005023f0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xd68>
10050239c:     	ldr	x10, [x8, #0x20]
1005023a0:     	mov	w11, #0x28              ; =40
1005023a4:     	madd	x9, x9, x11, x10
1005023a8:     	ldr	x10, [x9]
1005023ac:     	ldr	x11, [x8, #0x10]
1005023b0:     	cmp	x10, x11
1005023b4:     	b.ne	0x1005023fc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xd74>
1005023b8:     	ldp	x10, x11, [x9, #0x8]
1005023bc:     	cmp	x10, x25
1005023c0:     	ccmp	x11, x25, #0x0, ls
1005023c4:     	b.ls	0x1005023fc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xd74>
1005023c8:     	mov	x11, x21
1005023cc:     	ldr	x10, [x8, #0x30]
1005023d0:     	add	x10, x10, #0x1
1005023d4:     	str	x10, [x8, #0x30]
1005023d8:     	add	x8, x9, #0x21
1005023dc:     	ldrb	w8, [x8]
1005023e0:     	cmp	w8, #0xff
1005023e4:     	mov	x21, x11
1005023e8:     	b.ne	0x100502414 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xd8c>
1005023ec:     	b	0x100502408 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xd80>
1005023f0:     	ldr	x9, [x8, #0x58]
1005023f4:     	add	x9, x9, #0x1
1005023f8:     	str	x9, [x8, #0x58]
1005023fc:     	ldr	x9, [x8, #0x38]
100502400:     	add	x9, x9, #0x1
100502404:     	str	x9, [x8, #0x38]
100502408:     	mov	x0, x25
10050240c:     	bl	0x10051fc48 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
100502410:     	and	w8, w0, #0xff
100502414:     	cbz	w8, 0x100502044 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9bc>
100502418:     	ldurb	w8, [x25, #-0x8]
10050241c:     	ldurb	w9, [x25, #-0x7]
100502420:     	mov	w10, #0x82              ; =130
100502424:     	and	w9, w9, w10
100502428:     	cmp	w9, #0x2
10050242c:     	ccmp	w8, #0x1, #0x0, eq
100502430:     	b.ne	0x100502044 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9bc>
100502434:     	ldr	w8, [x25]
100502438:     	mov	w9, #0xe100             ; =57600
10050243c:     	movk	w9, #0x5f5, lsl #16
100502440:     	orr	w9, w9, #0x1
100502444:     	cmp	w8, w9
100502448:     	b.hs	0x100502044 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9bc>
10050244c:     	ldr	w9, [x25, #0x4]
100502450:     	cmp	w8, w9
100502454:     	b.hi	0x100502044 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x9bc>
100502458:     	ldr	w28, [x25], #0x8
10050245c:     	mov	w8, #0x8                ; =8
100502460:     	stp	xzr, x8, [sp, #0x78]
100502464:     	str	xzr, [sp, #0x88]
100502468:     	cbz	w28, 0x1005027ec <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1164>
10050246c:     	mov	x23, #0x0               ; =0
100502470:     	stp	x25, x28, [sp]
100502474:     	b	0x1005024a8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xe20>
100502478:     	mov	w8, #0x18               ; =24
10050247c:     	madd	x8, x28, x8, x25
100502480:     	ldr	x9, [sp, #0x10]
100502484:     	stp	x9, x27, [x8]
100502488:     	str	x24, [x8, #0x10]
10050248c:     	add	x8, x28, #0x1
100502490:     	str	x8, [sp, #0x88]
100502494:     	ldp	x25, x28, [sp]
100502498:     	ldr	x23, [sp, #0x18]
10050249c:     	add	x23, x23, #0x1
1005024a0:     	cmp	x23, x28
1005024a4:     	b.eq	0x1005027fc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1174>
1005024a8:     	ldr	d9, [x25, x23, lsl #3]
1005024ac:     	fmov	x26, d9
1005024b0:     	and	x24, x26, #0xffff000000000000
1005024b4:     	mov	x8, #0x7ff9000000000000 ; =9221401712017801216
1005024b8:     	cmp	x24, x8
1005024bc:     	str	x23, [sp, #0x18]
1005024c0:     	b.eq	0x100502500 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xe78>
1005024c4:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
1005024c8:     	cmp	x24, x8
1005024cc:     	b.ne	0x100502584 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xefc>
1005024d0:     	and	x23, x26, #0xffffffffffff
1005024d4:     	cmp	x23, #0x1, lsl #12      ; =0x1000
1005024d8:     	b.lo	0x100502498 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xe10>
1005024dc:     	ldr	w24, [x23, #0x4]
1005024e0:     	cbz	w24, 0x100502684 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xffc>
1005024e4:     	mov	x0, x24
1005024e8:     	mov	w1, #0x1                ; =1
1005024ec:     	bl	0x100b60248 <_mi_malloc_aligned>
1005024f0:     	cbz	x0, 0x10050339c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1d14>
1005024f4:     	mov	x27, x0
1005024f8:     	add	x1, x23, #0x14
1005024fc:     	b	0x100502658 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xfd0>
100502500:     	strb	wzr, [sp, #0x54]
100502504:     	str	wzr, [sp, #0x50]
100502508:     	ubfx	x1, x26, #40, #8
10050250c:     	cbz	x1, 0x10050255c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xed4>
100502510:     	strb	w26, [sp, #0x50]
100502514:     	cmp	x1, #0x1
100502518:     	b.eq	0x10050255c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xed4>
10050251c:     	lsr	x8, x26, #8
100502520:     	strb	w8, [sp, #0x51]
100502524:     	cmp	x1, #0x2
100502528:     	b.eq	0x10050255c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xed4>
10050252c:     	lsr	x8, x26, #16
100502530:     	strb	w8, [sp, #0x52]
100502534:     	cmp	x1, #0x3
100502538:     	b.eq	0x10050255c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xed4>
10050253c:     	lsr	x8, x26, #24
100502540:     	strb	w8, [sp, #0x53]
100502544:     	cmp	x1, #0x4
100502548:     	b.eq	0x10050255c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xed4>
10050254c:     	lsr	x8, x26, #32
100502550:     	strb	w8, [sp, #0x54]
100502554:     	cmp	x1, #0x5
100502558:     	b.ne	0x100503388 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1d00>
10050255c:     	add	x8, sp, #0x58
100502560:     	add	x0, sp, #0x50
100502564:     	bl	0x10002e158 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100502568:     	ldr	x8, [sp, #0x58]
10050256c:     	cbz	x8, 0x1005025c4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xf3c>
100502570:     	mov	x26, #-0x1              ; =-1
100502574:     	str	x26, [sp, #0x90]
100502578:     	cmn	x26, #0x1
10050257c:     	b.ne	0x100502710 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1088>
100502580:     	b	0x100502498 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xe10>
100502584:     	lsr	x8, x26, #52
100502588:     	cmp	x8, #0x0
10050258c:     	and	x8, x26, #0x7
100502590:     	ccmp	x26, #0x0, #0x4, eq
100502594:     	ccmp	x8, #0x0, #0x0, ne
100502598:     	b.eq	0x100502668 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xfe0>
10050259c:     	mov	w8, #0x7ffe0000         ; =2147352576
1005025a0:     	cmp	x8, x26, lsr #32
1005025a4:     	b.ne	0x100502610 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xf88>
1005025a8:     	add	x0, sp, #0x90
1005025ac:     	mov	x1, x26
1005025b0:     	bl	0x10078c5c0 <__RNvXs1K_NtCsctvjasLqLe9_5alloc6stringlNtB6_12SpecToString14spec_to_string>
1005025b4:     	ldr	x26, [sp, #0x90]
1005025b8:     	cmn	x26, #0x1
1005025bc:     	b.ne	0x100502710 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1088>
1005025c0:     	b	0x100502498 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xe10>
1005025c4:     	ldr	x26, [sp, #0x68]
1005025c8:     	tbnz	x26, #0x3f, 0x1005027e0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1158>
1005025cc:     	cbz	x26, 0x1005026fc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1074>
1005025d0:     	ldr	x27, [sp, #0x60]
1005025d4:     	mov	x0, x26
1005025d8:     	mov	w1, #0x1                ; =1
1005025dc:     	bl	0x100b60248 <_mi_malloc_aligned>
1005025e0:     	mov	x24, x0
1005025e4:     	mov	w0, #0x1                ; =1
1005025e8:     	cbz	x24, 0x1005027e4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x115c>
1005025ec:     	mov	x0, x24
1005025f0:     	mov	x1, x27
1005025f4:     	mov	x2, x26
1005025f8:     	bl	0x100b62e6c <_writev+0x100b62e6c>
1005025fc:     	stp	x26, x24, [sp, #0x90]
100502600:     	str	x26, [sp, #0xa0]
100502604:     	cmn	x26, #0x1
100502608:     	b.ne	0x100502710 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1088>
10050260c:     	b	0x100502498 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xe10>
100502610:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100502614:     	cmp	x24, x8
100502618:     	mov	x8, #0x7ff9000000000000 ; =9221401712017801216
10050261c:     	ccmp	x26, x8, #0x0, ls
100502620:     	b.hs	0x100502698 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1010>
100502624:     	mov.16b	v0, v9
100502628:     	bl	0x10087292c <_js_number_to_string>
10050262c:     	cmp	x0, #0x1, lsl #12       ; =0x1000
100502630:     	b.lo	0x100502498 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xe10>
100502634:     	mov	x26, x0
100502638:     	ldr	w24, [x0, #0x4]
10050263c:     	cbz	w24, 0x100502684 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xffc>
100502640:     	mov	x0, x24
100502644:     	mov	w1, #0x1                ; =1
100502648:     	bl	0x100b60248 <_mi_malloc_aligned>
10050264c:     	cbz	x0, 0x10050339c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1d14>
100502650:     	mov	x27, x0
100502654:     	add	x1, x26, #0x14
100502658:     	mov	x0, x27
10050265c:     	mov	x2, x24
100502660:     	bl	0x100b62e6c <_writev+0x100b62e6c>
100502664:     	b	0x100502688 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1000>
100502668:     	mov	x0, x26
10050266c:     	bl	0x100510a38 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100502670:     	tbz	w0, #0x0, 0x10050259c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xf14>
100502674:     	cmp	x26, #0x1, lsl #12      ; =0x1000
100502678:     	b.lo	0x100502498 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xe10>
10050267c:     	ldr	w24, [x26, #0x4]
100502680:     	cbnz	w24, 0x100502640 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xfb8>
100502684:     	mov	w27, #0x1               ; =1
100502688:     	stp	x24, x27, [sp, #0x90]
10050268c:     	str	x24, [sp, #0x10]
100502690:     	str	x24, [sp, #0xa0]
100502694:     	b	0x100502718 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1090>
100502698:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10050269c:     	cmp	x24, x8
1005026a0:     	b.ne	0x100502498 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xe10>
1005026a4:     	and	x1, x26, #0xffffffffffff
1005026a8:     	sub	x8, x1, #0x100, lsl #12 ; =0x100000
1005026ac:     	mov	x9, #0x7fffffffffff     ; =140737488355327
1005026b0:     	movk	x9, #0xffef, lsl #16
1005026b4:     	cmp	x8, x9
1005026b8:     	b.hi	0x100502498 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xe10>
1005026bc:     	add	x0, sp, #0x58
1005026c0:     	bl	0x10077026c <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
1005026c4:     	ldr	w8, [sp, #0x58]
1005026c8:     	tbz	w8, #0x0, 0x100502498 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xe10>
1005026cc:     	ldr	w8, [sp, #0x60]
1005026d0:     	mov	w9, #0x8068             ; =32872
1005026d4:     	movk	w9, #0x7fff, lsl #16
1005026d8:     	cmp	w9, w8, lsr #1
1005026dc:     	b.ne	0x100502498 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xe10>
1005026e0:     	mov.16b	v0, v9
1005026e4:     	bl	0x10084937c <_js_jsvalue_to_string>
1005026e8:     	cmp	x0, #0x1, lsl #12       ; =0x1000
1005026ec:     	b.hs	0x100502790 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1108>
1005026f0:     	mov	x26, #-0x1              ; =-1
1005026f4:     	str	x26, [sp, #0x90]
1005026f8:     	b	0x1005027d0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1148>
1005026fc:     	mov	w24, #0x1               ; =1
100502700:     	stp	x26, x24, [sp, #0x90]
100502704:     	str	x26, [sp, #0xa0]
100502708:     	cmn	x26, #0x1
10050270c:     	b.eq	0x100502498 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xe10>
100502710:     	str	x26, [sp, #0x10]
100502714:     	ldp	x27, x24, [sp, #0x98]
100502718:     	ldp	x25, x28, [sp, #0x80]
10050271c:     	cbz	x28, 0x100502774 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x10ec>
100502720:     	add	x8, x28, x28, lsl #1
100502724:     	lsl	x26, x8, #3
100502728:     	add	x23, x25, #0x10
10050272c:     	b	0x10050273c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x10b4>
100502730:     	add	x23, x23, #0x18
100502734:     	subs	x26, x26, #0x18
100502738:     	b.eq	0x100502774 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x10ec>
10050273c:     	ldr	x8, [x23]
100502740:     	cmp	x8, x24
100502744:     	b.ne	0x100502730 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x10a8>
100502748:     	ldur	x0, [x23, #-0x8]
10050274c:     	mov	x1, x27
100502750:     	mov	x2, x24
100502754:     	bl	0x100b62e60 <_writev+0x100b62e60>
100502758:     	cbnz	w0, 0x100502730 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x10a8>
10050275c:     	ldp	x25, x28, [sp]
100502760:     	ldr	x8, [sp, #0x10]
100502764:     	cbz	x8, 0x100502498 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xe10>
100502768:     	mov	x0, x27
10050276c:     	bl	0x100b5ffc0 <_mi_free>
100502770:     	b	0x100502498 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xe10>
100502774:     	ldr	x8, [sp, #0x78]
100502778:     	cmp	x28, x8
10050277c:     	b.ne	0x100502478 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xdf0>
100502780:     	add	x0, sp, #0x78
100502784:     	bl	0x100b58fdc <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecNtNtNtCs8BpVhDwHqJW_3std3ffi6os_str8OsStringE8grow_oneBS_>
100502788:     	ldr	x25, [sp, #0x80]
10050278c:     	b	0x100502478 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xdf0>
100502790:     	mov	x24, x0
100502794:     	ldr	w8, [x0, #0x4]
100502798:     	mov	x26, x8
10050279c:     	cbz	w8, 0x1005027c4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x113c>
1005027a0:     	mov	x0, x26
1005027a4:     	mov	w1, #0x1                ; =1
1005027a8:     	bl	0x100b60248 <_mi_malloc_aligned>
1005027ac:     	cbz	x0, 0x1005033a8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1d20>
1005027b0:     	mov	x27, x0
1005027b4:     	add	x1, x24, #0x14
1005027b8:     	mov	x2, x26
1005027bc:     	bl	0x100b62e6c <_writev+0x100b62e6c>
1005027c0:     	b	0x1005027c8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1140>
1005027c4:     	mov	w27, #0x1               ; =1
1005027c8:     	stp	x26, x27, [sp, #0x90]
1005027cc:     	str	x26, [sp, #0xa0]
1005027d0:     	ldp	x25, x28, [sp]
1005027d4:     	cmn	x26, #0x1
1005027d8:     	b.ne	0x100502710 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1088>
1005027dc:     	b	0x100502498 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xe10>
1005027e0:     	mov	x0, #0x0                ; =0
1005027e4:     	mov	x1, x26
1005027e8:     	bl	0x100b133c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1005027ec:     	mov	w24, #0x0               ; =0
1005027f0:     	mov	x26, #0x0               ; =0
1005027f4:     	mov	x23, #0x0               ; =0
1005027f8:     	b	0x100501958 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x2d0>
1005027fc:     	ldp	x8, x9, [sp, #0x78]
100502800:     	str	x9, [sp, #0x18]
100502804:     	ldr	x23, [sp, #0x88]
100502808:     	cmn	x8, #0x1
10050280c:     	b.eq	0x10050281c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1194>
100502810:     	mov	x26, x8
100502814:     	mov	w24, #0x0               ; =0
100502818:     	b	0x1005028b8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1230>
10050281c:     	and	x27, x22, #0xffff000000000000
100502820:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100502824:     	cmp	x27, x8
100502828:     	b.eq	0x100502088 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xa00>
10050282c:     	lsr	x8, x22, #52
100502830:     	cbnz	x8, 0x100502864 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x11dc>
100502834:     	and	x8, x22, #0x7
100502838:     	mov	w28, #0x0               ; =0
10050283c:     	mov	x26, #-0x1              ; =-1
100502840:     	mov	w24, #0x1               ; =1
100502844:     	cbz	x22, 0x1005028bc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1234>
100502848:     	cbnz	x8, 0x1005028bc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1234>
10050284c:     	mov	x0, x22
100502850:     	bl	0x100510a38 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100502854:     	tbz	w0, #0x0, 0x1005028b8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1230>
100502858:     	mov	x8, x22
10050285c:     	cmp	x22, #0x100, lsl #12    ; =0x100000
100502860:     	b.hs	0x100502874 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x11ec>
100502864:     	mov	w28, #0x0               ; =0
100502868:     	mov	x26, #-0x1              ; =-1
10050286c:     	mov	w24, #0x1               ; =1
100502870:     	b	0x1005028bc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1234>
100502874:     	mov	x9, #-0x1               ; =-1
100502878:     	ldr	w8, [x8, #0xc]
10050287c:     	mov	w10, #0x4f53            ; =20307
100502880:     	movk	w10, #0x434c, lsl #16
100502884:     	and	x11, x22, #0xffffffffffff
100502888:     	mov	x12, #0x7ffd000000000000 ; =9222527611924643840
10050288c:     	cmp	x27, x12
100502890:     	csel	x11, x11, x22, eq
100502894:     	mov	x12, #-0x1              ; =-1
100502898:     	mov	w13, #0x1               ; =1
10050289c:     	cmp	w8, w10
1005028a0:     	csinc	w24, w13, wzr, eq
1005028a4:     	csel	x26, x9, x12, ne
1005028a8:     	cset	w28, eq
1005028ac:     	csel	x8, x8, x11, ne
1005028b0:     	str	x8, [sp, #0x8]
1005028b4:     	b	0x1005028bc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1234>
1005028b8:     	mov	w28, #0x0               ; =0
1005028bc:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1005028c0:     	add	x0, x0, #0xd78
1005028c4:     	ldr	x8, [x0]
1005028c8:     	blr	x8
1005028cc:     	mov	x22, x0
1005028d0:     	ldr	w27, [x0]
1005028d4:     	add	w8, w27, #0x1
1005028d8:     	str	w8, [x0]
1005028dc:     	cbz	w27, 0x10050294c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x12c4>
1005028e0:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1005028e4:     	add	x0, x0, #0xd00
1005028e8:     	ldr	x8, [x0]
1005028ec:     	blr	x8
1005028f0:     	ldrb	w8, [x0, #0x20]
1005028f4:     	cmp	w8, #0x1
1005028f8:     	b.ne	0x100503190 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1b08>
1005028fc:     	ldr	x8, [x0]
100502900:     	cbnz	x8, 0x10050319c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1b14>
100502904:     	mov	x8, #-0x1               ; =-1
100502908:     	str	x8, [x0]
10050290c:     	ldr	x25, [x0, #0x18]
100502910:     	ldr	x8, [x0, #0x8]
100502914:     	cmp	x25, x8
100502918:     	b.eq	0x1005030d4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1a4c>
10050291c:     	ldr	x8, [x0, #0x10]
100502920:     	mov	w9, #0x18               ; =24
100502924:     	madd	x8, x25, x9, x8
100502928:     	mov	w9, #0x8                ; =8
10050292c:     	stp	xzr, x9, [x8]
100502930:     	str	xzr, [x8, #0x10]
100502934:     	add	x8, x25, #0x1
100502938:     	str	x8, [x0, #0x18]
10050293c:     	ldr	x8, [x0]
100502940:     	add	x8, x8, #0x1
100502944:     	str	x8, [x0]
100502948:     	b	0x1005029b4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x132c>
10050294c:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100502950:     	add	x0, x0, #0xdc0
100502954:     	ldr	x8, [x0]
100502958:     	blr	x8
10050295c:     	strb	wzr, [x0]
100502960:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100502964:     	add	x0, x0, #0xdf0
100502968:     	ldr	x8, [x0]
10050296c:     	blr	x8
100502970:     	strb	wzr, [x0]
100502974:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
100502978:     	ldr	w25, [x8, #0x5a8]
10050297c:     	cmp	w25, #0x300
100502980:     	b.hs	0x100503128 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1aa0>
100502984:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100502988:     	ldr	x8, [x8, #0x48]
10050298c:     	cmn	x8, #0x1
100502990:     	b.eq	0x100503118 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1a90>
100502994:     	mrs	x9, TPIDRRO_EL0
100502998:     	and	x9, x9, #0xfffffffffffffff8
10050299c:     	ldr	x0, [x9, x8, lsl #3]
1005029a0:     	cbz	x0, 0x100503118 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1a90>
1005029a4:     	add	x8, x0, x25, lsl #3
1005029a8:     	ldr	x0, [x8, #0x1e8]
1005029ac:     	cbz	x0, 0x100503128 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1aa0>
1005029b0:     	str	xzr, [x0]
1005029b4:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1005029b8:     	add	x0, x0, #0xd30
1005029bc:     	ldr	x8, [x0]
1005029c0:     	blr	x8
1005029c4:     	mov	x25, x0
1005029c8:     	ldrb	w8, [x0, #0x18]
1005029cc:     	cmp	w8, #0x1
1005029d0:     	b.ne	0x100503164 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1adc>
1005029d4:     	ldr	x8, [x0]
1005029d8:     	mov	x9, #-0x1               ; =-1
1005029dc:     	str	x9, [x0]
1005029e0:     	cmn	x8, #0x2
1005029e4:     	b.eq	0x10050328c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1c04>
1005029e8:     	cmn	x8, #0x1
1005029ec:     	b.eq	0x100502ad0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1448>
1005029f0:     	add	x9, sp, #0x90
1005029f4:     	ldur	q0, [x0, #0x8]
1005029f8:     	stur	q0, [x9, #0x8]
1005029fc:     	str	x8, [sp, #0x90]
100502a00:     	tbz	w24, #0x0, 0x100502ae4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x145c>
100502a04:     	str	w24, [sp, #0x10]
100502a08:     	mov	x24, x26
100502a0c:     	tbz	w28, #0x0, 0x100502bd4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x154c>
100502a10:     	bl	0x10028b898 <__RNvMs_NtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
100502a14:     	str	x0, [sp, #0x40]
100502a18:     	mov	x10, #0x7ffd000000000000 ; =9222527611924643840
100502a1c:     	mov	w8, #0x1                ; =1
100502a20:     	ldr	x9, [sp, #0x8]
100502a24:     	stp	x9, x10, [sp, #0x60]
100502a28:     	str	x8, [sp, #0x58]
100502a2c:     	add	x0, sp, #0x58
100502a30:     	bl	0x10028b9a0 <__RNvMs_NtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
100502a34:     	mov	x21, x0
100502a38:     	str	x0, [sp, #0x48]
100502a3c:     	mov	w0, #0x0                ; =0
100502a40:     	bl	0x10034b56c <__RNvNtCs2EcWOpJ680c_13perry_runtime6string20string_storage_alloc>
100502a44:     	stp	xzr, xzr, [x0]
100502a48:     	str	wzr, [x0, #0x10]
100502a4c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100502a50:     	bfxil	x8, x0, #0, #48
100502a54:     	fmov	d0, x8
100502a58:     	bl	0x10020b5a4 <__RNCINvNtNtCs2EcWOpJ680c_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
100502a5c:     	mov	x20, x0
100502a60:     	adrp	x26, 0x100f80000 <_perry_global_worker_ts__1>
100502a64:     	ldr	x8, [x26, #0x48]
100502a68:     	cmn	x8, #0x1
100502a6c:     	b.eq	0x100502c3c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x15b4>
100502a70:     	mrs	x9, TPIDRRO_EL0
100502a74:     	and	x9, x9, #0xfffffffffffffff8
100502a78:     	ldr	x8, [x9, x8, lsl #3]
100502a7c:     	cbz	x8, 0x100502c3c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x15b4>
100502a80:     	ldr	x8, [x8, #0x19e8]
100502a84:     	ldr	x28, [sp, #0x18]
100502a88:     	cbz	x8, 0x100503100 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1a78>
100502a8c:     	ldr	x9, [x8]
100502a90:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100502a94:     	cmp	x9, x10
100502a98:     	b.hs	0x100503208 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1b80>
100502a9c:     	add	x10, x9, #0x1
100502aa0:     	str	x10, [x8]
100502aa4:     	ldr	x10, [x8, #0x18]
100502aa8:     	cmp	x20, x10
100502aac:     	b.hs	0x100503214 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1b8c>
100502ab0:     	ldr	x10, [x8, #0x10]
100502ab4:     	mov	w11, #0x18              ; =24
100502ab8:     	madd	x10, x20, x11, x10
100502abc:     	ldr	x11, [x10]
100502ac0:     	cbnz	x11, 0x100503274 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1bec>
100502ac4:     	ldr	x0, [x10, #0x8]
100502ac8:     	str	x9, [x8]
100502acc:     	b	0x100502c48 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x15c0>
100502ad0:     	mov	x8, #0x0                ; =0
100502ad4:     	mov	w9, #0x1                ; =1
100502ad8:     	stp	x9, xzr, [sp, #0x98]
100502adc:     	str	x8, [sp, #0x90]
100502ae0:     	tbnz	w24, #0x0, 0x100502a04 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x137c>
100502ae4:     	cmp	x21, #0x0
100502ae8:     	cset	w6, ne
100502aec:     	ldp	x3, x4, [sp, #0x28]
100502af0:     	add	x2, sp, #0x90
100502af4:     	mov.16b	v0, v8
100502af8:     	ldr	x28, [sp, #0x18]
100502afc:     	mov	x0, x28
100502b00:     	mov	x1, x23
100502b04:     	mov	x5, #0x0                ; =0
100502b08:     	bl	0x100504780 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
100502b0c:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100502b10:     	add	x0, x0, #0xd90
100502b14:     	ldr	x8, [x0]
100502b18:     	blr	x8
100502b1c:     	ldrb	w8, [x0, #0x20]
100502b20:     	cbnz	w8, 0x1005031a8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1b20>
100502b24:     	ldr	x8, [x0]
100502b28:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100502b2c:     	cmp	x8, x9
100502b30:     	b.hs	0x1005031dc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1b54>
100502b34:     	ldr	x9, [x0, #0x18]
100502b38:     	cbz	x9, 0x100502b44 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x14bc>
100502b3c:     	cbnz	x8, 0x1005031e8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1b60>
100502b40:     	str	xzr, [x0, #0x18]
100502b44:     	ldp	x0, x1, [sp, #0x98]
100502b48:     	cmp	x1, #0x5
100502b4c:     	b.hi	0x100502bb4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x152c>
100502b50:     	cbz	x1, 0x100502ddc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1754>
100502b54:     	ldrsb	w8, [x0]
100502b58:     	tbnz	w8, #0x1f, 0x100502bb4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x152c>
100502b5c:     	cmp	x1, #0x1
100502b60:     	b.eq	0x100502b9c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1514>
100502b64:     	ldrsb	w8, [x0, #0x1]
100502b68:     	tbnz	w8, #0x1f, 0x100502bb4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x152c>
100502b6c:     	cmp	x1, #0x2
100502b70:     	b.eq	0x100502b9c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1514>
100502b74:     	ldrsb	w8, [x0, #0x2]
100502b78:     	tbnz	w8, #0x1f, 0x100502bb4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x152c>
100502b7c:     	cmp	x1, #0x3
100502b80:     	b.eq	0x100502b9c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1514>
100502b84:     	ldrsb	w8, [x0, #0x3]
100502b88:     	tbnz	w8, #0x1f, 0x100502bb4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x152c>
100502b8c:     	cmp	x1, #0x4
100502b90:     	b.eq	0x100502b9c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1514>
100502b94:     	ldrsb	w8, [x0, #0x4]
100502b98:     	tbnz	w8, #0x1f, 0x100502bb4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x152c>
100502b9c:     	cmp	x1, #0x4
100502ba0:     	b.hs	0x100502f20 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1898>
100502ba4:     	mov	x10, #0x0               ; =0
100502ba8:     	mov	x9, #0x0                ; =0
100502bac:     	mov	x8, x0
100502bb0:     	b	0x100502fb0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1928>
100502bb4:     	bl	0x10032a244 <__RNvNtCs2EcWOpJ680c_13perry_runtime4json36json_string_from_native_output_bytes>
100502bb8:     	mov	x19, #0x7fff000000000000 ; =9223090561878065152
100502bbc:     	bfxil	x19, x0, #0, #48
100502bc0:     	ldp	x21, x0, [sp, #0x90]
100502bc4:     	ldrb	w8, [x25, #0x18]
100502bc8:     	cmp	w8, #0x1
100502bcc:     	b.eq	0x100502fec <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1964>
100502bd0:     	b	0x100503174 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1aec>
100502bd4:     	mov	w0, #0x0                ; =0
100502bd8:     	bl	0x10034b56c <__RNvNtCs2EcWOpJ680c_13perry_runtime6string20string_storage_alloc>
100502bdc:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100502be0:     	bfxil	x8, x0, #0, #48
100502be4:     	fmov	d1, x8
100502be8:     	stp	xzr, xzr, [x0]
100502bec:     	str	wzr, [x0, #0x10]
100502bf0:     	mov.16b	v0, v8
100502bf4:     	bl	0x1004ffcbc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer19apply_to_json_keyed>
100502bf8:     	mov.16b	v8, v0
100502bfc:     	fmov	x26, d8
100502c00:     	cmp	x26, x19
100502c04:     	ldr	x28, [sp, #0x18]
100502c08:     	b.eq	0x100502e64 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x17dc>
100502c0c:     	mov	w8, #0x7ffd             ; =32765
100502c10:     	cmp	x8, x26, lsr #48
100502c14:     	b.ne	0x100502e34 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x17ac>
100502c18:     	and	x8, x26, #0xffffffffffff
100502c1c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100502c20:     	b.lo	0x100502e58 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x17d0>
100502c24:     	ldr	w8, [x8, #0xc]
100502c28:     	mov	w9, #0x4f53             ; =20307
100502c2c:     	movk	w9, #0x434c, lsl #16
100502c30:     	cmp	w8, w9
100502c34:     	b.ne	0x100502e58 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x17d0>
100502c38:     	b	0x100502e64 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x17dc>
100502c3c:     	mov	x0, x20
100502c40:     	bl	0x10013c6a8 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100502c44:     	ldr	x28, [sp, #0x18]
100502c48:     	fmov	d1, x0
100502c4c:     	mov.16b	v0, v8
100502c50:     	bl	0x1004ffcbc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer19apply_to_json_keyed>
100502c54:     	mov.16b	v8, v0
100502c58:     	ldr	x8, [x26, #0x48]
100502c5c:     	cmn	x8, #0x1
100502c60:     	b.eq	0x100502cc4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x163c>
100502c64:     	mrs	x9, TPIDRRO_EL0
100502c68:     	and	x9, x9, #0xfffffffffffffff8
100502c6c:     	ldr	x8, [x9, x8, lsl #3]
100502c70:     	cbz	x8, 0x100502cc4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x163c>
100502c74:     	ldr	x8, [x8, #0x19e8]
100502c78:     	cbz	x8, 0x100502cc4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x163c>
100502c7c:     	ldr	x9, [x8]
100502c80:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100502c84:     	cmp	x9, x10
100502c88:     	b.hs	0x100503208 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1b80>
100502c8c:     	add	x10, x9, #0x1
100502c90:     	str	x10, [x8]
100502c94:     	ldr	x10, [x8, #0x18]
100502c98:     	cmp	x21, x10
100502c9c:     	b.hs	0x100503214 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1b8c>
100502ca0:     	ldr	x10, [x8, #0x10]
100502ca4:     	mov	w11, #0x18              ; =24
100502ca8:     	madd	x10, x21, x11, x10
100502cac:     	ldr	x11, [x10]
100502cb0:     	cmp	x11, #0x1
100502cb4:     	b.ne	0x10050331c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1c94>
100502cb8:     	ldr	x21, [x10, #0x8]
100502cbc:     	str	x9, [x8]
100502cc0:     	b	0x100502cd0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1648>
100502cc4:     	mov	x0, x21
100502cc8:     	bl	0x10013c5d0 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
100502ccc:     	mov	x21, x0
100502cd0:     	ldr	x8, [x26, #0x48]
100502cd4:     	cmn	x8, #0x1
100502cd8:     	b.eq	0x100502d40 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x16b8>
100502cdc:     	mrs	x9, TPIDRRO_EL0
100502ce0:     	and	x9, x9, #0xfffffffffffffff8
100502ce4:     	ldr	x8, [x9, x8, lsl #3]
100502ce8:     	cbz	x8, 0x100502d40 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x16b8>
100502cec:     	ldr	x8, [x8, #0x19e8]
100502cf0:     	mov	x26, x24
100502cf4:     	cbz	x8, 0x10050310c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1a84>
100502cf8:     	ldr	x9, [x8]
100502cfc:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100502d00:     	cmp	x9, x10
100502d04:     	ldr	w24, [sp, #0x10]
100502d08:     	b.hs	0x100503208 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1b80>
100502d0c:     	add	x10, x9, #0x1
100502d10:     	str	x10, [x8]
100502d14:     	ldr	x10, [x8, #0x18]
100502d18:     	cmp	x20, x10
100502d1c:     	b.hs	0x100503214 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1b8c>
100502d20:     	ldr	x10, [x8, #0x10]
100502d24:     	mov	w11, #0x18              ; =24
100502d28:     	madd	x10, x20, x11, x10
100502d2c:     	ldr	x11, [x10]
100502d30:     	cbnz	x11, 0x100503274 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1bec>
100502d34:     	ldr	x0, [x10, #0x8]
100502d38:     	str	x9, [x8]
100502d3c:     	b	0x100502d50 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x16c8>
100502d40:     	mov	x0, x20
100502d44:     	bl	0x10013c6a8 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100502d48:     	mov	x26, x24
100502d4c:     	ldr	w24, [sp, #0x10]
100502d50:     	fmov	d9, x0
100502d54:     	mov.16b	v0, v8
100502d58:     	bl	0x1004ff7f4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer11root_holder>
100502d5c:     	mov.16b	v2, v0
100502d60:     	mov	x0, x21
100502d64:     	mov.16b	v0, v9
100502d68:     	mov.16b	v1, v8
100502d6c:     	bl	0x1004ffad4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer13call_replacer>
100502d70:     	str	d0, [sp, #0x50]
100502d74:     	fmov	x20, d0
100502d78:     	cmp	x20, x19
100502d7c:     	b.ne	0x100502de4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x175c>
100502d80:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100502d84:     	add	x0, x0, #0xd90
100502d88:     	ldr	x8, [x0]
100502d8c:     	blr	x8
100502d90:     	ldrb	w8, [x0, #0x20]
100502d94:     	cbnz	w8, 0x100503284 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1bfc>
100502d98:     	ldr	x8, [x0]
100502d9c:     	cbnz	x8, 0x10050334c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1cc4>
100502da0:     	str	xzr, [x0, #0x18]
100502da4:     	ldp	x21, x20, [sp, #0x90]
100502da8:     	ldrb	w8, [x25, #0x18]
100502dac:     	cmp	w8, #0x1
100502db0:     	b.ne	0x10050324c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1bc4>
100502db4:     	ldp	x8, x0, [x25]
100502db8:     	stp	x21, x20, [x25]
100502dbc:     	str	xzr, [x25, #0x10]
100502dc0:     	sub	x8, x8, #0x1
100502dc4:     	cmn	x8, #0x2
100502dc8:     	b.hs	0x100502dd0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1748>
100502dcc:     	bl	0x100b5ffc0 <_mi_free>
100502dd0:     	cbz	w27, 0x1005030b0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1a28>
100502dd4:     	bl	0x1003284a4 <__RNvNtCs2EcWOpJ680c_13perry_runtime4json19restore_shape_cache>
100502dd8:     	b	0x1005030b4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1a2c>
100502ddc:     	mov	x10, #0x0               ; =0
100502de0:     	b	0x100502fd0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1948>
100502de4:     	add	x0, sp, #0x90
100502de8:     	bl	0x100500038 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer21write_replaced_scalar>
100502dec:     	tbnz	w0, #0x0, 0x100502e28 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x17a0>
100502df0:     	mov	x0, x20
100502df4:     	bl	0x1003281a8 <__RNvNtCs2EcWOpJ680c_13perry_runtime4json15extract_pointer>
100502df8:     	cmp	x0, #0x1
100502dfc:     	b.ne	0x100503310 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1c88>
100502e00:     	add	x8, sp, #0x78
100502e04:     	add	x9, sp, #0x50
100502e08:     	stp	x8, x9, [sp, #0x58]
100502e0c:     	add	x8, sp, #0x90
100502e10:     	add	x9, sp, #0x20
100502e14:     	str	x8, [sp, #0x68]
100502e18:     	stp	x9, x1, [sp, #0x70]
100502e1c:     	add	x0, sp, #0x48
100502e20:     	add	x1, sp, #0x58
100502e24:     	bl	0x100144210 <__RINvMs2_NtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer23stringify_full_fallbacks3_0EBc_>
100502e28:     	add	x0, sp, #0x40
100502e2c:     	bl	0x1001672fc <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100502e30:     	b	0x100502b0c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1484>
100502e34:     	lsr	x8, x26, #52
100502e38:     	cbnz	x8, 0x100502e58 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x17d0>
100502e3c:     	cbz	x26, 0x100502e58 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x17d0>
100502e40:     	and	x8, x26, #0x7
100502e44:     	cbnz	x8, 0x100502e58 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x17d0>
100502e48:     	mov	x0, x26
100502e4c:     	bl	0x100510a38 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100502e50:     	mov	x8, x26
100502e54:     	tbnz	w0, #0x0, 0x100502c1c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1594>
100502e58:     	mov	x0, x26
100502e5c:     	bl	0x10050ad94 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify15is_symbol_value>
100502e60:     	tbz	w0, #0x0, 0x100502ef0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1868>
100502e64:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100502e68:     	add	x0, x0, #0xd90
100502e6c:     	ldr	x8, [x0]
100502e70:     	blr	x8
100502e74:     	ldrb	w8, [x0, #0x20]
100502e78:     	cbnz	w8, 0x100503218 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1b90>
100502e7c:     	ldr	x8, [x0]
100502e80:     	cbnz	x8, 0x100503240 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1bb8>
100502e84:     	str	xzr, [x0, #0x18]
100502e88:     	ldp	x21, x20, [sp, #0x90]
100502e8c:     	ldrb	w8, [x25, #0x18]
100502e90:     	cmp	w8, #0x1
100502e94:     	b.ne	0x1005031f4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1b6c>
100502e98:     	ldp	x8, x0, [x25]
100502e9c:     	stp	x21, x20, [x25]
100502ea0:     	str	xzr, [x25, #0x10]
100502ea4:     	sub	x8, x8, #0x1
100502ea8:     	cmn	x8, #0x2
100502eac:     	b.hs	0x100502eb4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x182c>
100502eb0:     	bl	0x100b5ffc0 <_mi_free>
100502eb4:     	cbz	w27, 0x100502ed4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x184c>
100502eb8:     	bl	0x1003284a4 <__RNvNtCs2EcWOpJ680c_13perry_runtime4json19restore_shape_cache>
100502ebc:     	ldr	w8, [x22]
100502ec0:     	sub	w8, w8, #0x1
100502ec4:     	str	w8, [x22]
100502ec8:     	ldr	x8, [sp, #0x20]
100502ecc:     	cbnz	x8, 0x10050307c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19f4>
100502ed0:     	b	0x100503084 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19fc>
100502ed4:     	bl	0x1003282d4 <__RNvNtCs2EcWOpJ680c_13perry_runtime4json17clear_shape_cache>
100502ed8:     	ldr	w8, [x22]
100502edc:     	sub	w8, w8, #0x1
100502ee0:     	str	w8, [x22]
100502ee4:     	ldr	x8, [sp, #0x20]
100502ee8:     	cbnz	x8, 0x10050307c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19f4>
100502eec:     	b	0x100503084 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19fc>
100502ef0:     	cmp	x20, x26
100502ef4:     	b.eq	0x100502f00 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1878>
100502ef8:     	mov.16b	v0, v8
100502efc:     	bl	0x10051016c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify24arm_to_json_result_guard>
100502f00:     	mov	x26, x24
100502f04:     	cbz	x21, 0x100503138 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1ab0>
100502f08:     	ldp	x1, x2, [sp, #0x28]
100502f0c:     	add	x0, sp, #0x90
100502f10:     	mov.16b	v0, v8
100502f14:     	mov	x3, #0x0                ; =0
100502f18:     	bl	0x100500b28 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer22stringify_value_pretty>
100502f1c:     	b	0x100503148 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1ac0>
100502f20:     	and	x9, x1, #0x4
100502f24:     	add	x8, x0, x9
100502f28:     	adrp	x10, 0x100c9a000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4e30>
100502f2c:     	ldr	q0, [x10, #0xa40]
100502f30:     	adrp	x10, 0x100c3a000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x3363a>
100502f34:     	ldr	q2, [x10, #0x940]
100502f38:     	movi.2d	v1, #0000000000000000
100502f3c:     	movi.2d	v3, #0x000000000000ff
100502f40:     	mov	w10, #0x4               ; =4
100502f44:     	dup.2d	v4, x10
100502f48:     	mov	x10, x0
100502f4c:     	and	x11, x1, #0x4
100502f50:     	movi.2d	v5, #0000000000000000
100502f54:     	ldr	s6, [x10], #0x4
100502f58:     	ushll.8h	v6, v6, #0x0
100502f5c:     	ushll.4s	v6, v6, #0x0
100502f60:     	ushll2.2d	v7, v6, #0x0
100502f64:     	and.16b	v7, v7, v3
100502f68:     	ushll.2d	v6, v6, #0x0
100502f6c:     	and.16b	v6, v6, v3
100502f70:     	shl.2d	v16, v0, #0x3
100502f74:     	shl.2d	v17, v2, #0x3
100502f78:     	ushl.2d	v6, v6, v17
100502f7c:     	ushl.2d	v7, v7, v16
100502f80:     	orr.16b	v1, v7, v1
100502f84:     	orr.16b	v5, v6, v5
100502f88:     	add.2d	v0, v0, v4
100502f8c:     	add.2d	v2, v2, v4
100502f90:     	subs	x11, x11, #0x4
100502f94:     	b.ne	0x100502f54 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x18cc>
100502f98:     	orr.16b	v0, v5, v1
100502f9c:     	mov	d1, v0[1]
100502fa0:     	orr.8b	v0, v0, v1
100502fa4:     	fmov	x10, d0
100502fa8:     	cmp	x1, x9
100502fac:     	b.eq	0x100502fd0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1948>
100502fb0:     	add	x11, x0, x1
100502fb4:     	lsl	x9, x9, #3
100502fb8:     	ldrb	w12, [x8], #0x1
100502fbc:     	lsl	x12, x12, x9
100502fc0:     	orr	x10, x12, x10
100502fc4:     	add	x9, x9, #0x8
100502fc8:     	cmp	x8, x11
100502fcc:     	b.ne	0x100502fb8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1930>
100502fd0:     	orr	x8, x10, x1, lsl #40
100502fd4:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100502fd8:     	orr	x19, x8, x9
100502fdc:     	ldr	x21, [sp, #0x90]
100502fe0:     	ldrb	w8, [x25, #0x18]
100502fe4:     	cmp	w8, #0x1
100502fe8:     	b.ne	0x100503174 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1aec>
100502fec:     	ldp	x9, x8, [x25]
100502ff0:     	stp	x21, x0, [x25]
100502ff4:     	str	xzr, [x25, #0x10]
100502ff8:     	sub	x9, x9, #0x1
100502ffc:     	cmn	x9, #0x2
100503000:     	b.hs	0x10050300c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1984>
100503004:     	mov	x0, x8
100503008:     	bl	0x100b5ffc0 <_mi_free>
10050300c:     	cbz	w27, 0x100503028 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19a0>
100503010:     	bl	0x1003284a4 <__RNvNtCs2EcWOpJ680c_13perry_runtime4json19restore_shape_cache>
100503014:     	ldr	w8, [x22]
100503018:     	sub	w8, w8, #0x1
10050301c:     	str	w8, [x22]
100503020:     	tbz	w24, #0x0, 0x10050303c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19b4>
100503024:     	b	0x100503074 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19ec>
100503028:     	bl	0x1003282d4 <__RNvNtCs2EcWOpJ680c_13perry_runtime4json17clear_shape_cache>
10050302c:     	ldr	w8, [x22]
100503030:     	sub	w8, w8, #0x1
100503034:     	str	w8, [x22]
100503038:     	tbnz	w24, #0x0, 0x100503074 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19ec>
10050303c:     	cbz	x23, 0x100503068 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19e0>
100503040:     	add	x20, x28, #0x8
100503044:     	b	0x100503054 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19cc>
100503048:     	add	x20, x20, #0x18
10050304c:     	subs	x23, x23, #0x1
100503050:     	b.eq	0x100503068 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19e0>
100503054:     	ldur	x8, [x20, #-0x8]
100503058:     	cbz	x8, 0x100503048 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19c0>
10050305c:     	ldr	x0, [x20]
100503060:     	bl	0x100b5ffc0 <_mi_free>
100503064:     	b	0x100503048 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19c0>
100503068:     	cbz	x26, 0x100503074 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19ec>
10050306c:     	mov	x0, x28
100503070:     	bl	0x100b5ffc0 <_mi_free>
100503074:     	ldr	x8, [sp, #0x20]
100503078:     	cbz	x8, 0x100503084 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19fc>
10050307c:     	ldr	x0, [sp, #0x28]
100503080:     	bl	0x100b5ffc0 <_mi_free>
100503084:     	mov	x0, x19
100503088:     	ldp	x29, x30, [sp, #0x120]
10050308c:     	ldp	x20, x19, [sp, #0x110]
100503090:     	ldp	x22, x21, [sp, #0x100]
100503094:     	ldp	x24, x23, [sp, #0xf0]
100503098:     	ldp	x26, x25, [sp, #0xe0]
10050309c:     	ldp	x28, x27, [sp, #0xd0]
1005030a0:     	ldp	d9, d8, [sp, #0xc0]
1005030a4:     	ldp	d11, d10, [sp, #0xb0]
1005030a8:     	add	sp, sp, #0x130
1005030ac:     	ret
1005030b0:     	bl	0x1003282d4 <__RNvNtCs2EcWOpJ680c_13perry_runtime4json17clear_shape_cache>
1005030b4:     	ldr	w8, [x22]
1005030b8:     	sub	w8, w8, #0x1
1005030bc:     	str	w8, [x22]
1005030c0:     	add	x0, sp, #0x40
1005030c4:     	bl	0x1001672fc <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
1005030c8:     	ldr	x8, [sp, #0x20]
1005030cc:     	cbnz	x8, 0x10050307c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19f4>
1005030d0:     	b	0x100503084 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x19fc>
1005030d4:     	str	w24, [sp, #0x10]
1005030d8:     	mov	x24, x26
1005030dc:     	mov	x26, x21
1005030e0:     	mov	x21, x0
1005030e4:     	add	x0, x0, #0x8
1005030e8:     	bl	0x100b3cd50 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs2EcWOpJ680c_13perry_runtime>
1005030ec:     	mov	x0, x21
1005030f0:     	mov	x21, x26
1005030f4:     	mov	x26, x24
1005030f8:     	ldr	w24, [sp, #0x10]
1005030fc:     	b	0x10050291c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1294>
100503100:     	mov	x0, x20
100503104:     	bl	0x10013c6a8 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100503108:     	b	0x100502c48 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x15c0>
10050310c:     	mov	x0, x20
100503110:     	bl	0x10013c6a8 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100503114:     	b	0x100502d4c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x16c4>
100503118:     	bl	0x100b403fc <__RNvNtCs2EcWOpJ680c_13perry_runtime7tls_hot12hot_uncached>
10050311c:     	add	x8, x0, x25, lsl #3
100503120:     	ldr	x0, [x8, #0x1e8]
100503124:     	cbnz	x0, 0x1005029b0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1328>
100503128:     	adrp	x0, 0x100f10000 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10050312c:     	add	x0, x0, #0x138
100503130:     	bl	0x100b3dc1c <__RNvMs5_NtCs2EcWOpJ680c_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100503134:     	b	0x1005029b0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1328>
100503138:     	add	x1, sp, #0x90
10050313c:     	mov.16b	v0, v8
100503140:     	mov	w0, #0x0                ; =0
100503144:     	bl	0x10050ae6c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify15stringify_value>
100503148:     	ldr	w24, [sp, #0x10]
10050314c:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100503150:     	add	x0, x0, #0xdc0
100503154:     	ldr	x8, [x0]
100503158:     	blr	x8
10050315c:     	strb	wzr, [x0]
100503160:     	b	0x100502b0c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1484>
100503164:     	mov	x0, x25
100503168:     	bl	0x100b1f5c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs2EcWOpJ680c_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10050316c:     	cbnz	x0, 0x1005029d4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x134c>
100503170:     	b	0x10050328c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1c04>
100503174:     	mov	x20, x0
100503178:     	mov	x0, x25
10050317c:     	bl	0x100b1f5c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs2EcWOpJ680c_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100503180:     	mov	x25, x0
100503184:     	mov	x0, x20
100503188:     	cbnz	x25, 0x100502fec <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1964>
10050318c:     	b	0x10050325c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1bd4>
100503190:     	bl	0x100b1f724 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs2EcWOpJ680c_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100503194:     	cbnz	x0, 0x1005028fc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1274>
100503198:     	b	0x10050328c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1c04>
10050319c:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
1005031a0:     	add	x0, x0, #0x408
1005031a4:     	bl	0x100b1376c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1005031a8:     	cmp	w8, #0x1
1005031ac:     	b.ne	0x10050328c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1c04>
1005031b0:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs2EcWOpJ680c_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtB1a_13async_context20AsyncContextSnapshotEEKj1_EEB1a_+0x18>
1005031b4:     	add	x1, x1, #0xe18
1005031b8:     	mov	x19, x0
1005031bc:     	bl	0x100a2149c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1005031c0:     	mov	x0, x19
1005031c4:     	strb	wzr, [x19, #0x20]
1005031c8:     	ldr	x28, [sp, #0x18]
1005031cc:     	ldr	x8, [x19]
1005031d0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1005031d4:     	cmp	x8, x9
1005031d8:     	b.lo	0x100502b34 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x14ac>
1005031dc:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1005031e0:     	add	x0, x0, #0xea8
1005031e4:     	bl	0x100b1379c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1005031e8:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1005031ec:     	add	x0, x0, #0xec0
1005031f0:     	bl	0x100b1376c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1005031f4:     	mov	x0, x25
1005031f8:     	bl	0x100b1f5c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs2EcWOpJ680c_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1005031fc:     	mov	x25, x0
100503200:     	cbnz	x0, 0x100502e98 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1810>
100503204:     	b	0x10050325c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1bd4>
100503208:     	adrp	x0, 0x100ef7000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
10050320c:     	add	x0, x0, #0xd70
100503210:     	bl	0x100b1379c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100503214:     	bl	0x100b4c954 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
100503218:     	cmp	w8, #0x2
10050321c:     	b.eq	0x10050328c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1c04>
100503220:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs2EcWOpJ680c_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtB1a_13async_context20AsyncContextSnapshotEEKj1_EEB1a_+0x18>
100503224:     	add	x1, x1, #0xe18
100503228:     	mov	x20, x0
10050322c:     	bl	0x100a2149c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100503230:     	mov	x0, x20
100503234:     	strb	wzr, [x20, #0x20]
100503238:     	ldr	x8, [x20]
10050323c:     	cbz	x8, 0x100502e84 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x17fc>
100503240:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100503244:     	add	x0, x0, #0xe90
100503248:     	bl	0x100b1376c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10050324c:     	mov	x0, x25
100503250:     	bl	0x100b1f5c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs2EcWOpJ680c_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100503254:     	mov	x25, x0
100503258:     	cbnz	x0, 0x100502db4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x172c>
10050325c:     	cbz	x21, 0x10050328c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1c04>
100503260:     	mov	x0, x20
100503264:     	bl	0x100b5ffc0 <_mi_free>
100503268:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
10050326c:     	add	x0, x0, #0xc18
100503270:     	bl	0x100b5961c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100503274:     	adrp	x0, 0x100c43000 <_PERRY_EMPTY_STRING+0xa74>
100503278:     	add	x0, x0, #0x4b0
10050327c:     	mov	w1, #0xf                ; =15
100503280:     	bl	0x100b4c91c <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100503284:     	cmp	w8, #0x2
100503288:     	b.ne	0x10050332c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1ca4>
10050328c:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100503290:     	add	x0, x0, #0xc18
100503294:     	bl	0x100b5961c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100503298:     	mov	w25, #0x1               ; =1
10050329c:     	mov	w8, #0x8                ; =8
1005032a0:     	str	x8, [sp, #0x18]
1005032a4:     	ldr	x0, [x0, #0x8]
1005032a8:     	str	x0, [sp]
1005032ac:     	bl	0x10057c3c0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1005032b0:     	cbz	x0, 0x100503358 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1cd0>
1005032b4:     	mov	x26, #0x0               ; =0
1005032b8:     	mov	w24, #0x0               ; =0
1005032bc:     	ldrb	w8, [x0]
1005032c0:     	mov	x23, #0x0               ; =0
1005032c4:     	mov	w28, #0x0               ; =0
1005032c8:     	cmp	w8, #0x1
1005032cc:     	b.ne	0x100503368 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1ce0>
1005032d0:     	cmp	w25, #0x3f
1005032d4:     	ldr	x21, [sp, #0x10]
1005032d8:     	b.hi	0x1005028bc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1234>
1005032dc:     	add	w25, w25, #0x1
1005032e0:     	ldrsb	w8, [x0, #0x1]
1005032e4:     	tbnz	w8, #0x1f, 0x1005032a4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1c1c>
1005032e8:     	ldr	x25, [sp]
1005032ec:     	str	x25, [x27, #0x8]
1005032f0:     	ldrb	w8, [x27, #0x1]
1005032f4:     	orr	w8, w8, #0x80
1005032f8:     	strb	w8, [x27, #0x1]
1005032fc:     	ldrb	w8, [x0]
100503300:     	ldr	x21, [sp, #0x10]
100503304:     	cmp	w8, #0x1
100503308:     	b.ne	0x100502148 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xac0>
10050330c:     	b	0x1005021ec <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0xb64>
100503310:     	adrp	x0, 0x100f10000 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100503314:     	add	x0, x0, #0x270
100503318:     	bl	0x100b13830 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
10050331c:     	adrp	x0, 0x100c43000 <_PERRY_EMPTY_STRING+0xa74>
100503320:     	add	x0, x0, #0x1e7
100503324:     	mov	w1, #0xb                ; =11
100503328:     	bl	0x100b4c91c <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
10050332c:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs2EcWOpJ680c_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtB1a_13async_context20AsyncContextSnapshotEEKj1_EEB1a_+0x18>
100503330:     	add	x1, x1, #0xe18
100503334:     	mov	x20, x0
100503338:     	bl	0x100a2149c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10050333c:     	mov	x0, x20
100503340:     	strb	wzr, [x20, #0x20]
100503344:     	ldr	x8, [x20]
100503348:     	cbz	x8, 0x100502da0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1718>
10050334c:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100503350:     	add	x0, x0, #0xe78
100503354:     	bl	0x100b1376c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100503358:     	mov	w24, #0x0               ; =0
10050335c:     	mov	x26, #0x0               ; =0
100503360:     	mov	x23, #0x0               ; =0
100503364:     	mov	w28, #0x0               ; =0
100503368:     	ldr	x21, [sp, #0x10]
10050336c:     	b	0x1005028bc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback+0x1234>
100503370:     	mov	w0, #0x1                ; =1
100503374:     	mov	x1, x23
100503378:     	bl	0x100b133c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10050337c:     	mov	w0, #0x1                ; =1
100503380:     	mov	x1, x21
100503384:     	bl	0x100b133c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100503388:     	adrp	x2, 0x100ef8000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
10050338c:     	add	x2, x2, #0x3c8
100503390:     	mov	w0, #0x5                ; =5
100503394:     	mov	w1, #0x5                ; =5
100503398:     	bl	0x100b138cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
10050339c:     	mov	w0, #0x1                ; =1
1005033a0:     	mov	x1, x24
1005033a4:     	bl	0x100b133c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1005033a8:     	mov	w0, #0x1                ; =1
1005033ac:     	mov	x1, x26
1005033b0:     	bl	0x100b133c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1005033b4:     	nop
1005033b8:     	nop
1005033bc:     	nop

0000000100847dc0 <_js_json_stringify_full>:
100847dc0:     	sub	sp, sp, #0xa0
100847dc4:     	stp	d11, d10, [sp, #0x40]
100847dc8:     	stp	d9, d8, [sp, #0x50]
100847dcc:     	stp	x24, x23, [sp, #0x60]
100847dd0:     	stp	x22, x21, [sp, #0x70]
100847dd4:     	stp	x20, x19, [sp, #0x80]
100847dd8:     	stp	x29, x30, [sp, #0x90]
100847ddc:     	add	x29, sp, #0x90
100847de0:     	fmov	x9, d1
100847de4:     	fmov	x8, d2
100847de8:     	mov	x10, #-0x7ffc000000000001 ; =-9222246136947933185
100847dec:     	add	x11, x8, x10
100847df0:     	add	x21, x9, x10
100847df4:     	cmp	x11, #0x1
100847df8:     	b.hi	0x100847e0c <_js_json_stringify_full+0x4c>
100847dfc:     	cmp	x21, #0x2
100847e00:     	b.lo	0x100847e2c <_js_json_stringify_full+0x6c>
100847e04:     	mov	w8, #0x1                ; =1
100847e08:     	b	0x100848704 <_js_json_stringify_full+0x944>
100847e0c:     	cmp	x21, #0x2
100847e10:     	cset	w9, lo
100847e14:     	mov	x10, #0x3               ; =3
100847e18:     	movk	x10, #0x7ffc, lsl #48
100847e1c:     	cmp	x8, x10
100847e20:     	cset	w8, eq
100847e24:     	csel	w9, wzr, w9, ne
100847e28:     	tbz	w9, #0x0, 0x100848704 <_js_json_stringify_full+0x944>
100847e2c:     	fmov	x8, d0
100847e30:     	mov	x9, #-0x2               ; =-2
100847e34:     	movk	x9, #0x8003, lsl #48
100847e38:     	add	x9, x8, x9
100847e3c:     	cmp	x9, #0x3
100847e40:     	b.hs	0x100847e70 <_js_json_stringify_full+0xb0>
100847e44:     	adrp	x8, 0x100c9a000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4e30>
100847e48:     	add	x8, x8, #0x758
100847e4c:     	ldr	x0, [x8, x9, lsl #3]
100847e50:     	ldp	x29, x30, [sp, #0x90]
100847e54:     	ldp	x20, x19, [sp, #0x80]
100847e58:     	ldp	x22, x21, [sp, #0x70]
100847e5c:     	ldp	x24, x23, [sp, #0x60]
100847e60:     	ldp	d9, d8, [sp, #0x50]
100847e64:     	ldp	d11, d10, [sp, #0x40]
100847e68:     	add	sp, sp, #0xa0
100847e6c:     	ret
100847e70:     	strb	wzr, [sp, #0x14]
100847e74:     	str	wzr, [sp, #0x10]
100847e78:     	and	x9, x8, #0xffff000000000000
100847e7c:     	mov	x10, #0x7fff000000000000 ; =9223090561878065152
100847e80:     	cmp	x9, x10
100847e84:     	b.eq	0x100847ef8 <_js_json_stringify_full+0x138>
100847e88:     	mov	x10, #0x7ff9000000000000 ; =9221401712017801216
100847e8c:     	cmp	x9, x10
100847e90:     	b.ne	0x1008482ec <_js_json_stringify_full+0x52c>
100847e94:     	ubfx	x11, x8, #40, #8
100847e98:     	cbz	x11, 0x100847ee8 <_js_json_stringify_full+0x128>
100847e9c:     	strb	w8, [sp, #0x10]
100847ea0:     	cmp	x11, #0x1
100847ea4:     	b.eq	0x100847ee8 <_js_json_stringify_full+0x128>
100847ea8:     	lsr	x10, x8, #8
100847eac:     	strb	w10, [sp, #0x11]
100847eb0:     	cmp	x11, #0x2
100847eb4:     	b.eq	0x100847ee8 <_js_json_stringify_full+0x128>
100847eb8:     	lsr	x10, x8, #16
100847ebc:     	strb	w10, [sp, #0x12]
100847ec0:     	cmp	x11, #0x3
100847ec4:     	b.eq	0x100847ee8 <_js_json_stringify_full+0x128>
100847ec8:     	lsr	x10, x8, #24
100847ecc:     	strb	w10, [sp, #0x13]
100847ed0:     	cmp	x11, #0x4
100847ed4:     	b.eq	0x100847ee8 <_js_json_stringify_full+0x128>
100847ed8:     	lsr	x10, x8, #32
100847edc:     	strb	w10, [sp, #0x14]
100847ee0:     	cmp	x11, #0x5
100847ee4:     	b.ne	0x10084872c <_js_json_stringify_full+0x96c>
100847ee8:     	add	x13, sp, #0x10
100847eec:     	cmp	w11, #0x3
100847ef0:     	b.ls	0x100847f10 <_js_json_stringify_full+0x150>
100847ef4:     	b	0x1008482ec <_js_json_stringify_full+0x52c>
100847ef8:     	ands	x10, x8, #0xffffffffffff
100847efc:     	b.eq	0x100847e04 <_js_json_stringify_full+0x44>
100847f00:     	add	x13, x10, #0x14
100847f04:     	ldr	w11, [x10, #0x4]
100847f08:     	cmp	w11, #0x3
100847f0c:     	b.hi	0x1008482ec <_js_json_stringify_full+0x52c>
100847f10:     	stur	wzr, [sp, #0x19]
100847f14:     	mov	w10, #0x22              ; =34
100847f18:     	strb	w10, [sp, #0x18]
100847f1c:     	cbz	w11, 0x100847f54 <_js_json_stringify_full+0x194>
100847f20:     	add	x12, sp, #0x18
100847f24:     	ldrb	w14, [x13]
100847f28:     	sxtb	w16, w14
100847f2c:     	cmp	w14, #0xb
100847f30:     	b.le	0x100847f5c <_js_json_stringify_full+0x19c>
100847f34:     	cmp	w14, #0x21
100847f38:     	b.gt	0x100847f7c <_js_json_stringify_full+0x1bc>
100847f3c:     	cmp	w14, #0xc
100847f40:     	b.eq	0x100847fb0 <_js_json_stringify_full+0x1f0>
100847f44:     	cmp	w14, #0xd
100847f48:     	b.ne	0x100847f8c <_js_json_stringify_full+0x1cc>
100847f4c:     	mov	w16, #0x72              ; =114
100847f50:     	b	0x100847fbc <_js_json_stringify_full+0x1fc>
100847f54:     	mov	w12, #0x1               ; =1
100847f58:     	b	0x100847fe4 <_js_json_stringify_full+0x224>
100847f5c:     	cmp	w14, #0x8
100847f60:     	b.eq	0x100847fa8 <_js_json_stringify_full+0x1e8>
100847f64:     	cmp	w14, #0x9
100847f68:     	b.eq	0x100847fb8 <_js_json_stringify_full+0x1f8>
100847f6c:     	cmp	w14, #0xa
100847f70:     	b.ne	0x100847f8c <_js_json_stringify_full+0x1cc>
100847f74:     	mov	w16, #0x6e              ; =110
100847f78:     	b	0x100847fbc <_js_json_stringify_full+0x1fc>
100847f7c:     	cmp	w14, #0x22
100847f80:     	b.eq	0x100847fbc <_js_json_stringify_full+0x1fc>
100847f84:     	cmp	w14, #0x5c
100847f88:     	b.eq	0x100847fbc <_js_json_stringify_full+0x1fc>
100847f8c:     	cmp	w16, #0x20
100847f90:     	b.lt	0x1008482ec <_js_json_stringify_full+0x52c>
100847f94:     	mov	w15, #0x0               ; =0
100847f98:     	add	x14, x12, #0x2
100847f9c:     	mov	w12, #0x2               ; =2
100847fa0:     	mov	w17, #0x1               ; =1
100847fa4:     	b	0x100847fd4 <_js_json_stringify_full+0x214>
100847fa8:     	mov	w16, #0x62              ; =98
100847fac:     	b	0x100847fbc <_js_json_stringify_full+0x1fc>
100847fb0:     	mov	w16, #0x66              ; =102
100847fb4:     	b	0x100847fbc <_js_json_stringify_full+0x1fc>
100847fb8:     	mov	w16, #0x74              ; =116
100847fbc:     	add	x14, x12, #0x3
100847fc0:     	mov	w12, #0x5c              ; =92
100847fc4:     	strb	w12, [sp, #0x19]
100847fc8:     	mov	w15, #0x1               ; =1
100847fcc:     	mov	w12, #0x3               ; =3
100847fd0:     	mov	w17, #0x2               ; =2
100847fd4:     	add	x0, sp, #0x18
100847fd8:     	strb	w16, [x0, x17]
100847fdc:     	cmp	w11, #0x1
100847fe0:     	b.ne	0x100848024 <_js_json_stringify_full+0x264>
100847fe4:     	add	x9, sp, #0x18
100847fe8:     	strb	w10, [x9, x12]
100847fec:     	add	x8, x12, #0x1
100847ff0:     	cmp	x12, #0x3
100847ff4:     	b.hs	0x100848008 <_js_json_stringify_full+0x248>
100847ff8:     	mov	x15, #0x0               ; =0
100847ffc:     	mov	x11, #0x0               ; =0
100848000:     	add	x10, sp, #0x18
100848004:     	b	0x10084825c <_js_json_stringify_full+0x49c>
100848008:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4e30>
10084800c:     	adrp	x13, 0x100c3a000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x3363a>
100848010:     	cmp	x12, #0xf
100848014:     	b.hs	0x100848054 <_js_json_stringify_full+0x294>
100848018:     	mov	x11, #0x0               ; =0
10084801c:     	mov	x15, #0x0               ; =0
100848020:     	b	0x1008481c0 <_js_json_stringify_full+0x400>
100848024:     	ldrb	w17, [x13, #0x1]
100848028:     	sxtb	w16, w17
10084802c:     	cmp	w17, #0xb
100848030:     	b.le	0x10084828c <_js_json_stringify_full+0x4cc>
100848034:     	cmp	w17, #0x21
100848038:     	b.gt	0x1008482ac <_js_json_stringify_full+0x4ec>
10084803c:     	cmp	w17, #0xc
100848040:     	b.eq	0x1008482dc <_js_json_stringify_full+0x51c>
100848044:     	cmp	w17, #0xd
100848048:     	b.ne	0x1008482bc <_js_json_stringify_full+0x4fc>
10084804c:     	mov	w16, #0x72              ; =114
100848050:     	b	0x1008482e8 <_js_json_stringify_full+0x528>
100848054:     	and	x12, x8, #0xc
100848058:     	and	x11, x8, #0x10
10084805c:     	add	x15, sp, #0x18
100848060:     	add	x10, x15, x11
100848064:     	adrp	x16, 0x100c9b000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e30>
100848068:     	ldr	q0, [x16, #0x8d0]
10084806c:     	adrp	x16, 0x100c9b000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e30>
100848070:     	ldr	q1, [x16, #0x8e0]
100848074:     	adrp	x16, 0x100c9b000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e30>
100848078:     	ldr	q2, [x16, #0x8f0]
10084807c:     	adrp	x16, 0x100c9b000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e30>
100848080:     	ldr	q3, [x16, #0x900]
100848084:     	adrp	x16, 0x100c9b000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e30>
100848088:     	ldr	q4, [x16, #0x910]
10084808c:     	movi.2d	v5, #0000000000000000
100848090:     	adrp	x16, 0x100c9b000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5e30>
100848094:     	ldr	q6, [x16, #0x920]
100848098:     	mov	w16, #0x10              ; =16
10084809c:     	dup.2d	v7, x16
1008480a0:     	and	x16, x8, #0x10
1008480a4:     	movi.2d	v16, #0000000000000000
1008480a8:     	ldr	q19, [x14, #0xa40]
1008480ac:     	movi.2d	v18, #0000000000000000
1008480b0:     	movi.2d	v17, #0000000000000000
1008480b4:     	ldr	q23, [x13, #0x940]
1008480b8:     	movi.2d	v22, #0000000000000000
1008480bc:     	movi.2d	v20, #0000000000000000
1008480c0:     	movi.2d	v24, #0000000000000000
1008480c4:     	movi.2d	v21, #0000000000000000
1008480c8:     	ldr	q25, [x15], #0x10
1008480cc:     	ushll.8h	v26, v25, #0x0
1008480d0:     	ushll2.4s	v27, v26, #0x0
1008480d4:     	ushll2.2d	v28, v27, #0x0
1008480d8:     	ushll2.8h	v25, v25, #0x0
1008480dc:     	ushll.4s	v29, v25, #0x0
1008480e0:     	ushll2.2d	v30, v29, #0x0
1008480e4:     	ushll.2d	v29, v29, #0x0
1008480e8:     	ushll.2d	v27, v27, #0x0
1008480ec:     	ushll.4s	v26, v26, #0x0
1008480f0:     	ushll2.2d	v31, v26, #0x0
1008480f4:     	ushll2.4s	v25, v25, #0x0
1008480f8:     	ushll.2d	v8, v25, #0x0
1008480fc:     	ushll.2d	v26, v26, #0x0
100848100:     	ushll2.2d	v25, v25, #0x0
100848104:     	shl.2d	v9, v0, #0x3
100848108:     	ushl.2d	v25, v25, v9
10084810c:     	shl.2d	v9, v23, #0x3
100848110:     	ushl.2d	v26, v26, v9
100848114:     	shl.2d	v9, v1, #0x3
100848118:     	ushl.2d	v8, v8, v9
10084811c:     	shl.2d	v9, v19, #0x3
100848120:     	ushl.2d	v31, v31, v9
100848124:     	shl.2d	v9, v6, #0x3
100848128:     	ushl.2d	v27, v27, v9
10084812c:     	shl.2d	v9, v3, #0x3
100848130:     	ushl.2d	v29, v29, v9
100848134:     	shl.2d	v9, v2, #0x3
100848138:     	ushl.2d	v30, v30, v9
10084813c:     	shl.2d	v9, v4, #0x3
100848140:     	ushl.2d	v28, v28, v9
100848144:     	orr.16b	v17, v28, v17
100848148:     	orr.16b	v20, v30, v20
10084814c:     	orr.16b	v22, v29, v22
100848150:     	orr.16b	v18, v27, v18
100848154:     	orr.16b	v5, v31, v5
100848158:     	orr.16b	v24, v8, v24
10084815c:     	orr.16b	v16, v26, v16
100848160:     	orr.16b	v21, v25, v21
100848164:     	add.2d	v6, v6, v7
100848168:     	add.2d	v19, v19, v7
10084816c:     	add.2d	v23, v23, v7
100848170:     	add.2d	v4, v4, v7
100848174:     	add.2d	v3, v3, v7
100848178:     	add.2d	v2, v2, v7
10084817c:     	add.2d	v1, v1, v7
100848180:     	add.2d	v0, v0, v7
100848184:     	subs	x16, x16, #0x10
100848188:     	b.ne	0x1008480c8 <_js_json_stringify_full+0x308>
10084818c:     	orr.16b	v0, v16, v22
100848190:     	orr.16b	v1, v18, v24
100848194:     	orr.16b	v0, v0, v1
100848198:     	orr.16b	v1, v5, v20
10084819c:     	orr.16b	v2, v17, v21
1008481a0:     	orr.16b	v1, v1, v2
1008481a4:     	orr.16b	v0, v0, v1
1008481a8:     	mov	d1, v0[1]
1008481ac:     	orr.8b	v0, v0, v1
1008481b0:     	fmov	x15, d0
1008481b4:     	cmp	x8, x11
1008481b8:     	b.eq	0x10084827c <_js_json_stringify_full+0x4bc>
1008481bc:     	cbz	x12, 0x10084825c <_js_json_stringify_full+0x49c>
1008481c0:     	mov	x16, x11
1008481c4:     	and	x11, x8, #0x1c
1008481c8:     	add	x17, sp, #0x18
1008481cc:     	add	x10, x17, x11
1008481d0:     	fmov	d0, x15
1008481d4:     	movi.2d	v1, #0000000000000000
1008481d8:     	dup.2d	v3, x16
1008481dc:     	ldr	q2, [x14, #0xa40]
1008481e0:     	orr.16b	v2, v3, v2
1008481e4:     	ldr	q4, [x13, #0x940]
1008481e8:     	orr.16b	v3, v3, v4
1008481ec:     	sub	x12, x16, x11
1008481f0:     	add	x13, x17, x16
1008481f4:     	movi.2d	v4, #0x000000000000ff
1008481f8:     	mov	w14, #0x4               ; =4
1008481fc:     	dup.2d	v5, x14
100848200:     	ldr	s6, [x13], #0x4
100848204:     	ushll.8h	v6, v6, #0x0
100848208:     	ushll.4s	v6, v6, #0x0
10084820c:     	ushll2.2d	v7, v6, #0x0
100848210:     	and.16b	v7, v7, v4
100848214:     	ushll.2d	v6, v6, #0x0
100848218:     	and.16b	v6, v6, v4
10084821c:     	shl.2d	v16, v2, #0x3
100848220:     	shl.2d	v17, v3, #0x3
100848224:     	ushl.2d	v6, v6, v17
100848228:     	ushl.2d	v7, v7, v16
10084822c:     	orr.16b	v1, v7, v1
100848230:     	orr.16b	v0, v6, v0
100848234:     	add.2d	v2, v2, v5
100848238:     	add.2d	v3, v3, v5
10084823c:     	adds	x12, x12, #0x4
100848240:     	b.ne	0x100848200 <_js_json_stringify_full+0x440>
100848244:     	orr.16b	v0, v0, v1
100848248:     	mov	d1, v0[1]
10084824c:     	orr.8b	v0, v0, v1
100848250:     	fmov	x15, d0
100848254:     	cmp	x8, x11
100848258:     	b.eq	0x10084827c <_js_json_stringify_full+0x4bc>
10084825c:     	add	x9, x9, x8
100848260:     	lsl	x11, x11, #3
100848264:     	ldrb	w12, [x10], #0x1
100848268:     	lsl	x12, x12, x11
10084826c:     	orr	x15, x12, x15
100848270:     	add	x11, x11, #0x8
100848274:     	cmp	x10, x9
100848278:     	b.ne	0x100848264 <_js_json_stringify_full+0x4a4>
10084827c:     	orr	x8, x15, x8, lsl #40
100848280:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100848284:     	orr	x0, x8, x9
100848288:     	b	0x100847e50 <_js_json_stringify_full+0x90>
10084828c:     	cmp	w17, #0x8
100848290:     	b.eq	0x1008482d4 <_js_json_stringify_full+0x514>
100848294:     	cmp	w17, #0x9
100848298:     	b.eq	0x1008482e4 <_js_json_stringify_full+0x524>
10084829c:     	cmp	w17, #0xa
1008482a0:     	b.ne	0x1008482bc <_js_json_stringify_full+0x4fc>
1008482a4:     	mov	w16, #0x6e              ; =110
1008482a8:     	b	0x1008482e8 <_js_json_stringify_full+0x528>
1008482ac:     	cmp	w17, #0x22
1008482b0:     	b.eq	0x1008482e8 <_js_json_stringify_full+0x528>
1008482b4:     	cmp	w17, #0x5c
1008482b8:     	b.eq	0x1008482e8 <_js_json_stringify_full+0x528>
1008482bc:     	cmp	w16, #0x20
1008482c0:     	b.lt	0x1008482ec <_js_json_stringify_full+0x52c>
1008482c4:     	add	x14, sp, #0x18
1008482c8:     	strb	w16, [x14, x12]
1008482cc:     	add	x12, x12, #0x1
1008482d0:     	b	0x100848430 <_js_json_stringify_full+0x670>
1008482d4:     	mov	w16, #0x62              ; =98
1008482d8:     	b	0x1008482e8 <_js_json_stringify_full+0x528>
1008482dc:     	mov	w16, #0x66              ; =102
1008482e0:     	b	0x1008482e8 <_js_json_stringify_full+0x528>
1008482e4:     	mov	w16, #0x74              ; =116
1008482e8:     	tbz	w15, #0x0, 0x10084841c <_js_json_stringify_full+0x65c>
1008482ec:     	mov	x10, #0x7ffd000000000000 ; =9222527611924643840
1008482f0:     	cmp	x9, x10
1008482f4:     	b.eq	0x100848358 <_js_json_stringify_full+0x598>
1008482f8:     	mov	x10, #0x7fff000000000000 ; =9223090561878065152
1008482fc:     	cmp	x9, x10
100848300:     	b.ne	0x100847e04 <_js_json_stringify_full+0x44>
100848304:     	and	x0, x8, #0xffffffffffff
100848308:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
10084830c:     	mov	x9, #0x7fffffffffff     ; =140737488355327
100848310:     	movk	x9, #0xffef, lsl #16
100848314:     	cmp	x8, x9
100848318:     	b.hi	0x100847e04 <_js_json_stringify_full+0x44>
10084831c:     	ldr	w8, [x0, #0x4]
100848320:     	cmp	w8, #0x40
100848324:     	b.lo	0x100847e04 <_js_json_stringify_full+0x44>
100848328:     	mov.16b	v8, v2
10084832c:     	mov.16b	v10, v1
100848330:     	mov.16b	v9, v0
100848334:     	bl	0x1004f3068 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json16stringify_string17quote_heap_string>
100848338:     	mov.16b	v0, v9
10084833c:     	mov.16b	v1, v10
100848340:     	mov.16b	v2, v8
100848344:     	cmp	x0, #0x1
100848348:     	b.ne	0x100847e04 <_js_json_stringify_full+0x44>
10084834c:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100848350:     	bfxil	x0, x1, #0, #48
100848354:     	b	0x100847e50 <_js_json_stringify_full+0x90>
100848358:     	mov.16b	v8, v0
10084835c:     	mov.16b	v9, v1
100848360:     	mov.16b	v10, v2
100848364:     	and	x19, x8, #0xffffffffffff
100848368:     	mov	x0, x19
10084836c:     	bl	0x10057c3c0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100848370:     	cbz	x0, 0x1008483a4 <_js_json_stringify_full+0x5e4>
100848374:     	ldrb	w8, [x0]
100848378:     	cmp	w8, #0x2
10084837c:     	b.ne	0x1008483a4 <_js_json_stringify_full+0x5e4>
100848380:     	ldrsb	w8, [x0, #0x1]
100848384:     	tbnz	w8, #0x1f, 0x1008483a4 <_js_json_stringify_full+0x5e4>
100848388:     	ldrh	w8, [x0, #0x2]
10084838c:     	tbnz	w8, #0xb, 0x1008483a4 <_js_json_stringify_full+0x5e4>
100848390:     	ldr	w8, [x0, #0x4]
100848394:     	cmp	w8, #0x18
100848398:     	b.lo	0x1008483a4 <_js_json_stringify_full+0x5e4>
10084839c:     	ldr	w8, [x19]
1008483a0:     	cbz	w8, 0x1008484b8 <_js_json_stringify_full+0x6f8>
1008483a4:     	mov	x0, x19
1008483a8:     	bl	0x10057c3c0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1008483ac:     	mov.16b	v2, v10
1008483b0:     	mov.16b	v1, v9
1008483b4:     	mov.16b	v0, v8
1008483b8:     	cbz	x0, 0x100847e04 <_js_json_stringify_full+0x44>
1008483bc:     	ldrb	w8, [x0]
1008483c0:     	cmp	w8, #0x2
1008483c4:     	b.ne	0x100847e04 <_js_json_stringify_full+0x44>
1008483c8:     	ldrh	w8, [x0, #0x2]
1008483cc:     	tbnz	w8, #0xb, 0x100847e04 <_js_json_stringify_full+0x44>
1008483d0:     	ldr	w8, [x0, #0x4]
1008483d4:     	cmp	w8, #0x18
1008483d8:     	b.lo	0x100847e04 <_js_json_stringify_full+0x44>
1008483dc:     	ldr	w8, [x19]
1008483e0:     	cbnz	w8, 0x100847e04 <_js_json_stringify_full+0x44>
1008483e4:     	mov	x22, x0
1008483e8:     	mov	x0, x19
1008483ec:     	bl	0x100348000 <__RNvNtCs2EcWOpJ680c_13perry_runtime6object17object_keys_array>
1008483f0:     	cbz	x0, 0x100848510 <_js_json_stringify_full+0x750>
1008483f4:     	ldr	w20, [x0]
1008483f8:     	cmp	w20, #0x4
1008483fc:     	mov.16b	v2, v10
100848400:     	mov.16b	v1, v9
100848404:     	mov.16b	v0, v8
100848408:     	b.hi	0x100847e04 <_js_json_stringify_full+0x44>
10084840c:     	ldr	w8, [x0, #0x4]
100848410:     	cmp	w20, w8
100848414:     	b.hi	0x100847e04 <_js_json_stringify_full+0x44>
100848418:     	b	0x100848520 <_js_json_stringify_full+0x760>
10084841c:     	add	x15, sp, #0x18
100848420:     	mov	w17, #0x5c              ; =92
100848424:     	strb	w17, [x15, x12]
100848428:     	add	x12, x12, #0x2
10084842c:     	strb	w16, [x14, #0x1]
100848430:     	cmp	w11, #0x2
100848434:     	b.eq	0x100847fe4 <_js_json_stringify_full+0x224>
100848438:     	ldrb	w13, [x13, #0x2]
10084843c:     	sxtb	w11, w13
100848440:     	cmp	w13, #0xb
100848444:     	b.le	0x100848468 <_js_json_stringify_full+0x6a8>
100848448:     	cmp	w13, #0x21
10084844c:     	b.gt	0x100848488 <_js_json_stringify_full+0x6c8>
100848450:     	cmp	w13, #0xc
100848454:     	b.eq	0x1008484e0 <_js_json_stringify_full+0x720>
100848458:     	cmp	w13, #0xd
10084845c:     	b.ne	0x100848498 <_js_json_stringify_full+0x6d8>
100848460:     	mov	w11, #0x72              ; =114
100848464:     	b	0x1008484ec <_js_json_stringify_full+0x72c>
100848468:     	cmp	w13, #0x8
10084846c:     	b.eq	0x1008484d8 <_js_json_stringify_full+0x718>
100848470:     	cmp	w13, #0x9
100848474:     	b.eq	0x1008484e8 <_js_json_stringify_full+0x728>
100848478:     	cmp	w13, #0xa
10084847c:     	b.ne	0x100848498 <_js_json_stringify_full+0x6d8>
100848480:     	mov	w11, #0x6e              ; =110
100848484:     	b	0x1008484ec <_js_json_stringify_full+0x72c>
100848488:     	cmp	w13, #0x22
10084848c:     	b.eq	0x1008484ec <_js_json_stringify_full+0x72c>
100848490:     	cmp	w13, #0x5c
100848494:     	b.eq	0x1008484ec <_js_json_stringify_full+0x72c>
100848498:     	cmp	x12, #0x3
10084849c:     	mov	w13, #0x20              ; =32
1008484a0:     	ccmp	w11, w13, #0x8, ls
1008484a4:     	b.lt	0x1008482ec <_js_json_stringify_full+0x52c>
1008484a8:     	add	x8, sp, #0x18
1008484ac:     	strb	w11, [x8, x12]
1008484b0:     	add	x12, x12, #0x1
1008484b4:     	b	0x100847fe4 <_js_json_stringify_full+0x224>
1008484b8:     	mov	x1, x0
1008484bc:     	mov	x0, x19
1008484c0:     	mov	x22, x1
1008484c4:     	bl	0x1004f91c0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json23stringify_record_output20emit_repeated_output>
1008484c8:     	cmp	x0, #0x1
1008484cc:     	b.ne	0x1008485e8 <_js_json_stringify_full+0x828>
1008484d0:     	mov	x0, x1
1008484d4:     	b	0x100847e50 <_js_json_stringify_full+0x90>
1008484d8:     	mov	w11, #0x62              ; =98
1008484dc:     	b	0x1008484ec <_js_json_stringify_full+0x72c>
1008484e0:     	mov	w11, #0x66              ; =102
1008484e4:     	b	0x1008484ec <_js_json_stringify_full+0x72c>
1008484e8:     	mov	w11, #0x74              ; =116
1008484ec:     	cmp	x12, #0x2
1008484f0:     	b.hi	0x1008482ec <_js_json_stringify_full+0x52c>
1008484f4:     	add	x8, sp, #0x18
1008484f8:     	add	x8, x8, x12
1008484fc:     	add	x12, x12, #0x2
100848500:     	mov	w9, #0x5c               ; =92
100848504:     	strb	w9, [x8]
100848508:     	strb	w11, [x8, #0x1]
10084850c:     	b	0x100847fe4 <_js_json_stringify_full+0x224>
100848510:     	mov	x20, #0x0               ; =0
100848514:     	mov.16b	v2, v10
100848518:     	mov.16b	v1, v9
10084851c:     	mov.16b	v0, v8
100848520:     	ldr	w8, [x22, #0x4]
100848524:     	lsl	x9, x20, #3
100848528:     	add	x9, x9, #0x18
10084852c:     	cmp	x9, x8
100848530:     	b.hi	0x100847e04 <_js_json_stringify_full+0x44>
100848534:     	ldr	w8, [x19, #0x4]
100848538:     	mov	w9, #-0x40000000        ; =-1073741824
10084853c:     	nop
100848540:     	cmp	w8, w9
100848544:     	csel	w8, w8, wzr, lt
100848548:     	mov	x22, x0
10084854c:     	mov	x0, x8
100848550:     	bl	0x1005e70a4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
100848554:     	mov.16b	v0, v8
100848558:     	mov.16b	v1, v9
10084855c:     	mov.16b	v2, v10
100848560:     	mov	w9, #0x2                ; =2
100848564:     	cmp	w1, #0x2
100848568:     	csel	w10, w1, w9, hi
10084856c:     	tst	w0, #0x1
100848570:     	csel	x8, x10, x9, ne
100848574:     	cmp	x20, x8
100848578:     	b.hi	0x100847e04 <_js_json_stringify_full+0x44>
10084857c:     	cbz	x20, 0x100848694 <_js_json_stringify_full+0x8d4>
100848580:     	mov	x0, x22
100848584:     	mov	x1, x20
100848588:     	bl	0x1004f0180 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
10084858c:     	mov.16b	v2, v10
100848590:     	mov.16b	v1, v9
100848594:     	mov.16b	v0, v8
100848598:     	tbz	w0, #0x0, 0x100847e04 <_js_json_stringify_full+0x44>
10084859c:     	str	x21, [sp, #0x8]
1008485a0:     	cmp	x20, #0x1
1008485a4:     	b.eq	0x1008486b0 <_js_json_stringify_full+0x8f0>
1008485a8:     	cmp	x20, #0x2
1008485ac:     	b.ne	0x1008486d8 <_js_json_stringify_full+0x918>
1008485b0:     	mov	x21, #0x0               ; =0
1008485b4:     	add	x22, x19, #0x10
1008485b8:     	mov	w8, #0x1                ; =1
1008485bc:     	mov	x23, x8
1008485c0:     	ldr	x1, [x22, x21, lsl #3]
1008485c4:     	add	x0, sp, #0x18
1008485c8:     	bl	0x1004f01d4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
1008485cc:     	ldr	w8, [sp, #0x18]
1008485d0:     	cmn	w8, #0x1
1008485d4:     	b.ne	0x1008486bc <_js_json_stringify_full+0x8fc>
1008485d8:     	mov	w8, #0x0                ; =0
1008485dc:     	mov	w21, #0x1               ; =1
1008485e0:     	tbnz	w23, #0x0, 0x1008485bc <_js_json_stringify_full+0x7fc>
1008485e4:     	b	0x1008486d8 <_js_json_stringify_full+0x918>
1008485e8:     	mov	x0, x19
1008485ec:     	bl	0x100348000 <__RNvNtCs2EcWOpJ680c_13perry_runtime6object17object_keys_array>
1008485f0:     	cbz	x0, 0x10084867c <_js_json_stringify_full+0x8bc>
1008485f4:     	ldr	w20, [x0]
1008485f8:     	cbz	w20, 0x10084867c <_js_json_stringify_full+0x8bc>
1008485fc:     	cmp	w20, #0x8
100848600:     	b.hi	0x1008483a4 <_js_json_stringify_full+0x5e4>
100848604:     	ldr	w8, [x0, #0x4]
100848608:     	cmp	w20, w8
10084860c:     	b.hi	0x1008483a4 <_js_json_stringify_full+0x5e4>
100848610:     	ldr	w8, [x22, #0x4]
100848614:     	lsl	x9, x20, #3
100848618:     	add	x9, x9, #0x18
10084861c:     	cmp	x9, x8
100848620:     	b.hi	0x1008483a4 <_js_json_stringify_full+0x5e4>
100848624:     	ldr	w8, [x19, #0x4]
100848628:     	mov	w9, #-0x40000000        ; =-1073741824
10084862c:     	cmp	w8, w9
100848630:     	csel	w8, w8, wzr, lt
100848634:     	mov	x22, x0
100848638:     	mov	x0, x8
10084863c:     	bl	0x1005e70a4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
100848640:     	mov	w9, #0x2                ; =2
100848644:     	cmp	w1, #0x2
100848648:     	csel	w10, w1, w9, hi
10084864c:     	tst	w0, #0x1
100848650:     	csel	w8, w10, w9, ne
100848654:     	cmp	w20, w8
100848658:     	b.hi	0x1008483a4 <_js_json_stringify_full+0x5e4>
10084865c:     	mov	x0, x22
100848660:     	mov	x1, x20
100848664:     	bl	0x1004f0180 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
100848668:     	cbz	w0, 0x1008483a4 <_js_json_stringify_full+0x5e4>
10084866c:     	mov	x0, x19
100848670:     	mov	x1, x20
100848674:     	bl	0x1004f8300 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json23stringify_record_output11emit_record>
100848678:     	b	0x100848684 <_js_json_stringify_full+0x8c4>
10084867c:     	mov	x0, x19
100848680:     	bl	0x1004f9080 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json23stringify_record_output17emit_empty_object>
100848684:     	mov	x8, x0
100848688:     	mov	x0, x1
10084868c:     	tbnz	w8, #0x0, 0x100847e50 <_js_json_stringify_full+0x90>
100848690:     	b	0x1008483a4 <_js_json_stringify_full+0x5e4>
100848694:     	mov	x0, x19
100848698:     	bl	0x1004f8130 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
10084869c:     	mov	w8, w0
1008486a0:     	mov	x0, #0x7d7b             ; =32123
1008486a4:     	movk	x0, #0x200, lsl #32
1008486a8:     	movk	x0, #0x7ff9, lsl #48
1008486ac:     	b	0x1008486f0 <_js_json_stringify_full+0x930>
1008486b0:     	mov	x0, x19
1008486b4:     	bl	0x1004efd80 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat21emit_one_field_object>
1008486b8:     	b	0x1008486e4 <_js_json_stringify_full+0x924>
1008486bc:     	add	x2, sp, #0x18
1008486c0:     	mov	x0, x19
1008486c4:     	mov	x1, x21
1008486c8:     	bl	0x1004f0580 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
1008486cc:     	mov	x8, x0
1008486d0:     	tbnz	w8, #0x0, 0x1008484d0 <_js_json_stringify_full+0x710>
1008486d4:     	mov	w20, #0x2               ; =2
1008486d8:     	mov	x0, x19
1008486dc:     	mov	x1, x20
1008486e0:     	bl	0x1004eec00 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat11emit_object>
1008486e4:     	mov	x8, x0
1008486e8:     	mov	x0, x1
1008486ec:     	ldr	x21, [sp, #0x8]
1008486f0:     	tbnz	w8, #0x0, 0x100847e50 <_js_json_stringify_full+0x90>
1008486f4:     	mov	w8, #0x1                ; =1
1008486f8:     	mov.16b	v2, v10
1008486fc:     	mov.16b	v1, v9
100848700:     	mov.16b	v0, v8
100848704:     	cmp	x21, #0x2
100848708:     	csel	w0, wzr, w8, hs
10084870c:     	ldp	x29, x30, [sp, #0x90]
100848710:     	ldp	x20, x19, [sp, #0x80]
100848714:     	ldp	x22, x21, [sp, #0x70]
100848718:     	ldp	x24, x23, [sp, #0x60]
10084871c:     	ldp	d9, d8, [sp, #0x50]
100848720:     	ldp	d11, d10, [sp, #0x40]
100848724:     	add	sp, sp, #0xa0
100848728:     	b	0x100501688 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer23stringify_full_fallback>
10084872c:     	adrp	x2, 0x100ef8000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100848730:     	add	x2, x2, #0x3c8
100848734:     	mov	w0, #0x5                ; =5
100848738:     	mov	w1, #0x5                ; =5
10084873c:     	bl	0x100b138cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
		...
