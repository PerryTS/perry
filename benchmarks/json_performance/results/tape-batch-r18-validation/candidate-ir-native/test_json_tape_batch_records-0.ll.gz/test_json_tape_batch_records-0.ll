; ModuleID = '/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/tape-batch-r18/candidate-ir-native/test_json_tape_batch_records/.perry-trace/llvm/test_json_tape_batch_records_ts.ll'
source_filename = "perry_module"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx15.0.0"

module asm ".no_dead_strip __LLVM_StackMaps"

@test_json_tape_batch_records_ts_.str.0 = private unnamed_addr constant [129 x i8] c"/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/tape-batch-r18/test_json_tape_batch_records.ts\00"
@test_json_tape_batch_records_ts_.str.0.bytes = private unnamed_addr constant [6 x i8] c"\22id\22:\00"
@test_json_tape_batch_records_ts_.str.1.bytes = private unnamed_addr constant [2 x i8] c"{\00"
@test_json_tape_batch_records_ts_.str.2.bytes = private unnamed_addr constant [43 x i8] c",\22name\22:\22\\u0061\\ud800\\n\22,\22tags\22:[],\22n\22:-0}\00"
@test_json_tape_batch_records_ts_.str.3.bytes = private unnamed_addr constant [12 x i8] c",\22\\u0069d\22:\00"
@test_json_tape_batch_records_ts_.str.4.bytes = private unnamed_addr constant [41 x i8] c",\22name\22:\22\C3\A9\F0\9F\98\80\22,\22tags\22:[null,true,0.1]}\00"
@test_json_tape_batch_records_ts_.str.5.bytes = private unnamed_addr constant [42 x i8] c",\22nested\22:{\22x\22:1,\22x\22:2},\22tags\22:[[1],[2]]}\00"
@test_json_tape_batch_records_ts_.str.6.bytes = private unnamed_addr constant [50 x i8] c",\22a\22:1,\22b\22:2,\22c\22:3,\22d\22:4,\22e\22:5,\22f\22:6,\22g\22:7,\22h\22:8}\00"
@test_json_tape_batch_records_ts_.str.7.bytes = private unnamed_addr constant [48 x i8] c",\22__proto__\22:{\22safe\22:true},\22tags\22:[],\22n\22:1e300}\00"
@test_json_tape_batch_records_ts_.str.8.bytes = private unnamed_addr constant [17 x i8] c",\22name\22:\22record_\00"
@test_json_tape_batch_records_ts_.str.9.bytes = private unnamed_addr constant [63 x i8] c"\22,\22tags\22:[\22red\22,\22blue\22],\22active\22:true,\22n\22:0.10000000000000001}\00"
@test_json_tape_batch_records_ts_.str.10.bytes = private unnamed_addr constant [3 x i8] c"[ \00"
@test_json_tape_batch_records_ts_.str.11.bytes = private unnamed_addr constant [4 x i8] c" , \00"
@test_json_tape_batch_records_ts_.str.12.bytes = private unnamed_addr constant [3 x i8] c" ]\00"
@test_json_tape_batch_records_ts_.str.13.bytes = private unnamed_addr constant [5 x i8] c"name\00"
@test_json_tape_batch_records_ts_.str.14.bytes = private unnamed_addr constant [9 x i8] c"changed_\00"
@test_json_tape_batch_records_ts_.str.15.bytes = private unnamed_addr constant [5 x i8] c"tags\00"
@test_json_tape_batch_records_ts_.str.16.bytes = private unnamed_addr constant [6 x i8] c"extra\00"
@test_json_tape_batch_records_ts_.str.17.bytes = private unnamed_addr constant [5 x i8] c"push\00"
@test_json_tape_batch_records_ts_.str.18.bytes = private unnamed_addr constant [3 x i8] c"id\00"
@test_json_tape_batch_records_ts_.str.19.bytes = private unnamed_addr constant [7 x i8] c"length\00"
@test_json_tape_batch_records_ts_.str.20.bytes = private unnamed_addr constant [21 x i8] c"lost cached identity\00"
@test_json_tape_batch_records_ts_.str.21.bytes = private unnamed_addr constant [21 x i8] c"lost cached mutation\00"
@test_json_tape_batch_records_ts_.str.22.bytes = private unnamed_addr constant [21 x i8] c"lost nested mutation\00"
@test_json_tape_batch_records_ts_.str.23.bytes = private unnamed_addr constant [9 x i8] c"checksum\00"
@test_json_tape_batch_records_ts_.str.24.bytes = private unnamed_addr constant [5 x i8] c"done\00"
@test_json_tape_batch_records_ts_.str.25.bytes = private unnamed_addr constant [6 x i8] c"value\00"
@test_json_tape_batch_records_ts_.str.26.bytes = private unnamed_addr constant [7 x i8] c"return\00"
@test_json_tape_batch_records_ts_.str.27.bytes = private unnamed_addr constant [16 x i8] c"stringify_first\00"
@test_json_tape_batch_records_ts_.str.28.bytes = private unnamed_addr constant [6 x i8] c"alias\00"
@test_json_tape_batch_records_ts_.str.1 = private unnamed_addr constant [7 x i8] c"record\00"
@test_json_tape_batch_records_ts_.str.2 = private unnamed_addr constant [761 x i8] c"function record(index: number): string {\0A    const id = '\22id\22:' + index;\0A    if (index % 7 === 1) {\0A        return '{' + id + ',\22name\22:\22\\\\u0061\\\\ud800\\\\n\22,\22tags\22:[],\22n\22:-0}';\0A    }\0A    if (index % 7 === 2) {\0A        return '{' + id + ',\22\\\\u0069d\22:' + (index + 10) + ',\22name\22:\22\C3\A9\F0\9F\98\80\22,\22tags\22:[null,true,0.1]}';\0A    }\0A    if (index % 7 === 3) {\0A        return '{' + id + ',\22nested\22:{\22x\22:1,\22x\22:2},\22tags\22:[[1],[2]]}';\0A    }\0A    if (index % 7 === 4) {\0A        return '{' + id + ',\22a\22:1,\22b\22:2,\22c\22:3,\22d\22:4,\22e\22:5,\22f\22:6,\22g\22:7,\22h\22:8}';\0A    }\0A    if (index % 7 === 5) {\0A        return '{' + id + ',\22__proto__\22:{\22safe\22:true},\22tags\22:[],\22n\22:1e300}';\0A    }\0A    return '{' + id + ',\22name\22:\22record_' + index + '\22,\22tags\22:[\22red\22,\22blue\22],\22active\22:true,\22n\22:0.10000000000000001}';\0A}\00"
@PERRY_SYMBOL_PROPERTY_IC_EPOCH = external global i64
@PERRY_GC_POLL_ARMED = external global i32
@PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD = external global [65536 x i8]
@PERRY_PER_OBJECT_LAYOUTS_ANY = external global i32
@PERRY_LAYOUT_ADDR_FILTER = external global [64 x i64]
@PERRY_YOUNG_LAYOUT_RECORDS = external global i32
@PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED = external global i8
@PERRY_ARRAY_PROTO_ITERATOR_PATCHED = external global i8
@PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT = external global i32
@PERRY_HOT_TSD_KEY = external global i64
@PERRY_TA_KIND_CACHE = external global [64 x i64]
@PERRY_U8_INLINE_CACHE = external global [64 x i64]
@PERRY_TA_VIEW_GUARD = external global i64
@perry_null_guard_zero_test_json_tape_batch_records_ts = internal global i32 0
@perry_ic_test_json_tape_batch_records_ts__0 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__2 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__4 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__7 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__9 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__10 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__12 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__13 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__14 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__16 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__18 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__20 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__22 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__23 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__25 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__26 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__28 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__30 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__32 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__34 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__36 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__38 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__40 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__41 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__41_poly_tail = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__42 = private global ptr null
@perry_ic_test_json_tape_batch_records_ts__44 = private global ptr null
@perry_concat_site_test_json_tape_batch_records_ts__1 = private global [32 x i64] zeroinitializer
@perry_concat_site_test_json_tape_batch_records_ts__17 = private global [32 x i64] zeroinitializer
@test_json_tape_batch_records_ts_.str.0.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.1.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.2.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.3.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.4.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.5.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.6.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.7.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.8.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.9.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.10.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.11.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.12.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.13.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.14.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.15.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.16.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.17.dispatch = private unnamed_addr constant { i32, i32, i64, ptr } { i32 4, i32 0, i64 7818252312440358301, ptr @test_json_tape_batch_records_ts_.str.17.bytes }
@test_json_tape_batch_records_ts_.str.17.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.18.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.19.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.20.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.21.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.22.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.23.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.24.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.25.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.26.dispatch = private unnamed_addr constant { i32, i32, i64, ptr } { i32 6, i32 0, i64 -4195180554649555617, ptr @test_json_tape_batch_records_ts_.str.26.bytes }
@test_json_tape_batch_records_ts_.str.26.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.27.handle = internal global double 0.000000e+00
@test_json_tape_batch_records_ts_.str.28.handle = internal global double 0.000000e+00

declare void @js_gc_init()

declare void @js_typed_feedback_maybe_dump_trace()

declare void @js_set_process_entry_path(ptr, i32)

declare void @js_stdlib_init_dispatch()

declare void @perry_app_group_init(ptr, i32)

declare void @perry_update_notify_startup(ptr, i32)

declare void @perry_macos_bundle_chdir()

declare i32 @perry_i18n_locale_index_for(i64, i32)

declare void @perry_i18n_init(ptr, ptr, i32, i32)

declare void @perry_i18n_set_currencies(ptr, i32)

declare i32 @perry_i18n_plural_category(i32, double)

declare void @js_register_function_name_static(ptr, ptr, i32)

declare void @js_register_function_name(ptr, ptr, i32)

declare void @js_register_function_source_static(ptr, ptr, i32, i32)

declare void @js_register_function_source(ptr, ptr, i32, i32)

declare void @js_console_log_dynamic(double)

declare void @js_console_log_number(double)

declare void @js_console_error_dynamic(double)

declare void @js_console_error_number(double)

declare void @js_console_warn_dynamic(double)

declare void @js_console_warn_number(double)

declare void @js_console_dir_with_options(double, double)

declare double @js_console_method_by_value(double)

declare double @js_nanbox_string(i64)

; Function Attrs: nounwind willreturn
declare double @js_nanbox_pointer(i64) #0

; Function Attrs: nounwind willreturn
declare i64 @js_nanbox_get_pointer(double) #0

declare double @js_native_handle_new_owned(i64, i64, i32, i32, ptr, ptr, i64)

declare double @js_native_handle_new_borrowed(i64, i64, i32, i32, ptr, i64)

declare i64 @js_native_handle_unwrap(double, i64, i32, i32, i32)

declare i64 @js_string_from_bytes(ptr, i32)

declare i64 @js_string_from_wtf8_bytes(ptr, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_is_truthy(double) #0

declare double @js_native_abi_check_f64(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_f64_arg_guard(double) #0

declare double @js_typed_f64_arg_to_raw(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_string_arg_guard(double) #0

declare i64 @js_typed_string_arg_to_raw(double)

declare i32 @js_param_type_guard(double, ptr, i32)

declare float @js_native_abi_check_f32(double)

declare i8 @js_native_abi_check_i8(double)

declare i16 @js_native_abi_check_i16(double)

declare i32 @js_native_abi_check_i32(double)

declare i64 @js_native_abi_check_i64(double)

declare i8 @js_native_abi_check_u8(double)

declare i16 @js_native_abi_check_u16(double)

declare i32 @js_native_abi_check_u32(double)

declare i64 @js_native_abi_check_u64(double)

declare i64 @js_native_abi_check_usize(double)

declare i64 @js_native_abi_check_isize(double)

declare double @js_native_abi_materialize_i64(i64)

declare double @js_native_abi_materialize_u64(i64)

declare i64 @js_native_abi_check_string_ptr(double)

declare i64 @js_native_abi_check_ptr(double)

declare ptr @js_native_abi_check_buffer_data_ptr(double)

declare i64 @js_native_abi_check_buffer_byte_len(double)

declare i64 @js_native_abi_check_promise(double)

declare i64 @js_native_abi_check_pod_object(double)

declare double @js_date_now()

declare void @js_gc_register_global_root(i64)

declare i64 @js_string_concat(i64, i64)

declare double @js_string_concat_box(double, double)

declare i64 @js_jsvalue_to_string(double)

declare i64 @js_jsvalue_to_string_method(double)

declare i64 @js_jsvalue_to_string_coerce(double)

declare i64 @js_string_concat_value(i64, double)

declare double @js_string_concat_site_value(i64, i64, double)

declare i64 @js_value_concat_string(double, i64)

declare double @js_string_concat_value_box(i64, double)

declare double @js_string_add_value(double, double)

declare double @js_value_add_string(double, double)

declare i64 @js_string_concat_chain(i64, i32)

declare i64 @js_string_append_chain(i64, i32)

declare i64 @js_string_append(i64, i64)

declare i64 @js_string_append_known_heap(i64, i64)

declare i32 @js_string_index_of(i64, i64)

declare i32 @js_string_index_of_from(i64, i64, i32)

declare i32 @js_string_position_to_index(double)

declare i64 @js_string_slice(i64, i32, i32)

declare i64 @js_string_substring(i64, i32, i32)

declare i64 @js_string_substr(i64, double, double)

declare i64 @js_string_split(i64, i64)

declare i64 @js_string_split_n(i64, i64, i32)

declare double @js_string_split_part_value(i64, i64, i32)

declare double @js_string_split_part_utf16_length(i64, i64, i32)

declare double @js_string_to_upper_case_split_part_utf16_length(i64, i64, i32)

declare i32 @js_string_to_upper_case_index_of(i64, i64)

declare i64 @js_string_split_value(i64, double, double)

declare double @js_math_trunc(double)

declare double @js_math_round(double)

declare double @js_math_sign(double)

declare double @js_math_imul(double, double)

declare double @js_math_pow(double, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.ceil.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.copysign.f64(double, double) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.aarch64.fjcvtzs(double) #3

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #5

declare i64 @js_json_stringify(double, i32)

declare i64 @js_map_alloc(i32)

declare i64 @js_text_encoder_encode_into_llvm(double, double)

declare i64 @js_value_typeof(double)

declare i32 @js_value_typeof_tag(double)

declare i32 @js_string_starts_with(i64, i64)

declare i32 @js_string_ends_with(i64, i64)

declare i64 @js_string_search_value_to_string(double, i32)

declare i32 @js_string_starts_with_at(i64, i64, i32)

declare i32 @js_string_ends_with_at(i64, i64, i32)

declare i64 @js_closure_alloc(ptr, i32)

declare i64 @js_closure_alloc_init(ptr, i32, ptr)

declare i64 @js_closure_alloc_singleton(ptr)

declare i64 @js_closure_alloc_with_captures_singleton(ptr, i32, ptr)

declare void @js_closure_set_capture_bits(i64, i32, i64)

declare void @js_closure_set_box_capture_ptr(i64, i32, i64)

declare i64 @js_closure_get_capture_bits(i64, i32)

declare void @js_closure_set_capture_f64(i64, i32, double)

declare double @js_closure_get_capture_f64(i64, i32)

declare void @js_register_closure_rest(ptr, i32)

declare void @js_register_closure_synthetic_arguments(ptr, i32)

declare void @js_register_closure_rest_and_arguments(ptr, i32)

declare void @js_register_closure_arity(ptr, i32)

declare void @js_register_closure_length(ptr, i32)

declare void @js_register_closure_arrow_function(ptr)

declare void @js_register_closure_trusted_direct(ptr, ptr, i32, i64)

declare void @js_register_closure_versioned_loop_direct(ptr, ptr, i32, i64)

declare ptr @js_closure_resolve_versioned_loop_direct_call(i64, i32)

declare void @js_register_closure_strict_function(ptr)

declare void @js_register_closure_async_function(ptr)

declare void @js_register_closure_generator_function(ptr)

declare void @js_register_closure_async_generator_function(ptr)

declare i64 @js_closure_unbox_callee_checked(double)

declare i64 @js_closure_unbox_callee_checked_rebind(double, double)

declare double @js_closure_call0(i64)

declare double @js_closure_call1(i64, double)

declare double @js_closure_call1_receiverless(i64, double)

declare double @js_closure_call2(i64, double, double)

declare double @js_closure_call3(i64, double, double, double)

declare ptr @js_closure_resolve_arrow_direct_call(i64, i32)

declare double @js_closure_call4(i64, double, double, double, double)

declare double @js_closure_call5(i64, double, double, double, double, double)

declare double @js_closure_call6(i64, double, double, double, double, double, double)

declare double @js_closure_call7(i64, double, double, double, double, double, double, double)

declare double @js_closure_call8(i64, double, double, double, double, double, double, double, double)

declare double @js_closure_call9(i64, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call10(i64, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call11(i64, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call12(i64, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call13(i64, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call14(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call15(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call16(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare i64 @js_array_map(i64, i64)

declare void @js_array_map_discard(i64, i64)

declare i64 @js_array_filter(i64, i64)

declare i64 @js_array_concat(i64, i64)

declare i64 @js_array_concat_new(i64, i64)

declare i64 @js_error_new()

declare i64 @js_error_new_with_message(i64)

declare i64 @js_error_new_from_value(double)

declare i64 @js_error_new_kind_from_value(i32, double)

declare i64 @js_error_new_with_cause_from_value(double, double)

declare i64 @js_error_new_kind_with_options_from_value(i32, double, double)

declare double @js_assert_assertion_error_ctor(double)

declare double @js_assert_assert_ctor(double)

declare void @js_throw_type_error_property_access(i32, ptr, i64)

declare void @js_throw_type_error_not_a_function(ptr, i64, ptr, i64)

declare void @js_throw_error_with_code(ptr, i64, ptr, i64, i32)

declare i64 @js_map_set(i64, double, double)

declare i64 @js_map_set_string_number(i64, i64, double)

declare i64 @js_map_set_string_key(i64, i64, double)

declare i64 @js_map_set_string_i32(i64, i64, i32)

declare i64 @js_map_set_string_u32(i64, i64, i32)

declare i64 @js_map_set_string_f32(i64, i64, float)

declare i64 @js_map_set_string_bool(i64, i64, i32)

declare i64 @js_map_set_string_string(i64, i64, i64)

declare i64 @js_map_set_number_key(i64, double, double)

declare double @js_map_get(i64, double)

declare double @js_declared_map_get(double, double)

declare double @js_map_get_string_key(i64, i64)

declare double @js_map_get_number_key(i64, double)

declare i32 @js_map_has(i64, double)

declare i32 @js_map_has_string_key(i64, i64)

declare i32 @js_map_has_number_key(i64, double)

declare i32 @js_map_delete(i64, double)

declare i32 @js_map_delete_string_key(i64, i64)

declare i32 @js_map_delete_number_key(i64, double)

declare i64 @js_object_keys(i64)

declare i64 @js_object_keys_value(double)

declare i64 @js_for_in_keys_value(double)

declare i64 @js_for_in_keys_stable_value(double)

declare double @js_is_finite(double)

declare i32 @js_is_undefined_or_bare_nan(double)

declare double @js_math_min_array(i64)

declare double @js_math_max_array(i64)

declare double @js_math_min2(double, double)

declare double @js_math_max2(double, double)

declare i64 @js_string_coerce(double)

declare i64 @js_string_coerce_method_this(double, ptr, i64)

declare i64 @js_array_slice(i64, i32, i32)

declare i64 @js_array_slice_values(i64, double, double)

declare double @js_array_shift_f64(i64)

declare i64 @js_set_alloc(i32)

declare i64 @js_set_from_array(i64)

declare i64 @js_set_from_iterable(double)

declare i64 @js_map_from_array(i64)

declare i64 @js_map_from_iterable(double)

declare double @js_object_has_property(double, double)

declare double @js_in_operator(double, double)

declare double @js_private_brand_check(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_guard(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_brand_add(double, i32)

declare double @js_private_field_add(double, i32, double, double)

declare double @js_class_field_add(double, double, double)

declare double @js_class_computed_field_key(double, i32, ptr, i64)

declare double @js_fs_to_unix_timestamp(double)

declare i32 @js_fs_write_file_sync(double, double)

declare i32 @js_fs_write_file_sync_options(double, double, double)

declare i32 @js_fs_append_file_sync(double, double)

declare i32 @js_fs_append_file_sync_options(double, double, double)

declare i32 @js_fs_exists_sync(double)

declare i64 @js_fs_read_file_sync(double)

declare double @js_fs_read_file_dispatch(double, double)

declare double @js_fs_open_as_blob(double, double)

declare double @js_fs_promises_read_file(double, double)

declare double @js_fs_promises_write_file(double, double, double)

declare double @js_fs_promises_append_file(double, double, double)

declare double @js_fs_promises_mkdir(double, double)

declare double @js_fs_promises_rmdir(double, double)

declare i32 @js_fs_mkdir_sync(double)

declare i32 @js_fs_mkdir_sync_options(double, double)

declare i32 @js_fs_unlink_sync(double)

declare double @js_fs_readdir_sync(double, double)

declare double @js_fs_stat_sync(double)

declare double @js_fs_stat_sync_options(double, double)

declare double @js_fs_lstat_sync(double)

declare double @js_fs_lstat_sync_options(double, double)

declare i32 @js_fs_rename_sync(double, double)

declare i32 @js_fs_copy_file_sync(double, double)

declare i32 @js_fs_copy_file_sync_flags(double, double, double)

declare i32 @js_fs_cp_sync(double, double)

declare i32 @js_fs_cp_sync_options(double, double, double)

declare i32 @js_fs_chmod_sync(double, double)

declare i32 @js_fs_chown_sync(double, double, double)

declare i32 @js_fs_lchown_sync(double, double, double)

declare i32 @js_fs_lchmod_sync(double, double)

declare i32 @js_fs_truncate_sync(double, double)

declare i32 @js_fs_ftruncate_sync(double, double)

declare i32 @js_fs_fsync_sync(double)

declare i32 @js_fs_fdatasync_sync(double)

declare i32 @js_fs_fchmod_sync(double, double)

declare i32 @js_fs_fchown_sync(double, double, double)

declare double @js_fs_fstat_sync(double)

declare double @js_fs_fstat_sync_options(double, double)

declare i32 @js_fs_utimes_sync(double, double, double)

declare i32 @js_fs_lutimes_sync(double, double, double)

declare i32 @js_fs_futimes_sync(double, double, double)

declare double @js_fs_readv_sync(double, double, double)

declare double @js_fs_writev_sync(double, double, double)

declare double @js_fs_statfs_sync(double)

declare double @js_fs_statfs_sync_options(double, double)

declare double @js_fs_opendir_sync(double)

declare double @js_fs_glob_sync(double)

declare double @js_fs_glob_sync_options(double, double)

declare i32 @js_fs_link_sync(double, double)

declare i32 @js_fs_symlink_sync(double, double)

declare double @js_fs_symlink_callback(double, double, double, double)

declare i64 @js_fs_readlink_sync(double)

declare i64 @js_fs_readlink_sync_options(double, double)

declare double @js_fs_readlink_dispatch(double, double)

declare double @js_fs_open_sync(double, double)

declare i32 @js_fs_close_sync(double)

declare double @js_fs_read_sync(double, double, double, double, double)

declare double @js_fs_read_sync_options(double, double, double)

declare double @js_fs_write_sync(double, double)

declare double @js_fs_write_string_sync_options(double, double, double)

declare double @js_fs_write_buffer_sync(double, double, double, double, double)

declare double @js_fs_write_sync_options_dispatch(double, double, double)

declare i32 @js_fs_access_sync(double)

declare i32 @js_fs_access_sync_mode(double, double)

declare double @js_fs_access_sync_throw(double)

declare double @js_fs_access_sync_throw_mode(double, double)

declare i64 @js_fs_realpath_sync(double)

declare double @js_fs_realpath_dispatch(double, double)

declare i64 @js_fs_mkdtemp_sync(double)

declare i64 @js_fs_mkdtemp_sync_options(double, double)

declare double @js_fs_mkdtemp_dispatch(double, double)

declare double @js_fs_mkdtemp_disposable_sync(double, double)

declare i32 @js_fs_rmdir_sync(double)

declare i32 @js_fs_rmdir_sync_options(double, double)

declare i32 @js_fs_rm_recursive(double)

declare i32 @js_fs_rm_recursive_options(double, double)

declare double @js_fs_create_write_stream(double, double)

declare double @js_fs_create_read_stream(double, double)

declare double @js_fs_utf8_stream_new(double)

declare double @js_fs_utf8_stream_call_without_new(double)

declare double @js_fs_utf8_stream_write(double, double)

declare double @js_fs_utf8_stream_flush(double, double)

declare double @js_fs_utf8_stream_flush_sync(double)

declare double @js_fs_utf8_stream_end(double, double)

declare double @js_fs_utf8_stream_destroy(double)

declare double @js_fs_utf8_stream_reopen(double, double)

declare double @js_fs_utf8_stream_on(double, double, double)

declare double @js_fs_utf8_stream_once(double, double, double)

declare double @js_fs_utf8_stream_off(double, double, double)

declare double @js_fs_utf8_stream_remove_all(double, double)

declare double @js_fs_utf8_stream_listener_count(double, double)

declare double @js_fs_utf8_stream_emit(double, double, double)

declare double @js_fs_read_file_callback(double, double, double)

declare double @js_fs_stats_is_file(double)

declare double @js_fs_stats_is_directory(double)

declare i64 @js_fs_read_file_binary(double)

declare double @js_number_coerce(double)

declare double @js_math_to_number(double)

declare i64 @js_set_add(i64, double)

declare i64 @js_set_add_string(i64, i64)

declare i64 @js_set_add_number(i64, double)

declare i64 @js_set_add_i32(i64, i32)

declare i64 @js_set_add_u32(i64, i32)

declare i64 @js_set_add_f32(i64, float)

declare i64 @js_set_add_bool(i64, i32)

declare i32 @js_set_has(i64, double)

declare double @js_readonly_set_has(double, double)

declare i32 @js_set_has_string(i64, i64)

declare i32 @js_set_has_number(i64, double)

declare i32 @js_set_has_i32(i64, i32)

declare i32 @js_set_has_u32(i64, i32)

declare i32 @js_set_has_f32(i64, float)

declare i32 @js_set_has_bool(i64, i32)

declare i32 @js_set_delete(i64, double)

declare i32 @js_set_delete_string(i64, i64)

declare i32 @js_set_delete_number(i64, double)

declare i32 @js_set_delete_i32(i64, i32)

declare i32 @js_set_delete_u32(i64, i32)

declare i32 @js_set_delete_f32(i64, float)

declare i32 @js_set_delete_bool(i64, i32)

declare i32 @js_set_size(i64)

declare i64 @js_set_union(i64, double)

declare i64 @js_set_intersection(i64, double)

declare i64 @js_set_difference(i64, double)

declare i64 @js_set_symmetric_difference(i64, double)

declare i32 @js_set_is_subset_of(i64, double)

declare i32 @js_set_is_superset_of(i64, double)

declare i32 @js_set_is_disjoint_from(i64, double)

declare i64 @js_string_to_lower_case(i64)

declare i64 @js_string_to_upper_case(i64)

declare i64 @js_string_to_locale_lower_case(i64, double)

declare i64 @js_string_to_locale_upper_case(i64, double)

declare void @js_string_validate_collator_args(double, double)

declare i64 @js_string_trim(i64)

declare i64 @js_string_trim_start(i64)

declare i64 @js_string_trim_end(i64)

declare i64 @js_string_big(i64)

declare i64 @js_string_blink(i64)

declare i64 @js_string_bold(i64)

declare i64 @js_string_fixed(i64)

declare i64 @js_string_italics(i64)

declare i64 @js_string_small(i64)

declare i64 @js_string_strike(i64)

declare i64 @js_string_sub(i64)

declare i64 @js_string_sup(i64)

declare i64 @js_string_anchor(i64, i64)

declare i64 @js_string_link(i64, i64)

declare i64 @js_string_fontcolor(i64, i64)

declare i64 @js_string_fontsize(i64, i64)

declare i64 @js_string_char_at(i64, i32)

declare double @js_string_index_get(i64, double)

declare double @js_string_index_get_boxed(double, double)

declare i32 @js_string_index_to_i32(double)

declare i32 @js_string_end_index_to_i32(double, i32)

declare double @js_typed_feedback_object_get_field_by_value_f64(i64, i64, double)

declare double @js_dyn_index_get(double, double)

declare double @js_packed_arraylike_index_get(double, double, ptr)

declare i32 @js_packed_arraylike_loop_guard(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_guard_live(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_revalidate_live(double, double, i32, ptr)

declare double @js_dyn_index_set(double, double, double)

declare double @js_dyn_index_set_strict(double, double, double, i32)

declare i64 @js_string_to_char_array(i64)

declare i64 @js_string_repeat(i64, double)

declare i64 @js_string_replace_string(i64, i64, i64)

declare i64 @js_string_replace_all_string(i64, i64, i64)

declare i32 @js_string_equals(i64, i64)

declare i32 @js_string_compare(i64, i64)

declare i32 @js_jsvalue_equals(double, double)

declare i32 @js_string_compare_value(double, double)

declare i64 @js_jsvalue_to_string_radix(double, double)

declare double @js_math_random()

declare double @js_webassembly_validate(double)

declare double @js_webassembly_compile(double)

declare double @js_webassembly_module_new(double)

declare double @js_webassembly_module_exports(double)

declare double @js_webassembly_module_imports(double)

declare double @js_webassembly_module_custom_sections(double, double)

declare double @js_webassembly_instantiate(double, double)

declare double @js_wasi_emit_warning()

declare double @js_webassembly_call_export_0(double, double)

declare double @js_webassembly_call_export_1(double, double, double)

declare double @js_webassembly_call_export_2(double, double, double, double)

declare double @js_webassembly_call_export_3(double, double, double, double, double)

declare double @js_webassembly_call_export_4(double, double, double, double, double, double)

declare void @js_console_log_spread(i64)

declare void @js_console_info_spread(i64)

declare void @js_console_debug_spread(i64)

declare void @js_console_error_spread(i64)

declare void @js_console_warn_spread(i64)

declare double @js_util_format(i64)

declare double @js_util_format_with_options(double, i64)

declare double @js_util_inspect(double, double)

declare double @js_util_debuglog(double, double)

declare double @js_util_diff(double, double)

declare double @js_util_inherits(double, double)

declare double @js_util_is_deep_strict_equal(double, double)

declare double @js_util_strip_vt_control_characters(double)

declare double @js_util_style_text(double, double, double)

declare double @js_util_get_call_sites(double, double)

declare double @js_util_promisify(double)

declare double @js_util_callbackify(double)

declare double @js_util_deprecate(double, double, double)

declare double @js_util_aborted(double, double)

declare double @js_util_transferable_abort_controller()

declare double @js_util_transferable_abort_signal(double)

declare double @js_util_parse_args(double)

declare double @js_boxed_number_new(double)

declare double @js_boxed_string_new(double, i32)

declare double @js_boxed_boolean_new(double)

declare double @js_util_types_is_arguments_object(double)

declare double @js_util_types_is_promise(double)

declare double @js_util_types_is_big_int_object(double)

declare double @js_util_types_is_symbol_object(double)

declare double @js_util_types_is_array_buffer(double)

declare double @js_util_types_is_shared_array_buffer(double)

declare double @js_util_types_is_any_array_buffer(double)

declare double @js_util_types_is_array_buffer_view(double)

declare double @js_util_types_is_data_view(double)

declare double @js_util_types_is_typed_array(double)

declare double @js_util_types_is_uint8_array(double)

declare double @js_util_types_is_int8_array(double)

declare double @js_util_types_is_int16_array(double)

declare double @js_util_types_is_uint16_array(double)

declare double @js_util_types_is_int32_array(double)

declare double @js_util_types_is_uint32_array(double)

declare double @js_util_types_is_float16_array(double)

declare double @js_util_types_is_float32_array(double)

declare double @js_util_types_is_float64_array(double)

declare double @js_util_types_is_uint8_clamped_array(double)

declare double @js_util_types_is_big_int64_array(double)

declare double @js_util_types_is_big_uint64_array(double)

declare double @js_util_types_is_map(double)

declare double @js_util_types_is_weak_map(double)

declare double @js_util_types_is_set(double)

declare double @js_util_types_is_weak_set(double)

declare double @js_util_types_is_date(double)

declare double @js_util_types_is_reg_exp(double)

declare double @js_util_types_is_async_function(double)

declare double @js_util_types_is_generator_function(double)

declare double @js_util_types_is_generator_object(double)

declare double @js_util_types_is_native_error(double)

declare double @js_util_types_is_number_object(double)

declare double @js_util_types_is_string_object(double)

declare double @js_util_types_is_boolean_object(double)

declare double @js_util_types_is_boxed_primitive(double)

declare double @js_util_types_is_external(double)

declare double @js_util_types_is_module_namespace_object(double)

declare double @js_util_types_is_key_object(double)

declare double @js_util_types_is_crypto_key(double)

declare double @js_util_types_is_proxy(double)

declare double @js_util_types_is_map_iterator(double)

declare double @js_util_types_is_set_iterator(double)

declare double @js_data_view_new(double, double, double)

declare double @js_data_view_get_direct(double, double, double, i32, i32)

declare double @js_data_view_set_direct(double, double, double, double, i32, i32)

declare i64 @js_getenv(i64)

declare double @js_getenv_value(i64)

declare void @js_setenv(i64, double)

declare void @js_removeenv(i64)

declare double @js_process_exit_code_get()

declare double @js_process_exit_code_set(double)

declare void @js_console_table(double)

declare void @js_console_table_with_properties(double, double)

declare void @js_console_trace(double)

declare void @js_console_trace_spread(i64)

declare i64 @js_process_cwd()

declare i64 @js_process_argv()

declare double @js_process_pid()

declare double @js_process_ppid()

declare double @js_process_uptime()

declare i64 @js_process_version()

declare double @js_process_versions()

declare double @js_process_memory_usage()

declare double @js_bigint_as_int_n_call(double, double)

declare double @js_bigint_as_uint_n_call(double, double)

declare double @js_v8_serialize(double)

declare double @js_v8_deserialize(double)

declare double @js_v8_get_heap_statistics()

declare double @js_v8_get_heap_code_statistics()

declare double @js_v8_get_heap_space_statistics()

declare double @js_v8_cached_data_version_tag()

declare double @js_v8_get_heap_snapshot(double)

declare double @js_v8_write_heap_snapshot(double, double)

declare double @js_v8_gc_profiler_new()

declare double @js_v8_gc_profiler_start(double)

declare double @js_v8_gc_profiler_stop(double)

declare double @js_v8_gc_profiler_report()

declare double @js_v8_serializer_new(double)

declare double @js_v8_deserializer_new(double)

declare double @js_v8_noop_undefined()

declare double @js_v8_is_building_snapshot()

declare double @js_v8_namespace(ptr, i64)

declare double @js_v8_throw_not_building_snapshot()

declare double @js_v8_promise_hook_register()

declare double @js_v8_promise_hooks_on_init(double)

declare double @js_v8_promise_hooks_on_before(double)

declare double @js_v8_promise_hooks_on_after(double)

declare double @js_v8_promise_hooks_on_settled(double)

declare double @js_v8_promise_hooks_create_hook(double)

declare double @js_process_thread_cpu_usage(double)

declare double @js_process_available_memory()

declare double @js_process_constrained_memory()

declare double @js_process_source_maps_enabled()

declare double @js_process_set_source_maps_enabled(double)

declare double @js_process_has_uncaught_exception_capture_callback()

declare double @js_process_set_uncaught_exception_capture_callback(double)

declare double @js_process_add_uncaught_exception_capture_callback(double)

declare double @js_process_getuid()

declare double @js_process_geteuid()

declare double @js_process_getgid()

declare double @js_process_getegid()

declare void @js_process_emit_warning(double, double, double)

declare double @js_process_cpu_usage(double)

declare double @js_process_resource_usage()

declare double @js_process_active_resources_info()

declare double @js_process_env()

declare double @js_process_hrtime_bigint()

declare double @js_process_hrtime(double)

declare double @js_process_title()

declare void @js_process_set_title(double)

declare void @js_process_chdir(i64)

declare void @js_process_chdir_jsv(double)

declare double @js_process_kill(double, double)

declare void @js_process_exit(double)

declare void @js_process_abort()

declare double @js_process_umask()

declare double @js_process_umask_set(double)

declare double @js_process_on(i64, i64)

declare double @js_process_add_listener(i64, i64)

declare double @js_process_once(i64, i64)

declare double @js_process_prepend_listener(i64, i64)

declare double @js_process_prepend_once_listener(i64, i64)

declare double @js_process_emit(i64, i64)

declare void @js_process_emit_before_exit(double)

declare void @js_process_emit_before_exit_pending()

declare void @js_process_run_exit_sequence()

declare void @js_process_run_finalization_exit()

declare void @js_trace_events_flush_output()

declare void @js_promise_report_unhandled_rejections()

declare i32 @js_process_pending_exit_code()

declare void @js_gc_release_current_thread_collection_side_allocations()

declare double @js_process_remove_listener(i64, i64)

declare double @js_process_off(i64, i64)

declare double @js_process_remove_all_listeners(i64)

declare double @js_process_listener_count(i64, i64)

declare i64 @js_process_listeners(i64)

declare i64 @js_process_raw_listeners(i64)

declare i64 @js_process_event_names()

declare double @js_process_set_max_listeners(double)

declare double @js_process_get_max_listeners()

declare double @js_process_get_builtin_module(double)

declare double @js_process_get_builtin_module_devirt(double)

declare double @js_process_execve(double, double, double)

declare double @js_module_is_builtin(double)

declare double @js_module_find_package_json(double, double, double)

declare double @js_module_find_source_map(double)

declare double @js_module_source_map_new(double, double)

declare double @js_module_register(double, double, double)

declare double @js_module_register_hooks(double)

declare void @js_process_next_tick(i64, i64)

declare double @js_process_stdin()

declare double @js_process_stdout()

declare double @js_process_stderr()

declare double @js_readline_set_raw_mode(double)

declare void @js_readline_stdin_on(i64, i64)

declare double @js_readline_stdin_remove_listener(i64, i64)

declare double @js_readline_stdin_pause()

declare double @js_readline_stdin_resume()

declare double @js_readline_stdin_unref()

declare double @js_readline_stdin_ref()

declare double @js_readline_stdin_destroy()

declare double @js_tty_isatty(double)

declare double @js_tty_read_stream_new(double)

declare double @js_tty_write_stream_new(double)

declare double @js_wasi_constructor_call(double)

declare double @js_process_stdin_isatty()

declare double @js_process_stdout_isatty()

declare double @js_process_stderr_isatty()

declare double @js_process_stdout_columns()

declare double @js_process_stdout_rows()

declare double @js_process_stdout_on(i64, i64)

declare i64 @js_os_platform()

declare i64 @js_os_arch()

declare i64 @js_os_type()

declare i64 @js_os_release()

declare i64 @js_os_hostname()

declare i64 @js_os_eol()

declare double @js_os_available_parallelism()

declare i64 @js_os_endianness()

declare i64 @js_os_dev_null()

declare i64 @js_os_machine()

declare i64 @js_os_loadavg()

declare i64 @js_os_version()

declare i64 @js_box_alloc_bits(i64)

declare i64 @js_box_get_bits(i64)

declare i64 @js_box_get_bits_named(i64, double)

declare void @js_box_set_bits(i64, i64)

declare i64 @js_box_get_bits_trusted(i64)

declare i64 @js_box_get_bits_trusted_named(i64, double)

declare void @js_box_set_bits_trusted_no_barrier(i64, i64)

declare i64 @js_box_alloc(double)

declare double @js_box_get(i64)

declare void @js_box_set(i64, double)

declare i64 @js_i32_box_alloc(i32)

declare i32 @js_i32_box_get(i64)

declare void @js_i32_box_set(i64, i32)

declare void @js_box_release(i64)

declare void @js_i32_box_release(i64)

declare void @js_bool_box_release(i64)

declare i64 @js_bool_box_alloc(i32)

declare i32 @js_bool_box_get(i64)

declare void @js_bool_box_set(i64, i32)

declare i64 @js_arguments_object_alloc(double, double, i32)

declare void @js_arguments_object_map_index(i64, i32, i64)

declare i64 @js_array_like_to_array(double)

declare i32 @js_object_get_class_id(i64)

declare i64 @js_object_alloc_with_parent(i32, i32, i32)

declare i64 @js_object_alloc_class_with_keys(i32, i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_dynamic_parent(i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_inline_keys(i32, i32, i32, i64)

declare i64 @js_object_alloc_class_inline_keys_stamped(i32, i32, i32, i64, i32)

declare i64 @js_build_class_keys_array(i32, i32, ptr, i32)

declare i32 @js_object_shape_id_for_keys(i64, i32)

declare i32 @js_gc_typed_shape_id_for_keys(i32, i64, i32, ptr, i32, ptr, i32)

declare ptr @js_inline_arena_state()

declare ptr @js_inline_arena_slow_alloc(ptr, i64, i64)

declare i32 @js_object_delete_field(i64, i64)

declare i32 @js_object_delete_field_value(double, i64)

declare i32 @js_object_delete_dynamic_value(double, double)

declare double @js_delete_result(i32, i32)

declare i64 @js_eq(i64, i64)

declare i64 @js_loose_eq(i64, i64)

declare i64 @js_number_to_fixed(double, double)

declare i64 @js_string_replace_regex(i64, i64, i64)

declare i64 @js_string_replace_all_regex(i64, i64, i64)

declare double @js_array_at(i64, double)

declare double @js_date_get_time(double)

declare double @js_date_get_full_year(double)

declare double @js_date_get_month(double)

declare double @js_date_get_date(double)

declare double @js_date_get_day(double)

declare double @js_date_get_hours(double)

declare double @js_date_get_minutes(double)

declare double @js_date_get_seconds(double)

declare double @js_date_get_milliseconds(double)

declare double @js_date_get_utc_day(double)

declare double @js_date_get_utc_full_year(double)

declare double @js_date_get_utc_month(double)

declare double @js_date_get_utc_date(double)

declare double @js_date_get_utc_hours(double)

declare double @js_date_get_utc_minutes(double)

declare double @js_date_get_utc_seconds(double)

declare double @js_date_get_utc_milliseconds(double)

declare double @js_date_value_of(double)

declare double @js_date_get_timezone_offset(double)

declare double @js_date_coerce_number(double)

declare double @js_rel_lt(double, double)

declare double @js_rel_le(double, double)

declare double @js_rel_gt(double, double)

declare double @js_rel_ge(double, double)

declare i64 @js_date_to_string(double)

declare i64 @js_date_to_iso_string(double)

declare i64 @js_date_to_iso_string_or_throw(double)

declare double @js_date_new_from_timestamp(double)

declare double @js_date_new_from_value(double)

declare i32 @js_array_indexOf_f64(i64, double)

declare i64 @js_array_indexOf_jsvalue(i64, double, double, i32)

declare i64 @js_array_last_index_of_jsvalue(i64, double, double, i32)

declare i32 @js_array_includes_f64(i64, double)

declare i32 @js_array_includes_jsvalue(i64, double, double, i32)

declare i32 @js_map_size(i64)

declare void @js_map_clear(i64)

declare void @js_set_clear(i64)

declare i64 @js_map_entries(i64)

declare i64 @js_map_keys(i64)

declare i64 @js_map_values(i64)

declare double @js_map_entry_key_at(i64, i32)

declare double @js_map_entry_value_at(i64, i32)

declare double @js_map_entry_key_raw_at(i64, i32)

declare double @js_map_entry_value_raw_at(i64, i32)

declare double @js_set_value_raw_at(i64, i32)

declare double @js_map_find_key_index(double, double)

declare double @js_set_find_value_index(double, double)

declare double @js_map_cursor_next(double, double, double)

declare double @js_map_compaction_epoch(double)

declare double @js_set_cursor_next(double, double, double)

declare double @js_set_compaction_epoch(double)

declare void @js_map_foreach(i64, double, double)

declare void @js_set_foreach(i64, double, double)

declare i64 @js_map_entries_iter_obj(i64)

declare i64 @js_map_keys_iter_obj(i64)

declare i64 @js_map_values_iter_obj(i64)

declare i64 @js_set_values_iter_obj(i64)

declare i64 @js_set_keys_iter_obj(i64)

declare i64 @js_set_entries_iter_obj(i64)

declare i64 @js_set_to_array(i64)

declare double @js_set_value_at(i64, i32)

declare i64 @js_array_splice(i64, i32, i32, ptr, i32, ptr)

declare i32 @js_array_splice_delete_count(double)

declare double @js_parse_int(i64, double)

declare double @js_parse_float(i64)

declare double @js_array_reduce(i64, i64, i32, double)

declare double @js_array_reduce_right(i64, i64, i32, double)

declare i64 @js_array_sort_default(i64)

declare i64 @js_array_reverse(i64)

declare double @js_array_reverse_value(double)

declare i64 @js_array_flat(i64)

declare i64 @js_array_flat_depth(i64, double)

declare i64 @js_array_flatMap(i64, i64)

declare i64 @js_array_sort_with_comparator(i64, i64)

declare i64 @js_validate_array_comparator(double)

declare i64 @js_validate_array_callback(double)

declare i64 @js_validate_array_map_callback(i64, double)

declare i64 @js_array_to_reversed(i64)

declare i64 @js_array_to_sorted_default(i64)

declare i64 @js_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_array_to_spliced(i64, double, double, ptr, i32)

declare i64 @js_array_with(i64, double, double)

declare i64 @js_array_copy_within(i64, double, double, i32, double)

declare double @js_array_copy_within_value(double, double, double, i32, double)

declare i64 @js_regexp_new(i64, i64)

declare i64 @js_regexp_new_site(i64, i64, i64)

declare i64 @js_regexp_new_factory_site(i64, i64, i64, i64)

declare i64 @js_regexp_site_test_new(i64, i64, i64)

declare double @js_regexp_site_factory_call_value(i64, double)

declare double @js_regexp_site_factory_call_method(i64, double, double)

declare double @js_regexp_site_test_get_method(i64, double)

declare double @js_regexp_site_test_dispatch(i64, double, double, double)

declare i64 @js_regexp_construct(double, double)

declare i64 @js_regexp_construct_call(double, double)

declare i32 @js_regexp_test(i64, i64)

declare double @js_regexp_escape(double)

declare i64 @js_get_string_pointer_unified(double)

declare i32 @js_switch_strict_equals(double, double)

declare i64 @js_value_to_str_ptr_for_ffi(double)

declare void @js_string_addref(i64)

declare void @js_string_addref_if_heap_string(double)

declare i64 @js_bigint_from_string(ptr, i32)

declare i64 @js_bigint_from_f64(double)

declare i64 @js_bigint_from_i128_parts(i64, i64)

declare i32 @js_bigint_cmp(i64, i64)

declare double @js_dynamic_add(double, double)

declare double @js_to_numeric(double)

declare double @js_numeric_step(double, i32)

declare i64 @js_box_capture_cell_ptr(i64)

declare double @js_dynamic_string_or_number_add(double, double)

declare double @js_dynamic_sub(double, double)

declare double @js_dynamic_mul(double, double)

declare double @js_dynamic_div(double, double)

declare double @js_dynamic_mod(double, double)

declare double @js_dynamic_bitand(double, double)

declare double @js_dynamic_bitor(double, double)

declare double @js_dynamic_bitxor(double, double)

declare double @js_dynamic_shl(double, double)

declare double @js_dynamic_shr(double, double)

declare double @js_dynamic_bitnot(double)

declare double @js_dynamic_pow(double, double)

declare double @js_dynamic_ushr(double, double)

declare double @js_instanceof(double, i32)

declare double @js_instanceof_dynamic(double, double)

declare double @js_instanceof_noncallable_rhs()

declare void @js_register_class_extends_error(i32)

declare void @js_register_class_extends_data_view(i32)

declare void @js_register_class_extends_typed_array(i32)

declare void @js_register_class_id(i32)

declare void @js_register_class_name(i32, ptr, i32)

declare void @js_register_class_source(i32, ptr, i32)

declare void @js_register_class_length(i32, i32)

declare void @js_register_anon_shape_class_id(i32)

declare double @js_get_global_this_builtin_value(ptr, i64)

declare double @js_promise_static_function_value(ptr, i64)

declare double @js_builtin_prototype_method_value(ptr, i64, ptr, i64)

declare void @js_register_class_parent(i32, i32)

declare void @js_register_class_generic_origin(i32, i32)

declare void @js_register_class_parent_dynamic(i32, double)

declare double @js_get_dynamic_parent_value(i32)

declare void @js_class_register_capture_values(i32, ptr, i64)

declare void @js_class_object_refresh_capture_values(double, i64, double)

declare void @js_tdz_suppress_begin()

declare void @js_tdz_suppress_end()

declare double @js_class_capture_value(i32, i32)

declare double @js_class_capture_value_for_receiver(double, i32, i32)

declare double @js_class_capture_value_or(i32, i32, double)

declare double @js_param_or_class_capture_value(double, i32, i32)

declare void @js_super_construct_apply(i32, double, double)

declare double @js_super_method_call_dynamic(i32, ptr, i64, double, ptr, i64)

declare double @js_super_method_call_dynamic_apply(i32, ptr, i64, double, double)

declare i64 @js_array_push_spread_any(i64, double)

declare i32 @js_set_function_prototype(double, double)

declare double @js_set_prototype_property(double, double, i32)

declare void @js_register_prototype_method(i32, ptr, i64, double)

declare i32 @js_register_function_prototype_method(double, ptr, i64, double)

declare double @js_new_function_construct(double, ptr, i64)

declare double @js_function_ctor_from_strings(ptr, i64)

declare double @js_new_function_construct_apply(double, double)

declare double @js_throw_not_a_constructor()

declare double @js_new_target_value()

declare double @js_get_function_prototype_method(double, ptr, i64)

declare double @js_function_prototype_value_for_read(double)

declare i64 @js_typeerror_new(i64)

declare i64 @js_rangeerror_new(i64)

declare i64 @js_syntaxerror_new(i64)

declare i64 @js_referenceerror_new(i64)

declare double @js_throw_symbol_constructor_type_error()

declare double @js_throw_bigint_constructor_type_error()

declare double @js_throw_strict_eval_arguments_syntax_error()

declare double @js_throw_eval_syntax_error(double)

declare double @js_throw_restricted_function_property_assignment()

declare double @js_throw_math_constructor_type_error()

declare double @js_throw_json_constructor_type_error()

declare double @js_webcrypto_illegal_constructor()

declare double @js_throw_type_error_const_assignment(double)

declare double @js_throw_reference_error_unresolvable_assignment(double)

declare double @js_throw_reference_error_unresolved_get()

declare double @js_with_implicit_unset()

declare double @js_with_implicit_read(double, double)

declare double @js_iterator_result_validate(double)

declare double @js_for_of_next(double)

declare double @js_segments_view_open(double, double)

declare double @js_segments_view_next(double)

declare double @js_segments_view_code_point_at(double, double)

declare double @js_segments_view_segment(double)

declare double @js_segments_view_regexp_test(double, double)

declare double @js_global_get_or_throw_unresolved(double)

declare double @js_module_ambient_require()

declare double @js_module_ambient_require_apply(double)

declare double @js_module_dynamic_import_fallback(double)

declare double @js_module_dynamic_import_deferred(double, double)

declare double @js_module_create_require_devirt(double)

declare double @js_global_get_optional(double)

declare double @js_global_update(double, double, double)

declare double @js_global_assign_existing_or_throw(double, double)

declare double @js_throw_reference_error_this_before_super()

declare double @js_throw_reference_error_super_delete()

declare double @js_throw_reference_error_unresolved_assignment()

declare i64 @js_evalerror_new(i64)

declare i64 @js_urierror_new(i64)

declare i64 @js_weakmap_new()

declare i64 @js_weakset_new()

declare double @js_weakmap_init_iterable(double, double)

declare double @js_weakset_init_iterable(double, double)

declare double @js_weakmap_set(double, double, double)

declare double @js_weakmap_get(double, double)

declare double @js_weakmap_has(double, double)

declare double @js_weakmap_delete(double, double)

declare double @js_weakset_add(double, double)

declare double @js_weakset_has(double, double)

declare double @js_weakset_delete(double, double)

declare double @js_weak_throw_primitive()

declare i64 @js_buffer_from_string(i64, i32)

declare i32 @js_encoding_tag_from_value(double)

declare i64 @js_value_to_string_with_encoding(double, i32)

declare i64 @js_value_to_string_with_encoding_or_radix(double, i32, double)

declare i64 @js_object_values(i64)

declare i64 @js_object_values_value(double)

declare i64 @js_object_entries(i64)

declare i64 @js_object_entries_value(double)

declare i64 @js_path_join(i64, i64)

declare i64 @js_path_win32_join(i64, i64)

declare i64 @js_path_win32_dirname(i64)

declare i64 @js_path_win32_basename(i64)

declare i64 @js_path_win32_basename_ext(i64, i64)

declare i64 @js_path_win32_extname(i64)

declare i32 @js_path_win32_is_absolute(i64)

declare i64 @js_path_win32_normalize(i64)

declare i64 @js_path_win32_parse(i64)

declare i64 @js_path_win32_format(double)

declare i64 @js_path_win32_relative(i64, i64)

declare i64 @js_path_win32_relative_checked(double, double)

declare i64 @js_path_win32_resolve(i64)

declare i64 @js_path_win32_resolve_join(i64, i64)

declare i64 @js_path_win32_to_namespaced_path(i64)

declare double @js_path_win32_to_namespaced_path_value(double)

declare i32 @js_path_win32_matches_glob(i64, i64)

declare i64 @js_path_win32_sep_get()

declare i64 @js_path_win32_delimiter_get()

declare i64 @js_path_dirname(i64)

declare i64 @js_path_resolve(i64)

declare i64 @js_path_relative(i64, i64)

declare i64 @js_path_relative_checked(double, double)

declare i64 @js_path_to_namespaced_path(i64)

declare double @js_path_to_namespaced_path_value(double)

declare i32 @js_path_matches_glob(i64, i64)

declare i64 @js_path_resolve_join(i64, i64)

declare i64 @js_path_arg_header(double)

declare i64 @js_path_join_value(double, double)

declare i64 @js_path_win32_join_value(double, double)

declare i64 @js_path_resolve_join_value(double, double)

declare i64 @js_path_win32_resolve_join_value(double, double)

declare i64 @js_path_basename_ext_value(double, double)

declare i64 @js_path_win32_basename_ext_value(double, double)

declare i32 @js_path_matches_glob_value(double, double)

declare i32 @js_path_win32_matches_glob_value(double, double)

declare double @js_object_from_entries(double)

declare i64 @js_string_match(i64, i64)

declare i64 @js_string_match_all(i64, i64)

declare i64 @js_string_match_all_value(i64, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log2.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log10.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.exp.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sin.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.cos.f64(double) #1

declare i64 @js_path_basename(i64)

declare i64 @js_path_basename_ext(i64, i64)

declare i64 @js_path_extname(i64)

declare i64 @js_path_sep_get()

declare i64 @js_path_delimiter_get()

declare i64 @js_path_parse(i64)

declare i64 @js_json_parse(i64)

declare i64 @js_json_text_to_string(double)

declare double @js_json_raw_json(double)

declare double @js_json_is_raw_json(double)

declare i64 @js_json_parse_or_null(i64)

declare i64 @js_json_parse_typed_array(i64, i64, i32, i32)

declare i64 @js_date_to_date_string(double)

declare i64 @js_date_to_time_string(double)

declare i64 @js_date_to_utc_string(double)

declare i64 @js_date_to_locale_date_string(double)

declare i64 @js_date_to_locale_time_string(double)

declare i64 @js_date_to_json(double)

declare i64 @js_regexp_exec(i64, i64)

declare i64 @js_number_to_precision(double, double)

declare i64 @js_number_to_exponential(double, double)

declare double @js_date_new()

declare double @js_number_is_integer(double)

declare double @js_number_is_nan(double)

declare double @js_number_is_safe_integer(double)

declare double @js_date_parse(i64)

declare double @js_date_utc(ptr, i32)

declare double @js_date_new_local_components(double, double, double, double, double, double, double)

declare double @js_date_apply_setter(double, i32, i32, ptr, i32)

declare double @js_math_clz32(double)

declare double @js_math_cbrt(double)

declare double @js_math_fround(double)

declare double @js_math_f16round(double)

declare double @js_math_sinh(double)

declare double @js_math_cosh(double)

declare double @js_math_tanh(double)

declare double @js_math_asinh(double)

declare double @js_math_acosh(double)

declare double @js_math_atanh(double)

declare double @js_math_hypot(double, double)

declare double @js_object_is(double, double)

declare i64 @js_path_normalize(i64)

declare i64 @js_path_format(double)

declare i32 @js_path_is_absolute(i64)

declare i64 @js_encode_uri(double)

declare i64 @js_decode_uri(double)

declare i64 @js_encode_uri_component(double)

declare i64 @js_decode_uri_component(double)

declare i64 @js_text_encoder_new()

declare i64 @js_text_decoder_new(double, double, double)

declare i64 @js_text_encoder_encode_llvm(double)

declare i64 @js_text_decoder_decode_llvm(double, double)

declare i64 @js_text_decoder_encoding(double)

declare double @js_text_decoder_fatal(double)

declare double @js_text_decoder_ignore_bom(double)

declare void @js_queue_microtask(i64)

declare void @js_queue_next_tick(i64)

declare void @js_queue_next_tick_args(i64, ptr, i32)

declare void @js_drain_queued_microtasks()

declare i64 @js_uint8array_from_array(i64)

declare i64 @js_uint8array_alloc(i32)

declare i64 @js_uint8array_new(double)

declare i64 @js_uint8array_view(double, double, double)

declare i64 @js_typed_array_new_empty(i32, i32)

declare i64 @js_typed_array_new_from_array(i32, i64)

declare i64 @js_typed_array_new(i32, double)

declare i64 @js_typed_array_view(i32, double, double, double)

declare i32 @js_typed_array_length(i64)

declare double @js_typed_array_get(i64, i32)

declare i32 @js_typed_array_read_int32(i64, i32)

declare double @js_typed_array_read_f64(i64, i32)

declare double @js_u8_buffer_read_f64(i64, i32)

declare double @js_typed_array_index_get_dynamic(i64, double)

declare double @js_typed_array_at(i64, double)

declare void @js_typed_array_set(i64, i32, double)

declare double @js_typed_array_index_set_dynamic(i64, double, double)

declare i32 @js_uint8array_get(i64, i32)

declare double @js_uint8array_index_get_value(i64, i32)

declare void @js_uint8array_set(i64, i32, i32)

declare i64 @js_native_arena_alloc(i64)

declare i64 @js_native_arena_view(i64, i32, i64, i64)

declare i64 @js_native_pod_view(i64, i64, i64, i64, i64, i64)

declare double @js_native_pod_view_length(double)

declare ptr @js_native_abi_check_pod_view_data_ptr(double, i64)

declare i64 @js_native_abi_check_pod_view_record_count(double, i64)

declare void @js_native_arena_dispose(i64)

declare void @js_native_memory_fill_u32(i64, double)

declare void @js_native_memory_copy(i64, i64)

declare i64 @js_typed_array_to_reversed(i64)

declare i64 @js_typed_array_to_sorted_default(i64)

declare i64 @js_typed_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_typed_array_with(i64, double, double)

declare double @js_typed_array_find_last(i64, i64)

declare double @js_typed_array_find_last_index(i64, i64)

declare double @js_typed_array_set_from(i64, double, double)

declare i64 @js_typed_array_subarray(i64, i32, double, i32, double)

declare double @js_object_has_own(double, double)

declare double @js_object_property_is_enumerable(double, double)

declare double @js_object_define_getter(double, double, double)

declare double @js_object_define_setter(double, double, double)

declare double @js_object_lookup_getter(double, double)

declare double @js_object_lookup_setter(double, double)

declare double @js_object_get_own_field_or_undef(double, ptr, i64)

declare double @js_unresolved_namespace_stub()

declare double @js_node_submodule_export_as_function(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace_member(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace(ptr, i32)

declare void @js_node_submod_install_vm()

declare void @js_node_submod_install_timers()

declare void @js_node_submod_install_timers_promises()

declare void @js_node_submod_install_fs_promises()

declare void @js_node_submod_install_readline_promises()

declare void @js_node_submod_install_stream_promises()

declare void @js_node_submod_install_stream_consumers()

declare void @js_node_submod_install_stream_web()

declare void @js_node_submod_install_hono_jsx_server()

declare void @js_node_submod_install_hono_jsx_streaming()

declare void @js_node_submod_install_sys()

declare void @js_node_submod_install_diagnostics_channel()

declare void @js_node_submod_install_trace_events()

declare void @js_node_submod_install_test()

declare void @js_node_submod_install_test_reporters()

declare void @js_node_submod_install_all()

declare void @js_node_submod_enable_install_all()

declare double @js_unresolved_default_call()

declare double @js_get_global_this()

declare double @js_module_top_this()

declare double @js_global_or_console_property_by_name(i64)

declare void @js_class_register_static_symbol(i32, double, double)

declare void @js_register_class_computed_method(i64, double, i64, i64, i64, i64, i64)

declare void @js_register_class_computed_accessor(i64, double, i64, i64, i64, i64)

declare void @js_class_register_static_field(i32, ptr, i64, double, ptr)

declare double @js_object_define_property(double, double, double)

declare double @js_object_define_get_accessor(double, double, double)

declare double @js_object_get_own_property_descriptor(double, double)

declare double @js_object_get_own_property_descriptors(double)

declare double @js_object_get_own_property_names(double)

declare double @js_symbol_new(double)

declare double @js_symbol_new_empty()

declare double @js_symbol_for(double)

declare double @js_symbol_computed_member(double, double)

declare double @js_symbol_key_for(double)

declare double @js_symbol_description(double)

declare i64 @js_symbol_to_string(double)

declare i32 @js_symbol_equals(double, double)

declare i32 @js_is_symbol(double)

declare i64 @js_object_get_own_property_symbols(double)

declare double @js_object_set_symbol_property(double, double, double)

declare double @js_to_property_key(double)

declare double @js_object_set_property_key(double, double, double)

declare double @js_object_get_property_key(double, double)

declare double @js_object_set_property_key_method(double, double, double)

declare double @js_object_super_get(double, double, double)

declare double @js_object_super_put_value_set(double, double, double, double, i32)

declare double @js_object_super_call(double, double, double, ptr, i64)

declare double @js_object_literal_infer_computed_function_name(double, double)

declare double @js_object_get_symbol_property(double, double)

declare double @js_object_get_symbol_property_ic_miss(double, double, ptr)

declare double @js_object_get_symbol_then_field_ic_miss(double, double, ptr, i64, ptr, ptr)

declare double @js_object_create(double)

declare double @js_object_create_with_props(double, double)

declare double @js_object_freeze(double)

declare double @js_object_seal(double)

declare double @js_object_prevent_extensions(double)

declare void @js_object_copy_own_fields(i64, double)

declare double @js_object_assign_validate_target(double)

declare double @js_object_assign_one(double, double)

declare double @js_string_at(i64, i32)

declare double @js_string_code_point_at(i64, i32)

declare i64 @js_string_from_code_point(double)

declare i64 @js_string_raw(double, double)

declare i64 @js_string_from_char_code(double)

declare i64 @js_string_from_char_code_array(double)

declare double @js_string_char_code_at(i64, i32)

declare i32 @js_string_last_index_of(i64, i64)

declare i32 @js_string_last_index_of_from(i64, i64, double, i32)

declare double @js_string_locale_compare(i64, i64)

declare double @js_string_locale_compare_opts(i64, i64, double)

declare i64 @js_string_normalize(i64, double)

declare i64 @js_string_pad_start(i64, double, i64)

declare i64 @js_string_pad_end(i64, double, i64)

declare i64 @js_string_pad_fill(double)

declare double @js_string_is_well_formed(i64)

declare i64 @js_string_to_well_formed(i64)

declare i32 @js_string_search_regex(i64, i64)

declare i32 @js_string_search_value(i64, double)

declare i64 @js_string_match_value(i64, double)

declare double @js_regexp_exec_get_index()

declare i64 @js_regexp_exec_get_groups()

declare double @js_regexp_get_last_index(i64)

declare void @js_regexp_set_last_index(i64, double)

declare i64 @js_regexp_get_source(i64)

declare i64 @js_regexp_get_flags(i64)

declare i64 @js_string_replace_regex_named(i64, i64, i64)

declare i64 @js_string_replace_all_regex_named(i64, i64, i64)

declare i64 @js_string_replace_string_fn(i64, i64, double)

declare i64 @js_string_replace_string_dyn(i64, i64, double)

declare i64 @js_string_replace_all_string_dyn(i64, i64, double)

declare i64 @js_string_replace_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_all_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_string_fn(i64, i64, double)

declare i64 @js_string_replace_regex_fn(i64, i64, double)

declare i64 @js_string_replace_all_regex_fn(i64, i64, double)

declare double @js_structured_clone(double)

declare double @js_structured_clone_with_options(double, double)

declare double @js_generator_attach_prototype(double, i32)

declare double @js_generator_attach_closure_prototype(double, i64)

declare i64 @js_weakref_new(double)

declare double @js_weakref_deref(double)

declare i64 @js_finreg_new(double)

declare double @js_finreg_register(double, double, double, double)

declare double @js_finreg_unregister(double, double)

declare i64 @js_atob(double)

declare i64 @js_btoa(double)

declare double @js_object_is_frozen(double)

declare double @js_object_is_sealed(double)

declare double @js_object_is_extensible(double)

declare i64 @js_aggregateerror_new(i64, i64)

declare i64 @js_error_new_with_cause(i64, double)

declare i64 @js_aggregateerror_new_full(double, i64, double)

declare i64 @js_error_new_kind_with_options(i32, i64, double)

declare double @js_error_is_error(double)

declare i64 @js_error_get_errors(i64)

declare i64 @js_crypto_sha256(i64)

declare i64 @js_crypto_sha256_bytes(i64)

declare i64 @js_crypto_md5(i64)

declare i64 @js_crypto_hmac_sha256(i64, i64)

declare i64 @js_crypto_hmac_sha256_bytes(i64, i64)

declare void @js_runtime_validate_string_arg(double, ptr, i32)

declare void @js_set_call_location(ptr, i64, i32)

declare void @js_runtime_validate_crypto_key_arg(double, ptr, i32)

declare void @js_runtime_validate_integer_arg(double, ptr, i32, double, double)

declare i64 @js_crypto_pbkdf2_bytes(i64, i64, double, double, i64)

declare double @js_crypto_pbkdf2_async_alg(i64, i64, double, double, i64, double)

declare i64 @js_crypto_argon2_sync(i64, double)

declare double @js_crypto_argon2_async(i64, double, double)

declare i64 @js_crypto_encapsulate(double)

declare double @js_crypto_encapsulate_async(double, double)

declare i64 @js_crypto_decapsulate(double, double)

declare double @js_crypto_decapsulate_async(double, double, double)

declare i64 @js_crypto_hkdf_bytes_alg(i64, i64, i64, i64, double)

declare double @js_crypto_hkdf_async_alg(i64, i64, i64, i64, double, double)

declare i64 @js_crypto_scrypt_bytes(i64, i64, double, double)

declare double @js_crypto_scrypt_async(i64, i64, double, double, double)

declare i64 @js_crypto_sign_rsa_sha256(i64, i64, double)

declare double @js_crypto_sign_async(i64, i64, double, double)

declare double @js_crypto_verify_rsa_sha256(i64, i64, double, i64)

declare double @js_crypto_verify_async(i64, i64, double, i64, double)

declare i64 @js_crypto_public_encrypt(i64, i64)

declare i64 @js_crypto_private_decrypt(i64, i64)

declare i64 @js_crypto_private_encrypt(i64, i64)

declare i64 @js_crypto_public_decrypt(i64, i64)

declare i64 @js_crypto_create_public_key(i64)

declare i64 @js_crypto_create_private_key_value(double)

declare i64 @js_crypto_create_public_key_value(double)

declare i64 @js_crypto_generate_key_pair_sync_rsa(double)

declare i64 @js_crypto_generate_key_pair_sync_ec_p256(double)

declare i64 @js_crypto_generate_key_pair_sync_ed25519(double)

declare i64 @js_crypto_generate_key_pair_sync_x25519(double)

declare double @js_crypto_generate_key_pair_async(i64, double, double)

declare i64 @js_crypto_diffie_hellman(double)

declare double @js_crypto_get_cipher_info(double, double)

declare i64 @js_crypto_get_curves()

declare i64 @js_crypto_secure_heap_used()

declare i64 @js_crypto_random_bytes_buffer(double)

declare double @js_crypto_random_bytes_async(double, double)

declare i64 @js_crypto_random_uuid(double)

declare i64 @js_crypto_random_uuidv7()

declare double @js_crypto_random_int(double, double)

declare double @js_crypto_random_int_async(double, double, double)

declare double @js_crypto_timing_safe_equal(double, double)

declare i64 @js_crypto_get_hashes()

declare i64 @js_crypto_get_ciphers()

declare double @js_crypto_generate_prime_sync(double, double)

declare double @js_crypto_generate_prime_async(double, double, double)

declare double @js_crypto_check_prime_sync(double, double)

declare double @js_crypto_check_prime_async(double, double, double)

declare i64 @js_crypto_create_secret_key(i64, i64)

declare i64 @js_crypto_generate_key_sync(i64, double)

declare double @js_crypto_generate_key_async(i64, double, double)

declare i64 @js_webcrypto_digest(double, double)

declare i64 @js_webcrypto_import_key(double, double, double, double, double)

declare i64 @js_webcrypto_export_key(double, double)

declare i64 @js_webcrypto_sign(double, double, double)

declare i64 @js_webcrypto_verify(double, double, double, double)

declare i64 @js_webcrypto_derive_bits(double, double, double)

declare i64 @js_webcrypto_derive_key(double, double, double, double, double)

declare i64 @js_webcrypto_encrypt(double, double, double)

declare i64 @js_webcrypto_decrypt(double, double, double)

declare i64 @js_webcrypto_generate_key(double, double, double)

declare i64 @js_webcrypto_wrap_key(double, double, double, double)

declare i64 @js_webcrypto_unwrap_key(double, double, double, double, double, double, double)

declare i64 @js_zlib_create_brotli_decompress(double)

declare double @js_crypto_random_fill_sync(double, double, double)

declare double @js_crypto_random_fill_async(double, double, double, double)

declare double @js_crypto_create_hash(i64)

declare double @js_crypto_create_hash_options(i64, double)

declare double @js_crypto_x509_new(i64)

declare double @js_crypto_certificate_verify_spkac(double)

declare double @js_crypto_certificate_export_public_key(double)

declare double @js_crypto_certificate_export_challenge(double)

declare double @js_crypto_create_sign(i64)

declare double @js_crypto_create_verify(i64)

declare double @js_crypto_create_ecdh(i64)

declare double @js_crypto_create_diffie_hellman(double, double, double)

declare double @js_crypto_get_diffie_hellman(double)

declare double @js_crypto_ecdh_convert_key(double, double, double, double, double)

declare double @js_crypto_create_hmac(i64, i64)

declare i64 @js_buffer_alloc(i32, i32)

declare i64 @js_buffer_alloc_fill_value(i32, double, i32)

declare i64 @js_array_buffer_new(i32)

declare i64 @js_shared_array_buffer_new(i32)

declare i64 @js_array_buffer_new_value(double)

declare i64 @js_shared_array_buffer_new_value(double)

declare i64 @js_json_stringify_full(double, double, double)

declare i64 @js_json_parse_with_reviver(i64, i64)

declare double @js_array_find(i64, i64)

declare i32 @js_array_findIndex(i64, i64)

declare double @js_array_find_last(i64, i64)

declare i32 @js_array_find_last_index(i64, i64)

declare double @js_array_some(i64, i64)

declare double @js_array_some_captureless(i64, ptr)

declare double @js_array_every(i64, i64)

declare i32 @js_promise_state(i64)

declare double @js_promise_value(i64)

declare double @js_promise_reason(i64)

declare i32 @js_value_is_promise(double)

declare double @js_assimilate_thenable(double)

declare i32 @js_promise_run_microtasks()

declare i32 @js_promise_run_microtasks_event_loop()

declare i32 @js_promise_run_microtasks_await_loop()

declare i32 @js_await_loop_tick_timers()

declare void @js_mark_entry_module_esm()

declare i32 @js_promise_run_promise_jobs()

declare void @js_run_stdlib_pump()

declare void @js_sleep_ms(double)

declare void @js_wait_for_event()

declare i32 @js_event_loop_host_driven()

declare void @js_unsettled_top_level_await_exit()

declare void @js_throw(double)

declare void @js_eh_try_push()

declare i32 @perry_eh_personality(...)

declare void @js_try_end()

declare double @js_get_exception()

declare void @js_clear_exception()

declare i32 @js_has_exception()

declare void @js_enter_finally()

declare void @js_leave_finally()

declare double @js_await_any_promise(double)

declare i64 @js_promise_new()

declare i64 @js_promise_new_with_executor(i64)

declare i32 @js_timer_tick()

declare i32 @js_timer_tick_if_refed()

declare i32 @js_callback_timer_tick()

declare i32 @js_interval_timer_tick()

declare i32 @js_timer_has_pending()

declare i32 @js_callback_timer_has_pending()

declare i32 @js_interval_timer_has_pending()

declare i32 @js_stdlib_has_active_handles()

declare i32 @js_bun_ffi_has_active_threadsafe_callbacks()

declare i32 @js_microtasks_pending()

declare i64 @js_timer_validate_callback(double, i32)

declare i64 @js_set_timeout_callback(i64, double)

declare i64 @js_set_timeout_callback_args(i64, double, ptr, i32)

declare i64 @js_set_immediate_callback(i64)

declare i64 @js_set_immediate_callback_args(i64, ptr, i32)

declare i64 @setInterval(i64, double)

declare i64 @js_set_interval_callback_args(i64, double, ptr, i32)

declare void @clearTimeout(i64)

declare void @clearInterval(i64)

declare void @clearImmediate(i64)

declare void @js_clear_timeout_value(double)

declare void @js_clear_interval_value(double)

declare void @js_clear_immediate_value(double)

declare i64 @js_buffer_from_array(i64)

declare i64 @js_buffer_from_arraybuffer_slice(i64, i32, i32)

declare i32 @js_buffer_length(i64)

declare i32 @js_buffer_get(i64, i32)

declare double @js_buffer_index_get_value(i64, i32)

declare ptr @js_native_buffer_data_ptr(double)

declare i64 @js_native_buffer_byte_len(double)

declare void @js_console_time(i64)

declare void @js_console_time_end(i64)

declare void @js_console_time_log(i64)

declare void @js_console_time_value(double)

declare void @js_console_time_end_value(double)

declare void @js_console_time_log_value(double)

declare void @js_console_time_log_spread(double, i64)

declare void @js_console_count(i64)

declare void @js_console_count_reset(i64)

declare void @js_console_count_value(double)

declare void @js_console_count_reset_value(double)

declare double @js_console_new(double)

declare double @js_console_new2(double, double)

declare void @js_console_group_begin()

declare void @js_console_group_end()

declare void @js_console_clear()

declare void @js_console_noop()

declare double @js_native_call_method(double, ptr, i64, ptr, i64)

declare double @js_native_call_method_by_id(double, i64, ptr, i64)

declare double @js_native_call_method_apply(double, ptr, i64, i64)

declare double @js_native_call_method_apply_by_id(double, i64, i64)

declare double @js_native_call_method_str_key(double, i64, ptr, i64)

declare double @js_native_call_method_value(double, double, ptr, i64)

declare double @js_native_call_method_value_apply(double, double, i64)

declare void @js_promise_resolve(i64, double)

declare void @js_promise_reject(i64, double)

declare void @js_promise_mark_internally_handled(i64)

declare i64 @js_promise_resolved(double)

declare i64 @js_async_fn_result(double)

declare i64 @js_promise_rejected(double)

declare double @js_create_namespace(i32, ptr, ptr, ptr, ptr)

declare double @js_finalize_namespace(double)

declare i64 @js_promise_then(i64, i64, i64)

declare i64 @js_promise_resolved_then(double, i64, i64)

declare i64 @js_promise_finally(i64, i64)

declare double @js_promise_then_checked(double, double, double)

declare double @js_promise_catch_checked(double, double)

declare double @js_promise_finally_checked(double, double)

declare i64 @js_promise_closure_arg(double)

declare i64 @js_promise_all(i64)

declare i64 @js_promise_race(i64)

declare i64 @js_promise_any(i64)

declare i64 @js_promise_all_settled(i64)

declare i64 @js_promise_all_iterable(double)

declare i64 @js_promise_race_iterable(double)

declare i64 @js_promise_any_iterable(double)

declare i64 @js_promise_all_settled_iterable(double)

declare i64 @js_promise_with_resolvers()

declare i64 @js_promise_try(double, i64)

declare i64 @js_array_unshift_f64(i64, double)

declare i64 @js_array_unshift_variadic(i64, ptr, i32)

declare i64 @js_array_entries(i64)

declare i64 @js_array_keys(i64)

declare i64 @js_array_values(i64)

declare i64 @js_array_entries_iter_obj(i64)

declare i64 @js_array_keys_iter_obj(i64)

declare i64 @js_array_values_iter_obj(i64)

declare double @js_response_new(i64, double, i64, double)

declare double @js_fetch_unwrap_handle(double)

declare double @js_response_body_init_reset()

declare i64 @js_response_body_init_ptr(double)

declare double @js_headers_new()

declare double @js_headers_set(double, i64, i64)

declare double @js_headers_append(double, i64, i64)

declare i64 @js_headers_get(double, i64)

declare double @js_headers_get_set_cookie(double)

declare double @js_headers_has(double, i64)

declare double @js_headers_delete(double, i64)

declare double @js_headers_for_each(double, double)

declare double @js_headers_keys(double)

declare double @js_headers_values(double)

declare double @js_headers_entries(double)

declare double @js_headers_init_from_value(double, double)

declare double @js_headers_method_value(double, i64, i64)

declare double @js_request_new(i64, i64, i64, double, i64, i64, i64, i64, i64, i64, i64, double, i64, double)

declare double @js_request_new_from_init(i64, double)

declare i64 @js_request_get_url(double)

declare i64 @js_request_input_to_url(double)

declare i64 @js_request_get_method(double)

declare double @js_request_get_body(double)

declare double @js_request_body_used(double)

declare i64 @js_request_get_destination(double)

declare i64 @js_request_get_referrer(double)

declare i64 @js_request_get_referrer_policy(double)

declare i64 @js_request_get_mode(double)

declare i64 @js_request_get_credentials(double)

declare i64 @js_request_get_cache(double)

declare i64 @js_request_get_redirect(double)

declare i64 @js_request_get_integrity(double)

declare double @js_request_get_keepalive(double)

declare i64 @js_request_get_duplex(double)

declare double @js_request_get_signal(double)

declare double @js_request_get_headers(double)

declare i64 @js_request_text(double)

declare i64 @js_request_json(double)

declare i64 @js_request_array_buffer(double)

declare i64 @js_request_blob(double)

declare i64 @js_request_bytes(double)

declare i64 @js_request_form_data(double)

declare double @js_request_clone(double)

declare double @js_fetch_response_status(double)

declare i64 @js_fetch_response_status_text(double)

declare double @js_fetch_response_ok(double)

declare i64 @js_fetch_response_type(double)

declare i64 @js_fetch_response_url(double)

declare double @js_fetch_response_redirected(double)

declare double @js_response_body_used(double)

declare i64 @js_fetch_response_text(double)

declare i64 @js_fetch_response_json(double)

declare double @js_response_get_headers(double)

declare double @js_response_clone(double)

declare i64 @js_response_array_buffer(double)

declare i64 @js_response_blob(double)

declare i64 @js_response_bytes(double)

declare i64 @js_response_form_data(double)

declare double @js_form_data_new()

declare double @js_form_data_append(double, double, double, double)

declare double @js_form_data_set(double, double, double, double)

declare double @js_form_data_delete(double, i64)

declare double @js_form_data_get(double, i64)

declare double @js_form_data_get_all(double, i64)

declare double @js_form_data_has(double, i64)

declare double @js_form_data_entries(double)

declare double @js_form_data_keys(double)

declare double @js_form_data_values(double)

declare double @js_form_data_for_each(double, double)

declare double @js_blob_size(double)

declare i64 @js_blob_type(double)

declare i64 @js_blob_array_buffer(double)

declare i64 @js_blob_bytes(double)

declare i64 @js_blob_text(double)

declare double @js_blob_slice(double, double, double, i64)

declare double @js_blob_new(double, double)

declare double @js_file_new(double, double, double, double)

declare i64 @js_file_name(double)

declare double @js_file_last_modified(double)

declare i64 @js_url_create_object_url(double)

declare void @js_url_revoke_object_url(double)

declare double @js_buffer_resolve_object_url(double)

declare double @js_response_static_json(double, double, i64, double)

declare double @js_response_static_redirect(i64, double)

declare double @js_response_static_error()

declare double @js_blob_stream(double)

declare double @js_response_body(double)

declare double @js_readable_stream_new(double, double, double, double)

declare double @js_readable_stream_new_with_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_with_strategy_and_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_from_source_object(double, double)

declare double @js_readable_stream_get_reader(double)

declare double @js_readable_stream_get_reader_with_options(double, double)

declare double @js_readable_stream_get_byob_reader(double)

declare double @js_readable_stream_controller_byob_request(double)

declare double @js_readable_stream_from_iterable(double)

declare double @js_readable_stream_locked(double)

declare i64 @js_readable_stream_cancel(double, double)

declare double @js_readable_stream_tee(double)

declare i64 @js_readable_stream_pipe_to(double, double, double)

declare double @js_readable_stream_pipe_through(double, double, double)

declare double @js_readable_stream_pipe_through_validate(double, double, double, double)

declare double @js_readable_stream_controller_enqueue(double, double)

declare double @js_readable_stream_controller_close(double)

declare double @js_readable_stream_controller_error(double, double)

declare double @js_readable_stream_controller_desired_size(double)

declare i64 @js_reader_read(double)

declare i64 @js_reader_read_with_view(double, double)

declare double @js_reader_release_lock(double)

declare i64 @js_reader_closed(double)

declare i64 @js_reader_cancel(double, double)

declare double @js_writable_stream_new(double, double, double, double, double)

declare double @js_writable_stream_new_with_sink_type(double, double, double, double, double, double)

declare double @js_writable_stream_new_from_sink_object(double, double)

declare double @js_writable_stream_throw_invalid_sink()

declare double @js_writable_stream_get_writer(double)

declare double @js_writable_stream_locked(double)

declare i64 @js_writable_stream_close(double)

declare i64 @js_writable_stream_abort(double, double)

declare i64 @js_writer_write(double, double)

declare i64 @js_writer_close(double)

declare i64 @js_writer_abort(double, double)

declare double @js_writer_release_lock(double)

declare i64 @js_writer_closed(double)

declare i64 @js_writer_ready(double)

declare double @js_writer_desired_size(double)

declare double @js_transform_stream_new(double, double, double, double, double)

declare double @js_transform_stream_new_from_transformer_object(double, double, double)

declare double @js_transform_stream_readable(double)

declare double @js_transform_stream_writable(double)

declare double @js_text_encoding_stream_new()

declare double @js_text_encoder_stream_new()

declare double @js_text_decoder_stream_new()

declare double @js_stream_web_text_encoder_stream_new()

declare double @js_stream_web_text_decoder_stream_new(double, double)

declare double @js_stream_web_compression_stream_new(double)

declare double @js_stream_web_decompression_stream_new(double)

declare double @js_streams_strategy_high_water_mark(double)

declare double @js_count_queuing_strategy_new(double)

declare double @js_byte_length_queuing_strategy_new(double)

declare double @js_stream_unwrap_handle(double)

declare double @js_readable_stream_subclass_init(double, double, double, double, double)

declare double @js_writable_stream_subclass_init(double, double, double, double, double)

declare double @js_transform_stream_subclass_init(double, double, double, double)

declare double @js_request_subclass_init(double, double, double)

declare double @js_response_subclass_init(double, double, double)

declare double @js_fetch_or_value_super(double, double, ptr, i64)

declare double @js_builtin_subclass_construct(i32, ptr, i64, ptr, i64)

declare i64 @js_abort_controller_new()

declare i64 @js_abort_controller_signal(i64)

declare void @js_abort_controller_abort(i64)

declare void @js_abort_controller_abort_reason(i64, double)

declare void @js_abort_signal_add_listener(i64, double, double)

declare i64 @js_abort_signal_timeout(double)

declare i64 @js_abort_signal_abort(double)

declare i64 @js_abort_signal_any(i64)

declare double @js_abort_signal_throw_if_aborted(i64)

declare i64 @js_event_target_new()

declare i64 @js_event_new(double, double, i32)

declare double @js_event_subclass_init(double, double, double, i32, i32)

declare i64 @js_custom_event_new(double, double, i32)

declare i64 @js_dom_exception_new(double, double)

declare double @js_dom_exception_subclass_init(double, double, double)

declare void @js_event_target_add_event_listener(i64, i64, i64)

declare void @js_event_target_add_event_listener_with_options(i64, i64, i64, double)

declare void @js_event_target_remove_event_listener(i64, i64, i64)

declare void @js_event_target_remove_event_listener_with_options(i64, i64, i64, double)

declare double @js_event_target_dispatch_event(i64, double)

declare i32 @js_event_target_is_event_target(i64)

declare i64 @js_event_target_get_event_listeners(i64, i64)

declare double @js_event_target_get_max_listeners(i64)

declare i32 @js_event_target_set_max_listeners(i64, double)

declare double @js_message_channel_new()

declare double @js_message_port_constructor_error()

declare double @js_broadcast_channel_new(double)

declare i64 @js_array_alloc(i32)

declare i64 @js_tagged_template_register_raw(i64, i64)

declare i64 @js_tagged_template_get_or_init(i64, i64, i64)

declare i64 @js_template_raw(i64)

declare i64 @js_array_create()

declare i64 @js_array_constructor_single(double)

declare i64 @js_array_alloc_literal(i32)

declare i64 @js_array_from_values(ptr, i32)

declare double @js_value_from_const_descriptor(ptr, i32)

declare i64 @js_array_push_f64(i64, double)

declare i64 @js_array_push_u31_with_length(i64, i32, ptr)

declare i64 @js_array_push_f64_spec(i64, double)

declare void @js_array_push_guard(i64)

declare i64 @js_array_push_hole(i64)

declare i64 @js_array_numeric_push_f64_unboxed(i64, double)

declare i64 @js_array_push_spread_f64(i64, i64)

declare double @js_array_get_f64(i64, i32)

declare i32 @js_array_ensure_element_shape(i64)

declare double @js_array_get_index_or_string(i64, double)

declare double @js_array_numeric_get_f64_unboxed(i64, i32)

declare void @js_array_set_f64(i64, i32, double)

declare i32 @js_array_numeric_set_f64_unboxed(i64, i32, double)

declare i64 @js_array_set_f64_extend(i64, i32, double)

declare i64 @js_array_set_f64_extend_strict(i64, i32, double)

declare i64 @js_array_fill_f64_const_extend(i64, i32, double)

declare i64 @js_array_fill_f64_iota_extend(i64, i32)

declare i64 @js_array_fill_f64_const_len_extend(i64, double)

declare i64 @js_array_fill_f64_iota_len_extend(i64)

declare i64 @js_array_numeric_range_add(double, double, double, double)

declare i64 @js_array_numeric_range_add_len(double, double, double)

declare i64 @js_array_fill_range_strided_tagged(double, double, double, double, i64)

declare i64 @js_array_set_string_key(i64, i64, double)

declare i64 @js_array_set_index_or_string(i64, double, double)

declare i64 @js_array_mark_arguments_object(i64)

declare i32 @js_array_mark_numeric_f64_layout(i64)

declare i32 @js_array_is_numeric_f64_layout(i64)

declare void @js_array_clear_numeric_layout(i64)

; Function Attrs: nounwind willreturn
declare double @js_array_numeric_value_to_raw_f64(double) #0

declare double @js_array_refresh_local_head(double)

declare void @js_array_note_numeric_write(i64, i64)

declare void @js_array_declare_all_pointer_elements(i64)

declare i32 @js_array_length(i64)

declare double @js_array_is_array(double)

declare double @js_value_length_f64(double)

declare double @js_value_length_property_f64(double)

declare double @js_value_length_property_ic_f64(double, ptr)

declare nonnull ptr @js_shadow_frame_enter(i32)

declare i64 @js_shadow_frame_push(i32)

declare void @js_shadow_frame_pop(i64)

declare void @js_shadow_slot_set(i32, i64)

declare void @js_shadow_slot_bind(i32, ptr)

declare void @js_gc_write_barriers_emitted(i32)

declare i32 @js_gc_temp_root_push(i64)

declare i64 @js_gc_temp_root_get(i32)

declare void @js_gc_temp_root_set(i32, i64)

declare void @js_gc_temp_root_truncate(i32)

declare void @js_array_push_f64_temp_rooted(i32, double)

declare void @js_gc_loop_safepoint()

declare void @js_write_barrier(i64, i64)

declare void @js_write_barrier_slot(i64, i64, i64)

declare i64 @js_array_live_head(i64)

declare void @js_write_barrier_slot_validated_parent(i64, i64, i64)

declare void @js_write_barrier_root_nanbox(i64)

declare void @js_write_barrier_root_heap_word(i64)

declare void @js_gc_note_slot_layout(i64, i32, i64)

declare void @js_gc_note_slot_layout_aware(i64, i32, i64, i64)

declare void @js_gc_init_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_declare_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_forget_object_layout(i64)

declare double @js_array_pop_f64(i64)

declare i64 @js_array_join(i64, i64)

declare i64 @js_array_join_value(i64, double)

declare void @js_array_forEach(i64, i64)

declare i64 @js_array_fill(i64, double)

declare i64 @js_array_fill_range(i64, double, double, double)

declare double @js_array_fill_generic(double, double, i32, double, i32, double)

declare i32 @js_array_delete(i64, i32)

declare void @js_array_set_length(i64, double)

declare void @js_array_set_length_strict(i64, double)

declare i64 @js_array_clone(i64)

declare i32 @js_short_packed_spread_values(double, ptr)

declare i64 @js_spread_tail_fallback_args(ptr, i64, double)

declare i64 @js_array_from_value(double)

declare i64 @js_array_from_arraylike_holey_value(double)

declare double @js_iterator_from(double)

declare i64 @js_array_from_mapped(double, double, double)

declare i64 @js_array_concat_variadic(i64, ptr, i32)

declare double @js_arraylike_forEach(double, double, double)

declare double @js_arraylike_map(double, double, double)

declare double @js_arraylike_filter(double, double, double)

declare double @js_arraylike_some(double, double, double)

declare double @js_arraylike_every(double, double, double)

declare double @js_arraylike_find(double, double, double)

declare double @js_arraylike_findIndex(double, double, double)

declare double @js_arraylike_findLast(double, double, double)

declare double @js_arraylike_findLastIndex(double, double, double)

declare double @js_arraylike_reduce(double, double, i32, double)

declare double @js_arraylike_reduceRight(double, double, i32, double)

declare double @js_arraylike_indexOf(double, double, double, i32)

declare double @js_arraylike_lastIndexOf(double, double, double, i32)

declare double @js_arraylike_includes(double, double, double, i32)

declare double @js_arraylike_at(double, double)

declare double @js_arraylike_join(double, double)

declare double @js_arraylike_flat(double, double)

declare double @js_arraylike_slice(double, double, i32, double, i32)

declare double @js_arraylike_sort(double, double)

declare double @js_arraylike_splice(double, ptr, i32)

declare double @js_arraylike_concat(double, ptr, i32)

declare double @js_arraylike_pop(double)

declare double @js_arraylike_shift(double)

declare double @js_arraylike_push(double, ptr, i32)

declare double @js_arraylike_unshift(double, ptr, i32)

declare i64 @js_array_clone_for_spread(double)

declare i64 @js_array_spread_append(i64, double)

declare i64 @js_iterator_to_array(double)

declare double @js_iterator_next_result(double)

declare double @js_iterator_close_if_not_done(double, double)

declare double @js_iterator_rest_to_array(double, double)

declare double @js_get_iterator(double)

declare double @js_get_async_iterator(double)

declare double @js_for_of_to_array(double)

declare i64 @js_object_alloc(i32, i32)

declare double @js_object_coerce(double)

declare void @js_object_mark_class(i64)

declare void @js_class_object_pin_parent(i64, i32)

declare i64 @js_object_alloc_with_shape(i32, i32, ptr, i32)

declare void @js_object_set_field(i64, i32, i64)

declare i64 @js_object_get_field(i64, i32)

declare void @js_object_set_field_by_name(i64, i64, double)

declare void @js_object_set_field_by_property_id(i64, i64, double)

declare void @js_object_set_field_by_name_nonenum(i64, i64, double)

declare void @js_error_subclass_default_init(double, double)

declare void @js_object_set_field_by_name_nonconfigurable(i64, i64, double)

declare void @js_error_apply_cause_to_object(i64, double)

declare void @js_error_subclass_capture_stack(double)

declare i32 @js_with_has_binding(double, i64)

declare double @js_with_get_binding(double, i64)

declare double @js_with_set_binding(double, i64, double, i32)

declare i32 @js_with_delete_binding(double, i64)

declare i32 @js_pod_scalar_write_compatible(double, i32)

declare void @js_typed_feedback_register_site(i64, i32, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64)

declare void @js_typed_feedback_record_guard_pass(i64)

declare void @js_typed_feedback_record_guard_fail(i64)

declare void @js_typed_feedback_record_fallback_call(i64)

declare void @js_typed_feedback_observe_property_get(i64, i64, i64)

declare void @js_typed_feedback_observe_property_set(i64, i64, i64)

declare double @js_typed_feedback_object_get_field_by_name_f64(i64, i64, i64)

declare void @js_typed_feedback_object_set_field_by_name(i64, i64, i64, double)

declare void @js_typed_feedback_object_set_field_by_name_fast(i64, i64, i64, double)

declare i32 @js_typed_feedback_class_field_set_guard(i64, double, i32, i32, i64, i32, double, i32)

declare void @js_class_field_set_fallback(i64, i64, i64, double)

declare void @js_class_field_set_ic(i64, double, i32, i32, i64, i32, double, i32)

declare i32 @js_typed_feedback_class_field_get_guard(i64, double, i32, i32, i64, i32, i32)

declare double @js_class_field_get_ic(i64, double, i32, i32, i64, i32, i32)

declare double @js_typed_feedback_native_call_method(i64, double, ptr, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_by_id(i64, double, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_apply(i64, double, ptr, i64, i64)

declare double @js_typed_feedback_native_call_method_apply_by_id(i64, double, i64, i64)

declare i32 @js_typed_feedback_method_direct_call_guard(i64, double, i32, i32, ptr, i64, ptr)

declare i32 @js_method_direct_shape_guard(double, i32, i32, i32)

declare i32 @js_method_direct_shape_class(double, ptr, i32)

declare i32 @js_typed_feedback_closure_direct_call_guard(i64, double, ptr, i32, i32)

declare i64 @js_closure_exact_func_guard(double, ptr)

declare i64 @js_object_own_method_cache_miss(double, i32, i32, ptr, i64, ptr, ptr)

declare void @js_typed_feedback_object_set_unboxed_f64_field(i64, i64, i32, i64, double)

declare double @js_typed_feedback_observe_helper_return(i64, double)

declare void @js_object_set_index_polymorphic(i64, double, double)

declare double @js_object_get_index_polymorphic(i64, double)

declare double @js_object_get_field_by_name_f64(i64, i64)

declare double @js_object_get_field_by_name_boxed(double, i64)

declare double @js_object_get_field_by_property_id_f64(i64, i64)

declare double @js_native_module_property_by_name(ptr, i64, ptr, i64)

declare double @js_native_module_esm_export_value(double, double)

declare double @js_native_module_named_esm_export_value(double, double)

declare double @js_create_native_module_namespace(ptr, i64)

declare void @js_nm_install_assert()

declare void @js_nm_install_async_hooks()

declare void @js_nm_install_bigint()

declare void @js_nm_install_buffer()

declare void @js_bun_tcp_nm_install()

declare void @js_nm_install_bun()

declare void @js_nm_install_bun_ffi()

declare void @js_nm_install_child_process()

declare void @js_nm_install_cluster()

declare void @js_nm_install_console()

declare void @js_nm_install_crypto()

declare void @js_nm_install_dgram()

declare void @js_nm_install_dns()

declare void @js_nm_install_domain()

declare void @js_nm_install_events()

declare void @js_nm_install_fs()

declare void @js_nm_install_http()

declare void @js_nm_install_inspector()

declare void @js_nm_install_module()

declare void @js_nm_install_net()

declare void @js_nm_install_node_pty()

declare void @js_nm_install_os()

declare void @js_nm_install_path()

declare void @js_nm_install_perf()

declare void @js_nm_install_process()

declare void @js_nm_install_punycode()

declare void @js_nm_install_querystring()

declare void @js_nm_install_readline()

declare void @js_nm_install_repl()

declare void @js_nm_install_sea()

declare void @js_nm_install_sqlite()

declare void @js_nm_install_stream()

declare void @js_nm_install_timers()

declare void @js_nm_install_tls()

declare void @js_nm_install_tty()

declare void @js_nm_install_url()

declare void @js_nm_install_util()

declare void @js_nm_install_v8()

declare void @js_nm_install_vm()

declare void @js_nm_install_wasi()

declare void @js_nm_install_zlib()

declare void @js_nm_install_all()

declare double @js_object_get_field_ic_miss(i64, i64, ptr)

declare double @js_object_get_field_ic(i64, i64, i64, ptr)

declare i64 @js_object_rest(i64, i64)

declare double @js_require_object_coercible(double)

declare double @js_require_json_disk(double)

declare double @js_require_resolve_node_modules(double, double)

declare void @js_globalthis_seed_async_local_storage()

declare void @js_register_path_module_partial(double, double)

declare void @js_register_path_module(double, double)

declare void @js_link_path_module_parent(double)

declare void @js_run_module_init_catching(i64)

declare double @js_require_path_module(double)

declare double @js_has_path_module(double)

declare void @js_register_path_init(ptr, i64, i64)

declare i64 @js_array_alloc_with_length(i32)

declare void @js_array_set_f64_unchecked(i64, i32, double)

declare double @js_typed_feedback_array_get_f64(i64, i64, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_get_guard(i64, double, i32, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_get_guard(i64, double, i32, i32) #0

declare i32 @js_typed_feedback_packed_f64_array_loop_guard(i64, double)

declare i32 @js_string_array_range_loop_guard(double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense_i32(i64, double, i32, i32)

declare i32 @js_typed_feedback_masked_window_ta_kind(i64, double, i32, i32)

declare i64 @js_typed_array_masked_window_data_ptr(double)

declare i64 @js_packed_ecs_u32_loop_guard(double, double, double, double, double, double, i32, ptr)

declare i32 @js_typed_feedback_packed_u32_array_loop_guard(i64, double)

declare double @js_typed_feedback_array_index_get_fallback_boxed(i64, double, double)

declare void @js_typed_feedback_array_set_f64(i64, i64, i32, double)

declare i64 @js_typed_feedback_array_set_f64_extend(i64, i64, i32, double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_push_guard(i64, double, double) #0

declare double @js_typed_feedback_array_index_set_fallback_boxed(i64, double, double, double, i32)

declare void @js_typed_feedback_observe_array_element(i64, i64, i32)

declare i64 @js_typed_feedback_array_set_string_key(i64, i64, i64, double)

declare i64 @js_typed_feedback_array_set_index_or_string(i64, i64, double, double, i32)

declare void @js_typed_feedback_object_set_index_polymorphic(i64, i64, double, double)

declare double @js_proxy_new(double, double)

declare double @js_proxy_revocable(double, double)

declare void @js_proxy_revoke(double)

declare i32 @js_proxy_is_revoked(double)

declare i32 @js_proxy_is_proxy(double)

declare double @js_proxy_target(double)

declare double @js_proxy_get(double, double)

declare double @js_proxy_set(double, double, double)

declare double @js_proxy_has(double, double)

declare double @js_proxy_delete(double, double)

declare double @js_proxy_apply(double, double, double)

declare double @js_proxy_construct(double, double, double)

declare double @js_reflect_construct(double, double, double)

declare double @js_reflect_get(double, double, double)

declare double @js_reflect_set(double, double, double, double)

declare double @js_put_value_set(double, double, double, double, i32)

declare i32 @js_transition_ic_spill_append(double, i64, i32, double)

declare ptr @perry_transition_cache_base()

declare void @js_transition_ic_note_hit()

declare double @js_put_value_set_dyn_ic(ptr, double, double, double, i32)

declare double @js_put_value_set_ic_miss(double, i64, double, i32, ptr, i32)

declare i32 @js_put_value_set_ic_overflow_store(double, i64, i32, double)

declare double @js_object_get_field_ic_overflow_load(i64, i64, i32, ptr)

declare double @js_put_value_set_ic_poly_tail(ptr, double, i64, double, i32)

declare i64 @js_object_array_numeric_write_guard(double, double, double, double, double, i32, i32)

declare i64 @js_object_array_numeric_write_range_guard(double, double, double, double, double, i32, i32, i32)

declare double @js_super_put_value_set(i32, double, double, double, i32)

declare double @js_super_accessor_get(i32, double, double)

declare double @js_reflect_has(double, double)

declare double @js_reflect_delete(double, double)

declare double @js_reflect_own_keys(double)

declare double @js_reflect_apply(double, double, double)

declare double @js_reflect_define_property(double, double, double)

declare double @js_reflect_get_own_property_descriptor(double, double)

declare double @js_reflect_get_prototype_of(double)

declare double @js_reflect_set_prototype_of(double, double)

declare double @js_reflect_is_extensible(double)

declare double @js_reflect_prevent_extensions(double)

declare double @js_reflect_define_metadata(double, double, double, double)

declare double @js_reflect_get_metadata(double, double, double)

declare double @js_reflect_get_own_metadata(double, double, double)

declare double @js_reflect_has_metadata(double, double, double)

declare double @js_reflect_has_own_metadata(double, double, double)

declare double @js_reflect_get_metadata_keys(double, double)

declare double @js_reflect_get_own_metadata_keys(double, double)

declare double @js_reflect_delete_metadata(double, double, double)

declare double @js_http_server_construct_with_this(double, double, double)

declare double @js_https_server_construct_with_this(double, double, double)

declare i64 @js_net_socket_set_encoding(i64, i64)

declare double @js_vm_create_context(double, double)

declare double @js_vm_create_script_branded(double, double)

declare double @js_vm_module_call()

declare double @js_vm_module_constructor_error()

declare double @js_repl_start(double)

declare double @js_repl_repl_server_new(double)

declare double @js_repl_recoverable_new(double)

declare double @js_worker_threads_worker_new(i64, double)

declare double @js_worker_threads_worker_post_message(i64, double)

declare double @js_worker_threads_worker_on(i64, double, i64)

declare double @js_worker_threads_worker_once(i64, double, i64)

declare double @js_worker_threads_worker_off(i64, double, i64)

declare double @js_worker_threads_worker_add_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_remove_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_terminate(i64)

declare double @js_worker_threads_worker_ref(i64)

declare double @js_worker_threads_worker_unref(i64)

declare double @js_worker_threads_worker_get_heap_statistics(i64)

declare double @js_worker_threads_worker_cpu_usage(i64, double)

declare double @js_worker_threads_worker_get_heap_snapshot(i64, double)

declare double @js_worker_threads_worker_start_cpu_profile(i64)

declare double @js_worker_threads_worker_start_heap_profile(i64)

declare i64 @js_http_client_request_end(i64, double)

declare i64 @js_http_client_request_write(i64, double)

declare i64 @js_http_client_request_end_full(i64, double, i64, i64)

declare double @js_http_client_request_write_full(i64, double, i64, i64)

declare i64 @js_http_set_timeout_full(i64, double, i64)

declare i64 @js_http_client_request_method(i64)

declare i64 @js_http_client_request_protocol(i64)

declare i64 @js_http_client_request_host(i64)

declare i64 @js_http_client_request_path(i64)

declare double @js_http_client_request_listener_count(i64, i64)

declare double @js_http_client_request_get_header(i64, i64)

declare double @js_http_client_request_has_header(i64, i64)

declare double @js_http_client_request_remove_header(i64, i64)

declare double @js_http_client_request_get_header_names(i64)

declare double @js_http_client_request_get_headers(i64)

declare double @js_http_client_request_get_raw_header_names(i64)

declare double @js_http_client_request_abort(i64)

declare i64 @js_http_client_request_destroy(i64, double)

declare double @js_http_client_request_noop_undefined(i64, double, double)

declare double @js_http_client_request_aborted(i64)

declare double @js_http_client_request_destroyed(i64)

declare double @js_http_client_request_finished(i64)

declare double @js_http_client_request_reused_socket(i64)

declare double @js_http_client_request_max_headers_count(i64)

declare double @js_http_client_request_writable_ended(i64)

declare double @js_http_client_request_writable_finished(i64)

declare double @js_http_client_request_socket(i64)

declare i64 @js_http_get(double, i64)

declare i64 @js_http_get_overload(i64)

declare i64 @js_http_request_overload(i64)

declare i64 @js_https_get_overload(i64)

declare i64 @js_https_request_overload(i64)

declare i64 @js_http_on(i64, i64, i64)

declare i64 @js_http_once(i64, i64, i64)

declare i64 @js_http_request(double, i64)

declare i64 @js_http_request_body(i64)

declare double @js_http_request_body_length(i64)

declare i64 @js_http_request_content_type(i64)

declare double @js_http_request_has_header(i64, i64)

declare i64 @js_http_request_header(i64, i64)

declare i64 @js_http_request_headers_all(i64)

declare double @js_http_request_id(i64)

declare double @js_http_request_is_method(i64, i64)

declare i64 @js_http_request_method(i64)

declare i64 @js_http_request_path(i64)

declare i64 @js_http_request_query(i64)

declare i64 @js_http_request_query_all(i64)

declare i64 @js_http_request_query_param(i64, i64)

declare double @js_http_respond_error(i64, double, i64)

declare double @js_http_respond_html(i64, double, i64)

declare double @js_http_respond_json(i64, double, i64)

declare double @js_http_respond_not_found(i64)

declare double @js_http_respond_redirect(i64, i64, double)

declare i64 @js_http_respond_status_text(double)

declare double @js_http_respond_text(i64, double, i64)

declare double @js_http_respond_with_headers(i64, double, i64, i64)

declare double @js_http_response_headers(i64)

declare double @js_http_response_trailers(i64)

declare double @js_http_incoming_message_socket(i64)

declare double @js_http_incoming_message_req(i64)

declare i64 @js_http_incoming_message_set_encoding(i64, i64)

declare i64 @js_http_server_accept_v2(i64)

declare double @js_http_server_close(i64)

declare i64 @js_http_server_create(double)

declare i64 @js_http_set_header(i64, i64, i64)

declare i64 @js_http_set_timeout(i64, double)

declare double @js_http_status_code(i64)

declare i64 @js_http_status_message(i64)

declare i64 @js_http_agent_new(double)

declare i64 @js_https_agent_new(double)

declare i64 @js_http_agent_get_name(i64, double)

declare i64 @js_http_agent_noop_self(i64)

declare double @js_http_agent_max_sockets(i64)

declare double @js_http_agent_max_free_sockets(i64)

declare double @js_http_agent_max_total_sockets(i64)

declare double @js_http_agent_keep_alive_msecs(i64)

declare double @js_http_agent_keep_alive(i64)

declare i64 @js_http_agent_protocol(i64)

declare double @js_http_agent_default_port(i64)

declare void @js_http_agent_set_protocol(i64, i64)

declare i64 @js_http_agent_destroy(i64)

declare double @js_http_agent_destroyed(i64)

declare double @js_http_agent_sockets(i64)

declare double @js_http_agent_free_sockets(i64)

declare double @js_http_agent_requests(i64)

declare void @js_http_agent_set_max_sockets(i64, double)

declare void @js_http_agent_set_max_free_sockets(i64, double)

declare void @js_http_agent_set_max_total_sockets(i64, double)

declare void @js_http_agent_set_keep_alive(i64, double)

declare void @js_http_agent_set_keep_alive_msecs(i64, double)

declare void @js_http_agent_set_create_connection(i64, i64)

declare void @js_http_agent_set_create_socket(i64, i64)

declare i64 @js_http_agent_create_connection(i64)

declare i64 @js_http_agent_create_socket(i64)

declare i64 @js_https_get(double, i64)

declare i64 @js_https_request(double, i64)

declare i64 @js_node_http_create_server(i64)

declare i64 @js_node_http_server_listen(i64, i64)

declare void @js_node_http_server_close(i64, i64)

declare void @js_node_http_server_close_all_connections(i64)

declare void @js_node_http_server_close_idle_connections(i64)

declare i64 @js_node_http_server_address_json(i64)

declare i32 @js_node_http_server_listening(i64)

declare double @js_node_http_server_listening_value(i64)

declare double @js_node_http_server_on(i64, i64, i64)

declare i64 @js_node_http_im_method(i64)

declare i64 @js_node_http_im_url(i64)

declare i64 @js_node_http_im_http_version(i64)

declare i64 @js_node_http_im_headers_json(i64)

declare i64 @js_node_http_im_raw_headers_json(i64)

declare i64 @js_node_http_im_headers_distinct_json(i64)

declare i64 @js_node_http_im_trailers_json(i64)

declare i64 @js_node_http_im_raw_trailers_json(i64)

declare i64 @js_node_http_im_trailers_distinct_json(i64)

declare i32 @js_node_http_im_complete(i64)

declare i32 @js_node_http_im_aborted(i64)

declare i32 @js_node_http_im_destroyed(i64)

declare i64 @js_node_http_im_remote_address(i64)

declare double @js_node_http_im_remote_port(i64)

declare void @js_node_http_im_pause(i64)

declare void @js_node_http_im_resume(i64)

declare void @js_node_http_im_destroy(i64)

declare double @js_node_http_im_on(i64, i64, i64)

declare double @js_node_http_im_once(i64, i64, i64)

declare double @js_node_http_im_read(i64)

declare i64 @js_node_http_im_set_timeout(i64, double, i64)

declare void @js_node_http_res_set_status(i64, double)

declare double @js_node_http_res_get_status(i64)

declare void @js_node_http_res_set_status_message(i64, i64)

declare void @js_node_http_res_set_header(i64, i64, double)

declare i64 @js_node_http_res_set_header_self(i64, i64, double)

declare double @js_node_http_res_get_header(i64, i64)

declare void @js_node_http_res_remove_header(i64, i64)

declare i32 @js_node_http_res_has_header(i64, i64)

declare double @js_node_http_res_has_header_value(i64, i64)

declare i64 @js_node_http_res_get_headers_json(i64)

declare i64 @js_node_http_res_get_header_names_json(i64)

declare i64 @js_node_http_res_append_header(i64, i64, i64)

declare i64 @js_node_http_res_set_headers(i64, double)

declare double @js_node_http_res_get_status_message(i64)

declare i32 @js_node_http_res_headers_sent(i64)

declare i32 @js_node_http_res_writable_ended(i64)

declare i32 @js_node_http_res_writable_finished(i64)

declare i32 @js_node_http_res_finished(i64)

declare i32 @js_node_http_res_send_date(i64)

declare void @js_node_http_res_set_send_date(i64, double)

declare i32 @js_node_http_res_strict_content_length(i64)

declare void @js_node_http_res_set_strict_content_length(i64, double)

declare i64 @js_node_http_res_req_handle(i64)

declare void @js_node_http_res_write_head(i64, double, i64, i64)

declare i32 @js_node_http_res_write(i64, double)

declare double @js_node_http_res_write_full(i64, double, i64, i64)

declare void @js_node_http_res_add_trailers(i64, double)

declare void @js_node_http_res_end(i64, double)

declare void @js_node_http_res_end_full(i64, double, i64, i64)

declare void @js_node_http_res_flush_headers(i64)

declare void @js_node_http_res_cork(i64)

declare void @js_node_http_res_uncork(i64)

declare i64 @js_node_http_res_set_timeout(i64, double, i64)

declare void @js_node_http_res_write_early_hints(i64, double, i64)

declare void @js_node_http_res_write_continue(i64)

declare void @js_node_http_res_write_processing(i64)

declare double @js_node_http_res_on(i64, i64, i64)

declare i64 @js_node_https_create_server(double, i64)

declare i64 @js_node_https_server_listen(i64, i64)

declare void @js_node_https_server_close(i64, i64)

declare void @js_node_https_server_close_all_connections(i64)

declare void @js_node_https_server_close_idle_connections(i64)

declare i64 @js_node_https_server_address_json(i64)

declare double @js_node_https_server_on(i64, i64, i64)

declare double @js_node_https_server_listening_value(i64)

declare double @js_node_https_server_headers_timeout(i64)

declare double @js_node_https_server_set_headers_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout(i64)

declare double @js_node_https_server_set_keep_alive_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout_buffer(i64)

declare double @js_node_https_server_set_keep_alive_timeout_buffer(i64, double)

declare double @js_node_https_server_request_timeout(i64)

declare double @js_node_https_server_set_request_timeout(i64, double)

declare double @js_node_https_server_idle_timeout(i64)

declare double @js_node_https_server_set_idle_timeout(i64, double)

declare double @js_node_https_server_max_headers_count(i64)

declare double @js_node_https_server_set_max_headers_count(i64, double)

declare double @js_node_https_server_max_requests_per_socket(i64)

declare double @js_node_https_server_set_max_requests_per_socket(i64, double)

declare i64 @js_node_https_server_set_timeout_method(i64, double, i64)

declare i64 @js_node_http2_create_server(double, double)

declare i64 @js_node_http2_create_secure_server(double, i64)

declare i64 @js_node_http2_connect(double, double, i64)

declare i64 @js_node_http2_server_listen(i64, i64)

declare void @js_node_http2_server_close(i64, i64)

declare i64 @js_node_http2_server_address_json(i64)

declare double @js_node_http2_server_on(i64, i64, i64)

declare i64 @js_node_http2_get_default_settings()

declare i64 @js_node_http2_get_packed_settings(i64)

declare i64 @js_node_http2_get_unpacked_settings(i64)

declare i64 @js_pg_client_connect(i64)

declare i64 @js_pg_client_end(i64)

declare i64 @js_pg_client_new(i64)

declare i64 @js_pg_client_query(i64, i64)

declare i64 @js_pg_client_query_params(i64, i64, i64)

declare i64 @js_pg_connect(i64)

declare i64 @js_pg_create_pool(i64)

declare i64 @js_pg_pool_end(i64)

declare i64 @js_pg_pool_new(i64)

declare i64 @js_pg_pool_query(i64, i64)

declare i64 @js_ioredis_connect(i64)

declare i64 @js_ioredis_decr(i64, i64)

declare i64 @js_ioredis_del(i64, i64)

declare void @js_ioredis_disconnect(i64)

declare i64 @js_ioredis_exists(i64, i64)

declare i64 @js_ioredis_expire(i64, i64, double)

declare i64 @js_ioredis_get(i64, i64)

declare i64 @js_ioredis_hdel(i64, i64, i64)

declare i64 @js_ioredis_hget(i64, i64, i64)

declare i64 @js_ioredis_hgetall(i64, i64)

declare i64 @js_ioredis_hlen(i64, i64)

declare i64 @js_ioredis_hset(i64, i64, i64, i64)

declare i64 @js_ioredis_incr(i64, i64)

declare i64 @js_ioredis_new(i64)

declare i64 @js_ioredis_ping(i64)

declare i64 @js_ioredis_quit(i64)

declare i64 @js_ioredis_set(i64, i64, i64)

declare i64 @js_ioredis_setex(i64, i64, double, i64)

declare i64 @js_mongodb_client_close(i64)

declare i64 @js_mongodb_client_connect(i64)

declare i64 @js_mongodb_client_db(i64, i64)

declare i64 @js_mongodb_client_list_databases(i64)

declare i64 @js_mongodb_client_new(i64)

declare i64 @js_mongodb_collection_count_value(i64, double)

declare i64 @js_mongodb_collection_delete_many_value(i64, double)

declare i64 @js_mongodb_collection_delete_one_value(i64, double)

declare i64 @js_mongodb_collection_find_one_value(i64, double)

declare i64 @js_mongodb_collection_find_value(i64, double)

declare i64 @js_mongodb_collection_insert_many_value(i64, double)

declare i64 @js_mongodb_collection_insert_one_value(i64, double)

declare i64 @js_mongodb_collection_update_many_value(i64, double, double)

declare i64 @js_mongodb_collection_update_one_value(i64, double, double)

declare i64 @js_mongodb_collection_count(i64, i64)

declare i64 @js_mongodb_collection_delete_many(i64, i64)

declare i64 @js_mongodb_collection_delete_one(i64, i64)

declare i64 @js_mongodb_collection_find(i64, i64)

declare i64 @js_mongodb_collection_find_one(i64, i64)

declare i64 @js_mongodb_collection_insert_many(i64, i64)

declare i64 @js_mongodb_collection_insert_one(i64, i64)

declare i64 @js_mongodb_collection_update_many(i64, i64, i64)

declare i64 @js_mongodb_collection_update_one(i64, i64, i64)

declare i64 @js_mongodb_connect(i64)

declare i64 @js_mongodb_db_collection(i64, i64)

declare i64 @js_mongodb_db_list_collections(i64)

declare void @js_sqlite_close(i64)

declare void @js_sqlite_exec(i64, i64)

declare i64 @js_sqlite_open(i64)

declare i64 @js_sqlite_pragma(i64, i64, i64)

declare i64 @js_sqlite_prepare(i64, i64)

declare i64 @js_sqlite_stmt_all(i64, i64)

declare i64 @js_sqlite_stmt_columns(i64)

declare i64 @js_sqlite_stmt_get(i64, i64)

declare i64 @js_sqlite_stmt_run(i64, i64)

declare i64 @js_sqlite_transaction(i64, i64)

declare void @js_sqlite_transaction_commit(i64)

declare void @js_sqlite_transaction_rollback(i64)

declare i64 @js_bun_sqlite_database_call(double, double)

declare i64 @js_bun_sqlite_database_new(double, double)

declare i64 @js_bun_sqlite_database_query(i64, double)

declare i64 @js_bun_sqlite_database_run(i64, double, i64)

declare i64 @js_bun_sqlite_database_filename(i64)

declare i64 @js_bun_sqlite_database_transaction(i64, double)

declare i64 @js_bun_sqlite_statement_values(i64, i64)

declare double @js_bun_sqlite_statement_safe_integers(i64, double)

declare void @js_bun_sqlite_statement_finalize(i64)

declare i64 @js_node_sqlite_backup(double, double, double)

declare i64 @js_node_sqlite_database_sync_call(double, double)

declare i64 @js_node_sqlite_database_sync_new(double, double)

declare i32 @js_node_sqlite_database_sync_open(i64)

declare i32 @js_node_sqlite_database_sync_close(i64)

declare i32 @js_node_sqlite_database_sync_dispose(i64)

declare i32 @js_node_sqlite_database_sync_exec(i64, double)

declare i64 @js_node_sqlite_database_sync_prepare(i64, double, double)

declare i32 @js_node_sqlite_database_sync_function(i64, double, double, double)

declare i32 @js_node_sqlite_database_sync_aggregate(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_defensive(i64, double)

declare i32 @js_node_sqlite_database_sync_set_authorizer(i64, double)

declare i64 @js_node_sqlite_database_sync_create_tag_store(i64, double)

declare i64 @js_node_sqlite_database_sync_create_session(i64, double)

declare double @js_node_sqlite_database_sync_apply_changeset(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_load_extension(i64, double)

declare i32 @js_node_sqlite_database_sync_load_extension(i64, double)

declare double @js_node_sqlite_database_sync_location(i64, double)

declare double @js_node_sqlite_database_sync_is_open(i64)

declare double @js_node_sqlite_database_sync_is_transaction(i64)

declare i64 @js_node_sqlite_database_sync_limits(i64)

declare i64 @js_node_sqlite_statement_sync_call(double, double)

declare i64 @js_node_sqlite_statement_sync_new(double, double)

declare i64 @js_node_sqlite_statement_sync_run(i64, i64)

declare double @js_node_sqlite_statement_sync_get(i64, i64)

declare i64 @js_node_sqlite_statement_sync_all(i64, i64)

declare double @js_node_sqlite_statement_sync_iterate(i64, i64)

declare i64 @js_node_sqlite_statement_sync_columns(i64)

declare i32 @js_node_sqlite_statement_sync_set_read_bigints(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_return_arrays(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_bare_named_parameters(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_unknown_named_parameters(i64, double)

declare i64 @js_node_sqlite_statement_sync_source_sql(i64)

declare i64 @js_node_sqlite_statement_sync_expanded_sql(i64)

declare i64 @js_node_sqlite_sql_tag_store_run(i64, i64)

declare double @js_node_sqlite_sql_tag_store_get(i64, i64)

declare i64 @js_node_sqlite_sql_tag_store_all(i64, i64)

declare double @js_node_sqlite_sql_tag_store_iterate(i64, i64)

declare i32 @js_node_sqlite_sql_tag_store_clear(i64)

declare double @js_node_sqlite_sql_tag_store_size(i64)

declare double @js_node_sqlite_sql_tag_store_capacity(i64)

declare i64 @js_node_sqlite_sql_tag_store_db(i64)

declare i64 @js_node_sqlite_session_call(double, double)

declare i64 @js_node_sqlite_session_new(double, double)

declare i64 @js_node_sqlite_session_changeset(i64)

declare i64 @js_node_sqlite_session_patchset(i64)

declare i32 @js_node_sqlite_session_close(i64)

declare i32 @js_node_sqlite_session_dispose(i64)

declare i64 @js_os_cpus()

declare double @js_os_freemem()

declare i64 @js_os_homedir()

declare i64 @js_os_network_interfaces()

declare i64 @js_os_tmpdir()

declare double @js_os_totalmem()

declare double @js_os_uptime()

declare i64 @js_os_user_info()

declare i64 @js_os_user_info_buffer()

declare i64 @js_os_user_info_options(i64)

declare i64 @js_crypto_aes256_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_encrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_encrypt(i64, i64, i64)

declare double @js_crypto_create_cipheriv(i64, i64, i64, double)

declare double @js_crypto_create_decipheriv(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sha256(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sync(i64, i64, i64, i64, double)

declare i64 @js_crypto_pbkdf2(i64, i64, double, double)

declare i64 @js_crypto_random_bytes_hex(double)

declare i64 @js_crypto_random_nonce()

declare i64 @js_crypto_scrypt(i64, i64, double)

declare double @js_crypto_generate_key_pair_sync(i64, i64)

declare i64 @js_crypto_scrypt_custom(i64, i64, double, double, double, double)

declare i64 @js_crypto_x25519_keypair()

declare i64 @js_crypto_x25519_shared_secret(i64, i64)

declare i64 @js_keccak256_native(i64)

declare i64 @js_keccak256_native_bytes(i64)

declare i64 @js_nanoid(double)

declare i64 @js_nanoid_custom(i64, double)

declare i64 @js_argon2_hash(i64)

declare i64 @js_argon2_hash_options(i64, i64)

declare i64 @js_argon2_verify(i64, i64)

declare i64 @js_bcrypt_compare(i64, i64)

declare double @js_bcrypt_compare_sync(i64, i64)

declare i64 @js_bcrypt_gen_salt(double)

declare i64 @js_bcrypt_hash(i64, double)

declare i64 @js_bcrypt_hash_sync(i64, double)

declare i64 @js_ads_interstitial_load(i64)

declare i64 @js_ads_interstitial_show()

declare i64 @js_ads_rewarded_load(i64)

declare i64 @js_ads_rewarded_show()

declare double @js_ads_banner_create(i64, i64)

declare void @js_ads_banner_destroy(double)

declare i64 @js_ads_request_consent()

declare i64 @js_perry_read_embedded(double)

declare i64 @js_perry_embedded_files()

declare double @js_thread_parallel_map(double, double)

declare double @js_thread_parallel_filter(double, double)

declare double @js_thread_spawn(double)

declare double @js_perry_native_i8(double)

declare double @js_perry_native_i16(double)

declare double @js_perry_native_u8(double)

declare double @js_perry_native_u16(double)

declare double @js_perry_native_i32(double)

declare double @js_perry_native_i64(double)

declare double @js_perry_native_u32(double)

declare double @js_perry_native_u64(double)

declare double @js_perry_native_usize(double)

declare double @js_perry_native_isize(double)

declare double @js_perry_native_f32(double)

declare double @js_perry_native_f64(double)

declare i64 @js_jwt_decode(i64)

declare i64 @js_jwt_sign(i64, i64, double, i64)

declare i64 @js_jwt_sign_es256(i64, i64, double, i64)

declare i64 @js_jwt_sign_rs256(i64, i64, double, i64)

declare i64 @js_jwt_verify(i64, i64)

declare i64 @js_jwt_verify_es256(i64, i64)

declare i64 @js_jwt_verify_rs256(i64, i64)

declare i64 @js_jwt_sign_dyn(i64, i64, i64, double, i64)

declare i64 @js_jwt_verify_dyn(i64, i64, i64)

declare i64 @js_jwt_sign_dyn_opts(i64, i64, double)

declare i64 @js_jwt_verify_dyn_opts(i64, i64, double)

declare double @js_axios_create(i64)

declare i64 @js_axios_delete(i64)

declare i64 @js_axios_get(i64)

declare i64 @js_axios_head(i64)

declare i64 @js_axios_options(i64)

declare i64 @js_axios_post(i64, double)

declare i64 @js_axios_put(i64, double)

declare i64 @js_axios_patch(i64, double)

declare i64 @js_axios_request(i64)

declare double @js_axios_response_status(i64)

declare i64 @js_axios_response_status_text(i64)

declare i64 @js_axios_response_data(i64)

declare double @js_axios_response_data_parsed(i64)

declare i64 @js_sharp_auto_orient(i64)

declare i64 @js_sharp_avif(i64, double)

declare i64 @js_sharp_blur(i64, double)

declare i64 @js_sharp_composite(i64, double)

declare i64 @js_sharp_extend(i64, double)

declare i64 @js_sharp_extract(i64, double)

declare i64 @js_sharp_flip(i64)

declare i64 @js_sharp_flop(i64)

declare i64 @js_sharp_from_buffer(i64, double)

declare i64 @js_sharp_from_file(i64)

declare i64 @js_sharp_from_input(i64)

declare i64 @js_sharp_grayscale(i64)

declare i64 @js_sharp_metadata(i64)

declare i64 @js_sharp_sharpen(i64)

declare i64 @js_sharp_trim(i64)

declare i64 @js_sharp_negate(i64)

declare i64 @js_sharp_quality(i64, double)

declare i64 @js_sharp_resize(i64, double, double)

declare i64 @js_sharp_rotate(i64, double)

declare i64 @js_sharp_to_buffer(i64)

declare i64 @js_sharp_to_file(i64, i64)

declare i64 @js_sharp_to_format(i64, i64)

declare void @js_cron_clear_interval(i64)

declare void @js_cron_clear_timeout(i64)

declare i64 @js_cron_describe(i64)

declare double @js_cron_job_is_running(i64)

declare i64 @js_cron_job_new(i64, i64, double)

declare void @js_cron_job_start(i64)

declare void @js_cron_job_stop(i64)

declare i64 @js_cron_next_date(i64)

declare i64 @js_cron_next_dates(i64, double)

declare i64 @js_cron_schedule(i64, i64)

declare i64 @js_cron_set_interval(double, double)

declare i64 @js_cron_set_timeout(double, double)

declare i32 @js_cron_timer_has_pending()

declare i32 @js_cron_timer_tick()

declare double @js_cron_validate(i64)

declare i64 @js_async_hooks_create_hook(double)

declare double @js_async_hooks_execution_async_id()

declare double @js_async_hooks_trigger_async_id()

declare double @js_async_hooks_execution_async_resource()

declare i64 @js_async_hook_enable(i64)

declare i64 @js_async_hook_disable(i64)

declare i64 @js_async_resource_new(double, double)

declare double @js_async_resource_subclass_init(double, double, double)

declare double @js_async_resource_async_id(i64)

declare double @js_async_resource_trigger_async_id(i64)

declare i64 @js_async_resource_emit_destroy(i64)

declare double @js_async_resource_run_in_async_scope(i64, double, double, i64)

declare i64 @js_async_resource_bind(i64, double, double)

declare i64 @js_async_resource_static_bind(i64, double)

declare void @js_async_local_storage_disable(i64)

declare void @js_async_local_storage_enter_with(i64, double)

declare double @js_async_local_storage_exit(i64, double, i64)

declare double @js_async_local_storage_get_store(i64)

declare i64 @js_async_local_storage_new()

declare double @js_async_local_storage_subclass_init(double)

declare double @js_async_local_storage_run(i64, double, double, i64)

declare i64 @js_disposable_stack_new()

declare i64 @js_async_disposable_stack_new()

declare double @js_suppressed_error_new(double, double, double)

declare i64 @js_zlib_deflate_sync(i64, double)

declare void @js_zlib_deflate(double, double)

declare i64 @js_zlib_gunzip_sync(i64)

declare void @js_zlib_gunzip(double, double)

declare i64 @js_zlib_gzip_sync(i64, double)

declare void @js_zlib_gzip(double, double)

declare i64 @js_zlib_inflate_sync(i64)

declare void @js_zlib_inflate(double, double)

declare i64 @js_zlib_deflate_raw_sync(double, double)

declare void @js_zlib_deflate_raw(double, double)

declare i64 @js_zlib_inflate_raw_sync(double)

declare void @js_zlib_inflate_raw(double, double)

declare i64 @js_zlib_unzip_sync(double)

declare void @js_zlib_unzip(double, double)

declare double @js_zlib_crc32(double, double)

declare i64 @js_zlib_brotli_compress_sync(i64)

declare i64 @js_zlib_brotli_decompress_sync(i64)

declare void @js_zlib_brotli_compress(double, double)

declare void @js_zlib_brotli_decompress(double, double)

declare i64 @js_zlib_zstd_compress_sync(double, double)

declare i64 @js_zlib_zstd_decompress_sync(double, double)

declare void @js_zlib_zstd_compress(double, double)

declare void @js_zlib_zstd_decompress(double, double)

declare i64 @js_zlib_create_gzip(double)

declare i64 @js_zlib_create_gunzip(double)

declare i64 @js_zlib_create_deflate(double)

declare i64 @js_zlib_create_inflate(double)

declare i64 @js_zlib_create_deflate_raw(double)

declare i64 @js_zlib_create_inflate_raw(double)

declare i64 @js_zlib_create_unzip(double)

declare i64 @js_zlib_create_brotli_compress(double)

declare i64 @js_zlib_create_zstd_compress(double)

declare i64 @js_zlib_create_zstd_decompress(double)

declare i64 @js_buffer_alloc_unsafe(i32)

declare i32 @js_buffer_byte_length(i64)

declare i32 @js_buffer_byte_length_value(double, double)

declare i64 @js_buffer_concat(i64)

declare i64 @js_buffer_concat_with_length(i64, double)

declare i32 @js_buffer_validate_size(double)

declare i64 @js_buffer_validate_concat_list(double)

declare i32 @js_buffer_copy(i64, i64, i32, i32, i32)

declare i32 @js_buffer_equals(i64, i64)

declare i64 @js_buffer_fill(i64, i32)

declare i64 @js_buffer_from_value(i64, i32)

declare double @js_buffer_is_ascii(double)

declare i32 @js_buffer_is_buffer(i64)

declare i32 @js_buffer_is_node_buffer(i64)

declare i32 @js_buffer_is_encoding(double)

declare double @js_buffer_is_utf8(double)

declare void @js_buffer_print(i64)

declare void @js_buffer_set(i64, i32, i32)

declare void @js_buffer_set_from(i64, i64, i32)

declare i64 @js_buffer_slice(i64, i32, i32)

declare i64 @js_buffer_to_string(i64, i32)

declare i64 @js_buffer_transcode(double, double, double)

declare i32 @js_buffer_write(i64, i64, i32, i32)

declare double @js_child_process_exec_sync(i64, i64)

declare double @js_child_process_exec(i64, double, double)

declare i64 @js_child_process_get_process_status(double)

declare i32 @js_child_process_kill_process(double)

declare i64 @js_child_process_spawn_background(double, i64, double, double)

declare i64 @js_child_process_spawn_sync(i64, i64, i64)

declare double @js_child_process_spawn_streams(i64, i64, i64)

declare double @js_pty_spawn(i64, i64, i64)

declare double @js_child_process_fork(i64, i64, i64)

declare double @js_child_process_exec_file(i64, double, double, double)

declare double @js_child_process_exec_file_sync(i64, double, double)

declare double @js_child_process_validate_command(double, ptr, i32)

declare double @js_child_process_validate_args(double)

declare double @js_child_process_validate_options(double, i32, i32)

declare double @js_child_process_validate_fork_module(double)

declare double @js_child_process_validate_spawn_args(double, i32, i32)

declare double @js_child_process_new()

declare i64 @js_cheerio_load(i64)

declare i64 @js_cheerio_load_fragment(i64)

declare i64 @js_cheerio_select(i64, i64)

declare i64 @js_cheerio_selection_attr(i64, i64)

declare i64 @js_cheerio_selection_attrs(i64, i64)

declare i64 @js_cheerio_selection_children(i64, i64)

declare i64 @js_cheerio_selection_eq(i64, double)

declare i64 @js_cheerio_selection_find(i64, i64)

declare i64 @js_cheerio_selection_first(i64)

declare double @js_cheerio_selection_has_class(i64, i64)

declare i64 @js_cheerio_selection_html(i64)

declare double @js_cheerio_selection_is(i64, i64)

declare i64 @js_cheerio_selection_last(i64)

declare double @js_cheerio_selection_length(i64)

declare i64 @js_cheerio_selection_parent(i64)

declare i64 @js_cheerio_selection_text(i64)

declare i64 @js_cheerio_selection_texts(i64)

declare i64 @js_cheerio_selection_to_array(i64)

declare double @js_url_file_url_to_path(double, double)

declare double @js_url_file_url_to_path_buffer(double, double)

declare double @js_url_get_hash(i64)

declare double @js_url_get_host(i64)

declare double @js_url_get_hostname(i64)

declare double @js_url_get_href(i64)

declare double @js_url_get_origin(i64)

declare double @js_url_get_pathname(i64)

declare double @js_url_get_port(i64)

declare double @js_url_get_protocol(i64)

declare double @js_url_get_search(i64)

declare double @js_url_get_search_params(i64)

declare i64 @js_url_new(i64)

declare i64 @js_url_new_with_base(i64, i64)

declare i64 @js_url_pattern_new(double, double)

declare double @js_url_pattern_constructor_call(double, double)

declare i32 @js_url_can_parse(i64)

declare i32 @js_url_can_parse_with_base(i64, i64)

declare i64 @js_url_parse(i64)

declare i64 @js_url_parse_with_base(i64, i64)

declare void @js_url_set_pathname(i64, double)

declare void @js_url_set_search(i64, double)

declare void @js_url_set_hash(i64, double)

declare void @js_url_set_protocol(i64, double)

declare void @js_url_set_hostname(i64, double)

declare void @js_url_set_port(i64, double)

declare void @js_url_set_username(i64, double)

declare void @js_url_set_password(i64, double)

declare void @js_url_set_href(i64, double)

declare double @js_url_search_params_has2(i64, double, double)

declare void @js_url_search_params_delete2(i64, double, double)

declare double @js_url_search_params_throw_missing_args(i32)

declare void @js_url_search_params_append(i64, double, double)

declare void @js_url_search_params_delete(i64, double)

declare i64 @js_url_search_params_get(i64, double)

declare double @js_url_search_params_get_all(i64, double)

declare double @js_url_search_params_has(i64, double)

declare i64 @js_url_search_params_new(i64)

declare i64 @js_url_search_params_new_any(double)

declare i64 @js_url_search_params_new_empty()

declare double @js_url_search_params_subclass_init(double, double)

declare void @js_url_search_params_set(i64, double, double)

declare i64 @js_url_search_params_to_string(i64)

declare i32 @js_url_search_params_size(i64)

declare double @js_url_search_params_entries_arr(i64)

declare double @js_url_search_params_keys_arr(i64)

declare double @js_url_search_params_values_arr(i64)

declare void @js_url_search_params_sort(i64)

declare void @js_url_search_params_for_each(i64, double, double)

declare i64 @js_url_coerce_string(double)

declare double @js_url_path_to_file_url(double, double)

declare double @js_url_domain_to_ascii(double)

declare double @js_url_domain_to_unicode(double)

declare double @js_url_to_http_options(double)

declare double @js_url_legacy_url_new()

declare double @js_url_format(double, double)

declare double @js_url_legacy_parse(double, double, double)

declare double @js_url_legacy_resolve(double, double)

declare double @js_url_legacy_resolve_object(double, double)

declare void @js_ws_close(i64)

declare i64 @js_ws_connect(i64)

declare double @js_ws_connect_start(double)

declare i64 @js_ws_handle_to_i64(double)

declare double @js_ws_is_open(i64)

declare double @js_ws_message_count(i64)

declare double @js_ws_ready_state(i64)

declare i64 @js_ws_on(i64, i64, i64)

declare i64 @js_ws_receive(i64)

declare void @js_ws_send(i64, i64)

declare void @js_ws_send_to_client(double, i64)

declare void @js_ws_close_client(double)

declare void @js_ws_send_client_i64(i64, i64)

declare void @js_ws_close_client_i64(i64)

declare i64 @js_ws_on_client_i64(i64, i64, i64)

declare void @js_ws_server_close(i64)

declare double @js_ws_server_clients(i64)

declare double @js_ws_server_address(i64)

declare i32 @js_ws_server_emit(i64, i64, double, double)

declare i64 @js_ws_server_new(double)

declare void @js_ws_handle_upgrade(i64, double, double, double, i64)

declare i64 @js_ws_wait_for_message(i64, double)

declare i64 @js_pdf_create_pdf(double)

declare void @js_pdf_add_text(i64, i64, double, double, double)

declare void @js_pdf_add_line(i64, double, double, double, double)

declare void @js_pdf_new_page(i64)

declare void @js_pdf_save(i64)

declare i64 @js_commander_action(i64, i64)

declare i64 @js_commander_command(i64, i64)

declare i64 @js_commander_description(i64, i64)

declare i64 @js_commander_get_option(i64, i64)

declare double @js_commander_get_option_bool(i64, i64)

declare double @js_commander_get_option_number(i64, i64)

declare i64 @js_commander_name(i64, i64)

declare i64 @js_commander_new()

declare i64 @js_commander_option(i64, i64, i64, i64)

declare i64 @js_commander_opts(i64)

declare i64 @js_commander_parse(i64, double)

declare i64 @js_commander_required_option(i64, i64, i64, i64)

declare i64 @js_commander_version(i64, i64)

declare double @js_dotenv_config()

declare double @js_dotenv_config_path(i64)

declare i64 @js_dotenv_parse(i64)

declare double @js_datefns_add_days(double, double)

declare double @js_datefns_add_months(double, double)

declare double @js_datefns_add_years(double, double)

declare double @js_datefns_difference_in_days(double, double)

declare double @js_datefns_difference_in_hours(double, double)

declare double @js_datefns_difference_in_minutes(double, double)

declare double @js_datefns_end_of_day(double)

declare i64 @js_datefns_format(double, i64)

declare double @js_datefns_is_after(double, double)

declare double @js_datefns_is_before(double, double)

declare double @js_datefns_parse_iso(i64)

declare double @js_datefns_start_of_day(double)

declare double @js_dayjs_add(i64, double, i64)

declare double @js_dayjs_date(i64)

declare double @js_dayjs_day(i64)

declare double @js_dayjs_diff(i64, i64, i64)

declare double @js_dayjs_end_of(i64, i64)

declare double @js_dayjs_factory(i64)

declare i64 @js_dayjs_format(i64, i64)

declare double @js_dayjs_from_timestamp(double)

declare double @js_dayjs_hour(i64)

declare double @js_dayjs_is_after(i64, i64)

declare double @js_dayjs_is_before(i64, i64)

declare double @js_dayjs_is_same(i64, i64)

declare double @js_dayjs_is_valid(i64)

declare double @js_dayjs_millisecond(i64)

declare double @js_dayjs_minute(i64)

declare double @js_dayjs_month(i64)

declare double @js_dayjs_now()

declare double @js_dayjs_parse(i64)

declare double @js_dayjs_second(i64)

declare double @js_dayjs_start_of(i64, i64)

declare double @js_dayjs_subtract(i64, double, i64)

declare i64 @js_dayjs_to_iso_string(i64)

declare double @js_dayjs_unix(i64)

declare double @js_dayjs_value_of(i64)

declare double @js_dayjs_year(i64)

declare double @js_moment_add(i64, double, i64)

declare double @js_moment_clone(i64)

declare double @js_moment_date(i64)

declare double @js_moment_day(i64)

declare double @js_moment_diff(i64, i64, i64)

declare double @js_moment_end_of(i64, i64)

declare double @js_moment_factory(i64)

declare i64 @js_moment_format(i64, i64)

declare i64 @js_moment_from_now(i64)

declare double @js_moment_from_timestamp(double)

declare double @js_moment_hour(i64)

declare double @js_moment_is_after(i64, i64)

declare double @js_moment_is_before(i64, i64)

declare double @js_moment_is_between(i64, i64, i64)

declare double @js_moment_is_same(i64, i64, i64)

declare double @js_moment_is_valid(i64)

declare double @js_moment_millisecond(i64)

declare double @js_moment_minute(i64)

declare double @js_moment_month(i64)

declare double @js_moment_now()

declare double @js_moment_parse(i64)

declare double @js_moment_second(i64)

declare double @js_moment_start_of(i64, i64)

declare double @js_moment_subtract(i64, double, i64)

declare double @js_moment_to_date(i64)

declare i64 @js_moment_to_iso_string(i64)

declare double @js_moment_unix(i64)

declare double @js_moment_value_of(i64)

declare double @js_moment_year(i64)

declare i64 @js_decimal_abs(i64)

declare i64 @js_decimal_ceil(i64)

declare double @js_decimal_cmp(i64, i64)

declare double @js_decimal_cmp_value(i64, double)

declare i64 @js_decimal_coerce_to_handle(double)

declare i64 @js_decimal_div(i64, i64)

declare i64 @js_decimal_div_number(i64, double)

declare i64 @js_decimal_div_value(i64, double)

declare double @js_decimal_eq(i64, i64)

declare double @js_decimal_eq_value(i64, double)

declare i64 @js_decimal_floor(i64)

declare i64 @js_decimal_from_number(double)

declare i64 @js_decimal_from_string(i64)

declare double @js_decimal_gt(i64, i64)

declare double @js_decimal_gt_value(i64, double)

declare double @js_decimal_gte(i64, i64)

declare double @js_decimal_gte_value(i64, double)

declare double @js_decimal_is_negative(i64)

declare double @js_decimal_is_positive(i64)

declare double @js_decimal_is_zero(i64)

declare double @js_decimal_lt(i64, i64)

declare double @js_decimal_lt_value(i64, double)

declare double @js_decimal_lte(i64, i64)

declare double @js_decimal_lte_value(i64, double)

declare i64 @js_decimal_minus(i64, i64)

declare i64 @js_decimal_minus_number(i64, double)

declare i64 @js_decimal_minus_value(i64, double)

declare i64 @js_decimal_mod(i64, i64)

declare i64 @js_decimal_mod_value(i64, double)

declare i64 @js_decimal_neg(i64)

declare i64 @js_decimal_plus(i64, i64)

declare i64 @js_decimal_plus_number(i64, double)

declare i64 @js_decimal_plus_value(i64, double)

declare i64 @js_decimal_pow(i64, double)

declare i64 @js_decimal_round(i64)

declare i64 @js_decimal_sqrt(i64)

declare i64 @js_decimal_times(i64, i64)

declare i64 @js_decimal_times_number(i64, double)

declare i64 @js_decimal_times_value(i64, double)

declare i64 @js_decimal_to_fixed(i64, double)

declare double @js_decimal_to_number(i64)

declare i64 @js_decimal_to_string(i64)

declare i64 @js_ethers_format_ether(i64)

declare i64 @js_ethers_format_units(i64, double)

declare i64 @js_ethers_get_address(i64)

declare i64 @js_ethers_parse_ether(i64)

declare i64 @js_ethers_parse_units(i64, double)

declare i64 @js_lodash_camel_case(i64)

declare i64 @js_lodash_capitalize(i64)

declare i64 @js_lodash_chunk(i64, double)

declare double @js_lodash_clamp(double, double, double)

declare i64 @js_lodash_compact(i64)

declare i64 @js_lodash_concat(i64, i64)

declare i64 @js_lodash_difference(i64, i64)

declare i64 @js_lodash_drop(i64, double)

declare i64 @js_lodash_drop_right(i64, double)

declare double @js_lodash_ends_with(i64, i64)

declare i64 @js_lodash_escape(i64)

declare double @js_lodash_first(i64)

declare i64 @js_lodash_flatten(i64)

declare double @js_lodash_in_range(double, double, double)

declare double @js_lodash_includes(i64, i64)

declare i64 @js_lodash_initial(i64)

declare i64 @js_lodash_kebab_case(i64)

declare double @js_lodash_last(i64)

declare i64 @js_lodash_lower_case(i64)

declare i64 @js_lodash_lower_first(i64)

declare double @js_lodash_max(i64)

declare double @js_lodash_max_by(i64, double)

declare double @js_lodash_mean(i64)

declare double @js_lodash_mean_by(i64, double)

declare double @js_lodash_min(i64)

declare double @js_lodash_min_by(i64, double)

declare i64 @js_lodash_pad(i64, double)

declare i64 @js_lodash_pad_end(i64, double)

declare i64 @js_lodash_pad_start(i64, double)

declare double @js_lodash_random(double, double)

declare i64 @js_lodash_repeat(i64, double)

declare i64 @js_lodash_replace(i64, i64, i64)

declare i64 @js_lodash_reverse(i64)

declare double @js_lodash_size(i64)

declare i64 @js_lodash_snake_case(i64)

declare i64 @js_lodash_split(i64, i64)

declare i64 @js_lodash_start_case(i64)

declare double @js_lodash_starts_with(i64, i64)

declare double @js_lodash_sum(i64)

declare double @js_lodash_sum_by(i64, double)

declare i64 @js_lodash_tail(i64)

declare i64 @js_lodash_take(i64, double)

declare i64 @js_lodash_take_right(i64, double)

declare i64 @js_lodash_trim(i64)

declare i64 @js_lodash_trim_end(i64)

declare i64 @js_lodash_trim_start(i64)

declare i64 @js_lodash_truncate(i64, double)

declare i64 @js_lodash_unescape(i64)

declare i64 @js_lodash_uniq(i64)

declare i64 @js_lodash_upper_case(i64)

declare i64 @js_lodash_upper_first(i64)

declare void @js_lru_cache_clear(i64)

declare double @js_lru_cache_delete(i64, double)

declare double @js_lru_cache_get(i64, double)

declare double @js_lru_cache_has(i64, double)

declare i64 @js_lru_cache_new(double)

declare double @js_lru_cache_peek(i64, double)

declare i64 @js_lru_cache_set(i64, double, double)

declare double @js_lru_cache_size(i64)

declare double @js_event_emitter_subclass_init(double)

declare double @js_event_emitter_async_resource_subclass_init(double, double)

declare double @js_array_subclass_init(double, double)

declare double @js_array_subclass_init_args(double, ptr, i64)

declare double @js_map_set_subclass_init(double, i32, double)

declare double @js_weak_collection_subclass_init(double, i32, double)

declare double @js_promise_subclass_init(double, double)

declare double @js_node_stream_readable_new(double)

declare double @js_node_stream_readable_subclass_init(double, double)

declare double @js_node_stream_writable_new(double)

declare double @js_node_stream_writable_subclass_init(double, double)

declare double @js_node_stream_duplex_new(double)

declare double @js_node_stream_duplex_subclass_init(double, double)

declare double @js_node_stream_transform_new(double)

declare double @js_node_stream_transform_subclass_init(double, double)

declare double @js_node_stream_passthrough_new(double)

declare double @js_node_stream_readable_from(double)

declare double @js_node_stream_readable_from_options(double, double)

declare double @js_node_stream_duplex_from_options(double, double)

declare double @js_node_stream_is_disturbed(double)

declare double @js_node_stream_is_errored(double)

declare double @js_node_stream_is_readable(double)

declare double @js_node_stream_is_writable(double)

declare double @js_node_stream_is_array_buffer_view(double)

declare double @js_node_stream_is_uint8_array(double)

declare double @js_node_stream_is_destroyed(double)

declare double @js_node_stream_uint8_array_to_buffer(double)

declare double @js_node_stream_get_default_hwm(double)

declare double @js_node_stream_set_default_hwm(double, double)

declare double @js_node_stream_add_abort_signal(double, double)

declare double @js_node_stream_compose(i64)

declare double @js_node_stream_pipeline(i64)

declare double @js_node_stream_finished(i64)

declare double @js_node_stream_duplex_pair(double)

declare double @js_node_stream_readable_to_web(double)

declare double @js_node_stream_writable_to_web(double)

declare double @js_node_stream_duplex_to_web(double)

declare double @js_node_stream_readable_from_web(double, double)

declare double @js_node_stream_writable_from_web(double, double)

declare double @js_node_stream_duplex_from_web(double, double)

declare double @js_node_stream_to_web(double)

declare double @js_node_stream_from_web(double)

declare double @js_node_stream_method_readable_aborted(i64)

declare double @js_node_stream_method_closed(i64)

declare double @js_node_stream_method_errored(i64)

declare double @js_node_stream_method_readable_did_read(i64)

declare double @js_node_stream_method_destroyed(i64)

declare double @js_node_stream_method_destroy(i64, double)

declare double @js_node_stream_method_pause(i64)

declare double @js_node_stream_method_readable(i64)

declare double @js_node_stream_method_readable_length(i64)

declare double @js_node_stream_method_readable_flowing(i64)

declare double @js_node_stream_method_readable_ended(i64)

declare double @js_node_stream_method_readable_object_mode(i64)

declare double @js_node_stream_method_pipe(i64, double, double)

declare double @js_node_stream_method_unpipe(i64, double)

declare double @js_node_stream_method_is_paused(i64)

declare double @js_node_stream_method_resume(i64)

declare double @js_node_stream_method_readable_encoding(i64)

declare double @js_node_stream_method_cork(i64)

declare double @js_node_stream_method_uncork(i64)

declare double @js_node_stream_method_writable_corked(i64)

declare double @js_node_stream_method_writable_length(i64)

declare double @js_node_stream_method_writable_need_drain(i64)

declare double @js_node_stream_method_writable(i64)

declare double @js_node_stream_method_writable_ended(i64)

declare double @js_node_stream_method_writable_finished(i64)

declare double @js_node_stream_method_allow_half_open(i64)

declare double @js_node_stream_method_set_encoding(i64, double)

declare double @js_node_stream_method_writable_object_mode(i64)

declare double @js_event_emitter_emit(i64, i64, i64)

declare double @js_event_emitter_emit0(i64, i64)

declare double @js_event_emitter_listener_count(i64, i64, i64)

declare i64 @js_event_emitter_new()

declare i64 @js_event_emitter_new_with_options(double)

declare i64 @js_event_emitter_on(i64, i64, i64)

declare i64 @js_event_emitter_once(i64, i64, i64)

declare i64 @js_event_emitter_prepend_listener(i64, i64, i64)

declare i64 @js_event_emitter_prepend_once_listener(i64, i64, i64)

declare i64 @js_event_emitter_remove_all_listeners(i64, i64)

declare i64 @js_event_emitter_remove_listener(i64, i64, i64)

declare i64 @js_event_emitter_set_max_listeners(i64, double)

declare double @js_event_emitter_get_max_listeners(i64)

declare i64 @js_event_emitter_event_names(i64)

declare i64 @js_event_emitter_listeners(i64, i64)

declare i64 @js_event_emitter_raw_listeners(i64, i64)

declare double @js_event_emitter_domain_value(i64)

declare i64 @js_event_emitter_async_resource_new(double)

declare double @js_event_emitter_async_resource_call(double)

declare double @js_event_emitter_async_resource_async_id(i64)

declare double @js_event_emitter_async_resource_trigger_async_id(i64)

declare double @js_event_emitter_async_resource_async_resource(i64)

declare double @js_event_emitter_async_resource_emit_destroy(i64)

declare i64 @js_events_once(double, i64, double)

declare i64 @js_events_on(double, i64, double)

declare i64 @js_events_add_abort_listener(double, double)

declare i64 @js_events_get_event_listeners(double, i64)

declare double @js_events_listener_count(double, i64)

declare double @js_events_get_max_listeners(double)

declare double @js_events_set_max_listeners(double, i64)

declare double @js_events_init()

declare i64 @js_domain_create()

declare i64 @js_domain_on(i64, i64, i64)

declare double @js_domain_emit(i64, i64, i64)

declare double @js_domain_run(i64, double, i64)

declare double @js_domain_bind(i64, double)

declare double @js_domain_intercept(i64, double)

declare i64 @js_domain_add(i64, double)

declare i64 @js_domain_remove(i64, double)

declare double @js_domain_enter(i64)

declare double @js_domain_exit(i64)

declare i64 @js_string_decoder_new(i64)

declare double @js_string_decoder_write(i64, double)

declare double @js_string_decoder_end(i64, double)

declare double @js_querystring_escape(double)

declare double @js_querystring_unescape(double)

declare i64 @js_querystring_unescape_buffer(double, double)

declare i64 @js_querystring_parse(double, double, double, double)

declare double @js_querystring_stringify(double, double, double, double)

declare i32 @js_fastify_add_hook(i64, i64, i64)

declare i32 @js_fastify_all(i64, i64, i64)

declare i64 @js_fastify_create()

declare i64 @js_fastify_create_with_opts(double)

declare double @js_fastify_ctx_html(i64, i64, double)

declare double @js_fastify_ctx_json(i64, double, double)

declare double @js_fastify_ctx_redirect(i64, i64, double)

declare double @js_fastify_ctx_text(i64, i64, double)

declare i32 @js_fastify_delete(i64, i64, i64)

declare i32 @js_fastify_get(i64, i64, i64)

declare i32 @js_fastify_head(i64, i64, i64)

declare void @js_fastify_listen(i64, double, i64)

declare void @js_fastify_app_close(i64)

declare i64 @js_fastify_app_server(i64)

declare void @js_fastify_app_on(i64, i64, i64)

declare i32 @js_fastify_options(i64, i64, i64)

declare i32 @js_fastify_patch(i64, i64, i64)

declare i32 @js_fastify_post(i64, i64, i64)

declare i32 @js_fastify_put(i64, i64, i64)

declare i32 @js_fastify_register(i64, i64, double)

declare i64 @js_fastify_reply_header(i64, i64, i64)

declare i32 @js_fastify_reply_send(i64, double)

declare i64 @js_fastify_reply_status(i64, double)

declare i64 @js_fastify_reply_type(i64, i64)

declare i64 @js_fastify_req_body(i64)

declare double @js_fastify_req_get_user_data(i64)

declare i64 @js_fastify_req_header(i64, i64)

declare i64 @js_fastify_req_headers(i64)

declare double @js_fastify_req_json(i64)

declare i64 @js_fastify_req_method(i64)

declare i64 @js_fastify_req_param(i64, i64)

declare i64 @js_fastify_req_params(i64)

declare i64 @js_fastify_req_query(i64)

declare double @js_fastify_req_query_object(i64)

declare void @js_fastify_req_set_user_data(i64, double)

declare i64 @js_fastify_req_url(i64)

declare i32 @js_fastify_route(i64, i64, i64, i64)

declare i32 @js_fastify_set_error_handler(i64, i64)

declare double @js_nodemailer_create_transport(i64)

declare i64 @js_nodemailer_send_mail(i64, i64)

declare i64 @js_nodemailer_verify(i64)

declare i64 @js_ratelimit_block(i64, i64, double)

declare i64 @js_ratelimit_consume(i64, i64, double)

declare i64 @js_ratelimit_create(i64)

declare i64 @js_ratelimit_delete(i64, i64)

declare i64 @js_ratelimit_get(i64, i64)

declare i64 @js_ratelimit_new_from_options(i64)

declare i64 @js_ratelimit_penalty(i64, i64, double)

declare i64 @js_ratelimit_reward(i64, i64, double)

declare double @js_validator_contains(i64, i64)

declare double @js_validator_equals(i64, i64)

declare double @js_validator_is_alpha(i64)

declare double @js_validator_is_alphanumeric(i64)

declare double @js_validator_is_email(i64)

declare double @js_validator_is_empty(i64)

declare double @js_validator_is_float(i64)

declare double @js_validator_is_hexadecimal(i64)

declare double @js_validator_is_int(i64)

declare double @js_validator_is_json(i64)

declare double @js_validator_is_length(i64, double, double)

declare double @js_validator_is_lowercase(i64)

declare double @js_validator_is_numeric(i64)

declare double @js_validator_is_uppercase(i64)

declare double @js_validator_is_url(i64)

declare double @js_validator_is_uuid(i64)

declare i64 @js_date_to_locale_string(double)

declare i64 @js_number_to_locale_string(double)

declare double @js_value_to_locale_string(double)

declare i64 @js_string_split_regex(i64, i64)

declare i32 @js_object_delete_dynamic(i64, double)

declare double @js_object_get_prototype_of(double)

declare double @js_object_set_prototype_of(double, double)

declare double @js_object_define_properties(double, double)

declare double @js_math_acos(double)

declare double @js_math_asin(double)

declare double @js_math_atan(double)

declare double @js_math_atan2(double, double)

declare double @js_math_cos(double)

declare double @js_math_expm1(double)

declare double @js_math_log(double)

declare double @js_math_log10(double)

declare double @js_math_log1p(double)

declare double @js_math_log2(double)

declare double @js_math_sin(double)

declare double @js_math_tan(double)

declare double @js_atomics_load(ptr, double, double)

declare double @js_atomics_is_lock_free(ptr, double)

declare double @js_atomics_store(ptr, double, double, double)

declare double @js_atomics_add(ptr, double, double, double)

declare double @js_atomics_sub(ptr, double, double, double)

declare double @js_atomics_and(ptr, double, double, double)

declare double @js_atomics_or(ptr, double, double, double)

declare double @js_atomics_xor(ptr, double, double, double)

declare double @js_atomics_exchange(ptr, double, double, double)

declare double @js_atomics_compare_exchange(ptr, double, double, double, double)

declare double @js_atomics_notify(ptr, double, double, double)

declare double @js_atomics_wait(ptr, double, double, double, double)

declare double @js_atomics_wait_async(ptr, double, double, double, double)

declare double @js_number_is_finite(double)

declare double @js_json_get_bool(i64, i64)

declare double @js_json_get_number(i64, i64)

declare i64 @js_json_get_string(i64, i64)

declare double @js_json_is_valid(i64)

declare i64 @js_json_stringify_bool(double)

declare i64 @js_json_stringify_null()

declare i64 @js_json_stringify_number(double)

declare i64 @js_json_stringify_string(i64)

declare void @js_set_property(double, i64, i64, double)

declare i64 @js_error_get_message(i64)

declare double @js_await_js_promise(double)

declare i64 @js_text_decoder_decode(i64)

declare i64 @js_text_encoder_encode(double)

declare double @js_call_function(i64, i64, i64, i64, i64)

declare double @js_call_method(double, i64, i64, i64, i64)

declare double @js_call_value(double, i64, i64)

declare double @js_closure_call_array(i64, ptr, i64)

declare double @js_closure_call_apply_with_spread(double, ptr, i64, i64)

declare double @js_create_callback(i64, i64, i64)

declare double @js_dynamic_neg(double)

declare double @js_dynamic_pos(double)

declare i32 @js_dynamic_string_equals(double, double)

declare double @js_is_nan(double)

declare i32 @js_jsvalue_compare(double, double)

declare i32 @js_jsvalue_loose_equals(double, double)

declare void @js_gc_collect()

declare void @js_console_assert(double, i64)

declare void @js_console_assert_spread(double, i64)

declare void @js_console_group(i64)

declare double @js_console_context(double)

declare double @js_console_create_task(double)

declare i64 @js_fetch_input_ptr(double)

declare i64 @js_fetch_get(i64)

declare i64 @js_fetch_get_with_auth(i64, i64)

declare i64 @js_fetch_post(i64, i64, i64)

declare i64 @js_fetch_post_with_auth(i64, i64, i64)

declare double @js_fetch_stream_close(double)

declare i64 @js_fetch_stream_poll(double)

declare double @js_fetch_stream_start(i64, i64, i64, i64)

declare double @js_fetch_stream_status(double)

declare i64 @js_fetch_text(i64)

declare i64 @js_fetch_with_options(i64, i64, i64, i64)

declare void @js_fetch_set_pending_signal(double)

declare i64 @js_fetch_headers_to_json(double)

declare double @js_net_create_connection(i32, i64, i64)

declare i64 @js_net_create_server(i64, i64)

declare i64 @js_ext_net_create_server(i64, i64)

declare i64 @js_ext_net_socket_connect(double, double, double)

declare double @js_net_normalize_args(double)

declare double @js_net_create_server_handle_stub(double, double, double, double, double)

declare void @js_net_validate_create_server_options(double)

declare i64 @js_net_socket_set_timeout(i64, double, i64)

declare void @js_net_server_listen(i64, double, double, double)

declare void @js_net_server_close(i64, i64)

declare i64 @js_net_server_address(i64)

declare void @js_net_server_on(i64, i64, i64)

declare double @js_net_server_get_listening(i64)

declare double @js_net_server_get_connections(i64)

declare double @js_net_server_get_max_connections(i64)

declare double @js_net_server_set_max_connections(i64, double)

declare double @js_net_server_get_drop_max_connection(i64)

declare double @js_net_server_set_drop_max_connection(i64, double)

declare i64 @js_net_block_list_new()

declare double @js_net_block_list_is_block_list(double)

declare double @js_net_block_list_add_address(i64, i64, i64)

declare double @js_net_block_list_add_range(i64, i64, i64, i64)

declare double @js_net_block_list_add_subnet(i64, i64, double, i64)

declare double @js_net_block_list_check(i64, i64, i64)

declare double @js_net_block_list_to_json(i64)

declare i64 @js_net_block_list_rules(i64)

declare double @js_net_block_list_from_json(i64, double)

declare i64 @js_net_socket_address_new(double)

declare double @js_net_socket_address_parse(i64)

declare i64 @js_net_socket_address_get_address(i64)

declare i64 @js_net_socket_address_get_family(i64)

declare double @js_net_socket_address_get_port(i64)

declare double @js_net_socket_address_get_flowlabel(i64)

declare double @js_net_socket_get_type_of_service(i64)

declare i64 @js_net_socket_set_type_of_service(i64, double)

declare i64 @js_net_socket_address(i64)

declare i64 @js_net_socket_once(i64, i64, i64)

declare i64 @js_ext_net_socket_once(i64, i64, i64)

declare void @js_ext_net_socket_on(i64, i64, i64)

declare i64 @js_ext_tls_connect(double, double, double, double)

declare i64 @js_net_socket_remove_listener(i64, i64, i64)

declare i64 @js_net_socket_remove_all_listeners(i64, i64)

declare double @js_net_socket_listener_count(i64, i64)

declare i64 @js_net_socket_event_names(i64)

declare i64 @js_net_socket_reset_and_destroy(i64)

declare i64 @js_net_server_once(i64, i64, i64)

declare i64 @js_net_server_remove_listener(i64, i64, i64)

declare i64 @js_net_server_remove_all_listeners(i64, i64)

declare double @js_net_server_listener_count(i64, i64)

declare i64 @js_net_server_event_names(i64)

declare double @js_performance_now()

declare double @js_perf_mark(double, double)

declare double @js_perf_measure(double, double, double)

declare double @js_perf_get_entries()

declare double @js_perf_get_entries_by_type(double)

declare double @js_perf_get_entries_by_name(double, double)

declare double @js_perf_clear_marks(double)

declare double @js_perf_clear_measures(double)

declare double @js_perf_event_loop_utilization(double, double)

declare double @js_perf_to_json()

declare double @js_perf_clear_resource_timings()

declare double @js_perf_set_resource_timing_buffer_size(double)

declare double @js_perf_mark_resource_timing(double, double, double, double, double, double, double, double)

declare double @js_perf_timerify(double, double)

declare double @js_perf_observer_new(double)

declare double @js_perf_observer_observe(double, double)

declare double @js_perf_observer_disconnect(double)

declare double @js_perf_observer_take_records(double)

declare double @js_perf_monitor_event_loop_delay(double)

declare double @js_perf_create_histogram(double)

declare double @js_iter_result_set(double, i32)

declare double @js_iter_result_set_f64(double, i32)

declare double @js_iter_result_set_i32(i32, i32)

declare double @js_iter_result_set_i1(i32, i32)

declare double @js_iter_result_get_value()

declare double @js_iter_result_get_value_f64()

declare i32 @js_iter_result_get_value_i32()

declare i32 @js_iter_result_get_value_i1()

declare double @js_iter_result_get_done()

declare i64 @js_async_step_chain(double, i64)

declare i64 @js_async_step_done(double, i64)

declare i64 @js_get_current_step_closure()

declare double @js_async_first_call(double)

declare double @js_async_generator_resume(double, double, double)

declare void @js_register_class_getter(i64, i64, i64, i64)

declare void @js_register_class_setter(i64, i64, i64, i64)

declare void @js_register_class_string_member_order(i64, i64, i64, i64, i64)

declare void @js_register_class_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_getter(i64, i64, i64, i64)

declare void @js_register_class_static_setter(i64, i64, i64, i64)

declare void @js_register_class_method(i64, i64, i64, i64, i64, i64, i64)

declare void @js_register_class_constructor(i64, i64, i64, i64)

declare void @js_register_class_constructor_flags(i64, i64, i64)

declare void @js_register_class_static_method(i64, i64, i64, i64, i64, i64)

declare double @js_class_static_method_call(double, i64, i64, ptr, i64)

declare double @js_class_method_bind(double, i64, i64)

declare double @js_class_method_snapshot_bind(double, i64, i64)

declare double @js_class_method_bind_by_id(double, i64)

declare double @js_class_lexical_binding_get(double)

declare double @js_class_lexical_binding_set(double, double)

declare double @js_class_prototype_method_value(double, double)

declare double @js_implicit_this_get()

declare double @js_implicit_this_get_sloppy()

declare double @js_implicit_this_set(double)

declare double @js_static_this_resolve(double)

declare void @js_static_this_arm_classref(i32)

declare void @js_static_this_arm_value(double)

declare double @js_ctor_return_override(double, double, i32)

declare double @js_new_target_get()

declare double @js_new_target_set(double)

declare void @js_derived_super_scope_push(ptr)

declare void @js_derived_super_scope_pop()

declare double @js_derived_super_bind_current()

declare double @js_derived_this_check_current()

declare double @js_get_export(i64, i64, i64)

declare double @js_get_property(double, i64, i64)

declare i64 @js_load_module(i64, i64)

declare double @js_module_dynamic_import_apply_hooks(double)

declare double @js_native_call_method_nullsafe(double, i64, i64, i64, i64)

declare double @js_native_call_value(double, i64, i64)

declare double @js_new_from_handle(double, i64, i64)

declare double @js_new_instance(i64, i64, i64, i64, i64)

declare void @js_runtime_init()

declare double @js_object_set_symbol_method(double, double, double)

declare double @js_object_set_method_by_name(double, double, double)

declare double @js_object_define_accessor(double, double, double, double)

declare double @js_object_literal_set_computed(double, double, double)

declare double @js_object_literal_to_property_key(double)

declare double @js_object_literal_set_prototype(double, double)

declare double @js_to_primitive(double, i32)

declare void @js_register_class_has_instance(i32, i64)

declare void @js_register_class_to_string_tag(i32, i64)

declare double @js_object_to_string(double)

declare double @js_object_group_by(double, double)

declare double @js_map_group_by(double, double)

declare double @js_array_from_async(double, double, double)

declare double @js_jsx(double, double)

declare double @js_jsxs(double, double)

declare i64 @js_node_http_server_ref(i64)

declare i64 @js_node_http_server_unref(i64)

declare i64 @js_node_https_server_ref(i64)

declare i64 @js_node_https_server_unref(i64)

declare double @js_http_client_request_flush_headers(i64, double, double)

declare double @js_node_http_im_http_version_major(i64)

declare double @js_node_http_im_http_version_minor(i64)

declare i64 @js_node_http_im_pause_self(i64)

declare i64 @js_node_http_im_resume_self(i64)

declare i64 @js_commander_args_array(i64)

declare i64 @js_commander_argument(i64, i64)

declare double @__ic_decl_4()

declare double @__ic_decl_7()

declare double @__ic_decl_9()

declare double @__ic_decl_12()

declare double @__ic_decl_16()

declare double @__ic_decl_20()

declare double @__ic_decl_22()

declare double @__ic_decl_25()

declare double @__ic_decl_28()

declare double @__ic_decl_30()

declare double @__ic_decl_32()

declare double @__ic_decl_34()

declare double @__ic_decl_36()

declare double @__ic_decl_41()

declare double @__ic_decl_44()

declare token @llvm.experimental.gc.statepoint.p0(i64 immarg, i32 immarg, ptr, i32 immarg, i32 immarg, ...)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token, i32 immarg, i32 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.experimental.gc.result.i1(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i8 @llvm.experimental.gc.result.i8(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i16 @llvm.experimental.gc.result.i16(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.experimental.gc.result.i32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i64 @llvm.experimental.gc.result.i64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i128 @llvm.experimental.gc.result.i128(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.experimental.gc.result.f32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare double @llvm.experimental.gc.result.f64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr @llvm.experimental.gc.result.p0(token) #3

; Function Attrs: optsize
define internal double @"perry_fn_test_json_tape_batch_records_ts__record$spec_i32"(i32 %arg6) #6 gc "statepoint-example" {
entry.0:
  %r30 = alloca [32 x double], align 8
  %r69 = alloca [32 x double], align 8
  %r97 = alloca [32 x double], align 8
  %r123 = alloca [32 x double], align 8
  %r149 = alloca [32 x double], align 8
  %r163 = alloca [32 x double], align 8
  %r3 = load double, ptr @test_json_tape_batch_records_ts_.str.0.handle, align 8
  %r5 = sitofp i32 %arg6 to double
  %r6 = bitcast double %r3 to i64
  %r7 = and i64 %r6, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r7, double %r5, i32 0, i32 0)
  %r82 = call double @llvm.experimental.gc.result.f64(token %statepoint_token)
  %rs4gc.b2 = bitcast double %r82 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %r9.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r9 = call i64 asm "", "=r,0"(i64 %r9.rs4i) #7
  %r10 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r11 = icmp ne i32 %r10, 0
  br i1 %r11, label %shadow.root.barrier.1, label %shadow.root.barrier.done.2

shadow.root.barrier.1:                            ; preds = %entry.0
  call void @js_write_barrier_root_nanbox(i64 %r9) #7
  br label %shadow.root.barrier.done.2

shadow.root.barrier.done.2:                       ; preds = %shadow.root.barrier.1, %entry.0
  %r13 = sitofp i32 %arg6 to double
  %r14 = fptosi double %r13 to i64
  %r16 = srem i64 %r14, 7
  %r17 = sitofp i64 %r16 to double
  %r18 = icmp eq i64 %r16, 0
  %r19 = fcmp olt double %r13, 0.000000e+00
  %r20 = and i1 %r18, %r19
  %r21 = fneg double %r17
  %r22 = select i1 %r20, double %r21, double %r17
  %r23 = fcmp oeq double %r22, 1.000000e+00
  %r24 = select i1 %r23, i64 9222246136947933188, i64 9222246136947933187
  %r25 = bitcast i64 %r24 to double
  %r26 = icmp eq i64 %r24, 9222246136947933188
  br i1 %r26, label %if.then.3, label %if.else.4

if.then.3:                                        ; preds = %shadow.root.barrier.done.2
  %r27 = load double, ptr @test_json_tape_batch_records_ts_.str.1.handle, align 8
  %r28.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r28.rs4o = call i64 asm "", "=r,0"(i64 %r28.rs4i) #7
  %r28 = bitcast i64 %r28.rs4o to double
  %r29 = load double, ptr @test_json_tape_batch_records_ts_.str.2.handle, align 8
  %r31 = getelementptr double, ptr %r30, i64 0
  store double %r27, ptr %r31, align 8
  %r32 = getelementptr double, ptr %r30, i64 1
  store double %r28, ptr %r32, align 8
  %r33 = getelementptr double, ptr %r30, i64 2
  store double %r29, ptr %r33, align 8
  %r34 = ptrtoint ptr %r30 to i64
  %statepoint_token3 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r34, i32 3, i32 0, i32 0)
  %r354 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token3)
  %r36 = or i64 %r354, 9223090561878065152
  %r37 = bitcast i64 %r36 to double
  ret double %r37

if.else.4:                                        ; preds = %shadow.root.barrier.done.2
  br label %if.merge.5

if.merge.5:                                       ; preds = %if.else.4
  %r39 = sitofp i32 %arg6 to double
  %r40 = fptosi double %r39 to i64
  %r42 = srem i64 %r40, 7
  %r43 = sitofp i64 %r42 to double
  %r44 = icmp eq i64 %r42, 0
  %r45 = fcmp olt double %r39, 0.000000e+00
  %r46 = and i1 %r44, %r45
  %r47 = fneg double %r43
  %r48 = select i1 %r46, double %r47, double %r43
  %r49 = fcmp oeq double %r48, 2.000000e+00
  %r50 = select i1 %r49, i64 9222246136947933188, i64 9222246136947933187
  %r51 = bitcast i64 %r50 to double
  %r52 = icmp eq i64 %r50, 9222246136947933188
  br i1 %r52, label %if.then.6, label %if.else.7

if.then.6:                                        ; preds = %if.merge.5
  %r53 = load double, ptr @test_json_tape_batch_records_ts_.str.1.handle, align 8
  %r54.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r54.rs4o = call i64 asm "", "=r,0"(i64 %r54.rs4i) #7
  %r54 = bitcast i64 %r54.rs4o to double
  %r55 = bitcast double %r54 to i64
  %rs4gc.s3 = inttoptr i64 %r55 to ptr addrspace(1)
  %r57.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3 to i64
  %r57 = call i64 asm "", "=r,0"(i64 %r57.rs4i) #7
  %r58 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r59 = icmp ne i32 %r58, 0
  br i1 %r59, label %shadow.root.barrier.9, label %shadow.root.barrier.done.10

if.else.7:                                        ; preds = %if.merge.5
  br label %if.merge.8

if.merge.8:                                       ; preds = %if.else.7
  %r80 = sitofp i32 %arg6 to double
  %r81 = fptosi double %r80 to i64
  %r83 = srem i64 %r81, 7
  %r84 = sitofp i64 %r83 to double
  %r85 = icmp eq i64 %r83, 0
  %r86 = fcmp olt double %r80, 0.000000e+00
  %r87 = and i1 %r85, %r86
  %r88 = fneg double %r84
  %r89 = select i1 %r87, double %r88, double %r84
  %r90 = fcmp oeq double %r89, 3.000000e+00
  %r91 = select i1 %r90, i64 9222246136947933188, i64 9222246136947933187
  %r92 = bitcast i64 %r91 to double
  %r93 = icmp eq i64 %r91, 9222246136947933188
  br i1 %r93, label %if.then.11, label %if.else.12

shadow.root.barrier.9:                            ; preds = %if.then.6
  call void @js_write_barrier_root_nanbox(i64 %r57) #7
  br label %shadow.root.barrier.done.10

shadow.root.barrier.done.10:                      ; preds = %shadow.root.barrier.9, %if.then.6
  %r60 = load double, ptr @test_json_tape_batch_records_ts_.str.3.handle, align 8
  %r62 = sitofp i32 %arg6 to double
  %r63 = fadd double %r62, 1.000000e+01
  %r64 = load double, ptr @test_json_tape_batch_records_ts_.str.4.handle, align 8
  %r65 = load double, ptr @test_json_tape_batch_records_ts_.str.1.handle, align 8
  %r66.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3 to i64
  %r66 = call i64 asm "", "=r,0"(i64 %r66.rs4i) #7
  %r67 = bitcast i64 %r66 to double
  %r68 = load double, ptr @test_json_tape_batch_records_ts_.str.3.handle, align 8
  %r70 = getelementptr double, ptr %r69, i64 0
  store double %r65, ptr %r70, align 8
  %r71 = getelementptr double, ptr %r69, i64 1
  store double %r67, ptr %r71, align 8
  %r72 = getelementptr double, ptr %r69, i64 2
  store double %r68, ptr %r72, align 8
  %r73 = getelementptr double, ptr %r69, i64 3
  store double %r63, ptr %r73, align 8
  %r74 = getelementptr double, ptr %r69, i64 4
  store double %r64, ptr %r74, align 8
  %r75 = ptrtoint ptr %r69 to i64
  %statepoint_token5 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r75, i32 5, i32 0, i32 0)
  %r766 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token5)
  %r77 = or i64 %r766, 9223090561878065152
  %r78 = bitcast i64 %r77 to double
  ret double %r78

if.then.11:                                       ; preds = %if.merge.8
  %r94 = load double, ptr @test_json_tape_batch_records_ts_.str.1.handle, align 8
  %r95.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r95.rs4o = call i64 asm "", "=r,0"(i64 %r95.rs4i) #7
  %r95 = bitcast i64 %r95.rs4o to double
  %r96 = load double, ptr @test_json_tape_batch_records_ts_.str.5.handle, align 8
  %r98 = getelementptr double, ptr %r97, i64 0
  store double %r94, ptr %r98, align 8
  %r99 = getelementptr double, ptr %r97, i64 1
  store double %r95, ptr %r99, align 8
  %r100 = getelementptr double, ptr %r97, i64 2
  store double %r96, ptr %r100, align 8
  %r101 = ptrtoint ptr %r97 to i64
  %statepoint_token7 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r101, i32 3, i32 0, i32 0)
  %r1028 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token7)
  %r103 = or i64 %r1028, 9223090561878065152
  %r104 = bitcast i64 %r103 to double
  ret double %r104

if.else.12:                                       ; preds = %if.merge.8
  br label %if.merge.13

if.merge.13:                                      ; preds = %if.else.12
  %r106 = sitofp i32 %arg6 to double
  %r107 = fptosi double %r106 to i64
  %r109 = srem i64 %r107, 7
  %r110 = sitofp i64 %r109 to double
  %r111 = icmp eq i64 %r109, 0
  %r112 = fcmp olt double %r106, 0.000000e+00
  %r113 = and i1 %r111, %r112
  %r114 = fneg double %r110
  %r115 = select i1 %r113, double %r114, double %r110
  %r116 = fcmp oeq double %r115, 4.000000e+00
  %r117 = select i1 %r116, i64 9222246136947933188, i64 9222246136947933187
  %r118 = bitcast i64 %r117 to double
  %r119 = icmp eq i64 %r117, 9222246136947933188
  br i1 %r119, label %if.then.14, label %if.else.15

if.then.14:                                       ; preds = %if.merge.13
  %r120 = load double, ptr @test_json_tape_batch_records_ts_.str.1.handle, align 8
  %r121.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r121.rs4o = call i64 asm "", "=r,0"(i64 %r121.rs4i) #7
  %r121 = bitcast i64 %r121.rs4o to double
  %r122 = load double, ptr @test_json_tape_batch_records_ts_.str.6.handle, align 8
  %r124 = getelementptr double, ptr %r123, i64 0
  store double %r120, ptr %r124, align 8
  %r125 = getelementptr double, ptr %r123, i64 1
  store double %r121, ptr %r125, align 8
  %r126 = getelementptr double, ptr %r123, i64 2
  store double %r122, ptr %r126, align 8
  %r127 = ptrtoint ptr %r123 to i64
  %statepoint_token9 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r127, i32 3, i32 0, i32 0)
  %r12810 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token9)
  %r129 = or i64 %r12810, 9223090561878065152
  %r130 = bitcast i64 %r129 to double
  ret double %r130

if.else.15:                                       ; preds = %if.merge.13
  br label %if.merge.16

if.merge.16:                                      ; preds = %if.else.15
  %r132 = sitofp i32 %arg6 to double
  %r133 = fptosi double %r132 to i64
  %r135 = srem i64 %r133, 7
  %r136 = sitofp i64 %r135 to double
  %r137 = icmp eq i64 %r135, 0
  %r138 = fcmp olt double %r132, 0.000000e+00
  %r139 = and i1 %r137, %r138
  %r140 = fneg double %r136
  %r141 = select i1 %r139, double %r140, double %r136
  %r142 = fcmp oeq double %r141, 5.000000e+00
  %r143 = select i1 %r142, i64 9222246136947933188, i64 9222246136947933187
  %r144 = bitcast i64 %r143 to double
  %r145 = icmp eq i64 %r143, 9222246136947933188
  br i1 %r145, label %if.then.17, label %if.else.18

if.then.17:                                       ; preds = %if.merge.16
  %r146 = load double, ptr @test_json_tape_batch_records_ts_.str.1.handle, align 8
  %r147.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r147.rs4o = call i64 asm "", "=r,0"(i64 %r147.rs4i) #7
  %r147 = bitcast i64 %r147.rs4o to double
  %r148 = load double, ptr @test_json_tape_batch_records_ts_.str.7.handle, align 8
  %r150 = getelementptr double, ptr %r149, i64 0
  store double %r146, ptr %r150, align 8
  %r151 = getelementptr double, ptr %r149, i64 1
  store double %r147, ptr %r151, align 8
  %r152 = getelementptr double, ptr %r149, i64 2
  store double %r148, ptr %r152, align 8
  %r153 = ptrtoint ptr %r149 to i64
  %statepoint_token11 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r153, i32 3, i32 0, i32 0)
  %r15412 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token11)
  %r155 = or i64 %r15412, 9223090561878065152
  %r156 = bitcast i64 %r155 to double
  ret double %r156

if.else.18:                                       ; preds = %if.merge.16
  br label %if.merge.19

if.merge.19:                                      ; preds = %if.else.18
  %r157 = load double, ptr @test_json_tape_batch_records_ts_.str.1.handle, align 8
  %r158.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r158.rs4o = call i64 asm "", "=r,0"(i64 %r158.rs4i) #7
  %r158 = bitcast i64 %r158.rs4o to double
  %r159 = load double, ptr @test_json_tape_batch_records_ts_.str.8.handle, align 8
  %r161 = sitofp i32 %arg6 to double
  %r162 = load double, ptr @test_json_tape_batch_records_ts_.str.9.handle, align 8
  %r164 = getelementptr double, ptr %r163, i64 0
  store double %r157, ptr %r164, align 8
  %r165 = getelementptr double, ptr %r163, i64 1
  store double %r158, ptr %r165, align 8
  %r166 = getelementptr double, ptr %r163, i64 2
  store double %r159, ptr %r166, align 8
  %r167 = getelementptr double, ptr %r163, i64 3
  store double %r161, ptr %r167, align 8
  %r168 = getelementptr double, ptr %r163, i64 4
  store double %r162, ptr %r168, align 8
  %r169 = ptrtoint ptr %r163 to i64
  %statepoint_token13 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r169, i32 5, i32 0, i32 0)
  %r17014 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token13)
  %r171 = or i64 %r17014, 9223090561878065152
  %r172 = bitcast i64 %r171 to double
  ret double %r172
}

; Function Attrs: optsize
define double @perry_fn_test_json_tape_batch_records_ts__record(double %arg6) #6 gc "statepoint-example" {
entry.0:
  %r20 = alloca [32 x double], align 8
  %r56 = alloca [32 x double], align 8
  %r75 = alloca [32 x double], align 8
  %r92 = alloca [32 x double], align 8
  %r109 = alloca [32 x double], align 8
  %r122 = alloca [32 x double], align 8
  %rs4gc.b2 = bitcast double %arg6 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %r3 = load double, ptr @test_json_tape_batch_records_ts_.str.0.handle, align 8
  %r4.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r4.rs4o = call i64 asm "", "=r,0"(i64 %r4.rs4i) #7
  %r4 = bitcast i64 %r4.rs4o to double
  %r5 = bitcast double %r3 to i64
  %r6 = and i64 %r5, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r6, double %r4, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s2) ]
  %r710 = call double @llvm.experimental.gc.result.f64(token %statepoint_token)
  %rs4gc.s2.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s2, %rs4gc.s2)
  %rs4gc.b3 = bitcast double %r710 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %r8.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3 to i64
  %r8 = call i64 asm "", "=r,0"(i64 %r8.rs4i) #7
  %r9 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r10 = icmp ne i32 %r9, 0
  br i1 %r10, label %shadow.root.barrier.1, label %shadow.root.barrier.done.2

shadow.root.barrier.1:                            ; preds = %entry.0
  call void @js_write_barrier_root_nanbox(i64 %r8) #7
  br label %shadow.root.barrier.done.2

shadow.root.barrier.done.2:                       ; preds = %shadow.root.barrier.1, %entry.0
  %r11.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2.relocated to i64
  %r11.rs4o = call i64 asm "", "=r,0"(i64 %r11.rs4i) #7
  %r11 = bitcast i64 %r11.rs4o to double
  %statepoint_token11 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_mod, i32 2, i32 0, double %r11, double 7.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3, ptr addrspace(1) %rs4gc.s2.relocated) ]
  %r1212 = call double @llvm.experimental.gc.result.f64(token %statepoint_token11)
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token11, i32 0, i32 0) ; (%rs4gc.s3, %rs4gc.s3)
  %rs4gc.s2.relocated13 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token11, i32 1, i32 1) ; (%rs4gc.s2.relocated, %rs4gc.s2.relocated)
  %r13 = fcmp oeq double %r1212, 1.000000e+00
  %r14 = select i1 %r13, i64 9222246136947933188, i64 9222246136947933187
  %r15 = bitcast i64 %r14 to double
  %r16 = icmp eq i64 %r14, 9222246136947933188
  br i1 %r16, label %if.then.3, label %if.else.4

if.then.3:                                        ; preds = %shadow.root.barrier.done.2
  %r17 = load double, ptr @test_json_tape_batch_records_ts_.str.1.handle, align 8
  %r18.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3.relocated to i64
  %r18.rs4o = call i64 asm "", "=r,0"(i64 %r18.rs4i) #7
  %r18 = bitcast i64 %r18.rs4o to double
  %r19 = load double, ptr @test_json_tape_batch_records_ts_.str.2.handle, align 8
  %r21 = getelementptr double, ptr %r20, i64 0
  store double %r17, ptr %r21, align 8
  %r22 = getelementptr double, ptr %r20, i64 1
  store double %r18, ptr %r22, align 8
  %r23 = getelementptr double, ptr %r20, i64 2
  store double %r19, ptr %r23, align 8
  %r24 = ptrtoint ptr %r20 to i64
  %statepoint_token14 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r24, i32 3, i32 0, i32 0)
  %r2515 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token14)
  %r26 = or i64 %r2515, 9223090561878065152
  %r27 = bitcast i64 %r26 to double
  ret double %r27

if.else.4:                                        ; preds = %shadow.root.barrier.done.2
  br label %if.merge.5

if.merge.5:                                       ; preds = %if.else.4
  %r28.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2.relocated13 to i64
  %r28.rs4o = call i64 asm "", "=r,0"(i64 %r28.rs4i) #7
  %r28 = bitcast i64 %r28.rs4o to double
  %statepoint_token16 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_mod, i32 2, i32 0, double %r28, double 7.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s2.relocated13, ptr addrspace(1) %rs4gc.s3.relocated) ]
  %r2917 = call double @llvm.experimental.gc.result.f64(token %statepoint_token16)
  %rs4gc.s2.relocated18 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token16, i32 0, i32 0) ; (%rs4gc.s2.relocated13, %rs4gc.s2.relocated13)
  %rs4gc.s3.relocated19 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token16, i32 1, i32 1) ; (%rs4gc.s3.relocated, %rs4gc.s3.relocated)
  %r30 = fcmp oeq double %r2917, 2.000000e+00
  %r31 = select i1 %r30, i64 9222246136947933188, i64 9222246136947933187
  %r32 = bitcast i64 %r31 to double
  %r33 = icmp eq i64 %r31, 9222246136947933188
  br i1 %r33, label %if.then.6, label %if.else.7

if.then.6:                                        ; preds = %if.merge.5
  %r34 = load double, ptr @test_json_tape_batch_records_ts_.str.1.handle, align 8
  %r35.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3.relocated19 to i64
  %r35.rs4o = call i64 asm "", "=r,0"(i64 %r35.rs4i) #7
  %r35 = bitcast i64 %r35.rs4o to double
  %r36 = bitcast double %r35 to i64
  %rs4gc.s4 = inttoptr i64 %r36 to ptr addrspace(1)
  %r38.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s4 to i64
  %r38 = call i64 asm "", "=r,0"(i64 %r38.rs4i) #7
  %r39 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r40 = icmp ne i32 %r39, 0
  br i1 %r40, label %shadow.root.barrier.9, label %shadow.root.barrier.done.10

if.else.7:                                        ; preds = %if.merge.5
  br label %if.merge.8

if.merge.8:                                       ; preds = %if.else.7
  %r66.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2.relocated18 to i64
  %r66.rs4o = call i64 asm "", "=r,0"(i64 %r66.rs4i) #7
  %r66 = bitcast i64 %r66.rs4o to double
  %statepoint_token20 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_mod, i32 2, i32 0, double %r66, double 7.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated19, ptr addrspace(1) %rs4gc.s2.relocated18) ]
  %r6721 = call double @llvm.experimental.gc.result.f64(token %statepoint_token20)
  %rs4gc.s3.relocated22 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token20, i32 0, i32 0) ; (%rs4gc.s3.relocated19, %rs4gc.s3.relocated19)
  %rs4gc.s2.relocated23 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token20, i32 1, i32 1) ; (%rs4gc.s2.relocated18, %rs4gc.s2.relocated18)
  %r68 = fcmp oeq double %r6721, 3.000000e+00
  %r69 = select i1 %r68, i64 9222246136947933188, i64 9222246136947933187
  %r70 = bitcast i64 %r69 to double
  %r71 = icmp eq i64 %r69, 9222246136947933188
  br i1 %r71, label %if.then.14, label %if.else.15

shadow.root.barrier.9:                            ; preds = %if.then.6
  call void @js_write_barrier_root_nanbox(i64 %r38) #7
  br label %shadow.root.barrier.done.10

shadow.root.barrier.done.10:                      ; preds = %shadow.root.barrier.9, %if.then.6
  %r41 = load double, ptr @test_json_tape_batch_records_ts_.str.3.handle, align 8
  %r42.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2.relocated18 to i64
  %r42.rs4o = call i64 asm "", "=r,0"(i64 %r42.rs4i) #7
  %r42 = bitcast i64 %r42.rs4o to double
  %r43 = bitcast double %r42 to i64
  %r44 = and i64 %r43, -281474976710656
  %r45 = icmp ult i64 %r44, 9221401712017801216
  %r46 = icmp ugt i64 %r44, 9223090561878065152
  %r47 = or i1 %r45, %r46
  br i1 %r47, label %guarded_add.numeric.11, label %guarded_add.dynamic.12

guarded_add.numeric.11:                           ; preds = %shadow.root.barrier.done.10
  %r48 = fadd double %r42, 1.000000e+01
  br label %guarded_add.merge.13

guarded_add.dynamic.12:                           ; preds = %shadow.root.barrier.done.10
  %statepoint_token24 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r42, double 1.000000e+01, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4) ]
  %r4925 = call double @llvm.experimental.gc.result.f64(token %statepoint_token24)
  %rs4gc.s4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token24, i32 0, i32 0) ; (%rs4gc.s4, %rs4gc.s4)
  br label %guarded_add.merge.13

guarded_add.merge.13:                             ; preds = %guarded_add.dynamic.12, %guarded_add.numeric.11
  %.0 = phi ptr addrspace(1) [ %rs4gc.s4, %guarded_add.numeric.11 ], [ %rs4gc.s4.relocated, %guarded_add.dynamic.12 ]
  %r50 = phi double [ %r48, %guarded_add.numeric.11 ], [ %r4925, %guarded_add.dynamic.12 ]
  %r51 = load double, ptr @test_json_tape_batch_records_ts_.str.4.handle, align 8
  %r52 = load double, ptr @test_json_tape_batch_records_ts_.str.1.handle, align 8
  %r53.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r53 = call i64 asm "", "=r,0"(i64 %r53.rs4i) #7
  %r54 = bitcast i64 %r53 to double
  %r55 = load double, ptr @test_json_tape_batch_records_ts_.str.3.handle, align 8
  %r57 = getelementptr double, ptr %r56, i64 0
  store double %r52, ptr %r57, align 8
  %r58 = getelementptr double, ptr %r56, i64 1
  store double %r54, ptr %r58, align 8
  %r59 = getelementptr double, ptr %r56, i64 2
  store double %r55, ptr %r59, align 8
  %r60 = getelementptr double, ptr %r56, i64 3
  store double %r50, ptr %r60, align 8
  %r61 = getelementptr double, ptr %r56, i64 4
  store double %r51, ptr %r61, align 8
  %r62 = ptrtoint ptr %r56 to i64
  %statepoint_token26 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r62, i32 5, i32 0, i32 0)
  %r6327 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token26)
  %r64 = or i64 %r6327, 9223090561878065152
  %r65 = bitcast i64 %r64 to double
  ret double %r65

if.then.14:                                       ; preds = %if.merge.8
  %r72 = load double, ptr @test_json_tape_batch_records_ts_.str.1.handle, align 8
  %r73.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3.relocated22 to i64
  %r73.rs4o = call i64 asm "", "=r,0"(i64 %r73.rs4i) #7
  %r73 = bitcast i64 %r73.rs4o to double
  %r74 = load double, ptr @test_json_tape_batch_records_ts_.str.5.handle, align 8
  %r76 = getelementptr double, ptr %r75, i64 0
  store double %r72, ptr %r76, align 8
  %r77 = getelementptr double, ptr %r75, i64 1
  store double %r73, ptr %r77, align 8
  %r78 = getelementptr double, ptr %r75, i64 2
  store double %r74, ptr %r78, align 8
  %r79 = ptrtoint ptr %r75 to i64
  %statepoint_token28 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r79, i32 3, i32 0, i32 0)
  %r8029 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token28)
  %r81 = or i64 %r8029, 9223090561878065152
  %r82 = bitcast i64 %r81 to double
  ret double %r82

if.else.15:                                       ; preds = %if.merge.8
  br label %if.merge.16

if.merge.16:                                      ; preds = %if.else.15
  %r83.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2.relocated23 to i64
  %r83.rs4o = call i64 asm "", "=r,0"(i64 %r83.rs4i) #7
  %r83 = bitcast i64 %r83.rs4o to double
  %statepoint_token30 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_mod, i32 2, i32 0, double %r83, double 7.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated22, ptr addrspace(1) %rs4gc.s2.relocated23) ]
  %r8431 = call double @llvm.experimental.gc.result.f64(token %statepoint_token30)
  %rs4gc.s3.relocated32 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token30, i32 0, i32 0) ; (%rs4gc.s3.relocated22, %rs4gc.s3.relocated22)
  %rs4gc.s2.relocated33 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token30, i32 1, i32 1) ; (%rs4gc.s2.relocated23, %rs4gc.s2.relocated23)
  %r85 = fcmp oeq double %r8431, 4.000000e+00
  %r86 = select i1 %r85, i64 9222246136947933188, i64 9222246136947933187
  %r87 = bitcast i64 %r86 to double
  %r88 = icmp eq i64 %r86, 9222246136947933188
  br i1 %r88, label %if.then.17, label %if.else.18

if.then.17:                                       ; preds = %if.merge.16
  %r89 = load double, ptr @test_json_tape_batch_records_ts_.str.1.handle, align 8
  %r90.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3.relocated32 to i64
  %r90.rs4o = call i64 asm "", "=r,0"(i64 %r90.rs4i) #7
  %r90 = bitcast i64 %r90.rs4o to double
  %r91 = load double, ptr @test_json_tape_batch_records_ts_.str.6.handle, align 8
  %r93 = getelementptr double, ptr %r92, i64 0
  store double %r89, ptr %r93, align 8
  %r94 = getelementptr double, ptr %r92, i64 1
  store double %r90, ptr %r94, align 8
  %r95 = getelementptr double, ptr %r92, i64 2
  store double %r91, ptr %r95, align 8
  %r96 = ptrtoint ptr %r92 to i64
  %statepoint_token34 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r96, i32 3, i32 0, i32 0)
  %r9735 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token34)
  %r98 = or i64 %r9735, 9223090561878065152
  %r99 = bitcast i64 %r98 to double
  ret double %r99

if.else.18:                                       ; preds = %if.merge.16
  br label %if.merge.19

if.merge.19:                                      ; preds = %if.else.18
  %r100.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2.relocated33 to i64
  %r100.rs4o = call i64 asm "", "=r,0"(i64 %r100.rs4i) #7
  %r100 = bitcast i64 %r100.rs4o to double
  %statepoint_token36 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_mod, i32 2, i32 0, double %r100, double 7.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated32, ptr addrspace(1) %rs4gc.s2.relocated33) ]
  %r10137 = call double @llvm.experimental.gc.result.f64(token %statepoint_token36)
  %rs4gc.s3.relocated38 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token36, i32 0, i32 0) ; (%rs4gc.s3.relocated32, %rs4gc.s3.relocated32)
  %rs4gc.s2.relocated39 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token36, i32 1, i32 1) ; (%rs4gc.s2.relocated33, %rs4gc.s2.relocated33)
  %r102 = fcmp oeq double %r10137, 5.000000e+00
  %r103 = select i1 %r102, i64 9222246136947933188, i64 9222246136947933187
  %r104 = bitcast i64 %r103 to double
  %r105 = icmp eq i64 %r103, 9222246136947933188
  br i1 %r105, label %if.then.20, label %if.else.21

if.then.20:                                       ; preds = %if.merge.19
  %r106 = load double, ptr @test_json_tape_batch_records_ts_.str.1.handle, align 8
  %r107.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3.relocated38 to i64
  %r107.rs4o = call i64 asm "", "=r,0"(i64 %r107.rs4i) #7
  %r107 = bitcast i64 %r107.rs4o to double
  %r108 = load double, ptr @test_json_tape_batch_records_ts_.str.7.handle, align 8
  %r110 = getelementptr double, ptr %r109, i64 0
  store double %r106, ptr %r110, align 8
  %r111 = getelementptr double, ptr %r109, i64 1
  store double %r107, ptr %r111, align 8
  %r112 = getelementptr double, ptr %r109, i64 2
  store double %r108, ptr %r112, align 8
  %r113 = ptrtoint ptr %r109 to i64
  %statepoint_token40 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r113, i32 3, i32 0, i32 0)
  %r11441 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token40)
  %r115 = or i64 %r11441, 9223090561878065152
  %r116 = bitcast i64 %r115 to double
  ret double %r116

if.else.21:                                       ; preds = %if.merge.19
  br label %if.merge.22

if.merge.22:                                      ; preds = %if.else.21
  %r117 = load double, ptr @test_json_tape_batch_records_ts_.str.1.handle, align 8
  %r118.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3.relocated38 to i64
  %r118.rs4o = call i64 asm "", "=r,0"(i64 %r118.rs4i) #7
  %r118 = bitcast i64 %r118.rs4o to double
  %r119 = load double, ptr @test_json_tape_batch_records_ts_.str.8.handle, align 8
  %r120.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2.relocated39 to i64
  %r120.rs4o = call i64 asm "", "=r,0"(i64 %r120.rs4i) #7
  %r120 = bitcast i64 %r120.rs4o to double
  %r121 = load double, ptr @test_json_tape_batch_records_ts_.str.9.handle, align 8
  %r123 = getelementptr double, ptr %r122, i64 0
  store double %r117, ptr %r123, align 8
  %r124 = getelementptr double, ptr %r122, i64 1
  store double %r118, ptr %r124, align 8
  %r125 = getelementptr double, ptr %r122, i64 2
  store double %r119, ptr %r125, align 8
  %r126 = getelementptr double, ptr %r122, i64 3
  store double %r120, ptr %r126, align 8
  %r127 = getelementptr double, ptr %r122, i64 4
  store double %r121, ptr %r127, align 8
  %r128 = ptrtoint ptr %r122 to i64
  %statepoint_token42 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r128, i32 5, i32 0, i32 0)
  %r12943 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token42)
  %r130 = or i64 %r12943, 9223090561878065152
  %r131 = bitcast i64 %r130 to double
  ret double %r131
}

; Function Attrs: optsize
define double @__perry_wrap_perry_fn_test_json_tape_batch_records_ts__record(i64 %this_closure, double %a0) #6 {
entry.0:
  %r1 = call double @perry_fn_test_json_tape_batch_records_ts__record(double %a0)
  ret double %r1
}

; Function Attrs: optsize
define internal double @__perry_wrap_perry_unknown_func_test_json_tape_batch_records_ts(i64 %this_closure, double %a0, double %a1, double %a2, double %a3, double %a4) #6 {
entry.0:
  ret double 0x7FFC000000000001
}

; Function Attrs: optsize
define void @test_json_tape_batch_records_ts__init() #6 {
entry.0:
  ret void
}

; Function Attrs: optsize
define i32 @main() #6 gc "statepoint-example" personality ptr @perry_eh_personality {
entry.0:
  %r120 = alloca [32 x double], align 8
  %r795 = alloca [1 x double], align 8
  %r800 = alloca [7 x i64], align 8
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (ptr, i32)) @js_set_process_entry_path, i32 2, i32 0, ptr @test_json_tape_batch_records_ts_.str.0, i32 128, i32 0, i32 0)
  %statepoint_token30 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_init, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token31 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32)) @js_gc_write_barriers_emitted, i32 1, i32 0, i32 1, i32 0, i32 0)
  %statepoint_token32 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @perry_macos_bundle_chdir, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token33 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @__perry_init_strings_test_json_tape_batch_records_ts, i32 0, i32 0, i32 0, i32 0)
  %r456 = call ptr @perry_transition_cache_base() #7
  %statepoint_token34 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0)
  %r235 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token34)
  %r3 = or i64 %r235, 9222527611924643840
  %r4 = bitcast i64 %r3 to double
  %rs4gc.b14 = bitcast double %r4 to i64
  %rs4gc.s14 = inttoptr i64 %rs4gc.b14 to ptr addrspace(1)
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r5 = call i64 asm "", "=r,0"(i64 %r5.rs4i) #7
  %r6 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r7 = icmp ne i32 %r6, 0
  br i1 %r7, label %shadow.root.barrier.1, label %shadow.root.barrier.done.2

shadow.root.barrier.1:                            ; preds = %entry.0
  call void @js_write_barrier_root_nanbox(i64 %r5) #7
  br label %shadow.root.barrier.done.2

shadow.root.barrier.done.2:                       ; preds = %shadow.root.barrier.1, %entry.0
  br label %for.cond.3

for.cond.3:                                       ; preds = %for.update.5, %shadow.root.barrier.done.2
  %r8.0 = phi double [ 0.000000e+00, %shadow.root.barrier.done.2 ], [ %r108, %for.update.5 ]
  %r1.0.base = phi ptr addrspace(1) [ %rs4gc.s14, %shadow.root.barrier.done.2 ], [ %.0, %for.update.5 ], !is_base_value !0
  %r1.0 = phi ptr addrspace(1) [ %rs4gc.s14, %shadow.root.barrier.done.2 ], [ %.0995, %for.update.5 ]
  %r10 = fcmp olt double %r8.0, 2.400000e+02
  %r11 = select i1 %r10, i64 9222246136947933188, i64 9222246136947933187
  %r12 = bitcast i64 %r11 to double
  %r13 = icmp eq i64 %r11, 9222246136947933188
  br i1 %r13, label %for.body.4, label %for.exit.6

for.body.4:                                       ; preds = %for.cond.3
  %r15 = fptosi double %r8.0 to i32
  %statepoint_token36 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i32)) @"perry_fn_test_json_tape_batch_records_ts__record$spec_i32", i32 1, i32 0, i32 %r15, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1.0.base, ptr addrspace(1) %r1.0) ]
  %r1655 = call double @llvm.experimental.gc.result.f64(token %statepoint_token36)
  %r1.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token36, i32 0, i32 0) ; (%r1.0.base, %r1.0.base)
  %r1.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token36, i32 0, i32 1) ; (%r1.0.base, %r1.0)
  %r17 = bitcast double %r1655 to i64
  %r18.rs4i = ptrtoint ptr addrspace(1) %r1.0.relocated to i64
  %r18.rs4o = call i64 asm "", "=r,0"(i64 %r18.rs4i) #7
  %r18 = bitcast i64 %r18.rs4o to double
  %r19 = bitcast double %r18 to i64
  %r20 = and i64 %r19, 281474976710655
  %r21 = sub nsw i64 %r20, 8
  %r22 = inttoptr i64 %r21 to ptr
  %r23 = load i8, ptr %r22, align 1
  %r24 = icmp ne i8 %r23, 1
  %r25 = sub nsw i64 %r20, 7
  %r26 = inttoptr i64 %r25 to ptr
  %r27 = load i8, ptr %r26, align 1
  %r28 = and i8 %r27, -128
  %r29 = icmp ne i8 %r28, 0
  %r30 = or i1 %r24, %r29
  br i1 %r29, label %apush.fwd.7, label %apush.elements.8

for.update.5:                                     ; preds = %gcpoll.done.19
  %r108 = fadd double %r8.0, 1.000000e+00
  br label %for.cond.3

for.exit.6:                                       ; preds = %for.cond.3
  %r110 = load double, ptr @test_json_tape_batch_records_ts_.str.10.handle, align 8
  %r111.rs4i = ptrtoint ptr addrspace(1) %r1.0 to i64
  %r111.rs4o = call i64 asm "", "=r,0"(i64 %r111.rs4i) #7
  %r111 = bitcast i64 %r111.rs4o to double
  %r112 = load double, ptr @test_json_tape_batch_records_ts_.str.11.handle, align 8
  %r113 = bitcast double %r111 to i64
  %r114 = and i64 %r113, 281474976710655
  %statepoint_token56 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_join_value, i32 2, i32 0, i64 %r114, double %r112, i32 0, i32 0)
  %r11557 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token56)
  %r116 = or i64 %r11557, 9223090561878065152
  %r117 = bitcast i64 %r116 to double
  %r118 = load double, ptr @test_json_tape_batch_records_ts_.str.12.handle, align 8
  %r119 = load double, ptr @test_json_tape_batch_records_ts_.str.10.handle, align 8
  %r121 = getelementptr double, ptr %r120, i64 0
  store double %r119, ptr %r121, align 8
  %r122 = getelementptr double, ptr %r120, i64 1
  store double %r117, ptr %r122, align 8
  %r123 = getelementptr double, ptr %r120, i64 2
  store double %r118, ptr %r123, align 8
  %r124 = ptrtoint ptr %r120 to i64
  %statepoint_token58 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r124, i32 3, i32 0, i32 0)
  %r12559 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token58)
  %r126 = or i64 %r12559, 9223090561878065152
  %r127 = bitcast i64 %r126 to double
  %rs4gc.b15 = bitcast double %r127 to i64
  %rs4gc.s15 = inttoptr i64 %rs4gc.b15 to ptr addrspace(1)
  %r128.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15 to i64
  %r128 = call i64 asm "", "=r,0"(i64 %r128.rs4i) #7
  %r129 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r130 = icmp ne i32 %r129, 0
  br i1 %r130, label %shadow.root.barrier.20, label %shadow.root.barrier.done.21

apush.fwd.7:                                      ; preds = %apush.elements.check.9, %for.body.4
  %statepoint_token60 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r20, double %r1655, i32 0, i32 0)
  %r57100 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token60)
  %r58 = or i64 %r57100, 9222527611924643840
  %r59 = bitcast i64 %r58 to double
  %rs4gc.b16 = bitcast double %r59 to i64
  %rs4gc.s16 = inttoptr i64 %rs4gc.b16 to ptr addrspace(1)
  br label %apush.merge.13

apush.elements.8:                                 ; preds = %for.body.4
  %r32 = add nuw nsw i64 %r20, 8
  %r33 = inttoptr i64 %r32 to ptr
  %r34 = load i64, ptr %r33, align 8
  %r35 = icmp ne i64 %r34, 0
  %r36 = icmp eq i8 %r23, 2
  %r37 = and i1 %r36, %r35
  %r38 = select i1 %r37, i64 %r34, i64 %r20
  %r39 = inttoptr i64 %r38 to ptr
  %r40 = getelementptr i64, ptr %r39, i64 12
  %r41 = load i64, ptr %r40, align 8
  %r42 = icmp ne i64 %r41, 0
  %r43 = and i1 %r37, %r42
  %r44 = select i1 %r43, i64 %r41, i64 %r20
  %r31 = icmp eq i8 %r23, 1
  br i1 %r31, label %apush.nofwd.10, label %apush.elements.check.9

apush.elements.check.9:                           ; preds = %apush.elements.8
  %r45 = icmp ne i64 %r44, 0
  %r46 = sub i64 %r44, 8
  %r47 = inttoptr i64 %r46 to ptr
  %r48 = load i8, ptr %r47, align 1
  %r49 = icmp eq i8 %r48, 1
  %r50 = sub i64 %r44, 7
  %r51 = inttoptr i64 %r50 to ptr
  %r52 = load i8, ptr %r51, align 1
  %r53 = and i8 %r52, -128
  %r54 = icmp eq i8 %r53, 0
  %r55 = and i1 %r45, %r49
  %r56 = and i1 %r55, %r54
  br i1 %r56, label %apush.nofwd.10, label %apush.fwd.7

apush.nofwd.10:                                   ; preds = %apush.elements.check.9, %apush.elements.8
  %r60 = phi i64 [ %r20, %apush.elements.8 ], [ %r44, %apush.elements.check.9 ]
  %r61 = sub i64 %r60, 6
  %r62 = inttoptr i64 %r61 to ptr
  %r63 = load i16, ptr %r62, align 2
  %r64 = and i16 %r63, 1031
  %r65 = icmp eq i16 %r64, 0
  %r66 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r67 = icmp eq i8 %r66, 0
  %r68 = and i1 %r65, %r67
  %r69 = icmp ult i64 %r60, 4096
  %r70 = inttoptr i64 %r60 to ptr
  %r71 = select i1 %r69, ptr @perry_null_guard_zero_test_json_tape_batch_records_ts, ptr %r70
  %r72 = load i32, ptr %r71, align 4
  %r73 = add i64 %r60, 4
  %r74 = inttoptr i64 %r73 to ptr
  %r75 = load i32, ptr %r74, align 4
  %r76 = icmp ult i32 %r72, %r75
  %r77 = and i1 %r76, %r68
  br i1 %r77, label %apush.inbounds.11, label %apush.realloc.12

apush.inbounds.11:                                ; preds = %apush.nofwd.10
  %r78 = icmp ult i64 %r60, 4096
  %r79 = inttoptr i64 %r60 to ptr
  %r80 = select i1 %r78, ptr @perry_null_guard_zero_test_json_tape_batch_records_ts, ptr %r79
  %r81 = load i32, ptr %r80, align 4
  %r82 = zext i32 %r81 to i64
  %r83 = shl nuw nsw i64 %r82, 3
  %r84 = add nuw nsw i64 %r83, 8
  %r85 = add i64 %r60, %r84
  %r86 = inttoptr i64 %r85 to ptr
  store double %r1655, ptr %r86, align 8
  %r87 = lshr i64 %r17, 48
  %r88 = icmp eq i64 %r87, 32765
  %r89 = and i16 %r63, -1920
  %r90 = icmp eq i16 %r89, -24576
  %r91 = and i1 %r88, %r90
  br i1 %r91, label %apush.pointer_layout.done.15, label %apush.pointer_layout.bookkeeping.14

apush.realloc.12:                                 ; preds = %apush.nofwd.10
  %statepoint_token101 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r20, double %r1655, i32 0, i32 0)
  %r102102 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token101)
  %r103 = or i64 %r102102, 9222527611924643840
  %r104 = bitcast i64 %r103 to double
  %rs4gc.b17 = bitcast double %r104 to i64
  %rs4gc.s17 = inttoptr i64 %rs4gc.b17 to ptr addrspace(1)
  br label %apush.merge.13

apush.merge.13:                                   ; preds = %apush.barrier.done.17, %apush.realloc.12, %apush.fwd.7
  %r1.1.base = phi ptr addrspace(1) [ %rs4gc.s16, %apush.fwd.7 ], [ %r1.0.base.relocated, %apush.barrier.done.17 ], [ %rs4gc.s17, %apush.realloc.12 ], !is_base_value !0
  %r1.1 = phi ptr addrspace(1) [ %rs4gc.s16, %apush.fwd.7 ], [ %r1.0.relocated, %apush.barrier.done.17 ], [ %rs4gc.s17, %apush.realloc.12 ]
  %r105 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r106 = icmp ne i32 %r105, 0
  br i1 %r106, label %gcpoll.18, label %gcpoll.done.19

apush.pointer_layout.bookkeeping.14:              ; preds = %apush.inbounds.11
  call void @js_string_addref_if_heap_string(double %r1655) #7
  call void @js_gc_note_slot_layout(i64 %r60, i32 %r81, i64 %r17) #7
  call void @js_array_note_numeric_write(i64 %r60, i64 %r17) #7
  br label %apush.pointer_layout.done.15

apush.pointer_layout.done.15:                     ; preds = %apush.pointer_layout.bookkeeping.14, %apush.inbounds.11
  %r92 = sub i64 %r60, 7
  %r93 = inttoptr i64 %r92 to ptr
  %r94 = load i8, ptr %r93, align 1
  %r95 = and i8 %r94, 32
  %r96 = icmp ne i8 %r95, 0
  %r97 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r98 = icmp ne i32 %r97, 0
  %r99 = or i1 %r96, %r98
  br i1 %r99, label %apush.barrier.16, label %apush.barrier.done.17

apush.barrier.16:                                 ; preds = %apush.pointer_layout.done.15
  call void @js_write_barrier_slot_validated_parent(i64 %r60, i64 %r85, i64 %r17) #7
  br label %apush.barrier.done.17

apush.barrier.done.17:                            ; preds = %apush.barrier.16, %apush.pointer_layout.done.15
  %r100 = add i32 %r81, 1
  %r101 = inttoptr i64 %r60 to ptr
  store i32 %r100, ptr %r101, align 4
  br label %apush.merge.13

gcpoll.18:                                        ; preds = %apush.merge.13
  %statepoint_token103 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1.1.base, ptr addrspace(1) %r1.1) ]
  %r1.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token103, i32 0, i32 0) ; (%r1.1.base, %r1.1.base)
  %r1.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token103, i32 0, i32 1) ; (%r1.1.base, %r1.1)
  br label %gcpoll.done.19

gcpoll.done.19:                                   ; preds = %gcpoll.18, %apush.merge.13
  %.0995 = phi ptr addrspace(1) [ %r1.1.relocated, %gcpoll.18 ], [ %r1.1, %apush.merge.13 ]
  %.0 = phi ptr addrspace(1) [ %r1.1.base.relocated, %gcpoll.18 ], [ %r1.1.base, %apush.merge.13 ]
  br label %for.update.5

shadow.root.barrier.20:                           ; preds = %for.exit.6
  call void @js_write_barrier_root_nanbox(i64 %r128) #7
  br label %shadow.root.barrier.done.21

shadow.root.barrier.done.21:                      ; preds = %shadow.root.barrier.20, %for.exit.6
  %statepoint_token104 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s15) ]
  %r132105 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token104)
  %rs4gc.s15.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token104, i32 0, i32 0) ; (%rs4gc.s15, %rs4gc.s15)
  %r133 = or i64 %r132105, 9222527611924643840
  %r134 = bitcast i64 %r133 to double
  %rs4gc.b18 = bitcast double %r134 to i64
  %rs4gc.s18 = inttoptr i64 %rs4gc.b18 to ptr addrspace(1)
  %r135.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r135 = call i64 asm "", "=r,0"(i64 %r135.rs4i) #7
  %r136 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r137 = icmp ne i32 %r136, 0
  br i1 %r137, label %shadow.root.barrier.22, label %shadow.root.barrier.done.23

shadow.root.barrier.22:                           ; preds = %shadow.root.barrier.done.21
  call void @js_write_barrier_root_nanbox(i64 %r135) #7
  br label %shadow.root.barrier.done.23

shadow.root.barrier.done.23:                      ; preds = %shadow.root.barrier.22, %shadow.root.barrier.done.21
  br label %for.cond.24

for.cond.24:                                      ; preds = %for.update.26, %shadow.root.barrier.done.23
  %.0996 = phi ptr addrspace(1) [ %rs4gc.s15.relocated, %shadow.root.barrier.done.23 ], [ %.39, %for.update.26 ]
  %r139.0 = phi i32 [ 0, %shadow.root.barrier.done.23 ], [ %r4182, %for.update.26 ]
  %r138.0 = phi ptr addrspace(1) [ null, %shadow.root.barrier.done.23 ], [ %.01157, %for.update.26 ]
  %r131.0.base = phi ptr addrspace(1) [ %rs4gc.s18, %shadow.root.barrier.done.23 ], [ %.111130, %for.update.26 ], !is_base_value !0
  %r131.0 = phi ptr addrspace(1) [ %rs4gc.s18, %shadow.root.barrier.done.23 ], [ %.111142, %for.update.26 ]
  %r141 = sitofp i32 %r139.0 to double
  %r142 = fcmp olt double %r141, 2.400000e+01
  %r143 = select i1 %r142, i64 9222246136947933188, i64 9222246136947933187
  %r144 = bitcast i64 %r143 to double
  %r145 = icmp eq i64 %r143, 9222246136947933188
  br i1 %r145, label %for.body.25, label %for.exit.27

for.body.25:                                      ; preds = %for.cond.24
  %r147.rs4i = ptrtoint ptr addrspace(1) %.0996 to i64
  %r147.rs4o = call i64 asm "", "=r,0"(i64 %r147.rs4i) #7
  %r147 = bitcast i64 %r147.rs4o to double
  %statepoint_token106 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r147, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r138.0, ptr addrspace(1) %r131.0.base, ptr addrspace(1) %.0996, ptr addrspace(1) %r131.0) ]
  %r148107 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token106)
  %r138.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token106, i32 0, i32 0) ; (%r138.0, %r138.0)
  %r131.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token106, i32 1, i32 1) ; (%r131.0.base, %r131.0.base)
  %rs4gc.s15.relocated108 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token106, i32 2, i32 2) ; (%.0996, %.0996)
  %r131.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token106, i32 1, i32 3) ; (%r131.0.base, %r131.0)
  %statepoint_token109 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r148107, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r138.0.relocated, ptr addrspace(1) %r131.0.base.relocated, ptr addrspace(1) %rs4gc.s15.relocated108, ptr addrspace(1) %r131.0.relocated) ]
  %r149110 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token109)
  %r138.0.relocated111 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token109, i32 0, i32 0) ; (%r138.0.relocated, %r138.0.relocated)
  %r131.0.base.relocated112 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token109, i32 1, i32 1) ; (%r131.0.base.relocated, %r131.0.base.relocated)
  %rs4gc.s15.relocated113 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token109, i32 2, i32 2) ; (%rs4gc.s15.relocated108, %rs4gc.s15.relocated108)
  %r131.0.relocated114 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token109, i32 1, i32 3) ; (%r131.0.base.relocated, %r131.0.relocated)
  %r150 = bitcast i64 %r149110 to double
  %rs4gc.b20 = bitcast double %r150 to i64
  %rs4gc.s20 = inttoptr i64 %rs4gc.b20 to ptr addrspace(1)
  %r151.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20 to i64
  %r151 = call i64 asm "", "=r,0"(i64 %r151.rs4i) #7
  %r152 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r153 = icmp ne i32 %r152, 0
  br i1 %r153, label %shadow.root.barrier.28, label %shadow.root.barrier.done.29

for.update.26:                                    ; preds = %gcpoll.done.805
  %r4182 = add i32 %r139.0, 1
  %r4183 = sitofp i32 %r139.0 to double
  %r4184 = sitofp i32 %r4182 to double
  br label %for.cond.24

for.exit.27:                                      ; preds = %for.cond.24
  %statepoint_token115 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_collect, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0996, ptr addrspace(1) %r131.0, ptr addrspace(1) %r131.0.base, ptr addrspace(1) %r138.0) ]
  %rs4gc.s15.relocated116 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token115, i32 0, i32 0) ; (%.0996, %.0996)
  %r131.0.relocated117 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token115, i32 2, i32 1) ; (%r131.0.base, %r131.0)
  %r131.0.base.relocated118 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token115, i32 2, i32 2) ; (%r131.0.base, %r131.0.base)
  %r138.0.relocated119 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token115, i32 3, i32 3) ; (%r138.0, %r138.0)
  %statepoint_token120 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s15.relocated116, ptr addrspace(1) %r131.0.relocated117, ptr addrspace(1) %r131.0.base.relocated118, ptr addrspace(1) %r138.0.relocated119) ]
  %r4185121 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token120)
  %rs4gc.s15.relocated122 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token120, i32 0, i32 0) ; (%rs4gc.s15.relocated116, %rs4gc.s15.relocated116)
  %r131.0.relocated123 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token120, i32 2, i32 1) ; (%r131.0.base.relocated118, %r131.0.relocated117)
  %r131.0.base.relocated124 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token120, i32 2, i32 2) ; (%r131.0.base.relocated118, %r131.0.base.relocated118)
  %r138.0.relocated125 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token120, i32 3, i32 3) ; (%r138.0.relocated119, %r138.0.relocated119)
  %rs4gc.s21 = inttoptr i64 %r4185121 to ptr addrspace(1)
  %r4186.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r4186 = call i64 asm "", "=r,0"(i64 %r4186.rs4i) #7
  %r4187 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4188 = icmp ne i32 %r4187, 0
  br i1 %r4188, label %shadow.root.barrier.806, label %shadow.root.barrier.done.807

shadow.root.barrier.28:                           ; preds = %for.body.25
  call void @js_write_barrier_root_nanbox(i64 %r151) #7
  br label %shadow.root.barrier.done.29

shadow.root.barrier.done.29:                      ; preds = %shadow.root.barrier.28, %for.body.25
  %r155.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20 to i64
  %r155.rs4o = call i64 asm "", "=r,0"(i64 %r155.rs4i) #7
  %r155 = bitcast i64 %r155.rs4o to double
  %r156 = bitcast double %r155 to i64
  %r157 = and i64 %r156, 281474976710655
  %r158 = and i64 %r156, -281474976710656
  %r159 = icmp eq i64 %r158, 9222527611924643840
  %r160 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r161 = icmp eq i64 %r160, 0
  %r162 = icmp ugt i64 %r157, 1048575
  %r163 = icmp ult i64 %r157, 140737488355328
  %r164 = and i1 %r162, %r163
  %r165 = and i1 %r159, %r161
  %r166 = and i1 %r165, %r164
  br i1 %r166, label %tav.get.brand.34, label %tav.get.slow.32

tav.get.fast.30:                                  ; preds = %tav.get.brand.34
  %r183 = bitcast double %r155 to i64
  %r184 = and i64 %r183, 281474976710655
  %r185 = add nuw nsw i64 %r184, 8
  %r186 = inttoptr i64 %r185 to ptr
  %r187 = load i8, ptr %r186, align 1
  %r188 = zext i8 %r187 to i64
  %r192 = inttoptr i64 %r184 to ptr
  %r193 = load i32, ptr %r192, align 4
  %r194 = zext i32 %r193 to i64
  %r195 = icmp ult i64 0, %r194
  %r196 = and i1 true, %r195
  br i1 %r196, label %tav.get.load.31, label %tav.get.slow.32

tav.get.load.31:                                  ; preds = %tav.get.fast.30
  %r197 = add nuw nsw i64 %r184, 16
  %r198 = icmp eq i64 %r188, 0
  br i1 %r198, label %tav.k.i8.35, label %tav.kd1.43

tav.get.slow.32:                                  ; preds = %tav.get.brand.34, %tav.get.fast.30, %shadow.root.barrier.done.29
  %r249 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__0, align 8
  %r250 = icmp ne ptr %r249, null
  %r251 = select i1 %r250, ptr %r249, ptr @perry_ic_test_json_tape_batch_records_ts__0
  %r252 = bitcast double %r155 to i64
  %r253 = and i64 %r252, 281474976710655
  %r254 = and i64 %r252, -281474976710656
  %r255 = icmp eq i64 %r254, 9222527611924643840
  %r256 = icmp uge i64 %r253, 2199023255552
  %r257 = icmp ult i64 %r253, 140737488355328
  %r260 = and i1 %r255, %r256
  %r261 = and i1 %r260, %r257
  br i1 %r261, label %arrlike.ic.header.50, label %arrlike.ic.miss.69

tav.get.merge.33:                                 ; preds = %arrlike.elem.value.75, %arrlike.ic.miss.69, %arrlike.ic.spill_load.68, %arrlike.ic.inline.65, %arrlike.ic.array_load.53, %tav.k.f64.42, %tav.k.f32.41, %tav.k.u32.40, %tav.k.i32.39, %tav.k.u16.38, %tav.k.i16.37, %tav.k.u8.36, %tav.k.i8.35
  %.01054 = phi ptr addrspace(1) [ %rs4gc.s20, %tav.k.i8.35 ], [ %rs4gc.s20, %tav.k.u8.36 ], [ %rs4gc.s20, %tav.k.i16.37 ], [ %rs4gc.s20, %tav.k.u16.38 ], [ %rs4gc.s20, %tav.k.i32.39 ], [ %rs4gc.s20, %tav.k.u32.40 ], [ %rs4gc.s20, %tav.k.f32.41 ], [ %rs4gc.s20, %tav.k.f64.42 ], [ %rs4gc.s20, %arrlike.ic.array_load.53 ], [ %rs4gc.s20.relocated, %arrlike.ic.miss.69 ], [ %rs4gc.s20, %arrlike.elem.value.75 ], [ %rs4gc.s20, %arrlike.ic.inline.65 ], [ %rs4gc.s20, %arrlike.ic.spill_load.68 ]
  %.01029 = phi ptr addrspace(1) [ %r131.0.relocated114, %tav.k.i8.35 ], [ %r131.0.relocated114, %tav.k.u8.36 ], [ %r131.0.relocated114, %tav.k.i16.37 ], [ %r131.0.relocated114, %tav.k.u16.38 ], [ %r131.0.relocated114, %tav.k.i32.39 ], [ %r131.0.relocated114, %tav.k.u32.40 ], [ %r131.0.relocated114, %tav.k.f32.41 ], [ %r131.0.relocated114, %tav.k.f64.42 ], [ %r131.0.relocated114, %arrlike.ic.array_load.53 ], [ %r131.0.relocated131, %arrlike.ic.miss.69 ], [ %r131.0.relocated114, %arrlike.elem.value.75 ], [ %r131.0.relocated114, %arrlike.ic.inline.65 ], [ %r131.0.relocated114, %arrlike.ic.spill_load.68 ]
  %.01004 = phi ptr addrspace(1) [ %r131.0.base.relocated112, %tav.k.i8.35 ], [ %r131.0.base.relocated112, %tav.k.u8.36 ], [ %r131.0.base.relocated112, %tav.k.i16.37 ], [ %r131.0.base.relocated112, %tav.k.u16.38 ], [ %r131.0.base.relocated112, %tav.k.i32.39 ], [ %r131.0.base.relocated112, %tav.k.u32.40 ], [ %r131.0.base.relocated112, %tav.k.f32.41 ], [ %r131.0.base.relocated112, %tav.k.f64.42 ], [ %r131.0.base.relocated112, %arrlike.ic.array_load.53 ], [ %r131.0.base.relocated129, %arrlike.ic.miss.69 ], [ %r131.0.base.relocated112, %arrlike.elem.value.75 ], [ %r131.0.base.relocated112, %arrlike.ic.inline.65 ], [ %r131.0.base.relocated112, %arrlike.ic.spill_load.68 ]
  %.0997 = phi ptr addrspace(1) [ %r138.0.relocated111, %tav.k.i8.35 ], [ %r138.0.relocated111, %tav.k.u8.36 ], [ %r138.0.relocated111, %tav.k.i16.37 ], [ %r138.0.relocated111, %tav.k.u16.38 ], [ %r138.0.relocated111, %tav.k.i32.39 ], [ %r138.0.relocated111, %tav.k.u32.40 ], [ %r138.0.relocated111, %tav.k.f32.41 ], [ %r138.0.relocated111, %tav.k.f64.42 ], [ %r138.0.relocated111, %arrlike.ic.array_load.53 ], [ %r138.0.relocated128, %arrlike.ic.miss.69 ], [ %r138.0.relocated111, %arrlike.elem.value.75 ], [ %r138.0.relocated111, %arrlike.ic.inline.65 ], [ %r138.0.relocated111, %arrlike.ic.spill_load.68 ]
  %.1 = phi ptr addrspace(1) [ %rs4gc.s15.relocated113, %tav.k.i8.35 ], [ %rs4gc.s15.relocated113, %tav.k.u8.36 ], [ %rs4gc.s15.relocated113, %tav.k.i16.37 ], [ %rs4gc.s15.relocated113, %tav.k.u16.38 ], [ %rs4gc.s15.relocated113, %tav.k.i32.39 ], [ %rs4gc.s15.relocated113, %tav.k.u32.40 ], [ %rs4gc.s15.relocated113, %tav.k.f32.41 ], [ %rs4gc.s15.relocated113, %tav.k.f64.42 ], [ %rs4gc.s15.relocated113, %arrlike.ic.array_load.53 ], [ %rs4gc.s15.relocated130, %arrlike.ic.miss.69 ], [ %rs4gc.s15.relocated113, %arrlike.elem.value.75 ], [ %rs4gc.s15.relocated113, %arrlike.ic.inline.65 ], [ %rs4gc.s15.relocated113, %arrlike.ic.spill_load.68 ]
  %r422 = phi double [ %r211, %tav.k.i8.35 ], [ %r217, %tav.k.u8.36 ], [ %r223, %tav.k.i16.37 ], [ %r229, %tav.k.u16.38 ], [ %r234, %tav.k.i32.39 ], [ %r239, %tav.k.u32.40 ], [ %r244, %tav.k.f32.41 ], [ %r248, %tav.k.f64.42 ], [ %r305, %arrlike.elem.value.75 ], [ %r333, %arrlike.ic.array_load.53 ], [ %r403, %arrlike.ic.inline.65 ], [ %r420, %arrlike.ic.spill_load.68 ], [ %r421127, %arrlike.ic.miss.69 ]
  %rs4gc.b22 = bitcast double %r422 to i64
  %rs4gc.s22 = inttoptr i64 %rs4gc.b22 to ptr addrspace(1)
  %r423 = bitcast double %r422 to i64
  %r424 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r425 = icmp ne i32 %r424, 0
  br i1 %r425, label %shadow.root.barrier.77, label %shadow.root.barrier.done.78

tav.get.brand.34:                                 ; preds = %shadow.root.barrier.done.29
  %r167 = bitcast double %r155 to i64
  %r168 = and i64 %r167, 281474976710655
  %r169 = sub nsw i64 %r168, 8
  %r170 = inttoptr i64 %r169 to ptr
  %r171 = load i8, ptr %r170, align 1
  %r172 = icmp eq i8 %r171, 11
  %r173 = add nuw nsw i64 %r168, 8
  %r174 = inttoptr i64 %r173 to ptr
  %r175 = load i8, ptr %r174, align 1
  %r176 = zext i8 %r175 to i64
  %r177 = icmp ule i64 %r176, 8
  %r180 = and i1 %r172, %r177
  br i1 %r180, label %tav.get.fast.30, label %tav.get.slow.32

tav.k.i8.35:                                      ; preds = %tav.get.load.31
  %r207 = add nuw nsw i64 %r197, 0
  %r208 = inttoptr i64 %r207 to ptr
  %r209 = load i8, ptr %r208, align 1
  %r210 = sext i8 %r209 to i32
  %r211 = sitofp i32 %r210 to double
  br label %tav.get.merge.33

tav.k.u8.36:                                      ; preds = %tav.kd7.49, %tav.kd1.43
  %r213 = add nuw nsw i64 %r197, 0
  %r214 = inttoptr i64 %r213 to ptr
  %r215 = load i8, ptr %r214, align 1
  %r216 = zext i8 %r215 to i32
  %r217 = uitofp nneg i32 %r216 to double
  br label %tav.get.merge.33

tav.k.i16.37:                                     ; preds = %tav.kd2.44
  %r219 = add nuw nsw i64 %r197, 0
  %r220 = inttoptr i64 %r219 to ptr
  %r221 = load i16, ptr %r220, align 2
  %r222 = sext i16 %r221 to i32
  %r223 = sitofp i32 %r222 to double
  br label %tav.get.merge.33

tav.k.u16.38:                                     ; preds = %tav.kd3.45
  %r225 = add nuw nsw i64 %r197, 0
  %r226 = inttoptr i64 %r225 to ptr
  %r227 = load i16, ptr %r226, align 2
  %r228 = zext i16 %r227 to i32
  %r229 = uitofp nneg i32 %r228 to double
  br label %tav.get.merge.33

tav.k.i32.39:                                     ; preds = %tav.kd4.46
  %r231 = add nuw nsw i64 %r197, 0
  %r232 = inttoptr i64 %r231 to ptr
  %r233 = load i32, ptr %r232, align 4
  %r234 = sitofp i32 %r233 to double
  br label %tav.get.merge.33

tav.k.u32.40:                                     ; preds = %tav.kd5.47
  %r236 = add nuw nsw i64 %r197, 0
  %r237 = inttoptr i64 %r236 to ptr
  %r238 = load i32, ptr %r237, align 4
  %r239 = uitofp i32 %r238 to double
  br label %tav.get.merge.33

tav.k.f32.41:                                     ; preds = %tav.kd6.48
  %r241 = add nuw nsw i64 %r197, 0
  %r242 = inttoptr i64 %r241 to ptr
  %r243 = load float, ptr %r242, align 4
  %r244 = fpext float %r243 to double
  br label %tav.get.merge.33

tav.k.f64.42:                                     ; preds = %tav.kd7.49
  %r246 = add nuw nsw i64 %r197, 0
  %r247 = inttoptr i64 %r246 to ptr
  %r248 = load double, ptr %r247, align 8
  br label %tav.get.merge.33

tav.kd1.43:                                       ; preds = %tav.get.load.31
  %r199 = icmp eq i64 %r188, 1
  br i1 %r199, label %tav.k.u8.36, label %tav.kd2.44

tav.kd2.44:                                       ; preds = %tav.kd1.43
  %r200 = icmp eq i64 %r188, 2
  br i1 %r200, label %tav.k.i16.37, label %tav.kd3.45

tav.kd3.45:                                       ; preds = %tav.kd2.44
  %r201 = icmp eq i64 %r188, 3
  br i1 %r201, label %tav.k.u16.38, label %tav.kd4.46

tav.kd4.46:                                       ; preds = %tav.kd3.45
  %r202 = icmp eq i64 %r188, 4
  br i1 %r202, label %tav.k.i32.39, label %tav.kd5.47

tav.kd5.47:                                       ; preds = %tav.kd4.46
  %r203 = icmp eq i64 %r188, 5
  br i1 %r203, label %tav.k.u32.40, label %tav.kd6.48

tav.kd6.48:                                       ; preds = %tav.kd5.47
  %r204 = icmp eq i64 %r188, 6
  br i1 %r204, label %tav.k.f32.41, label %tav.kd7.49

tav.kd7.49:                                       ; preds = %tav.kd6.48
  %r205 = icmp eq i64 %r188, 7
  br i1 %r205, label %tav.k.f64.42, label %tav.k.u8.36

arrlike.ic.header.50:                             ; preds = %tav.get.slow.32
  %r267 = sub nuw nsw i64 %r253, 8
  %r268 = inttoptr i64 %r267 to ptr
  %r269 = load i8, ptr %r268, align 1
  %r271 = sub nuw nsw i64 %r253, 7
  %r272 = inttoptr i64 %r271 to ptr
  %r273 = load i8, ptr %r272, align 1
  %r274 = and i8 %r273, -128
  %r275 = icmp eq i8 %r274, 0
  %r276 = and i1 true, %r275
  br i1 %r276, label %arrlike.ic.brand.51, label %arrlike.ic.miss.69

arrlike.ic.brand.51:                              ; preds = %arrlike.ic.header.50
  %r270 = icmp eq i8 %r269, 1
  br i1 %r270, label %arrlike.ic.array_guard.52, label %arrlike.elem.kind.70

arrlike.ic.array_guard.52:                        ; preds = %arrlike.ic.brand.51
  %r308 = sub nuw nsw i64 %r253, 6
  %r309 = inttoptr i64 %r308 to ptr
  %r310 = load i16, ptr %r309, align 2
  %r311 = and i16 %r310, 1024
  %r312 = icmp eq i16 %r311, 0
  %r313 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r314 = icmp eq i8 %r313, 0
  %r315 = inttoptr i64 %r253 to ptr
  %r316 = load i32, ptr %r315, align 4
  %r317 = add nuw nsw i64 %r253, 4
  %r318 = inttoptr i64 %r317 to ptr
  %r319 = load i32, ptr %r318, align 4
  %r320 = zext i32 %r316 to i64
  %r321 = zext i32 %r319 to i64
  %r322 = icmp ult i64 0, %r320
  %r323 = icmp ule i64 %r320, %r321
  %r324 = and i1 %r312, %r314
  %r325 = and i1 %r324, %r322
  %r326 = and i1 %r325, %r323
  br i1 %r326, label %arrlike.ic.array_load.53, label %arrlike.ic.miss.69

arrlike.ic.array_load.53:                         ; preds = %arrlike.ic.array_guard.52
  %r328 = getelementptr inbounds nuw i64, ptr %r315, i64 1
  %r329 = load double, ptr %r328, align 8
  %r330 = bitcast double %r329 to i64
  %r331 = icmp eq i64 %r330, 9222246136947933200
  %r333 = select i1 %r331, double 0x7FFC000000000001, double %r329
  br label %tav.get.merge.33

arrlike.ic.shape.54:                              ; preds = %arrlike.elem.store.72, %arrlike.elem.meta.71
  %r335 = inttoptr i64 %r253 to ptr
  %r336 = load i32, ptr %r335, align 4
  %r337 = add nuw nsw i64 %r253, 4
  %r338 = inttoptr i64 %r337 to ptr
  %r339 = load i32, ptr %r338, align 4
  %r340 = zext i32 %r336 to i64
  %r341 = zext i32 %r339 to i64
  %r342 = shl nuw i64 %r340, 32
  %r343 = or i64 %r342, %r341
  %r344 = getelementptr i64, ptr %r251, i64 0
  %r345 = load i64, ptr %r344, align 8
  %r346 = icmp ne i64 %r345, 0
  %r347 = and i1 true, %r346
  br i1 %r347, label %arrlike.ic.identity.55, label %arrlike.ic.miss.69

arrlike.ic.identity.55:                           ; preds = %arrlike.ic.shape.54
  %r348 = and i64 %r345, -9223372036854775808
  %0 = icmp slt i64 %r345, 0
  br i1 %0, label %arrlike.ic.family_meta.57, label %arrlike.ic.exact.56

arrlike.ic.exact.56:                              ; preds = %arrlike.ic.identity.55
  %r350 = icmp eq i64 %r343, %r345
  br i1 %r350, label %arrlike.ic.bounds.59, label %arrlike.ic.miss.69

arrlike.ic.family_meta.57:                        ; preds = %arrlike.ic.identity.55
  %r351 = add nuw nsw i64 %r253, 8
  %r352 = inttoptr i64 %r351 to ptr
  %r353 = load i64, ptr %r352, align 8
  %r354 = icmp ne i64 %r353, 0
  br i1 %r354, label %arrlike.ic.family_token.58, label %arrlike.ic.miss.69

arrlike.ic.family_token.58:                       ; preds = %arrlike.ic.family_meta.57
  %r355 = inttoptr i64 %r353 to ptr
  %r356 = getelementptr i64, ptr %r355, i64 6
  %r357 = load i64, ptr %r356, align 8
  %r358 = icmp eq i64 %r357, %r345
  br i1 %r358, label %arrlike.ic.bounds.59, label %arrlike.ic.miss.69

arrlike.ic.bounds.59:                             ; preds = %arrlike.ic.family_token.58, %arrlike.ic.exact.56
  %r359 = getelementptr i64, ptr %r249, i64 1
  %r360 = load i64, ptr %r359, align 8
  %r361 = getelementptr i64, ptr %r249, i64 2
  %r362 = load i64, ptr %r361, align 8
  %r363 = getelementptr i64, ptr %r249, i64 3
  %r364 = load i64, ptr %r363, align 8
  %r365 = getelementptr i64, ptr %r249, i64 4
  %r366 = load i64, ptr %r365, align 8
  %r367 = icmp ult i64 %r360, %r366
  br i1 %r367, label %arrlike.ic.length_inline.60, label %arrlike.ic.length_spill_meta.61

arrlike.ic.length_inline.60:                      ; preds = %arrlike.ic.bounds.59
  %r368 = shl i64 %r360, 3
  %r369 = add i64 %r368, 16
  %r370 = add i64 %r253, %r369
  %r371 = inttoptr i64 %r370 to ptr
  %r372 = load double, ptr %r371, align 8
  br label %arrlike.ic.range.64

arrlike.ic.length_spill_meta.61:                  ; preds = %arrlike.ic.bounds.59
  %r373 = add nuw nsw i64 %r253, 8
  %r374 = inttoptr i64 %r373 to ptr
  %r375 = load i64, ptr %r374, align 8
  %r376 = icmp ne i64 %r375, 0
  br i1 %r376, label %arrlike.ic.length_spill_ptr.62, label %arrlike.ic.miss.69

arrlike.ic.length_spill_ptr.62:                   ; preds = %arrlike.ic.length_spill_meta.61
  %r377 = inttoptr i64 %r375 to ptr
  %r378 = getelementptr i64, ptr %r377, i64 4
  %r379 = load i64, ptr %r378, align 8
  %r380 = icmp ne i64 %r379, 0
  %r381 = select i1 %r380, i64 %r379, i64 %r375
  %r382 = inttoptr i64 %r381 to ptr
  %r383 = load i32, ptr %r382, align 4
  %r384 = zext i32 %r383 to i64
  %r385 = icmp ult i64 %r360, %r384
  %r386 = and i1 %r380, %r385
  br i1 %r386, label %arrlike.ic.length_spill_load.63, label %arrlike.ic.miss.69

arrlike.ic.length_spill_load.63:                  ; preds = %arrlike.ic.length_spill_ptr.62
  %r387 = add nuw nsw i64 %r360, 1
  %r388 = getelementptr inbounds nuw i64, ptr %r382, i64 %r387
  %r389 = load double, ptr %r388, align 8
  br label %arrlike.ic.range.64

arrlike.ic.range.64:                              ; preds = %arrlike.ic.length_spill_load.63, %arrlike.ic.length_inline.60
  %r390 = phi double [ %r372, %arrlike.ic.length_inline.60 ], [ %r389, %arrlike.ic.length_spill_load.63 ]
  %r391 = fcmp olt double 0.000000e+00, %r390
  %r392 = icmp ult i64 0, %r364
  %r393 = and i1 %r391, %r392
  %r394 = add nuw nsw i64 %r362, 0
  %r395 = icmp ult i64 %r394, %r366
  %r396 = and i1 %r393, %r395
  %r397 = xor i1 %r395, true
  %r398 = and i1 %r393, %r397
  br i1 %r396, label %arrlike.ic.inline.65, label %arrlike.ic.spill_or_miss.76

arrlike.ic.inline.65:                             ; preds = %arrlike.ic.range.64
  %r399 = shl i64 %r394, 3
  %r400 = add i64 %r399, 16
  %r401 = add i64 %r253, %r400
  %r402 = inttoptr i64 %r401 to ptr
  %r403 = load double, ptr %r402, align 8
  br label %tav.get.merge.33

arrlike.ic.spill.66:                              ; preds = %arrlike.ic.spill_or_miss.76
  %r404 = add nuw nsw i64 %r253, 8
  %r405 = inttoptr i64 %r404 to ptr
  %r406 = load i64, ptr %r405, align 8
  %r407 = icmp ne i64 %r406, 0
  br i1 %r407, label %arrlike.ic.spill_ptr.67, label %arrlike.ic.miss.69

arrlike.ic.spill_ptr.67:                          ; preds = %arrlike.ic.spill.66
  %r408 = inttoptr i64 %r406 to ptr
  %r409 = getelementptr i64, ptr %r408, i64 4
  %r410 = load i64, ptr %r409, align 8
  %r411 = icmp ne i64 %r410, 0
  %r412 = select i1 %r411, i64 %r410, i64 %r406
  %r413 = inttoptr i64 %r412 to ptr
  %r414 = load i32, ptr %r413, align 4
  %r415 = zext i32 %r414 to i64
  %r416 = icmp ult i64 %r394, %r415
  %r417 = and i1 %r411, %r416
  br i1 %r417, label %arrlike.ic.spill_load.68, label %arrlike.ic.miss.69

arrlike.ic.spill_load.68:                         ; preds = %arrlike.ic.spill_ptr.67
  %r418 = add nuw nsw i64 %r394, 1
  %r419 = getelementptr inbounds nuw i64, ptr %r413, i64 %r418
  %r420 = load double, ptr %r419, align 8
  br label %tav.get.merge.33

arrlike.ic.miss.69:                               ; preds = %arrlike.ic.spill_or_miss.76, %arrlike.elem.load.74, %arrlike.elem.bounds.73, %arrlike.elem.kind.70, %arrlike.ic.spill_ptr.67, %arrlike.ic.spill.66, %arrlike.ic.length_spill_ptr.62, %arrlike.ic.length_spill_meta.61, %arrlike.ic.family_token.58, %arrlike.ic.family_meta.57, %arrlike.ic.exact.56, %arrlike.ic.shape.54, %arrlike.ic.array_guard.52, %arrlike.ic.header.50, %tav.get.slow.32
  %statepoint_token126 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, ptr)) @js_packed_arraylike_index_get, i32 3, i32 0, double %r155, double 0.000000e+00, ptr @perry_ic_test_json_tape_batch_records_ts__0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r138.0.relocated111, ptr addrspace(1) %rs4gc.s20, ptr addrspace(1) %r131.0.base.relocated112, ptr addrspace(1) %rs4gc.s15.relocated113, ptr addrspace(1) %r131.0.relocated114) ]
  %r421127 = call double @llvm.experimental.gc.result.f64(token %statepoint_token126)
  %r138.0.relocated128 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token126, i32 0, i32 0) ; (%r138.0.relocated111, %r138.0.relocated111)
  %rs4gc.s20.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token126, i32 1, i32 1) ; (%rs4gc.s20, %rs4gc.s20)
  %r131.0.base.relocated129 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token126, i32 2, i32 2) ; (%r131.0.base.relocated112, %r131.0.base.relocated112)
  %rs4gc.s15.relocated130 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token126, i32 3, i32 3) ; (%rs4gc.s15.relocated113, %rs4gc.s15.relocated113)
  %r131.0.relocated131 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token126, i32 2, i32 4) ; (%r131.0.base.relocated112, %r131.0.relocated114)
  br label %tav.get.merge.33

arrlike.elem.kind.70:                             ; preds = %arrlike.ic.brand.51
  %r277 = icmp eq i8 %r269, 2
  br i1 %r277, label %arrlike.elem.meta.71, label %arrlike.ic.miss.69

arrlike.elem.meta.71:                             ; preds = %arrlike.elem.kind.70
  %r278 = add nuw nsw i64 %r253, 8
  %r279 = inttoptr i64 %r278 to ptr
  %r280 = load i64, ptr %r279, align 8
  %r281 = icmp ne i64 %r280, 0
  br i1 %r281, label %arrlike.elem.store.72, label %arrlike.ic.shape.54

arrlike.elem.store.72:                            ; preds = %arrlike.elem.meta.71
  %r282 = inttoptr i64 %r280 to ptr
  %r283 = getelementptr i64, ptr %r282, i64 12
  %r284 = load i64, ptr %r283, align 8
  %r285 = icmp ne i64 %r284, 0
  br i1 %r285, label %arrlike.elem.bounds.73, label %arrlike.ic.shape.54

arrlike.elem.bounds.73:                           ; preds = %arrlike.elem.store.72
  %r286 = sub i64 %r284, 8
  %r287 = inttoptr i64 %r286 to ptr
  %r288 = load i8, ptr %r287, align 1
  %r289 = icmp eq i8 %r288, 1
  %r290 = sub i64 %r284, 7
  %r291 = inttoptr i64 %r290 to ptr
  %r292 = load i8, ptr %r291, align 1
  %r293 = and i8 %r292, -128
  %r294 = icmp eq i8 %r293, 0
  %r295 = inttoptr i64 %r284 to ptr
  %r296 = load i32, ptr %r295, align 4
  %r297 = zext i32 %r296 to i64
  %r298 = icmp ult i64 0, %r297
  %r299 = and i1 %r289, %r294
  %r300 = and i1 %r299, %r298
  br i1 %r300, label %arrlike.elem.load.74, label %arrlike.ic.miss.69

arrlike.elem.load.74:                             ; preds = %arrlike.elem.bounds.73
  %r302 = add i64 %r284, 8
  %r303 = add nuw nsw i64 %r302, 0
  %r304 = inttoptr i64 %r303 to ptr
  %r305 = load double, ptr %r304, align 8
  %r306 = bitcast double %r305 to i64
  %r307 = icmp eq i64 %r306, 9222246136947933200
  br i1 %r307, label %arrlike.ic.miss.69, label %arrlike.elem.value.75

arrlike.elem.value.75:                            ; preds = %arrlike.elem.load.74
  br label %tav.get.merge.33

arrlike.ic.spill_or_miss.76:                      ; preds = %arrlike.ic.range.64
  br i1 %r398, label %arrlike.ic.spill.66, label %arrlike.ic.miss.69

shadow.root.barrier.77:                           ; preds = %tav.get.merge.33
  call void @js_write_barrier_root_nanbox(i64 %r423) #7
  br label %shadow.root.barrier.done.78

shadow.root.barrier.done.78:                      ; preds = %shadow.root.barrier.77, %tav.get.merge.33
  %r426 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r427 = load double, ptr @test_json_tape_batch_records_ts_.str.14.handle, align 8
  %r429 = sitofp i32 %r139.0 to double
  %r430 = fcmp oge double %r429, 0.000000e+00
  %r431 = fcmp olt double %r429, 3.200000e+01
  %r432 = and i1 %r430, %r431
  br i1 %r432, label %csite.chk.79, label %csite.plain.82

csite.chk.79:                                     ; preds = %shadow.root.barrier.done.78
  %r433 = fptosi double %r429 to i32
  %r434 = sitofp i32 %r433 to double
  %r435 = fcmp oeq double %r434, %r429
  %r436 = sext i32 %r433 to i64
  %r437 = getelementptr [32 x i64], ptr @perry_concat_site_test_json_tape_batch_records_ts__1, i64 0, i64 %r436
  %r438 = load i64, ptr %r437, align 8
  %r439 = icmp ne i64 %r438, 0
  %r440 = and i1 %r435, %r439
  br i1 %r440, label %csite.hit.80, label %csite.fill.81

csite.hit.80:                                     ; preds = %csite.chk.79
  %r441 = bitcast i64 %r438 to double
  br label %csite.merge.83

csite.fill.81:                                    ; preds = %csite.chk.79
  %r442 = bitcast double %r427 to i64
  %r443 = and i64 %r442, 281474976710655
  %statepoint_token132 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, double)) @js_string_concat_site_value, i32 3, i32 0, i64 ptrtoint (ptr @perry_concat_site_test_json_tape_batch_records_ts__1 to i64), i64 %r443, double %r429, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0997, ptr addrspace(1) %.01054, ptr addrspace(1) %.01004, ptr addrspace(1) %rs4gc.s22, ptr addrspace(1) %.1, ptr addrspace(1) %.01029) ]
  %r445133 = call double @llvm.experimental.gc.result.f64(token %statepoint_token132)
  %r138.0.relocated134 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token132, i32 0, i32 0) ; (%.0997, %.0997)
  %rs4gc.s20.relocated135 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token132, i32 1, i32 1) ; (%.01054, %.01054)
  %r131.0.base.relocated136 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token132, i32 2, i32 2) ; (%.01004, %.01004)
  %rs4gc.s22.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token132, i32 3, i32 3) ; (%rs4gc.s22, %rs4gc.s22)
  %rs4gc.s15.relocated137 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token132, i32 4, i32 4) ; (%.1, %.1)
  %r131.0.relocated138 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token132, i32 2, i32 5) ; (%.01004, %.01029)
  br label %csite.merge.83

csite.plain.82:                                   ; preds = %shadow.root.barrier.done.78
  %r446 = bitcast double %r427 to i64
  %r447 = and i64 %r446, 281474976710655
  %statepoint_token139 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r447, double %r429, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0997, ptr addrspace(1) %.01054, ptr addrspace(1) %.01004, ptr addrspace(1) %rs4gc.s22, ptr addrspace(1) %.1, ptr addrspace(1) %.01029) ]
  %r448140 = call double @llvm.experimental.gc.result.f64(token %statepoint_token139)
  %r138.0.relocated141 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token139, i32 0, i32 0) ; (%.0997, %.0997)
  %rs4gc.s20.relocated142 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token139, i32 1, i32 1) ; (%.01054, %.01054)
  %r131.0.base.relocated143 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token139, i32 2, i32 2) ; (%.01004, %.01004)
  %rs4gc.s22.relocated144 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token139, i32 3, i32 3) ; (%rs4gc.s22, %rs4gc.s22)
  %rs4gc.s15.relocated145 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token139, i32 4, i32 4) ; (%.1, %.1)
  %r131.0.relocated146 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token139, i32 2, i32 5) ; (%.01004, %.01029)
  br label %csite.merge.83

csite.merge.83:                                   ; preds = %csite.plain.82, %csite.fill.81, %csite.hit.80
  %.01086 = phi ptr addrspace(1) [ %rs4gc.s22, %csite.hit.80 ], [ %rs4gc.s22.relocated, %csite.fill.81 ], [ %rs4gc.s22.relocated144, %csite.plain.82 ]
  %.11055 = phi ptr addrspace(1) [ %.01054, %csite.hit.80 ], [ %rs4gc.s20.relocated135, %csite.fill.81 ], [ %rs4gc.s20.relocated142, %csite.plain.82 ]
  %.11030 = phi ptr addrspace(1) [ %.01029, %csite.hit.80 ], [ %r131.0.relocated138, %csite.fill.81 ], [ %r131.0.relocated146, %csite.plain.82 ]
  %.11005 = phi ptr addrspace(1) [ %.01004, %csite.hit.80 ], [ %r131.0.base.relocated136, %csite.fill.81 ], [ %r131.0.base.relocated143, %csite.plain.82 ]
  %.1998 = phi ptr addrspace(1) [ %.0997, %csite.hit.80 ], [ %r138.0.relocated134, %csite.fill.81 ], [ %r138.0.relocated141, %csite.plain.82 ]
  %.2 = phi ptr addrspace(1) [ %.1, %csite.hit.80 ], [ %rs4gc.s15.relocated137, %csite.fill.81 ], [ %rs4gc.s15.relocated145, %csite.plain.82 ]
  %r449 = phi double [ %r441, %csite.hit.80 ], [ %r445133, %csite.fill.81 ], [ %r448140, %csite.plain.82 ]
  %r450 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r451.rs4i = ptrtoint ptr addrspace(1) %.01086 to i64
  %r451.rs4o = call i64 asm "", "=r,0"(i64 %r451.rs4i) #7
  %r451 = bitcast i64 %r451.rs4o to double
  %r452 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__2, align 8
  %r453 = icmp ne ptr %r452, null
  %r454 = select i1 %r453, ptr %r452, ptr @perry_ic_test_json_tape_batch_records_ts__2
  %r457 = bitcast double %r450 to i64
  %r458 = bitcast double %r449 to i64
  %r459 = bitcast double %r451 to i64
  %r460 = and i64 %r459, 281474976710655
  %r461 = lshr i64 %r459, 48
  %r462 = icmp eq i64 %r461, 32765
  %r463 = icmp ugt i64 %r460, 1048575
  %r464 = lshr i64 %r458, 48
  %r465 = icmp ne i64 %r464, 32765
  %r466 = icmp ne i64 %r464, 32767
  %r467 = icmp ne i64 %r464, 32762
  %r468 = and i1 %r465, %r466
  %r469 = and i1 %r468, %r467
  %r470 = icmp ne i64 %r457, 0
  %r471 = and i1 %r462, %r463
  %r472 = and i1 %r471, %r470
  br i1 %r472, label %put.dynic.guard.84, label %put.dynic.slow.102

put.dynic.guard.84:                               ; preds = %csite.merge.83
  %r473 = sub nuw nsw i64 %r460, 8
  %r474 = inttoptr i64 %r473 to ptr
  %r475 = load i8, ptr %r474, align 1
  %r476 = icmp eq i8 %r475, 2
  %r477 = sub nuw nsw i64 %r460, 7
  %r478 = inttoptr i64 %r477 to ptr
  %r479 = load i8, ptr %r478, align 1
  %r480 = and i8 %r479, -128
  %r481 = icmp eq i8 %r480, 0
  %r482 = sub nuw nsw i64 %r460, 6
  %r483 = inttoptr i64 %r482 to ptr
  %r484 = load i16, ptr %r483, align 2
  %r485 = and i16 %r484, 6535
  %r486 = icmp eq i16 %r485, 0
  %r487 = add nuw nsw i64 %r460, 0
  %r488 = inttoptr i64 %r487 to ptr
  %r489 = load i32, ptr %r488, align 4
  %r490 = icmp ne i32 %r489, 0
  %r491 = icmp ne i32 %r489, -2
  %r492 = and i16 %r484, 512
  %r493 = icmp ne i16 %r492, 0
  %r494 = or i1 %r490, %r493
  %r495 = add nuw nsw i64 %r460, 4
  %r496 = inttoptr i64 %r495 to ptr
  %r497 = load i32, ptr %r496, align 4
  %r498 = add i32 %r497, -2147483648
  %r499 = icmp ult i32 %r498, 1073741824
  %r500 = zext i32 %r497 to i64
  %r501 = or i64 %r500, 4611686018427387904
  %r502 = select i1 %r499, i64 %r501, i64 0
  %r503 = getelementptr i64, ptr %r454, i64 0
  %r504 = load i64, ptr %r503, align 8
  %r505 = icmp eq i64 %r502, %r504
  %r506 = icmp ne i64 %r502, 0
  %r507 = and i1 %r476, %r481
  %r508 = and i1 %r507, %r486
  %r509 = and i1 %r508, %r494
  %r510 = and i1 %r509, %r491
  %r511 = and i1 %r505, %r506
  %r512 = and i1 %r510, %r511
  br i1 %r512, label %put.dynic.ways.85, label %put.dynic.trans.gate.93

put.dynic.ways.85:                                ; preds = %put.dynic.guard.84
  %r514 = getelementptr i64, ptr %r452, i64 1
  %r515 = load i64, ptr %r514, align 8
  %r516 = getelementptr i64, ptr %r452, i64 2
  %r517 = load i64, ptr %r516, align 8
  %r518 = icmp eq i64 %r457, %r515
  br i1 %r518, label %put.dynic.store.88, label %put.dynic.way1.86

put.dynic.way1.86:                                ; preds = %put.dynic.ways.85
  %r519 = getelementptr i64, ptr %r452, i64 3
  %r520 = load i64, ptr %r519, align 8
  %r521 = getelementptr i64, ptr %r452, i64 4
  %r522 = load i64, ptr %r521, align 8
  %r523 = icmp eq i64 %r457, %r520
  br i1 %r523, label %put.dynic.store.88, label %put.dynic.way2.87

put.dynic.way2.87:                                ; preds = %put.dynic.way1.86
  %r524 = getelementptr i64, ptr %r452, i64 5
  %r525 = load i64, ptr %r524, align 8
  %r526 = getelementptr i64, ptr %r452, i64 6
  %r527 = load i64, ptr %r526, align 8
  %r528 = icmp eq i64 %r457, %r525
  br i1 %r528, label %put.dynic.store.88, label %put.dynic.trans.probe.94

put.dynic.store.88:                               ; preds = %put.dynic.way2.87, %put.dynic.way1.86, %put.dynic.ways.85
  %r529 = phi i64 [ %r517, %put.dynic.ways.85 ], [ %r522, %put.dynic.way1.86 ], [ %r527, %put.dynic.way2.87 ]
  %r530 = shl i64 %r529, 3
  %r531 = add i64 %r530, 16
  %r532 = inttoptr i64 %r460 to ptr
  %r533 = getelementptr inbounds i8, ptr %r532, i64 %r531
  %r534 = and i16 %r484, 1024
  %r535 = icmp ne i16 %r534, 0
  br i1 %r535, label %put.dynic.store.validate.89, label %put.dynic.store.dispatch.90

put.dynic.store.validate.89:                      ; preds = %put.dynic.store.88
  %r536 = load double, ptr %r533, align 8
  %r537 = bitcast double %r536 to i64
  %r538 = icmp eq i64 %r537, 9222246136947933200
  br i1 %r538, label %put.dynic.slow.102, label %put.dynic.store.dispatch.90

put.dynic.store.dispatch.90:                      ; preds = %put.dynic.store.validate.89, %put.dynic.store.88
  br i1 %r469, label %put.dynic.store.scalar.91, label %put.dynic.store.ref.92

put.dynic.store.scalar.91:                        ; preds = %put.dynic.store.dispatch.90
  store double %r449, ptr %r533, align 8
  br label %put.dynic.merge.103

put.dynic.store.ref.92:                           ; preds = %put.dynic.store.dispatch.90
  %r539 = trunc i64 %r529 to i32
  %r540 = shl i64 %r529, 3
  %r541 = add nuw nsw i64 %r460, 16
  %r542 = add i64 %r541, %r540
  %r543 = load double, ptr %r533, align 8
  %r544 = bitcast double %r543 to i64
  store double %r449, ptr %r533, align 8
  call void @js_string_addref_if_heap_string(double %r449) #7
  %r545 = bitcast double %r449 to i64
  %r5984.rs4i = ptrtoint ptr addrspace(1) %.01086 to i64
  %r5984.rs4o = call i64 asm "", "=r,0"(i64 %r5984.rs4i) #7
  %r5984 = bitcast i64 %r5984.rs4o to double
  %r5985 = bitcast double %r5984 to i64
  %r5986 = and i64 %r5985, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r5986, i32 %r539, i64 %r545, i64 %r544) #7
  %r5982.rs4i = ptrtoint ptr addrspace(1) %.01086 to i64
  %r5982.rs4o = call i64 asm "", "=r,0"(i64 %r5982.rs4i) #7
  %r5982 = bitcast i64 %r5982.rs4o to double
  %r5983 = bitcast double %r5982 to i64
  call void @js_write_barrier_slot(i64 %r5983, i64 %r542, i64 %r545) #7
  br label %put.dynic.merge.103

put.dynic.trans.gate.93:                          ; preds = %put.dynic.guard.84
  %r513 = and i1 %r510, %r506
  br i1 %r513, label %put.dynic.trans.probe.94, label %put.dynic.slow.102

put.dynic.trans.probe.94:                         ; preds = %put.dynic.trans.gate.93, %put.dynic.way2.87
  %r546 = lshr i64 %r457, 48
  %r547 = icmp eq i64 %r546, 32767
  %r548 = and i64 %r457, 281474976710655
  %r549 = icmp ugt i64 %r548, 1048575
  %r550 = and i16 %r484, -16384
  %r551 = icmp eq i16 %r550, 0
  %r552 = and i8 %r479, 32
  %r553 = icmp eq i8 %r552, 0
  %r554 = and i1 %r547, %r549
  %r555 = and i1 %r554, %r551
  %r556 = and i1 %r555, %r553
  br i1 %r556, label %put.dynic.trans.key.95, label %put.dynic.slow.102

put.dynic.trans.key.95:                           ; preds = %put.dynic.trans.probe.94
  %r557 = and i64 %r457, 281474976710655
  %r558 = add nuw nsw i64 %r557, 4
  %r559 = inttoptr i64 %r558 to ptr
  %r560 = load i32, ptr %r559, align 4
  %r561 = icmp uge i32 %r560, 6
  %r562 = icmp ule i32 %r560, 8
  %r563 = add nuw nsw i64 %r557, 20
  %r564 = inttoptr i64 %r563 to ptr
  %r565 = load i8, ptr %r564, align 1
  %r566 = sub i8 %r565, 48
  %r567 = icmp ult i8 %r566, 10
  %r568 = icmp eq i1 %r567, false
  %r569 = and i1 %r561, %r562
  %r570 = and i1 %r569, %r568
  br i1 %r570, label %put.dynic.trans.entry.96, label %put.dynic.slow.102

put.dynic.trans.entry.96:                         ; preds = %put.dynic.trans.key.95
  %r571 = add nuw nsw i64 %r557, 20
  %r572 = inttoptr i64 %r571 to ptr
  %r573 = load i64, ptr %r572, align 8
  %r574 = zext nneg i32 %r560 to i64
  %r575 = sub nuw nsw i64 8, %r574
  %r576 = shl nuw nsw i64 %r575, 3
  %r577 = lshr i64 -1, %r576
  %r578 = and i64 %r573, %r577
  %r580 = ptrtoint ptr %r456 to i64
  %r581 = zext i32 %r497 to i64
  %r582 = mul i64 %r581, -7046029254386353131
  %r583 = lshr i64 %r578, 3
  %r584 = mul i64 %r583, -4126379630918253789
  %r585 = xor i64 %r582, %r584
  %r586 = and i64 %r585, 16383
  %r587 = shl nuw nsw i64 %r586, 5
  %r588 = add i64 %r580, %r587
  %r589 = inttoptr i64 %r588 to ptr
  %r590 = load i64, ptr %r589, align 8
  %r591 = add i64 %r588, 8
  %r592 = inttoptr i64 %r591 to ptr
  %r593 = load i64, ptr %r592, align 8
  %r594 = add i64 %r588, 16
  %r595 = inttoptr i64 %r594 to ptr
  %r596 = load i32, ptr %r595, align 4
  %r597 = add i64 %r588, 20
  %r598 = inttoptr i64 %r597 to ptr
  %r599 = load i32, ptr %r598, align 4
  %r600 = add i64 %r588, 24
  %r601 = inttoptr i64 %r600 to ptr
  %r602 = load i32, ptr %r601, align 4
  %r603 = lshr i32 %r602, 24
  %r604 = and i32 %r602, 16777215
  %r605 = add i64 %r588, 28
  %r606 = inttoptr i64 %r605 to ptr
  %r607 = load i32, ptr %r606, align 4
  %r608 = icmp eq i64 %r590, %r578
  %r609 = icmp eq i32 %r603, %r560
  %r610 = icmp eq i32 %r596, %r497
  %r611 = icmp ne i64 %r593, 0
  %r612 = add nuw nsw i32 %r604, 1
  %r613 = icmp eq i32 %r607, %r612
  %r614 = zext nneg i32 %r604 to i64
  %r615 = and i64 %r458, 281474976710655
  %r616 = icmp eq i64 %r464, 32765
  %r617 = icmp eq i64 %r615, 0
  %r618 = and i1 %r616, %r617
  %r619 = select i1 %r618, i64 9222246136947933185, i64 %r458
  %r620 = bitcast i64 %r619 to double
  %r621 = and i1 %r608, %r609
  %r622 = and i1 %r621, %r610
  %r623 = and i1 %r622, %r611
  %r624 = and i1 %r623, %r613
  br i1 %r624, label %put.dynic.trans.nk.97, label %put.dynic.slow.102

put.dynic.trans.nk.97:                            ; preds = %put.dynic.trans.entry.96
  %r625 = inttoptr i64 %r593 to ptr
  %r626 = load i32, ptr %r625, align 4
  %r627 = icmp eq i32 %r626, %r612
  br i1 %r627, label %put.dynic.trans.dispatch.98, label %put.dynic.slow.102

put.dynic.trans.dispatch.98:                      ; preds = %put.dynic.trans.nk.97
  %r628 = icmp ult i64 %r614, 2
  br i1 %r628, label %put.dynic.trans.inline_ref.99, label %put.dynic.trans.ovf.100

put.dynic.trans.inline_ref.99:                    ; preds = %put.dynic.trans.dispatch.98
  %r629 = shl nuw nsw i64 %r614, 3
  %r630 = add nuw nsw i64 %r629, 16
  %r631 = add nuw nsw i64 %r460, %r630
  %r632 = inttoptr i64 %r631 to ptr
  %r633 = trunc nuw nsw i64 %r614 to i32
  %r634 = load double, ptr %r632, align 8
  %r635 = bitcast double %r634 to i64
  store double %r620, ptr %r632, align 8
  call void @js_string_addref_if_heap_string(double %r620) #7
  %r636 = bitcast double %r620 to i64
  %r5979.rs4i = ptrtoint ptr addrspace(1) %.01086 to i64
  %r5979.rs4o = call i64 asm "", "=r,0"(i64 %r5979.rs4i) #7
  %r5979 = bitcast i64 %r5979.rs4o to double
  %r5980 = bitcast double %r5979 to i64
  %r5981 = and i64 %r5980, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r5981, i32 %r633, i64 %r636, i64 %r635) #7
  %r5977.rs4i = ptrtoint ptr addrspace(1) %.01086 to i64
  %r5977.rs4o = call i64 asm "", "=r,0"(i64 %r5977.rs4i) #7
  %r5977 = bitcast i64 %r5977.rs4o to double
  %r5978 = bitcast double %r5977 to i64
  call void @js_write_barrier_slot(i64 %r5978, i64 %r631, i64 %r636) #7
  br label %put.dynic.trans.stamp.101

put.dynic.trans.ovf.100:                          ; preds = %put.dynic.trans.dispatch.98
  %r637 = trunc nuw nsw i64 %r614 to i32
  %r638 = call i32 @js_transition_ic_spill_append(double %r451, i64 %r502, i32 %r637, double %r620) #7
  %r639 = icmp ne i32 %r638, 0
  br i1 %r639, label %put.dynic.trans.stamp.101, label %put.dynic.slow.102

put.dynic.trans.stamp.101:                        ; preds = %put.dynic.trans.ovf.100, %put.dynic.trans.inline_ref.99
  %r5974.rs4i = ptrtoint ptr addrspace(1) %.01086 to i64
  %r5974.rs4o = call i64 asm "", "=r,0"(i64 %r5974.rs4i) #7
  %r5974 = bitcast i64 %r5974.rs4o to double
  %r5975 = bitcast double %r5974 to i64
  %r5976 = and i64 %r5975, 281474976710655
  %r640 = add nuw nsw i64 %r5976, 4
  %r641 = inttoptr i64 %r640 to ptr
  store i32 %r599, ptr %r641, align 4
  br label %put.dynic.merge.103

put.dynic.slow.102:                               ; preds = %put.dynic.trans.ovf.100, %put.dynic.trans.nk.97, %put.dynic.trans.entry.96, %put.dynic.trans.key.95, %put.dynic.trans.probe.94, %put.dynic.trans.gate.93, %put.dynic.store.validate.89, %csite.merge.83
  %statepoint_token147 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, double, double, i32)) @js_put_value_set_dyn_ic, i32 5, i32 0, ptr @perry_ic_test_json_tape_batch_records_ts__2, double %r451, double %r450, double %r449, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1998, ptr addrspace(1) %.11055, ptr addrspace(1) %.11005, ptr addrspace(1) %.01086, ptr addrspace(1) %.2, ptr addrspace(1) %.11030) ]
  %r642148 = call double @llvm.experimental.gc.result.f64(token %statepoint_token147)
  %r138.0.relocated149 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token147, i32 0, i32 0) ; (%.1998, %.1998)
  %rs4gc.s20.relocated150 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token147, i32 1, i32 1) ; (%.11055, %.11055)
  %r131.0.base.relocated151 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token147, i32 2, i32 2) ; (%.11005, %.11005)
  %rs4gc.s22.relocated152 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token147, i32 3, i32 3) ; (%.01086, %.01086)
  %rs4gc.s15.relocated153 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token147, i32 4, i32 4) ; (%.2, %.2)
  %r131.0.relocated154 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token147, i32 2, i32 5) ; (%.11005, %.11030)
  br label %put.dynic.merge.103

put.dynic.merge.103:                              ; preds = %put.dynic.slow.102, %put.dynic.trans.stamp.101, %put.dynic.store.ref.92, %put.dynic.store.scalar.91
  %.11087 = phi ptr addrspace(1) [ %rs4gc.s22.relocated152, %put.dynic.slow.102 ], [ %.01086, %put.dynic.store.scalar.91 ], [ %.01086, %put.dynic.store.ref.92 ], [ %.01086, %put.dynic.trans.stamp.101 ]
  %.21056 = phi ptr addrspace(1) [ %rs4gc.s20.relocated150, %put.dynic.slow.102 ], [ %.11055, %put.dynic.store.scalar.91 ], [ %.11055, %put.dynic.store.ref.92 ], [ %.11055, %put.dynic.trans.stamp.101 ]
  %.21031 = phi ptr addrspace(1) [ %r131.0.relocated154, %put.dynic.slow.102 ], [ %.11030, %put.dynic.store.scalar.91 ], [ %.11030, %put.dynic.store.ref.92 ], [ %.11030, %put.dynic.trans.stamp.101 ]
  %.21006 = phi ptr addrspace(1) [ %r131.0.base.relocated151, %put.dynic.slow.102 ], [ %.11005, %put.dynic.store.scalar.91 ], [ %.11005, %put.dynic.store.ref.92 ], [ %.11005, %put.dynic.trans.stamp.101 ]
  %.2999 = phi ptr addrspace(1) [ %r138.0.relocated149, %put.dynic.slow.102 ], [ %.1998, %put.dynic.store.scalar.91 ], [ %.1998, %put.dynic.store.ref.92 ], [ %.1998, %put.dynic.trans.stamp.101 ]
  %.3 = phi ptr addrspace(1) [ %rs4gc.s15.relocated153, %put.dynic.slow.102 ], [ %.2, %put.dynic.store.scalar.91 ], [ %.2, %put.dynic.store.ref.92 ], [ %.2, %put.dynic.trans.stamp.101 ]
  %r643 = phi double [ %r449, %put.dynic.store.scalar.91 ], [ %r449, %put.dynic.store.ref.92 ], [ %r620, %put.dynic.trans.stamp.101 ], [ %r642148, %put.dynic.slow.102 ]
  %r644.rs4i = ptrtoint ptr addrspace(1) %.11087 to i64
  %r644.rs4o = call i64 asm "", "=r,0"(i64 %r644.rs4i) #7
  %r644 = bitcast i64 %r644.rs4o to double
  %r645 = bitcast double %r644 to i64
  %r646 = and i64 %r645, 281474976710655
  %r647 = lshr i64 %r645, 48
  %r648 = and i64 %r647, 65533
  %r649 = icmp eq i64 %r648, 32765
  br i1 %r649, label %pget.recv_ok.105, label %pget.recv_other.109

pget.recv_sso.104:                                ; preds = %pget.recv_other.109
  %r787 = load double, ptr @test_json_tape_batch_records_ts_.str.15.handle, align 8
  %r788 = bitcast double %r787 to i64
  %r789 = and i64 %r788, 281474976710655
  %statepoint_token155 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r645, i64 %r789, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2999, ptr addrspace(1) %.21056, ptr addrspace(1) %.21006, ptr addrspace(1) %.11087, ptr addrspace(1) %.3, ptr addrspace(1) %.21031) ]
  %r790156 = call double @llvm.experimental.gc.result.f64(token %statepoint_token155)
  %r138.0.relocated157 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 0, i32 0) ; (%.2999, %.2999)
  %rs4gc.s20.relocated158 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 1, i32 1) ; (%.21056, %.21056)
  %r131.0.base.relocated159 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 2, i32 2) ; (%.21006, %.21006)
  %rs4gc.s22.relocated160 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 3, i32 3) ; (%.11087, %.11087)
  %rs4gc.s15.relocated161 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 4, i32 4) ; (%.3, %.3)
  %r131.0.relocated162 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 2, i32 5) ; (%.21006, %.21031)
  br label %pget.recv_merge.108

pget.recv_ok.105:                                 ; preds = %put.dynic.merge.103
  %r656 = icmp ugt i64 %r646, 1048575
  br i1 %r656, label %pic.recv_hdr.126, label %pic.miss.cold.123

pget.recv_bad.106:                                ; preds = %pget.check_class_ref.110
  %r779 = icmp eq i64 %r645, 9222246136947933185
  %r780 = icmp eq i64 %r645, 9222246136947933186
  %r781 = or i1 %r779, %r780
  br i1 %r781, label %pget.throw_nullish.133, label %pget.recv_undef_return.134

pget.recv_class_ref.107:                          ; preds = %pget.check_class_ref.110
  %r652 = load double, ptr @test_json_tape_batch_records_ts_.str.15.handle, align 8
  %r653 = bitcast double %r652 to i64
  %r654 = and i64 %r653, 281474976710655
  %statepoint_token163 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 367713371643969539, i64 %r645, i64 %r654, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2999, ptr addrspace(1) %.21056, ptr addrspace(1) %.21006, ptr addrspace(1) %.11087, ptr addrspace(1) %.3, ptr addrspace(1) %.21031) ]
  %r655164 = call double @llvm.experimental.gc.result.f64(token %statepoint_token163)
  %r138.0.relocated165 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token163, i32 0, i32 0) ; (%.2999, %.2999)
  %rs4gc.s20.relocated166 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token163, i32 1, i32 1) ; (%.21056, %.21056)
  %r131.0.base.relocated167 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token163, i32 2, i32 2) ; (%.21006, %.21006)
  %rs4gc.s22.relocated168 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token163, i32 3, i32 3) ; (%.11087, %.11087)
  %rs4gc.s15.relocated169 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token163, i32 4, i32 4) ; (%.3, %.3)
  %r131.0.relocated170 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token163, i32 2, i32 5) ; (%.21006, %.21031)
  br label %pget.recv_merge.108

pget.recv_merge.108:                              ; preds = %pget.recv_undef_return.134, %pic.merge.125, %pget.recv_class_ref.107, %pget.recv_sso.104
  %.21088 = phi ptr addrspace(1) [ %.31089, %pic.merge.125 ], [ %rs4gc.s22.relocated160, %pget.recv_sso.104 ], [ %rs4gc.s22.relocated168, %pget.recv_class_ref.107 ], [ %rs4gc.s22.relocated208, %pget.recv_undef_return.134 ]
  %.31057 = phi ptr addrspace(1) [ %.41058, %pic.merge.125 ], [ %rs4gc.s20.relocated158, %pget.recv_sso.104 ], [ %rs4gc.s20.relocated166, %pget.recv_class_ref.107 ], [ %rs4gc.s20.relocated206, %pget.recv_undef_return.134 ]
  %.31032 = phi ptr addrspace(1) [ %.41033, %pic.merge.125 ], [ %r131.0.relocated162, %pget.recv_sso.104 ], [ %r131.0.relocated170, %pget.recv_class_ref.107 ], [ %r131.0.relocated210, %pget.recv_undef_return.134 ]
  %.31007 = phi ptr addrspace(1) [ %.41008, %pic.merge.125 ], [ %r131.0.base.relocated159, %pget.recv_sso.104 ], [ %r131.0.base.relocated167, %pget.recv_class_ref.107 ], [ %r131.0.base.relocated207, %pget.recv_undef_return.134 ]
  %.31000 = phi ptr addrspace(1) [ %.41001, %pic.merge.125 ], [ %r138.0.relocated157, %pget.recv_sso.104 ], [ %r138.0.relocated165, %pget.recv_class_ref.107 ], [ %r138.0.relocated205, %pget.recv_undef_return.134 ]
  %.4 = phi ptr addrspace(1) [ %.5, %pic.merge.125 ], [ %rs4gc.s15.relocated161, %pget.recv_sso.104 ], [ %rs4gc.s15.relocated169, %pget.recv_class_ref.107 ], [ %rs4gc.s15.relocated209, %pget.recv_undef_return.134 ]
  %r791 = phi double [ %r778, %pic.merge.125 ], [ %r786204, %pget.recv_undef_return.134 ], [ %r790156, %pget.recv_sso.104 ], [ %r655164, %pget.recv_class_ref.107 ]
  %r792 = load double, ptr @test_json_tape_batch_records_ts_.str.16.handle, align 8
  %r794 = or i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.17.dispatch to i64), 9221120237041090560
  %r796 = getelementptr double, ptr %r795, i64 0
  store double %r792, ptr %r796, align 8
  %statepoint_token171 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, i64, ptr, i64)) @js_typed_feedback_native_call_method_by_id, i32 5, i32 0, i64 367713371643969541, double %r791, i64 %r794, ptr %r795, i64 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31000, ptr addrspace(1) %.31057, ptr addrspace(1) %.31007, ptr addrspace(1) %.21088, ptr addrspace(1) %.4, ptr addrspace(1) %.31032) ]
  %r138.0.relocated172 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 0, i32 0) ; (%.31000, %.31000)
  %rs4gc.s20.relocated173 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 1, i32 1) ; (%.31057, %.31057)
  %r131.0.base.relocated174 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 2, i32 2) ; (%.31007, %.31007)
  %rs4gc.s22.relocated175 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 3, i32 3) ; (%.21088, %.21088)
  %rs4gc.s15.relocated176 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 4, i32 4) ; (%.4, %.4)
  %r131.0.relocated177 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 2, i32 5) ; (%.31007, %.31032)
  %r799.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20.relocated173 to i64
  %r799.rs4o = call i64 asm "", "=r,0"(i64 %r799.rs4i) #7
  %r799 = bitcast i64 %r799.rs4o to double
  %statepoint_token178 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, i32, ptr)) @js_packed_arraylike_loop_guard_live, i32 4, i32 0, double %r799, double -1.000000e+00, i32 1, ptr %r800, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r138.0.relocated172, ptr addrspace(1) %rs4gc.s20.relocated173, ptr addrspace(1) %r131.0.base.relocated174, ptr addrspace(1) %rs4gc.s22.relocated175, ptr addrspace(1) %rs4gc.s15.relocated176, ptr addrspace(1) %r131.0.relocated177) ]
  %r801179 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token178)
  %r138.0.relocated180 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 0, i32 0) ; (%r138.0.relocated172, %r138.0.relocated172)
  %rs4gc.s20.relocated181 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 1, i32 1) ; (%rs4gc.s20.relocated173, %rs4gc.s20.relocated173)
  %r131.0.base.relocated182 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 2, i32 2) ; (%r131.0.base.relocated174, %r131.0.base.relocated174)
  %rs4gc.s22.relocated183 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 3, i32 3) ; (%rs4gc.s22.relocated175, %rs4gc.s22.relocated175)
  %rs4gc.s15.relocated184 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 4, i32 4) ; (%rs4gc.s15.relocated176, %rs4gc.s15.relocated176)
  %r131.0.relocated185 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 2, i32 5) ; (%r131.0.base.relocated174, %r131.0.relocated177)
  %r802 = icmp ne i64 %r801179, 0
  br label %stable_packed.loop.slow.preheader.136

pget.recv_other.109:                              ; preds = %put.dynic.merge.103
  %r650 = icmp eq i64 %r647, 32761
  br i1 %r650, label %pget.recv_sso.104, label %pget.check_class_ref.110

pget.check_class_ref.110:                         ; preds = %pget.recv_other.109
  %r651 = icmp eq i64 %r647, 32766
  br i1 %r651, label %pget.recv_class_ref.107, label %pget.recv_bad.106

pic.hit.111:                                      ; preds = %pic.token.127
  %r681 = getelementptr i64, ptr %r666, i64 1
  %r682 = load i64, ptr %r681, align 8
  %r683 = and i64 %r682, 1073741824
  %r684 = icmp ne i64 %r683, 0
  br i1 %r684, label %pic.hit.overflow.128, label %pic.hit.inline.129

pic.hit.live.112:                                 ; preds = %pic.hit.inline.129
  br label %pic.merge.125

pic.prefix.guard.113:                             ; preds = %pic.token.127
  %r697 = getelementptr i64, ptr %r666, i64 2
  %r698 = load i64, ptr %r697, align 8
  %r699 = icmp ne i64 %r698, 0
  br i1 %r699, label %pic.prefix.meta.114, label %pic.miss.122

pic.prefix.meta.114:                              ; preds = %pic.prefix.guard.113
  %r700 = add nuw nsw i64 %r646, 8
  %r701 = inttoptr i64 %r700 to ptr
  %r702 = load i64, ptr %r701, align 8
  %r703 = icmp ne i64 %r702, 0
  br i1 %r703, label %pic.prefix.token.115, label %pic.miss.122

pic.prefix.token.115:                             ; preds = %pic.prefix.meta.114
  %r704 = inttoptr i64 %r702 to ptr
  %r705 = getelementptr i64, ptr %r704, i64 6
  %r706 = load i64, ptr %r705, align 8
  %r707 = icmp eq i64 %r706, %r698
  br i1 %r707, label %pic.prefix.hit.116, label %pic.miss.122

pic.prefix.hit.116:                               ; preds = %pic.prefix.token.115
  %r708 = getelementptr i64, ptr %r666, i64 1
  %r709 = load i64, ptr %r708, align 8
  %r710 = shl i64 %r709, 3
  %r711 = add nuw nsw i64 %r646, 16
  %r712 = add i64 %r711, %r710
  %r713 = inttoptr i64 %r712 to ptr
  %r714 = load double, ptr %r713, align 8
  br label %pic.merge.125

pic.desc.classify.117:                            ; preds = %pic.recv_hdr.126
  %r670 = and i1 %r660, %r667
  br i1 %r670, label %pic.desc.prefix.guard.118, label %pic.miss.cold.123

pic.desc.prefix.guard.118:                        ; preds = %pic.desc.classify.117
  %r715 = getelementptr i64, ptr %r666, i64 2
  %r716 = load i64, ptr %r715, align 8
  %r717 = icmp ne i64 %r716, 0
  br i1 %r717, label %pic.desc.prefix.meta.119, label %pic.miss.cold.123

pic.desc.prefix.meta.119:                         ; preds = %pic.desc.prefix.guard.118
  %r718 = add nuw nsw i64 %r646, 8
  %r719 = inttoptr i64 %r718 to ptr
  %r720 = load i64, ptr %r719, align 8
  %r721 = icmp ne i64 %r720, 0
  br i1 %r721, label %pic.desc.prefix.token.120, label %pic.miss.cold.123

pic.desc.prefix.token.120:                        ; preds = %pic.desc.prefix.meta.119
  %r722 = inttoptr i64 %r720 to ptr
  %r723 = getelementptr i64, ptr %r722, i64 6
  %r724 = load i64, ptr %r723, align 8
  %r725 = icmp eq i64 %r724, %r716
  br i1 %r725, label %pic.desc.prefix.hit.121, label %pic.miss.cold.123

pic.desc.prefix.hit.121:                          ; preds = %pic.desc.prefix.token.120
  %r726 = getelementptr i64, ptr %r666, i64 1
  %r727 = load i64, ptr %r726, align 8
  %r728 = shl i64 %r727, 3
  %r729 = add nuw nsw i64 %r646, 16
  %r730 = add i64 %r729, %r728
  %r731 = inttoptr i64 %r730 to ptr
  %r732 = load double, ptr %r731, align 8
  br label %pic.merge.125

pic.miss.122:                                     ; preds = %pic.hit.inline.129, %pic.prefix.token.115, %pic.prefix.meta.114, %pic.prefix.guard.113
  %r733 = getelementptr i64, ptr %r666, i64 3
  %r734 = load i64, ptr %r733, align 8
  %r735 = icmp sgt i64 %r734, 0
  br i1 %r735, label %pic.ways.130, label %pic.miss.call.124

pic.miss.cold.123:                                ; preds = %pic.desc.prefix.token.120, %pic.desc.prefix.meta.119, %pic.desc.prefix.guard.118, %pic.desc.classify.117, %pget.recv_ok.105
  br label %pic.miss.call.124

pic.miss.call.124:                                ; preds = %pic.way.load.131, %pic.ways.130, %pic.miss.cold.123, %pic.miss.122
  %r774 = load double, ptr @test_json_tape_batch_records_ts_.str.15.handle, align 8
  %r775 = bitcast double %r774 to i64
  %r776 = and i64 %r775, 281474976710655
  %statepoint_token186 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r646, i64 %r776, ptr @perry_ic_test_json_tape_batch_records_ts__4, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2999, ptr addrspace(1) %.21056, ptr addrspace(1) %.21006, ptr addrspace(1) %.11087, ptr addrspace(1) %.3, ptr addrspace(1) %.21031) ]
  %r777187 = call double @llvm.experimental.gc.result.f64(token %statepoint_token186)
  %r138.0.relocated188 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token186, i32 0, i32 0) ; (%.2999, %.2999)
  %rs4gc.s20.relocated189 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token186, i32 1, i32 1) ; (%.21056, %.21056)
  %r131.0.base.relocated190 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token186, i32 2, i32 2) ; (%.21006, %.21006)
  %rs4gc.s22.relocated191 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token186, i32 3, i32 3) ; (%.11087, %.11087)
  %rs4gc.s15.relocated192 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token186, i32 4, i32 4) ; (%.3, %.3)
  %r131.0.relocated193 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token186, i32 2, i32 5) ; (%.21006, %.21031)
  br label %pic.merge.125

pic.merge.125:                                    ; preds = %pic.way.live.132, %pic.hit.overflow.128, %pic.miss.call.124, %pic.desc.prefix.hit.121, %pic.prefix.hit.116, %pic.hit.live.112
  %.31089 = phi ptr addrspace(1) [ %rs4gc.s22.relocated199, %pic.hit.overflow.128 ], [ %rs4gc.s22.relocated191, %pic.miss.call.124 ], [ %.11087, %pic.way.live.132 ], [ %.11087, %pic.hit.live.112 ], [ %.11087, %pic.prefix.hit.116 ], [ %.11087, %pic.desc.prefix.hit.121 ]
  %.41058 = phi ptr addrspace(1) [ %rs4gc.s20.relocated197, %pic.hit.overflow.128 ], [ %rs4gc.s20.relocated189, %pic.miss.call.124 ], [ %.21056, %pic.way.live.132 ], [ %.21056, %pic.hit.live.112 ], [ %.21056, %pic.prefix.hit.116 ], [ %.21056, %pic.desc.prefix.hit.121 ]
  %.41033 = phi ptr addrspace(1) [ %r131.0.relocated201, %pic.hit.overflow.128 ], [ %r131.0.relocated193, %pic.miss.call.124 ], [ %.21031, %pic.way.live.132 ], [ %.21031, %pic.hit.live.112 ], [ %.21031, %pic.prefix.hit.116 ], [ %.21031, %pic.desc.prefix.hit.121 ]
  %.41008 = phi ptr addrspace(1) [ %r131.0.base.relocated198, %pic.hit.overflow.128 ], [ %r131.0.base.relocated190, %pic.miss.call.124 ], [ %.21006, %pic.way.live.132 ], [ %.21006, %pic.hit.live.112 ], [ %.21006, %pic.prefix.hit.116 ], [ %.21006, %pic.desc.prefix.hit.121 ]
  %.41001 = phi ptr addrspace(1) [ %r138.0.relocated196, %pic.hit.overflow.128 ], [ %r138.0.relocated188, %pic.miss.call.124 ], [ %.2999, %pic.way.live.132 ], [ %.2999, %pic.hit.live.112 ], [ %.2999, %pic.prefix.hit.116 ], [ %.2999, %pic.desc.prefix.hit.121 ]
  %.5 = phi ptr addrspace(1) [ %rs4gc.s15.relocated200, %pic.hit.overflow.128 ], [ %rs4gc.s15.relocated192, %pic.miss.call.124 ], [ %.3, %pic.way.live.132 ], [ %.3, %pic.hit.live.112 ], [ %.3, %pic.prefix.hit.116 ], [ %.3, %pic.desc.prefix.hit.121 ]
  %r778 = phi double [ %r694, %pic.hit.live.112 ], [ %r689195, %pic.hit.overflow.128 ], [ %r714, %pic.prefix.hit.116 ], [ %r732, %pic.desc.prefix.hit.121 ], [ %r771, %pic.way.live.132 ], [ %r777187, %pic.miss.call.124 ]
  br label %pget.recv_merge.108

pic.recv_hdr.126:                                 ; preds = %pget.recv_ok.105
  %r657 = sub nuw nsw i64 %r646, 8
  %r658 = inttoptr i64 %r657 to ptr
  %r659 = load i8, ptr %r658, align 1
  %r660 = icmp eq i8 %r659, 2
  %r661 = sub nuw nsw i64 %r646, 6
  %r662 = inttoptr i64 %r661 to ptr
  %r663 = load i16, ptr %r662, align 2
  %r664 = and i16 %r663, 2048
  %r665 = icmp eq i16 %r664, 0
  %r666 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__4, align 8
  %r667 = icmp ne ptr %r666, null
  %r668 = and i1 %r660, %r665
  %r669 = and i1 %r668, %r667
  br i1 %r669, label %pic.token.127, label %pic.desc.classify.117

pic.token.127:                                    ; preds = %pic.recv_hdr.126
  %r671 = add nuw nsw i64 %r646, 4
  %r672 = inttoptr i64 %r671 to ptr
  %r673 = load i32, ptr %r672, align 4
  %r674 = zext i32 %r673 to i64
  %r675 = or i64 %r674, 4611686018427387904
  %r676 = icmp ne i32 %r673, 0
  %r677 = getelementptr i64, ptr %r666, i64 0
  %r678 = load i64, ptr %r677, align 8
  %r679 = icmp eq i64 %r675, %r678
  %r680 = and i1 %r679, %r676
  br i1 %r680, label %pic.hit.111, label %pic.prefix.guard.113

pic.hit.overflow.128:                             ; preds = %pic.hit.111
  %r685 = load double, ptr @test_json_tape_batch_records_ts_.str.15.handle, align 8
  %r686 = bitcast double %r685 to i64
  %r687 = and i64 %r686, 281474976710655
  %r688 = trunc i64 %r682 to i32
  %statepoint_token194 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r646, i64 %r687, i32 %r688, ptr @perry_ic_test_json_tape_batch_records_ts__4, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2999, ptr addrspace(1) %.21056, ptr addrspace(1) %.21006, ptr addrspace(1) %.11087, ptr addrspace(1) %.3, ptr addrspace(1) %.21031) ]
  %r689195 = call double @llvm.experimental.gc.result.f64(token %statepoint_token194)
  %r138.0.relocated196 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token194, i32 0, i32 0) ; (%.2999, %.2999)
  %rs4gc.s20.relocated197 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token194, i32 1, i32 1) ; (%.21056, %.21056)
  %r131.0.base.relocated198 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token194, i32 2, i32 2) ; (%.21006, %.21006)
  %rs4gc.s22.relocated199 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token194, i32 3, i32 3) ; (%.11087, %.11087)
  %rs4gc.s15.relocated200 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token194, i32 4, i32 4) ; (%.3, %.3)
  %r131.0.relocated201 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token194, i32 2, i32 5) ; (%.21006, %.21031)
  br label %pic.merge.125

pic.hit.inline.129:                               ; preds = %pic.hit.111
  %r690 = shl i64 %r682, 3
  %r691 = add nuw nsw i64 %r646, 16
  %r692 = add i64 %r691, %r690
  %r693 = inttoptr i64 %r692 to ptr
  %r694 = load double, ptr %r693, align 8
  %r695 = bitcast double %r694 to i64
  %r696 = icmp eq i64 %r695, 9222246136947933200
  br i1 %r696, label %pic.miss.122, label %pic.hit.live.112

pic.ways.130:                                     ; preds = %pic.miss.122
  %r736 = getelementptr i64, ptr %r666, i64 4
  %r737 = load i64, ptr %r736, align 8
  %r738 = icmp eq i64 %r737, %r675
  %r739 = getelementptr i64, ptr %r666, i64 5
  %r740 = load i64, ptr %r739, align 8
  %r741 = select i1 %r738, i64 %r740, i64 0
  %r742 = getelementptr i64, ptr %r666, i64 6
  %r743 = load i64, ptr %r742, align 8
  %r744 = icmp eq i64 %r743, %r675
  %r745 = getelementptr i64, ptr %r666, i64 7
  %r746 = load i64, ptr %r745, align 8
  %r747 = select i1 %r744, i64 %r746, i64 0
  %r748 = getelementptr i64, ptr %r666, i64 8
  %r749 = load i64, ptr %r748, align 8
  %r750 = icmp eq i64 %r749, %r675
  %r751 = getelementptr i64, ptr %r666, i64 9
  %r752 = load i64, ptr %r751, align 8
  %r753 = select i1 %r750, i64 %r752, i64 0
  %r754 = getelementptr i64, ptr %r666, i64 10
  %r755 = load i64, ptr %r754, align 8
  %r756 = icmp eq i64 %r755, %r675
  %r757 = getelementptr i64, ptr %r666, i64 11
  %r758 = load i64, ptr %r757, align 8
  %r759 = select i1 %r756, i64 %r758, i64 0
  %r760 = or i1 %r738, %r744
  %r761 = select i1 %r738, i64 %r741, i64 %r747
  %r762 = or i1 %r750, %r756
  %r763 = select i1 %r750, i64 %r753, i64 %r759
  %r764 = or i1 %r760, %r762
  %r765 = select i1 %r760, i64 %r761, i64 %r763
  %r766 = and i1 %r676, %r764
  br i1 %r766, label %pic.way.load.131, label %pic.miss.call.124

pic.way.load.131:                                 ; preds = %pic.ways.130
  %r767 = shl i64 %r765, 3
  %r768 = add nuw nsw i64 %r646, 16
  %r769 = add i64 %r768, %r767
  %r770 = inttoptr i64 %r769 to ptr
  %r771 = load double, ptr %r770, align 8
  %r772 = bitcast double %r771 to i64
  %r773 = icmp eq i64 %r772, 9222246136947933200
  br i1 %r773, label %pic.miss.call.124, label %pic.way.live.132

pic.way.live.132:                                 ; preds = %pic.way.load.131
  br label %pic.merge.125

pget.throw_nullish.133:                           ; preds = %pget.recv_bad.106
  %r782 = zext i1 %r780 to i32
  %statepoint_token202 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r782, ptr @test_json_tape_batch_records_ts_.str.15.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.134:                       ; preds = %pget.recv_bad.106
  %r783 = load double, ptr @test_json_tape_batch_records_ts_.str.15.handle, align 8
  %r784 = bitcast double %r783 to i64
  %r785 = and i64 %r784, 281474976710655
  %statepoint_token203 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r645, i64 %r785, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2999, ptr addrspace(1) %.21056, ptr addrspace(1) %.21006, ptr addrspace(1) %.11087, ptr addrspace(1) %.3, ptr addrspace(1) %.21031) ]
  %r786204 = call double @llvm.experimental.gc.result.f64(token %statepoint_token203)
  %r138.0.relocated205 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 0, i32 0) ; (%.2999, %.2999)
  %rs4gc.s20.relocated206 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 1, i32 1) ; (%.21056, %.21056)
  %r131.0.base.relocated207 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 2, i32 2) ; (%.21006, %.21006)
  %rs4gc.s22.relocated208 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 3, i32 3) ; (%.11087, %.11087)
  %rs4gc.s15.relocated209 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 4, i32 4) ; (%.3, %.3)
  %r131.0.relocated210 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 2, i32 5) ; (%.21006, %.21031)
  br label %pget.recv_merge.108

stable_packed.loop.slow.preheader.136:            ; preds = %pget.recv_merge.108
  %r1026.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20.relocated181 to i64
  %r1026.rs4o = call i64 asm "", "=r,0"(i64 %r1026.rs4i) #7
  %r1026 = bitcast i64 %r1026.rs4o to double
  %r1027 = bitcast double %r1026 to i64
  %r1028 = and i64 %r1027, 281474976710655
  %r1029 = lshr i64 %r1027, 48
  %r1030 = and i64 %r1029, 65533
  %r1031 = icmp eq i64 %r1030, 32765
  br i1 %r1031, label %pget.recv_ok.185, label %pget.recv_other.190

stable_packed.loop.merge.137:                     ; preds = %for.stable_packed_slow.exit.220
  %r1632.rs4i = ptrtoint ptr addrspace(1) %.71061 to i64
  %r1632.rs4o = call i64 asm "", "=r,0"(i64 %r1632.rs4i) #7
  %r1632 = bitcast i64 %r1632.rs4o to double
  %r1633 = bitcast double %r1632 to i64
  %r1634 = and i64 %r1633, 281474976710655
  %r1635 = and i64 %r1633, -281474976710656
  %r1636 = icmp eq i64 %r1635, 9222527611924643840
  %r1637 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r1638 = icmp eq i64 %r1637, 0
  %r1639 = icmp ugt i64 %r1634, 1048575
  %r1640 = icmp ult i64 %r1634, 140737488355328
  %r1641 = and i1 %r1639, %r1640
  %r1642 = and i1 %r1636, %r1638
  %r1643 = and i1 %r1642, %r1641
  br i1 %r1643, label %tav.get.brand.312, label %tav.get.slow.310

pget.recv_sso.184:                                ; preds = %pget.recv_other.190
  %r1170 = lshr i64 %r1027, 40
  %r1171 = and i64 %r1170, 255
  %r1172 = uitofp nneg i64 %r1171 to double
  br label %pget.recv_merge.188

pget.recv_ok.185:                                 ; preds = %stable_packed.loop.slow.preheader.136
  %r1038 = icmp eq i64 %r1029, 32767
  br i1 %r1038, label %pget.strlen_heap.189, label %pget.recv_obj.192

pget.recv_bad.186:                                ; preds = %pget.check_class_ref.191
  %r1162 = icmp eq i64 %r1027, 9222246136947933185
  %r1163 = icmp eq i64 %r1027, 9222246136947933186
  %r1164 = or i1 %r1162, %r1163
  br i1 %r1164, label %pget.throw_nullish.215, label %pget.recv_undef_return.216

pget.recv_class_ref.187:                          ; preds = %pget.check_class_ref.191
  %r1034 = load double, ptr @test_json_tape_batch_records_ts_.str.19.handle, align 8
  %r1035 = bitcast double %r1034 to i64
  %r1036 = and i64 %r1035, 281474976710655
  %statepoint_token211 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 367713371643969544, i64 %r1027, i64 %r1036, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r138.0.relocated180, ptr addrspace(1) %rs4gc.s20.relocated181, ptr addrspace(1) %r131.0.base.relocated182, ptr addrspace(1) %rs4gc.s22.relocated183, ptr addrspace(1) %rs4gc.s15.relocated184, ptr addrspace(1) %r131.0.relocated185) ]
  %r1037212 = call double @llvm.experimental.gc.result.f64(token %statepoint_token211)
  %r138.0.relocated213 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 0, i32 0) ; (%r138.0.relocated180, %r138.0.relocated180)
  %rs4gc.s20.relocated214 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 1, i32 1) ; (%rs4gc.s20.relocated181, %rs4gc.s20.relocated181)
  %r131.0.base.relocated215 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 2, i32 2) ; (%r131.0.base.relocated182, %r131.0.base.relocated182)
  %rs4gc.s22.relocated216 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 3, i32 3) ; (%rs4gc.s22.relocated183, %rs4gc.s22.relocated183)
  %rs4gc.s15.relocated217 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 4, i32 4) ; (%rs4gc.s15.relocated184, %rs4gc.s15.relocated184)
  %r131.0.relocated218 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 2, i32 5) ; (%r131.0.base.relocated182, %r131.0.relocated185)
  br label %pget.recv_merge.188

pget.recv_merge.188:                              ; preds = %pget.recv_undef_return.216, %pic.merge.207, %pget.strlen_heap.189, %pget.recv_class_ref.187, %pget.recv_sso.184
  %.41090 = phi ptr addrspace(1) [ %rs4gc.s22.relocated183, %pget.strlen_heap.189 ], [ %.51091, %pic.merge.207 ], [ %rs4gc.s22.relocated183, %pget.recv_sso.184 ], [ %rs4gc.s22.relocated216, %pget.recv_class_ref.187 ], [ %rs4gc.s22.relocated241, %pget.recv_undef_return.216 ]
  %.51059 = phi ptr addrspace(1) [ %rs4gc.s20.relocated181, %pget.strlen_heap.189 ], [ %.61060, %pic.merge.207 ], [ %rs4gc.s20.relocated181, %pget.recv_sso.184 ], [ %rs4gc.s20.relocated214, %pget.recv_class_ref.187 ], [ %rs4gc.s20.relocated239, %pget.recv_undef_return.216 ]
  %.51034 = phi ptr addrspace(1) [ %r131.0.relocated185, %pget.strlen_heap.189 ], [ %.61035, %pic.merge.207 ], [ %r131.0.relocated185, %pget.recv_sso.184 ], [ %r131.0.relocated218, %pget.recv_class_ref.187 ], [ %r131.0.relocated243, %pget.recv_undef_return.216 ]
  %.51009 = phi ptr addrspace(1) [ %r131.0.base.relocated182, %pget.strlen_heap.189 ], [ %.61010, %pic.merge.207 ], [ %r131.0.base.relocated182, %pget.recv_sso.184 ], [ %r131.0.base.relocated215, %pget.recv_class_ref.187 ], [ %r131.0.base.relocated240, %pget.recv_undef_return.216 ]
  %.51002 = phi ptr addrspace(1) [ %r138.0.relocated180, %pget.strlen_heap.189 ], [ %.61003, %pic.merge.207 ], [ %r138.0.relocated180, %pget.recv_sso.184 ], [ %r138.0.relocated213, %pget.recv_class_ref.187 ], [ %r138.0.relocated238, %pget.recv_undef_return.216 ]
  %.6 = phi ptr addrspace(1) [ %rs4gc.s15.relocated184, %pget.strlen_heap.189 ], [ %.7, %pic.merge.207 ], [ %rs4gc.s15.relocated184, %pget.recv_sso.184 ], [ %rs4gc.s15.relocated217, %pget.recv_class_ref.187 ], [ %rs4gc.s15.relocated242, %pget.recv_undef_return.216 ]
  %r1178 = phi double [ %r1161, %pic.merge.207 ], [ %r1169237, %pget.recv_undef_return.216 ], [ %r1172, %pget.recv_sso.184 ], [ %r1037212, %pget.recv_class_ref.187 ], [ %r1177, %pget.strlen_heap.189 ]
  %r1181 = fptosi double %r1178 to i32
  br label %for.stable_packed_slow.cond.217

pget.strlen_heap.189:                             ; preds = %pget.recv_ok.185
  %r1173 = icmp ult i64 %r1028, 4096
  %r1174 = inttoptr i64 %r1028 to ptr
  %r1175 = select i1 %r1173, ptr @perry_null_guard_zero_test_json_tape_batch_records_ts, ptr %r1174
  %r1176 = load i32, ptr %r1175, align 4
  %r1177 = uitofp i32 %r1176 to double
  br label %pget.recv_merge.188

pget.recv_other.190:                              ; preds = %stable_packed.loop.slow.preheader.136
  %r1032 = icmp eq i64 %r1029, 32761
  br i1 %r1032, label %pget.recv_sso.184, label %pget.check_class_ref.191

pget.check_class_ref.191:                         ; preds = %pget.recv_other.190
  %r1033 = icmp eq i64 %r1029, 32766
  br i1 %r1033, label %pget.recv_class_ref.187, label %pget.recv_bad.186

pget.recv_obj.192:                                ; preds = %pget.recv_ok.185
  %r1039 = icmp ugt i64 %r1028, 1048575
  br i1 %r1039, label %pic.recv_hdr.208, label %pic.miss.cold.205

pic.hit.193:                                      ; preds = %pic.token.209
  %r1064 = getelementptr i64, ptr %r1049, i64 1
  %r1065 = load i64, ptr %r1064, align 8
  %r1066 = and i64 %r1065, 1073741824
  %r1067 = icmp ne i64 %r1066, 0
  br i1 %r1067, label %pic.hit.overflow.210, label %pic.hit.inline.211

pic.hit.live.194:                                 ; preds = %pic.hit.inline.211
  br label %pic.merge.207

pic.prefix.guard.195:                             ; preds = %pic.token.209
  %r1080 = getelementptr i64, ptr %r1049, i64 2
  %r1081 = load i64, ptr %r1080, align 8
  %r1082 = icmp ne i64 %r1081, 0
  br i1 %r1082, label %pic.prefix.meta.196, label %pic.miss.204

pic.prefix.meta.196:                              ; preds = %pic.prefix.guard.195
  %r1083 = add nuw nsw i64 %r1028, 8
  %r1084 = inttoptr i64 %r1083 to ptr
  %r1085 = load i64, ptr %r1084, align 8
  %r1086 = icmp ne i64 %r1085, 0
  br i1 %r1086, label %pic.prefix.token.197, label %pic.miss.204

pic.prefix.token.197:                             ; preds = %pic.prefix.meta.196
  %r1087 = inttoptr i64 %r1085 to ptr
  %r1088 = getelementptr i64, ptr %r1087, i64 6
  %r1089 = load i64, ptr %r1088, align 8
  %r1090 = icmp eq i64 %r1089, %r1081
  br i1 %r1090, label %pic.prefix.hit.198, label %pic.miss.204

pic.prefix.hit.198:                               ; preds = %pic.prefix.token.197
  %r1091 = getelementptr i64, ptr %r1049, i64 1
  %r1092 = load i64, ptr %r1091, align 8
  %r1093 = shl i64 %r1092, 3
  %r1094 = add nuw nsw i64 %r1028, 16
  %r1095 = add i64 %r1094, %r1093
  %r1096 = inttoptr i64 %r1095 to ptr
  %r1097 = load double, ptr %r1096, align 8
  br label %pic.merge.207

pic.desc.classify.199:                            ; preds = %pic.recv_hdr.208
  %r1053 = and i1 %r1043, %r1050
  br i1 %r1053, label %pic.desc.prefix.guard.200, label %pic.miss.cold.205

pic.desc.prefix.guard.200:                        ; preds = %pic.desc.classify.199
  %r1098 = getelementptr i64, ptr %r1049, i64 2
  %r1099 = load i64, ptr %r1098, align 8
  %r1100 = icmp ne i64 %r1099, 0
  br i1 %r1100, label %pic.desc.prefix.meta.201, label %pic.miss.cold.205

pic.desc.prefix.meta.201:                         ; preds = %pic.desc.prefix.guard.200
  %r1101 = add nuw nsw i64 %r1028, 8
  %r1102 = inttoptr i64 %r1101 to ptr
  %r1103 = load i64, ptr %r1102, align 8
  %r1104 = icmp ne i64 %r1103, 0
  br i1 %r1104, label %pic.desc.prefix.token.202, label %pic.miss.cold.205

pic.desc.prefix.token.202:                        ; preds = %pic.desc.prefix.meta.201
  %r1105 = inttoptr i64 %r1103 to ptr
  %r1106 = getelementptr i64, ptr %r1105, i64 6
  %r1107 = load i64, ptr %r1106, align 8
  %r1108 = icmp eq i64 %r1107, %r1099
  br i1 %r1108, label %pic.desc.prefix.hit.203, label %pic.miss.cold.205

pic.desc.prefix.hit.203:                          ; preds = %pic.desc.prefix.token.202
  %r1109 = getelementptr i64, ptr %r1049, i64 1
  %r1110 = load i64, ptr %r1109, align 8
  %r1111 = shl i64 %r1110, 3
  %r1112 = add nuw nsw i64 %r1028, 16
  %r1113 = add i64 %r1112, %r1111
  %r1114 = inttoptr i64 %r1113 to ptr
  %r1115 = load double, ptr %r1114, align 8
  br label %pic.merge.207

pic.miss.204:                                     ; preds = %pic.hit.inline.211, %pic.prefix.token.197, %pic.prefix.meta.196, %pic.prefix.guard.195
  %r1116 = getelementptr i64, ptr %r1049, i64 3
  %r1117 = load i64, ptr %r1116, align 8
  %r1118 = icmp sgt i64 %r1117, 0
  br i1 %r1118, label %pic.ways.212, label %pic.miss.call.206

pic.miss.cold.205:                                ; preds = %pic.desc.prefix.token.202, %pic.desc.prefix.meta.201, %pic.desc.prefix.guard.200, %pic.desc.classify.199, %pget.recv_obj.192
  br label %pic.miss.call.206

pic.miss.call.206:                                ; preds = %pic.way.load.213, %pic.ways.212, %pic.miss.cold.205, %pic.miss.204
  %r1157 = load double, ptr @test_json_tape_batch_records_ts_.str.19.handle, align 8
  %r1158 = bitcast double %r1157 to i64
  %r1159 = and i64 %r1158, 281474976710655
  %statepoint_token219 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1028, i64 %r1159, ptr @perry_ic_test_json_tape_batch_records_ts__9, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r138.0.relocated180, ptr addrspace(1) %rs4gc.s20.relocated181, ptr addrspace(1) %r131.0.base.relocated182, ptr addrspace(1) %rs4gc.s22.relocated183, ptr addrspace(1) %rs4gc.s15.relocated184, ptr addrspace(1) %r131.0.relocated185) ]
  %r1160220 = call double @llvm.experimental.gc.result.f64(token %statepoint_token219)
  %r138.0.relocated221 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token219, i32 0, i32 0) ; (%r138.0.relocated180, %r138.0.relocated180)
  %rs4gc.s20.relocated222 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token219, i32 1, i32 1) ; (%rs4gc.s20.relocated181, %rs4gc.s20.relocated181)
  %r131.0.base.relocated223 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token219, i32 2, i32 2) ; (%r131.0.base.relocated182, %r131.0.base.relocated182)
  %rs4gc.s22.relocated224 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token219, i32 3, i32 3) ; (%rs4gc.s22.relocated183, %rs4gc.s22.relocated183)
  %rs4gc.s15.relocated225 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token219, i32 4, i32 4) ; (%rs4gc.s15.relocated184, %rs4gc.s15.relocated184)
  %r131.0.relocated226 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token219, i32 2, i32 5) ; (%r131.0.base.relocated182, %r131.0.relocated185)
  br label %pic.merge.207

pic.merge.207:                                    ; preds = %pic.way.live.214, %pic.hit.overflow.210, %pic.miss.call.206, %pic.desc.prefix.hit.203, %pic.prefix.hit.198, %pic.hit.live.194
  %.51091 = phi ptr addrspace(1) [ %rs4gc.s22.relocated232, %pic.hit.overflow.210 ], [ %rs4gc.s22.relocated224, %pic.miss.call.206 ], [ %rs4gc.s22.relocated183, %pic.way.live.214 ], [ %rs4gc.s22.relocated183, %pic.hit.live.194 ], [ %rs4gc.s22.relocated183, %pic.prefix.hit.198 ], [ %rs4gc.s22.relocated183, %pic.desc.prefix.hit.203 ]
  %.61060 = phi ptr addrspace(1) [ %rs4gc.s20.relocated230, %pic.hit.overflow.210 ], [ %rs4gc.s20.relocated222, %pic.miss.call.206 ], [ %rs4gc.s20.relocated181, %pic.way.live.214 ], [ %rs4gc.s20.relocated181, %pic.hit.live.194 ], [ %rs4gc.s20.relocated181, %pic.prefix.hit.198 ], [ %rs4gc.s20.relocated181, %pic.desc.prefix.hit.203 ]
  %.61035 = phi ptr addrspace(1) [ %r131.0.relocated234, %pic.hit.overflow.210 ], [ %r131.0.relocated226, %pic.miss.call.206 ], [ %r131.0.relocated185, %pic.way.live.214 ], [ %r131.0.relocated185, %pic.hit.live.194 ], [ %r131.0.relocated185, %pic.prefix.hit.198 ], [ %r131.0.relocated185, %pic.desc.prefix.hit.203 ]
  %.61010 = phi ptr addrspace(1) [ %r131.0.base.relocated231, %pic.hit.overflow.210 ], [ %r131.0.base.relocated223, %pic.miss.call.206 ], [ %r131.0.base.relocated182, %pic.way.live.214 ], [ %r131.0.base.relocated182, %pic.hit.live.194 ], [ %r131.0.base.relocated182, %pic.prefix.hit.198 ], [ %r131.0.base.relocated182, %pic.desc.prefix.hit.203 ]
  %.61003 = phi ptr addrspace(1) [ %r138.0.relocated229, %pic.hit.overflow.210 ], [ %r138.0.relocated221, %pic.miss.call.206 ], [ %r138.0.relocated180, %pic.way.live.214 ], [ %r138.0.relocated180, %pic.hit.live.194 ], [ %r138.0.relocated180, %pic.prefix.hit.198 ], [ %r138.0.relocated180, %pic.desc.prefix.hit.203 ]
  %.7 = phi ptr addrspace(1) [ %rs4gc.s15.relocated233, %pic.hit.overflow.210 ], [ %rs4gc.s15.relocated225, %pic.miss.call.206 ], [ %rs4gc.s15.relocated184, %pic.way.live.214 ], [ %rs4gc.s15.relocated184, %pic.hit.live.194 ], [ %rs4gc.s15.relocated184, %pic.prefix.hit.198 ], [ %rs4gc.s15.relocated184, %pic.desc.prefix.hit.203 ]
  %r1161 = phi double [ %r1077, %pic.hit.live.194 ], [ %r1072228, %pic.hit.overflow.210 ], [ %r1097, %pic.prefix.hit.198 ], [ %r1115, %pic.desc.prefix.hit.203 ], [ %r1154, %pic.way.live.214 ], [ %r1160220, %pic.miss.call.206 ]
  br label %pget.recv_merge.188

pic.recv_hdr.208:                                 ; preds = %pget.recv_obj.192
  %r1040 = sub nuw nsw i64 %r1028, 8
  %r1041 = inttoptr i64 %r1040 to ptr
  %r1042 = load i8, ptr %r1041, align 1
  %r1043 = icmp eq i8 %r1042, 2
  %r1044 = sub nuw nsw i64 %r1028, 6
  %r1045 = inttoptr i64 %r1044 to ptr
  %r1046 = load i16, ptr %r1045, align 2
  %r1047 = and i16 %r1046, 2048
  %r1048 = icmp eq i16 %r1047, 0
  %r1049 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__9, align 8
  %r1050 = icmp ne ptr %r1049, null
  %r1051 = and i1 %r1043, %r1048
  %r1052 = and i1 %r1051, %r1050
  br i1 %r1052, label %pic.token.209, label %pic.desc.classify.199

pic.token.209:                                    ; preds = %pic.recv_hdr.208
  %r1054 = add nuw nsw i64 %r1028, 4
  %r1055 = inttoptr i64 %r1054 to ptr
  %r1056 = load i32, ptr %r1055, align 4
  %r1057 = zext i32 %r1056 to i64
  %r1058 = or i64 %r1057, 4611686018427387904
  %r1059 = icmp ne i32 %r1056, 0
  %r1060 = getelementptr i64, ptr %r1049, i64 0
  %r1061 = load i64, ptr %r1060, align 8
  %r1062 = icmp eq i64 %r1058, %r1061
  %r1063 = and i1 %r1062, %r1059
  br i1 %r1063, label %pic.hit.193, label %pic.prefix.guard.195

pic.hit.overflow.210:                             ; preds = %pic.hit.193
  %r1068 = load double, ptr @test_json_tape_batch_records_ts_.str.19.handle, align 8
  %r1069 = bitcast double %r1068 to i64
  %r1070 = and i64 %r1069, 281474976710655
  %r1071 = trunc i64 %r1065 to i32
  %statepoint_token227 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1028, i64 %r1070, i32 %r1071, ptr @perry_ic_test_json_tape_batch_records_ts__9, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r138.0.relocated180, ptr addrspace(1) %rs4gc.s20.relocated181, ptr addrspace(1) %r131.0.base.relocated182, ptr addrspace(1) %rs4gc.s22.relocated183, ptr addrspace(1) %rs4gc.s15.relocated184, ptr addrspace(1) %r131.0.relocated185) ]
  %r1072228 = call double @llvm.experimental.gc.result.f64(token %statepoint_token227)
  %r138.0.relocated229 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token227, i32 0, i32 0) ; (%r138.0.relocated180, %r138.0.relocated180)
  %rs4gc.s20.relocated230 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token227, i32 1, i32 1) ; (%rs4gc.s20.relocated181, %rs4gc.s20.relocated181)
  %r131.0.base.relocated231 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token227, i32 2, i32 2) ; (%r131.0.base.relocated182, %r131.0.base.relocated182)
  %rs4gc.s22.relocated232 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token227, i32 3, i32 3) ; (%rs4gc.s22.relocated183, %rs4gc.s22.relocated183)
  %rs4gc.s15.relocated233 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token227, i32 4, i32 4) ; (%rs4gc.s15.relocated184, %rs4gc.s15.relocated184)
  %r131.0.relocated234 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token227, i32 2, i32 5) ; (%r131.0.base.relocated182, %r131.0.relocated185)
  br label %pic.merge.207

pic.hit.inline.211:                               ; preds = %pic.hit.193
  %r1073 = shl i64 %r1065, 3
  %r1074 = add nuw nsw i64 %r1028, 16
  %r1075 = add i64 %r1074, %r1073
  %r1076 = inttoptr i64 %r1075 to ptr
  %r1077 = load double, ptr %r1076, align 8
  %r1078 = bitcast double %r1077 to i64
  %r1079 = icmp eq i64 %r1078, 9222246136947933200
  br i1 %r1079, label %pic.miss.204, label %pic.hit.live.194

pic.ways.212:                                     ; preds = %pic.miss.204
  %r1119 = getelementptr i64, ptr %r1049, i64 4
  %r1120 = load i64, ptr %r1119, align 8
  %r1121 = icmp eq i64 %r1120, %r1058
  %r1122 = getelementptr i64, ptr %r1049, i64 5
  %r1123 = load i64, ptr %r1122, align 8
  %r1124 = select i1 %r1121, i64 %r1123, i64 0
  %r1125 = getelementptr i64, ptr %r1049, i64 6
  %r1126 = load i64, ptr %r1125, align 8
  %r1127 = icmp eq i64 %r1126, %r1058
  %r1128 = getelementptr i64, ptr %r1049, i64 7
  %r1129 = load i64, ptr %r1128, align 8
  %r1130 = select i1 %r1127, i64 %r1129, i64 0
  %r1131 = getelementptr i64, ptr %r1049, i64 8
  %r1132 = load i64, ptr %r1131, align 8
  %r1133 = icmp eq i64 %r1132, %r1058
  %r1134 = getelementptr i64, ptr %r1049, i64 9
  %r1135 = load i64, ptr %r1134, align 8
  %r1136 = select i1 %r1133, i64 %r1135, i64 0
  %r1137 = getelementptr i64, ptr %r1049, i64 10
  %r1138 = load i64, ptr %r1137, align 8
  %r1139 = icmp eq i64 %r1138, %r1058
  %r1140 = getelementptr i64, ptr %r1049, i64 11
  %r1141 = load i64, ptr %r1140, align 8
  %r1142 = select i1 %r1139, i64 %r1141, i64 0
  %r1143 = or i1 %r1121, %r1127
  %r1144 = select i1 %r1121, i64 %r1124, i64 %r1130
  %r1145 = or i1 %r1133, %r1139
  %r1146 = select i1 %r1133, i64 %r1136, i64 %r1142
  %r1147 = or i1 %r1143, %r1145
  %r1148 = select i1 %r1143, i64 %r1144, i64 %r1146
  %r1149 = and i1 %r1059, %r1147
  br i1 %r1149, label %pic.way.load.213, label %pic.miss.call.206

pic.way.load.213:                                 ; preds = %pic.ways.212
  %r1150 = shl i64 %r1148, 3
  %r1151 = add nuw nsw i64 %r1028, 16
  %r1152 = add i64 %r1151, %r1150
  %r1153 = inttoptr i64 %r1152 to ptr
  %r1154 = load double, ptr %r1153, align 8
  %r1155 = bitcast double %r1154 to i64
  %r1156 = icmp eq i64 %r1155, 9222246136947933200
  br i1 %r1156, label %pic.miss.call.206, label %pic.way.live.214

pic.way.live.214:                                 ; preds = %pic.way.load.213
  br label %pic.merge.207

pget.throw_nullish.215:                           ; preds = %pget.recv_bad.186
  %r1165 = zext i1 %r1163 to i32
  %statepoint_token235 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1165, ptr @test_json_tape_batch_records_ts_.str.19.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.216:                       ; preds = %pget.recv_bad.186
  %r1166 = load double, ptr @test_json_tape_batch_records_ts_.str.19.handle, align 8
  %r1167 = bitcast double %r1166 to i64
  %r1168 = and i64 %r1167, 281474976710655
  %statepoint_token236 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1027, i64 %r1168, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r138.0.relocated180, ptr addrspace(1) %rs4gc.s20.relocated181, ptr addrspace(1) %r131.0.base.relocated182, ptr addrspace(1) %rs4gc.s22.relocated183, ptr addrspace(1) %rs4gc.s15.relocated184, ptr addrspace(1) %r131.0.relocated185) ]
  %r1169237 = call double @llvm.experimental.gc.result.f64(token %statepoint_token236)
  %r138.0.relocated238 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token236, i32 0, i32 0) ; (%r138.0.relocated180, %r138.0.relocated180)
  %rs4gc.s20.relocated239 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token236, i32 1, i32 1) ; (%rs4gc.s20.relocated181, %rs4gc.s20.relocated181)
  %r131.0.base.relocated240 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token236, i32 2, i32 2) ; (%r131.0.base.relocated182, %r131.0.base.relocated182)
  %rs4gc.s22.relocated241 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token236, i32 3, i32 3) ; (%rs4gc.s22.relocated183, %rs4gc.s22.relocated183)
  %rs4gc.s15.relocated242 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token236, i32 4, i32 4) ; (%rs4gc.s15.relocated184, %rs4gc.s15.relocated184)
  %r131.0.relocated243 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token236, i32 2, i32 5) ; (%r131.0.base.relocated182, %r131.0.relocated185)
  br label %pget.recv_merge.188

for.stable_packed_slow.cond.217:                  ; preds = %for.stable_packed_slow.update.219, %pget.recv_merge.188
  %.61092 = phi ptr addrspace(1) [ %.41090, %pget.recv_merge.188 ], [ %.111097, %for.stable_packed_slow.update.219 ]
  %.71061 = phi ptr addrspace(1) [ %.51059, %pget.recv_merge.188 ], [ %.121066, %for.stable_packed_slow.update.219 ]
  %.71036 = phi ptr addrspace(1) [ %.51034, %pget.recv_merge.188 ], [ %.121041, %for.stable_packed_slow.update.219 ]
  %.71011 = phi ptr addrspace(1) [ %.51009, %pget.recv_merge.188 ], [ %.121016, %for.stable_packed_slow.update.219 ]
  %.8 = phi ptr addrspace(1) [ %.6, %pget.recv_merge.188 ], [ %.13, %for.stable_packed_slow.update.219 ]
  %r798.0 = phi i32 [ 0, %pget.recv_merge.188 ], [ %r1629, %for.stable_packed_slow.update.219 ]
  %r138.1 = phi ptr addrspace(1) [ %.51002, %pget.recv_merge.188 ], [ %.01102, %for.stable_packed_slow.update.219 ]
  %r1185 = icmp slt i32 %r798.0, %r1181
  br i1 %r1185, label %for.stable_packed_slow.body.218, label %for.stable_packed_slow.exit.220

for.stable_packed_slow.body.218:                  ; preds = %for.stable_packed_slow.cond.217
  %r1186.rs4i = ptrtoint ptr addrspace(1) %r138.1 to i64
  %r1186.rs4o = call i64 asm "", "=r,0"(i64 %r1186.rs4i) #7
  %r1186 = bitcast i64 %r1186.rs4o to double
  %r1187 = bitcast double %r1186 to i64
  %rs4gc.s25 = inttoptr i64 %r1187 to ptr addrspace(1)
  %r1188.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s25 to i64
  %r1188 = call i64 asm "", "=r,0"(i64 %r1188.rs4i) #7
  %r1189 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1190 = icmp ne i32 %r1189, 0
  br i1 %r1190, label %shadow.root.barrier.221, label %shadow.root.barrier.done.222

for.stable_packed_slow.update.219:                ; preds = %gcpoll.done.307
  %r1629 = add i32 %r798.0, 1
  %r1630 = sitofp i32 %r798.0 to double
  %r1631 = sitofp i32 %r1629 to double
  br label %for.stable_packed_slow.cond.217

for.stable_packed_slow.exit.220:                  ; preds = %for.stable_packed_slow.cond.217
  br label %stable_packed.loop.merge.137

shadow.root.barrier.221:                          ; preds = %for.stable_packed_slow.body.218
  call void @js_write_barrier_root_nanbox(i64 %r1188) #7
  br label %shadow.root.barrier.done.222

shadow.root.barrier.done.222:                     ; preds = %shadow.root.barrier.221, %for.stable_packed_slow.body.218
  %r1191.rs4i = ptrtoint ptr addrspace(1) %.71061 to i64
  %r1191.rs4o = call i64 asm "", "=r,0"(i64 %r1191.rs4i) #7
  %r1191 = bitcast i64 %r1191.rs4o to double
  %r1193 = sitofp i32 %r798.0 to double
  %r1194 = bitcast double %r1191 to i64
  %r1195 = and i64 %r1194, 281474976710655
  %r1196 = and i64 %r1194, -281474976710656
  %r1197 = icmp eq i64 %r1196, 9222527611924643840
  %r1198 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r1199 = icmp eq i64 %r1198, 0
  %r1200 = icmp ugt i64 %r1195, 1048575
  %r1201 = icmp ult i64 %r1195, 140737488355328
  %r1202 = and i1 %r1200, %r1201
  %r1203 = and i1 %r1197, %r1199
  %r1204 = and i1 %r1203, %r1202
  br i1 %r1204, label %tav.get.brand.227, label %tav.get.slow.225

tav.get.fast.223:                                 ; preds = %tav.get.brand.227
  %r1221 = bitcast double %r1191 to i64
  %r1222 = and i64 %r1221, 281474976710655
  %r1223 = add nuw nsw i64 %r1222, 8
  %r1224 = inttoptr i64 %r1223 to ptr
  %r1225 = load i8, ptr %r1224, align 1
  %r1226 = zext i8 %r1225 to i64
  %r1227 = fptosi double %r1193 to i64
  %r1228 = sitofp i64 %r1227 to double
  %r1229 = fcmp oeq double %r1228, %r1193
  %r1230 = inttoptr i64 %r1222 to ptr
  %r1231 = load i32, ptr %r1230, align 4
  %r1232 = zext i32 %r1231 to i64
  %r1233 = icmp ult i64 %r1227, %r1232
  %r1234 = and i1 %r1229, %r1233
  br i1 %r1234, label %tav.get.load.224, label %tav.get.slow.225

tav.get.load.224:                                 ; preds = %tav.get.fast.223
  %r1235 = add nuw nsw i64 %r1222, 16
  %r1236 = icmp eq i64 %r1226, 0
  br i1 %r1236, label %tav.k.i8.228, label %tav.kd1.236

tav.get.slow.225:                                 ; preds = %tav.get.brand.227, %tav.get.fast.223, %shadow.root.barrier.done.222
  %r1287 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__10, align 8
  %r1288 = icmp ne ptr %r1287, null
  %r1289 = select i1 %r1288, ptr %r1287, ptr @perry_ic_test_json_tape_batch_records_ts__10
  %r1290 = bitcast double %r1191 to i64
  %r1291 = and i64 %r1290, 281474976710655
  %r1292 = and i64 %r1290, -281474976710656
  %r1293 = icmp eq i64 %r1292, 9222527611924643840
  %r1294 = icmp uge i64 %r1291, 2199023255552
  %r1295 = icmp ult i64 %r1291, 140737488355328
  %r1296 = fcmp oge double %r1193, 0.000000e+00
  %r1297 = fcmp olt double %r1193, 0x41EFFFFFFFE00000
  %r1298 = and i1 %r1293, %r1294
  %r1299 = and i1 %r1298, %r1295
  %r1300 = and i1 %r1296, %r1297
  %r1301 = and i1 %r1299, %r1300
  br i1 %r1301, label %arrlike.ic.header.243, label %arrlike.ic.miss.262

tav.get.merge.226:                                ; preds = %arrlike.elem.value.268, %arrlike.ic.miss.262, %arrlike.ic.spill_load.261, %arrlike.ic.inline.258, %arrlike.ic.array_load.246, %tav.k.f64.235, %tav.k.f32.234, %tav.k.u32.233, %tav.k.i32.232, %tav.k.u16.231, %tav.k.i16.230, %tav.k.u8.229, %tav.k.i8.228
  %.01099 = phi ptr addrspace(1) [ %rs4gc.s25, %tav.k.i8.228 ], [ %rs4gc.s25, %tav.k.u8.229 ], [ %rs4gc.s25, %tav.k.i16.230 ], [ %rs4gc.s25, %tav.k.u16.231 ], [ %rs4gc.s25, %tav.k.i32.232 ], [ %rs4gc.s25, %tav.k.u32.233 ], [ %rs4gc.s25, %tav.k.f32.234 ], [ %rs4gc.s25, %tav.k.f64.235 ], [ %rs4gc.s25, %arrlike.ic.array_load.246 ], [ %rs4gc.s25.relocated, %arrlike.ic.miss.262 ], [ %rs4gc.s25, %arrlike.elem.value.268 ], [ %rs4gc.s25, %arrlike.ic.inline.258 ], [ %rs4gc.s25, %arrlike.ic.spill_load.261 ]
  %.71093 = phi ptr addrspace(1) [ %.61092, %tav.k.i8.228 ], [ %.61092, %tav.k.u8.229 ], [ %.61092, %tav.k.i16.230 ], [ %.61092, %tav.k.u16.231 ], [ %.61092, %tav.k.i32.232 ], [ %.61092, %tav.k.u32.233 ], [ %.61092, %tav.k.f32.234 ], [ %.61092, %tav.k.f64.235 ], [ %.61092, %arrlike.ic.array_load.246 ], [ %rs4gc.s22.relocated248, %arrlike.ic.miss.262 ], [ %.61092, %arrlike.elem.value.268 ], [ %.61092, %arrlike.ic.inline.258 ], [ %.61092, %arrlike.ic.spill_load.261 ]
  %.81062 = phi ptr addrspace(1) [ %.71061, %tav.k.i8.228 ], [ %.71061, %tav.k.u8.229 ], [ %.71061, %tav.k.i16.230 ], [ %.71061, %tav.k.u16.231 ], [ %.71061, %tav.k.i32.232 ], [ %.71061, %tav.k.u32.233 ], [ %.71061, %tav.k.f32.234 ], [ %.71061, %tav.k.f64.235 ], [ %.71061, %arrlike.ic.array_load.246 ], [ %rs4gc.s20.relocated246, %arrlike.ic.miss.262 ], [ %.71061, %arrlike.elem.value.268 ], [ %.71061, %arrlike.ic.inline.258 ], [ %.71061, %arrlike.ic.spill_load.261 ]
  %.81037 = phi ptr addrspace(1) [ %.71036, %tav.k.i8.228 ], [ %.71036, %tav.k.u8.229 ], [ %.71036, %tav.k.i16.230 ], [ %.71036, %tav.k.u16.231 ], [ %.71036, %tav.k.i32.232 ], [ %.71036, %tav.k.u32.233 ], [ %.71036, %tav.k.f32.234 ], [ %.71036, %tav.k.f64.235 ], [ %.71036, %arrlike.ic.array_load.246 ], [ %r131.0.relocated250, %arrlike.ic.miss.262 ], [ %.71036, %arrlike.elem.value.268 ], [ %.71036, %arrlike.ic.inline.258 ], [ %.71036, %arrlike.ic.spill_load.261 ]
  %.81012 = phi ptr addrspace(1) [ %.71011, %tav.k.i8.228 ], [ %.71011, %tav.k.u8.229 ], [ %.71011, %tav.k.i16.230 ], [ %.71011, %tav.k.u16.231 ], [ %.71011, %tav.k.i32.232 ], [ %.71011, %tav.k.u32.233 ], [ %.71011, %tav.k.f32.234 ], [ %.71011, %tav.k.f64.235 ], [ %.71011, %arrlike.ic.array_load.246 ], [ %r131.0.base.relocated247, %arrlike.ic.miss.262 ], [ %.71011, %arrlike.elem.value.268 ], [ %.71011, %arrlike.ic.inline.258 ], [ %.71011, %arrlike.ic.spill_load.261 ]
  %.9 = phi ptr addrspace(1) [ %.8, %tav.k.i8.228 ], [ %.8, %tav.k.u8.229 ], [ %.8, %tav.k.i16.230 ], [ %.8, %tav.k.u16.231 ], [ %.8, %tav.k.i32.232 ], [ %.8, %tav.k.u32.233 ], [ %.8, %tav.k.f32.234 ], [ %.8, %tav.k.f64.235 ], [ %.8, %arrlike.ic.array_load.246 ], [ %rs4gc.s15.relocated249, %arrlike.ic.miss.262 ], [ %.8, %arrlike.elem.value.268 ], [ %.8, %arrlike.ic.inline.258 ], [ %.8, %arrlike.ic.spill_load.261 ]
  %r1460 = phi double [ %r1249, %tav.k.i8.228 ], [ %r1255, %tav.k.u8.229 ], [ %r1261, %tav.k.i16.230 ], [ %r1267, %tav.k.u16.231 ], [ %r1272, %tav.k.i32.232 ], [ %r1277, %tav.k.u32.233 ], [ %r1282, %tav.k.f32.234 ], [ %r1286, %tav.k.f64.235 ], [ %r1343, %arrlike.elem.value.268 ], [ %r1371, %arrlike.ic.array_load.246 ], [ %r1441, %arrlike.ic.inline.258 ], [ %r1458, %arrlike.ic.spill_load.261 ], [ %r1459245, %arrlike.ic.miss.262 ]
  %r1461 = bitcast double %r1460 to i64
  %r1462 = and i64 %r1461, 281474976710655
  %r1463 = lshr i64 %r1461, 48
  %r1464 = and i64 %r1463, 65533
  %r1465 = icmp eq i64 %r1464, 32765
  br i1 %r1465, label %pget.recv_ok.271, label %pget.recv_other.275

tav.get.brand.227:                                ; preds = %shadow.root.barrier.done.222
  %r1205 = bitcast double %r1191 to i64
  %r1206 = and i64 %r1205, 281474976710655
  %r1207 = sub nsw i64 %r1206, 8
  %r1208 = inttoptr i64 %r1207 to ptr
  %r1209 = load i8, ptr %r1208, align 1
  %r1210 = icmp eq i8 %r1209, 11
  %r1211 = add nuw nsw i64 %r1206, 8
  %r1212 = inttoptr i64 %r1211 to ptr
  %r1213 = load i8, ptr %r1212, align 1
  %r1214 = zext i8 %r1213 to i64
  %r1215 = icmp ule i64 %r1214, 8
  %r1216 = fcmp oge double %r1193, 0.000000e+00
  %r1217 = fcmp olt double %r1193, 0x41F0000000000000
  %r1218 = and i1 %r1210, %r1215
  %r1219 = and i1 %r1218, %r1216
  %r1220 = and i1 %r1219, %r1217
  br i1 %r1220, label %tav.get.fast.223, label %tav.get.slow.225

tav.k.i8.228:                                     ; preds = %tav.get.load.224
  %r1244 = shl nuw nsw i64 %r1227, 0
  %r1245 = add nuw nsw i64 %r1235, %r1244
  %r1246 = inttoptr i64 %r1245 to ptr
  %r1247 = load i8, ptr %r1246, align 1
  %r1248 = sext i8 %r1247 to i32
  %r1249 = sitofp i32 %r1248 to double
  br label %tav.get.merge.226

tav.k.u8.229:                                     ; preds = %tav.kd7.242, %tav.kd1.236
  %r1250 = shl nuw nsw i64 %r1227, 0
  %r1251 = add nuw nsw i64 %r1235, %r1250
  %r1252 = inttoptr i64 %r1251 to ptr
  %r1253 = load i8, ptr %r1252, align 1
  %r1254 = zext i8 %r1253 to i32
  %r1255 = uitofp nneg i32 %r1254 to double
  br label %tav.get.merge.226

tav.k.i16.230:                                    ; preds = %tav.kd2.237
  %r1256 = shl nuw nsw i64 %r1227, 1
  %r1257 = add nuw nsw i64 %r1235, %r1256
  %r1258 = inttoptr i64 %r1257 to ptr
  %r1259 = load i16, ptr %r1258, align 2
  %r1260 = sext i16 %r1259 to i32
  %r1261 = sitofp i32 %r1260 to double
  br label %tav.get.merge.226

tav.k.u16.231:                                    ; preds = %tav.kd3.238
  %r1262 = shl nuw nsw i64 %r1227, 1
  %r1263 = add nuw nsw i64 %r1235, %r1262
  %r1264 = inttoptr i64 %r1263 to ptr
  %r1265 = load i16, ptr %r1264, align 2
  %r1266 = zext i16 %r1265 to i32
  %r1267 = uitofp nneg i32 %r1266 to double
  br label %tav.get.merge.226

tav.k.i32.232:                                    ; preds = %tav.kd4.239
  %r1268 = shl nuw nsw i64 %r1227, 2
  %r1269 = add nuw nsw i64 %r1235, %r1268
  %r1270 = inttoptr i64 %r1269 to ptr
  %r1271 = load i32, ptr %r1270, align 4
  %r1272 = sitofp i32 %r1271 to double
  br label %tav.get.merge.226

tav.k.u32.233:                                    ; preds = %tav.kd5.240
  %r1273 = shl nuw nsw i64 %r1227, 2
  %r1274 = add nuw nsw i64 %r1235, %r1273
  %r1275 = inttoptr i64 %r1274 to ptr
  %r1276 = load i32, ptr %r1275, align 4
  %r1277 = uitofp i32 %r1276 to double
  br label %tav.get.merge.226

tav.k.f32.234:                                    ; preds = %tav.kd6.241
  %r1278 = shl nuw nsw i64 %r1227, 2
  %r1279 = add nuw nsw i64 %r1235, %r1278
  %r1280 = inttoptr i64 %r1279 to ptr
  %r1281 = load float, ptr %r1280, align 4
  %r1282 = fpext float %r1281 to double
  br label %tav.get.merge.226

tav.k.f64.235:                                    ; preds = %tav.kd7.242
  %r1283 = shl nuw nsw i64 %r1227, 3
  %r1284 = add nuw nsw i64 %r1235, %r1283
  %r1285 = inttoptr i64 %r1284 to ptr
  %r1286 = load double, ptr %r1285, align 8
  br label %tav.get.merge.226

tav.kd1.236:                                      ; preds = %tav.get.load.224
  %r1237 = icmp eq i64 %r1226, 1
  br i1 %r1237, label %tav.k.u8.229, label %tav.kd2.237

tav.kd2.237:                                      ; preds = %tav.kd1.236
  %r1238 = icmp eq i64 %r1226, 2
  br i1 %r1238, label %tav.k.i16.230, label %tav.kd3.238

tav.kd3.238:                                      ; preds = %tav.kd2.237
  %r1239 = icmp eq i64 %r1226, 3
  br i1 %r1239, label %tav.k.u16.231, label %tav.kd4.239

tav.kd4.239:                                      ; preds = %tav.kd3.238
  %r1240 = icmp eq i64 %r1226, 4
  br i1 %r1240, label %tav.k.i32.232, label %tav.kd5.240

tav.kd5.240:                                      ; preds = %tav.kd4.239
  %r1241 = icmp eq i64 %r1226, 5
  br i1 %r1241, label %tav.k.u32.233, label %tav.kd6.241

tav.kd6.241:                                      ; preds = %tav.kd5.240
  %r1242 = icmp eq i64 %r1226, 6
  br i1 %r1242, label %tav.k.f32.234, label %tav.kd7.242

tav.kd7.242:                                      ; preds = %tav.kd6.241
  %r1243 = icmp eq i64 %r1226, 7
  br i1 %r1243, label %tav.k.f64.235, label %tav.k.u8.229

arrlike.ic.header.243:                            ; preds = %tav.get.slow.225
  %r1302 = fptosi double %r1193 to i64
  %r1303 = sitofp i64 %r1302 to double
  %r1304 = fcmp oeq double %r1303, %r1193
  %r1305 = sub nuw nsw i64 %r1291, 8
  %r1306 = inttoptr i64 %r1305 to ptr
  %r1307 = load i8, ptr %r1306, align 1
  %r1309 = sub nuw nsw i64 %r1291, 7
  %r1310 = inttoptr i64 %r1309 to ptr
  %r1311 = load i8, ptr %r1310, align 1
  %r1312 = and i8 %r1311, -128
  %r1313 = icmp eq i8 %r1312, 0
  %r1314 = and i1 %r1304, %r1313
  br i1 %r1314, label %arrlike.ic.brand.244, label %arrlike.ic.miss.262

arrlike.ic.brand.244:                             ; preds = %arrlike.ic.header.243
  %r1308 = icmp eq i8 %r1307, 1
  br i1 %r1308, label %arrlike.ic.array_guard.245, label %arrlike.elem.kind.263

arrlike.ic.array_guard.245:                       ; preds = %arrlike.ic.brand.244
  %r1346 = sub nuw nsw i64 %r1291, 6
  %r1347 = inttoptr i64 %r1346 to ptr
  %r1348 = load i16, ptr %r1347, align 2
  %r1349 = and i16 %r1348, 1024
  %r1350 = icmp eq i16 %r1349, 0
  %r1351 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1352 = icmp eq i8 %r1351, 0
  %r1353 = inttoptr i64 %r1291 to ptr
  %r1354 = load i32, ptr %r1353, align 4
  %r1355 = add nuw nsw i64 %r1291, 4
  %r1356 = inttoptr i64 %r1355 to ptr
  %r1357 = load i32, ptr %r1356, align 4
  %r1358 = zext i32 %r1354 to i64
  %r1359 = zext i32 %r1357 to i64
  %r1360 = icmp ult i64 %r1302, %r1358
  %r1361 = icmp ule i64 %r1358, %r1359
  %r1362 = and i1 %r1350, %r1352
  %r1363 = and i1 %r1362, %r1360
  %r1364 = and i1 %r1363, %r1361
  br i1 %r1364, label %arrlike.ic.array_load.246, label %arrlike.ic.miss.262

arrlike.ic.array_load.246:                        ; preds = %arrlike.ic.array_guard.245
  %r1365 = add nuw nsw i64 %r1302, 1
  %r1366 = getelementptr inbounds nuw i64, ptr %r1353, i64 %r1365
  %r1367 = load double, ptr %r1366, align 8
  %r1368 = bitcast double %r1367 to i64
  %r1369 = icmp eq i64 %r1368, 9222246136947933200
  %r1371 = select i1 %r1369, double 0x7FFC000000000001, double %r1367
  br label %tav.get.merge.226

arrlike.ic.shape.247:                             ; preds = %arrlike.elem.store.265, %arrlike.elem.meta.264
  %r1373 = inttoptr i64 %r1291 to ptr
  %r1374 = load i32, ptr %r1373, align 4
  %r1375 = add nuw nsw i64 %r1291, 4
  %r1376 = inttoptr i64 %r1375 to ptr
  %r1377 = load i32, ptr %r1376, align 4
  %r1378 = zext i32 %r1374 to i64
  %r1379 = zext i32 %r1377 to i64
  %r1380 = shl nuw i64 %r1378, 32
  %r1381 = or i64 %r1380, %r1379
  %r1382 = getelementptr i64, ptr %r1289, i64 0
  %r1383 = load i64, ptr %r1382, align 8
  %r1384 = icmp ne i64 %r1383, 0
  %r1385 = and i1 true, %r1384
  br i1 %r1385, label %arrlike.ic.identity.248, label %arrlike.ic.miss.262

arrlike.ic.identity.248:                          ; preds = %arrlike.ic.shape.247
  %r1386 = and i64 %r1383, -9223372036854775808
  %1 = icmp slt i64 %r1383, 0
  br i1 %1, label %arrlike.ic.family_meta.250, label %arrlike.ic.exact.249

arrlike.ic.exact.249:                             ; preds = %arrlike.ic.identity.248
  %r1388 = icmp eq i64 %r1381, %r1383
  br i1 %r1388, label %arrlike.ic.bounds.252, label %arrlike.ic.miss.262

arrlike.ic.family_meta.250:                       ; preds = %arrlike.ic.identity.248
  %r1389 = add nuw nsw i64 %r1291, 8
  %r1390 = inttoptr i64 %r1389 to ptr
  %r1391 = load i64, ptr %r1390, align 8
  %r1392 = icmp ne i64 %r1391, 0
  br i1 %r1392, label %arrlike.ic.family_token.251, label %arrlike.ic.miss.262

arrlike.ic.family_token.251:                      ; preds = %arrlike.ic.family_meta.250
  %r1393 = inttoptr i64 %r1391 to ptr
  %r1394 = getelementptr i64, ptr %r1393, i64 6
  %r1395 = load i64, ptr %r1394, align 8
  %r1396 = icmp eq i64 %r1395, %r1383
  br i1 %r1396, label %arrlike.ic.bounds.252, label %arrlike.ic.miss.262

arrlike.ic.bounds.252:                            ; preds = %arrlike.ic.family_token.251, %arrlike.ic.exact.249
  %r1397 = getelementptr i64, ptr %r1287, i64 1
  %r1398 = load i64, ptr %r1397, align 8
  %r1399 = getelementptr i64, ptr %r1287, i64 2
  %r1400 = load i64, ptr %r1399, align 8
  %r1401 = getelementptr i64, ptr %r1287, i64 3
  %r1402 = load i64, ptr %r1401, align 8
  %r1403 = getelementptr i64, ptr %r1287, i64 4
  %r1404 = load i64, ptr %r1403, align 8
  %r1405 = icmp ult i64 %r1398, %r1404
  br i1 %r1405, label %arrlike.ic.length_inline.253, label %arrlike.ic.length_spill_meta.254

arrlike.ic.length_inline.253:                     ; preds = %arrlike.ic.bounds.252
  %r1406 = shl i64 %r1398, 3
  %r1407 = add i64 %r1406, 16
  %r1408 = add i64 %r1291, %r1407
  %r1409 = inttoptr i64 %r1408 to ptr
  %r1410 = load double, ptr %r1409, align 8
  br label %arrlike.ic.range.257

arrlike.ic.length_spill_meta.254:                 ; preds = %arrlike.ic.bounds.252
  %r1411 = add nuw nsw i64 %r1291, 8
  %r1412 = inttoptr i64 %r1411 to ptr
  %r1413 = load i64, ptr %r1412, align 8
  %r1414 = icmp ne i64 %r1413, 0
  br i1 %r1414, label %arrlike.ic.length_spill_ptr.255, label %arrlike.ic.miss.262

arrlike.ic.length_spill_ptr.255:                  ; preds = %arrlike.ic.length_spill_meta.254
  %r1415 = inttoptr i64 %r1413 to ptr
  %r1416 = getelementptr i64, ptr %r1415, i64 4
  %r1417 = load i64, ptr %r1416, align 8
  %r1418 = icmp ne i64 %r1417, 0
  %r1419 = select i1 %r1418, i64 %r1417, i64 %r1413
  %r1420 = inttoptr i64 %r1419 to ptr
  %r1421 = load i32, ptr %r1420, align 4
  %r1422 = zext i32 %r1421 to i64
  %r1423 = icmp ult i64 %r1398, %r1422
  %r1424 = and i1 %r1418, %r1423
  br i1 %r1424, label %arrlike.ic.length_spill_load.256, label %arrlike.ic.miss.262

arrlike.ic.length_spill_load.256:                 ; preds = %arrlike.ic.length_spill_ptr.255
  %r1425 = add nuw nsw i64 %r1398, 1
  %r1426 = getelementptr inbounds nuw i64, ptr %r1420, i64 %r1425
  %r1427 = load double, ptr %r1426, align 8
  br label %arrlike.ic.range.257

arrlike.ic.range.257:                             ; preds = %arrlike.ic.length_spill_load.256, %arrlike.ic.length_inline.253
  %r1428 = phi double [ %r1410, %arrlike.ic.length_inline.253 ], [ %r1427, %arrlike.ic.length_spill_load.256 ]
  %r1429 = fcmp olt double %r1193, %r1428
  %r1430 = icmp ult i64 %r1302, %r1402
  %r1431 = and i1 %r1429, %r1430
  %r1432 = add i64 %r1400, %r1302
  %r1433 = icmp ult i64 %r1432, %r1404
  %r1434 = and i1 %r1431, %r1433
  %r1435 = xor i1 %r1433, true
  %r1436 = and i1 %r1431, %r1435
  br i1 %r1434, label %arrlike.ic.inline.258, label %arrlike.ic.spill_or_miss.269

arrlike.ic.inline.258:                            ; preds = %arrlike.ic.range.257
  %r1437 = shl i64 %r1432, 3
  %r1438 = add i64 %r1437, 16
  %r1439 = add i64 %r1291, %r1438
  %r1440 = inttoptr i64 %r1439 to ptr
  %r1441 = load double, ptr %r1440, align 8
  br label %tav.get.merge.226

arrlike.ic.spill.259:                             ; preds = %arrlike.ic.spill_or_miss.269
  %r1442 = add nuw nsw i64 %r1291, 8
  %r1443 = inttoptr i64 %r1442 to ptr
  %r1444 = load i64, ptr %r1443, align 8
  %r1445 = icmp ne i64 %r1444, 0
  br i1 %r1445, label %arrlike.ic.spill_ptr.260, label %arrlike.ic.miss.262

arrlike.ic.spill_ptr.260:                         ; preds = %arrlike.ic.spill.259
  %r1446 = inttoptr i64 %r1444 to ptr
  %r1447 = getelementptr i64, ptr %r1446, i64 4
  %r1448 = load i64, ptr %r1447, align 8
  %r1449 = icmp ne i64 %r1448, 0
  %r1450 = select i1 %r1449, i64 %r1448, i64 %r1444
  %r1451 = inttoptr i64 %r1450 to ptr
  %r1452 = load i32, ptr %r1451, align 4
  %r1453 = zext i32 %r1452 to i64
  %r1454 = icmp ult i64 %r1432, %r1453
  %r1455 = and i1 %r1449, %r1454
  br i1 %r1455, label %arrlike.ic.spill_load.261, label %arrlike.ic.miss.262

arrlike.ic.spill_load.261:                        ; preds = %arrlike.ic.spill_ptr.260
  %r1456 = add nuw nsw i64 %r1432, 1
  %r1457 = getelementptr inbounds nuw i64, ptr %r1451, i64 %r1456
  %r1458 = load double, ptr %r1457, align 8
  br label %tav.get.merge.226

arrlike.ic.miss.262:                              ; preds = %arrlike.ic.spill_or_miss.269, %arrlike.elem.load.267, %arrlike.elem.bounds.266, %arrlike.elem.kind.263, %arrlike.ic.spill_ptr.260, %arrlike.ic.spill.259, %arrlike.ic.length_spill_ptr.255, %arrlike.ic.length_spill_meta.254, %arrlike.ic.family_token.251, %arrlike.ic.family_meta.250, %arrlike.ic.exact.249, %arrlike.ic.shape.247, %arrlike.ic.array_guard.245, %arrlike.ic.header.243, %tav.get.slow.225
  %statepoint_token244 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, ptr)) @js_packed_arraylike_index_get, i32 3, i32 0, double %r1191, double %r1193, ptr @perry_ic_test_json_tape_batch_records_ts__10, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s25, ptr addrspace(1) %.71061, ptr addrspace(1) %.71011, ptr addrspace(1) %.61092, ptr addrspace(1) %.8, ptr addrspace(1) %.71036) ]
  %r1459245 = call double @llvm.experimental.gc.result.f64(token %statepoint_token244)
  %rs4gc.s25.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 0, i32 0) ; (%rs4gc.s25, %rs4gc.s25)
  %rs4gc.s20.relocated246 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 1, i32 1) ; (%.71061, %.71061)
  %r131.0.base.relocated247 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 2, i32 2) ; (%.71011, %.71011)
  %rs4gc.s22.relocated248 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 3, i32 3) ; (%.61092, %.61092)
  %rs4gc.s15.relocated249 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 4, i32 4) ; (%.8, %.8)
  %r131.0.relocated250 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 2, i32 5) ; (%.71011, %.71036)
  br label %tav.get.merge.226

arrlike.elem.kind.263:                            ; preds = %arrlike.ic.brand.244
  %r1315 = icmp eq i8 %r1307, 2
  br i1 %r1315, label %arrlike.elem.meta.264, label %arrlike.ic.miss.262

arrlike.elem.meta.264:                            ; preds = %arrlike.elem.kind.263
  %r1316 = add nuw nsw i64 %r1291, 8
  %r1317 = inttoptr i64 %r1316 to ptr
  %r1318 = load i64, ptr %r1317, align 8
  %r1319 = icmp ne i64 %r1318, 0
  br i1 %r1319, label %arrlike.elem.store.265, label %arrlike.ic.shape.247

arrlike.elem.store.265:                           ; preds = %arrlike.elem.meta.264
  %r1320 = inttoptr i64 %r1318 to ptr
  %r1321 = getelementptr i64, ptr %r1320, i64 12
  %r1322 = load i64, ptr %r1321, align 8
  %r1323 = icmp ne i64 %r1322, 0
  br i1 %r1323, label %arrlike.elem.bounds.266, label %arrlike.ic.shape.247

arrlike.elem.bounds.266:                          ; preds = %arrlike.elem.store.265
  %r1324 = sub i64 %r1322, 8
  %r1325 = inttoptr i64 %r1324 to ptr
  %r1326 = load i8, ptr %r1325, align 1
  %r1327 = icmp eq i8 %r1326, 1
  %r1328 = sub i64 %r1322, 7
  %r1329 = inttoptr i64 %r1328 to ptr
  %r1330 = load i8, ptr %r1329, align 1
  %r1331 = and i8 %r1330, -128
  %r1332 = icmp eq i8 %r1331, 0
  %r1333 = inttoptr i64 %r1322 to ptr
  %r1334 = load i32, ptr %r1333, align 4
  %r1335 = zext i32 %r1334 to i64
  %r1336 = icmp ult i64 %r1302, %r1335
  %r1337 = and i1 %r1327, %r1332
  %r1338 = and i1 %r1337, %r1336
  br i1 %r1338, label %arrlike.elem.load.267, label %arrlike.ic.miss.262

arrlike.elem.load.267:                            ; preds = %arrlike.elem.bounds.266
  %r1339 = shl nuw nsw i64 %r1302, 3
  %r1340 = add i64 %r1322, 8
  %r1341 = add i64 %r1340, %r1339
  %r1342 = inttoptr i64 %r1341 to ptr
  %r1343 = load double, ptr %r1342, align 8
  %r1344 = bitcast double %r1343 to i64
  %r1345 = icmp eq i64 %r1344, 9222246136947933200
  br i1 %r1345, label %arrlike.ic.miss.262, label %arrlike.elem.value.268

arrlike.elem.value.268:                           ; preds = %arrlike.elem.load.267
  br label %tav.get.merge.226

arrlike.ic.spill_or_miss.269:                     ; preds = %arrlike.ic.range.257
  br i1 %r1436, label %arrlike.ic.spill.259, label %arrlike.ic.miss.262

pget.recv_sso.270:                                ; preds = %pget.recv_other.275
  %r1603 = load double, ptr @test_json_tape_batch_records_ts_.str.18.handle, align 8
  %r1604 = bitcast double %r1603 to i64
  %r1605 = and i64 %r1604, 281474976710655
  %statepoint_token251 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1461, i64 %r1605, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.81062, ptr addrspace(1) %.81012, ptr addrspace(1) %.71093, ptr addrspace(1) %.9, ptr addrspace(1) %.01099, ptr addrspace(1) %.81037) ]
  %r1606252 = call double @llvm.experimental.gc.result.f64(token %statepoint_token251)
  %rs4gc.s20.relocated253 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token251, i32 0, i32 0) ; (%.81062, %.81062)
  %r131.0.base.relocated254 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token251, i32 1, i32 1) ; (%.81012, %.81012)
  %rs4gc.s22.relocated255 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token251, i32 2, i32 2) ; (%.71093, %.71093)
  %rs4gc.s15.relocated256 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token251, i32 3, i32 3) ; (%.9, %.9)
  %rs4gc.s25.relocated257 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token251, i32 4, i32 4) ; (%.01099, %.01099)
  %r131.0.relocated258 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token251, i32 1, i32 5) ; (%.81012, %.81037)
  br label %pget.recv_merge.274

pget.recv_ok.271:                                 ; preds = %tav.get.merge.226
  %r1472 = icmp ugt i64 %r1462, 1048575
  br i1 %r1472, label %pic.recv_hdr.292, label %pic.miss.cold.289

pget.recv_bad.272:                                ; preds = %pget.check_class_ref.276
  %r1595 = icmp eq i64 %r1461, 9222246136947933185
  %r1596 = icmp eq i64 %r1461, 9222246136947933186
  %r1597 = or i1 %r1595, %r1596
  br i1 %r1597, label %pget.throw_nullish.299, label %pget.recv_undef_return.300

pget.recv_class_ref.273:                          ; preds = %pget.check_class_ref.276
  %r1468 = load double, ptr @test_json_tape_batch_records_ts_.str.18.handle, align 8
  %r1469 = bitcast double %r1468 to i64
  %r1470 = and i64 %r1469, 281474976710655
  %statepoint_token259 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 367713371643969547, i64 %r1461, i64 %r1470, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.81062, ptr addrspace(1) %.81012, ptr addrspace(1) %.71093, ptr addrspace(1) %.9, ptr addrspace(1) %.01099, ptr addrspace(1) %.81037) ]
  %r1471260 = call double @llvm.experimental.gc.result.f64(token %statepoint_token259)
  %rs4gc.s20.relocated261 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 0, i32 0) ; (%.81062, %.81062)
  %r131.0.base.relocated262 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 1, i32 1) ; (%.81012, %.81012)
  %rs4gc.s22.relocated263 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 2, i32 2) ; (%.71093, %.71093)
  %rs4gc.s15.relocated264 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 3, i32 3) ; (%.9, %.9)
  %rs4gc.s25.relocated265 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 4, i32 4) ; (%.01099, %.01099)
  %r131.0.relocated266 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 1, i32 5) ; (%.81012, %.81037)
  br label %pget.recv_merge.274

pget.recv_merge.274:                              ; preds = %pget.recv_undef_return.300, %pic.merge.291, %pget.recv_class_ref.273, %pget.recv_sso.270
  %.11100 = phi ptr addrspace(1) [ %.21101, %pic.merge.291 ], [ %rs4gc.s25.relocated257, %pget.recv_sso.270 ], [ %rs4gc.s25.relocated265, %pget.recv_class_ref.273 ], [ %rs4gc.s25.relocated290, %pget.recv_undef_return.300 ]
  %.81094 = phi ptr addrspace(1) [ %.91095, %pic.merge.291 ], [ %rs4gc.s22.relocated255, %pget.recv_sso.270 ], [ %rs4gc.s22.relocated263, %pget.recv_class_ref.273 ], [ %rs4gc.s22.relocated288, %pget.recv_undef_return.300 ]
  %.91063 = phi ptr addrspace(1) [ %.101064, %pic.merge.291 ], [ %rs4gc.s20.relocated253, %pget.recv_sso.270 ], [ %rs4gc.s20.relocated261, %pget.recv_class_ref.273 ], [ %rs4gc.s20.relocated286, %pget.recv_undef_return.300 ]
  %.91038 = phi ptr addrspace(1) [ %.101039, %pic.merge.291 ], [ %r131.0.relocated258, %pget.recv_sso.270 ], [ %r131.0.relocated266, %pget.recv_class_ref.273 ], [ %r131.0.relocated291, %pget.recv_undef_return.300 ]
  %.91013 = phi ptr addrspace(1) [ %.101014, %pic.merge.291 ], [ %r131.0.base.relocated254, %pget.recv_sso.270 ], [ %r131.0.base.relocated262, %pget.recv_class_ref.273 ], [ %r131.0.base.relocated287, %pget.recv_undef_return.300 ]
  %.10 = phi ptr addrspace(1) [ %.11, %pic.merge.291 ], [ %rs4gc.s15.relocated256, %pget.recv_sso.270 ], [ %rs4gc.s15.relocated264, %pget.recv_class_ref.273 ], [ %rs4gc.s15.relocated289, %pget.recv_undef_return.300 ]
  %r1607 = phi double [ %r1594, %pic.merge.291 ], [ %r1602285, %pget.recv_undef_return.300 ], [ %r1606252, %pget.recv_sso.270 ], [ %r1471260, %pget.recv_class_ref.273 ]
  %r1608.rs4i = ptrtoint ptr addrspace(1) %.11100 to i64
  %r1608 = call i64 asm "", "=r,0"(i64 %r1608.rs4i) #7
  %r1609 = bitcast i64 %r1608 to double
  %r1610 = and i64 %r1608, -281474976710656
  %r1611 = icmp ult i64 %r1610, 9221401712017801216
  %r1612 = icmp ugt i64 %r1610, 9223090561878065152
  %r1613 = or i1 %r1611, %r1612
  %r1614 = bitcast double %r1607 to i64
  %r1615 = and i64 %r1614, -281474976710656
  %r1616 = icmp ult i64 %r1615, 9221401712017801216
  %r1617 = icmp ugt i64 %r1615, 9223090561878065152
  %r1618 = or i1 %r1616, %r1617
  %r1619 = and i1 %r1613, %r1618
  br i1 %r1619, label %guarded_add.numeric.301, label %guarded_add.dynamic.302

pget.recv_other.275:                              ; preds = %tav.get.merge.226
  %r1466 = icmp eq i64 %r1463, 32761
  br i1 %r1466, label %pget.recv_sso.270, label %pget.check_class_ref.276

pget.check_class_ref.276:                         ; preds = %pget.recv_other.275
  %r1467 = icmp eq i64 %r1463, 32766
  br i1 %r1467, label %pget.recv_class_ref.273, label %pget.recv_bad.272

pic.hit.277:                                      ; preds = %pic.token.293
  %r1497 = getelementptr i64, ptr %r1482, i64 1
  %r1498 = load i64, ptr %r1497, align 8
  %r1499 = and i64 %r1498, 1073741824
  %r1500 = icmp ne i64 %r1499, 0
  br i1 %r1500, label %pic.hit.overflow.294, label %pic.hit.inline.295

pic.hit.live.278:                                 ; preds = %pic.hit.inline.295
  br label %pic.merge.291

pic.prefix.guard.279:                             ; preds = %pic.token.293
  %r1513 = getelementptr i64, ptr %r1482, i64 2
  %r1514 = load i64, ptr %r1513, align 8
  %r1515 = icmp ne i64 %r1514, 0
  br i1 %r1515, label %pic.prefix.meta.280, label %pic.miss.288

pic.prefix.meta.280:                              ; preds = %pic.prefix.guard.279
  %r1516 = add nuw nsw i64 %r1462, 8
  %r1517 = inttoptr i64 %r1516 to ptr
  %r1518 = load i64, ptr %r1517, align 8
  %r1519 = icmp ne i64 %r1518, 0
  br i1 %r1519, label %pic.prefix.token.281, label %pic.miss.288

pic.prefix.token.281:                             ; preds = %pic.prefix.meta.280
  %r1520 = inttoptr i64 %r1518 to ptr
  %r1521 = getelementptr i64, ptr %r1520, i64 6
  %r1522 = load i64, ptr %r1521, align 8
  %r1523 = icmp eq i64 %r1522, %r1514
  br i1 %r1523, label %pic.prefix.hit.282, label %pic.miss.288

pic.prefix.hit.282:                               ; preds = %pic.prefix.token.281
  %r1524 = getelementptr i64, ptr %r1482, i64 1
  %r1525 = load i64, ptr %r1524, align 8
  %r1526 = shl i64 %r1525, 3
  %r1527 = add nuw nsw i64 %r1462, 16
  %r1528 = add i64 %r1527, %r1526
  %r1529 = inttoptr i64 %r1528 to ptr
  %r1530 = load double, ptr %r1529, align 8
  br label %pic.merge.291

pic.desc.classify.283:                            ; preds = %pic.recv_hdr.292
  %r1486 = and i1 %r1476, %r1483
  br i1 %r1486, label %pic.desc.prefix.guard.284, label %pic.miss.cold.289

pic.desc.prefix.guard.284:                        ; preds = %pic.desc.classify.283
  %r1531 = getelementptr i64, ptr %r1482, i64 2
  %r1532 = load i64, ptr %r1531, align 8
  %r1533 = icmp ne i64 %r1532, 0
  br i1 %r1533, label %pic.desc.prefix.meta.285, label %pic.miss.cold.289

pic.desc.prefix.meta.285:                         ; preds = %pic.desc.prefix.guard.284
  %r1534 = add nuw nsw i64 %r1462, 8
  %r1535 = inttoptr i64 %r1534 to ptr
  %r1536 = load i64, ptr %r1535, align 8
  %r1537 = icmp ne i64 %r1536, 0
  br i1 %r1537, label %pic.desc.prefix.token.286, label %pic.miss.cold.289

pic.desc.prefix.token.286:                        ; preds = %pic.desc.prefix.meta.285
  %r1538 = inttoptr i64 %r1536 to ptr
  %r1539 = getelementptr i64, ptr %r1538, i64 6
  %r1540 = load i64, ptr %r1539, align 8
  %r1541 = icmp eq i64 %r1540, %r1532
  br i1 %r1541, label %pic.desc.prefix.hit.287, label %pic.miss.cold.289

pic.desc.prefix.hit.287:                          ; preds = %pic.desc.prefix.token.286
  %r1542 = getelementptr i64, ptr %r1482, i64 1
  %r1543 = load i64, ptr %r1542, align 8
  %r1544 = shl i64 %r1543, 3
  %r1545 = add nuw nsw i64 %r1462, 16
  %r1546 = add i64 %r1545, %r1544
  %r1547 = inttoptr i64 %r1546 to ptr
  %r1548 = load double, ptr %r1547, align 8
  br label %pic.merge.291

pic.miss.288:                                     ; preds = %pic.hit.inline.295, %pic.prefix.token.281, %pic.prefix.meta.280, %pic.prefix.guard.279
  %r1549 = getelementptr i64, ptr %r1482, i64 3
  %r1550 = load i64, ptr %r1549, align 8
  %r1551 = icmp sgt i64 %r1550, 0
  br i1 %r1551, label %pic.ways.296, label %pic.miss.call.290

pic.miss.cold.289:                                ; preds = %pic.desc.prefix.token.286, %pic.desc.prefix.meta.285, %pic.desc.prefix.guard.284, %pic.desc.classify.283, %pget.recv_ok.271
  br label %pic.miss.call.290

pic.miss.call.290:                                ; preds = %pic.way.load.297, %pic.ways.296, %pic.miss.cold.289, %pic.miss.288
  %r1590 = load double, ptr @test_json_tape_batch_records_ts_.str.18.handle, align 8
  %r1591 = bitcast double %r1590 to i64
  %r1592 = and i64 %r1591, 281474976710655
  %statepoint_token267 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1462, i64 %r1592, ptr @perry_ic_test_json_tape_batch_records_ts__12, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.81062, ptr addrspace(1) %.81012, ptr addrspace(1) %.71093, ptr addrspace(1) %.9, ptr addrspace(1) %.01099, ptr addrspace(1) %.81037) ]
  %r1593268 = call double @llvm.experimental.gc.result.f64(token %statepoint_token267)
  %rs4gc.s20.relocated269 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token267, i32 0, i32 0) ; (%.81062, %.81062)
  %r131.0.base.relocated270 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token267, i32 1, i32 1) ; (%.81012, %.81012)
  %rs4gc.s22.relocated271 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token267, i32 2, i32 2) ; (%.71093, %.71093)
  %rs4gc.s15.relocated272 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token267, i32 3, i32 3) ; (%.9, %.9)
  %rs4gc.s25.relocated273 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token267, i32 4, i32 4) ; (%.01099, %.01099)
  %r131.0.relocated274 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token267, i32 1, i32 5) ; (%.81012, %.81037)
  br label %pic.merge.291

pic.merge.291:                                    ; preds = %pic.way.live.298, %pic.hit.overflow.294, %pic.miss.call.290, %pic.desc.prefix.hit.287, %pic.prefix.hit.282, %pic.hit.live.278
  %.21101 = phi ptr addrspace(1) [ %rs4gc.s25.relocated281, %pic.hit.overflow.294 ], [ %rs4gc.s25.relocated273, %pic.miss.call.290 ], [ %.01099, %pic.way.live.298 ], [ %.01099, %pic.hit.live.278 ], [ %.01099, %pic.prefix.hit.282 ], [ %.01099, %pic.desc.prefix.hit.287 ]
  %.91095 = phi ptr addrspace(1) [ %rs4gc.s22.relocated279, %pic.hit.overflow.294 ], [ %rs4gc.s22.relocated271, %pic.miss.call.290 ], [ %.71093, %pic.way.live.298 ], [ %.71093, %pic.hit.live.278 ], [ %.71093, %pic.prefix.hit.282 ], [ %.71093, %pic.desc.prefix.hit.287 ]
  %.101064 = phi ptr addrspace(1) [ %rs4gc.s20.relocated277, %pic.hit.overflow.294 ], [ %rs4gc.s20.relocated269, %pic.miss.call.290 ], [ %.81062, %pic.way.live.298 ], [ %.81062, %pic.hit.live.278 ], [ %.81062, %pic.prefix.hit.282 ], [ %.81062, %pic.desc.prefix.hit.287 ]
  %.101039 = phi ptr addrspace(1) [ %r131.0.relocated282, %pic.hit.overflow.294 ], [ %r131.0.relocated274, %pic.miss.call.290 ], [ %.81037, %pic.way.live.298 ], [ %.81037, %pic.hit.live.278 ], [ %.81037, %pic.prefix.hit.282 ], [ %.81037, %pic.desc.prefix.hit.287 ]
  %.101014 = phi ptr addrspace(1) [ %r131.0.base.relocated278, %pic.hit.overflow.294 ], [ %r131.0.base.relocated270, %pic.miss.call.290 ], [ %.81012, %pic.way.live.298 ], [ %.81012, %pic.hit.live.278 ], [ %.81012, %pic.prefix.hit.282 ], [ %.81012, %pic.desc.prefix.hit.287 ]
  %.11 = phi ptr addrspace(1) [ %rs4gc.s15.relocated280, %pic.hit.overflow.294 ], [ %rs4gc.s15.relocated272, %pic.miss.call.290 ], [ %.9, %pic.way.live.298 ], [ %.9, %pic.hit.live.278 ], [ %.9, %pic.prefix.hit.282 ], [ %.9, %pic.desc.prefix.hit.287 ]
  %r1594 = phi double [ %r1510, %pic.hit.live.278 ], [ %r1505276, %pic.hit.overflow.294 ], [ %r1530, %pic.prefix.hit.282 ], [ %r1548, %pic.desc.prefix.hit.287 ], [ %r1587, %pic.way.live.298 ], [ %r1593268, %pic.miss.call.290 ]
  br label %pget.recv_merge.274

pic.recv_hdr.292:                                 ; preds = %pget.recv_ok.271
  %r1473 = sub nuw nsw i64 %r1462, 8
  %r1474 = inttoptr i64 %r1473 to ptr
  %r1475 = load i8, ptr %r1474, align 1
  %r1476 = icmp eq i8 %r1475, 2
  %r1477 = sub nuw nsw i64 %r1462, 6
  %r1478 = inttoptr i64 %r1477 to ptr
  %r1479 = load i16, ptr %r1478, align 2
  %r1480 = and i16 %r1479, 2048
  %r1481 = icmp eq i16 %r1480, 0
  %r1482 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__12, align 8
  %r1483 = icmp ne ptr %r1482, null
  %r1484 = and i1 %r1476, %r1481
  %r1485 = and i1 %r1484, %r1483
  br i1 %r1485, label %pic.token.293, label %pic.desc.classify.283

pic.token.293:                                    ; preds = %pic.recv_hdr.292
  %r1487 = add nuw nsw i64 %r1462, 4
  %r1488 = inttoptr i64 %r1487 to ptr
  %r1489 = load i32, ptr %r1488, align 4
  %r1490 = zext i32 %r1489 to i64
  %r1491 = or i64 %r1490, 4611686018427387904
  %r1492 = icmp ne i32 %r1489, 0
  %r1493 = getelementptr i64, ptr %r1482, i64 0
  %r1494 = load i64, ptr %r1493, align 8
  %r1495 = icmp eq i64 %r1491, %r1494
  %r1496 = and i1 %r1495, %r1492
  br i1 %r1496, label %pic.hit.277, label %pic.prefix.guard.279

pic.hit.overflow.294:                             ; preds = %pic.hit.277
  %r1501 = load double, ptr @test_json_tape_batch_records_ts_.str.18.handle, align 8
  %r1502 = bitcast double %r1501 to i64
  %r1503 = and i64 %r1502, 281474976710655
  %r1504 = trunc i64 %r1498 to i32
  %statepoint_token275 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1462, i64 %r1503, i32 %r1504, ptr @perry_ic_test_json_tape_batch_records_ts__12, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.81062, ptr addrspace(1) %.81012, ptr addrspace(1) %.71093, ptr addrspace(1) %.9, ptr addrspace(1) %.01099, ptr addrspace(1) %.81037) ]
  %r1505276 = call double @llvm.experimental.gc.result.f64(token %statepoint_token275)
  %rs4gc.s20.relocated277 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token275, i32 0, i32 0) ; (%.81062, %.81062)
  %r131.0.base.relocated278 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token275, i32 1, i32 1) ; (%.81012, %.81012)
  %rs4gc.s22.relocated279 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token275, i32 2, i32 2) ; (%.71093, %.71093)
  %rs4gc.s15.relocated280 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token275, i32 3, i32 3) ; (%.9, %.9)
  %rs4gc.s25.relocated281 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token275, i32 4, i32 4) ; (%.01099, %.01099)
  %r131.0.relocated282 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token275, i32 1, i32 5) ; (%.81012, %.81037)
  br label %pic.merge.291

pic.hit.inline.295:                               ; preds = %pic.hit.277
  %r1506 = shl i64 %r1498, 3
  %r1507 = add nuw nsw i64 %r1462, 16
  %r1508 = add i64 %r1507, %r1506
  %r1509 = inttoptr i64 %r1508 to ptr
  %r1510 = load double, ptr %r1509, align 8
  %r1511 = bitcast double %r1510 to i64
  %r1512 = icmp eq i64 %r1511, 9222246136947933200
  br i1 %r1512, label %pic.miss.288, label %pic.hit.live.278

pic.ways.296:                                     ; preds = %pic.miss.288
  %r1552 = getelementptr i64, ptr %r1482, i64 4
  %r1553 = load i64, ptr %r1552, align 8
  %r1554 = icmp eq i64 %r1553, %r1491
  %r1555 = getelementptr i64, ptr %r1482, i64 5
  %r1556 = load i64, ptr %r1555, align 8
  %r1557 = select i1 %r1554, i64 %r1556, i64 0
  %r1558 = getelementptr i64, ptr %r1482, i64 6
  %r1559 = load i64, ptr %r1558, align 8
  %r1560 = icmp eq i64 %r1559, %r1491
  %r1561 = getelementptr i64, ptr %r1482, i64 7
  %r1562 = load i64, ptr %r1561, align 8
  %r1563 = select i1 %r1560, i64 %r1562, i64 0
  %r1564 = getelementptr i64, ptr %r1482, i64 8
  %r1565 = load i64, ptr %r1564, align 8
  %r1566 = icmp eq i64 %r1565, %r1491
  %r1567 = getelementptr i64, ptr %r1482, i64 9
  %r1568 = load i64, ptr %r1567, align 8
  %r1569 = select i1 %r1566, i64 %r1568, i64 0
  %r1570 = getelementptr i64, ptr %r1482, i64 10
  %r1571 = load i64, ptr %r1570, align 8
  %r1572 = icmp eq i64 %r1571, %r1491
  %r1573 = getelementptr i64, ptr %r1482, i64 11
  %r1574 = load i64, ptr %r1573, align 8
  %r1575 = select i1 %r1572, i64 %r1574, i64 0
  %r1576 = or i1 %r1554, %r1560
  %r1577 = select i1 %r1554, i64 %r1557, i64 %r1563
  %r1578 = or i1 %r1566, %r1572
  %r1579 = select i1 %r1566, i64 %r1569, i64 %r1575
  %r1580 = or i1 %r1576, %r1578
  %r1581 = select i1 %r1576, i64 %r1577, i64 %r1579
  %r1582 = and i1 %r1492, %r1580
  br i1 %r1582, label %pic.way.load.297, label %pic.miss.call.290

pic.way.load.297:                                 ; preds = %pic.ways.296
  %r1583 = shl i64 %r1581, 3
  %r1584 = add nuw nsw i64 %r1462, 16
  %r1585 = add i64 %r1584, %r1583
  %r1586 = inttoptr i64 %r1585 to ptr
  %r1587 = load double, ptr %r1586, align 8
  %r1588 = bitcast double %r1587 to i64
  %r1589 = icmp eq i64 %r1588, 9222246136947933200
  br i1 %r1589, label %pic.miss.call.290, label %pic.way.live.298

pic.way.live.298:                                 ; preds = %pic.way.load.297
  br label %pic.merge.291

pget.throw_nullish.299:                           ; preds = %pget.recv_bad.272
  %r1598 = zext i1 %r1596 to i32
  %statepoint_token283 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1598, ptr @test_json_tape_batch_records_ts_.str.18.bytes, i64 2, i32 0, i32 0)
  unreachable

pget.recv_undef_return.300:                       ; preds = %pget.recv_bad.272
  %r1599 = load double, ptr @test_json_tape_batch_records_ts_.str.18.handle, align 8
  %r1600 = bitcast double %r1599 to i64
  %r1601 = and i64 %r1600, 281474976710655
  %statepoint_token284 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1461, i64 %r1601, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.81062, ptr addrspace(1) %.81012, ptr addrspace(1) %.71093, ptr addrspace(1) %.9, ptr addrspace(1) %.01099, ptr addrspace(1) %.81037) ]
  %r1602285 = call double @llvm.experimental.gc.result.f64(token %statepoint_token284)
  %rs4gc.s20.relocated286 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 0, i32 0) ; (%.81062, %.81062)
  %r131.0.base.relocated287 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 1, i32 1) ; (%.81012, %.81012)
  %rs4gc.s22.relocated288 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 2, i32 2) ; (%.71093, %.71093)
  %rs4gc.s15.relocated289 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 3, i32 3) ; (%.9, %.9)
  %rs4gc.s25.relocated290 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 4, i32 4) ; (%.01099, %.01099)
  %r131.0.relocated291 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 1, i32 5) ; (%.81012, %.81037)
  br label %pget.recv_merge.274

guarded_add.numeric.301:                          ; preds = %pget.recv_merge.274
  %r1620 = fadd double %r1609, %r1607
  br label %guarded_add.merge.303

guarded_add.dynamic.302:                          ; preds = %pget.recv_merge.274
  %statepoint_token292 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r1609, double %r1607, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.91063, ptr addrspace(1) %.91013, ptr addrspace(1) %.81094, ptr addrspace(1) %.10, ptr addrspace(1) %.91038) ]
  %r1621293 = call double @llvm.experimental.gc.result.f64(token %statepoint_token292)
  %rs4gc.s20.relocated294 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token292, i32 0, i32 0) ; (%.91063, %.91063)
  %r131.0.base.relocated295 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token292, i32 1, i32 1) ; (%.91013, %.91013)
  %rs4gc.s22.relocated296 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token292, i32 2, i32 2) ; (%.81094, %.81094)
  %rs4gc.s15.relocated297 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token292, i32 3, i32 3) ; (%.10, %.10)
  %r131.0.relocated298 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token292, i32 1, i32 4) ; (%.91013, %.91038)
  br label %guarded_add.merge.303

guarded_add.merge.303:                            ; preds = %guarded_add.dynamic.302, %guarded_add.numeric.301
  %.101096 = phi ptr addrspace(1) [ %.81094, %guarded_add.numeric.301 ], [ %rs4gc.s22.relocated296, %guarded_add.dynamic.302 ]
  %.111065 = phi ptr addrspace(1) [ %.91063, %guarded_add.numeric.301 ], [ %rs4gc.s20.relocated294, %guarded_add.dynamic.302 ]
  %.111040 = phi ptr addrspace(1) [ %.91038, %guarded_add.numeric.301 ], [ %r131.0.relocated298, %guarded_add.dynamic.302 ]
  %.111015 = phi ptr addrspace(1) [ %.91013, %guarded_add.numeric.301 ], [ %r131.0.base.relocated295, %guarded_add.dynamic.302 ]
  %.12 = phi ptr addrspace(1) [ %.10, %guarded_add.numeric.301 ], [ %rs4gc.s15.relocated297, %guarded_add.dynamic.302 ]
  %r1622 = phi double [ %r1620, %guarded_add.numeric.301 ], [ %r1621293, %guarded_add.dynamic.302 ]
  %rs4gc.b26 = bitcast double %r1622 to i64
  %rs4gc.s26 = inttoptr i64 %rs4gc.b26 to ptr addrspace(1)
  %r1623.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s26 to i64
  %r1623 = call i64 asm "", "=r,0"(i64 %r1623.rs4i) #7
  %r1624 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1625 = icmp ne i32 %r1624, 0
  br i1 %r1625, label %shadow.root.barrier.304, label %shadow.root.barrier.done.305

shadow.root.barrier.304:                          ; preds = %guarded_add.merge.303
  call void @js_write_barrier_root_nanbox(i64 %r1623) #7
  br label %shadow.root.barrier.done.305

shadow.root.barrier.done.305:                     ; preds = %shadow.root.barrier.304, %guarded_add.merge.303
  %r1626 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1627 = icmp ne i32 %r1626, 0
  br i1 %r1627, label %gcpoll.306, label %gcpoll.done.307

gcpoll.306:                                       ; preds = %shadow.root.barrier.done.305
  %statepoint_token299 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s26, ptr addrspace(1) %.111065, ptr addrspace(1) %.111015, ptr addrspace(1) %.101096, ptr addrspace(1) %.12, ptr addrspace(1) %.111040) ]
  %rs4gc.s26.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token299, i32 0, i32 0) ; (%rs4gc.s26, %rs4gc.s26)
  %rs4gc.s20.relocated300 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token299, i32 1, i32 1) ; (%.111065, %.111065)
  %r131.0.base.relocated301 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token299, i32 2, i32 2) ; (%.111015, %.111015)
  %rs4gc.s22.relocated302 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token299, i32 3, i32 3) ; (%.101096, %.101096)
  %rs4gc.s15.relocated303 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token299, i32 4, i32 4) ; (%.12, %.12)
  %r131.0.relocated304 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token299, i32 2, i32 5) ; (%.111015, %.111040)
  br label %gcpoll.done.307

gcpoll.done.307:                                  ; preds = %gcpoll.306, %shadow.root.barrier.done.305
  %.01102 = phi ptr addrspace(1) [ %rs4gc.s26.relocated, %gcpoll.306 ], [ %rs4gc.s26, %shadow.root.barrier.done.305 ]
  %.111097 = phi ptr addrspace(1) [ %rs4gc.s22.relocated302, %gcpoll.306 ], [ %.101096, %shadow.root.barrier.done.305 ]
  %.121066 = phi ptr addrspace(1) [ %rs4gc.s20.relocated300, %gcpoll.306 ], [ %.111065, %shadow.root.barrier.done.305 ]
  %.121041 = phi ptr addrspace(1) [ %r131.0.relocated304, %gcpoll.306 ], [ %.111040, %shadow.root.barrier.done.305 ]
  %.121016 = phi ptr addrspace(1) [ %r131.0.base.relocated301, %gcpoll.306 ], [ %.111015, %shadow.root.barrier.done.305 ]
  %.13 = phi ptr addrspace(1) [ %rs4gc.s15.relocated303, %gcpoll.306 ], [ %.12, %shadow.root.barrier.done.305 ]
  br label %for.stable_packed_slow.update.219

tav.get.fast.308:                                 ; preds = %tav.get.brand.312
  %r1660 = bitcast double %r1632 to i64
  %r1661 = and i64 %r1660, 281474976710655
  %r1662 = add nuw nsw i64 %r1661, 8
  %r1663 = inttoptr i64 %r1662 to ptr
  %r1664 = load i8, ptr %r1663, align 1
  %r1665 = zext i8 %r1664 to i64
  %r1669 = inttoptr i64 %r1661 to ptr
  %r1670 = load i32, ptr %r1669, align 4
  %r1671 = zext i32 %r1670 to i64
  %r1672 = icmp ult i64 0, %r1671
  %r1673 = and i1 true, %r1672
  br i1 %r1673, label %tav.get.load.309, label %tav.get.slow.310

tav.get.load.309:                                 ; preds = %tav.get.fast.308
  %r1674 = add nuw nsw i64 %r1661, 16
  %r1675 = icmp eq i64 %r1665, 0
  br i1 %r1675, label %tav.k.i8.313, label %tav.kd1.321

tav.get.slow.310:                                 ; preds = %tav.get.brand.312, %tav.get.fast.308, %stable_packed.loop.merge.137
  %r1726 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__13, align 8
  %r1727 = icmp ne ptr %r1726, null
  %r1728 = select i1 %r1727, ptr %r1726, ptr @perry_ic_test_json_tape_batch_records_ts__13
  %r1729 = bitcast double %r1632 to i64
  %r1730 = and i64 %r1729, 281474976710655
  %r1731 = and i64 %r1729, -281474976710656
  %r1732 = icmp eq i64 %r1731, 9222527611924643840
  %r1733 = icmp uge i64 %r1730, 2199023255552
  %r1734 = icmp ult i64 %r1730, 140737488355328
  %r1737 = and i1 %r1732, %r1733
  %r1738 = and i1 %r1737, %r1734
  br i1 %r1738, label %arrlike.ic.header.328, label %arrlike.ic.miss.347

tav.get.merge.311:                                ; preds = %arrlike.elem.value.353, %arrlike.ic.miss.347, %arrlike.ic.spill_load.346, %arrlike.ic.inline.343, %arrlike.ic.array_load.331, %tav.k.f64.320, %tav.k.f32.319, %tav.k.u32.318, %tav.k.i32.317, %tav.k.u16.316, %tav.k.i16.315, %tav.k.u8.314, %tav.k.i8.313
  %.01103 = phi ptr addrspace(1) [ %r138.1, %tav.k.i8.313 ], [ %r138.1, %tav.k.u8.314 ], [ %r138.1, %tav.k.i16.315 ], [ %r138.1, %tav.k.u16.316 ], [ %r138.1, %tav.k.i32.317 ], [ %r138.1, %tav.k.u32.318 ], [ %r138.1, %tav.k.f32.319 ], [ %r138.1, %tav.k.f64.320 ], [ %r138.1, %arrlike.ic.array_load.331 ], [ %r138.1.relocated, %arrlike.ic.miss.347 ], [ %r138.1, %arrlike.elem.value.353 ], [ %r138.1, %arrlike.ic.inline.343 ], [ %r138.1, %arrlike.ic.spill_load.346 ]
  %.121098 = phi ptr addrspace(1) [ %.61092, %tav.k.i8.313 ], [ %.61092, %tav.k.u8.314 ], [ %.61092, %tav.k.i16.315 ], [ %.61092, %tav.k.u16.316 ], [ %.61092, %tav.k.i32.317 ], [ %.61092, %tav.k.u32.318 ], [ %.61092, %tav.k.f32.319 ], [ %.61092, %tav.k.f64.320 ], [ %.61092, %arrlike.ic.array_load.331 ], [ %rs4gc.s22.relocated311, %arrlike.ic.miss.347 ], [ %.61092, %arrlike.elem.value.353 ], [ %.61092, %arrlike.ic.inline.343 ], [ %.61092, %arrlike.ic.spill_load.346 ]
  %.131067 = phi ptr addrspace(1) [ %.71061, %tav.k.i8.313 ], [ %.71061, %tav.k.u8.314 ], [ %.71061, %tav.k.i16.315 ], [ %.71061, %tav.k.u16.316 ], [ %.71061, %tav.k.i32.317 ], [ %.71061, %tav.k.u32.318 ], [ %.71061, %tav.k.f32.319 ], [ %.71061, %tav.k.f64.320 ], [ %.71061, %arrlike.ic.array_load.331 ], [ %rs4gc.s20.relocated307, %arrlike.ic.miss.347 ], [ %.71061, %arrlike.elem.value.353 ], [ %.71061, %arrlike.ic.inline.343 ], [ %.71061, %arrlike.ic.spill_load.346 ]
  %.131042 = phi ptr addrspace(1) [ %.71036, %tav.k.i8.313 ], [ %.71036, %tav.k.u8.314 ], [ %.71036, %tav.k.i16.315 ], [ %.71036, %tav.k.u16.316 ], [ %.71036, %tav.k.i32.317 ], [ %.71036, %tav.k.u32.318 ], [ %.71036, %tav.k.f32.319 ], [ %.71036, %tav.k.f64.320 ], [ %.71036, %arrlike.ic.array_load.331 ], [ %r131.0.relocated310, %arrlike.ic.miss.347 ], [ %.71036, %arrlike.elem.value.353 ], [ %.71036, %arrlike.ic.inline.343 ], [ %.71036, %arrlike.ic.spill_load.346 ]
  %.131017 = phi ptr addrspace(1) [ %.71011, %tav.k.i8.313 ], [ %.71011, %tav.k.u8.314 ], [ %.71011, %tav.k.i16.315 ], [ %.71011, %tav.k.u16.316 ], [ %.71011, %tav.k.i32.317 ], [ %.71011, %tav.k.u32.318 ], [ %.71011, %tav.k.f32.319 ], [ %.71011, %tav.k.f64.320 ], [ %.71011, %arrlike.ic.array_load.331 ], [ %r131.0.base.relocated309, %arrlike.ic.miss.347 ], [ %.71011, %arrlike.elem.value.353 ], [ %.71011, %arrlike.ic.inline.343 ], [ %.71011, %arrlike.ic.spill_load.346 ]
  %.14 = phi ptr addrspace(1) [ %.8, %tav.k.i8.313 ], [ %.8, %tav.k.u8.314 ], [ %.8, %tav.k.i16.315 ], [ %.8, %tav.k.u16.316 ], [ %.8, %tav.k.i32.317 ], [ %.8, %tav.k.u32.318 ], [ %.8, %tav.k.f32.319 ], [ %.8, %tav.k.f64.320 ], [ %.8, %arrlike.ic.array_load.331 ], [ %rs4gc.s15.relocated308, %arrlike.ic.miss.347 ], [ %.8, %arrlike.elem.value.353 ], [ %.8, %arrlike.ic.inline.343 ], [ %.8, %arrlike.ic.spill_load.346 ]
  %r1899 = phi double [ %r1688, %tav.k.i8.313 ], [ %r1694, %tav.k.u8.314 ], [ %r1700, %tav.k.i16.315 ], [ %r1706, %tav.k.u16.316 ], [ %r1711, %tav.k.i32.317 ], [ %r1716, %tav.k.u32.318 ], [ %r1721, %tav.k.f32.319 ], [ %r1725, %tav.k.f64.320 ], [ %r1782, %arrlike.elem.value.353 ], [ %r1810, %arrlike.ic.array_load.331 ], [ %r1880, %arrlike.ic.inline.343 ], [ %r1897, %arrlike.ic.spill_load.346 ], [ %r1898306, %arrlike.ic.miss.347 ]
  %r1900.rs4i = ptrtoint ptr addrspace(1) %.121098 to i64
  %r1900.rs4o = call i64 asm "", "=r,0"(i64 %r1900.rs4i) #7
  %r1900 = bitcast i64 %r1900.rs4o to double
  %r1901 = bitcast double %r1899 to i64
  %r1902 = bitcast double %r1900 to i64
  %r1903 = icmp eq i64 %r1901, %r1902
  br i1 %r1903, label %anyeq.same.355, label %anyeq.diff.356

tav.get.brand.312:                                ; preds = %stable_packed.loop.merge.137
  %r1644 = bitcast double %r1632 to i64
  %r1645 = and i64 %r1644, 281474976710655
  %r1646 = sub nsw i64 %r1645, 8
  %r1647 = inttoptr i64 %r1646 to ptr
  %r1648 = load i8, ptr %r1647, align 1
  %r1649 = icmp eq i8 %r1648, 11
  %r1650 = add nuw nsw i64 %r1645, 8
  %r1651 = inttoptr i64 %r1650 to ptr
  %r1652 = load i8, ptr %r1651, align 1
  %r1653 = zext i8 %r1652 to i64
  %r1654 = icmp ule i64 %r1653, 8
  %r1657 = and i1 %r1649, %r1654
  br i1 %r1657, label %tav.get.fast.308, label %tav.get.slow.310

tav.k.i8.313:                                     ; preds = %tav.get.load.309
  %r1684 = add nuw nsw i64 %r1674, 0
  %r1685 = inttoptr i64 %r1684 to ptr
  %r1686 = load i8, ptr %r1685, align 1
  %r1687 = sext i8 %r1686 to i32
  %r1688 = sitofp i32 %r1687 to double
  br label %tav.get.merge.311

tav.k.u8.314:                                     ; preds = %tav.kd7.327, %tav.kd1.321
  %r1690 = add nuw nsw i64 %r1674, 0
  %r1691 = inttoptr i64 %r1690 to ptr
  %r1692 = load i8, ptr %r1691, align 1
  %r1693 = zext i8 %r1692 to i32
  %r1694 = uitofp nneg i32 %r1693 to double
  br label %tav.get.merge.311

tav.k.i16.315:                                    ; preds = %tav.kd2.322
  %r1696 = add nuw nsw i64 %r1674, 0
  %r1697 = inttoptr i64 %r1696 to ptr
  %r1698 = load i16, ptr %r1697, align 2
  %r1699 = sext i16 %r1698 to i32
  %r1700 = sitofp i32 %r1699 to double
  br label %tav.get.merge.311

tav.k.u16.316:                                    ; preds = %tav.kd3.323
  %r1702 = add nuw nsw i64 %r1674, 0
  %r1703 = inttoptr i64 %r1702 to ptr
  %r1704 = load i16, ptr %r1703, align 2
  %r1705 = zext i16 %r1704 to i32
  %r1706 = uitofp nneg i32 %r1705 to double
  br label %tav.get.merge.311

tav.k.i32.317:                                    ; preds = %tav.kd4.324
  %r1708 = add nuw nsw i64 %r1674, 0
  %r1709 = inttoptr i64 %r1708 to ptr
  %r1710 = load i32, ptr %r1709, align 4
  %r1711 = sitofp i32 %r1710 to double
  br label %tav.get.merge.311

tav.k.u32.318:                                    ; preds = %tav.kd5.325
  %r1713 = add nuw nsw i64 %r1674, 0
  %r1714 = inttoptr i64 %r1713 to ptr
  %r1715 = load i32, ptr %r1714, align 4
  %r1716 = uitofp i32 %r1715 to double
  br label %tav.get.merge.311

tav.k.f32.319:                                    ; preds = %tav.kd6.326
  %r1718 = add nuw nsw i64 %r1674, 0
  %r1719 = inttoptr i64 %r1718 to ptr
  %r1720 = load float, ptr %r1719, align 4
  %r1721 = fpext float %r1720 to double
  br label %tav.get.merge.311

tav.k.f64.320:                                    ; preds = %tav.kd7.327
  %r1723 = add nuw nsw i64 %r1674, 0
  %r1724 = inttoptr i64 %r1723 to ptr
  %r1725 = load double, ptr %r1724, align 8
  br label %tav.get.merge.311

tav.kd1.321:                                      ; preds = %tav.get.load.309
  %r1676 = icmp eq i64 %r1665, 1
  br i1 %r1676, label %tav.k.u8.314, label %tav.kd2.322

tav.kd2.322:                                      ; preds = %tav.kd1.321
  %r1677 = icmp eq i64 %r1665, 2
  br i1 %r1677, label %tav.k.i16.315, label %tav.kd3.323

tav.kd3.323:                                      ; preds = %tav.kd2.322
  %r1678 = icmp eq i64 %r1665, 3
  br i1 %r1678, label %tav.k.u16.316, label %tav.kd4.324

tav.kd4.324:                                      ; preds = %tav.kd3.323
  %r1679 = icmp eq i64 %r1665, 4
  br i1 %r1679, label %tav.k.i32.317, label %tav.kd5.325

tav.kd5.325:                                      ; preds = %tav.kd4.324
  %r1680 = icmp eq i64 %r1665, 5
  br i1 %r1680, label %tav.k.u32.318, label %tav.kd6.326

tav.kd6.326:                                      ; preds = %tav.kd5.325
  %r1681 = icmp eq i64 %r1665, 6
  br i1 %r1681, label %tav.k.f32.319, label %tav.kd7.327

tav.kd7.327:                                      ; preds = %tav.kd6.326
  %r1682 = icmp eq i64 %r1665, 7
  br i1 %r1682, label %tav.k.f64.320, label %tav.k.u8.314

arrlike.ic.header.328:                            ; preds = %tav.get.slow.310
  %r1744 = sub nuw nsw i64 %r1730, 8
  %r1745 = inttoptr i64 %r1744 to ptr
  %r1746 = load i8, ptr %r1745, align 1
  %r1748 = sub nuw nsw i64 %r1730, 7
  %r1749 = inttoptr i64 %r1748 to ptr
  %r1750 = load i8, ptr %r1749, align 1
  %r1751 = and i8 %r1750, -128
  %r1752 = icmp eq i8 %r1751, 0
  %r1753 = and i1 true, %r1752
  br i1 %r1753, label %arrlike.ic.brand.329, label %arrlike.ic.miss.347

arrlike.ic.brand.329:                             ; preds = %arrlike.ic.header.328
  %r1747 = icmp eq i8 %r1746, 1
  br i1 %r1747, label %arrlike.ic.array_guard.330, label %arrlike.elem.kind.348

arrlike.ic.array_guard.330:                       ; preds = %arrlike.ic.brand.329
  %r1785 = sub nuw nsw i64 %r1730, 6
  %r1786 = inttoptr i64 %r1785 to ptr
  %r1787 = load i16, ptr %r1786, align 2
  %r1788 = and i16 %r1787, 1024
  %r1789 = icmp eq i16 %r1788, 0
  %r1790 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1791 = icmp eq i8 %r1790, 0
  %r1792 = inttoptr i64 %r1730 to ptr
  %r1793 = load i32, ptr %r1792, align 4
  %r1794 = add nuw nsw i64 %r1730, 4
  %r1795 = inttoptr i64 %r1794 to ptr
  %r1796 = load i32, ptr %r1795, align 4
  %r1797 = zext i32 %r1793 to i64
  %r1798 = zext i32 %r1796 to i64
  %r1799 = icmp ult i64 0, %r1797
  %r1800 = icmp ule i64 %r1797, %r1798
  %r1801 = and i1 %r1789, %r1791
  %r1802 = and i1 %r1801, %r1799
  %r1803 = and i1 %r1802, %r1800
  br i1 %r1803, label %arrlike.ic.array_load.331, label %arrlike.ic.miss.347

arrlike.ic.array_load.331:                        ; preds = %arrlike.ic.array_guard.330
  %r1805 = getelementptr inbounds nuw i64, ptr %r1792, i64 1
  %r1806 = load double, ptr %r1805, align 8
  %r1807 = bitcast double %r1806 to i64
  %r1808 = icmp eq i64 %r1807, 9222246136947933200
  %r1810 = select i1 %r1808, double 0x7FFC000000000001, double %r1806
  br label %tav.get.merge.311

arrlike.ic.shape.332:                             ; preds = %arrlike.elem.store.350, %arrlike.elem.meta.349
  %r1812 = inttoptr i64 %r1730 to ptr
  %r1813 = load i32, ptr %r1812, align 4
  %r1814 = add nuw nsw i64 %r1730, 4
  %r1815 = inttoptr i64 %r1814 to ptr
  %r1816 = load i32, ptr %r1815, align 4
  %r1817 = zext i32 %r1813 to i64
  %r1818 = zext i32 %r1816 to i64
  %r1819 = shl nuw i64 %r1817, 32
  %r1820 = or i64 %r1819, %r1818
  %r1821 = getelementptr i64, ptr %r1728, i64 0
  %r1822 = load i64, ptr %r1821, align 8
  %r1823 = icmp ne i64 %r1822, 0
  %r1824 = and i1 true, %r1823
  br i1 %r1824, label %arrlike.ic.identity.333, label %arrlike.ic.miss.347

arrlike.ic.identity.333:                          ; preds = %arrlike.ic.shape.332
  %r1825 = and i64 %r1822, -9223372036854775808
  %2 = icmp slt i64 %r1822, 0
  br i1 %2, label %arrlike.ic.family_meta.335, label %arrlike.ic.exact.334

arrlike.ic.exact.334:                             ; preds = %arrlike.ic.identity.333
  %r1827 = icmp eq i64 %r1820, %r1822
  br i1 %r1827, label %arrlike.ic.bounds.337, label %arrlike.ic.miss.347

arrlike.ic.family_meta.335:                       ; preds = %arrlike.ic.identity.333
  %r1828 = add nuw nsw i64 %r1730, 8
  %r1829 = inttoptr i64 %r1828 to ptr
  %r1830 = load i64, ptr %r1829, align 8
  %r1831 = icmp ne i64 %r1830, 0
  br i1 %r1831, label %arrlike.ic.family_token.336, label %arrlike.ic.miss.347

arrlike.ic.family_token.336:                      ; preds = %arrlike.ic.family_meta.335
  %r1832 = inttoptr i64 %r1830 to ptr
  %r1833 = getelementptr i64, ptr %r1832, i64 6
  %r1834 = load i64, ptr %r1833, align 8
  %r1835 = icmp eq i64 %r1834, %r1822
  br i1 %r1835, label %arrlike.ic.bounds.337, label %arrlike.ic.miss.347

arrlike.ic.bounds.337:                            ; preds = %arrlike.ic.family_token.336, %arrlike.ic.exact.334
  %r1836 = getelementptr i64, ptr %r1726, i64 1
  %r1837 = load i64, ptr %r1836, align 8
  %r1838 = getelementptr i64, ptr %r1726, i64 2
  %r1839 = load i64, ptr %r1838, align 8
  %r1840 = getelementptr i64, ptr %r1726, i64 3
  %r1841 = load i64, ptr %r1840, align 8
  %r1842 = getelementptr i64, ptr %r1726, i64 4
  %r1843 = load i64, ptr %r1842, align 8
  %r1844 = icmp ult i64 %r1837, %r1843
  br i1 %r1844, label %arrlike.ic.length_inline.338, label %arrlike.ic.length_spill_meta.339

arrlike.ic.length_inline.338:                     ; preds = %arrlike.ic.bounds.337
  %r1845 = shl i64 %r1837, 3
  %r1846 = add i64 %r1845, 16
  %r1847 = add i64 %r1730, %r1846
  %r1848 = inttoptr i64 %r1847 to ptr
  %r1849 = load double, ptr %r1848, align 8
  br label %arrlike.ic.range.342

arrlike.ic.length_spill_meta.339:                 ; preds = %arrlike.ic.bounds.337
  %r1850 = add nuw nsw i64 %r1730, 8
  %r1851 = inttoptr i64 %r1850 to ptr
  %r1852 = load i64, ptr %r1851, align 8
  %r1853 = icmp ne i64 %r1852, 0
  br i1 %r1853, label %arrlike.ic.length_spill_ptr.340, label %arrlike.ic.miss.347

arrlike.ic.length_spill_ptr.340:                  ; preds = %arrlike.ic.length_spill_meta.339
  %r1854 = inttoptr i64 %r1852 to ptr
  %r1855 = getelementptr i64, ptr %r1854, i64 4
  %r1856 = load i64, ptr %r1855, align 8
  %r1857 = icmp ne i64 %r1856, 0
  %r1858 = select i1 %r1857, i64 %r1856, i64 %r1852
  %r1859 = inttoptr i64 %r1858 to ptr
  %r1860 = load i32, ptr %r1859, align 4
  %r1861 = zext i32 %r1860 to i64
  %r1862 = icmp ult i64 %r1837, %r1861
  %r1863 = and i1 %r1857, %r1862
  br i1 %r1863, label %arrlike.ic.length_spill_load.341, label %arrlike.ic.miss.347

arrlike.ic.length_spill_load.341:                 ; preds = %arrlike.ic.length_spill_ptr.340
  %r1864 = add nuw nsw i64 %r1837, 1
  %r1865 = getelementptr inbounds nuw i64, ptr %r1859, i64 %r1864
  %r1866 = load double, ptr %r1865, align 8
  br label %arrlike.ic.range.342

arrlike.ic.range.342:                             ; preds = %arrlike.ic.length_spill_load.341, %arrlike.ic.length_inline.338
  %r1867 = phi double [ %r1849, %arrlike.ic.length_inline.338 ], [ %r1866, %arrlike.ic.length_spill_load.341 ]
  %r1868 = fcmp olt double 0.000000e+00, %r1867
  %r1869 = icmp ult i64 0, %r1841
  %r1870 = and i1 %r1868, %r1869
  %r1871 = add nuw nsw i64 %r1839, 0
  %r1872 = icmp ult i64 %r1871, %r1843
  %r1873 = and i1 %r1870, %r1872
  %r1874 = xor i1 %r1872, true
  %r1875 = and i1 %r1870, %r1874
  br i1 %r1873, label %arrlike.ic.inline.343, label %arrlike.ic.spill_or_miss.354

arrlike.ic.inline.343:                            ; preds = %arrlike.ic.range.342
  %r1876 = shl i64 %r1871, 3
  %r1877 = add i64 %r1876, 16
  %r1878 = add i64 %r1730, %r1877
  %r1879 = inttoptr i64 %r1878 to ptr
  %r1880 = load double, ptr %r1879, align 8
  br label %tav.get.merge.311

arrlike.ic.spill.344:                             ; preds = %arrlike.ic.spill_or_miss.354
  %r1881 = add nuw nsw i64 %r1730, 8
  %r1882 = inttoptr i64 %r1881 to ptr
  %r1883 = load i64, ptr %r1882, align 8
  %r1884 = icmp ne i64 %r1883, 0
  br i1 %r1884, label %arrlike.ic.spill_ptr.345, label %arrlike.ic.miss.347

arrlike.ic.spill_ptr.345:                         ; preds = %arrlike.ic.spill.344
  %r1885 = inttoptr i64 %r1883 to ptr
  %r1886 = getelementptr i64, ptr %r1885, i64 4
  %r1887 = load i64, ptr %r1886, align 8
  %r1888 = icmp ne i64 %r1887, 0
  %r1889 = select i1 %r1888, i64 %r1887, i64 %r1883
  %r1890 = inttoptr i64 %r1889 to ptr
  %r1891 = load i32, ptr %r1890, align 4
  %r1892 = zext i32 %r1891 to i64
  %r1893 = icmp ult i64 %r1871, %r1892
  %r1894 = and i1 %r1888, %r1893
  br i1 %r1894, label %arrlike.ic.spill_load.346, label %arrlike.ic.miss.347

arrlike.ic.spill_load.346:                        ; preds = %arrlike.ic.spill_ptr.345
  %r1895 = add nuw nsw i64 %r1871, 1
  %r1896 = getelementptr inbounds nuw i64, ptr %r1890, i64 %r1895
  %r1897 = load double, ptr %r1896, align 8
  br label %tav.get.merge.311

arrlike.ic.miss.347:                              ; preds = %arrlike.ic.spill_or_miss.354, %arrlike.elem.load.352, %arrlike.elem.bounds.351, %arrlike.elem.kind.348, %arrlike.ic.spill_ptr.345, %arrlike.ic.spill.344, %arrlike.ic.length_spill_ptr.340, %arrlike.ic.length_spill_meta.339, %arrlike.ic.family_token.336, %arrlike.ic.family_meta.335, %arrlike.ic.exact.334, %arrlike.ic.shape.332, %arrlike.ic.array_guard.330, %arrlike.ic.header.328, %tav.get.slow.310
  %statepoint_token305 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, ptr)) @js_packed_arraylike_index_get, i32 3, i32 0, double %r1632, double 0.000000e+00, ptr @perry_ic_test_json_tape_batch_records_ts__13, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.71061, ptr addrspace(1) %r138.1, ptr addrspace(1) %.8, ptr addrspace(1) %.71011, ptr addrspace(1) %.71036, ptr addrspace(1) %.61092) ]
  %r1898306 = call double @llvm.experimental.gc.result.f64(token %statepoint_token305)
  %rs4gc.s20.relocated307 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token305, i32 0, i32 0) ; (%.71061, %.71061)
  %r138.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token305, i32 1, i32 1) ; (%r138.1, %r138.1)
  %rs4gc.s15.relocated308 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token305, i32 2, i32 2) ; (%.8, %.8)
  %r131.0.base.relocated309 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token305, i32 3, i32 3) ; (%.71011, %.71011)
  %r131.0.relocated310 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token305, i32 3, i32 4) ; (%.71011, %.71036)
  %rs4gc.s22.relocated311 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token305, i32 5, i32 5) ; (%.61092, %.61092)
  br label %tav.get.merge.311

arrlike.elem.kind.348:                            ; preds = %arrlike.ic.brand.329
  %r1754 = icmp eq i8 %r1746, 2
  br i1 %r1754, label %arrlike.elem.meta.349, label %arrlike.ic.miss.347

arrlike.elem.meta.349:                            ; preds = %arrlike.elem.kind.348
  %r1755 = add nuw nsw i64 %r1730, 8
  %r1756 = inttoptr i64 %r1755 to ptr
  %r1757 = load i64, ptr %r1756, align 8
  %r1758 = icmp ne i64 %r1757, 0
  br i1 %r1758, label %arrlike.elem.store.350, label %arrlike.ic.shape.332

arrlike.elem.store.350:                           ; preds = %arrlike.elem.meta.349
  %r1759 = inttoptr i64 %r1757 to ptr
  %r1760 = getelementptr i64, ptr %r1759, i64 12
  %r1761 = load i64, ptr %r1760, align 8
  %r1762 = icmp ne i64 %r1761, 0
  br i1 %r1762, label %arrlike.elem.bounds.351, label %arrlike.ic.shape.332

arrlike.elem.bounds.351:                          ; preds = %arrlike.elem.store.350
  %r1763 = sub i64 %r1761, 8
  %r1764 = inttoptr i64 %r1763 to ptr
  %r1765 = load i8, ptr %r1764, align 1
  %r1766 = icmp eq i8 %r1765, 1
  %r1767 = sub i64 %r1761, 7
  %r1768 = inttoptr i64 %r1767 to ptr
  %r1769 = load i8, ptr %r1768, align 1
  %r1770 = and i8 %r1769, -128
  %r1771 = icmp eq i8 %r1770, 0
  %r1772 = inttoptr i64 %r1761 to ptr
  %r1773 = load i32, ptr %r1772, align 4
  %r1774 = zext i32 %r1773 to i64
  %r1775 = icmp ult i64 0, %r1774
  %r1776 = and i1 %r1766, %r1771
  %r1777 = and i1 %r1776, %r1775
  br i1 %r1777, label %arrlike.elem.load.352, label %arrlike.ic.miss.347

arrlike.elem.load.352:                            ; preds = %arrlike.elem.bounds.351
  %r1779 = add i64 %r1761, 8
  %r1780 = add nuw nsw i64 %r1779, 0
  %r1781 = inttoptr i64 %r1780 to ptr
  %r1782 = load double, ptr %r1781, align 8
  %r1783 = bitcast double %r1782 to i64
  %r1784 = icmp eq i64 %r1783, 9222246136947933200
  br i1 %r1784, label %arrlike.ic.miss.347, label %arrlike.elem.value.353

arrlike.elem.value.353:                           ; preds = %arrlike.elem.load.352
  br label %tav.get.merge.311

arrlike.ic.spill_or_miss.354:                     ; preds = %arrlike.ic.range.342
  br i1 %r1875, label %arrlike.ic.spill.344, label %arrlike.ic.miss.347

anyeq.same.355:                                   ; preds = %tav.get.merge.311
  %r1904 = lshr i64 %r1901, 48
  %r1905 = icmp uge i64 %r1904, 32761
  %r1906 = icmp ule i64 %r1904, 32767
  %r1907 = and i1 %r1905, %r1906
  %r1908 = fcmp uno double %r1899, %r1899
  %r1909 = xor i1 %r1908, true
  %r1910 = or i1 %r1907, %r1909
  br i1 %r1910, label %anyeq.true.358, label %anyeq.slow.357

anyeq.diff.356:                                   ; preds = %tav.get.merge.311
  %r1911 = and i64 %r1901, 9221120237041090560
  %r1912 = icmp ne i64 %r1911, 9221120237041090560
  %r1913 = and i64 %r1902, 9221120237041090560
  %r1914 = icmp ne i64 %r1913, 9221120237041090560
  %r1915 = and i1 %r1912, %r1914
  br i1 %r1915, label %anyeq.num.361, label %anyeq.tag.362

anyeq.slow.357:                                   ; preds = %anyeq.tag.362, %anyeq.same.355
  %statepoint_token312 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i64)) @js_eq, i32 2, i32 0, i64 %r1901, i64 %r1902, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.131067, ptr addrspace(1) %.01103, ptr addrspace(1) %.14, ptr addrspace(1) %.131017, ptr addrspace(1) %.131042) ]
  %r1926313 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token312)
  %rs4gc.s20.relocated314 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token312, i32 0, i32 0) ; (%.131067, %.131067)
  %r138.1.relocated315 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token312, i32 1, i32 1) ; (%.01103, %.01103)
  %rs4gc.s15.relocated316 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token312, i32 2, i32 2) ; (%.14, %.14)
  %r131.0.base.relocated317 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token312, i32 3, i32 3) ; (%.131017, %.131017)
  %r131.0.relocated318 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token312, i32 3, i32 4) ; (%.131017, %.131042)
  br label %anyeq.merge.360

anyeq.true.358:                                   ; preds = %anyeq.num.361, %anyeq.same.355
  br label %anyeq.merge.360

anyeq.false.359:                                  ; preds = %anyeq.tag.362, %anyeq.num.361
  br label %anyeq.merge.360

anyeq.merge.360:                                  ; preds = %anyeq.false.359, %anyeq.true.358, %anyeq.slow.357
  %.11104 = phi ptr addrspace(1) [ %.01103, %anyeq.true.358 ], [ %r138.1.relocated315, %anyeq.slow.357 ], [ %.01103, %anyeq.false.359 ]
  %.141068 = phi ptr addrspace(1) [ %.131067, %anyeq.true.358 ], [ %rs4gc.s20.relocated314, %anyeq.slow.357 ], [ %.131067, %anyeq.false.359 ]
  %.141043 = phi ptr addrspace(1) [ %.131042, %anyeq.true.358 ], [ %r131.0.relocated318, %anyeq.slow.357 ], [ %.131042, %anyeq.false.359 ]
  %.141018 = phi ptr addrspace(1) [ %.131017, %anyeq.true.358 ], [ %r131.0.base.relocated317, %anyeq.slow.357 ], [ %.131017, %anyeq.false.359 ]
  %.15 = phi ptr addrspace(1) [ %.14, %anyeq.true.358 ], [ %rs4gc.s15.relocated316, %anyeq.slow.357 ], [ %.14, %anyeq.false.359 ]
  %r1927 = phi i64 [ 9222246136947933188, %anyeq.true.358 ], [ 9222246136947933187, %anyeq.false.359 ], [ %r1926313, %anyeq.slow.357 ]
  %r1928 = bitcast i64 %r1927 to double
  %r1929 = icmp eq i64 %r1927, 9222246136947933188
  %r1930 = xor i1 %r1929, true
  %r1931 = select i1 %r1930, i64 9222246136947933188, i64 9222246136947933187
  %r1932 = bitcast i64 %r1931 to double
  %r1933 = icmp eq i64 %r1931, 9222246136947933188
  br i1 %r1933, label %if.then.363, label %if.else.364

anyeq.num.361:                                    ; preds = %anyeq.diff.356
  %r1916 = fcmp oeq double %r1899, %r1900
  br i1 %r1916, label %anyeq.true.358, label %anyeq.false.359

anyeq.tag.362:                                    ; preds = %anyeq.diff.356
  %r1917 = lshr i64 %r1901, 48
  %r1918 = lshr i64 %r1902, 48
  %r1919 = icmp eq i64 %r1917, 32761
  %r1920 = icmp eq i64 %r1918, 32761
  %r1921 = and i1 %r1919, %r1920
  %r1922 = icmp eq i64 %r1917, 32766
  %r1923 = icmp eq i64 %r1918, 32766
  %r1924 = and i1 %r1922, %r1923
  %r1925 = or i1 %r1921, %r1924
  br i1 %r1925, label %anyeq.false.359, label %anyeq.slow.357

if.then.363:                                      ; preds = %anyeq.merge.360
  %r1934 = load double, ptr @test_json_tape_batch_records_ts_.str.20.handle, align 8
  %statepoint_token319 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_error_new_from_value, i32 1, i32 0, double %r1934, i32 0, i32 0)
  %r1935320 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token319)
  %r1936 = or i64 %r1935320, 9222527611924643840
  %r1937 = bitcast i64 %r1936 to double
  %statepoint_token321 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r1937, i32 0, i32 0)
  unreachable

if.else.364:                                      ; preds = %anyeq.merge.360
  br label %if.merge.365

if.merge.365:                                     ; preds = %if.else.364
  %r1938.rs4i = ptrtoint ptr addrspace(1) %.141068 to i64
  %r1938.rs4o = call i64 asm "", "=r,0"(i64 %r1938.rs4i) #7
  %r1938 = bitcast i64 %r1938.rs4o to double
  %r1939 = bitcast double %r1938 to i64
  %r1940 = and i64 %r1939, 281474976710655
  %r1941 = and i64 %r1939, -281474976710656
  %r1942 = icmp eq i64 %r1941, 9222527611924643840
  %r1943 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r1944 = icmp eq i64 %r1943, 0
  %r1945 = icmp ugt i64 %r1940, 1048575
  %r1946 = icmp ult i64 %r1940, 140737488355328
  %r1947 = and i1 %r1945, %r1946
  %r1948 = and i1 %r1942, %r1944
  %r1949 = and i1 %r1948, %r1947
  br i1 %r1949, label %tav.get.brand.370, label %tav.get.slow.368

tav.get.fast.366:                                 ; preds = %tav.get.brand.370
  %r1966 = bitcast double %r1938 to i64
  %r1967 = and i64 %r1966, 281474976710655
  %r1968 = add nuw nsw i64 %r1967, 8
  %r1969 = inttoptr i64 %r1968 to ptr
  %r1970 = load i8, ptr %r1969, align 1
  %r1971 = zext i8 %r1970 to i64
  %r1975 = inttoptr i64 %r1967 to ptr
  %r1976 = load i32, ptr %r1975, align 4
  %r1977 = zext i32 %r1976 to i64
  %r1978 = icmp ult i64 0, %r1977
  %r1979 = and i1 true, %r1978
  br i1 %r1979, label %tav.get.load.367, label %tav.get.slow.368

tav.get.load.367:                                 ; preds = %tav.get.fast.366
  %r1980 = add nuw nsw i64 %r1967, 16
  %r1981 = icmp eq i64 %r1971, 0
  br i1 %r1981, label %tav.k.i8.371, label %tav.kd1.379

tav.get.slow.368:                                 ; preds = %tav.get.brand.370, %tav.get.fast.366, %if.merge.365
  %r2032 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__14, align 8
  %r2033 = icmp ne ptr %r2032, null
  %r2034 = select i1 %r2033, ptr %r2032, ptr @perry_ic_test_json_tape_batch_records_ts__14
  %r2035 = bitcast double %r1938 to i64
  %r2036 = and i64 %r2035, 281474976710655
  %r2037 = and i64 %r2035, -281474976710656
  %r2038 = icmp eq i64 %r2037, 9222527611924643840
  %r2039 = icmp uge i64 %r2036, 2199023255552
  %r2040 = icmp ult i64 %r2036, 140737488355328
  %r2043 = and i1 %r2038, %r2039
  %r2044 = and i1 %r2043, %r2040
  br i1 %r2044, label %arrlike.ic.header.386, label %arrlike.ic.miss.405

tav.get.merge.369:                                ; preds = %arrlike.elem.value.411, %arrlike.ic.miss.405, %arrlike.ic.spill_load.404, %arrlike.ic.inline.401, %arrlike.ic.array_load.389, %tav.k.f64.378, %tav.k.f32.377, %tav.k.u32.376, %tav.k.i32.375, %tav.k.u16.374, %tav.k.i16.373, %tav.k.u8.372, %tav.k.i8.371
  %.21105 = phi ptr addrspace(1) [ %.11104, %tav.k.i8.371 ], [ %.11104, %tav.k.u8.372 ], [ %.11104, %tav.k.i16.373 ], [ %.11104, %tav.k.u16.374 ], [ %.11104, %tav.k.i32.375 ], [ %.11104, %tav.k.u32.376 ], [ %.11104, %tav.k.f32.377 ], [ %.11104, %tav.k.f64.378 ], [ %.11104, %arrlike.ic.array_load.389 ], [ %r138.1.relocated325, %arrlike.ic.miss.405 ], [ %.11104, %arrlike.elem.value.411 ], [ %.11104, %arrlike.ic.inline.401 ], [ %.11104, %arrlike.ic.spill_load.404 ]
  %.151069 = phi ptr addrspace(1) [ %.141068, %tav.k.i8.371 ], [ %.141068, %tav.k.u8.372 ], [ %.141068, %tav.k.i16.373 ], [ %.141068, %tav.k.u16.374 ], [ %.141068, %tav.k.i32.375 ], [ %.141068, %tav.k.u32.376 ], [ %.141068, %tav.k.f32.377 ], [ %.141068, %tav.k.f64.378 ], [ %.141068, %arrlike.ic.array_load.389 ], [ %rs4gc.s20.relocated324, %arrlike.ic.miss.405 ], [ %.141068, %arrlike.elem.value.411 ], [ %.141068, %arrlike.ic.inline.401 ], [ %.141068, %arrlike.ic.spill_load.404 ]
  %.151044 = phi ptr addrspace(1) [ %.141043, %tav.k.i8.371 ], [ %.141043, %tav.k.u8.372 ], [ %.141043, %tav.k.i16.373 ], [ %.141043, %tav.k.u16.374 ], [ %.141043, %tav.k.i32.375 ], [ %.141043, %tav.k.u32.376 ], [ %.141043, %tav.k.f32.377 ], [ %.141043, %tav.k.f64.378 ], [ %.141043, %arrlike.ic.array_load.389 ], [ %r131.0.relocated328, %arrlike.ic.miss.405 ], [ %.141043, %arrlike.elem.value.411 ], [ %.141043, %arrlike.ic.inline.401 ], [ %.141043, %arrlike.ic.spill_load.404 ]
  %.151019 = phi ptr addrspace(1) [ %.141018, %tav.k.i8.371 ], [ %.141018, %tav.k.u8.372 ], [ %.141018, %tav.k.i16.373 ], [ %.141018, %tav.k.u16.374 ], [ %.141018, %tav.k.i32.375 ], [ %.141018, %tav.k.u32.376 ], [ %.141018, %tav.k.f32.377 ], [ %.141018, %tav.k.f64.378 ], [ %.141018, %arrlike.ic.array_load.389 ], [ %r131.0.base.relocated327, %arrlike.ic.miss.405 ], [ %.141018, %arrlike.elem.value.411 ], [ %.141018, %arrlike.ic.inline.401 ], [ %.141018, %arrlike.ic.spill_load.404 ]
  %.16 = phi ptr addrspace(1) [ %.15, %tav.k.i8.371 ], [ %.15, %tav.k.u8.372 ], [ %.15, %tav.k.i16.373 ], [ %.15, %tav.k.u16.374 ], [ %.15, %tav.k.i32.375 ], [ %.15, %tav.k.u32.376 ], [ %.15, %tav.k.f32.377 ], [ %.15, %tav.k.f64.378 ], [ %.15, %arrlike.ic.array_load.389 ], [ %rs4gc.s15.relocated326, %arrlike.ic.miss.405 ], [ %.15, %arrlike.elem.value.411 ], [ %.15, %arrlike.ic.inline.401 ], [ %.15, %arrlike.ic.spill_load.404 ]
  %r2205 = phi double [ %r1994, %tav.k.i8.371 ], [ %r2000, %tav.k.u8.372 ], [ %r2006, %tav.k.i16.373 ], [ %r2012, %tav.k.u16.374 ], [ %r2017, %tav.k.i32.375 ], [ %r2022, %tav.k.u32.376 ], [ %r2027, %tav.k.f32.377 ], [ %r2031, %tav.k.f64.378 ], [ %r2088, %arrlike.elem.value.411 ], [ %r2116, %arrlike.ic.array_load.389 ], [ %r2186, %arrlike.ic.inline.401 ], [ %r2203, %arrlike.ic.spill_load.404 ], [ %r2204323, %arrlike.ic.miss.405 ]
  %r2206 = bitcast double %r2205 to i64
  %r2207 = and i64 %r2206, 281474976710655
  %r2208 = lshr i64 %r2206, 48
  %r2209 = and i64 %r2208, 65533
  %r2210 = icmp eq i64 %r2209, 32765
  br i1 %r2210, label %pget.recv_ok.414, label %pget.recv_other.418

tav.get.brand.370:                                ; preds = %if.merge.365
  %r1950 = bitcast double %r1938 to i64
  %r1951 = and i64 %r1950, 281474976710655
  %r1952 = sub nsw i64 %r1951, 8
  %r1953 = inttoptr i64 %r1952 to ptr
  %r1954 = load i8, ptr %r1953, align 1
  %r1955 = icmp eq i8 %r1954, 11
  %r1956 = add nuw nsw i64 %r1951, 8
  %r1957 = inttoptr i64 %r1956 to ptr
  %r1958 = load i8, ptr %r1957, align 1
  %r1959 = zext i8 %r1958 to i64
  %r1960 = icmp ule i64 %r1959, 8
  %r1963 = and i1 %r1955, %r1960
  br i1 %r1963, label %tav.get.fast.366, label %tav.get.slow.368

tav.k.i8.371:                                     ; preds = %tav.get.load.367
  %r1990 = add nuw nsw i64 %r1980, 0
  %r1991 = inttoptr i64 %r1990 to ptr
  %r1992 = load i8, ptr %r1991, align 1
  %r1993 = sext i8 %r1992 to i32
  %r1994 = sitofp i32 %r1993 to double
  br label %tav.get.merge.369

tav.k.u8.372:                                     ; preds = %tav.kd7.385, %tav.kd1.379
  %r1996 = add nuw nsw i64 %r1980, 0
  %r1997 = inttoptr i64 %r1996 to ptr
  %r1998 = load i8, ptr %r1997, align 1
  %r1999 = zext i8 %r1998 to i32
  %r2000 = uitofp nneg i32 %r1999 to double
  br label %tav.get.merge.369

tav.k.i16.373:                                    ; preds = %tav.kd2.380
  %r2002 = add nuw nsw i64 %r1980, 0
  %r2003 = inttoptr i64 %r2002 to ptr
  %r2004 = load i16, ptr %r2003, align 2
  %r2005 = sext i16 %r2004 to i32
  %r2006 = sitofp i32 %r2005 to double
  br label %tav.get.merge.369

tav.k.u16.374:                                    ; preds = %tav.kd3.381
  %r2008 = add nuw nsw i64 %r1980, 0
  %r2009 = inttoptr i64 %r2008 to ptr
  %r2010 = load i16, ptr %r2009, align 2
  %r2011 = zext i16 %r2010 to i32
  %r2012 = uitofp nneg i32 %r2011 to double
  br label %tav.get.merge.369

tav.k.i32.375:                                    ; preds = %tav.kd4.382
  %r2014 = add nuw nsw i64 %r1980, 0
  %r2015 = inttoptr i64 %r2014 to ptr
  %r2016 = load i32, ptr %r2015, align 4
  %r2017 = sitofp i32 %r2016 to double
  br label %tav.get.merge.369

tav.k.u32.376:                                    ; preds = %tav.kd5.383
  %r2019 = add nuw nsw i64 %r1980, 0
  %r2020 = inttoptr i64 %r2019 to ptr
  %r2021 = load i32, ptr %r2020, align 4
  %r2022 = uitofp i32 %r2021 to double
  br label %tav.get.merge.369

tav.k.f32.377:                                    ; preds = %tav.kd6.384
  %r2024 = add nuw nsw i64 %r1980, 0
  %r2025 = inttoptr i64 %r2024 to ptr
  %r2026 = load float, ptr %r2025, align 4
  %r2027 = fpext float %r2026 to double
  br label %tav.get.merge.369

tav.k.f64.378:                                    ; preds = %tav.kd7.385
  %r2029 = add nuw nsw i64 %r1980, 0
  %r2030 = inttoptr i64 %r2029 to ptr
  %r2031 = load double, ptr %r2030, align 8
  br label %tav.get.merge.369

tav.kd1.379:                                      ; preds = %tav.get.load.367
  %r1982 = icmp eq i64 %r1971, 1
  br i1 %r1982, label %tav.k.u8.372, label %tav.kd2.380

tav.kd2.380:                                      ; preds = %tav.kd1.379
  %r1983 = icmp eq i64 %r1971, 2
  br i1 %r1983, label %tav.k.i16.373, label %tav.kd3.381

tav.kd3.381:                                      ; preds = %tav.kd2.380
  %r1984 = icmp eq i64 %r1971, 3
  br i1 %r1984, label %tav.k.u16.374, label %tav.kd4.382

tav.kd4.382:                                      ; preds = %tav.kd3.381
  %r1985 = icmp eq i64 %r1971, 4
  br i1 %r1985, label %tav.k.i32.375, label %tav.kd5.383

tav.kd5.383:                                      ; preds = %tav.kd4.382
  %r1986 = icmp eq i64 %r1971, 5
  br i1 %r1986, label %tav.k.u32.376, label %tav.kd6.384

tav.kd6.384:                                      ; preds = %tav.kd5.383
  %r1987 = icmp eq i64 %r1971, 6
  br i1 %r1987, label %tav.k.f32.377, label %tav.kd7.385

tav.kd7.385:                                      ; preds = %tav.kd6.384
  %r1988 = icmp eq i64 %r1971, 7
  br i1 %r1988, label %tav.k.f64.378, label %tav.k.u8.372

arrlike.ic.header.386:                            ; preds = %tav.get.slow.368
  %r2050 = sub nuw nsw i64 %r2036, 8
  %r2051 = inttoptr i64 %r2050 to ptr
  %r2052 = load i8, ptr %r2051, align 1
  %r2054 = sub nuw nsw i64 %r2036, 7
  %r2055 = inttoptr i64 %r2054 to ptr
  %r2056 = load i8, ptr %r2055, align 1
  %r2057 = and i8 %r2056, -128
  %r2058 = icmp eq i8 %r2057, 0
  %r2059 = and i1 true, %r2058
  br i1 %r2059, label %arrlike.ic.brand.387, label %arrlike.ic.miss.405

arrlike.ic.brand.387:                             ; preds = %arrlike.ic.header.386
  %r2053 = icmp eq i8 %r2052, 1
  br i1 %r2053, label %arrlike.ic.array_guard.388, label %arrlike.elem.kind.406

arrlike.ic.array_guard.388:                       ; preds = %arrlike.ic.brand.387
  %r2091 = sub nuw nsw i64 %r2036, 6
  %r2092 = inttoptr i64 %r2091 to ptr
  %r2093 = load i16, ptr %r2092, align 2
  %r2094 = and i16 %r2093, 1024
  %r2095 = icmp eq i16 %r2094, 0
  %r2096 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2097 = icmp eq i8 %r2096, 0
  %r2098 = inttoptr i64 %r2036 to ptr
  %r2099 = load i32, ptr %r2098, align 4
  %r2100 = add nuw nsw i64 %r2036, 4
  %r2101 = inttoptr i64 %r2100 to ptr
  %r2102 = load i32, ptr %r2101, align 4
  %r2103 = zext i32 %r2099 to i64
  %r2104 = zext i32 %r2102 to i64
  %r2105 = icmp ult i64 0, %r2103
  %r2106 = icmp ule i64 %r2103, %r2104
  %r2107 = and i1 %r2095, %r2097
  %r2108 = and i1 %r2107, %r2105
  %r2109 = and i1 %r2108, %r2106
  br i1 %r2109, label %arrlike.ic.array_load.389, label %arrlike.ic.miss.405

arrlike.ic.array_load.389:                        ; preds = %arrlike.ic.array_guard.388
  %r2111 = getelementptr inbounds nuw i64, ptr %r2098, i64 1
  %r2112 = load double, ptr %r2111, align 8
  %r2113 = bitcast double %r2112 to i64
  %r2114 = icmp eq i64 %r2113, 9222246136947933200
  %r2116 = select i1 %r2114, double 0x7FFC000000000001, double %r2112
  br label %tav.get.merge.369

arrlike.ic.shape.390:                             ; preds = %arrlike.elem.store.408, %arrlike.elem.meta.407
  %r2118 = inttoptr i64 %r2036 to ptr
  %r2119 = load i32, ptr %r2118, align 4
  %r2120 = add nuw nsw i64 %r2036, 4
  %r2121 = inttoptr i64 %r2120 to ptr
  %r2122 = load i32, ptr %r2121, align 4
  %r2123 = zext i32 %r2119 to i64
  %r2124 = zext i32 %r2122 to i64
  %r2125 = shl nuw i64 %r2123, 32
  %r2126 = or i64 %r2125, %r2124
  %r2127 = getelementptr i64, ptr %r2034, i64 0
  %r2128 = load i64, ptr %r2127, align 8
  %r2129 = icmp ne i64 %r2128, 0
  %r2130 = and i1 true, %r2129
  br i1 %r2130, label %arrlike.ic.identity.391, label %arrlike.ic.miss.405

arrlike.ic.identity.391:                          ; preds = %arrlike.ic.shape.390
  %r2131 = and i64 %r2128, -9223372036854775808
  %3 = icmp slt i64 %r2128, 0
  br i1 %3, label %arrlike.ic.family_meta.393, label %arrlike.ic.exact.392

arrlike.ic.exact.392:                             ; preds = %arrlike.ic.identity.391
  %r2133 = icmp eq i64 %r2126, %r2128
  br i1 %r2133, label %arrlike.ic.bounds.395, label %arrlike.ic.miss.405

arrlike.ic.family_meta.393:                       ; preds = %arrlike.ic.identity.391
  %r2134 = add nuw nsw i64 %r2036, 8
  %r2135 = inttoptr i64 %r2134 to ptr
  %r2136 = load i64, ptr %r2135, align 8
  %r2137 = icmp ne i64 %r2136, 0
  br i1 %r2137, label %arrlike.ic.family_token.394, label %arrlike.ic.miss.405

arrlike.ic.family_token.394:                      ; preds = %arrlike.ic.family_meta.393
  %r2138 = inttoptr i64 %r2136 to ptr
  %r2139 = getelementptr i64, ptr %r2138, i64 6
  %r2140 = load i64, ptr %r2139, align 8
  %r2141 = icmp eq i64 %r2140, %r2128
  br i1 %r2141, label %arrlike.ic.bounds.395, label %arrlike.ic.miss.405

arrlike.ic.bounds.395:                            ; preds = %arrlike.ic.family_token.394, %arrlike.ic.exact.392
  %r2142 = getelementptr i64, ptr %r2032, i64 1
  %r2143 = load i64, ptr %r2142, align 8
  %r2144 = getelementptr i64, ptr %r2032, i64 2
  %r2145 = load i64, ptr %r2144, align 8
  %r2146 = getelementptr i64, ptr %r2032, i64 3
  %r2147 = load i64, ptr %r2146, align 8
  %r2148 = getelementptr i64, ptr %r2032, i64 4
  %r2149 = load i64, ptr %r2148, align 8
  %r2150 = icmp ult i64 %r2143, %r2149
  br i1 %r2150, label %arrlike.ic.length_inline.396, label %arrlike.ic.length_spill_meta.397

arrlike.ic.length_inline.396:                     ; preds = %arrlike.ic.bounds.395
  %r2151 = shl i64 %r2143, 3
  %r2152 = add i64 %r2151, 16
  %r2153 = add i64 %r2036, %r2152
  %r2154 = inttoptr i64 %r2153 to ptr
  %r2155 = load double, ptr %r2154, align 8
  br label %arrlike.ic.range.400

arrlike.ic.length_spill_meta.397:                 ; preds = %arrlike.ic.bounds.395
  %r2156 = add nuw nsw i64 %r2036, 8
  %r2157 = inttoptr i64 %r2156 to ptr
  %r2158 = load i64, ptr %r2157, align 8
  %r2159 = icmp ne i64 %r2158, 0
  br i1 %r2159, label %arrlike.ic.length_spill_ptr.398, label %arrlike.ic.miss.405

arrlike.ic.length_spill_ptr.398:                  ; preds = %arrlike.ic.length_spill_meta.397
  %r2160 = inttoptr i64 %r2158 to ptr
  %r2161 = getelementptr i64, ptr %r2160, i64 4
  %r2162 = load i64, ptr %r2161, align 8
  %r2163 = icmp ne i64 %r2162, 0
  %r2164 = select i1 %r2163, i64 %r2162, i64 %r2158
  %r2165 = inttoptr i64 %r2164 to ptr
  %r2166 = load i32, ptr %r2165, align 4
  %r2167 = zext i32 %r2166 to i64
  %r2168 = icmp ult i64 %r2143, %r2167
  %r2169 = and i1 %r2163, %r2168
  br i1 %r2169, label %arrlike.ic.length_spill_load.399, label %arrlike.ic.miss.405

arrlike.ic.length_spill_load.399:                 ; preds = %arrlike.ic.length_spill_ptr.398
  %r2170 = add nuw nsw i64 %r2143, 1
  %r2171 = getelementptr inbounds nuw i64, ptr %r2165, i64 %r2170
  %r2172 = load double, ptr %r2171, align 8
  br label %arrlike.ic.range.400

arrlike.ic.range.400:                             ; preds = %arrlike.ic.length_spill_load.399, %arrlike.ic.length_inline.396
  %r2173 = phi double [ %r2155, %arrlike.ic.length_inline.396 ], [ %r2172, %arrlike.ic.length_spill_load.399 ]
  %r2174 = fcmp olt double 0.000000e+00, %r2173
  %r2175 = icmp ult i64 0, %r2147
  %r2176 = and i1 %r2174, %r2175
  %r2177 = add nuw nsw i64 %r2145, 0
  %r2178 = icmp ult i64 %r2177, %r2149
  %r2179 = and i1 %r2176, %r2178
  %r2180 = xor i1 %r2178, true
  %r2181 = and i1 %r2176, %r2180
  br i1 %r2179, label %arrlike.ic.inline.401, label %arrlike.ic.spill_or_miss.412

arrlike.ic.inline.401:                            ; preds = %arrlike.ic.range.400
  %r2182 = shl i64 %r2177, 3
  %r2183 = add i64 %r2182, 16
  %r2184 = add i64 %r2036, %r2183
  %r2185 = inttoptr i64 %r2184 to ptr
  %r2186 = load double, ptr %r2185, align 8
  br label %tav.get.merge.369

arrlike.ic.spill.402:                             ; preds = %arrlike.ic.spill_or_miss.412
  %r2187 = add nuw nsw i64 %r2036, 8
  %r2188 = inttoptr i64 %r2187 to ptr
  %r2189 = load i64, ptr %r2188, align 8
  %r2190 = icmp ne i64 %r2189, 0
  br i1 %r2190, label %arrlike.ic.spill_ptr.403, label %arrlike.ic.miss.405

arrlike.ic.spill_ptr.403:                         ; preds = %arrlike.ic.spill.402
  %r2191 = inttoptr i64 %r2189 to ptr
  %r2192 = getelementptr i64, ptr %r2191, i64 4
  %r2193 = load i64, ptr %r2192, align 8
  %r2194 = icmp ne i64 %r2193, 0
  %r2195 = select i1 %r2194, i64 %r2193, i64 %r2189
  %r2196 = inttoptr i64 %r2195 to ptr
  %r2197 = load i32, ptr %r2196, align 4
  %r2198 = zext i32 %r2197 to i64
  %r2199 = icmp ult i64 %r2177, %r2198
  %r2200 = and i1 %r2194, %r2199
  br i1 %r2200, label %arrlike.ic.spill_load.404, label %arrlike.ic.miss.405

arrlike.ic.spill_load.404:                        ; preds = %arrlike.ic.spill_ptr.403
  %r2201 = add nuw nsw i64 %r2177, 1
  %r2202 = getelementptr inbounds nuw i64, ptr %r2196, i64 %r2201
  %r2203 = load double, ptr %r2202, align 8
  br label %tav.get.merge.369

arrlike.ic.miss.405:                              ; preds = %arrlike.ic.spill_or_miss.412, %arrlike.elem.load.410, %arrlike.elem.bounds.409, %arrlike.elem.kind.406, %arrlike.ic.spill_ptr.403, %arrlike.ic.spill.402, %arrlike.ic.length_spill_ptr.398, %arrlike.ic.length_spill_meta.397, %arrlike.ic.family_token.394, %arrlike.ic.family_meta.393, %arrlike.ic.exact.392, %arrlike.ic.shape.390, %arrlike.ic.array_guard.388, %arrlike.ic.header.386, %tav.get.slow.368
  %statepoint_token322 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, ptr)) @js_packed_arraylike_index_get, i32 3, i32 0, double %r1938, double 0.000000e+00, ptr @perry_ic_test_json_tape_batch_records_ts__14, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.141068, ptr addrspace(1) %.11104, ptr addrspace(1) %.15, ptr addrspace(1) %.141018, ptr addrspace(1) %.141043) ]
  %r2204323 = call double @llvm.experimental.gc.result.f64(token %statepoint_token322)
  %rs4gc.s20.relocated324 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token322, i32 0, i32 0) ; (%.141068, %.141068)
  %r138.1.relocated325 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token322, i32 1, i32 1) ; (%.11104, %.11104)
  %rs4gc.s15.relocated326 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token322, i32 2, i32 2) ; (%.15, %.15)
  %r131.0.base.relocated327 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token322, i32 3, i32 3) ; (%.141018, %.141018)
  %r131.0.relocated328 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token322, i32 3, i32 4) ; (%.141018, %.141043)
  br label %tav.get.merge.369

arrlike.elem.kind.406:                            ; preds = %arrlike.ic.brand.387
  %r2060 = icmp eq i8 %r2052, 2
  br i1 %r2060, label %arrlike.elem.meta.407, label %arrlike.ic.miss.405

arrlike.elem.meta.407:                            ; preds = %arrlike.elem.kind.406
  %r2061 = add nuw nsw i64 %r2036, 8
  %r2062 = inttoptr i64 %r2061 to ptr
  %r2063 = load i64, ptr %r2062, align 8
  %r2064 = icmp ne i64 %r2063, 0
  br i1 %r2064, label %arrlike.elem.store.408, label %arrlike.ic.shape.390

arrlike.elem.store.408:                           ; preds = %arrlike.elem.meta.407
  %r2065 = inttoptr i64 %r2063 to ptr
  %r2066 = getelementptr i64, ptr %r2065, i64 12
  %r2067 = load i64, ptr %r2066, align 8
  %r2068 = icmp ne i64 %r2067, 0
  br i1 %r2068, label %arrlike.elem.bounds.409, label %arrlike.ic.shape.390

arrlike.elem.bounds.409:                          ; preds = %arrlike.elem.store.408
  %r2069 = sub i64 %r2067, 8
  %r2070 = inttoptr i64 %r2069 to ptr
  %r2071 = load i8, ptr %r2070, align 1
  %r2072 = icmp eq i8 %r2071, 1
  %r2073 = sub i64 %r2067, 7
  %r2074 = inttoptr i64 %r2073 to ptr
  %r2075 = load i8, ptr %r2074, align 1
  %r2076 = and i8 %r2075, -128
  %r2077 = icmp eq i8 %r2076, 0
  %r2078 = inttoptr i64 %r2067 to ptr
  %r2079 = load i32, ptr %r2078, align 4
  %r2080 = zext i32 %r2079 to i64
  %r2081 = icmp ult i64 0, %r2080
  %r2082 = and i1 %r2072, %r2077
  %r2083 = and i1 %r2082, %r2081
  br i1 %r2083, label %arrlike.elem.load.410, label %arrlike.ic.miss.405

arrlike.elem.load.410:                            ; preds = %arrlike.elem.bounds.409
  %r2085 = add i64 %r2067, 8
  %r2086 = add nuw nsw i64 %r2085, 0
  %r2087 = inttoptr i64 %r2086 to ptr
  %r2088 = load double, ptr %r2087, align 8
  %r2089 = bitcast double %r2088 to i64
  %r2090 = icmp eq i64 %r2089, 9222246136947933200
  br i1 %r2090, label %arrlike.ic.miss.405, label %arrlike.elem.value.411

arrlike.elem.value.411:                           ; preds = %arrlike.elem.load.410
  br label %tav.get.merge.369

arrlike.ic.spill_or_miss.412:                     ; preds = %arrlike.ic.range.400
  br i1 %r2181, label %arrlike.ic.spill.402, label %arrlike.ic.miss.405

pget.recv_sso.413:                                ; preds = %pget.recv_other.418
  %r2348 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r2349 = bitcast double %r2348 to i64
  %r2350 = and i64 %r2349, 281474976710655
  %statepoint_token329 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2206, i64 %r2350, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.151069, ptr addrspace(1) %.21105, ptr addrspace(1) %.16, ptr addrspace(1) %.151019, ptr addrspace(1) %.151044) ]
  %r2351330 = call double @llvm.experimental.gc.result.f64(token %statepoint_token329)
  %rs4gc.s20.relocated331 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 0, i32 0) ; (%.151069, %.151069)
  %r138.1.relocated332 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 1, i32 1) ; (%.21105, %.21105)
  %rs4gc.s15.relocated333 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 2, i32 2) ; (%.16, %.16)
  %r131.0.base.relocated334 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 3, i32 3) ; (%.151019, %.151019)
  %r131.0.relocated335 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 3, i32 4) ; (%.151019, %.151044)
  br label %pget.recv_merge.417

pget.recv_ok.414:                                 ; preds = %tav.get.merge.369
  %r2217 = icmp ugt i64 %r2207, 1048575
  br i1 %r2217, label %pic.recv_hdr.435, label %pic.miss.cold.432

pget.recv_bad.415:                                ; preds = %pget.check_class_ref.419
  %r2340 = icmp eq i64 %r2206, 9222246136947933185
  %r2341 = icmp eq i64 %r2206, 9222246136947933186
  %r2342 = or i1 %r2340, %r2341
  br i1 %r2342, label %pget.throw_nullish.442, label %pget.recv_undef_return.443

pget.recv_class_ref.416:                          ; preds = %pget.check_class_ref.419
  %r2213 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r2214 = bitcast double %r2213 to i64
  %r2215 = and i64 %r2214, 281474976710655
  %statepoint_token336 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 367713371643969551, i64 %r2206, i64 %r2215, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.151069, ptr addrspace(1) %.21105, ptr addrspace(1) %.16, ptr addrspace(1) %.151019, ptr addrspace(1) %.151044) ]
  %r2216337 = call double @llvm.experimental.gc.result.f64(token %statepoint_token336)
  %rs4gc.s20.relocated338 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token336, i32 0, i32 0) ; (%.151069, %.151069)
  %r138.1.relocated339 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token336, i32 1, i32 1) ; (%.21105, %.21105)
  %rs4gc.s15.relocated340 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token336, i32 2, i32 2) ; (%.16, %.16)
  %r131.0.base.relocated341 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token336, i32 3, i32 3) ; (%.151019, %.151019)
  %r131.0.relocated342 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token336, i32 3, i32 4) ; (%.151019, %.151044)
  br label %pget.recv_merge.417

pget.recv_merge.417:                              ; preds = %pget.recv_undef_return.443, %pic.merge.434, %pget.recv_class_ref.416, %pget.recv_sso.413
  %.31106 = phi ptr addrspace(1) [ %.41107, %pic.merge.434 ], [ %r138.1.relocated332, %pget.recv_sso.413 ], [ %r138.1.relocated339, %pget.recv_class_ref.416 ], [ %r138.1.relocated361, %pget.recv_undef_return.443 ]
  %.161070 = phi ptr addrspace(1) [ %.171071, %pic.merge.434 ], [ %rs4gc.s20.relocated331, %pget.recv_sso.413 ], [ %rs4gc.s20.relocated338, %pget.recv_class_ref.416 ], [ %rs4gc.s20.relocated360, %pget.recv_undef_return.443 ]
  %.161045 = phi ptr addrspace(1) [ %.171046, %pic.merge.434 ], [ %r131.0.relocated335, %pget.recv_sso.413 ], [ %r131.0.relocated342, %pget.recv_class_ref.416 ], [ %r131.0.relocated364, %pget.recv_undef_return.443 ]
  %.161020 = phi ptr addrspace(1) [ %.171021, %pic.merge.434 ], [ %r131.0.base.relocated334, %pget.recv_sso.413 ], [ %r131.0.base.relocated341, %pget.recv_class_ref.416 ], [ %r131.0.base.relocated363, %pget.recv_undef_return.443 ]
  %.17 = phi ptr addrspace(1) [ %.18, %pic.merge.434 ], [ %rs4gc.s15.relocated333, %pget.recv_sso.413 ], [ %rs4gc.s15.relocated340, %pget.recv_class_ref.416 ], [ %rs4gc.s15.relocated362, %pget.recv_undef_return.443 ]
  %r2352 = phi double [ %r2339, %pic.merge.434 ], [ %r2347359, %pget.recv_undef_return.443 ], [ %r2351330, %pget.recv_sso.413 ], [ %r2216337, %pget.recv_class_ref.416 ]
  %r2353 = bitcast double %r2352 to i64
  %rs4gc.s27 = inttoptr i64 %r2353 to ptr addrspace(1)
  %r2354.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s27 to i64
  %r2354 = call i64 asm "", "=r,0"(i64 %r2354.rs4i) #7
  %r2355 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2356 = icmp ne i32 %r2355, 0
  br i1 %r2356, label %shadow.root.barrier.444, label %shadow.root.barrier.done.445

pget.recv_other.418:                              ; preds = %tav.get.merge.369
  %r2211 = icmp eq i64 %r2208, 32761
  br i1 %r2211, label %pget.recv_sso.413, label %pget.check_class_ref.419

pget.check_class_ref.419:                         ; preds = %pget.recv_other.418
  %r2212 = icmp eq i64 %r2208, 32766
  br i1 %r2212, label %pget.recv_class_ref.416, label %pget.recv_bad.415

pic.hit.420:                                      ; preds = %pic.token.436
  %r2242 = getelementptr i64, ptr %r2227, i64 1
  %r2243 = load i64, ptr %r2242, align 8
  %r2244 = and i64 %r2243, 1073741824
  %r2245 = icmp ne i64 %r2244, 0
  br i1 %r2245, label %pic.hit.overflow.437, label %pic.hit.inline.438

pic.hit.live.421:                                 ; preds = %pic.hit.inline.438
  br label %pic.merge.434

pic.prefix.guard.422:                             ; preds = %pic.token.436
  %r2258 = getelementptr i64, ptr %r2227, i64 2
  %r2259 = load i64, ptr %r2258, align 8
  %r2260 = icmp ne i64 %r2259, 0
  br i1 %r2260, label %pic.prefix.meta.423, label %pic.miss.431

pic.prefix.meta.423:                              ; preds = %pic.prefix.guard.422
  %r2261 = add nuw nsw i64 %r2207, 8
  %r2262 = inttoptr i64 %r2261 to ptr
  %r2263 = load i64, ptr %r2262, align 8
  %r2264 = icmp ne i64 %r2263, 0
  br i1 %r2264, label %pic.prefix.token.424, label %pic.miss.431

pic.prefix.token.424:                             ; preds = %pic.prefix.meta.423
  %r2265 = inttoptr i64 %r2263 to ptr
  %r2266 = getelementptr i64, ptr %r2265, i64 6
  %r2267 = load i64, ptr %r2266, align 8
  %r2268 = icmp eq i64 %r2267, %r2259
  br i1 %r2268, label %pic.prefix.hit.425, label %pic.miss.431

pic.prefix.hit.425:                               ; preds = %pic.prefix.token.424
  %r2269 = getelementptr i64, ptr %r2227, i64 1
  %r2270 = load i64, ptr %r2269, align 8
  %r2271 = shl i64 %r2270, 3
  %r2272 = add nuw nsw i64 %r2207, 16
  %r2273 = add i64 %r2272, %r2271
  %r2274 = inttoptr i64 %r2273 to ptr
  %r2275 = load double, ptr %r2274, align 8
  br label %pic.merge.434

pic.desc.classify.426:                            ; preds = %pic.recv_hdr.435
  %r2231 = and i1 %r2221, %r2228
  br i1 %r2231, label %pic.desc.prefix.guard.427, label %pic.miss.cold.432

pic.desc.prefix.guard.427:                        ; preds = %pic.desc.classify.426
  %r2276 = getelementptr i64, ptr %r2227, i64 2
  %r2277 = load i64, ptr %r2276, align 8
  %r2278 = icmp ne i64 %r2277, 0
  br i1 %r2278, label %pic.desc.prefix.meta.428, label %pic.miss.cold.432

pic.desc.prefix.meta.428:                         ; preds = %pic.desc.prefix.guard.427
  %r2279 = add nuw nsw i64 %r2207, 8
  %r2280 = inttoptr i64 %r2279 to ptr
  %r2281 = load i64, ptr %r2280, align 8
  %r2282 = icmp ne i64 %r2281, 0
  br i1 %r2282, label %pic.desc.prefix.token.429, label %pic.miss.cold.432

pic.desc.prefix.token.429:                        ; preds = %pic.desc.prefix.meta.428
  %r2283 = inttoptr i64 %r2281 to ptr
  %r2284 = getelementptr i64, ptr %r2283, i64 6
  %r2285 = load i64, ptr %r2284, align 8
  %r2286 = icmp eq i64 %r2285, %r2277
  br i1 %r2286, label %pic.desc.prefix.hit.430, label %pic.miss.cold.432

pic.desc.prefix.hit.430:                          ; preds = %pic.desc.prefix.token.429
  %r2287 = getelementptr i64, ptr %r2227, i64 1
  %r2288 = load i64, ptr %r2287, align 8
  %r2289 = shl i64 %r2288, 3
  %r2290 = add nuw nsw i64 %r2207, 16
  %r2291 = add i64 %r2290, %r2289
  %r2292 = inttoptr i64 %r2291 to ptr
  %r2293 = load double, ptr %r2292, align 8
  br label %pic.merge.434

pic.miss.431:                                     ; preds = %pic.hit.inline.438, %pic.prefix.token.424, %pic.prefix.meta.423, %pic.prefix.guard.422
  %r2294 = getelementptr i64, ptr %r2227, i64 3
  %r2295 = load i64, ptr %r2294, align 8
  %r2296 = icmp sgt i64 %r2295, 0
  br i1 %r2296, label %pic.ways.439, label %pic.miss.call.433

pic.miss.cold.432:                                ; preds = %pic.desc.prefix.token.429, %pic.desc.prefix.meta.428, %pic.desc.prefix.guard.427, %pic.desc.classify.426, %pget.recv_ok.414
  br label %pic.miss.call.433

pic.miss.call.433:                                ; preds = %pic.way.load.440, %pic.ways.439, %pic.miss.cold.432, %pic.miss.431
  %r2335 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r2336 = bitcast double %r2335 to i64
  %r2337 = and i64 %r2336, 281474976710655
  %statepoint_token343 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r2207, i64 %r2337, ptr @perry_ic_test_json_tape_batch_records_ts__16, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.151069, ptr addrspace(1) %.21105, ptr addrspace(1) %.16, ptr addrspace(1) %.151019, ptr addrspace(1) %.151044) ]
  %r2338344 = call double @llvm.experimental.gc.result.f64(token %statepoint_token343)
  %rs4gc.s20.relocated345 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token343, i32 0, i32 0) ; (%.151069, %.151069)
  %r138.1.relocated346 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token343, i32 1, i32 1) ; (%.21105, %.21105)
  %rs4gc.s15.relocated347 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token343, i32 2, i32 2) ; (%.16, %.16)
  %r131.0.base.relocated348 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token343, i32 3, i32 3) ; (%.151019, %.151019)
  %r131.0.relocated349 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token343, i32 3, i32 4) ; (%.151019, %.151044)
  br label %pic.merge.434

pic.merge.434:                                    ; preds = %pic.way.live.441, %pic.hit.overflow.437, %pic.miss.call.433, %pic.desc.prefix.hit.430, %pic.prefix.hit.425, %pic.hit.live.421
  %.41107 = phi ptr addrspace(1) [ %r138.1.relocated353, %pic.hit.overflow.437 ], [ %r138.1.relocated346, %pic.miss.call.433 ], [ %.21105, %pic.way.live.441 ], [ %.21105, %pic.hit.live.421 ], [ %.21105, %pic.prefix.hit.425 ], [ %.21105, %pic.desc.prefix.hit.430 ]
  %.171071 = phi ptr addrspace(1) [ %rs4gc.s20.relocated352, %pic.hit.overflow.437 ], [ %rs4gc.s20.relocated345, %pic.miss.call.433 ], [ %.151069, %pic.way.live.441 ], [ %.151069, %pic.hit.live.421 ], [ %.151069, %pic.prefix.hit.425 ], [ %.151069, %pic.desc.prefix.hit.430 ]
  %.171046 = phi ptr addrspace(1) [ %r131.0.relocated356, %pic.hit.overflow.437 ], [ %r131.0.relocated349, %pic.miss.call.433 ], [ %.151044, %pic.way.live.441 ], [ %.151044, %pic.hit.live.421 ], [ %.151044, %pic.prefix.hit.425 ], [ %.151044, %pic.desc.prefix.hit.430 ]
  %.171021 = phi ptr addrspace(1) [ %r131.0.base.relocated355, %pic.hit.overflow.437 ], [ %r131.0.base.relocated348, %pic.miss.call.433 ], [ %.151019, %pic.way.live.441 ], [ %.151019, %pic.hit.live.421 ], [ %.151019, %pic.prefix.hit.425 ], [ %.151019, %pic.desc.prefix.hit.430 ]
  %.18 = phi ptr addrspace(1) [ %rs4gc.s15.relocated354, %pic.hit.overflow.437 ], [ %rs4gc.s15.relocated347, %pic.miss.call.433 ], [ %.16, %pic.way.live.441 ], [ %.16, %pic.hit.live.421 ], [ %.16, %pic.prefix.hit.425 ], [ %.16, %pic.desc.prefix.hit.430 ]
  %r2339 = phi double [ %r2255, %pic.hit.live.421 ], [ %r2250351, %pic.hit.overflow.437 ], [ %r2275, %pic.prefix.hit.425 ], [ %r2293, %pic.desc.prefix.hit.430 ], [ %r2332, %pic.way.live.441 ], [ %r2338344, %pic.miss.call.433 ]
  br label %pget.recv_merge.417

pic.recv_hdr.435:                                 ; preds = %pget.recv_ok.414
  %r2218 = sub nuw nsw i64 %r2207, 8
  %r2219 = inttoptr i64 %r2218 to ptr
  %r2220 = load i8, ptr %r2219, align 1
  %r2221 = icmp eq i8 %r2220, 2
  %r2222 = sub nuw nsw i64 %r2207, 6
  %r2223 = inttoptr i64 %r2222 to ptr
  %r2224 = load i16, ptr %r2223, align 2
  %r2225 = and i16 %r2224, 2048
  %r2226 = icmp eq i16 %r2225, 0
  %r2227 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__16, align 8
  %r2228 = icmp ne ptr %r2227, null
  %r2229 = and i1 %r2221, %r2226
  %r2230 = and i1 %r2229, %r2228
  br i1 %r2230, label %pic.token.436, label %pic.desc.classify.426

pic.token.436:                                    ; preds = %pic.recv_hdr.435
  %r2232 = add nuw nsw i64 %r2207, 4
  %r2233 = inttoptr i64 %r2232 to ptr
  %r2234 = load i32, ptr %r2233, align 4
  %r2235 = zext i32 %r2234 to i64
  %r2236 = or i64 %r2235, 4611686018427387904
  %r2237 = icmp ne i32 %r2234, 0
  %r2238 = getelementptr i64, ptr %r2227, i64 0
  %r2239 = load i64, ptr %r2238, align 8
  %r2240 = icmp eq i64 %r2236, %r2239
  %r2241 = and i1 %r2240, %r2237
  br i1 %r2241, label %pic.hit.420, label %pic.prefix.guard.422

pic.hit.overflow.437:                             ; preds = %pic.hit.420
  %r2246 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r2247 = bitcast double %r2246 to i64
  %r2248 = and i64 %r2247, 281474976710655
  %r2249 = trunc i64 %r2243 to i32
  %statepoint_token350 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r2207, i64 %r2248, i32 %r2249, ptr @perry_ic_test_json_tape_batch_records_ts__16, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.151069, ptr addrspace(1) %.21105, ptr addrspace(1) %.16, ptr addrspace(1) %.151019, ptr addrspace(1) %.151044) ]
  %r2250351 = call double @llvm.experimental.gc.result.f64(token %statepoint_token350)
  %rs4gc.s20.relocated352 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token350, i32 0, i32 0) ; (%.151069, %.151069)
  %r138.1.relocated353 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token350, i32 1, i32 1) ; (%.21105, %.21105)
  %rs4gc.s15.relocated354 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token350, i32 2, i32 2) ; (%.16, %.16)
  %r131.0.base.relocated355 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token350, i32 3, i32 3) ; (%.151019, %.151019)
  %r131.0.relocated356 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token350, i32 3, i32 4) ; (%.151019, %.151044)
  br label %pic.merge.434

pic.hit.inline.438:                               ; preds = %pic.hit.420
  %r2251 = shl i64 %r2243, 3
  %r2252 = add nuw nsw i64 %r2207, 16
  %r2253 = add i64 %r2252, %r2251
  %r2254 = inttoptr i64 %r2253 to ptr
  %r2255 = load double, ptr %r2254, align 8
  %r2256 = bitcast double %r2255 to i64
  %r2257 = icmp eq i64 %r2256, 9222246136947933200
  br i1 %r2257, label %pic.miss.431, label %pic.hit.live.421

pic.ways.439:                                     ; preds = %pic.miss.431
  %r2297 = getelementptr i64, ptr %r2227, i64 4
  %r2298 = load i64, ptr %r2297, align 8
  %r2299 = icmp eq i64 %r2298, %r2236
  %r2300 = getelementptr i64, ptr %r2227, i64 5
  %r2301 = load i64, ptr %r2300, align 8
  %r2302 = select i1 %r2299, i64 %r2301, i64 0
  %r2303 = getelementptr i64, ptr %r2227, i64 6
  %r2304 = load i64, ptr %r2303, align 8
  %r2305 = icmp eq i64 %r2304, %r2236
  %r2306 = getelementptr i64, ptr %r2227, i64 7
  %r2307 = load i64, ptr %r2306, align 8
  %r2308 = select i1 %r2305, i64 %r2307, i64 0
  %r2309 = getelementptr i64, ptr %r2227, i64 8
  %r2310 = load i64, ptr %r2309, align 8
  %r2311 = icmp eq i64 %r2310, %r2236
  %r2312 = getelementptr i64, ptr %r2227, i64 9
  %r2313 = load i64, ptr %r2312, align 8
  %r2314 = select i1 %r2311, i64 %r2313, i64 0
  %r2315 = getelementptr i64, ptr %r2227, i64 10
  %r2316 = load i64, ptr %r2315, align 8
  %r2317 = icmp eq i64 %r2316, %r2236
  %r2318 = getelementptr i64, ptr %r2227, i64 11
  %r2319 = load i64, ptr %r2318, align 8
  %r2320 = select i1 %r2317, i64 %r2319, i64 0
  %r2321 = or i1 %r2299, %r2305
  %r2322 = select i1 %r2299, i64 %r2302, i64 %r2308
  %r2323 = or i1 %r2311, %r2317
  %r2324 = select i1 %r2311, i64 %r2314, i64 %r2320
  %r2325 = or i1 %r2321, %r2323
  %r2326 = select i1 %r2321, i64 %r2322, i64 %r2324
  %r2327 = and i1 %r2237, %r2325
  br i1 %r2327, label %pic.way.load.440, label %pic.miss.call.433

pic.way.load.440:                                 ; preds = %pic.ways.439
  %r2328 = shl i64 %r2326, 3
  %r2329 = add nuw nsw i64 %r2207, 16
  %r2330 = add i64 %r2329, %r2328
  %r2331 = inttoptr i64 %r2330 to ptr
  %r2332 = load double, ptr %r2331, align 8
  %r2333 = bitcast double %r2332 to i64
  %r2334 = icmp eq i64 %r2333, 9222246136947933200
  br i1 %r2334, label %pic.miss.call.433, label %pic.way.live.441

pic.way.live.441:                                 ; preds = %pic.way.load.440
  br label %pic.merge.434

pget.throw_nullish.442:                           ; preds = %pget.recv_bad.415
  %r2343 = zext i1 %r2341 to i32
  %statepoint_token357 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2343, ptr @test_json_tape_batch_records_ts_.str.13.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.443:                       ; preds = %pget.recv_bad.415
  %r2344 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r2345 = bitcast double %r2344 to i64
  %r2346 = and i64 %r2345, 281474976710655
  %statepoint_token358 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2206, i64 %r2346, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.151069, ptr addrspace(1) %.21105, ptr addrspace(1) %.16, ptr addrspace(1) %.151019, ptr addrspace(1) %.151044) ]
  %r2347359 = call double @llvm.experimental.gc.result.f64(token %statepoint_token358)
  %rs4gc.s20.relocated360 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token358, i32 0, i32 0) ; (%.151069, %.151069)
  %r138.1.relocated361 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token358, i32 1, i32 1) ; (%.21105, %.21105)
  %rs4gc.s15.relocated362 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token358, i32 2, i32 2) ; (%.16, %.16)
  %r131.0.base.relocated363 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token358, i32 3, i32 3) ; (%.151019, %.151019)
  %r131.0.relocated364 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token358, i32 3, i32 4) ; (%.151019, %.151044)
  br label %pget.recv_merge.417

shadow.root.barrier.444:                          ; preds = %pget.recv_merge.417
  call void @js_write_barrier_root_nanbox(i64 %r2354) #7
  br label %shadow.root.barrier.done.445

shadow.root.barrier.done.445:                     ; preds = %shadow.root.barrier.444, %pget.recv_merge.417
  %r2357 = load double, ptr @test_json_tape_batch_records_ts_.str.14.handle, align 8
  %r2359 = sitofp i32 %r139.0 to double
  %r2360 = fcmp oge double %r2359, 0.000000e+00
  %r2361 = fcmp olt double %r2359, 3.200000e+01
  %r2362 = and i1 %r2360, %r2361
  br i1 %r2362, label %csite.chk.446, label %csite.plain.449

csite.chk.446:                                    ; preds = %shadow.root.barrier.done.445
  %r2363 = fptosi double %r2359 to i32
  %r2364 = sitofp i32 %r2363 to double
  %r2365 = fcmp oeq double %r2364, %r2359
  %r2366 = sext i32 %r2363 to i64
  %r2367 = getelementptr [32 x i64], ptr @perry_concat_site_test_json_tape_batch_records_ts__17, i64 0, i64 %r2366
  %r2368 = load i64, ptr %r2367, align 8
  %r2369 = icmp ne i64 %r2368, 0
  %r2370 = and i1 %r2365, %r2369
  br i1 %r2370, label %csite.hit.447, label %csite.fill.448

csite.hit.447:                                    ; preds = %csite.chk.446
  %r2371 = bitcast i64 %r2368 to double
  br label %csite.merge.450

csite.fill.448:                                   ; preds = %csite.chk.446
  %r2372 = bitcast double %r2357 to i64
  %r2373 = and i64 %r2372, 281474976710655
  %statepoint_token365 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, double)) @js_string_concat_site_value, i32 3, i32 0, i64 ptrtoint (ptr @perry_concat_site_test_json_tape_batch_records_ts__17 to i64), i64 %r2373, double %r2359, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.161070, ptr addrspace(1) %.31106, ptr addrspace(1) %.17, ptr addrspace(1) %.161020, ptr addrspace(1) %.161045, ptr addrspace(1) %rs4gc.s27) ]
  %r2375366 = call double @llvm.experimental.gc.result.f64(token %statepoint_token365)
  %rs4gc.s20.relocated367 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token365, i32 0, i32 0) ; (%.161070, %.161070)
  %r138.1.relocated368 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token365, i32 1, i32 1) ; (%.31106, %.31106)
  %rs4gc.s15.relocated369 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token365, i32 2, i32 2) ; (%.17, %.17)
  %r131.0.base.relocated370 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token365, i32 3, i32 3) ; (%.161020, %.161020)
  %r131.0.relocated371 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token365, i32 3, i32 4) ; (%.161020, %.161045)
  %rs4gc.s27.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token365, i32 5, i32 5) ; (%rs4gc.s27, %rs4gc.s27)
  br label %csite.merge.450

csite.plain.449:                                  ; preds = %shadow.root.barrier.done.445
  %r2376 = bitcast double %r2357 to i64
  %r2377 = and i64 %r2376, 281474976710655
  %statepoint_token372 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r2377, double %r2359, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.161070, ptr addrspace(1) %.31106, ptr addrspace(1) %.17, ptr addrspace(1) %.161020, ptr addrspace(1) %.161045, ptr addrspace(1) %rs4gc.s27) ]
  %r2378373 = call double @llvm.experimental.gc.result.f64(token %statepoint_token372)
  %rs4gc.s20.relocated374 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token372, i32 0, i32 0) ; (%.161070, %.161070)
  %r138.1.relocated375 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token372, i32 1, i32 1) ; (%.31106, %.31106)
  %rs4gc.s15.relocated376 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token372, i32 2, i32 2) ; (%.17, %.17)
  %r131.0.base.relocated377 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token372, i32 3, i32 3) ; (%.161020, %.161020)
  %r131.0.relocated378 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token372, i32 3, i32 4) ; (%.161020, %.161045)
  %rs4gc.s27.relocated379 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token372, i32 5, i32 5) ; (%rs4gc.s27, %rs4gc.s27)
  br label %csite.merge.450

csite.merge.450:                                  ; preds = %csite.plain.449, %csite.fill.448, %csite.hit.447
  %.01118 = phi ptr addrspace(1) [ %rs4gc.s27, %csite.hit.447 ], [ %rs4gc.s27.relocated, %csite.fill.448 ], [ %rs4gc.s27.relocated379, %csite.plain.449 ]
  %.51108 = phi ptr addrspace(1) [ %.31106, %csite.hit.447 ], [ %r138.1.relocated368, %csite.fill.448 ], [ %r138.1.relocated375, %csite.plain.449 ]
  %.181072 = phi ptr addrspace(1) [ %.161070, %csite.hit.447 ], [ %rs4gc.s20.relocated367, %csite.fill.448 ], [ %rs4gc.s20.relocated374, %csite.plain.449 ]
  %.181047 = phi ptr addrspace(1) [ %.161045, %csite.hit.447 ], [ %r131.0.relocated371, %csite.fill.448 ], [ %r131.0.relocated378, %csite.plain.449 ]
  %.181022 = phi ptr addrspace(1) [ %.161020, %csite.hit.447 ], [ %r131.0.base.relocated370, %csite.fill.448 ], [ %r131.0.base.relocated377, %csite.plain.449 ]
  %.19 = phi ptr addrspace(1) [ %.17, %csite.hit.447 ], [ %rs4gc.s15.relocated369, %csite.fill.448 ], [ %rs4gc.s15.relocated376, %csite.plain.449 ]
  %r2379 = phi double [ %r2371, %csite.hit.447 ], [ %r2375366, %csite.fill.448 ], [ %r2378373, %csite.plain.449 ]
  %r2380.rs4i = ptrtoint ptr addrspace(1) %.01118 to i64
  %r2380 = call i64 asm "", "=r,0"(i64 %r2380.rs4i) #7
  %r2381 = bitcast i64 %r2380 to double
  %r2382 = bitcast double %r2379 to i64
  %r2383 = icmp eq i64 %r2380, %r2382
  br i1 %r2383, label %streq.true.455, label %streq.tag.451

streq.tag.451:                                    ; preds = %csite.merge.450
  %r2384 = lshr i64 %r2380, 48
  %r2385 = lshr i64 %r2382, 48
  %r2386 = icmp eq i64 %r2384, 32767
  %r2387 = icmp eq i64 %r2385, 32767
  %r2388 = and i1 %r2386, %r2387
  br i1 %r2388, label %streq.heap.452, label %streq.ssochk.453

streq.heap.452:                                   ; preds = %streq.tag.451
  %r2389 = and i64 %r2380, 281474976710655
  %r2390 = and i64 %r2382, 281474976710655
  %r2391 = icmp ugt i64 %r2389, 4095
  %r2392 = icmp ugt i64 %r2390, 4095
  %r2393 = and i1 %r2391, %r2392
  br i1 %r2393, label %streq.heap.valid.458, label %streq.heap.slow.466

streq.ssochk.453:                                 ; preds = %streq.tag.451
  %r2423 = icmp eq i64 %r2384, 32761
  %r2424 = icmp eq i64 %r2385, 32761
  %r2425 = and i1 %r2423, %r2424
  br i1 %r2425, label %streq.false.456, label %streq.boxed.454

streq.boxed.454:                                  ; preds = %streq.ssochk.453
  %statepoint_token380 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r2381, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.181072, ptr addrspace(1) %.51108, ptr addrspace(1) %.19, ptr addrspace(1) %.181022, ptr addrspace(1) %.181047) ]
  %r2426381 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token380)
  %rs4gc.s20.relocated382 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token380, i32 0, i32 0) ; (%.181072, %.181072)
  %r138.1.relocated383 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token380, i32 1, i32 1) ; (%.51108, %.51108)
  %rs4gc.s15.relocated384 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token380, i32 2, i32 2) ; (%.19, %.19)
  %r131.0.base.relocated385 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token380, i32 3, i32 3) ; (%.181022, %.181022)
  %r131.0.relocated386 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token380, i32 3, i32 4) ; (%.181022, %.181047)
  %statepoint_token387 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r2379, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s20.relocated382, ptr addrspace(1) %r138.1.relocated383, ptr addrspace(1) %rs4gc.s15.relocated384, ptr addrspace(1) %r131.0.base.relocated385, ptr addrspace(1) %r131.0.relocated386) ]
  %r2427388 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token387)
  %rs4gc.s20.relocated389 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token387, i32 0, i32 0) ; (%rs4gc.s20.relocated382, %rs4gc.s20.relocated382)
  %r138.1.relocated390 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token387, i32 1, i32 1) ; (%r138.1.relocated383, %r138.1.relocated383)
  %rs4gc.s15.relocated391 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token387, i32 2, i32 2) ; (%rs4gc.s15.relocated384, %rs4gc.s15.relocated384)
  %r131.0.base.relocated392 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token387, i32 3, i32 3) ; (%r131.0.base.relocated385, %r131.0.base.relocated385)
  %r131.0.relocated393 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token387, i32 3, i32 4) ; (%r131.0.base.relocated385, %r131.0.relocated386)
  %statepoint_token394 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r2426381, i64 %r2427388, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s20.relocated389, ptr addrspace(1) %r138.1.relocated390, ptr addrspace(1) %rs4gc.s15.relocated391, ptr addrspace(1) %r131.0.base.relocated392, ptr addrspace(1) %r131.0.relocated393) ]
  %r2428395 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token394)
  %rs4gc.s20.relocated396 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 0, i32 0) ; (%rs4gc.s20.relocated389, %rs4gc.s20.relocated389)
  %r138.1.relocated397 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 1, i32 1) ; (%r138.1.relocated390, %r138.1.relocated390)
  %rs4gc.s15.relocated398 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 2, i32 2) ; (%rs4gc.s15.relocated391, %rs4gc.s15.relocated391)
  %r131.0.base.relocated399 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 3, i32 3) ; (%r131.0.base.relocated392, %r131.0.base.relocated392)
  %r131.0.relocated400 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 3, i32 4) ; (%r131.0.base.relocated392, %r131.0.relocated393)
  br label %streq.merge.457

streq.true.455:                                   ; preds = %streq.heap.middle.byte.465, %streq.heap.two.463, %streq.heap.one.461, %streq.heap.len.459, %csite.merge.450
  br label %streq.merge.457

streq.false.456:                                  ; preds = %streq.heap.middle.byte.465, %streq.heap.last.462, %streq.heap.first.460, %streq.heap.valid.458, %streq.ssochk.453
  br label %streq.merge.457

streq.merge.457:                                  ; preds = %streq.heap.slow.466, %streq.false.456, %streq.true.455, %streq.boxed.454
  %.61109 = phi ptr addrspace(1) [ %.51108, %streq.true.455 ], [ %.51108, %streq.false.456 ], [ %r138.1.relocated404, %streq.heap.slow.466 ], [ %r138.1.relocated397, %streq.boxed.454 ]
  %.191073 = phi ptr addrspace(1) [ %.181072, %streq.true.455 ], [ %.181072, %streq.false.456 ], [ %rs4gc.s20.relocated403, %streq.heap.slow.466 ], [ %rs4gc.s20.relocated396, %streq.boxed.454 ]
  %.191048 = phi ptr addrspace(1) [ %.181047, %streq.true.455 ], [ %.181047, %streq.false.456 ], [ %r131.0.relocated407, %streq.heap.slow.466 ], [ %r131.0.relocated400, %streq.boxed.454 ]
  %.191023 = phi ptr addrspace(1) [ %.181022, %streq.true.455 ], [ %.181022, %streq.false.456 ], [ %r131.0.base.relocated406, %streq.heap.slow.466 ], [ %r131.0.base.relocated399, %streq.boxed.454 ]
  %.20 = phi ptr addrspace(1) [ %.19, %streq.true.455 ], [ %.19, %streq.false.456 ], [ %rs4gc.s15.relocated405, %streq.heap.slow.466 ], [ %rs4gc.s15.relocated398, %streq.boxed.454 ]
  %r2429 = phi i32 [ 1, %streq.true.455 ], [ 0, %streq.false.456 ], [ %r2422402, %streq.heap.slow.466 ], [ %r2428395, %streq.boxed.454 ]
  %r2430 = icmp ne i32 %r2429, 0
  %r2431 = xor i1 %r2430, true
  %r2432 = select i1 %r2431, i64 9222246136947933188, i64 9222246136947933187
  %r2433 = bitcast i64 %r2432 to double
  %r2434 = icmp eq i64 %r2432, 9222246136947933188
  br i1 %r2434, label %if.then.467, label %if.else.468

streq.heap.valid.458:                             ; preds = %streq.heap.452
  %r2394 = inttoptr i64 %r2389 to ptr
  %r2395 = inttoptr i64 %r2390 to ptr
  %r2396 = getelementptr inbounds nuw i8, ptr %r2394, i64 4
  %r2397 = getelementptr inbounds nuw i8, ptr %r2395, i64 4
  %r2398 = load i32, ptr %r2396, align 4
  %r2399 = load i32, ptr %r2397, align 4
  %r2400 = icmp eq i32 %r2398, %r2399
  br i1 %r2400, label %streq.heap.len.459, label %streq.false.456

streq.heap.len.459:                               ; preds = %streq.heap.valid.458
  %r2401 = icmp eq i32 %r2398, 0
  br i1 %r2401, label %streq.true.455, label %streq.heap.first.460

streq.heap.first.460:                             ; preds = %streq.heap.len.459
  %r2402 = getelementptr inbounds nuw i8, ptr %r2394, i64 20
  %r2403 = getelementptr inbounds nuw i8, ptr %r2395, i64 20
  %r2404 = load i8, ptr %r2402, align 1
  %r2405 = load i8, ptr %r2403, align 1
  %r2406 = icmp eq i8 %r2404, %r2405
  br i1 %r2406, label %streq.heap.one.461, label %streq.false.456

streq.heap.one.461:                               ; preds = %streq.heap.first.460
  %r2407 = icmp eq i32 %r2398, 1
  br i1 %r2407, label %streq.true.455, label %streq.heap.last.462

streq.heap.last.462:                              ; preds = %streq.heap.one.461
  %r2408 = zext i32 %r2398 to i64
  %r2409 = add nuw nsw i64 %r2408, 19
  %r2410 = getelementptr inbounds nuw i8, ptr %r2394, i64 %r2409
  %r2411 = getelementptr inbounds nuw i8, ptr %r2395, i64 %r2409
  %r2412 = load i8, ptr %r2410, align 1
  %r2413 = load i8, ptr %r2411, align 1
  %r2414 = icmp eq i8 %r2412, %r2413
  br i1 %r2414, label %streq.heap.two.463, label %streq.false.456

streq.heap.two.463:                               ; preds = %streq.heap.last.462
  %r2415 = icmp eq i32 %r2398, 2
  br i1 %r2415, label %streq.true.455, label %streq.heap.middle.464

streq.heap.middle.464:                            ; preds = %streq.heap.two.463
  %r2416 = icmp eq i32 %r2398, 3
  br i1 %r2416, label %streq.heap.middle.byte.465, label %streq.heap.slow.466

streq.heap.middle.byte.465:                       ; preds = %streq.heap.middle.464
  %r2417 = getelementptr inbounds nuw i8, ptr %r2394, i64 21
  %r2418 = getelementptr inbounds nuw i8, ptr %r2395, i64 21
  %r2419 = load i8, ptr %r2417, align 1
  %r2420 = load i8, ptr %r2418, align 1
  %r2421 = icmp eq i8 %r2419, %r2420
  br i1 %r2421, label %streq.true.455, label %streq.false.456

streq.heap.slow.466:                              ; preds = %streq.heap.middle.464, %streq.heap.452
  %statepoint_token401 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r2389, i64 %r2390, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.181072, ptr addrspace(1) %.51108, ptr addrspace(1) %.19, ptr addrspace(1) %.181022, ptr addrspace(1) %.181047) ]
  %r2422402 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token401)
  %rs4gc.s20.relocated403 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token401, i32 0, i32 0) ; (%.181072, %.181072)
  %r138.1.relocated404 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token401, i32 1, i32 1) ; (%.51108, %.51108)
  %rs4gc.s15.relocated405 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token401, i32 2, i32 2) ; (%.19, %.19)
  %r131.0.base.relocated406 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token401, i32 3, i32 3) ; (%.181022, %.181022)
  %r131.0.relocated407 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token401, i32 3, i32 4) ; (%.181022, %.181047)
  br label %streq.merge.457

if.then.467:                                      ; preds = %streq.merge.457
  %r2435 = load double, ptr @test_json_tape_batch_records_ts_.str.21.handle, align 8
  %statepoint_token408 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_error_new_from_value, i32 1, i32 0, double %r2435, i32 0, i32 0)
  %r2436409 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token408)
  %r2437 = or i64 %r2436409, 9222527611924643840
  %r2438 = bitcast i64 %r2437 to double
  %statepoint_token410 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r2438, i32 0, i32 0)
  unreachable

if.else.468:                                      ; preds = %streq.merge.457
  br label %if.merge.469

if.merge.469:                                     ; preds = %if.else.468
  %r2439.rs4i = ptrtoint ptr addrspace(1) %.191073 to i64
  %r2439.rs4o = call i64 asm "", "=r,0"(i64 %r2439.rs4i) #7
  %r2439 = bitcast i64 %r2439.rs4o to double
  %r2440 = bitcast double %r2439 to i64
  %r2441 = and i64 %r2440, 281474976710655
  %r2442 = and i64 %r2440, -281474976710656
  %r2443 = icmp eq i64 %r2442, 9222527611924643840
  %r2444 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r2445 = icmp eq i64 %r2444, 0
  %r2446 = icmp ugt i64 %r2441, 1048575
  %r2447 = icmp ult i64 %r2441, 140737488355328
  %r2448 = and i1 %r2446, %r2447
  %r2449 = and i1 %r2443, %r2445
  %r2450 = and i1 %r2449, %r2448
  br i1 %r2450, label %tav.get.brand.474, label %tav.get.slow.472

tav.get.fast.470:                                 ; preds = %tav.get.brand.474
  %r2467 = bitcast double %r2439 to i64
  %r2468 = and i64 %r2467, 281474976710655
  %r2469 = add nuw nsw i64 %r2468, 8
  %r2470 = inttoptr i64 %r2469 to ptr
  %r2471 = load i8, ptr %r2470, align 1
  %r2472 = zext i8 %r2471 to i64
  %r2476 = inttoptr i64 %r2468 to ptr
  %r2477 = load i32, ptr %r2476, align 4
  %r2478 = zext i32 %r2477 to i64
  %r2479 = icmp ult i64 0, %r2478
  %r2480 = and i1 true, %r2479
  br i1 %r2480, label %tav.get.load.471, label %tav.get.slow.472

tav.get.load.471:                                 ; preds = %tav.get.fast.470
  %r2481 = add nuw nsw i64 %r2468, 16
  %r2482 = icmp eq i64 %r2472, 0
  br i1 %r2482, label %tav.k.i8.475, label %tav.kd1.483

tav.get.slow.472:                                 ; preds = %tav.get.brand.474, %tav.get.fast.470, %if.merge.469
  %r2533 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__18, align 8
  %r2534 = icmp ne ptr %r2533, null
  %r2535 = select i1 %r2534, ptr %r2533, ptr @perry_ic_test_json_tape_batch_records_ts__18
  %r2536 = bitcast double %r2439 to i64
  %r2537 = and i64 %r2536, 281474976710655
  %r2538 = and i64 %r2536, -281474976710656
  %r2539 = icmp eq i64 %r2538, 9222527611924643840
  %r2540 = icmp uge i64 %r2537, 2199023255552
  %r2541 = icmp ult i64 %r2537, 140737488355328
  %r2544 = and i1 %r2539, %r2540
  %r2545 = and i1 %r2544, %r2541
  br i1 %r2545, label %arrlike.ic.header.490, label %arrlike.ic.miss.509

tav.get.merge.473:                                ; preds = %arrlike.elem.value.515, %arrlike.ic.miss.509, %arrlike.ic.spill_load.508, %arrlike.ic.inline.505, %arrlike.ic.array_load.493, %tav.k.f64.482, %tav.k.f32.481, %tav.k.u32.480, %tav.k.i32.479, %tav.k.u16.478, %tav.k.i16.477, %tav.k.u8.476, %tav.k.i8.475
  %.71110 = phi ptr addrspace(1) [ %.61109, %tav.k.i8.475 ], [ %.61109, %tav.k.u8.476 ], [ %.61109, %tav.k.i16.477 ], [ %.61109, %tav.k.u16.478 ], [ %.61109, %tav.k.i32.479 ], [ %.61109, %tav.k.u32.480 ], [ %.61109, %tav.k.f32.481 ], [ %.61109, %tav.k.f64.482 ], [ %.61109, %arrlike.ic.array_load.493 ], [ %r138.1.relocated414, %arrlike.ic.miss.509 ], [ %.61109, %arrlike.elem.value.515 ], [ %.61109, %arrlike.ic.inline.505 ], [ %.61109, %arrlike.ic.spill_load.508 ]
  %.201074 = phi ptr addrspace(1) [ %.191073, %tav.k.i8.475 ], [ %.191073, %tav.k.u8.476 ], [ %.191073, %tav.k.i16.477 ], [ %.191073, %tav.k.u16.478 ], [ %.191073, %tav.k.i32.479 ], [ %.191073, %tav.k.u32.480 ], [ %.191073, %tav.k.f32.481 ], [ %.191073, %tav.k.f64.482 ], [ %.191073, %arrlike.ic.array_load.493 ], [ %rs4gc.s20.relocated413, %arrlike.ic.miss.509 ], [ %.191073, %arrlike.elem.value.515 ], [ %.191073, %arrlike.ic.inline.505 ], [ %.191073, %arrlike.ic.spill_load.508 ]
  %.201049 = phi ptr addrspace(1) [ %.191048, %tav.k.i8.475 ], [ %.191048, %tav.k.u8.476 ], [ %.191048, %tav.k.i16.477 ], [ %.191048, %tav.k.u16.478 ], [ %.191048, %tav.k.i32.479 ], [ %.191048, %tav.k.u32.480 ], [ %.191048, %tav.k.f32.481 ], [ %.191048, %tav.k.f64.482 ], [ %.191048, %arrlike.ic.array_load.493 ], [ %r131.0.relocated417, %arrlike.ic.miss.509 ], [ %.191048, %arrlike.elem.value.515 ], [ %.191048, %arrlike.ic.inline.505 ], [ %.191048, %arrlike.ic.spill_load.508 ]
  %.201024 = phi ptr addrspace(1) [ %.191023, %tav.k.i8.475 ], [ %.191023, %tav.k.u8.476 ], [ %.191023, %tav.k.i16.477 ], [ %.191023, %tav.k.u16.478 ], [ %.191023, %tav.k.i32.479 ], [ %.191023, %tav.k.u32.480 ], [ %.191023, %tav.k.f32.481 ], [ %.191023, %tav.k.f64.482 ], [ %.191023, %arrlike.ic.array_load.493 ], [ %r131.0.base.relocated416, %arrlike.ic.miss.509 ], [ %.191023, %arrlike.elem.value.515 ], [ %.191023, %arrlike.ic.inline.505 ], [ %.191023, %arrlike.ic.spill_load.508 ]
  %.21 = phi ptr addrspace(1) [ %.20, %tav.k.i8.475 ], [ %.20, %tav.k.u8.476 ], [ %.20, %tav.k.i16.477 ], [ %.20, %tav.k.u16.478 ], [ %.20, %tav.k.i32.479 ], [ %.20, %tav.k.u32.480 ], [ %.20, %tav.k.f32.481 ], [ %.20, %tav.k.f64.482 ], [ %.20, %arrlike.ic.array_load.493 ], [ %rs4gc.s15.relocated415, %arrlike.ic.miss.509 ], [ %.20, %arrlike.elem.value.515 ], [ %.20, %arrlike.ic.inline.505 ], [ %.20, %arrlike.ic.spill_load.508 ]
  %r2706 = phi double [ %r2495, %tav.k.i8.475 ], [ %r2501, %tav.k.u8.476 ], [ %r2507, %tav.k.i16.477 ], [ %r2513, %tav.k.u16.478 ], [ %r2518, %tav.k.i32.479 ], [ %r2523, %tav.k.u32.480 ], [ %r2528, %tav.k.f32.481 ], [ %r2532, %tav.k.f64.482 ], [ %r2589, %arrlike.elem.value.515 ], [ %r2617, %arrlike.ic.array_load.493 ], [ %r2687, %arrlike.ic.inline.505 ], [ %r2704, %arrlike.ic.spill_load.508 ], [ %r2705412, %arrlike.ic.miss.509 ]
  %r2707 = bitcast double %r2706 to i64
  %r2708 = and i64 %r2707, 281474976710655
  %r2709 = lshr i64 %r2707, 48
  %r2710 = and i64 %r2709, 65533
  %r2711 = icmp eq i64 %r2710, 32765
  br i1 %r2711, label %pget.recv_ok.518, label %pget.recv_other.522

tav.get.brand.474:                                ; preds = %if.merge.469
  %r2451 = bitcast double %r2439 to i64
  %r2452 = and i64 %r2451, 281474976710655
  %r2453 = sub nsw i64 %r2452, 8
  %r2454 = inttoptr i64 %r2453 to ptr
  %r2455 = load i8, ptr %r2454, align 1
  %r2456 = icmp eq i8 %r2455, 11
  %r2457 = add nuw nsw i64 %r2452, 8
  %r2458 = inttoptr i64 %r2457 to ptr
  %r2459 = load i8, ptr %r2458, align 1
  %r2460 = zext i8 %r2459 to i64
  %r2461 = icmp ule i64 %r2460, 8
  %r2464 = and i1 %r2456, %r2461
  br i1 %r2464, label %tav.get.fast.470, label %tav.get.slow.472

tav.k.i8.475:                                     ; preds = %tav.get.load.471
  %r2491 = add nuw nsw i64 %r2481, 0
  %r2492 = inttoptr i64 %r2491 to ptr
  %r2493 = load i8, ptr %r2492, align 1
  %r2494 = sext i8 %r2493 to i32
  %r2495 = sitofp i32 %r2494 to double
  br label %tav.get.merge.473

tav.k.u8.476:                                     ; preds = %tav.kd7.489, %tav.kd1.483
  %r2497 = add nuw nsw i64 %r2481, 0
  %r2498 = inttoptr i64 %r2497 to ptr
  %r2499 = load i8, ptr %r2498, align 1
  %r2500 = zext i8 %r2499 to i32
  %r2501 = uitofp nneg i32 %r2500 to double
  br label %tav.get.merge.473

tav.k.i16.477:                                    ; preds = %tav.kd2.484
  %r2503 = add nuw nsw i64 %r2481, 0
  %r2504 = inttoptr i64 %r2503 to ptr
  %r2505 = load i16, ptr %r2504, align 2
  %r2506 = sext i16 %r2505 to i32
  %r2507 = sitofp i32 %r2506 to double
  br label %tav.get.merge.473

tav.k.u16.478:                                    ; preds = %tav.kd3.485
  %r2509 = add nuw nsw i64 %r2481, 0
  %r2510 = inttoptr i64 %r2509 to ptr
  %r2511 = load i16, ptr %r2510, align 2
  %r2512 = zext i16 %r2511 to i32
  %r2513 = uitofp nneg i32 %r2512 to double
  br label %tav.get.merge.473

tav.k.i32.479:                                    ; preds = %tav.kd4.486
  %r2515 = add nuw nsw i64 %r2481, 0
  %r2516 = inttoptr i64 %r2515 to ptr
  %r2517 = load i32, ptr %r2516, align 4
  %r2518 = sitofp i32 %r2517 to double
  br label %tav.get.merge.473

tav.k.u32.480:                                    ; preds = %tav.kd5.487
  %r2520 = add nuw nsw i64 %r2481, 0
  %r2521 = inttoptr i64 %r2520 to ptr
  %r2522 = load i32, ptr %r2521, align 4
  %r2523 = uitofp i32 %r2522 to double
  br label %tav.get.merge.473

tav.k.f32.481:                                    ; preds = %tav.kd6.488
  %r2525 = add nuw nsw i64 %r2481, 0
  %r2526 = inttoptr i64 %r2525 to ptr
  %r2527 = load float, ptr %r2526, align 4
  %r2528 = fpext float %r2527 to double
  br label %tav.get.merge.473

tav.k.f64.482:                                    ; preds = %tav.kd7.489
  %r2530 = add nuw nsw i64 %r2481, 0
  %r2531 = inttoptr i64 %r2530 to ptr
  %r2532 = load double, ptr %r2531, align 8
  br label %tav.get.merge.473

tav.kd1.483:                                      ; preds = %tav.get.load.471
  %r2483 = icmp eq i64 %r2472, 1
  br i1 %r2483, label %tav.k.u8.476, label %tav.kd2.484

tav.kd2.484:                                      ; preds = %tav.kd1.483
  %r2484 = icmp eq i64 %r2472, 2
  br i1 %r2484, label %tav.k.i16.477, label %tav.kd3.485

tav.kd3.485:                                      ; preds = %tav.kd2.484
  %r2485 = icmp eq i64 %r2472, 3
  br i1 %r2485, label %tav.k.u16.478, label %tav.kd4.486

tav.kd4.486:                                      ; preds = %tav.kd3.485
  %r2486 = icmp eq i64 %r2472, 4
  br i1 %r2486, label %tav.k.i32.479, label %tav.kd5.487

tav.kd5.487:                                      ; preds = %tav.kd4.486
  %r2487 = icmp eq i64 %r2472, 5
  br i1 %r2487, label %tav.k.u32.480, label %tav.kd6.488

tav.kd6.488:                                      ; preds = %tav.kd5.487
  %r2488 = icmp eq i64 %r2472, 6
  br i1 %r2488, label %tav.k.f32.481, label %tav.kd7.489

tav.kd7.489:                                      ; preds = %tav.kd6.488
  %r2489 = icmp eq i64 %r2472, 7
  br i1 %r2489, label %tav.k.f64.482, label %tav.k.u8.476

arrlike.ic.header.490:                            ; preds = %tav.get.slow.472
  %r2551 = sub nuw nsw i64 %r2537, 8
  %r2552 = inttoptr i64 %r2551 to ptr
  %r2553 = load i8, ptr %r2552, align 1
  %r2555 = sub nuw nsw i64 %r2537, 7
  %r2556 = inttoptr i64 %r2555 to ptr
  %r2557 = load i8, ptr %r2556, align 1
  %r2558 = and i8 %r2557, -128
  %r2559 = icmp eq i8 %r2558, 0
  %r2560 = and i1 true, %r2559
  br i1 %r2560, label %arrlike.ic.brand.491, label %arrlike.ic.miss.509

arrlike.ic.brand.491:                             ; preds = %arrlike.ic.header.490
  %r2554 = icmp eq i8 %r2553, 1
  br i1 %r2554, label %arrlike.ic.array_guard.492, label %arrlike.elem.kind.510

arrlike.ic.array_guard.492:                       ; preds = %arrlike.ic.brand.491
  %r2592 = sub nuw nsw i64 %r2537, 6
  %r2593 = inttoptr i64 %r2592 to ptr
  %r2594 = load i16, ptr %r2593, align 2
  %r2595 = and i16 %r2594, 1024
  %r2596 = icmp eq i16 %r2595, 0
  %r2597 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2598 = icmp eq i8 %r2597, 0
  %r2599 = inttoptr i64 %r2537 to ptr
  %r2600 = load i32, ptr %r2599, align 4
  %r2601 = add nuw nsw i64 %r2537, 4
  %r2602 = inttoptr i64 %r2601 to ptr
  %r2603 = load i32, ptr %r2602, align 4
  %r2604 = zext i32 %r2600 to i64
  %r2605 = zext i32 %r2603 to i64
  %r2606 = icmp ult i64 0, %r2604
  %r2607 = icmp ule i64 %r2604, %r2605
  %r2608 = and i1 %r2596, %r2598
  %r2609 = and i1 %r2608, %r2606
  %r2610 = and i1 %r2609, %r2607
  br i1 %r2610, label %arrlike.ic.array_load.493, label %arrlike.ic.miss.509

arrlike.ic.array_load.493:                        ; preds = %arrlike.ic.array_guard.492
  %r2612 = getelementptr inbounds nuw i64, ptr %r2599, i64 1
  %r2613 = load double, ptr %r2612, align 8
  %r2614 = bitcast double %r2613 to i64
  %r2615 = icmp eq i64 %r2614, 9222246136947933200
  %r2617 = select i1 %r2615, double 0x7FFC000000000001, double %r2613
  br label %tav.get.merge.473

arrlike.ic.shape.494:                             ; preds = %arrlike.elem.store.512, %arrlike.elem.meta.511
  %r2619 = inttoptr i64 %r2537 to ptr
  %r2620 = load i32, ptr %r2619, align 4
  %r2621 = add nuw nsw i64 %r2537, 4
  %r2622 = inttoptr i64 %r2621 to ptr
  %r2623 = load i32, ptr %r2622, align 4
  %r2624 = zext i32 %r2620 to i64
  %r2625 = zext i32 %r2623 to i64
  %r2626 = shl nuw i64 %r2624, 32
  %r2627 = or i64 %r2626, %r2625
  %r2628 = getelementptr i64, ptr %r2535, i64 0
  %r2629 = load i64, ptr %r2628, align 8
  %r2630 = icmp ne i64 %r2629, 0
  %r2631 = and i1 true, %r2630
  br i1 %r2631, label %arrlike.ic.identity.495, label %arrlike.ic.miss.509

arrlike.ic.identity.495:                          ; preds = %arrlike.ic.shape.494
  %r2632 = and i64 %r2629, -9223372036854775808
  %4 = icmp slt i64 %r2629, 0
  br i1 %4, label %arrlike.ic.family_meta.497, label %arrlike.ic.exact.496

arrlike.ic.exact.496:                             ; preds = %arrlike.ic.identity.495
  %r2634 = icmp eq i64 %r2627, %r2629
  br i1 %r2634, label %arrlike.ic.bounds.499, label %arrlike.ic.miss.509

arrlike.ic.family_meta.497:                       ; preds = %arrlike.ic.identity.495
  %r2635 = add nuw nsw i64 %r2537, 8
  %r2636 = inttoptr i64 %r2635 to ptr
  %r2637 = load i64, ptr %r2636, align 8
  %r2638 = icmp ne i64 %r2637, 0
  br i1 %r2638, label %arrlike.ic.family_token.498, label %arrlike.ic.miss.509

arrlike.ic.family_token.498:                      ; preds = %arrlike.ic.family_meta.497
  %r2639 = inttoptr i64 %r2637 to ptr
  %r2640 = getelementptr i64, ptr %r2639, i64 6
  %r2641 = load i64, ptr %r2640, align 8
  %r2642 = icmp eq i64 %r2641, %r2629
  br i1 %r2642, label %arrlike.ic.bounds.499, label %arrlike.ic.miss.509

arrlike.ic.bounds.499:                            ; preds = %arrlike.ic.family_token.498, %arrlike.ic.exact.496
  %r2643 = getelementptr i64, ptr %r2533, i64 1
  %r2644 = load i64, ptr %r2643, align 8
  %r2645 = getelementptr i64, ptr %r2533, i64 2
  %r2646 = load i64, ptr %r2645, align 8
  %r2647 = getelementptr i64, ptr %r2533, i64 3
  %r2648 = load i64, ptr %r2647, align 8
  %r2649 = getelementptr i64, ptr %r2533, i64 4
  %r2650 = load i64, ptr %r2649, align 8
  %r2651 = icmp ult i64 %r2644, %r2650
  br i1 %r2651, label %arrlike.ic.length_inline.500, label %arrlike.ic.length_spill_meta.501

arrlike.ic.length_inline.500:                     ; preds = %arrlike.ic.bounds.499
  %r2652 = shl i64 %r2644, 3
  %r2653 = add i64 %r2652, 16
  %r2654 = add i64 %r2537, %r2653
  %r2655 = inttoptr i64 %r2654 to ptr
  %r2656 = load double, ptr %r2655, align 8
  br label %arrlike.ic.range.504

arrlike.ic.length_spill_meta.501:                 ; preds = %arrlike.ic.bounds.499
  %r2657 = add nuw nsw i64 %r2537, 8
  %r2658 = inttoptr i64 %r2657 to ptr
  %r2659 = load i64, ptr %r2658, align 8
  %r2660 = icmp ne i64 %r2659, 0
  br i1 %r2660, label %arrlike.ic.length_spill_ptr.502, label %arrlike.ic.miss.509

arrlike.ic.length_spill_ptr.502:                  ; preds = %arrlike.ic.length_spill_meta.501
  %r2661 = inttoptr i64 %r2659 to ptr
  %r2662 = getelementptr i64, ptr %r2661, i64 4
  %r2663 = load i64, ptr %r2662, align 8
  %r2664 = icmp ne i64 %r2663, 0
  %r2665 = select i1 %r2664, i64 %r2663, i64 %r2659
  %r2666 = inttoptr i64 %r2665 to ptr
  %r2667 = load i32, ptr %r2666, align 4
  %r2668 = zext i32 %r2667 to i64
  %r2669 = icmp ult i64 %r2644, %r2668
  %r2670 = and i1 %r2664, %r2669
  br i1 %r2670, label %arrlike.ic.length_spill_load.503, label %arrlike.ic.miss.509

arrlike.ic.length_spill_load.503:                 ; preds = %arrlike.ic.length_spill_ptr.502
  %r2671 = add nuw nsw i64 %r2644, 1
  %r2672 = getelementptr inbounds nuw i64, ptr %r2666, i64 %r2671
  %r2673 = load double, ptr %r2672, align 8
  br label %arrlike.ic.range.504

arrlike.ic.range.504:                             ; preds = %arrlike.ic.length_spill_load.503, %arrlike.ic.length_inline.500
  %r2674 = phi double [ %r2656, %arrlike.ic.length_inline.500 ], [ %r2673, %arrlike.ic.length_spill_load.503 ]
  %r2675 = fcmp olt double 0.000000e+00, %r2674
  %r2676 = icmp ult i64 0, %r2648
  %r2677 = and i1 %r2675, %r2676
  %r2678 = add nuw nsw i64 %r2646, 0
  %r2679 = icmp ult i64 %r2678, %r2650
  %r2680 = and i1 %r2677, %r2679
  %r2681 = xor i1 %r2679, true
  %r2682 = and i1 %r2677, %r2681
  br i1 %r2680, label %arrlike.ic.inline.505, label %arrlike.ic.spill_or_miss.516

arrlike.ic.inline.505:                            ; preds = %arrlike.ic.range.504
  %r2683 = shl i64 %r2678, 3
  %r2684 = add i64 %r2683, 16
  %r2685 = add i64 %r2537, %r2684
  %r2686 = inttoptr i64 %r2685 to ptr
  %r2687 = load double, ptr %r2686, align 8
  br label %tav.get.merge.473

arrlike.ic.spill.506:                             ; preds = %arrlike.ic.spill_or_miss.516
  %r2688 = add nuw nsw i64 %r2537, 8
  %r2689 = inttoptr i64 %r2688 to ptr
  %r2690 = load i64, ptr %r2689, align 8
  %r2691 = icmp ne i64 %r2690, 0
  br i1 %r2691, label %arrlike.ic.spill_ptr.507, label %arrlike.ic.miss.509

arrlike.ic.spill_ptr.507:                         ; preds = %arrlike.ic.spill.506
  %r2692 = inttoptr i64 %r2690 to ptr
  %r2693 = getelementptr i64, ptr %r2692, i64 4
  %r2694 = load i64, ptr %r2693, align 8
  %r2695 = icmp ne i64 %r2694, 0
  %r2696 = select i1 %r2695, i64 %r2694, i64 %r2690
  %r2697 = inttoptr i64 %r2696 to ptr
  %r2698 = load i32, ptr %r2697, align 4
  %r2699 = zext i32 %r2698 to i64
  %r2700 = icmp ult i64 %r2678, %r2699
  %r2701 = and i1 %r2695, %r2700
  br i1 %r2701, label %arrlike.ic.spill_load.508, label %arrlike.ic.miss.509

arrlike.ic.spill_load.508:                        ; preds = %arrlike.ic.spill_ptr.507
  %r2702 = add nuw nsw i64 %r2678, 1
  %r2703 = getelementptr inbounds nuw i64, ptr %r2697, i64 %r2702
  %r2704 = load double, ptr %r2703, align 8
  br label %tav.get.merge.473

arrlike.ic.miss.509:                              ; preds = %arrlike.ic.spill_or_miss.516, %arrlike.elem.load.514, %arrlike.elem.bounds.513, %arrlike.elem.kind.510, %arrlike.ic.spill_ptr.507, %arrlike.ic.spill.506, %arrlike.ic.length_spill_ptr.502, %arrlike.ic.length_spill_meta.501, %arrlike.ic.family_token.498, %arrlike.ic.family_meta.497, %arrlike.ic.exact.496, %arrlike.ic.shape.494, %arrlike.ic.array_guard.492, %arrlike.ic.header.490, %tav.get.slow.472
  %statepoint_token411 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, ptr)) @js_packed_arraylike_index_get, i32 3, i32 0, double %r2439, double 0.000000e+00, ptr @perry_ic_test_json_tape_batch_records_ts__18, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.191073, ptr addrspace(1) %.61109, ptr addrspace(1) %.20, ptr addrspace(1) %.191023, ptr addrspace(1) %.191048) ]
  %r2705412 = call double @llvm.experimental.gc.result.f64(token %statepoint_token411)
  %rs4gc.s20.relocated413 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token411, i32 0, i32 0) ; (%.191073, %.191073)
  %r138.1.relocated414 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token411, i32 1, i32 1) ; (%.61109, %.61109)
  %rs4gc.s15.relocated415 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token411, i32 2, i32 2) ; (%.20, %.20)
  %r131.0.base.relocated416 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token411, i32 3, i32 3) ; (%.191023, %.191023)
  %r131.0.relocated417 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token411, i32 3, i32 4) ; (%.191023, %.191048)
  br label %tav.get.merge.473

arrlike.elem.kind.510:                            ; preds = %arrlike.ic.brand.491
  %r2561 = icmp eq i8 %r2553, 2
  br i1 %r2561, label %arrlike.elem.meta.511, label %arrlike.ic.miss.509

arrlike.elem.meta.511:                            ; preds = %arrlike.elem.kind.510
  %r2562 = add nuw nsw i64 %r2537, 8
  %r2563 = inttoptr i64 %r2562 to ptr
  %r2564 = load i64, ptr %r2563, align 8
  %r2565 = icmp ne i64 %r2564, 0
  br i1 %r2565, label %arrlike.elem.store.512, label %arrlike.ic.shape.494

arrlike.elem.store.512:                           ; preds = %arrlike.elem.meta.511
  %r2566 = inttoptr i64 %r2564 to ptr
  %r2567 = getelementptr i64, ptr %r2566, i64 12
  %r2568 = load i64, ptr %r2567, align 8
  %r2569 = icmp ne i64 %r2568, 0
  br i1 %r2569, label %arrlike.elem.bounds.513, label %arrlike.ic.shape.494

arrlike.elem.bounds.513:                          ; preds = %arrlike.elem.store.512
  %r2570 = sub i64 %r2568, 8
  %r2571 = inttoptr i64 %r2570 to ptr
  %r2572 = load i8, ptr %r2571, align 1
  %r2573 = icmp eq i8 %r2572, 1
  %r2574 = sub i64 %r2568, 7
  %r2575 = inttoptr i64 %r2574 to ptr
  %r2576 = load i8, ptr %r2575, align 1
  %r2577 = and i8 %r2576, -128
  %r2578 = icmp eq i8 %r2577, 0
  %r2579 = inttoptr i64 %r2568 to ptr
  %r2580 = load i32, ptr %r2579, align 4
  %r2581 = zext i32 %r2580 to i64
  %r2582 = icmp ult i64 0, %r2581
  %r2583 = and i1 %r2573, %r2578
  %r2584 = and i1 %r2583, %r2582
  br i1 %r2584, label %arrlike.elem.load.514, label %arrlike.ic.miss.509

arrlike.elem.load.514:                            ; preds = %arrlike.elem.bounds.513
  %r2586 = add i64 %r2568, 8
  %r2587 = add nuw nsw i64 %r2586, 0
  %r2588 = inttoptr i64 %r2587 to ptr
  %r2589 = load double, ptr %r2588, align 8
  %r2590 = bitcast double %r2589 to i64
  %r2591 = icmp eq i64 %r2590, 9222246136947933200
  br i1 %r2591, label %arrlike.ic.miss.509, label %arrlike.elem.value.515

arrlike.elem.value.515:                           ; preds = %arrlike.elem.load.514
  br label %tav.get.merge.473

arrlike.ic.spill_or_miss.516:                     ; preds = %arrlike.ic.range.504
  br i1 %r2682, label %arrlike.ic.spill.506, label %arrlike.ic.miss.509

pget.recv_sso.517:                                ; preds = %pget.recv_other.522
  %r2849 = load double, ptr @test_json_tape_batch_records_ts_.str.15.handle, align 8
  %r2850 = bitcast double %r2849 to i64
  %r2851 = and i64 %r2850, 281474976710655
  %statepoint_token418 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2707, i64 %r2851, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.201074, ptr addrspace(1) %.71110, ptr addrspace(1) %.21, ptr addrspace(1) %.201024, ptr addrspace(1) %.201049) ]
  %r2852419 = call double @llvm.experimental.gc.result.f64(token %statepoint_token418)
  %rs4gc.s20.relocated420 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token418, i32 0, i32 0) ; (%.201074, %.201074)
  %r138.1.relocated421 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token418, i32 1, i32 1) ; (%.71110, %.71110)
  %rs4gc.s15.relocated422 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token418, i32 2, i32 2) ; (%.21, %.21)
  %r131.0.base.relocated423 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token418, i32 3, i32 3) ; (%.201024, %.201024)
  %r131.0.relocated424 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token418, i32 3, i32 4) ; (%.201024, %.201049)
  br label %pget.recv_merge.521

pget.recv_ok.518:                                 ; preds = %tav.get.merge.473
  %r2718 = icmp ugt i64 %r2708, 1048575
  br i1 %r2718, label %pic.recv_hdr.539, label %pic.miss.cold.536

pget.recv_bad.519:                                ; preds = %pget.check_class_ref.523
  %r2841 = icmp eq i64 %r2707, 9222246136947933185
  %r2842 = icmp eq i64 %r2707, 9222246136947933186
  %r2843 = or i1 %r2841, %r2842
  br i1 %r2843, label %pget.throw_nullish.546, label %pget.recv_undef_return.547

pget.recv_class_ref.520:                          ; preds = %pget.check_class_ref.523
  %r2714 = load double, ptr @test_json_tape_batch_records_ts_.str.15.handle, align 8
  %r2715 = bitcast double %r2714 to i64
  %r2716 = and i64 %r2715, 281474976710655
  %statepoint_token425 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 367713371643969555, i64 %r2707, i64 %r2716, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.201074, ptr addrspace(1) %.71110, ptr addrspace(1) %.21, ptr addrspace(1) %.201024, ptr addrspace(1) %.201049) ]
  %r2717426 = call double @llvm.experimental.gc.result.f64(token %statepoint_token425)
  %rs4gc.s20.relocated427 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token425, i32 0, i32 0) ; (%.201074, %.201074)
  %r138.1.relocated428 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token425, i32 1, i32 1) ; (%.71110, %.71110)
  %rs4gc.s15.relocated429 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token425, i32 2, i32 2) ; (%.21, %.21)
  %r131.0.base.relocated430 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token425, i32 3, i32 3) ; (%.201024, %.201024)
  %r131.0.relocated431 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token425, i32 3, i32 4) ; (%.201024, %.201049)
  br label %pget.recv_merge.521

pget.recv_merge.521:                              ; preds = %pget.recv_undef_return.547, %pic.merge.538, %pget.recv_class_ref.520, %pget.recv_sso.517
  %.81111 = phi ptr addrspace(1) [ %.91112, %pic.merge.538 ], [ %r138.1.relocated421, %pget.recv_sso.517 ], [ %r138.1.relocated428, %pget.recv_class_ref.520 ], [ %r138.1.relocated450, %pget.recv_undef_return.547 ]
  %.211075 = phi ptr addrspace(1) [ %.221076, %pic.merge.538 ], [ %rs4gc.s20.relocated420, %pget.recv_sso.517 ], [ %rs4gc.s20.relocated427, %pget.recv_class_ref.520 ], [ %rs4gc.s20.relocated449, %pget.recv_undef_return.547 ]
  %.211050 = phi ptr addrspace(1) [ %.221051, %pic.merge.538 ], [ %r131.0.relocated424, %pget.recv_sso.517 ], [ %r131.0.relocated431, %pget.recv_class_ref.520 ], [ %r131.0.relocated453, %pget.recv_undef_return.547 ]
  %.211025 = phi ptr addrspace(1) [ %.221026, %pic.merge.538 ], [ %r131.0.base.relocated423, %pget.recv_sso.517 ], [ %r131.0.base.relocated430, %pget.recv_class_ref.520 ], [ %r131.0.base.relocated452, %pget.recv_undef_return.547 ]
  %.22 = phi ptr addrspace(1) [ %.23, %pic.merge.538 ], [ %rs4gc.s15.relocated422, %pget.recv_sso.517 ], [ %rs4gc.s15.relocated429, %pget.recv_class_ref.520 ], [ %rs4gc.s15.relocated451, %pget.recv_undef_return.547 ]
  %r2853 = phi double [ %r2840, %pic.merge.538 ], [ %r2848448, %pget.recv_undef_return.547 ], [ %r2852419, %pget.recv_sso.517 ], [ %r2717426, %pget.recv_class_ref.520 ]
  %r2854 = bitcast double %r2853 to i64
  %r2855 = and i64 %r2854, 281474976710655
  %r2856 = lshr i64 %r2854, 48
  %r2857 = and i64 %r2856, 65533
  %r2858 = icmp eq i64 %r2857, 32765
  br i1 %r2858, label %pget.recv_ok.549, label %pget.recv_other.554

pget.recv_other.522:                              ; preds = %tav.get.merge.473
  %r2712 = icmp eq i64 %r2709, 32761
  br i1 %r2712, label %pget.recv_sso.517, label %pget.check_class_ref.523

pget.check_class_ref.523:                         ; preds = %pget.recv_other.522
  %r2713 = icmp eq i64 %r2709, 32766
  br i1 %r2713, label %pget.recv_class_ref.520, label %pget.recv_bad.519

pic.hit.524:                                      ; preds = %pic.token.540
  %r2743 = getelementptr i64, ptr %r2728, i64 1
  %r2744 = load i64, ptr %r2743, align 8
  %r2745 = and i64 %r2744, 1073741824
  %r2746 = icmp ne i64 %r2745, 0
  br i1 %r2746, label %pic.hit.overflow.541, label %pic.hit.inline.542

pic.hit.live.525:                                 ; preds = %pic.hit.inline.542
  br label %pic.merge.538

pic.prefix.guard.526:                             ; preds = %pic.token.540
  %r2759 = getelementptr i64, ptr %r2728, i64 2
  %r2760 = load i64, ptr %r2759, align 8
  %r2761 = icmp ne i64 %r2760, 0
  br i1 %r2761, label %pic.prefix.meta.527, label %pic.miss.535

pic.prefix.meta.527:                              ; preds = %pic.prefix.guard.526
  %r2762 = add nuw nsw i64 %r2708, 8
  %r2763 = inttoptr i64 %r2762 to ptr
  %r2764 = load i64, ptr %r2763, align 8
  %r2765 = icmp ne i64 %r2764, 0
  br i1 %r2765, label %pic.prefix.token.528, label %pic.miss.535

pic.prefix.token.528:                             ; preds = %pic.prefix.meta.527
  %r2766 = inttoptr i64 %r2764 to ptr
  %r2767 = getelementptr i64, ptr %r2766, i64 6
  %r2768 = load i64, ptr %r2767, align 8
  %r2769 = icmp eq i64 %r2768, %r2760
  br i1 %r2769, label %pic.prefix.hit.529, label %pic.miss.535

pic.prefix.hit.529:                               ; preds = %pic.prefix.token.528
  %r2770 = getelementptr i64, ptr %r2728, i64 1
  %r2771 = load i64, ptr %r2770, align 8
  %r2772 = shl i64 %r2771, 3
  %r2773 = add nuw nsw i64 %r2708, 16
  %r2774 = add i64 %r2773, %r2772
  %r2775 = inttoptr i64 %r2774 to ptr
  %r2776 = load double, ptr %r2775, align 8
  br label %pic.merge.538

pic.desc.classify.530:                            ; preds = %pic.recv_hdr.539
  %r2732 = and i1 %r2722, %r2729
  br i1 %r2732, label %pic.desc.prefix.guard.531, label %pic.miss.cold.536

pic.desc.prefix.guard.531:                        ; preds = %pic.desc.classify.530
  %r2777 = getelementptr i64, ptr %r2728, i64 2
  %r2778 = load i64, ptr %r2777, align 8
  %r2779 = icmp ne i64 %r2778, 0
  br i1 %r2779, label %pic.desc.prefix.meta.532, label %pic.miss.cold.536

pic.desc.prefix.meta.532:                         ; preds = %pic.desc.prefix.guard.531
  %r2780 = add nuw nsw i64 %r2708, 8
  %r2781 = inttoptr i64 %r2780 to ptr
  %r2782 = load i64, ptr %r2781, align 8
  %r2783 = icmp ne i64 %r2782, 0
  br i1 %r2783, label %pic.desc.prefix.token.533, label %pic.miss.cold.536

pic.desc.prefix.token.533:                        ; preds = %pic.desc.prefix.meta.532
  %r2784 = inttoptr i64 %r2782 to ptr
  %r2785 = getelementptr i64, ptr %r2784, i64 6
  %r2786 = load i64, ptr %r2785, align 8
  %r2787 = icmp eq i64 %r2786, %r2778
  br i1 %r2787, label %pic.desc.prefix.hit.534, label %pic.miss.cold.536

pic.desc.prefix.hit.534:                          ; preds = %pic.desc.prefix.token.533
  %r2788 = getelementptr i64, ptr %r2728, i64 1
  %r2789 = load i64, ptr %r2788, align 8
  %r2790 = shl i64 %r2789, 3
  %r2791 = add nuw nsw i64 %r2708, 16
  %r2792 = add i64 %r2791, %r2790
  %r2793 = inttoptr i64 %r2792 to ptr
  %r2794 = load double, ptr %r2793, align 8
  br label %pic.merge.538

pic.miss.535:                                     ; preds = %pic.hit.inline.542, %pic.prefix.token.528, %pic.prefix.meta.527, %pic.prefix.guard.526
  %r2795 = getelementptr i64, ptr %r2728, i64 3
  %r2796 = load i64, ptr %r2795, align 8
  %r2797 = icmp sgt i64 %r2796, 0
  br i1 %r2797, label %pic.ways.543, label %pic.miss.call.537

pic.miss.cold.536:                                ; preds = %pic.desc.prefix.token.533, %pic.desc.prefix.meta.532, %pic.desc.prefix.guard.531, %pic.desc.classify.530, %pget.recv_ok.518
  br label %pic.miss.call.537

pic.miss.call.537:                                ; preds = %pic.way.load.544, %pic.ways.543, %pic.miss.cold.536, %pic.miss.535
  %r2836 = load double, ptr @test_json_tape_batch_records_ts_.str.15.handle, align 8
  %r2837 = bitcast double %r2836 to i64
  %r2838 = and i64 %r2837, 281474976710655
  %statepoint_token432 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r2708, i64 %r2838, ptr @perry_ic_test_json_tape_batch_records_ts__20, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.201074, ptr addrspace(1) %.71110, ptr addrspace(1) %.21, ptr addrspace(1) %.201024, ptr addrspace(1) %.201049) ]
  %r2839433 = call double @llvm.experimental.gc.result.f64(token %statepoint_token432)
  %rs4gc.s20.relocated434 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token432, i32 0, i32 0) ; (%.201074, %.201074)
  %r138.1.relocated435 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token432, i32 1, i32 1) ; (%.71110, %.71110)
  %rs4gc.s15.relocated436 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token432, i32 2, i32 2) ; (%.21, %.21)
  %r131.0.base.relocated437 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token432, i32 3, i32 3) ; (%.201024, %.201024)
  %r131.0.relocated438 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token432, i32 3, i32 4) ; (%.201024, %.201049)
  br label %pic.merge.538

pic.merge.538:                                    ; preds = %pic.way.live.545, %pic.hit.overflow.541, %pic.miss.call.537, %pic.desc.prefix.hit.534, %pic.prefix.hit.529, %pic.hit.live.525
  %.91112 = phi ptr addrspace(1) [ %r138.1.relocated442, %pic.hit.overflow.541 ], [ %r138.1.relocated435, %pic.miss.call.537 ], [ %.71110, %pic.way.live.545 ], [ %.71110, %pic.hit.live.525 ], [ %.71110, %pic.prefix.hit.529 ], [ %.71110, %pic.desc.prefix.hit.534 ]
  %.221076 = phi ptr addrspace(1) [ %rs4gc.s20.relocated441, %pic.hit.overflow.541 ], [ %rs4gc.s20.relocated434, %pic.miss.call.537 ], [ %.201074, %pic.way.live.545 ], [ %.201074, %pic.hit.live.525 ], [ %.201074, %pic.prefix.hit.529 ], [ %.201074, %pic.desc.prefix.hit.534 ]
  %.221051 = phi ptr addrspace(1) [ %r131.0.relocated445, %pic.hit.overflow.541 ], [ %r131.0.relocated438, %pic.miss.call.537 ], [ %.201049, %pic.way.live.545 ], [ %.201049, %pic.hit.live.525 ], [ %.201049, %pic.prefix.hit.529 ], [ %.201049, %pic.desc.prefix.hit.534 ]
  %.221026 = phi ptr addrspace(1) [ %r131.0.base.relocated444, %pic.hit.overflow.541 ], [ %r131.0.base.relocated437, %pic.miss.call.537 ], [ %.201024, %pic.way.live.545 ], [ %.201024, %pic.hit.live.525 ], [ %.201024, %pic.prefix.hit.529 ], [ %.201024, %pic.desc.prefix.hit.534 ]
  %.23 = phi ptr addrspace(1) [ %rs4gc.s15.relocated443, %pic.hit.overflow.541 ], [ %rs4gc.s15.relocated436, %pic.miss.call.537 ], [ %.21, %pic.way.live.545 ], [ %.21, %pic.hit.live.525 ], [ %.21, %pic.prefix.hit.529 ], [ %.21, %pic.desc.prefix.hit.534 ]
  %r2840 = phi double [ %r2756, %pic.hit.live.525 ], [ %r2751440, %pic.hit.overflow.541 ], [ %r2776, %pic.prefix.hit.529 ], [ %r2794, %pic.desc.prefix.hit.534 ], [ %r2833, %pic.way.live.545 ], [ %r2839433, %pic.miss.call.537 ]
  br label %pget.recv_merge.521

pic.recv_hdr.539:                                 ; preds = %pget.recv_ok.518
  %r2719 = sub nuw nsw i64 %r2708, 8
  %r2720 = inttoptr i64 %r2719 to ptr
  %r2721 = load i8, ptr %r2720, align 1
  %r2722 = icmp eq i8 %r2721, 2
  %r2723 = sub nuw nsw i64 %r2708, 6
  %r2724 = inttoptr i64 %r2723 to ptr
  %r2725 = load i16, ptr %r2724, align 2
  %r2726 = and i16 %r2725, 2048
  %r2727 = icmp eq i16 %r2726, 0
  %r2728 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__20, align 8
  %r2729 = icmp ne ptr %r2728, null
  %r2730 = and i1 %r2722, %r2727
  %r2731 = and i1 %r2730, %r2729
  br i1 %r2731, label %pic.token.540, label %pic.desc.classify.530

pic.token.540:                                    ; preds = %pic.recv_hdr.539
  %r2733 = add nuw nsw i64 %r2708, 4
  %r2734 = inttoptr i64 %r2733 to ptr
  %r2735 = load i32, ptr %r2734, align 4
  %r2736 = zext i32 %r2735 to i64
  %r2737 = or i64 %r2736, 4611686018427387904
  %r2738 = icmp ne i32 %r2735, 0
  %r2739 = getelementptr i64, ptr %r2728, i64 0
  %r2740 = load i64, ptr %r2739, align 8
  %r2741 = icmp eq i64 %r2737, %r2740
  %r2742 = and i1 %r2741, %r2738
  br i1 %r2742, label %pic.hit.524, label %pic.prefix.guard.526

pic.hit.overflow.541:                             ; preds = %pic.hit.524
  %r2747 = load double, ptr @test_json_tape_batch_records_ts_.str.15.handle, align 8
  %r2748 = bitcast double %r2747 to i64
  %r2749 = and i64 %r2748, 281474976710655
  %r2750 = trunc i64 %r2744 to i32
  %statepoint_token439 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r2708, i64 %r2749, i32 %r2750, ptr @perry_ic_test_json_tape_batch_records_ts__20, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.201074, ptr addrspace(1) %.71110, ptr addrspace(1) %.21, ptr addrspace(1) %.201024, ptr addrspace(1) %.201049) ]
  %r2751440 = call double @llvm.experimental.gc.result.f64(token %statepoint_token439)
  %rs4gc.s20.relocated441 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token439, i32 0, i32 0) ; (%.201074, %.201074)
  %r138.1.relocated442 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token439, i32 1, i32 1) ; (%.71110, %.71110)
  %rs4gc.s15.relocated443 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token439, i32 2, i32 2) ; (%.21, %.21)
  %r131.0.base.relocated444 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token439, i32 3, i32 3) ; (%.201024, %.201024)
  %r131.0.relocated445 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token439, i32 3, i32 4) ; (%.201024, %.201049)
  br label %pic.merge.538

pic.hit.inline.542:                               ; preds = %pic.hit.524
  %r2752 = shl i64 %r2744, 3
  %r2753 = add nuw nsw i64 %r2708, 16
  %r2754 = add i64 %r2753, %r2752
  %r2755 = inttoptr i64 %r2754 to ptr
  %r2756 = load double, ptr %r2755, align 8
  %r2757 = bitcast double %r2756 to i64
  %r2758 = icmp eq i64 %r2757, 9222246136947933200
  br i1 %r2758, label %pic.miss.535, label %pic.hit.live.525

pic.ways.543:                                     ; preds = %pic.miss.535
  %r2798 = getelementptr i64, ptr %r2728, i64 4
  %r2799 = load i64, ptr %r2798, align 8
  %r2800 = icmp eq i64 %r2799, %r2737
  %r2801 = getelementptr i64, ptr %r2728, i64 5
  %r2802 = load i64, ptr %r2801, align 8
  %r2803 = select i1 %r2800, i64 %r2802, i64 0
  %r2804 = getelementptr i64, ptr %r2728, i64 6
  %r2805 = load i64, ptr %r2804, align 8
  %r2806 = icmp eq i64 %r2805, %r2737
  %r2807 = getelementptr i64, ptr %r2728, i64 7
  %r2808 = load i64, ptr %r2807, align 8
  %r2809 = select i1 %r2806, i64 %r2808, i64 0
  %r2810 = getelementptr i64, ptr %r2728, i64 8
  %r2811 = load i64, ptr %r2810, align 8
  %r2812 = icmp eq i64 %r2811, %r2737
  %r2813 = getelementptr i64, ptr %r2728, i64 9
  %r2814 = load i64, ptr %r2813, align 8
  %r2815 = select i1 %r2812, i64 %r2814, i64 0
  %r2816 = getelementptr i64, ptr %r2728, i64 10
  %r2817 = load i64, ptr %r2816, align 8
  %r2818 = icmp eq i64 %r2817, %r2737
  %r2819 = getelementptr i64, ptr %r2728, i64 11
  %r2820 = load i64, ptr %r2819, align 8
  %r2821 = select i1 %r2818, i64 %r2820, i64 0
  %r2822 = or i1 %r2800, %r2806
  %r2823 = select i1 %r2800, i64 %r2803, i64 %r2809
  %r2824 = or i1 %r2812, %r2818
  %r2825 = select i1 %r2812, i64 %r2815, i64 %r2821
  %r2826 = or i1 %r2822, %r2824
  %r2827 = select i1 %r2822, i64 %r2823, i64 %r2825
  %r2828 = and i1 %r2738, %r2826
  br i1 %r2828, label %pic.way.load.544, label %pic.miss.call.537

pic.way.load.544:                                 ; preds = %pic.ways.543
  %r2829 = shl i64 %r2827, 3
  %r2830 = add nuw nsw i64 %r2708, 16
  %r2831 = add i64 %r2830, %r2829
  %r2832 = inttoptr i64 %r2831 to ptr
  %r2833 = load double, ptr %r2832, align 8
  %r2834 = bitcast double %r2833 to i64
  %r2835 = icmp eq i64 %r2834, 9222246136947933200
  br i1 %r2835, label %pic.miss.call.537, label %pic.way.live.545

pic.way.live.545:                                 ; preds = %pic.way.load.544
  br label %pic.merge.538

pget.throw_nullish.546:                           ; preds = %pget.recv_bad.519
  %r2844 = zext i1 %r2842 to i32
  %statepoint_token446 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2844, ptr @test_json_tape_batch_records_ts_.str.15.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.547:                       ; preds = %pget.recv_bad.519
  %r2845 = load double, ptr @test_json_tape_batch_records_ts_.str.15.handle, align 8
  %r2846 = bitcast double %r2845 to i64
  %r2847 = and i64 %r2846, 281474976710655
  %statepoint_token447 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2707, i64 %r2847, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.201074, ptr addrspace(1) %.71110, ptr addrspace(1) %.21, ptr addrspace(1) %.201024, ptr addrspace(1) %.201049) ]
  %r2848448 = call double @llvm.experimental.gc.result.f64(token %statepoint_token447)
  %rs4gc.s20.relocated449 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 0, i32 0) ; (%.201074, %.201074)
  %r138.1.relocated450 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 1, i32 1) ; (%.71110, %.71110)
  %rs4gc.s15.relocated451 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 2, i32 2) ; (%.21, %.21)
  %r131.0.base.relocated452 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 3, i32 3) ; (%.201024, %.201024)
  %r131.0.relocated453 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 3, i32 4) ; (%.201024, %.201049)
  br label %pget.recv_merge.521

pget.recv_sso.548:                                ; preds = %pget.recv_other.554
  %r2997 = lshr i64 %r2854, 40
  %r2998 = and i64 %r2997, 255
  %r2999 = uitofp nneg i64 %r2998 to double
  br label %pget.recv_merge.552

pget.recv_ok.549:                                 ; preds = %pget.recv_merge.521
  %r2865 = icmp eq i64 %r2856, 32767
  br i1 %r2865, label %pget.strlen_heap.553, label %pget.recv_obj.556

pget.recv_bad.550:                                ; preds = %pget.check_class_ref.555
  %r2989 = icmp eq i64 %r2854, 9222246136947933185
  %r2990 = icmp eq i64 %r2854, 9222246136947933186
  %r2991 = or i1 %r2989, %r2990
  br i1 %r2991, label %pget.throw_nullish.579, label %pget.recv_undef_return.580

pget.recv_class_ref.551:                          ; preds = %pget.check_class_ref.555
  %r2861 = load double, ptr @test_json_tape_batch_records_ts_.str.19.handle, align 8
  %r2862 = bitcast double %r2861 to i64
  %r2863 = and i64 %r2862, 281474976710655
  %statepoint_token454 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 367713371643969557, i64 %r2854, i64 %r2863, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.211075, ptr addrspace(1) %.81111, ptr addrspace(1) %.22, ptr addrspace(1) %.211025, ptr addrspace(1) %.211050) ]
  %r2864455 = call double @llvm.experimental.gc.result.f64(token %statepoint_token454)
  %rs4gc.s20.relocated456 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token454, i32 0, i32 0) ; (%.211075, %.211075)
  %r138.1.relocated457 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token454, i32 1, i32 1) ; (%.81111, %.81111)
  %rs4gc.s15.relocated458 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token454, i32 2, i32 2) ; (%.22, %.22)
  %r131.0.base.relocated459 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token454, i32 3, i32 3) ; (%.211025, %.211025)
  %r131.0.relocated460 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token454, i32 3, i32 4) ; (%.211025, %.211050)
  br label %pget.recv_merge.552

pget.recv_merge.552:                              ; preds = %pget.recv_undef_return.580, %pic.merge.571, %pget.strlen_heap.553, %pget.recv_class_ref.551, %pget.recv_sso.548
  %.101113 = phi ptr addrspace(1) [ %.81111, %pget.strlen_heap.553 ], [ %.111114, %pic.merge.571 ], [ %.81111, %pget.recv_sso.548 ], [ %r138.1.relocated457, %pget.recv_class_ref.551 ], [ %r138.1.relocated479, %pget.recv_undef_return.580 ]
  %.231077 = phi ptr addrspace(1) [ %.211075, %pget.strlen_heap.553 ], [ %.241078, %pic.merge.571 ], [ %.211075, %pget.recv_sso.548 ], [ %rs4gc.s20.relocated456, %pget.recv_class_ref.551 ], [ %rs4gc.s20.relocated478, %pget.recv_undef_return.580 ]
  %.231052 = phi ptr addrspace(1) [ %.211050, %pget.strlen_heap.553 ], [ %.241053, %pic.merge.571 ], [ %.211050, %pget.recv_sso.548 ], [ %r131.0.relocated460, %pget.recv_class_ref.551 ], [ %r131.0.relocated482, %pget.recv_undef_return.580 ]
  %.231027 = phi ptr addrspace(1) [ %.211025, %pget.strlen_heap.553 ], [ %.241028, %pic.merge.571 ], [ %.211025, %pget.recv_sso.548 ], [ %r131.0.base.relocated459, %pget.recv_class_ref.551 ], [ %r131.0.base.relocated481, %pget.recv_undef_return.580 ]
  %.24 = phi ptr addrspace(1) [ %.22, %pget.strlen_heap.553 ], [ %.25, %pic.merge.571 ], [ %.22, %pget.recv_sso.548 ], [ %rs4gc.s15.relocated458, %pget.recv_class_ref.551 ], [ %rs4gc.s15.relocated480, %pget.recv_undef_return.580 ]
  %r3005 = phi double [ %r2988, %pic.merge.571 ], [ %r2996477, %pget.recv_undef_return.580 ], [ %r2999, %pget.recv_sso.548 ], [ %r2864455, %pget.recv_class_ref.551 ], [ %r3004, %pget.strlen_heap.553 ]
  %r3006 = bitcast double %r3005 to i64
  %r3007 = lshr i64 %r3006, 48
  %r3008 = icmp eq i64 %r3007, 32766
  %r3009 = trunc i64 %r3006 to i32
  %r3010 = sitofp i32 %r3009 to double
  %r3011 = select i1 %r3008, double %r3010, double %r3005
  %r3018 = fcmp une double %r3011, 3.000000e+00
  %r3019 = select i1 %r3018, i64 9222246136947933188, i64 9222246136947933187
  %r3020 = bitcast i64 %r3019 to double
  %r3021 = icmp eq i64 %r3019, 9222246136947933188
  br i1 %r3021, label %if.then.581, label %if.else.582

pget.strlen_heap.553:                             ; preds = %pget.recv_ok.549
  %r3000 = icmp ult i64 %r2855, 4096
  %r3001 = inttoptr i64 %r2855 to ptr
  %r3002 = select i1 %r3000, ptr @perry_null_guard_zero_test_json_tape_batch_records_ts, ptr %r3001
  %r3003 = load i32, ptr %r3002, align 4
  %r3004 = uitofp i32 %r3003 to double
  br label %pget.recv_merge.552

pget.recv_other.554:                              ; preds = %pget.recv_merge.521
  %r2859 = icmp eq i64 %r2856, 32761
  br i1 %r2859, label %pget.recv_sso.548, label %pget.check_class_ref.555

pget.check_class_ref.555:                         ; preds = %pget.recv_other.554
  %r2860 = icmp eq i64 %r2856, 32766
  br i1 %r2860, label %pget.recv_class_ref.551, label %pget.recv_bad.550

pget.recv_obj.556:                                ; preds = %pget.recv_ok.549
  %r2866 = icmp ugt i64 %r2855, 1048575
  br i1 %r2866, label %pic.recv_hdr.572, label %pic.miss.cold.569

pic.hit.557:                                      ; preds = %pic.token.573
  %r2891 = getelementptr i64, ptr %r2876, i64 1
  %r2892 = load i64, ptr %r2891, align 8
  %r2893 = and i64 %r2892, 1073741824
  %r2894 = icmp ne i64 %r2893, 0
  br i1 %r2894, label %pic.hit.overflow.574, label %pic.hit.inline.575

pic.hit.live.558:                                 ; preds = %pic.hit.inline.575
  br label %pic.merge.571

pic.prefix.guard.559:                             ; preds = %pic.token.573
  %r2907 = getelementptr i64, ptr %r2876, i64 2
  %r2908 = load i64, ptr %r2907, align 8
  %r2909 = icmp ne i64 %r2908, 0
  br i1 %r2909, label %pic.prefix.meta.560, label %pic.miss.568

pic.prefix.meta.560:                              ; preds = %pic.prefix.guard.559
  %r2910 = add nuw nsw i64 %r2855, 8
  %r2911 = inttoptr i64 %r2910 to ptr
  %r2912 = load i64, ptr %r2911, align 8
  %r2913 = icmp ne i64 %r2912, 0
  br i1 %r2913, label %pic.prefix.token.561, label %pic.miss.568

pic.prefix.token.561:                             ; preds = %pic.prefix.meta.560
  %r2914 = inttoptr i64 %r2912 to ptr
  %r2915 = getelementptr i64, ptr %r2914, i64 6
  %r2916 = load i64, ptr %r2915, align 8
  %r2917 = icmp eq i64 %r2916, %r2908
  br i1 %r2917, label %pic.prefix.hit.562, label %pic.miss.568

pic.prefix.hit.562:                               ; preds = %pic.prefix.token.561
  %r2918 = getelementptr i64, ptr %r2876, i64 1
  %r2919 = load i64, ptr %r2918, align 8
  %r2920 = shl i64 %r2919, 3
  %r2921 = add nuw nsw i64 %r2855, 16
  %r2922 = add i64 %r2921, %r2920
  %r2923 = inttoptr i64 %r2922 to ptr
  %r2924 = load double, ptr %r2923, align 8
  br label %pic.merge.571

pic.desc.classify.563:                            ; preds = %pic.recv_hdr.572
  %r2880 = and i1 %r2870, %r2877
  br i1 %r2880, label %pic.desc.prefix.guard.564, label %pic.miss.cold.569

pic.desc.prefix.guard.564:                        ; preds = %pic.desc.classify.563
  %r2925 = getelementptr i64, ptr %r2876, i64 2
  %r2926 = load i64, ptr %r2925, align 8
  %r2927 = icmp ne i64 %r2926, 0
  br i1 %r2927, label %pic.desc.prefix.meta.565, label %pic.miss.cold.569

pic.desc.prefix.meta.565:                         ; preds = %pic.desc.prefix.guard.564
  %r2928 = add nuw nsw i64 %r2855, 8
  %r2929 = inttoptr i64 %r2928 to ptr
  %r2930 = load i64, ptr %r2929, align 8
  %r2931 = icmp ne i64 %r2930, 0
  br i1 %r2931, label %pic.desc.prefix.token.566, label %pic.miss.cold.569

pic.desc.prefix.token.566:                        ; preds = %pic.desc.prefix.meta.565
  %r2932 = inttoptr i64 %r2930 to ptr
  %r2933 = getelementptr i64, ptr %r2932, i64 6
  %r2934 = load i64, ptr %r2933, align 8
  %r2935 = icmp eq i64 %r2934, %r2926
  br i1 %r2935, label %pic.desc.prefix.hit.567, label %pic.miss.cold.569

pic.desc.prefix.hit.567:                          ; preds = %pic.desc.prefix.token.566
  %r2936 = getelementptr i64, ptr %r2876, i64 1
  %r2937 = load i64, ptr %r2936, align 8
  %r2938 = shl i64 %r2937, 3
  %r2939 = add nuw nsw i64 %r2855, 16
  %r2940 = add i64 %r2939, %r2938
  %r2941 = inttoptr i64 %r2940 to ptr
  %r2942 = load double, ptr %r2941, align 8
  br label %pic.merge.571

pic.miss.568:                                     ; preds = %pic.hit.inline.575, %pic.prefix.token.561, %pic.prefix.meta.560, %pic.prefix.guard.559
  %r2943 = getelementptr i64, ptr %r2876, i64 3
  %r2944 = load i64, ptr %r2943, align 8
  %r2945 = icmp sgt i64 %r2944, 0
  br i1 %r2945, label %pic.ways.576, label %pic.miss.call.570

pic.miss.cold.569:                                ; preds = %pic.desc.prefix.token.566, %pic.desc.prefix.meta.565, %pic.desc.prefix.guard.564, %pic.desc.classify.563, %pget.recv_obj.556
  br label %pic.miss.call.570

pic.miss.call.570:                                ; preds = %pic.way.load.577, %pic.ways.576, %pic.miss.cold.569, %pic.miss.568
  %r2984 = load double, ptr @test_json_tape_batch_records_ts_.str.19.handle, align 8
  %r2985 = bitcast double %r2984 to i64
  %r2986 = and i64 %r2985, 281474976710655
  %statepoint_token461 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r2855, i64 %r2986, ptr @perry_ic_test_json_tape_batch_records_ts__22, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.211075, ptr addrspace(1) %.81111, ptr addrspace(1) %.22, ptr addrspace(1) %.211025, ptr addrspace(1) %.211050) ]
  %r2987462 = call double @llvm.experimental.gc.result.f64(token %statepoint_token461)
  %rs4gc.s20.relocated463 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token461, i32 0, i32 0) ; (%.211075, %.211075)
  %r138.1.relocated464 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token461, i32 1, i32 1) ; (%.81111, %.81111)
  %rs4gc.s15.relocated465 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token461, i32 2, i32 2) ; (%.22, %.22)
  %r131.0.base.relocated466 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token461, i32 3, i32 3) ; (%.211025, %.211025)
  %r131.0.relocated467 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token461, i32 3, i32 4) ; (%.211025, %.211050)
  br label %pic.merge.571

pic.merge.571:                                    ; preds = %pic.way.live.578, %pic.hit.overflow.574, %pic.miss.call.570, %pic.desc.prefix.hit.567, %pic.prefix.hit.562, %pic.hit.live.558
  %.111114 = phi ptr addrspace(1) [ %r138.1.relocated471, %pic.hit.overflow.574 ], [ %r138.1.relocated464, %pic.miss.call.570 ], [ %.81111, %pic.way.live.578 ], [ %.81111, %pic.hit.live.558 ], [ %.81111, %pic.prefix.hit.562 ], [ %.81111, %pic.desc.prefix.hit.567 ]
  %.241078 = phi ptr addrspace(1) [ %rs4gc.s20.relocated470, %pic.hit.overflow.574 ], [ %rs4gc.s20.relocated463, %pic.miss.call.570 ], [ %.211075, %pic.way.live.578 ], [ %.211075, %pic.hit.live.558 ], [ %.211075, %pic.prefix.hit.562 ], [ %.211075, %pic.desc.prefix.hit.567 ]
  %.241053 = phi ptr addrspace(1) [ %r131.0.relocated474, %pic.hit.overflow.574 ], [ %r131.0.relocated467, %pic.miss.call.570 ], [ %.211050, %pic.way.live.578 ], [ %.211050, %pic.hit.live.558 ], [ %.211050, %pic.prefix.hit.562 ], [ %.211050, %pic.desc.prefix.hit.567 ]
  %.241028 = phi ptr addrspace(1) [ %r131.0.base.relocated473, %pic.hit.overflow.574 ], [ %r131.0.base.relocated466, %pic.miss.call.570 ], [ %.211025, %pic.way.live.578 ], [ %.211025, %pic.hit.live.558 ], [ %.211025, %pic.prefix.hit.562 ], [ %.211025, %pic.desc.prefix.hit.567 ]
  %.25 = phi ptr addrspace(1) [ %rs4gc.s15.relocated472, %pic.hit.overflow.574 ], [ %rs4gc.s15.relocated465, %pic.miss.call.570 ], [ %.22, %pic.way.live.578 ], [ %.22, %pic.hit.live.558 ], [ %.22, %pic.prefix.hit.562 ], [ %.22, %pic.desc.prefix.hit.567 ]
  %r2988 = phi double [ %r2904, %pic.hit.live.558 ], [ %r2899469, %pic.hit.overflow.574 ], [ %r2924, %pic.prefix.hit.562 ], [ %r2942, %pic.desc.prefix.hit.567 ], [ %r2981, %pic.way.live.578 ], [ %r2987462, %pic.miss.call.570 ]
  br label %pget.recv_merge.552

pic.recv_hdr.572:                                 ; preds = %pget.recv_obj.556
  %r2867 = sub nuw nsw i64 %r2855, 8
  %r2868 = inttoptr i64 %r2867 to ptr
  %r2869 = load i8, ptr %r2868, align 1
  %r2870 = icmp eq i8 %r2869, 2
  %r2871 = sub nuw nsw i64 %r2855, 6
  %r2872 = inttoptr i64 %r2871 to ptr
  %r2873 = load i16, ptr %r2872, align 2
  %r2874 = and i16 %r2873, 2048
  %r2875 = icmp eq i16 %r2874, 0
  %r2876 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__22, align 8
  %r2877 = icmp ne ptr %r2876, null
  %r2878 = and i1 %r2870, %r2875
  %r2879 = and i1 %r2878, %r2877
  br i1 %r2879, label %pic.token.573, label %pic.desc.classify.563

pic.token.573:                                    ; preds = %pic.recv_hdr.572
  %r2881 = add nuw nsw i64 %r2855, 4
  %r2882 = inttoptr i64 %r2881 to ptr
  %r2883 = load i32, ptr %r2882, align 4
  %r2884 = zext i32 %r2883 to i64
  %r2885 = or i64 %r2884, 4611686018427387904
  %r2886 = icmp ne i32 %r2883, 0
  %r2887 = getelementptr i64, ptr %r2876, i64 0
  %r2888 = load i64, ptr %r2887, align 8
  %r2889 = icmp eq i64 %r2885, %r2888
  %r2890 = and i1 %r2889, %r2886
  br i1 %r2890, label %pic.hit.557, label %pic.prefix.guard.559

pic.hit.overflow.574:                             ; preds = %pic.hit.557
  %r2895 = load double, ptr @test_json_tape_batch_records_ts_.str.19.handle, align 8
  %r2896 = bitcast double %r2895 to i64
  %r2897 = and i64 %r2896, 281474976710655
  %r2898 = trunc i64 %r2892 to i32
  %statepoint_token468 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r2855, i64 %r2897, i32 %r2898, ptr @perry_ic_test_json_tape_batch_records_ts__22, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.211075, ptr addrspace(1) %.81111, ptr addrspace(1) %.22, ptr addrspace(1) %.211025, ptr addrspace(1) %.211050) ]
  %r2899469 = call double @llvm.experimental.gc.result.f64(token %statepoint_token468)
  %rs4gc.s20.relocated470 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token468, i32 0, i32 0) ; (%.211075, %.211075)
  %r138.1.relocated471 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token468, i32 1, i32 1) ; (%.81111, %.81111)
  %rs4gc.s15.relocated472 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token468, i32 2, i32 2) ; (%.22, %.22)
  %r131.0.base.relocated473 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token468, i32 3, i32 3) ; (%.211025, %.211025)
  %r131.0.relocated474 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token468, i32 3, i32 4) ; (%.211025, %.211050)
  br label %pic.merge.571

pic.hit.inline.575:                               ; preds = %pic.hit.557
  %r2900 = shl i64 %r2892, 3
  %r2901 = add nuw nsw i64 %r2855, 16
  %r2902 = add i64 %r2901, %r2900
  %r2903 = inttoptr i64 %r2902 to ptr
  %r2904 = load double, ptr %r2903, align 8
  %r2905 = bitcast double %r2904 to i64
  %r2906 = icmp eq i64 %r2905, 9222246136947933200
  br i1 %r2906, label %pic.miss.568, label %pic.hit.live.558

pic.ways.576:                                     ; preds = %pic.miss.568
  %r2946 = getelementptr i64, ptr %r2876, i64 4
  %r2947 = load i64, ptr %r2946, align 8
  %r2948 = icmp eq i64 %r2947, %r2885
  %r2949 = getelementptr i64, ptr %r2876, i64 5
  %r2950 = load i64, ptr %r2949, align 8
  %r2951 = select i1 %r2948, i64 %r2950, i64 0
  %r2952 = getelementptr i64, ptr %r2876, i64 6
  %r2953 = load i64, ptr %r2952, align 8
  %r2954 = icmp eq i64 %r2953, %r2885
  %r2955 = getelementptr i64, ptr %r2876, i64 7
  %r2956 = load i64, ptr %r2955, align 8
  %r2957 = select i1 %r2954, i64 %r2956, i64 0
  %r2958 = getelementptr i64, ptr %r2876, i64 8
  %r2959 = load i64, ptr %r2958, align 8
  %r2960 = icmp eq i64 %r2959, %r2885
  %r2961 = getelementptr i64, ptr %r2876, i64 9
  %r2962 = load i64, ptr %r2961, align 8
  %r2963 = select i1 %r2960, i64 %r2962, i64 0
  %r2964 = getelementptr i64, ptr %r2876, i64 10
  %r2965 = load i64, ptr %r2964, align 8
  %r2966 = icmp eq i64 %r2965, %r2885
  %r2967 = getelementptr i64, ptr %r2876, i64 11
  %r2968 = load i64, ptr %r2967, align 8
  %r2969 = select i1 %r2966, i64 %r2968, i64 0
  %r2970 = or i1 %r2948, %r2954
  %r2971 = select i1 %r2948, i64 %r2951, i64 %r2957
  %r2972 = or i1 %r2960, %r2966
  %r2973 = select i1 %r2960, i64 %r2963, i64 %r2969
  %r2974 = or i1 %r2970, %r2972
  %r2975 = select i1 %r2970, i64 %r2971, i64 %r2973
  %r2976 = and i1 %r2886, %r2974
  br i1 %r2976, label %pic.way.load.577, label %pic.miss.call.570

pic.way.load.577:                                 ; preds = %pic.ways.576
  %r2977 = shl i64 %r2975, 3
  %r2978 = add nuw nsw i64 %r2855, 16
  %r2979 = add i64 %r2978, %r2977
  %r2980 = inttoptr i64 %r2979 to ptr
  %r2981 = load double, ptr %r2980, align 8
  %r2982 = bitcast double %r2981 to i64
  %r2983 = icmp eq i64 %r2982, 9222246136947933200
  br i1 %r2983, label %pic.miss.call.570, label %pic.way.live.578

pic.way.live.578:                                 ; preds = %pic.way.load.577
  br label %pic.merge.571

pget.throw_nullish.579:                           ; preds = %pget.recv_bad.550
  %r2992 = zext i1 %r2990 to i32
  %statepoint_token475 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2992, ptr @test_json_tape_batch_records_ts_.str.19.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.580:                       ; preds = %pget.recv_bad.550
  %r2993 = load double, ptr @test_json_tape_batch_records_ts_.str.19.handle, align 8
  %r2994 = bitcast double %r2993 to i64
  %r2995 = and i64 %r2994, 281474976710655
  %statepoint_token476 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2854, i64 %r2995, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.211075, ptr addrspace(1) %.81111, ptr addrspace(1) %.22, ptr addrspace(1) %.211025, ptr addrspace(1) %.211050) ]
  %r2996477 = call double @llvm.experimental.gc.result.f64(token %statepoint_token476)
  %rs4gc.s20.relocated478 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token476, i32 0, i32 0) ; (%.211075, %.211075)
  %r138.1.relocated479 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token476, i32 1, i32 1) ; (%.81111, %.81111)
  %rs4gc.s15.relocated480 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token476, i32 2, i32 2) ; (%.22, %.22)
  %r131.0.base.relocated481 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token476, i32 3, i32 3) ; (%.211025, %.211025)
  %r131.0.relocated482 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token476, i32 3, i32 4) ; (%.211025, %.211050)
  br label %pget.recv_merge.552

if.then.581:                                      ; preds = %pget.recv_merge.552
  %r3022 = load double, ptr @test_json_tape_batch_records_ts_.str.22.handle, align 8
  %statepoint_token483 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_error_new_from_value, i32 1, i32 0, double %r3022, i32 0, i32 0)
  %r3023484 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token483)
  %r3024 = or i64 %r3023484, 9222527611924643840
  %r3025 = bitcast i64 %r3024 to double
  %statepoint_token485 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r3025, i32 0, i32 0)
  unreachable

if.else.582:                                      ; preds = %pget.recv_merge.552
  br label %if.merge.583

if.merge.583:                                     ; preds = %if.else.582
  %r3027 = sitofp i32 %r139.0 to double
  %r3028 = fptosi double %r3027 to i64
  %r3030 = srem i64 %r3028, 6
  %r3031 = sitofp i64 %r3030 to double
  %r3032 = icmp eq i64 %r3030, 0
  %r3033 = fcmp olt double %r3027, 0.000000e+00
  %r3034 = and i1 %r3032, %r3033
  %r3035 = fneg double %r3031
  %r3036 = select i1 %r3034, double %r3035, double %r3031
  %r3037 = fcmp oeq double %r3036, 0.000000e+00
  %r3038 = select i1 %r3037, i64 9222246136947933188, i64 9222246136947933187
  %r3039 = bitcast i64 %r3038 to double
  %r3040 = icmp eq i64 %r3038, 9222246136947933188
  br i1 %r3040, label %if.then.584, label %if.else.585

if.then.584:                                      ; preds = %if.merge.583
  %r3041.rs4i = ptrtoint ptr addrspace(1) %.231077 to i64
  %r3041.rs4o = call i64 asm "", "=r,0"(i64 %r3041.rs4i) #7
  %r3041 = bitcast i64 %r3041.rs4o to double
  %r3042 = bitcast double %r3041 to i64
  %r3043.rs4i = ptrtoint ptr addrspace(1) %.231052 to i64
  %r3043.rs4o = call i64 asm "", "=r,0"(i64 %r3043.rs4i) #7
  %r3043 = bitcast i64 %r3043.rs4o to double
  %r3044 = bitcast double %r3043 to i64
  %r3045 = and i64 %r3044, 281474976710655
  %r3046 = sub nsw i64 %r3045, 8
  %r3047 = inttoptr i64 %r3046 to ptr
  %r3048 = load i8, ptr %r3047, align 1
  %r3049 = icmp ne i8 %r3048, 1
  %r3050 = sub nsw i64 %r3045, 7
  %r3051 = inttoptr i64 %r3050 to ptr
  %r3052 = load i8, ptr %r3051, align 1
  %r3053 = and i8 %r3052, -128
  %r3054 = icmp ne i8 %r3053, 0
  %r3055 = or i1 %r3049, %r3054
  br i1 %r3054, label %apush.fwd.587, label %apush.elements.588

if.else.585:                                      ; preds = %if.merge.583
  br label %if.merge.586

if.merge.586:                                     ; preds = %apush.merge.593, %if.else.585
  %.121115 = phi ptr addrspace(1) [ %.131116, %apush.merge.593 ], [ %.101113, %if.else.585 ]
  %.251079 = phi ptr addrspace(1) [ %.261080, %apush.merge.593 ], [ %.231077, %if.else.585 ]
  %.26 = phi ptr addrspace(1) [ %.27, %apush.merge.593 ], [ %.24, %if.else.585 ]
  %r131.1.base = phi ptr addrspace(1) [ %r131.2.base, %apush.merge.593 ], [ %.231027, %if.else.585 ], !is_base_value !0
  %r131.1 = phi ptr addrspace(1) [ %r131.2, %apush.merge.593 ], [ %.231052, %if.else.585 ]
  %r3131 = sitofp i32 %r139.0 to double
  %r3132 = fptosi double %r3131 to i64
  %r3134 = srem i64 %r3132, 4
  %r3135 = sitofp i64 %r3134 to double
  %r3136 = icmp eq i64 %r3134, 0
  %r3137 = fcmp olt double %r3131, 0.000000e+00
  %r3138 = and i1 %r3136, %r3137
  %r3139 = fneg double %r3135
  %r3140 = select i1 %r3138, double %r3139, double %r3135
  %r3141 = fcmp oeq double %r3140, 0.000000e+00
  %r3142 = select i1 %r3141, i64 9222246136947933188, i64 9222246136947933187
  %r3143 = bitcast i64 %r3142 to double
  %r3144 = icmp eq i64 %r3142, 9222246136947933188
  br i1 %r3144, label %if.then.598, label %if.else.599

apush.fwd.587:                                    ; preds = %apush.elements.check.589, %if.then.584
  %statepoint_token486 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r3045, double %r3041, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.231077, ptr addrspace(1) %.101113, ptr addrspace(1) %.24) ]
  %r3082487 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token486)
  %rs4gc.s20.relocated488 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token486, i32 0, i32 0) ; (%.231077, %.231077)
  %r138.1.relocated489 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token486, i32 1, i32 1) ; (%.101113, %.101113)
  %rs4gc.s15.relocated490 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token486, i32 2, i32 2) ; (%.24, %.24)
  %r3083 = or i64 %r3082487, 9222527611924643840
  %r3084 = bitcast i64 %r3083 to double
  %rs4gc.b28 = bitcast double %r3084 to i64
  %rs4gc.s28 = inttoptr i64 %rs4gc.b28 to ptr addrspace(1)
  br label %apush.merge.593

apush.elements.588:                               ; preds = %if.then.584
  %r3057 = add nuw nsw i64 %r3045, 8
  %r3058 = inttoptr i64 %r3057 to ptr
  %r3059 = load i64, ptr %r3058, align 8
  %r3060 = icmp ne i64 %r3059, 0
  %r3061 = icmp eq i8 %r3048, 2
  %r3062 = and i1 %r3061, %r3060
  %r3063 = select i1 %r3062, i64 %r3059, i64 %r3045
  %r3064 = inttoptr i64 %r3063 to ptr
  %r3065 = getelementptr i64, ptr %r3064, i64 12
  %r3066 = load i64, ptr %r3065, align 8
  %r3067 = icmp ne i64 %r3066, 0
  %r3068 = and i1 %r3062, %r3067
  %r3069 = select i1 %r3068, i64 %r3066, i64 %r3045
  %r3056 = icmp eq i8 %r3048, 1
  br i1 %r3056, label %apush.nofwd.590, label %apush.elements.check.589

apush.elements.check.589:                         ; preds = %apush.elements.588
  %r3070 = icmp ne i64 %r3069, 0
  %r3071 = sub i64 %r3069, 8
  %r3072 = inttoptr i64 %r3071 to ptr
  %r3073 = load i8, ptr %r3072, align 1
  %r3074 = icmp eq i8 %r3073, 1
  %r3075 = sub i64 %r3069, 7
  %r3076 = inttoptr i64 %r3075 to ptr
  %r3077 = load i8, ptr %r3076, align 1
  %r3078 = and i8 %r3077, -128
  %r3079 = icmp eq i8 %r3078, 0
  %r3080 = and i1 %r3070, %r3074
  %r3081 = and i1 %r3080, %r3079
  br i1 %r3081, label %apush.nofwd.590, label %apush.fwd.587

apush.nofwd.590:                                  ; preds = %apush.elements.check.589, %apush.elements.588
  %r3085 = phi i64 [ %r3045, %apush.elements.588 ], [ %r3069, %apush.elements.check.589 ]
  %r3086 = sub i64 %r3085, 6
  %r3087 = inttoptr i64 %r3086 to ptr
  %r3088 = load i16, ptr %r3087, align 2
  %r3089 = and i16 %r3088, 1031
  %r3090 = icmp eq i16 %r3089, 0
  %r3091 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r3092 = icmp eq i8 %r3091, 0
  %r3093 = and i1 %r3090, %r3092
  %r3094 = icmp ult i64 %r3085, 4096
  %r3095 = inttoptr i64 %r3085 to ptr
  %r3096 = select i1 %r3094, ptr @perry_null_guard_zero_test_json_tape_batch_records_ts, ptr %r3095
  %r3097 = load i32, ptr %r3096, align 4
  %r3098 = add i64 %r3085, 4
  %r3099 = inttoptr i64 %r3098 to ptr
  %r3100 = load i32, ptr %r3099, align 4
  %r3101 = icmp ult i32 %r3097, %r3100
  %r3102 = and i1 %r3101, %r3093
  br i1 %r3102, label %apush.inbounds.591, label %apush.realloc.592

apush.inbounds.591:                               ; preds = %apush.nofwd.590
  %r3103 = icmp ult i64 %r3085, 4096
  %r3104 = inttoptr i64 %r3085 to ptr
  %r3105 = select i1 %r3103, ptr @perry_null_guard_zero_test_json_tape_batch_records_ts, ptr %r3104
  %r3106 = load i32, ptr %r3105, align 4
  %r3107 = zext i32 %r3106 to i64
  %r3108 = shl nuw nsw i64 %r3107, 3
  %r3109 = add nuw nsw i64 %r3108, 8
  %r3110 = add i64 %r3085, %r3109
  %r3111 = inttoptr i64 %r3110 to ptr
  store double %r3041, ptr %r3111, align 8
  %r3112 = lshr i64 %r3042, 48
  %r3113 = icmp eq i64 %r3112, 32765
  %r3114 = and i16 %r3088, -1920
  %r3115 = icmp eq i16 %r3114, -24576
  %r3116 = and i1 %r3113, %r3115
  br i1 %r3116, label %apush.pointer_layout.done.595, label %apush.pointer_layout.bookkeeping.594

apush.realloc.592:                                ; preds = %apush.nofwd.590
  %statepoint_token491 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r3045, double %r3041, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.231077, ptr addrspace(1) %.101113, ptr addrspace(1) %.24) ]
  %r3127492 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token491)
  %rs4gc.s20.relocated493 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token491, i32 0, i32 0) ; (%.231077, %.231077)
  %r138.1.relocated494 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token491, i32 1, i32 1) ; (%.101113, %.101113)
  %rs4gc.s15.relocated495 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token491, i32 2, i32 2) ; (%.24, %.24)
  %r3128 = or i64 %r3127492, 9222527611924643840
  %r3129 = bitcast i64 %r3128 to double
  %rs4gc.b29 = bitcast double %r3129 to i64
  %rs4gc.s29 = inttoptr i64 %rs4gc.b29 to ptr addrspace(1)
  br label %apush.merge.593

apush.merge.593:                                  ; preds = %apush.barrier.done.597, %apush.realloc.592, %apush.fwd.587
  %.131116 = phi ptr addrspace(1) [ %r138.1.relocated489, %apush.fwd.587 ], [ %.101113, %apush.barrier.done.597 ], [ %r138.1.relocated494, %apush.realloc.592 ]
  %.261080 = phi ptr addrspace(1) [ %rs4gc.s20.relocated488, %apush.fwd.587 ], [ %.231077, %apush.barrier.done.597 ], [ %rs4gc.s20.relocated493, %apush.realloc.592 ]
  %.27 = phi ptr addrspace(1) [ %rs4gc.s15.relocated490, %apush.fwd.587 ], [ %.24, %apush.barrier.done.597 ], [ %rs4gc.s15.relocated495, %apush.realloc.592 ]
  %r131.2.base = phi ptr addrspace(1) [ %rs4gc.s28, %apush.fwd.587 ], [ %.231027, %apush.barrier.done.597 ], [ %rs4gc.s29, %apush.realloc.592 ], !is_base_value !0
  %r131.2 = phi ptr addrspace(1) [ %rs4gc.s28, %apush.fwd.587 ], [ %.231052, %apush.barrier.done.597 ], [ %rs4gc.s29, %apush.realloc.592 ]
  br label %if.merge.586

apush.pointer_layout.bookkeeping.594:             ; preds = %apush.inbounds.591
  call void @js_string_addref_if_heap_string(double %r3041) #7
  %r5972.rs4i = ptrtoint ptr addrspace(1) %.231077 to i64
  %r5972.rs4o = call i64 asm "", "=r,0"(i64 %r5972.rs4i) #7
  %r5972 = bitcast i64 %r5972.rs4o to double
  %r5973 = bitcast double %r5972 to i64
  call void @js_gc_note_slot_layout(i64 %r3085, i32 %r3106, i64 %r5973) #7
  %r5970.rs4i = ptrtoint ptr addrspace(1) %.231077 to i64
  %r5970.rs4o = call i64 asm "", "=r,0"(i64 %r5970.rs4i) #7
  %r5970 = bitcast i64 %r5970.rs4o to double
  %r5971 = bitcast double %r5970 to i64
  call void @js_array_note_numeric_write(i64 %r3085, i64 %r5971) #7
  br label %apush.pointer_layout.done.595

apush.pointer_layout.done.595:                    ; preds = %apush.pointer_layout.bookkeeping.594, %apush.inbounds.591
  %r3117 = sub i64 %r3085, 7
  %r3118 = inttoptr i64 %r3117 to ptr
  %r3119 = load i8, ptr %r3118, align 1
  %r3120 = and i8 %r3119, 32
  %r3121 = icmp ne i8 %r3120, 0
  %r3122 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3123 = icmp ne i32 %r3122, 0
  %r3124 = or i1 %r3121, %r3123
  br i1 %r3124, label %apush.barrier.596, label %apush.barrier.done.597

apush.barrier.596:                                ; preds = %apush.pointer_layout.done.595
  %r5968.rs4i = ptrtoint ptr addrspace(1) %.231077 to i64
  %r5968.rs4o = call i64 asm "", "=r,0"(i64 %r5968.rs4i) #7
  %r5968 = bitcast i64 %r5968.rs4o to double
  %r5969 = bitcast double %r5968 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r3085, i64 %r3110, i64 %r5969) #7
  br label %apush.barrier.done.597

apush.barrier.done.597:                           ; preds = %apush.barrier.596, %apush.pointer_layout.done.595
  %r3125 = add i32 %r3106, 1
  %r3126 = inttoptr i64 %r3085 to ptr
  store i32 %r3125, ptr %r3126, align 4
  br label %apush.merge.593

if.then.598:                                      ; preds = %if.merge.586
  %statepoint_token496 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_collect, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r131.1.base, ptr addrspace(1) %.26, ptr addrspace(1) %.251079, ptr addrspace(1) %.121115, ptr addrspace(1) %r131.1) ]
  %r131.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token496, i32 0, i32 0) ; (%r131.1.base, %r131.1.base)
  %rs4gc.s15.relocated497 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token496, i32 1, i32 1) ; (%.26, %.26)
  %rs4gc.s20.relocated498 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token496, i32 2, i32 2) ; (%.251079, %.251079)
  %r138.1.relocated499 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token496, i32 3, i32 3) ; (%.121115, %.121115)
  %r131.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token496, i32 0, i32 4) ; (%r131.1.base, %r131.1)
  br label %if.merge.600

if.else.599:                                      ; preds = %if.merge.586
  br label %if.merge.600

if.merge.600:                                     ; preds = %if.else.599, %if.then.598
  %.01131 = phi ptr addrspace(1) [ %r131.1.relocated, %if.then.598 ], [ %r131.1, %if.else.599 ]
  %.01119 = phi ptr addrspace(1) [ %r131.1.base.relocated, %if.then.598 ], [ %r131.1.base, %if.else.599 ]
  %.141117 = phi ptr addrspace(1) [ %r138.1.relocated499, %if.then.598 ], [ %.121115, %if.else.599 ]
  %.271081 = phi ptr addrspace(1) [ %rs4gc.s20.relocated498, %if.then.598 ], [ %.251079, %if.else.599 ]
  %.28 = phi ptr addrspace(1) [ %rs4gc.s15.relocated497, %if.then.598 ], [ %.26, %if.else.599 ]
  %r3145.rs4i = ptrtoint ptr addrspace(1) %.141117 to i64
  %r3145.rs4o = call i64 asm "", "=r,0"(i64 %r3145.rs4i) #7
  %r3145 = bitcast i64 %r3145.rs4o to double
  %r3146 = bitcast double %r3145 to i64
  %rs4gc.s30 = inttoptr i64 %r3146 to ptr addrspace(1)
  %r3147.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s30 to i64
  %r3147 = call i64 asm "", "=r,0"(i64 %r3147.rs4i) #7
  %r3148 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3149 = icmp ne i32 %r3148, 0
  br i1 %r3149, label %shadow.root.barrier.601, label %shadow.root.barrier.done.602

shadow.root.barrier.601:                          ; preds = %if.merge.600
  call void @js_write_barrier_root_nanbox(i64 %r3147) #7
  br label %shadow.root.barrier.done.602

shadow.root.barrier.done.602:                     ; preds = %shadow.root.barrier.601, %if.merge.600
  %r3150.rs4i = ptrtoint ptr addrspace(1) %.271081 to i64
  %r3150.rs4o = call i64 asm "", "=r,0"(i64 %r3150.rs4i) #7
  %r3150 = bitcast i64 %r3150.rs4o to double
  %r3151 = bitcast double %r3150 to i64
  %r3152 = and i64 %r3151, 281474976710655
  %r3153 = and i64 %r3151, -281474976710656
  %r3154 = icmp eq i64 %r3153, 9222527611924643840
  %r3155 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r3156 = icmp eq i64 %r3155, 0
  %r3157 = icmp ugt i64 %r3152, 1048575
  %r3158 = icmp ult i64 %r3152, 140737488355328
  %r3159 = and i1 %r3157, %r3158
  %r3160 = and i1 %r3154, %r3156
  %r3161 = and i1 %r3160, %r3159
  br i1 %r3161, label %tav.get.brand.607, label %tav.get.slow.605

tav.get.fast.603:                                 ; preds = %tav.get.brand.607
  %r3178 = bitcast double %r3150 to i64
  %r3179 = and i64 %r3178, 281474976710655
  %r3180 = add nuw nsw i64 %r3179, 8
  %r3181 = inttoptr i64 %r3180 to ptr
  %r3182 = load i8, ptr %r3181, align 1
  %r3183 = zext i8 %r3182 to i64
  %r3187 = inttoptr i64 %r3179 to ptr
  %r3188 = load i32, ptr %r3187, align 4
  %r3189 = zext i32 %r3188 to i64
  %r3190 = icmp ult i64 1, %r3189
  %r3191 = and i1 true, %r3190
  br i1 %r3191, label %tav.get.load.604, label %tav.get.slow.605

tav.get.load.604:                                 ; preds = %tav.get.fast.603
  %r3192 = add nuw nsw i64 %r3179, 16
  %r3193 = icmp eq i64 %r3183, 0
  br i1 %r3193, label %tav.k.i8.608, label %tav.kd1.616

tav.get.slow.605:                                 ; preds = %tav.get.brand.607, %tav.get.fast.603, %shadow.root.barrier.done.602
  %r3244 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__23, align 8
  %r3245 = icmp ne ptr %r3244, null
  %r3246 = select i1 %r3245, ptr %r3244, ptr @perry_ic_test_json_tape_batch_records_ts__23
  %r3247 = bitcast double %r3150 to i64
  %r3248 = and i64 %r3247, 281474976710655
  %r3249 = and i64 %r3247, -281474976710656
  %r3250 = icmp eq i64 %r3249, 9222527611924643840
  %r3251 = icmp uge i64 %r3248, 2199023255552
  %r3252 = icmp ult i64 %r3248, 140737488355328
  %r3255 = and i1 %r3250, %r3251
  %r3256 = and i1 %r3255, %r3252
  br i1 %r3256, label %arrlike.ic.header.623, label %arrlike.ic.miss.642

tav.get.merge.606:                                ; preds = %arrlike.elem.value.648, %arrlike.ic.miss.642, %arrlike.ic.spill_load.641, %arrlike.ic.inline.638, %arrlike.ic.array_load.626, %tav.k.f64.615, %tav.k.f32.614, %tav.k.u32.613, %tav.k.i32.612, %tav.k.u16.611, %tav.k.i16.610, %tav.k.u8.609, %tav.k.i8.608
  %.01143 = phi ptr addrspace(1) [ %rs4gc.s30, %tav.k.i8.608 ], [ %rs4gc.s30, %tav.k.u8.609 ], [ %rs4gc.s30, %tav.k.i16.610 ], [ %rs4gc.s30, %tav.k.u16.611 ], [ %rs4gc.s30, %tav.k.i32.612 ], [ %rs4gc.s30, %tav.k.u32.613 ], [ %rs4gc.s30, %tav.k.f32.614 ], [ %rs4gc.s30, %tav.k.f64.615 ], [ %rs4gc.s30, %arrlike.ic.array_load.626 ], [ %rs4gc.s30.relocated, %arrlike.ic.miss.642 ], [ %rs4gc.s30, %arrlike.elem.value.648 ], [ %rs4gc.s30, %arrlike.ic.inline.638 ], [ %rs4gc.s30, %arrlike.ic.spill_load.641 ]
  %.11132 = phi ptr addrspace(1) [ %.01131, %tav.k.i8.608 ], [ %.01131, %tav.k.u8.609 ], [ %.01131, %tav.k.i16.610 ], [ %.01131, %tav.k.u16.611 ], [ %.01131, %tav.k.i32.612 ], [ %.01131, %tav.k.u32.613 ], [ %.01131, %tav.k.f32.614 ], [ %.01131, %tav.k.f64.615 ], [ %.01131, %arrlike.ic.array_load.626 ], [ %r131.1.relocated505, %arrlike.ic.miss.642 ], [ %.01131, %arrlike.elem.value.648 ], [ %.01131, %arrlike.ic.inline.638 ], [ %.01131, %arrlike.ic.spill_load.641 ]
  %.11120 = phi ptr addrspace(1) [ %.01119, %tav.k.i8.608 ], [ %.01119, %tav.k.u8.609 ], [ %.01119, %tav.k.i16.610 ], [ %.01119, %tav.k.u16.611 ], [ %.01119, %tav.k.i32.612 ], [ %.01119, %tav.k.u32.613 ], [ %.01119, %tav.k.f32.614 ], [ %.01119, %tav.k.f64.615 ], [ %.01119, %arrlike.ic.array_load.626 ], [ %r131.1.base.relocated502, %arrlike.ic.miss.642 ], [ %.01119, %arrlike.elem.value.648 ], [ %.01119, %arrlike.ic.inline.638 ], [ %.01119, %arrlike.ic.spill_load.641 ]
  %.281082 = phi ptr addrspace(1) [ %.271081, %tav.k.i8.608 ], [ %.271081, %tav.k.u8.609 ], [ %.271081, %tav.k.i16.610 ], [ %.271081, %tav.k.u16.611 ], [ %.271081, %tav.k.i32.612 ], [ %.271081, %tav.k.u32.613 ], [ %.271081, %tav.k.f32.614 ], [ %.271081, %tav.k.f64.615 ], [ %.271081, %arrlike.ic.array_load.626 ], [ %rs4gc.s20.relocated504, %arrlike.ic.miss.642 ], [ %.271081, %arrlike.elem.value.648 ], [ %.271081, %arrlike.ic.inline.638 ], [ %.271081, %arrlike.ic.spill_load.641 ]
  %.29 = phi ptr addrspace(1) [ %.28, %tav.k.i8.608 ], [ %.28, %tav.k.u8.609 ], [ %.28, %tav.k.i16.610 ], [ %.28, %tav.k.u16.611 ], [ %.28, %tav.k.i32.612 ], [ %.28, %tav.k.u32.613 ], [ %.28, %tav.k.f32.614 ], [ %.28, %tav.k.f64.615 ], [ %.28, %arrlike.ic.array_load.626 ], [ %rs4gc.s15.relocated503, %arrlike.ic.miss.642 ], [ %.28, %arrlike.elem.value.648 ], [ %.28, %arrlike.ic.inline.638 ], [ %.28, %arrlike.ic.spill_load.641 ]
  %r3417 = phi double [ %r3206, %tav.k.i8.608 ], [ %r3212, %tav.k.u8.609 ], [ %r3218, %tav.k.i16.610 ], [ %r3224, %tav.k.u16.611 ], [ %r3229, %tav.k.i32.612 ], [ %r3234, %tav.k.u32.613 ], [ %r3239, %tav.k.f32.614 ], [ %r3243, %tav.k.f64.615 ], [ %r3300, %arrlike.elem.value.648 ], [ %r3328, %arrlike.ic.array_load.626 ], [ %r3398, %arrlike.ic.inline.638 ], [ %r3415, %arrlike.ic.spill_load.641 ], [ %r3416501, %arrlike.ic.miss.642 ]
  %r3418 = bitcast double %r3417 to i64
  %r3419 = and i64 %r3418, 281474976710655
  %r3420 = lshr i64 %r3418, 48
  %r3421 = and i64 %r3420, 65533
  %r3422 = icmp eq i64 %r3421, 32765
  br i1 %r3422, label %pget.recv_ok.651, label %pget.recv_other.655

tav.get.brand.607:                                ; preds = %shadow.root.barrier.done.602
  %r3162 = bitcast double %r3150 to i64
  %r3163 = and i64 %r3162, 281474976710655
  %r3164 = sub nsw i64 %r3163, 8
  %r3165 = inttoptr i64 %r3164 to ptr
  %r3166 = load i8, ptr %r3165, align 1
  %r3167 = icmp eq i8 %r3166, 11
  %r3168 = add nuw nsw i64 %r3163, 8
  %r3169 = inttoptr i64 %r3168 to ptr
  %r3170 = load i8, ptr %r3169, align 1
  %r3171 = zext i8 %r3170 to i64
  %r3172 = icmp ule i64 %r3171, 8
  %r3175 = and i1 %r3167, %r3172
  br i1 %r3175, label %tav.get.fast.603, label %tav.get.slow.605

tav.k.i8.608:                                     ; preds = %tav.get.load.604
  %r3202 = add nuw nsw i64 %r3192, 1
  %r3203 = inttoptr i64 %r3202 to ptr
  %r3204 = load i8, ptr %r3203, align 1
  %r3205 = sext i8 %r3204 to i32
  %r3206 = sitofp i32 %r3205 to double
  br label %tav.get.merge.606

tav.k.u8.609:                                     ; preds = %tav.kd7.622, %tav.kd1.616
  %r3208 = add nuw nsw i64 %r3192, 1
  %r3209 = inttoptr i64 %r3208 to ptr
  %r3210 = load i8, ptr %r3209, align 1
  %r3211 = zext i8 %r3210 to i32
  %r3212 = uitofp nneg i32 %r3211 to double
  br label %tav.get.merge.606

tav.k.i16.610:                                    ; preds = %tav.kd2.617
  %r3214 = add nuw nsw i64 %r3192, 2
  %r3215 = inttoptr i64 %r3214 to ptr
  %r3216 = load i16, ptr %r3215, align 2
  %r3217 = sext i16 %r3216 to i32
  %r3218 = sitofp i32 %r3217 to double
  br label %tav.get.merge.606

tav.k.u16.611:                                    ; preds = %tav.kd3.618
  %r3220 = add nuw nsw i64 %r3192, 2
  %r3221 = inttoptr i64 %r3220 to ptr
  %r3222 = load i16, ptr %r3221, align 2
  %r3223 = zext i16 %r3222 to i32
  %r3224 = uitofp nneg i32 %r3223 to double
  br label %tav.get.merge.606

tav.k.i32.612:                                    ; preds = %tav.kd4.619
  %r3226 = add nuw nsw i64 %r3192, 4
  %r3227 = inttoptr i64 %r3226 to ptr
  %r3228 = load i32, ptr %r3227, align 4
  %r3229 = sitofp i32 %r3228 to double
  br label %tav.get.merge.606

tav.k.u32.613:                                    ; preds = %tav.kd5.620
  %r3231 = add nuw nsw i64 %r3192, 4
  %r3232 = inttoptr i64 %r3231 to ptr
  %r3233 = load i32, ptr %r3232, align 4
  %r3234 = uitofp i32 %r3233 to double
  br label %tav.get.merge.606

tav.k.f32.614:                                    ; preds = %tav.kd6.621
  %r3236 = add nuw nsw i64 %r3192, 4
  %r3237 = inttoptr i64 %r3236 to ptr
  %r3238 = load float, ptr %r3237, align 4
  %r3239 = fpext float %r3238 to double
  br label %tav.get.merge.606

tav.k.f64.615:                                    ; preds = %tav.kd7.622
  %r3241 = add nuw nsw i64 %r3192, 8
  %r3242 = inttoptr i64 %r3241 to ptr
  %r3243 = load double, ptr %r3242, align 8
  br label %tav.get.merge.606

tav.kd1.616:                                      ; preds = %tav.get.load.604
  %r3194 = icmp eq i64 %r3183, 1
  br i1 %r3194, label %tav.k.u8.609, label %tav.kd2.617

tav.kd2.617:                                      ; preds = %tav.kd1.616
  %r3195 = icmp eq i64 %r3183, 2
  br i1 %r3195, label %tav.k.i16.610, label %tav.kd3.618

tav.kd3.618:                                      ; preds = %tav.kd2.617
  %r3196 = icmp eq i64 %r3183, 3
  br i1 %r3196, label %tav.k.u16.611, label %tav.kd4.619

tav.kd4.619:                                      ; preds = %tav.kd3.618
  %r3197 = icmp eq i64 %r3183, 4
  br i1 %r3197, label %tav.k.i32.612, label %tav.kd5.620

tav.kd5.620:                                      ; preds = %tav.kd4.619
  %r3198 = icmp eq i64 %r3183, 5
  br i1 %r3198, label %tav.k.u32.613, label %tav.kd6.621

tav.kd6.621:                                      ; preds = %tav.kd5.620
  %r3199 = icmp eq i64 %r3183, 6
  br i1 %r3199, label %tav.k.f32.614, label %tav.kd7.622

tav.kd7.622:                                      ; preds = %tav.kd6.621
  %r3200 = icmp eq i64 %r3183, 7
  br i1 %r3200, label %tav.k.f64.615, label %tav.k.u8.609

arrlike.ic.header.623:                            ; preds = %tav.get.slow.605
  %r3262 = sub nuw nsw i64 %r3248, 8
  %r3263 = inttoptr i64 %r3262 to ptr
  %r3264 = load i8, ptr %r3263, align 1
  %r3266 = sub nuw nsw i64 %r3248, 7
  %r3267 = inttoptr i64 %r3266 to ptr
  %r3268 = load i8, ptr %r3267, align 1
  %r3269 = and i8 %r3268, -128
  %r3270 = icmp eq i8 %r3269, 0
  %r3271 = and i1 true, %r3270
  br i1 %r3271, label %arrlike.ic.brand.624, label %arrlike.ic.miss.642

arrlike.ic.brand.624:                             ; preds = %arrlike.ic.header.623
  %r3265 = icmp eq i8 %r3264, 1
  br i1 %r3265, label %arrlike.ic.array_guard.625, label %arrlike.elem.kind.643

arrlike.ic.array_guard.625:                       ; preds = %arrlike.ic.brand.624
  %r3303 = sub nuw nsw i64 %r3248, 6
  %r3304 = inttoptr i64 %r3303 to ptr
  %r3305 = load i16, ptr %r3304, align 2
  %r3306 = and i16 %r3305, 1024
  %r3307 = icmp eq i16 %r3306, 0
  %r3308 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r3309 = icmp eq i8 %r3308, 0
  %r3310 = inttoptr i64 %r3248 to ptr
  %r3311 = load i32, ptr %r3310, align 4
  %r3312 = add nuw nsw i64 %r3248, 4
  %r3313 = inttoptr i64 %r3312 to ptr
  %r3314 = load i32, ptr %r3313, align 4
  %r3315 = zext i32 %r3311 to i64
  %r3316 = zext i32 %r3314 to i64
  %r3317 = icmp ult i64 1, %r3315
  %r3318 = icmp ule i64 %r3315, %r3316
  %r3319 = and i1 %r3307, %r3309
  %r3320 = and i1 %r3319, %r3317
  %r3321 = and i1 %r3320, %r3318
  br i1 %r3321, label %arrlike.ic.array_load.626, label %arrlike.ic.miss.642

arrlike.ic.array_load.626:                        ; preds = %arrlike.ic.array_guard.625
  %r3323 = getelementptr inbounds nuw i64, ptr %r3310, i64 2
  %r3324 = load double, ptr %r3323, align 8
  %r3325 = bitcast double %r3324 to i64
  %r3326 = icmp eq i64 %r3325, 9222246136947933200
  %r3328 = select i1 %r3326, double 0x7FFC000000000001, double %r3324
  br label %tav.get.merge.606

arrlike.ic.shape.627:                             ; preds = %arrlike.elem.store.645, %arrlike.elem.meta.644
  %r3330 = inttoptr i64 %r3248 to ptr
  %r3331 = load i32, ptr %r3330, align 4
  %r3332 = add nuw nsw i64 %r3248, 4
  %r3333 = inttoptr i64 %r3332 to ptr
  %r3334 = load i32, ptr %r3333, align 4
  %r3335 = zext i32 %r3331 to i64
  %r3336 = zext i32 %r3334 to i64
  %r3337 = shl nuw i64 %r3335, 32
  %r3338 = or i64 %r3337, %r3336
  %r3339 = getelementptr i64, ptr %r3246, i64 0
  %r3340 = load i64, ptr %r3339, align 8
  %r3341 = icmp ne i64 %r3340, 0
  %r3342 = and i1 true, %r3341
  br i1 %r3342, label %arrlike.ic.identity.628, label %arrlike.ic.miss.642

arrlike.ic.identity.628:                          ; preds = %arrlike.ic.shape.627
  %r3343 = and i64 %r3340, -9223372036854775808
  %5 = icmp slt i64 %r3340, 0
  br i1 %5, label %arrlike.ic.family_meta.630, label %arrlike.ic.exact.629

arrlike.ic.exact.629:                             ; preds = %arrlike.ic.identity.628
  %r3345 = icmp eq i64 %r3338, %r3340
  br i1 %r3345, label %arrlike.ic.bounds.632, label %arrlike.ic.miss.642

arrlike.ic.family_meta.630:                       ; preds = %arrlike.ic.identity.628
  %r3346 = add nuw nsw i64 %r3248, 8
  %r3347 = inttoptr i64 %r3346 to ptr
  %r3348 = load i64, ptr %r3347, align 8
  %r3349 = icmp ne i64 %r3348, 0
  br i1 %r3349, label %arrlike.ic.family_token.631, label %arrlike.ic.miss.642

arrlike.ic.family_token.631:                      ; preds = %arrlike.ic.family_meta.630
  %r3350 = inttoptr i64 %r3348 to ptr
  %r3351 = getelementptr i64, ptr %r3350, i64 6
  %r3352 = load i64, ptr %r3351, align 8
  %r3353 = icmp eq i64 %r3352, %r3340
  br i1 %r3353, label %arrlike.ic.bounds.632, label %arrlike.ic.miss.642

arrlike.ic.bounds.632:                            ; preds = %arrlike.ic.family_token.631, %arrlike.ic.exact.629
  %r3354 = getelementptr i64, ptr %r3244, i64 1
  %r3355 = load i64, ptr %r3354, align 8
  %r3356 = getelementptr i64, ptr %r3244, i64 2
  %r3357 = load i64, ptr %r3356, align 8
  %r3358 = getelementptr i64, ptr %r3244, i64 3
  %r3359 = load i64, ptr %r3358, align 8
  %r3360 = getelementptr i64, ptr %r3244, i64 4
  %r3361 = load i64, ptr %r3360, align 8
  %r3362 = icmp ult i64 %r3355, %r3361
  br i1 %r3362, label %arrlike.ic.length_inline.633, label %arrlike.ic.length_spill_meta.634

arrlike.ic.length_inline.633:                     ; preds = %arrlike.ic.bounds.632
  %r3363 = shl i64 %r3355, 3
  %r3364 = add i64 %r3363, 16
  %r3365 = add i64 %r3248, %r3364
  %r3366 = inttoptr i64 %r3365 to ptr
  %r3367 = load double, ptr %r3366, align 8
  br label %arrlike.ic.range.637

arrlike.ic.length_spill_meta.634:                 ; preds = %arrlike.ic.bounds.632
  %r3368 = add nuw nsw i64 %r3248, 8
  %r3369 = inttoptr i64 %r3368 to ptr
  %r3370 = load i64, ptr %r3369, align 8
  %r3371 = icmp ne i64 %r3370, 0
  br i1 %r3371, label %arrlike.ic.length_spill_ptr.635, label %arrlike.ic.miss.642

arrlike.ic.length_spill_ptr.635:                  ; preds = %arrlike.ic.length_spill_meta.634
  %r3372 = inttoptr i64 %r3370 to ptr
  %r3373 = getelementptr i64, ptr %r3372, i64 4
  %r3374 = load i64, ptr %r3373, align 8
  %r3375 = icmp ne i64 %r3374, 0
  %r3376 = select i1 %r3375, i64 %r3374, i64 %r3370
  %r3377 = inttoptr i64 %r3376 to ptr
  %r3378 = load i32, ptr %r3377, align 4
  %r3379 = zext i32 %r3378 to i64
  %r3380 = icmp ult i64 %r3355, %r3379
  %r3381 = and i1 %r3375, %r3380
  br i1 %r3381, label %arrlike.ic.length_spill_load.636, label %arrlike.ic.miss.642

arrlike.ic.length_spill_load.636:                 ; preds = %arrlike.ic.length_spill_ptr.635
  %r3382 = add nuw nsw i64 %r3355, 1
  %r3383 = getelementptr inbounds nuw i64, ptr %r3377, i64 %r3382
  %r3384 = load double, ptr %r3383, align 8
  br label %arrlike.ic.range.637

arrlike.ic.range.637:                             ; preds = %arrlike.ic.length_spill_load.636, %arrlike.ic.length_inline.633
  %r3385 = phi double [ %r3367, %arrlike.ic.length_inline.633 ], [ %r3384, %arrlike.ic.length_spill_load.636 ]
  %r3386 = fcmp olt double 1.000000e+00, %r3385
  %r3387 = icmp ult i64 1, %r3359
  %r3388 = and i1 %r3386, %r3387
  %r3389 = add i64 %r3357, 1
  %r3390 = icmp ult i64 %r3389, %r3361
  %r3391 = and i1 %r3388, %r3390
  %r3392 = xor i1 %r3390, true
  %r3393 = and i1 %r3388, %r3392
  br i1 %r3391, label %arrlike.ic.inline.638, label %arrlike.ic.spill_or_miss.649

arrlike.ic.inline.638:                            ; preds = %arrlike.ic.range.637
  %r3394 = shl i64 %r3389, 3
  %r3395 = add i64 %r3394, 16
  %r3396 = add i64 %r3248, %r3395
  %r3397 = inttoptr i64 %r3396 to ptr
  %r3398 = load double, ptr %r3397, align 8
  br label %tav.get.merge.606

arrlike.ic.spill.639:                             ; preds = %arrlike.ic.spill_or_miss.649
  %r3399 = add nuw nsw i64 %r3248, 8
  %r3400 = inttoptr i64 %r3399 to ptr
  %r3401 = load i64, ptr %r3400, align 8
  %r3402 = icmp ne i64 %r3401, 0
  br i1 %r3402, label %arrlike.ic.spill_ptr.640, label %arrlike.ic.miss.642

arrlike.ic.spill_ptr.640:                         ; preds = %arrlike.ic.spill.639
  %r3403 = inttoptr i64 %r3401 to ptr
  %r3404 = getelementptr i64, ptr %r3403, i64 4
  %r3405 = load i64, ptr %r3404, align 8
  %r3406 = icmp ne i64 %r3405, 0
  %r3407 = select i1 %r3406, i64 %r3405, i64 %r3401
  %r3408 = inttoptr i64 %r3407 to ptr
  %r3409 = load i32, ptr %r3408, align 4
  %r3410 = zext i32 %r3409 to i64
  %r3411 = icmp ult i64 %r3389, %r3410
  %r3412 = and i1 %r3406, %r3411
  br i1 %r3412, label %arrlike.ic.spill_load.641, label %arrlike.ic.miss.642

arrlike.ic.spill_load.641:                        ; preds = %arrlike.ic.spill_ptr.640
  %r3413 = add nuw nsw i64 %r3389, 1
  %r3414 = getelementptr inbounds nuw i64, ptr %r3408, i64 %r3413
  %r3415 = load double, ptr %r3414, align 8
  br label %tav.get.merge.606

arrlike.ic.miss.642:                              ; preds = %arrlike.ic.spill_or_miss.649, %arrlike.elem.load.647, %arrlike.elem.bounds.646, %arrlike.elem.kind.643, %arrlike.ic.spill_ptr.640, %arrlike.ic.spill.639, %arrlike.ic.length_spill_ptr.635, %arrlike.ic.length_spill_meta.634, %arrlike.ic.family_token.631, %arrlike.ic.family_meta.630, %arrlike.ic.exact.629, %arrlike.ic.shape.627, %arrlike.ic.array_guard.625, %arrlike.ic.header.623, %tav.get.slow.605
  %statepoint_token500 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, ptr)) @js_packed_arraylike_index_get, i32 3, i32 0, double %r3150, double 1.000000e+00, ptr @perry_ic_test_json_tape_batch_records_ts__23, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s30, ptr addrspace(1) %.01119, ptr addrspace(1) %.28, ptr addrspace(1) %.271081, ptr addrspace(1) %.01131) ]
  %r3416501 = call double @llvm.experimental.gc.result.f64(token %statepoint_token500)
  %rs4gc.s30.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token500, i32 0, i32 0) ; (%rs4gc.s30, %rs4gc.s30)
  %r131.1.base.relocated502 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token500, i32 1, i32 1) ; (%.01119, %.01119)
  %rs4gc.s15.relocated503 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token500, i32 2, i32 2) ; (%.28, %.28)
  %rs4gc.s20.relocated504 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token500, i32 3, i32 3) ; (%.271081, %.271081)
  %r131.1.relocated505 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token500, i32 1, i32 4) ; (%.01119, %.01131)
  br label %tav.get.merge.606

arrlike.elem.kind.643:                            ; preds = %arrlike.ic.brand.624
  %r3272 = icmp eq i8 %r3264, 2
  br i1 %r3272, label %arrlike.elem.meta.644, label %arrlike.ic.miss.642

arrlike.elem.meta.644:                            ; preds = %arrlike.elem.kind.643
  %r3273 = add nuw nsw i64 %r3248, 8
  %r3274 = inttoptr i64 %r3273 to ptr
  %r3275 = load i64, ptr %r3274, align 8
  %r3276 = icmp ne i64 %r3275, 0
  br i1 %r3276, label %arrlike.elem.store.645, label %arrlike.ic.shape.627

arrlike.elem.store.645:                           ; preds = %arrlike.elem.meta.644
  %r3277 = inttoptr i64 %r3275 to ptr
  %r3278 = getelementptr i64, ptr %r3277, i64 12
  %r3279 = load i64, ptr %r3278, align 8
  %r3280 = icmp ne i64 %r3279, 0
  br i1 %r3280, label %arrlike.elem.bounds.646, label %arrlike.ic.shape.627

arrlike.elem.bounds.646:                          ; preds = %arrlike.elem.store.645
  %r3281 = sub i64 %r3279, 8
  %r3282 = inttoptr i64 %r3281 to ptr
  %r3283 = load i8, ptr %r3282, align 1
  %r3284 = icmp eq i8 %r3283, 1
  %r3285 = sub i64 %r3279, 7
  %r3286 = inttoptr i64 %r3285 to ptr
  %r3287 = load i8, ptr %r3286, align 1
  %r3288 = and i8 %r3287, -128
  %r3289 = icmp eq i8 %r3288, 0
  %r3290 = inttoptr i64 %r3279 to ptr
  %r3291 = load i32, ptr %r3290, align 4
  %r3292 = zext i32 %r3291 to i64
  %r3293 = icmp ult i64 1, %r3292
  %r3294 = and i1 %r3284, %r3289
  %r3295 = and i1 %r3294, %r3293
  br i1 %r3295, label %arrlike.elem.load.647, label %arrlike.ic.miss.642

arrlike.elem.load.647:                            ; preds = %arrlike.elem.bounds.646
  %r3297 = add i64 %r3279, 8
  %r3298 = add i64 %r3297, 8
  %r3299 = inttoptr i64 %r3298 to ptr
  %r3300 = load double, ptr %r3299, align 8
  %r3301 = bitcast double %r3300 to i64
  %r3302 = icmp eq i64 %r3301, 9222246136947933200
  br i1 %r3302, label %arrlike.ic.miss.642, label %arrlike.elem.value.648

arrlike.elem.value.648:                           ; preds = %arrlike.elem.load.647
  br label %tav.get.merge.606

arrlike.ic.spill_or_miss.649:                     ; preds = %arrlike.ic.range.637
  br i1 %r3393, label %arrlike.ic.spill.639, label %arrlike.ic.miss.642

pget.recv_sso.650:                                ; preds = %pget.recv_other.655
  %r3560 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r3561 = bitcast double %r3560 to i64
  %r3562 = and i64 %r3561, 281474976710655
  %statepoint_token506 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3418, i64 %r3562, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01143, ptr addrspace(1) %.11120, ptr addrspace(1) %.29, ptr addrspace(1) %.281082, ptr addrspace(1) %.11132) ]
  %r3563507 = call double @llvm.experimental.gc.result.f64(token %statepoint_token506)
  %rs4gc.s30.relocated508 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token506, i32 0, i32 0) ; (%.01143, %.01143)
  %r131.1.base.relocated509 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token506, i32 1, i32 1) ; (%.11120, %.11120)
  %rs4gc.s15.relocated510 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token506, i32 2, i32 2) ; (%.29, %.29)
  %rs4gc.s20.relocated511 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token506, i32 3, i32 3) ; (%.281082, %.281082)
  %r131.1.relocated512 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token506, i32 1, i32 4) ; (%.11120, %.11132)
  br label %pget.recv_merge.654

pget.recv_ok.651:                                 ; preds = %tav.get.merge.606
  %r3429 = icmp ugt i64 %r3419, 1048575
  br i1 %r3429, label %pic.recv_hdr.672, label %pic.miss.cold.669

pget.recv_bad.652:                                ; preds = %pget.check_class_ref.656
  %r3552 = icmp eq i64 %r3418, 9222246136947933185
  %r3553 = icmp eq i64 %r3418, 9222246136947933186
  %r3554 = or i1 %r3552, %r3553
  br i1 %r3554, label %pget.throw_nullish.679, label %pget.recv_undef_return.680

pget.recv_class_ref.653:                          ; preds = %pget.check_class_ref.656
  %r3425 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r3426 = bitcast double %r3425 to i64
  %r3427 = and i64 %r3426, 281474976710655
  %statepoint_token513 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 367713371643969560, i64 %r3418, i64 %r3427, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01143, ptr addrspace(1) %.11120, ptr addrspace(1) %.29, ptr addrspace(1) %.281082, ptr addrspace(1) %.11132) ]
  %r3428514 = call double @llvm.experimental.gc.result.f64(token %statepoint_token513)
  %rs4gc.s30.relocated515 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token513, i32 0, i32 0) ; (%.01143, %.01143)
  %r131.1.base.relocated516 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token513, i32 1, i32 1) ; (%.11120, %.11120)
  %rs4gc.s15.relocated517 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token513, i32 2, i32 2) ; (%.29, %.29)
  %rs4gc.s20.relocated518 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token513, i32 3, i32 3) ; (%.281082, %.281082)
  %r131.1.relocated519 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token513, i32 1, i32 4) ; (%.11120, %.11132)
  br label %pget.recv_merge.654

pget.recv_merge.654:                              ; preds = %pget.recv_undef_return.680, %pic.merge.671, %pget.recv_class_ref.653, %pget.recv_sso.650
  %.11144 = phi ptr addrspace(1) [ %.21145, %pic.merge.671 ], [ %rs4gc.s30.relocated508, %pget.recv_sso.650 ], [ %rs4gc.s30.relocated515, %pget.recv_class_ref.653 ], [ %rs4gc.s30.relocated537, %pget.recv_undef_return.680 ]
  %.21133 = phi ptr addrspace(1) [ %.31134, %pic.merge.671 ], [ %r131.1.relocated512, %pget.recv_sso.650 ], [ %r131.1.relocated519, %pget.recv_class_ref.653 ], [ %r131.1.relocated541, %pget.recv_undef_return.680 ]
  %.21121 = phi ptr addrspace(1) [ %.31122, %pic.merge.671 ], [ %r131.1.base.relocated509, %pget.recv_sso.650 ], [ %r131.1.base.relocated516, %pget.recv_class_ref.653 ], [ %r131.1.base.relocated538, %pget.recv_undef_return.680 ]
  %.291083 = phi ptr addrspace(1) [ %.301084, %pic.merge.671 ], [ %rs4gc.s20.relocated511, %pget.recv_sso.650 ], [ %rs4gc.s20.relocated518, %pget.recv_class_ref.653 ], [ %rs4gc.s20.relocated540, %pget.recv_undef_return.680 ]
  %.30 = phi ptr addrspace(1) [ %.31, %pic.merge.671 ], [ %rs4gc.s15.relocated510, %pget.recv_sso.650 ], [ %rs4gc.s15.relocated517, %pget.recv_class_ref.653 ], [ %rs4gc.s15.relocated539, %pget.recv_undef_return.680 ]
  %r3564 = phi double [ %r3551, %pic.merge.671 ], [ %r3559536, %pget.recv_undef_return.680 ], [ %r3563507, %pget.recv_sso.650 ], [ %r3428514, %pget.recv_class_ref.653 ]
  %r3565 = bitcast double %r3564 to i64
  %r3566 = lshr i64 %r3565, 48
  %r3567 = icmp eq i64 %r3566, 32761
  br i1 %r3567, label %strlen.sso.681, label %strlen.chk.682

pget.recv_other.655:                              ; preds = %tav.get.merge.606
  %r3423 = icmp eq i64 %r3420, 32761
  br i1 %r3423, label %pget.recv_sso.650, label %pget.check_class_ref.656

pget.check_class_ref.656:                         ; preds = %pget.recv_other.655
  %r3424 = icmp eq i64 %r3420, 32766
  br i1 %r3424, label %pget.recv_class_ref.653, label %pget.recv_bad.652

pic.hit.657:                                      ; preds = %pic.token.673
  %r3454 = getelementptr i64, ptr %r3439, i64 1
  %r3455 = load i64, ptr %r3454, align 8
  %r3456 = and i64 %r3455, 1073741824
  %r3457 = icmp ne i64 %r3456, 0
  br i1 %r3457, label %pic.hit.overflow.674, label %pic.hit.inline.675

pic.hit.live.658:                                 ; preds = %pic.hit.inline.675
  br label %pic.merge.671

pic.prefix.guard.659:                             ; preds = %pic.token.673
  %r3470 = getelementptr i64, ptr %r3439, i64 2
  %r3471 = load i64, ptr %r3470, align 8
  %r3472 = icmp ne i64 %r3471, 0
  br i1 %r3472, label %pic.prefix.meta.660, label %pic.miss.668

pic.prefix.meta.660:                              ; preds = %pic.prefix.guard.659
  %r3473 = add nuw nsw i64 %r3419, 8
  %r3474 = inttoptr i64 %r3473 to ptr
  %r3475 = load i64, ptr %r3474, align 8
  %r3476 = icmp ne i64 %r3475, 0
  br i1 %r3476, label %pic.prefix.token.661, label %pic.miss.668

pic.prefix.token.661:                             ; preds = %pic.prefix.meta.660
  %r3477 = inttoptr i64 %r3475 to ptr
  %r3478 = getelementptr i64, ptr %r3477, i64 6
  %r3479 = load i64, ptr %r3478, align 8
  %r3480 = icmp eq i64 %r3479, %r3471
  br i1 %r3480, label %pic.prefix.hit.662, label %pic.miss.668

pic.prefix.hit.662:                               ; preds = %pic.prefix.token.661
  %r3481 = getelementptr i64, ptr %r3439, i64 1
  %r3482 = load i64, ptr %r3481, align 8
  %r3483 = shl i64 %r3482, 3
  %r3484 = add nuw nsw i64 %r3419, 16
  %r3485 = add i64 %r3484, %r3483
  %r3486 = inttoptr i64 %r3485 to ptr
  %r3487 = load double, ptr %r3486, align 8
  br label %pic.merge.671

pic.desc.classify.663:                            ; preds = %pic.recv_hdr.672
  %r3443 = and i1 %r3433, %r3440
  br i1 %r3443, label %pic.desc.prefix.guard.664, label %pic.miss.cold.669

pic.desc.prefix.guard.664:                        ; preds = %pic.desc.classify.663
  %r3488 = getelementptr i64, ptr %r3439, i64 2
  %r3489 = load i64, ptr %r3488, align 8
  %r3490 = icmp ne i64 %r3489, 0
  br i1 %r3490, label %pic.desc.prefix.meta.665, label %pic.miss.cold.669

pic.desc.prefix.meta.665:                         ; preds = %pic.desc.prefix.guard.664
  %r3491 = add nuw nsw i64 %r3419, 8
  %r3492 = inttoptr i64 %r3491 to ptr
  %r3493 = load i64, ptr %r3492, align 8
  %r3494 = icmp ne i64 %r3493, 0
  br i1 %r3494, label %pic.desc.prefix.token.666, label %pic.miss.cold.669

pic.desc.prefix.token.666:                        ; preds = %pic.desc.prefix.meta.665
  %r3495 = inttoptr i64 %r3493 to ptr
  %r3496 = getelementptr i64, ptr %r3495, i64 6
  %r3497 = load i64, ptr %r3496, align 8
  %r3498 = icmp eq i64 %r3497, %r3489
  br i1 %r3498, label %pic.desc.prefix.hit.667, label %pic.miss.cold.669

pic.desc.prefix.hit.667:                          ; preds = %pic.desc.prefix.token.666
  %r3499 = getelementptr i64, ptr %r3439, i64 1
  %r3500 = load i64, ptr %r3499, align 8
  %r3501 = shl i64 %r3500, 3
  %r3502 = add nuw nsw i64 %r3419, 16
  %r3503 = add i64 %r3502, %r3501
  %r3504 = inttoptr i64 %r3503 to ptr
  %r3505 = load double, ptr %r3504, align 8
  br label %pic.merge.671

pic.miss.668:                                     ; preds = %pic.hit.inline.675, %pic.prefix.token.661, %pic.prefix.meta.660, %pic.prefix.guard.659
  %r3506 = getelementptr i64, ptr %r3439, i64 3
  %r3507 = load i64, ptr %r3506, align 8
  %r3508 = icmp sgt i64 %r3507, 0
  br i1 %r3508, label %pic.ways.676, label %pic.miss.call.670

pic.miss.cold.669:                                ; preds = %pic.desc.prefix.token.666, %pic.desc.prefix.meta.665, %pic.desc.prefix.guard.664, %pic.desc.classify.663, %pget.recv_ok.651
  br label %pic.miss.call.670

pic.miss.call.670:                                ; preds = %pic.way.load.677, %pic.ways.676, %pic.miss.cold.669, %pic.miss.668
  %r3547 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r3548 = bitcast double %r3547 to i64
  %r3549 = and i64 %r3548, 281474976710655
  %statepoint_token520 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r3419, i64 %r3549, ptr @perry_ic_test_json_tape_batch_records_ts__25, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01143, ptr addrspace(1) %.11120, ptr addrspace(1) %.29, ptr addrspace(1) %.281082, ptr addrspace(1) %.11132) ]
  %r3550521 = call double @llvm.experimental.gc.result.f64(token %statepoint_token520)
  %rs4gc.s30.relocated522 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token520, i32 0, i32 0) ; (%.01143, %.01143)
  %r131.1.base.relocated523 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token520, i32 1, i32 1) ; (%.11120, %.11120)
  %rs4gc.s15.relocated524 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token520, i32 2, i32 2) ; (%.29, %.29)
  %rs4gc.s20.relocated525 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token520, i32 3, i32 3) ; (%.281082, %.281082)
  %r131.1.relocated526 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token520, i32 1, i32 4) ; (%.11120, %.11132)
  br label %pic.merge.671

pic.merge.671:                                    ; preds = %pic.way.live.678, %pic.hit.overflow.674, %pic.miss.call.670, %pic.desc.prefix.hit.667, %pic.prefix.hit.662, %pic.hit.live.658
  %.21145 = phi ptr addrspace(1) [ %rs4gc.s30.relocated529, %pic.hit.overflow.674 ], [ %rs4gc.s30.relocated522, %pic.miss.call.670 ], [ %.01143, %pic.way.live.678 ], [ %.01143, %pic.hit.live.658 ], [ %.01143, %pic.prefix.hit.662 ], [ %.01143, %pic.desc.prefix.hit.667 ]
  %.31134 = phi ptr addrspace(1) [ %r131.1.relocated533, %pic.hit.overflow.674 ], [ %r131.1.relocated526, %pic.miss.call.670 ], [ %.11132, %pic.way.live.678 ], [ %.11132, %pic.hit.live.658 ], [ %.11132, %pic.prefix.hit.662 ], [ %.11132, %pic.desc.prefix.hit.667 ]
  %.31122 = phi ptr addrspace(1) [ %r131.1.base.relocated530, %pic.hit.overflow.674 ], [ %r131.1.base.relocated523, %pic.miss.call.670 ], [ %.11120, %pic.way.live.678 ], [ %.11120, %pic.hit.live.658 ], [ %.11120, %pic.prefix.hit.662 ], [ %.11120, %pic.desc.prefix.hit.667 ]
  %.301084 = phi ptr addrspace(1) [ %rs4gc.s20.relocated532, %pic.hit.overflow.674 ], [ %rs4gc.s20.relocated525, %pic.miss.call.670 ], [ %.281082, %pic.way.live.678 ], [ %.281082, %pic.hit.live.658 ], [ %.281082, %pic.prefix.hit.662 ], [ %.281082, %pic.desc.prefix.hit.667 ]
  %.31 = phi ptr addrspace(1) [ %rs4gc.s15.relocated531, %pic.hit.overflow.674 ], [ %rs4gc.s15.relocated524, %pic.miss.call.670 ], [ %.29, %pic.way.live.678 ], [ %.29, %pic.hit.live.658 ], [ %.29, %pic.prefix.hit.662 ], [ %.29, %pic.desc.prefix.hit.667 ]
  %r3551 = phi double [ %r3467, %pic.hit.live.658 ], [ %r3462528, %pic.hit.overflow.674 ], [ %r3487, %pic.prefix.hit.662 ], [ %r3505, %pic.desc.prefix.hit.667 ], [ %r3544, %pic.way.live.678 ], [ %r3550521, %pic.miss.call.670 ]
  br label %pget.recv_merge.654

pic.recv_hdr.672:                                 ; preds = %pget.recv_ok.651
  %r3430 = sub nuw nsw i64 %r3419, 8
  %r3431 = inttoptr i64 %r3430 to ptr
  %r3432 = load i8, ptr %r3431, align 1
  %r3433 = icmp eq i8 %r3432, 2
  %r3434 = sub nuw nsw i64 %r3419, 6
  %r3435 = inttoptr i64 %r3434 to ptr
  %r3436 = load i16, ptr %r3435, align 2
  %r3437 = and i16 %r3436, 2048
  %r3438 = icmp eq i16 %r3437, 0
  %r3439 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__25, align 8
  %r3440 = icmp ne ptr %r3439, null
  %r3441 = and i1 %r3433, %r3438
  %r3442 = and i1 %r3441, %r3440
  br i1 %r3442, label %pic.token.673, label %pic.desc.classify.663

pic.token.673:                                    ; preds = %pic.recv_hdr.672
  %r3444 = add nuw nsw i64 %r3419, 4
  %r3445 = inttoptr i64 %r3444 to ptr
  %r3446 = load i32, ptr %r3445, align 4
  %r3447 = zext i32 %r3446 to i64
  %r3448 = or i64 %r3447, 4611686018427387904
  %r3449 = icmp ne i32 %r3446, 0
  %r3450 = getelementptr i64, ptr %r3439, i64 0
  %r3451 = load i64, ptr %r3450, align 8
  %r3452 = icmp eq i64 %r3448, %r3451
  %r3453 = and i1 %r3452, %r3449
  br i1 %r3453, label %pic.hit.657, label %pic.prefix.guard.659

pic.hit.overflow.674:                             ; preds = %pic.hit.657
  %r3458 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r3459 = bitcast double %r3458 to i64
  %r3460 = and i64 %r3459, 281474976710655
  %r3461 = trunc i64 %r3455 to i32
  %statepoint_token527 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r3419, i64 %r3460, i32 %r3461, ptr @perry_ic_test_json_tape_batch_records_ts__25, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01143, ptr addrspace(1) %.11120, ptr addrspace(1) %.29, ptr addrspace(1) %.281082, ptr addrspace(1) %.11132) ]
  %r3462528 = call double @llvm.experimental.gc.result.f64(token %statepoint_token527)
  %rs4gc.s30.relocated529 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token527, i32 0, i32 0) ; (%.01143, %.01143)
  %r131.1.base.relocated530 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token527, i32 1, i32 1) ; (%.11120, %.11120)
  %rs4gc.s15.relocated531 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token527, i32 2, i32 2) ; (%.29, %.29)
  %rs4gc.s20.relocated532 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token527, i32 3, i32 3) ; (%.281082, %.281082)
  %r131.1.relocated533 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token527, i32 1, i32 4) ; (%.11120, %.11132)
  br label %pic.merge.671

pic.hit.inline.675:                               ; preds = %pic.hit.657
  %r3463 = shl i64 %r3455, 3
  %r3464 = add nuw nsw i64 %r3419, 16
  %r3465 = add i64 %r3464, %r3463
  %r3466 = inttoptr i64 %r3465 to ptr
  %r3467 = load double, ptr %r3466, align 8
  %r3468 = bitcast double %r3467 to i64
  %r3469 = icmp eq i64 %r3468, 9222246136947933200
  br i1 %r3469, label %pic.miss.668, label %pic.hit.live.658

pic.ways.676:                                     ; preds = %pic.miss.668
  %r3509 = getelementptr i64, ptr %r3439, i64 4
  %r3510 = load i64, ptr %r3509, align 8
  %r3511 = icmp eq i64 %r3510, %r3448
  %r3512 = getelementptr i64, ptr %r3439, i64 5
  %r3513 = load i64, ptr %r3512, align 8
  %r3514 = select i1 %r3511, i64 %r3513, i64 0
  %r3515 = getelementptr i64, ptr %r3439, i64 6
  %r3516 = load i64, ptr %r3515, align 8
  %r3517 = icmp eq i64 %r3516, %r3448
  %r3518 = getelementptr i64, ptr %r3439, i64 7
  %r3519 = load i64, ptr %r3518, align 8
  %r3520 = select i1 %r3517, i64 %r3519, i64 0
  %r3521 = getelementptr i64, ptr %r3439, i64 8
  %r3522 = load i64, ptr %r3521, align 8
  %r3523 = icmp eq i64 %r3522, %r3448
  %r3524 = getelementptr i64, ptr %r3439, i64 9
  %r3525 = load i64, ptr %r3524, align 8
  %r3526 = select i1 %r3523, i64 %r3525, i64 0
  %r3527 = getelementptr i64, ptr %r3439, i64 10
  %r3528 = load i64, ptr %r3527, align 8
  %r3529 = icmp eq i64 %r3528, %r3448
  %r3530 = getelementptr i64, ptr %r3439, i64 11
  %r3531 = load i64, ptr %r3530, align 8
  %r3532 = select i1 %r3529, i64 %r3531, i64 0
  %r3533 = or i1 %r3511, %r3517
  %r3534 = select i1 %r3511, i64 %r3514, i64 %r3520
  %r3535 = or i1 %r3523, %r3529
  %r3536 = select i1 %r3523, i64 %r3526, i64 %r3532
  %r3537 = or i1 %r3533, %r3535
  %r3538 = select i1 %r3533, i64 %r3534, i64 %r3536
  %r3539 = and i1 %r3449, %r3537
  br i1 %r3539, label %pic.way.load.677, label %pic.miss.call.670

pic.way.load.677:                                 ; preds = %pic.ways.676
  %r3540 = shl i64 %r3538, 3
  %r3541 = add nuw nsw i64 %r3419, 16
  %r3542 = add i64 %r3541, %r3540
  %r3543 = inttoptr i64 %r3542 to ptr
  %r3544 = load double, ptr %r3543, align 8
  %r3545 = bitcast double %r3544 to i64
  %r3546 = icmp eq i64 %r3545, 9222246136947933200
  br i1 %r3546, label %pic.miss.call.670, label %pic.way.live.678

pic.way.live.678:                                 ; preds = %pic.way.load.677
  br label %pic.merge.671

pget.throw_nullish.679:                           ; preds = %pget.recv_bad.652
  %r3555 = zext i1 %r3553 to i32
  %statepoint_token534 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r3555, ptr @test_json_tape_batch_records_ts_.str.13.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.680:                       ; preds = %pget.recv_bad.652
  %r3556 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r3557 = bitcast double %r3556 to i64
  %r3558 = and i64 %r3557, 281474976710655
  %statepoint_token535 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3418, i64 %r3558, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01143, ptr addrspace(1) %.11120, ptr addrspace(1) %.29, ptr addrspace(1) %.281082, ptr addrspace(1) %.11132) ]
  %r3559536 = call double @llvm.experimental.gc.result.f64(token %statepoint_token535)
  %rs4gc.s30.relocated537 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token535, i32 0, i32 0) ; (%.01143, %.01143)
  %r131.1.base.relocated538 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token535, i32 1, i32 1) ; (%.11120, %.11120)
  %rs4gc.s15.relocated539 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token535, i32 2, i32 2) ; (%.29, %.29)
  %rs4gc.s20.relocated540 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token535, i32 3, i32 3) ; (%.281082, %.281082)
  %r131.1.relocated541 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token535, i32 1, i32 4) ; (%.11120, %.11132)
  br label %pget.recv_merge.654

strlen.sso.681:                                   ; preds = %pget.recv_merge.654
  %r3568 = lshr i64 %r3565, 40
  %r3569 = and i64 %r3568, 255
  %r3570 = uitofp nneg i64 %r3569 to double
  br label %strlen.merge.685

strlen.chk.682:                                   ; preds = %pget.recv_merge.654
  %r3571 = icmp eq i64 %r3566, 32767
  br i1 %r3571, label %strlen.heap.683, label %strlen.slow.684

strlen.heap.683:                                  ; preds = %strlen.chk.682
  %r3573 = and i64 %r3565, 281474976710655
  %r3574 = icmp ult i64 %r3573, 4096
  %r3575 = inttoptr i64 %r3573 to ptr
  %r3576 = select i1 %r3574, ptr @perry_null_guard_zero_test_json_tape_batch_records_ts, ptr %r3575
  %r3577 = load i32, ptr %r3576, align 4
  %r3578 = uitofp i32 %r3577 to double
  br label %strlen.merge.685

strlen.slow.684:                                  ; preds = %strlen.chk.682
  %statepoint_token542 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_value_length_property_f64, i32 1, i32 0, double %r3564, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11144, ptr addrspace(1) %.21121, ptr addrspace(1) %.30, ptr addrspace(1) %.291083, ptr addrspace(1) %.21133) ]
  %r3572543 = call double @llvm.experimental.gc.result.f64(token %statepoint_token542)
  %rs4gc.s30.relocated544 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token542, i32 0, i32 0) ; (%.11144, %.11144)
  %r131.1.base.relocated545 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token542, i32 1, i32 1) ; (%.21121, %.21121)
  %rs4gc.s15.relocated546 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token542, i32 2, i32 2) ; (%.30, %.30)
  %rs4gc.s20.relocated547 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token542, i32 3, i32 3) ; (%.291083, %.291083)
  %r131.1.relocated548 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token542, i32 1, i32 4) ; (%.21121, %.21133)
  br label %strlen.merge.685

strlen.merge.685:                                 ; preds = %strlen.slow.684, %strlen.heap.683, %strlen.sso.681
  %.31146 = phi ptr addrspace(1) [ %.11144, %strlen.sso.681 ], [ %.11144, %strlen.heap.683 ], [ %rs4gc.s30.relocated544, %strlen.slow.684 ]
  %.41135 = phi ptr addrspace(1) [ %.21133, %strlen.sso.681 ], [ %.21133, %strlen.heap.683 ], [ %r131.1.relocated548, %strlen.slow.684 ]
  %.41123 = phi ptr addrspace(1) [ %.21121, %strlen.sso.681 ], [ %.21121, %strlen.heap.683 ], [ %r131.1.base.relocated545, %strlen.slow.684 ]
  %.311085 = phi ptr addrspace(1) [ %.291083, %strlen.sso.681 ], [ %.291083, %strlen.heap.683 ], [ %rs4gc.s20.relocated547, %strlen.slow.684 ]
  %.32 = phi ptr addrspace(1) [ %.30, %strlen.sso.681 ], [ %.30, %strlen.heap.683 ], [ %rs4gc.s15.relocated546, %strlen.slow.684 ]
  %r3579 = phi double [ %r3570, %strlen.sso.681 ], [ %r3578, %strlen.heap.683 ], [ %r3572543, %strlen.slow.684 ]
  %r3580 = bitcast double %r3579 to i64
  %rs4gc.s31 = inttoptr i64 %r3580 to ptr addrspace(1)
  %r3582.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31 to i64
  %r3582 = call i64 asm "", "=r,0"(i64 %r3582.rs4i) #7
  %r3583 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3584 = icmp ne i32 %r3583, 0
  br i1 %r3584, label %shadow.root.barrier.686, label %shadow.root.barrier.done.687

shadow.root.barrier.686:                          ; preds = %strlen.merge.685
  call void @js_write_barrier_root_nanbox(i64 %r3582) #7
  br label %shadow.root.barrier.done.687

shadow.root.barrier.done.687:                     ; preds = %shadow.root.barrier.686, %strlen.merge.685
  %r3585.rs4i = ptrtoint ptr addrspace(1) %.311085 to i64
  %r3585.rs4o = call i64 asm "", "=r,0"(i64 %r3585.rs4i) #7
  %r3585 = bitcast i64 %r3585.rs4o to double
  %r3586 = bitcast double %r3585 to i64
  %r3587 = and i64 %r3586, 281474976710655
  %r3588 = and i64 %r3586, -281474976710656
  %r3589 = icmp eq i64 %r3588, 9222527611924643840
  %r3590 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r3591 = icmp eq i64 %r3590, 0
  %r3592 = icmp ugt i64 %r3587, 1048575
  %r3593 = icmp ult i64 %r3587, 140737488355328
  %r3594 = and i1 %r3592, %r3593
  %r3595 = and i1 %r3589, %r3591
  %r3596 = and i1 %r3595, %r3594
  br i1 %r3596, label %tav.get.brand.692, label %tav.get.slow.690

tav.get.fast.688:                                 ; preds = %tav.get.brand.692
  %r3613 = bitcast double %r3585 to i64
  %r3614 = and i64 %r3613, 281474976710655
  %r3615 = add nuw nsw i64 %r3614, 8
  %r3616 = inttoptr i64 %r3615 to ptr
  %r3617 = load i8, ptr %r3616, align 1
  %r3618 = zext i8 %r3617 to i64
  %r3622 = inttoptr i64 %r3614 to ptr
  %r3623 = load i32, ptr %r3622, align 4
  %r3624 = zext i32 %r3623 to i64
  %r3625 = icmp ult i64 2, %r3624
  %r3626 = and i1 true, %r3625
  br i1 %r3626, label %tav.get.load.689, label %tav.get.slow.690

tav.get.load.689:                                 ; preds = %tav.get.fast.688
  %r3627 = add nuw nsw i64 %r3614, 16
  %r3628 = icmp eq i64 %r3618, 0
  br i1 %r3628, label %tav.k.i8.693, label %tav.kd1.701

tav.get.slow.690:                                 ; preds = %tav.get.brand.692, %tav.get.fast.688, %shadow.root.barrier.done.687
  %r3679 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__26, align 8
  %r3680 = icmp ne ptr %r3679, null
  %r3681 = select i1 %r3680, ptr %r3679, ptr @perry_ic_test_json_tape_batch_records_ts__26
  %r3682 = bitcast double %r3585 to i64
  %r3683 = and i64 %r3682, 281474976710655
  %r3684 = and i64 %r3682, -281474976710656
  %r3685 = icmp eq i64 %r3684, 9222527611924643840
  %r3686 = icmp uge i64 %r3683, 2199023255552
  %r3687 = icmp ult i64 %r3683, 140737488355328
  %r3690 = and i1 %r3685, %r3686
  %r3691 = and i1 %r3690, %r3687
  br i1 %r3691, label %arrlike.ic.header.708, label %arrlike.ic.miss.727

tav.get.merge.691:                                ; preds = %arrlike.elem.value.733, %arrlike.ic.miss.727, %arrlike.ic.spill_load.726, %arrlike.ic.inline.723, %arrlike.ic.array_load.711, %tav.k.f64.700, %tav.k.f32.699, %tav.k.u32.698, %tav.k.i32.697, %tav.k.u16.696, %tav.k.i16.695, %tav.k.u8.694, %tav.k.i8.693
  %.01152 = phi ptr addrspace(1) [ %rs4gc.s31, %tav.k.i8.693 ], [ %rs4gc.s31, %tav.k.u8.694 ], [ %rs4gc.s31, %tav.k.i16.695 ], [ %rs4gc.s31, %tav.k.u16.696 ], [ %rs4gc.s31, %tav.k.i32.697 ], [ %rs4gc.s31, %tav.k.u32.698 ], [ %rs4gc.s31, %tav.k.f32.699 ], [ %rs4gc.s31, %tav.k.f64.700 ], [ %rs4gc.s31, %arrlike.ic.array_load.711 ], [ %rs4gc.s31.relocated, %arrlike.ic.miss.727 ], [ %rs4gc.s31, %arrlike.elem.value.733 ], [ %rs4gc.s31, %arrlike.ic.inline.723 ], [ %rs4gc.s31, %arrlike.ic.spill_load.726 ]
  %.41147 = phi ptr addrspace(1) [ %.31146, %tav.k.i8.693 ], [ %.31146, %tav.k.u8.694 ], [ %.31146, %tav.k.i16.695 ], [ %.31146, %tav.k.u16.696 ], [ %.31146, %tav.k.i32.697 ], [ %.31146, %tav.k.u32.698 ], [ %.31146, %tav.k.f32.699 ], [ %.31146, %tav.k.f64.700 ], [ %.31146, %arrlike.ic.array_load.711 ], [ %rs4gc.s30.relocated551, %arrlike.ic.miss.727 ], [ %.31146, %arrlike.elem.value.733 ], [ %.31146, %arrlike.ic.inline.723 ], [ %.31146, %arrlike.ic.spill_load.726 ]
  %.51136 = phi ptr addrspace(1) [ %.41135, %tav.k.i8.693 ], [ %.41135, %tav.k.u8.694 ], [ %.41135, %tav.k.i16.695 ], [ %.41135, %tav.k.u16.696 ], [ %.41135, %tav.k.i32.697 ], [ %.41135, %tav.k.u32.698 ], [ %.41135, %tav.k.f32.699 ], [ %.41135, %tav.k.f64.700 ], [ %.41135, %arrlike.ic.array_load.711 ], [ %r131.1.relocated554, %arrlike.ic.miss.727 ], [ %.41135, %arrlike.elem.value.733 ], [ %.41135, %arrlike.ic.inline.723 ], [ %.41135, %arrlike.ic.spill_load.726 ]
  %.51124 = phi ptr addrspace(1) [ %.41123, %tav.k.i8.693 ], [ %.41123, %tav.k.u8.694 ], [ %.41123, %tav.k.i16.695 ], [ %.41123, %tav.k.u16.696 ], [ %.41123, %tav.k.i32.697 ], [ %.41123, %tav.k.u32.698 ], [ %.41123, %tav.k.f32.699 ], [ %.41123, %tav.k.f64.700 ], [ %.41123, %arrlike.ic.array_load.711 ], [ %r131.1.base.relocated552, %arrlike.ic.miss.727 ], [ %.41123, %arrlike.elem.value.733 ], [ %.41123, %arrlike.ic.inline.723 ], [ %.41123, %arrlike.ic.spill_load.726 ]
  %.33 = phi ptr addrspace(1) [ %.32, %tav.k.i8.693 ], [ %.32, %tav.k.u8.694 ], [ %.32, %tav.k.i16.695 ], [ %.32, %tav.k.u16.696 ], [ %.32, %tav.k.i32.697 ], [ %.32, %tav.k.u32.698 ], [ %.32, %tav.k.f32.699 ], [ %.32, %tav.k.f64.700 ], [ %.32, %arrlike.ic.array_load.711 ], [ %rs4gc.s15.relocated553, %arrlike.ic.miss.727 ], [ %.32, %arrlike.elem.value.733 ], [ %.32, %arrlike.ic.inline.723 ], [ %.32, %arrlike.ic.spill_load.726 ]
  %r3852 = phi double [ %r3641, %tav.k.i8.693 ], [ %r3647, %tav.k.u8.694 ], [ %r3653, %tav.k.i16.695 ], [ %r3659, %tav.k.u16.696 ], [ %r3664, %tav.k.i32.697 ], [ %r3669, %tav.k.u32.698 ], [ %r3674, %tav.k.f32.699 ], [ %r3678, %tav.k.f64.700 ], [ %r3735, %arrlike.elem.value.733 ], [ %r3763, %arrlike.ic.array_load.711 ], [ %r3833, %arrlike.ic.inline.723 ], [ %r3850, %arrlike.ic.spill_load.726 ], [ %r3851550, %arrlike.ic.miss.727 ]
  %r3853 = bitcast double %r3852 to i64
  %r3854 = and i64 %r3853, 281474976710655
  %r3855 = lshr i64 %r3853, 48
  %r3856 = and i64 %r3855, 65533
  %r3857 = icmp eq i64 %r3856, 32765
  br i1 %r3857, label %pget.recv_ok.736, label %pget.recv_other.740

tav.get.brand.692:                                ; preds = %shadow.root.barrier.done.687
  %r3597 = bitcast double %r3585 to i64
  %r3598 = and i64 %r3597, 281474976710655
  %r3599 = sub nsw i64 %r3598, 8
  %r3600 = inttoptr i64 %r3599 to ptr
  %r3601 = load i8, ptr %r3600, align 1
  %r3602 = icmp eq i8 %r3601, 11
  %r3603 = add nuw nsw i64 %r3598, 8
  %r3604 = inttoptr i64 %r3603 to ptr
  %r3605 = load i8, ptr %r3604, align 1
  %r3606 = zext i8 %r3605 to i64
  %r3607 = icmp ule i64 %r3606, 8
  %r3610 = and i1 %r3602, %r3607
  br i1 %r3610, label %tav.get.fast.688, label %tav.get.slow.690

tav.k.i8.693:                                     ; preds = %tav.get.load.689
  %r3637 = add nuw nsw i64 %r3627, 2
  %r3638 = inttoptr i64 %r3637 to ptr
  %r3639 = load i8, ptr %r3638, align 1
  %r3640 = sext i8 %r3639 to i32
  %r3641 = sitofp i32 %r3640 to double
  br label %tav.get.merge.691

tav.k.u8.694:                                     ; preds = %tav.kd7.707, %tav.kd1.701
  %r3643 = add nuw nsw i64 %r3627, 2
  %r3644 = inttoptr i64 %r3643 to ptr
  %r3645 = load i8, ptr %r3644, align 1
  %r3646 = zext i8 %r3645 to i32
  %r3647 = uitofp nneg i32 %r3646 to double
  br label %tav.get.merge.691

tav.k.i16.695:                                    ; preds = %tav.kd2.702
  %r3649 = add nuw nsw i64 %r3627, 4
  %r3650 = inttoptr i64 %r3649 to ptr
  %r3651 = load i16, ptr %r3650, align 2
  %r3652 = sext i16 %r3651 to i32
  %r3653 = sitofp i32 %r3652 to double
  br label %tav.get.merge.691

tav.k.u16.696:                                    ; preds = %tav.kd3.703
  %r3655 = add nuw nsw i64 %r3627, 4
  %r3656 = inttoptr i64 %r3655 to ptr
  %r3657 = load i16, ptr %r3656, align 2
  %r3658 = zext i16 %r3657 to i32
  %r3659 = uitofp nneg i32 %r3658 to double
  br label %tav.get.merge.691

tav.k.i32.697:                                    ; preds = %tav.kd4.704
  %r3661 = add nuw nsw i64 %r3627, 8
  %r3662 = inttoptr i64 %r3661 to ptr
  %r3663 = load i32, ptr %r3662, align 4
  %r3664 = sitofp i32 %r3663 to double
  br label %tav.get.merge.691

tav.k.u32.698:                                    ; preds = %tav.kd5.705
  %r3666 = add nuw nsw i64 %r3627, 8
  %r3667 = inttoptr i64 %r3666 to ptr
  %r3668 = load i32, ptr %r3667, align 4
  %r3669 = uitofp i32 %r3668 to double
  br label %tav.get.merge.691

tav.k.f32.699:                                    ; preds = %tav.kd6.706
  %r3671 = add nuw nsw i64 %r3627, 8
  %r3672 = inttoptr i64 %r3671 to ptr
  %r3673 = load float, ptr %r3672, align 4
  %r3674 = fpext float %r3673 to double
  br label %tav.get.merge.691

tav.k.f64.700:                                    ; preds = %tav.kd7.707
  %r3676 = add nuw nsw i64 %r3627, 16
  %r3677 = inttoptr i64 %r3676 to ptr
  %r3678 = load double, ptr %r3677, align 8
  br label %tav.get.merge.691

tav.kd1.701:                                      ; preds = %tav.get.load.689
  %r3629 = icmp eq i64 %r3618, 1
  br i1 %r3629, label %tav.k.u8.694, label %tav.kd2.702

tav.kd2.702:                                      ; preds = %tav.kd1.701
  %r3630 = icmp eq i64 %r3618, 2
  br i1 %r3630, label %tav.k.i16.695, label %tav.kd3.703

tav.kd3.703:                                      ; preds = %tav.kd2.702
  %r3631 = icmp eq i64 %r3618, 3
  br i1 %r3631, label %tav.k.u16.696, label %tav.kd4.704

tav.kd4.704:                                      ; preds = %tav.kd3.703
  %r3632 = icmp eq i64 %r3618, 4
  br i1 %r3632, label %tav.k.i32.697, label %tav.kd5.705

tav.kd5.705:                                      ; preds = %tav.kd4.704
  %r3633 = icmp eq i64 %r3618, 5
  br i1 %r3633, label %tav.k.u32.698, label %tav.kd6.706

tav.kd6.706:                                      ; preds = %tav.kd5.705
  %r3634 = icmp eq i64 %r3618, 6
  br i1 %r3634, label %tav.k.f32.699, label %tav.kd7.707

tav.kd7.707:                                      ; preds = %tav.kd6.706
  %r3635 = icmp eq i64 %r3618, 7
  br i1 %r3635, label %tav.k.f64.700, label %tav.k.u8.694

arrlike.ic.header.708:                            ; preds = %tav.get.slow.690
  %r3697 = sub nuw nsw i64 %r3683, 8
  %r3698 = inttoptr i64 %r3697 to ptr
  %r3699 = load i8, ptr %r3698, align 1
  %r3701 = sub nuw nsw i64 %r3683, 7
  %r3702 = inttoptr i64 %r3701 to ptr
  %r3703 = load i8, ptr %r3702, align 1
  %r3704 = and i8 %r3703, -128
  %r3705 = icmp eq i8 %r3704, 0
  %r3706 = and i1 true, %r3705
  br i1 %r3706, label %arrlike.ic.brand.709, label %arrlike.ic.miss.727

arrlike.ic.brand.709:                             ; preds = %arrlike.ic.header.708
  %r3700 = icmp eq i8 %r3699, 1
  br i1 %r3700, label %arrlike.ic.array_guard.710, label %arrlike.elem.kind.728

arrlike.ic.array_guard.710:                       ; preds = %arrlike.ic.brand.709
  %r3738 = sub nuw nsw i64 %r3683, 6
  %r3739 = inttoptr i64 %r3738 to ptr
  %r3740 = load i16, ptr %r3739, align 2
  %r3741 = and i16 %r3740, 1024
  %r3742 = icmp eq i16 %r3741, 0
  %r3743 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r3744 = icmp eq i8 %r3743, 0
  %r3745 = inttoptr i64 %r3683 to ptr
  %r3746 = load i32, ptr %r3745, align 4
  %r3747 = add nuw nsw i64 %r3683, 4
  %r3748 = inttoptr i64 %r3747 to ptr
  %r3749 = load i32, ptr %r3748, align 4
  %r3750 = zext i32 %r3746 to i64
  %r3751 = zext i32 %r3749 to i64
  %r3752 = icmp ult i64 2, %r3750
  %r3753 = icmp ule i64 %r3750, %r3751
  %r3754 = and i1 %r3742, %r3744
  %r3755 = and i1 %r3754, %r3752
  %r3756 = and i1 %r3755, %r3753
  br i1 %r3756, label %arrlike.ic.array_load.711, label %arrlike.ic.miss.727

arrlike.ic.array_load.711:                        ; preds = %arrlike.ic.array_guard.710
  %r3758 = getelementptr inbounds nuw i64, ptr %r3745, i64 3
  %r3759 = load double, ptr %r3758, align 8
  %r3760 = bitcast double %r3759 to i64
  %r3761 = icmp eq i64 %r3760, 9222246136947933200
  %r3763 = select i1 %r3761, double 0x7FFC000000000001, double %r3759
  br label %tav.get.merge.691

arrlike.ic.shape.712:                             ; preds = %arrlike.elem.store.730, %arrlike.elem.meta.729
  %r3765 = inttoptr i64 %r3683 to ptr
  %r3766 = load i32, ptr %r3765, align 4
  %r3767 = add nuw nsw i64 %r3683, 4
  %r3768 = inttoptr i64 %r3767 to ptr
  %r3769 = load i32, ptr %r3768, align 4
  %r3770 = zext i32 %r3766 to i64
  %r3771 = zext i32 %r3769 to i64
  %r3772 = shl nuw i64 %r3770, 32
  %r3773 = or i64 %r3772, %r3771
  %r3774 = getelementptr i64, ptr %r3681, i64 0
  %r3775 = load i64, ptr %r3774, align 8
  %r3776 = icmp ne i64 %r3775, 0
  %r3777 = and i1 true, %r3776
  br i1 %r3777, label %arrlike.ic.identity.713, label %arrlike.ic.miss.727

arrlike.ic.identity.713:                          ; preds = %arrlike.ic.shape.712
  %r3778 = and i64 %r3775, -9223372036854775808
  %6 = icmp slt i64 %r3775, 0
  br i1 %6, label %arrlike.ic.family_meta.715, label %arrlike.ic.exact.714

arrlike.ic.exact.714:                             ; preds = %arrlike.ic.identity.713
  %r3780 = icmp eq i64 %r3773, %r3775
  br i1 %r3780, label %arrlike.ic.bounds.717, label %arrlike.ic.miss.727

arrlike.ic.family_meta.715:                       ; preds = %arrlike.ic.identity.713
  %r3781 = add nuw nsw i64 %r3683, 8
  %r3782 = inttoptr i64 %r3781 to ptr
  %r3783 = load i64, ptr %r3782, align 8
  %r3784 = icmp ne i64 %r3783, 0
  br i1 %r3784, label %arrlike.ic.family_token.716, label %arrlike.ic.miss.727

arrlike.ic.family_token.716:                      ; preds = %arrlike.ic.family_meta.715
  %r3785 = inttoptr i64 %r3783 to ptr
  %r3786 = getelementptr i64, ptr %r3785, i64 6
  %r3787 = load i64, ptr %r3786, align 8
  %r3788 = icmp eq i64 %r3787, %r3775
  br i1 %r3788, label %arrlike.ic.bounds.717, label %arrlike.ic.miss.727

arrlike.ic.bounds.717:                            ; preds = %arrlike.ic.family_token.716, %arrlike.ic.exact.714
  %r3789 = getelementptr i64, ptr %r3679, i64 1
  %r3790 = load i64, ptr %r3789, align 8
  %r3791 = getelementptr i64, ptr %r3679, i64 2
  %r3792 = load i64, ptr %r3791, align 8
  %r3793 = getelementptr i64, ptr %r3679, i64 3
  %r3794 = load i64, ptr %r3793, align 8
  %r3795 = getelementptr i64, ptr %r3679, i64 4
  %r3796 = load i64, ptr %r3795, align 8
  %r3797 = icmp ult i64 %r3790, %r3796
  br i1 %r3797, label %arrlike.ic.length_inline.718, label %arrlike.ic.length_spill_meta.719

arrlike.ic.length_inline.718:                     ; preds = %arrlike.ic.bounds.717
  %r3798 = shl i64 %r3790, 3
  %r3799 = add i64 %r3798, 16
  %r3800 = add i64 %r3683, %r3799
  %r3801 = inttoptr i64 %r3800 to ptr
  %r3802 = load double, ptr %r3801, align 8
  br label %arrlike.ic.range.722

arrlike.ic.length_spill_meta.719:                 ; preds = %arrlike.ic.bounds.717
  %r3803 = add nuw nsw i64 %r3683, 8
  %r3804 = inttoptr i64 %r3803 to ptr
  %r3805 = load i64, ptr %r3804, align 8
  %r3806 = icmp ne i64 %r3805, 0
  br i1 %r3806, label %arrlike.ic.length_spill_ptr.720, label %arrlike.ic.miss.727

arrlike.ic.length_spill_ptr.720:                  ; preds = %arrlike.ic.length_spill_meta.719
  %r3807 = inttoptr i64 %r3805 to ptr
  %r3808 = getelementptr i64, ptr %r3807, i64 4
  %r3809 = load i64, ptr %r3808, align 8
  %r3810 = icmp ne i64 %r3809, 0
  %r3811 = select i1 %r3810, i64 %r3809, i64 %r3805
  %r3812 = inttoptr i64 %r3811 to ptr
  %r3813 = load i32, ptr %r3812, align 4
  %r3814 = zext i32 %r3813 to i64
  %r3815 = icmp ult i64 %r3790, %r3814
  %r3816 = and i1 %r3810, %r3815
  br i1 %r3816, label %arrlike.ic.length_spill_load.721, label %arrlike.ic.miss.727

arrlike.ic.length_spill_load.721:                 ; preds = %arrlike.ic.length_spill_ptr.720
  %r3817 = add nuw nsw i64 %r3790, 1
  %r3818 = getelementptr inbounds nuw i64, ptr %r3812, i64 %r3817
  %r3819 = load double, ptr %r3818, align 8
  br label %arrlike.ic.range.722

arrlike.ic.range.722:                             ; preds = %arrlike.ic.length_spill_load.721, %arrlike.ic.length_inline.718
  %r3820 = phi double [ %r3802, %arrlike.ic.length_inline.718 ], [ %r3819, %arrlike.ic.length_spill_load.721 ]
  %r3821 = fcmp olt double 2.000000e+00, %r3820
  %r3822 = icmp ult i64 2, %r3794
  %r3823 = and i1 %r3821, %r3822
  %r3824 = add i64 %r3792, 2
  %r3825 = icmp ult i64 %r3824, %r3796
  %r3826 = and i1 %r3823, %r3825
  %r3827 = xor i1 %r3825, true
  %r3828 = and i1 %r3823, %r3827
  br i1 %r3826, label %arrlike.ic.inline.723, label %arrlike.ic.spill_or_miss.734

arrlike.ic.inline.723:                            ; preds = %arrlike.ic.range.722
  %r3829 = shl i64 %r3824, 3
  %r3830 = add i64 %r3829, 16
  %r3831 = add i64 %r3683, %r3830
  %r3832 = inttoptr i64 %r3831 to ptr
  %r3833 = load double, ptr %r3832, align 8
  br label %tav.get.merge.691

arrlike.ic.spill.724:                             ; preds = %arrlike.ic.spill_or_miss.734
  %r3834 = add nuw nsw i64 %r3683, 8
  %r3835 = inttoptr i64 %r3834 to ptr
  %r3836 = load i64, ptr %r3835, align 8
  %r3837 = icmp ne i64 %r3836, 0
  br i1 %r3837, label %arrlike.ic.spill_ptr.725, label %arrlike.ic.miss.727

arrlike.ic.spill_ptr.725:                         ; preds = %arrlike.ic.spill.724
  %r3838 = inttoptr i64 %r3836 to ptr
  %r3839 = getelementptr i64, ptr %r3838, i64 4
  %r3840 = load i64, ptr %r3839, align 8
  %r3841 = icmp ne i64 %r3840, 0
  %r3842 = select i1 %r3841, i64 %r3840, i64 %r3836
  %r3843 = inttoptr i64 %r3842 to ptr
  %r3844 = load i32, ptr %r3843, align 4
  %r3845 = zext i32 %r3844 to i64
  %r3846 = icmp ult i64 %r3824, %r3845
  %r3847 = and i1 %r3841, %r3846
  br i1 %r3847, label %arrlike.ic.spill_load.726, label %arrlike.ic.miss.727

arrlike.ic.spill_load.726:                        ; preds = %arrlike.ic.spill_ptr.725
  %r3848 = add nuw nsw i64 %r3824, 1
  %r3849 = getelementptr inbounds nuw i64, ptr %r3843, i64 %r3848
  %r3850 = load double, ptr %r3849, align 8
  br label %tav.get.merge.691

arrlike.ic.miss.727:                              ; preds = %arrlike.ic.spill_or_miss.734, %arrlike.elem.load.732, %arrlike.elem.bounds.731, %arrlike.elem.kind.728, %arrlike.ic.spill_ptr.725, %arrlike.ic.spill.724, %arrlike.ic.length_spill_ptr.720, %arrlike.ic.length_spill_meta.719, %arrlike.ic.family_token.716, %arrlike.ic.family_meta.715, %arrlike.ic.exact.714, %arrlike.ic.shape.712, %arrlike.ic.array_guard.710, %arrlike.ic.header.708, %tav.get.slow.690
  %statepoint_token549 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, ptr)) @js_packed_arraylike_index_get, i32 3, i32 0, double %r3585, double 2.000000e+00, ptr @perry_ic_test_json_tape_batch_records_ts__26, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s31, ptr addrspace(1) %.31146, ptr addrspace(1) %.41123, ptr addrspace(1) %.32, ptr addrspace(1) %.41135) ]
  %r3851550 = call double @llvm.experimental.gc.result.f64(token %statepoint_token549)
  %rs4gc.s31.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token549, i32 0, i32 0) ; (%rs4gc.s31, %rs4gc.s31)
  %rs4gc.s30.relocated551 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token549, i32 1, i32 1) ; (%.31146, %.31146)
  %r131.1.base.relocated552 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token549, i32 2, i32 2) ; (%.41123, %.41123)
  %rs4gc.s15.relocated553 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token549, i32 3, i32 3) ; (%.32, %.32)
  %r131.1.relocated554 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token549, i32 2, i32 4) ; (%.41123, %.41135)
  br label %tav.get.merge.691

arrlike.elem.kind.728:                            ; preds = %arrlike.ic.brand.709
  %r3707 = icmp eq i8 %r3699, 2
  br i1 %r3707, label %arrlike.elem.meta.729, label %arrlike.ic.miss.727

arrlike.elem.meta.729:                            ; preds = %arrlike.elem.kind.728
  %r3708 = add nuw nsw i64 %r3683, 8
  %r3709 = inttoptr i64 %r3708 to ptr
  %r3710 = load i64, ptr %r3709, align 8
  %r3711 = icmp ne i64 %r3710, 0
  br i1 %r3711, label %arrlike.elem.store.730, label %arrlike.ic.shape.712

arrlike.elem.store.730:                           ; preds = %arrlike.elem.meta.729
  %r3712 = inttoptr i64 %r3710 to ptr
  %r3713 = getelementptr i64, ptr %r3712, i64 12
  %r3714 = load i64, ptr %r3713, align 8
  %r3715 = icmp ne i64 %r3714, 0
  br i1 %r3715, label %arrlike.elem.bounds.731, label %arrlike.ic.shape.712

arrlike.elem.bounds.731:                          ; preds = %arrlike.elem.store.730
  %r3716 = sub i64 %r3714, 8
  %r3717 = inttoptr i64 %r3716 to ptr
  %r3718 = load i8, ptr %r3717, align 1
  %r3719 = icmp eq i8 %r3718, 1
  %r3720 = sub i64 %r3714, 7
  %r3721 = inttoptr i64 %r3720 to ptr
  %r3722 = load i8, ptr %r3721, align 1
  %r3723 = and i8 %r3722, -128
  %r3724 = icmp eq i8 %r3723, 0
  %r3725 = inttoptr i64 %r3714 to ptr
  %r3726 = load i32, ptr %r3725, align 4
  %r3727 = zext i32 %r3726 to i64
  %r3728 = icmp ult i64 2, %r3727
  %r3729 = and i1 %r3719, %r3724
  %r3730 = and i1 %r3729, %r3728
  br i1 %r3730, label %arrlike.elem.load.732, label %arrlike.ic.miss.727

arrlike.elem.load.732:                            ; preds = %arrlike.elem.bounds.731
  %r3732 = add i64 %r3714, 8
  %r3733 = add i64 %r3732, 16
  %r3734 = inttoptr i64 %r3733 to ptr
  %r3735 = load double, ptr %r3734, align 8
  %r3736 = bitcast double %r3735 to i64
  %r3737 = icmp eq i64 %r3736, 9222246136947933200
  br i1 %r3737, label %arrlike.ic.miss.727, label %arrlike.elem.value.733

arrlike.elem.value.733:                           ; preds = %arrlike.elem.load.732
  br label %tav.get.merge.691

arrlike.ic.spill_or_miss.734:                     ; preds = %arrlike.ic.range.722
  br i1 %r3828, label %arrlike.ic.spill.724, label %arrlike.ic.miss.727

pget.recv_sso.735:                                ; preds = %pget.recv_other.740
  %r3995 = load double, ptr @test_json_tape_batch_records_ts_.str.15.handle, align 8
  %r3996 = bitcast double %r3995 to i64
  %r3997 = and i64 %r3996, 281474976710655
  %statepoint_token555 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3853, i64 %r3997, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01152, ptr addrspace(1) %.41147, ptr addrspace(1) %.51124, ptr addrspace(1) %.33, ptr addrspace(1) %.51136) ]
  %r3998556 = call double @llvm.experimental.gc.result.f64(token %statepoint_token555)
  %rs4gc.s31.relocated557 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token555, i32 0, i32 0) ; (%.01152, %.01152)
  %rs4gc.s30.relocated558 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token555, i32 1, i32 1) ; (%.41147, %.41147)
  %r131.1.base.relocated559 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token555, i32 2, i32 2) ; (%.51124, %.51124)
  %rs4gc.s15.relocated560 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token555, i32 3, i32 3) ; (%.33, %.33)
  %r131.1.relocated561 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token555, i32 2, i32 4) ; (%.51124, %.51136)
  br label %pget.recv_merge.739

pget.recv_ok.736:                                 ; preds = %tav.get.merge.691
  %r3864 = icmp ugt i64 %r3854, 1048575
  br i1 %r3864, label %pic.recv_hdr.757, label %pic.miss.cold.754

pget.recv_bad.737:                                ; preds = %pget.check_class_ref.741
  %r3987 = icmp eq i64 %r3853, 9222246136947933185
  %r3988 = icmp eq i64 %r3853, 9222246136947933186
  %r3989 = or i1 %r3987, %r3988
  br i1 %r3989, label %pget.throw_nullish.764, label %pget.recv_undef_return.765

pget.recv_class_ref.738:                          ; preds = %pget.check_class_ref.741
  %r3860 = load double, ptr @test_json_tape_batch_records_ts_.str.15.handle, align 8
  %r3861 = bitcast double %r3860 to i64
  %r3862 = and i64 %r3861, 281474976710655
  %statepoint_token562 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 367713371643969563, i64 %r3853, i64 %r3862, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01152, ptr addrspace(1) %.41147, ptr addrspace(1) %.51124, ptr addrspace(1) %.33, ptr addrspace(1) %.51136) ]
  %r3863563 = call double @llvm.experimental.gc.result.f64(token %statepoint_token562)
  %rs4gc.s31.relocated564 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token562, i32 0, i32 0) ; (%.01152, %.01152)
  %rs4gc.s30.relocated565 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token562, i32 1, i32 1) ; (%.41147, %.41147)
  %r131.1.base.relocated566 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token562, i32 2, i32 2) ; (%.51124, %.51124)
  %rs4gc.s15.relocated567 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token562, i32 3, i32 3) ; (%.33, %.33)
  %r131.1.relocated568 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token562, i32 2, i32 4) ; (%.51124, %.51136)
  br label %pget.recv_merge.739

pget.recv_merge.739:                              ; preds = %pget.recv_undef_return.765, %pic.merge.756, %pget.recv_class_ref.738, %pget.recv_sso.735
  %.11153 = phi ptr addrspace(1) [ %.21154, %pic.merge.756 ], [ %rs4gc.s31.relocated557, %pget.recv_sso.735 ], [ %rs4gc.s31.relocated564, %pget.recv_class_ref.738 ], [ %rs4gc.s31.relocated586, %pget.recv_undef_return.765 ]
  %.51148 = phi ptr addrspace(1) [ %.61149, %pic.merge.756 ], [ %rs4gc.s30.relocated558, %pget.recv_sso.735 ], [ %rs4gc.s30.relocated565, %pget.recv_class_ref.738 ], [ %rs4gc.s30.relocated587, %pget.recv_undef_return.765 ]
  %.61137 = phi ptr addrspace(1) [ %.71138, %pic.merge.756 ], [ %r131.1.relocated561, %pget.recv_sso.735 ], [ %r131.1.relocated568, %pget.recv_class_ref.738 ], [ %r131.1.relocated590, %pget.recv_undef_return.765 ]
  %.61125 = phi ptr addrspace(1) [ %.71126, %pic.merge.756 ], [ %r131.1.base.relocated559, %pget.recv_sso.735 ], [ %r131.1.base.relocated566, %pget.recv_class_ref.738 ], [ %r131.1.base.relocated588, %pget.recv_undef_return.765 ]
  %.34 = phi ptr addrspace(1) [ %.35, %pic.merge.756 ], [ %rs4gc.s15.relocated560, %pget.recv_sso.735 ], [ %rs4gc.s15.relocated567, %pget.recv_class_ref.738 ], [ %rs4gc.s15.relocated589, %pget.recv_undef_return.765 ]
  %r3999 = phi double [ %r3986, %pic.merge.756 ], [ %r3994585, %pget.recv_undef_return.765 ], [ %r3998556, %pget.recv_sso.735 ], [ %r3863563, %pget.recv_class_ref.738 ]
  %r4000 = bitcast double %r3999 to i64
  %r4001 = and i64 %r4000, 281474976710655
  %r4002 = lshr i64 %r4000, 48
  %r4003 = and i64 %r4002, 65533
  %r4004 = icmp eq i64 %r4003, 32765
  br i1 %r4004, label %pget.recv_ok.767, label %pget.recv_other.772

pget.recv_other.740:                              ; preds = %tav.get.merge.691
  %r3858 = icmp eq i64 %r3855, 32761
  br i1 %r3858, label %pget.recv_sso.735, label %pget.check_class_ref.741

pget.check_class_ref.741:                         ; preds = %pget.recv_other.740
  %r3859 = icmp eq i64 %r3855, 32766
  br i1 %r3859, label %pget.recv_class_ref.738, label %pget.recv_bad.737

pic.hit.742:                                      ; preds = %pic.token.758
  %r3889 = getelementptr i64, ptr %r3874, i64 1
  %r3890 = load i64, ptr %r3889, align 8
  %r3891 = and i64 %r3890, 1073741824
  %r3892 = icmp ne i64 %r3891, 0
  br i1 %r3892, label %pic.hit.overflow.759, label %pic.hit.inline.760

pic.hit.live.743:                                 ; preds = %pic.hit.inline.760
  br label %pic.merge.756

pic.prefix.guard.744:                             ; preds = %pic.token.758
  %r3905 = getelementptr i64, ptr %r3874, i64 2
  %r3906 = load i64, ptr %r3905, align 8
  %r3907 = icmp ne i64 %r3906, 0
  br i1 %r3907, label %pic.prefix.meta.745, label %pic.miss.753

pic.prefix.meta.745:                              ; preds = %pic.prefix.guard.744
  %r3908 = add nuw nsw i64 %r3854, 8
  %r3909 = inttoptr i64 %r3908 to ptr
  %r3910 = load i64, ptr %r3909, align 8
  %r3911 = icmp ne i64 %r3910, 0
  br i1 %r3911, label %pic.prefix.token.746, label %pic.miss.753

pic.prefix.token.746:                             ; preds = %pic.prefix.meta.745
  %r3912 = inttoptr i64 %r3910 to ptr
  %r3913 = getelementptr i64, ptr %r3912, i64 6
  %r3914 = load i64, ptr %r3913, align 8
  %r3915 = icmp eq i64 %r3914, %r3906
  br i1 %r3915, label %pic.prefix.hit.747, label %pic.miss.753

pic.prefix.hit.747:                               ; preds = %pic.prefix.token.746
  %r3916 = getelementptr i64, ptr %r3874, i64 1
  %r3917 = load i64, ptr %r3916, align 8
  %r3918 = shl i64 %r3917, 3
  %r3919 = add nuw nsw i64 %r3854, 16
  %r3920 = add i64 %r3919, %r3918
  %r3921 = inttoptr i64 %r3920 to ptr
  %r3922 = load double, ptr %r3921, align 8
  br label %pic.merge.756

pic.desc.classify.748:                            ; preds = %pic.recv_hdr.757
  %r3878 = and i1 %r3868, %r3875
  br i1 %r3878, label %pic.desc.prefix.guard.749, label %pic.miss.cold.754

pic.desc.prefix.guard.749:                        ; preds = %pic.desc.classify.748
  %r3923 = getelementptr i64, ptr %r3874, i64 2
  %r3924 = load i64, ptr %r3923, align 8
  %r3925 = icmp ne i64 %r3924, 0
  br i1 %r3925, label %pic.desc.prefix.meta.750, label %pic.miss.cold.754

pic.desc.prefix.meta.750:                         ; preds = %pic.desc.prefix.guard.749
  %r3926 = add nuw nsw i64 %r3854, 8
  %r3927 = inttoptr i64 %r3926 to ptr
  %r3928 = load i64, ptr %r3927, align 8
  %r3929 = icmp ne i64 %r3928, 0
  br i1 %r3929, label %pic.desc.prefix.token.751, label %pic.miss.cold.754

pic.desc.prefix.token.751:                        ; preds = %pic.desc.prefix.meta.750
  %r3930 = inttoptr i64 %r3928 to ptr
  %r3931 = getelementptr i64, ptr %r3930, i64 6
  %r3932 = load i64, ptr %r3931, align 8
  %r3933 = icmp eq i64 %r3932, %r3924
  br i1 %r3933, label %pic.desc.prefix.hit.752, label %pic.miss.cold.754

pic.desc.prefix.hit.752:                          ; preds = %pic.desc.prefix.token.751
  %r3934 = getelementptr i64, ptr %r3874, i64 1
  %r3935 = load i64, ptr %r3934, align 8
  %r3936 = shl i64 %r3935, 3
  %r3937 = add nuw nsw i64 %r3854, 16
  %r3938 = add i64 %r3937, %r3936
  %r3939 = inttoptr i64 %r3938 to ptr
  %r3940 = load double, ptr %r3939, align 8
  br label %pic.merge.756

pic.miss.753:                                     ; preds = %pic.hit.inline.760, %pic.prefix.token.746, %pic.prefix.meta.745, %pic.prefix.guard.744
  %r3941 = getelementptr i64, ptr %r3874, i64 3
  %r3942 = load i64, ptr %r3941, align 8
  %r3943 = icmp sgt i64 %r3942, 0
  br i1 %r3943, label %pic.ways.761, label %pic.miss.call.755

pic.miss.cold.754:                                ; preds = %pic.desc.prefix.token.751, %pic.desc.prefix.meta.750, %pic.desc.prefix.guard.749, %pic.desc.classify.748, %pget.recv_ok.736
  br label %pic.miss.call.755

pic.miss.call.755:                                ; preds = %pic.way.load.762, %pic.ways.761, %pic.miss.cold.754, %pic.miss.753
  %r3982 = load double, ptr @test_json_tape_batch_records_ts_.str.15.handle, align 8
  %r3983 = bitcast double %r3982 to i64
  %r3984 = and i64 %r3983, 281474976710655
  %statepoint_token569 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r3854, i64 %r3984, ptr @perry_ic_test_json_tape_batch_records_ts__28, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01152, ptr addrspace(1) %.41147, ptr addrspace(1) %.51124, ptr addrspace(1) %.33, ptr addrspace(1) %.51136) ]
  %r3985570 = call double @llvm.experimental.gc.result.f64(token %statepoint_token569)
  %rs4gc.s31.relocated571 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token569, i32 0, i32 0) ; (%.01152, %.01152)
  %rs4gc.s30.relocated572 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token569, i32 1, i32 1) ; (%.41147, %.41147)
  %r131.1.base.relocated573 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token569, i32 2, i32 2) ; (%.51124, %.51124)
  %rs4gc.s15.relocated574 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token569, i32 3, i32 3) ; (%.33, %.33)
  %r131.1.relocated575 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token569, i32 2, i32 4) ; (%.51124, %.51136)
  br label %pic.merge.756

pic.merge.756:                                    ; preds = %pic.way.live.763, %pic.hit.overflow.759, %pic.miss.call.755, %pic.desc.prefix.hit.752, %pic.prefix.hit.747, %pic.hit.live.743
  %.21154 = phi ptr addrspace(1) [ %rs4gc.s31.relocated578, %pic.hit.overflow.759 ], [ %rs4gc.s31.relocated571, %pic.miss.call.755 ], [ %.01152, %pic.way.live.763 ], [ %.01152, %pic.hit.live.743 ], [ %.01152, %pic.prefix.hit.747 ], [ %.01152, %pic.desc.prefix.hit.752 ]
  %.61149 = phi ptr addrspace(1) [ %rs4gc.s30.relocated579, %pic.hit.overflow.759 ], [ %rs4gc.s30.relocated572, %pic.miss.call.755 ], [ %.41147, %pic.way.live.763 ], [ %.41147, %pic.hit.live.743 ], [ %.41147, %pic.prefix.hit.747 ], [ %.41147, %pic.desc.prefix.hit.752 ]
  %.71138 = phi ptr addrspace(1) [ %r131.1.relocated582, %pic.hit.overflow.759 ], [ %r131.1.relocated575, %pic.miss.call.755 ], [ %.51136, %pic.way.live.763 ], [ %.51136, %pic.hit.live.743 ], [ %.51136, %pic.prefix.hit.747 ], [ %.51136, %pic.desc.prefix.hit.752 ]
  %.71126 = phi ptr addrspace(1) [ %r131.1.base.relocated580, %pic.hit.overflow.759 ], [ %r131.1.base.relocated573, %pic.miss.call.755 ], [ %.51124, %pic.way.live.763 ], [ %.51124, %pic.hit.live.743 ], [ %.51124, %pic.prefix.hit.747 ], [ %.51124, %pic.desc.prefix.hit.752 ]
  %.35 = phi ptr addrspace(1) [ %rs4gc.s15.relocated581, %pic.hit.overflow.759 ], [ %rs4gc.s15.relocated574, %pic.miss.call.755 ], [ %.33, %pic.way.live.763 ], [ %.33, %pic.hit.live.743 ], [ %.33, %pic.prefix.hit.747 ], [ %.33, %pic.desc.prefix.hit.752 ]
  %r3986 = phi double [ %r3902, %pic.hit.live.743 ], [ %r3897577, %pic.hit.overflow.759 ], [ %r3922, %pic.prefix.hit.747 ], [ %r3940, %pic.desc.prefix.hit.752 ], [ %r3979, %pic.way.live.763 ], [ %r3985570, %pic.miss.call.755 ]
  br label %pget.recv_merge.739

pic.recv_hdr.757:                                 ; preds = %pget.recv_ok.736
  %r3865 = sub nuw nsw i64 %r3854, 8
  %r3866 = inttoptr i64 %r3865 to ptr
  %r3867 = load i8, ptr %r3866, align 1
  %r3868 = icmp eq i8 %r3867, 2
  %r3869 = sub nuw nsw i64 %r3854, 6
  %r3870 = inttoptr i64 %r3869 to ptr
  %r3871 = load i16, ptr %r3870, align 2
  %r3872 = and i16 %r3871, 2048
  %r3873 = icmp eq i16 %r3872, 0
  %r3874 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__28, align 8
  %r3875 = icmp ne ptr %r3874, null
  %r3876 = and i1 %r3868, %r3873
  %r3877 = and i1 %r3876, %r3875
  br i1 %r3877, label %pic.token.758, label %pic.desc.classify.748

pic.token.758:                                    ; preds = %pic.recv_hdr.757
  %r3879 = add nuw nsw i64 %r3854, 4
  %r3880 = inttoptr i64 %r3879 to ptr
  %r3881 = load i32, ptr %r3880, align 4
  %r3882 = zext i32 %r3881 to i64
  %r3883 = or i64 %r3882, 4611686018427387904
  %r3884 = icmp ne i32 %r3881, 0
  %r3885 = getelementptr i64, ptr %r3874, i64 0
  %r3886 = load i64, ptr %r3885, align 8
  %r3887 = icmp eq i64 %r3883, %r3886
  %r3888 = and i1 %r3887, %r3884
  br i1 %r3888, label %pic.hit.742, label %pic.prefix.guard.744

pic.hit.overflow.759:                             ; preds = %pic.hit.742
  %r3893 = load double, ptr @test_json_tape_batch_records_ts_.str.15.handle, align 8
  %r3894 = bitcast double %r3893 to i64
  %r3895 = and i64 %r3894, 281474976710655
  %r3896 = trunc i64 %r3890 to i32
  %statepoint_token576 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r3854, i64 %r3895, i32 %r3896, ptr @perry_ic_test_json_tape_batch_records_ts__28, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01152, ptr addrspace(1) %.41147, ptr addrspace(1) %.51124, ptr addrspace(1) %.33, ptr addrspace(1) %.51136) ]
  %r3897577 = call double @llvm.experimental.gc.result.f64(token %statepoint_token576)
  %rs4gc.s31.relocated578 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token576, i32 0, i32 0) ; (%.01152, %.01152)
  %rs4gc.s30.relocated579 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token576, i32 1, i32 1) ; (%.41147, %.41147)
  %r131.1.base.relocated580 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token576, i32 2, i32 2) ; (%.51124, %.51124)
  %rs4gc.s15.relocated581 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token576, i32 3, i32 3) ; (%.33, %.33)
  %r131.1.relocated582 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token576, i32 2, i32 4) ; (%.51124, %.51136)
  br label %pic.merge.756

pic.hit.inline.760:                               ; preds = %pic.hit.742
  %r3898 = shl i64 %r3890, 3
  %r3899 = add nuw nsw i64 %r3854, 16
  %r3900 = add i64 %r3899, %r3898
  %r3901 = inttoptr i64 %r3900 to ptr
  %r3902 = load double, ptr %r3901, align 8
  %r3903 = bitcast double %r3902 to i64
  %r3904 = icmp eq i64 %r3903, 9222246136947933200
  br i1 %r3904, label %pic.miss.753, label %pic.hit.live.743

pic.ways.761:                                     ; preds = %pic.miss.753
  %r3944 = getelementptr i64, ptr %r3874, i64 4
  %r3945 = load i64, ptr %r3944, align 8
  %r3946 = icmp eq i64 %r3945, %r3883
  %r3947 = getelementptr i64, ptr %r3874, i64 5
  %r3948 = load i64, ptr %r3947, align 8
  %r3949 = select i1 %r3946, i64 %r3948, i64 0
  %r3950 = getelementptr i64, ptr %r3874, i64 6
  %r3951 = load i64, ptr %r3950, align 8
  %r3952 = icmp eq i64 %r3951, %r3883
  %r3953 = getelementptr i64, ptr %r3874, i64 7
  %r3954 = load i64, ptr %r3953, align 8
  %r3955 = select i1 %r3952, i64 %r3954, i64 0
  %r3956 = getelementptr i64, ptr %r3874, i64 8
  %r3957 = load i64, ptr %r3956, align 8
  %r3958 = icmp eq i64 %r3957, %r3883
  %r3959 = getelementptr i64, ptr %r3874, i64 9
  %r3960 = load i64, ptr %r3959, align 8
  %r3961 = select i1 %r3958, i64 %r3960, i64 0
  %r3962 = getelementptr i64, ptr %r3874, i64 10
  %r3963 = load i64, ptr %r3962, align 8
  %r3964 = icmp eq i64 %r3963, %r3883
  %r3965 = getelementptr i64, ptr %r3874, i64 11
  %r3966 = load i64, ptr %r3965, align 8
  %r3967 = select i1 %r3964, i64 %r3966, i64 0
  %r3968 = or i1 %r3946, %r3952
  %r3969 = select i1 %r3946, i64 %r3949, i64 %r3955
  %r3970 = or i1 %r3958, %r3964
  %r3971 = select i1 %r3958, i64 %r3961, i64 %r3967
  %r3972 = or i1 %r3968, %r3970
  %r3973 = select i1 %r3968, i64 %r3969, i64 %r3971
  %r3974 = and i1 %r3884, %r3972
  br i1 %r3974, label %pic.way.load.762, label %pic.miss.call.755

pic.way.load.762:                                 ; preds = %pic.ways.761
  %r3975 = shl i64 %r3973, 3
  %r3976 = add nuw nsw i64 %r3854, 16
  %r3977 = add i64 %r3976, %r3975
  %r3978 = inttoptr i64 %r3977 to ptr
  %r3979 = load double, ptr %r3978, align 8
  %r3980 = bitcast double %r3979 to i64
  %r3981 = icmp eq i64 %r3980, 9222246136947933200
  br i1 %r3981, label %pic.miss.call.755, label %pic.way.live.763

pic.way.live.763:                                 ; preds = %pic.way.load.762
  br label %pic.merge.756

pget.throw_nullish.764:                           ; preds = %pget.recv_bad.737
  %r3990 = zext i1 %r3988 to i32
  %statepoint_token583 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r3990, ptr @test_json_tape_batch_records_ts_.str.15.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.765:                       ; preds = %pget.recv_bad.737
  %r3991 = load double, ptr @test_json_tape_batch_records_ts_.str.15.handle, align 8
  %r3992 = bitcast double %r3991 to i64
  %r3993 = and i64 %r3992, 281474976710655
  %statepoint_token584 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3853, i64 %r3993, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01152, ptr addrspace(1) %.41147, ptr addrspace(1) %.51124, ptr addrspace(1) %.33, ptr addrspace(1) %.51136) ]
  %r3994585 = call double @llvm.experimental.gc.result.f64(token %statepoint_token584)
  %rs4gc.s31.relocated586 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token584, i32 0, i32 0) ; (%.01152, %.01152)
  %rs4gc.s30.relocated587 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token584, i32 1, i32 1) ; (%.41147, %.41147)
  %r131.1.base.relocated588 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token584, i32 2, i32 2) ; (%.51124, %.51124)
  %rs4gc.s15.relocated589 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token584, i32 3, i32 3) ; (%.33, %.33)
  %r131.1.relocated590 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token584, i32 2, i32 4) ; (%.51124, %.51136)
  br label %pget.recv_merge.739

pget.recv_sso.766:                                ; preds = %pget.recv_other.772
  %r4143 = lshr i64 %r4000, 40
  %r4144 = and i64 %r4143, 255
  %r4145 = uitofp nneg i64 %r4144 to double
  br label %pget.recv_merge.770

pget.recv_ok.767:                                 ; preds = %pget.recv_merge.739
  %r4011 = icmp eq i64 %r4002, 32767
  br i1 %r4011, label %pget.strlen_heap.771, label %pget.recv_obj.774

pget.recv_bad.768:                                ; preds = %pget.check_class_ref.773
  %r4135 = icmp eq i64 %r4000, 9222246136947933185
  %r4136 = icmp eq i64 %r4000, 9222246136947933186
  %r4137 = or i1 %r4135, %r4136
  br i1 %r4137, label %pget.throw_nullish.797, label %pget.recv_undef_return.798

pget.recv_class_ref.769:                          ; preds = %pget.check_class_ref.773
  %r4007 = load double, ptr @test_json_tape_batch_records_ts_.str.19.handle, align 8
  %r4008 = bitcast double %r4007 to i64
  %r4009 = and i64 %r4008, 281474976710655
  %statepoint_token591 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 367713371643969565, i64 %r4000, i64 %r4009, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61125, ptr addrspace(1) %.34, ptr addrspace(1) %.51148, ptr addrspace(1) %.11153, ptr addrspace(1) %.61137) ]
  %r4010592 = call double @llvm.experimental.gc.result.f64(token %statepoint_token591)
  %r131.1.base.relocated593 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token591, i32 0, i32 0) ; (%.61125, %.61125)
  %rs4gc.s15.relocated594 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token591, i32 1, i32 1) ; (%.34, %.34)
  %rs4gc.s30.relocated595 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token591, i32 2, i32 2) ; (%.51148, %.51148)
  %rs4gc.s31.relocated596 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token591, i32 3, i32 3) ; (%.11153, %.11153)
  %r131.1.relocated597 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token591, i32 0, i32 4) ; (%.61125, %.61137)
  br label %pget.recv_merge.770

pget.recv_merge.770:                              ; preds = %pget.recv_undef_return.798, %pic.merge.789, %pget.strlen_heap.771, %pget.recv_class_ref.769, %pget.recv_sso.766
  %.31155 = phi ptr addrspace(1) [ %.11153, %pget.strlen_heap.771 ], [ %.41156, %pic.merge.789 ], [ %.11153, %pget.recv_sso.766 ], [ %rs4gc.s31.relocated596, %pget.recv_class_ref.769 ], [ %rs4gc.s31.relocated618, %pget.recv_undef_return.798 ]
  %.71150 = phi ptr addrspace(1) [ %.51148, %pget.strlen_heap.771 ], [ %.81151, %pic.merge.789 ], [ %.51148, %pget.recv_sso.766 ], [ %rs4gc.s30.relocated595, %pget.recv_class_ref.769 ], [ %rs4gc.s30.relocated617, %pget.recv_undef_return.798 ]
  %.81139 = phi ptr addrspace(1) [ %.61137, %pget.strlen_heap.771 ], [ %.91140, %pic.merge.789 ], [ %.61137, %pget.recv_sso.766 ], [ %r131.1.relocated597, %pget.recv_class_ref.769 ], [ %r131.1.relocated619, %pget.recv_undef_return.798 ]
  %.81127 = phi ptr addrspace(1) [ %.61125, %pget.strlen_heap.771 ], [ %.91128, %pic.merge.789 ], [ %.61125, %pget.recv_sso.766 ], [ %r131.1.base.relocated593, %pget.recv_class_ref.769 ], [ %r131.1.base.relocated615, %pget.recv_undef_return.798 ]
  %.36 = phi ptr addrspace(1) [ %.34, %pget.strlen_heap.771 ], [ %.37, %pic.merge.789 ], [ %.34, %pget.recv_sso.766 ], [ %rs4gc.s15.relocated594, %pget.recv_class_ref.769 ], [ %rs4gc.s15.relocated616, %pget.recv_undef_return.798 ]
  %r4151 = phi double [ %r4134, %pic.merge.789 ], [ %r4142614, %pget.recv_undef_return.798 ], [ %r4145, %pget.recv_sso.766 ], [ %r4010592, %pget.recv_class_ref.769 ], [ %r4150, %pget.strlen_heap.771 ]
  %r4152.rs4i = ptrtoint ptr addrspace(1) %.71150 to i64
  %r4152 = call i64 asm "", "=r,0"(i64 %r4152.rs4i) #7
  %r4153 = bitcast i64 %r4152 to double
  %r4154.rs4i = ptrtoint ptr addrspace(1) %.31155 to i64
  %r4154 = call i64 asm "", "=r,0"(i64 %r4154.rs4i) #7
  %r4155 = bitcast i64 %r4154 to double
  %r4156 = and i64 %r4152, -281474976710656
  %r4157 = icmp ult i64 %r4156, 9221401712017801216
  %r4158 = icmp ugt i64 %r4156, 9223090561878065152
  %r4159 = or i1 %r4157, %r4158
  %r4160 = and i64 %r4154, -281474976710656
  %r4161 = icmp ult i64 %r4160, 9221401712017801216
  %r4162 = icmp ugt i64 %r4160, 9223090561878065152
  %r4163 = or i1 %r4161, %r4162
  %r4164 = and i1 %r4159, %r4163
  %r4165 = bitcast double %r4151 to i64
  %r4166 = and i64 %r4165, -281474976710656
  %r4167 = icmp ult i64 %r4166, 9221401712017801216
  %r4168 = icmp ugt i64 %r4166, 9223090561878065152
  %r4169 = or i1 %r4167, %r4168
  %r4170 = and i1 %r4164, %r4169
  br i1 %r4170, label %guarded_add.numeric.799, label %guarded_add.dynamic.800

pget.strlen_heap.771:                             ; preds = %pget.recv_ok.767
  %r4146 = icmp ult i64 %r4001, 4096
  %r4147 = inttoptr i64 %r4001 to ptr
  %r4148 = select i1 %r4146, ptr @perry_null_guard_zero_test_json_tape_batch_records_ts, ptr %r4147
  %r4149 = load i32, ptr %r4148, align 4
  %r4150 = uitofp i32 %r4149 to double
  br label %pget.recv_merge.770

pget.recv_other.772:                              ; preds = %pget.recv_merge.739
  %r4005 = icmp eq i64 %r4002, 32761
  br i1 %r4005, label %pget.recv_sso.766, label %pget.check_class_ref.773

pget.check_class_ref.773:                         ; preds = %pget.recv_other.772
  %r4006 = icmp eq i64 %r4002, 32766
  br i1 %r4006, label %pget.recv_class_ref.769, label %pget.recv_bad.768

pget.recv_obj.774:                                ; preds = %pget.recv_ok.767
  %r4012 = icmp ugt i64 %r4001, 1048575
  br i1 %r4012, label %pic.recv_hdr.790, label %pic.miss.cold.787

pic.hit.775:                                      ; preds = %pic.token.791
  %r4037 = getelementptr i64, ptr %r4022, i64 1
  %r4038 = load i64, ptr %r4037, align 8
  %r4039 = and i64 %r4038, 1073741824
  %r4040 = icmp ne i64 %r4039, 0
  br i1 %r4040, label %pic.hit.overflow.792, label %pic.hit.inline.793

pic.hit.live.776:                                 ; preds = %pic.hit.inline.793
  br label %pic.merge.789

pic.prefix.guard.777:                             ; preds = %pic.token.791
  %r4053 = getelementptr i64, ptr %r4022, i64 2
  %r4054 = load i64, ptr %r4053, align 8
  %r4055 = icmp ne i64 %r4054, 0
  br i1 %r4055, label %pic.prefix.meta.778, label %pic.miss.786

pic.prefix.meta.778:                              ; preds = %pic.prefix.guard.777
  %r4056 = add nuw nsw i64 %r4001, 8
  %r4057 = inttoptr i64 %r4056 to ptr
  %r4058 = load i64, ptr %r4057, align 8
  %r4059 = icmp ne i64 %r4058, 0
  br i1 %r4059, label %pic.prefix.token.779, label %pic.miss.786

pic.prefix.token.779:                             ; preds = %pic.prefix.meta.778
  %r4060 = inttoptr i64 %r4058 to ptr
  %r4061 = getelementptr i64, ptr %r4060, i64 6
  %r4062 = load i64, ptr %r4061, align 8
  %r4063 = icmp eq i64 %r4062, %r4054
  br i1 %r4063, label %pic.prefix.hit.780, label %pic.miss.786

pic.prefix.hit.780:                               ; preds = %pic.prefix.token.779
  %r4064 = getelementptr i64, ptr %r4022, i64 1
  %r4065 = load i64, ptr %r4064, align 8
  %r4066 = shl i64 %r4065, 3
  %r4067 = add nuw nsw i64 %r4001, 16
  %r4068 = add i64 %r4067, %r4066
  %r4069 = inttoptr i64 %r4068 to ptr
  %r4070 = load double, ptr %r4069, align 8
  br label %pic.merge.789

pic.desc.classify.781:                            ; preds = %pic.recv_hdr.790
  %r4026 = and i1 %r4016, %r4023
  br i1 %r4026, label %pic.desc.prefix.guard.782, label %pic.miss.cold.787

pic.desc.prefix.guard.782:                        ; preds = %pic.desc.classify.781
  %r4071 = getelementptr i64, ptr %r4022, i64 2
  %r4072 = load i64, ptr %r4071, align 8
  %r4073 = icmp ne i64 %r4072, 0
  br i1 %r4073, label %pic.desc.prefix.meta.783, label %pic.miss.cold.787

pic.desc.prefix.meta.783:                         ; preds = %pic.desc.prefix.guard.782
  %r4074 = add nuw nsw i64 %r4001, 8
  %r4075 = inttoptr i64 %r4074 to ptr
  %r4076 = load i64, ptr %r4075, align 8
  %r4077 = icmp ne i64 %r4076, 0
  br i1 %r4077, label %pic.desc.prefix.token.784, label %pic.miss.cold.787

pic.desc.prefix.token.784:                        ; preds = %pic.desc.prefix.meta.783
  %r4078 = inttoptr i64 %r4076 to ptr
  %r4079 = getelementptr i64, ptr %r4078, i64 6
  %r4080 = load i64, ptr %r4079, align 8
  %r4081 = icmp eq i64 %r4080, %r4072
  br i1 %r4081, label %pic.desc.prefix.hit.785, label %pic.miss.cold.787

pic.desc.prefix.hit.785:                          ; preds = %pic.desc.prefix.token.784
  %r4082 = getelementptr i64, ptr %r4022, i64 1
  %r4083 = load i64, ptr %r4082, align 8
  %r4084 = shl i64 %r4083, 3
  %r4085 = add nuw nsw i64 %r4001, 16
  %r4086 = add i64 %r4085, %r4084
  %r4087 = inttoptr i64 %r4086 to ptr
  %r4088 = load double, ptr %r4087, align 8
  br label %pic.merge.789

pic.miss.786:                                     ; preds = %pic.hit.inline.793, %pic.prefix.token.779, %pic.prefix.meta.778, %pic.prefix.guard.777
  %r4089 = getelementptr i64, ptr %r4022, i64 3
  %r4090 = load i64, ptr %r4089, align 8
  %r4091 = icmp sgt i64 %r4090, 0
  br i1 %r4091, label %pic.ways.794, label %pic.miss.call.788

pic.miss.cold.787:                                ; preds = %pic.desc.prefix.token.784, %pic.desc.prefix.meta.783, %pic.desc.prefix.guard.782, %pic.desc.classify.781, %pget.recv_obj.774
  br label %pic.miss.call.788

pic.miss.call.788:                                ; preds = %pic.way.load.795, %pic.ways.794, %pic.miss.cold.787, %pic.miss.786
  %r4130 = load double, ptr @test_json_tape_batch_records_ts_.str.19.handle, align 8
  %r4131 = bitcast double %r4130 to i64
  %r4132 = and i64 %r4131, 281474976710655
  %statepoint_token598 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r4001, i64 %r4132, ptr @perry_ic_test_json_tape_batch_records_ts__30, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61125, ptr addrspace(1) %.34, ptr addrspace(1) %.51148, ptr addrspace(1) %.11153, ptr addrspace(1) %.61137) ]
  %r4133599 = call double @llvm.experimental.gc.result.f64(token %statepoint_token598)
  %r131.1.base.relocated600 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token598, i32 0, i32 0) ; (%.61125, %.61125)
  %rs4gc.s15.relocated601 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token598, i32 1, i32 1) ; (%.34, %.34)
  %rs4gc.s30.relocated602 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token598, i32 2, i32 2) ; (%.51148, %.51148)
  %rs4gc.s31.relocated603 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token598, i32 3, i32 3) ; (%.11153, %.11153)
  %r131.1.relocated604 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token598, i32 0, i32 4) ; (%.61125, %.61137)
  br label %pic.merge.789

pic.merge.789:                                    ; preds = %pic.way.live.796, %pic.hit.overflow.792, %pic.miss.call.788, %pic.desc.prefix.hit.785, %pic.prefix.hit.780, %pic.hit.live.776
  %.41156 = phi ptr addrspace(1) [ %rs4gc.s31.relocated610, %pic.hit.overflow.792 ], [ %rs4gc.s31.relocated603, %pic.miss.call.788 ], [ %.11153, %pic.way.live.796 ], [ %.11153, %pic.hit.live.776 ], [ %.11153, %pic.prefix.hit.780 ], [ %.11153, %pic.desc.prefix.hit.785 ]
  %.81151 = phi ptr addrspace(1) [ %rs4gc.s30.relocated609, %pic.hit.overflow.792 ], [ %rs4gc.s30.relocated602, %pic.miss.call.788 ], [ %.51148, %pic.way.live.796 ], [ %.51148, %pic.hit.live.776 ], [ %.51148, %pic.prefix.hit.780 ], [ %.51148, %pic.desc.prefix.hit.785 ]
  %.91140 = phi ptr addrspace(1) [ %r131.1.relocated611, %pic.hit.overflow.792 ], [ %r131.1.relocated604, %pic.miss.call.788 ], [ %.61137, %pic.way.live.796 ], [ %.61137, %pic.hit.live.776 ], [ %.61137, %pic.prefix.hit.780 ], [ %.61137, %pic.desc.prefix.hit.785 ]
  %.91128 = phi ptr addrspace(1) [ %r131.1.base.relocated607, %pic.hit.overflow.792 ], [ %r131.1.base.relocated600, %pic.miss.call.788 ], [ %.61125, %pic.way.live.796 ], [ %.61125, %pic.hit.live.776 ], [ %.61125, %pic.prefix.hit.780 ], [ %.61125, %pic.desc.prefix.hit.785 ]
  %.37 = phi ptr addrspace(1) [ %rs4gc.s15.relocated608, %pic.hit.overflow.792 ], [ %rs4gc.s15.relocated601, %pic.miss.call.788 ], [ %.34, %pic.way.live.796 ], [ %.34, %pic.hit.live.776 ], [ %.34, %pic.prefix.hit.780 ], [ %.34, %pic.desc.prefix.hit.785 ]
  %r4134 = phi double [ %r4050, %pic.hit.live.776 ], [ %r4045606, %pic.hit.overflow.792 ], [ %r4070, %pic.prefix.hit.780 ], [ %r4088, %pic.desc.prefix.hit.785 ], [ %r4127, %pic.way.live.796 ], [ %r4133599, %pic.miss.call.788 ]
  br label %pget.recv_merge.770

pic.recv_hdr.790:                                 ; preds = %pget.recv_obj.774
  %r4013 = sub nuw nsw i64 %r4001, 8
  %r4014 = inttoptr i64 %r4013 to ptr
  %r4015 = load i8, ptr %r4014, align 1
  %r4016 = icmp eq i8 %r4015, 2
  %r4017 = sub nuw nsw i64 %r4001, 6
  %r4018 = inttoptr i64 %r4017 to ptr
  %r4019 = load i16, ptr %r4018, align 2
  %r4020 = and i16 %r4019, 2048
  %r4021 = icmp eq i16 %r4020, 0
  %r4022 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__30, align 8
  %r4023 = icmp ne ptr %r4022, null
  %r4024 = and i1 %r4016, %r4021
  %r4025 = and i1 %r4024, %r4023
  br i1 %r4025, label %pic.token.791, label %pic.desc.classify.781

pic.token.791:                                    ; preds = %pic.recv_hdr.790
  %r4027 = add nuw nsw i64 %r4001, 4
  %r4028 = inttoptr i64 %r4027 to ptr
  %r4029 = load i32, ptr %r4028, align 4
  %r4030 = zext i32 %r4029 to i64
  %r4031 = or i64 %r4030, 4611686018427387904
  %r4032 = icmp ne i32 %r4029, 0
  %r4033 = getelementptr i64, ptr %r4022, i64 0
  %r4034 = load i64, ptr %r4033, align 8
  %r4035 = icmp eq i64 %r4031, %r4034
  %r4036 = and i1 %r4035, %r4032
  br i1 %r4036, label %pic.hit.775, label %pic.prefix.guard.777

pic.hit.overflow.792:                             ; preds = %pic.hit.775
  %r4041 = load double, ptr @test_json_tape_batch_records_ts_.str.19.handle, align 8
  %r4042 = bitcast double %r4041 to i64
  %r4043 = and i64 %r4042, 281474976710655
  %r4044 = trunc i64 %r4038 to i32
  %statepoint_token605 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r4001, i64 %r4043, i32 %r4044, ptr @perry_ic_test_json_tape_batch_records_ts__30, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61125, ptr addrspace(1) %.34, ptr addrspace(1) %.51148, ptr addrspace(1) %.11153, ptr addrspace(1) %.61137) ]
  %r4045606 = call double @llvm.experimental.gc.result.f64(token %statepoint_token605)
  %r131.1.base.relocated607 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token605, i32 0, i32 0) ; (%.61125, %.61125)
  %rs4gc.s15.relocated608 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token605, i32 1, i32 1) ; (%.34, %.34)
  %rs4gc.s30.relocated609 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token605, i32 2, i32 2) ; (%.51148, %.51148)
  %rs4gc.s31.relocated610 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token605, i32 3, i32 3) ; (%.11153, %.11153)
  %r131.1.relocated611 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token605, i32 0, i32 4) ; (%.61125, %.61137)
  br label %pic.merge.789

pic.hit.inline.793:                               ; preds = %pic.hit.775
  %r4046 = shl i64 %r4038, 3
  %r4047 = add nuw nsw i64 %r4001, 16
  %r4048 = add i64 %r4047, %r4046
  %r4049 = inttoptr i64 %r4048 to ptr
  %r4050 = load double, ptr %r4049, align 8
  %r4051 = bitcast double %r4050 to i64
  %r4052 = icmp eq i64 %r4051, 9222246136947933200
  br i1 %r4052, label %pic.miss.786, label %pic.hit.live.776

pic.ways.794:                                     ; preds = %pic.miss.786
  %r4092 = getelementptr i64, ptr %r4022, i64 4
  %r4093 = load i64, ptr %r4092, align 8
  %r4094 = icmp eq i64 %r4093, %r4031
  %r4095 = getelementptr i64, ptr %r4022, i64 5
  %r4096 = load i64, ptr %r4095, align 8
  %r4097 = select i1 %r4094, i64 %r4096, i64 0
  %r4098 = getelementptr i64, ptr %r4022, i64 6
  %r4099 = load i64, ptr %r4098, align 8
  %r4100 = icmp eq i64 %r4099, %r4031
  %r4101 = getelementptr i64, ptr %r4022, i64 7
  %r4102 = load i64, ptr %r4101, align 8
  %r4103 = select i1 %r4100, i64 %r4102, i64 0
  %r4104 = getelementptr i64, ptr %r4022, i64 8
  %r4105 = load i64, ptr %r4104, align 8
  %r4106 = icmp eq i64 %r4105, %r4031
  %r4107 = getelementptr i64, ptr %r4022, i64 9
  %r4108 = load i64, ptr %r4107, align 8
  %r4109 = select i1 %r4106, i64 %r4108, i64 0
  %r4110 = getelementptr i64, ptr %r4022, i64 10
  %r4111 = load i64, ptr %r4110, align 8
  %r4112 = icmp eq i64 %r4111, %r4031
  %r4113 = getelementptr i64, ptr %r4022, i64 11
  %r4114 = load i64, ptr %r4113, align 8
  %r4115 = select i1 %r4112, i64 %r4114, i64 0
  %r4116 = or i1 %r4094, %r4100
  %r4117 = select i1 %r4094, i64 %r4097, i64 %r4103
  %r4118 = or i1 %r4106, %r4112
  %r4119 = select i1 %r4106, i64 %r4109, i64 %r4115
  %r4120 = or i1 %r4116, %r4118
  %r4121 = select i1 %r4116, i64 %r4117, i64 %r4119
  %r4122 = and i1 %r4032, %r4120
  br i1 %r4122, label %pic.way.load.795, label %pic.miss.call.788

pic.way.load.795:                                 ; preds = %pic.ways.794
  %r4123 = shl i64 %r4121, 3
  %r4124 = add nuw nsw i64 %r4001, 16
  %r4125 = add i64 %r4124, %r4123
  %r4126 = inttoptr i64 %r4125 to ptr
  %r4127 = load double, ptr %r4126, align 8
  %r4128 = bitcast double %r4127 to i64
  %r4129 = icmp eq i64 %r4128, 9222246136947933200
  br i1 %r4129, label %pic.miss.call.788, label %pic.way.live.796

pic.way.live.796:                                 ; preds = %pic.way.load.795
  br label %pic.merge.789

pget.throw_nullish.797:                           ; preds = %pget.recv_bad.768
  %r4138 = zext i1 %r4136 to i32
  %statepoint_token612 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r4138, ptr @test_json_tape_batch_records_ts_.str.19.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.798:                       ; preds = %pget.recv_bad.768
  %r4139 = load double, ptr @test_json_tape_batch_records_ts_.str.19.handle, align 8
  %r4140 = bitcast double %r4139 to i64
  %r4141 = and i64 %r4140, 281474976710655
  %statepoint_token613 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r4000, i64 %r4141, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61125, ptr addrspace(1) %.34, ptr addrspace(1) %.51148, ptr addrspace(1) %.11153, ptr addrspace(1) %.61137) ]
  %r4142614 = call double @llvm.experimental.gc.result.f64(token %statepoint_token613)
  %r131.1.base.relocated615 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token613, i32 0, i32 0) ; (%.61125, %.61125)
  %rs4gc.s15.relocated616 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token613, i32 1, i32 1) ; (%.34, %.34)
  %rs4gc.s30.relocated617 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token613, i32 2, i32 2) ; (%.51148, %.51148)
  %rs4gc.s31.relocated618 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token613, i32 3, i32 3) ; (%.11153, %.11153)
  %r131.1.relocated619 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token613, i32 0, i32 4) ; (%.61125, %.61137)
  br label %pget.recv_merge.770

guarded_add.numeric.799:                          ; preds = %pget.recv_merge.770
  %r4171 = fadd double %r4155, %r4151
  %r4172 = fadd double %r4153, %r4171
  br label %guarded_add.merge.801

guarded_add.dynamic.800:                          ; preds = %pget.recv_merge.770
  %statepoint_token620 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r4155, double %r4151, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.81127, ptr addrspace(1) %.36, ptr addrspace(1) %.81139, ptr addrspace(1) %.71150) ]
  %r4173621 = call double @llvm.experimental.gc.result.f64(token %statepoint_token620)
  %r131.1.base.relocated622 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token620, i32 0, i32 0) ; (%.81127, %.81127)
  %rs4gc.s15.relocated623 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token620, i32 1, i32 1) ; (%.36, %.36)
  %r131.1.relocated624 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token620, i32 0, i32 2) ; (%.81127, %.81139)
  %rs4gc.s30.relocated625 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token620, i32 3, i32 3) ; (%.71150, %.71150)
  %r5966.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s30.relocated625 to i64
  %r5966 = call i64 asm "", "=r,0"(i64 %r5966.rs4i) #7
  %r5967 = bitcast i64 %r5966 to double
  %statepoint_token626 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r5967, double %r4173621, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r131.1.base.relocated622, ptr addrspace(1) %rs4gc.s15.relocated623, ptr addrspace(1) %r131.1.relocated624) ]
  %r4174627 = call double @llvm.experimental.gc.result.f64(token %statepoint_token626)
  %r131.1.base.relocated628 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token626, i32 0, i32 0) ; (%r131.1.base.relocated622, %r131.1.base.relocated622)
  %rs4gc.s15.relocated629 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token626, i32 1, i32 1) ; (%rs4gc.s15.relocated623, %rs4gc.s15.relocated623)
  %r131.1.relocated630 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token626, i32 0, i32 2) ; (%r131.1.base.relocated622, %r131.1.relocated624)
  br label %guarded_add.merge.801

guarded_add.merge.801:                            ; preds = %guarded_add.dynamic.800, %guarded_add.numeric.799
  %.101141 = phi ptr addrspace(1) [ %.81139, %guarded_add.numeric.799 ], [ %r131.1.relocated630, %guarded_add.dynamic.800 ]
  %.101129 = phi ptr addrspace(1) [ %.81127, %guarded_add.numeric.799 ], [ %r131.1.base.relocated628, %guarded_add.dynamic.800 ]
  %.38 = phi ptr addrspace(1) [ %.36, %guarded_add.numeric.799 ], [ %rs4gc.s15.relocated629, %guarded_add.dynamic.800 ]
  %r4175 = phi double [ %r4172, %guarded_add.numeric.799 ], [ %r4174627, %guarded_add.dynamic.800 ]
  %rs4gc.b32 = bitcast double %r4175 to i64
  %rs4gc.s32 = inttoptr i64 %rs4gc.b32 to ptr addrspace(1)
  %r4176.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s32 to i64
  %r4176 = call i64 asm "", "=r,0"(i64 %r4176.rs4i) #7
  %r4177 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4178 = icmp ne i32 %r4177, 0
  br i1 %r4178, label %shadow.root.barrier.802, label %shadow.root.barrier.done.803

shadow.root.barrier.802:                          ; preds = %guarded_add.merge.801
  call void @js_write_barrier_root_nanbox(i64 %r4176) #7
  br label %shadow.root.barrier.done.803

shadow.root.barrier.done.803:                     ; preds = %shadow.root.barrier.802, %guarded_add.merge.801
  %r4179 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r4180 = icmp ne i32 %r4179, 0
  br i1 %r4180, label %gcpoll.804, label %gcpoll.done.805

gcpoll.804:                                       ; preds = %shadow.root.barrier.done.803
  %statepoint_token631 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s32, ptr addrspace(1) %.101129, ptr addrspace(1) %.101141, ptr addrspace(1) %.38) ]
  %rs4gc.s32.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token631, i32 0, i32 0) ; (%rs4gc.s32, %rs4gc.s32)
  %r131.1.base.relocated632 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token631, i32 1, i32 1) ; (%.101129, %.101129)
  %r131.1.relocated633 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token631, i32 1, i32 2) ; (%.101129, %.101141)
  %rs4gc.s15.relocated634 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token631, i32 3, i32 3) ; (%.38, %.38)
  br label %gcpoll.done.805

gcpoll.done.805:                                  ; preds = %gcpoll.804, %shadow.root.barrier.done.803
  %.01157 = phi ptr addrspace(1) [ %rs4gc.s32.relocated, %gcpoll.804 ], [ %rs4gc.s32, %shadow.root.barrier.done.803 ]
  %.111142 = phi ptr addrspace(1) [ %r131.1.relocated633, %gcpoll.804 ], [ %.101141, %shadow.root.barrier.done.803 ]
  %.111130 = phi ptr addrspace(1) [ %r131.1.base.relocated632, %gcpoll.804 ], [ %.101129, %shadow.root.barrier.done.803 ]
  %.39 = phi ptr addrspace(1) [ %rs4gc.s15.relocated634, %gcpoll.804 ], [ %.38, %shadow.root.barrier.done.803 ]
  br label %for.update.26

shadow.root.barrier.806:                          ; preds = %for.exit.27
  call void @js_write_barrier_root_nanbox(i64 %r4186) #7
  br label %shadow.root.barrier.done.807

shadow.root.barrier.done.807:                     ; preds = %shadow.root.barrier.806, %for.exit.27
  %r4189 = load double, ptr @test_json_tape_batch_records_ts_.str.23.handle, align 8
  %r4190.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r4190 = call i64 asm "", "=r,0"(i64 %r4190.rs4i) #7
  %statepoint_token635 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4190, double %r4189, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s15.relocated122, ptr addrspace(1) %r131.0.relocated123, ptr addrspace(1) %r131.0.base.relocated124, ptr addrspace(1) %r138.0.relocated125) ]
  %r4191636 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token635)
  %rs4gc.s15.relocated637 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token635, i32 0, i32 0) ; (%rs4gc.s15.relocated122, %rs4gc.s15.relocated122)
  %r131.0.relocated638 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token635, i32 2, i32 1) ; (%r131.0.base.relocated124, %r131.0.relocated123)
  %r131.0.base.relocated639 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token635, i32 2, i32 2) ; (%r131.0.base.relocated124, %r131.0.base.relocated124)
  %r138.0.relocated640 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token635, i32 3, i32 3) ; (%r138.0.relocated125, %r138.0.relocated125)
  %rs4gc.s33 = inttoptr i64 %r4191636 to ptr addrspace(1)
  %r4192.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s33 to i64
  %r4192 = call i64 asm "", "=r,0"(i64 %r4192.rs4i) #7
  %r4193 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4194 = icmp ne i32 %r4193, 0
  br i1 %r4194, label %shadow.root.barrier.808, label %shadow.root.barrier.done.809

shadow.root.barrier.808:                          ; preds = %shadow.root.barrier.done.807
  call void @js_write_barrier_root_nanbox(i64 %r4192) #7
  br label %shadow.root.barrier.done.809

shadow.root.barrier.done.809:                     ; preds = %shadow.root.barrier.808, %shadow.root.barrier.done.807
  %r4195.rs4i = ptrtoint ptr addrspace(1) %r138.0.relocated640 to i64
  %r4195.rs4o = call i64 asm "", "=r,0"(i64 %r4195.rs4i) #7
  %r4195 = bitcast i64 %r4195.rs4o to double
  %r4196.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s33 to i64
  %r4196 = call i64 asm "", "=r,0"(i64 %r4196.rs4i) #7
  %statepoint_token641 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4196, double %r4195, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s15.relocated637, ptr addrspace(1) %r131.0.relocated638, ptr addrspace(1) %r131.0.base.relocated639) ]
  %r4197642 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token641)
  %rs4gc.s15.relocated643 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token641, i32 0, i32 0) ; (%rs4gc.s15.relocated637, %rs4gc.s15.relocated637)
  %r131.0.relocated644 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token641, i32 2, i32 1) ; (%r131.0.base.relocated639, %r131.0.relocated638)
  %r131.0.base.relocated645 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token641, i32 2, i32 2) ; (%r131.0.base.relocated639, %r131.0.base.relocated639)
  %rs4gc.s34 = inttoptr i64 %r4197642 to ptr addrspace(1)
  %r4198.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s34 to i64
  %r4198 = call i64 asm "", "=r,0"(i64 %r4198.rs4i) #7
  %r4199 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4200 = icmp ne i32 %r4199, 0
  br i1 %r4200, label %shadow.root.barrier.810, label %shadow.root.barrier.done.811

shadow.root.barrier.810:                          ; preds = %shadow.root.barrier.done.809
  call void @js_write_barrier_root_nanbox(i64 %r4198) #7
  br label %shadow.root.barrier.done.811

shadow.root.barrier.done.811:                     ; preds = %shadow.root.barrier.810, %shadow.root.barrier.done.809
  %r4201.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s34 to i64
  %r4201 = call i64 asm "", "=r,0"(i64 %r4201.rs4i) #7
  %statepoint_token646 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r4201, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s15.relocated643, ptr addrspace(1) %r131.0.relocated644, ptr addrspace(1) %r131.0.base.relocated645) ]
  %rs4gc.s15.relocated647 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token646, i32 0, i32 0) ; (%rs4gc.s15.relocated643, %rs4gc.s15.relocated643)
  %r131.0.relocated648 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token646, i32 2, i32 1) ; (%r131.0.base.relocated645, %r131.0.relocated644)
  %r131.0.base.relocated649 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token646, i32 2, i32 2) ; (%r131.0.base.relocated645, %r131.0.base.relocated645)
  %r4202 = load volatile i8, ptr @PERRY_ARRAY_PROTO_ITERATOR_PATCHED, align 1
  %r4203 = zext i8 %r4202 to i32
  %r4204 = icmp ne i32 %r4203, 0
  %r4205 = select i1 %r4204, i64 9222246136947933188, i64 9222246136947933187
  %r4206 = bitcast i64 %r4205 to double
  br label %truthy.tag.813

truthy.tag.813:                                   ; preds = %shadow.root.barrier.done.811
  %r4210 = icmp eq i64 %r4205, 9222246136947933188
  %r4211 = icmp eq i64 %r4205, 9222246136947933187
  %r4214 = or i1 %r4211, false
  %r4215 = or i1 %r4214, false
  %r4216 = or i1 %r4210, %r4215
  br i1 %r4216, label %truthy.merge.815, label %truthy.obj.816

truthy.slow.814:                                  ; preds = %truthy.obj.816
  %r4222 = call i32 @js_is_truthy(double %r4206) #7
  %r4223 = icmp ne i32 %r4222, 0
  br label %truthy.merge.815

truthy.merge.815:                                 ; preds = %truthy.obj.816, %truthy.slow.814, %truthy.tag.813
  %r4224 = phi i1 [ %r4223, %truthy.slow.814 ], [ %r4210, %truthy.tag.813 ], [ true, %truthy.obj.816 ]
  br i1 %r4224, label %if.then.817, label %if.else.818

truthy.obj.816:                                   ; preds = %truthy.tag.813
  %r4217 = lshr i64 9222246136947933187, 48
  %r4218 = icmp eq i64 %r4217, 32765
  %r4219 = and i64 9222246136947933187, 281474976710655
  %r4220 = icmp ne i64 %r4219, 0
  %r4221 = and i1 %r4218, %r4220
  br i1 %r4221, label %truthy.merge.815, label %truthy.slow.814

if.then.817:                                      ; preds = %truthy.merge.815
  %r4226.rs4i = ptrtoint ptr addrspace(1) %r131.0.relocated648 to i64
  %r4226.rs4o = call i64 asm "", "=r,0"(i64 %r4226.rs4i) #7
  %r4226 = bitcast i64 %r4226.rs4o to double
  %statepoint_token650 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_get_iterator, i32 1, i32 0, double %r4226, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s15.relocated647) ]
  %r4227651 = call double @llvm.experimental.gc.result.f64(token %statepoint_token650)
  %rs4gc.s15.relocated652 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token650, i32 0, i32 0) ; (%rs4gc.s15.relocated647, %rs4gc.s15.relocated647)
  %rs4gc.b35 = bitcast double %r4227651 to i64
  %rs4gc.s35 = inttoptr i64 %rs4gc.b35 to ptr addrspace(1)
  %r4228.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35 to i64
  %r4228 = call i64 asm "", "=r,0"(i64 %r4228.rs4i) #7
  %r4229 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4230 = icmp ne i32 %r4229, 0
  br i1 %r4230, label %shadow.root.barrier.820, label %shadow.root.barrier.done.821

if.else.818:                                      ; preds = %truthy.merge.815
  %r4784.rs4i = ptrtoint ptr addrspace(1) %r131.0.relocated648 to i64
  %r4784.rs4o = call i64 asm "", "=r,0"(i64 %r4784.rs4i) #7
  %r4784 = bitcast i64 %r4784.rs4o to double
  %r4785 = bitcast double %r4784 to i64
  %r4786 = and i64 %r4785, -281474976710656
  %r4787 = icmp ne i64 %r4786, 9223090561878065152
  br i1 %r4787, label %str_addref.done.958, label %str_addref.call.957

if.merge.819:                                     ; preds = %for.exit.964, %for.exit.827
  %.40 = phi ptr addrspace(1) [ %.44, %for.exit.827 ], [ %.55, %for.exit.964 ]
  %r5010.rs4i = ptrtoint ptr addrspace(1) %.40 to i64
  %r5010.rs4o = call i64 asm "", "=r,0"(i64 %r5010.rs4i) #7
  %r5010 = bitcast i64 %r5010.rs4o to double
  %statepoint_token653 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r5010, i32 0, i32 0)
  %r5011654 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token653)
  %statepoint_token655 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r5011654, i32 0, i32 0)
  %r5012656 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token655)
  %r5013 = bitcast i64 %r5012656 to double
  %rs4gc.b36 = bitcast double %r5013 to i64
  %rs4gc.s36 = inttoptr i64 %rs4gc.b36 to ptr addrspace(1)
  %r5014.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s36 to i64
  %r5014 = call i64 asm "", "=r,0"(i64 %r5014.rs4i) #7
  %r5015 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5016 = icmp ne i32 %r5015, 0
  br i1 %r5016, label %shadow.root.barrier.1005, label %shadow.root.barrier.done.1006

shadow.root.barrier.820:                          ; preds = %if.then.817
  call void @js_write_barrier_root_nanbox(i64 %r4228) #7
  br label %shadow.root.barrier.done.821

shadow.root.barrier.done.821:                     ; preds = %shadow.root.barrier.820, %if.then.817
  %r4232.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35 to i64
  %r4232.rs4o = call i64 asm "", "=r,0"(i64 %r4232.rs4i) #7
  %r4232 = bitcast i64 %r4232.rs4o to double
  %statepoint_token657 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_for_of_next, i32 1, i32 0, double %r4232, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35, ptr addrspace(1) %rs4gc.s15.relocated652) ]
  %r4233658 = call double @llvm.experimental.gc.result.f64(token %statepoint_token657)
  %rs4gc.s35.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token657, i32 0, i32 0) ; (%rs4gc.s35, %rs4gc.s35)
  %rs4gc.s15.relocated659 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token657, i32 1, i32 1) ; (%rs4gc.s15.relocated652, %rs4gc.s15.relocated652)
  %rs4gc.b37 = bitcast double %r4233658 to i64
  %rs4gc.s37 = inttoptr i64 %rs4gc.b37 to ptr addrspace(1)
  %r4234.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s37 to i64
  %r4234 = call i64 asm "", "=r,0"(i64 %r4234.rs4i) #7
  %r4235 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4236 = icmp ne i32 %r4235, 0
  br i1 %r4236, label %shadow.root.barrier.822, label %shadow.root.barrier.done.823

shadow.root.barrier.822:                          ; preds = %shadow.root.barrier.done.821
  call void @js_write_barrier_root_nanbox(i64 %r4234) #7
  br label %shadow.root.barrier.done.823

shadow.root.barrier.done.823:                     ; preds = %shadow.root.barrier.822, %shadow.root.barrier.done.821
  br label %for.cond.824

for.cond.824:                                     ; preds = %gcpoll.done.956, %shadow.root.barrier.done.823
  %.01158 = phi ptr addrspace(1) [ %rs4gc.s35.relocated, %shadow.root.barrier.done.823 ], [ %.131171, %gcpoll.done.956 ]
  %.41 = phi ptr addrspace(1) [ %rs4gc.s15.relocated659, %shadow.root.barrier.done.823 ], [ %.51, %gcpoll.done.956 ]
  %r4231.0 = phi ptr addrspace(1) [ %rs4gc.s37, %shadow.root.barrier.done.823 ], [ %.01194, %gcpoll.done.956 ]
  %r4237.rs4i = ptrtoint ptr addrspace(1) %r4231.0 to i64
  %r4237.rs4o = call i64 asm "", "=r,0"(i64 %r4237.rs4i) #7
  %r4237 = bitcast i64 %r4237.rs4o to double
  %r4238 = bitcast double %r4237 to i64
  %r4239 = and i64 %r4238, 281474976710655
  %r4240 = lshr i64 %r4238, 48
  %r4241 = and i64 %r4240, 65533
  %r4242 = icmp eq i64 %r4241, 32765
  br i1 %r4242, label %pget.recv_ok.829, label %pget.recv_other.833

for.body.825:                                     ; preds = %gcpoll.done.865
  %r4411.rs4i = ptrtoint ptr addrspace(1) %.21179 to i64
  %r4411.rs4o = call i64 asm "", "=r,0"(i64 %r4411.rs4i) #7
  %r4411 = bitcast i64 %r4411.rs4o to double
  %r4412 = bitcast double %r4411 to i64
  %r4413 = and i64 %r4412, 281474976710655
  %r4414 = lshr i64 %r4412, 48
  %r4415 = and i64 %r4414, 65533
  %r4416 = icmp eq i64 %r4415, 32765
  br i1 %r4416, label %pget.recv_ok.867, label %pget.recv_other.871

for.update.826:                                   ; preds = %gcpoll.done.952
  %r4776.rs4i = ptrtoint ptr addrspace(1) %.81166 to i64
  %r4776.rs4o = call i64 asm "", "=r,0"(i64 %r4776.rs4i) #7
  %r4776 = bitcast i64 %r4776.rs4o to double
  %statepoint_token660 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_for_of_next, i32 1, i32 0, double %r4776, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.81166, ptr addrspace(1) %.48) ]
  %r4777661 = call double @llvm.experimental.gc.result.f64(token %statepoint_token660)
  %rs4gc.s35.relocated662 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token660, i32 0, i32 0) ; (%.81166, %.81166)
  %rs4gc.s15.relocated663 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token660, i32 1, i32 1) ; (%.48, %.48)
  %rs4gc.b38 = bitcast double %r4777661 to i64
  %rs4gc.s38 = inttoptr i64 %rs4gc.b38 to ptr addrspace(1)
  %r4778.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s38 to i64
  %r4778 = call i64 asm "", "=r,0"(i64 %r4778.rs4i) #7
  %r4779 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4780 = icmp ne i32 %r4779, 0
  br i1 %r4780, label %shadow.root.barrier.953, label %shadow.root.barrier.done.954

for.exit.827:                                     ; preds = %gcpoll.done.865
  br label %if.merge.819

pget.recv_sso.828:                                ; preds = %pget.recv_other.833
  %r4380 = load double, ptr @test_json_tape_batch_records_ts_.str.24.handle, align 8
  %r4381 = bitcast double %r4380 to i64
  %r4382 = and i64 %r4381, 281474976710655
  %statepoint_token664 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r4238, i64 %r4382, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01158, ptr addrspace(1) %r4231.0, ptr addrspace(1) %.41) ]
  %r4383665 = call double @llvm.experimental.gc.result.f64(token %statepoint_token664)
  %rs4gc.s35.relocated666 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token664, i32 0, i32 0) ; (%.01158, %.01158)
  %r4231.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token664, i32 1, i32 1) ; (%r4231.0, %r4231.0)
  %rs4gc.s15.relocated667 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token664, i32 2, i32 2) ; (%.41, %.41)
  br label %pget.recv_merge.832

pget.recv_ok.829:                                 ; preds = %for.cond.824
  %r4249 = icmp ugt i64 %r4239, 1048575
  br i1 %r4249, label %pic.recv_hdr.850, label %pic.miss.cold.847

pget.recv_bad.830:                                ; preds = %pget.check_class_ref.834
  %r4372 = icmp eq i64 %r4238, 9222246136947933185
  %r4373 = icmp eq i64 %r4238, 9222246136947933186
  %r4374 = or i1 %r4372, %r4373
  br i1 %r4374, label %pget.throw_nullish.857, label %pget.recv_undef_return.858

pget.recv_class_ref.831:                          ; preds = %pget.check_class_ref.834
  %r4245 = load double, ptr @test_json_tape_batch_records_ts_.str.24.handle, align 8
  %r4246 = bitcast double %r4245 to i64
  %r4247 = and i64 %r4246, 281474976710655
  %statepoint_token668 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 367713371643969567, i64 %r4238, i64 %r4247, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01158, ptr addrspace(1) %r4231.0, ptr addrspace(1) %.41) ]
  %r4248669 = call double @llvm.experimental.gc.result.f64(token %statepoint_token668)
  %rs4gc.s35.relocated670 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token668, i32 0, i32 0) ; (%.01158, %.01158)
  %r4231.0.relocated671 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token668, i32 1, i32 1) ; (%r4231.0, %r4231.0)
  %rs4gc.s15.relocated672 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token668, i32 2, i32 2) ; (%.41, %.41)
  br label %pget.recv_merge.832

pget.recv_merge.832:                              ; preds = %pget.recv_undef_return.858, %pic.merge.849, %pget.recv_class_ref.831, %pget.recv_sso.828
  %.01177 = phi ptr addrspace(1) [ %.11178, %pic.merge.849 ], [ %r4231.0.relocated, %pget.recv_sso.828 ], [ %r4231.0.relocated671, %pget.recv_class_ref.831 ], [ %r4231.0.relocated687, %pget.recv_undef_return.858 ]
  %.11159 = phi ptr addrspace(1) [ %.21160, %pic.merge.849 ], [ %rs4gc.s35.relocated666, %pget.recv_sso.828 ], [ %rs4gc.s35.relocated670, %pget.recv_class_ref.831 ], [ %rs4gc.s35.relocated686, %pget.recv_undef_return.858 ]
  %.42 = phi ptr addrspace(1) [ %.43, %pic.merge.849 ], [ %rs4gc.s15.relocated667, %pget.recv_sso.828 ], [ %rs4gc.s15.relocated672, %pget.recv_class_ref.831 ], [ %rs4gc.s15.relocated688, %pget.recv_undef_return.858 ]
  %r4384 = phi double [ %r4371, %pic.merge.849 ], [ %r4379685, %pget.recv_undef_return.858 ], [ %r4383665, %pget.recv_sso.828 ], [ %r4248669, %pget.recv_class_ref.831 ]
  %r4385 = bitcast double %r4384 to i64
  %r4386 = and i64 %r4385, 9221120237041090560
  %r4387 = icmp ne i64 %r4386, 9221120237041090560
  br i1 %r4387, label %truthy.num.859, label %truthy.tag.860

pget.recv_other.833:                              ; preds = %for.cond.824
  %r4243 = icmp eq i64 %r4240, 32761
  br i1 %r4243, label %pget.recv_sso.828, label %pget.check_class_ref.834

pget.check_class_ref.834:                         ; preds = %pget.recv_other.833
  %r4244 = icmp eq i64 %r4240, 32766
  br i1 %r4244, label %pget.recv_class_ref.831, label %pget.recv_bad.830

pic.hit.835:                                      ; preds = %pic.token.851
  %r4274 = getelementptr i64, ptr %r4259, i64 1
  %r4275 = load i64, ptr %r4274, align 8
  %r4276 = and i64 %r4275, 1073741824
  %r4277 = icmp ne i64 %r4276, 0
  br i1 %r4277, label %pic.hit.overflow.852, label %pic.hit.inline.853

pic.hit.live.836:                                 ; preds = %pic.hit.inline.853
  br label %pic.merge.849

pic.prefix.guard.837:                             ; preds = %pic.token.851
  %r4290 = getelementptr i64, ptr %r4259, i64 2
  %r4291 = load i64, ptr %r4290, align 8
  %r4292 = icmp ne i64 %r4291, 0
  br i1 %r4292, label %pic.prefix.meta.838, label %pic.miss.846

pic.prefix.meta.838:                              ; preds = %pic.prefix.guard.837
  %r4293 = add nuw nsw i64 %r4239, 8
  %r4294 = inttoptr i64 %r4293 to ptr
  %r4295 = load i64, ptr %r4294, align 8
  %r4296 = icmp ne i64 %r4295, 0
  br i1 %r4296, label %pic.prefix.token.839, label %pic.miss.846

pic.prefix.token.839:                             ; preds = %pic.prefix.meta.838
  %r4297 = inttoptr i64 %r4295 to ptr
  %r4298 = getelementptr i64, ptr %r4297, i64 6
  %r4299 = load i64, ptr %r4298, align 8
  %r4300 = icmp eq i64 %r4299, %r4291
  br i1 %r4300, label %pic.prefix.hit.840, label %pic.miss.846

pic.prefix.hit.840:                               ; preds = %pic.prefix.token.839
  %r4301 = getelementptr i64, ptr %r4259, i64 1
  %r4302 = load i64, ptr %r4301, align 8
  %r4303 = shl i64 %r4302, 3
  %r4304 = add nuw nsw i64 %r4239, 16
  %r4305 = add i64 %r4304, %r4303
  %r4306 = inttoptr i64 %r4305 to ptr
  %r4307 = load double, ptr %r4306, align 8
  br label %pic.merge.849

pic.desc.classify.841:                            ; preds = %pic.recv_hdr.850
  %r4263 = and i1 %r4253, %r4260
  br i1 %r4263, label %pic.desc.prefix.guard.842, label %pic.miss.cold.847

pic.desc.prefix.guard.842:                        ; preds = %pic.desc.classify.841
  %r4308 = getelementptr i64, ptr %r4259, i64 2
  %r4309 = load i64, ptr %r4308, align 8
  %r4310 = icmp ne i64 %r4309, 0
  br i1 %r4310, label %pic.desc.prefix.meta.843, label %pic.miss.cold.847

pic.desc.prefix.meta.843:                         ; preds = %pic.desc.prefix.guard.842
  %r4311 = add nuw nsw i64 %r4239, 8
  %r4312 = inttoptr i64 %r4311 to ptr
  %r4313 = load i64, ptr %r4312, align 8
  %r4314 = icmp ne i64 %r4313, 0
  br i1 %r4314, label %pic.desc.prefix.token.844, label %pic.miss.cold.847

pic.desc.prefix.token.844:                        ; preds = %pic.desc.prefix.meta.843
  %r4315 = inttoptr i64 %r4313 to ptr
  %r4316 = getelementptr i64, ptr %r4315, i64 6
  %r4317 = load i64, ptr %r4316, align 8
  %r4318 = icmp eq i64 %r4317, %r4309
  br i1 %r4318, label %pic.desc.prefix.hit.845, label %pic.miss.cold.847

pic.desc.prefix.hit.845:                          ; preds = %pic.desc.prefix.token.844
  %r4319 = getelementptr i64, ptr %r4259, i64 1
  %r4320 = load i64, ptr %r4319, align 8
  %r4321 = shl i64 %r4320, 3
  %r4322 = add nuw nsw i64 %r4239, 16
  %r4323 = add i64 %r4322, %r4321
  %r4324 = inttoptr i64 %r4323 to ptr
  %r4325 = load double, ptr %r4324, align 8
  br label %pic.merge.849

pic.miss.846:                                     ; preds = %pic.hit.inline.853, %pic.prefix.token.839, %pic.prefix.meta.838, %pic.prefix.guard.837
  %r4326 = getelementptr i64, ptr %r4259, i64 3
  %r4327 = load i64, ptr %r4326, align 8
  %r4328 = icmp sgt i64 %r4327, 0
  br i1 %r4328, label %pic.ways.854, label %pic.miss.call.848

pic.miss.cold.847:                                ; preds = %pic.desc.prefix.token.844, %pic.desc.prefix.meta.843, %pic.desc.prefix.guard.842, %pic.desc.classify.841, %pget.recv_ok.829
  br label %pic.miss.call.848

pic.miss.call.848:                                ; preds = %pic.way.load.855, %pic.ways.854, %pic.miss.cold.847, %pic.miss.846
  %r4367 = load double, ptr @test_json_tape_batch_records_ts_.str.24.handle, align 8
  %r4368 = bitcast double %r4367 to i64
  %r4369 = and i64 %r4368, 281474976710655
  %statepoint_token673 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r4239, i64 %r4369, ptr @perry_ic_test_json_tape_batch_records_ts__32, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01158, ptr addrspace(1) %r4231.0, ptr addrspace(1) %.41) ]
  %r4370674 = call double @llvm.experimental.gc.result.f64(token %statepoint_token673)
  %rs4gc.s35.relocated675 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token673, i32 0, i32 0) ; (%.01158, %.01158)
  %r4231.0.relocated676 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token673, i32 1, i32 1) ; (%r4231.0, %r4231.0)
  %rs4gc.s15.relocated677 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token673, i32 2, i32 2) ; (%.41, %.41)
  br label %pic.merge.849

pic.merge.849:                                    ; preds = %pic.way.live.856, %pic.hit.overflow.852, %pic.miss.call.848, %pic.desc.prefix.hit.845, %pic.prefix.hit.840, %pic.hit.live.836
  %.11178 = phi ptr addrspace(1) [ %r4231.0.relocated681, %pic.hit.overflow.852 ], [ %r4231.0.relocated676, %pic.miss.call.848 ], [ %r4231.0, %pic.way.live.856 ], [ %r4231.0, %pic.hit.live.836 ], [ %r4231.0, %pic.prefix.hit.840 ], [ %r4231.0, %pic.desc.prefix.hit.845 ]
  %.21160 = phi ptr addrspace(1) [ %rs4gc.s35.relocated680, %pic.hit.overflow.852 ], [ %rs4gc.s35.relocated675, %pic.miss.call.848 ], [ %.01158, %pic.way.live.856 ], [ %.01158, %pic.hit.live.836 ], [ %.01158, %pic.prefix.hit.840 ], [ %.01158, %pic.desc.prefix.hit.845 ]
  %.43 = phi ptr addrspace(1) [ %rs4gc.s15.relocated682, %pic.hit.overflow.852 ], [ %rs4gc.s15.relocated677, %pic.miss.call.848 ], [ %.41, %pic.way.live.856 ], [ %.41, %pic.hit.live.836 ], [ %.41, %pic.prefix.hit.840 ], [ %.41, %pic.desc.prefix.hit.845 ]
  %r4371 = phi double [ %r4287, %pic.hit.live.836 ], [ %r4282679, %pic.hit.overflow.852 ], [ %r4307, %pic.prefix.hit.840 ], [ %r4325, %pic.desc.prefix.hit.845 ], [ %r4364, %pic.way.live.856 ], [ %r4370674, %pic.miss.call.848 ]
  br label %pget.recv_merge.832

pic.recv_hdr.850:                                 ; preds = %pget.recv_ok.829
  %r4250 = sub nuw nsw i64 %r4239, 8
  %r4251 = inttoptr i64 %r4250 to ptr
  %r4252 = load i8, ptr %r4251, align 1
  %r4253 = icmp eq i8 %r4252, 2
  %r4254 = sub nuw nsw i64 %r4239, 6
  %r4255 = inttoptr i64 %r4254 to ptr
  %r4256 = load i16, ptr %r4255, align 2
  %r4257 = and i16 %r4256, 2048
  %r4258 = icmp eq i16 %r4257, 0
  %r4259 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__32, align 8
  %r4260 = icmp ne ptr %r4259, null
  %r4261 = and i1 %r4253, %r4258
  %r4262 = and i1 %r4261, %r4260
  br i1 %r4262, label %pic.token.851, label %pic.desc.classify.841

pic.token.851:                                    ; preds = %pic.recv_hdr.850
  %r4264 = add nuw nsw i64 %r4239, 4
  %r4265 = inttoptr i64 %r4264 to ptr
  %r4266 = load i32, ptr %r4265, align 4
  %r4267 = zext i32 %r4266 to i64
  %r4268 = or i64 %r4267, 4611686018427387904
  %r4269 = icmp ne i32 %r4266, 0
  %r4270 = getelementptr i64, ptr %r4259, i64 0
  %r4271 = load i64, ptr %r4270, align 8
  %r4272 = icmp eq i64 %r4268, %r4271
  %r4273 = and i1 %r4272, %r4269
  br i1 %r4273, label %pic.hit.835, label %pic.prefix.guard.837

pic.hit.overflow.852:                             ; preds = %pic.hit.835
  %r4278 = load double, ptr @test_json_tape_batch_records_ts_.str.24.handle, align 8
  %r4279 = bitcast double %r4278 to i64
  %r4280 = and i64 %r4279, 281474976710655
  %r4281 = trunc i64 %r4275 to i32
  %statepoint_token678 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r4239, i64 %r4280, i32 %r4281, ptr @perry_ic_test_json_tape_batch_records_ts__32, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01158, ptr addrspace(1) %r4231.0, ptr addrspace(1) %.41) ]
  %r4282679 = call double @llvm.experimental.gc.result.f64(token %statepoint_token678)
  %rs4gc.s35.relocated680 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token678, i32 0, i32 0) ; (%.01158, %.01158)
  %r4231.0.relocated681 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token678, i32 1, i32 1) ; (%r4231.0, %r4231.0)
  %rs4gc.s15.relocated682 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token678, i32 2, i32 2) ; (%.41, %.41)
  br label %pic.merge.849

pic.hit.inline.853:                               ; preds = %pic.hit.835
  %r4283 = shl i64 %r4275, 3
  %r4284 = add nuw nsw i64 %r4239, 16
  %r4285 = add i64 %r4284, %r4283
  %r4286 = inttoptr i64 %r4285 to ptr
  %r4287 = load double, ptr %r4286, align 8
  %r4288 = bitcast double %r4287 to i64
  %r4289 = icmp eq i64 %r4288, 9222246136947933200
  br i1 %r4289, label %pic.miss.846, label %pic.hit.live.836

pic.ways.854:                                     ; preds = %pic.miss.846
  %r4329 = getelementptr i64, ptr %r4259, i64 4
  %r4330 = load i64, ptr %r4329, align 8
  %r4331 = icmp eq i64 %r4330, %r4268
  %r4332 = getelementptr i64, ptr %r4259, i64 5
  %r4333 = load i64, ptr %r4332, align 8
  %r4334 = select i1 %r4331, i64 %r4333, i64 0
  %r4335 = getelementptr i64, ptr %r4259, i64 6
  %r4336 = load i64, ptr %r4335, align 8
  %r4337 = icmp eq i64 %r4336, %r4268
  %r4338 = getelementptr i64, ptr %r4259, i64 7
  %r4339 = load i64, ptr %r4338, align 8
  %r4340 = select i1 %r4337, i64 %r4339, i64 0
  %r4341 = getelementptr i64, ptr %r4259, i64 8
  %r4342 = load i64, ptr %r4341, align 8
  %r4343 = icmp eq i64 %r4342, %r4268
  %r4344 = getelementptr i64, ptr %r4259, i64 9
  %r4345 = load i64, ptr %r4344, align 8
  %r4346 = select i1 %r4343, i64 %r4345, i64 0
  %r4347 = getelementptr i64, ptr %r4259, i64 10
  %r4348 = load i64, ptr %r4347, align 8
  %r4349 = icmp eq i64 %r4348, %r4268
  %r4350 = getelementptr i64, ptr %r4259, i64 11
  %r4351 = load i64, ptr %r4350, align 8
  %r4352 = select i1 %r4349, i64 %r4351, i64 0
  %r4353 = or i1 %r4331, %r4337
  %r4354 = select i1 %r4331, i64 %r4334, i64 %r4340
  %r4355 = or i1 %r4343, %r4349
  %r4356 = select i1 %r4343, i64 %r4346, i64 %r4352
  %r4357 = or i1 %r4353, %r4355
  %r4358 = select i1 %r4353, i64 %r4354, i64 %r4356
  %r4359 = and i1 %r4269, %r4357
  br i1 %r4359, label %pic.way.load.855, label %pic.miss.call.848

pic.way.load.855:                                 ; preds = %pic.ways.854
  %r4360 = shl i64 %r4358, 3
  %r4361 = add nuw nsw i64 %r4239, 16
  %r4362 = add i64 %r4361, %r4360
  %r4363 = inttoptr i64 %r4362 to ptr
  %r4364 = load double, ptr %r4363, align 8
  %r4365 = bitcast double %r4364 to i64
  %r4366 = icmp eq i64 %r4365, 9222246136947933200
  br i1 %r4366, label %pic.miss.call.848, label %pic.way.live.856

pic.way.live.856:                                 ; preds = %pic.way.load.855
  br label %pic.merge.849

pget.throw_nullish.857:                           ; preds = %pget.recv_bad.830
  %r4375 = zext i1 %r4373 to i32
  %statepoint_token683 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r4375, ptr @test_json_tape_batch_records_ts_.str.24.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.858:                       ; preds = %pget.recv_bad.830
  %r4376 = load double, ptr @test_json_tape_batch_records_ts_.str.24.handle, align 8
  %r4377 = bitcast double %r4376 to i64
  %r4378 = and i64 %r4377, 281474976710655
  %statepoint_token684 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r4238, i64 %r4378, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01158, ptr addrspace(1) %r4231.0, ptr addrspace(1) %.41) ]
  %r4379685 = call double @llvm.experimental.gc.result.f64(token %statepoint_token684)
  %rs4gc.s35.relocated686 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token684, i32 0, i32 0) ; (%.01158, %.01158)
  %r4231.0.relocated687 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token684, i32 1, i32 1) ; (%r4231.0, %r4231.0)
  %rs4gc.s15.relocated688 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token684, i32 2, i32 2) ; (%.41, %.41)
  br label %pget.recv_merge.832

truthy.num.859:                                   ; preds = %pget.recv_merge.832
  %r4388 = fcmp one double %r4384, 0.000000e+00
  br label %truthy.merge.862

truthy.tag.860:                                   ; preds = %pget.recv_merge.832
  %r4389 = icmp eq i64 %r4385, 9222246136947933188
  %r4390 = icmp eq i64 %r4385, 9222246136947933187
  %r4391 = icmp eq i64 %r4385, 9222246136947933185
  %r4392 = icmp eq i64 %r4385, 9222246136947933186
  %r4393 = or i1 %r4390, %r4391
  %r4394 = or i1 %r4393, %r4392
  %r4395 = or i1 %r4389, %r4394
  br i1 %r4395, label %truthy.merge.862, label %truthy.obj.863

truthy.slow.861:                                  ; preds = %truthy.obj.863
  %r4401 = call i32 @js_is_truthy(double %r4384) #7
  %r4402 = icmp ne i32 %r4401, 0
  br label %truthy.merge.862

truthy.merge.862:                                 ; preds = %truthy.obj.863, %truthy.slow.861, %truthy.tag.860, %truthy.num.859
  %r4403 = phi i1 [ %r4388, %truthy.num.859 ], [ %r4389, %truthy.tag.860 ], [ true, %truthy.obj.863 ], [ %r4402, %truthy.slow.861 ]
  %r4404 = xor i1 %r4403, true
  %r4405 = select i1 %r4404, i64 9222246136947933188, i64 9222246136947933187
  %r4406 = bitcast i64 %r4405 to double
  %r4408 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r4409 = icmp ne i32 %r4408, 0
  br i1 %r4409, label %gcpoll.864, label %gcpoll.done.865

truthy.obj.863:                                   ; preds = %truthy.tag.860
  %r4396 = lshr i64 %r4385, 48
  %r4397 = icmp eq i64 %r4396, 32765
  %r4398 = and i64 %r4385, 281474976710655
  %r4399 = icmp ne i64 %r4398, 0
  %r4400 = and i1 %r4397, %r4399
  br i1 %r4400, label %truthy.merge.862, label %truthy.slow.861

gcpoll.864:                                       ; preds = %truthy.merge.862
  %statepoint_token689 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11159, ptr addrspace(1) %.42, ptr addrspace(1) %.01177) ]
  %rs4gc.s35.relocated690 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token689, i32 0, i32 0) ; (%.11159, %.11159)
  %rs4gc.s15.relocated691 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token689, i32 1, i32 1) ; (%.42, %.42)
  %r4231.0.relocated692 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token689, i32 2, i32 2) ; (%.01177, %.01177)
  br label %gcpoll.done.865

gcpoll.done.865:                                  ; preds = %gcpoll.864, %truthy.merge.862
  %.21179 = phi ptr addrspace(1) [ %r4231.0.relocated692, %gcpoll.864 ], [ %.01177, %truthy.merge.862 ]
  %.31161 = phi ptr addrspace(1) [ %rs4gc.s35.relocated690, %gcpoll.864 ], [ %.11159, %truthy.merge.862 ]
  %.44 = phi ptr addrspace(1) [ %rs4gc.s15.relocated691, %gcpoll.864 ], [ %.42, %truthy.merge.862 ]
  %r4407 = icmp eq i64 %r4405, 9222246136947933188
  br i1 %r4407, label %for.body.825, label %for.exit.827

pget.recv_sso.866:                                ; preds = %pget.recv_other.871
  %r4554 = load double, ptr @test_json_tape_batch_records_ts_.str.25.handle, align 8
  %r4555 = bitcast double %r4554 to i64
  %r4556 = and i64 %r4555, 281474976710655
  %statepoint_token693 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r4412, i64 %r4556, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31161, ptr addrspace(1) %.44) ]
  %r4557694 = call double @llvm.experimental.gc.result.f64(token %statepoint_token693)
  %rs4gc.s35.relocated695 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token693, i32 0, i32 0) ; (%.31161, %.31161)
  %rs4gc.s15.relocated696 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token693, i32 1, i32 1) ; (%.44, %.44)
  br label %pget.recv_merge.870

pget.recv_ok.867:                                 ; preds = %for.body.825
  %r4423 = icmp ugt i64 %r4413, 1048575
  br i1 %r4423, label %pic.recv_hdr.888, label %pic.miss.cold.885

pget.recv_bad.868:                                ; preds = %pget.check_class_ref.872
  %r4546 = icmp eq i64 %r4412, 9222246136947933185
  %r4547 = icmp eq i64 %r4412, 9222246136947933186
  %r4548 = or i1 %r4546, %r4547
  br i1 %r4548, label %pget.throw_nullish.895, label %pget.recv_undef_return.896

pget.recv_class_ref.869:                          ; preds = %pget.check_class_ref.872
  %r4419 = load double, ptr @test_json_tape_batch_records_ts_.str.25.handle, align 8
  %r4420 = bitcast double %r4419 to i64
  %r4421 = and i64 %r4420, 281474976710655
  %statepoint_token697 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 367713371643969569, i64 %r4412, i64 %r4421, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31161, ptr addrspace(1) %.44) ]
  %r4422698 = call double @llvm.experimental.gc.result.f64(token %statepoint_token697)
  %rs4gc.s35.relocated699 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token697, i32 0, i32 0) ; (%.31161, %.31161)
  %rs4gc.s15.relocated700 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token697, i32 1, i32 1) ; (%.44, %.44)
  br label %pget.recv_merge.870

pget.recv_merge.870:                              ; preds = %pget.recv_undef_return.896, %pic.merge.887, %pget.recv_class_ref.869, %pget.recv_sso.866
  %.41162 = phi ptr addrspace(1) [ %.51163, %pic.merge.887 ], [ %rs4gc.s35.relocated695, %pget.recv_sso.866 ], [ %rs4gc.s35.relocated699, %pget.recv_class_ref.869 ], [ %rs4gc.s35.relocated712, %pget.recv_undef_return.896 ]
  %.45 = phi ptr addrspace(1) [ %.46, %pic.merge.887 ], [ %rs4gc.s15.relocated696, %pget.recv_sso.866 ], [ %rs4gc.s15.relocated700, %pget.recv_class_ref.869 ], [ %rs4gc.s15.relocated713, %pget.recv_undef_return.896 ]
  %r4558 = phi double [ %r4545, %pic.merge.887 ], [ %r4553711, %pget.recv_undef_return.896 ], [ %r4557694, %pget.recv_sso.866 ], [ %r4422698, %pget.recv_class_ref.869 ]
  %rs4gc.b39 = bitcast double %r4558 to i64
  %rs4gc.s39 = inttoptr i64 %rs4gc.b39 to ptr addrspace(1)
  %r4559.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s39 to i64
  %r4559 = call i64 asm "", "=r,0"(i64 %r4559.rs4i) #7
  %r4560 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4561 = icmp ne i32 %r4560, 0
  br i1 %r4561, label %shadow.root.barrier.897, label %shadow.root.barrier.done.898

pget.recv_other.871:                              ; preds = %for.body.825
  %r4417 = icmp eq i64 %r4414, 32761
  br i1 %r4417, label %pget.recv_sso.866, label %pget.check_class_ref.872

pget.check_class_ref.872:                         ; preds = %pget.recv_other.871
  %r4418 = icmp eq i64 %r4414, 32766
  br i1 %r4418, label %pget.recv_class_ref.869, label %pget.recv_bad.868

pic.hit.873:                                      ; preds = %pic.token.889
  %r4448 = getelementptr i64, ptr %r4433, i64 1
  %r4449 = load i64, ptr %r4448, align 8
  %r4450 = and i64 %r4449, 1073741824
  %r4451 = icmp ne i64 %r4450, 0
  br i1 %r4451, label %pic.hit.overflow.890, label %pic.hit.inline.891

pic.hit.live.874:                                 ; preds = %pic.hit.inline.891
  br label %pic.merge.887

pic.prefix.guard.875:                             ; preds = %pic.token.889
  %r4464 = getelementptr i64, ptr %r4433, i64 2
  %r4465 = load i64, ptr %r4464, align 8
  %r4466 = icmp ne i64 %r4465, 0
  br i1 %r4466, label %pic.prefix.meta.876, label %pic.miss.884

pic.prefix.meta.876:                              ; preds = %pic.prefix.guard.875
  %r4467 = add nuw nsw i64 %r4413, 8
  %r4468 = inttoptr i64 %r4467 to ptr
  %r4469 = load i64, ptr %r4468, align 8
  %r4470 = icmp ne i64 %r4469, 0
  br i1 %r4470, label %pic.prefix.token.877, label %pic.miss.884

pic.prefix.token.877:                             ; preds = %pic.prefix.meta.876
  %r4471 = inttoptr i64 %r4469 to ptr
  %r4472 = getelementptr i64, ptr %r4471, i64 6
  %r4473 = load i64, ptr %r4472, align 8
  %r4474 = icmp eq i64 %r4473, %r4465
  br i1 %r4474, label %pic.prefix.hit.878, label %pic.miss.884

pic.prefix.hit.878:                               ; preds = %pic.prefix.token.877
  %r4475 = getelementptr i64, ptr %r4433, i64 1
  %r4476 = load i64, ptr %r4475, align 8
  %r4477 = shl i64 %r4476, 3
  %r4478 = add nuw nsw i64 %r4413, 16
  %r4479 = add i64 %r4478, %r4477
  %r4480 = inttoptr i64 %r4479 to ptr
  %r4481 = load double, ptr %r4480, align 8
  br label %pic.merge.887

pic.desc.classify.879:                            ; preds = %pic.recv_hdr.888
  %r4437 = and i1 %r4427, %r4434
  br i1 %r4437, label %pic.desc.prefix.guard.880, label %pic.miss.cold.885

pic.desc.prefix.guard.880:                        ; preds = %pic.desc.classify.879
  %r4482 = getelementptr i64, ptr %r4433, i64 2
  %r4483 = load i64, ptr %r4482, align 8
  %r4484 = icmp ne i64 %r4483, 0
  br i1 %r4484, label %pic.desc.prefix.meta.881, label %pic.miss.cold.885

pic.desc.prefix.meta.881:                         ; preds = %pic.desc.prefix.guard.880
  %r4485 = add nuw nsw i64 %r4413, 8
  %r4486 = inttoptr i64 %r4485 to ptr
  %r4487 = load i64, ptr %r4486, align 8
  %r4488 = icmp ne i64 %r4487, 0
  br i1 %r4488, label %pic.desc.prefix.token.882, label %pic.miss.cold.885

pic.desc.prefix.token.882:                        ; preds = %pic.desc.prefix.meta.881
  %r4489 = inttoptr i64 %r4487 to ptr
  %r4490 = getelementptr i64, ptr %r4489, i64 6
  %r4491 = load i64, ptr %r4490, align 8
  %r4492 = icmp eq i64 %r4491, %r4483
  br i1 %r4492, label %pic.desc.prefix.hit.883, label %pic.miss.cold.885

pic.desc.prefix.hit.883:                          ; preds = %pic.desc.prefix.token.882
  %r4493 = getelementptr i64, ptr %r4433, i64 1
  %r4494 = load i64, ptr %r4493, align 8
  %r4495 = shl i64 %r4494, 3
  %r4496 = add nuw nsw i64 %r4413, 16
  %r4497 = add i64 %r4496, %r4495
  %r4498 = inttoptr i64 %r4497 to ptr
  %r4499 = load double, ptr %r4498, align 8
  br label %pic.merge.887

pic.miss.884:                                     ; preds = %pic.hit.inline.891, %pic.prefix.token.877, %pic.prefix.meta.876, %pic.prefix.guard.875
  %r4500 = getelementptr i64, ptr %r4433, i64 3
  %r4501 = load i64, ptr %r4500, align 8
  %r4502 = icmp sgt i64 %r4501, 0
  br i1 %r4502, label %pic.ways.892, label %pic.miss.call.886

pic.miss.cold.885:                                ; preds = %pic.desc.prefix.token.882, %pic.desc.prefix.meta.881, %pic.desc.prefix.guard.880, %pic.desc.classify.879, %pget.recv_ok.867
  br label %pic.miss.call.886

pic.miss.call.886:                                ; preds = %pic.way.load.893, %pic.ways.892, %pic.miss.cold.885, %pic.miss.884
  %r4541 = load double, ptr @test_json_tape_batch_records_ts_.str.25.handle, align 8
  %r4542 = bitcast double %r4541 to i64
  %r4543 = and i64 %r4542, 281474976710655
  %statepoint_token701 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r4413, i64 %r4543, ptr @perry_ic_test_json_tape_batch_records_ts__34, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31161, ptr addrspace(1) %.44) ]
  %r4544702 = call double @llvm.experimental.gc.result.f64(token %statepoint_token701)
  %rs4gc.s35.relocated703 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token701, i32 0, i32 0) ; (%.31161, %.31161)
  %rs4gc.s15.relocated704 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token701, i32 1, i32 1) ; (%.44, %.44)
  br label %pic.merge.887

pic.merge.887:                                    ; preds = %pic.way.live.894, %pic.hit.overflow.890, %pic.miss.call.886, %pic.desc.prefix.hit.883, %pic.prefix.hit.878, %pic.hit.live.874
  %.51163 = phi ptr addrspace(1) [ %rs4gc.s35.relocated707, %pic.hit.overflow.890 ], [ %rs4gc.s35.relocated703, %pic.miss.call.886 ], [ %.31161, %pic.way.live.894 ], [ %.31161, %pic.hit.live.874 ], [ %.31161, %pic.prefix.hit.878 ], [ %.31161, %pic.desc.prefix.hit.883 ]
  %.46 = phi ptr addrspace(1) [ %rs4gc.s15.relocated708, %pic.hit.overflow.890 ], [ %rs4gc.s15.relocated704, %pic.miss.call.886 ], [ %.44, %pic.way.live.894 ], [ %.44, %pic.hit.live.874 ], [ %.44, %pic.prefix.hit.878 ], [ %.44, %pic.desc.prefix.hit.883 ]
  %r4545 = phi double [ %r4461, %pic.hit.live.874 ], [ %r4456706, %pic.hit.overflow.890 ], [ %r4481, %pic.prefix.hit.878 ], [ %r4499, %pic.desc.prefix.hit.883 ], [ %r4538, %pic.way.live.894 ], [ %r4544702, %pic.miss.call.886 ]
  br label %pget.recv_merge.870

pic.recv_hdr.888:                                 ; preds = %pget.recv_ok.867
  %r4424 = sub nuw nsw i64 %r4413, 8
  %r4425 = inttoptr i64 %r4424 to ptr
  %r4426 = load i8, ptr %r4425, align 1
  %r4427 = icmp eq i8 %r4426, 2
  %r4428 = sub nuw nsw i64 %r4413, 6
  %r4429 = inttoptr i64 %r4428 to ptr
  %r4430 = load i16, ptr %r4429, align 2
  %r4431 = and i16 %r4430, 2048
  %r4432 = icmp eq i16 %r4431, 0
  %r4433 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__34, align 8
  %r4434 = icmp ne ptr %r4433, null
  %r4435 = and i1 %r4427, %r4432
  %r4436 = and i1 %r4435, %r4434
  br i1 %r4436, label %pic.token.889, label %pic.desc.classify.879

pic.token.889:                                    ; preds = %pic.recv_hdr.888
  %r4438 = add nuw nsw i64 %r4413, 4
  %r4439 = inttoptr i64 %r4438 to ptr
  %r4440 = load i32, ptr %r4439, align 4
  %r4441 = zext i32 %r4440 to i64
  %r4442 = or i64 %r4441, 4611686018427387904
  %r4443 = icmp ne i32 %r4440, 0
  %r4444 = getelementptr i64, ptr %r4433, i64 0
  %r4445 = load i64, ptr %r4444, align 8
  %r4446 = icmp eq i64 %r4442, %r4445
  %r4447 = and i1 %r4446, %r4443
  br i1 %r4447, label %pic.hit.873, label %pic.prefix.guard.875

pic.hit.overflow.890:                             ; preds = %pic.hit.873
  %r4452 = load double, ptr @test_json_tape_batch_records_ts_.str.25.handle, align 8
  %r4453 = bitcast double %r4452 to i64
  %r4454 = and i64 %r4453, 281474976710655
  %r4455 = trunc i64 %r4449 to i32
  %statepoint_token705 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r4413, i64 %r4454, i32 %r4455, ptr @perry_ic_test_json_tape_batch_records_ts__34, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31161, ptr addrspace(1) %.44) ]
  %r4456706 = call double @llvm.experimental.gc.result.f64(token %statepoint_token705)
  %rs4gc.s35.relocated707 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token705, i32 0, i32 0) ; (%.31161, %.31161)
  %rs4gc.s15.relocated708 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token705, i32 1, i32 1) ; (%.44, %.44)
  br label %pic.merge.887

pic.hit.inline.891:                               ; preds = %pic.hit.873
  %r4457 = shl i64 %r4449, 3
  %r4458 = add nuw nsw i64 %r4413, 16
  %r4459 = add i64 %r4458, %r4457
  %r4460 = inttoptr i64 %r4459 to ptr
  %r4461 = load double, ptr %r4460, align 8
  %r4462 = bitcast double %r4461 to i64
  %r4463 = icmp eq i64 %r4462, 9222246136947933200
  br i1 %r4463, label %pic.miss.884, label %pic.hit.live.874

pic.ways.892:                                     ; preds = %pic.miss.884
  %r4503 = getelementptr i64, ptr %r4433, i64 4
  %r4504 = load i64, ptr %r4503, align 8
  %r4505 = icmp eq i64 %r4504, %r4442
  %r4506 = getelementptr i64, ptr %r4433, i64 5
  %r4507 = load i64, ptr %r4506, align 8
  %r4508 = select i1 %r4505, i64 %r4507, i64 0
  %r4509 = getelementptr i64, ptr %r4433, i64 6
  %r4510 = load i64, ptr %r4509, align 8
  %r4511 = icmp eq i64 %r4510, %r4442
  %r4512 = getelementptr i64, ptr %r4433, i64 7
  %r4513 = load i64, ptr %r4512, align 8
  %r4514 = select i1 %r4511, i64 %r4513, i64 0
  %r4515 = getelementptr i64, ptr %r4433, i64 8
  %r4516 = load i64, ptr %r4515, align 8
  %r4517 = icmp eq i64 %r4516, %r4442
  %r4518 = getelementptr i64, ptr %r4433, i64 9
  %r4519 = load i64, ptr %r4518, align 8
  %r4520 = select i1 %r4517, i64 %r4519, i64 0
  %r4521 = getelementptr i64, ptr %r4433, i64 10
  %r4522 = load i64, ptr %r4521, align 8
  %r4523 = icmp eq i64 %r4522, %r4442
  %r4524 = getelementptr i64, ptr %r4433, i64 11
  %r4525 = load i64, ptr %r4524, align 8
  %r4526 = select i1 %r4523, i64 %r4525, i64 0
  %r4527 = or i1 %r4505, %r4511
  %r4528 = select i1 %r4505, i64 %r4508, i64 %r4514
  %r4529 = or i1 %r4517, %r4523
  %r4530 = select i1 %r4517, i64 %r4520, i64 %r4526
  %r4531 = or i1 %r4527, %r4529
  %r4532 = select i1 %r4527, i64 %r4528, i64 %r4530
  %r4533 = and i1 %r4443, %r4531
  br i1 %r4533, label %pic.way.load.893, label %pic.miss.call.886

pic.way.load.893:                                 ; preds = %pic.ways.892
  %r4534 = shl i64 %r4532, 3
  %r4535 = add nuw nsw i64 %r4413, 16
  %r4536 = add i64 %r4535, %r4534
  %r4537 = inttoptr i64 %r4536 to ptr
  %r4538 = load double, ptr %r4537, align 8
  %r4539 = bitcast double %r4538 to i64
  %r4540 = icmp eq i64 %r4539, 9222246136947933200
  br i1 %r4540, label %pic.miss.call.886, label %pic.way.live.894

pic.way.live.894:                                 ; preds = %pic.way.load.893
  br label %pic.merge.887

pget.throw_nullish.895:                           ; preds = %pget.recv_bad.868
  %r4549 = zext i1 %r4547 to i32
  %statepoint_token709 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r4549, ptr @test_json_tape_batch_records_ts_.str.25.bytes, i64 5, i32 0, i32 0)
  unreachable

pget.recv_undef_return.896:                       ; preds = %pget.recv_bad.868
  %r4550 = load double, ptr @test_json_tape_batch_records_ts_.str.25.handle, align 8
  %r4551 = bitcast double %r4550 to i64
  %r4552 = and i64 %r4551, 281474976710655
  %statepoint_token710 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r4412, i64 %r4552, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31161, ptr addrspace(1) %.44) ]
  %r4553711 = call double @llvm.experimental.gc.result.f64(token %statepoint_token710)
  %rs4gc.s35.relocated712 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token710, i32 0, i32 0) ; (%.31161, %.31161)
  %rs4gc.s15.relocated713 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token710, i32 1, i32 1) ; (%.44, %.44)
  br label %pget.recv_merge.870

shadow.root.barrier.897:                          ; preds = %pget.recv_merge.870
  call void @js_write_barrier_root_nanbox(i64 %r4559) #7
  br label %shadow.root.barrier.done.898

shadow.root.barrier.done.898:                     ; preds = %shadow.root.barrier.897, %pget.recv_merge.870
  %statepoint_token714 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_eh_try_push, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.41162, ptr addrspace(1) %.45, ptr addrspace(1) %rs4gc.s39) ]
  %rs4gc.s35.relocated715 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token714, i32 0, i32 0) ; (%.41162, %.41162)
  %rs4gc.s15.relocated716 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token714, i32 1, i32 1) ; (%.45, %.45)
  %rs4gc.s39.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token714, i32 2, i32 2) ; (%rs4gc.s39, %rs4gc.s39)
  br label %try.body.899

try.body.899:                                     ; preds = %shadow.root.barrier.done.898
  %r4563.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s39.relocated to i64
  %r4563.rs4o = call i64 asm "", "=r,0"(i64 %r4563.rs4i) #7
  %r4563 = bitcast i64 %r4563.rs4o to double
  %statepoint_token720 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r4563, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35.relocated715, ptr addrspace(1) %rs4gc.s15.relocated716) ]
          to label %eh.cont4565 unwind label %eh.lpad.9021

eh.cont4565:                                      ; preds = %try.body.899
  %r4564721 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token720)
  %rs4gc.s35.relocated722 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token720, i32 0, i32 0) ; (%rs4gc.s35.relocated715, %rs4gc.s35.relocated715)
  %rs4gc.s15.relocated723 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token720, i32 1, i32 1) ; (%rs4gc.s15.relocated716, %rs4gc.s15.relocated716)
  %r4566 = bitcast i64 %r4564721 to double
  %rs4gc.s40 = inttoptr i64 %r4564721 to ptr addrspace(1)
  %r4567.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s40 to i64
  %r4567 = call i64 asm "", "=r,0"(i64 %r4567.rs4i) #7
  %r4568 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4569 = icmp ne i32 %r4568, 0
  br i1 %r4569, label %shadow.root.barrier.903, label %shadow.root.barrier.done.904

try.catch.900:                                    ; preds = %eh.lpad.902
  %statepoint_token724 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_try_end, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61164) ]
  %rs4gc.s35.relocated725 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token724, i32 0, i32 0) ; (%.61164, %.61164)
  %statepoint_token726 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_get_exception, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35.relocated725) ]
  %r4588727 = call double @llvm.experimental.gc.result.f64(token %statepoint_token726)
  %rs4gc.s35.relocated728 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token726, i32 0, i32 0) ; (%rs4gc.s35.relocated725, %rs4gc.s35.relocated725)
  %statepoint_token729 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_clear_exception, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35.relocated728) ]
  %rs4gc.s35.relocated730 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token729, i32 0, i32 0) ; (%rs4gc.s35.relocated728, %rs4gc.s35.relocated728)
  %rs4gc.b41 = bitcast double %r4588727 to i64
  %rs4gc.s41 = inttoptr i64 %rs4gc.b41 to ptr addrspace(1)
  %r4590.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s41 to i64
  %r4590 = call i64 asm "", "=r,0"(i64 %r4590.rs4i) #7
  %r4591 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4592 = icmp ne i32 %r4591, 0
  br i1 %r4592, label %shadow.root.barrier.909, label %shadow.root.barrier.done.910

try.finally.901:                                  ; preds = %eh.cont4587
  %r4774 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r4775 = icmp ne i32 %r4774, 0
  br i1 %r4775, label %gcpoll.951, label %gcpoll.done.952

eh.lpad.9021:                                     ; preds = %try.body.899
  %lpad = landingpad token
          cleanup
  %rs4gc.s35.relocated718 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad, i32 0, i32 0) ; (%rs4gc.s35.relocated715, %rs4gc.s35.relocated715)
  %rs4gc.s15.relocated719 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad, i32 1, i32 1) ; (%rs4gc.s15.relocated716, %rs4gc.s15.relocated716)
  br label %eh.lpad.902

eh.lpad.902.split-lp2:                            ; preds = %shadow.root.barrier.903
  %lpad3 = landingpad token
          cleanup
  %rs4gc.s35.relocated732 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad3, i32 0, i32 0) ; (%rs4gc.s35.relocated722, %rs4gc.s35.relocated722)
  %rs4gc.s40.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad3, i32 1, i32 1) ; (%rs4gc.s40, %rs4gc.s40)
  %rs4gc.s15.relocated733 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad3, i32 2, i32 2) ; (%rs4gc.s15.relocated723, %rs4gc.s15.relocated723)
  br label %eh.lpad.902.split-lp

eh.lpad.902.split-lp.split-lp5:                   ; preds = %shadow.root.barrier.done.904
  %lpad6 = landingpad token
          cleanup
  %rs4gc.s35.relocated739 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad6, i32 0, i32 0) ; (%.71165, %.71165)
  %rs4gc.s40.relocated740 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad6, i32 1, i32 1) ; (%.01180, %.01180)
  %rs4gc.s15.relocated741 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad6, i32 2, i32 2) ; (%.47, %.47)
  br label %eh.lpad.902.split-lp.split-lp

eh.lpad.902.split-lp.split-lp.split-lp7:          ; preds = %shadow.root.barrier.905
  %lpad8 = landingpad token
          cleanup
  %rs4gc.s35.relocated748 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad8, i32 0, i32 0) ; (%rs4gc.s35.relocated744, %rs4gc.s35.relocated744)
  %rs4gc.s42.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad8, i32 1, i32 1) ; (%rs4gc.s42, %rs4gc.s42)
  %rs4gc.s40.relocated749 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad8, i32 2, i32 2) ; (%rs4gc.s40.relocated745, %rs4gc.s40.relocated745)
  %rs4gc.s15.relocated750 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad8, i32 3, i32 3) ; (%rs4gc.s15.relocated746, %rs4gc.s15.relocated746)
  br label %eh.lpad.902.split-lp.split-lp.split-lp

eh.lpad.902.split-lp.split-lp.split-lp.split-lp10: ; preds = %shadow.root.barrier.done.906
  %lpad11 = landingpad token
          cleanup
  %rs4gc.s35.relocated757 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad11, i32 0, i32 0) ; (%.91167, %.91167)
  %rs4gc.s15.relocated758 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad11, i32 1, i32 1) ; (%.49, %.49)
  br label %eh.lpad.902.split-lp.split-lp.split-lp.split-lp

eh.lpad.902.split-lp.split-lp.split-lp.split-lp.split-lp12: ; preds = %shadow.root.barrier.907
  %lpad13 = landingpad token
          cleanup
  %rs4gc.s35.relocated764 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad13, i32 0, i32 0) ; (%rs4gc.s35.relocated761, %rs4gc.s35.relocated761)
  %rs4gc.s43.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad13, i32 1, i32 1) ; (%rs4gc.s43, %rs4gc.s43)
  %rs4gc.s15.relocated765 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad13, i32 2, i32 2) ; (%rs4gc.s15.relocated762, %rs4gc.s15.relocated762)
  br label %eh.lpad.902.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.902.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %shadow.root.barrier.done.908
  %lpad.split-lp14 = landingpad token
          cleanup
  %rs4gc.s35.relocated771 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad.split-lp14, i32 0, i32 0) ; (%.101168, %.101168)
  %rs4gc.s15.relocated772 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad.split-lp14, i32 1, i32 1) ; (%.50, %.50)
  br label %eh.lpad.902.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.902.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.902.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.902.split-lp.split-lp.split-lp.split-lp.split-lp12
  %.181176 = phi ptr addrspace(1) [ %rs4gc.s35.relocated771, %eh.lpad.902.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s35.relocated764, %eh.lpad.902.split-lp.split-lp.split-lp.split-lp.split-lp12 ]
  br label %eh.lpad.902.split-lp.split-lp.split-lp.split-lp

eh.lpad.902.split-lp.split-lp.split-lp.split-lp:  ; preds = %eh.lpad.902.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.902.split-lp.split-lp.split-lp.split-lp10
  %.171175 = phi ptr addrspace(1) [ %.181176, %eh.lpad.902.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s35.relocated757, %eh.lpad.902.split-lp.split-lp.split-lp.split-lp10 ]
  br label %eh.lpad.902.split-lp.split-lp.split-lp

eh.lpad.902.split-lp.split-lp.split-lp:           ; preds = %eh.lpad.902.split-lp.split-lp.split-lp.split-lp, %eh.lpad.902.split-lp.split-lp.split-lp7
  %.161174 = phi ptr addrspace(1) [ %.171175, %eh.lpad.902.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s35.relocated748, %eh.lpad.902.split-lp.split-lp.split-lp7 ]
  br label %eh.lpad.902.split-lp.split-lp

eh.lpad.902.split-lp.split-lp:                    ; preds = %eh.lpad.902.split-lp.split-lp.split-lp, %eh.lpad.902.split-lp.split-lp5
  %.151173 = phi ptr addrspace(1) [ %.161174, %eh.lpad.902.split-lp.split-lp.split-lp ], [ %rs4gc.s35.relocated739, %eh.lpad.902.split-lp.split-lp5 ]
  br label %eh.lpad.902.split-lp

eh.lpad.902.split-lp:                             ; preds = %eh.lpad.902.split-lp.split-lp, %eh.lpad.902.split-lp2
  %.141172 = phi ptr addrspace(1) [ %.151173, %eh.lpad.902.split-lp.split-lp ], [ %rs4gc.s35.relocated732, %eh.lpad.902.split-lp2 ]
  br label %eh.lpad.902

eh.lpad.902:                                      ; preds = %eh.lpad.902.split-lp, %eh.lpad.9021
  %.61164 = phi ptr addrspace(1) [ %.141172, %eh.lpad.902.split-lp ], [ %rs4gc.s35.relocated718, %eh.lpad.9021 ]
  br label %try.catch.900

shadow.root.barrier.903:                          ; preds = %eh.cont4565
  %statepoint_token734 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_write_barrier_root_nanbox, i32 1, i32 0, i64 %r4567, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35.relocated722, ptr addrspace(1) %rs4gc.s40, ptr addrspace(1) %rs4gc.s15.relocated723) ]
          to label %eh.cont4570 unwind label %eh.lpad.902.split-lp2

eh.cont4570:                                      ; preds = %shadow.root.barrier.903
  %rs4gc.s35.relocated735 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token734, i32 0, i32 0) ; (%rs4gc.s35.relocated722, %rs4gc.s35.relocated722)
  %rs4gc.s40.relocated736 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token734, i32 1, i32 1) ; (%rs4gc.s40, %rs4gc.s40)
  %rs4gc.s15.relocated737 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token734, i32 2, i32 2) ; (%rs4gc.s15.relocated723, %rs4gc.s15.relocated723)
  br label %shadow.root.barrier.done.904

shadow.root.barrier.done.904:                     ; preds = %eh.cont4570, %eh.cont4565
  %.01180 = phi ptr addrspace(1) [ %rs4gc.s40.relocated736, %eh.cont4570 ], [ %rs4gc.s40, %eh.cont4565 ]
  %.71165 = phi ptr addrspace(1) [ %rs4gc.s35.relocated735, %eh.cont4570 ], [ %rs4gc.s35.relocated722, %eh.cont4565 ]
  %.47 = phi ptr addrspace(1) [ %rs4gc.s15.relocated737, %eh.cont4570 ], [ %rs4gc.s15.relocated723, %eh.cont4565 ]
  %statepoint_token742 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.71165, ptr addrspace(1) %.01180, ptr addrspace(1) %.47) ]
          to label %eh.cont4572 unwind label %eh.lpad.902.split-lp.split-lp5

eh.cont4572:                                      ; preds = %shadow.root.barrier.done.904
  %r4571743 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token742)
  %rs4gc.s35.relocated744 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token742, i32 0, i32 0) ; (%.71165, %.71165)
  %rs4gc.s40.relocated745 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token742, i32 1, i32 1) ; (%.01180, %.01180)
  %rs4gc.s15.relocated746 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token742, i32 2, i32 2) ; (%.47, %.47)
  %rs4gc.s42 = inttoptr i64 %r4571743 to ptr addrspace(1)
  %r4573.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s42 to i64
  %r4573 = call i64 asm "", "=r,0"(i64 %r4573.rs4i) #7
  %r4574 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4575 = icmp ne i32 %r4574, 0
  br i1 %r4575, label %shadow.root.barrier.905, label %shadow.root.barrier.done.906

shadow.root.barrier.905:                          ; preds = %eh.cont4572
  %statepoint_token751 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_write_barrier_root_nanbox, i32 1, i32 0, i64 %r4573, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35.relocated744, ptr addrspace(1) %rs4gc.s42, ptr addrspace(1) %rs4gc.s40.relocated745, ptr addrspace(1) %rs4gc.s15.relocated746) ]
          to label %eh.cont4576 unwind label %eh.lpad.902.split-lp.split-lp.split-lp7

eh.cont4576:                                      ; preds = %shadow.root.barrier.905
  %rs4gc.s35.relocated752 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token751, i32 0, i32 0) ; (%rs4gc.s35.relocated744, %rs4gc.s35.relocated744)
  %rs4gc.s42.relocated753 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token751, i32 1, i32 1) ; (%rs4gc.s42, %rs4gc.s42)
  %rs4gc.s40.relocated754 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token751, i32 2, i32 2) ; (%rs4gc.s40.relocated745, %rs4gc.s40.relocated745)
  %rs4gc.s15.relocated755 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token751, i32 3, i32 3) ; (%rs4gc.s15.relocated746, %rs4gc.s15.relocated746)
  br label %shadow.root.barrier.done.906

shadow.root.barrier.done.906:                     ; preds = %eh.cont4576, %eh.cont4572
  %.01182 = phi ptr addrspace(1) [ %rs4gc.s42.relocated753, %eh.cont4576 ], [ %rs4gc.s42, %eh.cont4572 ]
  %.11181 = phi ptr addrspace(1) [ %rs4gc.s40.relocated754, %eh.cont4576 ], [ %rs4gc.s40.relocated745, %eh.cont4572 ]
  %.91167 = phi ptr addrspace(1) [ %rs4gc.s35.relocated752, %eh.cont4576 ], [ %rs4gc.s35.relocated744, %eh.cont4572 ]
  %.49 = phi ptr addrspace(1) [ %rs4gc.s15.relocated755, %eh.cont4576 ], [ %rs4gc.s15.relocated746, %eh.cont4572 ]
  %r4577.rs4i = ptrtoint ptr addrspace(1) %.11181 to i64
  %r4577 = call i64 asm "", "=r,0"(i64 %r4577.rs4i) #7
  %r4578 = bitcast i64 %r4577 to double
  %r4579.rs4i = ptrtoint ptr addrspace(1) %.01182 to i64
  %r4579 = call i64 asm "", "=r,0"(i64 %r4579.rs4i) #7
  %statepoint_token759 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4579, double %r4578, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.91167, ptr addrspace(1) %.49) ]
          to label %eh.cont4581 unwind label %eh.lpad.902.split-lp.split-lp.split-lp.split-lp10

eh.cont4581:                                      ; preds = %shadow.root.barrier.done.906
  %r4580760 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token759)
  %rs4gc.s35.relocated761 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token759, i32 0, i32 0) ; (%.91167, %.91167)
  %rs4gc.s15.relocated762 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token759, i32 1, i32 1) ; (%.49, %.49)
  %rs4gc.s43 = inttoptr i64 %r4580760 to ptr addrspace(1)
  %r4582.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s43 to i64
  %r4582 = call i64 asm "", "=r,0"(i64 %r4582.rs4i) #7
  %r4583 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4584 = icmp ne i32 %r4583, 0
  br i1 %r4584, label %shadow.root.barrier.907, label %shadow.root.barrier.done.908

shadow.root.barrier.907:                          ; preds = %eh.cont4581
  %statepoint_token766 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_write_barrier_root_nanbox, i32 1, i32 0, i64 %r4582, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35.relocated761, ptr addrspace(1) %rs4gc.s43, ptr addrspace(1) %rs4gc.s15.relocated762) ]
          to label %eh.cont4585 unwind label %eh.lpad.902.split-lp.split-lp.split-lp.split-lp.split-lp12

eh.cont4585:                                      ; preds = %shadow.root.barrier.907
  %rs4gc.s35.relocated767 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token766, i32 0, i32 0) ; (%rs4gc.s35.relocated761, %rs4gc.s35.relocated761)
  %rs4gc.s43.relocated768 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token766, i32 1, i32 1) ; (%rs4gc.s43, %rs4gc.s43)
  %rs4gc.s15.relocated769 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token766, i32 2, i32 2) ; (%rs4gc.s15.relocated762, %rs4gc.s15.relocated762)
  br label %shadow.root.barrier.done.908

shadow.root.barrier.done.908:                     ; preds = %eh.cont4585, %eh.cont4581
  %.01183 = phi ptr addrspace(1) [ %rs4gc.s43.relocated768, %eh.cont4585 ], [ %rs4gc.s43, %eh.cont4581 ]
  %.101168 = phi ptr addrspace(1) [ %rs4gc.s35.relocated767, %eh.cont4585 ], [ %rs4gc.s35.relocated761, %eh.cont4581 ]
  %.50 = phi ptr addrspace(1) [ %rs4gc.s15.relocated769, %eh.cont4585 ], [ %rs4gc.s15.relocated762, %eh.cont4581 ]
  %r4586.rs4i = ptrtoint ptr addrspace(1) %.01183 to i64
  %r4586 = call i64 asm "", "=r,0"(i64 %r4586.rs4i) #7
  %statepoint_token773 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r4586, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.101168, ptr addrspace(1) %.50) ]
          to label %eh.cont4587 unwind label %eh.lpad.902.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.cont4587:                                      ; preds = %shadow.root.barrier.done.908
  %rs4gc.s35.relocated774 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token773, i32 0, i32 0) ; (%.101168, %.101168)
  %rs4gc.s15.relocated775 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token773, i32 1, i32 1) ; (%.50, %.50)
  %statepoint_token776 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_try_end, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35.relocated774, ptr addrspace(1) %rs4gc.s15.relocated775) ]
  %rs4gc.s35.relocated777 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token776, i32 0, i32 0) ; (%rs4gc.s35.relocated774, %rs4gc.s35.relocated774)
  %rs4gc.s15.relocated778 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token776, i32 1, i32 1) ; (%rs4gc.s15.relocated775, %rs4gc.s15.relocated775)
  br label %try.finally.901

shadow.root.barrier.909:                          ; preds = %try.catch.900
  call void @js_write_barrier_root_nanbox(i64 %r4590) #7
  br label %shadow.root.barrier.done.910

shadow.root.barrier.done.910:                     ; preds = %shadow.root.barrier.909, %try.catch.900
  %statepoint_token779 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_eh_try_push, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35.relocated730, ptr addrspace(1) %rs4gc.s41) ]
  %rs4gc.s35.relocated780 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token779, i32 0, i32 0) ; (%rs4gc.s35.relocated730, %rs4gc.s35.relocated730)
  %rs4gc.s41.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token779, i32 1, i32 1) ; (%rs4gc.s41, %rs4gc.s41)
  br label %try.body.911

try.body.911:                                     ; preds = %shadow.root.barrier.done.910
  %r4594.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated780 to i64
  %r4594.rs4o = call i64 asm "", "=r,0"(i64 %r4594.rs4i) #7
  %r4594 = bitcast i64 %r4594.rs4o to double
  %r4595 = bitcast double %r4594 to i64
  %r4596 = and i64 %r4595, 281474976710655
  %r4597 = lshr i64 %r4595, 48
  %r4598 = and i64 %r4597, 65533
  %r4599 = icmp eq i64 %r4598, 32765
  br i1 %r4599, label %pget.recv_ok.916, label %pget.recv_other.920

try.catch.912:                                    ; preds = %eh.lpad.914
  %statepoint_token781 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_try_end, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11185) ]
  %rs4gc.s41.relocated782 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token781, i32 0, i32 0) ; (%.11185, %.11185)
  %statepoint_token783 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_get_exception, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s41.relocated782) ]
  %r4768784 = call double @llvm.experimental.gc.result.f64(token %statepoint_token783)
  %rs4gc.s41.relocated785 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token783, i32 0, i32 0) ; (%rs4gc.s41.relocated782, %rs4gc.s41.relocated782)
  %statepoint_token786 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_clear_exception, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s41.relocated785) ]
  %rs4gc.s41.relocated787 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token786, i32 0, i32 0) ; (%rs4gc.s41.relocated785, %rs4gc.s41.relocated785)
  %rs4gc.b44 = bitcast double %r4768784 to i64
  %rs4gc.s44 = inttoptr i64 %rs4gc.b44 to ptr addrspace(1)
  %r4770.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s44 to i64
  %r4770 = call i64 asm "", "=r,0"(i64 %r4770.rs4i) #7
  %r4771 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4772 = icmp ne i32 %r4771, 0
  br i1 %r4772, label %shadow.root.barrier.949, label %shadow.root.barrier.done.950

try.finally.913:                                  ; preds = %shadow.root.barrier.done.950, %if.merge.948
  %.01184 = phi ptr addrspace(1) [ %rs4gc.s41.relocated833, %if.merge.948 ], [ %rs4gc.s41.relocated787, %shadow.root.barrier.done.950 ]
  %r4773.rs4i = ptrtoint ptr addrspace(1) %.01184 to i64
  %r4773.rs4o = call i64 asm "", "=r,0"(i64 %r4773.rs4i) #7
  %r4773 = bitcast i64 %r4773.rs4o to double
  %statepoint_token788 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r4773, i32 0, i32 0)
  unreachable

eh.lpad.91415:                                    ; preds = %pget.recv_sso.915
  %lpad16 = landingpad token
          cleanup
  %rs4gc.s35.relocated790 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad16, i32 0, i32 0) ; (%rs4gc.s35.relocated780, %rs4gc.s35.relocated780)
  %rs4gc.s41.relocated791 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad16, i32 1, i32 1) ; (%rs4gc.s41.relocated, %rs4gc.s41.relocated)
  br label %eh.lpad.914

eh.lpad.914.split-lp17:                           ; preds = %pget.recv_class_ref.918
  %lpad18 = landingpad token
          cleanup
  %rs4gc.s35.relocated797 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad18, i32 0, i32 0) ; (%rs4gc.s35.relocated780, %rs4gc.s35.relocated780)
  %rs4gc.s41.relocated798 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad18, i32 1, i32 1) ; (%rs4gc.s41.relocated, %rs4gc.s41.relocated)
  br label %eh.lpad.914.split-lp

eh.lpad.914.split-lp.split-lp20:                  ; preds = %pic.miss.call.935
  %lpad21 = landingpad token
          cleanup
  %rs4gc.s35.relocated804 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad21, i32 0, i32 0) ; (%rs4gc.s35.relocated780, %rs4gc.s35.relocated780)
  %rs4gc.s41.relocated805 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad21, i32 1, i32 1) ; (%rs4gc.s41.relocated, %rs4gc.s41.relocated)
  br label %eh.lpad.914.split-lp.split-lp

eh.lpad.914.split-lp.split-lp.split-lp22:         ; preds = %pic.hit.overflow.939
  %lpad23 = landingpad token
          cleanup
  %rs4gc.s35.relocated811 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad23, i32 0, i32 0) ; (%rs4gc.s35.relocated780, %rs4gc.s35.relocated780)
  %rs4gc.s41.relocated812 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad23, i32 1, i32 1) ; (%rs4gc.s41.relocated, %rs4gc.s41.relocated)
  br label %eh.lpad.914.split-lp.split-lp.split-lp

eh.lpad.914.split-lp.split-lp.split-lp.split-lp25: ; preds = %pget.throw_nullish.944
  %lpad26 = landingpad token
          cleanup
  %rs4gc.s41.relocated818 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad26, i32 0, i32 0) ; (%rs4gc.s41.relocated, %rs4gc.s41.relocated)
  br label %eh.lpad.914.split-lp.split-lp.split-lp.split-lp

eh.lpad.914.split-lp.split-lp.split-lp.split-lp.split-lp27: ; preds = %pget.recv_undef_return.945
  %lpad28 = landingpad token
          cleanup
  %rs4gc.s35.relocated822 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad28, i32 0, i32 0) ; (%rs4gc.s35.relocated780, %rs4gc.s35.relocated780)
  %rs4gc.s41.relocated823 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad28, i32 1, i32 1) ; (%rs4gc.s41.relocated, %rs4gc.s41.relocated)
  br label %eh.lpad.914.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.914.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %if.then.946
  %lpad.split-lp29 = landingpad token
          cleanup
  %rs4gc.s41.relocated829 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad.split-lp29, i32 0, i32 0) ; (%.21186, %.21186)
  br label %eh.lpad.914.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.914.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.914.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.914.split-lp.split-lp.split-lp.split-lp.split-lp27
  %.91193 = phi ptr addrspace(1) [ %rs4gc.s41.relocated829, %eh.lpad.914.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s41.relocated823, %eh.lpad.914.split-lp.split-lp.split-lp.split-lp.split-lp27 ]
  br label %eh.lpad.914.split-lp.split-lp.split-lp.split-lp

eh.lpad.914.split-lp.split-lp.split-lp.split-lp:  ; preds = %eh.lpad.914.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.914.split-lp.split-lp.split-lp.split-lp25
  %.81192 = phi ptr addrspace(1) [ %.91193, %eh.lpad.914.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s41.relocated818, %eh.lpad.914.split-lp.split-lp.split-lp.split-lp25 ]
  br label %eh.lpad.914.split-lp.split-lp.split-lp

eh.lpad.914.split-lp.split-lp.split-lp:           ; preds = %eh.lpad.914.split-lp.split-lp.split-lp.split-lp, %eh.lpad.914.split-lp.split-lp.split-lp22
  %.71191 = phi ptr addrspace(1) [ %.81192, %eh.lpad.914.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s41.relocated812, %eh.lpad.914.split-lp.split-lp.split-lp22 ]
  br label %eh.lpad.914.split-lp.split-lp

eh.lpad.914.split-lp.split-lp:                    ; preds = %eh.lpad.914.split-lp.split-lp.split-lp, %eh.lpad.914.split-lp.split-lp20
  %.61190 = phi ptr addrspace(1) [ %.71191, %eh.lpad.914.split-lp.split-lp.split-lp ], [ %rs4gc.s41.relocated805, %eh.lpad.914.split-lp.split-lp20 ]
  br label %eh.lpad.914.split-lp

eh.lpad.914.split-lp:                             ; preds = %eh.lpad.914.split-lp.split-lp, %eh.lpad.914.split-lp17
  %.51189 = phi ptr addrspace(1) [ %.61190, %eh.lpad.914.split-lp.split-lp ], [ %rs4gc.s41.relocated798, %eh.lpad.914.split-lp17 ]
  br label %eh.lpad.914

eh.lpad.914:                                      ; preds = %eh.lpad.914.split-lp, %eh.lpad.91415
  %.11185 = phi ptr addrspace(1) [ %.51189, %eh.lpad.914.split-lp ], [ %rs4gc.s41.relocated791, %eh.lpad.91415 ]
  br label %try.catch.912

pget.recv_sso.915:                                ; preds = %pget.recv_other.920
  %r4742 = load double, ptr @test_json_tape_batch_records_ts_.str.26.handle, align 8
  %r4743 = bitcast double %r4742 to i64
  %r4744 = and i64 %r4743, 281474976710655
  %statepoint_token792 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r4595, i64 %r4744, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35.relocated780, ptr addrspace(1) %rs4gc.s41.relocated) ]
          to label %eh.cont4746 unwind label %eh.lpad.91415

eh.cont4746:                                      ; preds = %pget.recv_sso.915
  %r4745793 = call double @llvm.experimental.gc.result.f64(token %statepoint_token792)
  %rs4gc.s35.relocated794 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token792, i32 0, i32 0) ; (%rs4gc.s35.relocated780, %rs4gc.s35.relocated780)
  %rs4gc.s41.relocated795 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token792, i32 1, i32 1) ; (%rs4gc.s41.relocated, %rs4gc.s41.relocated)
  br label %pget.recv_merge.919

pget.recv_ok.916:                                 ; preds = %try.body.911
  %r4607 = icmp ugt i64 %r4596, 1048575
  br i1 %r4607, label %pic.recv_hdr.937, label %pic.miss.cold.934

pget.recv_bad.917:                                ; preds = %pget.check_class_ref.921
  %r4732 = icmp eq i64 %r4595, 9222246136947933185
  %r4733 = icmp eq i64 %r4595, 9222246136947933186
  %r4734 = or i1 %r4732, %r4733
  br i1 %r4734, label %pget.throw_nullish.944, label %pget.recv_undef_return.945

pget.recv_class_ref.918:                          ; preds = %pget.check_class_ref.921
  %r4602 = load double, ptr @test_json_tape_batch_records_ts_.str.26.handle, align 8
  %r4603 = bitcast double %r4602 to i64
  %r4604 = and i64 %r4603, 281474976710655
  %statepoint_token799 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 367713371643969571, i64 %r4595, i64 %r4604, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35.relocated780, ptr addrspace(1) %rs4gc.s41.relocated) ]
          to label %eh.cont4606 unwind label %eh.lpad.914.split-lp17

eh.cont4606:                                      ; preds = %pget.recv_class_ref.918
  %r4605800 = call double @llvm.experimental.gc.result.f64(token %statepoint_token799)
  %rs4gc.s35.relocated801 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token799, i32 0, i32 0) ; (%rs4gc.s35.relocated780, %rs4gc.s35.relocated780)
  %rs4gc.s41.relocated802 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token799, i32 1, i32 1) ; (%rs4gc.s41.relocated, %rs4gc.s41.relocated)
  br label %pget.recv_merge.919

pget.recv_merge.919:                              ; preds = %eh.cont4741, %pic.merge.936, %eh.cont4606, %eh.cont4746
  %.21186 = phi ptr addrspace(1) [ %.31187, %pic.merge.936 ], [ %rs4gc.s41.relocated795, %eh.cont4746 ], [ %rs4gc.s41.relocated802, %eh.cont4606 ], [ %rs4gc.s41.relocated827, %eh.cont4741 ]
  %.111169 = phi ptr addrspace(1) [ %.121170, %pic.merge.936 ], [ %rs4gc.s35.relocated794, %eh.cont4746 ], [ %rs4gc.s35.relocated801, %eh.cont4606 ], [ %rs4gc.s35.relocated826, %eh.cont4741 ]
  %r4747 = phi double [ %r4731, %pic.merge.936 ], [ %r4740825, %eh.cont4741 ], [ %r4745793, %eh.cont4746 ], [ %r4605800, %eh.cont4606 ]
  %r4748 = bitcast double %r4747 to i64
  %r4750 = icmp eq i64 %r4748, 9222246136947933186
  %r4751 = icmp eq i64 %r4748, 9222246136947933186
  %r4752 = icmp eq i64 %r4748, 9222246136947933185
  %r4755 = or i1 %r4751, %r4752
  %r4758 = or i1 %r4750, %r4755
  %r4759 = xor i1 %r4758, true
  %r4760 = select i1 %r4759, i64 9222246136947933188, i64 9222246136947933187
  %r4761 = bitcast i64 %r4760 to double
  %r4762 = icmp eq i64 %r4760, 9222246136947933188
  br i1 %r4762, label %if.then.946, label %if.else.947

pget.recv_other.920:                              ; preds = %try.body.911
  %r4600 = icmp eq i64 %r4597, 32761
  br i1 %r4600, label %pget.recv_sso.915, label %pget.check_class_ref.921

pget.check_class_ref.921:                         ; preds = %pget.recv_other.920
  %r4601 = icmp eq i64 %r4597, 32766
  br i1 %r4601, label %pget.recv_class_ref.918, label %pget.recv_bad.917

pic.hit.922:                                      ; preds = %pic.token.938
  %r4632 = getelementptr i64, ptr %r4617, i64 1
  %r4633 = load i64, ptr %r4632, align 8
  %r4634 = and i64 %r4633, 1073741824
  %r4635 = icmp ne i64 %r4634, 0
  br i1 %r4635, label %pic.hit.overflow.939, label %pic.hit.inline.940

pic.hit.live.923:                                 ; preds = %pic.hit.inline.940
  br label %pic.merge.936

pic.prefix.guard.924:                             ; preds = %pic.token.938
  %r4649 = getelementptr i64, ptr %r4617, i64 2
  %r4650 = load i64, ptr %r4649, align 8
  %r4651 = icmp ne i64 %r4650, 0
  br i1 %r4651, label %pic.prefix.meta.925, label %pic.miss.933

pic.prefix.meta.925:                              ; preds = %pic.prefix.guard.924
  %r4652 = add nuw nsw i64 %r4596, 8
  %r4653 = inttoptr i64 %r4652 to ptr
  %r4654 = load i64, ptr %r4653, align 8
  %r4655 = icmp ne i64 %r4654, 0
  br i1 %r4655, label %pic.prefix.token.926, label %pic.miss.933

pic.prefix.token.926:                             ; preds = %pic.prefix.meta.925
  %r4656 = inttoptr i64 %r4654 to ptr
  %r4657 = getelementptr i64, ptr %r4656, i64 6
  %r4658 = load i64, ptr %r4657, align 8
  %r4659 = icmp eq i64 %r4658, %r4650
  br i1 %r4659, label %pic.prefix.hit.927, label %pic.miss.933

pic.prefix.hit.927:                               ; preds = %pic.prefix.token.926
  %r4660 = getelementptr i64, ptr %r4617, i64 1
  %r4661 = load i64, ptr %r4660, align 8
  %r4662 = shl i64 %r4661, 3
  %r4663 = add nuw nsw i64 %r4596, 16
  %r4664 = add i64 %r4663, %r4662
  %r4665 = inttoptr i64 %r4664 to ptr
  %r4666 = load double, ptr %r4665, align 8
  br label %pic.merge.936

pic.desc.classify.928:                            ; preds = %pic.recv_hdr.937
  %r4621 = and i1 %r4611, %r4618
  br i1 %r4621, label %pic.desc.prefix.guard.929, label %pic.miss.cold.934

pic.desc.prefix.guard.929:                        ; preds = %pic.desc.classify.928
  %r4667 = getelementptr i64, ptr %r4617, i64 2
  %r4668 = load i64, ptr %r4667, align 8
  %r4669 = icmp ne i64 %r4668, 0
  br i1 %r4669, label %pic.desc.prefix.meta.930, label %pic.miss.cold.934

pic.desc.prefix.meta.930:                         ; preds = %pic.desc.prefix.guard.929
  %r4670 = add nuw nsw i64 %r4596, 8
  %r4671 = inttoptr i64 %r4670 to ptr
  %r4672 = load i64, ptr %r4671, align 8
  %r4673 = icmp ne i64 %r4672, 0
  br i1 %r4673, label %pic.desc.prefix.token.931, label %pic.miss.cold.934

pic.desc.prefix.token.931:                        ; preds = %pic.desc.prefix.meta.930
  %r4674 = inttoptr i64 %r4672 to ptr
  %r4675 = getelementptr i64, ptr %r4674, i64 6
  %r4676 = load i64, ptr %r4675, align 8
  %r4677 = icmp eq i64 %r4676, %r4668
  br i1 %r4677, label %pic.desc.prefix.hit.932, label %pic.miss.cold.934

pic.desc.prefix.hit.932:                          ; preds = %pic.desc.prefix.token.931
  %r4678 = getelementptr i64, ptr %r4617, i64 1
  %r4679 = load i64, ptr %r4678, align 8
  %r4680 = shl i64 %r4679, 3
  %r4681 = add nuw nsw i64 %r4596, 16
  %r4682 = add i64 %r4681, %r4680
  %r4683 = inttoptr i64 %r4682 to ptr
  %r4684 = load double, ptr %r4683, align 8
  br label %pic.merge.936

pic.miss.933:                                     ; preds = %pic.hit.inline.940, %pic.prefix.token.926, %pic.prefix.meta.925, %pic.prefix.guard.924
  %r4685 = getelementptr i64, ptr %r4617, i64 3
  %r4686 = load i64, ptr %r4685, align 8
  %r4687 = icmp sgt i64 %r4686, 0
  br i1 %r4687, label %pic.ways.941, label %pic.miss.call.935

pic.miss.cold.934:                                ; preds = %pic.desc.prefix.token.931, %pic.desc.prefix.meta.930, %pic.desc.prefix.guard.929, %pic.desc.classify.928, %pget.recv_ok.916
  br label %pic.miss.call.935

pic.miss.call.935:                                ; preds = %pic.way.load.942, %pic.ways.941, %pic.miss.cold.934, %pic.miss.933
  %r4726 = load double, ptr @test_json_tape_batch_records_ts_.str.26.handle, align 8
  %r4727 = bitcast double %r4726 to i64
  %r4728 = and i64 %r4727, 281474976710655
  %statepoint_token806 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r4596, i64 %r4728, ptr @perry_ic_test_json_tape_batch_records_ts__36, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35.relocated780, ptr addrspace(1) %rs4gc.s41.relocated) ]
          to label %eh.cont4730 unwind label %eh.lpad.914.split-lp.split-lp20

eh.cont4730:                                      ; preds = %pic.miss.call.935
  %r4729807 = call double @llvm.experimental.gc.result.f64(token %statepoint_token806)
  %rs4gc.s35.relocated808 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token806, i32 0, i32 0) ; (%rs4gc.s35.relocated780, %rs4gc.s35.relocated780)
  %rs4gc.s41.relocated809 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token806, i32 1, i32 1) ; (%rs4gc.s41.relocated, %rs4gc.s41.relocated)
  br label %pic.merge.936

pic.merge.936:                                    ; preds = %pic.way.live.943, %eh.cont4641, %eh.cont4730, %pic.desc.prefix.hit.932, %pic.prefix.hit.927, %pic.hit.live.923
  %.31187 = phi ptr addrspace(1) [ %rs4gc.s41.relocated816, %eh.cont4641 ], [ %rs4gc.s41.relocated809, %eh.cont4730 ], [ %rs4gc.s41.relocated, %pic.way.live.943 ], [ %rs4gc.s41.relocated, %pic.hit.live.923 ], [ %rs4gc.s41.relocated, %pic.prefix.hit.927 ], [ %rs4gc.s41.relocated, %pic.desc.prefix.hit.932 ]
  %.121170 = phi ptr addrspace(1) [ %rs4gc.s35.relocated815, %eh.cont4641 ], [ %rs4gc.s35.relocated808, %eh.cont4730 ], [ %rs4gc.s35.relocated780, %pic.way.live.943 ], [ %rs4gc.s35.relocated780, %pic.hit.live.923 ], [ %rs4gc.s35.relocated780, %pic.prefix.hit.927 ], [ %rs4gc.s35.relocated780, %pic.desc.prefix.hit.932 ]
  %r4731 = phi double [ %r4646, %pic.hit.live.923 ], [ %r4640814, %eh.cont4641 ], [ %r4666, %pic.prefix.hit.927 ], [ %r4684, %pic.desc.prefix.hit.932 ], [ %r4723, %pic.way.live.943 ], [ %r4729807, %eh.cont4730 ]
  br label %pget.recv_merge.919

pic.recv_hdr.937:                                 ; preds = %pget.recv_ok.916
  %r4608 = sub nuw nsw i64 %r4596, 8
  %r4609 = inttoptr i64 %r4608 to ptr
  %r4610 = load i8, ptr %r4609, align 1
  %r4611 = icmp eq i8 %r4610, 2
  %r4612 = sub nuw nsw i64 %r4596, 6
  %r4613 = inttoptr i64 %r4612 to ptr
  %r4614 = load i16, ptr %r4613, align 2
  %r4615 = and i16 %r4614, 2048
  %r4616 = icmp eq i16 %r4615, 0
  %r4617 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__36, align 8
  %r4618 = icmp ne ptr %r4617, null
  %r4619 = and i1 %r4611, %r4616
  %r4620 = and i1 %r4619, %r4618
  br i1 %r4620, label %pic.token.938, label %pic.desc.classify.928

pic.token.938:                                    ; preds = %pic.recv_hdr.937
  %r4622 = add nuw nsw i64 %r4596, 4
  %r4623 = inttoptr i64 %r4622 to ptr
  %r4624 = load i32, ptr %r4623, align 4
  %r4625 = zext i32 %r4624 to i64
  %r4626 = or i64 %r4625, 4611686018427387904
  %r4627 = icmp ne i32 %r4624, 0
  %r4628 = getelementptr i64, ptr %r4617, i64 0
  %r4629 = load i64, ptr %r4628, align 8
  %r4630 = icmp eq i64 %r4626, %r4629
  %r4631 = and i1 %r4630, %r4627
  br i1 %r4631, label %pic.hit.922, label %pic.prefix.guard.924

pic.hit.overflow.939:                             ; preds = %pic.hit.922
  %r4636 = load double, ptr @test_json_tape_batch_records_ts_.str.26.handle, align 8
  %r4637 = bitcast double %r4636 to i64
  %r4638 = and i64 %r4637, 281474976710655
  %r4639 = trunc i64 %r4633 to i32
  %statepoint_token813 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r4596, i64 %r4638, i32 %r4639, ptr @perry_ic_test_json_tape_batch_records_ts__36, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35.relocated780, ptr addrspace(1) %rs4gc.s41.relocated) ]
          to label %eh.cont4641 unwind label %eh.lpad.914.split-lp.split-lp.split-lp22

eh.cont4641:                                      ; preds = %pic.hit.overflow.939
  %r4640814 = call double @llvm.experimental.gc.result.f64(token %statepoint_token813)
  %rs4gc.s35.relocated815 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token813, i32 0, i32 0) ; (%rs4gc.s35.relocated780, %rs4gc.s35.relocated780)
  %rs4gc.s41.relocated816 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token813, i32 1, i32 1) ; (%rs4gc.s41.relocated, %rs4gc.s41.relocated)
  br label %pic.merge.936

pic.hit.inline.940:                               ; preds = %pic.hit.922
  %r4642 = shl i64 %r4633, 3
  %r4643 = add nuw nsw i64 %r4596, 16
  %r4644 = add i64 %r4643, %r4642
  %r4645 = inttoptr i64 %r4644 to ptr
  %r4646 = load double, ptr %r4645, align 8
  %r4647 = bitcast double %r4646 to i64
  %r4648 = icmp eq i64 %r4647, 9222246136947933200
  br i1 %r4648, label %pic.miss.933, label %pic.hit.live.923

pic.ways.941:                                     ; preds = %pic.miss.933
  %r4688 = getelementptr i64, ptr %r4617, i64 4
  %r4689 = load i64, ptr %r4688, align 8
  %r4690 = icmp eq i64 %r4689, %r4626
  %r4691 = getelementptr i64, ptr %r4617, i64 5
  %r4692 = load i64, ptr %r4691, align 8
  %r4693 = select i1 %r4690, i64 %r4692, i64 0
  %r4694 = getelementptr i64, ptr %r4617, i64 6
  %r4695 = load i64, ptr %r4694, align 8
  %r4696 = icmp eq i64 %r4695, %r4626
  %r4697 = getelementptr i64, ptr %r4617, i64 7
  %r4698 = load i64, ptr %r4697, align 8
  %r4699 = select i1 %r4696, i64 %r4698, i64 0
  %r4700 = getelementptr i64, ptr %r4617, i64 8
  %r4701 = load i64, ptr %r4700, align 8
  %r4702 = icmp eq i64 %r4701, %r4626
  %r4703 = getelementptr i64, ptr %r4617, i64 9
  %r4704 = load i64, ptr %r4703, align 8
  %r4705 = select i1 %r4702, i64 %r4704, i64 0
  %r4706 = getelementptr i64, ptr %r4617, i64 10
  %r4707 = load i64, ptr %r4706, align 8
  %r4708 = icmp eq i64 %r4707, %r4626
  %r4709 = getelementptr i64, ptr %r4617, i64 11
  %r4710 = load i64, ptr %r4709, align 8
  %r4711 = select i1 %r4708, i64 %r4710, i64 0
  %r4712 = or i1 %r4690, %r4696
  %r4713 = select i1 %r4690, i64 %r4693, i64 %r4699
  %r4714 = or i1 %r4702, %r4708
  %r4715 = select i1 %r4702, i64 %r4705, i64 %r4711
  %r4716 = or i1 %r4712, %r4714
  %r4717 = select i1 %r4712, i64 %r4713, i64 %r4715
  %r4718 = and i1 %r4627, %r4716
  br i1 %r4718, label %pic.way.load.942, label %pic.miss.call.935

pic.way.load.942:                                 ; preds = %pic.ways.941
  %r4719 = shl i64 %r4717, 3
  %r4720 = add nuw nsw i64 %r4596, 16
  %r4721 = add i64 %r4720, %r4719
  %r4722 = inttoptr i64 %r4721 to ptr
  %r4723 = load double, ptr %r4722, align 8
  %r4724 = bitcast double %r4723 to i64
  %r4725 = icmp eq i64 %r4724, 9222246136947933200
  br i1 %r4725, label %pic.miss.call.935, label %pic.way.live.943

pic.way.live.943:                                 ; preds = %pic.way.load.942
  br label %pic.merge.936

pget.throw_nullish.944:                           ; preds = %pget.recv_bad.917
  %r4735 = zext i1 %r4733 to i32
  %statepoint_token819 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r4735, ptr @test_json_tape_batch_records_ts_.str.26.bytes, i64 6, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s41.relocated) ]
          to label %eh.cont4736 unwind label %eh.lpad.914.split-lp.split-lp.split-lp.split-lp25

eh.cont4736:                                      ; preds = %pget.throw_nullish.944
  %rs4gc.s41.relocated820 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token819, i32 0, i32 0) ; (%rs4gc.s41.relocated, %rs4gc.s41.relocated)
  unreachable

pget.recv_undef_return.945:                       ; preds = %pget.recv_bad.917
  %r4737 = load double, ptr @test_json_tape_batch_records_ts_.str.26.handle, align 8
  %r4738 = bitcast double %r4737 to i64
  %r4739 = and i64 %r4738, 281474976710655
  %statepoint_token824 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r4595, i64 %r4739, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35.relocated780, ptr addrspace(1) %rs4gc.s41.relocated) ]
          to label %eh.cont4741 unwind label %eh.lpad.914.split-lp.split-lp.split-lp.split-lp.split-lp27

eh.cont4741:                                      ; preds = %pget.recv_undef_return.945
  %r4740825 = call double @llvm.experimental.gc.result.f64(token %statepoint_token824)
  %rs4gc.s35.relocated826 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token824, i32 0, i32 0) ; (%rs4gc.s35.relocated780, %rs4gc.s35.relocated780)
  %rs4gc.s41.relocated827 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token824, i32 1, i32 1) ; (%rs4gc.s41.relocated, %rs4gc.s41.relocated)
  br label %pget.recv_merge.919

if.then.946:                                      ; preds = %pget.recv_merge.919
  %r4763.rs4i = ptrtoint ptr addrspace(1) %.111169 to i64
  %r4763.rs4o = call i64 asm "", "=r,0"(i64 %r4763.rs4i) #7
  %r4763 = bitcast i64 %r4763.rs4o to double
  %r4765 = or i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.26.dispatch to i64), 9221120237041090560
  %statepoint_token830 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, i64, ptr, i64)) @js_typed_feedback_native_call_method_by_id, i32 5, i32 0, i64 367713371643969573, double %r4763, i64 %r4765, ptr null, i64 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.21186) ]
          to label %eh.cont4767 unwind label %eh.lpad.914.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.cont4767:                                      ; preds = %if.then.946
  %rs4gc.s41.relocated831 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token830, i32 0, i32 0) ; (%.21186, %.21186)
  br label %if.merge.948

if.else.947:                                      ; preds = %pget.recv_merge.919
  br label %if.merge.948

if.merge.948:                                     ; preds = %if.else.947, %eh.cont4767
  %.41188 = phi ptr addrspace(1) [ %rs4gc.s41.relocated831, %eh.cont4767 ], [ %.21186, %if.else.947 ]
  %statepoint_token832 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_try_end, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.41188) ]
  %rs4gc.s41.relocated833 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token832, i32 0, i32 0) ; (%.41188, %.41188)
  br label %try.finally.913

shadow.root.barrier.949:                          ; preds = %try.catch.912
  call void @js_write_barrier_root_nanbox(i64 %r4770) #7
  br label %shadow.root.barrier.done.950

shadow.root.barrier.done.950:                     ; preds = %shadow.root.barrier.949, %try.catch.912
  br label %try.finally.913

gcpoll.951:                                       ; preds = %try.finally.901
  %statepoint_token834 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35.relocated777, ptr addrspace(1) %rs4gc.s15.relocated778) ]
  %rs4gc.s35.relocated835 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token834, i32 0, i32 0) ; (%rs4gc.s35.relocated777, %rs4gc.s35.relocated777)
  %rs4gc.s15.relocated836 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token834, i32 1, i32 1) ; (%rs4gc.s15.relocated778, %rs4gc.s15.relocated778)
  br label %gcpoll.done.952

gcpoll.done.952:                                  ; preds = %gcpoll.951, %try.finally.901
  %.81166 = phi ptr addrspace(1) [ %rs4gc.s35.relocated835, %gcpoll.951 ], [ %rs4gc.s35.relocated777, %try.finally.901 ]
  %.48 = phi ptr addrspace(1) [ %rs4gc.s15.relocated836, %gcpoll.951 ], [ %rs4gc.s15.relocated778, %try.finally.901 ]
  br label %for.update.826

shadow.root.barrier.953:                          ; preds = %for.update.826
  call void @js_write_barrier_root_nanbox(i64 %r4778) #7
  br label %shadow.root.barrier.done.954

shadow.root.barrier.done.954:                     ; preds = %shadow.root.barrier.953, %for.update.826
  %r4781 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r4782 = icmp ne i32 %r4781, 0
  br i1 %r4782, label %gcpoll.955, label %gcpoll.done.956

gcpoll.955:                                       ; preds = %shadow.root.barrier.done.954
  %statepoint_token837 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s38, ptr addrspace(1) %rs4gc.s35.relocated662, ptr addrspace(1) %rs4gc.s15.relocated663) ]
  %rs4gc.s38.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token837, i32 0, i32 0) ; (%rs4gc.s38, %rs4gc.s38)
  %rs4gc.s35.relocated838 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token837, i32 1, i32 1) ; (%rs4gc.s35.relocated662, %rs4gc.s35.relocated662)
  %rs4gc.s15.relocated839 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token837, i32 2, i32 2) ; (%rs4gc.s15.relocated663, %rs4gc.s15.relocated663)
  br label %gcpoll.done.956

gcpoll.done.956:                                  ; preds = %gcpoll.955, %shadow.root.barrier.done.954
  %.01194 = phi ptr addrspace(1) [ %rs4gc.s38.relocated, %gcpoll.955 ], [ %rs4gc.s38, %shadow.root.barrier.done.954 ]
  %.131171 = phi ptr addrspace(1) [ %rs4gc.s35.relocated838, %gcpoll.955 ], [ %rs4gc.s35.relocated662, %shadow.root.barrier.done.954 ]
  %.51 = phi ptr addrspace(1) [ %rs4gc.s15.relocated839, %gcpoll.955 ], [ %rs4gc.s15.relocated663, %shadow.root.barrier.done.954 ]
  br label %for.cond.824

str_addref.call.957:                              ; preds = %if.else.818
  call void @js_string_addref_if_heap_string(double %r4784) #7
  br label %str_addref.done.958

str_addref.done.958:                              ; preds = %str_addref.call.957, %if.else.818
  %r5965.rs4i = ptrtoint ptr addrspace(1) %r131.0.relocated648 to i64
  %r5965.rs4o = call i64 asm "", "=r,0"(i64 %r5965.rs4i) #7
  %r5965 = bitcast i64 %r5965.rs4o to double
  %rs4gc.b45 = bitcast double %r5965 to i64
  %rs4gc.s45 = inttoptr i64 %rs4gc.b45 to ptr addrspace(1)
  %r4788.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s45 to i64
  %r4788 = call i64 asm "", "=r,0"(i64 %r4788.rs4i) #7
  %r4789 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4790 = icmp ne i32 %r4789, 0
  br i1 %r4790, label %shadow.root.barrier.959, label %shadow.root.barrier.done.960

shadow.root.barrier.959:                          ; preds = %str_addref.done.958
  call void @js_write_barrier_root_nanbox(i64 %r4788) #7
  br label %shadow.root.barrier.done.960

shadow.root.barrier.done.960:                     ; preds = %shadow.root.barrier.959, %str_addref.done.958
  br label %for.cond.961

for.cond.961:                                     ; preds = %for.update.963, %shadow.root.barrier.done.960
  %.01195 = phi ptr addrspace(1) [ %rs4gc.s45, %shadow.root.barrier.done.960 ], [ %.51200, %for.update.963 ]
  %.52 = phi ptr addrspace(1) [ %rs4gc.s15.relocated647, %shadow.root.barrier.done.960 ], [ %.57, %for.update.963 ]
  %r4791.0 = phi i32 [ 0, %shadow.root.barrier.done.960 ], [ %r5006, %for.update.963 ]
  %r4793 = sitofp i32 %r4791.0 to double
  %r4794.rs4i = ptrtoint ptr addrspace(1) %.01195 to i64
  %r4794.rs4o = call i64 asm "", "=r,0"(i64 %r4794.rs4i) #7
  %r4794 = bitcast i64 %r4794.rs4o to double
  %r4795 = bitcast double %r4794 to i64
  %r4796 = and i64 %r4795, 281474976710655
  %r4797 = lshr i64 %r4795, 48
  %r4798 = and i64 %r4797, 65533
  %r4799 = icmp eq i64 %r4798, 32765
  %r4800 = icmp ugt i64 %r4796, 1048575
  %r4801 = and i1 %r4799, %r4800
  br i1 %r4801, label %plen.check_gc.965, label %plen.slow.967

for.body.962:                                     ; preds = %gcpoll.done.987
  %r4908.rs4i = ptrtoint ptr addrspace(1) %.31198 to i64
  %r4908.rs4o = call i64 asm "", "=r,0"(i64 %r4908.rs4i) #7
  %r4908 = bitcast i64 %r4908.rs4o to double
  %r4910 = bitcast double %r4908 to i64
  %r4911 = and i64 %r4910, 281474976710655
  %r4912 = lshr i64 %r4910, 48
  %r4913 = icmp eq i64 %r4912, 32765
  %r4914 = icmp ugt i64 %r4911, 1048575
  %r4915 = and i1 %r4913, %r4914
  br i1 %r4915, label %arr.guard.deref.992, label %arr.fallback.989

for.update.963:                                   ; preds = %gcpoll.done.1004
  %r5006 = add i32 %r4791.0, 1
  %r5007 = sitofp i32 %r4791.0 to double
  %r5008 = sitofp i32 %r5006 to double
  br label %for.cond.961

for.exit.964:                                     ; preds = %gcpoll.done.987
  br label %if.merge.819

plen.check_gc.965:                                ; preds = %for.cond.961
  %r4802 = sub nuw nsw i64 %r4796, 8
  %r4803 = inttoptr i64 %r4802 to ptr
  %r4804 = load i8, ptr %r4803, align 1
  %r4805 = icmp eq i8 %r4804, 1
  %r4806 = icmp eq i8 %r4804, 3
  %r4807 = or i1 %r4805, %r4806
  %r4808 = sub nuw nsw i64 %r4796, 7
  %r4809 = inttoptr i64 %r4808 to ptr
  %r4810 = load i8, ptr %r4809, align 1
  %r4811 = and i8 %r4810, -128
  %r4812 = icmp eq i8 %r4811, 0
  %r4813 = and i1 %r4807, %r4812
  br i1 %r4813, label %plen.fast.966, label %plen.slow.967

plen.fast.966:                                    ; preds = %plen.check_gc.965
  %r4815 = inttoptr i64 %r4796 to ptr
  %r4816 = select i1 false, ptr @perry_null_guard_zero_test_json_tape_batch_records_ts, ptr %r4815
  %r4817 = load i32, ptr %r4816, align 4
  %r4818 = uitofp i32 %r4817 to double
  br label %plen.merge.968

plen.slow.967:                                    ; preds = %plen.check_gc.965, %for.cond.961
  %r4819 = lshr i64 %r4795, 48
  %r4820 = icmp eq i64 %r4819, 32765
  %r4821 = icmp uge i64 %r4796, 2199023255552
  %r4822 = icmp ult i64 %r4796, 140737488355328
  %r4823 = and i1 %r4820, %r4821
  %r4824 = and i1 %r4823, %r4822
  %r4825 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__38, align 8
  br i1 %r4824, label %plen.ic.header.969, label %plen.ic.miss.981

plen.merge.968:                                   ; preds = %plen.ic.merge.982, %plen.fast.966
  %.11196 = phi ptr addrspace(1) [ %.01195, %plen.fast.966 ], [ %.21197, %plen.ic.merge.982 ]
  %.53 = phi ptr addrspace(1) [ %.52, %plen.fast.966 ], [ %.54, %plen.ic.merge.982 ]
  %r4900 = phi double [ %r4818, %plen.fast.966 ], [ %r4899, %plen.ic.merge.982 ]
  %r4901 = fcmp olt double %r4793, %r4900
  %r4902 = select i1 %r4901, i64 9222246136947933188, i64 9222246136947933187
  %r4903 = bitcast i64 %r4902 to double
  %r4905 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r4906 = icmp ne i32 %r4905, 0
  br i1 %r4906, label %gcpoll.986, label %gcpoll.done.987

plen.ic.header.969:                               ; preds = %plen.slow.967
  %r4827 = sub nuw nsw i64 %r4796, 8
  %r4828 = inttoptr i64 %r4827 to ptr
  %r4829 = load i8, ptr %r4828, align 1
  %r4830 = icmp eq i8 %r4829, 2
  %r4831 = sub nuw nsw i64 %r4796, 7
  %r4832 = inttoptr i64 %r4831 to ptr
  %r4833 = load i8, ptr %r4832, align 1
  %r4834 = and i8 %r4833, -128
  %r4835 = icmp eq i8 %r4834, 0
  %r4836 = and i1 %r4830, %r4835
  br i1 %r4836, label %plen.elem.meta.983, label %plen.ic.miss.981

plen.ic.shape.970:                                ; preds = %plen.elem.store.984, %plen.elem.meta.983
  %r4826 = icmp ne ptr %r4825, null
  br i1 %r4826, label %plen.ic.shape.probe.971, label %plen.ic.miss.981

plen.ic.shape.probe.971:                          ; preds = %plen.ic.shape.970
  %r4848 = inttoptr i64 %r4796 to ptr
  %r4849 = load i32, ptr %r4848, align 4
  %r4850 = add nuw nsw i64 %r4796, 4
  %r4851 = inttoptr i64 %r4850 to ptr
  %r4852 = load i32, ptr %r4851, align 4
  %r4853 = zext i32 %r4849 to i64
  %r4854 = zext i32 %r4852 to i64
  %r4855 = shl nuw i64 %r4853, 32
  %r4856 = or i64 %r4855, %r4854
  %r4857 = getelementptr i64, ptr %r4825, i64 0
  %r4858 = load i64, ptr %r4857, align 8
  %r4859 = icmp ne i64 %r4858, 0
  br i1 %r4859, label %plen.ic.identity.972, label %plen.ic.miss.981

plen.ic.identity.972:                             ; preds = %plen.ic.shape.probe.971
  %r4860 = and i64 %r4858, -9223372036854775808
  %7 = icmp slt i64 %r4858, 0
  br i1 %7, label %plen.ic.family_meta.974, label %plen.ic.exact.973

plen.ic.exact.973:                                ; preds = %plen.ic.identity.972
  %r4862 = icmp eq i64 %r4856, %r4858
  br i1 %r4862, label %plen.ic.slot.976, label %plen.ic.miss.981

plen.ic.family_meta.974:                          ; preds = %plen.ic.identity.972
  %r4863 = add nuw nsw i64 %r4796, 8
  %r4864 = inttoptr i64 %r4863 to ptr
  %r4865 = load i64, ptr %r4864, align 8
  %r4866 = icmp ne i64 %r4865, 0
  br i1 %r4866, label %plen.ic.family_token.975, label %plen.ic.miss.981

plen.ic.family_token.975:                         ; preds = %plen.ic.family_meta.974
  %r4867 = inttoptr i64 %r4865 to ptr
  %r4868 = getelementptr i64, ptr %r4867, i64 6
  %r4869 = load i64, ptr %r4868, align 8
  %r4870 = icmp eq i64 %r4869, %r4858
  br i1 %r4870, label %plen.ic.slot.976, label %plen.ic.miss.981

plen.ic.slot.976:                                 ; preds = %plen.ic.family_token.975, %plen.ic.exact.973
  %r4871 = getelementptr i64, ptr %r4825, i64 1
  %r4872 = load i64, ptr %r4871, align 8
  %r4873 = getelementptr i64, ptr %r4825, i64 2
  %r4874 = load i64, ptr %r4873, align 8
  %r4875 = icmp ult i64 %r4872, %r4874
  br i1 %r4875, label %plen.ic.inline.977, label %plen.ic.spill_meta.978

plen.ic.inline.977:                               ; preds = %plen.ic.slot.976
  %r4876 = shl i64 %r4872, 3
  %r4877 = add i64 %r4876, 16
  %r4878 = add i64 %r4796, %r4877
  %r4879 = inttoptr i64 %r4878 to ptr
  %r4880 = load double, ptr %r4879, align 8
  br label %plen.ic.merge.982

plen.ic.spill_meta.978:                           ; preds = %plen.ic.slot.976
  %r4881 = add nuw nsw i64 %r4796, 8
  %r4882 = inttoptr i64 %r4881 to ptr
  %r4883 = load i64, ptr %r4882, align 8
  %r4884 = icmp ne i64 %r4883, 0
  br i1 %r4884, label %plen.ic.spill_ptr.979, label %plen.ic.miss.981

plen.ic.spill_ptr.979:                            ; preds = %plen.ic.spill_meta.978
  %r4885 = inttoptr i64 %r4883 to ptr
  %r4886 = getelementptr i64, ptr %r4885, i64 4
  %r4887 = load i64, ptr %r4886, align 8
  %r4888 = icmp ne i64 %r4887, 0
  %r4889 = select i1 %r4888, i64 %r4887, i64 %r4883
  %r4890 = inttoptr i64 %r4889 to ptr
  %r4891 = load i32, ptr %r4890, align 4
  %r4892 = zext i32 %r4891 to i64
  %r4893 = icmp ult i64 %r4872, %r4892
  %r4894 = and i1 %r4888, %r4893
  br i1 %r4894, label %plen.ic.spill_load.980, label %plen.ic.miss.981

plen.ic.spill_load.980:                           ; preds = %plen.ic.spill_ptr.979
  %r4895 = add nuw nsw i64 %r4872, 1
  %r4896 = getelementptr inbounds nuw i64, ptr %r4890, i64 %r4895
  %r4897 = load double, ptr %r4896, align 8
  br label %plen.ic.merge.982

plen.ic.miss.981:                                 ; preds = %plen.ic.spill_ptr.979, %plen.ic.spill_meta.978, %plen.ic.family_token.975, %plen.ic.family_meta.974, %plen.ic.exact.973, %plen.ic.shape.probe.971, %plen.ic.shape.970, %plen.ic.header.969, %plen.slow.967
  %statepoint_token840 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r4794, ptr @perry_ic_test_json_tape_batch_records_ts__38, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01195, ptr addrspace(1) %.52) ]
  %r4898841 = call double @llvm.experimental.gc.result.f64(token %statepoint_token840)
  %rs4gc.s45.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token840, i32 0, i32 0) ; (%.01195, %.01195)
  %rs4gc.s15.relocated842 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token840, i32 1, i32 1) ; (%.52, %.52)
  br label %plen.ic.merge.982

plen.ic.merge.982:                                ; preds = %plen.elem.length.985, %plen.ic.miss.981, %plen.ic.spill_load.980, %plen.ic.inline.977
  %.21197 = phi ptr addrspace(1) [ %.01195, %plen.elem.length.985 ], [ %.01195, %plen.ic.inline.977 ], [ %.01195, %plen.ic.spill_load.980 ], [ %rs4gc.s45.relocated, %plen.ic.miss.981 ]
  %.54 = phi ptr addrspace(1) [ %.52, %plen.elem.length.985 ], [ %.52, %plen.ic.inline.977 ], [ %.52, %plen.ic.spill_load.980 ], [ %rs4gc.s15.relocated842, %plen.ic.miss.981 ]
  %r4899 = phi double [ %r4847, %plen.elem.length.985 ], [ %r4880, %plen.ic.inline.977 ], [ %r4897, %plen.ic.spill_load.980 ], [ %r4898841, %plen.ic.miss.981 ]
  br label %plen.merge.968

plen.elem.meta.983:                               ; preds = %plen.ic.header.969
  %r4837 = add nuw nsw i64 %r4796, 8
  %r4838 = inttoptr i64 %r4837 to ptr
  %r4839 = load i64, ptr %r4838, align 8
  %r4840 = icmp ne i64 %r4839, 0
  br i1 %r4840, label %plen.elem.store.984, label %plen.ic.shape.970

plen.elem.store.984:                              ; preds = %plen.elem.meta.983
  %r4841 = inttoptr i64 %r4839 to ptr
  %r4842 = getelementptr i64, ptr %r4841, i64 12
  %r4843 = load i64, ptr %r4842, align 8
  %r4844 = icmp ne i64 %r4843, 0
  br i1 %r4844, label %plen.elem.length.985, label %plen.ic.shape.970

plen.elem.length.985:                             ; preds = %plen.elem.store.984
  %r4845 = inttoptr i64 %r4843 to ptr
  %r4846 = load i32, ptr %r4845, align 4
  %r4847 = uitofp i32 %r4846 to double
  br label %plen.ic.merge.982

gcpoll.986:                                       ; preds = %plen.merge.968
  %statepoint_token843 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11196, ptr addrspace(1) %.53) ]
  %rs4gc.s45.relocated844 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token843, i32 0, i32 0) ; (%.11196, %.11196)
  %rs4gc.s15.relocated845 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token843, i32 1, i32 1) ; (%.53, %.53)
  br label %gcpoll.done.987

gcpoll.done.987:                                  ; preds = %gcpoll.986, %plen.merge.968
  %.31198 = phi ptr addrspace(1) [ %rs4gc.s45.relocated844, %gcpoll.986 ], [ %.11196, %plen.merge.968 ]
  %.55 = phi ptr addrspace(1) [ %rs4gc.s15.relocated845, %gcpoll.986 ], [ %.53, %plen.merge.968 ]
  %r4904 = icmp eq i64 %r4902, 9222246136947933188
  br i1 %r4904, label %for.body.962, label %for.exit.964

arr.fast.988:                                     ; preds = %arr.guard.range.994
  %r4971 = zext i32 %r4791.0 to i64
  %r4972 = shl nuw nsw i64 %r4971, 3
  %r4973 = add nuw nsw i64 %r4972, 8
  %r4974 = add i64 %r4930, %r4973
  %r4975 = inttoptr i64 %r4974 to ptr
  %r4976 = load double, ptr %r4975, align 8
  %r4977 = bitcast double %r4976 to i64
  %r4978 = icmp eq i64 %r4977, 9222246136947933200
  %r4980 = select i1 %r4978, double 0x7FFC000000000001, double %r4976
  br label %arr.merge.991

arr.fallback.989:                                 ; preds = %arr.guard.live.993, %arr.guard.deref.992, %for.body.962
  %r4969 = sitofp i32 %r4791.0 to double
  %statepoint_token846 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 367713371643969575, double %r4908, double %r4969, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31198, ptr addrspace(1) %.55) ]
  %r4970847 = call double @llvm.experimental.gc.result.f64(token %statepoint_token846)
  %rs4gc.s45.relocated848 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token846, i32 0, i32 0) ; (%.31198, %.31198)
  %rs4gc.s15.relocated849 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token846, i32 1, i32 1) ; (%.55, %.55)
  br label %arr.merge.991

arr.guard.oob.990:                                ; preds = %arr.guard.range.994
  br label %arr.merge.991

arr.merge.991:                                    ; preds = %arr.guard.oob.990, %arr.fallback.989, %arr.fast.988
  %.41199 = phi ptr addrspace(1) [ %.31198, %arr.fast.988 ], [ %.31198, %arr.guard.oob.990 ], [ %rs4gc.s45.relocated848, %arr.fallback.989 ]
  %.56 = phi ptr addrspace(1) [ %.55, %arr.fast.988 ], [ %.55, %arr.guard.oob.990 ], [ %rs4gc.s15.relocated849, %arr.fallback.989 ]
  %r4981 = phi double [ %r4980, %arr.fast.988 ], [ %r4970847, %arr.fallback.989 ], [ 0x7FFC000000000001, %arr.guard.oob.990 ]
  %rs4gc.b46 = bitcast double %r4981 to i64
  %rs4gc.s46 = inttoptr i64 %rs4gc.b46 to ptr addrspace(1)
  %r4982 = bitcast double %r4981 to i64
  %r4983 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4984 = icmp ne i32 %r4983, 0
  br i1 %r4984, label %shadow.root.barrier.995, label %shadow.root.barrier.done.996

arr.guard.deref.992:                              ; preds = %for.body.962
  %r4916 = bitcast double %r4908 to i64
  %r4917 = and i64 %r4916, 281474976710655
  %r4918 = sub nsw i64 %r4917, 8
  %r4919 = inttoptr i64 %r4918 to ptr
  %r4920 = load i8, ptr %r4919, align 1
  %r4921 = icmp eq i8 %r4920, 1
  %r4922 = sub nsw i64 %r4917, 7
  %r4923 = inttoptr i64 %r4922 to ptr
  %r4924 = load i8, ptr %r4923, align 1
  %r4925 = and i8 %r4924, -128
  %r4926 = icmp ne i8 %r4925, 0
  %r4927 = inttoptr i64 %r4917 to ptr
  %r4928 = load i64, ptr %r4927, align 8
  %r4929 = and i1 %r4921, %r4926
  %r4930 = select i1 %r4929, i64 %r4928, i64 %r4917
  %r4931 = lshr i64 %r4930, 48
  %r4932 = icmp eq i64 %r4931, 0
  %r4933 = icmp ugt i64 %r4930, 1048575
  %r4934 = and i1 %r4932, %r4933
  br i1 %r4934, label %arr.guard.live.993, label %arr.fallback.989

arr.guard.live.993:                               ; preds = %arr.guard.deref.992
  %r4935 = sub nuw i64 %r4930, 8
  %r4936 = inttoptr i64 %r4935 to ptr
  %r4937 = load i8, ptr %r4936, align 1
  %r4938 = icmp eq i8 %r4937, 1
  %r4939 = sub nuw i64 %r4930, 7
  %r4940 = inttoptr i64 %r4939 to ptr
  %r4941 = load i8, ptr %r4940, align 1
  %r4942 = and i8 %r4941, -128
  %r4943 = icmp eq i8 %r4942, 0
  %r4944 = sub nuw i64 %r4930, 6
  %r4945 = inttoptr i64 %r4944 to ptr
  %r4946 = load i16, ptr %r4945, align 2
  %r4947 = and i16 %r4946, 1024
  %r4948 = icmp eq i16 %r4947, 0
  %r4949 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r4950 = icmp eq i8 %r4949, 0
  %r4951 = inttoptr i64 %r4930 to ptr
  %r4952 = load i32, ptr %r4951, align 4
  %r4953 = getelementptr i8, ptr %r4951, i64 4
  %r4954 = load i32, ptr %r4953, align 4
  %r4955 = icmp slt i32 %r4791.0, 0
  %r4956 = icmp eq i1 %r4955, false
  %r4958 = icmp ule i32 %r4952, 16000000
  %r4959 = icmp ule i32 %r4954, 16000000
  %r4960 = icmp ule i32 %r4952, %r4954
  %r4961 = and i1 %r4938, %r4943
  %r4962 = and i1 %r4961, %r4948
  %r4963 = and i1 %r4962, %r4950
  %r4964 = and i1 %r4963, %r4956
  %r4965 = and i1 %r4964, %r4958
  %r4966 = and i1 %r4965, %r4959
  %r4967 = and i1 %r4966, %r4960
  br i1 %r4967, label %arr.guard.range.994, label %arr.fallback.989

arr.guard.range.994:                              ; preds = %arr.guard.live.993
  %r4957 = icmp ult i32 %r4791.0, %r4952
  br i1 %r4957, label %arr.fast.988, label %arr.guard.oob.990

shadow.root.barrier.995:                          ; preds = %arr.merge.991
  call void @js_write_barrier_root_nanbox(i64 %r4982) #7
  br label %shadow.root.barrier.done.996

shadow.root.barrier.done.996:                     ; preds = %shadow.root.barrier.995, %arr.merge.991
  %r4985.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s46 to i64
  %r4985.rs4o = call i64 asm "", "=r,0"(i64 %r4985.rs4i) #7
  %r4985 = bitcast i64 %r4985.rs4o to double
  %statepoint_token850 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r4985, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.41199, ptr addrspace(1) %.56) ]
  %r4986851 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token850)
  %rs4gc.s45.relocated852 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token850, i32 0, i32 0) ; (%.41199, %.41199)
  %rs4gc.s15.relocated853 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token850, i32 1, i32 1) ; (%.56, %.56)
  %r4987 = bitcast i64 %r4986851 to double
  %rs4gc.s47 = inttoptr i64 %r4986851 to ptr addrspace(1)
  %r4988.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s47 to i64
  %r4988 = call i64 asm "", "=r,0"(i64 %r4988.rs4i) #7
  %r4989 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4990 = icmp ne i32 %r4989, 0
  br i1 %r4990, label %shadow.root.barrier.997, label %shadow.root.barrier.done.998

shadow.root.barrier.997:                          ; preds = %shadow.root.barrier.done.996
  call void @js_write_barrier_root_nanbox(i64 %r4988) #7
  br label %shadow.root.barrier.done.998

shadow.root.barrier.done.998:                     ; preds = %shadow.root.barrier.997, %shadow.root.barrier.done.996
  %statepoint_token854 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s45.relocated852, ptr addrspace(1) %rs4gc.s15.relocated853, ptr addrspace(1) %rs4gc.s47) ]
  %r4991855 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token854)
  %rs4gc.s45.relocated856 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token854, i32 0, i32 0) ; (%rs4gc.s45.relocated852, %rs4gc.s45.relocated852)
  %rs4gc.s15.relocated857 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token854, i32 1, i32 1) ; (%rs4gc.s15.relocated853, %rs4gc.s15.relocated853)
  %rs4gc.s47.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token854, i32 2, i32 2) ; (%rs4gc.s47, %rs4gc.s47)
  %rs4gc.s48 = inttoptr i64 %r4991855 to ptr addrspace(1)
  %r4992.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s48 to i64
  %r4992 = call i64 asm "", "=r,0"(i64 %r4992.rs4i) #7
  %r4993 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4994 = icmp ne i32 %r4993, 0
  br i1 %r4994, label %shadow.root.barrier.999, label %shadow.root.barrier.done.1000

shadow.root.barrier.999:                          ; preds = %shadow.root.barrier.done.998
  call void @js_write_barrier_root_nanbox(i64 %r4992) #7
  br label %shadow.root.barrier.done.1000

shadow.root.barrier.done.1000:                    ; preds = %shadow.root.barrier.999, %shadow.root.barrier.done.998
  %r4995.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s47.relocated to i64
  %r4995 = call i64 asm "", "=r,0"(i64 %r4995.rs4i) #7
  %r4996 = bitcast i64 %r4995 to double
  %r4997.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s48 to i64
  %r4997 = call i64 asm "", "=r,0"(i64 %r4997.rs4i) #7
  %statepoint_token858 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4997, double %r4996, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s45.relocated856, ptr addrspace(1) %rs4gc.s15.relocated857) ]
  %r4998859 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token858)
  %rs4gc.s45.relocated860 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token858, i32 0, i32 0) ; (%rs4gc.s45.relocated856, %rs4gc.s45.relocated856)
  %rs4gc.s15.relocated861 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token858, i32 1, i32 1) ; (%rs4gc.s15.relocated857, %rs4gc.s15.relocated857)
  %rs4gc.s49 = inttoptr i64 %r4998859 to ptr addrspace(1)
  %r4999.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s49 to i64
  %r4999 = call i64 asm "", "=r,0"(i64 %r4999.rs4i) #7
  %r5000 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5001 = icmp ne i32 %r5000, 0
  br i1 %r5001, label %shadow.root.barrier.1001, label %shadow.root.barrier.done.1002

shadow.root.barrier.1001:                         ; preds = %shadow.root.barrier.done.1000
  call void @js_write_barrier_root_nanbox(i64 %r4999) #7
  br label %shadow.root.barrier.done.1002

shadow.root.barrier.done.1002:                    ; preds = %shadow.root.barrier.1001, %shadow.root.barrier.done.1000
  %r5002.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s49 to i64
  %r5002 = call i64 asm "", "=r,0"(i64 %r5002.rs4i) #7
  %statepoint_token862 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r5002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s45.relocated860, ptr addrspace(1) %rs4gc.s15.relocated861) ]
  %rs4gc.s45.relocated863 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token862, i32 0, i32 0) ; (%rs4gc.s45.relocated860, %rs4gc.s45.relocated860)
  %rs4gc.s15.relocated864 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token862, i32 1, i32 1) ; (%rs4gc.s15.relocated861, %rs4gc.s15.relocated861)
  %r5003 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r5004 = icmp ne i32 %r5003, 0
  br i1 %r5004, label %gcpoll.1003, label %gcpoll.done.1004

gcpoll.1003:                                      ; preds = %shadow.root.barrier.done.1002
  %statepoint_token865 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s45.relocated863, ptr addrspace(1) %rs4gc.s15.relocated864) ]
  %rs4gc.s45.relocated866 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token865, i32 0, i32 0) ; (%rs4gc.s45.relocated863, %rs4gc.s45.relocated863)
  %rs4gc.s15.relocated867 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token865, i32 1, i32 1) ; (%rs4gc.s15.relocated864, %rs4gc.s15.relocated864)
  br label %gcpoll.done.1004

gcpoll.done.1004:                                 ; preds = %gcpoll.1003, %shadow.root.barrier.done.1002
  %.51200 = phi ptr addrspace(1) [ %rs4gc.s45.relocated866, %gcpoll.1003 ], [ %rs4gc.s45.relocated863, %shadow.root.barrier.done.1002 ]
  %.57 = phi ptr addrspace(1) [ %rs4gc.s15.relocated867, %gcpoll.1003 ], [ %rs4gc.s15.relocated864, %shadow.root.barrier.done.1002 ]
  br label %for.update.963

shadow.root.barrier.1005:                         ; preds = %if.merge.819
  call void @js_write_barrier_root_nanbox(i64 %r5014) #7
  br label %shadow.root.barrier.done.1006

shadow.root.barrier.done.1006:                    ; preds = %shadow.root.barrier.1005, %if.merge.819
  %r5018.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s36 to i64
  %r5018.rs4o = call i64 asm "", "=r,0"(i64 %r5018.rs4i) #7
  %r5018 = bitcast i64 %r5018.rs4o to double
  %r5019 = bitcast double %r5018 to i64
  %r5020 = and i64 %r5019, 281474976710655
  %r5021 = and i64 %r5019, -281474976710656
  %r5022 = icmp eq i64 %r5021, 9222527611924643840
  %r5023 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r5024 = icmp eq i64 %r5023, 0
  %r5025 = icmp ugt i64 %r5020, 1048575
  %r5026 = icmp ult i64 %r5020, 140737488355328
  %r5027 = and i1 %r5025, %r5026
  %r5028 = and i1 %r5022, %r5024
  %r5029 = and i1 %r5028, %r5027
  br i1 %r5029, label %tav.get.brand.1011, label %tav.get.slow.1009

tav.get.fast.1007:                                ; preds = %tav.get.brand.1011
  %r5046 = bitcast double %r5018 to i64
  %r5047 = and i64 %r5046, 281474976710655
  %r5048 = add nuw nsw i64 %r5047, 8
  %r5049 = inttoptr i64 %r5048 to ptr
  %r5050 = load i8, ptr %r5049, align 1
  %r5051 = zext i8 %r5050 to i64
  %r5055 = inttoptr i64 %r5047 to ptr
  %r5056 = load i32, ptr %r5055, align 4
  %r5057 = zext i32 %r5056 to i64
  %r5058 = icmp ult i64 0, %r5057
  %r5059 = and i1 true, %r5058
  br i1 %r5059, label %tav.get.load.1008, label %tav.get.slow.1009

tav.get.load.1008:                                ; preds = %tav.get.fast.1007
  %r5060 = add nuw nsw i64 %r5047, 16
  %r5061 = icmp eq i64 %r5051, 0
  br i1 %r5061, label %tav.k.i8.1012, label %tav.kd1.1020

tav.get.slow.1009:                                ; preds = %tav.get.brand.1011, %tav.get.fast.1007, %shadow.root.barrier.done.1006
  %r5112 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__40, align 8
  %r5113 = icmp ne ptr %r5112, null
  %r5114 = select i1 %r5113, ptr %r5112, ptr @perry_ic_test_json_tape_batch_records_ts__40
  %r5115 = bitcast double %r5018 to i64
  %r5116 = and i64 %r5115, 281474976710655
  %r5117 = and i64 %r5115, -281474976710656
  %r5118 = icmp eq i64 %r5117, 9222527611924643840
  %r5119 = icmp uge i64 %r5116, 2199023255552
  %r5120 = icmp ult i64 %r5116, 140737488355328
  %r5123 = and i1 %r5118, %r5119
  %r5124 = and i1 %r5123, %r5120
  br i1 %r5124, label %arrlike.ic.header.1027, label %arrlike.ic.miss.1046

tav.get.merge.1010:                               ; preds = %arrlike.elem.value.1052, %arrlike.ic.miss.1046, %arrlike.ic.spill_load.1045, %arrlike.ic.inline.1042, %arrlike.ic.array_load.1030, %tav.k.f64.1019, %tav.k.f32.1018, %tav.k.u32.1017, %tav.k.i32.1016, %tav.k.u16.1015, %tav.k.i16.1014, %tav.k.u8.1013, %tav.k.i8.1012
  %.01201 = phi ptr addrspace(1) [ %rs4gc.s36, %tav.k.i8.1012 ], [ %rs4gc.s36, %tav.k.u8.1013 ], [ %rs4gc.s36, %tav.k.i16.1014 ], [ %rs4gc.s36, %tav.k.u16.1015 ], [ %rs4gc.s36, %tav.k.i32.1016 ], [ %rs4gc.s36, %tav.k.u32.1017 ], [ %rs4gc.s36, %tav.k.f32.1018 ], [ %rs4gc.s36, %tav.k.f64.1019 ], [ %rs4gc.s36, %arrlike.ic.array_load.1030 ], [ %rs4gc.s36.relocated, %arrlike.ic.miss.1046 ], [ %rs4gc.s36, %arrlike.elem.value.1052 ], [ %rs4gc.s36, %arrlike.ic.inline.1042 ], [ %rs4gc.s36, %arrlike.ic.spill_load.1045 ]
  %r5285 = phi double [ %r5074, %tav.k.i8.1012 ], [ %r5080, %tav.k.u8.1013 ], [ %r5086, %tav.k.i16.1014 ], [ %r5092, %tav.k.u16.1015 ], [ %r5097, %tav.k.i32.1016 ], [ %r5102, %tav.k.u32.1017 ], [ %r5107, %tav.k.f32.1018 ], [ %r5111, %tav.k.f64.1019 ], [ %r5168, %arrlike.elem.value.1052 ], [ %r5196, %arrlike.ic.array_load.1030 ], [ %r5266, %arrlike.ic.inline.1042 ], [ %r5283, %arrlike.ic.spill_load.1045 ], [ %r5284869, %arrlike.ic.miss.1046 ]
  %rs4gc.b50 = bitcast double %r5285 to i64
  %rs4gc.s50 = inttoptr i64 %rs4gc.b50 to ptr addrspace(1)
  %r5286 = bitcast double %r5285 to i64
  %r5287 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5288 = icmp ne i32 %r5287, 0
  br i1 %r5288, label %shadow.root.barrier.1054, label %shadow.root.barrier.done.1055

tav.get.brand.1011:                               ; preds = %shadow.root.barrier.done.1006
  %r5030 = bitcast double %r5018 to i64
  %r5031 = and i64 %r5030, 281474976710655
  %r5032 = sub nsw i64 %r5031, 8
  %r5033 = inttoptr i64 %r5032 to ptr
  %r5034 = load i8, ptr %r5033, align 1
  %r5035 = icmp eq i8 %r5034, 11
  %r5036 = add nuw nsw i64 %r5031, 8
  %r5037 = inttoptr i64 %r5036 to ptr
  %r5038 = load i8, ptr %r5037, align 1
  %r5039 = zext i8 %r5038 to i64
  %r5040 = icmp ule i64 %r5039, 8
  %r5043 = and i1 %r5035, %r5040
  br i1 %r5043, label %tav.get.fast.1007, label %tav.get.slow.1009

tav.k.i8.1012:                                    ; preds = %tav.get.load.1008
  %r5070 = add nuw nsw i64 %r5060, 0
  %r5071 = inttoptr i64 %r5070 to ptr
  %r5072 = load i8, ptr %r5071, align 1
  %r5073 = sext i8 %r5072 to i32
  %r5074 = sitofp i32 %r5073 to double
  br label %tav.get.merge.1010

tav.k.u8.1013:                                    ; preds = %tav.kd7.1026, %tav.kd1.1020
  %r5076 = add nuw nsw i64 %r5060, 0
  %r5077 = inttoptr i64 %r5076 to ptr
  %r5078 = load i8, ptr %r5077, align 1
  %r5079 = zext i8 %r5078 to i32
  %r5080 = uitofp nneg i32 %r5079 to double
  br label %tav.get.merge.1010

tav.k.i16.1014:                                   ; preds = %tav.kd2.1021
  %r5082 = add nuw nsw i64 %r5060, 0
  %r5083 = inttoptr i64 %r5082 to ptr
  %r5084 = load i16, ptr %r5083, align 2
  %r5085 = sext i16 %r5084 to i32
  %r5086 = sitofp i32 %r5085 to double
  br label %tav.get.merge.1010

tav.k.u16.1015:                                   ; preds = %tav.kd3.1022
  %r5088 = add nuw nsw i64 %r5060, 0
  %r5089 = inttoptr i64 %r5088 to ptr
  %r5090 = load i16, ptr %r5089, align 2
  %r5091 = zext i16 %r5090 to i32
  %r5092 = uitofp nneg i32 %r5091 to double
  br label %tav.get.merge.1010

tav.k.i32.1016:                                   ; preds = %tav.kd4.1023
  %r5094 = add nuw nsw i64 %r5060, 0
  %r5095 = inttoptr i64 %r5094 to ptr
  %r5096 = load i32, ptr %r5095, align 4
  %r5097 = sitofp i32 %r5096 to double
  br label %tav.get.merge.1010

tav.k.u32.1017:                                   ; preds = %tav.kd5.1024
  %r5099 = add nuw nsw i64 %r5060, 0
  %r5100 = inttoptr i64 %r5099 to ptr
  %r5101 = load i32, ptr %r5100, align 4
  %r5102 = uitofp i32 %r5101 to double
  br label %tav.get.merge.1010

tav.k.f32.1018:                                   ; preds = %tav.kd6.1025
  %r5104 = add nuw nsw i64 %r5060, 0
  %r5105 = inttoptr i64 %r5104 to ptr
  %r5106 = load float, ptr %r5105, align 4
  %r5107 = fpext float %r5106 to double
  br label %tav.get.merge.1010

tav.k.f64.1019:                                   ; preds = %tav.kd7.1026
  %r5109 = add nuw nsw i64 %r5060, 0
  %r5110 = inttoptr i64 %r5109 to ptr
  %r5111 = load double, ptr %r5110, align 8
  br label %tav.get.merge.1010

tav.kd1.1020:                                     ; preds = %tav.get.load.1008
  %r5062 = icmp eq i64 %r5051, 1
  br i1 %r5062, label %tav.k.u8.1013, label %tav.kd2.1021

tav.kd2.1021:                                     ; preds = %tav.kd1.1020
  %r5063 = icmp eq i64 %r5051, 2
  br i1 %r5063, label %tav.k.i16.1014, label %tav.kd3.1022

tav.kd3.1022:                                     ; preds = %tav.kd2.1021
  %r5064 = icmp eq i64 %r5051, 3
  br i1 %r5064, label %tav.k.u16.1015, label %tav.kd4.1023

tav.kd4.1023:                                     ; preds = %tav.kd3.1022
  %r5065 = icmp eq i64 %r5051, 4
  br i1 %r5065, label %tav.k.i32.1016, label %tav.kd5.1024

tav.kd5.1024:                                     ; preds = %tav.kd4.1023
  %r5066 = icmp eq i64 %r5051, 5
  br i1 %r5066, label %tav.k.u32.1017, label %tav.kd6.1025

tav.kd6.1025:                                     ; preds = %tav.kd5.1024
  %r5067 = icmp eq i64 %r5051, 6
  br i1 %r5067, label %tav.k.f32.1018, label %tav.kd7.1026

tav.kd7.1026:                                     ; preds = %tav.kd6.1025
  %r5068 = icmp eq i64 %r5051, 7
  br i1 %r5068, label %tav.k.f64.1019, label %tav.k.u8.1013

arrlike.ic.header.1027:                           ; preds = %tav.get.slow.1009
  %r5130 = sub nuw nsw i64 %r5116, 8
  %r5131 = inttoptr i64 %r5130 to ptr
  %r5132 = load i8, ptr %r5131, align 1
  %r5134 = sub nuw nsw i64 %r5116, 7
  %r5135 = inttoptr i64 %r5134 to ptr
  %r5136 = load i8, ptr %r5135, align 1
  %r5137 = and i8 %r5136, -128
  %r5138 = icmp eq i8 %r5137, 0
  %r5139 = and i1 true, %r5138
  br i1 %r5139, label %arrlike.ic.brand.1028, label %arrlike.ic.miss.1046

arrlike.ic.brand.1028:                            ; preds = %arrlike.ic.header.1027
  %r5133 = icmp eq i8 %r5132, 1
  br i1 %r5133, label %arrlike.ic.array_guard.1029, label %arrlike.elem.kind.1047

arrlike.ic.array_guard.1029:                      ; preds = %arrlike.ic.brand.1028
  %r5171 = sub nuw nsw i64 %r5116, 6
  %r5172 = inttoptr i64 %r5171 to ptr
  %r5173 = load i16, ptr %r5172, align 2
  %r5174 = and i16 %r5173, 1024
  %r5175 = icmp eq i16 %r5174, 0
  %r5176 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r5177 = icmp eq i8 %r5176, 0
  %r5178 = inttoptr i64 %r5116 to ptr
  %r5179 = load i32, ptr %r5178, align 4
  %r5180 = add nuw nsw i64 %r5116, 4
  %r5181 = inttoptr i64 %r5180 to ptr
  %r5182 = load i32, ptr %r5181, align 4
  %r5183 = zext i32 %r5179 to i64
  %r5184 = zext i32 %r5182 to i64
  %r5185 = icmp ult i64 0, %r5183
  %r5186 = icmp ule i64 %r5183, %r5184
  %r5187 = and i1 %r5175, %r5177
  %r5188 = and i1 %r5187, %r5185
  %r5189 = and i1 %r5188, %r5186
  br i1 %r5189, label %arrlike.ic.array_load.1030, label %arrlike.ic.miss.1046

arrlike.ic.array_load.1030:                       ; preds = %arrlike.ic.array_guard.1029
  %r5191 = getelementptr inbounds nuw i64, ptr %r5178, i64 1
  %r5192 = load double, ptr %r5191, align 8
  %r5193 = bitcast double %r5192 to i64
  %r5194 = icmp eq i64 %r5193, 9222246136947933200
  %r5196 = select i1 %r5194, double 0x7FFC000000000001, double %r5192
  br label %tav.get.merge.1010

arrlike.ic.shape.1031:                            ; preds = %arrlike.elem.store.1049, %arrlike.elem.meta.1048
  %r5198 = inttoptr i64 %r5116 to ptr
  %r5199 = load i32, ptr %r5198, align 4
  %r5200 = add nuw nsw i64 %r5116, 4
  %r5201 = inttoptr i64 %r5200 to ptr
  %r5202 = load i32, ptr %r5201, align 4
  %r5203 = zext i32 %r5199 to i64
  %r5204 = zext i32 %r5202 to i64
  %r5205 = shl nuw i64 %r5203, 32
  %r5206 = or i64 %r5205, %r5204
  %r5207 = getelementptr i64, ptr %r5114, i64 0
  %r5208 = load i64, ptr %r5207, align 8
  %r5209 = icmp ne i64 %r5208, 0
  %r5210 = and i1 true, %r5209
  br i1 %r5210, label %arrlike.ic.identity.1032, label %arrlike.ic.miss.1046

arrlike.ic.identity.1032:                         ; preds = %arrlike.ic.shape.1031
  %r5211 = and i64 %r5208, -9223372036854775808
  %8 = icmp slt i64 %r5208, 0
  br i1 %8, label %arrlike.ic.family_meta.1034, label %arrlike.ic.exact.1033

arrlike.ic.exact.1033:                            ; preds = %arrlike.ic.identity.1032
  %r5213 = icmp eq i64 %r5206, %r5208
  br i1 %r5213, label %arrlike.ic.bounds.1036, label %arrlike.ic.miss.1046

arrlike.ic.family_meta.1034:                      ; preds = %arrlike.ic.identity.1032
  %r5214 = add nuw nsw i64 %r5116, 8
  %r5215 = inttoptr i64 %r5214 to ptr
  %r5216 = load i64, ptr %r5215, align 8
  %r5217 = icmp ne i64 %r5216, 0
  br i1 %r5217, label %arrlike.ic.family_token.1035, label %arrlike.ic.miss.1046

arrlike.ic.family_token.1035:                     ; preds = %arrlike.ic.family_meta.1034
  %r5218 = inttoptr i64 %r5216 to ptr
  %r5219 = getelementptr i64, ptr %r5218, i64 6
  %r5220 = load i64, ptr %r5219, align 8
  %r5221 = icmp eq i64 %r5220, %r5208
  br i1 %r5221, label %arrlike.ic.bounds.1036, label %arrlike.ic.miss.1046

arrlike.ic.bounds.1036:                           ; preds = %arrlike.ic.family_token.1035, %arrlike.ic.exact.1033
  %r5222 = getelementptr i64, ptr %r5112, i64 1
  %r5223 = load i64, ptr %r5222, align 8
  %r5224 = getelementptr i64, ptr %r5112, i64 2
  %r5225 = load i64, ptr %r5224, align 8
  %r5226 = getelementptr i64, ptr %r5112, i64 3
  %r5227 = load i64, ptr %r5226, align 8
  %r5228 = getelementptr i64, ptr %r5112, i64 4
  %r5229 = load i64, ptr %r5228, align 8
  %r5230 = icmp ult i64 %r5223, %r5229
  br i1 %r5230, label %arrlike.ic.length_inline.1037, label %arrlike.ic.length_spill_meta.1038

arrlike.ic.length_inline.1037:                    ; preds = %arrlike.ic.bounds.1036
  %r5231 = shl i64 %r5223, 3
  %r5232 = add i64 %r5231, 16
  %r5233 = add i64 %r5116, %r5232
  %r5234 = inttoptr i64 %r5233 to ptr
  %r5235 = load double, ptr %r5234, align 8
  br label %arrlike.ic.range.1041

arrlike.ic.length_spill_meta.1038:                ; preds = %arrlike.ic.bounds.1036
  %r5236 = add nuw nsw i64 %r5116, 8
  %r5237 = inttoptr i64 %r5236 to ptr
  %r5238 = load i64, ptr %r5237, align 8
  %r5239 = icmp ne i64 %r5238, 0
  br i1 %r5239, label %arrlike.ic.length_spill_ptr.1039, label %arrlike.ic.miss.1046

arrlike.ic.length_spill_ptr.1039:                 ; preds = %arrlike.ic.length_spill_meta.1038
  %r5240 = inttoptr i64 %r5238 to ptr
  %r5241 = getelementptr i64, ptr %r5240, i64 4
  %r5242 = load i64, ptr %r5241, align 8
  %r5243 = icmp ne i64 %r5242, 0
  %r5244 = select i1 %r5243, i64 %r5242, i64 %r5238
  %r5245 = inttoptr i64 %r5244 to ptr
  %r5246 = load i32, ptr %r5245, align 4
  %r5247 = zext i32 %r5246 to i64
  %r5248 = icmp ult i64 %r5223, %r5247
  %r5249 = and i1 %r5243, %r5248
  br i1 %r5249, label %arrlike.ic.length_spill_load.1040, label %arrlike.ic.miss.1046

arrlike.ic.length_spill_load.1040:                ; preds = %arrlike.ic.length_spill_ptr.1039
  %r5250 = add nuw nsw i64 %r5223, 1
  %r5251 = getelementptr inbounds nuw i64, ptr %r5245, i64 %r5250
  %r5252 = load double, ptr %r5251, align 8
  br label %arrlike.ic.range.1041

arrlike.ic.range.1041:                            ; preds = %arrlike.ic.length_spill_load.1040, %arrlike.ic.length_inline.1037
  %r5253 = phi double [ %r5235, %arrlike.ic.length_inline.1037 ], [ %r5252, %arrlike.ic.length_spill_load.1040 ]
  %r5254 = fcmp olt double 0.000000e+00, %r5253
  %r5255 = icmp ult i64 0, %r5227
  %r5256 = and i1 %r5254, %r5255
  %r5257 = add nuw nsw i64 %r5225, 0
  %r5258 = icmp ult i64 %r5257, %r5229
  %r5259 = and i1 %r5256, %r5258
  %r5260 = xor i1 %r5258, true
  %r5261 = and i1 %r5256, %r5260
  br i1 %r5259, label %arrlike.ic.inline.1042, label %arrlike.ic.spill_or_miss.1053

arrlike.ic.inline.1042:                           ; preds = %arrlike.ic.range.1041
  %r5262 = shl i64 %r5257, 3
  %r5263 = add i64 %r5262, 16
  %r5264 = add i64 %r5116, %r5263
  %r5265 = inttoptr i64 %r5264 to ptr
  %r5266 = load double, ptr %r5265, align 8
  br label %tav.get.merge.1010

arrlike.ic.spill.1043:                            ; preds = %arrlike.ic.spill_or_miss.1053
  %r5267 = add nuw nsw i64 %r5116, 8
  %r5268 = inttoptr i64 %r5267 to ptr
  %r5269 = load i64, ptr %r5268, align 8
  %r5270 = icmp ne i64 %r5269, 0
  br i1 %r5270, label %arrlike.ic.spill_ptr.1044, label %arrlike.ic.miss.1046

arrlike.ic.spill_ptr.1044:                        ; preds = %arrlike.ic.spill.1043
  %r5271 = inttoptr i64 %r5269 to ptr
  %r5272 = getelementptr i64, ptr %r5271, i64 4
  %r5273 = load i64, ptr %r5272, align 8
  %r5274 = icmp ne i64 %r5273, 0
  %r5275 = select i1 %r5274, i64 %r5273, i64 %r5269
  %r5276 = inttoptr i64 %r5275 to ptr
  %r5277 = load i32, ptr %r5276, align 4
  %r5278 = zext i32 %r5277 to i64
  %r5279 = icmp ult i64 %r5257, %r5278
  %r5280 = and i1 %r5274, %r5279
  br i1 %r5280, label %arrlike.ic.spill_load.1045, label %arrlike.ic.miss.1046

arrlike.ic.spill_load.1045:                       ; preds = %arrlike.ic.spill_ptr.1044
  %r5281 = add nuw nsw i64 %r5257, 1
  %r5282 = getelementptr inbounds nuw i64, ptr %r5276, i64 %r5281
  %r5283 = load double, ptr %r5282, align 8
  br label %tav.get.merge.1010

arrlike.ic.miss.1046:                             ; preds = %arrlike.ic.spill_or_miss.1053, %arrlike.elem.load.1051, %arrlike.elem.bounds.1050, %arrlike.elem.kind.1047, %arrlike.ic.spill_ptr.1044, %arrlike.ic.spill.1043, %arrlike.ic.length_spill_ptr.1039, %arrlike.ic.length_spill_meta.1038, %arrlike.ic.family_token.1035, %arrlike.ic.family_meta.1034, %arrlike.ic.exact.1033, %arrlike.ic.shape.1031, %arrlike.ic.array_guard.1029, %arrlike.ic.header.1027, %tav.get.slow.1009
  %statepoint_token868 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, ptr)) @js_packed_arraylike_index_get, i32 3, i32 0, double %r5018, double 0.000000e+00, ptr @perry_ic_test_json_tape_batch_records_ts__40, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s36) ]
  %r5284869 = call double @llvm.experimental.gc.result.f64(token %statepoint_token868)
  %rs4gc.s36.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token868, i32 0, i32 0) ; (%rs4gc.s36, %rs4gc.s36)
  br label %tav.get.merge.1010

arrlike.elem.kind.1047:                           ; preds = %arrlike.ic.brand.1028
  %r5140 = icmp eq i8 %r5132, 2
  br i1 %r5140, label %arrlike.elem.meta.1048, label %arrlike.ic.miss.1046

arrlike.elem.meta.1048:                           ; preds = %arrlike.elem.kind.1047
  %r5141 = add nuw nsw i64 %r5116, 8
  %r5142 = inttoptr i64 %r5141 to ptr
  %r5143 = load i64, ptr %r5142, align 8
  %r5144 = icmp ne i64 %r5143, 0
  br i1 %r5144, label %arrlike.elem.store.1049, label %arrlike.ic.shape.1031

arrlike.elem.store.1049:                          ; preds = %arrlike.elem.meta.1048
  %r5145 = inttoptr i64 %r5143 to ptr
  %r5146 = getelementptr i64, ptr %r5145, i64 12
  %r5147 = load i64, ptr %r5146, align 8
  %r5148 = icmp ne i64 %r5147, 0
  br i1 %r5148, label %arrlike.elem.bounds.1050, label %arrlike.ic.shape.1031

arrlike.elem.bounds.1050:                         ; preds = %arrlike.elem.store.1049
  %r5149 = sub i64 %r5147, 8
  %r5150 = inttoptr i64 %r5149 to ptr
  %r5151 = load i8, ptr %r5150, align 1
  %r5152 = icmp eq i8 %r5151, 1
  %r5153 = sub i64 %r5147, 7
  %r5154 = inttoptr i64 %r5153 to ptr
  %r5155 = load i8, ptr %r5154, align 1
  %r5156 = and i8 %r5155, -128
  %r5157 = icmp eq i8 %r5156, 0
  %r5158 = inttoptr i64 %r5147 to ptr
  %r5159 = load i32, ptr %r5158, align 4
  %r5160 = zext i32 %r5159 to i64
  %r5161 = icmp ult i64 0, %r5160
  %r5162 = and i1 %r5152, %r5157
  %r5163 = and i1 %r5162, %r5161
  br i1 %r5163, label %arrlike.elem.load.1051, label %arrlike.ic.miss.1046

arrlike.elem.load.1051:                           ; preds = %arrlike.elem.bounds.1050
  %r5165 = add i64 %r5147, 8
  %r5166 = add nuw nsw i64 %r5165, 0
  %r5167 = inttoptr i64 %r5166 to ptr
  %r5168 = load double, ptr %r5167, align 8
  %r5169 = bitcast double %r5168 to i64
  %r5170 = icmp eq i64 %r5169, 9222246136947933200
  br i1 %r5170, label %arrlike.ic.miss.1046, label %arrlike.elem.value.1052

arrlike.elem.value.1052:                          ; preds = %arrlike.elem.load.1051
  br label %tav.get.merge.1010

arrlike.ic.spill_or_miss.1053:                    ; preds = %arrlike.ic.range.1041
  br i1 %r5261, label %arrlike.ic.spill.1043, label %arrlike.ic.miss.1046

shadow.root.barrier.1054:                         ; preds = %tav.get.merge.1010
  call void @js_write_barrier_root_nanbox(i64 %r5286) #7
  br label %shadow.root.barrier.done.1055

shadow.root.barrier.done.1055:                    ; preds = %shadow.root.barrier.1054, %tav.get.merge.1010
  %r5289.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s50 to i64
  %r5289.rs4o = call i64 asm "", "=r,0"(i64 %r5289.rs4i) #7
  %r5289 = bitcast i64 %r5289.rs4o to double
  %r5290 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r5291 = load double, ptr @test_json_tape_batch_records_ts_.str.27.handle, align 8
  %r5292 = bitcast double %r5289 to i64
  %r5293 = bitcast double %r5290 to i64
  %r5294 = and i64 %r5293, 281474976710655
  %r5295 = and i64 %r5292, 281474976710655
  %r5296 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__41, align 8
  %r5297 = icmp ne ptr %r5296, null
  %r5298 = lshr i64 %r5292, 48
  %r5299 = icmp eq i64 %r5298, 32765
  %r5300 = icmp ugt i64 %r5295, 1048575
  %r5301 = and i1 %r5299, %r5300
  %r5302 = and i1 %r5301, %r5297
  br i1 %r5302, label %put.pic.guard.1056, label %put.pic.miss.1068

put.pic.guard.1056:                               ; preds = %shadow.root.barrier.done.1055
  %r5303 = sub nuw nsw i64 %r5295, 8
  %r5304 = inttoptr i64 %r5303 to ptr
  %r5305 = load i8, ptr %r5304, align 1
  %r5306 = icmp eq i8 %r5305, 2
  %r5307 = sub nuw nsw i64 %r5295, 7
  %r5308 = inttoptr i64 %r5307 to ptr
  %r5309 = load i8, ptr %r5308, align 1
  %r5310 = and i8 %r5309, -128
  %r5311 = icmp eq i8 %r5310, 0
  %r5312 = sub nuw nsw i64 %r5295, 6
  %r5313 = inttoptr i64 %r5312 to ptr
  %r5314 = load i16, ptr %r5313, align 2
  %r5315 = and i16 %r5314, 6535
  %r5316 = icmp eq i16 %r5315, 0
  %r5317 = add nuw nsw i64 %r5295, 0
  %r5318 = inttoptr i64 %r5317 to ptr
  %r5319 = load i32, ptr %r5318, align 4
  %r5320 = icmp ne i32 %r5319, 0
  %r5321 = icmp ne i32 %r5319, -2
  %r5322 = and i16 %r5314, 512
  %r5323 = icmp ne i16 %r5322, 0
  %r5324 = or i1 %r5320, %r5323
  %r5325 = add nuw nsw i64 %r5295, 4
  %r5326 = inttoptr i64 %r5325 to ptr
  %r5327 = load i32, ptr %r5326, align 4
  %r5328 = add i32 %r5327, -2147483648
  %r5329 = icmp ult i32 %r5328, 1073741824
  %r5330 = zext i32 %r5327 to i64
  %r5331 = or i64 %r5330, 4611686018427387904
  %r5332 = select i1 %r5329, i64 %r5331, i64 0
  %r5333 = getelementptr i64, ptr %r5296, i64 0
  %r5334 = load i64, ptr %r5333, align 8
  %r5335 = icmp eq i64 %r5332, %r5334
  %r5336 = icmp ne i64 %r5332, 0
  %r5337 = getelementptr i64, ptr %r5296, i64 1
  %r5338 = load i64, ptr %r5337, align 8
  %r5339 = and i1 true, %r5306
  %r5340 = and i1 %r5339, %r5311
  %r5341 = and i1 %r5340, %r5316
  %r5342 = and i1 %r5341, %r5324
  %r5343 = and i1 %r5342, %r5321
  %r5344 = and i1 %r5343, %r5335
  %r5345 = and i1 %r5344, %r5336
  br i1 %r5345, label %put.pic.hit.1064, label %put.pic.fallback.1060

put.pic.guard2.1057:                              ; preds = %put.pic.fallback.1060
  %r5347 = getelementptr i64, ptr %r5296, i64 2
  %r5348 = load i64, ptr %r5347, align 8
  %r5349 = getelementptr i64, ptr %r5296, i64 3
  %r5350 = load i64, ptr %r5349, align 8
  %r5351 = icmp eq i64 %r5332, %r5348
  %r5352 = and i1 true, %r5306
  %r5353 = and i1 %r5352, %r5311
  %r5354 = and i1 %r5353, %r5316
  %r5355 = and i1 %r5354, %r5324
  %r5356 = and i1 %r5355, %r5321
  %r5357 = and i1 %r5356, %r5351
  %r5358 = and i1 %r5357, %r5336
  br i1 %r5358, label %put.pic.hit.1064, label %put.pic.dispatch3.1061

put.pic.guard3.1058:                              ; preds = %put.pic.dispatch3.1061
  %r5360 = getelementptr i64, ptr %r5296, i64 4
  %r5361 = load i64, ptr %r5360, align 8
  %r5362 = getelementptr i64, ptr %r5296, i64 5
  %r5363 = load i64, ptr %r5362, align 8
  %r5364 = icmp eq i64 %r5332, %r5361
  %r5365 = and i1 true, %r5306
  %r5366 = and i1 %r5365, %r5311
  %r5367 = and i1 %r5366, %r5316
  %r5368 = and i1 %r5367, %r5324
  %r5369 = and i1 %r5368, %r5321
  %r5370 = and i1 %r5369, %r5364
  %r5371 = and i1 %r5370, %r5336
  br i1 %r5371, label %put.pic.hit.1064, label %put.pic.dispatch4.1062

put.pic.guard4.1059:                              ; preds = %put.pic.dispatch4.1062
  %r5373 = getelementptr i64, ptr %r5296, i64 6
  %r5374 = load i64, ptr %r5373, align 8
  %r5375 = getelementptr i64, ptr %r5296, i64 7
  %r5376 = load i64, ptr %r5375, align 8
  %r5377 = icmp eq i64 %r5332, %r5374
  %r5378 = and i1 true, %r5306
  %r5379 = and i1 %r5378, %r5311
  %r5380 = and i1 %r5379, %r5316
  %r5381 = and i1 %r5380, %r5324
  %r5382 = and i1 %r5381, %r5321
  %r5383 = and i1 %r5382, %r5377
  %r5384 = and i1 %r5383, %r5336
  br i1 %r5384, label %put.pic.hit.1064, label %put.pic.dispatch5.1063

put.pic.fallback.1060:                            ; preds = %put.pic.guard.1056
  %r5346 = icmp eq i64 %r5334, 0
  br i1 %r5346, label %put.pic.miss.1068, label %put.pic.guard2.1057

put.pic.dispatch3.1061:                           ; preds = %put.pic.guard2.1057
  %r5359 = icmp eq i64 %r5348, 0
  br i1 %r5359, label %put.pic.miss2.1069, label %put.pic.guard3.1058

put.pic.dispatch4.1062:                           ; preds = %put.pic.guard3.1058
  %r5372 = icmp eq i64 %r5361, 0
  br i1 %r5372, label %put.pic.miss3.1070, label %put.pic.guard4.1059

put.pic.dispatch5.1063:                           ; preds = %put.pic.guard4.1059
  %r5385 = icmp eq i64 %r5374, 0
  br i1 %r5385, label %put.pic.miss4.1071, label %put.pic.tail.1072

put.pic.hit.1064:                                 ; preds = %put.pic.guard4.1059, %put.pic.guard3.1058, %put.pic.guard2.1057, %put.pic.guard.1056
  %r5386 = phi i64 [ %r5338, %put.pic.guard.1056 ], [ %r5350, %put.pic.guard2.1057 ], [ %r5363, %put.pic.guard3.1058 ], [ %r5376, %put.pic.guard4.1059 ]
  %r5387 = and i64 %r5386, 1073741824
  %r5388 = icmp ne i64 %r5387, 0
  br i1 %r5388, label %put.pic.hit.overflow.1074, label %put.pic.hit.inline.1075

put.pic.hit.validate.1065:                        ; preds = %put.pic.hit.inline.1075
  %r5398 = load double, ptr %r5395, align 8
  %r5399 = bitcast double %r5398 to i64
  %r5400 = icmp eq i64 %r5399, 9222246136947933200
  br i1 %r5400, label %put.pic.deleted.1067, label %put.pic.hit.store.1066

put.pic.hit.store.1066:                           ; preds = %put.pic.hit.inline.1075, %put.pic.hit.validate.1065
  %r5401 = trunc i64 %r5386 to i32
  store double %r5291, ptr %r5395, align 8
  %r5402 = bitcast double %r5291 to i64
  %r5403 = lshr i64 %r5402, 48
  %r5404 = icmp eq i64 %r5403, 0
  %r5405 = icmp uge i64 %r5402, 4096
  %r5406 = and i1 %r5404, %r5405
  %r5407 = icmp eq i64 %r5403, 32765
  %r5408 = icmp eq i64 %r5403, 32767
  %r5409 = icmp eq i64 %r5403, 32762
  %r5410 = or i1 %r5407, %r5408
  %r5411 = or i1 %r5410, %r5409
  %r5412 = or i1 %r5411, %r5406
  br i1 %r5412, label %put.pic.gc_bookkeeping.1076, label %put.pic.gc_bookkeeping.done.1077

put.pic.deleted.1067:                             ; preds = %put.pic.hit.validate.1065
  %statepoint_token870 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r5289, i64 %r5294, double %r5291, i32 1, ptr @perry_ic_test_json_tape_batch_records_ts__41, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50, ptr addrspace(1) %.01201) ]
  %r5421871 = call double @llvm.experimental.gc.result.f64(token %statepoint_token870)
  %rs4gc.s50.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token870, i32 0, i32 0) ; (%rs4gc.s50, %rs4gc.s50)
  %rs4gc.s36.relocated872 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token870, i32 1, i32 1) ; (%.01201, %.01201)
  br label %put.pic.merge.1073

put.pic.miss.1068:                                ; preds = %put.pic.hit.overflow.1074, %put.pic.fallback.1060, %shadow.root.barrier.done.1055
  %.01204 = phi ptr addrspace(1) [ %rs4gc.s50.relocated899, %put.pic.hit.overflow.1074 ], [ %rs4gc.s50, %put.pic.fallback.1060 ], [ %rs4gc.s50, %shadow.root.barrier.done.1055 ]
  %.11202 = phi ptr addrspace(1) [ %rs4gc.s36.relocated900, %put.pic.hit.overflow.1074 ], [ %.01201, %put.pic.fallback.1060 ], [ %.01201, %shadow.root.barrier.done.1055 ]
  %r5960.rs4i = ptrtoint ptr addrspace(1) %.01204 to i64
  %r5960.rs4o = call i64 asm "", "=r,0"(i64 %r5960.rs4i) #7
  %r5960 = bitcast i64 %r5960.rs4o to double
  %r5961 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r5962 = bitcast double %r5961 to i64
  %r5963 = and i64 %r5962, 281474976710655
  %r5964 = load double, ptr @test_json_tape_batch_records_ts_.str.27.handle, align 8
  %statepoint_token873 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r5960, i64 %r5963, double %r5964, i32 1, ptr @perry_ic_test_json_tape_batch_records_ts__41, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01204, ptr addrspace(1) %.11202) ]
  %r5422874 = call double @llvm.experimental.gc.result.f64(token %statepoint_token873)
  %rs4gc.s50.relocated875 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token873, i32 0, i32 0) ; (%.01204, %.01204)
  %rs4gc.s36.relocated876 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token873, i32 1, i32 1) ; (%.11202, %.11202)
  br label %put.pic.merge.1073

put.pic.miss2.1069:                               ; preds = %put.pic.dispatch3.1061
  %statepoint_token877 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r5289, i64 %r5294, double %r5291, i32 1, ptr @perry_ic_test_json_tape_batch_records_ts__41, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50, ptr addrspace(1) %.01201) ]
  %r5423878 = call double @llvm.experimental.gc.result.f64(token %statepoint_token877)
  %rs4gc.s50.relocated879 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token877, i32 0, i32 0) ; (%rs4gc.s50, %rs4gc.s50)
  %rs4gc.s36.relocated880 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token877, i32 1, i32 1) ; (%.01201, %.01201)
  br label %put.pic.merge.1073

put.pic.miss3.1070:                               ; preds = %put.pic.dispatch4.1062
  %statepoint_token881 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r5289, i64 %r5294, double %r5291, i32 1, ptr @perry_ic_test_json_tape_batch_records_ts__41, i32 2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50, ptr addrspace(1) %.01201) ]
  %r5424882 = call double @llvm.experimental.gc.result.f64(token %statepoint_token881)
  %rs4gc.s50.relocated883 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token881, i32 0, i32 0) ; (%rs4gc.s50, %rs4gc.s50)
  %rs4gc.s36.relocated884 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token881, i32 1, i32 1) ; (%.01201, %.01201)
  br label %put.pic.merge.1073

put.pic.miss4.1071:                               ; preds = %put.pic.dispatch5.1063
  %statepoint_token885 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r5289, i64 %r5294, double %r5291, i32 1, ptr @perry_ic_test_json_tape_batch_records_ts__41, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50, ptr addrspace(1) %.01201) ]
  %r5425886 = call double @llvm.experimental.gc.result.f64(token %statepoint_token885)
  %rs4gc.s50.relocated887 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token885, i32 0, i32 0) ; (%rs4gc.s50, %rs4gc.s50)
  %rs4gc.s36.relocated888 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token885, i32 1, i32 1) ; (%.01201, %.01201)
  br label %put.pic.merge.1073

put.pic.tail.1072:                                ; preds = %put.pic.dispatch5.1063
  %statepoint_token889 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, i64, double, i32)) @js_put_value_set_ic_poly_tail, i32 5, i32 0, ptr @perry_ic_test_json_tape_batch_records_ts__41_poly_tail, double %r5289, i64 %r5294, double %r5291, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50, ptr addrspace(1) %.01201) ]
  %r5426890 = call double @llvm.experimental.gc.result.f64(token %statepoint_token889)
  %rs4gc.s50.relocated891 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token889, i32 0, i32 0) ; (%rs4gc.s50, %rs4gc.s50)
  %rs4gc.s36.relocated892 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token889, i32 1, i32 1) ; (%.01201, %.01201)
  br label %put.pic.merge.1073

put.pic.merge.1073:                               ; preds = %put.pic.gc_bookkeeping.done.1077, %put.pic.hit.overflow.1074, %put.pic.tail.1072, %put.pic.miss4.1071, %put.pic.miss3.1070, %put.pic.miss2.1069, %put.pic.miss.1068, %put.pic.deleted.1067
  %.11205 = phi ptr addrspace(1) [ %rs4gc.s50.relocated899, %put.pic.hit.overflow.1074 ], [ %rs4gc.s50.relocated875, %put.pic.miss.1068 ], [ %rs4gc.s50.relocated, %put.pic.deleted.1067 ], [ %rs4gc.s50, %put.pic.gc_bookkeeping.done.1077 ], [ %rs4gc.s50.relocated879, %put.pic.miss2.1069 ], [ %rs4gc.s50.relocated883, %put.pic.miss3.1070 ], [ %rs4gc.s50.relocated887, %put.pic.miss4.1071 ], [ %rs4gc.s50.relocated891, %put.pic.tail.1072 ]
  %.21203 = phi ptr addrspace(1) [ %rs4gc.s36.relocated900, %put.pic.hit.overflow.1074 ], [ %rs4gc.s36.relocated876, %put.pic.miss.1068 ], [ %rs4gc.s36.relocated872, %put.pic.deleted.1067 ], [ %.01201, %put.pic.gc_bookkeeping.done.1077 ], [ %rs4gc.s36.relocated880, %put.pic.miss2.1069 ], [ %rs4gc.s36.relocated884, %put.pic.miss3.1070 ], [ %rs4gc.s36.relocated888, %put.pic.miss4.1071 ], [ %rs4gc.s36.relocated892, %put.pic.tail.1072 ]
  %r5427 = phi double [ %r5291, %put.pic.gc_bookkeeping.done.1077 ], [ %r5291, %put.pic.hit.overflow.1074 ], [ %r5421871, %put.pic.deleted.1067 ], [ %r5422874, %put.pic.miss.1068 ], [ %r5423878, %put.pic.miss2.1069 ], [ %r5424882, %put.pic.miss3.1070 ], [ %r5425886, %put.pic.miss4.1071 ], [ %r5426890, %put.pic.tail.1072 ]
  %r5428.rs4i = ptrtoint ptr addrspace(1) %.21203 to i64
  %r5428.rs4o = call i64 asm "", "=r,0"(i64 %r5428.rs4i) #7
  %r5428 = bitcast i64 %r5428.rs4o to double
  %statepoint_token893 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r5428, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11205, ptr addrspace(1) %.21203) ]
  %r5429894 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token893)
  %rs4gc.s50.relocated895 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token893, i32 0, i32 0) ; (%.11205, %.11205)
  %rs4gc.s36.relocated896 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token893, i32 1, i32 1) ; (%.21203, %.21203)
  %r5430 = bitcast i64 %r5429894 to double
  %rs4gc.s51 = inttoptr i64 %r5429894 to ptr addrspace(1)
  %r5431.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s51 to i64
  %r5431 = call i64 asm "", "=r,0"(i64 %r5431.rs4i) #7
  %r5432 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5433 = icmp ne i32 %r5432, 0
  br i1 %r5433, label %shadow.root.barrier.1079, label %shadow.root.barrier.done.1080

put.pic.hit.overflow.1074:                        ; preds = %put.pic.hit.1064
  %r5389 = trunc i64 %r5386 to i32
  %statepoint_token897 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (double, i64, i32, double)) @js_put_value_set_ic_overflow_store, i32 4, i32 0, double %r5289, i64 %r5332, i32 %r5389, double %r5291, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50, ptr addrspace(1) %.01201) ]
  %r5390898 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token897)
  %rs4gc.s50.relocated899 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token897, i32 0, i32 0) ; (%rs4gc.s50, %rs4gc.s50)
  %rs4gc.s36.relocated900 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token897, i32 1, i32 1) ; (%.01201, %.01201)
  %r5391 = icmp ne i32 %r5390898, 0
  br i1 %r5391, label %put.pic.merge.1073, label %put.pic.miss.1068

put.pic.hit.inline.1075:                          ; preds = %put.pic.hit.1064
  %r5392 = shl i64 %r5386, 3
  %r5393 = add nuw nsw i64 %r5295, 16
  %r5394 = add i64 %r5393, %r5392
  %r5395 = inttoptr i64 %r5394 to ptr
  %r5396 = and i16 %r5314, 1024
  %r5397 = icmp ne i16 %r5396, 0
  br i1 %r5397, label %put.pic.hit.validate.1065, label %put.pic.hit.store.1066

put.pic.gc_bookkeeping.1076:                      ; preds = %put.pic.hit.store.1066
  call void @js_string_addref_if_heap_string(double %r5291) #7
  %r5955.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s50 to i64
  %r5955.rs4o = call i64 asm "", "=r,0"(i64 %r5955.rs4i) #7
  %r5955 = bitcast i64 %r5955.rs4o to double
  %r5956 = bitcast double %r5955 to i64
  %r5957 = and i64 %r5956, 281474976710655
  %r5958 = load double, ptr @test_json_tape_batch_records_ts_.str.27.handle, align 8
  %r5959 = bitcast double %r5958 to i64
  call void @js_gc_note_slot_layout(i64 %r5957, i32 %r5401, i64 %r5959) #7
  %r5952.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s50 to i64
  %r5952.rs4o = call i64 asm "", "=r,0"(i64 %r5952.rs4i) #7
  %r5952 = bitcast i64 %r5952.rs4o to double
  %r5953 = bitcast double %r5952 to i64
  %r5954 = and i64 %r5953, 281474976710655
  %r5413 = sub nsw i64 %r5954, 7
  %r5414 = inttoptr i64 %r5413 to ptr
  %r5415 = load i8, ptr %r5414, align 1
  %r5416 = and i8 %r5415, 32
  %r5417 = icmp ne i8 %r5416, 0
  %r5418 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5419 = icmp ne i32 %r5418, 0
  %r5420 = or i1 %r5417, %r5419
  br i1 %r5420, label %put.pic.barrier.1078, label %put.pic.gc_bookkeeping.done.1077

put.pic.gc_bookkeeping.done.1077:                 ; preds = %put.pic.barrier.1078, %put.pic.gc_bookkeeping.1076, %put.pic.hit.store.1066
  br label %put.pic.merge.1073

put.pic.barrier.1078:                             ; preds = %put.pic.gc_bookkeeping.1076
  %r5948.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s50 to i64
  %r5948.rs4o = call i64 asm "", "=r,0"(i64 %r5948.rs4i) #7
  %r5948 = bitcast i64 %r5948.rs4o to double
  %r5949 = bitcast double %r5948 to i64
  %r5950 = load double, ptr @test_json_tape_batch_records_ts_.str.27.handle, align 8
  %r5951 = bitcast double %r5950 to i64
  call void @js_write_barrier_slot(i64 %r5949, i64 %r5394, i64 %r5951) #7
  br label %put.pic.gc_bookkeeping.done.1077

shadow.root.barrier.1079:                         ; preds = %put.pic.merge.1073
  call void @js_write_barrier_root_nanbox(i64 %r5431) #7
  br label %shadow.root.barrier.done.1080

shadow.root.barrier.done.1080:                    ; preds = %shadow.root.barrier.1079, %put.pic.merge.1073
  %statepoint_token901 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50.relocated895, ptr addrspace(1) %rs4gc.s36.relocated896, ptr addrspace(1) %rs4gc.s51) ]
  %r5434902 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token901)
  %rs4gc.s50.relocated903 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token901, i32 0, i32 0) ; (%rs4gc.s50.relocated895, %rs4gc.s50.relocated895)
  %rs4gc.s36.relocated904 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token901, i32 1, i32 1) ; (%rs4gc.s36.relocated896, %rs4gc.s36.relocated896)
  %rs4gc.s51.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token901, i32 2, i32 2) ; (%rs4gc.s51, %rs4gc.s51)
  %rs4gc.s52 = inttoptr i64 %r5434902 to ptr addrspace(1)
  %r5435.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s52 to i64
  %r5435 = call i64 asm "", "=r,0"(i64 %r5435.rs4i) #7
  %r5436 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5437 = icmp ne i32 %r5436, 0
  br i1 %r5437, label %shadow.root.barrier.1081, label %shadow.root.barrier.done.1082

shadow.root.barrier.1081:                         ; preds = %shadow.root.barrier.done.1080
  call void @js_write_barrier_root_nanbox(i64 %r5435) #7
  br label %shadow.root.barrier.done.1082

shadow.root.barrier.done.1082:                    ; preds = %shadow.root.barrier.1081, %shadow.root.barrier.done.1080
  %r5438.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s51.relocated to i64
  %r5438 = call i64 asm "", "=r,0"(i64 %r5438.rs4i) #7
  %r5439 = bitcast i64 %r5438 to double
  %r5440.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s52 to i64
  %r5440 = call i64 asm "", "=r,0"(i64 %r5440.rs4i) #7
  %statepoint_token905 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r5440, double %r5439, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50.relocated903, ptr addrspace(1) %rs4gc.s36.relocated904) ]
  %r5441906 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token905)
  %rs4gc.s50.relocated907 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token905, i32 0, i32 0) ; (%rs4gc.s50.relocated903, %rs4gc.s50.relocated903)
  %rs4gc.s36.relocated908 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token905, i32 1, i32 1) ; (%rs4gc.s36.relocated904, %rs4gc.s36.relocated904)
  %rs4gc.s53 = inttoptr i64 %r5441906 to ptr addrspace(1)
  %r5442.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s53 to i64
  %r5442 = call i64 asm "", "=r,0"(i64 %r5442.rs4i) #7
  %r5443 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5444 = icmp ne i32 %r5443, 0
  br i1 %r5444, label %shadow.root.barrier.1083, label %shadow.root.barrier.done.1084

shadow.root.barrier.1083:                         ; preds = %shadow.root.barrier.done.1082
  call void @js_write_barrier_root_nanbox(i64 %r5442) #7
  br label %shadow.root.barrier.done.1084

shadow.root.barrier.done.1084:                    ; preds = %shadow.root.barrier.1083, %shadow.root.barrier.done.1082
  %r5445.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s53 to i64
  %r5445 = call i64 asm "", "=r,0"(i64 %r5445.rs4i) #7
  %statepoint_token909 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r5445, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50.relocated907, ptr addrspace(1) %rs4gc.s36.relocated908) ]
  %rs4gc.s50.relocated910 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token909, i32 0, i32 0) ; (%rs4gc.s50.relocated907, %rs4gc.s50.relocated907)
  %rs4gc.s36.relocated911 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token909, i32 1, i32 1) ; (%rs4gc.s36.relocated908, %rs4gc.s36.relocated908)
  %statepoint_token912 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_collect, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50.relocated910, ptr addrspace(1) %rs4gc.s36.relocated911) ]
  %rs4gc.s50.relocated913 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token912, i32 0, i32 0) ; (%rs4gc.s50.relocated910, %rs4gc.s50.relocated910)
  %rs4gc.s36.relocated914 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token912, i32 1, i32 1) ; (%rs4gc.s36.relocated911, %rs4gc.s36.relocated911)
  %statepoint_token915 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50.relocated913, ptr addrspace(1) %rs4gc.s36.relocated914) ]
  %r5446916 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token915)
  %rs4gc.s50.relocated917 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token915, i32 0, i32 0) ; (%rs4gc.s50.relocated913, %rs4gc.s50.relocated913)
  %rs4gc.s36.relocated918 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token915, i32 1, i32 1) ; (%rs4gc.s36.relocated914, %rs4gc.s36.relocated914)
  %rs4gc.s54 = inttoptr i64 %r5446916 to ptr addrspace(1)
  %r5447.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s54 to i64
  %r5447 = call i64 asm "", "=r,0"(i64 %r5447.rs4i) #7
  %r5448 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5449 = icmp ne i32 %r5448, 0
  br i1 %r5449, label %shadow.root.barrier.1085, label %shadow.root.barrier.done.1086

shadow.root.barrier.1085:                         ; preds = %shadow.root.barrier.done.1084
  call void @js_write_barrier_root_nanbox(i64 %r5447) #7
  br label %shadow.root.barrier.done.1086

shadow.root.barrier.done.1086:                    ; preds = %shadow.root.barrier.1085, %shadow.root.barrier.done.1084
  %r5450 = load double, ptr @test_json_tape_batch_records_ts_.str.28.handle, align 8
  %r5451.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s54 to i64
  %r5451 = call i64 asm "", "=r,0"(i64 %r5451.rs4i) #7
  %statepoint_token919 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r5451, double %r5450, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50.relocated917, ptr addrspace(1) %rs4gc.s36.relocated918) ]
  %r5452920 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token919)
  %rs4gc.s50.relocated921 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token919, i32 0, i32 0) ; (%rs4gc.s50.relocated917, %rs4gc.s50.relocated917)
  %rs4gc.s36.relocated922 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token919, i32 1, i32 1) ; (%rs4gc.s36.relocated918, %rs4gc.s36.relocated918)
  %rs4gc.s55 = inttoptr i64 %r5452920 to ptr addrspace(1)
  %r5453.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s55 to i64
  %r5453 = call i64 asm "", "=r,0"(i64 %r5453.rs4i) #7
  %r5454 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5455 = icmp ne i32 %r5454, 0
  br i1 %r5455, label %shadow.root.barrier.1087, label %shadow.root.barrier.done.1088

shadow.root.barrier.1087:                         ; preds = %shadow.root.barrier.done.1086
  call void @js_write_barrier_root_nanbox(i64 %r5453) #7
  br label %shadow.root.barrier.done.1088

shadow.root.barrier.done.1088:                    ; preds = %shadow.root.barrier.1087, %shadow.root.barrier.done.1086
  %r5456.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s36.relocated922 to i64
  %r5456.rs4o = call i64 asm "", "=r,0"(i64 %r5456.rs4i) #7
  %r5456 = bitcast i64 %r5456.rs4o to double
  %r5457 = bitcast double %r5456 to i64
  %r5458 = and i64 %r5457, 281474976710655
  %r5459 = and i64 %r5457, -281474976710656
  %r5460 = icmp eq i64 %r5459, 9222527611924643840
  %r5461 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r5462 = icmp eq i64 %r5461, 0
  %r5463 = icmp ugt i64 %r5458, 1048575
  %r5464 = icmp ult i64 %r5458, 140737488355328
  %r5465 = and i1 %r5463, %r5464
  %r5466 = and i1 %r5460, %r5462
  %r5467 = and i1 %r5466, %r5465
  br i1 %r5467, label %tav.get.brand.1093, label %tav.get.slow.1091

tav.get.fast.1089:                                ; preds = %tav.get.brand.1093
  %r5484 = bitcast double %r5456 to i64
  %r5485 = and i64 %r5484, 281474976710655
  %r5486 = add nuw nsw i64 %r5485, 8
  %r5487 = inttoptr i64 %r5486 to ptr
  %r5488 = load i8, ptr %r5487, align 1
  %r5489 = zext i8 %r5488 to i64
  %r5493 = inttoptr i64 %r5485 to ptr
  %r5494 = load i32, ptr %r5493, align 4
  %r5495 = zext i32 %r5494 to i64
  %r5496 = icmp ult i64 0, %r5495
  %r5497 = and i1 true, %r5496
  br i1 %r5497, label %tav.get.load.1090, label %tav.get.slow.1091

tav.get.load.1090:                                ; preds = %tav.get.fast.1089
  %r5498 = add nuw nsw i64 %r5485, 16
  %r5499 = icmp eq i64 %r5489, 0
  br i1 %r5499, label %tav.k.i8.1094, label %tav.kd1.1102

tav.get.slow.1091:                                ; preds = %tav.get.brand.1093, %tav.get.fast.1089, %shadow.root.barrier.done.1088
  %r5550 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__42, align 8
  %r5551 = icmp ne ptr %r5550, null
  %r5552 = select i1 %r5551, ptr %r5550, ptr @perry_ic_test_json_tape_batch_records_ts__42
  %r5553 = bitcast double %r5456 to i64
  %r5554 = and i64 %r5553, 281474976710655
  %r5555 = and i64 %r5553, -281474976710656
  %r5556 = icmp eq i64 %r5555, 9222527611924643840
  %r5557 = icmp uge i64 %r5554, 2199023255552
  %r5558 = icmp ult i64 %r5554, 140737488355328
  %r5561 = and i1 %r5556, %r5557
  %r5562 = and i1 %r5561, %r5558
  br i1 %r5562, label %arrlike.ic.header.1109, label %arrlike.ic.miss.1128

tav.get.merge.1092:                               ; preds = %arrlike.elem.value.1134, %arrlike.ic.miss.1128, %arrlike.ic.spill_load.1127, %arrlike.ic.inline.1124, %arrlike.ic.array_load.1112, %tav.k.f64.1101, %tav.k.f32.1100, %tav.k.u32.1099, %tav.k.i32.1098, %tav.k.u16.1097, %tav.k.i16.1096, %tav.k.u8.1095, %tav.k.i8.1094
  %.01208 = phi ptr addrspace(1) [ %rs4gc.s55, %tav.k.i8.1094 ], [ %rs4gc.s55, %tav.k.u8.1095 ], [ %rs4gc.s55, %tav.k.i16.1096 ], [ %rs4gc.s55, %tav.k.u16.1097 ], [ %rs4gc.s55, %tav.k.i32.1098 ], [ %rs4gc.s55, %tav.k.u32.1099 ], [ %rs4gc.s55, %tav.k.f32.1100 ], [ %rs4gc.s55, %tav.k.f64.1101 ], [ %rs4gc.s55, %arrlike.ic.array_load.1112 ], [ %rs4gc.s55.relocated, %arrlike.ic.miss.1128 ], [ %rs4gc.s55, %arrlike.elem.value.1134 ], [ %rs4gc.s55, %arrlike.ic.inline.1124 ], [ %rs4gc.s55, %arrlike.ic.spill_load.1127 ]
  %.21206 = phi ptr addrspace(1) [ %rs4gc.s50.relocated921, %tav.k.i8.1094 ], [ %rs4gc.s50.relocated921, %tav.k.u8.1095 ], [ %rs4gc.s50.relocated921, %tav.k.i16.1096 ], [ %rs4gc.s50.relocated921, %tav.k.u16.1097 ], [ %rs4gc.s50.relocated921, %tav.k.i32.1098 ], [ %rs4gc.s50.relocated921, %tav.k.u32.1099 ], [ %rs4gc.s50.relocated921, %tav.k.f32.1100 ], [ %rs4gc.s50.relocated921, %tav.k.f64.1101 ], [ %rs4gc.s50.relocated921, %arrlike.ic.array_load.1112 ], [ %rs4gc.s50.relocated925, %arrlike.ic.miss.1128 ], [ %rs4gc.s50.relocated921, %arrlike.elem.value.1134 ], [ %rs4gc.s50.relocated921, %arrlike.ic.inline.1124 ], [ %rs4gc.s50.relocated921, %arrlike.ic.spill_load.1127 ]
  %r5723 = phi double [ %r5512, %tav.k.i8.1094 ], [ %r5518, %tav.k.u8.1095 ], [ %r5524, %tav.k.i16.1096 ], [ %r5530, %tav.k.u16.1097 ], [ %r5535, %tav.k.i32.1098 ], [ %r5540, %tav.k.u32.1099 ], [ %r5545, %tav.k.f32.1100 ], [ %r5549, %tav.k.f64.1101 ], [ %r5606, %arrlike.elem.value.1134 ], [ %r5634, %arrlike.ic.array_load.1112 ], [ %r5704, %arrlike.ic.inline.1124 ], [ %r5721, %arrlike.ic.spill_load.1127 ], [ %r5722924, %arrlike.ic.miss.1128 ]
  %r5724.rs4i = ptrtoint ptr addrspace(1) %.21206 to i64
  %r5724.rs4o = call i64 asm "", "=r,0"(i64 %r5724.rs4i) #7
  %r5724 = bitcast i64 %r5724.rs4o to double
  %r5725 = bitcast double %r5723 to i64
  %r5726 = bitcast double %r5724 to i64
  %r5727 = icmp eq i64 %r5725, %r5726
  br i1 %r5727, label %anyeq.same.1136, label %anyeq.diff.1137

tav.get.brand.1093:                               ; preds = %shadow.root.barrier.done.1088
  %r5468 = bitcast double %r5456 to i64
  %r5469 = and i64 %r5468, 281474976710655
  %r5470 = sub nsw i64 %r5469, 8
  %r5471 = inttoptr i64 %r5470 to ptr
  %r5472 = load i8, ptr %r5471, align 1
  %r5473 = icmp eq i8 %r5472, 11
  %r5474 = add nuw nsw i64 %r5469, 8
  %r5475 = inttoptr i64 %r5474 to ptr
  %r5476 = load i8, ptr %r5475, align 1
  %r5477 = zext i8 %r5476 to i64
  %r5478 = icmp ule i64 %r5477, 8
  %r5481 = and i1 %r5473, %r5478
  br i1 %r5481, label %tav.get.fast.1089, label %tav.get.slow.1091

tav.k.i8.1094:                                    ; preds = %tav.get.load.1090
  %r5508 = add nuw nsw i64 %r5498, 0
  %r5509 = inttoptr i64 %r5508 to ptr
  %r5510 = load i8, ptr %r5509, align 1
  %r5511 = sext i8 %r5510 to i32
  %r5512 = sitofp i32 %r5511 to double
  br label %tav.get.merge.1092

tav.k.u8.1095:                                    ; preds = %tav.kd7.1108, %tav.kd1.1102
  %r5514 = add nuw nsw i64 %r5498, 0
  %r5515 = inttoptr i64 %r5514 to ptr
  %r5516 = load i8, ptr %r5515, align 1
  %r5517 = zext i8 %r5516 to i32
  %r5518 = uitofp nneg i32 %r5517 to double
  br label %tav.get.merge.1092

tav.k.i16.1096:                                   ; preds = %tav.kd2.1103
  %r5520 = add nuw nsw i64 %r5498, 0
  %r5521 = inttoptr i64 %r5520 to ptr
  %r5522 = load i16, ptr %r5521, align 2
  %r5523 = sext i16 %r5522 to i32
  %r5524 = sitofp i32 %r5523 to double
  br label %tav.get.merge.1092

tav.k.u16.1097:                                   ; preds = %tav.kd3.1104
  %r5526 = add nuw nsw i64 %r5498, 0
  %r5527 = inttoptr i64 %r5526 to ptr
  %r5528 = load i16, ptr %r5527, align 2
  %r5529 = zext i16 %r5528 to i32
  %r5530 = uitofp nneg i32 %r5529 to double
  br label %tav.get.merge.1092

tav.k.i32.1098:                                   ; preds = %tav.kd4.1105
  %r5532 = add nuw nsw i64 %r5498, 0
  %r5533 = inttoptr i64 %r5532 to ptr
  %r5534 = load i32, ptr %r5533, align 4
  %r5535 = sitofp i32 %r5534 to double
  br label %tav.get.merge.1092

tav.k.u32.1099:                                   ; preds = %tav.kd5.1106
  %r5537 = add nuw nsw i64 %r5498, 0
  %r5538 = inttoptr i64 %r5537 to ptr
  %r5539 = load i32, ptr %r5538, align 4
  %r5540 = uitofp i32 %r5539 to double
  br label %tav.get.merge.1092

tav.k.f32.1100:                                   ; preds = %tav.kd6.1107
  %r5542 = add nuw nsw i64 %r5498, 0
  %r5543 = inttoptr i64 %r5542 to ptr
  %r5544 = load float, ptr %r5543, align 4
  %r5545 = fpext float %r5544 to double
  br label %tav.get.merge.1092

tav.k.f64.1101:                                   ; preds = %tav.kd7.1108
  %r5547 = add nuw nsw i64 %r5498, 0
  %r5548 = inttoptr i64 %r5547 to ptr
  %r5549 = load double, ptr %r5548, align 8
  br label %tav.get.merge.1092

tav.kd1.1102:                                     ; preds = %tav.get.load.1090
  %r5500 = icmp eq i64 %r5489, 1
  br i1 %r5500, label %tav.k.u8.1095, label %tav.kd2.1103

tav.kd2.1103:                                     ; preds = %tav.kd1.1102
  %r5501 = icmp eq i64 %r5489, 2
  br i1 %r5501, label %tav.k.i16.1096, label %tav.kd3.1104

tav.kd3.1104:                                     ; preds = %tav.kd2.1103
  %r5502 = icmp eq i64 %r5489, 3
  br i1 %r5502, label %tav.k.u16.1097, label %tav.kd4.1105

tav.kd4.1105:                                     ; preds = %tav.kd3.1104
  %r5503 = icmp eq i64 %r5489, 4
  br i1 %r5503, label %tav.k.i32.1098, label %tav.kd5.1106

tav.kd5.1106:                                     ; preds = %tav.kd4.1105
  %r5504 = icmp eq i64 %r5489, 5
  br i1 %r5504, label %tav.k.u32.1099, label %tav.kd6.1107

tav.kd6.1107:                                     ; preds = %tav.kd5.1106
  %r5505 = icmp eq i64 %r5489, 6
  br i1 %r5505, label %tav.k.f32.1100, label %tav.kd7.1108

tav.kd7.1108:                                     ; preds = %tav.kd6.1107
  %r5506 = icmp eq i64 %r5489, 7
  br i1 %r5506, label %tav.k.f64.1101, label %tav.k.u8.1095

arrlike.ic.header.1109:                           ; preds = %tav.get.slow.1091
  %r5568 = sub nuw nsw i64 %r5554, 8
  %r5569 = inttoptr i64 %r5568 to ptr
  %r5570 = load i8, ptr %r5569, align 1
  %r5572 = sub nuw nsw i64 %r5554, 7
  %r5573 = inttoptr i64 %r5572 to ptr
  %r5574 = load i8, ptr %r5573, align 1
  %r5575 = and i8 %r5574, -128
  %r5576 = icmp eq i8 %r5575, 0
  %r5577 = and i1 true, %r5576
  br i1 %r5577, label %arrlike.ic.brand.1110, label %arrlike.ic.miss.1128

arrlike.ic.brand.1110:                            ; preds = %arrlike.ic.header.1109
  %r5571 = icmp eq i8 %r5570, 1
  br i1 %r5571, label %arrlike.ic.array_guard.1111, label %arrlike.elem.kind.1129

arrlike.ic.array_guard.1111:                      ; preds = %arrlike.ic.brand.1110
  %r5609 = sub nuw nsw i64 %r5554, 6
  %r5610 = inttoptr i64 %r5609 to ptr
  %r5611 = load i16, ptr %r5610, align 2
  %r5612 = and i16 %r5611, 1024
  %r5613 = icmp eq i16 %r5612, 0
  %r5614 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r5615 = icmp eq i8 %r5614, 0
  %r5616 = inttoptr i64 %r5554 to ptr
  %r5617 = load i32, ptr %r5616, align 4
  %r5618 = add nuw nsw i64 %r5554, 4
  %r5619 = inttoptr i64 %r5618 to ptr
  %r5620 = load i32, ptr %r5619, align 4
  %r5621 = zext i32 %r5617 to i64
  %r5622 = zext i32 %r5620 to i64
  %r5623 = icmp ult i64 0, %r5621
  %r5624 = icmp ule i64 %r5621, %r5622
  %r5625 = and i1 %r5613, %r5615
  %r5626 = and i1 %r5625, %r5623
  %r5627 = and i1 %r5626, %r5624
  br i1 %r5627, label %arrlike.ic.array_load.1112, label %arrlike.ic.miss.1128

arrlike.ic.array_load.1112:                       ; preds = %arrlike.ic.array_guard.1111
  %r5629 = getelementptr inbounds nuw i64, ptr %r5616, i64 1
  %r5630 = load double, ptr %r5629, align 8
  %r5631 = bitcast double %r5630 to i64
  %r5632 = icmp eq i64 %r5631, 9222246136947933200
  %r5634 = select i1 %r5632, double 0x7FFC000000000001, double %r5630
  br label %tav.get.merge.1092

arrlike.ic.shape.1113:                            ; preds = %arrlike.elem.store.1131, %arrlike.elem.meta.1130
  %r5636 = inttoptr i64 %r5554 to ptr
  %r5637 = load i32, ptr %r5636, align 4
  %r5638 = add nuw nsw i64 %r5554, 4
  %r5639 = inttoptr i64 %r5638 to ptr
  %r5640 = load i32, ptr %r5639, align 4
  %r5641 = zext i32 %r5637 to i64
  %r5642 = zext i32 %r5640 to i64
  %r5643 = shl nuw i64 %r5641, 32
  %r5644 = or i64 %r5643, %r5642
  %r5645 = getelementptr i64, ptr %r5552, i64 0
  %r5646 = load i64, ptr %r5645, align 8
  %r5647 = icmp ne i64 %r5646, 0
  %r5648 = and i1 true, %r5647
  br i1 %r5648, label %arrlike.ic.identity.1114, label %arrlike.ic.miss.1128

arrlike.ic.identity.1114:                         ; preds = %arrlike.ic.shape.1113
  %r5649 = and i64 %r5646, -9223372036854775808
  %9 = icmp slt i64 %r5646, 0
  br i1 %9, label %arrlike.ic.family_meta.1116, label %arrlike.ic.exact.1115

arrlike.ic.exact.1115:                            ; preds = %arrlike.ic.identity.1114
  %r5651 = icmp eq i64 %r5644, %r5646
  br i1 %r5651, label %arrlike.ic.bounds.1118, label %arrlike.ic.miss.1128

arrlike.ic.family_meta.1116:                      ; preds = %arrlike.ic.identity.1114
  %r5652 = add nuw nsw i64 %r5554, 8
  %r5653 = inttoptr i64 %r5652 to ptr
  %r5654 = load i64, ptr %r5653, align 8
  %r5655 = icmp ne i64 %r5654, 0
  br i1 %r5655, label %arrlike.ic.family_token.1117, label %arrlike.ic.miss.1128

arrlike.ic.family_token.1117:                     ; preds = %arrlike.ic.family_meta.1116
  %r5656 = inttoptr i64 %r5654 to ptr
  %r5657 = getelementptr i64, ptr %r5656, i64 6
  %r5658 = load i64, ptr %r5657, align 8
  %r5659 = icmp eq i64 %r5658, %r5646
  br i1 %r5659, label %arrlike.ic.bounds.1118, label %arrlike.ic.miss.1128

arrlike.ic.bounds.1118:                           ; preds = %arrlike.ic.family_token.1117, %arrlike.ic.exact.1115
  %r5660 = getelementptr i64, ptr %r5550, i64 1
  %r5661 = load i64, ptr %r5660, align 8
  %r5662 = getelementptr i64, ptr %r5550, i64 2
  %r5663 = load i64, ptr %r5662, align 8
  %r5664 = getelementptr i64, ptr %r5550, i64 3
  %r5665 = load i64, ptr %r5664, align 8
  %r5666 = getelementptr i64, ptr %r5550, i64 4
  %r5667 = load i64, ptr %r5666, align 8
  %r5668 = icmp ult i64 %r5661, %r5667
  br i1 %r5668, label %arrlike.ic.length_inline.1119, label %arrlike.ic.length_spill_meta.1120

arrlike.ic.length_inline.1119:                    ; preds = %arrlike.ic.bounds.1118
  %r5669 = shl i64 %r5661, 3
  %r5670 = add i64 %r5669, 16
  %r5671 = add i64 %r5554, %r5670
  %r5672 = inttoptr i64 %r5671 to ptr
  %r5673 = load double, ptr %r5672, align 8
  br label %arrlike.ic.range.1123

arrlike.ic.length_spill_meta.1120:                ; preds = %arrlike.ic.bounds.1118
  %r5674 = add nuw nsw i64 %r5554, 8
  %r5675 = inttoptr i64 %r5674 to ptr
  %r5676 = load i64, ptr %r5675, align 8
  %r5677 = icmp ne i64 %r5676, 0
  br i1 %r5677, label %arrlike.ic.length_spill_ptr.1121, label %arrlike.ic.miss.1128

arrlike.ic.length_spill_ptr.1121:                 ; preds = %arrlike.ic.length_spill_meta.1120
  %r5678 = inttoptr i64 %r5676 to ptr
  %r5679 = getelementptr i64, ptr %r5678, i64 4
  %r5680 = load i64, ptr %r5679, align 8
  %r5681 = icmp ne i64 %r5680, 0
  %r5682 = select i1 %r5681, i64 %r5680, i64 %r5676
  %r5683 = inttoptr i64 %r5682 to ptr
  %r5684 = load i32, ptr %r5683, align 4
  %r5685 = zext i32 %r5684 to i64
  %r5686 = icmp ult i64 %r5661, %r5685
  %r5687 = and i1 %r5681, %r5686
  br i1 %r5687, label %arrlike.ic.length_spill_load.1122, label %arrlike.ic.miss.1128

arrlike.ic.length_spill_load.1122:                ; preds = %arrlike.ic.length_spill_ptr.1121
  %r5688 = add nuw nsw i64 %r5661, 1
  %r5689 = getelementptr inbounds nuw i64, ptr %r5683, i64 %r5688
  %r5690 = load double, ptr %r5689, align 8
  br label %arrlike.ic.range.1123

arrlike.ic.range.1123:                            ; preds = %arrlike.ic.length_spill_load.1122, %arrlike.ic.length_inline.1119
  %r5691 = phi double [ %r5673, %arrlike.ic.length_inline.1119 ], [ %r5690, %arrlike.ic.length_spill_load.1122 ]
  %r5692 = fcmp olt double 0.000000e+00, %r5691
  %r5693 = icmp ult i64 0, %r5665
  %r5694 = and i1 %r5692, %r5693
  %r5695 = add nuw nsw i64 %r5663, 0
  %r5696 = icmp ult i64 %r5695, %r5667
  %r5697 = and i1 %r5694, %r5696
  %r5698 = xor i1 %r5696, true
  %r5699 = and i1 %r5694, %r5698
  br i1 %r5697, label %arrlike.ic.inline.1124, label %arrlike.ic.spill_or_miss.1135

arrlike.ic.inline.1124:                           ; preds = %arrlike.ic.range.1123
  %r5700 = shl i64 %r5695, 3
  %r5701 = add i64 %r5700, 16
  %r5702 = add i64 %r5554, %r5701
  %r5703 = inttoptr i64 %r5702 to ptr
  %r5704 = load double, ptr %r5703, align 8
  br label %tav.get.merge.1092

arrlike.ic.spill.1125:                            ; preds = %arrlike.ic.spill_or_miss.1135
  %r5705 = add nuw nsw i64 %r5554, 8
  %r5706 = inttoptr i64 %r5705 to ptr
  %r5707 = load i64, ptr %r5706, align 8
  %r5708 = icmp ne i64 %r5707, 0
  br i1 %r5708, label %arrlike.ic.spill_ptr.1126, label %arrlike.ic.miss.1128

arrlike.ic.spill_ptr.1126:                        ; preds = %arrlike.ic.spill.1125
  %r5709 = inttoptr i64 %r5707 to ptr
  %r5710 = getelementptr i64, ptr %r5709, i64 4
  %r5711 = load i64, ptr %r5710, align 8
  %r5712 = icmp ne i64 %r5711, 0
  %r5713 = select i1 %r5712, i64 %r5711, i64 %r5707
  %r5714 = inttoptr i64 %r5713 to ptr
  %r5715 = load i32, ptr %r5714, align 4
  %r5716 = zext i32 %r5715 to i64
  %r5717 = icmp ult i64 %r5695, %r5716
  %r5718 = and i1 %r5712, %r5717
  br i1 %r5718, label %arrlike.ic.spill_load.1127, label %arrlike.ic.miss.1128

arrlike.ic.spill_load.1127:                       ; preds = %arrlike.ic.spill_ptr.1126
  %r5719 = add nuw nsw i64 %r5695, 1
  %r5720 = getelementptr inbounds nuw i64, ptr %r5714, i64 %r5719
  %r5721 = load double, ptr %r5720, align 8
  br label %tav.get.merge.1092

arrlike.ic.miss.1128:                             ; preds = %arrlike.ic.spill_or_miss.1135, %arrlike.elem.load.1133, %arrlike.elem.bounds.1132, %arrlike.elem.kind.1129, %arrlike.ic.spill_ptr.1126, %arrlike.ic.spill.1125, %arrlike.ic.length_spill_ptr.1121, %arrlike.ic.length_spill_meta.1120, %arrlike.ic.family_token.1117, %arrlike.ic.family_meta.1116, %arrlike.ic.exact.1115, %arrlike.ic.shape.1113, %arrlike.ic.array_guard.1111, %arrlike.ic.header.1109, %tav.get.slow.1091
  %statepoint_token923 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, ptr)) @js_packed_arraylike_index_get, i32 3, i32 0, double %r5456, double 0.000000e+00, ptr @perry_ic_test_json_tape_batch_records_ts__42, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s50.relocated921, ptr addrspace(1) %rs4gc.s55) ]
  %r5722924 = call double @llvm.experimental.gc.result.f64(token %statepoint_token923)
  %rs4gc.s50.relocated925 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token923, i32 0, i32 0) ; (%rs4gc.s50.relocated921, %rs4gc.s50.relocated921)
  %rs4gc.s55.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token923, i32 1, i32 1) ; (%rs4gc.s55, %rs4gc.s55)
  br label %tav.get.merge.1092

arrlike.elem.kind.1129:                           ; preds = %arrlike.ic.brand.1110
  %r5578 = icmp eq i8 %r5570, 2
  br i1 %r5578, label %arrlike.elem.meta.1130, label %arrlike.ic.miss.1128

arrlike.elem.meta.1130:                           ; preds = %arrlike.elem.kind.1129
  %r5579 = add nuw nsw i64 %r5554, 8
  %r5580 = inttoptr i64 %r5579 to ptr
  %r5581 = load i64, ptr %r5580, align 8
  %r5582 = icmp ne i64 %r5581, 0
  br i1 %r5582, label %arrlike.elem.store.1131, label %arrlike.ic.shape.1113

arrlike.elem.store.1131:                          ; preds = %arrlike.elem.meta.1130
  %r5583 = inttoptr i64 %r5581 to ptr
  %r5584 = getelementptr i64, ptr %r5583, i64 12
  %r5585 = load i64, ptr %r5584, align 8
  %r5586 = icmp ne i64 %r5585, 0
  br i1 %r5586, label %arrlike.elem.bounds.1132, label %arrlike.ic.shape.1113

arrlike.elem.bounds.1132:                         ; preds = %arrlike.elem.store.1131
  %r5587 = sub i64 %r5585, 8
  %r5588 = inttoptr i64 %r5587 to ptr
  %r5589 = load i8, ptr %r5588, align 1
  %r5590 = icmp eq i8 %r5589, 1
  %r5591 = sub i64 %r5585, 7
  %r5592 = inttoptr i64 %r5591 to ptr
  %r5593 = load i8, ptr %r5592, align 1
  %r5594 = and i8 %r5593, -128
  %r5595 = icmp eq i8 %r5594, 0
  %r5596 = inttoptr i64 %r5585 to ptr
  %r5597 = load i32, ptr %r5596, align 4
  %r5598 = zext i32 %r5597 to i64
  %r5599 = icmp ult i64 0, %r5598
  %r5600 = and i1 %r5590, %r5595
  %r5601 = and i1 %r5600, %r5599
  br i1 %r5601, label %arrlike.elem.load.1133, label %arrlike.ic.miss.1128

arrlike.elem.load.1133:                           ; preds = %arrlike.elem.bounds.1132
  %r5603 = add i64 %r5585, 8
  %r5604 = add nuw nsw i64 %r5603, 0
  %r5605 = inttoptr i64 %r5604 to ptr
  %r5606 = load double, ptr %r5605, align 8
  %r5607 = bitcast double %r5606 to i64
  %r5608 = icmp eq i64 %r5607, 9222246136947933200
  br i1 %r5608, label %arrlike.ic.miss.1128, label %arrlike.elem.value.1134

arrlike.elem.value.1134:                          ; preds = %arrlike.elem.load.1133
  br label %tav.get.merge.1092

arrlike.ic.spill_or_miss.1135:                    ; preds = %arrlike.ic.range.1123
  br i1 %r5699, label %arrlike.ic.spill.1125, label %arrlike.ic.miss.1128

anyeq.same.1136:                                  ; preds = %tav.get.merge.1092
  %r5728 = lshr i64 %r5725, 48
  %r5729 = icmp uge i64 %r5728, 32761
  %r5730 = icmp ule i64 %r5728, 32767
  %r5731 = and i1 %r5729, %r5730
  %r5732 = fcmp uno double %r5723, %r5723
  %r5733 = xor i1 %r5732, true
  %r5734 = or i1 %r5731, %r5733
  br i1 %r5734, label %anyeq.true.1139, label %anyeq.slow.1138

anyeq.diff.1137:                                  ; preds = %tav.get.merge.1092
  %r5735 = and i64 %r5725, 9221120237041090560
  %r5736 = icmp ne i64 %r5735, 9221120237041090560
  %r5737 = and i64 %r5726, 9221120237041090560
  %r5738 = icmp ne i64 %r5737, 9221120237041090560
  %r5739 = and i1 %r5736, %r5738
  br i1 %r5739, label %anyeq.num.1142, label %anyeq.tag.1143

anyeq.slow.1138:                                  ; preds = %anyeq.tag.1143, %anyeq.same.1136
  %statepoint_token926 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i64)) @js_eq, i32 2, i32 0, i64 %r5725, i64 %r5726, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.21206, ptr addrspace(1) %.01208) ]
  %r5750927 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token926)
  %rs4gc.s50.relocated928 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token926, i32 0, i32 0) ; (%.21206, %.21206)
  %rs4gc.s55.relocated929 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token926, i32 1, i32 1) ; (%.01208, %.01208)
  br label %anyeq.merge.1141

anyeq.true.1139:                                  ; preds = %anyeq.num.1142, %anyeq.same.1136
  br label %anyeq.merge.1141

anyeq.false.1140:                                 ; preds = %anyeq.tag.1143, %anyeq.num.1142
  br label %anyeq.merge.1141

anyeq.merge.1141:                                 ; preds = %anyeq.false.1140, %anyeq.true.1139, %anyeq.slow.1138
  %.11209 = phi ptr addrspace(1) [ %.01208, %anyeq.true.1139 ], [ %rs4gc.s55.relocated929, %anyeq.slow.1138 ], [ %.01208, %anyeq.false.1140 ]
  %.31207 = phi ptr addrspace(1) [ %.21206, %anyeq.true.1139 ], [ %rs4gc.s50.relocated928, %anyeq.slow.1138 ], [ %.21206, %anyeq.false.1140 ]
  %r5751 = phi i64 [ 9222246136947933188, %anyeq.true.1139 ], [ 9222246136947933187, %anyeq.false.1140 ], [ %r5750927, %anyeq.slow.1138 ]
  %r5752 = bitcast i64 %r5751 to double
  %r5753.rs4i = ptrtoint ptr addrspace(1) %.11209 to i64
  %r5753 = call i64 asm "", "=r,0"(i64 %r5753.rs4i) #7
  %statepoint_token930 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r5753, double %r5752, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31207) ]
  %r5754931 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token930)
  %rs4gc.s50.relocated932 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token930, i32 0, i32 0) ; (%.31207, %.31207)
  %rs4gc.s56 = inttoptr i64 %r5754931 to ptr addrspace(1)
  %r5755.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s56 to i64
  %r5755 = call i64 asm "", "=r,0"(i64 %r5755.rs4i) #7
  %r5756 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5757 = icmp ne i32 %r5756, 0
  br i1 %r5757, label %shadow.root.barrier.1144, label %shadow.root.barrier.done.1145

anyeq.num.1142:                                   ; preds = %anyeq.diff.1137
  %r5740 = fcmp oeq double %r5723, %r5724
  br i1 %r5740, label %anyeq.true.1139, label %anyeq.false.1140

anyeq.tag.1143:                                   ; preds = %anyeq.diff.1137
  %r5741 = lshr i64 %r5725, 48
  %r5742 = lshr i64 %r5726, 48
  %r5743 = icmp eq i64 %r5741, 32761
  %r5744 = icmp eq i64 %r5742, 32761
  %r5745 = and i1 %r5743, %r5744
  %r5746 = icmp eq i64 %r5741, 32766
  %r5747 = icmp eq i64 %r5742, 32766
  %r5748 = and i1 %r5746, %r5747
  %r5749 = or i1 %r5745, %r5748
  br i1 %r5749, label %anyeq.false.1140, label %anyeq.slow.1138

shadow.root.barrier.1144:                         ; preds = %anyeq.merge.1141
  call void @js_write_barrier_root_nanbox(i64 %r5755) #7
  br label %shadow.root.barrier.done.1145

shadow.root.barrier.done.1145:                    ; preds = %shadow.root.barrier.1144, %anyeq.merge.1141
  %r5758.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s50.relocated932 to i64
  %r5758.rs4o = call i64 asm "", "=r,0"(i64 %r5758.rs4i) #7
  %r5758 = bitcast i64 %r5758.rs4o to double
  %r5759 = bitcast double %r5758 to i64
  %r5760 = and i64 %r5759, 281474976710655
  %r5761 = lshr i64 %r5759, 48
  %r5762 = and i64 %r5761, 65533
  %r5763 = icmp eq i64 %r5762, 32765
  br i1 %r5763, label %pget.recv_ok.1147, label %pget.recv_other.1151

pget.recv_sso.1146:                               ; preds = %pget.recv_other.1151
  %r5901 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r5902 = bitcast double %r5901 to i64
  %r5903 = and i64 %r5902, 281474976710655
  %statepoint_token933 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r5759, i64 %r5903, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s56) ]
  %r5904934 = call double @llvm.experimental.gc.result.f64(token %statepoint_token933)
  %rs4gc.s56.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token933, i32 0, i32 0) ; (%rs4gc.s56, %rs4gc.s56)
  br label %pget.recv_merge.1150

pget.recv_ok.1147:                                ; preds = %shadow.root.barrier.done.1145
  %r5770 = icmp ugt i64 %r5760, 1048575
  br i1 %r5770, label %pic.recv_hdr.1168, label %pic.miss.cold.1165

pget.recv_bad.1148:                               ; preds = %pget.check_class_ref.1152
  %r5893 = icmp eq i64 %r5759, 9222246136947933185
  %r5894 = icmp eq i64 %r5759, 9222246136947933186
  %r5895 = or i1 %r5893, %r5894
  br i1 %r5895, label %pget.throw_nullish.1175, label %pget.recv_undef_return.1176

pget.recv_class_ref.1149:                         ; preds = %pget.check_class_ref.1152
  %r5766 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r5767 = bitcast double %r5766 to i64
  %r5768 = and i64 %r5767, 281474976710655
  %statepoint_token935 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 367713371643969579, i64 %r5759, i64 %r5768, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s56) ]
  %r5769936 = call double @llvm.experimental.gc.result.f64(token %statepoint_token935)
  %rs4gc.s56.relocated937 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token935, i32 0, i32 0) ; (%rs4gc.s56, %rs4gc.s56)
  br label %pget.recv_merge.1150

pget.recv_merge.1150:                             ; preds = %pget.recv_undef_return.1176, %pic.merge.1167, %pget.recv_class_ref.1149, %pget.recv_sso.1146
  %.01210 = phi ptr addrspace(1) [ %.11211, %pic.merge.1167 ], [ %rs4gc.s56.relocated, %pget.recv_sso.1146 ], [ %rs4gc.s56.relocated937, %pget.recv_class_ref.1149 ], [ %rs4gc.s56.relocated949, %pget.recv_undef_return.1176 ]
  %r5905 = phi double [ %r5892, %pic.merge.1167 ], [ %r5900948, %pget.recv_undef_return.1176 ], [ %r5904934, %pget.recv_sso.1146 ], [ %r5769936, %pget.recv_class_ref.1149 ]
  %r5906.rs4i = ptrtoint ptr addrspace(1) %.01210 to i64
  %r5906 = call i64 asm "", "=r,0"(i64 %r5906.rs4i) #7
  %statepoint_token938 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r5906, double %r5905, i32 0, i32 0)
  %r5907939 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token938)
  %rs4gc.s57 = inttoptr i64 %r5907939 to ptr addrspace(1)
  %r5908.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s57 to i64
  %r5908 = call i64 asm "", "=r,0"(i64 %r5908.rs4i) #7
  %r5909 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5910 = icmp ne i32 %r5909, 0
  br i1 %r5910, label %shadow.root.barrier.1177, label %shadow.root.barrier.done.1178

pget.recv_other.1151:                             ; preds = %shadow.root.barrier.done.1145
  %r5764 = icmp eq i64 %r5761, 32761
  br i1 %r5764, label %pget.recv_sso.1146, label %pget.check_class_ref.1152

pget.check_class_ref.1152:                        ; preds = %pget.recv_other.1151
  %r5765 = icmp eq i64 %r5761, 32766
  br i1 %r5765, label %pget.recv_class_ref.1149, label %pget.recv_bad.1148

pic.hit.1153:                                     ; preds = %pic.token.1169
  %r5795 = getelementptr i64, ptr %r5780, i64 1
  %r5796 = load i64, ptr %r5795, align 8
  %r5797 = and i64 %r5796, 1073741824
  %r5798 = icmp ne i64 %r5797, 0
  br i1 %r5798, label %pic.hit.overflow.1170, label %pic.hit.inline.1171

pic.hit.live.1154:                                ; preds = %pic.hit.inline.1171
  br label %pic.merge.1167

pic.prefix.guard.1155:                            ; preds = %pic.token.1169
  %r5811 = getelementptr i64, ptr %r5780, i64 2
  %r5812 = load i64, ptr %r5811, align 8
  %r5813 = icmp ne i64 %r5812, 0
  br i1 %r5813, label %pic.prefix.meta.1156, label %pic.miss.1164

pic.prefix.meta.1156:                             ; preds = %pic.prefix.guard.1155
  %r5814 = add nuw nsw i64 %r5760, 8
  %r5815 = inttoptr i64 %r5814 to ptr
  %r5816 = load i64, ptr %r5815, align 8
  %r5817 = icmp ne i64 %r5816, 0
  br i1 %r5817, label %pic.prefix.token.1157, label %pic.miss.1164

pic.prefix.token.1157:                            ; preds = %pic.prefix.meta.1156
  %r5818 = inttoptr i64 %r5816 to ptr
  %r5819 = getelementptr i64, ptr %r5818, i64 6
  %r5820 = load i64, ptr %r5819, align 8
  %r5821 = icmp eq i64 %r5820, %r5812
  br i1 %r5821, label %pic.prefix.hit.1158, label %pic.miss.1164

pic.prefix.hit.1158:                              ; preds = %pic.prefix.token.1157
  %r5822 = getelementptr i64, ptr %r5780, i64 1
  %r5823 = load i64, ptr %r5822, align 8
  %r5824 = shl i64 %r5823, 3
  %r5825 = add nuw nsw i64 %r5760, 16
  %r5826 = add i64 %r5825, %r5824
  %r5827 = inttoptr i64 %r5826 to ptr
  %r5828 = load double, ptr %r5827, align 8
  br label %pic.merge.1167

pic.desc.classify.1159:                           ; preds = %pic.recv_hdr.1168
  %r5784 = and i1 %r5774, %r5781
  br i1 %r5784, label %pic.desc.prefix.guard.1160, label %pic.miss.cold.1165

pic.desc.prefix.guard.1160:                       ; preds = %pic.desc.classify.1159
  %r5829 = getelementptr i64, ptr %r5780, i64 2
  %r5830 = load i64, ptr %r5829, align 8
  %r5831 = icmp ne i64 %r5830, 0
  br i1 %r5831, label %pic.desc.prefix.meta.1161, label %pic.miss.cold.1165

pic.desc.prefix.meta.1161:                        ; preds = %pic.desc.prefix.guard.1160
  %r5832 = add nuw nsw i64 %r5760, 8
  %r5833 = inttoptr i64 %r5832 to ptr
  %r5834 = load i64, ptr %r5833, align 8
  %r5835 = icmp ne i64 %r5834, 0
  br i1 %r5835, label %pic.desc.prefix.token.1162, label %pic.miss.cold.1165

pic.desc.prefix.token.1162:                       ; preds = %pic.desc.prefix.meta.1161
  %r5836 = inttoptr i64 %r5834 to ptr
  %r5837 = getelementptr i64, ptr %r5836, i64 6
  %r5838 = load i64, ptr %r5837, align 8
  %r5839 = icmp eq i64 %r5838, %r5830
  br i1 %r5839, label %pic.desc.prefix.hit.1163, label %pic.miss.cold.1165

pic.desc.prefix.hit.1163:                         ; preds = %pic.desc.prefix.token.1162
  %r5840 = getelementptr i64, ptr %r5780, i64 1
  %r5841 = load i64, ptr %r5840, align 8
  %r5842 = shl i64 %r5841, 3
  %r5843 = add nuw nsw i64 %r5760, 16
  %r5844 = add i64 %r5843, %r5842
  %r5845 = inttoptr i64 %r5844 to ptr
  %r5846 = load double, ptr %r5845, align 8
  br label %pic.merge.1167

pic.miss.1164:                                    ; preds = %pic.hit.inline.1171, %pic.prefix.token.1157, %pic.prefix.meta.1156, %pic.prefix.guard.1155
  %r5847 = getelementptr i64, ptr %r5780, i64 3
  %r5848 = load i64, ptr %r5847, align 8
  %r5849 = icmp sgt i64 %r5848, 0
  br i1 %r5849, label %pic.ways.1172, label %pic.miss.call.1166

pic.miss.cold.1165:                               ; preds = %pic.desc.prefix.token.1162, %pic.desc.prefix.meta.1161, %pic.desc.prefix.guard.1160, %pic.desc.classify.1159, %pget.recv_ok.1147
  br label %pic.miss.call.1166

pic.miss.call.1166:                               ; preds = %pic.way.load.1173, %pic.ways.1172, %pic.miss.cold.1165, %pic.miss.1164
  %r5888 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r5889 = bitcast double %r5888 to i64
  %r5890 = and i64 %r5889, 281474976710655
  %statepoint_token940 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r5760, i64 %r5890, ptr @perry_ic_test_json_tape_batch_records_ts__44, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s56) ]
  %r5891941 = call double @llvm.experimental.gc.result.f64(token %statepoint_token940)
  %rs4gc.s56.relocated942 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token940, i32 0, i32 0) ; (%rs4gc.s56, %rs4gc.s56)
  br label %pic.merge.1167

pic.merge.1167:                                   ; preds = %pic.way.live.1174, %pic.hit.overflow.1170, %pic.miss.call.1166, %pic.desc.prefix.hit.1163, %pic.prefix.hit.1158, %pic.hit.live.1154
  %.11211 = phi ptr addrspace(1) [ %rs4gc.s56.relocated945, %pic.hit.overflow.1170 ], [ %rs4gc.s56.relocated942, %pic.miss.call.1166 ], [ %rs4gc.s56, %pic.way.live.1174 ], [ %rs4gc.s56, %pic.hit.live.1154 ], [ %rs4gc.s56, %pic.prefix.hit.1158 ], [ %rs4gc.s56, %pic.desc.prefix.hit.1163 ]
  %r5892 = phi double [ %r5808, %pic.hit.live.1154 ], [ %r5803944, %pic.hit.overflow.1170 ], [ %r5828, %pic.prefix.hit.1158 ], [ %r5846, %pic.desc.prefix.hit.1163 ], [ %r5885, %pic.way.live.1174 ], [ %r5891941, %pic.miss.call.1166 ]
  br label %pget.recv_merge.1150

pic.recv_hdr.1168:                                ; preds = %pget.recv_ok.1147
  %r5771 = sub nuw nsw i64 %r5760, 8
  %r5772 = inttoptr i64 %r5771 to ptr
  %r5773 = load i8, ptr %r5772, align 1
  %r5774 = icmp eq i8 %r5773, 2
  %r5775 = sub nuw nsw i64 %r5760, 6
  %r5776 = inttoptr i64 %r5775 to ptr
  %r5777 = load i16, ptr %r5776, align 2
  %r5778 = and i16 %r5777, 2048
  %r5779 = icmp eq i16 %r5778, 0
  %r5780 = load ptr, ptr @perry_ic_test_json_tape_batch_records_ts__44, align 8
  %r5781 = icmp ne ptr %r5780, null
  %r5782 = and i1 %r5774, %r5779
  %r5783 = and i1 %r5782, %r5781
  br i1 %r5783, label %pic.token.1169, label %pic.desc.classify.1159

pic.token.1169:                                   ; preds = %pic.recv_hdr.1168
  %r5785 = add nuw nsw i64 %r5760, 4
  %r5786 = inttoptr i64 %r5785 to ptr
  %r5787 = load i32, ptr %r5786, align 4
  %r5788 = zext i32 %r5787 to i64
  %r5789 = or i64 %r5788, 4611686018427387904
  %r5790 = icmp ne i32 %r5787, 0
  %r5791 = getelementptr i64, ptr %r5780, i64 0
  %r5792 = load i64, ptr %r5791, align 8
  %r5793 = icmp eq i64 %r5789, %r5792
  %r5794 = and i1 %r5793, %r5790
  br i1 %r5794, label %pic.hit.1153, label %pic.prefix.guard.1155

pic.hit.overflow.1170:                            ; preds = %pic.hit.1153
  %r5799 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r5800 = bitcast double %r5799 to i64
  %r5801 = and i64 %r5800, 281474976710655
  %r5802 = trunc i64 %r5796 to i32
  %statepoint_token943 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r5760, i64 %r5801, i32 %r5802, ptr @perry_ic_test_json_tape_batch_records_ts__44, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s56) ]
  %r5803944 = call double @llvm.experimental.gc.result.f64(token %statepoint_token943)
  %rs4gc.s56.relocated945 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token943, i32 0, i32 0) ; (%rs4gc.s56, %rs4gc.s56)
  br label %pic.merge.1167

pic.hit.inline.1171:                              ; preds = %pic.hit.1153
  %r5804 = shl i64 %r5796, 3
  %r5805 = add nuw nsw i64 %r5760, 16
  %r5806 = add i64 %r5805, %r5804
  %r5807 = inttoptr i64 %r5806 to ptr
  %r5808 = load double, ptr %r5807, align 8
  %r5809 = bitcast double %r5808 to i64
  %r5810 = icmp eq i64 %r5809, 9222246136947933200
  br i1 %r5810, label %pic.miss.1164, label %pic.hit.live.1154

pic.ways.1172:                                    ; preds = %pic.miss.1164
  %r5850 = getelementptr i64, ptr %r5780, i64 4
  %r5851 = load i64, ptr %r5850, align 8
  %r5852 = icmp eq i64 %r5851, %r5789
  %r5853 = getelementptr i64, ptr %r5780, i64 5
  %r5854 = load i64, ptr %r5853, align 8
  %r5855 = select i1 %r5852, i64 %r5854, i64 0
  %r5856 = getelementptr i64, ptr %r5780, i64 6
  %r5857 = load i64, ptr %r5856, align 8
  %r5858 = icmp eq i64 %r5857, %r5789
  %r5859 = getelementptr i64, ptr %r5780, i64 7
  %r5860 = load i64, ptr %r5859, align 8
  %r5861 = select i1 %r5858, i64 %r5860, i64 0
  %r5862 = getelementptr i64, ptr %r5780, i64 8
  %r5863 = load i64, ptr %r5862, align 8
  %r5864 = icmp eq i64 %r5863, %r5789
  %r5865 = getelementptr i64, ptr %r5780, i64 9
  %r5866 = load i64, ptr %r5865, align 8
  %r5867 = select i1 %r5864, i64 %r5866, i64 0
  %r5868 = getelementptr i64, ptr %r5780, i64 10
  %r5869 = load i64, ptr %r5868, align 8
  %r5870 = icmp eq i64 %r5869, %r5789
  %r5871 = getelementptr i64, ptr %r5780, i64 11
  %r5872 = load i64, ptr %r5871, align 8
  %r5873 = select i1 %r5870, i64 %r5872, i64 0
  %r5874 = or i1 %r5852, %r5858
  %r5875 = select i1 %r5852, i64 %r5855, i64 %r5861
  %r5876 = or i1 %r5864, %r5870
  %r5877 = select i1 %r5864, i64 %r5867, i64 %r5873
  %r5878 = or i1 %r5874, %r5876
  %r5879 = select i1 %r5874, i64 %r5875, i64 %r5877
  %r5880 = and i1 %r5790, %r5878
  br i1 %r5880, label %pic.way.load.1173, label %pic.miss.call.1166

pic.way.load.1173:                                ; preds = %pic.ways.1172
  %r5881 = shl i64 %r5879, 3
  %r5882 = add nuw nsw i64 %r5760, 16
  %r5883 = add i64 %r5882, %r5881
  %r5884 = inttoptr i64 %r5883 to ptr
  %r5885 = load double, ptr %r5884, align 8
  %r5886 = bitcast double %r5885 to i64
  %r5887 = icmp eq i64 %r5886, 9222246136947933200
  br i1 %r5887, label %pic.miss.call.1166, label %pic.way.live.1174

pic.way.live.1174:                                ; preds = %pic.way.load.1173
  br label %pic.merge.1167

pget.throw_nullish.1175:                          ; preds = %pget.recv_bad.1148
  %r5896 = zext i1 %r5894 to i32
  %statepoint_token946 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r5896, ptr @test_json_tape_batch_records_ts_.str.13.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.1176:                      ; preds = %pget.recv_bad.1148
  %r5897 = load double, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  %r5898 = bitcast double %r5897 to i64
  %r5899 = and i64 %r5898, 281474976710655
  %statepoint_token947 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r5759, i64 %r5899, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s56) ]
  %r5900948 = call double @llvm.experimental.gc.result.f64(token %statepoint_token947)
  %rs4gc.s56.relocated949 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token947, i32 0, i32 0) ; (%rs4gc.s56, %rs4gc.s56)
  br label %pget.recv_merge.1150

shadow.root.barrier.1177:                         ; preds = %pget.recv_merge.1150
  call void @js_write_barrier_root_nanbox(i64 %r5908) #7
  br label %shadow.root.barrier.done.1178

shadow.root.barrier.done.1178:                    ; preds = %shadow.root.barrier.1177, %pget.recv_merge.1150
  %r5911.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s57 to i64
  %r5911 = call i64 asm "", "=r,0"(i64 %r5911.rs4i) #7
  %statepoint_token950 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r5911, i32 0, i32 0)
  %statepoint_token951 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token952 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token953 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token954 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token955 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.1179

event_loop.header.1179:                           ; preds = %event_loop.body_wait.1184, %event_loop.body_check.1183, %shadow.root.barrier.done.1178
  %statepoint_token956 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_event_loop_host_driven, i32 0, i32 0, i32 0, i32 0)
  %r5916957 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token956)
  %r5917 = icmp ne i32 %r5916957, 0
  br i1 %r5917, label %event_loop.host_return.1181, label %event_loop.check_pending.1180

event_loop.check_pending.1180:                    ; preds = %event_loop.header.1179
  %statepoint_token958 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r5918959 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token958)
  %statepoint_token960 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r5919961 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token960)
  %statepoint_token962 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r5920963 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token962)
  %statepoint_token964 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r5921965 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token964)
  %statepoint_token966 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r5922967 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token966)
  %statepoint_token968 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r5923969 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token968)
  %r5924 = or i32 %r5918959, %r5919961
  %r5925 = or i32 %r5920963, %r5921965
  %r5926 = or i32 %r5925, %r5922967
  %r5927 = or i32 %r5924, %r5926
  %r5928 = or i32 %r5927, 0
  %r5929 = or i32 %r5928, %r5923969
  %r5930 = icmp ne i32 %r5929, 0
  br i1 %r5930, label %event_loop.body.1182, label %event_loop.exit.1185

event_loop.host_return.1181:                      ; preds = %event_loop.header.1179
  call void @js_typed_feedback_maybe_dump_trace() #7
  ret i32 0

event_loop.body.1182:                             ; preds = %event_loop.check_pending.1180
  %statepoint_token970 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token971 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.body_check.1183

event_loop.body_check.1183:                       ; preds = %event_loop.body.1182
  %statepoint_token972 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r5932973 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token972)
  %statepoint_token974 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r5933975 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token974)
  %statepoint_token976 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r5934977 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token976)
  %statepoint_token978 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r5935979 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token978)
  %statepoint_token980 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r5936981 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token980)
  %statepoint_token982 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r5937983 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token982)
  %r5938 = or i32 %r5932973, %r5933975
  %r5939 = or i32 %r5934977, %r5935979
  %r5940 = or i32 %r5939, %r5936981
  %r5941 = or i32 %r5938, %r5940
  %r5942 = or i32 %r5941, 0
  %r5943 = or i32 %r5942, %r5937983
  %r5944 = icmp ne i32 %r5943, 0
  br i1 %r5944, label %event_loop.body_wait.1184, label %event_loop.header.1179

event_loop.body_wait.1184:                        ; preds = %event_loop.body_check.1183
  %statepoint_token984 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_wait_for_event, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.1179

event_loop.exit.1185:                             ; preds = %event_loop.check_pending.1180
  %statepoint_token985 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_emit_before_exit_pending, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token986 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token987 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_exit_sequence, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token988 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_finalization_exit, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token989 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_promise_jobs, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token990 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_trace_events_flush_output, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token991 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_promise_report_unhandled_rejections, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token992 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_release_current_thread_collection_side_allocations, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token993 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_process_pending_exit_code, i32 0, i32 0, i32 0, i32 0)
  %r5947994 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token993)
  call void @js_typed_feedback_maybe_dump_trace() #7
  ret i32 %r5947994
}

; Function Attrs: optsize
define void @__perry_init_strings_test_json_tape_batch_records_ts_chunk0() #6 {
entry.0:
  %r1 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.0.bytes, i32 5)
  %r2 = call double @js_nanbox_string(i64 %r1)
  store double %r2, ptr @test_json_tape_batch_records_ts_.str.0.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.0.handle to i64))
  %r4 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.1.bytes, i32 1)
  %r5 = call double @js_nanbox_string(i64 %r4)
  store double %r5, ptr @test_json_tape_batch_records_ts_.str.1.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.1.handle to i64))
  %r7 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.2.bytes, i32 42)
  %r8 = call double @js_nanbox_string(i64 %r7)
  store double %r8, ptr @test_json_tape_batch_records_ts_.str.2.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.2.handle to i64))
  %r10 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.3.bytes, i32 11)
  %r11 = call double @js_nanbox_string(i64 %r10)
  store double %r11, ptr @test_json_tape_batch_records_ts_.str.3.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.3.handle to i64))
  %r13 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.4.bytes, i32 40)
  %r14 = call double @js_nanbox_string(i64 %r13)
  store double %r14, ptr @test_json_tape_batch_records_ts_.str.4.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.4.handle to i64))
  %r16 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.5.bytes, i32 41)
  %r17 = call double @js_nanbox_string(i64 %r16)
  store double %r17, ptr @test_json_tape_batch_records_ts_.str.5.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.5.handle to i64))
  %r19 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.6.bytes, i32 49)
  %r20 = call double @js_nanbox_string(i64 %r19)
  store double %r20, ptr @test_json_tape_batch_records_ts_.str.6.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.6.handle to i64))
  %r22 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.7.bytes, i32 47)
  %r23 = call double @js_nanbox_string(i64 %r22)
  store double %r23, ptr @test_json_tape_batch_records_ts_.str.7.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.7.handle to i64))
  %r25 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.8.bytes, i32 16)
  %r26 = call double @js_nanbox_string(i64 %r25)
  store double %r26, ptr @test_json_tape_batch_records_ts_.str.8.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.8.handle to i64))
  %r28 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.9.bytes, i32 62)
  %r29 = call double @js_nanbox_string(i64 %r28)
  store double %r29, ptr @test_json_tape_batch_records_ts_.str.9.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.9.handle to i64))
  %r31 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.10.bytes, i32 2)
  %r32 = call double @js_nanbox_string(i64 %r31)
  store double %r32, ptr @test_json_tape_batch_records_ts_.str.10.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.10.handle to i64))
  %r34 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.11.bytes, i32 3)
  %r35 = call double @js_nanbox_string(i64 %r34)
  store double %r35, ptr @test_json_tape_batch_records_ts_.str.11.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.11.handle to i64))
  %r37 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.12.bytes, i32 2)
  %r38 = call double @js_nanbox_string(i64 %r37)
  store double %r38, ptr @test_json_tape_batch_records_ts_.str.12.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.12.handle to i64))
  %r40 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.13.bytes, i32 4)
  %r41 = call double @js_nanbox_string(i64 %r40)
  store double %r41, ptr @test_json_tape_batch_records_ts_.str.13.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.13.handle to i64))
  %r43 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.14.bytes, i32 8)
  %r44 = call double @js_nanbox_string(i64 %r43)
  store double %r44, ptr @test_json_tape_batch_records_ts_.str.14.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.14.handle to i64))
  %r46 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.15.bytes, i32 4)
  %r47 = call double @js_nanbox_string(i64 %r46)
  store double %r47, ptr @test_json_tape_batch_records_ts_.str.15.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.15.handle to i64))
  %r49 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.16.bytes, i32 5)
  %r50 = call double @js_nanbox_string(i64 %r49)
  store double %r50, ptr @test_json_tape_batch_records_ts_.str.16.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.16.handle to i64))
  %r52 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.17.bytes, i32 4)
  %r53 = call double @js_nanbox_string(i64 %r52)
  store double %r53, ptr @test_json_tape_batch_records_ts_.str.17.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.17.handle to i64))
  %r55 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.18.bytes, i32 2)
  %r56 = call double @js_nanbox_string(i64 %r55)
  store double %r56, ptr @test_json_tape_batch_records_ts_.str.18.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.18.handle to i64))
  %r58 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.19.bytes, i32 6)
  %r59 = call double @js_nanbox_string(i64 %r58)
  store double %r59, ptr @test_json_tape_batch_records_ts_.str.19.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.19.handle to i64))
  %r61 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.20.bytes, i32 20)
  %r62 = call double @js_nanbox_string(i64 %r61)
  store double %r62, ptr @test_json_tape_batch_records_ts_.str.20.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.20.handle to i64))
  %r64 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.21.bytes, i32 20)
  %r65 = call double @js_nanbox_string(i64 %r64)
  store double %r65, ptr @test_json_tape_batch_records_ts_.str.21.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.21.handle to i64))
  %r67 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.22.bytes, i32 20)
  %r68 = call double @js_nanbox_string(i64 %r67)
  store double %r68, ptr @test_json_tape_batch_records_ts_.str.22.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.22.handle to i64))
  %r70 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.23.bytes, i32 8)
  %r71 = call double @js_nanbox_string(i64 %r70)
  store double %r71, ptr @test_json_tape_batch_records_ts_.str.23.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.23.handle to i64))
  %r73 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.24.bytes, i32 4)
  %r74 = call double @js_nanbox_string(i64 %r73)
  store double %r74, ptr @test_json_tape_batch_records_ts_.str.24.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.24.handle to i64))
  %r76 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.25.bytes, i32 5)
  %r77 = call double @js_nanbox_string(i64 %r76)
  store double %r77, ptr @test_json_tape_batch_records_ts_.str.25.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.25.handle to i64))
  %r79 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.26.bytes, i32 6)
  %r80 = call double @js_nanbox_string(i64 %r79)
  store double %r80, ptr @test_json_tape_batch_records_ts_.str.26.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.26.handle to i64))
  %r82 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.27.bytes, i32 15)
  %r83 = call double @js_nanbox_string(i64 %r82)
  store double %r83, ptr @test_json_tape_batch_records_ts_.str.27.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.27.handle to i64))
  %r85 = call i64 @js_string_from_bytes(ptr @test_json_tape_batch_records_ts_.str.28.bytes, i32 5)
  %r86 = call double @js_nanbox_string(i64 %r85)
  store double %r86, ptr @test_json_tape_batch_records_ts_.str.28.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_tape_batch_records_ts_.str.28.handle to i64))
  call void @js_register_function_name_static(ptr @__perry_wrap_perry_fn_test_json_tape_batch_records_ts__record, ptr @test_json_tape_batch_records_ts_.str.1, i32 6)
  call void @js_register_function_name_static(ptr @perry_fn_test_json_tape_batch_records_ts__record, ptr @test_json_tape_batch_records_ts_.str.1, i32 6)
  call void @js_register_function_source_static(ptr @__perry_wrap_perry_fn_test_json_tape_batch_records_ts__record, ptr @test_json_tape_batch_records_ts_.str.2, i32 760, i32 0)
  call void @js_register_closure_arity(ptr @__perry_wrap_perry_fn_test_json_tape_batch_records_ts__record, i32 1)
  call void @js_register_closure_length(ptr @__perry_wrap_perry_fn_test_json_tape_batch_records_ts__record, i32 1)
  call void @js_register_closure_strict_function(ptr @__perry_wrap_perry_fn_test_json_tape_batch_records_ts__record)
  ret void
}

; Function Attrs: optsize
define void @__perry_init_strings_test_json_tape_batch_records_ts() #6 {
entry.0:
  call void @__perry_init_strings_test_json_tape_batch_records_ts_chunk0()
  ret void
}

declare void @__tmp_use(...)

attributes #0 = { nounwind willreturn }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { optsize "frame-pointer"="non-leaf" }
attributes #7 = { "gc-leaf-function" }

!0 = !{}
