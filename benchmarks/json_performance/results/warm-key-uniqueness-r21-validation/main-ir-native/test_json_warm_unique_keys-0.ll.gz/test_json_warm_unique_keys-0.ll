; ModuleID = '/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/warm-key-uniqueness-r21/main-ir-native/test_json_warm_unique_keys/.perry-trace/llvm/test_json_warm_unique_keys_ts.ll'
source_filename = "perry_module"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx15.0.0"

module asm ".no_dead_strip __LLVM_StackMaps"

@test_json_warm_unique_keys_ts_.str.0 = private unnamed_addr constant [136 x i8] c"/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/warm-key-uniqueness-r21/test_json_warm_unique_keys.ts\00"
@test_json_warm_unique_keys_ts_.str.0.bytes = private unnamed_addr constant [2 x i8] c"a\00"
@test_json_warm_unique_keys_ts_.str.1.bytes = private unnamed_addr constant [2 x i8] c"b\00"
@test_json_warm_unique_keys_ts_.str.2.bytes = private unnamed_addr constant [2 x i8] c"c\00"
@test_json_warm_unique_keys_ts_.str.3.bytes = private unnamed_addr constant [2 x i8] c"d\00"
@test_json_warm_unique_keys_ts_.str.4.bytes = private unnamed_addr constant [2 x i8] c"e\00"
@test_json_warm_unique_keys_ts_.str.5.bytes = private unnamed_addr constant [2 x i8] c"f\00"
@test_json_warm_unique_keys_ts_.str.6.bytes = private unnamed_addr constant [2 x i8] c"g\00"
@test_json_warm_unique_keys_ts_.str.7.bytes = private unnamed_addr constant [2 x i8] c"h\00"
@test_json_warm_unique_keys_ts_.str.8.bytes = private unnamed_addr constant [50 x i8] c"{\22a\22:0,\22b\22:1,\22c\22:2,\22d\22:3,\22e\22:4,\22f\22:5,\22g\22:6,\22h\22:7}\00"
@test_json_warm_unique_keys_ts_.str.9.bytes = private unnamed_addr constant [2 x i8] c"\22\00"
@test_json_warm_unique_keys_ts_.str.10.bytes = private unnamed_addr constant [3 x i8] c"\22:\00"
@test_json_warm_unique_keys_ts_.str.11.bytes = private unnamed_addr constant [7 x i8] c"\22a\22:99\00"
@test_json_warm_unique_keys_ts_.str.12.bytes = private unnamed_addr constant [12 x i8] c"\22\\u0061\22:99\00"
@test_json_warm_unique_keys_ts_.str.13.bytes = private unnamed_addr constant [17 x i8] c"\22extra\22:9,\22a\22:99\00"
@test_json_warm_unique_keys_ts_.str.14.bytes = private unnamed_addr constant [30 x i8] c"\22nested\22:{\22a\22:1,\22a\22:2},\22a\22:99\00"
@test_json_warm_unique_keys_ts_.str.15.bytes = private unnamed_addr constant [2 x i8] c"{\00"
@test_json_warm_unique_keys_ts_.str.16.bytes = private unnamed_addr constant [2 x i8] c",\00"
@test_json_warm_unique_keys_ts_.str.17.bytes = private unnamed_addr constant [2 x i8] c"}\00"
@test_json_warm_unique_keys_ts_.str.18.bytes = private unnamed_addr constant [32 x i8] c"{\22a\22:0,\22b\22:{\22x\22:1,\22y\22:2},\22c\22:3}\00"
@test_json_warm_unique_keys_ts_.str.19.bytes = private unnamed_addr constant [51 x i8] c"{\22\\u0061\22:4,\22b\22:{\22other\22:8,\22other\22:9},\22c\22:5,\22a\22:6}\00"
@test_json_warm_unique_keys_ts_.str.20.bytes = private unnamed_addr constant [20 x i8] c"{\22a\22:7,\22b\22:8,\22c\22:9}\00"
@test_json_warm_unique_keys_ts_.str.21.bytes = private unnamed_addr constant [23 x i8] c"{\22a\22:10,\22b\22:11,\22a\22:12}\00"
@test_json_warm_unique_keys_ts_.str.22.bytes = private unnamed_addr constant [2 x i8] c"[\00"
@test_json_warm_unique_keys_ts_.str.23.bytes = private unnamed_addr constant [2 x i8] c"]\00"
@test_json_warm_unique_keys_ts_.str.24.bytes = private unnamed_addr constant [7 x i8] c"length\00"
@test_json_warm_unique_keys_ts_.str.25.bytes = private unnamed_addr constant [12 x i8] c"{\22records\22:\00"
@test_json_warm_unique_keys_ts_.str.26.bytes = private unnamed_addr constant [8 x i8] c"records\00"
@test_json_warm_unique_keys_ts_.str.27.bytes = private unnamed_addr constant [32 x i8] c"array and object roots disagree\00"
@test_json_warm_unique_keys_ts_.str.28.bytes = private unnamed_addr constant [6 x i8] c"round\00"
@test_json_warm_unique_keys_ts_.str.29.bytes = private unnamed_addr constant [5 x i8] c"done\00"
@test_json_warm_unique_keys_ts_.str.30.bytes = private unnamed_addr constant [6 x i8] c"value\00"
@test_json_warm_unique_keys_ts_.str.31.bytes = private unnamed_addr constant [9 x i8] c"retained\00"
@test_json_warm_unique_keys_ts_.str.32.bytes = private unnamed_addr constant [7 x i8] c"return\00"
@PERRY_SYMBOL_PROPERTY_IC_EPOCH = external global i64
@PERRY_GC_POLL_ARMED = external global i32
@PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD = external global [65536 x i8]
@PERRY_PER_OBJECT_LAYOUTS_ANY = external global i32
@PERRY_LAYOUT_ADDR_FILTER = external global [64 x i64]
@PERRY_YOUNG_LAYOUT_RECORDS = external global i32
@PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED = external global i8
@PERRY_ARRAY_PROTO_ITERATOR_PATCHED = external global i8
@PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT = external global i32
@PERRY_HOT_TSD_KEY = external global i64
@PERRY_TA_KIND_CACHE = external global [64 x i64]
@PERRY_U8_INLINE_CACHE = external global [64 x i64]
@PERRY_TA_VIEW_GUARD = external global i64
@perry_null_guard_zero_test_json_warm_unique_keys_ts = internal global i32 0
@perry_ic_test_json_warm_unique_keys_ts__5 = private global ptr null
@perry_ic_test_json_warm_unique_keys_ts__7 = private global ptr null
@perry_ic_test_json_warm_unique_keys_ts__8 = private global ptr null
@perry_ic_test_json_warm_unique_keys_ts__10 = private global ptr null
@perry_ic_test_json_warm_unique_keys_ts__12 = private global ptr null
@perry_ic_test_json_warm_unique_keys_ts__14 = private global ptr null
@perry_ic_test_json_warm_unique_keys_ts__16 = private global ptr null
@perry_ic_test_json_warm_unique_keys_ts__18 = private global ptr null
@perry_ic_test_json_warm_unique_keys_ts__20 = private global ptr null
@perry_ic_test_json_warm_unique_keys_ts__22 = private global ptr null
@test_json_warm_unique_keys_ts_.str.0.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.1.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.2.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.3.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.4.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.5.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.6.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.7.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.8.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.9.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.10.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.11.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.12.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.13.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.14.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.15.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.16.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.17.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.18.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.19.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.20.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.21.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.22.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.23.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.24.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.25.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.26.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.27.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.28.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.29.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.30.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.31.handle = internal global double 0.000000e+00
@test_json_warm_unique_keys_ts_.str.32.dispatch = private unnamed_addr constant { i32, i32, i64, ptr } { i32 6, i32 0, i64 -4195180554649555617, ptr @test_json_warm_unique_keys_ts_.str.32.bytes }
@test_json_warm_unique_keys_ts_.str.32.handle = internal global double 0.000000e+00

declare void @js_gc_init()

declare void @js_typed_feedback_maybe_dump_trace()

declare void @js_set_process_entry_path(ptr, i32)

declare void @js_stdlib_init_dispatch()

declare void @perry_app_group_init(ptr, i32)

declare void @perry_update_notify_startup(ptr, i32)

declare void @perry_macos_bundle_chdir()

declare i32 @perry_i18n_locale_index_for(i64, i32)

declare void @perry_i18n_init(ptr, ptr, i32, i32)

declare void @perry_i18n_set_currencies(ptr, i32)

declare i32 @perry_i18n_plural_category(i32, double)

declare void @js_register_function_name_static(ptr, ptr, i32)

declare void @js_register_function_name(ptr, ptr, i32)

declare void @js_register_function_source_static(ptr, ptr, i32, i32)

declare void @js_register_function_source(ptr, ptr, i32, i32)

declare void @js_console_log_dynamic(double)

declare void @js_console_log_number(double)

declare void @js_console_error_dynamic(double)

declare void @js_console_error_number(double)

declare void @js_console_warn_dynamic(double)

declare void @js_console_warn_number(double)

declare void @js_console_dir_with_options(double, double)

declare double @js_console_method_by_value(double)

declare double @js_nanbox_string(i64)

; Function Attrs: nounwind willreturn
declare double @js_nanbox_pointer(i64) #0

; Function Attrs: nounwind willreturn
declare i64 @js_nanbox_get_pointer(double) #0

declare double @js_native_handle_new_owned(i64, i64, i32, i32, ptr, ptr, i64)

declare double @js_native_handle_new_borrowed(i64, i64, i32, i32, ptr, i64)

declare i64 @js_native_handle_unwrap(double, i64, i32, i32, i32)

declare i64 @js_string_from_bytes(ptr, i32)

declare i64 @js_string_from_wtf8_bytes(ptr, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_is_truthy(double) #0

declare double @js_native_abi_check_f64(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_f64_arg_guard(double) #0

declare double @js_typed_f64_arg_to_raw(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_string_arg_guard(double) #0

declare i64 @js_typed_string_arg_to_raw(double)

declare i32 @js_param_type_guard(double, ptr, i32)

declare float @js_native_abi_check_f32(double)

declare i8 @js_native_abi_check_i8(double)

declare i16 @js_native_abi_check_i16(double)

declare i32 @js_native_abi_check_i32(double)

declare i64 @js_native_abi_check_i64(double)

declare i8 @js_native_abi_check_u8(double)

declare i16 @js_native_abi_check_u16(double)

declare i32 @js_native_abi_check_u32(double)

declare i64 @js_native_abi_check_u64(double)

declare i64 @js_native_abi_check_usize(double)

declare i64 @js_native_abi_check_isize(double)

declare double @js_native_abi_materialize_i64(i64)

declare double @js_native_abi_materialize_u64(i64)

declare i64 @js_native_abi_check_string_ptr(double)

declare i64 @js_native_abi_check_ptr(double)

declare ptr @js_native_abi_check_buffer_data_ptr(double)

declare i64 @js_native_abi_check_buffer_byte_len(double)

declare i64 @js_native_abi_check_promise(double)

declare i64 @js_native_abi_check_pod_object(double)

declare double @js_date_now()

declare void @js_gc_register_global_root(i64)

declare i64 @js_string_concat(i64, i64)

declare double @js_string_concat_box(double, double)

declare i64 @js_jsvalue_to_string(double)

declare i64 @js_jsvalue_to_string_method(double)

declare i64 @js_jsvalue_to_string_coerce(double)

declare i64 @js_string_concat_value(i64, double)

declare double @js_string_concat_site_value(i64, i64, double)

declare i64 @js_value_concat_string(double, i64)

declare double @js_string_concat_value_box(i64, double)

declare double @js_string_add_value(double, double)

declare double @js_value_add_string(double, double)

declare i64 @js_string_concat_chain(i64, i32)

declare i64 @js_string_append_chain(i64, i32)

declare i64 @js_string_append(i64, i64)

declare i64 @js_string_append_known_heap(i64, i64)

declare i32 @js_string_index_of(i64, i64)

declare i32 @js_string_index_of_from(i64, i64, i32)

declare i32 @js_string_position_to_index(double)

declare i64 @js_string_slice(i64, i32, i32)

declare i64 @js_string_substring(i64, i32, i32)

declare i64 @js_string_substr(i64, double, double)

declare i64 @js_string_split(i64, i64)

declare i64 @js_string_split_n(i64, i64, i32)

declare double @js_string_split_part_value(i64, i64, i32)

declare double @js_string_split_part_utf16_length(i64, i64, i32)

declare double @js_string_to_upper_case_split_part_utf16_length(i64, i64, i32)

declare i32 @js_string_to_upper_case_index_of(i64, i64)

declare i64 @js_string_split_value(i64, double, double)

declare double @js_math_trunc(double)

declare double @js_math_round(double)

declare double @js_math_sign(double)

declare double @js_math_imul(double, double)

declare double @js_math_pow(double, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.ceil.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.copysign.f64(double, double) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.aarch64.fjcvtzs(double) #3

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #5

declare i64 @js_json_stringify(double, i32)

declare i64 @js_map_alloc(i32)

declare i64 @js_text_encoder_encode_into_llvm(double, double)

declare i64 @js_value_typeof(double)

declare i32 @js_value_typeof_tag(double)

declare i32 @js_string_starts_with(i64, i64)

declare i32 @js_string_ends_with(i64, i64)

declare i64 @js_string_search_value_to_string(double, i32)

declare i32 @js_string_starts_with_at(i64, i64, i32)

declare i32 @js_string_ends_with_at(i64, i64, i32)

declare i64 @js_closure_alloc(ptr, i32)

declare i64 @js_closure_alloc_init(ptr, i32, ptr)

declare i64 @js_closure_alloc_singleton(ptr)

declare i64 @js_closure_alloc_with_captures_singleton(ptr, i32, ptr)

declare void @js_closure_set_capture_bits(i64, i32, i64)

declare void @js_closure_set_box_capture_ptr(i64, i32, i64)

declare i64 @js_closure_get_capture_bits(i64, i32)

declare void @js_closure_set_capture_f64(i64, i32, double)

declare double @js_closure_get_capture_f64(i64, i32)

declare void @js_register_closure_rest(ptr, i32)

declare void @js_register_closure_synthetic_arguments(ptr, i32)

declare void @js_register_closure_rest_and_arguments(ptr, i32)

declare void @js_register_closure_arity(ptr, i32)

declare void @js_register_closure_length(ptr, i32)

declare void @js_register_closure_arrow_function(ptr)

declare void @js_register_closure_trusted_direct(ptr, ptr, i32, i64)

declare void @js_register_closure_versioned_loop_direct(ptr, ptr, i32, i64)

declare ptr @js_closure_resolve_versioned_loop_direct_call(i64, i32)

declare void @js_register_closure_strict_function(ptr)

declare void @js_register_closure_async_function(ptr)

declare void @js_register_closure_generator_function(ptr)

declare void @js_register_closure_async_generator_function(ptr)

declare i64 @js_closure_unbox_callee_checked(double)

declare i64 @js_closure_unbox_callee_checked_rebind(double, double)

declare double @js_closure_call0(i64)

declare double @js_closure_call1(i64, double)

declare double @js_closure_call1_receiverless(i64, double)

declare double @js_closure_call2(i64, double, double)

declare double @js_closure_call3(i64, double, double, double)

declare ptr @js_closure_resolve_arrow_direct_call(i64, i32)

declare double @js_closure_call4(i64, double, double, double, double)

declare double @js_closure_call5(i64, double, double, double, double, double)

declare double @js_closure_call6(i64, double, double, double, double, double, double)

declare double @js_closure_call7(i64, double, double, double, double, double, double, double)

declare double @js_closure_call8(i64, double, double, double, double, double, double, double, double)

declare double @js_closure_call9(i64, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call10(i64, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call11(i64, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call12(i64, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call13(i64, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call14(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call15(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call16(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare i64 @js_array_map(i64, i64)

declare void @js_array_map_discard(i64, i64)

declare i64 @js_array_filter(i64, i64)

declare i64 @js_array_concat(i64, i64)

declare i64 @js_array_concat_new(i64, i64)

declare i64 @js_error_new()

declare i64 @js_error_new_with_message(i64)

declare i64 @js_error_new_from_value(double)

declare i64 @js_error_new_kind_from_value(i32, double)

declare i64 @js_error_new_with_cause_from_value(double, double)

declare i64 @js_error_new_kind_with_options_from_value(i32, double, double)

declare double @js_assert_assertion_error_ctor(double)

declare double @js_assert_assert_ctor(double)

declare void @js_throw_type_error_property_access(i32, ptr, i64)

declare void @js_throw_type_error_not_a_function(ptr, i64, ptr, i64)

declare void @js_throw_error_with_code(ptr, i64, ptr, i64, i32)

declare i64 @js_map_set(i64, double, double)

declare i64 @js_map_set_string_number(i64, i64, double)

declare i64 @js_map_set_string_key(i64, i64, double)

declare i64 @js_map_set_string_i32(i64, i64, i32)

declare i64 @js_map_set_string_u32(i64, i64, i32)

declare i64 @js_map_set_string_f32(i64, i64, float)

declare i64 @js_map_set_string_bool(i64, i64, i32)

declare i64 @js_map_set_string_string(i64, i64, i64)

declare i64 @js_map_set_number_key(i64, double, double)

declare double @js_map_get(i64, double)

declare double @js_declared_map_get(double, double)

declare double @js_map_get_string_key(i64, i64)

declare double @js_map_get_number_key(i64, double)

declare i32 @js_map_has(i64, double)

declare i32 @js_map_has_string_key(i64, i64)

declare i32 @js_map_has_number_key(i64, double)

declare i32 @js_map_delete(i64, double)

declare i32 @js_map_delete_string_key(i64, i64)

declare i32 @js_map_delete_number_key(i64, double)

declare i64 @js_object_keys(i64)

declare i64 @js_object_keys_value(double)

declare i64 @js_for_in_keys_value(double)

declare i64 @js_for_in_keys_stable_value(double)

declare double @js_is_finite(double)

declare i32 @js_is_undefined_or_bare_nan(double)

declare double @js_math_min_array(i64)

declare double @js_math_max_array(i64)

declare double @js_math_min2(double, double)

declare double @js_math_max2(double, double)

declare i64 @js_string_coerce(double)

declare i64 @js_string_coerce_method_this(double, ptr, i64)

declare i64 @js_array_slice(i64, i32, i32)

declare i64 @js_array_slice_values(i64, double, double)

declare double @js_array_shift_f64(i64)

declare i64 @js_set_alloc(i32)

declare i64 @js_set_from_array(i64)

declare i64 @js_set_from_iterable(double)

declare i64 @js_map_from_array(i64)

declare i64 @js_map_from_iterable(double)

declare double @js_object_has_property(double, double)

declare double @js_in_operator(double, double)

declare double @js_private_brand_check(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_guard(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_brand_add(double, i32)

declare double @js_private_field_add(double, i32, double, double)

declare double @js_class_field_add(double, double, double)

declare double @js_class_computed_field_key(double, i32, ptr, i64)

declare double @js_fs_to_unix_timestamp(double)

declare i32 @js_fs_write_file_sync(double, double)

declare i32 @js_fs_write_file_sync_options(double, double, double)

declare i32 @js_fs_append_file_sync(double, double)

declare i32 @js_fs_append_file_sync_options(double, double, double)

declare i32 @js_fs_exists_sync(double)

declare i64 @js_fs_read_file_sync(double)

declare double @js_fs_read_file_dispatch(double, double)

declare double @js_fs_open_as_blob(double, double)

declare double @js_fs_promises_read_file(double, double)

declare double @js_fs_promises_write_file(double, double, double)

declare double @js_fs_promises_append_file(double, double, double)

declare double @js_fs_promises_mkdir(double, double)

declare double @js_fs_promises_rmdir(double, double)

declare i32 @js_fs_mkdir_sync(double)

declare i32 @js_fs_mkdir_sync_options(double, double)

declare i32 @js_fs_unlink_sync(double)

declare double @js_fs_readdir_sync(double, double)

declare double @js_fs_stat_sync(double)

declare double @js_fs_stat_sync_options(double, double)

declare double @js_fs_lstat_sync(double)

declare double @js_fs_lstat_sync_options(double, double)

declare i32 @js_fs_rename_sync(double, double)

declare i32 @js_fs_copy_file_sync(double, double)

declare i32 @js_fs_copy_file_sync_flags(double, double, double)

declare i32 @js_fs_cp_sync(double, double)

declare i32 @js_fs_cp_sync_options(double, double, double)

declare i32 @js_fs_chmod_sync(double, double)

declare i32 @js_fs_chown_sync(double, double, double)

declare i32 @js_fs_lchown_sync(double, double, double)

declare i32 @js_fs_lchmod_sync(double, double)

declare i32 @js_fs_truncate_sync(double, double)

declare i32 @js_fs_ftruncate_sync(double, double)

declare i32 @js_fs_fsync_sync(double)

declare i32 @js_fs_fdatasync_sync(double)

declare i32 @js_fs_fchmod_sync(double, double)

declare i32 @js_fs_fchown_sync(double, double, double)

declare double @js_fs_fstat_sync(double)

declare double @js_fs_fstat_sync_options(double, double)

declare i32 @js_fs_utimes_sync(double, double, double)

declare i32 @js_fs_lutimes_sync(double, double, double)

declare i32 @js_fs_futimes_sync(double, double, double)

declare double @js_fs_readv_sync(double, double, double)

declare double @js_fs_writev_sync(double, double, double)

declare double @js_fs_statfs_sync(double)

declare double @js_fs_statfs_sync_options(double, double)

declare double @js_fs_opendir_sync(double)

declare double @js_fs_glob_sync(double)

declare double @js_fs_glob_sync_options(double, double)

declare i32 @js_fs_link_sync(double, double)

declare i32 @js_fs_symlink_sync(double, double)

declare double @js_fs_symlink_callback(double, double, double, double)

declare i64 @js_fs_readlink_sync(double)

declare i64 @js_fs_readlink_sync_options(double, double)

declare double @js_fs_readlink_dispatch(double, double)

declare double @js_fs_open_sync(double, double)

declare i32 @js_fs_close_sync(double)

declare double @js_fs_read_sync(double, double, double, double, double)

declare double @js_fs_read_sync_options(double, double, double)

declare double @js_fs_write_sync(double, double)

declare double @js_fs_write_string_sync_options(double, double, double)

declare double @js_fs_write_buffer_sync(double, double, double, double, double)

declare double @js_fs_write_sync_options_dispatch(double, double, double)

declare i32 @js_fs_access_sync(double)

declare i32 @js_fs_access_sync_mode(double, double)

declare double @js_fs_access_sync_throw(double)

declare double @js_fs_access_sync_throw_mode(double, double)

declare i64 @js_fs_realpath_sync(double)

declare double @js_fs_realpath_dispatch(double, double)

declare i64 @js_fs_mkdtemp_sync(double)

declare i64 @js_fs_mkdtemp_sync_options(double, double)

declare double @js_fs_mkdtemp_dispatch(double, double)

declare double @js_fs_mkdtemp_disposable_sync(double, double)

declare i32 @js_fs_rmdir_sync(double)

declare i32 @js_fs_rmdir_sync_options(double, double)

declare i32 @js_fs_rm_recursive(double)

declare i32 @js_fs_rm_recursive_options(double, double)

declare double @js_fs_create_write_stream(double, double)

declare double @js_fs_create_read_stream(double, double)

declare double @js_fs_utf8_stream_new(double)

declare double @js_fs_utf8_stream_call_without_new(double)

declare double @js_fs_utf8_stream_write(double, double)

declare double @js_fs_utf8_stream_flush(double, double)

declare double @js_fs_utf8_stream_flush_sync(double)

declare double @js_fs_utf8_stream_end(double, double)

declare double @js_fs_utf8_stream_destroy(double)

declare double @js_fs_utf8_stream_reopen(double, double)

declare double @js_fs_utf8_stream_on(double, double, double)

declare double @js_fs_utf8_stream_once(double, double, double)

declare double @js_fs_utf8_stream_off(double, double, double)

declare double @js_fs_utf8_stream_remove_all(double, double)

declare double @js_fs_utf8_stream_listener_count(double, double)

declare double @js_fs_utf8_stream_emit(double, double, double)

declare double @js_fs_read_file_callback(double, double, double)

declare double @js_fs_stats_is_file(double)

declare double @js_fs_stats_is_directory(double)

declare i64 @js_fs_read_file_binary(double)

declare double @js_number_coerce(double)

declare double @js_math_to_number(double)

declare i64 @js_set_add(i64, double)

declare i64 @js_set_add_string(i64, i64)

declare i64 @js_set_add_number(i64, double)

declare i64 @js_set_add_i32(i64, i32)

declare i64 @js_set_add_u32(i64, i32)

declare i64 @js_set_add_f32(i64, float)

declare i64 @js_set_add_bool(i64, i32)

declare i32 @js_set_has(i64, double)

declare double @js_readonly_set_has(double, double)

declare i32 @js_set_has_string(i64, i64)

declare i32 @js_set_has_number(i64, double)

declare i32 @js_set_has_i32(i64, i32)

declare i32 @js_set_has_u32(i64, i32)

declare i32 @js_set_has_f32(i64, float)

declare i32 @js_set_has_bool(i64, i32)

declare i32 @js_set_delete(i64, double)

declare i32 @js_set_delete_string(i64, i64)

declare i32 @js_set_delete_number(i64, double)

declare i32 @js_set_delete_i32(i64, i32)

declare i32 @js_set_delete_u32(i64, i32)

declare i32 @js_set_delete_f32(i64, float)

declare i32 @js_set_delete_bool(i64, i32)

declare i32 @js_set_size(i64)

declare i64 @js_set_union(i64, double)

declare i64 @js_set_intersection(i64, double)

declare i64 @js_set_difference(i64, double)

declare i64 @js_set_symmetric_difference(i64, double)

declare i32 @js_set_is_subset_of(i64, double)

declare i32 @js_set_is_superset_of(i64, double)

declare i32 @js_set_is_disjoint_from(i64, double)

declare i64 @js_string_to_lower_case(i64)

declare i64 @js_string_to_upper_case(i64)

declare i64 @js_string_to_locale_lower_case(i64, double)

declare i64 @js_string_to_locale_upper_case(i64, double)

declare void @js_string_validate_collator_args(double, double)

declare i64 @js_string_trim(i64)

declare i64 @js_string_trim_start(i64)

declare i64 @js_string_trim_end(i64)

declare i64 @js_string_big(i64)

declare i64 @js_string_blink(i64)

declare i64 @js_string_bold(i64)

declare i64 @js_string_fixed(i64)

declare i64 @js_string_italics(i64)

declare i64 @js_string_small(i64)

declare i64 @js_string_strike(i64)

declare i64 @js_string_sub(i64)

declare i64 @js_string_sup(i64)

declare i64 @js_string_anchor(i64, i64)

declare i64 @js_string_link(i64, i64)

declare i64 @js_string_fontcolor(i64, i64)

declare i64 @js_string_fontsize(i64, i64)

declare i64 @js_string_char_at(i64, i32)

declare double @js_string_index_get(i64, double)

declare double @js_string_index_get_boxed(double, double)

declare i32 @js_string_index_to_i32(double)

declare i32 @js_string_end_index_to_i32(double, i32)

declare double @js_typed_feedback_object_get_field_by_value_f64(i64, i64, double)

declare double @js_dyn_index_get(double, double)

declare double @js_packed_arraylike_index_get(double, double, ptr)

declare i32 @js_packed_arraylike_loop_guard(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_guard_live(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_revalidate_live(double, double, i32, ptr)

declare double @js_dyn_index_set(double, double, double)

declare double @js_dyn_index_set_strict(double, double, double, i32)

declare i64 @js_string_to_char_array(i64)

declare i64 @js_string_repeat(i64, double)

declare i64 @js_string_replace_string(i64, i64, i64)

declare i64 @js_string_replace_all_string(i64, i64, i64)

declare i32 @js_string_equals(i64, i64)

declare i32 @js_string_compare(i64, i64)

declare i32 @js_jsvalue_equals(double, double)

declare i32 @js_string_compare_value(double, double)

declare i64 @js_jsvalue_to_string_radix(double, double)

declare double @js_math_random()

declare double @js_webassembly_validate(double)

declare double @js_webassembly_compile(double)

declare double @js_webassembly_module_new(double)

declare double @js_webassembly_module_exports(double)

declare double @js_webassembly_module_imports(double)

declare double @js_webassembly_module_custom_sections(double, double)

declare double @js_webassembly_instantiate(double, double)

declare double @js_wasi_emit_warning()

declare double @js_webassembly_call_export_0(double, double)

declare double @js_webassembly_call_export_1(double, double, double)

declare double @js_webassembly_call_export_2(double, double, double, double)

declare double @js_webassembly_call_export_3(double, double, double, double, double)

declare double @js_webassembly_call_export_4(double, double, double, double, double, double)

declare void @js_console_log_spread(i64)

declare void @js_console_info_spread(i64)

declare void @js_console_debug_spread(i64)

declare void @js_console_error_spread(i64)

declare void @js_console_warn_spread(i64)

declare double @js_util_format(i64)

declare double @js_util_format_with_options(double, i64)

declare double @js_util_inspect(double, double)

declare double @js_util_debuglog(double, double)

declare double @js_util_diff(double, double)

declare double @js_util_inherits(double, double)

declare double @js_util_is_deep_strict_equal(double, double)

declare double @js_util_strip_vt_control_characters(double)

declare double @js_util_style_text(double, double, double)

declare double @js_util_get_call_sites(double, double)

declare double @js_util_promisify(double)

declare double @js_util_callbackify(double)

declare double @js_util_deprecate(double, double, double)

declare double @js_util_aborted(double, double)

declare double @js_util_transferable_abort_controller()

declare double @js_util_transferable_abort_signal(double)

declare double @js_util_parse_args(double)

declare double @js_boxed_number_new(double)

declare double @js_boxed_string_new(double, i32)

declare double @js_boxed_boolean_new(double)

declare double @js_util_types_is_arguments_object(double)

declare double @js_util_types_is_promise(double)

declare double @js_util_types_is_big_int_object(double)

declare double @js_util_types_is_symbol_object(double)

declare double @js_util_types_is_array_buffer(double)

declare double @js_util_types_is_shared_array_buffer(double)

declare double @js_util_types_is_any_array_buffer(double)

declare double @js_util_types_is_array_buffer_view(double)

declare double @js_util_types_is_data_view(double)

declare double @js_util_types_is_typed_array(double)

declare double @js_util_types_is_uint8_array(double)

declare double @js_util_types_is_int8_array(double)

declare double @js_util_types_is_int16_array(double)

declare double @js_util_types_is_uint16_array(double)

declare double @js_util_types_is_int32_array(double)

declare double @js_util_types_is_uint32_array(double)

declare double @js_util_types_is_float16_array(double)

declare double @js_util_types_is_float32_array(double)

declare double @js_util_types_is_float64_array(double)

declare double @js_util_types_is_uint8_clamped_array(double)

declare double @js_util_types_is_big_int64_array(double)

declare double @js_util_types_is_big_uint64_array(double)

declare double @js_util_types_is_map(double)

declare double @js_util_types_is_weak_map(double)

declare double @js_util_types_is_set(double)

declare double @js_util_types_is_weak_set(double)

declare double @js_util_types_is_date(double)

declare double @js_util_types_is_reg_exp(double)

declare double @js_util_types_is_async_function(double)

declare double @js_util_types_is_generator_function(double)

declare double @js_util_types_is_generator_object(double)

declare double @js_util_types_is_native_error(double)

declare double @js_util_types_is_number_object(double)

declare double @js_util_types_is_string_object(double)

declare double @js_util_types_is_boolean_object(double)

declare double @js_util_types_is_boxed_primitive(double)

declare double @js_util_types_is_external(double)

declare double @js_util_types_is_module_namespace_object(double)

declare double @js_util_types_is_key_object(double)

declare double @js_util_types_is_crypto_key(double)

declare double @js_util_types_is_proxy(double)

declare double @js_util_types_is_map_iterator(double)

declare double @js_util_types_is_set_iterator(double)

declare double @js_data_view_new(double, double, double)

declare double @js_data_view_get_direct(double, double, double, i32, i32)

declare double @js_data_view_set_direct(double, double, double, double, i32, i32)

declare i64 @js_getenv(i64)

declare double @js_getenv_value(i64)

declare void @js_setenv(i64, double)

declare void @js_removeenv(i64)

declare double @js_process_exit_code_get()

declare double @js_process_exit_code_set(double)

declare void @js_console_table(double)

declare void @js_console_table_with_properties(double, double)

declare void @js_console_trace(double)

declare void @js_console_trace_spread(i64)

declare i64 @js_process_cwd()

declare i64 @js_process_argv()

declare double @js_process_pid()

declare double @js_process_ppid()

declare double @js_process_uptime()

declare i64 @js_process_version()

declare double @js_process_versions()

declare double @js_process_memory_usage()

declare double @js_bigint_as_int_n_call(double, double)

declare double @js_bigint_as_uint_n_call(double, double)

declare double @js_v8_serialize(double)

declare double @js_v8_deserialize(double)

declare double @js_v8_get_heap_statistics()

declare double @js_v8_get_heap_code_statistics()

declare double @js_v8_get_heap_space_statistics()

declare double @js_v8_cached_data_version_tag()

declare double @js_v8_get_heap_snapshot(double)

declare double @js_v8_write_heap_snapshot(double, double)

declare double @js_v8_gc_profiler_new()

declare double @js_v8_gc_profiler_start(double)

declare double @js_v8_gc_profiler_stop(double)

declare double @js_v8_gc_profiler_report()

declare double @js_v8_serializer_new(double)

declare double @js_v8_deserializer_new(double)

declare double @js_v8_noop_undefined()

declare double @js_v8_is_building_snapshot()

declare double @js_v8_namespace(ptr, i64)

declare double @js_v8_throw_not_building_snapshot()

declare double @js_v8_promise_hook_register()

declare double @js_v8_promise_hooks_on_init(double)

declare double @js_v8_promise_hooks_on_before(double)

declare double @js_v8_promise_hooks_on_after(double)

declare double @js_v8_promise_hooks_on_settled(double)

declare double @js_v8_promise_hooks_create_hook(double)

declare double @js_process_thread_cpu_usage(double)

declare double @js_process_available_memory()

declare double @js_process_constrained_memory()

declare double @js_process_source_maps_enabled()

declare double @js_process_set_source_maps_enabled(double)

declare double @js_process_has_uncaught_exception_capture_callback()

declare double @js_process_set_uncaught_exception_capture_callback(double)

declare double @js_process_add_uncaught_exception_capture_callback(double)

declare double @js_process_getuid()

declare double @js_process_geteuid()

declare double @js_process_getgid()

declare double @js_process_getegid()

declare void @js_process_emit_warning(double, double, double)

declare double @js_process_cpu_usage(double)

declare double @js_process_resource_usage()

declare double @js_process_active_resources_info()

declare double @js_process_env()

declare double @js_process_hrtime_bigint()

declare double @js_process_hrtime(double)

declare double @js_process_title()

declare void @js_process_set_title(double)

declare void @js_process_chdir(i64)

declare void @js_process_chdir_jsv(double)

declare double @js_process_kill(double, double)

declare void @js_process_exit(double)

declare void @js_process_abort()

declare double @js_process_umask()

declare double @js_process_umask_set(double)

declare double @js_process_on(i64, i64)

declare double @js_process_add_listener(i64, i64)

declare double @js_process_once(i64, i64)

declare double @js_process_prepend_listener(i64, i64)

declare double @js_process_prepend_once_listener(i64, i64)

declare double @js_process_emit(i64, i64)

declare void @js_process_emit_before_exit(double)

declare void @js_process_emit_before_exit_pending()

declare void @js_process_run_exit_sequence()

declare void @js_process_run_finalization_exit()

declare void @js_trace_events_flush_output()

declare void @js_promise_report_unhandled_rejections()

declare i32 @js_process_pending_exit_code()

declare void @js_gc_release_current_thread_collection_side_allocations()

declare double @js_process_remove_listener(i64, i64)

declare double @js_process_off(i64, i64)

declare double @js_process_remove_all_listeners(i64)

declare double @js_process_listener_count(i64, i64)

declare i64 @js_process_listeners(i64)

declare i64 @js_process_raw_listeners(i64)

declare i64 @js_process_event_names()

declare double @js_process_set_max_listeners(double)

declare double @js_process_get_max_listeners()

declare double @js_process_get_builtin_module(double)

declare double @js_process_get_builtin_module_devirt(double)

declare double @js_process_execve(double, double, double)

declare double @js_module_is_builtin(double)

declare double @js_module_find_package_json(double, double, double)

declare double @js_module_find_source_map(double)

declare double @js_module_source_map_new(double, double)

declare double @js_module_register(double, double, double)

declare double @js_module_register_hooks(double)

declare void @js_process_next_tick(i64, i64)

declare double @js_process_stdin()

declare double @js_process_stdout()

declare double @js_process_stderr()

declare double @js_readline_set_raw_mode(double)

declare void @js_readline_stdin_on(i64, i64)

declare double @js_readline_stdin_remove_listener(i64, i64)

declare double @js_readline_stdin_pause()

declare double @js_readline_stdin_resume()

declare double @js_readline_stdin_unref()

declare double @js_readline_stdin_ref()

declare double @js_readline_stdin_destroy()

declare double @js_tty_isatty(double)

declare double @js_tty_read_stream_new(double)

declare double @js_tty_write_stream_new(double)

declare double @js_wasi_constructor_call(double)

declare double @js_process_stdin_isatty()

declare double @js_process_stdout_isatty()

declare double @js_process_stderr_isatty()

declare double @js_process_stdout_columns()

declare double @js_process_stdout_rows()

declare double @js_process_stdout_on(i64, i64)

declare i64 @js_os_platform()

declare i64 @js_os_arch()

declare i64 @js_os_type()

declare i64 @js_os_release()

declare i64 @js_os_hostname()

declare i64 @js_os_eol()

declare double @js_os_available_parallelism()

declare i64 @js_os_endianness()

declare i64 @js_os_dev_null()

declare i64 @js_os_machine()

declare i64 @js_os_loadavg()

declare i64 @js_os_version()

declare i64 @js_box_alloc_bits(i64)

declare i64 @js_box_get_bits(i64)

declare i64 @js_box_get_bits_named(i64, double)

declare void @js_box_set_bits(i64, i64)

declare i64 @js_box_get_bits_trusted(i64)

declare i64 @js_box_get_bits_trusted_named(i64, double)

declare void @js_box_set_bits_trusted_no_barrier(i64, i64)

declare i64 @js_box_alloc(double)

declare double @js_box_get(i64)

declare void @js_box_set(i64, double)

declare i64 @js_i32_box_alloc(i32)

declare i32 @js_i32_box_get(i64)

declare void @js_i32_box_set(i64, i32)

declare void @js_box_release(i64)

declare void @js_i32_box_release(i64)

declare void @js_bool_box_release(i64)

declare i64 @js_bool_box_alloc(i32)

declare i32 @js_bool_box_get(i64)

declare void @js_bool_box_set(i64, i32)

declare i64 @js_arguments_object_alloc(double, double, i32)

declare void @js_arguments_object_map_index(i64, i32, i64)

declare i64 @js_array_like_to_array(double)

declare i32 @js_object_get_class_id(i64)

declare i64 @js_object_alloc_with_parent(i32, i32, i32)

declare i64 @js_object_alloc_class_with_keys(i32, i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_dynamic_parent(i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_inline_keys(i32, i32, i32, i64)

declare i64 @js_object_alloc_class_inline_keys_stamped(i32, i32, i32, i64, i32)

declare i64 @js_build_class_keys_array(i32, i32, ptr, i32)

declare i32 @js_object_shape_id_for_keys(i64, i32)

declare i32 @js_gc_typed_shape_id_for_keys(i32, i64, i32, ptr, i32, ptr, i32)

declare ptr @js_inline_arena_state()

declare ptr @js_inline_arena_slow_alloc(ptr, i64, i64)

declare i32 @js_object_delete_field(i64, i64)

declare i32 @js_object_delete_field_value(double, i64)

declare i32 @js_object_delete_dynamic_value(double, double)

declare double @js_delete_result(i32, i32)

declare i64 @js_eq(i64, i64)

declare i64 @js_loose_eq(i64, i64)

declare i64 @js_number_to_fixed(double, double)

declare i64 @js_string_replace_regex(i64, i64, i64)

declare i64 @js_string_replace_all_regex(i64, i64, i64)

declare double @js_array_at(i64, double)

declare double @js_date_get_time(double)

declare double @js_date_get_full_year(double)

declare double @js_date_get_month(double)

declare double @js_date_get_date(double)

declare double @js_date_get_day(double)

declare double @js_date_get_hours(double)

declare double @js_date_get_minutes(double)

declare double @js_date_get_seconds(double)

declare double @js_date_get_milliseconds(double)

declare double @js_date_get_utc_day(double)

declare double @js_date_get_utc_full_year(double)

declare double @js_date_get_utc_month(double)

declare double @js_date_get_utc_date(double)

declare double @js_date_get_utc_hours(double)

declare double @js_date_get_utc_minutes(double)

declare double @js_date_get_utc_seconds(double)

declare double @js_date_get_utc_milliseconds(double)

declare double @js_date_value_of(double)

declare double @js_date_get_timezone_offset(double)

declare double @js_date_coerce_number(double)

declare double @js_rel_lt(double, double)

declare double @js_rel_le(double, double)

declare double @js_rel_gt(double, double)

declare double @js_rel_ge(double, double)

declare i64 @js_date_to_string(double)

declare i64 @js_date_to_iso_string(double)

declare i64 @js_date_to_iso_string_or_throw(double)

declare double @js_date_new_from_timestamp(double)

declare double @js_date_new_from_value(double)

declare i32 @js_array_indexOf_f64(i64, double)

declare i64 @js_array_indexOf_jsvalue(i64, double, double, i32)

declare i64 @js_array_last_index_of_jsvalue(i64, double, double, i32)

declare i32 @js_array_includes_f64(i64, double)

declare i32 @js_array_includes_jsvalue(i64, double, double, i32)

declare i32 @js_map_size(i64)

declare void @js_map_clear(i64)

declare void @js_set_clear(i64)

declare i64 @js_map_entries(i64)

declare i64 @js_map_keys(i64)

declare i64 @js_map_values(i64)

declare double @js_map_entry_key_at(i64, i32)

declare double @js_map_entry_value_at(i64, i32)

declare double @js_map_entry_key_raw_at(i64, i32)

declare double @js_map_entry_value_raw_at(i64, i32)

declare double @js_set_value_raw_at(i64, i32)

declare double @js_map_find_key_index(double, double)

declare double @js_set_find_value_index(double, double)

declare double @js_map_cursor_next(double, double, double)

declare double @js_map_compaction_epoch(double)

declare double @js_set_cursor_next(double, double, double)

declare double @js_set_compaction_epoch(double)

declare void @js_map_foreach(i64, double, double)

declare void @js_set_foreach(i64, double, double)

declare i64 @js_map_entries_iter_obj(i64)

declare i64 @js_map_keys_iter_obj(i64)

declare i64 @js_map_values_iter_obj(i64)

declare i64 @js_set_values_iter_obj(i64)

declare i64 @js_set_keys_iter_obj(i64)

declare i64 @js_set_entries_iter_obj(i64)

declare i64 @js_set_to_array(i64)

declare double @js_set_value_at(i64, i32)

declare i64 @js_array_splice(i64, i32, i32, ptr, i32, ptr)

declare i32 @js_array_splice_delete_count(double)

declare double @js_parse_int(i64, double)

declare double @js_parse_float(i64)

declare double @js_array_reduce(i64, i64, i32, double)

declare double @js_array_reduce_right(i64, i64, i32, double)

declare i64 @js_array_sort_default(i64)

declare i64 @js_array_reverse(i64)

declare double @js_array_reverse_value(double)

declare i64 @js_array_flat(i64)

declare i64 @js_array_flat_depth(i64, double)

declare i64 @js_array_flatMap(i64, i64)

declare i64 @js_array_sort_with_comparator(i64, i64)

declare i64 @js_validate_array_comparator(double)

declare i64 @js_validate_array_callback(double)

declare i64 @js_validate_array_map_callback(i64, double)

declare i64 @js_array_to_reversed(i64)

declare i64 @js_array_to_sorted_default(i64)

declare i64 @js_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_array_to_spliced(i64, double, double, ptr, i32)

declare i64 @js_array_with(i64, double, double)

declare i64 @js_array_copy_within(i64, double, double, i32, double)

declare double @js_array_copy_within_value(double, double, double, i32, double)

declare i64 @js_regexp_new(i64, i64)

declare i64 @js_regexp_new_site(i64, i64, i64)

declare i64 @js_regexp_new_factory_site(i64, i64, i64, i64)

declare i64 @js_regexp_site_test_new(i64, i64, i64)

declare double @js_regexp_site_factory_call_value(i64, double)

declare double @js_regexp_site_factory_call_method(i64, double, double)

declare double @js_regexp_site_test_get_method(i64, double)

declare double @js_regexp_site_test_dispatch(i64, double, double, double)

declare i64 @js_regexp_construct(double, double)

declare i64 @js_regexp_construct_call(double, double)

declare i32 @js_regexp_test(i64, i64)

declare double @js_regexp_escape(double)

declare i64 @js_get_string_pointer_unified(double)

declare i32 @js_switch_strict_equals(double, double)

declare i64 @js_value_to_str_ptr_for_ffi(double)

declare void @js_string_addref(i64)

declare void @js_string_addref_if_heap_string(double)

declare i64 @js_bigint_from_string(ptr, i32)

declare i64 @js_bigint_from_f64(double)

declare i64 @js_bigint_from_i128_parts(i64, i64)

declare i32 @js_bigint_cmp(i64, i64)

declare double @js_dynamic_add(double, double)

declare double @js_to_numeric(double)

declare double @js_numeric_step(double, i32)

declare i64 @js_box_capture_cell_ptr(i64)

declare double @js_dynamic_string_or_number_add(double, double)

declare double @js_dynamic_sub(double, double)

declare double @js_dynamic_mul(double, double)

declare double @js_dynamic_div(double, double)

declare double @js_dynamic_mod(double, double)

declare double @js_dynamic_bitand(double, double)

declare double @js_dynamic_bitor(double, double)

declare double @js_dynamic_bitxor(double, double)

declare double @js_dynamic_shl(double, double)

declare double @js_dynamic_shr(double, double)

declare double @js_dynamic_bitnot(double)

declare double @js_dynamic_pow(double, double)

declare double @js_dynamic_ushr(double, double)

declare double @js_instanceof(double, i32)

declare double @js_instanceof_dynamic(double, double)

declare double @js_instanceof_noncallable_rhs()

declare void @js_register_class_extends_error(i32)

declare void @js_register_class_extends_data_view(i32)

declare void @js_register_class_extends_typed_array(i32)

declare void @js_register_class_id(i32)

declare void @js_register_class_name(i32, ptr, i32)

declare void @js_register_class_source(i32, ptr, i32)

declare void @js_register_class_length(i32, i32)

declare void @js_register_anon_shape_class_id(i32)

declare double @js_get_global_this_builtin_value(ptr, i64)

declare double @js_promise_static_function_value(ptr, i64)

declare double @js_builtin_prototype_method_value(ptr, i64, ptr, i64)

declare void @js_register_class_parent(i32, i32)

declare void @js_register_class_generic_origin(i32, i32)

declare void @js_register_class_parent_dynamic(i32, double)

declare double @js_get_dynamic_parent_value(i32)

declare void @js_class_register_capture_values(i32, ptr, i64)

declare void @js_class_object_refresh_capture_values(double, i64, double)

declare void @js_tdz_suppress_begin()

declare void @js_tdz_suppress_end()

declare double @js_class_capture_value(i32, i32)

declare double @js_class_capture_value_for_receiver(double, i32, i32)

declare double @js_class_capture_value_or(i32, i32, double)

declare double @js_param_or_class_capture_value(double, i32, i32)

declare void @js_super_construct_apply(i32, double, double)

declare double @js_super_method_call_dynamic(i32, ptr, i64, double, ptr, i64)

declare double @js_super_method_call_dynamic_apply(i32, ptr, i64, double, double)

declare i64 @js_array_push_spread_any(i64, double)

declare i32 @js_set_function_prototype(double, double)

declare double @js_set_prototype_property(double, double, i32)

declare void @js_register_prototype_method(i32, ptr, i64, double)

declare i32 @js_register_function_prototype_method(double, ptr, i64, double)

declare double @js_new_function_construct(double, ptr, i64)

declare double @js_function_ctor_from_strings(ptr, i64)

declare double @js_new_function_construct_apply(double, double)

declare double @js_throw_not_a_constructor()

declare double @js_new_target_value()

declare double @js_get_function_prototype_method(double, ptr, i64)

declare double @js_function_prototype_value_for_read(double)

declare i64 @js_typeerror_new(i64)

declare i64 @js_rangeerror_new(i64)

declare i64 @js_syntaxerror_new(i64)

declare i64 @js_referenceerror_new(i64)

declare double @js_throw_symbol_constructor_type_error()

declare double @js_throw_bigint_constructor_type_error()

declare double @js_throw_strict_eval_arguments_syntax_error()

declare double @js_throw_eval_syntax_error(double)

declare double @js_throw_restricted_function_property_assignment()

declare double @js_throw_math_constructor_type_error()

declare double @js_throw_json_constructor_type_error()

declare double @js_webcrypto_illegal_constructor()

declare double @js_throw_type_error_const_assignment(double)

declare double @js_throw_reference_error_unresolvable_assignment(double)

declare double @js_throw_reference_error_unresolved_get()

declare double @js_with_implicit_unset()

declare double @js_with_implicit_read(double, double)

declare double @js_iterator_result_validate(double)

declare double @js_for_of_next(double)

declare double @js_segments_view_open(double, double)

declare double @js_segments_view_next(double)

declare double @js_segments_view_code_point_at(double, double)

declare double @js_segments_view_segment(double)

declare double @js_segments_view_regexp_test(double, double)

declare double @js_global_get_or_throw_unresolved(double)

declare double @js_module_ambient_require()

declare double @js_module_ambient_require_apply(double)

declare double @js_module_dynamic_import_fallback(double)

declare double @js_module_dynamic_import_deferred(double, double)

declare double @js_module_create_require_devirt(double)

declare double @js_global_get_optional(double)

declare double @js_global_update(double, double, double)

declare double @js_global_assign_existing_or_throw(double, double)

declare double @js_throw_reference_error_this_before_super()

declare double @js_throw_reference_error_super_delete()

declare double @js_throw_reference_error_unresolved_assignment()

declare i64 @js_evalerror_new(i64)

declare i64 @js_urierror_new(i64)

declare i64 @js_weakmap_new()

declare i64 @js_weakset_new()

declare double @js_weakmap_init_iterable(double, double)

declare double @js_weakset_init_iterable(double, double)

declare double @js_weakmap_set(double, double, double)

declare double @js_weakmap_get(double, double)

declare double @js_weakmap_has(double, double)

declare double @js_weakmap_delete(double, double)

declare double @js_weakset_add(double, double)

declare double @js_weakset_has(double, double)

declare double @js_weakset_delete(double, double)

declare double @js_weak_throw_primitive()

declare i64 @js_buffer_from_string(i64, i32)

declare i32 @js_encoding_tag_from_value(double)

declare i64 @js_value_to_string_with_encoding(double, i32)

declare i64 @js_value_to_string_with_encoding_or_radix(double, i32, double)

declare i64 @js_object_values(i64)

declare i64 @js_object_values_value(double)

declare i64 @js_object_entries(i64)

declare i64 @js_object_entries_value(double)

declare i64 @js_path_join(i64, i64)

declare i64 @js_path_win32_join(i64, i64)

declare i64 @js_path_win32_dirname(i64)

declare i64 @js_path_win32_basename(i64)

declare i64 @js_path_win32_basename_ext(i64, i64)

declare i64 @js_path_win32_extname(i64)

declare i32 @js_path_win32_is_absolute(i64)

declare i64 @js_path_win32_normalize(i64)

declare i64 @js_path_win32_parse(i64)

declare i64 @js_path_win32_format(double)

declare i64 @js_path_win32_relative(i64, i64)

declare i64 @js_path_win32_relative_checked(double, double)

declare i64 @js_path_win32_resolve(i64)

declare i64 @js_path_win32_resolve_join(i64, i64)

declare i64 @js_path_win32_to_namespaced_path(i64)

declare double @js_path_win32_to_namespaced_path_value(double)

declare i32 @js_path_win32_matches_glob(i64, i64)

declare i64 @js_path_win32_sep_get()

declare i64 @js_path_win32_delimiter_get()

declare i64 @js_path_dirname(i64)

declare i64 @js_path_resolve(i64)

declare i64 @js_path_relative(i64, i64)

declare i64 @js_path_relative_checked(double, double)

declare i64 @js_path_to_namespaced_path(i64)

declare double @js_path_to_namespaced_path_value(double)

declare i32 @js_path_matches_glob(i64, i64)

declare i64 @js_path_resolve_join(i64, i64)

declare i64 @js_path_arg_header(double)

declare i64 @js_path_join_value(double, double)

declare i64 @js_path_win32_join_value(double, double)

declare i64 @js_path_resolve_join_value(double, double)

declare i64 @js_path_win32_resolve_join_value(double, double)

declare i64 @js_path_basename_ext_value(double, double)

declare i64 @js_path_win32_basename_ext_value(double, double)

declare i32 @js_path_matches_glob_value(double, double)

declare i32 @js_path_win32_matches_glob_value(double, double)

declare double @js_object_from_entries(double)

declare i64 @js_string_match(i64, i64)

declare i64 @js_string_match_all(i64, i64)

declare i64 @js_string_match_all_value(i64, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log2.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log10.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.exp.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sin.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.cos.f64(double) #1

declare i64 @js_path_basename(i64)

declare i64 @js_path_basename_ext(i64, i64)

declare i64 @js_path_extname(i64)

declare i64 @js_path_sep_get()

declare i64 @js_path_delimiter_get()

declare i64 @js_path_parse(i64)

declare i64 @js_json_parse(i64)

declare i64 @js_json_text_to_string(double)

declare double @js_json_raw_json(double)

declare double @js_json_is_raw_json(double)

declare i64 @js_json_parse_or_null(i64)

declare i64 @js_json_parse_typed_array(i64, i64, i32, i32)

declare i64 @js_date_to_date_string(double)

declare i64 @js_date_to_time_string(double)

declare i64 @js_date_to_utc_string(double)

declare i64 @js_date_to_locale_date_string(double)

declare i64 @js_date_to_locale_time_string(double)

declare i64 @js_date_to_json(double)

declare i64 @js_regexp_exec(i64, i64)

declare i64 @js_number_to_precision(double, double)

declare i64 @js_number_to_exponential(double, double)

declare double @js_date_new()

declare double @js_number_is_integer(double)

declare double @js_number_is_nan(double)

declare double @js_number_is_safe_integer(double)

declare double @js_date_parse(i64)

declare double @js_date_utc(ptr, i32)

declare double @js_date_new_local_components(double, double, double, double, double, double, double)

declare double @js_date_apply_setter(double, i32, i32, ptr, i32)

declare double @js_math_clz32(double)

declare double @js_math_cbrt(double)

declare double @js_math_fround(double)

declare double @js_math_f16round(double)

declare double @js_math_sinh(double)

declare double @js_math_cosh(double)

declare double @js_math_tanh(double)

declare double @js_math_asinh(double)

declare double @js_math_acosh(double)

declare double @js_math_atanh(double)

declare double @js_math_hypot(double, double)

declare double @js_object_is(double, double)

declare i64 @js_path_normalize(i64)

declare i64 @js_path_format(double)

declare i32 @js_path_is_absolute(i64)

declare i64 @js_encode_uri(double)

declare i64 @js_decode_uri(double)

declare i64 @js_encode_uri_component(double)

declare i64 @js_decode_uri_component(double)

declare i64 @js_text_encoder_new()

declare i64 @js_text_decoder_new(double, double, double)

declare i64 @js_text_encoder_encode_llvm(double)

declare i64 @js_text_decoder_decode_llvm(double, double)

declare i64 @js_text_decoder_encoding(double)

declare double @js_text_decoder_fatal(double)

declare double @js_text_decoder_ignore_bom(double)

declare void @js_queue_microtask(i64)

declare void @js_queue_next_tick(i64)

declare void @js_queue_next_tick_args(i64, ptr, i32)

declare void @js_drain_queued_microtasks()

declare i64 @js_uint8array_from_array(i64)

declare i64 @js_uint8array_alloc(i32)

declare i64 @js_uint8array_new(double)

declare i64 @js_uint8array_view(double, double, double)

declare i64 @js_typed_array_new_empty(i32, i32)

declare i64 @js_typed_array_new_from_array(i32, i64)

declare i64 @js_typed_array_new(i32, double)

declare i64 @js_typed_array_view(i32, double, double, double)

declare i32 @js_typed_array_length(i64)

declare double @js_typed_array_get(i64, i32)

declare i32 @js_typed_array_read_int32(i64, i32)

declare double @js_typed_array_read_f64(i64, i32)

declare double @js_u8_buffer_read_f64(i64, i32)

declare double @js_typed_array_index_get_dynamic(i64, double)

declare double @js_typed_array_at(i64, double)

declare void @js_typed_array_set(i64, i32, double)

declare double @js_typed_array_index_set_dynamic(i64, double, double)

declare i32 @js_uint8array_get(i64, i32)

declare double @js_uint8array_index_get_value(i64, i32)

declare void @js_uint8array_set(i64, i32, i32)

declare i64 @js_native_arena_alloc(i64)

declare i64 @js_native_arena_view(i64, i32, i64, i64)

declare i64 @js_native_pod_view(i64, i64, i64, i64, i64, i64)

declare double @js_native_pod_view_length(double)

declare ptr @js_native_abi_check_pod_view_data_ptr(double, i64)

declare i64 @js_native_abi_check_pod_view_record_count(double, i64)

declare void @js_native_arena_dispose(i64)

declare void @js_native_memory_fill_u32(i64, double)

declare void @js_native_memory_copy(i64, i64)

declare i64 @js_typed_array_to_reversed(i64)

declare i64 @js_typed_array_to_sorted_default(i64)

declare i64 @js_typed_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_typed_array_with(i64, double, double)

declare double @js_typed_array_find_last(i64, i64)

declare double @js_typed_array_find_last_index(i64, i64)

declare double @js_typed_array_set_from(i64, double, double)

declare i64 @js_typed_array_subarray(i64, i32, double, i32, double)

declare double @js_object_has_own(double, double)

declare double @js_object_property_is_enumerable(double, double)

declare double @js_object_define_getter(double, double, double)

declare double @js_object_define_setter(double, double, double)

declare double @js_object_lookup_getter(double, double)

declare double @js_object_lookup_setter(double, double)

declare double @js_object_get_own_field_or_undef(double, ptr, i64)

declare double @js_unresolved_namespace_stub()

declare double @js_node_submodule_export_as_function(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace_member(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace(ptr, i32)

declare void @js_node_submod_install_vm()

declare void @js_node_submod_install_timers()

declare void @js_node_submod_install_timers_promises()

declare void @js_node_submod_install_fs_promises()

declare void @js_node_submod_install_readline_promises()

declare void @js_node_submod_install_stream_promises()

declare void @js_node_submod_install_stream_consumers()

declare void @js_node_submod_install_stream_web()

declare void @js_node_submod_install_hono_jsx_server()

declare void @js_node_submod_install_hono_jsx_streaming()

declare void @js_node_submod_install_sys()

declare void @js_node_submod_install_diagnostics_channel()

declare void @js_node_submod_install_trace_events()

declare void @js_node_submod_install_test()

declare void @js_node_submod_install_test_reporters()

declare void @js_node_submod_install_all()

declare void @js_node_submod_enable_install_all()

declare double @js_unresolved_default_call()

declare double @js_get_global_this()

declare double @js_module_top_this()

declare double @js_global_or_console_property_by_name(i64)

declare void @js_class_register_static_symbol(i32, double, double)

declare void @js_register_class_computed_method(i64, double, i64, i64, i64, i64, i64)

declare void @js_register_class_computed_accessor(i64, double, i64, i64, i64, i64)

declare void @js_class_register_static_field(i32, ptr, i64, double, ptr)

declare double @js_object_define_property(double, double, double)

declare double @js_object_define_get_accessor(double, double, double)

declare double @js_object_get_own_property_descriptor(double, double)

declare double @js_object_get_own_property_descriptors(double)

declare double @js_object_get_own_property_names(double)

declare double @js_symbol_new(double)

declare double @js_symbol_new_empty()

declare double @js_symbol_for(double)

declare double @js_symbol_computed_member(double, double)

declare double @js_symbol_key_for(double)

declare double @js_symbol_description(double)

declare i64 @js_symbol_to_string(double)

declare i32 @js_symbol_equals(double, double)

declare i32 @js_is_symbol(double)

declare i64 @js_object_get_own_property_symbols(double)

declare double @js_object_set_symbol_property(double, double, double)

declare double @js_to_property_key(double)

declare double @js_object_set_property_key(double, double, double)

declare double @js_object_get_property_key(double, double)

declare double @js_object_set_property_key_method(double, double, double)

declare double @js_object_super_get(double, double, double)

declare double @js_object_super_put_value_set(double, double, double, double, i32)

declare double @js_object_super_call(double, double, double, ptr, i64)

declare double @js_object_literal_infer_computed_function_name(double, double)

declare double @js_object_get_symbol_property(double, double)

declare double @js_object_get_symbol_property_ic_miss(double, double, ptr)

declare double @js_object_get_symbol_then_field_ic_miss(double, double, ptr, i64, ptr, ptr)

declare double @js_object_create(double)

declare double @js_object_create_with_props(double, double)

declare double @js_object_freeze(double)

declare double @js_object_seal(double)

declare double @js_object_prevent_extensions(double)

declare void @js_object_copy_own_fields(i64, double)

declare double @js_object_assign_validate_target(double)

declare double @js_object_assign_one(double, double)

declare double @js_string_at(i64, i32)

declare double @js_string_code_point_at(i64, i32)

declare i64 @js_string_from_code_point(double)

declare i64 @js_string_raw(double, double)

declare i64 @js_string_from_char_code(double)

declare i64 @js_string_from_char_code_array(double)

declare double @js_string_char_code_at(i64, i32)

declare i32 @js_string_last_index_of(i64, i64)

declare i32 @js_string_last_index_of_from(i64, i64, double, i32)

declare double @js_string_locale_compare(i64, i64)

declare double @js_string_locale_compare_opts(i64, i64, double)

declare i64 @js_string_normalize(i64, double)

declare i64 @js_string_pad_start(i64, double, i64)

declare i64 @js_string_pad_end(i64, double, i64)

declare i64 @js_string_pad_fill(double)

declare double @js_string_is_well_formed(i64)

declare i64 @js_string_to_well_formed(i64)

declare i32 @js_string_search_regex(i64, i64)

declare i32 @js_string_search_value(i64, double)

declare i64 @js_string_match_value(i64, double)

declare double @js_regexp_exec_get_index()

declare i64 @js_regexp_exec_get_groups()

declare double @js_regexp_get_last_index(i64)

declare void @js_regexp_set_last_index(i64, double)

declare i64 @js_regexp_get_source(i64)

declare i64 @js_regexp_get_flags(i64)

declare i64 @js_string_replace_regex_named(i64, i64, i64)

declare i64 @js_string_replace_all_regex_named(i64, i64, i64)

declare i64 @js_string_replace_string_fn(i64, i64, double)

declare i64 @js_string_replace_string_dyn(i64, i64, double)

declare i64 @js_string_replace_all_string_dyn(i64, i64, double)

declare i64 @js_string_replace_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_all_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_string_fn(i64, i64, double)

declare i64 @js_string_replace_regex_fn(i64, i64, double)

declare i64 @js_string_replace_all_regex_fn(i64, i64, double)

declare double @js_structured_clone(double)

declare double @js_structured_clone_with_options(double, double)

declare double @js_generator_attach_prototype(double, i32)

declare double @js_generator_attach_closure_prototype(double, i64)

declare i64 @js_weakref_new(double)

declare double @js_weakref_deref(double)

declare i64 @js_finreg_new(double)

declare double @js_finreg_register(double, double, double, double)

declare double @js_finreg_unregister(double, double)

declare i64 @js_atob(double)

declare i64 @js_btoa(double)

declare double @js_object_is_frozen(double)

declare double @js_object_is_sealed(double)

declare double @js_object_is_extensible(double)

declare i64 @js_aggregateerror_new(i64, i64)

declare i64 @js_error_new_with_cause(i64, double)

declare i64 @js_aggregateerror_new_full(double, i64, double)

declare i64 @js_error_new_kind_with_options(i32, i64, double)

declare double @js_error_is_error(double)

declare i64 @js_error_get_errors(i64)

declare i64 @js_crypto_sha256(i64)

declare i64 @js_crypto_sha256_bytes(i64)

declare i64 @js_crypto_md5(i64)

declare i64 @js_crypto_hmac_sha256(i64, i64)

declare i64 @js_crypto_hmac_sha256_bytes(i64, i64)

declare void @js_runtime_validate_string_arg(double, ptr, i32)

declare void @js_set_call_location(ptr, i64, i32)

declare void @js_runtime_validate_crypto_key_arg(double, ptr, i32)

declare void @js_runtime_validate_integer_arg(double, ptr, i32, double, double)

declare i64 @js_crypto_pbkdf2_bytes(i64, i64, double, double, i64)

declare double @js_crypto_pbkdf2_async_alg(i64, i64, double, double, i64, double)

declare i64 @js_crypto_argon2_sync(i64, double)

declare double @js_crypto_argon2_async(i64, double, double)

declare i64 @js_crypto_encapsulate(double)

declare double @js_crypto_encapsulate_async(double, double)

declare i64 @js_crypto_decapsulate(double, double)

declare double @js_crypto_decapsulate_async(double, double, double)

declare i64 @js_crypto_hkdf_bytes_alg(i64, i64, i64, i64, double)

declare double @js_crypto_hkdf_async_alg(i64, i64, i64, i64, double, double)

declare i64 @js_crypto_scrypt_bytes(i64, i64, double, double)

declare double @js_crypto_scrypt_async(i64, i64, double, double, double)

declare i64 @js_crypto_sign_rsa_sha256(i64, i64, double)

declare double @js_crypto_sign_async(i64, i64, double, double)

declare double @js_crypto_verify_rsa_sha256(i64, i64, double, i64)

declare double @js_crypto_verify_async(i64, i64, double, i64, double)

declare i64 @js_crypto_public_encrypt(i64, i64)

declare i64 @js_crypto_private_decrypt(i64, i64)

declare i64 @js_crypto_private_encrypt(i64, i64)

declare i64 @js_crypto_public_decrypt(i64, i64)

declare i64 @js_crypto_create_public_key(i64)

declare i64 @js_crypto_create_private_key_value(double)

declare i64 @js_crypto_create_public_key_value(double)

declare i64 @js_crypto_generate_key_pair_sync_rsa(double)

declare i64 @js_crypto_generate_key_pair_sync_ec_p256(double)

declare i64 @js_crypto_generate_key_pair_sync_ed25519(double)

declare i64 @js_crypto_generate_key_pair_sync_x25519(double)

declare double @js_crypto_generate_key_pair_async(i64, double, double)

declare i64 @js_crypto_diffie_hellman(double)

declare double @js_crypto_get_cipher_info(double, double)

declare i64 @js_crypto_get_curves()

declare i64 @js_crypto_secure_heap_used()

declare i64 @js_crypto_random_bytes_buffer(double)

declare double @js_crypto_random_bytes_async(double, double)

declare i64 @js_crypto_random_uuid(double)

declare i64 @js_crypto_random_uuidv7()

declare double @js_crypto_random_int(double, double)

declare double @js_crypto_random_int_async(double, double, double)

declare double @js_crypto_timing_safe_equal(double, double)

declare i64 @js_crypto_get_hashes()

declare i64 @js_crypto_get_ciphers()

declare double @js_crypto_generate_prime_sync(double, double)

declare double @js_crypto_generate_prime_async(double, double, double)

declare double @js_crypto_check_prime_sync(double, double)

declare double @js_crypto_check_prime_async(double, double, double)

declare i64 @js_crypto_create_secret_key(i64, i64)

declare i64 @js_crypto_generate_key_sync(i64, double)

declare double @js_crypto_generate_key_async(i64, double, double)

declare i64 @js_webcrypto_digest(double, double)

declare i64 @js_webcrypto_import_key(double, double, double, double, double)

declare i64 @js_webcrypto_export_key(double, double)

declare i64 @js_webcrypto_sign(double, double, double)

declare i64 @js_webcrypto_verify(double, double, double, double)

declare i64 @js_webcrypto_derive_bits(double, double, double)

declare i64 @js_webcrypto_derive_key(double, double, double, double, double)

declare i64 @js_webcrypto_encrypt(double, double, double)

declare i64 @js_webcrypto_decrypt(double, double, double)

declare i64 @js_webcrypto_generate_key(double, double, double)

declare i64 @js_webcrypto_wrap_key(double, double, double, double)

declare i64 @js_webcrypto_unwrap_key(double, double, double, double, double, double, double)

declare i64 @js_zlib_create_brotli_decompress(double)

declare double @js_crypto_random_fill_sync(double, double, double)

declare double @js_crypto_random_fill_async(double, double, double, double)

declare double @js_crypto_create_hash(i64)

declare double @js_crypto_create_hash_options(i64, double)

declare double @js_crypto_x509_new(i64)

declare double @js_crypto_certificate_verify_spkac(double)

declare double @js_crypto_certificate_export_public_key(double)

declare double @js_crypto_certificate_export_challenge(double)

declare double @js_crypto_create_sign(i64)

declare double @js_crypto_create_verify(i64)

declare double @js_crypto_create_ecdh(i64)

declare double @js_crypto_create_diffie_hellman(double, double, double)

declare double @js_crypto_get_diffie_hellman(double)

declare double @js_crypto_ecdh_convert_key(double, double, double, double, double)

declare double @js_crypto_create_hmac(i64, i64)

declare i64 @js_buffer_alloc(i32, i32)

declare i64 @js_buffer_alloc_fill_value(i32, double, i32)

declare i64 @js_array_buffer_new(i32)

declare i64 @js_shared_array_buffer_new(i32)

declare i64 @js_array_buffer_new_value(double)

declare i64 @js_shared_array_buffer_new_value(double)

declare i64 @js_json_stringify_full(double, double, double)

declare i64 @js_json_parse_with_reviver(i64, i64)

declare double @js_array_find(i64, i64)

declare i32 @js_array_findIndex(i64, i64)

declare double @js_array_find_last(i64, i64)

declare i32 @js_array_find_last_index(i64, i64)

declare double @js_array_some(i64, i64)

declare double @js_array_some_captureless(i64, ptr)

declare double @js_array_every(i64, i64)

declare i32 @js_promise_state(i64)

declare double @js_promise_value(i64)

declare double @js_promise_reason(i64)

declare i32 @js_value_is_promise(double)

declare double @js_assimilate_thenable(double)

declare i32 @js_promise_run_microtasks()

declare i32 @js_promise_run_microtasks_event_loop()

declare i32 @js_promise_run_microtasks_await_loop()

declare i32 @js_await_loop_tick_timers()

declare void @js_mark_entry_module_esm()

declare i32 @js_promise_run_promise_jobs()

declare void @js_run_stdlib_pump()

declare void @js_sleep_ms(double)

declare void @js_wait_for_event()

declare i32 @js_event_loop_host_driven()

declare void @js_unsettled_top_level_await_exit()

declare void @js_throw(double)

declare void @js_eh_try_push()

declare i32 @perry_eh_personality(...)

declare void @js_try_end()

declare double @js_get_exception()

declare void @js_clear_exception()

declare i32 @js_has_exception()

declare void @js_enter_finally()

declare void @js_leave_finally()

declare double @js_await_any_promise(double)

declare i64 @js_promise_new()

declare i64 @js_promise_new_with_executor(i64)

declare i32 @js_timer_tick()

declare i32 @js_timer_tick_if_refed()

declare i32 @js_callback_timer_tick()

declare i32 @js_interval_timer_tick()

declare i32 @js_timer_has_pending()

declare i32 @js_callback_timer_has_pending()

declare i32 @js_interval_timer_has_pending()

declare i32 @js_stdlib_has_active_handles()

declare i32 @js_bun_ffi_has_active_threadsafe_callbacks()

declare i32 @js_microtasks_pending()

declare i64 @js_timer_validate_callback(double, i32)

declare i64 @js_set_timeout_callback(i64, double)

declare i64 @js_set_timeout_callback_args(i64, double, ptr, i32)

declare i64 @js_set_immediate_callback(i64)

declare i64 @js_set_immediate_callback_args(i64, ptr, i32)

declare i64 @setInterval(i64, double)

declare i64 @js_set_interval_callback_args(i64, double, ptr, i32)

declare void @clearTimeout(i64)

declare void @clearInterval(i64)

declare void @clearImmediate(i64)

declare void @js_clear_timeout_value(double)

declare void @js_clear_interval_value(double)

declare void @js_clear_immediate_value(double)

declare i64 @js_buffer_from_array(i64)

declare i64 @js_buffer_from_arraybuffer_slice(i64, i32, i32)

declare i32 @js_buffer_length(i64)

declare i32 @js_buffer_get(i64, i32)

declare double @js_buffer_index_get_value(i64, i32)

declare ptr @js_native_buffer_data_ptr(double)

declare i64 @js_native_buffer_byte_len(double)

declare void @js_console_time(i64)

declare void @js_console_time_end(i64)

declare void @js_console_time_log(i64)

declare void @js_console_time_value(double)

declare void @js_console_time_end_value(double)

declare void @js_console_time_log_value(double)

declare void @js_console_time_log_spread(double, i64)

declare void @js_console_count(i64)

declare void @js_console_count_reset(i64)

declare void @js_console_count_value(double)

declare void @js_console_count_reset_value(double)

declare double @js_console_new(double)

declare double @js_console_new2(double, double)

declare void @js_console_group_begin()

declare void @js_console_group_end()

declare void @js_console_clear()

declare void @js_console_noop()

declare double @js_native_call_method(double, ptr, i64, ptr, i64)

declare double @js_native_call_method_by_id(double, i64, ptr, i64)

declare double @js_native_call_method_apply(double, ptr, i64, i64)

declare double @js_native_call_method_apply_by_id(double, i64, i64)

declare double @js_native_call_method_str_key(double, i64, ptr, i64)

declare double @js_native_call_method_value(double, double, ptr, i64)

declare double @js_native_call_method_value_apply(double, double, i64)

declare void @js_promise_resolve(i64, double)

declare void @js_promise_reject(i64, double)

declare void @js_promise_mark_internally_handled(i64)

declare i64 @js_promise_resolved(double)

declare i64 @js_async_fn_result(double)

declare i64 @js_promise_rejected(double)

declare double @js_create_namespace(i32, ptr, ptr, ptr, ptr)

declare double @js_finalize_namespace(double)

declare i64 @js_promise_then(i64, i64, i64)

declare i64 @js_promise_resolved_then(double, i64, i64)

declare i64 @js_promise_finally(i64, i64)

declare double @js_promise_then_checked(double, double, double)

declare double @js_promise_catch_checked(double, double)

declare double @js_promise_finally_checked(double, double)

declare i64 @js_promise_closure_arg(double)

declare i64 @js_promise_all(i64)

declare i64 @js_promise_race(i64)

declare i64 @js_promise_any(i64)

declare i64 @js_promise_all_settled(i64)

declare i64 @js_promise_all_iterable(double)

declare i64 @js_promise_race_iterable(double)

declare i64 @js_promise_any_iterable(double)

declare i64 @js_promise_all_settled_iterable(double)

declare i64 @js_promise_with_resolvers()

declare i64 @js_promise_try(double, i64)

declare i64 @js_array_unshift_f64(i64, double)

declare i64 @js_array_unshift_variadic(i64, ptr, i32)

declare i64 @js_array_entries(i64)

declare i64 @js_array_keys(i64)

declare i64 @js_array_values(i64)

declare i64 @js_array_entries_iter_obj(i64)

declare i64 @js_array_keys_iter_obj(i64)

declare i64 @js_array_values_iter_obj(i64)

declare double @js_response_new(i64, double, i64, double)

declare double @js_fetch_unwrap_handle(double)

declare double @js_response_body_init_reset()

declare i64 @js_response_body_init_ptr(double)

declare double @js_headers_new()

declare double @js_headers_set(double, i64, i64)

declare double @js_headers_append(double, i64, i64)

declare i64 @js_headers_get(double, i64)

declare double @js_headers_get_set_cookie(double)

declare double @js_headers_has(double, i64)

declare double @js_headers_delete(double, i64)

declare double @js_headers_for_each(double, double)

declare double @js_headers_keys(double)

declare double @js_headers_values(double)

declare double @js_headers_entries(double)

declare double @js_headers_init_from_value(double, double)

declare double @js_headers_method_value(double, i64, i64)

declare double @js_request_new(i64, i64, i64, double, i64, i64, i64, i64, i64, i64, i64, double, i64, double)

declare double @js_request_new_from_init(i64, double)

declare i64 @js_request_get_url(double)

declare i64 @js_request_input_to_url(double)

declare i64 @js_request_get_method(double)

declare double @js_request_get_body(double)

declare double @js_request_body_used(double)

declare i64 @js_request_get_destination(double)

declare i64 @js_request_get_referrer(double)

declare i64 @js_request_get_referrer_policy(double)

declare i64 @js_request_get_mode(double)

declare i64 @js_request_get_credentials(double)

declare i64 @js_request_get_cache(double)

declare i64 @js_request_get_redirect(double)

declare i64 @js_request_get_integrity(double)

declare double @js_request_get_keepalive(double)

declare i64 @js_request_get_duplex(double)

declare double @js_request_get_signal(double)

declare double @js_request_get_headers(double)

declare i64 @js_request_text(double)

declare i64 @js_request_json(double)

declare i64 @js_request_array_buffer(double)

declare i64 @js_request_blob(double)

declare i64 @js_request_bytes(double)

declare i64 @js_request_form_data(double)

declare double @js_request_clone(double)

declare double @js_fetch_response_status(double)

declare i64 @js_fetch_response_status_text(double)

declare double @js_fetch_response_ok(double)

declare i64 @js_fetch_response_type(double)

declare i64 @js_fetch_response_url(double)

declare double @js_fetch_response_redirected(double)

declare double @js_response_body_used(double)

declare i64 @js_fetch_response_text(double)

declare i64 @js_fetch_response_json(double)

declare double @js_response_get_headers(double)

declare double @js_response_clone(double)

declare i64 @js_response_array_buffer(double)

declare i64 @js_response_blob(double)

declare i64 @js_response_bytes(double)

declare i64 @js_response_form_data(double)

declare double @js_form_data_new()

declare double @js_form_data_append(double, double, double, double)

declare double @js_form_data_set(double, double, double, double)

declare double @js_form_data_delete(double, i64)

declare double @js_form_data_get(double, i64)

declare double @js_form_data_get_all(double, i64)

declare double @js_form_data_has(double, i64)

declare double @js_form_data_entries(double)

declare double @js_form_data_keys(double)

declare double @js_form_data_values(double)

declare double @js_form_data_for_each(double, double)

declare double @js_blob_size(double)

declare i64 @js_blob_type(double)

declare i64 @js_blob_array_buffer(double)

declare i64 @js_blob_bytes(double)

declare i64 @js_blob_text(double)

declare double @js_blob_slice(double, double, double, i64)

declare double @js_blob_new(double, double)

declare double @js_file_new(double, double, double, double)

declare i64 @js_file_name(double)

declare double @js_file_last_modified(double)

declare i64 @js_url_create_object_url(double)

declare void @js_url_revoke_object_url(double)

declare double @js_buffer_resolve_object_url(double)

declare double @js_response_static_json(double, double, i64, double)

declare double @js_response_static_redirect(i64, double)

declare double @js_response_static_error()

declare double @js_blob_stream(double)

declare double @js_response_body(double)

declare double @js_readable_stream_new(double, double, double, double)

declare double @js_readable_stream_new_with_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_with_strategy_and_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_from_source_object(double, double)

declare double @js_readable_stream_get_reader(double)

declare double @js_readable_stream_get_reader_with_options(double, double)

declare double @js_readable_stream_get_byob_reader(double)

declare double @js_readable_stream_controller_byob_request(double)

declare double @js_readable_stream_from_iterable(double)

declare double @js_readable_stream_locked(double)

declare i64 @js_readable_stream_cancel(double, double)

declare double @js_readable_stream_tee(double)

declare i64 @js_readable_stream_pipe_to(double, double, double)

declare double @js_readable_stream_pipe_through(double, double, double)

declare double @js_readable_stream_pipe_through_validate(double, double, double, double)

declare double @js_readable_stream_controller_enqueue(double, double)

declare double @js_readable_stream_controller_close(double)

declare double @js_readable_stream_controller_error(double, double)

declare double @js_readable_stream_controller_desired_size(double)

declare i64 @js_reader_read(double)

declare i64 @js_reader_read_with_view(double, double)

declare double @js_reader_release_lock(double)

declare i64 @js_reader_closed(double)

declare i64 @js_reader_cancel(double, double)

declare double @js_writable_stream_new(double, double, double, double, double)

declare double @js_writable_stream_new_with_sink_type(double, double, double, double, double, double)

declare double @js_writable_stream_new_from_sink_object(double, double)

declare double @js_writable_stream_throw_invalid_sink()

declare double @js_writable_stream_get_writer(double)

declare double @js_writable_stream_locked(double)

declare i64 @js_writable_stream_close(double)

declare i64 @js_writable_stream_abort(double, double)

declare i64 @js_writer_write(double, double)

declare i64 @js_writer_close(double)

declare i64 @js_writer_abort(double, double)

declare double @js_writer_release_lock(double)

declare i64 @js_writer_closed(double)

declare i64 @js_writer_ready(double)

declare double @js_writer_desired_size(double)

declare double @js_transform_stream_new(double, double, double, double, double)

declare double @js_transform_stream_new_from_transformer_object(double, double, double)

declare double @js_transform_stream_readable(double)

declare double @js_transform_stream_writable(double)

declare double @js_text_encoding_stream_new()

declare double @js_text_encoder_stream_new()

declare double @js_text_decoder_stream_new()

declare double @js_stream_web_text_encoder_stream_new()

declare double @js_stream_web_text_decoder_stream_new(double, double)

declare double @js_stream_web_compression_stream_new(double)

declare double @js_stream_web_decompression_stream_new(double)

declare double @js_streams_strategy_high_water_mark(double)

declare double @js_count_queuing_strategy_new(double)

declare double @js_byte_length_queuing_strategy_new(double)

declare double @js_stream_unwrap_handle(double)

declare double @js_readable_stream_subclass_init(double, double, double, double, double)

declare double @js_writable_stream_subclass_init(double, double, double, double, double)

declare double @js_transform_stream_subclass_init(double, double, double, double)

declare double @js_request_subclass_init(double, double, double)

declare double @js_response_subclass_init(double, double, double)

declare double @js_fetch_or_value_super(double, double, ptr, i64)

declare double @js_builtin_subclass_construct(i32, ptr, i64, ptr, i64)

declare i64 @js_abort_controller_new()

declare i64 @js_abort_controller_signal(i64)

declare void @js_abort_controller_abort(i64)

declare void @js_abort_controller_abort_reason(i64, double)

declare void @js_abort_signal_add_listener(i64, double, double)

declare i64 @js_abort_signal_timeout(double)

declare i64 @js_abort_signal_abort(double)

declare i64 @js_abort_signal_any(i64)

declare double @js_abort_signal_throw_if_aborted(i64)

declare i64 @js_event_target_new()

declare i64 @js_event_new(double, double, i32)

declare double @js_event_subclass_init(double, double, double, i32, i32)

declare i64 @js_custom_event_new(double, double, i32)

declare i64 @js_dom_exception_new(double, double)

declare double @js_dom_exception_subclass_init(double, double, double)

declare void @js_event_target_add_event_listener(i64, i64, i64)

declare void @js_event_target_add_event_listener_with_options(i64, i64, i64, double)

declare void @js_event_target_remove_event_listener(i64, i64, i64)

declare void @js_event_target_remove_event_listener_with_options(i64, i64, i64, double)

declare double @js_event_target_dispatch_event(i64, double)

declare i32 @js_event_target_is_event_target(i64)

declare i64 @js_event_target_get_event_listeners(i64, i64)

declare double @js_event_target_get_max_listeners(i64)

declare i32 @js_event_target_set_max_listeners(i64, double)

declare double @js_message_channel_new()

declare double @js_message_port_constructor_error()

declare double @js_broadcast_channel_new(double)

declare i64 @js_array_alloc(i32)

declare i64 @js_tagged_template_register_raw(i64, i64)

declare i64 @js_tagged_template_get_or_init(i64, i64, i64)

declare i64 @js_template_raw(i64)

declare i64 @js_array_create()

declare i64 @js_array_constructor_single(double)

declare i64 @js_array_alloc_literal(i32)

declare i64 @js_array_from_values(ptr, i32)

declare double @js_value_from_const_descriptor(ptr, i32)

declare i64 @js_array_push_f64(i64, double)

declare i64 @js_array_push_u31_with_length(i64, i32, ptr)

declare i64 @js_array_push_f64_spec(i64, double)

declare void @js_array_push_guard(i64)

declare i64 @js_array_push_hole(i64)

declare i64 @js_array_numeric_push_f64_unboxed(i64, double)

declare i64 @js_array_push_spread_f64(i64, i64)

declare double @js_array_get_f64(i64, i32)

declare i32 @js_array_ensure_element_shape(i64)

declare double @js_array_get_index_or_string(i64, double)

declare double @js_array_numeric_get_f64_unboxed(i64, i32)

declare void @js_array_set_f64(i64, i32, double)

declare i32 @js_array_numeric_set_f64_unboxed(i64, i32, double)

declare i64 @js_array_set_f64_extend(i64, i32, double)

declare i64 @js_array_set_f64_extend_strict(i64, i32, double)

declare i64 @js_array_fill_f64_const_extend(i64, i32, double)

declare i64 @js_array_fill_f64_iota_extend(i64, i32)

declare i64 @js_array_fill_f64_const_len_extend(i64, double)

declare i64 @js_array_fill_f64_iota_len_extend(i64)

declare i64 @js_array_numeric_range_add(double, double, double, double)

declare i64 @js_array_numeric_range_add_len(double, double, double)

declare i64 @js_array_fill_range_strided_tagged(double, double, double, double, i64)

declare i64 @js_array_set_string_key(i64, i64, double)

declare i64 @js_array_set_index_or_string(i64, double, double)

declare i64 @js_array_mark_arguments_object(i64)

declare i32 @js_array_mark_numeric_f64_layout(i64)

declare i32 @js_array_is_numeric_f64_layout(i64)

declare void @js_array_clear_numeric_layout(i64)

; Function Attrs: nounwind willreturn
declare double @js_array_numeric_value_to_raw_f64(double) #0

declare double @js_array_refresh_local_head(double)

declare void @js_array_note_numeric_write(i64, i64)

declare void @js_array_declare_all_pointer_elements(i64)

declare i32 @js_array_length(i64)

declare double @js_array_is_array(double)

declare double @js_value_length_f64(double)

declare double @js_value_length_property_f64(double)

declare double @js_value_length_property_ic_f64(double, ptr)

declare nonnull ptr @js_shadow_frame_enter(i32)

declare i64 @js_shadow_frame_push(i32)

declare void @js_shadow_frame_pop(i64)

declare void @js_shadow_slot_set(i32, i64)

declare void @js_shadow_slot_bind(i32, ptr)

declare void @js_gc_write_barriers_emitted(i32)

declare i32 @js_gc_temp_root_push(i64)

declare i64 @js_gc_temp_root_get(i32)

declare void @js_gc_temp_root_set(i32, i64)

declare void @js_gc_temp_root_truncate(i32)

declare void @js_array_push_f64_temp_rooted(i32, double)

declare void @js_gc_loop_safepoint()

declare void @js_write_barrier(i64, i64)

declare void @js_write_barrier_slot(i64, i64, i64)

declare i64 @js_array_live_head(i64)

declare void @js_write_barrier_slot_validated_parent(i64, i64, i64)

declare void @js_write_barrier_root_nanbox(i64)

declare void @js_write_barrier_root_heap_word(i64)

declare void @js_gc_note_slot_layout(i64, i32, i64)

declare void @js_gc_note_slot_layout_aware(i64, i32, i64, i64)

declare void @js_gc_init_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_declare_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_forget_object_layout(i64)

declare double @js_array_pop_f64(i64)

declare i64 @js_array_join(i64, i64)

declare i64 @js_array_join_value(i64, double)

declare void @js_array_forEach(i64, i64)

declare i64 @js_array_fill(i64, double)

declare i64 @js_array_fill_range(i64, double, double, double)

declare double @js_array_fill_generic(double, double, i32, double, i32, double)

declare i32 @js_array_delete(i64, i32)

declare void @js_array_set_length(i64, double)

declare void @js_array_set_length_strict(i64, double)

declare i64 @js_array_clone(i64)

declare i32 @js_short_packed_spread_values(double, ptr)

declare i64 @js_spread_tail_fallback_args(ptr, i64, double)

declare i64 @js_array_from_value(double)

declare i64 @js_array_from_arraylike_holey_value(double)

declare double @js_iterator_from(double)

declare i64 @js_array_from_mapped(double, double, double)

declare i64 @js_array_concat_variadic(i64, ptr, i32)

declare double @js_arraylike_forEach(double, double, double)

declare double @js_arraylike_map(double, double, double)

declare double @js_arraylike_filter(double, double, double)

declare double @js_arraylike_some(double, double, double)

declare double @js_arraylike_every(double, double, double)

declare double @js_arraylike_find(double, double, double)

declare double @js_arraylike_findIndex(double, double, double)

declare double @js_arraylike_findLast(double, double, double)

declare double @js_arraylike_findLastIndex(double, double, double)

declare double @js_arraylike_reduce(double, double, i32, double)

declare double @js_arraylike_reduceRight(double, double, i32, double)

declare double @js_arraylike_indexOf(double, double, double, i32)

declare double @js_arraylike_lastIndexOf(double, double, double, i32)

declare double @js_arraylike_includes(double, double, double, i32)

declare double @js_arraylike_at(double, double)

declare double @js_arraylike_join(double, double)

declare double @js_arraylike_flat(double, double)

declare double @js_arraylike_slice(double, double, i32, double, i32)

declare double @js_arraylike_sort(double, double)

declare double @js_arraylike_splice(double, ptr, i32)

declare double @js_arraylike_concat(double, ptr, i32)

declare double @js_arraylike_pop(double)

declare double @js_arraylike_shift(double)

declare double @js_arraylike_push(double, ptr, i32)

declare double @js_arraylike_unshift(double, ptr, i32)

declare i64 @js_array_clone_for_spread(double)

declare i64 @js_array_spread_append(i64, double)

declare i64 @js_iterator_to_array(double)

declare double @js_iterator_next_result(double)

declare double @js_iterator_close_if_not_done(double, double)

declare double @js_iterator_rest_to_array(double, double)

declare double @js_get_iterator(double)

declare double @js_get_async_iterator(double)

declare double @js_for_of_to_array(double)

declare i64 @js_object_alloc(i32, i32)

declare double @js_object_coerce(double)

declare void @js_object_mark_class(i64)

declare void @js_class_object_pin_parent(i64, i32)

declare i64 @js_object_alloc_with_shape(i32, i32, ptr, i32)

declare void @js_object_set_field(i64, i32, i64)

declare i64 @js_object_get_field(i64, i32)

declare void @js_object_set_field_by_name(i64, i64, double)

declare void @js_object_set_field_by_property_id(i64, i64, double)

declare void @js_object_set_field_by_name_nonenum(i64, i64, double)

declare void @js_error_subclass_default_init(double, double)

declare void @js_object_set_field_by_name_nonconfigurable(i64, i64, double)

declare void @js_error_apply_cause_to_object(i64, double)

declare void @js_error_subclass_capture_stack(double)

declare i32 @js_with_has_binding(double, i64)

declare double @js_with_get_binding(double, i64)

declare double @js_with_set_binding(double, i64, double, i32)

declare i32 @js_with_delete_binding(double, i64)

declare i32 @js_pod_scalar_write_compatible(double, i32)

declare void @js_typed_feedback_register_site(i64, i32, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64)

declare void @js_typed_feedback_record_guard_pass(i64)

declare void @js_typed_feedback_record_guard_fail(i64)

declare void @js_typed_feedback_record_fallback_call(i64)

declare void @js_typed_feedback_observe_property_get(i64, i64, i64)

declare void @js_typed_feedback_observe_property_set(i64, i64, i64)

declare double @js_typed_feedback_object_get_field_by_name_f64(i64, i64, i64)

declare void @js_typed_feedback_object_set_field_by_name(i64, i64, i64, double)

declare void @js_typed_feedback_object_set_field_by_name_fast(i64, i64, i64, double)

declare i32 @js_typed_feedback_class_field_set_guard(i64, double, i32, i32, i64, i32, double, i32)

declare void @js_class_field_set_fallback(i64, i64, i64, double)

declare void @js_class_field_set_ic(i64, double, i32, i32, i64, i32, double, i32)

declare i32 @js_typed_feedback_class_field_get_guard(i64, double, i32, i32, i64, i32, i32)

declare double @js_class_field_get_ic(i64, double, i32, i32, i64, i32, i32)

declare double @js_typed_feedback_native_call_method(i64, double, ptr, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_by_id(i64, double, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_apply(i64, double, ptr, i64, i64)

declare double @js_typed_feedback_native_call_method_apply_by_id(i64, double, i64, i64)

declare i32 @js_typed_feedback_method_direct_call_guard(i64, double, i32, i32, ptr, i64, ptr)

declare i32 @js_method_direct_shape_guard(double, i32, i32, i32)

declare i32 @js_method_direct_shape_class(double, ptr, i32)

declare i32 @js_typed_feedback_closure_direct_call_guard(i64, double, ptr, i32, i32)

declare i64 @js_closure_exact_func_guard(double, ptr)

declare i64 @js_object_own_method_cache_miss(double, i32, i32, ptr, i64, ptr, ptr)

declare void @js_typed_feedback_object_set_unboxed_f64_field(i64, i64, i32, i64, double)

declare double @js_typed_feedback_observe_helper_return(i64, double)

declare void @js_object_set_index_polymorphic(i64, double, double)

declare double @js_object_get_index_polymorphic(i64, double)

declare double @js_object_get_field_by_name_f64(i64, i64)

declare double @js_object_get_field_by_name_boxed(double, i64)

declare double @js_object_get_field_by_property_id_f64(i64, i64)

declare double @js_native_module_property_by_name(ptr, i64, ptr, i64)

declare double @js_native_module_esm_export_value(double, double)

declare double @js_native_module_named_esm_export_value(double, double)

declare double @js_create_native_module_namespace(ptr, i64)

declare void @js_nm_install_assert()

declare void @js_nm_install_async_hooks()

declare void @js_nm_install_bigint()

declare void @js_nm_install_buffer()

declare void @js_bun_tcp_nm_install()

declare void @js_nm_install_bun()

declare void @js_nm_install_bun_ffi()

declare void @js_nm_install_child_process()

declare void @js_nm_install_cluster()

declare void @js_nm_install_console()

declare void @js_nm_install_crypto()

declare void @js_nm_install_dgram()

declare void @js_nm_install_dns()

declare void @js_nm_install_domain()

declare void @js_nm_install_events()

declare void @js_nm_install_fs()

declare void @js_nm_install_http()

declare void @js_nm_install_inspector()

declare void @js_nm_install_module()

declare void @js_nm_install_net()

declare void @js_nm_install_node_pty()

declare void @js_nm_install_os()

declare void @js_nm_install_path()

declare void @js_nm_install_perf()

declare void @js_nm_install_process()

declare void @js_nm_install_punycode()

declare void @js_nm_install_querystring()

declare void @js_nm_install_readline()

declare void @js_nm_install_repl()

declare void @js_nm_install_sea()

declare void @js_nm_install_sqlite()

declare void @js_nm_install_stream()

declare void @js_nm_install_timers()

declare void @js_nm_install_tls()

declare void @js_nm_install_tty()

declare void @js_nm_install_url()

declare void @js_nm_install_util()

declare void @js_nm_install_v8()

declare void @js_nm_install_vm()

declare void @js_nm_install_wasi()

declare void @js_nm_install_zlib()

declare void @js_nm_install_all()

declare double @js_object_get_field_ic_miss(i64, i64, ptr)

declare double @js_object_get_field_ic(i64, i64, i64, ptr)

declare i64 @js_object_rest(i64, i64)

declare double @js_require_object_coercible(double)

declare double @js_require_json_disk(double)

declare double @js_require_resolve_node_modules(double, double)

declare void @js_globalthis_seed_async_local_storage()

declare void @js_register_path_module_partial(double, double)

declare void @js_register_path_module(double, double)

declare void @js_link_path_module_parent(double)

declare void @js_run_module_init_catching(i64)

declare double @js_require_path_module(double)

declare double @js_has_path_module(double)

declare void @js_register_path_init(ptr, i64, i64)

declare i64 @js_array_alloc_with_length(i32)

declare void @js_array_set_f64_unchecked(i64, i32, double)

declare double @js_typed_feedback_array_get_f64(i64, i64, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_get_guard(i64, double, i32, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_get_guard(i64, double, i32, i32) #0

declare i32 @js_typed_feedback_packed_f64_array_loop_guard(i64, double)

declare i32 @js_string_array_range_loop_guard(double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense_i32(i64, double, i32, i32)

declare i32 @js_typed_feedback_masked_window_ta_kind(i64, double, i32, i32)

declare i64 @js_typed_array_masked_window_data_ptr(double)

declare i64 @js_packed_ecs_u32_loop_guard(double, double, double, double, double, double, i32, ptr)

declare i32 @js_typed_feedback_packed_u32_array_loop_guard(i64, double)

declare double @js_typed_feedback_array_index_get_fallback_boxed(i64, double, double)

declare void @js_typed_feedback_array_set_f64(i64, i64, i32, double)

declare i64 @js_typed_feedback_array_set_f64_extend(i64, i64, i32, double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_push_guard(i64, double, double) #0

declare double @js_typed_feedback_array_index_set_fallback_boxed(i64, double, double, double, i32)

declare void @js_typed_feedback_observe_array_element(i64, i64, i32)

declare i64 @js_typed_feedback_array_set_string_key(i64, i64, i64, double)

declare i64 @js_typed_feedback_array_set_index_or_string(i64, i64, double, double, i32)

declare void @js_typed_feedback_object_set_index_polymorphic(i64, i64, double, double)

declare double @js_proxy_new(double, double)

declare double @js_proxy_revocable(double, double)

declare void @js_proxy_revoke(double)

declare i32 @js_proxy_is_revoked(double)

declare i32 @js_proxy_is_proxy(double)

declare double @js_proxy_target(double)

declare double @js_proxy_get(double, double)

declare double @js_proxy_set(double, double, double)

declare double @js_proxy_has(double, double)

declare double @js_proxy_delete(double, double)

declare double @js_proxy_apply(double, double, double)

declare double @js_proxy_construct(double, double, double)

declare double @js_reflect_construct(double, double, double)

declare double @js_reflect_get(double, double, double)

declare double @js_reflect_set(double, double, double, double)

declare double @js_put_value_set(double, double, double, double, i32)

declare i32 @js_transition_ic_spill_append(double, i64, i32, double)

declare ptr @perry_transition_cache_base()

declare void @js_transition_ic_note_hit()

declare double @js_put_value_set_dyn_ic(ptr, double, double, double, i32)

declare double @js_put_value_set_ic_miss(double, i64, double, i32, ptr, i32)

declare i32 @js_put_value_set_ic_overflow_store(double, i64, i32, double)

declare double @js_object_get_field_ic_overflow_load(i64, i64, i32, ptr)

declare double @js_put_value_set_ic_poly_tail(ptr, double, i64, double, i32)

declare i64 @js_object_array_numeric_write_guard(double, double, double, double, double, i32, i32)

declare i64 @js_object_array_numeric_write_range_guard(double, double, double, double, double, i32, i32, i32)

declare double @js_super_put_value_set(i32, double, double, double, i32)

declare double @js_super_accessor_get(i32, double, double)

declare double @js_reflect_has(double, double)

declare double @js_reflect_delete(double, double)

declare double @js_reflect_own_keys(double)

declare double @js_reflect_apply(double, double, double)

declare double @js_reflect_define_property(double, double, double)

declare double @js_reflect_get_own_property_descriptor(double, double)

declare double @js_reflect_get_prototype_of(double)

declare double @js_reflect_set_prototype_of(double, double)

declare double @js_reflect_is_extensible(double)

declare double @js_reflect_prevent_extensions(double)

declare double @js_reflect_define_metadata(double, double, double, double)

declare double @js_reflect_get_metadata(double, double, double)

declare double @js_reflect_get_own_metadata(double, double, double)

declare double @js_reflect_has_metadata(double, double, double)

declare double @js_reflect_has_own_metadata(double, double, double)

declare double @js_reflect_get_metadata_keys(double, double)

declare double @js_reflect_get_own_metadata_keys(double, double)

declare double @js_reflect_delete_metadata(double, double, double)

declare double @js_http_server_construct_with_this(double, double, double)

declare double @js_https_server_construct_with_this(double, double, double)

declare i64 @js_net_socket_set_encoding(i64, i64)

declare double @js_vm_create_context(double, double)

declare double @js_vm_create_script_branded(double, double)

declare double @js_vm_module_call()

declare double @js_vm_module_constructor_error()

declare double @js_repl_start(double)

declare double @js_repl_repl_server_new(double)

declare double @js_repl_recoverable_new(double)

declare double @js_worker_threads_worker_new(i64, double)

declare double @js_worker_threads_worker_post_message(i64, double)

declare double @js_worker_threads_worker_on(i64, double, i64)

declare double @js_worker_threads_worker_once(i64, double, i64)

declare double @js_worker_threads_worker_off(i64, double, i64)

declare double @js_worker_threads_worker_add_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_remove_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_terminate(i64)

declare double @js_worker_threads_worker_ref(i64)

declare double @js_worker_threads_worker_unref(i64)

declare double @js_worker_threads_worker_get_heap_statistics(i64)

declare double @js_worker_threads_worker_cpu_usage(i64, double)

declare double @js_worker_threads_worker_get_heap_snapshot(i64, double)

declare double @js_worker_threads_worker_start_cpu_profile(i64)

declare double @js_worker_threads_worker_start_heap_profile(i64)

declare i64 @js_http_client_request_end(i64, double)

declare i64 @js_http_client_request_write(i64, double)

declare i64 @js_http_client_request_end_full(i64, double, i64, i64)

declare double @js_http_client_request_write_full(i64, double, i64, i64)

declare i64 @js_http_set_timeout_full(i64, double, i64)

declare i64 @js_http_client_request_method(i64)

declare i64 @js_http_client_request_protocol(i64)

declare i64 @js_http_client_request_host(i64)

declare i64 @js_http_client_request_path(i64)

declare double @js_http_client_request_listener_count(i64, i64)

declare double @js_http_client_request_get_header(i64, i64)

declare double @js_http_client_request_has_header(i64, i64)

declare double @js_http_client_request_remove_header(i64, i64)

declare double @js_http_client_request_get_header_names(i64)

declare double @js_http_client_request_get_headers(i64)

declare double @js_http_client_request_get_raw_header_names(i64)

declare double @js_http_client_request_abort(i64)

declare i64 @js_http_client_request_destroy(i64, double)

declare double @js_http_client_request_noop_undefined(i64, double, double)

declare double @js_http_client_request_aborted(i64)

declare double @js_http_client_request_destroyed(i64)

declare double @js_http_client_request_finished(i64)

declare double @js_http_client_request_reused_socket(i64)

declare double @js_http_client_request_max_headers_count(i64)

declare double @js_http_client_request_writable_ended(i64)

declare double @js_http_client_request_writable_finished(i64)

declare double @js_http_client_request_socket(i64)

declare i64 @js_http_get(double, i64)

declare i64 @js_http_get_overload(i64)

declare i64 @js_http_request_overload(i64)

declare i64 @js_https_get_overload(i64)

declare i64 @js_https_request_overload(i64)

declare i64 @js_http_on(i64, i64, i64)

declare i64 @js_http_once(i64, i64, i64)

declare i64 @js_http_request(double, i64)

declare i64 @js_http_request_body(i64)

declare double @js_http_request_body_length(i64)

declare i64 @js_http_request_content_type(i64)

declare double @js_http_request_has_header(i64, i64)

declare i64 @js_http_request_header(i64, i64)

declare i64 @js_http_request_headers_all(i64)

declare double @js_http_request_id(i64)

declare double @js_http_request_is_method(i64, i64)

declare i64 @js_http_request_method(i64)

declare i64 @js_http_request_path(i64)

declare i64 @js_http_request_query(i64)

declare i64 @js_http_request_query_all(i64)

declare i64 @js_http_request_query_param(i64, i64)

declare double @js_http_respond_error(i64, double, i64)

declare double @js_http_respond_html(i64, double, i64)

declare double @js_http_respond_json(i64, double, i64)

declare double @js_http_respond_not_found(i64)

declare double @js_http_respond_redirect(i64, i64, double)

declare i64 @js_http_respond_status_text(double)

declare double @js_http_respond_text(i64, double, i64)

declare double @js_http_respond_with_headers(i64, double, i64, i64)

declare double @js_http_response_headers(i64)

declare double @js_http_response_trailers(i64)

declare double @js_http_incoming_message_socket(i64)

declare double @js_http_incoming_message_req(i64)

declare i64 @js_http_incoming_message_set_encoding(i64, i64)

declare i64 @js_http_server_accept_v2(i64)

declare double @js_http_server_close(i64)

declare i64 @js_http_server_create(double)

declare i64 @js_http_set_header(i64, i64, i64)

declare i64 @js_http_set_timeout(i64, double)

declare double @js_http_status_code(i64)

declare i64 @js_http_status_message(i64)

declare i64 @js_http_agent_new(double)

declare i64 @js_https_agent_new(double)

declare i64 @js_http_agent_get_name(i64, double)

declare i64 @js_http_agent_noop_self(i64)

declare double @js_http_agent_max_sockets(i64)

declare double @js_http_agent_max_free_sockets(i64)

declare double @js_http_agent_max_total_sockets(i64)

declare double @js_http_agent_keep_alive_msecs(i64)

declare double @js_http_agent_keep_alive(i64)

declare i64 @js_http_agent_protocol(i64)

declare double @js_http_agent_default_port(i64)

declare void @js_http_agent_set_protocol(i64, i64)

declare i64 @js_http_agent_destroy(i64)

declare double @js_http_agent_destroyed(i64)

declare double @js_http_agent_sockets(i64)

declare double @js_http_agent_free_sockets(i64)

declare double @js_http_agent_requests(i64)

declare void @js_http_agent_set_max_sockets(i64, double)

declare void @js_http_agent_set_max_free_sockets(i64, double)

declare void @js_http_agent_set_max_total_sockets(i64, double)

declare void @js_http_agent_set_keep_alive(i64, double)

declare void @js_http_agent_set_keep_alive_msecs(i64, double)

declare void @js_http_agent_set_create_connection(i64, i64)

declare void @js_http_agent_set_create_socket(i64, i64)

declare i64 @js_http_agent_create_connection(i64)

declare i64 @js_http_agent_create_socket(i64)

declare i64 @js_https_get(double, i64)

declare i64 @js_https_request(double, i64)

declare i64 @js_node_http_create_server(i64)

declare i64 @js_node_http_server_listen(i64, i64)

declare void @js_node_http_server_close(i64, i64)

declare void @js_node_http_server_close_all_connections(i64)

declare void @js_node_http_server_close_idle_connections(i64)

declare i64 @js_node_http_server_address_json(i64)

declare i32 @js_node_http_server_listening(i64)

declare double @js_node_http_server_listening_value(i64)

declare double @js_node_http_server_on(i64, i64, i64)

declare i64 @js_node_http_im_method(i64)

declare i64 @js_node_http_im_url(i64)

declare i64 @js_node_http_im_http_version(i64)

declare i64 @js_node_http_im_headers_json(i64)

declare i64 @js_node_http_im_raw_headers_json(i64)

declare i64 @js_node_http_im_headers_distinct_json(i64)

declare i64 @js_node_http_im_trailers_json(i64)

declare i64 @js_node_http_im_raw_trailers_json(i64)

declare i64 @js_node_http_im_trailers_distinct_json(i64)

declare i32 @js_node_http_im_complete(i64)

declare i32 @js_node_http_im_aborted(i64)

declare i32 @js_node_http_im_destroyed(i64)

declare i64 @js_node_http_im_remote_address(i64)

declare double @js_node_http_im_remote_port(i64)

declare void @js_node_http_im_pause(i64)

declare void @js_node_http_im_resume(i64)

declare void @js_node_http_im_destroy(i64)

declare double @js_node_http_im_on(i64, i64, i64)

declare double @js_node_http_im_once(i64, i64, i64)

declare double @js_node_http_im_read(i64)

declare i64 @js_node_http_im_set_timeout(i64, double, i64)

declare void @js_node_http_res_set_status(i64, double)

declare double @js_node_http_res_get_status(i64)

declare void @js_node_http_res_set_status_message(i64, i64)

declare void @js_node_http_res_set_header(i64, i64, double)

declare i64 @js_node_http_res_set_header_self(i64, i64, double)

declare double @js_node_http_res_get_header(i64, i64)

declare void @js_node_http_res_remove_header(i64, i64)

declare i32 @js_node_http_res_has_header(i64, i64)

declare double @js_node_http_res_has_header_value(i64, i64)

declare i64 @js_node_http_res_get_headers_json(i64)

declare i64 @js_node_http_res_get_header_names_json(i64)

declare i64 @js_node_http_res_append_header(i64, i64, i64)

declare i64 @js_node_http_res_set_headers(i64, double)

declare double @js_node_http_res_get_status_message(i64)

declare i32 @js_node_http_res_headers_sent(i64)

declare i32 @js_node_http_res_writable_ended(i64)

declare i32 @js_node_http_res_writable_finished(i64)

declare i32 @js_node_http_res_finished(i64)

declare i32 @js_node_http_res_send_date(i64)

declare void @js_node_http_res_set_send_date(i64, double)

declare i32 @js_node_http_res_strict_content_length(i64)

declare void @js_node_http_res_set_strict_content_length(i64, double)

declare i64 @js_node_http_res_req_handle(i64)

declare void @js_node_http_res_write_head(i64, double, i64, i64)

declare i32 @js_node_http_res_write(i64, double)

declare double @js_node_http_res_write_full(i64, double, i64, i64)

declare void @js_node_http_res_add_trailers(i64, double)

declare void @js_node_http_res_end(i64, double)

declare void @js_node_http_res_end_full(i64, double, i64, i64)

declare void @js_node_http_res_flush_headers(i64)

declare void @js_node_http_res_cork(i64)

declare void @js_node_http_res_uncork(i64)

declare i64 @js_node_http_res_set_timeout(i64, double, i64)

declare void @js_node_http_res_write_early_hints(i64, double, i64)

declare void @js_node_http_res_write_continue(i64)

declare void @js_node_http_res_write_processing(i64)

declare double @js_node_http_res_on(i64, i64, i64)

declare i64 @js_node_https_create_server(double, i64)

declare i64 @js_node_https_server_listen(i64, i64)

declare void @js_node_https_server_close(i64, i64)

declare void @js_node_https_server_close_all_connections(i64)

declare void @js_node_https_server_close_idle_connections(i64)

declare i64 @js_node_https_server_address_json(i64)

declare double @js_node_https_server_on(i64, i64, i64)

declare double @js_node_https_server_listening_value(i64)

declare double @js_node_https_server_headers_timeout(i64)

declare double @js_node_https_server_set_headers_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout(i64)

declare double @js_node_https_server_set_keep_alive_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout_buffer(i64)

declare double @js_node_https_server_set_keep_alive_timeout_buffer(i64, double)

declare double @js_node_https_server_request_timeout(i64)

declare double @js_node_https_server_set_request_timeout(i64, double)

declare double @js_node_https_server_idle_timeout(i64)

declare double @js_node_https_server_set_idle_timeout(i64, double)

declare double @js_node_https_server_max_headers_count(i64)

declare double @js_node_https_server_set_max_headers_count(i64, double)

declare double @js_node_https_server_max_requests_per_socket(i64)

declare double @js_node_https_server_set_max_requests_per_socket(i64, double)

declare i64 @js_node_https_server_set_timeout_method(i64, double, i64)

declare i64 @js_node_http2_create_server(double, double)

declare i64 @js_node_http2_create_secure_server(double, i64)

declare i64 @js_node_http2_connect(double, double, i64)

declare i64 @js_node_http2_server_listen(i64, i64)

declare void @js_node_http2_server_close(i64, i64)

declare i64 @js_node_http2_server_address_json(i64)

declare double @js_node_http2_server_on(i64, i64, i64)

declare i64 @js_node_http2_get_default_settings()

declare i64 @js_node_http2_get_packed_settings(i64)

declare i64 @js_node_http2_get_unpacked_settings(i64)

declare i64 @js_pg_client_connect(i64)

declare i64 @js_pg_client_end(i64)

declare i64 @js_pg_client_new(i64)

declare i64 @js_pg_client_query(i64, i64)

declare i64 @js_pg_client_query_params(i64, i64, i64)

declare i64 @js_pg_connect(i64)

declare i64 @js_pg_create_pool(i64)

declare i64 @js_pg_pool_end(i64)

declare i64 @js_pg_pool_new(i64)

declare i64 @js_pg_pool_query(i64, i64)

declare i64 @js_ioredis_connect(i64)

declare i64 @js_ioredis_decr(i64, i64)

declare i64 @js_ioredis_del(i64, i64)

declare void @js_ioredis_disconnect(i64)

declare i64 @js_ioredis_exists(i64, i64)

declare i64 @js_ioredis_expire(i64, i64, double)

declare i64 @js_ioredis_get(i64, i64)

declare i64 @js_ioredis_hdel(i64, i64, i64)

declare i64 @js_ioredis_hget(i64, i64, i64)

declare i64 @js_ioredis_hgetall(i64, i64)

declare i64 @js_ioredis_hlen(i64, i64)

declare i64 @js_ioredis_hset(i64, i64, i64, i64)

declare i64 @js_ioredis_incr(i64, i64)

declare i64 @js_ioredis_new(i64)

declare i64 @js_ioredis_ping(i64)

declare i64 @js_ioredis_quit(i64)

declare i64 @js_ioredis_set(i64, i64, i64)

declare i64 @js_ioredis_setex(i64, i64, double, i64)

declare i64 @js_mongodb_client_close(i64)

declare i64 @js_mongodb_client_connect(i64)

declare i64 @js_mongodb_client_db(i64, i64)

declare i64 @js_mongodb_client_list_databases(i64)

declare i64 @js_mongodb_client_new(i64)

declare i64 @js_mongodb_collection_count_value(i64, double)

declare i64 @js_mongodb_collection_delete_many_value(i64, double)

declare i64 @js_mongodb_collection_delete_one_value(i64, double)

declare i64 @js_mongodb_collection_find_one_value(i64, double)

declare i64 @js_mongodb_collection_find_value(i64, double)

declare i64 @js_mongodb_collection_insert_many_value(i64, double)

declare i64 @js_mongodb_collection_insert_one_value(i64, double)

declare i64 @js_mongodb_collection_update_many_value(i64, double, double)

declare i64 @js_mongodb_collection_update_one_value(i64, double, double)

declare i64 @js_mongodb_collection_count(i64, i64)

declare i64 @js_mongodb_collection_delete_many(i64, i64)

declare i64 @js_mongodb_collection_delete_one(i64, i64)

declare i64 @js_mongodb_collection_find(i64, i64)

declare i64 @js_mongodb_collection_find_one(i64, i64)

declare i64 @js_mongodb_collection_insert_many(i64, i64)

declare i64 @js_mongodb_collection_insert_one(i64, i64)

declare i64 @js_mongodb_collection_update_many(i64, i64, i64)

declare i64 @js_mongodb_collection_update_one(i64, i64, i64)

declare i64 @js_mongodb_connect(i64)

declare i64 @js_mongodb_db_collection(i64, i64)

declare i64 @js_mongodb_db_list_collections(i64)

declare void @js_sqlite_close(i64)

declare void @js_sqlite_exec(i64, i64)

declare i64 @js_sqlite_open(i64)

declare i64 @js_sqlite_pragma(i64, i64, i64)

declare i64 @js_sqlite_prepare(i64, i64)

declare i64 @js_sqlite_stmt_all(i64, i64)

declare i64 @js_sqlite_stmt_columns(i64)

declare i64 @js_sqlite_stmt_get(i64, i64)

declare i64 @js_sqlite_stmt_run(i64, i64)

declare i64 @js_sqlite_transaction(i64, i64)

declare void @js_sqlite_transaction_commit(i64)

declare void @js_sqlite_transaction_rollback(i64)

declare i64 @js_bun_sqlite_database_call(double, double)

declare i64 @js_bun_sqlite_database_new(double, double)

declare i64 @js_bun_sqlite_database_query(i64, double)

declare i64 @js_bun_sqlite_database_run(i64, double, i64)

declare i64 @js_bun_sqlite_database_filename(i64)

declare i64 @js_bun_sqlite_database_transaction(i64, double)

declare i64 @js_bun_sqlite_statement_values(i64, i64)

declare double @js_bun_sqlite_statement_safe_integers(i64, double)

declare void @js_bun_sqlite_statement_finalize(i64)

declare i64 @js_node_sqlite_backup(double, double, double)

declare i64 @js_node_sqlite_database_sync_call(double, double)

declare i64 @js_node_sqlite_database_sync_new(double, double)

declare i32 @js_node_sqlite_database_sync_open(i64)

declare i32 @js_node_sqlite_database_sync_close(i64)

declare i32 @js_node_sqlite_database_sync_dispose(i64)

declare i32 @js_node_sqlite_database_sync_exec(i64, double)

declare i64 @js_node_sqlite_database_sync_prepare(i64, double, double)

declare i32 @js_node_sqlite_database_sync_function(i64, double, double, double)

declare i32 @js_node_sqlite_database_sync_aggregate(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_defensive(i64, double)

declare i32 @js_node_sqlite_database_sync_set_authorizer(i64, double)

declare i64 @js_node_sqlite_database_sync_create_tag_store(i64, double)

declare i64 @js_node_sqlite_database_sync_create_session(i64, double)

declare double @js_node_sqlite_database_sync_apply_changeset(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_load_extension(i64, double)

declare i32 @js_node_sqlite_database_sync_load_extension(i64, double)

declare double @js_node_sqlite_database_sync_location(i64, double)

declare double @js_node_sqlite_database_sync_is_open(i64)

declare double @js_node_sqlite_database_sync_is_transaction(i64)

declare i64 @js_node_sqlite_database_sync_limits(i64)

declare i64 @js_node_sqlite_statement_sync_call(double, double)

declare i64 @js_node_sqlite_statement_sync_new(double, double)

declare i64 @js_node_sqlite_statement_sync_run(i64, i64)

declare double @js_node_sqlite_statement_sync_get(i64, i64)

declare i64 @js_node_sqlite_statement_sync_all(i64, i64)

declare double @js_node_sqlite_statement_sync_iterate(i64, i64)

declare i64 @js_node_sqlite_statement_sync_columns(i64)

declare i32 @js_node_sqlite_statement_sync_set_read_bigints(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_return_arrays(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_bare_named_parameters(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_unknown_named_parameters(i64, double)

declare i64 @js_node_sqlite_statement_sync_source_sql(i64)

declare i64 @js_node_sqlite_statement_sync_expanded_sql(i64)

declare i64 @js_node_sqlite_sql_tag_store_run(i64, i64)

declare double @js_node_sqlite_sql_tag_store_get(i64, i64)

declare i64 @js_node_sqlite_sql_tag_store_all(i64, i64)

declare double @js_node_sqlite_sql_tag_store_iterate(i64, i64)

declare i32 @js_node_sqlite_sql_tag_store_clear(i64)

declare double @js_node_sqlite_sql_tag_store_size(i64)

declare double @js_node_sqlite_sql_tag_store_capacity(i64)

declare i64 @js_node_sqlite_sql_tag_store_db(i64)

declare i64 @js_node_sqlite_session_call(double, double)

declare i64 @js_node_sqlite_session_new(double, double)

declare i64 @js_node_sqlite_session_changeset(i64)

declare i64 @js_node_sqlite_session_patchset(i64)

declare i32 @js_node_sqlite_session_close(i64)

declare i32 @js_node_sqlite_session_dispose(i64)

declare i64 @js_os_cpus()

declare double @js_os_freemem()

declare i64 @js_os_homedir()

declare i64 @js_os_network_interfaces()

declare i64 @js_os_tmpdir()

declare double @js_os_totalmem()

declare double @js_os_uptime()

declare i64 @js_os_user_info()

declare i64 @js_os_user_info_buffer()

declare i64 @js_os_user_info_options(i64)

declare i64 @js_crypto_aes256_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_encrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_encrypt(i64, i64, i64)

declare double @js_crypto_create_cipheriv(i64, i64, i64, double)

declare double @js_crypto_create_decipheriv(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sha256(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sync(i64, i64, i64, i64, double)

declare i64 @js_crypto_pbkdf2(i64, i64, double, double)

declare i64 @js_crypto_random_bytes_hex(double)

declare i64 @js_crypto_random_nonce()

declare i64 @js_crypto_scrypt(i64, i64, double)

declare double @js_crypto_generate_key_pair_sync(i64, i64)

declare i64 @js_crypto_scrypt_custom(i64, i64, double, double, double, double)

declare i64 @js_crypto_x25519_keypair()

declare i64 @js_crypto_x25519_shared_secret(i64, i64)

declare i64 @js_keccak256_native(i64)

declare i64 @js_keccak256_native_bytes(i64)

declare i64 @js_nanoid(double)

declare i64 @js_nanoid_custom(i64, double)

declare i64 @js_argon2_hash(i64)

declare i64 @js_argon2_hash_options(i64, i64)

declare i64 @js_argon2_verify(i64, i64)

declare i64 @js_bcrypt_compare(i64, i64)

declare double @js_bcrypt_compare_sync(i64, i64)

declare i64 @js_bcrypt_gen_salt(double)

declare i64 @js_bcrypt_hash(i64, double)

declare i64 @js_bcrypt_hash_sync(i64, double)

declare i64 @js_ads_interstitial_load(i64)

declare i64 @js_ads_interstitial_show()

declare i64 @js_ads_rewarded_load(i64)

declare i64 @js_ads_rewarded_show()

declare double @js_ads_banner_create(i64, i64)

declare void @js_ads_banner_destroy(double)

declare i64 @js_ads_request_consent()

declare i64 @js_perry_read_embedded(double)

declare i64 @js_perry_embedded_files()

declare double @js_thread_parallel_map(double, double)

declare double @js_thread_parallel_filter(double, double)

declare double @js_thread_spawn(double)

declare double @js_perry_native_i8(double)

declare double @js_perry_native_i16(double)

declare double @js_perry_native_u8(double)

declare double @js_perry_native_u16(double)

declare double @js_perry_native_i32(double)

declare double @js_perry_native_i64(double)

declare double @js_perry_native_u32(double)

declare double @js_perry_native_u64(double)

declare double @js_perry_native_usize(double)

declare double @js_perry_native_isize(double)

declare double @js_perry_native_f32(double)

declare double @js_perry_native_f64(double)

declare i64 @js_jwt_decode(i64)

declare i64 @js_jwt_sign(i64, i64, double, i64)

declare i64 @js_jwt_sign_es256(i64, i64, double, i64)

declare i64 @js_jwt_sign_rs256(i64, i64, double, i64)

declare i64 @js_jwt_verify(i64, i64)

declare i64 @js_jwt_verify_es256(i64, i64)

declare i64 @js_jwt_verify_rs256(i64, i64)

declare i64 @js_jwt_sign_dyn(i64, i64, i64, double, i64)

declare i64 @js_jwt_verify_dyn(i64, i64, i64)

declare i64 @js_jwt_sign_dyn_opts(i64, i64, double)

declare i64 @js_jwt_verify_dyn_opts(i64, i64, double)

declare double @js_axios_create(i64)

declare i64 @js_axios_delete(i64)

declare i64 @js_axios_get(i64)

declare i64 @js_axios_head(i64)

declare i64 @js_axios_options(i64)

declare i64 @js_axios_post(i64, double)

declare i64 @js_axios_put(i64, double)

declare i64 @js_axios_patch(i64, double)

declare i64 @js_axios_request(i64)

declare double @js_axios_response_status(i64)

declare i64 @js_axios_response_status_text(i64)

declare i64 @js_axios_response_data(i64)

declare double @js_axios_response_data_parsed(i64)

declare i64 @js_sharp_auto_orient(i64)

declare i64 @js_sharp_avif(i64, double)

declare i64 @js_sharp_blur(i64, double)

declare i64 @js_sharp_composite(i64, double)

declare i64 @js_sharp_extend(i64, double)

declare i64 @js_sharp_extract(i64, double)

declare i64 @js_sharp_flip(i64)

declare i64 @js_sharp_flop(i64)

declare i64 @js_sharp_from_buffer(i64, double)

declare i64 @js_sharp_from_file(i64)

declare i64 @js_sharp_from_input(i64)

declare i64 @js_sharp_grayscale(i64)

declare i64 @js_sharp_metadata(i64)

declare i64 @js_sharp_sharpen(i64)

declare i64 @js_sharp_trim(i64)

declare i64 @js_sharp_negate(i64)

declare i64 @js_sharp_quality(i64, double)

declare i64 @js_sharp_resize(i64, double, double)

declare i64 @js_sharp_rotate(i64, double)

declare i64 @js_sharp_to_buffer(i64)

declare i64 @js_sharp_to_file(i64, i64)

declare i64 @js_sharp_to_format(i64, i64)

declare void @js_cron_clear_interval(i64)

declare void @js_cron_clear_timeout(i64)

declare i64 @js_cron_describe(i64)

declare double @js_cron_job_is_running(i64)

declare i64 @js_cron_job_new(i64, i64, double)

declare void @js_cron_job_start(i64)

declare void @js_cron_job_stop(i64)

declare i64 @js_cron_next_date(i64)

declare i64 @js_cron_next_dates(i64, double)

declare i64 @js_cron_schedule(i64, i64)

declare i64 @js_cron_set_interval(double, double)

declare i64 @js_cron_set_timeout(double, double)

declare i32 @js_cron_timer_has_pending()

declare i32 @js_cron_timer_tick()

declare double @js_cron_validate(i64)

declare i64 @js_async_hooks_create_hook(double)

declare double @js_async_hooks_execution_async_id()

declare double @js_async_hooks_trigger_async_id()

declare double @js_async_hooks_execution_async_resource()

declare i64 @js_async_hook_enable(i64)

declare i64 @js_async_hook_disable(i64)

declare i64 @js_async_resource_new(double, double)

declare double @js_async_resource_subclass_init(double, double, double)

declare double @js_async_resource_async_id(i64)

declare double @js_async_resource_trigger_async_id(i64)

declare i64 @js_async_resource_emit_destroy(i64)

declare double @js_async_resource_run_in_async_scope(i64, double, double, i64)

declare i64 @js_async_resource_bind(i64, double, double)

declare i64 @js_async_resource_static_bind(i64, double)

declare void @js_async_local_storage_disable(i64)

declare void @js_async_local_storage_enter_with(i64, double)

declare double @js_async_local_storage_exit(i64, double, i64)

declare double @js_async_local_storage_get_store(i64)

declare i64 @js_async_local_storage_new()

declare double @js_async_local_storage_subclass_init(double)

declare double @js_async_local_storage_run(i64, double, double, i64)

declare i64 @js_disposable_stack_new()

declare i64 @js_async_disposable_stack_new()

declare double @js_suppressed_error_new(double, double, double)

declare i64 @js_zlib_deflate_sync(i64, double)

declare void @js_zlib_deflate(double, double)

declare i64 @js_zlib_gunzip_sync(i64)

declare void @js_zlib_gunzip(double, double)

declare i64 @js_zlib_gzip_sync(i64, double)

declare void @js_zlib_gzip(double, double)

declare i64 @js_zlib_inflate_sync(i64)

declare void @js_zlib_inflate(double, double)

declare i64 @js_zlib_deflate_raw_sync(double, double)

declare void @js_zlib_deflate_raw(double, double)

declare i64 @js_zlib_inflate_raw_sync(double)

declare void @js_zlib_inflate_raw(double, double)

declare i64 @js_zlib_unzip_sync(double)

declare void @js_zlib_unzip(double, double)

declare double @js_zlib_crc32(double, double)

declare i64 @js_zlib_brotli_compress_sync(i64)

declare i64 @js_zlib_brotli_decompress_sync(i64)

declare void @js_zlib_brotli_compress(double, double)

declare void @js_zlib_brotli_decompress(double, double)

declare i64 @js_zlib_zstd_compress_sync(double, double)

declare i64 @js_zlib_zstd_decompress_sync(double, double)

declare void @js_zlib_zstd_compress(double, double)

declare void @js_zlib_zstd_decompress(double, double)

declare i64 @js_zlib_create_gzip(double)

declare i64 @js_zlib_create_gunzip(double)

declare i64 @js_zlib_create_deflate(double)

declare i64 @js_zlib_create_inflate(double)

declare i64 @js_zlib_create_deflate_raw(double)

declare i64 @js_zlib_create_inflate_raw(double)

declare i64 @js_zlib_create_unzip(double)

declare i64 @js_zlib_create_brotli_compress(double)

declare i64 @js_zlib_create_zstd_compress(double)

declare i64 @js_zlib_create_zstd_decompress(double)

declare i64 @js_buffer_alloc_unsafe(i32)

declare i32 @js_buffer_byte_length(i64)

declare i32 @js_buffer_byte_length_value(double, double)

declare i64 @js_buffer_concat(i64)

declare i64 @js_buffer_concat_with_length(i64, double)

declare i32 @js_buffer_validate_size(double)

declare i64 @js_buffer_validate_concat_list(double)

declare i32 @js_buffer_copy(i64, i64, i32, i32, i32)

declare i32 @js_buffer_equals(i64, i64)

declare i64 @js_buffer_fill(i64, i32)

declare i64 @js_buffer_from_value(i64, i32)

declare double @js_buffer_is_ascii(double)

declare i32 @js_buffer_is_buffer(i64)

declare i32 @js_buffer_is_node_buffer(i64)

declare i32 @js_buffer_is_encoding(double)

declare double @js_buffer_is_utf8(double)

declare void @js_buffer_print(i64)

declare void @js_buffer_set(i64, i32, i32)

declare void @js_buffer_set_from(i64, i64, i32)

declare i64 @js_buffer_slice(i64, i32, i32)

declare i64 @js_buffer_to_string(i64, i32)

declare i64 @js_buffer_transcode(double, double, double)

declare i32 @js_buffer_write(i64, i64, i32, i32)

declare double @js_child_process_exec_sync(i64, i64)

declare double @js_child_process_exec(i64, double, double)

declare i64 @js_child_process_get_process_status(double)

declare i32 @js_child_process_kill_process(double)

declare i64 @js_child_process_spawn_background(double, i64, double, double)

declare i64 @js_child_process_spawn_sync(i64, i64, i64)

declare double @js_child_process_spawn_streams(i64, i64, i64)

declare double @js_pty_spawn(i64, i64, i64)

declare double @js_child_process_fork(i64, i64, i64)

declare double @js_child_process_exec_file(i64, double, double, double)

declare double @js_child_process_exec_file_sync(i64, double, double)

declare double @js_child_process_validate_command(double, ptr, i32)

declare double @js_child_process_validate_args(double)

declare double @js_child_process_validate_options(double, i32, i32)

declare double @js_child_process_validate_fork_module(double)

declare double @js_child_process_validate_spawn_args(double, i32, i32)

declare double @js_child_process_new()

declare i64 @js_cheerio_load(i64)

declare i64 @js_cheerio_load_fragment(i64)

declare i64 @js_cheerio_select(i64, i64)

declare i64 @js_cheerio_selection_attr(i64, i64)

declare i64 @js_cheerio_selection_attrs(i64, i64)

declare i64 @js_cheerio_selection_children(i64, i64)

declare i64 @js_cheerio_selection_eq(i64, double)

declare i64 @js_cheerio_selection_find(i64, i64)

declare i64 @js_cheerio_selection_first(i64)

declare double @js_cheerio_selection_has_class(i64, i64)

declare i64 @js_cheerio_selection_html(i64)

declare double @js_cheerio_selection_is(i64, i64)

declare i64 @js_cheerio_selection_last(i64)

declare double @js_cheerio_selection_length(i64)

declare i64 @js_cheerio_selection_parent(i64)

declare i64 @js_cheerio_selection_text(i64)

declare i64 @js_cheerio_selection_texts(i64)

declare i64 @js_cheerio_selection_to_array(i64)

declare double @js_url_file_url_to_path(double, double)

declare double @js_url_file_url_to_path_buffer(double, double)

declare double @js_url_get_hash(i64)

declare double @js_url_get_host(i64)

declare double @js_url_get_hostname(i64)

declare double @js_url_get_href(i64)

declare double @js_url_get_origin(i64)

declare double @js_url_get_pathname(i64)

declare double @js_url_get_port(i64)

declare double @js_url_get_protocol(i64)

declare double @js_url_get_search(i64)

declare double @js_url_get_search_params(i64)

declare i64 @js_url_new(i64)

declare i64 @js_url_new_with_base(i64, i64)

declare i64 @js_url_pattern_new(double, double)

declare double @js_url_pattern_constructor_call(double, double)

declare i32 @js_url_can_parse(i64)

declare i32 @js_url_can_parse_with_base(i64, i64)

declare i64 @js_url_parse(i64)

declare i64 @js_url_parse_with_base(i64, i64)

declare void @js_url_set_pathname(i64, double)

declare void @js_url_set_search(i64, double)

declare void @js_url_set_hash(i64, double)

declare void @js_url_set_protocol(i64, double)

declare void @js_url_set_hostname(i64, double)

declare void @js_url_set_port(i64, double)

declare void @js_url_set_username(i64, double)

declare void @js_url_set_password(i64, double)

declare void @js_url_set_href(i64, double)

declare double @js_url_search_params_has2(i64, double, double)

declare void @js_url_search_params_delete2(i64, double, double)

declare double @js_url_search_params_throw_missing_args(i32)

declare void @js_url_search_params_append(i64, double, double)

declare void @js_url_search_params_delete(i64, double)

declare i64 @js_url_search_params_get(i64, double)

declare double @js_url_search_params_get_all(i64, double)

declare double @js_url_search_params_has(i64, double)

declare i64 @js_url_search_params_new(i64)

declare i64 @js_url_search_params_new_any(double)

declare i64 @js_url_search_params_new_empty()

declare double @js_url_search_params_subclass_init(double, double)

declare void @js_url_search_params_set(i64, double, double)

declare i64 @js_url_search_params_to_string(i64)

declare i32 @js_url_search_params_size(i64)

declare double @js_url_search_params_entries_arr(i64)

declare double @js_url_search_params_keys_arr(i64)

declare double @js_url_search_params_values_arr(i64)

declare void @js_url_search_params_sort(i64)

declare void @js_url_search_params_for_each(i64, double, double)

declare i64 @js_url_coerce_string(double)

declare double @js_url_path_to_file_url(double, double)

declare double @js_url_domain_to_ascii(double)

declare double @js_url_domain_to_unicode(double)

declare double @js_url_to_http_options(double)

declare double @js_url_legacy_url_new()

declare double @js_url_format(double, double)

declare double @js_url_legacy_parse(double, double, double)

declare double @js_url_legacy_resolve(double, double)

declare double @js_url_legacy_resolve_object(double, double)

declare void @js_ws_close(i64)

declare i64 @js_ws_connect(i64)

declare double @js_ws_connect_start(double)

declare i64 @js_ws_handle_to_i64(double)

declare double @js_ws_is_open(i64)

declare double @js_ws_message_count(i64)

declare double @js_ws_ready_state(i64)

declare i64 @js_ws_on(i64, i64, i64)

declare i64 @js_ws_receive(i64)

declare void @js_ws_send(i64, i64)

declare void @js_ws_send_to_client(double, i64)

declare void @js_ws_close_client(double)

declare void @js_ws_send_client_i64(i64, i64)

declare void @js_ws_close_client_i64(i64)

declare i64 @js_ws_on_client_i64(i64, i64, i64)

declare void @js_ws_server_close(i64)

declare double @js_ws_server_clients(i64)

declare double @js_ws_server_address(i64)

declare i32 @js_ws_server_emit(i64, i64, double, double)

declare i64 @js_ws_server_new(double)

declare void @js_ws_handle_upgrade(i64, double, double, double, i64)

declare i64 @js_ws_wait_for_message(i64, double)

declare i64 @js_pdf_create_pdf(double)

declare void @js_pdf_add_text(i64, i64, double, double, double)

declare void @js_pdf_add_line(i64, double, double, double, double)

declare void @js_pdf_new_page(i64)

declare void @js_pdf_save(i64)

declare i64 @js_commander_action(i64, i64)

declare i64 @js_commander_command(i64, i64)

declare i64 @js_commander_description(i64, i64)

declare i64 @js_commander_get_option(i64, i64)

declare double @js_commander_get_option_bool(i64, i64)

declare double @js_commander_get_option_number(i64, i64)

declare i64 @js_commander_name(i64, i64)

declare i64 @js_commander_new()

declare i64 @js_commander_option(i64, i64, i64, i64)

declare i64 @js_commander_opts(i64)

declare i64 @js_commander_parse(i64, double)

declare i64 @js_commander_required_option(i64, i64, i64, i64)

declare i64 @js_commander_version(i64, i64)

declare double @js_dotenv_config()

declare double @js_dotenv_config_path(i64)

declare i64 @js_dotenv_parse(i64)

declare double @js_datefns_add_days(double, double)

declare double @js_datefns_add_months(double, double)

declare double @js_datefns_add_years(double, double)

declare double @js_datefns_difference_in_days(double, double)

declare double @js_datefns_difference_in_hours(double, double)

declare double @js_datefns_difference_in_minutes(double, double)

declare double @js_datefns_end_of_day(double)

declare i64 @js_datefns_format(double, i64)

declare double @js_datefns_is_after(double, double)

declare double @js_datefns_is_before(double, double)

declare double @js_datefns_parse_iso(i64)

declare double @js_datefns_start_of_day(double)

declare double @js_dayjs_add(i64, double, i64)

declare double @js_dayjs_date(i64)

declare double @js_dayjs_day(i64)

declare double @js_dayjs_diff(i64, i64, i64)

declare double @js_dayjs_end_of(i64, i64)

declare double @js_dayjs_factory(i64)

declare i64 @js_dayjs_format(i64, i64)

declare double @js_dayjs_from_timestamp(double)

declare double @js_dayjs_hour(i64)

declare double @js_dayjs_is_after(i64, i64)

declare double @js_dayjs_is_before(i64, i64)

declare double @js_dayjs_is_same(i64, i64)

declare double @js_dayjs_is_valid(i64)

declare double @js_dayjs_millisecond(i64)

declare double @js_dayjs_minute(i64)

declare double @js_dayjs_month(i64)

declare double @js_dayjs_now()

declare double @js_dayjs_parse(i64)

declare double @js_dayjs_second(i64)

declare double @js_dayjs_start_of(i64, i64)

declare double @js_dayjs_subtract(i64, double, i64)

declare i64 @js_dayjs_to_iso_string(i64)

declare double @js_dayjs_unix(i64)

declare double @js_dayjs_value_of(i64)

declare double @js_dayjs_year(i64)

declare double @js_moment_add(i64, double, i64)

declare double @js_moment_clone(i64)

declare double @js_moment_date(i64)

declare double @js_moment_day(i64)

declare double @js_moment_diff(i64, i64, i64)

declare double @js_moment_end_of(i64, i64)

declare double @js_moment_factory(i64)

declare i64 @js_moment_format(i64, i64)

declare i64 @js_moment_from_now(i64)

declare double @js_moment_from_timestamp(double)

declare double @js_moment_hour(i64)

declare double @js_moment_is_after(i64, i64)

declare double @js_moment_is_before(i64, i64)

declare double @js_moment_is_between(i64, i64, i64)

declare double @js_moment_is_same(i64, i64, i64)

declare double @js_moment_is_valid(i64)

declare double @js_moment_millisecond(i64)

declare double @js_moment_minute(i64)

declare double @js_moment_month(i64)

declare double @js_moment_now()

declare double @js_moment_parse(i64)

declare double @js_moment_second(i64)

declare double @js_moment_start_of(i64, i64)

declare double @js_moment_subtract(i64, double, i64)

declare double @js_moment_to_date(i64)

declare i64 @js_moment_to_iso_string(i64)

declare double @js_moment_unix(i64)

declare double @js_moment_value_of(i64)

declare double @js_moment_year(i64)

declare i64 @js_decimal_abs(i64)

declare i64 @js_decimal_ceil(i64)

declare double @js_decimal_cmp(i64, i64)

declare double @js_decimal_cmp_value(i64, double)

declare i64 @js_decimal_coerce_to_handle(double)

declare i64 @js_decimal_div(i64, i64)

declare i64 @js_decimal_div_number(i64, double)

declare i64 @js_decimal_div_value(i64, double)

declare double @js_decimal_eq(i64, i64)

declare double @js_decimal_eq_value(i64, double)

declare i64 @js_decimal_floor(i64)

declare i64 @js_decimal_from_number(double)

declare i64 @js_decimal_from_string(i64)

declare double @js_decimal_gt(i64, i64)

declare double @js_decimal_gt_value(i64, double)

declare double @js_decimal_gte(i64, i64)

declare double @js_decimal_gte_value(i64, double)

declare double @js_decimal_is_negative(i64)

declare double @js_decimal_is_positive(i64)

declare double @js_decimal_is_zero(i64)

declare double @js_decimal_lt(i64, i64)

declare double @js_decimal_lt_value(i64, double)

declare double @js_decimal_lte(i64, i64)

declare double @js_decimal_lte_value(i64, double)

declare i64 @js_decimal_minus(i64, i64)

declare i64 @js_decimal_minus_number(i64, double)

declare i64 @js_decimal_minus_value(i64, double)

declare i64 @js_decimal_mod(i64, i64)

declare i64 @js_decimal_mod_value(i64, double)

declare i64 @js_decimal_neg(i64)

declare i64 @js_decimal_plus(i64, i64)

declare i64 @js_decimal_plus_number(i64, double)

declare i64 @js_decimal_plus_value(i64, double)

declare i64 @js_decimal_pow(i64, double)

declare i64 @js_decimal_round(i64)

declare i64 @js_decimal_sqrt(i64)

declare i64 @js_decimal_times(i64, i64)

declare i64 @js_decimal_times_number(i64, double)

declare i64 @js_decimal_times_value(i64, double)

declare i64 @js_decimal_to_fixed(i64, double)

declare double @js_decimal_to_number(i64)

declare i64 @js_decimal_to_string(i64)

declare i64 @js_ethers_format_ether(i64)

declare i64 @js_ethers_format_units(i64, double)

declare i64 @js_ethers_get_address(i64)

declare i64 @js_ethers_parse_ether(i64)

declare i64 @js_ethers_parse_units(i64, double)

declare i64 @js_lodash_camel_case(i64)

declare i64 @js_lodash_capitalize(i64)

declare i64 @js_lodash_chunk(i64, double)

declare double @js_lodash_clamp(double, double, double)

declare i64 @js_lodash_compact(i64)

declare i64 @js_lodash_concat(i64, i64)

declare i64 @js_lodash_difference(i64, i64)

declare i64 @js_lodash_drop(i64, double)

declare i64 @js_lodash_drop_right(i64, double)

declare double @js_lodash_ends_with(i64, i64)

declare i64 @js_lodash_escape(i64)

declare double @js_lodash_first(i64)

declare i64 @js_lodash_flatten(i64)

declare double @js_lodash_in_range(double, double, double)

declare double @js_lodash_includes(i64, i64)

declare i64 @js_lodash_initial(i64)

declare i64 @js_lodash_kebab_case(i64)

declare double @js_lodash_last(i64)

declare i64 @js_lodash_lower_case(i64)

declare i64 @js_lodash_lower_first(i64)

declare double @js_lodash_max(i64)

declare double @js_lodash_max_by(i64, double)

declare double @js_lodash_mean(i64)

declare double @js_lodash_mean_by(i64, double)

declare double @js_lodash_min(i64)

declare double @js_lodash_min_by(i64, double)

declare i64 @js_lodash_pad(i64, double)

declare i64 @js_lodash_pad_end(i64, double)

declare i64 @js_lodash_pad_start(i64, double)

declare double @js_lodash_random(double, double)

declare i64 @js_lodash_repeat(i64, double)

declare i64 @js_lodash_replace(i64, i64, i64)

declare i64 @js_lodash_reverse(i64)

declare double @js_lodash_size(i64)

declare i64 @js_lodash_snake_case(i64)

declare i64 @js_lodash_split(i64, i64)

declare i64 @js_lodash_start_case(i64)

declare double @js_lodash_starts_with(i64, i64)

declare double @js_lodash_sum(i64)

declare double @js_lodash_sum_by(i64, double)

declare i64 @js_lodash_tail(i64)

declare i64 @js_lodash_take(i64, double)

declare i64 @js_lodash_take_right(i64, double)

declare i64 @js_lodash_trim(i64)

declare i64 @js_lodash_trim_end(i64)

declare i64 @js_lodash_trim_start(i64)

declare i64 @js_lodash_truncate(i64, double)

declare i64 @js_lodash_unescape(i64)

declare i64 @js_lodash_uniq(i64)

declare i64 @js_lodash_upper_case(i64)

declare i64 @js_lodash_upper_first(i64)

declare void @js_lru_cache_clear(i64)

declare double @js_lru_cache_delete(i64, double)

declare double @js_lru_cache_get(i64, double)

declare double @js_lru_cache_has(i64, double)

declare i64 @js_lru_cache_new(double)

declare double @js_lru_cache_peek(i64, double)

declare i64 @js_lru_cache_set(i64, double, double)

declare double @js_lru_cache_size(i64)

declare double @js_event_emitter_subclass_init(double)

declare double @js_event_emitter_async_resource_subclass_init(double, double)

declare double @js_array_subclass_init(double, double)

declare double @js_array_subclass_init_args(double, ptr, i64)

declare double @js_map_set_subclass_init(double, i32, double)

declare double @js_weak_collection_subclass_init(double, i32, double)

declare double @js_promise_subclass_init(double, double)

declare double @js_node_stream_readable_new(double)

declare double @js_node_stream_readable_subclass_init(double, double)

declare double @js_node_stream_writable_new(double)

declare double @js_node_stream_writable_subclass_init(double, double)

declare double @js_node_stream_duplex_new(double)

declare double @js_node_stream_duplex_subclass_init(double, double)

declare double @js_node_stream_transform_new(double)

declare double @js_node_stream_transform_subclass_init(double, double)

declare double @js_node_stream_passthrough_new(double)

declare double @js_node_stream_readable_from(double)

declare double @js_node_stream_readable_from_options(double, double)

declare double @js_node_stream_duplex_from_options(double, double)

declare double @js_node_stream_is_disturbed(double)

declare double @js_node_stream_is_errored(double)

declare double @js_node_stream_is_readable(double)

declare double @js_node_stream_is_writable(double)

declare double @js_node_stream_is_array_buffer_view(double)

declare double @js_node_stream_is_uint8_array(double)

declare double @js_node_stream_is_destroyed(double)

declare double @js_node_stream_uint8_array_to_buffer(double)

declare double @js_node_stream_get_default_hwm(double)

declare double @js_node_stream_set_default_hwm(double, double)

declare double @js_node_stream_add_abort_signal(double, double)

declare double @js_node_stream_compose(i64)

declare double @js_node_stream_pipeline(i64)

declare double @js_node_stream_finished(i64)

declare double @js_node_stream_duplex_pair(double)

declare double @js_node_stream_readable_to_web(double)

declare double @js_node_stream_writable_to_web(double)

declare double @js_node_stream_duplex_to_web(double)

declare double @js_node_stream_readable_from_web(double, double)

declare double @js_node_stream_writable_from_web(double, double)

declare double @js_node_stream_duplex_from_web(double, double)

declare double @js_node_stream_to_web(double)

declare double @js_node_stream_from_web(double)

declare double @js_node_stream_method_readable_aborted(i64)

declare double @js_node_stream_method_closed(i64)

declare double @js_node_stream_method_errored(i64)

declare double @js_node_stream_method_readable_did_read(i64)

declare double @js_node_stream_method_destroyed(i64)

declare double @js_node_stream_method_destroy(i64, double)

declare double @js_node_stream_method_pause(i64)

declare double @js_node_stream_method_readable(i64)

declare double @js_node_stream_method_readable_length(i64)

declare double @js_node_stream_method_readable_flowing(i64)

declare double @js_node_stream_method_readable_ended(i64)

declare double @js_node_stream_method_readable_object_mode(i64)

declare double @js_node_stream_method_pipe(i64, double, double)

declare double @js_node_stream_method_unpipe(i64, double)

declare double @js_node_stream_method_is_paused(i64)

declare double @js_node_stream_method_resume(i64)

declare double @js_node_stream_method_readable_encoding(i64)

declare double @js_node_stream_method_cork(i64)

declare double @js_node_stream_method_uncork(i64)

declare double @js_node_stream_method_writable_corked(i64)

declare double @js_node_stream_method_writable_length(i64)

declare double @js_node_stream_method_writable_need_drain(i64)

declare double @js_node_stream_method_writable(i64)

declare double @js_node_stream_method_writable_ended(i64)

declare double @js_node_stream_method_writable_finished(i64)

declare double @js_node_stream_method_allow_half_open(i64)

declare double @js_node_stream_method_set_encoding(i64, double)

declare double @js_node_stream_method_writable_object_mode(i64)

declare double @js_event_emitter_emit(i64, i64, i64)

declare double @js_event_emitter_emit0(i64, i64)

declare double @js_event_emitter_listener_count(i64, i64, i64)

declare i64 @js_event_emitter_new()

declare i64 @js_event_emitter_new_with_options(double)

declare i64 @js_event_emitter_on(i64, i64, i64)

declare i64 @js_event_emitter_once(i64, i64, i64)

declare i64 @js_event_emitter_prepend_listener(i64, i64, i64)

declare i64 @js_event_emitter_prepend_once_listener(i64, i64, i64)

declare i64 @js_event_emitter_remove_all_listeners(i64, i64)

declare i64 @js_event_emitter_remove_listener(i64, i64, i64)

declare i64 @js_event_emitter_set_max_listeners(i64, double)

declare double @js_event_emitter_get_max_listeners(i64)

declare i64 @js_event_emitter_event_names(i64)

declare i64 @js_event_emitter_listeners(i64, i64)

declare i64 @js_event_emitter_raw_listeners(i64, i64)

declare double @js_event_emitter_domain_value(i64)

declare i64 @js_event_emitter_async_resource_new(double)

declare double @js_event_emitter_async_resource_call(double)

declare double @js_event_emitter_async_resource_async_id(i64)

declare double @js_event_emitter_async_resource_trigger_async_id(i64)

declare double @js_event_emitter_async_resource_async_resource(i64)

declare double @js_event_emitter_async_resource_emit_destroy(i64)

declare i64 @js_events_once(double, i64, double)

declare i64 @js_events_on(double, i64, double)

declare i64 @js_events_add_abort_listener(double, double)

declare i64 @js_events_get_event_listeners(double, i64)

declare double @js_events_listener_count(double, i64)

declare double @js_events_get_max_listeners(double)

declare double @js_events_set_max_listeners(double, i64)

declare double @js_events_init()

declare i64 @js_domain_create()

declare i64 @js_domain_on(i64, i64, i64)

declare double @js_domain_emit(i64, i64, i64)

declare double @js_domain_run(i64, double, i64)

declare double @js_domain_bind(i64, double)

declare double @js_domain_intercept(i64, double)

declare i64 @js_domain_add(i64, double)

declare i64 @js_domain_remove(i64, double)

declare double @js_domain_enter(i64)

declare double @js_domain_exit(i64)

declare i64 @js_string_decoder_new(i64)

declare double @js_string_decoder_write(i64, double)

declare double @js_string_decoder_end(i64, double)

declare double @js_querystring_escape(double)

declare double @js_querystring_unescape(double)

declare i64 @js_querystring_unescape_buffer(double, double)

declare i64 @js_querystring_parse(double, double, double, double)

declare double @js_querystring_stringify(double, double, double, double)

declare i32 @js_fastify_add_hook(i64, i64, i64)

declare i32 @js_fastify_all(i64, i64, i64)

declare i64 @js_fastify_create()

declare i64 @js_fastify_create_with_opts(double)

declare double @js_fastify_ctx_html(i64, i64, double)

declare double @js_fastify_ctx_json(i64, double, double)

declare double @js_fastify_ctx_redirect(i64, i64, double)

declare double @js_fastify_ctx_text(i64, i64, double)

declare i32 @js_fastify_delete(i64, i64, i64)

declare i32 @js_fastify_get(i64, i64, i64)

declare i32 @js_fastify_head(i64, i64, i64)

declare void @js_fastify_listen(i64, double, i64)

declare void @js_fastify_app_close(i64)

declare i64 @js_fastify_app_server(i64)

declare void @js_fastify_app_on(i64, i64, i64)

declare i32 @js_fastify_options(i64, i64, i64)

declare i32 @js_fastify_patch(i64, i64, i64)

declare i32 @js_fastify_post(i64, i64, i64)

declare i32 @js_fastify_put(i64, i64, i64)

declare i32 @js_fastify_register(i64, i64, double)

declare i64 @js_fastify_reply_header(i64, i64, i64)

declare i32 @js_fastify_reply_send(i64, double)

declare i64 @js_fastify_reply_status(i64, double)

declare i64 @js_fastify_reply_type(i64, i64)

declare i64 @js_fastify_req_body(i64)

declare double @js_fastify_req_get_user_data(i64)

declare i64 @js_fastify_req_header(i64, i64)

declare i64 @js_fastify_req_headers(i64)

declare double @js_fastify_req_json(i64)

declare i64 @js_fastify_req_method(i64)

declare i64 @js_fastify_req_param(i64, i64)

declare i64 @js_fastify_req_params(i64)

declare i64 @js_fastify_req_query(i64)

declare double @js_fastify_req_query_object(i64)

declare void @js_fastify_req_set_user_data(i64, double)

declare i64 @js_fastify_req_url(i64)

declare i32 @js_fastify_route(i64, i64, i64, i64)

declare i32 @js_fastify_set_error_handler(i64, i64)

declare double @js_nodemailer_create_transport(i64)

declare i64 @js_nodemailer_send_mail(i64, i64)

declare i64 @js_nodemailer_verify(i64)

declare i64 @js_ratelimit_block(i64, i64, double)

declare i64 @js_ratelimit_consume(i64, i64, double)

declare i64 @js_ratelimit_create(i64)

declare i64 @js_ratelimit_delete(i64, i64)

declare i64 @js_ratelimit_get(i64, i64)

declare i64 @js_ratelimit_new_from_options(i64)

declare i64 @js_ratelimit_penalty(i64, i64, double)

declare i64 @js_ratelimit_reward(i64, i64, double)

declare double @js_validator_contains(i64, i64)

declare double @js_validator_equals(i64, i64)

declare double @js_validator_is_alpha(i64)

declare double @js_validator_is_alphanumeric(i64)

declare double @js_validator_is_email(i64)

declare double @js_validator_is_empty(i64)

declare double @js_validator_is_float(i64)

declare double @js_validator_is_hexadecimal(i64)

declare double @js_validator_is_int(i64)

declare double @js_validator_is_json(i64)

declare double @js_validator_is_length(i64, double, double)

declare double @js_validator_is_lowercase(i64)

declare double @js_validator_is_numeric(i64)

declare double @js_validator_is_uppercase(i64)

declare double @js_validator_is_url(i64)

declare double @js_validator_is_uuid(i64)

declare i64 @js_date_to_locale_string(double)

declare i64 @js_number_to_locale_string(double)

declare double @js_value_to_locale_string(double)

declare i64 @js_string_split_regex(i64, i64)

declare i32 @js_object_delete_dynamic(i64, double)

declare double @js_object_get_prototype_of(double)

declare double @js_object_set_prototype_of(double, double)

declare double @js_object_define_properties(double, double)

declare double @js_math_acos(double)

declare double @js_math_asin(double)

declare double @js_math_atan(double)

declare double @js_math_atan2(double, double)

declare double @js_math_cos(double)

declare double @js_math_expm1(double)

declare double @js_math_log(double)

declare double @js_math_log10(double)

declare double @js_math_log1p(double)

declare double @js_math_log2(double)

declare double @js_math_sin(double)

declare double @js_math_tan(double)

declare double @js_atomics_load(ptr, double, double)

declare double @js_atomics_is_lock_free(ptr, double)

declare double @js_atomics_store(ptr, double, double, double)

declare double @js_atomics_add(ptr, double, double, double)

declare double @js_atomics_sub(ptr, double, double, double)

declare double @js_atomics_and(ptr, double, double, double)

declare double @js_atomics_or(ptr, double, double, double)

declare double @js_atomics_xor(ptr, double, double, double)

declare double @js_atomics_exchange(ptr, double, double, double)

declare double @js_atomics_compare_exchange(ptr, double, double, double, double)

declare double @js_atomics_notify(ptr, double, double, double)

declare double @js_atomics_wait(ptr, double, double, double, double)

declare double @js_atomics_wait_async(ptr, double, double, double, double)

declare double @js_number_is_finite(double)

declare double @js_json_get_bool(i64, i64)

declare double @js_json_get_number(i64, i64)

declare i64 @js_json_get_string(i64, i64)

declare double @js_json_is_valid(i64)

declare i64 @js_json_stringify_bool(double)

declare i64 @js_json_stringify_null()

declare i64 @js_json_stringify_number(double)

declare i64 @js_json_stringify_string(i64)

declare void @js_set_property(double, i64, i64, double)

declare i64 @js_error_get_message(i64)

declare double @js_await_js_promise(double)

declare i64 @js_text_decoder_decode(i64)

declare i64 @js_text_encoder_encode(double)

declare double @js_call_function(i64, i64, i64, i64, i64)

declare double @js_call_method(double, i64, i64, i64, i64)

declare double @js_call_value(double, i64, i64)

declare double @js_closure_call_array(i64, ptr, i64)

declare double @js_closure_call_apply_with_spread(double, ptr, i64, i64)

declare double @js_create_callback(i64, i64, i64)

declare double @js_dynamic_neg(double)

declare double @js_dynamic_pos(double)

declare i32 @js_dynamic_string_equals(double, double)

declare double @js_is_nan(double)

declare i32 @js_jsvalue_compare(double, double)

declare i32 @js_jsvalue_loose_equals(double, double)

declare void @js_gc_collect()

declare void @js_console_assert(double, i64)

declare void @js_console_assert_spread(double, i64)

declare void @js_console_group(i64)

declare double @js_console_context(double)

declare double @js_console_create_task(double)

declare i64 @js_fetch_input_ptr(double)

declare i64 @js_fetch_get(i64)

declare i64 @js_fetch_get_with_auth(i64, i64)

declare i64 @js_fetch_post(i64, i64, i64)

declare i64 @js_fetch_post_with_auth(i64, i64, i64)

declare double @js_fetch_stream_close(double)

declare i64 @js_fetch_stream_poll(double)

declare double @js_fetch_stream_start(i64, i64, i64, i64)

declare double @js_fetch_stream_status(double)

declare i64 @js_fetch_text(i64)

declare i64 @js_fetch_with_options(i64, i64, i64, i64)

declare void @js_fetch_set_pending_signal(double)

declare i64 @js_fetch_headers_to_json(double)

declare double @js_net_create_connection(i32, i64, i64)

declare i64 @js_net_create_server(i64, i64)

declare i64 @js_ext_net_create_server(i64, i64)

declare i64 @js_ext_net_socket_connect(double, double, double)

declare double @js_net_normalize_args(double)

declare double @js_net_create_server_handle_stub(double, double, double, double, double)

declare void @js_net_validate_create_server_options(double)

declare i64 @js_net_socket_set_timeout(i64, double, i64)

declare void @js_net_server_listen(i64, double, double, double)

declare void @js_net_server_close(i64, i64)

declare i64 @js_net_server_address(i64)

declare void @js_net_server_on(i64, i64, i64)

declare double @js_net_server_get_listening(i64)

declare double @js_net_server_get_connections(i64)

declare double @js_net_server_get_max_connections(i64)

declare double @js_net_server_set_max_connections(i64, double)

declare double @js_net_server_get_drop_max_connection(i64)

declare double @js_net_server_set_drop_max_connection(i64, double)

declare i64 @js_net_block_list_new()

declare double @js_net_block_list_is_block_list(double)

declare double @js_net_block_list_add_address(i64, i64, i64)

declare double @js_net_block_list_add_range(i64, i64, i64, i64)

declare double @js_net_block_list_add_subnet(i64, i64, double, i64)

declare double @js_net_block_list_check(i64, i64, i64)

declare double @js_net_block_list_to_json(i64)

declare i64 @js_net_block_list_rules(i64)

declare double @js_net_block_list_from_json(i64, double)

declare i64 @js_net_socket_address_new(double)

declare double @js_net_socket_address_parse(i64)

declare i64 @js_net_socket_address_get_address(i64)

declare i64 @js_net_socket_address_get_family(i64)

declare double @js_net_socket_address_get_port(i64)

declare double @js_net_socket_address_get_flowlabel(i64)

declare double @js_net_socket_get_type_of_service(i64)

declare i64 @js_net_socket_set_type_of_service(i64, double)

declare i64 @js_net_socket_address(i64)

declare i64 @js_net_socket_once(i64, i64, i64)

declare i64 @js_ext_net_socket_once(i64, i64, i64)

declare void @js_ext_net_socket_on(i64, i64, i64)

declare i64 @js_ext_tls_connect(double, double, double, double)

declare i64 @js_net_socket_remove_listener(i64, i64, i64)

declare i64 @js_net_socket_remove_all_listeners(i64, i64)

declare double @js_net_socket_listener_count(i64, i64)

declare i64 @js_net_socket_event_names(i64)

declare i64 @js_net_socket_reset_and_destroy(i64)

declare i64 @js_net_server_once(i64, i64, i64)

declare i64 @js_net_server_remove_listener(i64, i64, i64)

declare i64 @js_net_server_remove_all_listeners(i64, i64)

declare double @js_net_server_listener_count(i64, i64)

declare i64 @js_net_server_event_names(i64)

declare double @js_performance_now()

declare double @js_perf_mark(double, double)

declare double @js_perf_measure(double, double, double)

declare double @js_perf_get_entries()

declare double @js_perf_get_entries_by_type(double)

declare double @js_perf_get_entries_by_name(double, double)

declare double @js_perf_clear_marks(double)

declare double @js_perf_clear_measures(double)

declare double @js_perf_event_loop_utilization(double, double)

declare double @js_perf_to_json()

declare double @js_perf_clear_resource_timings()

declare double @js_perf_set_resource_timing_buffer_size(double)

declare double @js_perf_mark_resource_timing(double, double, double, double, double, double, double, double)

declare double @js_perf_timerify(double, double)

declare double @js_perf_observer_new(double)

declare double @js_perf_observer_observe(double, double)

declare double @js_perf_observer_disconnect(double)

declare double @js_perf_observer_take_records(double)

declare double @js_perf_monitor_event_loop_delay(double)

declare double @js_perf_create_histogram(double)

declare double @js_iter_result_set(double, i32)

declare double @js_iter_result_set_f64(double, i32)

declare double @js_iter_result_set_i32(i32, i32)

declare double @js_iter_result_set_i1(i32, i32)

declare double @js_iter_result_get_value()

declare double @js_iter_result_get_value_f64()

declare i32 @js_iter_result_get_value_i32()

declare i32 @js_iter_result_get_value_i1()

declare double @js_iter_result_get_done()

declare i64 @js_async_step_chain(double, i64)

declare i64 @js_async_step_done(double, i64)

declare i64 @js_get_current_step_closure()

declare double @js_async_first_call(double)

declare double @js_async_generator_resume(double, double, double)

declare void @js_register_class_getter(i64, i64, i64, i64)

declare void @js_register_class_setter(i64, i64, i64, i64)

declare void @js_register_class_string_member_order(i64, i64, i64, i64, i64)

declare void @js_register_class_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_getter(i64, i64, i64, i64)

declare void @js_register_class_static_setter(i64, i64, i64, i64)

declare void @js_register_class_method(i64, i64, i64, i64, i64, i64, i64)

declare void @js_register_class_constructor(i64, i64, i64, i64)

declare void @js_register_class_constructor_flags(i64, i64, i64)

declare void @js_register_class_static_method(i64, i64, i64, i64, i64, i64)

declare double @js_class_static_method_call(double, i64, i64, ptr, i64)

declare double @js_class_method_bind(double, i64, i64)

declare double @js_class_method_snapshot_bind(double, i64, i64)

declare double @js_class_method_bind_by_id(double, i64)

declare double @js_class_lexical_binding_get(double)

declare double @js_class_lexical_binding_set(double, double)

declare double @js_class_prototype_method_value(double, double)

declare double @js_implicit_this_get()

declare double @js_implicit_this_get_sloppy()

declare double @js_implicit_this_set(double)

declare double @js_static_this_resolve(double)

declare void @js_static_this_arm_classref(i32)

declare void @js_static_this_arm_value(double)

declare double @js_ctor_return_override(double, double, i32)

declare double @js_new_target_get()

declare double @js_new_target_set(double)

declare void @js_derived_super_scope_push(ptr)

declare void @js_derived_super_scope_pop()

declare double @js_derived_super_bind_current()

declare double @js_derived_this_check_current()

declare double @js_get_export(i64, i64, i64)

declare double @js_get_property(double, i64, i64)

declare i64 @js_load_module(i64, i64)

declare double @js_module_dynamic_import_apply_hooks(double)

declare double @js_native_call_method_nullsafe(double, i64, i64, i64, i64)

declare double @js_native_call_value(double, i64, i64)

declare double @js_new_from_handle(double, i64, i64)

declare double @js_new_instance(i64, i64, i64, i64, i64)

declare void @js_runtime_init()

declare double @js_object_set_symbol_method(double, double, double)

declare double @js_object_set_method_by_name(double, double, double)

declare double @js_object_define_accessor(double, double, double, double)

declare double @js_object_literal_set_computed(double, double, double)

declare double @js_object_literal_to_property_key(double)

declare double @js_object_literal_set_prototype(double, double)

declare double @js_to_primitive(double, i32)

declare void @js_register_class_has_instance(i32, i64)

declare void @js_register_class_to_string_tag(i32, i64)

declare double @js_object_to_string(double)

declare double @js_object_group_by(double, double)

declare double @js_map_group_by(double, double)

declare double @js_array_from_async(double, double, double)

declare double @js_jsx(double, double)

declare double @js_jsxs(double, double)

declare i64 @js_node_http_server_ref(i64)

declare i64 @js_node_http_server_unref(i64)

declare i64 @js_node_https_server_ref(i64)

declare i64 @js_node_https_server_unref(i64)

declare double @js_http_client_request_flush_headers(i64, double, double)

declare double @js_node_http_im_http_version_major(i64)

declare double @js_node_http_im_http_version_minor(i64)

declare i64 @js_node_http_im_pause_self(i64)

declare i64 @js_node_http_im_resume_self(i64)

declare i64 @js_commander_args_array(i64)

declare i64 @js_commander_argument(i64, i64)

declare double @__ic_decl_5()

declare double @__ic_decl_7()

declare double @__ic_decl_10()

declare double @__ic_decl_12()

declare double @__ic_decl_14()

declare double @__ic_decl_16()

declare double @__ic_decl_18()

declare double @__ic_decl_20()

declare token @llvm.experimental.gc.statepoint.p0(i64 immarg, i32 immarg, ptr, i32 immarg, i32 immarg, ...)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token, i32 immarg, i32 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.experimental.gc.result.i1(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i8 @llvm.experimental.gc.result.i8(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i16 @llvm.experimental.gc.result.i16(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.experimental.gc.result.i32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i64 @llvm.experimental.gc.result.i64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i128 @llvm.experimental.gc.result.i128(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.experimental.gc.result.f32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare double @llvm.experimental.gc.result.f64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr @llvm.experimental.gc.result.p0(token) #3

; Function Attrs: optsize
define internal double @__perry_wrap_perry_unknown_func_test_json_warm_unique_keys_ts(i64 %this_closure, double %a0, double %a1, double %a2, double %a3, double %a4) #6 {
entry.0:
  ret double 0x7FFC000000000001
}

; Function Attrs: optsize
define void @test_json_warm_unique_keys_ts__init() #6 {
entry.0:
  ret void
}

; Function Attrs: optsize
define i32 @main() #6 gc "statepoint-example" personality ptr @perry_eh_personality {
entry.0:
  %r261 = alloca [32 x double], align 8
  %r745 = alloca [32 x double], align 8
  %r1020 = alloca [32 x double], align 8
  %r1504 = alloca [32 x double], align 8
  %r1779 = alloca [32 x double], align 8
  %r2263 = alloca [32 x double], align 8
  %r2538 = alloca [32 x double], align 8
  %r3022 = alloca [32 x double], align 8
  %r3499 = alloca [32 x double], align 8
  %r3538 = alloca [7 x i64], align 8
  %r4374 = alloca [32 x double], align 8
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (ptr, i32)) @js_set_process_entry_path, i32 2, i32 0, ptr @test_json_warm_unique_keys_ts_.str.0, i32 135, i32 0, i32 0)
  %statepoint_token35 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_init, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token36 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32)) @js_gc_write_barriers_emitted, i32 1, i32 0, i32 1, i32 0, i32 0)
  %statepoint_token37 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @perry_macos_bundle_chdir, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token38 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @__perry_init_strings_test_json_warm_unique_keys_ts, i32 0, i32 0, i32 0, i32 0)
  %r2 = load double, ptr @test_json_warm_unique_keys_ts_.str.0.handle, align 8
  %r3 = load double, ptr @test_json_warm_unique_keys_ts_.str.1.handle, align 8
  %r4 = load double, ptr @test_json_warm_unique_keys_ts_.str.2.handle, align 8
  %r5 = load double, ptr @test_json_warm_unique_keys_ts_.str.3.handle, align 8
  %r6 = load double, ptr @test_json_warm_unique_keys_ts_.str.4.handle, align 8
  %r7 = load double, ptr @test_json_warm_unique_keys_ts_.str.5.handle, align 8
  %r8 = load double, ptr @test_json_warm_unique_keys_ts_.str.6.handle, align 8
  %r9 = load double, ptr @test_json_warm_unique_keys_ts_.str.7.handle, align 8
  br label %arena_state.init.1

arena_state.init.1:                               ; preds = %entry.0
  %r13 = load atomic i64, ptr @PERRY_HOT_TSD_KEY monotonic, align 8
  %r14 = icmp ne i64 %r13, -1
  br i1 %r14, label %arena_state.hot_tls.tsd.3, label %arena_state.hot_tls.slow.5

arena_state.ready.2:                              ; preds = %arena_state.hot_tls.resolved.7
  %r29 = getelementptr i8, ptr %r27, i64 8
  %r30 = load i64, ptr %r29, align 8
  %r31 = add i64 %r30, 80
  %r32 = getelementptr i8, ptr %r27, i64 16
  %r33 = load i64, ptr %r32, align 8
  %r34 = icmp ule i64 %r31, %r33
  br i1 %r34, label %arrlit.fast.8, label %arrlit.slow.9

arena_state.hot_tls.tsd.3:                        ; preds = %arena_state.init.1
  %r15 = call i64 asm sideeffect "mrs $0, tpidrro_el0", "=r"() #7
  %r16 = and i64 %r15, -8
  %r17 = shl i64 %r13, 3
  %r18 = add i64 %r16, %r17
  %r19 = inttoptr i64 %r18 to ptr
  %r20 = load ptr, ptr %r19, align 8
  %r21 = icmp ne ptr %r20, null
  br i1 %r21, label %arena_state.hot_tls.fast.4, label %arena_state.hot_tls.slow.5

arena_state.hot_tls.fast.4:                       ; preds = %arena_state.hot_tls.tsd.3
  %r22 = getelementptr i8, ptr %r20, i64 8
  %r23 = load ptr, ptr %r22, align 8
  %r24 = load ptr, ptr %r23, align 8
  %r25 = icmp ne ptr %r24, null
  br i1 %r25, label %arena_state.hot_tls.ready.6, label %arena_state.hot_tls.slow.5

arena_state.hot_tls.slow.5:                       ; preds = %arena_state.hot_tls.fast.4, %arena_state.hot_tls.tsd.3, %arena_state.init.1
  %statepoint_token39 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr ()) @js_inline_arena_state, i32 0, i32 0, i32 0, i32 0)
  %r2640 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token39)
  br label %arena_state.hot_tls.resolved.7

arena_state.hot_tls.ready.6:                      ; preds = %arena_state.hot_tls.fast.4
  br label %arena_state.hot_tls.resolved.7

arena_state.hot_tls.resolved.7:                   ; preds = %arena_state.hot_tls.ready.6, %arena_state.hot_tls.slow.5
  %r27 = phi ptr [ %r23, %arena_state.hot_tls.ready.6 ], [ %r2640, %arena_state.hot_tls.slow.5 ]
  br label %arena_state.ready.2

arrlit.fast.8:                                    ; preds = %arena_state.ready.2
  store i64 %r31, ptr %r29, align 8
  %r35 = load ptr, ptr %r27, align 8
  %r36 = getelementptr i8, ptr %r35, i64 %r30
  br label %arrlit.merge.10

arrlit.slow.9:                                    ; preds = %arena_state.ready.2
  %statepoint_token41 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr (ptr, i64, i64)) @js_inline_arena_slow_alloc, i32 3, i32 0, ptr %r27, i64 80, i64 8, i32 0, i32 0)
  %r3742 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token41)
  br label %arrlit.merge.10

arrlit.merge.10:                                  ; preds = %arrlit.slow.9, %arrlit.fast.8
  %r38 = phi ptr [ %r36, %arrlit.fast.8 ], [ %r3742, %arrlit.slow.9 ]
  store i64 344671126017, ptr %r38, align 8
  %r39 = getelementptr i8, ptr %r38, i64 8
  store i64 34359738376, ptr %r39, align 8
  %r40 = getelementptr i8, ptr %r38, i64 8
  %r41 = ptrtoint ptr %r40 to i64
  %r42 = getelementptr inbounds nuw i8, ptr %r38, i64 16
  %r5923 = load double, ptr @test_json_warm_unique_keys_ts_.str.0.handle, align 8
  store double %r5923, ptr %r42, align 8
  %r5922 = load double, ptr @test_json_warm_unique_keys_ts_.str.0.handle, align 8
  call void @js_string_addref_if_heap_string(double %r5922) #7
  %r5921 = load double, ptr @test_json_warm_unique_keys_ts_.str.0.handle, align 8
  %r43 = bitcast double %r5921 to i64
  %r5919 = load double, ptr @test_json_warm_unique_keys_ts_.str.0.handle, align 8
  %r5920 = bitcast double %r5919 to i64
  call void @js_gc_note_slot_layout(i64 %r41, i32 0, i64 %r5920) #7
  %r44 = getelementptr inbounds nuw i8, ptr %r38, i64 24
  %r5918 = load double, ptr @test_json_warm_unique_keys_ts_.str.1.handle, align 8
  store double %r5918, ptr %r44, align 8
  %r5917 = load double, ptr @test_json_warm_unique_keys_ts_.str.1.handle, align 8
  call void @js_string_addref_if_heap_string(double %r5917) #7
  %r5916 = load double, ptr @test_json_warm_unique_keys_ts_.str.1.handle, align 8
  %r45 = bitcast double %r5916 to i64
  %r5914 = load double, ptr @test_json_warm_unique_keys_ts_.str.1.handle, align 8
  %r5915 = bitcast double %r5914 to i64
  call void @js_gc_note_slot_layout(i64 %r41, i32 1, i64 %r5915) #7
  %r46 = getelementptr inbounds nuw i8, ptr %r38, i64 32
  %r5913 = load double, ptr @test_json_warm_unique_keys_ts_.str.2.handle, align 8
  store double %r5913, ptr %r46, align 8
  %r5912 = load double, ptr @test_json_warm_unique_keys_ts_.str.2.handle, align 8
  call void @js_string_addref_if_heap_string(double %r5912) #7
  %r5911 = load double, ptr @test_json_warm_unique_keys_ts_.str.2.handle, align 8
  %r47 = bitcast double %r5911 to i64
  %r5909 = load double, ptr @test_json_warm_unique_keys_ts_.str.2.handle, align 8
  %r5910 = bitcast double %r5909 to i64
  call void @js_gc_note_slot_layout(i64 %r41, i32 2, i64 %r5910) #7
  %r48 = getelementptr inbounds nuw i8, ptr %r38, i64 40
  %r5908 = load double, ptr @test_json_warm_unique_keys_ts_.str.3.handle, align 8
  store double %r5908, ptr %r48, align 8
  %r5907 = load double, ptr @test_json_warm_unique_keys_ts_.str.3.handle, align 8
  call void @js_string_addref_if_heap_string(double %r5907) #7
  %r5906 = load double, ptr @test_json_warm_unique_keys_ts_.str.3.handle, align 8
  %r49 = bitcast double %r5906 to i64
  %r5904 = load double, ptr @test_json_warm_unique_keys_ts_.str.3.handle, align 8
  %r5905 = bitcast double %r5904 to i64
  call void @js_gc_note_slot_layout(i64 %r41, i32 3, i64 %r5905) #7
  %r50 = getelementptr inbounds nuw i8, ptr %r38, i64 48
  %r5903 = load double, ptr @test_json_warm_unique_keys_ts_.str.4.handle, align 8
  store double %r5903, ptr %r50, align 8
  %r5902 = load double, ptr @test_json_warm_unique_keys_ts_.str.4.handle, align 8
  call void @js_string_addref_if_heap_string(double %r5902) #7
  %r5901 = load double, ptr @test_json_warm_unique_keys_ts_.str.4.handle, align 8
  %r51 = bitcast double %r5901 to i64
  %r5899 = load double, ptr @test_json_warm_unique_keys_ts_.str.4.handle, align 8
  %r5900 = bitcast double %r5899 to i64
  call void @js_gc_note_slot_layout(i64 %r41, i32 4, i64 %r5900) #7
  %r52 = getelementptr inbounds nuw i8, ptr %r38, i64 56
  %r5898 = load double, ptr @test_json_warm_unique_keys_ts_.str.5.handle, align 8
  store double %r5898, ptr %r52, align 8
  %r5897 = load double, ptr @test_json_warm_unique_keys_ts_.str.5.handle, align 8
  call void @js_string_addref_if_heap_string(double %r5897) #7
  %r5896 = load double, ptr @test_json_warm_unique_keys_ts_.str.5.handle, align 8
  %r53 = bitcast double %r5896 to i64
  %r5894 = load double, ptr @test_json_warm_unique_keys_ts_.str.5.handle, align 8
  %r5895 = bitcast double %r5894 to i64
  call void @js_gc_note_slot_layout(i64 %r41, i32 5, i64 %r5895) #7
  %r54 = getelementptr inbounds nuw i8, ptr %r38, i64 64
  %r5893 = load double, ptr @test_json_warm_unique_keys_ts_.str.6.handle, align 8
  store double %r5893, ptr %r54, align 8
  %r5892 = load double, ptr @test_json_warm_unique_keys_ts_.str.6.handle, align 8
  call void @js_string_addref_if_heap_string(double %r5892) #7
  %r5891 = load double, ptr @test_json_warm_unique_keys_ts_.str.6.handle, align 8
  %r55 = bitcast double %r5891 to i64
  %r5889 = load double, ptr @test_json_warm_unique_keys_ts_.str.6.handle, align 8
  %r5890 = bitcast double %r5889 to i64
  call void @js_gc_note_slot_layout(i64 %r41, i32 6, i64 %r5890) #7
  %r56 = getelementptr inbounds nuw i8, ptr %r38, i64 72
  %r5888 = load double, ptr @test_json_warm_unique_keys_ts_.str.7.handle, align 8
  store double %r5888, ptr %r56, align 8
  %r5887 = load double, ptr @test_json_warm_unique_keys_ts_.str.7.handle, align 8
  call void @js_string_addref_if_heap_string(double %r5887) #7
  %r5886 = load double, ptr @test_json_warm_unique_keys_ts_.str.7.handle, align 8
  %r57 = bitcast double %r5886 to i64
  %r5884 = load double, ptr @test_json_warm_unique_keys_ts_.str.7.handle, align 8
  %r5885 = bitcast double %r5884 to i64
  call void @js_gc_note_slot_layout(i64 %r41, i32 7, i64 %r5885) #7
  %r58 = or i64 %r41, 9222527611924643840
  %r59 = bitcast i64 %r58 to double
  %rs4gc.b19 = bitcast double %r59 to i64
  %rs4gc.s19 = inttoptr i64 %rs4gc.b19 to ptr addrspace(1)
  %r60.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19 to i64
  %r60 = call i64 asm "", "=r,0"(i64 %r60.rs4i) #7
  %r61 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r62 = icmp ne i32 %r61, 0
  br i1 %r62, label %shadow.root.barrier.11, label %shadow.root.barrier.done.12

shadow.root.barrier.11:                           ; preds = %arrlit.merge.10
  call void @js_write_barrier_root_nanbox(i64 %r60) #7
  br label %shadow.root.barrier.done.12

shadow.root.barrier.done.12:                      ; preds = %shadow.root.barrier.11, %arrlit.merge.10
  %r64 = load double, ptr @test_json_warm_unique_keys_ts_.str.8.handle, align 8
  %rs4gc.b20 = bitcast double %r64 to i64
  %rs4gc.s20 = inttoptr i64 %rs4gc.b20 to ptr addrspace(1)
  %r65.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20 to i64
  %r65 = call i64 asm "", "=r,0"(i64 %r65.rs4i) #7
  %r66 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r67 = icmp ne i32 %r66, 0
  br i1 %r67, label %shadow.root.barrier.13, label %shadow.root.barrier.done.14

shadow.root.barrier.13:                           ; preds = %shadow.root.barrier.done.12
  call void @js_write_barrier_root_nanbox(i64 %r65) #7
  br label %shadow.root.barrier.done.14

shadow.root.barrier.done.14:                      ; preds = %shadow.root.barrier.13, %shadow.root.barrier.done.12
  %statepoint_token43 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19) ]
  %r6944 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token43)
  %rs4gc.s19.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token43, i32 0, i32 0) ; (%rs4gc.s19, %rs4gc.s19)
  %r70 = or i64 %r6944, 9222527611924643840
  %r71 = bitcast i64 %r70 to double
  %rs4gc.b21 = bitcast double %r71 to i64
  %rs4gc.s21 = inttoptr i64 %rs4gc.b21 to ptr addrspace(1)
  %r72.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r72 = call i64 asm "", "=r,0"(i64 %r72.rs4i) #7
  %r73 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r74 = icmp ne i32 %r73, 0
  br i1 %r74, label %shadow.root.barrier.15, label %shadow.root.barrier.done.16

shadow.root.barrier.15:                           ; preds = %shadow.root.barrier.done.14
  call void @js_write_barrier_root_nanbox(i64 %r72) #7
  br label %shadow.root.barrier.done.16

shadow.root.barrier.done.16:                      ; preds = %shadow.root.barrier.15, %shadow.root.barrier.done.14
  br label %for.cond.17

for.cond.17:                                      ; preds = %for.update.19, %shadow.root.barrier.done.16
  %.0 = phi ptr addrspace(1) [ %rs4gc.s19.relocated, %shadow.root.barrier.done.16 ], [ %.29, %for.update.19 ]
  %r75.0 = phi i32 [ 0, %shadow.root.barrier.done.16 ], [ %r3121, %for.update.19 ]
  %r68.0.base = phi ptr addrspace(1) [ %rs4gc.s21, %shadow.root.barrier.done.16 ], [ %.0958, %for.update.19 ], !is_base_value !0
  %r68.0 = phi ptr addrspace(1) [ %rs4gc.s21, %shadow.root.barrier.done.16 ], [ %.0959, %for.update.19 ]
  %r77 = sitofp i32 %r75.0 to double
  %r78 = fcmp ole double %r77, 8.000000e+00
  %r79 = select i1 %r78, i64 9222246136947933188, i64 9222246136947933187
  %r80 = bitcast i64 %r79 to double
  %r81 = icmp eq i64 %r79, 9222246136947933188
  br i1 %r81, label %for.body.18, label %for.exit.20

for.body.18:                                      ; preds = %for.cond.17
  %r82 = load double, ptr @test_json_warm_unique_keys_ts_.str.8.handle, align 8
  %r83 = bitcast double %r82 to i64
  %r84.rs4i = ptrtoint ptr addrspace(1) %r68.0 to i64
  %r84.rs4o = call i64 asm "", "=r,0"(i64 %r84.rs4i) #7
  %r84 = bitcast i64 %r84.rs4o to double
  %r85 = bitcast double %r84 to i64
  %r86 = and i64 %r85, 281474976710655
  %r87 = sub nsw i64 %r86, 8
  %r88 = inttoptr i64 %r87 to ptr
  %r89 = load i8, ptr %r88, align 1
  %r90 = icmp ne i8 %r89, 1
  %r91 = sub nsw i64 %r86, 7
  %r92 = inttoptr i64 %r91 to ptr
  %r93 = load i8, ptr %r92, align 1
  %r94 = and i8 %r93, -128
  %r95 = icmp ne i8 %r94, 0
  %r96 = or i1 %r90, %r95
  br i1 %r95, label %apush.fwd.21, label %apush.elements.22

for.update.19:                                    ; preds = %gcpoll.done.438
  %r3121 = add i32 %r75.0, 1
  %r3122 = sitofp i32 %r75.0 to double
  %r3123 = sitofp i32 %r3121 to double
  br label %for.cond.17

for.exit.20:                                      ; preds = %for.cond.17
  %r3124 = load double, ptr @test_json_warm_unique_keys_ts_.str.18.handle, align 8
  %r3125 = bitcast double %r3124 to i64
  %r3126.rs4i = ptrtoint ptr addrspace(1) %r68.0 to i64
  %r3126.rs4o = call i64 asm "", "=r,0"(i64 %r3126.rs4i) #7
  %r3126 = bitcast i64 %r3126.rs4o to double
  %r3127 = bitcast double %r3126 to i64
  %r3128 = and i64 %r3127, 281474976710655
  %r3129 = sub nsw i64 %r3128, 8
  %r3130 = inttoptr i64 %r3129 to ptr
  %r3131 = load i8, ptr %r3130, align 1
  %r3132 = icmp ne i8 %r3131, 1
  %r3133 = sub nsw i64 %r3128, 7
  %r3134 = inttoptr i64 %r3133 to ptr
  %r3135 = load i8, ptr %r3134, align 1
  %r3136 = and i8 %r3135, -128
  %r3137 = icmp ne i8 %r3136, 0
  %r3138 = or i1 %r3132, %r3137
  br i1 %r3137, label %apush.fwd.439, label %apush.elements.440

apush.fwd.21:                                     ; preds = %apush.elements.check.23, %for.body.18
  %statepoint_token45 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r86, double %r82, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0) ]
  %r12346 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token45)
  %rs4gc.s19.relocated47 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token45, i32 0, i32 0) ; (%.0, %.0)
  %r124 = or i64 %r12346, 9222527611924643840
  %r125 = bitcast i64 %r124 to double
  %rs4gc.b22 = bitcast double %r125 to i64
  %rs4gc.s22 = inttoptr i64 %rs4gc.b22 to ptr addrspace(1)
  br label %apush.merge.27

apush.elements.22:                                ; preds = %for.body.18
  %r98 = add nuw nsw i64 %r86, 8
  %r99 = inttoptr i64 %r98 to ptr
  %r100 = load i64, ptr %r99, align 8
  %r101 = icmp ne i64 %r100, 0
  %r102 = icmp eq i8 %r89, 2
  %r103 = and i1 %r102, %r101
  %r104 = select i1 %r103, i64 %r100, i64 %r86
  %r105 = inttoptr i64 %r104 to ptr
  %r106 = getelementptr i64, ptr %r105, i64 12
  %r107 = load i64, ptr %r106, align 8
  %r108 = icmp ne i64 %r107, 0
  %r109 = and i1 %r103, %r108
  %r110 = select i1 %r109, i64 %r107, i64 %r86
  %r97 = icmp eq i8 %r89, 1
  br i1 %r97, label %apush.nofwd.24, label %apush.elements.check.23

apush.elements.check.23:                          ; preds = %apush.elements.22
  %r111 = icmp ne i64 %r110, 0
  %r112 = sub i64 %r110, 8
  %r113 = inttoptr i64 %r112 to ptr
  %r114 = load i8, ptr %r113, align 1
  %r115 = icmp eq i8 %r114, 1
  %r116 = sub i64 %r110, 7
  %r117 = inttoptr i64 %r116 to ptr
  %r118 = load i8, ptr %r117, align 1
  %r119 = and i8 %r118, -128
  %r120 = icmp eq i8 %r119, 0
  %r121 = and i1 %r111, %r115
  %r122 = and i1 %r121, %r120
  br i1 %r122, label %apush.nofwd.24, label %apush.fwd.21

apush.nofwd.24:                                   ; preds = %apush.elements.check.23, %apush.elements.22
  %r126 = phi i64 [ %r86, %apush.elements.22 ], [ %r110, %apush.elements.check.23 ]
  %r127 = sub i64 %r126, 6
  %r128 = inttoptr i64 %r127 to ptr
  %r129 = load i16, ptr %r128, align 2
  %r130 = and i16 %r129, 1031
  %r131 = icmp eq i16 %r130, 0
  %r132 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r133 = icmp eq i8 %r132, 0
  %r134 = and i1 %r131, %r133
  %r135 = icmp ult i64 %r126, 4096
  %r136 = inttoptr i64 %r126 to ptr
  %r137 = select i1 %r135, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r136
  %r138 = load i32, ptr %r137, align 4
  %r139 = add i64 %r126, 4
  %r140 = inttoptr i64 %r139 to ptr
  %r141 = load i32, ptr %r140, align 4
  %r142 = icmp ult i32 %r138, %r141
  %r143 = and i1 %r142, %r134
  br i1 %r143, label %apush.inbounds.25, label %apush.realloc.26

apush.inbounds.25:                                ; preds = %apush.nofwd.24
  %r144 = icmp ult i64 %r126, 4096
  %r145 = inttoptr i64 %r126 to ptr
  %r146 = select i1 %r144, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r145
  %r147 = load i32, ptr %r146, align 4
  %r148 = zext i32 %r147 to i64
  %r149 = shl nuw nsw i64 %r148, 3
  %r150 = add nuw nsw i64 %r149, 8
  %r151 = add i64 %r126, %r150
  %r152 = inttoptr i64 %r151 to ptr
  store double %r82, ptr %r152, align 8
  %r153 = lshr i64 %r83, 48
  %r154 = icmp eq i64 %r153, 32765
  %r155 = and i16 %r129, -1920
  %r156 = icmp eq i16 %r155, -24576
  %r157 = and i1 %r154, %r156
  br i1 %r157, label %apush.pointer_layout.done.29, label %apush.pointer_layout.bookkeeping.28

apush.realloc.26:                                 ; preds = %apush.nofwd.24
  %statepoint_token48 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r86, double %r82, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0) ]
  %r16849 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token48)
  %rs4gc.s19.relocated50 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token48, i32 0, i32 0) ; (%.0, %.0)
  %r169 = or i64 %r16849, 9222527611924643840
  %r170 = bitcast i64 %r169 to double
  %rs4gc.b23 = bitcast double %r170 to i64
  %rs4gc.s23 = inttoptr i64 %rs4gc.b23 to ptr addrspace(1)
  br label %apush.merge.27

apush.merge.27:                                   ; preds = %apush.barrier.done.31, %apush.realloc.26, %apush.fwd.21
  %.1 = phi ptr addrspace(1) [ %rs4gc.s19.relocated47, %apush.fwd.21 ], [ %.0, %apush.barrier.done.31 ], [ %rs4gc.s19.relocated50, %apush.realloc.26 ]
  %r68.1.base = phi ptr addrspace(1) [ %rs4gc.s22, %apush.fwd.21 ], [ %r68.0.base, %apush.barrier.done.31 ], [ %rs4gc.s23, %apush.realloc.26 ], !is_base_value !0
  %r68.1 = phi ptr addrspace(1) [ %rs4gc.s22, %apush.fwd.21 ], [ %r68.0, %apush.barrier.done.31 ], [ %rs4gc.s23, %apush.realloc.26 ]
  %statepoint_token51 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1, ptr addrspace(1) %r68.1.base, ptr addrspace(1) %r68.1) ]
  %r17252 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token51)
  %rs4gc.s19.relocated53 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token51, i32 0, i32 0) ; (%.1, %.1)
  %r68.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token51, i32 1, i32 1) ; (%r68.1.base, %r68.1.base)
  %r68.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token51, i32 1, i32 2) ; (%r68.1.base, %r68.1)
  %r173 = or i64 %r17252, 9222527611924643840
  %r174 = bitcast i64 %r173 to double
  %rs4gc.b24 = bitcast double %r174 to i64
  %rs4gc.s24 = inttoptr i64 %rs4gc.b24 to ptr addrspace(1)
  %r175.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24 to i64
  %r175 = call i64 asm "", "=r,0"(i64 %r175.rs4i) #7
  %r176 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r177 = icmp ne i32 %r176, 0
  br i1 %r177, label %shadow.root.barrier.32, label %shadow.root.barrier.done.33

apush.pointer_layout.bookkeeping.28:              ; preds = %apush.inbounds.25
  call void @js_string_addref_if_heap_string(double %r82) #7
  %r5882 = load double, ptr @test_json_warm_unique_keys_ts_.str.8.handle, align 8
  %r5883 = bitcast double %r5882 to i64
  call void @js_gc_note_slot_layout(i64 %r126, i32 %r147, i64 %r5883) #7
  %r5880 = load double, ptr @test_json_warm_unique_keys_ts_.str.8.handle, align 8
  %r5881 = bitcast double %r5880 to i64
  call void @js_array_note_numeric_write(i64 %r126, i64 %r5881) #7
  br label %apush.pointer_layout.done.29

apush.pointer_layout.done.29:                     ; preds = %apush.pointer_layout.bookkeeping.28, %apush.inbounds.25
  %r158 = sub i64 %r126, 7
  %r159 = inttoptr i64 %r158 to ptr
  %r160 = load i8, ptr %r159, align 1
  %r161 = and i8 %r160, 32
  %r162 = icmp ne i8 %r161, 0
  %r163 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r164 = icmp ne i32 %r163, 0
  %r165 = or i1 %r162, %r164
  br i1 %r165, label %apush.barrier.30, label %apush.barrier.done.31

apush.barrier.30:                                 ; preds = %apush.pointer_layout.done.29
  %r5878 = load double, ptr @test_json_warm_unique_keys_ts_.str.8.handle, align 8
  %r5879 = bitcast double %r5878 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r126, i64 %r151, i64 %r5879) #7
  br label %apush.barrier.done.31

apush.barrier.done.31:                            ; preds = %apush.barrier.30, %apush.pointer_layout.done.29
  %r166 = add i32 %r147, 1
  %r167 = inttoptr i64 %r126 to ptr
  store i32 %r166, ptr %r167, align 4
  br label %apush.merge.27

shadow.root.barrier.32:                           ; preds = %apush.merge.27
  call void @js_write_barrier_root_nanbox(i64 %r175) #7
  br label %shadow.root.barrier.done.33

shadow.root.barrier.done.33:                      ; preds = %shadow.root.barrier.32, %apush.merge.27
  br label %for.cond.34

for.cond.34:                                      ; preds = %for.update.36, %shadow.root.barrier.done.33
  %.0907 = phi ptr addrspace(1) [ %r68.1.relocated, %shadow.root.barrier.done.33 ], [ %.3910, %for.update.36 ]
  %.0902 = phi ptr addrspace(1) [ %r68.1.base.relocated, %shadow.root.barrier.done.33 ], [ %.3905, %for.update.36 ]
  %.2 = phi ptr addrspace(1) [ %rs4gc.s19.relocated53, %shadow.root.barrier.done.33 ], [ %.5, %for.update.36 ]
  %r178.0 = phi i32 [ 0, %shadow.root.barrier.done.33 ], [ %r364, %for.update.36 ]
  %r171.0.base = phi ptr addrspace(1) [ %rs4gc.s24, %shadow.root.barrier.done.33 ], [ %.0914, %for.update.36 ], !is_base_value !0
  %r171.0 = phi ptr addrspace(1) [ %rs4gc.s24, %shadow.root.barrier.done.33 ], [ %.0915, %for.update.36 ]
  %r183 = icmp slt i32 %r178.0, %r75.0
  br i1 %r183, label %for.body.35, label %for.exit.37

for.body.35:                                      ; preds = %for.cond.34
  %r184 = load double, ptr @test_json_warm_unique_keys_ts_.str.9.handle, align 8
  %r185.rs4i = ptrtoint ptr addrspace(1) %.2 to i64
  %r185.rs4o = call i64 asm "", "=r,0"(i64 %r185.rs4i) #7
  %r185 = bitcast i64 %r185.rs4o to double
  %r187 = bitcast double %r185 to i64
  %r188 = and i64 %r187, 281474976710655
  %r189 = lshr i64 %r187, 48
  %r190 = icmp eq i64 %r189, 32765
  %r191 = icmp ugt i64 %r188, 1048575
  %r192 = and i1 %r190, %r191
  br i1 %r192, label %arr.guard.deref.42, label %arr.fallback.39

for.update.36:                                    ; preds = %gcpoll.done.57
  %r364 = add i32 %r178.0, 1
  %r365 = sitofp i32 %r178.0 to double
  %r366 = sitofp i32 %r364 to double
  br label %for.cond.34

for.exit.37:                                      ; preds = %for.cond.34
  br label %if.then.58

arr.fast.38:                                      ; preds = %arr.guard.range.44
  %r248 = zext i32 %r178.0 to i64
  %r249 = shl nuw nsw i64 %r248, 3
  %r250 = add nuw nsw i64 %r249, 8
  %r251 = add i64 %r207, %r250
  %r252 = inttoptr i64 %r251 to ptr
  %r253 = load double, ptr %r252, align 8
  %r254 = bitcast double %r253 to i64
  %r255 = icmp eq i64 %r254, 9222246136947933200
  %r257 = select i1 %r255, double 0x7FFC000000000001, double %r253
  br label %arr.merge.41

arr.fallback.39:                                  ; preds = %arr.guard.live.43, %arr.guard.deref.42, %for.body.35
  %r246 = sitofp i32 %r178.0 to double
  %statepoint_token54 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 547434508618563584, double %r185, double %r246, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r171.0, ptr addrspace(1) %r171.0.base, ptr addrspace(1) %.2, ptr addrspace(1) %.0902, ptr addrspace(1) %.0907) ]
  %r24755 = call double @llvm.experimental.gc.result.f64(token %statepoint_token54)
  %r171.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token54, i32 1, i32 0) ; (%r171.0.base, %r171.0)
  %r171.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token54, i32 1, i32 1) ; (%r171.0.base, %r171.0.base)
  %rs4gc.s19.relocated56 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token54, i32 2, i32 2) ; (%.2, %.2)
  %r68.1.base.relocated57 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token54, i32 3, i32 3) ; (%.0902, %.0902)
  %r68.1.relocated58 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token54, i32 3, i32 4) ; (%.0902, %.0907)
  br label %arr.merge.41

arr.guard.oob.40:                                 ; preds = %arr.guard.range.44
  br label %arr.merge.41

arr.merge.41:                                     ; preds = %arr.guard.oob.40, %arr.fallback.39, %arr.fast.38
  %.0913 = phi ptr addrspace(1) [ %r171.0.base, %arr.fast.38 ], [ %r171.0.base, %arr.guard.oob.40 ], [ %r171.0.base.relocated, %arr.fallback.39 ]
  %.0912 = phi ptr addrspace(1) [ %r171.0, %arr.fast.38 ], [ %r171.0, %arr.guard.oob.40 ], [ %r171.0.relocated, %arr.fallback.39 ]
  %.1908 = phi ptr addrspace(1) [ %.0907, %arr.fast.38 ], [ %.0907, %arr.guard.oob.40 ], [ %r68.1.relocated58, %arr.fallback.39 ]
  %.1903 = phi ptr addrspace(1) [ %.0902, %arr.fast.38 ], [ %.0902, %arr.guard.oob.40 ], [ %r68.1.base.relocated57, %arr.fallback.39 ]
  %.3 = phi ptr addrspace(1) [ %.2, %arr.fast.38 ], [ %.2, %arr.guard.oob.40 ], [ %rs4gc.s19.relocated56, %arr.fallback.39 ]
  %r258 = phi double [ %r257, %arr.fast.38 ], [ %r24755, %arr.fallback.39 ], [ 0x7FFC000000000001, %arr.guard.oob.40 ]
  %r259 = load double, ptr @test_json_warm_unique_keys_ts_.str.10.handle, align 8
  %r260 = load double, ptr @test_json_warm_unique_keys_ts_.str.9.handle, align 8
  %r262 = getelementptr double, ptr %r261, i64 0
  store double %r260, ptr %r262, align 8
  %r263 = getelementptr double, ptr %r261, i64 1
  store double %r258, ptr %r263, align 8
  %r264 = getelementptr double, ptr %r261, i64 2
  store double %r259, ptr %r264, align 8
  %r265 = ptrtoint ptr %r261 to i64
  %statepoint_token59 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r265, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3, ptr addrspace(1) %.1903, ptr addrspace(1) %.0913, ptr addrspace(1) %.0912, ptr addrspace(1) %.1908) ]
  %r26660 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token59)
  %rs4gc.s19.relocated61 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token59, i32 0, i32 0) ; (%.3, %.3)
  %r68.1.base.relocated62 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token59, i32 1, i32 1) ; (%.1903, %.1903)
  %r171.0.base.relocated63 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token59, i32 2, i32 2) ; (%.0913, %.0913)
  %r171.0.relocated64 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token59, i32 2, i32 3) ; (%.0913, %.0912)
  %r68.1.relocated65 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token59, i32 1, i32 4) ; (%.1903, %.1908)
  %r267 = or i64 %r26660, 9223090561878065152
  %r268 = bitcast i64 %r267 to double
  %r270 = sitofp i32 %r178.0 to double
  %statepoint_token66 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r268, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated61, ptr addrspace(1) %r68.1.base.relocated62, ptr addrspace(1) %r171.0.base.relocated63, ptr addrspace(1) %r171.0.relocated64, ptr addrspace(1) %r68.1.relocated65) ]
  %r27167 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token66)
  %rs4gc.s19.relocated68 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token66, i32 0, i32 0) ; (%rs4gc.s19.relocated61, %rs4gc.s19.relocated61)
  %r68.1.base.relocated69 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token66, i32 1, i32 1) ; (%r68.1.base.relocated62, %r68.1.base.relocated62)
  %r171.0.base.relocated70 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token66, i32 2, i32 2) ; (%r171.0.base.relocated63, %r171.0.base.relocated63)
  %r171.0.relocated71 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token66, i32 2, i32 3) ; (%r171.0.base.relocated63, %r171.0.relocated64)
  %r68.1.relocated72 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token66, i32 1, i32 4) ; (%r68.1.base.relocated62, %r68.1.relocated65)
  %statepoint_token73 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r27167, double %r270, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated68, ptr addrspace(1) %r68.1.base.relocated69, ptr addrspace(1) %r171.0.base.relocated70, ptr addrspace(1) %r171.0.relocated71, ptr addrspace(1) %r68.1.relocated72) ]
  %r27274 = call double @llvm.experimental.gc.result.f64(token %statepoint_token73)
  %rs4gc.s19.relocated75 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token73, i32 0, i32 0) ; (%rs4gc.s19.relocated68, %rs4gc.s19.relocated68)
  %r68.1.base.relocated76 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token73, i32 1, i32 1) ; (%r68.1.base.relocated69, %r68.1.base.relocated69)
  %r171.0.base.relocated77 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token73, i32 2, i32 2) ; (%r171.0.base.relocated70, %r171.0.base.relocated70)
  %r171.0.relocated78 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token73, i32 2, i32 3) ; (%r171.0.base.relocated70, %r171.0.relocated71)
  %r68.1.relocated79 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token73, i32 1, i32 4) ; (%r68.1.base.relocated69, %r68.1.relocated72)
  %r273 = bitcast double %r27274 to i64
  %r274.rs4i = ptrtoint ptr addrspace(1) %r171.0.relocated78 to i64
  %r274.rs4o = call i64 asm "", "=r,0"(i64 %r274.rs4i) #7
  %r274 = bitcast i64 %r274.rs4o to double
  %r275 = bitcast double %r274 to i64
  %r276 = and i64 %r275, 281474976710655
  %r277 = sub nsw i64 %r276, 8
  %r278 = inttoptr i64 %r277 to ptr
  %r279 = load i8, ptr %r278, align 1
  %r280 = icmp ne i8 %r279, 1
  %r281 = sub nsw i64 %r276, 7
  %r282 = inttoptr i64 %r281 to ptr
  %r283 = load i8, ptr %r282, align 1
  %r284 = and i8 %r283, -128
  %r285 = icmp ne i8 %r284, 0
  %r286 = or i1 %r280, %r285
  br i1 %r285, label %apush.fwd.45, label %apush.elements.46

arr.guard.deref.42:                               ; preds = %for.body.35
  %r193 = bitcast double %r185 to i64
  %r194 = and i64 %r193, 281474976710655
  %r195 = sub nsw i64 %r194, 8
  %r196 = inttoptr i64 %r195 to ptr
  %r197 = load i8, ptr %r196, align 1
  %r198 = icmp eq i8 %r197, 1
  %r199 = sub nsw i64 %r194, 7
  %r200 = inttoptr i64 %r199 to ptr
  %r201 = load i8, ptr %r200, align 1
  %r202 = and i8 %r201, -128
  %r203 = icmp ne i8 %r202, 0
  %r204 = inttoptr i64 %r194 to ptr
  %r205 = load i64, ptr %r204, align 8
  %r206 = and i1 %r198, %r203
  %r207 = select i1 %r206, i64 %r205, i64 %r194
  %r208 = lshr i64 %r207, 48
  %r209 = icmp eq i64 %r208, 0
  %r210 = icmp ugt i64 %r207, 1048575
  %r211 = and i1 %r209, %r210
  br i1 %r211, label %arr.guard.live.43, label %arr.fallback.39

arr.guard.live.43:                                ; preds = %arr.guard.deref.42
  %r212 = sub nuw i64 %r207, 8
  %r213 = inttoptr i64 %r212 to ptr
  %r214 = load i8, ptr %r213, align 1
  %r215 = icmp eq i8 %r214, 1
  %r216 = sub nuw i64 %r207, 7
  %r217 = inttoptr i64 %r216 to ptr
  %r218 = load i8, ptr %r217, align 1
  %r219 = and i8 %r218, -128
  %r220 = icmp eq i8 %r219, 0
  %r221 = sub nuw i64 %r207, 6
  %r222 = inttoptr i64 %r221 to ptr
  %r223 = load i16, ptr %r222, align 2
  %r224 = and i16 %r223, 1024
  %r225 = icmp eq i16 %r224, 0
  %r226 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r227 = icmp eq i8 %r226, 0
  %r228 = inttoptr i64 %r207 to ptr
  %r229 = load i32, ptr %r228, align 4
  %r230 = getelementptr i8, ptr %r228, i64 4
  %r231 = load i32, ptr %r230, align 4
  %r232 = icmp slt i32 %r178.0, 0
  %r233 = icmp eq i1 %r232, false
  %r235 = icmp ule i32 %r229, 16000000
  %r236 = icmp ule i32 %r231, 16000000
  %r237 = icmp ule i32 %r229, %r231
  %r238 = and i1 %r215, %r220
  %r239 = and i1 %r238, %r225
  %r240 = and i1 %r239, %r227
  %r241 = and i1 %r240, %r233
  %r242 = and i1 %r241, %r235
  %r243 = and i1 %r242, %r236
  %r244 = and i1 %r243, %r237
  br i1 %r244, label %arr.guard.range.44, label %arr.fallback.39

arr.guard.range.44:                               ; preds = %arr.guard.live.43
  %r234 = icmp ult i32 %r178.0, %r229
  br i1 %r234, label %arr.fast.38, label %arr.guard.oob.40

apush.fwd.45:                                     ; preds = %apush.elements.check.47, %arr.merge.41
  %statepoint_token80 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r276, double %r27274, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated75, ptr addrspace(1) %r68.1.base.relocated76, ptr addrspace(1) %r68.1.relocated79) ]
  %r31381 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token80)
  %rs4gc.s19.relocated82 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token80, i32 0, i32 0) ; (%rs4gc.s19.relocated75, %rs4gc.s19.relocated75)
  %r68.1.base.relocated83 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token80, i32 1, i32 1) ; (%r68.1.base.relocated76, %r68.1.base.relocated76)
  %r68.1.relocated84 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token80, i32 1, i32 2) ; (%r68.1.base.relocated76, %r68.1.relocated79)
  %r314 = or i64 %r31381, 9222527611924643840
  %r315 = bitcast i64 %r314 to double
  %rs4gc.b25 = bitcast double %r315 to i64
  %rs4gc.s25 = inttoptr i64 %rs4gc.b25 to ptr addrspace(1)
  br label %apush.merge.51

apush.elements.46:                                ; preds = %arr.merge.41
  %r288 = add nuw nsw i64 %r276, 8
  %r289 = inttoptr i64 %r288 to ptr
  %r290 = load i64, ptr %r289, align 8
  %r291 = icmp ne i64 %r290, 0
  %r292 = icmp eq i8 %r279, 2
  %r293 = and i1 %r292, %r291
  %r294 = select i1 %r293, i64 %r290, i64 %r276
  %r295 = inttoptr i64 %r294 to ptr
  %r296 = getelementptr i64, ptr %r295, i64 12
  %r297 = load i64, ptr %r296, align 8
  %r298 = icmp ne i64 %r297, 0
  %r299 = and i1 %r293, %r298
  %r300 = select i1 %r299, i64 %r297, i64 %r276
  %r287 = icmp eq i8 %r279, 1
  br i1 %r287, label %apush.nofwd.48, label %apush.elements.check.47

apush.elements.check.47:                          ; preds = %apush.elements.46
  %r301 = icmp ne i64 %r300, 0
  %r302 = sub i64 %r300, 8
  %r303 = inttoptr i64 %r302 to ptr
  %r304 = load i8, ptr %r303, align 1
  %r305 = icmp eq i8 %r304, 1
  %r306 = sub i64 %r300, 7
  %r307 = inttoptr i64 %r306 to ptr
  %r308 = load i8, ptr %r307, align 1
  %r309 = and i8 %r308, -128
  %r310 = icmp eq i8 %r309, 0
  %r311 = and i1 %r301, %r305
  %r312 = and i1 %r311, %r310
  br i1 %r312, label %apush.nofwd.48, label %apush.fwd.45

apush.nofwd.48:                                   ; preds = %apush.elements.check.47, %apush.elements.46
  %r316 = phi i64 [ %r276, %apush.elements.46 ], [ %r300, %apush.elements.check.47 ]
  %r317 = sub i64 %r316, 6
  %r318 = inttoptr i64 %r317 to ptr
  %r319 = load i16, ptr %r318, align 2
  %r320 = and i16 %r319, 1031
  %r321 = icmp eq i16 %r320, 0
  %r322 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r323 = icmp eq i8 %r322, 0
  %r324 = and i1 %r321, %r323
  %r325 = icmp ult i64 %r316, 4096
  %r326 = inttoptr i64 %r316 to ptr
  %r327 = select i1 %r325, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r326
  %r328 = load i32, ptr %r327, align 4
  %r329 = add i64 %r316, 4
  %r330 = inttoptr i64 %r329 to ptr
  %r331 = load i32, ptr %r330, align 4
  %r332 = icmp ult i32 %r328, %r331
  %r333 = and i1 %r332, %r324
  br i1 %r333, label %apush.inbounds.49, label %apush.realloc.50

apush.inbounds.49:                                ; preds = %apush.nofwd.48
  %r334 = icmp ult i64 %r316, 4096
  %r335 = inttoptr i64 %r316 to ptr
  %r336 = select i1 %r334, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r335
  %r337 = load i32, ptr %r336, align 4
  %r338 = zext i32 %r337 to i64
  %r339 = shl nuw nsw i64 %r338, 3
  %r340 = add nuw nsw i64 %r339, 8
  %r341 = add i64 %r316, %r340
  %r342 = inttoptr i64 %r341 to ptr
  store double %r27274, ptr %r342, align 8
  %r343 = lshr i64 %r273, 48
  %r344 = icmp eq i64 %r343, 32765
  %r345 = and i16 %r319, -1920
  %r346 = icmp eq i16 %r345, -24576
  %r347 = and i1 %r344, %r346
  br i1 %r347, label %apush.pointer_layout.done.53, label %apush.pointer_layout.bookkeeping.52

apush.realloc.50:                                 ; preds = %apush.nofwd.48
  %statepoint_token85 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r276, double %r27274, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated75, ptr addrspace(1) %r68.1.base.relocated76, ptr addrspace(1) %r68.1.relocated79) ]
  %r35886 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token85)
  %rs4gc.s19.relocated87 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token85, i32 0, i32 0) ; (%rs4gc.s19.relocated75, %rs4gc.s19.relocated75)
  %r68.1.base.relocated88 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token85, i32 1, i32 1) ; (%r68.1.base.relocated76, %r68.1.base.relocated76)
  %r68.1.relocated89 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token85, i32 1, i32 2) ; (%r68.1.base.relocated76, %r68.1.relocated79)
  %r359 = or i64 %r35886, 9222527611924643840
  %r360 = bitcast i64 %r359 to double
  %rs4gc.b26 = bitcast double %r360 to i64
  %rs4gc.s26 = inttoptr i64 %rs4gc.b26 to ptr addrspace(1)
  br label %apush.merge.51

apush.merge.51:                                   ; preds = %apush.barrier.done.55, %apush.realloc.50, %apush.fwd.45
  %.2909 = phi ptr addrspace(1) [ %r68.1.relocated84, %apush.fwd.45 ], [ %r68.1.relocated79, %apush.barrier.done.55 ], [ %r68.1.relocated89, %apush.realloc.50 ]
  %.2904 = phi ptr addrspace(1) [ %r68.1.base.relocated83, %apush.fwd.45 ], [ %r68.1.base.relocated76, %apush.barrier.done.55 ], [ %r68.1.base.relocated88, %apush.realloc.50 ]
  %.4 = phi ptr addrspace(1) [ %rs4gc.s19.relocated82, %apush.fwd.45 ], [ %rs4gc.s19.relocated75, %apush.barrier.done.55 ], [ %rs4gc.s19.relocated87, %apush.realloc.50 ]
  %r171.1.base = phi ptr addrspace(1) [ %rs4gc.s25, %apush.fwd.45 ], [ %r171.0.base.relocated77, %apush.barrier.done.55 ], [ %rs4gc.s26, %apush.realloc.50 ], !is_base_value !0
  %r171.1 = phi ptr addrspace(1) [ %rs4gc.s25, %apush.fwd.45 ], [ %r171.0.relocated78, %apush.barrier.done.55 ], [ %rs4gc.s26, %apush.realloc.50 ]
  %r361 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r362 = icmp ne i32 %r361, 0
  br i1 %r362, label %gcpoll.56, label %gcpoll.done.57

apush.pointer_layout.bookkeeping.52:              ; preds = %apush.inbounds.49
  call void @js_string_addref_if_heap_string(double %r27274) #7
  call void @js_gc_note_slot_layout(i64 %r316, i32 %r337, i64 %r273) #7
  call void @js_array_note_numeric_write(i64 %r316, i64 %r273) #7
  br label %apush.pointer_layout.done.53

apush.pointer_layout.done.53:                     ; preds = %apush.pointer_layout.bookkeeping.52, %apush.inbounds.49
  %r348 = sub i64 %r316, 7
  %r349 = inttoptr i64 %r348 to ptr
  %r350 = load i8, ptr %r349, align 1
  %r351 = and i8 %r350, 32
  %r352 = icmp ne i8 %r351, 0
  %r353 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r354 = icmp ne i32 %r353, 0
  %r355 = or i1 %r352, %r354
  br i1 %r355, label %apush.barrier.54, label %apush.barrier.done.55

apush.barrier.54:                                 ; preds = %apush.pointer_layout.done.53
  call void @js_write_barrier_slot_validated_parent(i64 %r316, i64 %r341, i64 %r273) #7
  br label %apush.barrier.done.55

apush.barrier.done.55:                            ; preds = %apush.barrier.54, %apush.pointer_layout.done.53
  %r356 = add i32 %r337, 1
  %r357 = inttoptr i64 %r316 to ptr
  store i32 %r356, ptr %r357, align 4
  br label %apush.merge.51

gcpoll.56:                                        ; preds = %apush.merge.51
  %statepoint_token90 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r171.1.base, ptr addrspace(1) %r171.1, ptr addrspace(1) %.4, ptr addrspace(1) %.2904, ptr addrspace(1) %.2909) ]
  %r171.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token90, i32 0, i32 0) ; (%r171.1.base, %r171.1.base)
  %r171.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token90, i32 0, i32 1) ; (%r171.1.base, %r171.1)
  %rs4gc.s19.relocated91 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token90, i32 2, i32 2) ; (%.4, %.4)
  %r68.1.base.relocated92 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token90, i32 3, i32 3) ; (%.2904, %.2904)
  %r68.1.relocated93 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token90, i32 3, i32 4) ; (%.2904, %.2909)
  br label %gcpoll.done.57

gcpoll.done.57:                                   ; preds = %gcpoll.56, %apush.merge.51
  %.0915 = phi ptr addrspace(1) [ %r171.1.relocated, %gcpoll.56 ], [ %r171.1, %apush.merge.51 ]
  %.0914 = phi ptr addrspace(1) [ %r171.1.base.relocated, %gcpoll.56 ], [ %r171.1.base, %apush.merge.51 ]
  %.3910 = phi ptr addrspace(1) [ %r68.1.relocated93, %gcpoll.56 ], [ %.2909, %apush.merge.51 ]
  %.3905 = phi ptr addrspace(1) [ %r68.1.base.relocated92, %gcpoll.56 ], [ %.2904, %apush.merge.51 ]
  %.5 = phi ptr addrspace(1) [ %rs4gc.s19.relocated91, %gcpoll.56 ], [ %.4, %apush.merge.51 ]
  br label %for.update.36

if.then.58:                                       ; preds = %for.exit.37
  %r370 = load double, ptr @test_json_warm_unique_keys_ts_.str.11.handle, align 8
  %r371 = bitcast double %r370 to i64
  %r372.rs4i = ptrtoint ptr addrspace(1) %r171.0 to i64
  %r372.rs4o = call i64 asm "", "=r,0"(i64 %r372.rs4i) #7
  %r372 = bitcast i64 %r372.rs4o to double
  %r373 = bitcast double %r372 to i64
  %r374 = and i64 %r373, 281474976710655
  %r375 = sub nsw i64 %r374, 8
  %r376 = inttoptr i64 %r375 to ptr
  %r377 = load i8, ptr %r376, align 1
  %r378 = icmp ne i8 %r377, 1
  %r379 = sub nsw i64 %r374, 7
  %r380 = inttoptr i64 %r379 to ptr
  %r381 = load i8, ptr %r380, align 1
  %r382 = and i8 %r381, -128
  %r383 = icmp ne i8 %r382, 0
  %r384 = or i1 %r378, %r383
  br i1 %r383, label %apush.fwd.61, label %apush.elements.62

if.merge.60:                                      ; preds = %apush.merge.67
  br label %if.else.73

apush.fwd.61:                                     ; preds = %apush.elements.check.63, %if.then.58
  %statepoint_token94 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r374, double %r370, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0907, ptr addrspace(1) %.2, ptr addrspace(1) %.0902) ]
  %r41195 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token94)
  %r68.1.relocated96 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 2, i32 0) ; (%.0902, %.0907)
  %rs4gc.s19.relocated97 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 1, i32 1) ; (%.2, %.2)
  %r68.1.base.relocated98 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 2, i32 2) ; (%.0902, %.0902)
  %r412 = or i64 %r41195, 9222527611924643840
  %r413 = bitcast i64 %r412 to double
  %rs4gc.b27 = bitcast double %r413 to i64
  %rs4gc.s27 = inttoptr i64 %rs4gc.b27 to ptr addrspace(1)
  br label %apush.merge.67

apush.elements.62:                                ; preds = %if.then.58
  %r386 = add nuw nsw i64 %r374, 8
  %r387 = inttoptr i64 %r386 to ptr
  %r388 = load i64, ptr %r387, align 8
  %r389 = icmp ne i64 %r388, 0
  %r390 = icmp eq i8 %r377, 2
  %r391 = and i1 %r390, %r389
  %r392 = select i1 %r391, i64 %r388, i64 %r374
  %r393 = inttoptr i64 %r392 to ptr
  %r394 = getelementptr i64, ptr %r393, i64 12
  %r395 = load i64, ptr %r394, align 8
  %r396 = icmp ne i64 %r395, 0
  %r397 = and i1 %r391, %r396
  %r398 = select i1 %r397, i64 %r395, i64 %r374
  %r385 = icmp eq i8 %r377, 1
  br i1 %r385, label %apush.nofwd.64, label %apush.elements.check.63

apush.elements.check.63:                          ; preds = %apush.elements.62
  %r399 = icmp ne i64 %r398, 0
  %r400 = sub i64 %r398, 8
  %r401 = inttoptr i64 %r400 to ptr
  %r402 = load i8, ptr %r401, align 1
  %r403 = icmp eq i8 %r402, 1
  %r404 = sub i64 %r398, 7
  %r405 = inttoptr i64 %r404 to ptr
  %r406 = load i8, ptr %r405, align 1
  %r407 = and i8 %r406, -128
  %r408 = icmp eq i8 %r407, 0
  %r409 = and i1 %r399, %r403
  %r410 = and i1 %r409, %r408
  br i1 %r410, label %apush.nofwd.64, label %apush.fwd.61

apush.nofwd.64:                                   ; preds = %apush.elements.check.63, %apush.elements.62
  %r414 = phi i64 [ %r374, %apush.elements.62 ], [ %r398, %apush.elements.check.63 ]
  %r415 = sub i64 %r414, 6
  %r416 = inttoptr i64 %r415 to ptr
  %r417 = load i16, ptr %r416, align 2
  %r418 = and i16 %r417, 1031
  %r419 = icmp eq i16 %r418, 0
  %r420 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r421 = icmp eq i8 %r420, 0
  %r422 = and i1 %r419, %r421
  %r423 = icmp ult i64 %r414, 4096
  %r424 = inttoptr i64 %r414 to ptr
  %r425 = select i1 %r423, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r424
  %r426 = load i32, ptr %r425, align 4
  %r427 = add i64 %r414, 4
  %r428 = inttoptr i64 %r427 to ptr
  %r429 = load i32, ptr %r428, align 4
  %r430 = icmp ult i32 %r426, %r429
  %r431 = and i1 %r430, %r422
  br i1 %r431, label %apush.inbounds.65, label %apush.realloc.66

apush.inbounds.65:                                ; preds = %apush.nofwd.64
  %r432 = icmp ult i64 %r414, 4096
  %r433 = inttoptr i64 %r414 to ptr
  %r434 = select i1 %r432, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r433
  %r435 = load i32, ptr %r434, align 4
  %r436 = zext i32 %r435 to i64
  %r437 = shl nuw nsw i64 %r436, 3
  %r438 = add nuw nsw i64 %r437, 8
  %r439 = add i64 %r414, %r438
  %r440 = inttoptr i64 %r439 to ptr
  store double %r370, ptr %r440, align 8
  %r441 = lshr i64 %r371, 48
  %r442 = icmp eq i64 %r441, 32765
  %r443 = and i16 %r417, -1920
  %r444 = icmp eq i16 %r443, -24576
  %r445 = and i1 %r442, %r444
  br i1 %r445, label %apush.pointer_layout.done.69, label %apush.pointer_layout.bookkeeping.68

apush.realloc.66:                                 ; preds = %apush.nofwd.64
  %statepoint_token99 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r374, double %r370, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0907, ptr addrspace(1) %.2, ptr addrspace(1) %.0902) ]
  %r456100 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token99)
  %r68.1.relocated101 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token99, i32 2, i32 0) ; (%.0902, %.0907)
  %rs4gc.s19.relocated102 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token99, i32 1, i32 1) ; (%.2, %.2)
  %r68.1.base.relocated103 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token99, i32 2, i32 2) ; (%.0902, %.0902)
  %r457 = or i64 %r456100, 9222527611924643840
  %r458 = bitcast i64 %r457 to double
  %rs4gc.b28 = bitcast double %r458 to i64
  %rs4gc.s28 = inttoptr i64 %rs4gc.b28 to ptr addrspace(1)
  br label %apush.merge.67

apush.merge.67:                                   ; preds = %apush.barrier.done.71, %apush.realloc.66, %apush.fwd.61
  %.4911 = phi ptr addrspace(1) [ %r68.1.relocated96, %apush.fwd.61 ], [ %.0907, %apush.barrier.done.71 ], [ %r68.1.relocated101, %apush.realloc.66 ]
  %.4906 = phi ptr addrspace(1) [ %r68.1.base.relocated98, %apush.fwd.61 ], [ %.0902, %apush.barrier.done.71 ], [ %r68.1.base.relocated103, %apush.realloc.66 ]
  %.6 = phi ptr addrspace(1) [ %rs4gc.s19.relocated97, %apush.fwd.61 ], [ %.2, %apush.barrier.done.71 ], [ %rs4gc.s19.relocated102, %apush.realloc.66 ]
  %r171.3 = phi ptr addrspace(1) [ %rs4gc.s27, %apush.fwd.61 ], [ %r171.0, %apush.barrier.done.71 ], [ %rs4gc.s28, %apush.realloc.66 ]
  br label %if.merge.60

apush.pointer_layout.bookkeeping.68:              ; preds = %apush.inbounds.65
  call void @js_string_addref_if_heap_string(double %r370) #7
  %r5876 = load double, ptr @test_json_warm_unique_keys_ts_.str.11.handle, align 8
  %r5877 = bitcast double %r5876 to i64
  call void @js_gc_note_slot_layout(i64 %r414, i32 %r435, i64 %r5877) #7
  %r5874 = load double, ptr @test_json_warm_unique_keys_ts_.str.11.handle, align 8
  %r5875 = bitcast double %r5874 to i64
  call void @js_array_note_numeric_write(i64 %r414, i64 %r5875) #7
  br label %apush.pointer_layout.done.69

apush.pointer_layout.done.69:                     ; preds = %apush.pointer_layout.bookkeeping.68, %apush.inbounds.65
  %r446 = sub i64 %r414, 7
  %r447 = inttoptr i64 %r446 to ptr
  %r448 = load i8, ptr %r447, align 1
  %r449 = and i8 %r448, 32
  %r450 = icmp ne i8 %r449, 0
  %r451 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r452 = icmp ne i32 %r451, 0
  %r453 = or i1 %r450, %r452
  br i1 %r453, label %apush.barrier.70, label %apush.barrier.done.71

apush.barrier.70:                                 ; preds = %apush.pointer_layout.done.69
  %r5872 = load double, ptr @test_json_warm_unique_keys_ts_.str.11.handle, align 8
  %r5873 = bitcast double %r5872 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r414, i64 %r439, i64 %r5873) #7
  br label %apush.barrier.done.71

apush.barrier.done.71:                            ; preds = %apush.barrier.70, %apush.pointer_layout.done.69
  %r454 = add i32 %r435, 1
  %r455 = inttoptr i64 %r414 to ptr
  store i32 %r454, ptr %r455, align 4
  br label %apush.merge.67

if.else.73:                                       ; preds = %if.merge.60
  br label %if.merge.74

if.merge.74:                                      ; preds = %if.else.73
  br label %if.else.87

if.else.87:                                       ; preds = %if.merge.74
  br label %if.merge.88

if.merge.88:                                      ; preds = %if.else.87
  br label %if.else.101

if.else.101:                                      ; preds = %if.merge.88
  br label %if.merge.102

if.merge.102:                                     ; preds = %if.else.101
  %r735 = load double, ptr @test_json_warm_unique_keys_ts_.str.15.handle, align 8
  %r736.rs4i = ptrtoint ptr addrspace(1) %r171.3 to i64
  %r736.rs4o = call i64 asm "", "=r,0"(i64 %r736.rs4i) #7
  %r736 = bitcast i64 %r736.rs4o to double
  %r737 = load double, ptr @test_json_warm_unique_keys_ts_.str.16.handle, align 8
  %r738 = bitcast double %r736 to i64
  %r739 = and i64 %r738, 281474976710655
  %statepoint_token104 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_join_value, i32 2, i32 0, i64 %r739, double %r737, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6, ptr addrspace(1) %.4906, ptr addrspace(1) %.4911) ]
  %r740105 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token104)
  %rs4gc.s19.relocated106 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token104, i32 0, i32 0) ; (%.6, %.6)
  %r68.1.base.relocated107 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token104, i32 1, i32 1) ; (%.4906, %.4906)
  %r68.1.relocated108 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token104, i32 1, i32 2) ; (%.4906, %.4911)
  %r741 = or i64 %r740105, 9223090561878065152
  %r742 = bitcast i64 %r741 to double
  %r743 = load double, ptr @test_json_warm_unique_keys_ts_.str.17.handle, align 8
  %r744 = load double, ptr @test_json_warm_unique_keys_ts_.str.15.handle, align 8
  %r746 = getelementptr double, ptr %r745, i64 0
  store double %r744, ptr %r746, align 8
  %r747 = getelementptr double, ptr %r745, i64 1
  store double %r742, ptr %r747, align 8
  %r748 = getelementptr double, ptr %r745, i64 2
  store double %r743, ptr %r748, align 8
  %r749 = ptrtoint ptr %r745 to i64
  %statepoint_token109 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r749, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated106, ptr addrspace(1) %r68.1.base.relocated107, ptr addrspace(1) %r68.1.relocated108) ]
  %r750110 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token109)
  %rs4gc.s19.relocated111 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token109, i32 0, i32 0) ; (%rs4gc.s19.relocated106, %rs4gc.s19.relocated106)
  %r68.1.base.relocated112 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token109, i32 1, i32 1) ; (%r68.1.base.relocated107, %r68.1.base.relocated107)
  %r68.1.relocated113 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token109, i32 1, i32 2) ; (%r68.1.base.relocated107, %r68.1.relocated108)
  %r751 = or i64 %r750110, 9223090561878065152
  %r752 = bitcast i64 %r751 to double
  %r753 = bitcast i64 %r751 to double
  %r754.rs4i = ptrtoint ptr addrspace(1) %r68.1.relocated113 to i64
  %r754.rs4o = call i64 asm "", "=r,0"(i64 %r754.rs4i) #7
  %r754 = bitcast i64 %r754.rs4o to double
  %r755 = bitcast double %r754 to i64
  %r756 = and i64 %r755, 281474976710655
  %r757 = sub nsw i64 %r756, 8
  %r758 = inttoptr i64 %r757 to ptr
  %r759 = load i8, ptr %r758, align 1
  %r760 = icmp ne i8 %r759, 1
  %r761 = sub nsw i64 %r756, 7
  %r762 = inttoptr i64 %r761 to ptr
  %r763 = load i8, ptr %r762, align 1
  %r764 = and i8 %r763, -128
  %r765 = icmp ne i8 %r764, 0
  %r766 = or i1 %r760, %r765
  br i1 %r765, label %apush.fwd.114, label %apush.elements.115

apush.fwd.114:                                    ; preds = %apush.elements.check.116, %if.merge.102
  %statepoint_token114 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r756, double %r753, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated111) ]
  %r793115 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token114)
  %rs4gc.s19.relocated116 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token114, i32 0, i32 0) ; (%rs4gc.s19.relocated111, %rs4gc.s19.relocated111)
  %r794 = or i64 %r793115, 9222527611924643840
  %r795 = bitcast i64 %r794 to double
  %rs4gc.b35 = bitcast double %r795 to i64
  %rs4gc.s35 = inttoptr i64 %rs4gc.b35 to ptr addrspace(1)
  br label %apush.merge.120

apush.elements.115:                               ; preds = %if.merge.102
  %r768 = add nuw nsw i64 %r756, 8
  %r769 = inttoptr i64 %r768 to ptr
  %r770 = load i64, ptr %r769, align 8
  %r771 = icmp ne i64 %r770, 0
  %r772 = icmp eq i8 %r759, 2
  %r773 = and i1 %r772, %r771
  %r774 = select i1 %r773, i64 %r770, i64 %r756
  %r775 = inttoptr i64 %r774 to ptr
  %r776 = getelementptr i64, ptr %r775, i64 12
  %r777 = load i64, ptr %r776, align 8
  %r778 = icmp ne i64 %r777, 0
  %r779 = and i1 %r773, %r778
  %r780 = select i1 %r779, i64 %r777, i64 %r756
  %r767 = icmp eq i8 %r759, 1
  br i1 %r767, label %apush.nofwd.117, label %apush.elements.check.116

apush.elements.check.116:                         ; preds = %apush.elements.115
  %r781 = icmp ne i64 %r780, 0
  %r782 = sub i64 %r780, 8
  %r783 = inttoptr i64 %r782 to ptr
  %r784 = load i8, ptr %r783, align 1
  %r785 = icmp eq i8 %r784, 1
  %r786 = sub i64 %r780, 7
  %r787 = inttoptr i64 %r786 to ptr
  %r788 = load i8, ptr %r787, align 1
  %r789 = and i8 %r788, -128
  %r790 = icmp eq i8 %r789, 0
  %r791 = and i1 %r781, %r785
  %r792 = and i1 %r791, %r790
  br i1 %r792, label %apush.nofwd.117, label %apush.fwd.114

apush.nofwd.117:                                  ; preds = %apush.elements.check.116, %apush.elements.115
  %r796 = phi i64 [ %r756, %apush.elements.115 ], [ %r780, %apush.elements.check.116 ]
  %r797 = sub i64 %r796, 6
  %r798 = inttoptr i64 %r797 to ptr
  %r799 = load i16, ptr %r798, align 2
  %r800 = and i16 %r799, 1031
  %r801 = icmp eq i16 %r800, 0
  %r802 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r803 = icmp eq i8 %r802, 0
  %r804 = and i1 %r801, %r803
  %r805 = icmp ult i64 %r796, 4096
  %r806 = inttoptr i64 %r796 to ptr
  %r807 = select i1 %r805, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r806
  %r808 = load i32, ptr %r807, align 4
  %r809 = add i64 %r796, 4
  %r810 = inttoptr i64 %r809 to ptr
  %r811 = load i32, ptr %r810, align 4
  %r812 = icmp ult i32 %r808, %r811
  %r813 = and i1 %r812, %r804
  br i1 %r813, label %apush.inbounds.118, label %apush.realloc.119

apush.inbounds.118:                               ; preds = %apush.nofwd.117
  %r814 = icmp ult i64 %r796, 4096
  %r815 = inttoptr i64 %r796 to ptr
  %r816 = select i1 %r814, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r815
  %r817 = load i32, ptr %r816, align 4
  %r818 = zext i32 %r817 to i64
  %r819 = shl nuw nsw i64 %r818, 3
  %r820 = add nuw nsw i64 %r819, 8
  %r821 = add i64 %r796, %r820
  %r822 = inttoptr i64 %r821 to ptr
  store double %r753, ptr %r822, align 8
  %r823 = lshr i64 %r751, 48
  %r825 = and i16 %r799, -1920
  %r826 = icmp eq i16 %r825, -24576
  br label %apush.pointer_layout.bookkeeping.121

apush.realloc.119:                                ; preds = %apush.nofwd.117
  %statepoint_token117 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r756, double %r753, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated111) ]
  %r838118 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token117)
  %rs4gc.s19.relocated119 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token117, i32 0, i32 0) ; (%rs4gc.s19.relocated111, %rs4gc.s19.relocated111)
  %r839 = or i64 %r838118, 9222527611924643840
  %r840 = bitcast i64 %r839 to double
  %rs4gc.b36 = bitcast double %r840 to i64
  %rs4gc.s36 = inttoptr i64 %rs4gc.b36 to ptr addrspace(1)
  br label %apush.merge.120

apush.merge.120:                                  ; preds = %apush.barrier.done.124, %apush.realloc.119, %apush.fwd.114
  %.7 = phi ptr addrspace(1) [ %rs4gc.s19.relocated116, %apush.fwd.114 ], [ %rs4gc.s19.relocated111, %apush.barrier.done.124 ], [ %rs4gc.s19.relocated119, %apush.realloc.119 ]
  %r68.2.base = phi ptr addrspace(1) [ %rs4gc.s35, %apush.fwd.114 ], [ %r68.1.base.relocated112, %apush.barrier.done.124 ], [ %rs4gc.s36, %apush.realloc.119 ], !is_base_value !0
  %r68.2 = phi ptr addrspace(1) [ %rs4gc.s35, %apush.fwd.114 ], [ %r68.1.relocated113, %apush.barrier.done.124 ], [ %rs4gc.s36, %apush.realloc.119 ]
  %r841 = load double, ptr @test_json_warm_unique_keys_ts_.str.8.handle, align 8
  %r842 = bitcast double %r841 to i64
  %r843.rs4i = ptrtoint ptr addrspace(1) %r68.2 to i64
  %r843.rs4o = call i64 asm "", "=r,0"(i64 %r843.rs4i) #7
  %r843 = bitcast i64 %r843.rs4o to double
  %r844 = bitcast double %r843 to i64
  %r845 = and i64 %r844, 281474976710655
  %r846 = sub nsw i64 %r845, 8
  %r847 = inttoptr i64 %r846 to ptr
  %r848 = load i8, ptr %r847, align 1
  %r849 = icmp ne i8 %r848, 1
  %r850 = sub nsw i64 %r845, 7
  %r851 = inttoptr i64 %r850 to ptr
  %r852 = load i8, ptr %r851, align 1
  %r853 = and i8 %r852, -128
  %r854 = icmp ne i8 %r853, 0
  %r855 = or i1 %r849, %r854
  br i1 %r854, label %apush.fwd.125, label %apush.elements.126

apush.pointer_layout.bookkeeping.121:             ; preds = %apush.inbounds.118
  call void @js_string_addref_if_heap_string(double %r753) #7
  call void @js_gc_note_slot_layout(i64 %r796, i32 %r817, i64 %r751) #7
  call void @js_array_note_numeric_write(i64 %r796, i64 %r751) #7
  br label %apush.pointer_layout.done.122

apush.pointer_layout.done.122:                    ; preds = %apush.pointer_layout.bookkeeping.121
  %r828 = sub i64 %r796, 7
  %r829 = inttoptr i64 %r828 to ptr
  %r830 = load i8, ptr %r829, align 1
  %r831 = and i8 %r830, 32
  %r832 = icmp ne i8 %r831, 0
  %r833 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r834 = icmp ne i32 %r833, 0
  %r835 = or i1 %r832, %r834
  br i1 %r835, label %apush.barrier.123, label %apush.barrier.done.124

apush.barrier.123:                                ; preds = %apush.pointer_layout.done.122
  call void @js_write_barrier_slot_validated_parent(i64 %r796, i64 %r821, i64 %r751) #7
  br label %apush.barrier.done.124

apush.barrier.done.124:                           ; preds = %apush.barrier.123, %apush.pointer_layout.done.122
  %r836 = add i32 %r817, 1
  %r837 = inttoptr i64 %r796 to ptr
  store i32 %r836, ptr %r837, align 4
  br label %apush.merge.120

apush.fwd.125:                                    ; preds = %apush.elements.check.127, %apush.merge.120
  %statepoint_token120 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r845, double %r841, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.7) ]
  %r882121 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token120)
  %rs4gc.s19.relocated122 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token120, i32 0, i32 0) ; (%.7, %.7)
  %r883 = or i64 %r882121, 9222527611924643840
  %r884 = bitcast i64 %r883 to double
  %rs4gc.b37 = bitcast double %r884 to i64
  %rs4gc.s37 = inttoptr i64 %rs4gc.b37 to ptr addrspace(1)
  br label %apush.merge.131

apush.elements.126:                               ; preds = %apush.merge.120
  %r857 = add nuw nsw i64 %r845, 8
  %r858 = inttoptr i64 %r857 to ptr
  %r859 = load i64, ptr %r858, align 8
  %r860 = icmp ne i64 %r859, 0
  %r861 = icmp eq i8 %r848, 2
  %r862 = and i1 %r861, %r860
  %r863 = select i1 %r862, i64 %r859, i64 %r845
  %r864 = inttoptr i64 %r863 to ptr
  %r865 = getelementptr i64, ptr %r864, i64 12
  %r866 = load i64, ptr %r865, align 8
  %r867 = icmp ne i64 %r866, 0
  %r868 = and i1 %r862, %r867
  %r869 = select i1 %r868, i64 %r866, i64 %r845
  %r856 = icmp eq i8 %r848, 1
  br i1 %r856, label %apush.nofwd.128, label %apush.elements.check.127

apush.elements.check.127:                         ; preds = %apush.elements.126
  %r870 = icmp ne i64 %r869, 0
  %r871 = sub i64 %r869, 8
  %r872 = inttoptr i64 %r871 to ptr
  %r873 = load i8, ptr %r872, align 1
  %r874 = icmp eq i8 %r873, 1
  %r875 = sub i64 %r869, 7
  %r876 = inttoptr i64 %r875 to ptr
  %r877 = load i8, ptr %r876, align 1
  %r878 = and i8 %r877, -128
  %r879 = icmp eq i8 %r878, 0
  %r880 = and i1 %r870, %r874
  %r881 = and i1 %r880, %r879
  br i1 %r881, label %apush.nofwd.128, label %apush.fwd.125

apush.nofwd.128:                                  ; preds = %apush.elements.check.127, %apush.elements.126
  %r885 = phi i64 [ %r845, %apush.elements.126 ], [ %r869, %apush.elements.check.127 ]
  %r886 = sub i64 %r885, 6
  %r887 = inttoptr i64 %r886 to ptr
  %r888 = load i16, ptr %r887, align 2
  %r889 = and i16 %r888, 1031
  %r890 = icmp eq i16 %r889, 0
  %r891 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r892 = icmp eq i8 %r891, 0
  %r893 = and i1 %r890, %r892
  %r894 = icmp ult i64 %r885, 4096
  %r895 = inttoptr i64 %r885 to ptr
  %r896 = select i1 %r894, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r895
  %r897 = load i32, ptr %r896, align 4
  %r898 = add i64 %r885, 4
  %r899 = inttoptr i64 %r898 to ptr
  %r900 = load i32, ptr %r899, align 4
  %r901 = icmp ult i32 %r897, %r900
  %r902 = and i1 %r901, %r893
  br i1 %r902, label %apush.inbounds.129, label %apush.realloc.130

apush.inbounds.129:                               ; preds = %apush.nofwd.128
  %r903 = icmp ult i64 %r885, 4096
  %r904 = inttoptr i64 %r885 to ptr
  %r905 = select i1 %r903, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r904
  %r906 = load i32, ptr %r905, align 4
  %r907 = zext i32 %r906 to i64
  %r908 = shl nuw nsw i64 %r907, 3
  %r909 = add nuw nsw i64 %r908, 8
  %r910 = add i64 %r885, %r909
  %r911 = inttoptr i64 %r910 to ptr
  store double %r841, ptr %r911, align 8
  %r912 = lshr i64 %r842, 48
  %r913 = icmp eq i64 %r912, 32765
  %r914 = and i16 %r888, -1920
  %r915 = icmp eq i16 %r914, -24576
  %r916 = and i1 %r913, %r915
  br i1 %r916, label %apush.pointer_layout.done.133, label %apush.pointer_layout.bookkeeping.132

apush.realloc.130:                                ; preds = %apush.nofwd.128
  %statepoint_token123 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r845, double %r841, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.7) ]
  %r927124 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token123)
  %rs4gc.s19.relocated125 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token123, i32 0, i32 0) ; (%.7, %.7)
  %r928 = or i64 %r927124, 9222527611924643840
  %r929 = bitcast i64 %r928 to double
  %rs4gc.b38 = bitcast double %r929 to i64
  %rs4gc.s38 = inttoptr i64 %rs4gc.b38 to ptr addrspace(1)
  br label %apush.merge.131

apush.merge.131:                                  ; preds = %apush.barrier.done.135, %apush.realloc.130, %apush.fwd.125
  %.8 = phi ptr addrspace(1) [ %rs4gc.s19.relocated122, %apush.fwd.125 ], [ %.7, %apush.barrier.done.135 ], [ %rs4gc.s19.relocated125, %apush.realloc.130 ]
  %r68.3.base = phi ptr addrspace(1) [ %rs4gc.s37, %apush.fwd.125 ], [ %r68.2.base, %apush.barrier.done.135 ], [ %rs4gc.s38, %apush.realloc.130 ], !is_base_value !0
  %r68.3 = phi ptr addrspace(1) [ %rs4gc.s37, %apush.fwd.125 ], [ %r68.2, %apush.barrier.done.135 ], [ %rs4gc.s38, %apush.realloc.130 ]
  %statepoint_token126 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.8, ptr addrspace(1) %r68.3.base, ptr addrspace(1) %r68.3) ]
  %r931127 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token126)
  %rs4gc.s19.relocated128 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token126, i32 0, i32 0) ; (%.8, %.8)
  %r68.3.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token126, i32 1, i32 1) ; (%r68.3.base, %r68.3.base)
  %r68.3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token126, i32 1, i32 2) ; (%r68.3.base, %r68.3)
  %r932 = or i64 %r931127, 9222527611924643840
  %r933 = bitcast i64 %r932 to double
  %rs4gc.b39 = bitcast double %r933 to i64
  %rs4gc.s39 = inttoptr i64 %rs4gc.b39 to ptr addrspace(1)
  %r934.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s39 to i64
  %r934 = call i64 asm "", "=r,0"(i64 %r934.rs4i) #7
  %r935 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r936 = icmp ne i32 %r935, 0
  br i1 %r936, label %shadow.root.barrier.136, label %shadow.root.barrier.done.137

apush.pointer_layout.bookkeeping.132:             ; preds = %apush.inbounds.129
  call void @js_string_addref_if_heap_string(double %r841) #7
  %r5852 = load double, ptr @test_json_warm_unique_keys_ts_.str.8.handle, align 8
  %r5853 = bitcast double %r5852 to i64
  call void @js_gc_note_slot_layout(i64 %r885, i32 %r906, i64 %r5853) #7
  %r5850 = load double, ptr @test_json_warm_unique_keys_ts_.str.8.handle, align 8
  %r5851 = bitcast double %r5850 to i64
  call void @js_array_note_numeric_write(i64 %r885, i64 %r5851) #7
  br label %apush.pointer_layout.done.133

apush.pointer_layout.done.133:                    ; preds = %apush.pointer_layout.bookkeeping.132, %apush.inbounds.129
  %r917 = sub i64 %r885, 7
  %r918 = inttoptr i64 %r917 to ptr
  %r919 = load i8, ptr %r918, align 1
  %r920 = and i8 %r919, 32
  %r921 = icmp ne i8 %r920, 0
  %r922 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r923 = icmp ne i32 %r922, 0
  %r924 = or i1 %r921, %r923
  br i1 %r924, label %apush.barrier.134, label %apush.barrier.done.135

apush.barrier.134:                                ; preds = %apush.pointer_layout.done.133
  %r5848 = load double, ptr @test_json_warm_unique_keys_ts_.str.8.handle, align 8
  %r5849 = bitcast double %r5848 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r885, i64 %r910, i64 %r5849) #7
  br label %apush.barrier.done.135

apush.barrier.done.135:                           ; preds = %apush.barrier.134, %apush.pointer_layout.done.133
  %r925 = add i32 %r906, 1
  %r926 = inttoptr i64 %r885 to ptr
  store i32 %r925, ptr %r926, align 4
  br label %apush.merge.131

shadow.root.barrier.136:                          ; preds = %apush.merge.131
  call void @js_write_barrier_root_nanbox(i64 %r934) #7
  br label %shadow.root.barrier.done.137

shadow.root.barrier.done.137:                     ; preds = %shadow.root.barrier.136, %apush.merge.131
  br label %for.cond.138

for.cond.138:                                     ; preds = %for.update.140, %shadow.root.barrier.done.137
  %.0921 = phi ptr addrspace(1) [ %r68.3.relocated, %shadow.root.barrier.done.137 ], [ %.3924, %for.update.140 ]
  %.0916 = phi ptr addrspace(1) [ %r68.3.base.relocated, %shadow.root.barrier.done.137 ], [ %.3919, %for.update.140 ]
  %.9 = phi ptr addrspace(1) [ %rs4gc.s19.relocated128, %shadow.root.barrier.done.137 ], [ %.12, %for.update.140 ]
  %r937.0 = phi i32 [ 0, %shadow.root.barrier.done.137 ], [ %r1123, %for.update.140 ]
  %r930.0.base = phi ptr addrspace(1) [ %rs4gc.s39, %shadow.root.barrier.done.137 ], [ %.0928, %for.update.140 ], !is_base_value !0
  %r930.0 = phi ptr addrspace(1) [ %rs4gc.s39, %shadow.root.barrier.done.137 ], [ %.0929, %for.update.140 ]
  %r942 = icmp slt i32 %r937.0, %r75.0
  br i1 %r942, label %for.body.139, label %for.exit.141

for.body.139:                                     ; preds = %for.cond.138
  %r943 = load double, ptr @test_json_warm_unique_keys_ts_.str.9.handle, align 8
  %r944.rs4i = ptrtoint ptr addrspace(1) %.9 to i64
  %r944.rs4o = call i64 asm "", "=r,0"(i64 %r944.rs4i) #7
  %r944 = bitcast i64 %r944.rs4o to double
  %r946 = bitcast double %r944 to i64
  %r947 = and i64 %r946, 281474976710655
  %r948 = lshr i64 %r946, 48
  %r949 = icmp eq i64 %r948, 32765
  %r950 = icmp ugt i64 %r947, 1048575
  %r951 = and i1 %r949, %r950
  br i1 %r951, label %arr.guard.deref.146, label %arr.fallback.143

for.update.140:                                   ; preds = %gcpoll.done.161
  %r1123 = add i32 %r937.0, 1
  %r1124 = sitofp i32 %r937.0 to double
  %r1125 = sitofp i32 %r1123 to double
  br label %for.cond.138

for.exit.141:                                     ; preds = %for.cond.138
  br label %if.else.163

arr.fast.142:                                     ; preds = %arr.guard.range.148
  %r1007 = zext i32 %r937.0 to i64
  %r1008 = shl nuw nsw i64 %r1007, 3
  %r1009 = add nuw nsw i64 %r1008, 8
  %r1010 = add i64 %r966, %r1009
  %r1011 = inttoptr i64 %r1010 to ptr
  %r1012 = load double, ptr %r1011, align 8
  %r1013 = bitcast double %r1012 to i64
  %r1014 = icmp eq i64 %r1013, 9222246136947933200
  %r1016 = select i1 %r1014, double 0x7FFC000000000001, double %r1012
  br label %arr.merge.145

arr.fallback.143:                                 ; preds = %arr.guard.live.147, %arr.guard.deref.146, %for.body.139
  %r1005 = sitofp i32 %r937.0 to double
  %statepoint_token129 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 547434508618563585, double %r944, double %r1005, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r930.0, ptr addrspace(1) %r930.0.base, ptr addrspace(1) %.9, ptr addrspace(1) %.0916, ptr addrspace(1) %.0921) ]
  %r1006130 = call double @llvm.experimental.gc.result.f64(token %statepoint_token129)
  %r930.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token129, i32 1, i32 0) ; (%r930.0.base, %r930.0)
  %r930.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token129, i32 1, i32 1) ; (%r930.0.base, %r930.0.base)
  %rs4gc.s19.relocated131 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token129, i32 2, i32 2) ; (%.9, %.9)
  %r68.3.base.relocated132 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token129, i32 3, i32 3) ; (%.0916, %.0916)
  %r68.3.relocated133 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token129, i32 3, i32 4) ; (%.0916, %.0921)
  br label %arr.merge.145

arr.guard.oob.144:                                ; preds = %arr.guard.range.148
  br label %arr.merge.145

arr.merge.145:                                    ; preds = %arr.guard.oob.144, %arr.fallback.143, %arr.fast.142
  %.0927 = phi ptr addrspace(1) [ %r930.0.base, %arr.fast.142 ], [ %r930.0.base, %arr.guard.oob.144 ], [ %r930.0.base.relocated, %arr.fallback.143 ]
  %.0926 = phi ptr addrspace(1) [ %r930.0, %arr.fast.142 ], [ %r930.0, %arr.guard.oob.144 ], [ %r930.0.relocated, %arr.fallback.143 ]
  %.1922 = phi ptr addrspace(1) [ %.0921, %arr.fast.142 ], [ %.0921, %arr.guard.oob.144 ], [ %r68.3.relocated133, %arr.fallback.143 ]
  %.1917 = phi ptr addrspace(1) [ %.0916, %arr.fast.142 ], [ %.0916, %arr.guard.oob.144 ], [ %r68.3.base.relocated132, %arr.fallback.143 ]
  %.10 = phi ptr addrspace(1) [ %.9, %arr.fast.142 ], [ %.9, %arr.guard.oob.144 ], [ %rs4gc.s19.relocated131, %arr.fallback.143 ]
  %r1017 = phi double [ %r1016, %arr.fast.142 ], [ %r1006130, %arr.fallback.143 ], [ 0x7FFC000000000001, %arr.guard.oob.144 ]
  %r1018 = load double, ptr @test_json_warm_unique_keys_ts_.str.10.handle, align 8
  %r1019 = load double, ptr @test_json_warm_unique_keys_ts_.str.9.handle, align 8
  %r1021 = getelementptr double, ptr %r1020, i64 0
  store double %r1019, ptr %r1021, align 8
  %r1022 = getelementptr double, ptr %r1020, i64 1
  store double %r1017, ptr %r1022, align 8
  %r1023 = getelementptr double, ptr %r1020, i64 2
  store double %r1018, ptr %r1023, align 8
  %r1024 = ptrtoint ptr %r1020 to i64
  %statepoint_token134 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r1024, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10, ptr addrspace(1) %.1917, ptr addrspace(1) %.0927, ptr addrspace(1) %.0926, ptr addrspace(1) %.1922) ]
  %r1025135 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token134)
  %rs4gc.s19.relocated136 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token134, i32 0, i32 0) ; (%.10, %.10)
  %r68.3.base.relocated137 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token134, i32 1, i32 1) ; (%.1917, %.1917)
  %r930.0.base.relocated138 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token134, i32 2, i32 2) ; (%.0927, %.0927)
  %r930.0.relocated139 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token134, i32 2, i32 3) ; (%.0927, %.0926)
  %r68.3.relocated140 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token134, i32 1, i32 4) ; (%.1917, %.1922)
  %r1026 = or i64 %r1025135, 9223090561878065152
  %r1027 = bitcast i64 %r1026 to double
  %r1029 = sitofp i32 %r937.0 to double
  %statepoint_token141 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r1027, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated136, ptr addrspace(1) %r68.3.base.relocated137, ptr addrspace(1) %r930.0.base.relocated138, ptr addrspace(1) %r930.0.relocated139, ptr addrspace(1) %r68.3.relocated140) ]
  %r1030142 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token141)
  %rs4gc.s19.relocated143 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 0, i32 0) ; (%rs4gc.s19.relocated136, %rs4gc.s19.relocated136)
  %r68.3.base.relocated144 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 1, i32 1) ; (%r68.3.base.relocated137, %r68.3.base.relocated137)
  %r930.0.base.relocated145 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 2, i32 2) ; (%r930.0.base.relocated138, %r930.0.base.relocated138)
  %r930.0.relocated146 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 2, i32 3) ; (%r930.0.base.relocated138, %r930.0.relocated139)
  %r68.3.relocated147 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 1, i32 4) ; (%r68.3.base.relocated137, %r68.3.relocated140)
  %statepoint_token148 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r1030142, double %r1029, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated143, ptr addrspace(1) %r68.3.base.relocated144, ptr addrspace(1) %r930.0.base.relocated145, ptr addrspace(1) %r930.0.relocated146, ptr addrspace(1) %r68.3.relocated147) ]
  %r1031149 = call double @llvm.experimental.gc.result.f64(token %statepoint_token148)
  %rs4gc.s19.relocated150 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token148, i32 0, i32 0) ; (%rs4gc.s19.relocated143, %rs4gc.s19.relocated143)
  %r68.3.base.relocated151 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token148, i32 1, i32 1) ; (%r68.3.base.relocated144, %r68.3.base.relocated144)
  %r930.0.base.relocated152 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token148, i32 2, i32 2) ; (%r930.0.base.relocated145, %r930.0.base.relocated145)
  %r930.0.relocated153 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token148, i32 2, i32 3) ; (%r930.0.base.relocated145, %r930.0.relocated146)
  %r68.3.relocated154 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token148, i32 1, i32 4) ; (%r68.3.base.relocated144, %r68.3.relocated147)
  %r1032 = bitcast double %r1031149 to i64
  %r1033.rs4i = ptrtoint ptr addrspace(1) %r930.0.relocated153 to i64
  %r1033.rs4o = call i64 asm "", "=r,0"(i64 %r1033.rs4i) #7
  %r1033 = bitcast i64 %r1033.rs4o to double
  %r1034 = bitcast double %r1033 to i64
  %r1035 = and i64 %r1034, 281474976710655
  %r1036 = sub nsw i64 %r1035, 8
  %r1037 = inttoptr i64 %r1036 to ptr
  %r1038 = load i8, ptr %r1037, align 1
  %r1039 = icmp ne i8 %r1038, 1
  %r1040 = sub nsw i64 %r1035, 7
  %r1041 = inttoptr i64 %r1040 to ptr
  %r1042 = load i8, ptr %r1041, align 1
  %r1043 = and i8 %r1042, -128
  %r1044 = icmp ne i8 %r1043, 0
  %r1045 = or i1 %r1039, %r1044
  br i1 %r1044, label %apush.fwd.149, label %apush.elements.150

arr.guard.deref.146:                              ; preds = %for.body.139
  %r952 = bitcast double %r944 to i64
  %r953 = and i64 %r952, 281474976710655
  %r954 = sub nsw i64 %r953, 8
  %r955 = inttoptr i64 %r954 to ptr
  %r956 = load i8, ptr %r955, align 1
  %r957 = icmp eq i8 %r956, 1
  %r958 = sub nsw i64 %r953, 7
  %r959 = inttoptr i64 %r958 to ptr
  %r960 = load i8, ptr %r959, align 1
  %r961 = and i8 %r960, -128
  %r962 = icmp ne i8 %r961, 0
  %r963 = inttoptr i64 %r953 to ptr
  %r964 = load i64, ptr %r963, align 8
  %r965 = and i1 %r957, %r962
  %r966 = select i1 %r965, i64 %r964, i64 %r953
  %r967 = lshr i64 %r966, 48
  %r968 = icmp eq i64 %r967, 0
  %r969 = icmp ugt i64 %r966, 1048575
  %r970 = and i1 %r968, %r969
  br i1 %r970, label %arr.guard.live.147, label %arr.fallback.143

arr.guard.live.147:                               ; preds = %arr.guard.deref.146
  %r971 = sub nuw i64 %r966, 8
  %r972 = inttoptr i64 %r971 to ptr
  %r973 = load i8, ptr %r972, align 1
  %r974 = icmp eq i8 %r973, 1
  %r975 = sub nuw i64 %r966, 7
  %r976 = inttoptr i64 %r975 to ptr
  %r977 = load i8, ptr %r976, align 1
  %r978 = and i8 %r977, -128
  %r979 = icmp eq i8 %r978, 0
  %r980 = sub nuw i64 %r966, 6
  %r981 = inttoptr i64 %r980 to ptr
  %r982 = load i16, ptr %r981, align 2
  %r983 = and i16 %r982, 1024
  %r984 = icmp eq i16 %r983, 0
  %r985 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r986 = icmp eq i8 %r985, 0
  %r987 = inttoptr i64 %r966 to ptr
  %r988 = load i32, ptr %r987, align 4
  %r989 = getelementptr i8, ptr %r987, i64 4
  %r990 = load i32, ptr %r989, align 4
  %r991 = icmp slt i32 %r937.0, 0
  %r992 = icmp eq i1 %r991, false
  %r994 = icmp ule i32 %r988, 16000000
  %r995 = icmp ule i32 %r990, 16000000
  %r996 = icmp ule i32 %r988, %r990
  %r997 = and i1 %r974, %r979
  %r998 = and i1 %r997, %r984
  %r999 = and i1 %r998, %r986
  %r1000 = and i1 %r999, %r992
  %r1001 = and i1 %r1000, %r994
  %r1002 = and i1 %r1001, %r995
  %r1003 = and i1 %r1002, %r996
  br i1 %r1003, label %arr.guard.range.148, label %arr.fallback.143

arr.guard.range.148:                              ; preds = %arr.guard.live.147
  %r993 = icmp ult i32 %r937.0, %r988
  br i1 %r993, label %arr.fast.142, label %arr.guard.oob.144

apush.fwd.149:                                    ; preds = %apush.elements.check.151, %arr.merge.145
  %statepoint_token155 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1035, double %r1031149, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated150, ptr addrspace(1) %r68.3.base.relocated151, ptr addrspace(1) %r68.3.relocated154) ]
  %r1072156 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token155)
  %rs4gc.s19.relocated157 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 0, i32 0) ; (%rs4gc.s19.relocated150, %rs4gc.s19.relocated150)
  %r68.3.base.relocated158 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 1, i32 1) ; (%r68.3.base.relocated151, %r68.3.base.relocated151)
  %r68.3.relocated159 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 1, i32 2) ; (%r68.3.base.relocated151, %r68.3.relocated154)
  %r1073 = or i64 %r1072156, 9222527611924643840
  %r1074 = bitcast i64 %r1073 to double
  %rs4gc.b40 = bitcast double %r1074 to i64
  %rs4gc.s40 = inttoptr i64 %rs4gc.b40 to ptr addrspace(1)
  br label %apush.merge.155

apush.elements.150:                               ; preds = %arr.merge.145
  %r1047 = add nuw nsw i64 %r1035, 8
  %r1048 = inttoptr i64 %r1047 to ptr
  %r1049 = load i64, ptr %r1048, align 8
  %r1050 = icmp ne i64 %r1049, 0
  %r1051 = icmp eq i8 %r1038, 2
  %r1052 = and i1 %r1051, %r1050
  %r1053 = select i1 %r1052, i64 %r1049, i64 %r1035
  %r1054 = inttoptr i64 %r1053 to ptr
  %r1055 = getelementptr i64, ptr %r1054, i64 12
  %r1056 = load i64, ptr %r1055, align 8
  %r1057 = icmp ne i64 %r1056, 0
  %r1058 = and i1 %r1052, %r1057
  %r1059 = select i1 %r1058, i64 %r1056, i64 %r1035
  %r1046 = icmp eq i8 %r1038, 1
  br i1 %r1046, label %apush.nofwd.152, label %apush.elements.check.151

apush.elements.check.151:                         ; preds = %apush.elements.150
  %r1060 = icmp ne i64 %r1059, 0
  %r1061 = sub i64 %r1059, 8
  %r1062 = inttoptr i64 %r1061 to ptr
  %r1063 = load i8, ptr %r1062, align 1
  %r1064 = icmp eq i8 %r1063, 1
  %r1065 = sub i64 %r1059, 7
  %r1066 = inttoptr i64 %r1065 to ptr
  %r1067 = load i8, ptr %r1066, align 1
  %r1068 = and i8 %r1067, -128
  %r1069 = icmp eq i8 %r1068, 0
  %r1070 = and i1 %r1060, %r1064
  %r1071 = and i1 %r1070, %r1069
  br i1 %r1071, label %apush.nofwd.152, label %apush.fwd.149

apush.nofwd.152:                                  ; preds = %apush.elements.check.151, %apush.elements.150
  %r1075 = phi i64 [ %r1035, %apush.elements.150 ], [ %r1059, %apush.elements.check.151 ]
  %r1076 = sub i64 %r1075, 6
  %r1077 = inttoptr i64 %r1076 to ptr
  %r1078 = load i16, ptr %r1077, align 2
  %r1079 = and i16 %r1078, 1031
  %r1080 = icmp eq i16 %r1079, 0
  %r1081 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1082 = icmp eq i8 %r1081, 0
  %r1083 = and i1 %r1080, %r1082
  %r1084 = icmp ult i64 %r1075, 4096
  %r1085 = inttoptr i64 %r1075 to ptr
  %r1086 = select i1 %r1084, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r1085
  %r1087 = load i32, ptr %r1086, align 4
  %r1088 = add i64 %r1075, 4
  %r1089 = inttoptr i64 %r1088 to ptr
  %r1090 = load i32, ptr %r1089, align 4
  %r1091 = icmp ult i32 %r1087, %r1090
  %r1092 = and i1 %r1091, %r1083
  br i1 %r1092, label %apush.inbounds.153, label %apush.realloc.154

apush.inbounds.153:                               ; preds = %apush.nofwd.152
  %r1093 = icmp ult i64 %r1075, 4096
  %r1094 = inttoptr i64 %r1075 to ptr
  %r1095 = select i1 %r1093, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r1094
  %r1096 = load i32, ptr %r1095, align 4
  %r1097 = zext i32 %r1096 to i64
  %r1098 = shl nuw nsw i64 %r1097, 3
  %r1099 = add nuw nsw i64 %r1098, 8
  %r1100 = add i64 %r1075, %r1099
  %r1101 = inttoptr i64 %r1100 to ptr
  store double %r1031149, ptr %r1101, align 8
  %r1102 = lshr i64 %r1032, 48
  %r1103 = icmp eq i64 %r1102, 32765
  %r1104 = and i16 %r1078, -1920
  %r1105 = icmp eq i16 %r1104, -24576
  %r1106 = and i1 %r1103, %r1105
  br i1 %r1106, label %apush.pointer_layout.done.157, label %apush.pointer_layout.bookkeeping.156

apush.realloc.154:                                ; preds = %apush.nofwd.152
  %statepoint_token160 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1035, double %r1031149, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated150, ptr addrspace(1) %r68.3.base.relocated151, ptr addrspace(1) %r68.3.relocated154) ]
  %r1117161 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token160)
  %rs4gc.s19.relocated162 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token160, i32 0, i32 0) ; (%rs4gc.s19.relocated150, %rs4gc.s19.relocated150)
  %r68.3.base.relocated163 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token160, i32 1, i32 1) ; (%r68.3.base.relocated151, %r68.3.base.relocated151)
  %r68.3.relocated164 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token160, i32 1, i32 2) ; (%r68.3.base.relocated151, %r68.3.relocated154)
  %r1118 = or i64 %r1117161, 9222527611924643840
  %r1119 = bitcast i64 %r1118 to double
  %rs4gc.b41 = bitcast double %r1119 to i64
  %rs4gc.s41 = inttoptr i64 %rs4gc.b41 to ptr addrspace(1)
  br label %apush.merge.155

apush.merge.155:                                  ; preds = %apush.barrier.done.159, %apush.realloc.154, %apush.fwd.149
  %.2923 = phi ptr addrspace(1) [ %r68.3.relocated159, %apush.fwd.149 ], [ %r68.3.relocated154, %apush.barrier.done.159 ], [ %r68.3.relocated164, %apush.realloc.154 ]
  %.2918 = phi ptr addrspace(1) [ %r68.3.base.relocated158, %apush.fwd.149 ], [ %r68.3.base.relocated151, %apush.barrier.done.159 ], [ %r68.3.base.relocated163, %apush.realloc.154 ]
  %.11 = phi ptr addrspace(1) [ %rs4gc.s19.relocated157, %apush.fwd.149 ], [ %rs4gc.s19.relocated150, %apush.barrier.done.159 ], [ %rs4gc.s19.relocated162, %apush.realloc.154 ]
  %r930.1.base = phi ptr addrspace(1) [ %rs4gc.s40, %apush.fwd.149 ], [ %r930.0.base.relocated152, %apush.barrier.done.159 ], [ %rs4gc.s41, %apush.realloc.154 ], !is_base_value !0
  %r930.1 = phi ptr addrspace(1) [ %rs4gc.s40, %apush.fwd.149 ], [ %r930.0.relocated153, %apush.barrier.done.159 ], [ %rs4gc.s41, %apush.realloc.154 ]
  %r1120 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1121 = icmp ne i32 %r1120, 0
  br i1 %r1121, label %gcpoll.160, label %gcpoll.done.161

apush.pointer_layout.bookkeeping.156:             ; preds = %apush.inbounds.153
  call void @js_string_addref_if_heap_string(double %r1031149) #7
  call void @js_gc_note_slot_layout(i64 %r1075, i32 %r1096, i64 %r1032) #7
  call void @js_array_note_numeric_write(i64 %r1075, i64 %r1032) #7
  br label %apush.pointer_layout.done.157

apush.pointer_layout.done.157:                    ; preds = %apush.pointer_layout.bookkeeping.156, %apush.inbounds.153
  %r1107 = sub i64 %r1075, 7
  %r1108 = inttoptr i64 %r1107 to ptr
  %r1109 = load i8, ptr %r1108, align 1
  %r1110 = and i8 %r1109, 32
  %r1111 = icmp ne i8 %r1110, 0
  %r1112 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1113 = icmp ne i32 %r1112, 0
  %r1114 = or i1 %r1111, %r1113
  br i1 %r1114, label %apush.barrier.158, label %apush.barrier.done.159

apush.barrier.158:                                ; preds = %apush.pointer_layout.done.157
  call void @js_write_barrier_slot_validated_parent(i64 %r1075, i64 %r1100, i64 %r1032) #7
  br label %apush.barrier.done.159

apush.barrier.done.159:                           ; preds = %apush.barrier.158, %apush.pointer_layout.done.157
  %r1115 = add i32 %r1096, 1
  %r1116 = inttoptr i64 %r1075 to ptr
  store i32 %r1115, ptr %r1116, align 4
  br label %apush.merge.155

gcpoll.160:                                       ; preds = %apush.merge.155
  %statepoint_token165 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r930.1.base, ptr addrspace(1) %r930.1, ptr addrspace(1) %.11, ptr addrspace(1) %.2918, ptr addrspace(1) %.2923) ]
  %r930.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token165, i32 0, i32 0) ; (%r930.1.base, %r930.1.base)
  %r930.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token165, i32 0, i32 1) ; (%r930.1.base, %r930.1)
  %rs4gc.s19.relocated166 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token165, i32 2, i32 2) ; (%.11, %.11)
  %r68.3.base.relocated167 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token165, i32 3, i32 3) ; (%.2918, %.2918)
  %r68.3.relocated168 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token165, i32 3, i32 4) ; (%.2918, %.2923)
  br label %gcpoll.done.161

gcpoll.done.161:                                  ; preds = %gcpoll.160, %apush.merge.155
  %.0929 = phi ptr addrspace(1) [ %r930.1.relocated, %gcpoll.160 ], [ %r930.1, %apush.merge.155 ]
  %.0928 = phi ptr addrspace(1) [ %r930.1.base.relocated, %gcpoll.160 ], [ %r930.1.base, %apush.merge.155 ]
  %.3924 = phi ptr addrspace(1) [ %r68.3.relocated168, %gcpoll.160 ], [ %.2923, %apush.merge.155 ]
  %.3919 = phi ptr addrspace(1) [ %r68.3.base.relocated167, %gcpoll.160 ], [ %.2918, %apush.merge.155 ]
  %.12 = phi ptr addrspace(1) [ %rs4gc.s19.relocated166, %gcpoll.160 ], [ %.11, %apush.merge.155 ]
  br label %for.update.140

if.else.163:                                      ; preds = %for.exit.141
  br label %if.merge.164

if.merge.164:                                     ; preds = %if.else.163
  br label %if.then.176

if.then.176:                                      ; preds = %if.merge.164
  %r1221 = load double, ptr @test_json_warm_unique_keys_ts_.str.12.handle, align 8
  %r1222 = bitcast double %r1221 to i64
  %r1223.rs4i = ptrtoint ptr addrspace(1) %r930.0 to i64
  %r1223.rs4o = call i64 asm "", "=r,0"(i64 %r1223.rs4i) #7
  %r1223 = bitcast i64 %r1223.rs4o to double
  %r1224 = bitcast double %r1223 to i64
  %r1225 = and i64 %r1224, 281474976710655
  %r1226 = sub nsw i64 %r1225, 8
  %r1227 = inttoptr i64 %r1226 to ptr
  %r1228 = load i8, ptr %r1227, align 1
  %r1229 = icmp ne i8 %r1228, 1
  %r1230 = sub nsw i64 %r1225, 7
  %r1231 = inttoptr i64 %r1230 to ptr
  %r1232 = load i8, ptr %r1231, align 1
  %r1233 = and i8 %r1232, -128
  %r1234 = icmp ne i8 %r1233, 0
  %r1235 = or i1 %r1229, %r1234
  br i1 %r1234, label %apush.fwd.179, label %apush.elements.180

if.merge.178:                                     ; preds = %apush.merge.185
  br label %if.else.191

apush.fwd.179:                                    ; preds = %apush.elements.check.181, %if.then.176
  %statepoint_token169 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1225, double %r1221, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0921, ptr addrspace(1) %.9, ptr addrspace(1) %.0916) ]
  %r1262170 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token169)
  %r68.3.relocated171 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 2, i32 0) ; (%.0916, %.0921)
  %rs4gc.s19.relocated172 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 1, i32 1) ; (%.9, %.9)
  %r68.3.base.relocated173 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 2, i32 2) ; (%.0916, %.0916)
  %r1263 = or i64 %r1262170, 9222527611924643840
  %r1264 = bitcast i64 %r1263 to double
  %rs4gc.b44 = bitcast double %r1264 to i64
  %rs4gc.s44 = inttoptr i64 %rs4gc.b44 to ptr addrspace(1)
  br label %apush.merge.185

apush.elements.180:                               ; preds = %if.then.176
  %r1237 = add nuw nsw i64 %r1225, 8
  %r1238 = inttoptr i64 %r1237 to ptr
  %r1239 = load i64, ptr %r1238, align 8
  %r1240 = icmp ne i64 %r1239, 0
  %r1241 = icmp eq i8 %r1228, 2
  %r1242 = and i1 %r1241, %r1240
  %r1243 = select i1 %r1242, i64 %r1239, i64 %r1225
  %r1244 = inttoptr i64 %r1243 to ptr
  %r1245 = getelementptr i64, ptr %r1244, i64 12
  %r1246 = load i64, ptr %r1245, align 8
  %r1247 = icmp ne i64 %r1246, 0
  %r1248 = and i1 %r1242, %r1247
  %r1249 = select i1 %r1248, i64 %r1246, i64 %r1225
  %r1236 = icmp eq i8 %r1228, 1
  br i1 %r1236, label %apush.nofwd.182, label %apush.elements.check.181

apush.elements.check.181:                         ; preds = %apush.elements.180
  %r1250 = icmp ne i64 %r1249, 0
  %r1251 = sub i64 %r1249, 8
  %r1252 = inttoptr i64 %r1251 to ptr
  %r1253 = load i8, ptr %r1252, align 1
  %r1254 = icmp eq i8 %r1253, 1
  %r1255 = sub i64 %r1249, 7
  %r1256 = inttoptr i64 %r1255 to ptr
  %r1257 = load i8, ptr %r1256, align 1
  %r1258 = and i8 %r1257, -128
  %r1259 = icmp eq i8 %r1258, 0
  %r1260 = and i1 %r1250, %r1254
  %r1261 = and i1 %r1260, %r1259
  br i1 %r1261, label %apush.nofwd.182, label %apush.fwd.179

apush.nofwd.182:                                  ; preds = %apush.elements.check.181, %apush.elements.180
  %r1265 = phi i64 [ %r1225, %apush.elements.180 ], [ %r1249, %apush.elements.check.181 ]
  %r1266 = sub i64 %r1265, 6
  %r1267 = inttoptr i64 %r1266 to ptr
  %r1268 = load i16, ptr %r1267, align 2
  %r1269 = and i16 %r1268, 1031
  %r1270 = icmp eq i16 %r1269, 0
  %r1271 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1272 = icmp eq i8 %r1271, 0
  %r1273 = and i1 %r1270, %r1272
  %r1274 = icmp ult i64 %r1265, 4096
  %r1275 = inttoptr i64 %r1265 to ptr
  %r1276 = select i1 %r1274, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r1275
  %r1277 = load i32, ptr %r1276, align 4
  %r1278 = add i64 %r1265, 4
  %r1279 = inttoptr i64 %r1278 to ptr
  %r1280 = load i32, ptr %r1279, align 4
  %r1281 = icmp ult i32 %r1277, %r1280
  %r1282 = and i1 %r1281, %r1273
  br i1 %r1282, label %apush.inbounds.183, label %apush.realloc.184

apush.inbounds.183:                               ; preds = %apush.nofwd.182
  %r1283 = icmp ult i64 %r1265, 4096
  %r1284 = inttoptr i64 %r1265 to ptr
  %r1285 = select i1 %r1283, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r1284
  %r1286 = load i32, ptr %r1285, align 4
  %r1287 = zext i32 %r1286 to i64
  %r1288 = shl nuw nsw i64 %r1287, 3
  %r1289 = add nuw nsw i64 %r1288, 8
  %r1290 = add i64 %r1265, %r1289
  %r1291 = inttoptr i64 %r1290 to ptr
  store double %r1221, ptr %r1291, align 8
  %r1292 = lshr i64 %r1222, 48
  %r1293 = icmp eq i64 %r1292, 32765
  %r1294 = and i16 %r1268, -1920
  %r1295 = icmp eq i16 %r1294, -24576
  %r1296 = and i1 %r1293, %r1295
  br i1 %r1296, label %apush.pointer_layout.done.187, label %apush.pointer_layout.bookkeeping.186

apush.realloc.184:                                ; preds = %apush.nofwd.182
  %statepoint_token174 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1225, double %r1221, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0921, ptr addrspace(1) %.9, ptr addrspace(1) %.0916) ]
  %r1307175 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token174)
  %r68.3.relocated176 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token174, i32 2, i32 0) ; (%.0916, %.0921)
  %rs4gc.s19.relocated177 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token174, i32 1, i32 1) ; (%.9, %.9)
  %r68.3.base.relocated178 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token174, i32 2, i32 2) ; (%.0916, %.0916)
  %r1308 = or i64 %r1307175, 9222527611924643840
  %r1309 = bitcast i64 %r1308 to double
  %rs4gc.b45 = bitcast double %r1309 to i64
  %rs4gc.s45 = inttoptr i64 %rs4gc.b45 to ptr addrspace(1)
  br label %apush.merge.185

apush.merge.185:                                  ; preds = %apush.barrier.done.189, %apush.realloc.184, %apush.fwd.179
  %.4925 = phi ptr addrspace(1) [ %r68.3.relocated171, %apush.fwd.179 ], [ %.0921, %apush.barrier.done.189 ], [ %r68.3.relocated176, %apush.realloc.184 ]
  %.4920 = phi ptr addrspace(1) [ %r68.3.base.relocated173, %apush.fwd.179 ], [ %.0916, %apush.barrier.done.189 ], [ %r68.3.base.relocated178, %apush.realloc.184 ]
  %.13 = phi ptr addrspace(1) [ %rs4gc.s19.relocated172, %apush.fwd.179 ], [ %.9, %apush.barrier.done.189 ], [ %rs4gc.s19.relocated177, %apush.realloc.184 ]
  %r930.5 = phi ptr addrspace(1) [ %rs4gc.s44, %apush.fwd.179 ], [ %r930.0, %apush.barrier.done.189 ], [ %rs4gc.s45, %apush.realloc.184 ]
  br label %if.merge.178

apush.pointer_layout.bookkeeping.186:             ; preds = %apush.inbounds.183
  call void @js_string_addref_if_heap_string(double %r1221) #7
  %r5840 = load double, ptr @test_json_warm_unique_keys_ts_.str.12.handle, align 8
  %r5841 = bitcast double %r5840 to i64
  call void @js_gc_note_slot_layout(i64 %r1265, i32 %r1286, i64 %r5841) #7
  %r5838 = load double, ptr @test_json_warm_unique_keys_ts_.str.12.handle, align 8
  %r5839 = bitcast double %r5838 to i64
  call void @js_array_note_numeric_write(i64 %r1265, i64 %r5839) #7
  br label %apush.pointer_layout.done.187

apush.pointer_layout.done.187:                    ; preds = %apush.pointer_layout.bookkeeping.186, %apush.inbounds.183
  %r1297 = sub i64 %r1265, 7
  %r1298 = inttoptr i64 %r1297 to ptr
  %r1299 = load i8, ptr %r1298, align 1
  %r1300 = and i8 %r1299, 32
  %r1301 = icmp ne i8 %r1300, 0
  %r1302 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1303 = icmp ne i32 %r1302, 0
  %r1304 = or i1 %r1301, %r1303
  br i1 %r1304, label %apush.barrier.188, label %apush.barrier.done.189

apush.barrier.188:                                ; preds = %apush.pointer_layout.done.187
  %r5836 = load double, ptr @test_json_warm_unique_keys_ts_.str.12.handle, align 8
  %r5837 = bitcast double %r5836 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r1265, i64 %r1290, i64 %r5837) #7
  br label %apush.barrier.done.189

apush.barrier.done.189:                           ; preds = %apush.barrier.188, %apush.pointer_layout.done.187
  %r1305 = add i32 %r1286, 1
  %r1306 = inttoptr i64 %r1265 to ptr
  store i32 %r1305, ptr %r1306, align 4
  br label %apush.merge.185

if.else.191:                                      ; preds = %if.merge.178
  br label %if.merge.192

if.merge.192:                                     ; preds = %if.else.191
  br label %if.else.205

if.else.205:                                      ; preds = %if.merge.192
  br label %if.merge.206

if.merge.206:                                     ; preds = %if.else.205
  %r1494 = load double, ptr @test_json_warm_unique_keys_ts_.str.15.handle, align 8
  %r1495.rs4i = ptrtoint ptr addrspace(1) %r930.5 to i64
  %r1495.rs4o = call i64 asm "", "=r,0"(i64 %r1495.rs4i) #7
  %r1495 = bitcast i64 %r1495.rs4o to double
  %r1496 = load double, ptr @test_json_warm_unique_keys_ts_.str.16.handle, align 8
  %r1497 = bitcast double %r1495 to i64
  %r1498 = and i64 %r1497, 281474976710655
  %statepoint_token179 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_join_value, i32 2, i32 0, i64 %r1498, double %r1496, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.13, ptr addrspace(1) %.4920, ptr addrspace(1) %.4925) ]
  %r1499180 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token179)
  %rs4gc.s19.relocated181 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token179, i32 0, i32 0) ; (%.13, %.13)
  %r68.3.base.relocated182 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token179, i32 1, i32 1) ; (%.4920, %.4920)
  %r68.3.relocated183 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token179, i32 1, i32 2) ; (%.4920, %.4925)
  %r1500 = or i64 %r1499180, 9223090561878065152
  %r1501 = bitcast i64 %r1500 to double
  %r1502 = load double, ptr @test_json_warm_unique_keys_ts_.str.17.handle, align 8
  %r1503 = load double, ptr @test_json_warm_unique_keys_ts_.str.15.handle, align 8
  %r1505 = getelementptr double, ptr %r1504, i64 0
  store double %r1503, ptr %r1505, align 8
  %r1506 = getelementptr double, ptr %r1504, i64 1
  store double %r1501, ptr %r1506, align 8
  %r1507 = getelementptr double, ptr %r1504, i64 2
  store double %r1502, ptr %r1507, align 8
  %r1508 = ptrtoint ptr %r1504 to i64
  %statepoint_token184 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r1508, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated181, ptr addrspace(1) %r68.3.base.relocated182, ptr addrspace(1) %r68.3.relocated183) ]
  %r1509185 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token184)
  %rs4gc.s19.relocated186 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token184, i32 0, i32 0) ; (%rs4gc.s19.relocated181, %rs4gc.s19.relocated181)
  %r68.3.base.relocated187 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token184, i32 1, i32 1) ; (%r68.3.base.relocated182, %r68.3.base.relocated182)
  %r68.3.relocated188 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token184, i32 1, i32 2) ; (%r68.3.base.relocated182, %r68.3.relocated183)
  %r1510 = or i64 %r1509185, 9223090561878065152
  %r1511 = bitcast i64 %r1510 to double
  %r1512 = bitcast i64 %r1510 to double
  %r1513.rs4i = ptrtoint ptr addrspace(1) %r68.3.relocated188 to i64
  %r1513.rs4o = call i64 asm "", "=r,0"(i64 %r1513.rs4i) #7
  %r1513 = bitcast i64 %r1513.rs4o to double
  %r1514 = bitcast double %r1513 to i64
  %r1515 = and i64 %r1514, 281474976710655
  %r1516 = sub nsw i64 %r1515, 8
  %r1517 = inttoptr i64 %r1516 to ptr
  %r1518 = load i8, ptr %r1517, align 1
  %r1519 = icmp ne i8 %r1518, 1
  %r1520 = sub nsw i64 %r1515, 7
  %r1521 = inttoptr i64 %r1520 to ptr
  %r1522 = load i8, ptr %r1521, align 1
  %r1523 = and i8 %r1522, -128
  %r1524 = icmp ne i8 %r1523, 0
  %r1525 = or i1 %r1519, %r1524
  br i1 %r1524, label %apush.fwd.218, label %apush.elements.219

apush.fwd.218:                                    ; preds = %apush.elements.check.220, %if.merge.206
  %statepoint_token189 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1515, double %r1512, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated186) ]
  %r1552190 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token189)
  %rs4gc.s19.relocated191 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token189, i32 0, i32 0) ; (%rs4gc.s19.relocated186, %rs4gc.s19.relocated186)
  %r1553 = or i64 %r1552190, 9222527611924643840
  %r1554 = bitcast i64 %r1553 to double
  %rs4gc.b50 = bitcast double %r1554 to i64
  %rs4gc.s50 = inttoptr i64 %rs4gc.b50 to ptr addrspace(1)
  br label %apush.merge.224

apush.elements.219:                               ; preds = %if.merge.206
  %r1527 = add nuw nsw i64 %r1515, 8
  %r1528 = inttoptr i64 %r1527 to ptr
  %r1529 = load i64, ptr %r1528, align 8
  %r1530 = icmp ne i64 %r1529, 0
  %r1531 = icmp eq i8 %r1518, 2
  %r1532 = and i1 %r1531, %r1530
  %r1533 = select i1 %r1532, i64 %r1529, i64 %r1515
  %r1534 = inttoptr i64 %r1533 to ptr
  %r1535 = getelementptr i64, ptr %r1534, i64 12
  %r1536 = load i64, ptr %r1535, align 8
  %r1537 = icmp ne i64 %r1536, 0
  %r1538 = and i1 %r1532, %r1537
  %r1539 = select i1 %r1538, i64 %r1536, i64 %r1515
  %r1526 = icmp eq i8 %r1518, 1
  br i1 %r1526, label %apush.nofwd.221, label %apush.elements.check.220

apush.elements.check.220:                         ; preds = %apush.elements.219
  %r1540 = icmp ne i64 %r1539, 0
  %r1541 = sub i64 %r1539, 8
  %r1542 = inttoptr i64 %r1541 to ptr
  %r1543 = load i8, ptr %r1542, align 1
  %r1544 = icmp eq i8 %r1543, 1
  %r1545 = sub i64 %r1539, 7
  %r1546 = inttoptr i64 %r1545 to ptr
  %r1547 = load i8, ptr %r1546, align 1
  %r1548 = and i8 %r1547, -128
  %r1549 = icmp eq i8 %r1548, 0
  %r1550 = and i1 %r1540, %r1544
  %r1551 = and i1 %r1550, %r1549
  br i1 %r1551, label %apush.nofwd.221, label %apush.fwd.218

apush.nofwd.221:                                  ; preds = %apush.elements.check.220, %apush.elements.219
  %r1555 = phi i64 [ %r1515, %apush.elements.219 ], [ %r1539, %apush.elements.check.220 ]
  %r1556 = sub i64 %r1555, 6
  %r1557 = inttoptr i64 %r1556 to ptr
  %r1558 = load i16, ptr %r1557, align 2
  %r1559 = and i16 %r1558, 1031
  %r1560 = icmp eq i16 %r1559, 0
  %r1561 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1562 = icmp eq i8 %r1561, 0
  %r1563 = and i1 %r1560, %r1562
  %r1564 = icmp ult i64 %r1555, 4096
  %r1565 = inttoptr i64 %r1555 to ptr
  %r1566 = select i1 %r1564, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r1565
  %r1567 = load i32, ptr %r1566, align 4
  %r1568 = add i64 %r1555, 4
  %r1569 = inttoptr i64 %r1568 to ptr
  %r1570 = load i32, ptr %r1569, align 4
  %r1571 = icmp ult i32 %r1567, %r1570
  %r1572 = and i1 %r1571, %r1563
  br i1 %r1572, label %apush.inbounds.222, label %apush.realloc.223

apush.inbounds.222:                               ; preds = %apush.nofwd.221
  %r1573 = icmp ult i64 %r1555, 4096
  %r1574 = inttoptr i64 %r1555 to ptr
  %r1575 = select i1 %r1573, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r1574
  %r1576 = load i32, ptr %r1575, align 4
  %r1577 = zext i32 %r1576 to i64
  %r1578 = shl nuw nsw i64 %r1577, 3
  %r1579 = add nuw nsw i64 %r1578, 8
  %r1580 = add i64 %r1555, %r1579
  %r1581 = inttoptr i64 %r1580 to ptr
  store double %r1512, ptr %r1581, align 8
  %r1582 = lshr i64 %r1510, 48
  %r1584 = and i16 %r1558, -1920
  %r1585 = icmp eq i16 %r1584, -24576
  br label %apush.pointer_layout.bookkeeping.225

apush.realloc.223:                                ; preds = %apush.nofwd.221
  %statepoint_token192 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1515, double %r1512, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated186) ]
  %r1597193 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token192)
  %rs4gc.s19.relocated194 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token192, i32 0, i32 0) ; (%rs4gc.s19.relocated186, %rs4gc.s19.relocated186)
  %r1598 = or i64 %r1597193, 9222527611924643840
  %r1599 = bitcast i64 %r1598 to double
  %rs4gc.b51 = bitcast double %r1599 to i64
  %rs4gc.s51 = inttoptr i64 %rs4gc.b51 to ptr addrspace(1)
  br label %apush.merge.224

apush.merge.224:                                  ; preds = %apush.barrier.done.228, %apush.realloc.223, %apush.fwd.218
  %.14 = phi ptr addrspace(1) [ %rs4gc.s19.relocated191, %apush.fwd.218 ], [ %rs4gc.s19.relocated186, %apush.barrier.done.228 ], [ %rs4gc.s19.relocated194, %apush.realloc.223 ]
  %r68.4.base = phi ptr addrspace(1) [ %rs4gc.s50, %apush.fwd.218 ], [ %r68.3.base.relocated187, %apush.barrier.done.228 ], [ %rs4gc.s51, %apush.realloc.223 ], !is_base_value !0
  %r68.4 = phi ptr addrspace(1) [ %rs4gc.s50, %apush.fwd.218 ], [ %r68.3.relocated188, %apush.barrier.done.228 ], [ %rs4gc.s51, %apush.realloc.223 ]
  %r1600 = load double, ptr @test_json_warm_unique_keys_ts_.str.8.handle, align 8
  %r1601 = bitcast double %r1600 to i64
  %r1602.rs4i = ptrtoint ptr addrspace(1) %r68.4 to i64
  %r1602.rs4o = call i64 asm "", "=r,0"(i64 %r1602.rs4i) #7
  %r1602 = bitcast i64 %r1602.rs4o to double
  %r1603 = bitcast double %r1602 to i64
  %r1604 = and i64 %r1603, 281474976710655
  %r1605 = sub nsw i64 %r1604, 8
  %r1606 = inttoptr i64 %r1605 to ptr
  %r1607 = load i8, ptr %r1606, align 1
  %r1608 = icmp ne i8 %r1607, 1
  %r1609 = sub nsw i64 %r1604, 7
  %r1610 = inttoptr i64 %r1609 to ptr
  %r1611 = load i8, ptr %r1610, align 1
  %r1612 = and i8 %r1611, -128
  %r1613 = icmp ne i8 %r1612, 0
  %r1614 = or i1 %r1608, %r1613
  br i1 %r1613, label %apush.fwd.229, label %apush.elements.230

apush.pointer_layout.bookkeeping.225:             ; preds = %apush.inbounds.222
  call void @js_string_addref_if_heap_string(double %r1512) #7
  call void @js_gc_note_slot_layout(i64 %r1555, i32 %r1576, i64 %r1510) #7
  call void @js_array_note_numeric_write(i64 %r1555, i64 %r1510) #7
  br label %apush.pointer_layout.done.226

apush.pointer_layout.done.226:                    ; preds = %apush.pointer_layout.bookkeeping.225
  %r1587 = sub i64 %r1555, 7
  %r1588 = inttoptr i64 %r1587 to ptr
  %r1589 = load i8, ptr %r1588, align 1
  %r1590 = and i8 %r1589, 32
  %r1591 = icmp ne i8 %r1590, 0
  %r1592 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1593 = icmp ne i32 %r1592, 0
  %r1594 = or i1 %r1591, %r1593
  br i1 %r1594, label %apush.barrier.227, label %apush.barrier.done.228

apush.barrier.227:                                ; preds = %apush.pointer_layout.done.226
  call void @js_write_barrier_slot_validated_parent(i64 %r1555, i64 %r1580, i64 %r1510) #7
  br label %apush.barrier.done.228

apush.barrier.done.228:                           ; preds = %apush.barrier.227, %apush.pointer_layout.done.226
  %r1595 = add i32 %r1576, 1
  %r1596 = inttoptr i64 %r1555 to ptr
  store i32 %r1595, ptr %r1596, align 4
  br label %apush.merge.224

apush.fwd.229:                                    ; preds = %apush.elements.check.231, %apush.merge.224
  %statepoint_token195 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1604, double %r1600, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.14) ]
  %r1641196 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token195)
  %rs4gc.s19.relocated197 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token195, i32 0, i32 0) ; (%.14, %.14)
  %r1642 = or i64 %r1641196, 9222527611924643840
  %r1643 = bitcast i64 %r1642 to double
  %rs4gc.b52 = bitcast double %r1643 to i64
  %rs4gc.s52 = inttoptr i64 %rs4gc.b52 to ptr addrspace(1)
  br label %apush.merge.235

apush.elements.230:                               ; preds = %apush.merge.224
  %r1616 = add nuw nsw i64 %r1604, 8
  %r1617 = inttoptr i64 %r1616 to ptr
  %r1618 = load i64, ptr %r1617, align 8
  %r1619 = icmp ne i64 %r1618, 0
  %r1620 = icmp eq i8 %r1607, 2
  %r1621 = and i1 %r1620, %r1619
  %r1622 = select i1 %r1621, i64 %r1618, i64 %r1604
  %r1623 = inttoptr i64 %r1622 to ptr
  %r1624 = getelementptr i64, ptr %r1623, i64 12
  %r1625 = load i64, ptr %r1624, align 8
  %r1626 = icmp ne i64 %r1625, 0
  %r1627 = and i1 %r1621, %r1626
  %r1628 = select i1 %r1627, i64 %r1625, i64 %r1604
  %r1615 = icmp eq i8 %r1607, 1
  br i1 %r1615, label %apush.nofwd.232, label %apush.elements.check.231

apush.elements.check.231:                         ; preds = %apush.elements.230
  %r1629 = icmp ne i64 %r1628, 0
  %r1630 = sub i64 %r1628, 8
  %r1631 = inttoptr i64 %r1630 to ptr
  %r1632 = load i8, ptr %r1631, align 1
  %r1633 = icmp eq i8 %r1632, 1
  %r1634 = sub i64 %r1628, 7
  %r1635 = inttoptr i64 %r1634 to ptr
  %r1636 = load i8, ptr %r1635, align 1
  %r1637 = and i8 %r1636, -128
  %r1638 = icmp eq i8 %r1637, 0
  %r1639 = and i1 %r1629, %r1633
  %r1640 = and i1 %r1639, %r1638
  br i1 %r1640, label %apush.nofwd.232, label %apush.fwd.229

apush.nofwd.232:                                  ; preds = %apush.elements.check.231, %apush.elements.230
  %r1644 = phi i64 [ %r1604, %apush.elements.230 ], [ %r1628, %apush.elements.check.231 ]
  %r1645 = sub i64 %r1644, 6
  %r1646 = inttoptr i64 %r1645 to ptr
  %r1647 = load i16, ptr %r1646, align 2
  %r1648 = and i16 %r1647, 1031
  %r1649 = icmp eq i16 %r1648, 0
  %r1650 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1651 = icmp eq i8 %r1650, 0
  %r1652 = and i1 %r1649, %r1651
  %r1653 = icmp ult i64 %r1644, 4096
  %r1654 = inttoptr i64 %r1644 to ptr
  %r1655 = select i1 %r1653, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r1654
  %r1656 = load i32, ptr %r1655, align 4
  %r1657 = add i64 %r1644, 4
  %r1658 = inttoptr i64 %r1657 to ptr
  %r1659 = load i32, ptr %r1658, align 4
  %r1660 = icmp ult i32 %r1656, %r1659
  %r1661 = and i1 %r1660, %r1652
  br i1 %r1661, label %apush.inbounds.233, label %apush.realloc.234

apush.inbounds.233:                               ; preds = %apush.nofwd.232
  %r1662 = icmp ult i64 %r1644, 4096
  %r1663 = inttoptr i64 %r1644 to ptr
  %r1664 = select i1 %r1662, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r1663
  %r1665 = load i32, ptr %r1664, align 4
  %r1666 = zext i32 %r1665 to i64
  %r1667 = shl nuw nsw i64 %r1666, 3
  %r1668 = add nuw nsw i64 %r1667, 8
  %r1669 = add i64 %r1644, %r1668
  %r1670 = inttoptr i64 %r1669 to ptr
  store double %r1600, ptr %r1670, align 8
  %r1671 = lshr i64 %r1601, 48
  %r1672 = icmp eq i64 %r1671, 32765
  %r1673 = and i16 %r1647, -1920
  %r1674 = icmp eq i16 %r1673, -24576
  %r1675 = and i1 %r1672, %r1674
  br i1 %r1675, label %apush.pointer_layout.done.237, label %apush.pointer_layout.bookkeeping.236

apush.realloc.234:                                ; preds = %apush.nofwd.232
  %statepoint_token198 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1604, double %r1600, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.14) ]
  %r1686199 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token198)
  %rs4gc.s19.relocated200 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token198, i32 0, i32 0) ; (%.14, %.14)
  %r1687 = or i64 %r1686199, 9222527611924643840
  %r1688 = bitcast i64 %r1687 to double
  %rs4gc.b53 = bitcast double %r1688 to i64
  %rs4gc.s53 = inttoptr i64 %rs4gc.b53 to ptr addrspace(1)
  br label %apush.merge.235

apush.merge.235:                                  ; preds = %apush.barrier.done.239, %apush.realloc.234, %apush.fwd.229
  %.15 = phi ptr addrspace(1) [ %rs4gc.s19.relocated197, %apush.fwd.229 ], [ %.14, %apush.barrier.done.239 ], [ %rs4gc.s19.relocated200, %apush.realloc.234 ]
  %r68.5.base = phi ptr addrspace(1) [ %rs4gc.s52, %apush.fwd.229 ], [ %r68.4.base, %apush.barrier.done.239 ], [ %rs4gc.s53, %apush.realloc.234 ], !is_base_value !0
  %r68.5 = phi ptr addrspace(1) [ %rs4gc.s52, %apush.fwd.229 ], [ %r68.4, %apush.barrier.done.239 ], [ %rs4gc.s53, %apush.realloc.234 ]
  %statepoint_token201 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.15, ptr addrspace(1) %r68.5.base, ptr addrspace(1) %r68.5) ]
  %r1690202 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token201)
  %rs4gc.s19.relocated203 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token201, i32 0, i32 0) ; (%.15, %.15)
  %r68.5.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token201, i32 1, i32 1) ; (%r68.5.base, %r68.5.base)
  %r68.5.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token201, i32 1, i32 2) ; (%r68.5.base, %r68.5)
  %r1691 = or i64 %r1690202, 9222527611924643840
  %r1692 = bitcast i64 %r1691 to double
  %rs4gc.b54 = bitcast double %r1692 to i64
  %rs4gc.s54 = inttoptr i64 %rs4gc.b54 to ptr addrspace(1)
  %r1693.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s54 to i64
  %r1693 = call i64 asm "", "=r,0"(i64 %r1693.rs4i) #7
  %r1694 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1695 = icmp ne i32 %r1694, 0
  br i1 %r1695, label %shadow.root.barrier.240, label %shadow.root.barrier.done.241

apush.pointer_layout.bookkeeping.236:             ; preds = %apush.inbounds.233
  call void @js_string_addref_if_heap_string(double %r1600) #7
  %r5822 = load double, ptr @test_json_warm_unique_keys_ts_.str.8.handle, align 8
  %r5823 = bitcast double %r5822 to i64
  call void @js_gc_note_slot_layout(i64 %r1644, i32 %r1665, i64 %r5823) #7
  %r5820 = load double, ptr @test_json_warm_unique_keys_ts_.str.8.handle, align 8
  %r5821 = bitcast double %r5820 to i64
  call void @js_array_note_numeric_write(i64 %r1644, i64 %r5821) #7
  br label %apush.pointer_layout.done.237

apush.pointer_layout.done.237:                    ; preds = %apush.pointer_layout.bookkeeping.236, %apush.inbounds.233
  %r1676 = sub i64 %r1644, 7
  %r1677 = inttoptr i64 %r1676 to ptr
  %r1678 = load i8, ptr %r1677, align 1
  %r1679 = and i8 %r1678, 32
  %r1680 = icmp ne i8 %r1679, 0
  %r1681 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1682 = icmp ne i32 %r1681, 0
  %r1683 = or i1 %r1680, %r1682
  br i1 %r1683, label %apush.barrier.238, label %apush.barrier.done.239

apush.barrier.238:                                ; preds = %apush.pointer_layout.done.237
  %r5818 = load double, ptr @test_json_warm_unique_keys_ts_.str.8.handle, align 8
  %r5819 = bitcast double %r5818 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r1644, i64 %r1669, i64 %r5819) #7
  br label %apush.barrier.done.239

apush.barrier.done.239:                           ; preds = %apush.barrier.238, %apush.pointer_layout.done.237
  %r1684 = add i32 %r1665, 1
  %r1685 = inttoptr i64 %r1644 to ptr
  store i32 %r1684, ptr %r1685, align 4
  br label %apush.merge.235

shadow.root.barrier.240:                          ; preds = %apush.merge.235
  call void @js_write_barrier_root_nanbox(i64 %r1693) #7
  br label %shadow.root.barrier.done.241

shadow.root.barrier.done.241:                     ; preds = %shadow.root.barrier.240, %apush.merge.235
  br label %for.cond.242

for.cond.242:                                     ; preds = %for.update.244, %shadow.root.barrier.done.241
  %.0935 = phi ptr addrspace(1) [ %r68.5.relocated, %shadow.root.barrier.done.241 ], [ %.3938, %for.update.244 ]
  %.0930 = phi ptr addrspace(1) [ %r68.5.base.relocated, %shadow.root.barrier.done.241 ], [ %.3933, %for.update.244 ]
  %.16 = phi ptr addrspace(1) [ %rs4gc.s19.relocated203, %shadow.root.barrier.done.241 ], [ %.19, %for.update.244 ]
  %r1696.0 = phi i32 [ 0, %shadow.root.barrier.done.241 ], [ %r1882, %for.update.244 ]
  %r1689.0.base = phi ptr addrspace(1) [ %rs4gc.s54, %shadow.root.barrier.done.241 ], [ %.0942, %for.update.244 ], !is_base_value !0
  %r1689.0 = phi ptr addrspace(1) [ %rs4gc.s54, %shadow.root.barrier.done.241 ], [ %.0943, %for.update.244 ]
  %r1701 = icmp slt i32 %r1696.0, %r75.0
  br i1 %r1701, label %for.body.243, label %for.exit.245

for.body.243:                                     ; preds = %for.cond.242
  %r1702 = load double, ptr @test_json_warm_unique_keys_ts_.str.9.handle, align 8
  %r1703.rs4i = ptrtoint ptr addrspace(1) %.16 to i64
  %r1703.rs4o = call i64 asm "", "=r,0"(i64 %r1703.rs4i) #7
  %r1703 = bitcast i64 %r1703.rs4o to double
  %r1705 = bitcast double %r1703 to i64
  %r1706 = and i64 %r1705, 281474976710655
  %r1707 = lshr i64 %r1705, 48
  %r1708 = icmp eq i64 %r1707, 32765
  %r1709 = icmp ugt i64 %r1706, 1048575
  %r1710 = and i1 %r1708, %r1709
  br i1 %r1710, label %arr.guard.deref.250, label %arr.fallback.247

for.update.244:                                   ; preds = %gcpoll.done.265
  %r1882 = add i32 %r1696.0, 1
  %r1883 = sitofp i32 %r1696.0 to double
  %r1884 = sitofp i32 %r1882 to double
  br label %for.cond.242

for.exit.245:                                     ; preds = %for.cond.242
  br label %if.else.267

arr.fast.246:                                     ; preds = %arr.guard.range.252
  %r1766 = zext i32 %r1696.0 to i64
  %r1767 = shl nuw nsw i64 %r1766, 3
  %r1768 = add nuw nsw i64 %r1767, 8
  %r1769 = add i64 %r1725, %r1768
  %r1770 = inttoptr i64 %r1769 to ptr
  %r1771 = load double, ptr %r1770, align 8
  %r1772 = bitcast double %r1771 to i64
  %r1773 = icmp eq i64 %r1772, 9222246136947933200
  %r1775 = select i1 %r1773, double 0x7FFC000000000001, double %r1771
  br label %arr.merge.249

arr.fallback.247:                                 ; preds = %arr.guard.live.251, %arr.guard.deref.250, %for.body.243
  %r1764 = sitofp i32 %r1696.0 to double
  %statepoint_token204 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 547434508618563586, double %r1703, double %r1764, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1689.0, ptr addrspace(1) %r1689.0.base, ptr addrspace(1) %.16, ptr addrspace(1) %.0930, ptr addrspace(1) %.0935) ]
  %r1765205 = call double @llvm.experimental.gc.result.f64(token %statepoint_token204)
  %r1689.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token204, i32 1, i32 0) ; (%r1689.0.base, %r1689.0)
  %r1689.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token204, i32 1, i32 1) ; (%r1689.0.base, %r1689.0.base)
  %rs4gc.s19.relocated206 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token204, i32 2, i32 2) ; (%.16, %.16)
  %r68.5.base.relocated207 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token204, i32 3, i32 3) ; (%.0930, %.0930)
  %r68.5.relocated208 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token204, i32 3, i32 4) ; (%.0930, %.0935)
  br label %arr.merge.249

arr.guard.oob.248:                                ; preds = %arr.guard.range.252
  br label %arr.merge.249

arr.merge.249:                                    ; preds = %arr.guard.oob.248, %arr.fallback.247, %arr.fast.246
  %.0941 = phi ptr addrspace(1) [ %r1689.0.base, %arr.fast.246 ], [ %r1689.0.base, %arr.guard.oob.248 ], [ %r1689.0.base.relocated, %arr.fallback.247 ]
  %.0940 = phi ptr addrspace(1) [ %r1689.0, %arr.fast.246 ], [ %r1689.0, %arr.guard.oob.248 ], [ %r1689.0.relocated, %arr.fallback.247 ]
  %.1936 = phi ptr addrspace(1) [ %.0935, %arr.fast.246 ], [ %.0935, %arr.guard.oob.248 ], [ %r68.5.relocated208, %arr.fallback.247 ]
  %.1931 = phi ptr addrspace(1) [ %.0930, %arr.fast.246 ], [ %.0930, %arr.guard.oob.248 ], [ %r68.5.base.relocated207, %arr.fallback.247 ]
  %.17 = phi ptr addrspace(1) [ %.16, %arr.fast.246 ], [ %.16, %arr.guard.oob.248 ], [ %rs4gc.s19.relocated206, %arr.fallback.247 ]
  %r1776 = phi double [ %r1775, %arr.fast.246 ], [ %r1765205, %arr.fallback.247 ], [ 0x7FFC000000000001, %arr.guard.oob.248 ]
  %r1777 = load double, ptr @test_json_warm_unique_keys_ts_.str.10.handle, align 8
  %r1778 = load double, ptr @test_json_warm_unique_keys_ts_.str.9.handle, align 8
  %r1780 = getelementptr double, ptr %r1779, i64 0
  store double %r1778, ptr %r1780, align 8
  %r1781 = getelementptr double, ptr %r1779, i64 1
  store double %r1776, ptr %r1781, align 8
  %r1782 = getelementptr double, ptr %r1779, i64 2
  store double %r1777, ptr %r1782, align 8
  %r1783 = ptrtoint ptr %r1779 to i64
  %statepoint_token209 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r1783, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.17, ptr addrspace(1) %.1931, ptr addrspace(1) %.0941, ptr addrspace(1) %.0940, ptr addrspace(1) %.1936) ]
  %r1784210 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token209)
  %rs4gc.s19.relocated211 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token209, i32 0, i32 0) ; (%.17, %.17)
  %r68.5.base.relocated212 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token209, i32 1, i32 1) ; (%.1931, %.1931)
  %r1689.0.base.relocated213 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token209, i32 2, i32 2) ; (%.0941, %.0941)
  %r1689.0.relocated214 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token209, i32 2, i32 3) ; (%.0941, %.0940)
  %r68.5.relocated215 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token209, i32 1, i32 4) ; (%.1931, %.1936)
  %r1785 = or i64 %r1784210, 9223090561878065152
  %r1786 = bitcast i64 %r1785 to double
  %r1788 = sitofp i32 %r1696.0 to double
  %statepoint_token216 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r1786, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated211, ptr addrspace(1) %r68.5.base.relocated212, ptr addrspace(1) %r1689.0.base.relocated213, ptr addrspace(1) %r1689.0.relocated214, ptr addrspace(1) %r68.5.relocated215) ]
  %r1789217 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token216)
  %rs4gc.s19.relocated218 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token216, i32 0, i32 0) ; (%rs4gc.s19.relocated211, %rs4gc.s19.relocated211)
  %r68.5.base.relocated219 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token216, i32 1, i32 1) ; (%r68.5.base.relocated212, %r68.5.base.relocated212)
  %r1689.0.base.relocated220 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token216, i32 2, i32 2) ; (%r1689.0.base.relocated213, %r1689.0.base.relocated213)
  %r1689.0.relocated221 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token216, i32 2, i32 3) ; (%r1689.0.base.relocated213, %r1689.0.relocated214)
  %r68.5.relocated222 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token216, i32 1, i32 4) ; (%r68.5.base.relocated212, %r68.5.relocated215)
  %statepoint_token223 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r1789217, double %r1788, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated218, ptr addrspace(1) %r68.5.base.relocated219, ptr addrspace(1) %r1689.0.base.relocated220, ptr addrspace(1) %r1689.0.relocated221, ptr addrspace(1) %r68.5.relocated222) ]
  %r1790224 = call double @llvm.experimental.gc.result.f64(token %statepoint_token223)
  %rs4gc.s19.relocated225 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token223, i32 0, i32 0) ; (%rs4gc.s19.relocated218, %rs4gc.s19.relocated218)
  %r68.5.base.relocated226 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token223, i32 1, i32 1) ; (%r68.5.base.relocated219, %r68.5.base.relocated219)
  %r1689.0.base.relocated227 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token223, i32 2, i32 2) ; (%r1689.0.base.relocated220, %r1689.0.base.relocated220)
  %r1689.0.relocated228 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token223, i32 2, i32 3) ; (%r1689.0.base.relocated220, %r1689.0.relocated221)
  %r68.5.relocated229 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token223, i32 1, i32 4) ; (%r68.5.base.relocated219, %r68.5.relocated222)
  %r1791 = bitcast double %r1790224 to i64
  %r1792.rs4i = ptrtoint ptr addrspace(1) %r1689.0.relocated228 to i64
  %r1792.rs4o = call i64 asm "", "=r,0"(i64 %r1792.rs4i) #7
  %r1792 = bitcast i64 %r1792.rs4o to double
  %r1793 = bitcast double %r1792 to i64
  %r1794 = and i64 %r1793, 281474976710655
  %r1795 = sub nsw i64 %r1794, 8
  %r1796 = inttoptr i64 %r1795 to ptr
  %r1797 = load i8, ptr %r1796, align 1
  %r1798 = icmp ne i8 %r1797, 1
  %r1799 = sub nsw i64 %r1794, 7
  %r1800 = inttoptr i64 %r1799 to ptr
  %r1801 = load i8, ptr %r1800, align 1
  %r1802 = and i8 %r1801, -128
  %r1803 = icmp ne i8 %r1802, 0
  %r1804 = or i1 %r1798, %r1803
  br i1 %r1803, label %apush.fwd.253, label %apush.elements.254

arr.guard.deref.250:                              ; preds = %for.body.243
  %r1711 = bitcast double %r1703 to i64
  %r1712 = and i64 %r1711, 281474976710655
  %r1713 = sub nsw i64 %r1712, 8
  %r1714 = inttoptr i64 %r1713 to ptr
  %r1715 = load i8, ptr %r1714, align 1
  %r1716 = icmp eq i8 %r1715, 1
  %r1717 = sub nsw i64 %r1712, 7
  %r1718 = inttoptr i64 %r1717 to ptr
  %r1719 = load i8, ptr %r1718, align 1
  %r1720 = and i8 %r1719, -128
  %r1721 = icmp ne i8 %r1720, 0
  %r1722 = inttoptr i64 %r1712 to ptr
  %r1723 = load i64, ptr %r1722, align 8
  %r1724 = and i1 %r1716, %r1721
  %r1725 = select i1 %r1724, i64 %r1723, i64 %r1712
  %r1726 = lshr i64 %r1725, 48
  %r1727 = icmp eq i64 %r1726, 0
  %r1728 = icmp ugt i64 %r1725, 1048575
  %r1729 = and i1 %r1727, %r1728
  br i1 %r1729, label %arr.guard.live.251, label %arr.fallback.247

arr.guard.live.251:                               ; preds = %arr.guard.deref.250
  %r1730 = sub nuw i64 %r1725, 8
  %r1731 = inttoptr i64 %r1730 to ptr
  %r1732 = load i8, ptr %r1731, align 1
  %r1733 = icmp eq i8 %r1732, 1
  %r1734 = sub nuw i64 %r1725, 7
  %r1735 = inttoptr i64 %r1734 to ptr
  %r1736 = load i8, ptr %r1735, align 1
  %r1737 = and i8 %r1736, -128
  %r1738 = icmp eq i8 %r1737, 0
  %r1739 = sub nuw i64 %r1725, 6
  %r1740 = inttoptr i64 %r1739 to ptr
  %r1741 = load i16, ptr %r1740, align 2
  %r1742 = and i16 %r1741, 1024
  %r1743 = icmp eq i16 %r1742, 0
  %r1744 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1745 = icmp eq i8 %r1744, 0
  %r1746 = inttoptr i64 %r1725 to ptr
  %r1747 = load i32, ptr %r1746, align 4
  %r1748 = getelementptr i8, ptr %r1746, i64 4
  %r1749 = load i32, ptr %r1748, align 4
  %r1750 = icmp slt i32 %r1696.0, 0
  %r1751 = icmp eq i1 %r1750, false
  %r1753 = icmp ule i32 %r1747, 16000000
  %r1754 = icmp ule i32 %r1749, 16000000
  %r1755 = icmp ule i32 %r1747, %r1749
  %r1756 = and i1 %r1733, %r1738
  %r1757 = and i1 %r1756, %r1743
  %r1758 = and i1 %r1757, %r1745
  %r1759 = and i1 %r1758, %r1751
  %r1760 = and i1 %r1759, %r1753
  %r1761 = and i1 %r1760, %r1754
  %r1762 = and i1 %r1761, %r1755
  br i1 %r1762, label %arr.guard.range.252, label %arr.fallback.247

arr.guard.range.252:                              ; preds = %arr.guard.live.251
  %r1752 = icmp ult i32 %r1696.0, %r1747
  br i1 %r1752, label %arr.fast.246, label %arr.guard.oob.248

apush.fwd.253:                                    ; preds = %apush.elements.check.255, %arr.merge.249
  %statepoint_token230 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1794, double %r1790224, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated225, ptr addrspace(1) %r68.5.base.relocated226, ptr addrspace(1) %r68.5.relocated229) ]
  %r1831231 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token230)
  %rs4gc.s19.relocated232 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token230, i32 0, i32 0) ; (%rs4gc.s19.relocated225, %rs4gc.s19.relocated225)
  %r68.5.base.relocated233 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token230, i32 1, i32 1) ; (%r68.5.base.relocated226, %r68.5.base.relocated226)
  %r68.5.relocated234 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token230, i32 1, i32 2) ; (%r68.5.base.relocated226, %r68.5.relocated229)
  %r1832 = or i64 %r1831231, 9222527611924643840
  %r1833 = bitcast i64 %r1832 to double
  %rs4gc.b55 = bitcast double %r1833 to i64
  %rs4gc.s55 = inttoptr i64 %rs4gc.b55 to ptr addrspace(1)
  br label %apush.merge.259

apush.elements.254:                               ; preds = %arr.merge.249
  %r1806 = add nuw nsw i64 %r1794, 8
  %r1807 = inttoptr i64 %r1806 to ptr
  %r1808 = load i64, ptr %r1807, align 8
  %r1809 = icmp ne i64 %r1808, 0
  %r1810 = icmp eq i8 %r1797, 2
  %r1811 = and i1 %r1810, %r1809
  %r1812 = select i1 %r1811, i64 %r1808, i64 %r1794
  %r1813 = inttoptr i64 %r1812 to ptr
  %r1814 = getelementptr i64, ptr %r1813, i64 12
  %r1815 = load i64, ptr %r1814, align 8
  %r1816 = icmp ne i64 %r1815, 0
  %r1817 = and i1 %r1811, %r1816
  %r1818 = select i1 %r1817, i64 %r1815, i64 %r1794
  %r1805 = icmp eq i8 %r1797, 1
  br i1 %r1805, label %apush.nofwd.256, label %apush.elements.check.255

apush.elements.check.255:                         ; preds = %apush.elements.254
  %r1819 = icmp ne i64 %r1818, 0
  %r1820 = sub i64 %r1818, 8
  %r1821 = inttoptr i64 %r1820 to ptr
  %r1822 = load i8, ptr %r1821, align 1
  %r1823 = icmp eq i8 %r1822, 1
  %r1824 = sub i64 %r1818, 7
  %r1825 = inttoptr i64 %r1824 to ptr
  %r1826 = load i8, ptr %r1825, align 1
  %r1827 = and i8 %r1826, -128
  %r1828 = icmp eq i8 %r1827, 0
  %r1829 = and i1 %r1819, %r1823
  %r1830 = and i1 %r1829, %r1828
  br i1 %r1830, label %apush.nofwd.256, label %apush.fwd.253

apush.nofwd.256:                                  ; preds = %apush.elements.check.255, %apush.elements.254
  %r1834 = phi i64 [ %r1794, %apush.elements.254 ], [ %r1818, %apush.elements.check.255 ]
  %r1835 = sub i64 %r1834, 6
  %r1836 = inttoptr i64 %r1835 to ptr
  %r1837 = load i16, ptr %r1836, align 2
  %r1838 = and i16 %r1837, 1031
  %r1839 = icmp eq i16 %r1838, 0
  %r1840 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1841 = icmp eq i8 %r1840, 0
  %r1842 = and i1 %r1839, %r1841
  %r1843 = icmp ult i64 %r1834, 4096
  %r1844 = inttoptr i64 %r1834 to ptr
  %r1845 = select i1 %r1843, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r1844
  %r1846 = load i32, ptr %r1845, align 4
  %r1847 = add i64 %r1834, 4
  %r1848 = inttoptr i64 %r1847 to ptr
  %r1849 = load i32, ptr %r1848, align 4
  %r1850 = icmp ult i32 %r1846, %r1849
  %r1851 = and i1 %r1850, %r1842
  br i1 %r1851, label %apush.inbounds.257, label %apush.realloc.258

apush.inbounds.257:                               ; preds = %apush.nofwd.256
  %r1852 = icmp ult i64 %r1834, 4096
  %r1853 = inttoptr i64 %r1834 to ptr
  %r1854 = select i1 %r1852, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r1853
  %r1855 = load i32, ptr %r1854, align 4
  %r1856 = zext i32 %r1855 to i64
  %r1857 = shl nuw nsw i64 %r1856, 3
  %r1858 = add nuw nsw i64 %r1857, 8
  %r1859 = add i64 %r1834, %r1858
  %r1860 = inttoptr i64 %r1859 to ptr
  store double %r1790224, ptr %r1860, align 8
  %r1861 = lshr i64 %r1791, 48
  %r1862 = icmp eq i64 %r1861, 32765
  %r1863 = and i16 %r1837, -1920
  %r1864 = icmp eq i16 %r1863, -24576
  %r1865 = and i1 %r1862, %r1864
  br i1 %r1865, label %apush.pointer_layout.done.261, label %apush.pointer_layout.bookkeeping.260

apush.realloc.258:                                ; preds = %apush.nofwd.256
  %statepoint_token235 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1794, double %r1790224, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated225, ptr addrspace(1) %r68.5.base.relocated226, ptr addrspace(1) %r68.5.relocated229) ]
  %r1876236 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token235)
  %rs4gc.s19.relocated237 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 0, i32 0) ; (%rs4gc.s19.relocated225, %rs4gc.s19.relocated225)
  %r68.5.base.relocated238 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 1, i32 1) ; (%r68.5.base.relocated226, %r68.5.base.relocated226)
  %r68.5.relocated239 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 1, i32 2) ; (%r68.5.base.relocated226, %r68.5.relocated229)
  %r1877 = or i64 %r1876236, 9222527611924643840
  %r1878 = bitcast i64 %r1877 to double
  %rs4gc.b56 = bitcast double %r1878 to i64
  %rs4gc.s56 = inttoptr i64 %rs4gc.b56 to ptr addrspace(1)
  br label %apush.merge.259

apush.merge.259:                                  ; preds = %apush.barrier.done.263, %apush.realloc.258, %apush.fwd.253
  %.2937 = phi ptr addrspace(1) [ %r68.5.relocated234, %apush.fwd.253 ], [ %r68.5.relocated229, %apush.barrier.done.263 ], [ %r68.5.relocated239, %apush.realloc.258 ]
  %.2932 = phi ptr addrspace(1) [ %r68.5.base.relocated233, %apush.fwd.253 ], [ %r68.5.base.relocated226, %apush.barrier.done.263 ], [ %r68.5.base.relocated238, %apush.realloc.258 ]
  %.18 = phi ptr addrspace(1) [ %rs4gc.s19.relocated232, %apush.fwd.253 ], [ %rs4gc.s19.relocated225, %apush.barrier.done.263 ], [ %rs4gc.s19.relocated237, %apush.realloc.258 ]
  %r1689.1.base = phi ptr addrspace(1) [ %rs4gc.s55, %apush.fwd.253 ], [ %r1689.0.base.relocated227, %apush.barrier.done.263 ], [ %rs4gc.s56, %apush.realloc.258 ], !is_base_value !0
  %r1689.1 = phi ptr addrspace(1) [ %rs4gc.s55, %apush.fwd.253 ], [ %r1689.0.relocated228, %apush.barrier.done.263 ], [ %rs4gc.s56, %apush.realloc.258 ]
  %r1879 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1880 = icmp ne i32 %r1879, 0
  br i1 %r1880, label %gcpoll.264, label %gcpoll.done.265

apush.pointer_layout.bookkeeping.260:             ; preds = %apush.inbounds.257
  call void @js_string_addref_if_heap_string(double %r1790224) #7
  call void @js_gc_note_slot_layout(i64 %r1834, i32 %r1855, i64 %r1791) #7
  call void @js_array_note_numeric_write(i64 %r1834, i64 %r1791) #7
  br label %apush.pointer_layout.done.261

apush.pointer_layout.done.261:                    ; preds = %apush.pointer_layout.bookkeeping.260, %apush.inbounds.257
  %r1866 = sub i64 %r1834, 7
  %r1867 = inttoptr i64 %r1866 to ptr
  %r1868 = load i8, ptr %r1867, align 1
  %r1869 = and i8 %r1868, 32
  %r1870 = icmp ne i8 %r1869, 0
  %r1871 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1872 = icmp ne i32 %r1871, 0
  %r1873 = or i1 %r1870, %r1872
  br i1 %r1873, label %apush.barrier.262, label %apush.barrier.done.263

apush.barrier.262:                                ; preds = %apush.pointer_layout.done.261
  call void @js_write_barrier_slot_validated_parent(i64 %r1834, i64 %r1859, i64 %r1791) #7
  br label %apush.barrier.done.263

apush.barrier.done.263:                           ; preds = %apush.barrier.262, %apush.pointer_layout.done.261
  %r1874 = add i32 %r1855, 1
  %r1875 = inttoptr i64 %r1834 to ptr
  store i32 %r1874, ptr %r1875, align 4
  br label %apush.merge.259

gcpoll.264:                                       ; preds = %apush.merge.259
  %statepoint_token240 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1689.1.base, ptr addrspace(1) %r1689.1, ptr addrspace(1) %.18, ptr addrspace(1) %.2932, ptr addrspace(1) %.2937) ]
  %r1689.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token240, i32 0, i32 0) ; (%r1689.1.base, %r1689.1.base)
  %r1689.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token240, i32 0, i32 1) ; (%r1689.1.base, %r1689.1)
  %rs4gc.s19.relocated241 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token240, i32 2, i32 2) ; (%.18, %.18)
  %r68.5.base.relocated242 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token240, i32 3, i32 3) ; (%.2932, %.2932)
  %r68.5.relocated243 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token240, i32 3, i32 4) ; (%.2932, %.2937)
  br label %gcpoll.done.265

gcpoll.done.265:                                  ; preds = %gcpoll.264, %apush.merge.259
  %.0943 = phi ptr addrspace(1) [ %r1689.1.relocated, %gcpoll.264 ], [ %r1689.1, %apush.merge.259 ]
  %.0942 = phi ptr addrspace(1) [ %r1689.1.base.relocated, %gcpoll.264 ], [ %r1689.1.base, %apush.merge.259 ]
  %.3938 = phi ptr addrspace(1) [ %r68.5.relocated243, %gcpoll.264 ], [ %.2937, %apush.merge.259 ]
  %.3933 = phi ptr addrspace(1) [ %r68.5.base.relocated242, %gcpoll.264 ], [ %.2932, %apush.merge.259 ]
  %.19 = phi ptr addrspace(1) [ %rs4gc.s19.relocated241, %gcpoll.264 ], [ %.18, %apush.merge.259 ]
  br label %for.update.244

if.else.267:                                      ; preds = %for.exit.245
  br label %if.merge.268

if.merge.268:                                     ; preds = %if.else.267
  br label %if.else.281

if.else.281:                                      ; preds = %if.merge.268
  br label %if.merge.282

if.merge.282:                                     ; preds = %if.else.281
  br label %if.then.294

if.then.294:                                      ; preds = %if.merge.282
  %r2072 = load double, ptr @test_json_warm_unique_keys_ts_.str.13.handle, align 8
  %r2073 = bitcast double %r2072 to i64
  %r2074.rs4i = ptrtoint ptr addrspace(1) %r1689.0 to i64
  %r2074.rs4o = call i64 asm "", "=r,0"(i64 %r2074.rs4i) #7
  %r2074 = bitcast i64 %r2074.rs4o to double
  %r2075 = bitcast double %r2074 to i64
  %r2076 = and i64 %r2075, 281474976710655
  %r2077 = sub nsw i64 %r2076, 8
  %r2078 = inttoptr i64 %r2077 to ptr
  %r2079 = load i8, ptr %r2078, align 1
  %r2080 = icmp ne i8 %r2079, 1
  %r2081 = sub nsw i64 %r2076, 7
  %r2082 = inttoptr i64 %r2081 to ptr
  %r2083 = load i8, ptr %r2082, align 1
  %r2084 = and i8 %r2083, -128
  %r2085 = icmp ne i8 %r2084, 0
  %r2086 = or i1 %r2080, %r2085
  br i1 %r2085, label %apush.fwd.297, label %apush.elements.298

if.merge.296:                                     ; preds = %apush.merge.303
  br label %if.else.309

apush.fwd.297:                                    ; preds = %apush.elements.check.299, %if.then.294
  %statepoint_token244 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r2076, double %r2072, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0935, ptr addrspace(1) %.16, ptr addrspace(1) %.0930) ]
  %r2113245 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token244)
  %r68.5.relocated246 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 2, i32 0) ; (%.0930, %.0935)
  %rs4gc.s19.relocated247 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 1, i32 1) ; (%.16, %.16)
  %r68.5.base.relocated248 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 2, i32 2) ; (%.0930, %.0930)
  %r2114 = or i64 %r2113245, 9222527611924643840
  %r2115 = bitcast i64 %r2114 to double
  %rs4gc.b61 = bitcast double %r2115 to i64
  %rs4gc.s61 = inttoptr i64 %rs4gc.b61 to ptr addrspace(1)
  br label %apush.merge.303

apush.elements.298:                               ; preds = %if.then.294
  %r2088 = add nuw nsw i64 %r2076, 8
  %r2089 = inttoptr i64 %r2088 to ptr
  %r2090 = load i64, ptr %r2089, align 8
  %r2091 = icmp ne i64 %r2090, 0
  %r2092 = icmp eq i8 %r2079, 2
  %r2093 = and i1 %r2092, %r2091
  %r2094 = select i1 %r2093, i64 %r2090, i64 %r2076
  %r2095 = inttoptr i64 %r2094 to ptr
  %r2096 = getelementptr i64, ptr %r2095, i64 12
  %r2097 = load i64, ptr %r2096, align 8
  %r2098 = icmp ne i64 %r2097, 0
  %r2099 = and i1 %r2093, %r2098
  %r2100 = select i1 %r2099, i64 %r2097, i64 %r2076
  %r2087 = icmp eq i8 %r2079, 1
  br i1 %r2087, label %apush.nofwd.300, label %apush.elements.check.299

apush.elements.check.299:                         ; preds = %apush.elements.298
  %r2101 = icmp ne i64 %r2100, 0
  %r2102 = sub i64 %r2100, 8
  %r2103 = inttoptr i64 %r2102 to ptr
  %r2104 = load i8, ptr %r2103, align 1
  %r2105 = icmp eq i8 %r2104, 1
  %r2106 = sub i64 %r2100, 7
  %r2107 = inttoptr i64 %r2106 to ptr
  %r2108 = load i8, ptr %r2107, align 1
  %r2109 = and i8 %r2108, -128
  %r2110 = icmp eq i8 %r2109, 0
  %r2111 = and i1 %r2101, %r2105
  %r2112 = and i1 %r2111, %r2110
  br i1 %r2112, label %apush.nofwd.300, label %apush.fwd.297

apush.nofwd.300:                                  ; preds = %apush.elements.check.299, %apush.elements.298
  %r2116 = phi i64 [ %r2076, %apush.elements.298 ], [ %r2100, %apush.elements.check.299 ]
  %r2117 = sub i64 %r2116, 6
  %r2118 = inttoptr i64 %r2117 to ptr
  %r2119 = load i16, ptr %r2118, align 2
  %r2120 = and i16 %r2119, 1031
  %r2121 = icmp eq i16 %r2120, 0
  %r2122 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2123 = icmp eq i8 %r2122, 0
  %r2124 = and i1 %r2121, %r2123
  %r2125 = icmp ult i64 %r2116, 4096
  %r2126 = inttoptr i64 %r2116 to ptr
  %r2127 = select i1 %r2125, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r2126
  %r2128 = load i32, ptr %r2127, align 4
  %r2129 = add i64 %r2116, 4
  %r2130 = inttoptr i64 %r2129 to ptr
  %r2131 = load i32, ptr %r2130, align 4
  %r2132 = icmp ult i32 %r2128, %r2131
  %r2133 = and i1 %r2132, %r2124
  br i1 %r2133, label %apush.inbounds.301, label %apush.realloc.302

apush.inbounds.301:                               ; preds = %apush.nofwd.300
  %r2134 = icmp ult i64 %r2116, 4096
  %r2135 = inttoptr i64 %r2116 to ptr
  %r2136 = select i1 %r2134, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r2135
  %r2137 = load i32, ptr %r2136, align 4
  %r2138 = zext i32 %r2137 to i64
  %r2139 = shl nuw nsw i64 %r2138, 3
  %r2140 = add nuw nsw i64 %r2139, 8
  %r2141 = add i64 %r2116, %r2140
  %r2142 = inttoptr i64 %r2141 to ptr
  store double %r2072, ptr %r2142, align 8
  %r2143 = lshr i64 %r2073, 48
  %r2144 = icmp eq i64 %r2143, 32765
  %r2145 = and i16 %r2119, -1920
  %r2146 = icmp eq i16 %r2145, -24576
  %r2147 = and i1 %r2144, %r2146
  br i1 %r2147, label %apush.pointer_layout.done.305, label %apush.pointer_layout.bookkeeping.304

apush.realloc.302:                                ; preds = %apush.nofwd.300
  %statepoint_token249 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r2076, double %r2072, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0935, ptr addrspace(1) %.16, ptr addrspace(1) %.0930) ]
  %r2158250 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token249)
  %r68.5.relocated251 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token249, i32 2, i32 0) ; (%.0930, %.0935)
  %rs4gc.s19.relocated252 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token249, i32 1, i32 1) ; (%.16, %.16)
  %r68.5.base.relocated253 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token249, i32 2, i32 2) ; (%.0930, %.0930)
  %r2159 = or i64 %r2158250, 9222527611924643840
  %r2160 = bitcast i64 %r2159 to double
  %rs4gc.b62 = bitcast double %r2160 to i64
  %rs4gc.s62 = inttoptr i64 %rs4gc.b62 to ptr addrspace(1)
  br label %apush.merge.303

apush.merge.303:                                  ; preds = %apush.barrier.done.307, %apush.realloc.302, %apush.fwd.297
  %.4939 = phi ptr addrspace(1) [ %r68.5.relocated246, %apush.fwd.297 ], [ %.0935, %apush.barrier.done.307 ], [ %r68.5.relocated251, %apush.realloc.302 ]
  %.4934 = phi ptr addrspace(1) [ %r68.5.base.relocated248, %apush.fwd.297 ], [ %.0930, %apush.barrier.done.307 ], [ %r68.5.base.relocated253, %apush.realloc.302 ]
  %.20 = phi ptr addrspace(1) [ %rs4gc.s19.relocated247, %apush.fwd.297 ], [ %.16, %apush.barrier.done.307 ], [ %rs4gc.s19.relocated252, %apush.realloc.302 ]
  %r1689.7 = phi ptr addrspace(1) [ %rs4gc.s61, %apush.fwd.297 ], [ %r1689.0, %apush.barrier.done.307 ], [ %rs4gc.s62, %apush.realloc.302 ]
  br label %if.merge.296

apush.pointer_layout.bookkeeping.304:             ; preds = %apush.inbounds.301
  call void @js_string_addref_if_heap_string(double %r2072) #7
  %r5804 = load double, ptr @test_json_warm_unique_keys_ts_.str.13.handle, align 8
  %r5805 = bitcast double %r5804 to i64
  call void @js_gc_note_slot_layout(i64 %r2116, i32 %r2137, i64 %r5805) #7
  %r5802 = load double, ptr @test_json_warm_unique_keys_ts_.str.13.handle, align 8
  %r5803 = bitcast double %r5802 to i64
  call void @js_array_note_numeric_write(i64 %r2116, i64 %r5803) #7
  br label %apush.pointer_layout.done.305

apush.pointer_layout.done.305:                    ; preds = %apush.pointer_layout.bookkeeping.304, %apush.inbounds.301
  %r2148 = sub i64 %r2116, 7
  %r2149 = inttoptr i64 %r2148 to ptr
  %r2150 = load i8, ptr %r2149, align 1
  %r2151 = and i8 %r2150, 32
  %r2152 = icmp ne i8 %r2151, 0
  %r2153 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2154 = icmp ne i32 %r2153, 0
  %r2155 = or i1 %r2152, %r2154
  br i1 %r2155, label %apush.barrier.306, label %apush.barrier.done.307

apush.barrier.306:                                ; preds = %apush.pointer_layout.done.305
  %r5800 = load double, ptr @test_json_warm_unique_keys_ts_.str.13.handle, align 8
  %r5801 = bitcast double %r5800 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r2116, i64 %r2141, i64 %r5801) #7
  br label %apush.barrier.done.307

apush.barrier.done.307:                           ; preds = %apush.barrier.306, %apush.pointer_layout.done.305
  %r2156 = add i32 %r2137, 1
  %r2157 = inttoptr i64 %r2116 to ptr
  store i32 %r2156, ptr %r2157, align 4
  br label %apush.merge.303

if.else.309:                                      ; preds = %if.merge.296
  br label %if.merge.310

if.merge.310:                                     ; preds = %if.else.309
  %r2253 = load double, ptr @test_json_warm_unique_keys_ts_.str.15.handle, align 8
  %r2254.rs4i = ptrtoint ptr addrspace(1) %r1689.7 to i64
  %r2254.rs4o = call i64 asm "", "=r,0"(i64 %r2254.rs4i) #7
  %r2254 = bitcast i64 %r2254.rs4o to double
  %r2255 = load double, ptr @test_json_warm_unique_keys_ts_.str.16.handle, align 8
  %r2256 = bitcast double %r2254 to i64
  %r2257 = and i64 %r2256, 281474976710655
  %statepoint_token254 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_join_value, i32 2, i32 0, i64 %r2257, double %r2255, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.20, ptr addrspace(1) %.4934, ptr addrspace(1) %.4939) ]
  %r2258255 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token254)
  %rs4gc.s19.relocated256 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token254, i32 0, i32 0) ; (%.20, %.20)
  %r68.5.base.relocated257 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token254, i32 1, i32 1) ; (%.4934, %.4934)
  %r68.5.relocated258 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token254, i32 1, i32 2) ; (%.4934, %.4939)
  %r2259 = or i64 %r2258255, 9223090561878065152
  %r2260 = bitcast i64 %r2259 to double
  %r2261 = load double, ptr @test_json_warm_unique_keys_ts_.str.17.handle, align 8
  %r2262 = load double, ptr @test_json_warm_unique_keys_ts_.str.15.handle, align 8
  %r2264 = getelementptr double, ptr %r2263, i64 0
  store double %r2262, ptr %r2264, align 8
  %r2265 = getelementptr double, ptr %r2263, i64 1
  store double %r2260, ptr %r2265, align 8
  %r2266 = getelementptr double, ptr %r2263, i64 2
  store double %r2261, ptr %r2266, align 8
  %r2267 = ptrtoint ptr %r2263 to i64
  %statepoint_token259 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r2267, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated256, ptr addrspace(1) %r68.5.base.relocated257, ptr addrspace(1) %r68.5.relocated258) ]
  %r2268260 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token259)
  %rs4gc.s19.relocated261 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 0, i32 0) ; (%rs4gc.s19.relocated256, %rs4gc.s19.relocated256)
  %r68.5.base.relocated262 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 1, i32 1) ; (%r68.5.base.relocated257, %r68.5.base.relocated257)
  %r68.5.relocated263 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 1, i32 2) ; (%r68.5.base.relocated257, %r68.5.relocated258)
  %r2269 = or i64 %r2268260, 9223090561878065152
  %r2270 = bitcast i64 %r2269 to double
  %r2271 = bitcast i64 %r2269 to double
  %r2272.rs4i = ptrtoint ptr addrspace(1) %r68.5.relocated263 to i64
  %r2272.rs4o = call i64 asm "", "=r,0"(i64 %r2272.rs4i) #7
  %r2272 = bitcast i64 %r2272.rs4o to double
  %r2273 = bitcast double %r2272 to i64
  %r2274 = and i64 %r2273, 281474976710655
  %r2275 = sub nsw i64 %r2274, 8
  %r2276 = inttoptr i64 %r2275 to ptr
  %r2277 = load i8, ptr %r2276, align 1
  %r2278 = icmp ne i8 %r2277, 1
  %r2279 = sub nsw i64 %r2274, 7
  %r2280 = inttoptr i64 %r2279 to ptr
  %r2281 = load i8, ptr %r2280, align 1
  %r2282 = and i8 %r2281, -128
  %r2283 = icmp ne i8 %r2282, 0
  %r2284 = or i1 %r2278, %r2283
  br i1 %r2283, label %apush.fwd.322, label %apush.elements.323

apush.fwd.322:                                    ; preds = %apush.elements.check.324, %if.merge.310
  %statepoint_token264 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r2274, double %r2271, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated261) ]
  %r2311265 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token264)
  %rs4gc.s19.relocated266 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token264, i32 0, i32 0) ; (%rs4gc.s19.relocated261, %rs4gc.s19.relocated261)
  %r2312 = or i64 %r2311265, 9222527611924643840
  %r2313 = bitcast i64 %r2312 to double
  %rs4gc.b65 = bitcast double %r2313 to i64
  %rs4gc.s65 = inttoptr i64 %rs4gc.b65 to ptr addrspace(1)
  br label %apush.merge.328

apush.elements.323:                               ; preds = %if.merge.310
  %r2286 = add nuw nsw i64 %r2274, 8
  %r2287 = inttoptr i64 %r2286 to ptr
  %r2288 = load i64, ptr %r2287, align 8
  %r2289 = icmp ne i64 %r2288, 0
  %r2290 = icmp eq i8 %r2277, 2
  %r2291 = and i1 %r2290, %r2289
  %r2292 = select i1 %r2291, i64 %r2288, i64 %r2274
  %r2293 = inttoptr i64 %r2292 to ptr
  %r2294 = getelementptr i64, ptr %r2293, i64 12
  %r2295 = load i64, ptr %r2294, align 8
  %r2296 = icmp ne i64 %r2295, 0
  %r2297 = and i1 %r2291, %r2296
  %r2298 = select i1 %r2297, i64 %r2295, i64 %r2274
  %r2285 = icmp eq i8 %r2277, 1
  br i1 %r2285, label %apush.nofwd.325, label %apush.elements.check.324

apush.elements.check.324:                         ; preds = %apush.elements.323
  %r2299 = icmp ne i64 %r2298, 0
  %r2300 = sub i64 %r2298, 8
  %r2301 = inttoptr i64 %r2300 to ptr
  %r2302 = load i8, ptr %r2301, align 1
  %r2303 = icmp eq i8 %r2302, 1
  %r2304 = sub i64 %r2298, 7
  %r2305 = inttoptr i64 %r2304 to ptr
  %r2306 = load i8, ptr %r2305, align 1
  %r2307 = and i8 %r2306, -128
  %r2308 = icmp eq i8 %r2307, 0
  %r2309 = and i1 %r2299, %r2303
  %r2310 = and i1 %r2309, %r2308
  br i1 %r2310, label %apush.nofwd.325, label %apush.fwd.322

apush.nofwd.325:                                  ; preds = %apush.elements.check.324, %apush.elements.323
  %r2314 = phi i64 [ %r2274, %apush.elements.323 ], [ %r2298, %apush.elements.check.324 ]
  %r2315 = sub i64 %r2314, 6
  %r2316 = inttoptr i64 %r2315 to ptr
  %r2317 = load i16, ptr %r2316, align 2
  %r2318 = and i16 %r2317, 1031
  %r2319 = icmp eq i16 %r2318, 0
  %r2320 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2321 = icmp eq i8 %r2320, 0
  %r2322 = and i1 %r2319, %r2321
  %r2323 = icmp ult i64 %r2314, 4096
  %r2324 = inttoptr i64 %r2314 to ptr
  %r2325 = select i1 %r2323, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r2324
  %r2326 = load i32, ptr %r2325, align 4
  %r2327 = add i64 %r2314, 4
  %r2328 = inttoptr i64 %r2327 to ptr
  %r2329 = load i32, ptr %r2328, align 4
  %r2330 = icmp ult i32 %r2326, %r2329
  %r2331 = and i1 %r2330, %r2322
  br i1 %r2331, label %apush.inbounds.326, label %apush.realloc.327

apush.inbounds.326:                               ; preds = %apush.nofwd.325
  %r2332 = icmp ult i64 %r2314, 4096
  %r2333 = inttoptr i64 %r2314 to ptr
  %r2334 = select i1 %r2332, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r2333
  %r2335 = load i32, ptr %r2334, align 4
  %r2336 = zext i32 %r2335 to i64
  %r2337 = shl nuw nsw i64 %r2336, 3
  %r2338 = add nuw nsw i64 %r2337, 8
  %r2339 = add i64 %r2314, %r2338
  %r2340 = inttoptr i64 %r2339 to ptr
  store double %r2271, ptr %r2340, align 8
  %r2341 = lshr i64 %r2269, 48
  %r2343 = and i16 %r2317, -1920
  %r2344 = icmp eq i16 %r2343, -24576
  br label %apush.pointer_layout.bookkeeping.329

apush.realloc.327:                                ; preds = %apush.nofwd.325
  %statepoint_token267 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r2274, double %r2271, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated261) ]
  %r2356268 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token267)
  %rs4gc.s19.relocated269 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token267, i32 0, i32 0) ; (%rs4gc.s19.relocated261, %rs4gc.s19.relocated261)
  %r2357 = or i64 %r2356268, 9222527611924643840
  %r2358 = bitcast i64 %r2357 to double
  %rs4gc.b66 = bitcast double %r2358 to i64
  %rs4gc.s66 = inttoptr i64 %rs4gc.b66 to ptr addrspace(1)
  br label %apush.merge.328

apush.merge.328:                                  ; preds = %apush.barrier.done.332, %apush.realloc.327, %apush.fwd.322
  %.21 = phi ptr addrspace(1) [ %rs4gc.s19.relocated266, %apush.fwd.322 ], [ %rs4gc.s19.relocated261, %apush.barrier.done.332 ], [ %rs4gc.s19.relocated269, %apush.realloc.327 ]
  %r68.6.base = phi ptr addrspace(1) [ %rs4gc.s65, %apush.fwd.322 ], [ %r68.5.base.relocated262, %apush.barrier.done.332 ], [ %rs4gc.s66, %apush.realloc.327 ], !is_base_value !0
  %r68.6 = phi ptr addrspace(1) [ %rs4gc.s65, %apush.fwd.322 ], [ %r68.5.relocated263, %apush.barrier.done.332 ], [ %rs4gc.s66, %apush.realloc.327 ]
  %r2359 = load double, ptr @test_json_warm_unique_keys_ts_.str.8.handle, align 8
  %r2360 = bitcast double %r2359 to i64
  %r2361.rs4i = ptrtoint ptr addrspace(1) %r68.6 to i64
  %r2361.rs4o = call i64 asm "", "=r,0"(i64 %r2361.rs4i) #7
  %r2361 = bitcast i64 %r2361.rs4o to double
  %r2362 = bitcast double %r2361 to i64
  %r2363 = and i64 %r2362, 281474976710655
  %r2364 = sub nsw i64 %r2363, 8
  %r2365 = inttoptr i64 %r2364 to ptr
  %r2366 = load i8, ptr %r2365, align 1
  %r2367 = icmp ne i8 %r2366, 1
  %r2368 = sub nsw i64 %r2363, 7
  %r2369 = inttoptr i64 %r2368 to ptr
  %r2370 = load i8, ptr %r2369, align 1
  %r2371 = and i8 %r2370, -128
  %r2372 = icmp ne i8 %r2371, 0
  %r2373 = or i1 %r2367, %r2372
  br i1 %r2372, label %apush.fwd.333, label %apush.elements.334

apush.pointer_layout.bookkeeping.329:             ; preds = %apush.inbounds.326
  call void @js_string_addref_if_heap_string(double %r2271) #7
  call void @js_gc_note_slot_layout(i64 %r2314, i32 %r2335, i64 %r2269) #7
  call void @js_array_note_numeric_write(i64 %r2314, i64 %r2269) #7
  br label %apush.pointer_layout.done.330

apush.pointer_layout.done.330:                    ; preds = %apush.pointer_layout.bookkeeping.329
  %r2346 = sub i64 %r2314, 7
  %r2347 = inttoptr i64 %r2346 to ptr
  %r2348 = load i8, ptr %r2347, align 1
  %r2349 = and i8 %r2348, 32
  %r2350 = icmp ne i8 %r2349, 0
  %r2351 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2352 = icmp ne i32 %r2351, 0
  %r2353 = or i1 %r2350, %r2352
  br i1 %r2353, label %apush.barrier.331, label %apush.barrier.done.332

apush.barrier.331:                                ; preds = %apush.pointer_layout.done.330
  call void @js_write_barrier_slot_validated_parent(i64 %r2314, i64 %r2339, i64 %r2269) #7
  br label %apush.barrier.done.332

apush.barrier.done.332:                           ; preds = %apush.barrier.331, %apush.pointer_layout.done.330
  %r2354 = add i32 %r2335, 1
  %r2355 = inttoptr i64 %r2314 to ptr
  store i32 %r2354, ptr %r2355, align 4
  br label %apush.merge.328

apush.fwd.333:                                    ; preds = %apush.elements.check.335, %apush.merge.328
  %statepoint_token270 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r2363, double %r2359, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.21) ]
  %r2400271 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token270)
  %rs4gc.s19.relocated272 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token270, i32 0, i32 0) ; (%.21, %.21)
  %r2401 = or i64 %r2400271, 9222527611924643840
  %r2402 = bitcast i64 %r2401 to double
  %rs4gc.b67 = bitcast double %r2402 to i64
  %rs4gc.s67 = inttoptr i64 %rs4gc.b67 to ptr addrspace(1)
  br label %apush.merge.339

apush.elements.334:                               ; preds = %apush.merge.328
  %r2375 = add nuw nsw i64 %r2363, 8
  %r2376 = inttoptr i64 %r2375 to ptr
  %r2377 = load i64, ptr %r2376, align 8
  %r2378 = icmp ne i64 %r2377, 0
  %r2379 = icmp eq i8 %r2366, 2
  %r2380 = and i1 %r2379, %r2378
  %r2381 = select i1 %r2380, i64 %r2377, i64 %r2363
  %r2382 = inttoptr i64 %r2381 to ptr
  %r2383 = getelementptr i64, ptr %r2382, i64 12
  %r2384 = load i64, ptr %r2383, align 8
  %r2385 = icmp ne i64 %r2384, 0
  %r2386 = and i1 %r2380, %r2385
  %r2387 = select i1 %r2386, i64 %r2384, i64 %r2363
  %r2374 = icmp eq i8 %r2366, 1
  br i1 %r2374, label %apush.nofwd.336, label %apush.elements.check.335

apush.elements.check.335:                         ; preds = %apush.elements.334
  %r2388 = icmp ne i64 %r2387, 0
  %r2389 = sub i64 %r2387, 8
  %r2390 = inttoptr i64 %r2389 to ptr
  %r2391 = load i8, ptr %r2390, align 1
  %r2392 = icmp eq i8 %r2391, 1
  %r2393 = sub i64 %r2387, 7
  %r2394 = inttoptr i64 %r2393 to ptr
  %r2395 = load i8, ptr %r2394, align 1
  %r2396 = and i8 %r2395, -128
  %r2397 = icmp eq i8 %r2396, 0
  %r2398 = and i1 %r2388, %r2392
  %r2399 = and i1 %r2398, %r2397
  br i1 %r2399, label %apush.nofwd.336, label %apush.fwd.333

apush.nofwd.336:                                  ; preds = %apush.elements.check.335, %apush.elements.334
  %r2403 = phi i64 [ %r2363, %apush.elements.334 ], [ %r2387, %apush.elements.check.335 ]
  %r2404 = sub i64 %r2403, 6
  %r2405 = inttoptr i64 %r2404 to ptr
  %r2406 = load i16, ptr %r2405, align 2
  %r2407 = and i16 %r2406, 1031
  %r2408 = icmp eq i16 %r2407, 0
  %r2409 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2410 = icmp eq i8 %r2409, 0
  %r2411 = and i1 %r2408, %r2410
  %r2412 = icmp ult i64 %r2403, 4096
  %r2413 = inttoptr i64 %r2403 to ptr
  %r2414 = select i1 %r2412, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r2413
  %r2415 = load i32, ptr %r2414, align 4
  %r2416 = add i64 %r2403, 4
  %r2417 = inttoptr i64 %r2416 to ptr
  %r2418 = load i32, ptr %r2417, align 4
  %r2419 = icmp ult i32 %r2415, %r2418
  %r2420 = and i1 %r2419, %r2411
  br i1 %r2420, label %apush.inbounds.337, label %apush.realloc.338

apush.inbounds.337:                               ; preds = %apush.nofwd.336
  %r2421 = icmp ult i64 %r2403, 4096
  %r2422 = inttoptr i64 %r2403 to ptr
  %r2423 = select i1 %r2421, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r2422
  %r2424 = load i32, ptr %r2423, align 4
  %r2425 = zext i32 %r2424 to i64
  %r2426 = shl nuw nsw i64 %r2425, 3
  %r2427 = add nuw nsw i64 %r2426, 8
  %r2428 = add i64 %r2403, %r2427
  %r2429 = inttoptr i64 %r2428 to ptr
  store double %r2359, ptr %r2429, align 8
  %r2430 = lshr i64 %r2360, 48
  %r2431 = icmp eq i64 %r2430, 32765
  %r2432 = and i16 %r2406, -1920
  %r2433 = icmp eq i16 %r2432, -24576
  %r2434 = and i1 %r2431, %r2433
  br i1 %r2434, label %apush.pointer_layout.done.341, label %apush.pointer_layout.bookkeeping.340

apush.realloc.338:                                ; preds = %apush.nofwd.336
  %statepoint_token273 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r2363, double %r2359, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.21) ]
  %r2445274 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token273)
  %rs4gc.s19.relocated275 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token273, i32 0, i32 0) ; (%.21, %.21)
  %r2446 = or i64 %r2445274, 9222527611924643840
  %r2447 = bitcast i64 %r2446 to double
  %rs4gc.b68 = bitcast double %r2447 to i64
  %rs4gc.s68 = inttoptr i64 %rs4gc.b68 to ptr addrspace(1)
  br label %apush.merge.339

apush.merge.339:                                  ; preds = %apush.barrier.done.343, %apush.realloc.338, %apush.fwd.333
  %.22 = phi ptr addrspace(1) [ %rs4gc.s19.relocated272, %apush.fwd.333 ], [ %.21, %apush.barrier.done.343 ], [ %rs4gc.s19.relocated275, %apush.realloc.338 ]
  %r68.7.base = phi ptr addrspace(1) [ %rs4gc.s67, %apush.fwd.333 ], [ %r68.6.base, %apush.barrier.done.343 ], [ %rs4gc.s68, %apush.realloc.338 ], !is_base_value !0
  %r68.7 = phi ptr addrspace(1) [ %rs4gc.s67, %apush.fwd.333 ], [ %r68.6, %apush.barrier.done.343 ], [ %rs4gc.s68, %apush.realloc.338 ]
  %statepoint_token276 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.22, ptr addrspace(1) %r68.7.base, ptr addrspace(1) %r68.7) ]
  %r2449277 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token276)
  %rs4gc.s19.relocated278 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token276, i32 0, i32 0) ; (%.22, %.22)
  %r68.7.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token276, i32 1, i32 1) ; (%r68.7.base, %r68.7.base)
  %r68.7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token276, i32 1, i32 2) ; (%r68.7.base, %r68.7)
  %r2450 = or i64 %r2449277, 9222527611924643840
  %r2451 = bitcast i64 %r2450 to double
  %rs4gc.b69 = bitcast double %r2451 to i64
  %rs4gc.s69 = inttoptr i64 %rs4gc.b69 to ptr addrspace(1)
  %r2452.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s69 to i64
  %r2452 = call i64 asm "", "=r,0"(i64 %r2452.rs4i) #7
  %r2453 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2454 = icmp ne i32 %r2453, 0
  br i1 %r2454, label %shadow.root.barrier.344, label %shadow.root.barrier.done.345

apush.pointer_layout.bookkeeping.340:             ; preds = %apush.inbounds.337
  call void @js_string_addref_if_heap_string(double %r2359) #7
  %r5792 = load double, ptr @test_json_warm_unique_keys_ts_.str.8.handle, align 8
  %r5793 = bitcast double %r5792 to i64
  call void @js_gc_note_slot_layout(i64 %r2403, i32 %r2424, i64 %r5793) #7
  %r5790 = load double, ptr @test_json_warm_unique_keys_ts_.str.8.handle, align 8
  %r5791 = bitcast double %r5790 to i64
  call void @js_array_note_numeric_write(i64 %r2403, i64 %r5791) #7
  br label %apush.pointer_layout.done.341

apush.pointer_layout.done.341:                    ; preds = %apush.pointer_layout.bookkeeping.340, %apush.inbounds.337
  %r2435 = sub i64 %r2403, 7
  %r2436 = inttoptr i64 %r2435 to ptr
  %r2437 = load i8, ptr %r2436, align 1
  %r2438 = and i8 %r2437, 32
  %r2439 = icmp ne i8 %r2438, 0
  %r2440 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2441 = icmp ne i32 %r2440, 0
  %r2442 = or i1 %r2439, %r2441
  br i1 %r2442, label %apush.barrier.342, label %apush.barrier.done.343

apush.barrier.342:                                ; preds = %apush.pointer_layout.done.341
  %r5788 = load double, ptr @test_json_warm_unique_keys_ts_.str.8.handle, align 8
  %r5789 = bitcast double %r5788 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r2403, i64 %r2428, i64 %r5789) #7
  br label %apush.barrier.done.343

apush.barrier.done.343:                           ; preds = %apush.barrier.342, %apush.pointer_layout.done.341
  %r2443 = add i32 %r2424, 1
  %r2444 = inttoptr i64 %r2403 to ptr
  store i32 %r2443, ptr %r2444, align 4
  br label %apush.merge.339

shadow.root.barrier.344:                          ; preds = %apush.merge.339
  call void @js_write_barrier_root_nanbox(i64 %r2452) #7
  br label %shadow.root.barrier.done.345

shadow.root.barrier.done.345:                     ; preds = %shadow.root.barrier.344, %apush.merge.339
  br label %for.cond.346

for.cond.346:                                     ; preds = %for.update.348, %shadow.root.barrier.done.345
  %.0949 = phi ptr addrspace(1) [ %r68.7.relocated, %shadow.root.barrier.done.345 ], [ %.3952, %for.update.348 ]
  %.0944 = phi ptr addrspace(1) [ %r68.7.base.relocated, %shadow.root.barrier.done.345 ], [ %.3947, %for.update.348 ]
  %.23 = phi ptr addrspace(1) [ %rs4gc.s19.relocated278, %shadow.root.barrier.done.345 ], [ %.26, %for.update.348 ]
  %r2455.0 = phi i32 [ 0, %shadow.root.barrier.done.345 ], [ %r2641, %for.update.348 ]
  %r2448.0.base = phi ptr addrspace(1) [ %rs4gc.s69, %shadow.root.barrier.done.345 ], [ %.0956, %for.update.348 ], !is_base_value !0
  %r2448.0 = phi ptr addrspace(1) [ %rs4gc.s69, %shadow.root.barrier.done.345 ], [ %.0957, %for.update.348 ]
  %r2460 = icmp slt i32 %r2455.0, %r75.0
  br i1 %r2460, label %for.body.347, label %for.exit.349

for.body.347:                                     ; preds = %for.cond.346
  %r2461 = load double, ptr @test_json_warm_unique_keys_ts_.str.9.handle, align 8
  %r2462.rs4i = ptrtoint ptr addrspace(1) %.23 to i64
  %r2462.rs4o = call i64 asm "", "=r,0"(i64 %r2462.rs4i) #7
  %r2462 = bitcast i64 %r2462.rs4o to double
  %r2464 = bitcast double %r2462 to i64
  %r2465 = and i64 %r2464, 281474976710655
  %r2466 = lshr i64 %r2464, 48
  %r2467 = icmp eq i64 %r2466, 32765
  %r2468 = icmp ugt i64 %r2465, 1048575
  %r2469 = and i1 %r2467, %r2468
  br i1 %r2469, label %arr.guard.deref.354, label %arr.fallback.351

for.update.348:                                   ; preds = %gcpoll.done.369
  %r2641 = add i32 %r2455.0, 1
  %r2642 = sitofp i32 %r2455.0 to double
  %r2643 = sitofp i32 %r2641 to double
  br label %for.cond.346

for.exit.349:                                     ; preds = %for.cond.346
  br label %if.else.371

arr.fast.350:                                     ; preds = %arr.guard.range.356
  %r2525 = zext i32 %r2455.0 to i64
  %r2526 = shl nuw nsw i64 %r2525, 3
  %r2527 = add nuw nsw i64 %r2526, 8
  %r2528 = add i64 %r2484, %r2527
  %r2529 = inttoptr i64 %r2528 to ptr
  %r2530 = load double, ptr %r2529, align 8
  %r2531 = bitcast double %r2530 to i64
  %r2532 = icmp eq i64 %r2531, 9222246136947933200
  %r2534 = select i1 %r2532, double 0x7FFC000000000001, double %r2530
  br label %arr.merge.353

arr.fallback.351:                                 ; preds = %arr.guard.live.355, %arr.guard.deref.354, %for.body.347
  %r2523 = sitofp i32 %r2455.0 to double
  %statepoint_token279 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 547434508618563587, double %r2462, double %r2523, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r2448.0, ptr addrspace(1) %r2448.0.base, ptr addrspace(1) %.23, ptr addrspace(1) %.0944, ptr addrspace(1) %.0949) ]
  %r2524280 = call double @llvm.experimental.gc.result.f64(token %statepoint_token279)
  %r2448.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token279, i32 1, i32 0) ; (%r2448.0.base, %r2448.0)
  %r2448.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token279, i32 1, i32 1) ; (%r2448.0.base, %r2448.0.base)
  %rs4gc.s19.relocated281 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token279, i32 2, i32 2) ; (%.23, %.23)
  %r68.7.base.relocated282 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token279, i32 3, i32 3) ; (%.0944, %.0944)
  %r68.7.relocated283 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token279, i32 3, i32 4) ; (%.0944, %.0949)
  br label %arr.merge.353

arr.guard.oob.352:                                ; preds = %arr.guard.range.356
  br label %arr.merge.353

arr.merge.353:                                    ; preds = %arr.guard.oob.352, %arr.fallback.351, %arr.fast.350
  %.0955 = phi ptr addrspace(1) [ %r2448.0.base, %arr.fast.350 ], [ %r2448.0.base, %arr.guard.oob.352 ], [ %r2448.0.base.relocated, %arr.fallback.351 ]
  %.0954 = phi ptr addrspace(1) [ %r2448.0, %arr.fast.350 ], [ %r2448.0, %arr.guard.oob.352 ], [ %r2448.0.relocated, %arr.fallback.351 ]
  %.1950 = phi ptr addrspace(1) [ %.0949, %arr.fast.350 ], [ %.0949, %arr.guard.oob.352 ], [ %r68.7.relocated283, %arr.fallback.351 ]
  %.1945 = phi ptr addrspace(1) [ %.0944, %arr.fast.350 ], [ %.0944, %arr.guard.oob.352 ], [ %r68.7.base.relocated282, %arr.fallback.351 ]
  %.24 = phi ptr addrspace(1) [ %.23, %arr.fast.350 ], [ %.23, %arr.guard.oob.352 ], [ %rs4gc.s19.relocated281, %arr.fallback.351 ]
  %r2535 = phi double [ %r2534, %arr.fast.350 ], [ %r2524280, %arr.fallback.351 ], [ 0x7FFC000000000001, %arr.guard.oob.352 ]
  %r2536 = load double, ptr @test_json_warm_unique_keys_ts_.str.10.handle, align 8
  %r2537 = load double, ptr @test_json_warm_unique_keys_ts_.str.9.handle, align 8
  %r2539 = getelementptr double, ptr %r2538, i64 0
  store double %r2537, ptr %r2539, align 8
  %r2540 = getelementptr double, ptr %r2538, i64 1
  store double %r2535, ptr %r2540, align 8
  %r2541 = getelementptr double, ptr %r2538, i64 2
  store double %r2536, ptr %r2541, align 8
  %r2542 = ptrtoint ptr %r2538 to i64
  %statepoint_token284 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r2542, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.24, ptr addrspace(1) %.1945, ptr addrspace(1) %.0955, ptr addrspace(1) %.0954, ptr addrspace(1) %.1950) ]
  %r2543285 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token284)
  %rs4gc.s19.relocated286 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 0, i32 0) ; (%.24, %.24)
  %r68.7.base.relocated287 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 1, i32 1) ; (%.1945, %.1945)
  %r2448.0.base.relocated288 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 2, i32 2) ; (%.0955, %.0955)
  %r2448.0.relocated289 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 2, i32 3) ; (%.0955, %.0954)
  %r68.7.relocated290 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 1, i32 4) ; (%.1945, %.1950)
  %r2544 = or i64 %r2543285, 9223090561878065152
  %r2545 = bitcast i64 %r2544 to double
  %r2547 = sitofp i32 %r2455.0 to double
  %statepoint_token291 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r2545, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated286, ptr addrspace(1) %r68.7.base.relocated287, ptr addrspace(1) %r2448.0.base.relocated288, ptr addrspace(1) %r2448.0.relocated289, ptr addrspace(1) %r68.7.relocated290) ]
  %r2548292 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token291)
  %rs4gc.s19.relocated293 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token291, i32 0, i32 0) ; (%rs4gc.s19.relocated286, %rs4gc.s19.relocated286)
  %r68.7.base.relocated294 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token291, i32 1, i32 1) ; (%r68.7.base.relocated287, %r68.7.base.relocated287)
  %r2448.0.base.relocated295 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token291, i32 2, i32 2) ; (%r2448.0.base.relocated288, %r2448.0.base.relocated288)
  %r2448.0.relocated296 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token291, i32 2, i32 3) ; (%r2448.0.base.relocated288, %r2448.0.relocated289)
  %r68.7.relocated297 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token291, i32 1, i32 4) ; (%r68.7.base.relocated287, %r68.7.relocated290)
  %statepoint_token298 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r2548292, double %r2547, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated293, ptr addrspace(1) %r68.7.base.relocated294, ptr addrspace(1) %r2448.0.base.relocated295, ptr addrspace(1) %r2448.0.relocated296, ptr addrspace(1) %r68.7.relocated297) ]
  %r2549299 = call double @llvm.experimental.gc.result.f64(token %statepoint_token298)
  %rs4gc.s19.relocated300 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token298, i32 0, i32 0) ; (%rs4gc.s19.relocated293, %rs4gc.s19.relocated293)
  %r68.7.base.relocated301 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token298, i32 1, i32 1) ; (%r68.7.base.relocated294, %r68.7.base.relocated294)
  %r2448.0.base.relocated302 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token298, i32 2, i32 2) ; (%r2448.0.base.relocated295, %r2448.0.base.relocated295)
  %r2448.0.relocated303 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token298, i32 2, i32 3) ; (%r2448.0.base.relocated295, %r2448.0.relocated296)
  %r68.7.relocated304 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token298, i32 1, i32 4) ; (%r68.7.base.relocated294, %r68.7.relocated297)
  %r2550 = bitcast double %r2549299 to i64
  %r2551.rs4i = ptrtoint ptr addrspace(1) %r2448.0.relocated303 to i64
  %r2551.rs4o = call i64 asm "", "=r,0"(i64 %r2551.rs4i) #7
  %r2551 = bitcast i64 %r2551.rs4o to double
  %r2552 = bitcast double %r2551 to i64
  %r2553 = and i64 %r2552, 281474976710655
  %r2554 = sub nsw i64 %r2553, 8
  %r2555 = inttoptr i64 %r2554 to ptr
  %r2556 = load i8, ptr %r2555, align 1
  %r2557 = icmp ne i8 %r2556, 1
  %r2558 = sub nsw i64 %r2553, 7
  %r2559 = inttoptr i64 %r2558 to ptr
  %r2560 = load i8, ptr %r2559, align 1
  %r2561 = and i8 %r2560, -128
  %r2562 = icmp ne i8 %r2561, 0
  %r2563 = or i1 %r2557, %r2562
  br i1 %r2562, label %apush.fwd.357, label %apush.elements.358

arr.guard.deref.354:                              ; preds = %for.body.347
  %r2470 = bitcast double %r2462 to i64
  %r2471 = and i64 %r2470, 281474976710655
  %r2472 = sub nsw i64 %r2471, 8
  %r2473 = inttoptr i64 %r2472 to ptr
  %r2474 = load i8, ptr %r2473, align 1
  %r2475 = icmp eq i8 %r2474, 1
  %r2476 = sub nsw i64 %r2471, 7
  %r2477 = inttoptr i64 %r2476 to ptr
  %r2478 = load i8, ptr %r2477, align 1
  %r2479 = and i8 %r2478, -128
  %r2480 = icmp ne i8 %r2479, 0
  %r2481 = inttoptr i64 %r2471 to ptr
  %r2482 = load i64, ptr %r2481, align 8
  %r2483 = and i1 %r2475, %r2480
  %r2484 = select i1 %r2483, i64 %r2482, i64 %r2471
  %r2485 = lshr i64 %r2484, 48
  %r2486 = icmp eq i64 %r2485, 0
  %r2487 = icmp ugt i64 %r2484, 1048575
  %r2488 = and i1 %r2486, %r2487
  br i1 %r2488, label %arr.guard.live.355, label %arr.fallback.351

arr.guard.live.355:                               ; preds = %arr.guard.deref.354
  %r2489 = sub nuw i64 %r2484, 8
  %r2490 = inttoptr i64 %r2489 to ptr
  %r2491 = load i8, ptr %r2490, align 1
  %r2492 = icmp eq i8 %r2491, 1
  %r2493 = sub nuw i64 %r2484, 7
  %r2494 = inttoptr i64 %r2493 to ptr
  %r2495 = load i8, ptr %r2494, align 1
  %r2496 = and i8 %r2495, -128
  %r2497 = icmp eq i8 %r2496, 0
  %r2498 = sub nuw i64 %r2484, 6
  %r2499 = inttoptr i64 %r2498 to ptr
  %r2500 = load i16, ptr %r2499, align 2
  %r2501 = and i16 %r2500, 1024
  %r2502 = icmp eq i16 %r2501, 0
  %r2503 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2504 = icmp eq i8 %r2503, 0
  %r2505 = inttoptr i64 %r2484 to ptr
  %r2506 = load i32, ptr %r2505, align 4
  %r2507 = getelementptr i8, ptr %r2505, i64 4
  %r2508 = load i32, ptr %r2507, align 4
  %r2509 = icmp slt i32 %r2455.0, 0
  %r2510 = icmp eq i1 %r2509, false
  %r2512 = icmp ule i32 %r2506, 16000000
  %r2513 = icmp ule i32 %r2508, 16000000
  %r2514 = icmp ule i32 %r2506, %r2508
  %r2515 = and i1 %r2492, %r2497
  %r2516 = and i1 %r2515, %r2502
  %r2517 = and i1 %r2516, %r2504
  %r2518 = and i1 %r2517, %r2510
  %r2519 = and i1 %r2518, %r2512
  %r2520 = and i1 %r2519, %r2513
  %r2521 = and i1 %r2520, %r2514
  br i1 %r2521, label %arr.guard.range.356, label %arr.fallback.351

arr.guard.range.356:                              ; preds = %arr.guard.live.355
  %r2511 = icmp ult i32 %r2455.0, %r2506
  br i1 %r2511, label %arr.fast.350, label %arr.guard.oob.352

apush.fwd.357:                                    ; preds = %apush.elements.check.359, %arr.merge.353
  %statepoint_token305 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r2553, double %r2549299, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated300, ptr addrspace(1) %r68.7.base.relocated301, ptr addrspace(1) %r68.7.relocated304) ]
  %r2590306 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token305)
  %rs4gc.s19.relocated307 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token305, i32 0, i32 0) ; (%rs4gc.s19.relocated300, %rs4gc.s19.relocated300)
  %r68.7.base.relocated308 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token305, i32 1, i32 1) ; (%r68.7.base.relocated301, %r68.7.base.relocated301)
  %r68.7.relocated309 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token305, i32 1, i32 2) ; (%r68.7.base.relocated301, %r68.7.relocated304)
  %r2591 = or i64 %r2590306, 9222527611924643840
  %r2592 = bitcast i64 %r2591 to double
  %rs4gc.b70 = bitcast double %r2592 to i64
  %rs4gc.s70 = inttoptr i64 %rs4gc.b70 to ptr addrspace(1)
  br label %apush.merge.363

apush.elements.358:                               ; preds = %arr.merge.353
  %r2565 = add nuw nsw i64 %r2553, 8
  %r2566 = inttoptr i64 %r2565 to ptr
  %r2567 = load i64, ptr %r2566, align 8
  %r2568 = icmp ne i64 %r2567, 0
  %r2569 = icmp eq i8 %r2556, 2
  %r2570 = and i1 %r2569, %r2568
  %r2571 = select i1 %r2570, i64 %r2567, i64 %r2553
  %r2572 = inttoptr i64 %r2571 to ptr
  %r2573 = getelementptr i64, ptr %r2572, i64 12
  %r2574 = load i64, ptr %r2573, align 8
  %r2575 = icmp ne i64 %r2574, 0
  %r2576 = and i1 %r2570, %r2575
  %r2577 = select i1 %r2576, i64 %r2574, i64 %r2553
  %r2564 = icmp eq i8 %r2556, 1
  br i1 %r2564, label %apush.nofwd.360, label %apush.elements.check.359

apush.elements.check.359:                         ; preds = %apush.elements.358
  %r2578 = icmp ne i64 %r2577, 0
  %r2579 = sub i64 %r2577, 8
  %r2580 = inttoptr i64 %r2579 to ptr
  %r2581 = load i8, ptr %r2580, align 1
  %r2582 = icmp eq i8 %r2581, 1
  %r2583 = sub i64 %r2577, 7
  %r2584 = inttoptr i64 %r2583 to ptr
  %r2585 = load i8, ptr %r2584, align 1
  %r2586 = and i8 %r2585, -128
  %r2587 = icmp eq i8 %r2586, 0
  %r2588 = and i1 %r2578, %r2582
  %r2589 = and i1 %r2588, %r2587
  br i1 %r2589, label %apush.nofwd.360, label %apush.fwd.357

apush.nofwd.360:                                  ; preds = %apush.elements.check.359, %apush.elements.358
  %r2593 = phi i64 [ %r2553, %apush.elements.358 ], [ %r2577, %apush.elements.check.359 ]
  %r2594 = sub i64 %r2593, 6
  %r2595 = inttoptr i64 %r2594 to ptr
  %r2596 = load i16, ptr %r2595, align 2
  %r2597 = and i16 %r2596, 1031
  %r2598 = icmp eq i16 %r2597, 0
  %r2599 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2600 = icmp eq i8 %r2599, 0
  %r2601 = and i1 %r2598, %r2600
  %r2602 = icmp ult i64 %r2593, 4096
  %r2603 = inttoptr i64 %r2593 to ptr
  %r2604 = select i1 %r2602, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r2603
  %r2605 = load i32, ptr %r2604, align 4
  %r2606 = add i64 %r2593, 4
  %r2607 = inttoptr i64 %r2606 to ptr
  %r2608 = load i32, ptr %r2607, align 4
  %r2609 = icmp ult i32 %r2605, %r2608
  %r2610 = and i1 %r2609, %r2601
  br i1 %r2610, label %apush.inbounds.361, label %apush.realloc.362

apush.inbounds.361:                               ; preds = %apush.nofwd.360
  %r2611 = icmp ult i64 %r2593, 4096
  %r2612 = inttoptr i64 %r2593 to ptr
  %r2613 = select i1 %r2611, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r2612
  %r2614 = load i32, ptr %r2613, align 4
  %r2615 = zext i32 %r2614 to i64
  %r2616 = shl nuw nsw i64 %r2615, 3
  %r2617 = add nuw nsw i64 %r2616, 8
  %r2618 = add i64 %r2593, %r2617
  %r2619 = inttoptr i64 %r2618 to ptr
  store double %r2549299, ptr %r2619, align 8
  %r2620 = lshr i64 %r2550, 48
  %r2621 = icmp eq i64 %r2620, 32765
  %r2622 = and i16 %r2596, -1920
  %r2623 = icmp eq i16 %r2622, -24576
  %r2624 = and i1 %r2621, %r2623
  br i1 %r2624, label %apush.pointer_layout.done.365, label %apush.pointer_layout.bookkeeping.364

apush.realloc.362:                                ; preds = %apush.nofwd.360
  %statepoint_token310 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r2553, double %r2549299, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated300, ptr addrspace(1) %r68.7.base.relocated301, ptr addrspace(1) %r68.7.relocated304) ]
  %r2635311 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token310)
  %rs4gc.s19.relocated312 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token310, i32 0, i32 0) ; (%rs4gc.s19.relocated300, %rs4gc.s19.relocated300)
  %r68.7.base.relocated313 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token310, i32 1, i32 1) ; (%r68.7.base.relocated301, %r68.7.base.relocated301)
  %r68.7.relocated314 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token310, i32 1, i32 2) ; (%r68.7.base.relocated301, %r68.7.relocated304)
  %r2636 = or i64 %r2635311, 9222527611924643840
  %r2637 = bitcast i64 %r2636 to double
  %rs4gc.b71 = bitcast double %r2637 to i64
  %rs4gc.s71 = inttoptr i64 %rs4gc.b71 to ptr addrspace(1)
  br label %apush.merge.363

apush.merge.363:                                  ; preds = %apush.barrier.done.367, %apush.realloc.362, %apush.fwd.357
  %.2951 = phi ptr addrspace(1) [ %r68.7.relocated309, %apush.fwd.357 ], [ %r68.7.relocated304, %apush.barrier.done.367 ], [ %r68.7.relocated314, %apush.realloc.362 ]
  %.2946 = phi ptr addrspace(1) [ %r68.7.base.relocated308, %apush.fwd.357 ], [ %r68.7.base.relocated301, %apush.barrier.done.367 ], [ %r68.7.base.relocated313, %apush.realloc.362 ]
  %.25 = phi ptr addrspace(1) [ %rs4gc.s19.relocated307, %apush.fwd.357 ], [ %rs4gc.s19.relocated300, %apush.barrier.done.367 ], [ %rs4gc.s19.relocated312, %apush.realloc.362 ]
  %r2448.1.base = phi ptr addrspace(1) [ %rs4gc.s70, %apush.fwd.357 ], [ %r2448.0.base.relocated302, %apush.barrier.done.367 ], [ %rs4gc.s71, %apush.realloc.362 ], !is_base_value !0
  %r2448.1 = phi ptr addrspace(1) [ %rs4gc.s70, %apush.fwd.357 ], [ %r2448.0.relocated303, %apush.barrier.done.367 ], [ %rs4gc.s71, %apush.realloc.362 ]
  %r2638 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r2639 = icmp ne i32 %r2638, 0
  br i1 %r2639, label %gcpoll.368, label %gcpoll.done.369

apush.pointer_layout.bookkeeping.364:             ; preds = %apush.inbounds.361
  call void @js_string_addref_if_heap_string(double %r2549299) #7
  call void @js_gc_note_slot_layout(i64 %r2593, i32 %r2614, i64 %r2550) #7
  call void @js_array_note_numeric_write(i64 %r2593, i64 %r2550) #7
  br label %apush.pointer_layout.done.365

apush.pointer_layout.done.365:                    ; preds = %apush.pointer_layout.bookkeeping.364, %apush.inbounds.361
  %r2625 = sub i64 %r2593, 7
  %r2626 = inttoptr i64 %r2625 to ptr
  %r2627 = load i8, ptr %r2626, align 1
  %r2628 = and i8 %r2627, 32
  %r2629 = icmp ne i8 %r2628, 0
  %r2630 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2631 = icmp ne i32 %r2630, 0
  %r2632 = or i1 %r2629, %r2631
  br i1 %r2632, label %apush.barrier.366, label %apush.barrier.done.367

apush.barrier.366:                                ; preds = %apush.pointer_layout.done.365
  call void @js_write_barrier_slot_validated_parent(i64 %r2593, i64 %r2618, i64 %r2550) #7
  br label %apush.barrier.done.367

apush.barrier.done.367:                           ; preds = %apush.barrier.366, %apush.pointer_layout.done.365
  %r2633 = add i32 %r2614, 1
  %r2634 = inttoptr i64 %r2593 to ptr
  store i32 %r2633, ptr %r2634, align 4
  br label %apush.merge.363

gcpoll.368:                                       ; preds = %apush.merge.363
  %statepoint_token315 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r2448.1.base, ptr addrspace(1) %r2448.1, ptr addrspace(1) %.25, ptr addrspace(1) %.2946, ptr addrspace(1) %.2951) ]
  %r2448.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token315, i32 0, i32 0) ; (%r2448.1.base, %r2448.1.base)
  %r2448.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token315, i32 0, i32 1) ; (%r2448.1.base, %r2448.1)
  %rs4gc.s19.relocated316 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token315, i32 2, i32 2) ; (%.25, %.25)
  %r68.7.base.relocated317 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token315, i32 3, i32 3) ; (%.2946, %.2946)
  %r68.7.relocated318 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token315, i32 3, i32 4) ; (%.2946, %.2951)
  br label %gcpoll.done.369

gcpoll.done.369:                                  ; preds = %gcpoll.368, %apush.merge.363
  %.0957 = phi ptr addrspace(1) [ %r2448.1.relocated, %gcpoll.368 ], [ %r2448.1, %apush.merge.363 ]
  %.0956 = phi ptr addrspace(1) [ %r2448.1.base.relocated, %gcpoll.368 ], [ %r2448.1.base, %apush.merge.363 ]
  %.3952 = phi ptr addrspace(1) [ %r68.7.relocated318, %gcpoll.368 ], [ %.2951, %apush.merge.363 ]
  %.3947 = phi ptr addrspace(1) [ %r68.7.base.relocated317, %gcpoll.368 ], [ %.2946, %apush.merge.363 ]
  %.26 = phi ptr addrspace(1) [ %rs4gc.s19.relocated316, %gcpoll.368 ], [ %.25, %apush.merge.363 ]
  br label %for.update.348

if.else.371:                                      ; preds = %for.exit.349
  br label %if.merge.372

if.merge.372:                                     ; preds = %if.else.371
  br label %if.else.385

if.else.385:                                      ; preds = %if.merge.372
  br label %if.merge.386

if.merge.386:                                     ; preds = %if.else.385
  br label %if.else.399

if.else.399:                                      ; preds = %if.merge.386
  br label %if.merge.400

if.merge.400:                                     ; preds = %if.else.399
  br label %if.then.412

if.then.412:                                      ; preds = %if.merge.400
  %r2923 = load double, ptr @test_json_warm_unique_keys_ts_.str.14.handle, align 8
  %r2924 = bitcast double %r2923 to i64
  %r2925.rs4i = ptrtoint ptr addrspace(1) %r2448.0 to i64
  %r2925.rs4o = call i64 asm "", "=r,0"(i64 %r2925.rs4i) #7
  %r2925 = bitcast i64 %r2925.rs4o to double
  %r2926 = bitcast double %r2925 to i64
  %r2927 = and i64 %r2926, 281474976710655
  %r2928 = sub nsw i64 %r2927, 8
  %r2929 = inttoptr i64 %r2928 to ptr
  %r2930 = load i8, ptr %r2929, align 1
  %r2931 = icmp ne i8 %r2930, 1
  %r2932 = sub nsw i64 %r2927, 7
  %r2933 = inttoptr i64 %r2932 to ptr
  %r2934 = load i8, ptr %r2933, align 1
  %r2935 = and i8 %r2934, -128
  %r2936 = icmp ne i8 %r2935, 0
  %r2937 = or i1 %r2931, %r2936
  br i1 %r2936, label %apush.fwd.415, label %apush.elements.416

if.merge.414:                                     ; preds = %apush.merge.421
  %r3012 = load double, ptr @test_json_warm_unique_keys_ts_.str.15.handle, align 8
  %r3013.rs4i = ptrtoint ptr addrspace(1) %r2448.9 to i64
  %r3013.rs4o = call i64 asm "", "=r,0"(i64 %r3013.rs4i) #7
  %r3013 = bitcast i64 %r3013.rs4o to double
  %r3014 = load double, ptr @test_json_warm_unique_keys_ts_.str.16.handle, align 8
  %r3015 = bitcast double %r3013 to i64
  %r3016 = and i64 %r3015, 281474976710655
  %statepoint_token319 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_join_value, i32 2, i32 0, i64 %r3016, double %r3014, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.27, ptr addrspace(1) %.4948, ptr addrspace(1) %.4953) ]
  %r3017320 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token319)
  %rs4gc.s19.relocated321 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token319, i32 0, i32 0) ; (%.27, %.27)
  %r68.7.base.relocated322 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token319, i32 1, i32 1) ; (%.4948, %.4948)
  %r68.7.relocated323 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token319, i32 1, i32 2) ; (%.4948, %.4953)
  %r3018 = or i64 %r3017320, 9223090561878065152
  %r3019 = bitcast i64 %r3018 to double
  %r3020 = load double, ptr @test_json_warm_unique_keys_ts_.str.17.handle, align 8
  %r3021 = load double, ptr @test_json_warm_unique_keys_ts_.str.15.handle, align 8
  %r3023 = getelementptr double, ptr %r3022, i64 0
  store double %r3021, ptr %r3023, align 8
  %r3024 = getelementptr double, ptr %r3022, i64 1
  store double %r3019, ptr %r3024, align 8
  %r3025 = getelementptr double, ptr %r3022, i64 2
  store double %r3020, ptr %r3025, align 8
  %r3026 = ptrtoint ptr %r3022 to i64
  %statepoint_token324 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r3026, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated321, ptr addrspace(1) %r68.7.base.relocated322, ptr addrspace(1) %r68.7.relocated323) ]
  %r3027325 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token324)
  %rs4gc.s19.relocated326 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token324, i32 0, i32 0) ; (%rs4gc.s19.relocated321, %rs4gc.s19.relocated321)
  %r68.7.base.relocated327 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token324, i32 1, i32 1) ; (%r68.7.base.relocated322, %r68.7.base.relocated322)
  %r68.7.relocated328 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token324, i32 1, i32 2) ; (%r68.7.base.relocated322, %r68.7.relocated323)
  %r3028 = or i64 %r3027325, 9223090561878065152
  %r3029 = bitcast i64 %r3028 to double
  %r3030 = bitcast i64 %r3028 to double
  %r3031.rs4i = ptrtoint ptr addrspace(1) %r68.7.relocated328 to i64
  %r3031.rs4o = call i64 asm "", "=r,0"(i64 %r3031.rs4i) #7
  %r3031 = bitcast i64 %r3031.rs4o to double
  %r3032 = bitcast double %r3031 to i64
  %r3033 = and i64 %r3032, 281474976710655
  %r3034 = sub nsw i64 %r3033, 8
  %r3035 = inttoptr i64 %r3034 to ptr
  %r3036 = load i8, ptr %r3035, align 1
  %r3037 = icmp ne i8 %r3036, 1
  %r3038 = sub nsw i64 %r3033, 7
  %r3039 = inttoptr i64 %r3038 to ptr
  %r3040 = load i8, ptr %r3039, align 1
  %r3041 = and i8 %r3040, -128
  %r3042 = icmp ne i8 %r3041, 0
  %r3043 = or i1 %r3037, %r3042
  br i1 %r3042, label %apush.fwd.426, label %apush.elements.427

apush.fwd.415:                                    ; preds = %apush.elements.check.417, %if.then.412
  %statepoint_token329 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r2927, double %r2923, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0949, ptr addrspace(1) %.0944, ptr addrspace(1) %.23) ]
  %r2964330 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token329)
  %r68.7.relocated331 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 1, i32 0) ; (%.0944, %.0949)
  %r68.7.base.relocated332 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 1, i32 1) ; (%.0944, %.0944)
  %rs4gc.s19.relocated333 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 2, i32 2) ; (%.23, %.23)
  %r2965 = or i64 %r2964330, 9222527611924643840
  %r2966 = bitcast i64 %r2965 to double
  %rs4gc.b78 = bitcast double %r2966 to i64
  %rs4gc.s78 = inttoptr i64 %rs4gc.b78 to ptr addrspace(1)
  br label %apush.merge.421

apush.elements.416:                               ; preds = %if.then.412
  %r2939 = add nuw nsw i64 %r2927, 8
  %r2940 = inttoptr i64 %r2939 to ptr
  %r2941 = load i64, ptr %r2940, align 8
  %r2942 = icmp ne i64 %r2941, 0
  %r2943 = icmp eq i8 %r2930, 2
  %r2944 = and i1 %r2943, %r2942
  %r2945 = select i1 %r2944, i64 %r2941, i64 %r2927
  %r2946 = inttoptr i64 %r2945 to ptr
  %r2947 = getelementptr i64, ptr %r2946, i64 12
  %r2948 = load i64, ptr %r2947, align 8
  %r2949 = icmp ne i64 %r2948, 0
  %r2950 = and i1 %r2944, %r2949
  %r2951 = select i1 %r2950, i64 %r2948, i64 %r2927
  %r2938 = icmp eq i8 %r2930, 1
  br i1 %r2938, label %apush.nofwd.418, label %apush.elements.check.417

apush.elements.check.417:                         ; preds = %apush.elements.416
  %r2952 = icmp ne i64 %r2951, 0
  %r2953 = sub i64 %r2951, 8
  %r2954 = inttoptr i64 %r2953 to ptr
  %r2955 = load i8, ptr %r2954, align 1
  %r2956 = icmp eq i8 %r2955, 1
  %r2957 = sub i64 %r2951, 7
  %r2958 = inttoptr i64 %r2957 to ptr
  %r2959 = load i8, ptr %r2958, align 1
  %r2960 = and i8 %r2959, -128
  %r2961 = icmp eq i8 %r2960, 0
  %r2962 = and i1 %r2952, %r2956
  %r2963 = and i1 %r2962, %r2961
  br i1 %r2963, label %apush.nofwd.418, label %apush.fwd.415

apush.nofwd.418:                                  ; preds = %apush.elements.check.417, %apush.elements.416
  %r2967 = phi i64 [ %r2927, %apush.elements.416 ], [ %r2951, %apush.elements.check.417 ]
  %r2968 = sub i64 %r2967, 6
  %r2969 = inttoptr i64 %r2968 to ptr
  %r2970 = load i16, ptr %r2969, align 2
  %r2971 = and i16 %r2970, 1031
  %r2972 = icmp eq i16 %r2971, 0
  %r2973 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2974 = icmp eq i8 %r2973, 0
  %r2975 = and i1 %r2972, %r2974
  %r2976 = icmp ult i64 %r2967, 4096
  %r2977 = inttoptr i64 %r2967 to ptr
  %r2978 = select i1 %r2976, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r2977
  %r2979 = load i32, ptr %r2978, align 4
  %r2980 = add i64 %r2967, 4
  %r2981 = inttoptr i64 %r2980 to ptr
  %r2982 = load i32, ptr %r2981, align 4
  %r2983 = icmp ult i32 %r2979, %r2982
  %r2984 = and i1 %r2983, %r2975
  br i1 %r2984, label %apush.inbounds.419, label %apush.realloc.420

apush.inbounds.419:                               ; preds = %apush.nofwd.418
  %r2985 = icmp ult i64 %r2967, 4096
  %r2986 = inttoptr i64 %r2967 to ptr
  %r2987 = select i1 %r2985, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r2986
  %r2988 = load i32, ptr %r2987, align 4
  %r2989 = zext i32 %r2988 to i64
  %r2990 = shl nuw nsw i64 %r2989, 3
  %r2991 = add nuw nsw i64 %r2990, 8
  %r2992 = add i64 %r2967, %r2991
  %r2993 = inttoptr i64 %r2992 to ptr
  store double %r2923, ptr %r2993, align 8
  %r2994 = lshr i64 %r2924, 48
  %r2995 = icmp eq i64 %r2994, 32765
  %r2996 = and i16 %r2970, -1920
  %r2997 = icmp eq i16 %r2996, -24576
  %r2998 = and i1 %r2995, %r2997
  br i1 %r2998, label %apush.pointer_layout.done.423, label %apush.pointer_layout.bookkeeping.422

apush.realloc.420:                                ; preds = %apush.nofwd.418
  %statepoint_token334 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r2927, double %r2923, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0949, ptr addrspace(1) %.0944, ptr addrspace(1) %.23) ]
  %r3009335 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token334)
  %r68.7.relocated336 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token334, i32 1, i32 0) ; (%.0944, %.0949)
  %r68.7.base.relocated337 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token334, i32 1, i32 1) ; (%.0944, %.0944)
  %rs4gc.s19.relocated338 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token334, i32 2, i32 2) ; (%.23, %.23)
  %r3010 = or i64 %r3009335, 9222527611924643840
  %r3011 = bitcast i64 %r3010 to double
  %rs4gc.b79 = bitcast double %r3011 to i64
  %rs4gc.s79 = inttoptr i64 %rs4gc.b79 to ptr addrspace(1)
  br label %apush.merge.421

apush.merge.421:                                  ; preds = %apush.barrier.done.425, %apush.realloc.420, %apush.fwd.415
  %.4953 = phi ptr addrspace(1) [ %r68.7.relocated331, %apush.fwd.415 ], [ %.0949, %apush.barrier.done.425 ], [ %r68.7.relocated336, %apush.realloc.420 ]
  %.4948 = phi ptr addrspace(1) [ %r68.7.base.relocated332, %apush.fwd.415 ], [ %.0944, %apush.barrier.done.425 ], [ %r68.7.base.relocated337, %apush.realloc.420 ]
  %.27 = phi ptr addrspace(1) [ %rs4gc.s19.relocated333, %apush.fwd.415 ], [ %.23, %apush.barrier.done.425 ], [ %rs4gc.s19.relocated338, %apush.realloc.420 ]
  %r2448.9 = phi ptr addrspace(1) [ %rs4gc.s78, %apush.fwd.415 ], [ %r2448.0, %apush.barrier.done.425 ], [ %rs4gc.s79, %apush.realloc.420 ]
  br label %if.merge.414

apush.pointer_layout.bookkeeping.422:             ; preds = %apush.inbounds.419
  call void @js_string_addref_if_heap_string(double %r2923) #7
  %r5768 = load double, ptr @test_json_warm_unique_keys_ts_.str.14.handle, align 8
  %r5769 = bitcast double %r5768 to i64
  call void @js_gc_note_slot_layout(i64 %r2967, i32 %r2988, i64 %r5769) #7
  %r5766 = load double, ptr @test_json_warm_unique_keys_ts_.str.14.handle, align 8
  %r5767 = bitcast double %r5766 to i64
  call void @js_array_note_numeric_write(i64 %r2967, i64 %r5767) #7
  br label %apush.pointer_layout.done.423

apush.pointer_layout.done.423:                    ; preds = %apush.pointer_layout.bookkeeping.422, %apush.inbounds.419
  %r2999 = sub i64 %r2967, 7
  %r3000 = inttoptr i64 %r2999 to ptr
  %r3001 = load i8, ptr %r3000, align 1
  %r3002 = and i8 %r3001, 32
  %r3003 = icmp ne i8 %r3002, 0
  %r3004 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3005 = icmp ne i32 %r3004, 0
  %r3006 = or i1 %r3003, %r3005
  br i1 %r3006, label %apush.barrier.424, label %apush.barrier.done.425

apush.barrier.424:                                ; preds = %apush.pointer_layout.done.423
  %r5764 = load double, ptr @test_json_warm_unique_keys_ts_.str.14.handle, align 8
  %r5765 = bitcast double %r5764 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r2967, i64 %r2992, i64 %r5765) #7
  br label %apush.barrier.done.425

apush.barrier.done.425:                           ; preds = %apush.barrier.424, %apush.pointer_layout.done.423
  %r3007 = add i32 %r2988, 1
  %r3008 = inttoptr i64 %r2967 to ptr
  store i32 %r3007, ptr %r3008, align 4
  br label %apush.merge.421

apush.fwd.426:                                    ; preds = %apush.elements.check.428, %if.merge.414
  %statepoint_token339 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r3033, double %r3030, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated326) ]
  %r3070340 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token339)
  %rs4gc.s19.relocated341 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token339, i32 0, i32 0) ; (%rs4gc.s19.relocated326, %rs4gc.s19.relocated326)
  %r3071 = or i64 %r3070340, 9222527611924643840
  %r3072 = bitcast i64 %r3071 to double
  %rs4gc.b80 = bitcast double %r3072 to i64
  %rs4gc.s80 = inttoptr i64 %rs4gc.b80 to ptr addrspace(1)
  br label %apush.merge.432

apush.elements.427:                               ; preds = %if.merge.414
  %r3045 = add nuw nsw i64 %r3033, 8
  %r3046 = inttoptr i64 %r3045 to ptr
  %r3047 = load i64, ptr %r3046, align 8
  %r3048 = icmp ne i64 %r3047, 0
  %r3049 = icmp eq i8 %r3036, 2
  %r3050 = and i1 %r3049, %r3048
  %r3051 = select i1 %r3050, i64 %r3047, i64 %r3033
  %r3052 = inttoptr i64 %r3051 to ptr
  %r3053 = getelementptr i64, ptr %r3052, i64 12
  %r3054 = load i64, ptr %r3053, align 8
  %r3055 = icmp ne i64 %r3054, 0
  %r3056 = and i1 %r3050, %r3055
  %r3057 = select i1 %r3056, i64 %r3054, i64 %r3033
  %r3044 = icmp eq i8 %r3036, 1
  br i1 %r3044, label %apush.nofwd.429, label %apush.elements.check.428

apush.elements.check.428:                         ; preds = %apush.elements.427
  %r3058 = icmp ne i64 %r3057, 0
  %r3059 = sub i64 %r3057, 8
  %r3060 = inttoptr i64 %r3059 to ptr
  %r3061 = load i8, ptr %r3060, align 1
  %r3062 = icmp eq i8 %r3061, 1
  %r3063 = sub i64 %r3057, 7
  %r3064 = inttoptr i64 %r3063 to ptr
  %r3065 = load i8, ptr %r3064, align 1
  %r3066 = and i8 %r3065, -128
  %r3067 = icmp eq i8 %r3066, 0
  %r3068 = and i1 %r3058, %r3062
  %r3069 = and i1 %r3068, %r3067
  br i1 %r3069, label %apush.nofwd.429, label %apush.fwd.426

apush.nofwd.429:                                  ; preds = %apush.elements.check.428, %apush.elements.427
  %r3073 = phi i64 [ %r3033, %apush.elements.427 ], [ %r3057, %apush.elements.check.428 ]
  %r3074 = sub i64 %r3073, 6
  %r3075 = inttoptr i64 %r3074 to ptr
  %r3076 = load i16, ptr %r3075, align 2
  %r3077 = and i16 %r3076, 1031
  %r3078 = icmp eq i16 %r3077, 0
  %r3079 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r3080 = icmp eq i8 %r3079, 0
  %r3081 = and i1 %r3078, %r3080
  %r3082 = icmp ult i64 %r3073, 4096
  %r3083 = inttoptr i64 %r3073 to ptr
  %r3084 = select i1 %r3082, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r3083
  %r3085 = load i32, ptr %r3084, align 4
  %r3086 = add i64 %r3073, 4
  %r3087 = inttoptr i64 %r3086 to ptr
  %r3088 = load i32, ptr %r3087, align 4
  %r3089 = icmp ult i32 %r3085, %r3088
  %r3090 = and i1 %r3089, %r3081
  br i1 %r3090, label %apush.inbounds.430, label %apush.realloc.431

apush.inbounds.430:                               ; preds = %apush.nofwd.429
  %r3091 = icmp ult i64 %r3073, 4096
  %r3092 = inttoptr i64 %r3073 to ptr
  %r3093 = select i1 %r3091, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r3092
  %r3094 = load i32, ptr %r3093, align 4
  %r3095 = zext i32 %r3094 to i64
  %r3096 = shl nuw nsw i64 %r3095, 3
  %r3097 = add nuw nsw i64 %r3096, 8
  %r3098 = add i64 %r3073, %r3097
  %r3099 = inttoptr i64 %r3098 to ptr
  store double %r3030, ptr %r3099, align 8
  %r3100 = lshr i64 %r3028, 48
  %r3102 = and i16 %r3076, -1920
  %r3103 = icmp eq i16 %r3102, -24576
  br label %apush.pointer_layout.bookkeeping.433

apush.realloc.431:                                ; preds = %apush.nofwd.429
  %statepoint_token342 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r3033, double %r3030, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s19.relocated326) ]
  %r3115343 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token342)
  %rs4gc.s19.relocated344 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 0, i32 0) ; (%rs4gc.s19.relocated326, %rs4gc.s19.relocated326)
  %r3116 = or i64 %r3115343, 9222527611924643840
  %r3117 = bitcast i64 %r3116 to double
  %rs4gc.b81 = bitcast double %r3117 to i64
  %rs4gc.s81 = inttoptr i64 %rs4gc.b81 to ptr addrspace(1)
  br label %apush.merge.432

apush.merge.432:                                  ; preds = %apush.barrier.done.436, %apush.realloc.431, %apush.fwd.426
  %.28 = phi ptr addrspace(1) [ %rs4gc.s19.relocated341, %apush.fwd.426 ], [ %rs4gc.s19.relocated326, %apush.barrier.done.436 ], [ %rs4gc.s19.relocated344, %apush.realloc.431 ]
  %r68.8.base = phi ptr addrspace(1) [ %rs4gc.s80, %apush.fwd.426 ], [ %r68.7.base.relocated327, %apush.barrier.done.436 ], [ %rs4gc.s81, %apush.realloc.431 ], !is_base_value !0
  %r68.8 = phi ptr addrspace(1) [ %rs4gc.s80, %apush.fwd.426 ], [ %r68.7.relocated328, %apush.barrier.done.436 ], [ %rs4gc.s81, %apush.realloc.431 ]
  %r3118 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r3119 = icmp ne i32 %r3118, 0
  br i1 %r3119, label %gcpoll.437, label %gcpoll.done.438

apush.pointer_layout.bookkeeping.433:             ; preds = %apush.inbounds.430
  call void @js_string_addref_if_heap_string(double %r3030) #7
  call void @js_gc_note_slot_layout(i64 %r3073, i32 %r3094, i64 %r3028) #7
  call void @js_array_note_numeric_write(i64 %r3073, i64 %r3028) #7
  br label %apush.pointer_layout.done.434

apush.pointer_layout.done.434:                    ; preds = %apush.pointer_layout.bookkeeping.433
  %r3105 = sub i64 %r3073, 7
  %r3106 = inttoptr i64 %r3105 to ptr
  %r3107 = load i8, ptr %r3106, align 1
  %r3108 = and i8 %r3107, 32
  %r3109 = icmp ne i8 %r3108, 0
  %r3110 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3111 = icmp ne i32 %r3110, 0
  %r3112 = or i1 %r3109, %r3111
  br i1 %r3112, label %apush.barrier.435, label %apush.barrier.done.436

apush.barrier.435:                                ; preds = %apush.pointer_layout.done.434
  call void @js_write_barrier_slot_validated_parent(i64 %r3073, i64 %r3098, i64 %r3028) #7
  br label %apush.barrier.done.436

apush.barrier.done.436:                           ; preds = %apush.barrier.435, %apush.pointer_layout.done.434
  %r3113 = add i32 %r3094, 1
  %r3114 = inttoptr i64 %r3073 to ptr
  store i32 %r3113, ptr %r3114, align 4
  br label %apush.merge.432

gcpoll.437:                                       ; preds = %apush.merge.432
  %statepoint_token345 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r68.8.base, ptr addrspace(1) %r68.8, ptr addrspace(1) %.28) ]
  %r68.8.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token345, i32 0, i32 0) ; (%r68.8.base, %r68.8.base)
  %r68.8.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token345, i32 0, i32 1) ; (%r68.8.base, %r68.8)
  %rs4gc.s19.relocated346 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token345, i32 2, i32 2) ; (%.28, %.28)
  br label %gcpoll.done.438

gcpoll.done.438:                                  ; preds = %gcpoll.437, %apush.merge.432
  %.0959 = phi ptr addrspace(1) [ %r68.8.relocated, %gcpoll.437 ], [ %r68.8, %apush.merge.432 ]
  %.0958 = phi ptr addrspace(1) [ %r68.8.base.relocated, %gcpoll.437 ], [ %r68.8.base, %apush.merge.432 ]
  %.29 = phi ptr addrspace(1) [ %rs4gc.s19.relocated346, %gcpoll.437 ], [ %.28, %apush.merge.432 ]
  br label %for.update.19

apush.fwd.439:                                    ; preds = %apush.elements.check.441, %for.exit.20
  %statepoint_token347 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r3128, double %r3124, i32 0, i32 0)
  %r3165348 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token347)
  %r3166 = or i64 %r3165348, 9222527611924643840
  %r3167 = bitcast i64 %r3166 to double
  %rs4gc.b82 = bitcast double %r3167 to i64
  %rs4gc.s82 = inttoptr i64 %rs4gc.b82 to ptr addrspace(1)
  br label %apush.merge.445

apush.elements.440:                               ; preds = %for.exit.20
  %r3140 = add nuw nsw i64 %r3128, 8
  %r3141 = inttoptr i64 %r3140 to ptr
  %r3142 = load i64, ptr %r3141, align 8
  %r3143 = icmp ne i64 %r3142, 0
  %r3144 = icmp eq i8 %r3131, 2
  %r3145 = and i1 %r3144, %r3143
  %r3146 = select i1 %r3145, i64 %r3142, i64 %r3128
  %r3147 = inttoptr i64 %r3146 to ptr
  %r3148 = getelementptr i64, ptr %r3147, i64 12
  %r3149 = load i64, ptr %r3148, align 8
  %r3150 = icmp ne i64 %r3149, 0
  %r3151 = and i1 %r3145, %r3150
  %r3152 = select i1 %r3151, i64 %r3149, i64 %r3128
  %r3139 = icmp eq i8 %r3131, 1
  br i1 %r3139, label %apush.nofwd.442, label %apush.elements.check.441

apush.elements.check.441:                         ; preds = %apush.elements.440
  %r3153 = icmp ne i64 %r3152, 0
  %r3154 = sub i64 %r3152, 8
  %r3155 = inttoptr i64 %r3154 to ptr
  %r3156 = load i8, ptr %r3155, align 1
  %r3157 = icmp eq i8 %r3156, 1
  %r3158 = sub i64 %r3152, 7
  %r3159 = inttoptr i64 %r3158 to ptr
  %r3160 = load i8, ptr %r3159, align 1
  %r3161 = and i8 %r3160, -128
  %r3162 = icmp eq i8 %r3161, 0
  %r3163 = and i1 %r3153, %r3157
  %r3164 = and i1 %r3163, %r3162
  br i1 %r3164, label %apush.nofwd.442, label %apush.fwd.439

apush.nofwd.442:                                  ; preds = %apush.elements.check.441, %apush.elements.440
  %r3168 = phi i64 [ %r3128, %apush.elements.440 ], [ %r3152, %apush.elements.check.441 ]
  %r3169 = sub i64 %r3168, 6
  %r3170 = inttoptr i64 %r3169 to ptr
  %r3171 = load i16, ptr %r3170, align 2
  %r3172 = and i16 %r3171, 1031
  %r3173 = icmp eq i16 %r3172, 0
  %r3174 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r3175 = icmp eq i8 %r3174, 0
  %r3176 = and i1 %r3173, %r3175
  %r3177 = icmp ult i64 %r3168, 4096
  %r3178 = inttoptr i64 %r3168 to ptr
  %r3179 = select i1 %r3177, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r3178
  %r3180 = load i32, ptr %r3179, align 4
  %r3181 = add i64 %r3168, 4
  %r3182 = inttoptr i64 %r3181 to ptr
  %r3183 = load i32, ptr %r3182, align 4
  %r3184 = icmp ult i32 %r3180, %r3183
  %r3185 = and i1 %r3184, %r3176
  br i1 %r3185, label %apush.inbounds.443, label %apush.realloc.444

apush.inbounds.443:                               ; preds = %apush.nofwd.442
  %r3186 = icmp ult i64 %r3168, 4096
  %r3187 = inttoptr i64 %r3168 to ptr
  %r3188 = select i1 %r3186, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r3187
  %r3189 = load i32, ptr %r3188, align 4
  %r3190 = zext i32 %r3189 to i64
  %r3191 = shl nuw nsw i64 %r3190, 3
  %r3192 = add nuw nsw i64 %r3191, 8
  %r3193 = add i64 %r3168, %r3192
  %r3194 = inttoptr i64 %r3193 to ptr
  store double %r3124, ptr %r3194, align 8
  %r3195 = lshr i64 %r3125, 48
  %r3196 = icmp eq i64 %r3195, 32765
  %r3197 = and i16 %r3171, -1920
  %r3198 = icmp eq i16 %r3197, -24576
  %r3199 = and i1 %r3196, %r3198
  br i1 %r3199, label %apush.pointer_layout.done.447, label %apush.pointer_layout.bookkeeping.446

apush.realloc.444:                                ; preds = %apush.nofwd.442
  %statepoint_token349 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r3128, double %r3124, i32 0, i32 0)
  %r3210350 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token349)
  %r3211 = or i64 %r3210350, 9222527611924643840
  %r3212 = bitcast i64 %r3211 to double
  %rs4gc.b83 = bitcast double %r3212 to i64
  %rs4gc.s83 = inttoptr i64 %rs4gc.b83 to ptr addrspace(1)
  br label %apush.merge.445

apush.merge.445:                                  ; preds = %apush.barrier.done.449, %apush.realloc.444, %apush.fwd.439
  %r68.9 = phi ptr addrspace(1) [ %rs4gc.s82, %apush.fwd.439 ], [ %r68.0, %apush.barrier.done.449 ], [ %rs4gc.s83, %apush.realloc.444 ]
  %r3213 = load double, ptr @test_json_warm_unique_keys_ts_.str.19.handle, align 8
  %r3214 = bitcast double %r3213 to i64
  %r3215.rs4i = ptrtoint ptr addrspace(1) %r68.9 to i64
  %r3215.rs4o = call i64 asm "", "=r,0"(i64 %r3215.rs4i) #7
  %r3215 = bitcast i64 %r3215.rs4o to double
  %r3216 = bitcast double %r3215 to i64
  %r3217 = and i64 %r3216, 281474976710655
  %r3218 = sub nsw i64 %r3217, 8
  %r3219 = inttoptr i64 %r3218 to ptr
  %r3220 = load i8, ptr %r3219, align 1
  %r3221 = icmp ne i8 %r3220, 1
  %r3222 = sub nsw i64 %r3217, 7
  %r3223 = inttoptr i64 %r3222 to ptr
  %r3224 = load i8, ptr %r3223, align 1
  %r3225 = and i8 %r3224, -128
  %r3226 = icmp ne i8 %r3225, 0
  %r3227 = or i1 %r3221, %r3226
  br i1 %r3226, label %apush.fwd.450, label %apush.elements.451

apush.pointer_layout.bookkeeping.446:             ; preds = %apush.inbounds.443
  call void @js_string_addref_if_heap_string(double %r3124) #7
  %r5762 = load double, ptr @test_json_warm_unique_keys_ts_.str.18.handle, align 8
  %r5763 = bitcast double %r5762 to i64
  call void @js_gc_note_slot_layout(i64 %r3168, i32 %r3189, i64 %r5763) #7
  %r5760 = load double, ptr @test_json_warm_unique_keys_ts_.str.18.handle, align 8
  %r5761 = bitcast double %r5760 to i64
  call void @js_array_note_numeric_write(i64 %r3168, i64 %r5761) #7
  br label %apush.pointer_layout.done.447

apush.pointer_layout.done.447:                    ; preds = %apush.pointer_layout.bookkeeping.446, %apush.inbounds.443
  %r3200 = sub i64 %r3168, 7
  %r3201 = inttoptr i64 %r3200 to ptr
  %r3202 = load i8, ptr %r3201, align 1
  %r3203 = and i8 %r3202, 32
  %r3204 = icmp ne i8 %r3203, 0
  %r3205 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3206 = icmp ne i32 %r3205, 0
  %r3207 = or i1 %r3204, %r3206
  br i1 %r3207, label %apush.barrier.448, label %apush.barrier.done.449

apush.barrier.448:                                ; preds = %apush.pointer_layout.done.447
  %r5758 = load double, ptr @test_json_warm_unique_keys_ts_.str.18.handle, align 8
  %r5759 = bitcast double %r5758 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r3168, i64 %r3193, i64 %r5759) #7
  br label %apush.barrier.done.449

apush.barrier.done.449:                           ; preds = %apush.barrier.448, %apush.pointer_layout.done.447
  %r3208 = add i32 %r3189, 1
  %r3209 = inttoptr i64 %r3168 to ptr
  store i32 %r3208, ptr %r3209, align 4
  br label %apush.merge.445

apush.fwd.450:                                    ; preds = %apush.elements.check.452, %apush.merge.445
  %statepoint_token351 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r3217, double %r3213, i32 0, i32 0)
  %r3254352 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token351)
  %r3255 = or i64 %r3254352, 9222527611924643840
  %r3256 = bitcast i64 %r3255 to double
  %rs4gc.b84 = bitcast double %r3256 to i64
  %rs4gc.s84 = inttoptr i64 %rs4gc.b84 to ptr addrspace(1)
  br label %apush.merge.456

apush.elements.451:                               ; preds = %apush.merge.445
  %r3229 = add nuw nsw i64 %r3217, 8
  %r3230 = inttoptr i64 %r3229 to ptr
  %r3231 = load i64, ptr %r3230, align 8
  %r3232 = icmp ne i64 %r3231, 0
  %r3233 = icmp eq i8 %r3220, 2
  %r3234 = and i1 %r3233, %r3232
  %r3235 = select i1 %r3234, i64 %r3231, i64 %r3217
  %r3236 = inttoptr i64 %r3235 to ptr
  %r3237 = getelementptr i64, ptr %r3236, i64 12
  %r3238 = load i64, ptr %r3237, align 8
  %r3239 = icmp ne i64 %r3238, 0
  %r3240 = and i1 %r3234, %r3239
  %r3241 = select i1 %r3240, i64 %r3238, i64 %r3217
  %r3228 = icmp eq i8 %r3220, 1
  br i1 %r3228, label %apush.nofwd.453, label %apush.elements.check.452

apush.elements.check.452:                         ; preds = %apush.elements.451
  %r3242 = icmp ne i64 %r3241, 0
  %r3243 = sub i64 %r3241, 8
  %r3244 = inttoptr i64 %r3243 to ptr
  %r3245 = load i8, ptr %r3244, align 1
  %r3246 = icmp eq i8 %r3245, 1
  %r3247 = sub i64 %r3241, 7
  %r3248 = inttoptr i64 %r3247 to ptr
  %r3249 = load i8, ptr %r3248, align 1
  %r3250 = and i8 %r3249, -128
  %r3251 = icmp eq i8 %r3250, 0
  %r3252 = and i1 %r3242, %r3246
  %r3253 = and i1 %r3252, %r3251
  br i1 %r3253, label %apush.nofwd.453, label %apush.fwd.450

apush.nofwd.453:                                  ; preds = %apush.elements.check.452, %apush.elements.451
  %r3257 = phi i64 [ %r3217, %apush.elements.451 ], [ %r3241, %apush.elements.check.452 ]
  %r3258 = sub i64 %r3257, 6
  %r3259 = inttoptr i64 %r3258 to ptr
  %r3260 = load i16, ptr %r3259, align 2
  %r3261 = and i16 %r3260, 1031
  %r3262 = icmp eq i16 %r3261, 0
  %r3263 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r3264 = icmp eq i8 %r3263, 0
  %r3265 = and i1 %r3262, %r3264
  %r3266 = icmp ult i64 %r3257, 4096
  %r3267 = inttoptr i64 %r3257 to ptr
  %r3268 = select i1 %r3266, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r3267
  %r3269 = load i32, ptr %r3268, align 4
  %r3270 = add i64 %r3257, 4
  %r3271 = inttoptr i64 %r3270 to ptr
  %r3272 = load i32, ptr %r3271, align 4
  %r3273 = icmp ult i32 %r3269, %r3272
  %r3274 = and i1 %r3273, %r3265
  br i1 %r3274, label %apush.inbounds.454, label %apush.realloc.455

apush.inbounds.454:                               ; preds = %apush.nofwd.453
  %r3275 = icmp ult i64 %r3257, 4096
  %r3276 = inttoptr i64 %r3257 to ptr
  %r3277 = select i1 %r3275, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r3276
  %r3278 = load i32, ptr %r3277, align 4
  %r3279 = zext i32 %r3278 to i64
  %r3280 = shl nuw nsw i64 %r3279, 3
  %r3281 = add nuw nsw i64 %r3280, 8
  %r3282 = add i64 %r3257, %r3281
  %r3283 = inttoptr i64 %r3282 to ptr
  store double %r3213, ptr %r3283, align 8
  %r3284 = lshr i64 %r3214, 48
  %r3285 = icmp eq i64 %r3284, 32765
  %r3286 = and i16 %r3260, -1920
  %r3287 = icmp eq i16 %r3286, -24576
  %r3288 = and i1 %r3285, %r3287
  br i1 %r3288, label %apush.pointer_layout.done.458, label %apush.pointer_layout.bookkeeping.457

apush.realloc.455:                                ; preds = %apush.nofwd.453
  %statepoint_token353 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r3217, double %r3213, i32 0, i32 0)
  %r3299354 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token353)
  %r3300 = or i64 %r3299354, 9222527611924643840
  %r3301 = bitcast i64 %r3300 to double
  %rs4gc.b85 = bitcast double %r3301 to i64
  %rs4gc.s85 = inttoptr i64 %rs4gc.b85 to ptr addrspace(1)
  br label %apush.merge.456

apush.merge.456:                                  ; preds = %apush.barrier.done.460, %apush.realloc.455, %apush.fwd.450
  %r68.10 = phi ptr addrspace(1) [ %rs4gc.s84, %apush.fwd.450 ], [ %r68.9, %apush.barrier.done.460 ], [ %rs4gc.s85, %apush.realloc.455 ]
  %r3302 = load double, ptr @test_json_warm_unique_keys_ts_.str.20.handle, align 8
  %r3303 = bitcast double %r3302 to i64
  %r3304.rs4i = ptrtoint ptr addrspace(1) %r68.10 to i64
  %r3304.rs4o = call i64 asm "", "=r,0"(i64 %r3304.rs4i) #7
  %r3304 = bitcast i64 %r3304.rs4o to double
  %r3305 = bitcast double %r3304 to i64
  %r3306 = and i64 %r3305, 281474976710655
  %r3307 = sub nsw i64 %r3306, 8
  %r3308 = inttoptr i64 %r3307 to ptr
  %r3309 = load i8, ptr %r3308, align 1
  %r3310 = icmp ne i8 %r3309, 1
  %r3311 = sub nsw i64 %r3306, 7
  %r3312 = inttoptr i64 %r3311 to ptr
  %r3313 = load i8, ptr %r3312, align 1
  %r3314 = and i8 %r3313, -128
  %r3315 = icmp ne i8 %r3314, 0
  %r3316 = or i1 %r3310, %r3315
  br i1 %r3315, label %apush.fwd.461, label %apush.elements.462

apush.pointer_layout.bookkeeping.457:             ; preds = %apush.inbounds.454
  call void @js_string_addref_if_heap_string(double %r3213) #7
  %r5756 = load double, ptr @test_json_warm_unique_keys_ts_.str.19.handle, align 8
  %r5757 = bitcast double %r5756 to i64
  call void @js_gc_note_slot_layout(i64 %r3257, i32 %r3278, i64 %r5757) #7
  %r5754 = load double, ptr @test_json_warm_unique_keys_ts_.str.19.handle, align 8
  %r5755 = bitcast double %r5754 to i64
  call void @js_array_note_numeric_write(i64 %r3257, i64 %r5755) #7
  br label %apush.pointer_layout.done.458

apush.pointer_layout.done.458:                    ; preds = %apush.pointer_layout.bookkeeping.457, %apush.inbounds.454
  %r3289 = sub i64 %r3257, 7
  %r3290 = inttoptr i64 %r3289 to ptr
  %r3291 = load i8, ptr %r3290, align 1
  %r3292 = and i8 %r3291, 32
  %r3293 = icmp ne i8 %r3292, 0
  %r3294 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3295 = icmp ne i32 %r3294, 0
  %r3296 = or i1 %r3293, %r3295
  br i1 %r3296, label %apush.barrier.459, label %apush.barrier.done.460

apush.barrier.459:                                ; preds = %apush.pointer_layout.done.458
  %r5752 = load double, ptr @test_json_warm_unique_keys_ts_.str.19.handle, align 8
  %r5753 = bitcast double %r5752 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r3257, i64 %r3282, i64 %r5753) #7
  br label %apush.barrier.done.460

apush.barrier.done.460:                           ; preds = %apush.barrier.459, %apush.pointer_layout.done.458
  %r3297 = add i32 %r3278, 1
  %r3298 = inttoptr i64 %r3257 to ptr
  store i32 %r3297, ptr %r3298, align 4
  br label %apush.merge.456

apush.fwd.461:                                    ; preds = %apush.elements.check.463, %apush.merge.456
  %statepoint_token355 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r3306, double %r3302, i32 0, i32 0)
  %r3343356 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token355)
  %r3344 = or i64 %r3343356, 9222527611924643840
  %r3345 = bitcast i64 %r3344 to double
  %rs4gc.b86 = bitcast double %r3345 to i64
  %rs4gc.s86 = inttoptr i64 %rs4gc.b86 to ptr addrspace(1)
  br label %apush.merge.467

apush.elements.462:                               ; preds = %apush.merge.456
  %r3318 = add nuw nsw i64 %r3306, 8
  %r3319 = inttoptr i64 %r3318 to ptr
  %r3320 = load i64, ptr %r3319, align 8
  %r3321 = icmp ne i64 %r3320, 0
  %r3322 = icmp eq i8 %r3309, 2
  %r3323 = and i1 %r3322, %r3321
  %r3324 = select i1 %r3323, i64 %r3320, i64 %r3306
  %r3325 = inttoptr i64 %r3324 to ptr
  %r3326 = getelementptr i64, ptr %r3325, i64 12
  %r3327 = load i64, ptr %r3326, align 8
  %r3328 = icmp ne i64 %r3327, 0
  %r3329 = and i1 %r3323, %r3328
  %r3330 = select i1 %r3329, i64 %r3327, i64 %r3306
  %r3317 = icmp eq i8 %r3309, 1
  br i1 %r3317, label %apush.nofwd.464, label %apush.elements.check.463

apush.elements.check.463:                         ; preds = %apush.elements.462
  %r3331 = icmp ne i64 %r3330, 0
  %r3332 = sub i64 %r3330, 8
  %r3333 = inttoptr i64 %r3332 to ptr
  %r3334 = load i8, ptr %r3333, align 1
  %r3335 = icmp eq i8 %r3334, 1
  %r3336 = sub i64 %r3330, 7
  %r3337 = inttoptr i64 %r3336 to ptr
  %r3338 = load i8, ptr %r3337, align 1
  %r3339 = and i8 %r3338, -128
  %r3340 = icmp eq i8 %r3339, 0
  %r3341 = and i1 %r3331, %r3335
  %r3342 = and i1 %r3341, %r3340
  br i1 %r3342, label %apush.nofwd.464, label %apush.fwd.461

apush.nofwd.464:                                  ; preds = %apush.elements.check.463, %apush.elements.462
  %r3346 = phi i64 [ %r3306, %apush.elements.462 ], [ %r3330, %apush.elements.check.463 ]
  %r3347 = sub i64 %r3346, 6
  %r3348 = inttoptr i64 %r3347 to ptr
  %r3349 = load i16, ptr %r3348, align 2
  %r3350 = and i16 %r3349, 1031
  %r3351 = icmp eq i16 %r3350, 0
  %r3352 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r3353 = icmp eq i8 %r3352, 0
  %r3354 = and i1 %r3351, %r3353
  %r3355 = icmp ult i64 %r3346, 4096
  %r3356 = inttoptr i64 %r3346 to ptr
  %r3357 = select i1 %r3355, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r3356
  %r3358 = load i32, ptr %r3357, align 4
  %r3359 = add i64 %r3346, 4
  %r3360 = inttoptr i64 %r3359 to ptr
  %r3361 = load i32, ptr %r3360, align 4
  %r3362 = icmp ult i32 %r3358, %r3361
  %r3363 = and i1 %r3362, %r3354
  br i1 %r3363, label %apush.inbounds.465, label %apush.realloc.466

apush.inbounds.465:                               ; preds = %apush.nofwd.464
  %r3364 = icmp ult i64 %r3346, 4096
  %r3365 = inttoptr i64 %r3346 to ptr
  %r3366 = select i1 %r3364, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r3365
  %r3367 = load i32, ptr %r3366, align 4
  %r3368 = zext i32 %r3367 to i64
  %r3369 = shl nuw nsw i64 %r3368, 3
  %r3370 = add nuw nsw i64 %r3369, 8
  %r3371 = add i64 %r3346, %r3370
  %r3372 = inttoptr i64 %r3371 to ptr
  store double %r3302, ptr %r3372, align 8
  %r3373 = lshr i64 %r3303, 48
  %r3374 = icmp eq i64 %r3373, 32765
  %r3375 = and i16 %r3349, -1920
  %r3376 = icmp eq i16 %r3375, -24576
  %r3377 = and i1 %r3374, %r3376
  br i1 %r3377, label %apush.pointer_layout.done.469, label %apush.pointer_layout.bookkeeping.468

apush.realloc.466:                                ; preds = %apush.nofwd.464
  %statepoint_token357 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r3306, double %r3302, i32 0, i32 0)
  %r3388358 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token357)
  %r3389 = or i64 %r3388358, 9222527611924643840
  %r3390 = bitcast i64 %r3389 to double
  %rs4gc.b87 = bitcast double %r3390 to i64
  %rs4gc.s87 = inttoptr i64 %rs4gc.b87 to ptr addrspace(1)
  br label %apush.merge.467

apush.merge.467:                                  ; preds = %apush.barrier.done.471, %apush.realloc.466, %apush.fwd.461
  %r68.11 = phi ptr addrspace(1) [ %rs4gc.s86, %apush.fwd.461 ], [ %r68.10, %apush.barrier.done.471 ], [ %rs4gc.s87, %apush.realloc.466 ]
  %r3391 = load double, ptr @test_json_warm_unique_keys_ts_.str.21.handle, align 8
  %r3392 = bitcast double %r3391 to i64
  %r3393.rs4i = ptrtoint ptr addrspace(1) %r68.11 to i64
  %r3393.rs4o = call i64 asm "", "=r,0"(i64 %r3393.rs4i) #7
  %r3393 = bitcast i64 %r3393.rs4o to double
  %r3394 = bitcast double %r3393 to i64
  %r3395 = and i64 %r3394, 281474976710655
  %r3396 = sub nsw i64 %r3395, 8
  %r3397 = inttoptr i64 %r3396 to ptr
  %r3398 = load i8, ptr %r3397, align 1
  %r3399 = icmp ne i8 %r3398, 1
  %r3400 = sub nsw i64 %r3395, 7
  %r3401 = inttoptr i64 %r3400 to ptr
  %r3402 = load i8, ptr %r3401, align 1
  %r3403 = and i8 %r3402, -128
  %r3404 = icmp ne i8 %r3403, 0
  %r3405 = or i1 %r3399, %r3404
  br i1 %r3404, label %apush.fwd.472, label %apush.elements.473

apush.pointer_layout.bookkeeping.468:             ; preds = %apush.inbounds.465
  call void @js_string_addref_if_heap_string(double %r3302) #7
  %r5750 = load double, ptr @test_json_warm_unique_keys_ts_.str.20.handle, align 8
  %r5751 = bitcast double %r5750 to i64
  call void @js_gc_note_slot_layout(i64 %r3346, i32 %r3367, i64 %r5751) #7
  %r5748 = load double, ptr @test_json_warm_unique_keys_ts_.str.20.handle, align 8
  %r5749 = bitcast double %r5748 to i64
  call void @js_array_note_numeric_write(i64 %r3346, i64 %r5749) #7
  br label %apush.pointer_layout.done.469

apush.pointer_layout.done.469:                    ; preds = %apush.pointer_layout.bookkeeping.468, %apush.inbounds.465
  %r3378 = sub i64 %r3346, 7
  %r3379 = inttoptr i64 %r3378 to ptr
  %r3380 = load i8, ptr %r3379, align 1
  %r3381 = and i8 %r3380, 32
  %r3382 = icmp ne i8 %r3381, 0
  %r3383 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3384 = icmp ne i32 %r3383, 0
  %r3385 = or i1 %r3382, %r3384
  br i1 %r3385, label %apush.barrier.470, label %apush.barrier.done.471

apush.barrier.470:                                ; preds = %apush.pointer_layout.done.469
  %r5746 = load double, ptr @test_json_warm_unique_keys_ts_.str.20.handle, align 8
  %r5747 = bitcast double %r5746 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r3346, i64 %r3371, i64 %r5747) #7
  br label %apush.barrier.done.471

apush.barrier.done.471:                           ; preds = %apush.barrier.470, %apush.pointer_layout.done.469
  %r3386 = add i32 %r3367, 1
  %r3387 = inttoptr i64 %r3346 to ptr
  store i32 %r3386, ptr %r3387, align 4
  br label %apush.merge.467

apush.fwd.472:                                    ; preds = %apush.elements.check.474, %apush.merge.467
  %statepoint_token359 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r3395, double %r3391, i32 0, i32 0)
  %r3432360 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token359)
  %r3433 = or i64 %r3432360, 9222527611924643840
  %r3434 = bitcast i64 %r3433 to double
  %rs4gc.b88 = bitcast double %r3434 to i64
  %rs4gc.s88 = inttoptr i64 %rs4gc.b88 to ptr addrspace(1)
  br label %apush.merge.478

apush.elements.473:                               ; preds = %apush.merge.467
  %r3407 = add nuw nsw i64 %r3395, 8
  %r3408 = inttoptr i64 %r3407 to ptr
  %r3409 = load i64, ptr %r3408, align 8
  %r3410 = icmp ne i64 %r3409, 0
  %r3411 = icmp eq i8 %r3398, 2
  %r3412 = and i1 %r3411, %r3410
  %r3413 = select i1 %r3412, i64 %r3409, i64 %r3395
  %r3414 = inttoptr i64 %r3413 to ptr
  %r3415 = getelementptr i64, ptr %r3414, i64 12
  %r3416 = load i64, ptr %r3415, align 8
  %r3417 = icmp ne i64 %r3416, 0
  %r3418 = and i1 %r3412, %r3417
  %r3419 = select i1 %r3418, i64 %r3416, i64 %r3395
  %r3406 = icmp eq i8 %r3398, 1
  br i1 %r3406, label %apush.nofwd.475, label %apush.elements.check.474

apush.elements.check.474:                         ; preds = %apush.elements.473
  %r3420 = icmp ne i64 %r3419, 0
  %r3421 = sub i64 %r3419, 8
  %r3422 = inttoptr i64 %r3421 to ptr
  %r3423 = load i8, ptr %r3422, align 1
  %r3424 = icmp eq i8 %r3423, 1
  %r3425 = sub i64 %r3419, 7
  %r3426 = inttoptr i64 %r3425 to ptr
  %r3427 = load i8, ptr %r3426, align 1
  %r3428 = and i8 %r3427, -128
  %r3429 = icmp eq i8 %r3428, 0
  %r3430 = and i1 %r3420, %r3424
  %r3431 = and i1 %r3430, %r3429
  br i1 %r3431, label %apush.nofwd.475, label %apush.fwd.472

apush.nofwd.475:                                  ; preds = %apush.elements.check.474, %apush.elements.473
  %r3435 = phi i64 [ %r3395, %apush.elements.473 ], [ %r3419, %apush.elements.check.474 ]
  %r3436 = sub i64 %r3435, 6
  %r3437 = inttoptr i64 %r3436 to ptr
  %r3438 = load i16, ptr %r3437, align 2
  %r3439 = and i16 %r3438, 1031
  %r3440 = icmp eq i16 %r3439, 0
  %r3441 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r3442 = icmp eq i8 %r3441, 0
  %r3443 = and i1 %r3440, %r3442
  %r3444 = icmp ult i64 %r3435, 4096
  %r3445 = inttoptr i64 %r3435 to ptr
  %r3446 = select i1 %r3444, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r3445
  %r3447 = load i32, ptr %r3446, align 4
  %r3448 = add i64 %r3435, 4
  %r3449 = inttoptr i64 %r3448 to ptr
  %r3450 = load i32, ptr %r3449, align 4
  %r3451 = icmp ult i32 %r3447, %r3450
  %r3452 = and i1 %r3451, %r3443
  br i1 %r3452, label %apush.inbounds.476, label %apush.realloc.477

apush.inbounds.476:                               ; preds = %apush.nofwd.475
  %r3453 = icmp ult i64 %r3435, 4096
  %r3454 = inttoptr i64 %r3435 to ptr
  %r3455 = select i1 %r3453, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r3454
  %r3456 = load i32, ptr %r3455, align 4
  %r3457 = zext i32 %r3456 to i64
  %r3458 = shl nuw nsw i64 %r3457, 3
  %r3459 = add nuw nsw i64 %r3458, 8
  %r3460 = add i64 %r3435, %r3459
  %r3461 = inttoptr i64 %r3460 to ptr
  store double %r3391, ptr %r3461, align 8
  %r3462 = lshr i64 %r3392, 48
  %r3463 = icmp eq i64 %r3462, 32765
  %r3464 = and i16 %r3438, -1920
  %r3465 = icmp eq i16 %r3464, -24576
  %r3466 = and i1 %r3463, %r3465
  br i1 %r3466, label %apush.pointer_layout.done.480, label %apush.pointer_layout.bookkeeping.479

apush.realloc.477:                                ; preds = %apush.nofwd.475
  %statepoint_token361 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r3395, double %r3391, i32 0, i32 0)
  %r3477362 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token361)
  %r3478 = or i64 %r3477362, 9222527611924643840
  %r3479 = bitcast i64 %r3478 to double
  %rs4gc.b89 = bitcast double %r3479 to i64
  %rs4gc.s89 = inttoptr i64 %rs4gc.b89 to ptr addrspace(1)
  br label %apush.merge.478

apush.merge.478:                                  ; preds = %apush.barrier.done.482, %apush.realloc.477, %apush.fwd.472
  %r68.12 = phi ptr addrspace(1) [ %rs4gc.s88, %apush.fwd.472 ], [ %r68.11, %apush.barrier.done.482 ], [ %rs4gc.s89, %apush.realloc.477 ]
  %r3481.rs4i = ptrtoint ptr addrspace(1) %r68.12 to i64
  %r3481.rs4o = call i64 asm "", "=r,0"(i64 %r3481.rs4i) #7
  %r3481 = bitcast i64 %r3481.rs4o to double
  %r3482 = load double, ptr @test_json_warm_unique_keys_ts_.str.16.handle, align 8
  %r3483 = bitcast double %r3481 to i64
  %r3484 = and i64 %r3483, 281474976710655
  %statepoint_token363 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_join_value, i32 2, i32 0, i64 %r3484, double %r3482, i32 0, i32 0)
  %r3485364 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token363)
  %r3486 = or i64 %r3485364, 9223090561878065152
  %r3487 = bitcast i64 %r3486 to double
  %rs4gc.b90 = bitcast double %r3487 to i64
  %rs4gc.s90 = inttoptr i64 %rs4gc.b90 to ptr addrspace(1)
  %r3488.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s90 to i64
  %r3488 = call i64 asm "", "=r,0"(i64 %r3488.rs4i) #7
  %r3489 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3490 = icmp ne i32 %r3489, 0
  br i1 %r3490, label %shadow.root.barrier.483, label %shadow.root.barrier.done.484

apush.pointer_layout.bookkeeping.479:             ; preds = %apush.inbounds.476
  call void @js_string_addref_if_heap_string(double %r3391) #7
  %r5744 = load double, ptr @test_json_warm_unique_keys_ts_.str.21.handle, align 8
  %r5745 = bitcast double %r5744 to i64
  call void @js_gc_note_slot_layout(i64 %r3435, i32 %r3456, i64 %r5745) #7
  %r5742 = load double, ptr @test_json_warm_unique_keys_ts_.str.21.handle, align 8
  %r5743 = bitcast double %r5742 to i64
  call void @js_array_note_numeric_write(i64 %r3435, i64 %r5743) #7
  br label %apush.pointer_layout.done.480

apush.pointer_layout.done.480:                    ; preds = %apush.pointer_layout.bookkeeping.479, %apush.inbounds.476
  %r3467 = sub i64 %r3435, 7
  %r3468 = inttoptr i64 %r3467 to ptr
  %r3469 = load i8, ptr %r3468, align 1
  %r3470 = and i8 %r3469, 32
  %r3471 = icmp ne i8 %r3470, 0
  %r3472 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3473 = icmp ne i32 %r3472, 0
  %r3474 = or i1 %r3471, %r3473
  br i1 %r3474, label %apush.barrier.481, label %apush.barrier.done.482

apush.barrier.481:                                ; preds = %apush.pointer_layout.done.480
  %r5740 = load double, ptr @test_json_warm_unique_keys_ts_.str.21.handle, align 8
  %r5741 = bitcast double %r5740 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r3435, i64 %r3460, i64 %r5741) #7
  br label %apush.barrier.done.482

apush.barrier.done.482:                           ; preds = %apush.barrier.481, %apush.pointer_layout.done.480
  %r3475 = add i32 %r3456, 1
  %r3476 = inttoptr i64 %r3435 to ptr
  store i32 %r3475, ptr %r3476, align 4
  br label %apush.merge.478

shadow.root.barrier.483:                          ; preds = %apush.merge.478
  call void @js_write_barrier_root_nanbox(i64 %r3488) #7
  br label %shadow.root.barrier.done.484

shadow.root.barrier.done.484:                     ; preds = %shadow.root.barrier.483, %apush.merge.478
  %r3492 = load double, ptr @test_json_warm_unique_keys_ts_.str.22.handle, align 8
  %r3493.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s90 to i64
  %r3493.rs4o = call i64 asm "", "=r,0"(i64 %r3493.rs4i) #7
  %r3493 = bitcast i64 %r3493.rs4o to double
  %r3494 = load double, ptr @test_json_warm_unique_keys_ts_.str.16.handle, align 8
  %r3495.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s90 to i64
  %r3495.rs4o = call i64 asm "", "=r,0"(i64 %r3495.rs4i) #7
  %r3495 = bitcast i64 %r3495.rs4o to double
  %r3496 = load double, ptr @test_json_warm_unique_keys_ts_.str.16.handle, align 8
  %r3497.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s90 to i64
  %r3497.rs4o = call i64 asm "", "=r,0"(i64 %r3497.rs4i) #7
  %r3497 = bitcast i64 %r3497.rs4o to double
  %r3498 = load double, ptr @test_json_warm_unique_keys_ts_.str.23.handle, align 8
  %r3500 = getelementptr double, ptr %r3499, i64 0
  store double %r3492, ptr %r3500, align 8
  %r3501 = getelementptr double, ptr %r3499, i64 1
  store double %r3493, ptr %r3501, align 8
  %r3502 = getelementptr double, ptr %r3499, i64 2
  store double %r3494, ptr %r3502, align 8
  %r3503 = getelementptr double, ptr %r3499, i64 3
  store double %r3495, ptr %r3503, align 8
  %r3504 = getelementptr double, ptr %r3499, i64 4
  store double %r3496, ptr %r3504, align 8
  %r3505 = getelementptr double, ptr %r3499, i64 5
  store double %r3497, ptr %r3505, align 8
  %r3506 = getelementptr double, ptr %r3499, i64 6
  store double %r3498, ptr %r3506, align 8
  %r3507 = ptrtoint ptr %r3499 to i64
  %statepoint_token365 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r3507, i32 7, i32 0, i32 0)
  %r3508366 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token365)
  %r3509 = or i64 %r3508366, 9223090561878065152
  %r3510 = bitcast i64 %r3509 to double
  %rs4gc.b91 = bitcast double %r3510 to i64
  %rs4gc.s91 = inttoptr i64 %rs4gc.b91 to ptr addrspace(1)
  %r3511.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s91 to i64
  %r3511 = call i64 asm "", "=r,0"(i64 %r3511.rs4i) #7
  %r3512 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3513 = icmp ne i32 %r3512, 0
  br i1 %r3513, label %shadow.root.barrier.485, label %shadow.root.barrier.done.486

shadow.root.barrier.485:                          ; preds = %shadow.root.barrier.done.484
  call void @js_write_barrier_root_nanbox(i64 %r3511) #7
  br label %shadow.root.barrier.done.486

shadow.root.barrier.done.486:                     ; preds = %shadow.root.barrier.485, %shadow.root.barrier.done.484
  %statepoint_token367 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s91) ]
  %r3515368 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token367)
  %rs4gc.s91.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token367, i32 0, i32 0) ; (%rs4gc.s91, %rs4gc.s91)
  %r3516 = or i64 %r3515368, 9222527611924643840
  %r3517 = bitcast i64 %r3516 to double
  %rs4gc.b92 = bitcast double %r3517 to i64
  %rs4gc.s92 = inttoptr i64 %rs4gc.b92 to ptr addrspace(1)
  %r3518.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s92 to i64
  %r3518 = call i64 asm "", "=r,0"(i64 %r3518.rs4i) #7
  %r3519 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3520 = icmp ne i32 %r3519, 0
  br i1 %r3520, label %shadow.root.barrier.487, label %shadow.root.barrier.done.488

shadow.root.barrier.487:                          ; preds = %shadow.root.barrier.done.486
  call void @js_write_barrier_root_nanbox(i64 %r3518) #7
  br label %shadow.root.barrier.done.488

shadow.root.barrier.done.488:                     ; preds = %shadow.root.barrier.487, %shadow.root.barrier.done.486
  br label %for.cond.489

for.cond.489:                                     ; preds = %for.update.491, %shadow.root.barrier.done.488
  %.0960 = phi ptr addrspace(1) [ %rs4gc.s91.relocated, %shadow.root.barrier.done.488 ], [ %.16976, %for.update.491 ]
  %r3521.0 = phi double [ 0.000000e+00, %shadow.root.barrier.done.488 ], [ %r4886, %for.update.491 ]
  %r3514.0.base = phi ptr addrspace(1) [ %rs4gc.s92, %shadow.root.barrier.done.488 ], [ %.21028, %for.update.491 ], !is_base_value !0
  %r3514.0 = phi ptr addrspace(1) [ %rs4gc.s92, %shadow.root.barrier.done.488 ], [ %.21031, %for.update.491 ]
  %r3523 = fcmp olt double %r3521.0, 1.600000e+01
  %r3524 = select i1 %r3523, i64 9222246136947933188, i64 9222246136947933187
  %r3525 = bitcast i64 %r3524 to double
  %r3526 = icmp eq i64 %r3524, 9222246136947933188
  br i1 %r3526, label %for.body.490, label %for.exit.492

for.body.490:                                     ; preds = %for.cond.489
  %r3528.rs4i = ptrtoint ptr addrspace(1) %.0960 to i64
  %r3528.rs4o = call i64 asm "", "=r,0"(i64 %r3528.rs4i) #7
  %r3528 = bitcast i64 %r3528.rs4o to double
  %statepoint_token369 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r3528, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r3514.0.base, ptr addrspace(1) %.0960, ptr addrspace(1) %r3514.0) ]
  %r3529370 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token369)
  %r3514.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token369, i32 0, i32 0) ; (%r3514.0.base, %r3514.0.base)
  %rs4gc.s91.relocated371 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token369, i32 1, i32 1) ; (%.0960, %.0960)
  %r3514.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token369, i32 0, i32 2) ; (%r3514.0.base, %r3514.0)
  %statepoint_token372 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r3529370, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r3514.0.base.relocated, ptr addrspace(1) %rs4gc.s91.relocated371, ptr addrspace(1) %r3514.0.relocated) ]
  %r3530373 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token372)
  %r3514.0.base.relocated374 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token372, i32 0, i32 0) ; (%r3514.0.base.relocated, %r3514.0.base.relocated)
  %rs4gc.s91.relocated375 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token372, i32 1, i32 1) ; (%rs4gc.s91.relocated371, %rs4gc.s91.relocated371)
  %r3514.0.relocated376 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token372, i32 0, i32 2) ; (%r3514.0.base.relocated, %r3514.0.relocated)
  %r3531 = bitcast i64 %r3530373 to double
  %rs4gc.b93 = bitcast double %r3531 to i64
  %rs4gc.s93 = inttoptr i64 %rs4gc.b93 to ptr addrspace(1)
  %r3532.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s93 to i64
  %r3532 = call i64 asm "", "=r,0"(i64 %r3532.rs4i) #7
  %r3533 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3534 = icmp ne i32 %r3533, 0
  br i1 %r3534, label %shadow.root.barrier.493, label %shadow.root.barrier.done.494

for.update.491:                                   ; preds = %gcpoll.done.778
  %r4886 = fadd double %r3521.0, 1.000000e+00
  br label %for.cond.489

for.exit.492:                                     ; preds = %for.cond.489
  %statepoint_token377 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_collect, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r3514.0, ptr addrspace(1) %r3514.0.base) ]
  %r3514.0.relocated378 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token377, i32 1, i32 0) ; (%r3514.0.base, %r3514.0)
  %r3514.0.base.relocated379 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token377, i32 1, i32 1) ; (%r3514.0.base, %r3514.0.base)
  %r4887 = load volatile i8, ptr @PERRY_ARRAY_PROTO_ITERATOR_PATCHED, align 1
  %r4888 = zext i8 %r4887 to i32
  %r4889 = icmp ne i32 %r4888, 0
  %r4890 = select i1 %r4889, i64 9222246136947933188, i64 9222246136947933187
  %r4891 = bitcast i64 %r4890 to double
  br label %truthy.tag.780

shadow.root.barrier.493:                          ; preds = %for.body.490
  call void @js_write_barrier_root_nanbox(i64 %r3532) #7
  br label %shadow.root.barrier.done.494

shadow.root.barrier.done.494:                     ; preds = %shadow.root.barrier.493, %for.body.490
  %r3537.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s93 to i64
  %r3537.rs4o = call i64 asm "", "=r,0"(i64 %r3537.rs4i) #7
  %r3537 = bitcast i64 %r3537.rs4o to double
  %statepoint_token380 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, i32, ptr)) @js_packed_arraylike_loop_guard_live, i32 4, i32 0, double %r3537, double -1.000000e+00, i32 1, ptr %r3538, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s93, ptr addrspace(1) %r3514.0.base.relocated374, ptr addrspace(1) %rs4gc.s91.relocated375, ptr addrspace(1) %r3514.0.relocated376) ]
  %r3539381 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token380)
  %rs4gc.s93.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token380, i32 0, i32 0) ; (%rs4gc.s93, %rs4gc.s93)
  %r3514.0.base.relocated382 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token380, i32 1, i32 1) ; (%r3514.0.base.relocated374, %r3514.0.base.relocated374)
  %rs4gc.s91.relocated383 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token380, i32 2, i32 2) ; (%rs4gc.s91.relocated375, %rs4gc.s91.relocated375)
  %r3514.0.relocated384 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token380, i32 1, i32 3) ; (%r3514.0.base.relocated374, %r3514.0.relocated376)
  %r3540 = icmp ne i64 %r3539381, 0
  br label %stable_packed.loop.slow.preheader.496

stable_packed.loop.slow.preheader.496:            ; preds = %shadow.root.barrier.done.494
  %r3764.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s93.relocated to i64
  %r3764.rs4o = call i64 asm "", "=r,0"(i64 %r3764.rs4i) #7
  %r3764 = bitcast i64 %r3764.rs4o to double
  %r3765 = bitcast double %r3764 to i64
  %r3766 = and i64 %r3765, 281474976710655
  %r3767 = lshr i64 %r3765, 48
  %r3768 = and i64 %r3767, 65533
  %r3769 = icmp eq i64 %r3768, 32765
  br i1 %r3769, label %pget.recv_ok.545, label %pget.recv_other.550

stable_packed.loop.merge.497:                     ; preds = %for.stable_packed_slow.exit.580
  %r4371 = load double, ptr @test_json_warm_unique_keys_ts_.str.25.handle, align 8
  %r4372.rs4i = ptrtoint ptr addrspace(1) %.3963 to i64
  %r4372.rs4o = call i64 asm "", "=r,0"(i64 %r4372.rs4i) #7
  %r4372 = bitcast i64 %r4372.rs4o to double
  %r4373 = load double, ptr @test_json_warm_unique_keys_ts_.str.17.handle, align 8
  %r4375 = getelementptr double, ptr %r4374, i64 0
  store double %r4371, ptr %r4375, align 8
  %r4376 = getelementptr double, ptr %r4374, i64 1
  store double %r4372, ptr %r4376, align 8
  %r4377 = getelementptr double, ptr %r4374, i64 2
  store double %r4373, ptr %r4377, align 8
  %r4378 = ptrtoint ptr %r4374 to i64
  %statepoint_token385 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r4378, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r3535.0, ptr addrspace(1) %.2979, ptr addrspace(1) %.21001, ptr addrspace(1) %.3963, ptr addrspace(1) %.2990) ]
  %r4379386 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token385)
  %r3535.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token385, i32 0, i32 0) ; (%r3535.0, %r3535.0)
  %r3514.0.base.relocated387 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token385, i32 1, i32 1) ; (%.2979, %.2979)
  %rs4gc.s93.relocated388 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token385, i32 2, i32 2) ; (%.21001, %.21001)
  %rs4gc.s91.relocated389 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token385, i32 3, i32 3) ; (%.3963, %.3963)
  %r3514.0.relocated390 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token385, i32 1, i32 4) ; (%.2979, %.2990)
  %r4380 = or i64 %r4379386, 9223090561878065152
  %r4381 = bitcast i64 %r4380 to double
  %statepoint_token391 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r4381, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r3535.0.relocated, ptr addrspace(1) %r3514.0.base.relocated387, ptr addrspace(1) %rs4gc.s93.relocated388, ptr addrspace(1) %rs4gc.s91.relocated389, ptr addrspace(1) %r3514.0.relocated390) ]
  %r4382392 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token391)
  %r3535.0.relocated393 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token391, i32 0, i32 0) ; (%r3535.0.relocated, %r3535.0.relocated)
  %r3514.0.base.relocated394 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token391, i32 1, i32 1) ; (%r3514.0.base.relocated387, %r3514.0.base.relocated387)
  %rs4gc.s93.relocated395 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token391, i32 2, i32 2) ; (%rs4gc.s93.relocated388, %rs4gc.s93.relocated388)
  %rs4gc.s91.relocated396 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token391, i32 3, i32 3) ; (%rs4gc.s91.relocated389, %rs4gc.s91.relocated389)
  %r3514.0.relocated397 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token391, i32 1, i32 4) ; (%r3514.0.base.relocated387, %r3514.0.relocated390)
  %statepoint_token398 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r4382392, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r3535.0.relocated393, ptr addrspace(1) %r3514.0.base.relocated394, ptr addrspace(1) %rs4gc.s93.relocated395, ptr addrspace(1) %rs4gc.s91.relocated396, ptr addrspace(1) %r3514.0.relocated397) ]
  %r4383399 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token398)
  %r3535.0.relocated400 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token398, i32 0, i32 0) ; (%r3535.0.relocated393, %r3535.0.relocated393)
  %r3514.0.base.relocated401 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token398, i32 1, i32 1) ; (%r3514.0.base.relocated394, %r3514.0.base.relocated394)
  %rs4gc.s93.relocated402 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token398, i32 2, i32 2) ; (%rs4gc.s93.relocated395, %rs4gc.s93.relocated395)
  %rs4gc.s91.relocated403 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token398, i32 3, i32 3) ; (%rs4gc.s91.relocated396, %rs4gc.s91.relocated396)
  %r3514.0.relocated404 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token398, i32 1, i32 4) ; (%r3514.0.base.relocated394, %r3514.0.relocated397)
  %r4384 = bitcast i64 %r4383399 to double
  %rs4gc.b95 = bitcast double %r4384 to i64
  %rs4gc.s95 = inttoptr i64 %rs4gc.b95 to ptr addrspace(1)
  %r4385.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s95 to i64
  %r4385 = call i64 asm "", "=r,0"(i64 %r4385.rs4i) #7
  %r4386 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4387 = icmp ne i32 %r4386, 0
  br i1 %r4387, label %shadow.root.barrier.668, label %shadow.root.barrier.done.669

pget.recv_sso.544:                                ; preds = %pget.recv_other.550
  %r3908 = lshr i64 %r3765, 40
  %r3909 = and i64 %r3908, 255
  %r3910 = uitofp nneg i64 %r3909 to double
  br label %pget.recv_merge.548

pget.recv_ok.545:                                 ; preds = %stable_packed.loop.slow.preheader.496
  %r3776 = icmp eq i64 %r3767, 32767
  br i1 %r3776, label %pget.strlen_heap.549, label %pget.recv_obj.552

pget.recv_bad.546:                                ; preds = %pget.check_class_ref.551
  %r3900 = icmp eq i64 %r3765, 9222246136947933185
  %r3901 = icmp eq i64 %r3765, 9222246136947933186
  %r3902 = or i1 %r3900, %r3901
  br i1 %r3902, label %pget.throw_nullish.575, label %pget.recv_undef_return.576

pget.recv_class_ref.547:                          ; preds = %pget.check_class_ref.551
  %r3772 = load double, ptr @test_json_warm_unique_keys_ts_.str.24.handle, align 8
  %r3773 = bitcast double %r3772 to i64
  %r3774 = and i64 %r3773, 281474976710655
  %statepoint_token405 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 547434508618563590, i64 %r3765, i64 %r3774, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s93.relocated, ptr addrspace(1) %r3514.0.base.relocated382, ptr addrspace(1) %rs4gc.s91.relocated383, ptr addrspace(1) %r3514.0.relocated384) ]
  %r3775406 = call double @llvm.experimental.gc.result.f64(token %statepoint_token405)
  %rs4gc.s93.relocated407 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token405, i32 0, i32 0) ; (%rs4gc.s93.relocated, %rs4gc.s93.relocated)
  %r3514.0.base.relocated408 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token405, i32 1, i32 1) ; (%r3514.0.base.relocated382, %r3514.0.base.relocated382)
  %rs4gc.s91.relocated409 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token405, i32 2, i32 2) ; (%rs4gc.s91.relocated383, %rs4gc.s91.relocated383)
  %r3514.0.relocated410 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token405, i32 1, i32 3) ; (%r3514.0.base.relocated382, %r3514.0.relocated384)
  br label %pget.recv_merge.548

pget.recv_merge.548:                              ; preds = %pget.recv_undef_return.576, %pic.merge.567, %pget.strlen_heap.549, %pget.recv_class_ref.547, %pget.recv_sso.544
  %.0999 = phi ptr addrspace(1) [ %rs4gc.s93.relocated, %pget.strlen_heap.549 ], [ %.11000, %pic.merge.567 ], [ %rs4gc.s93.relocated, %pget.recv_sso.544 ], [ %rs4gc.s93.relocated407, %pget.recv_class_ref.547 ], [ %rs4gc.s93.relocated426, %pget.recv_undef_return.576 ]
  %.0988 = phi ptr addrspace(1) [ %r3514.0.relocated384, %pget.strlen_heap.549 ], [ %.1989, %pic.merge.567 ], [ %r3514.0.relocated384, %pget.recv_sso.544 ], [ %r3514.0.relocated410, %pget.recv_class_ref.547 ], [ %r3514.0.relocated429, %pget.recv_undef_return.576 ]
  %.0977 = phi ptr addrspace(1) [ %r3514.0.base.relocated382, %pget.strlen_heap.549 ], [ %.1978, %pic.merge.567 ], [ %r3514.0.base.relocated382, %pget.recv_sso.544 ], [ %r3514.0.base.relocated408, %pget.recv_class_ref.547 ], [ %r3514.0.base.relocated427, %pget.recv_undef_return.576 ]
  %.1961 = phi ptr addrspace(1) [ %rs4gc.s91.relocated383, %pget.strlen_heap.549 ], [ %.2962, %pic.merge.567 ], [ %rs4gc.s91.relocated383, %pget.recv_sso.544 ], [ %rs4gc.s91.relocated409, %pget.recv_class_ref.547 ], [ %rs4gc.s91.relocated428, %pget.recv_undef_return.576 ]
  %r3916 = phi double [ %r3899, %pic.merge.567 ], [ %r3907425, %pget.recv_undef_return.576 ], [ %r3910, %pget.recv_sso.544 ], [ %r3775406, %pget.recv_class_ref.547 ], [ %r3915, %pget.strlen_heap.549 ]
  %r3919 = fptosi double %r3916 to i32
  br label %for.stable_packed_slow.cond.577

pget.strlen_heap.549:                             ; preds = %pget.recv_ok.545
  %r3911 = icmp ult i64 %r3766, 4096
  %r3912 = inttoptr i64 %r3766 to ptr
  %r3913 = select i1 %r3911, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r3912
  %r3914 = load i32, ptr %r3913, align 4
  %r3915 = uitofp i32 %r3914 to double
  br label %pget.recv_merge.548

pget.recv_other.550:                              ; preds = %stable_packed.loop.slow.preheader.496
  %r3770 = icmp eq i64 %r3767, 32761
  br i1 %r3770, label %pget.recv_sso.544, label %pget.check_class_ref.551

pget.check_class_ref.551:                         ; preds = %pget.recv_other.550
  %r3771 = icmp eq i64 %r3767, 32766
  br i1 %r3771, label %pget.recv_class_ref.547, label %pget.recv_bad.546

pget.recv_obj.552:                                ; preds = %pget.recv_ok.545
  %r3777 = icmp ugt i64 %r3766, 1048575
  br i1 %r3777, label %pic.recv_hdr.568, label %pic.miss.cold.565

pic.hit.553:                                      ; preds = %pic.token.569
  %r3802 = getelementptr i64, ptr %r3787, i64 1
  %r3803 = load i64, ptr %r3802, align 8
  %r3804 = and i64 %r3803, 1073741824
  %r3805 = icmp ne i64 %r3804, 0
  br i1 %r3805, label %pic.hit.overflow.570, label %pic.hit.inline.571

pic.hit.live.554:                                 ; preds = %pic.hit.inline.571
  br label %pic.merge.567

pic.prefix.guard.555:                             ; preds = %pic.token.569
  %r3818 = getelementptr i64, ptr %r3787, i64 2
  %r3819 = load i64, ptr %r3818, align 8
  %r3820 = icmp ne i64 %r3819, 0
  br i1 %r3820, label %pic.prefix.meta.556, label %pic.miss.564

pic.prefix.meta.556:                              ; preds = %pic.prefix.guard.555
  %r3821 = add nuw nsw i64 %r3766, 8
  %r3822 = inttoptr i64 %r3821 to ptr
  %r3823 = load i64, ptr %r3822, align 8
  %r3824 = icmp ne i64 %r3823, 0
  br i1 %r3824, label %pic.prefix.token.557, label %pic.miss.564

pic.prefix.token.557:                             ; preds = %pic.prefix.meta.556
  %r3825 = inttoptr i64 %r3823 to ptr
  %r3826 = getelementptr i64, ptr %r3825, i64 6
  %r3827 = load i64, ptr %r3826, align 8
  %r3828 = icmp eq i64 %r3827, %r3819
  br i1 %r3828, label %pic.prefix.hit.558, label %pic.miss.564

pic.prefix.hit.558:                               ; preds = %pic.prefix.token.557
  %r3829 = getelementptr i64, ptr %r3787, i64 1
  %r3830 = load i64, ptr %r3829, align 8
  %r3831 = shl i64 %r3830, 3
  %r3832 = add nuw nsw i64 %r3766, 16
  %r3833 = add i64 %r3832, %r3831
  %r3834 = inttoptr i64 %r3833 to ptr
  %r3835 = load double, ptr %r3834, align 8
  br label %pic.merge.567

pic.desc.classify.559:                            ; preds = %pic.recv_hdr.568
  %r3791 = and i1 %r3781, %r3788
  br i1 %r3791, label %pic.desc.prefix.guard.560, label %pic.miss.cold.565

pic.desc.prefix.guard.560:                        ; preds = %pic.desc.classify.559
  %r3836 = getelementptr i64, ptr %r3787, i64 2
  %r3837 = load i64, ptr %r3836, align 8
  %r3838 = icmp ne i64 %r3837, 0
  br i1 %r3838, label %pic.desc.prefix.meta.561, label %pic.miss.cold.565

pic.desc.prefix.meta.561:                         ; preds = %pic.desc.prefix.guard.560
  %r3839 = add nuw nsw i64 %r3766, 8
  %r3840 = inttoptr i64 %r3839 to ptr
  %r3841 = load i64, ptr %r3840, align 8
  %r3842 = icmp ne i64 %r3841, 0
  br i1 %r3842, label %pic.desc.prefix.token.562, label %pic.miss.cold.565

pic.desc.prefix.token.562:                        ; preds = %pic.desc.prefix.meta.561
  %r3843 = inttoptr i64 %r3841 to ptr
  %r3844 = getelementptr i64, ptr %r3843, i64 6
  %r3845 = load i64, ptr %r3844, align 8
  %r3846 = icmp eq i64 %r3845, %r3837
  br i1 %r3846, label %pic.desc.prefix.hit.563, label %pic.miss.cold.565

pic.desc.prefix.hit.563:                          ; preds = %pic.desc.prefix.token.562
  %r3847 = getelementptr i64, ptr %r3787, i64 1
  %r3848 = load i64, ptr %r3847, align 8
  %r3849 = shl i64 %r3848, 3
  %r3850 = add nuw nsw i64 %r3766, 16
  %r3851 = add i64 %r3850, %r3849
  %r3852 = inttoptr i64 %r3851 to ptr
  %r3853 = load double, ptr %r3852, align 8
  br label %pic.merge.567

pic.miss.564:                                     ; preds = %pic.hit.inline.571, %pic.prefix.token.557, %pic.prefix.meta.556, %pic.prefix.guard.555
  %r3854 = getelementptr i64, ptr %r3787, i64 3
  %r3855 = load i64, ptr %r3854, align 8
  %r3856 = icmp sgt i64 %r3855, 0
  br i1 %r3856, label %pic.ways.572, label %pic.miss.call.566

pic.miss.cold.565:                                ; preds = %pic.desc.prefix.token.562, %pic.desc.prefix.meta.561, %pic.desc.prefix.guard.560, %pic.desc.classify.559, %pget.recv_obj.552
  br label %pic.miss.call.566

pic.miss.call.566:                                ; preds = %pic.way.load.573, %pic.ways.572, %pic.miss.cold.565, %pic.miss.564
  %r3895 = load double, ptr @test_json_warm_unique_keys_ts_.str.24.handle, align 8
  %r3896 = bitcast double %r3895 to i64
  %r3897 = and i64 %r3896, 281474976710655
  %statepoint_token411 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r3766, i64 %r3897, ptr @perry_ic_test_json_warm_unique_keys_ts__7, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s93.relocated, ptr addrspace(1) %r3514.0.base.relocated382, ptr addrspace(1) %rs4gc.s91.relocated383, ptr addrspace(1) %r3514.0.relocated384) ]
  %r3898412 = call double @llvm.experimental.gc.result.f64(token %statepoint_token411)
  %rs4gc.s93.relocated413 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token411, i32 0, i32 0) ; (%rs4gc.s93.relocated, %rs4gc.s93.relocated)
  %r3514.0.base.relocated414 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token411, i32 1, i32 1) ; (%r3514.0.base.relocated382, %r3514.0.base.relocated382)
  %rs4gc.s91.relocated415 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token411, i32 2, i32 2) ; (%rs4gc.s91.relocated383, %rs4gc.s91.relocated383)
  %r3514.0.relocated416 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token411, i32 1, i32 3) ; (%r3514.0.base.relocated382, %r3514.0.relocated384)
  br label %pic.merge.567

pic.merge.567:                                    ; preds = %pic.way.live.574, %pic.hit.overflow.570, %pic.miss.call.566, %pic.desc.prefix.hit.563, %pic.prefix.hit.558, %pic.hit.live.554
  %.11000 = phi ptr addrspace(1) [ %rs4gc.s93.relocated419, %pic.hit.overflow.570 ], [ %rs4gc.s93.relocated413, %pic.miss.call.566 ], [ %rs4gc.s93.relocated, %pic.way.live.574 ], [ %rs4gc.s93.relocated, %pic.hit.live.554 ], [ %rs4gc.s93.relocated, %pic.prefix.hit.558 ], [ %rs4gc.s93.relocated, %pic.desc.prefix.hit.563 ]
  %.1989 = phi ptr addrspace(1) [ %r3514.0.relocated422, %pic.hit.overflow.570 ], [ %r3514.0.relocated416, %pic.miss.call.566 ], [ %r3514.0.relocated384, %pic.way.live.574 ], [ %r3514.0.relocated384, %pic.hit.live.554 ], [ %r3514.0.relocated384, %pic.prefix.hit.558 ], [ %r3514.0.relocated384, %pic.desc.prefix.hit.563 ]
  %.1978 = phi ptr addrspace(1) [ %r3514.0.base.relocated420, %pic.hit.overflow.570 ], [ %r3514.0.base.relocated414, %pic.miss.call.566 ], [ %r3514.0.base.relocated382, %pic.way.live.574 ], [ %r3514.0.base.relocated382, %pic.hit.live.554 ], [ %r3514.0.base.relocated382, %pic.prefix.hit.558 ], [ %r3514.0.base.relocated382, %pic.desc.prefix.hit.563 ]
  %.2962 = phi ptr addrspace(1) [ %rs4gc.s91.relocated421, %pic.hit.overflow.570 ], [ %rs4gc.s91.relocated415, %pic.miss.call.566 ], [ %rs4gc.s91.relocated383, %pic.way.live.574 ], [ %rs4gc.s91.relocated383, %pic.hit.live.554 ], [ %rs4gc.s91.relocated383, %pic.prefix.hit.558 ], [ %rs4gc.s91.relocated383, %pic.desc.prefix.hit.563 ]
  %r3899 = phi double [ %r3815, %pic.hit.live.554 ], [ %r3810418, %pic.hit.overflow.570 ], [ %r3835, %pic.prefix.hit.558 ], [ %r3853, %pic.desc.prefix.hit.563 ], [ %r3892, %pic.way.live.574 ], [ %r3898412, %pic.miss.call.566 ]
  br label %pget.recv_merge.548

pic.recv_hdr.568:                                 ; preds = %pget.recv_obj.552
  %r3778 = sub nuw nsw i64 %r3766, 8
  %r3779 = inttoptr i64 %r3778 to ptr
  %r3780 = load i8, ptr %r3779, align 1
  %r3781 = icmp eq i8 %r3780, 2
  %r3782 = sub nuw nsw i64 %r3766, 6
  %r3783 = inttoptr i64 %r3782 to ptr
  %r3784 = load i16, ptr %r3783, align 2
  %r3785 = and i16 %r3784, 2048
  %r3786 = icmp eq i16 %r3785, 0
  %r3787 = load ptr, ptr @perry_ic_test_json_warm_unique_keys_ts__7, align 8
  %r3788 = icmp ne ptr %r3787, null
  %r3789 = and i1 %r3781, %r3786
  %r3790 = and i1 %r3789, %r3788
  br i1 %r3790, label %pic.token.569, label %pic.desc.classify.559

pic.token.569:                                    ; preds = %pic.recv_hdr.568
  %r3792 = add nuw nsw i64 %r3766, 4
  %r3793 = inttoptr i64 %r3792 to ptr
  %r3794 = load i32, ptr %r3793, align 4
  %r3795 = zext i32 %r3794 to i64
  %r3796 = or i64 %r3795, 4611686018427387904
  %r3797 = icmp ne i32 %r3794, 0
  %r3798 = getelementptr i64, ptr %r3787, i64 0
  %r3799 = load i64, ptr %r3798, align 8
  %r3800 = icmp eq i64 %r3796, %r3799
  %r3801 = and i1 %r3800, %r3797
  br i1 %r3801, label %pic.hit.553, label %pic.prefix.guard.555

pic.hit.overflow.570:                             ; preds = %pic.hit.553
  %r3806 = load double, ptr @test_json_warm_unique_keys_ts_.str.24.handle, align 8
  %r3807 = bitcast double %r3806 to i64
  %r3808 = and i64 %r3807, 281474976710655
  %r3809 = trunc i64 %r3803 to i32
  %statepoint_token417 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r3766, i64 %r3808, i32 %r3809, ptr @perry_ic_test_json_warm_unique_keys_ts__7, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s93.relocated, ptr addrspace(1) %r3514.0.base.relocated382, ptr addrspace(1) %rs4gc.s91.relocated383, ptr addrspace(1) %r3514.0.relocated384) ]
  %r3810418 = call double @llvm.experimental.gc.result.f64(token %statepoint_token417)
  %rs4gc.s93.relocated419 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token417, i32 0, i32 0) ; (%rs4gc.s93.relocated, %rs4gc.s93.relocated)
  %r3514.0.base.relocated420 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token417, i32 1, i32 1) ; (%r3514.0.base.relocated382, %r3514.0.base.relocated382)
  %rs4gc.s91.relocated421 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token417, i32 2, i32 2) ; (%rs4gc.s91.relocated383, %rs4gc.s91.relocated383)
  %r3514.0.relocated422 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token417, i32 1, i32 3) ; (%r3514.0.base.relocated382, %r3514.0.relocated384)
  br label %pic.merge.567

pic.hit.inline.571:                               ; preds = %pic.hit.553
  %r3811 = shl i64 %r3803, 3
  %r3812 = add nuw nsw i64 %r3766, 16
  %r3813 = add i64 %r3812, %r3811
  %r3814 = inttoptr i64 %r3813 to ptr
  %r3815 = load double, ptr %r3814, align 8
  %r3816 = bitcast double %r3815 to i64
  %r3817 = icmp eq i64 %r3816, 9222246136947933200
  br i1 %r3817, label %pic.miss.564, label %pic.hit.live.554

pic.ways.572:                                     ; preds = %pic.miss.564
  %r3857 = getelementptr i64, ptr %r3787, i64 4
  %r3858 = load i64, ptr %r3857, align 8
  %r3859 = icmp eq i64 %r3858, %r3796
  %r3860 = getelementptr i64, ptr %r3787, i64 5
  %r3861 = load i64, ptr %r3860, align 8
  %r3862 = select i1 %r3859, i64 %r3861, i64 0
  %r3863 = getelementptr i64, ptr %r3787, i64 6
  %r3864 = load i64, ptr %r3863, align 8
  %r3865 = icmp eq i64 %r3864, %r3796
  %r3866 = getelementptr i64, ptr %r3787, i64 7
  %r3867 = load i64, ptr %r3866, align 8
  %r3868 = select i1 %r3865, i64 %r3867, i64 0
  %r3869 = getelementptr i64, ptr %r3787, i64 8
  %r3870 = load i64, ptr %r3869, align 8
  %r3871 = icmp eq i64 %r3870, %r3796
  %r3872 = getelementptr i64, ptr %r3787, i64 9
  %r3873 = load i64, ptr %r3872, align 8
  %r3874 = select i1 %r3871, i64 %r3873, i64 0
  %r3875 = getelementptr i64, ptr %r3787, i64 10
  %r3876 = load i64, ptr %r3875, align 8
  %r3877 = icmp eq i64 %r3876, %r3796
  %r3878 = getelementptr i64, ptr %r3787, i64 11
  %r3879 = load i64, ptr %r3878, align 8
  %r3880 = select i1 %r3877, i64 %r3879, i64 0
  %r3881 = or i1 %r3859, %r3865
  %r3882 = select i1 %r3859, i64 %r3862, i64 %r3868
  %r3883 = or i1 %r3871, %r3877
  %r3884 = select i1 %r3871, i64 %r3874, i64 %r3880
  %r3885 = or i1 %r3881, %r3883
  %r3886 = select i1 %r3881, i64 %r3882, i64 %r3884
  %r3887 = and i1 %r3797, %r3885
  br i1 %r3887, label %pic.way.load.573, label %pic.miss.call.566

pic.way.load.573:                                 ; preds = %pic.ways.572
  %r3888 = shl i64 %r3886, 3
  %r3889 = add nuw nsw i64 %r3766, 16
  %r3890 = add i64 %r3889, %r3888
  %r3891 = inttoptr i64 %r3890 to ptr
  %r3892 = load double, ptr %r3891, align 8
  %r3893 = bitcast double %r3892 to i64
  %r3894 = icmp eq i64 %r3893, 9222246136947933200
  br i1 %r3894, label %pic.miss.call.566, label %pic.way.live.574

pic.way.live.574:                                 ; preds = %pic.way.load.573
  br label %pic.merge.567

pget.throw_nullish.575:                           ; preds = %pget.recv_bad.546
  %r3903 = zext i1 %r3901 to i32
  %statepoint_token423 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r3903, ptr @test_json_warm_unique_keys_ts_.str.24.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.576:                       ; preds = %pget.recv_bad.546
  %r3904 = load double, ptr @test_json_warm_unique_keys_ts_.str.24.handle, align 8
  %r3905 = bitcast double %r3904 to i64
  %r3906 = and i64 %r3905, 281474976710655
  %statepoint_token424 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3765, i64 %r3906, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s93.relocated, ptr addrspace(1) %r3514.0.base.relocated382, ptr addrspace(1) %rs4gc.s91.relocated383, ptr addrspace(1) %r3514.0.relocated384) ]
  %r3907425 = call double @llvm.experimental.gc.result.f64(token %statepoint_token424)
  %rs4gc.s93.relocated426 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token424, i32 0, i32 0) ; (%rs4gc.s93.relocated, %rs4gc.s93.relocated)
  %r3514.0.base.relocated427 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token424, i32 1, i32 1) ; (%r3514.0.base.relocated382, %r3514.0.base.relocated382)
  %rs4gc.s91.relocated428 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token424, i32 2, i32 2) ; (%rs4gc.s91.relocated383, %rs4gc.s91.relocated383)
  %r3514.0.relocated429 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token424, i32 1, i32 3) ; (%r3514.0.base.relocated382, %r3514.0.relocated384)
  br label %pget.recv_merge.548

for.stable_packed_slow.cond.577:                  ; preds = %for.stable_packed_slow.update.579, %pget.recv_merge.548
  %.21001 = phi ptr addrspace(1) [ %.0999, %pget.recv_merge.548 ], [ %.71006, %for.stable_packed_slow.update.579 ]
  %.2990 = phi ptr addrspace(1) [ %.0988, %pget.recv_merge.548 ], [ %.7995, %for.stable_packed_slow.update.579 ]
  %.2979 = phi ptr addrspace(1) [ %.0977, %pget.recv_merge.548 ], [ %.7984, %for.stable_packed_slow.update.579 ]
  %.3963 = phi ptr addrspace(1) [ %.1961, %pget.recv_merge.548 ], [ %.8968, %for.stable_packed_slow.update.579 ]
  %r3536.0 = phi i32 [ 0, %pget.recv_merge.548 ], [ %r4367, %for.stable_packed_slow.update.579 ]
  %r3535.0 = phi ptr addrspace(1) [ null, %pget.recv_merge.548 ], [ %.01018, %for.stable_packed_slow.update.579 ]
  %r3923 = icmp slt i32 %r3536.0, %r3919
  br i1 %r3923, label %for.stable_packed_slow.body.578, label %for.stable_packed_slow.exit.580

for.stable_packed_slow.body.578:                  ; preds = %for.stable_packed_slow.cond.577
  %r3924.rs4i = ptrtoint ptr addrspace(1) %r3535.0 to i64
  %r3924.rs4o = call i64 asm "", "=r,0"(i64 %r3924.rs4i) #7
  %r3924 = bitcast i64 %r3924.rs4o to double
  %r3925 = bitcast double %r3924 to i64
  %rs4gc.s98 = inttoptr i64 %r3925 to ptr addrspace(1)
  %r3926.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s98 to i64
  %r3926 = call i64 asm "", "=r,0"(i64 %r3926.rs4i) #7
  %r3927 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3928 = icmp ne i32 %r3927, 0
  br i1 %r3928, label %shadow.root.barrier.581, label %shadow.root.barrier.done.582

for.stable_packed_slow.update.579:                ; preds = %gcpoll.done.667
  %r4367 = add i32 %r3536.0, 1
  %r4368 = sitofp i32 %r3536.0 to double
  %r4369 = sitofp i32 %r4367 to double
  br label %for.stable_packed_slow.cond.577

for.stable_packed_slow.exit.580:                  ; preds = %for.stable_packed_slow.cond.577
  br label %stable_packed.loop.merge.497

shadow.root.barrier.581:                          ; preds = %for.stable_packed_slow.body.578
  call void @js_write_barrier_root_nanbox(i64 %r3926) #7
  br label %shadow.root.barrier.done.582

shadow.root.barrier.done.582:                     ; preds = %shadow.root.barrier.581, %for.stable_packed_slow.body.578
  %r3929.rs4i = ptrtoint ptr addrspace(1) %.21001 to i64
  %r3929.rs4o = call i64 asm "", "=r,0"(i64 %r3929.rs4i) #7
  %r3929 = bitcast i64 %r3929.rs4o to double
  %r3931 = sitofp i32 %r3536.0 to double
  %r3932 = bitcast double %r3929 to i64
  %r3933 = and i64 %r3932, 281474976710655
  %r3934 = and i64 %r3932, -281474976710656
  %r3935 = icmp eq i64 %r3934, 9222527611924643840
  %r3936 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r3937 = icmp eq i64 %r3936, 0
  %r3938 = icmp ugt i64 %r3933, 1048575
  %r3939 = icmp ult i64 %r3933, 140737488355328
  %r3940 = and i1 %r3938, %r3939
  %r3941 = and i1 %r3935, %r3937
  %r3942 = and i1 %r3941, %r3940
  br i1 %r3942, label %tav.get.brand.587, label %tav.get.slow.585

tav.get.fast.583:                                 ; preds = %tav.get.brand.587
  %r3959 = bitcast double %r3929 to i64
  %r3960 = and i64 %r3959, 281474976710655
  %r3961 = add nuw nsw i64 %r3960, 8
  %r3962 = inttoptr i64 %r3961 to ptr
  %r3963 = load i8, ptr %r3962, align 1
  %r3964 = zext i8 %r3963 to i64
  %r3965 = fptosi double %r3931 to i64
  %r3966 = sitofp i64 %r3965 to double
  %r3967 = fcmp oeq double %r3966, %r3931
  %r3968 = inttoptr i64 %r3960 to ptr
  %r3969 = load i32, ptr %r3968, align 4
  %r3970 = zext i32 %r3969 to i64
  %r3971 = icmp ult i64 %r3965, %r3970
  %r3972 = and i1 %r3967, %r3971
  br i1 %r3972, label %tav.get.load.584, label %tav.get.slow.585

tav.get.load.584:                                 ; preds = %tav.get.fast.583
  %r3973 = add nuw nsw i64 %r3960, 16
  %r3974 = icmp eq i64 %r3964, 0
  br i1 %r3974, label %tav.k.i8.588, label %tav.kd1.596

tav.get.slow.585:                                 ; preds = %tav.get.brand.587, %tav.get.fast.583, %shadow.root.barrier.done.582
  %r4025 = load ptr, ptr @perry_ic_test_json_warm_unique_keys_ts__8, align 8
  %r4026 = icmp ne ptr %r4025, null
  %r4027 = select i1 %r4026, ptr %r4025, ptr @perry_ic_test_json_warm_unique_keys_ts__8
  %r4028 = bitcast double %r3929 to i64
  %r4029 = and i64 %r4028, 281474976710655
  %r4030 = and i64 %r4028, -281474976710656
  %r4031 = icmp eq i64 %r4030, 9222527611924643840
  %r4032 = icmp uge i64 %r4029, 2199023255552
  %r4033 = icmp ult i64 %r4029, 140737488355328
  %r4034 = fcmp oge double %r3931, 0.000000e+00
  %r4035 = fcmp olt double %r3931, 0x41EFFFFFFFE00000
  %r4036 = and i1 %r4031, %r4032
  %r4037 = and i1 %r4036, %r4033
  %r4038 = and i1 %r4034, %r4035
  %r4039 = and i1 %r4037, %r4038
  br i1 %r4039, label %arrlike.ic.header.603, label %arrlike.ic.miss.622

tav.get.merge.586:                                ; preds = %arrlike.elem.value.628, %arrlike.ic.miss.622, %arrlike.ic.spill_load.621, %arrlike.ic.inline.618, %arrlike.ic.array_load.606, %tav.k.f64.595, %tav.k.f32.594, %tav.k.u32.593, %tav.k.i32.592, %tav.k.u16.591, %tav.k.i16.590, %tav.k.u8.589, %tav.k.i8.588
  %.01015 = phi ptr addrspace(1) [ %rs4gc.s98, %tav.k.i8.588 ], [ %rs4gc.s98, %tav.k.u8.589 ], [ %rs4gc.s98, %tav.k.i16.590 ], [ %rs4gc.s98, %tav.k.u16.591 ], [ %rs4gc.s98, %tav.k.i32.592 ], [ %rs4gc.s98, %tav.k.u32.593 ], [ %rs4gc.s98, %tav.k.f32.594 ], [ %rs4gc.s98, %tav.k.f64.595 ], [ %rs4gc.s98, %arrlike.ic.array_load.606 ], [ %rs4gc.s98.relocated, %arrlike.ic.miss.622 ], [ %rs4gc.s98, %arrlike.elem.value.628 ], [ %rs4gc.s98, %arrlike.ic.inline.618 ], [ %rs4gc.s98, %arrlike.ic.spill_load.621 ]
  %.31002 = phi ptr addrspace(1) [ %.21001, %tav.k.i8.588 ], [ %.21001, %tav.k.u8.589 ], [ %.21001, %tav.k.i16.590 ], [ %.21001, %tav.k.u16.591 ], [ %.21001, %tav.k.i32.592 ], [ %.21001, %tav.k.u32.593 ], [ %.21001, %tav.k.f32.594 ], [ %.21001, %tav.k.f64.595 ], [ %.21001, %arrlike.ic.array_load.606 ], [ %rs4gc.s93.relocated432, %arrlike.ic.miss.622 ], [ %.21001, %arrlike.elem.value.628 ], [ %.21001, %arrlike.ic.inline.618 ], [ %.21001, %arrlike.ic.spill_load.621 ]
  %.3991 = phi ptr addrspace(1) [ %.2990, %tav.k.i8.588 ], [ %.2990, %tav.k.u8.589 ], [ %.2990, %tav.k.i16.590 ], [ %.2990, %tav.k.u16.591 ], [ %.2990, %tav.k.i32.592 ], [ %.2990, %tav.k.u32.593 ], [ %.2990, %tav.k.f32.594 ], [ %.2990, %tav.k.f64.595 ], [ %.2990, %arrlike.ic.array_load.606 ], [ %r3514.0.relocated435, %arrlike.ic.miss.622 ], [ %.2990, %arrlike.elem.value.628 ], [ %.2990, %arrlike.ic.inline.618 ], [ %.2990, %arrlike.ic.spill_load.621 ]
  %.3980 = phi ptr addrspace(1) [ %.2979, %tav.k.i8.588 ], [ %.2979, %tav.k.u8.589 ], [ %.2979, %tav.k.i16.590 ], [ %.2979, %tav.k.u16.591 ], [ %.2979, %tav.k.i32.592 ], [ %.2979, %tav.k.u32.593 ], [ %.2979, %tav.k.f32.594 ], [ %.2979, %tav.k.f64.595 ], [ %.2979, %arrlike.ic.array_load.606 ], [ %r3514.0.base.relocated433, %arrlike.ic.miss.622 ], [ %.2979, %arrlike.elem.value.628 ], [ %.2979, %arrlike.ic.inline.618 ], [ %.2979, %arrlike.ic.spill_load.621 ]
  %.4964 = phi ptr addrspace(1) [ %.3963, %tav.k.i8.588 ], [ %.3963, %tav.k.u8.589 ], [ %.3963, %tav.k.i16.590 ], [ %.3963, %tav.k.u16.591 ], [ %.3963, %tav.k.i32.592 ], [ %.3963, %tav.k.u32.593 ], [ %.3963, %tav.k.f32.594 ], [ %.3963, %tav.k.f64.595 ], [ %.3963, %arrlike.ic.array_load.606 ], [ %rs4gc.s91.relocated434, %arrlike.ic.miss.622 ], [ %.3963, %arrlike.elem.value.628 ], [ %.3963, %arrlike.ic.inline.618 ], [ %.3963, %arrlike.ic.spill_load.621 ]
  %r4198 = phi double [ %r3987, %tav.k.i8.588 ], [ %r3993, %tav.k.u8.589 ], [ %r3999, %tav.k.i16.590 ], [ %r4005, %tav.k.u16.591 ], [ %r4010, %tav.k.i32.592 ], [ %r4015, %tav.k.u32.593 ], [ %r4020, %tav.k.f32.594 ], [ %r4024, %tav.k.f64.595 ], [ %r4081, %arrlike.elem.value.628 ], [ %r4109, %arrlike.ic.array_load.606 ], [ %r4179, %arrlike.ic.inline.618 ], [ %r4196, %arrlike.ic.spill_load.621 ], [ %r4197431, %arrlike.ic.miss.622 ]
  %r4199 = bitcast double %r4198 to i64
  %r4200 = and i64 %r4199, 281474976710655
  %r4201 = lshr i64 %r4199, 48
  %r4202 = and i64 %r4201, 65533
  %r4203 = icmp eq i64 %r4202, 32765
  br i1 %r4203, label %pget.recv_ok.631, label %pget.recv_other.635

tav.get.brand.587:                                ; preds = %shadow.root.barrier.done.582
  %r3943 = bitcast double %r3929 to i64
  %r3944 = and i64 %r3943, 281474976710655
  %r3945 = sub nsw i64 %r3944, 8
  %r3946 = inttoptr i64 %r3945 to ptr
  %r3947 = load i8, ptr %r3946, align 1
  %r3948 = icmp eq i8 %r3947, 11
  %r3949 = add nuw nsw i64 %r3944, 8
  %r3950 = inttoptr i64 %r3949 to ptr
  %r3951 = load i8, ptr %r3950, align 1
  %r3952 = zext i8 %r3951 to i64
  %r3953 = icmp ule i64 %r3952, 8
  %r3954 = fcmp oge double %r3931, 0.000000e+00
  %r3955 = fcmp olt double %r3931, 0x41F0000000000000
  %r3956 = and i1 %r3948, %r3953
  %r3957 = and i1 %r3956, %r3954
  %r3958 = and i1 %r3957, %r3955
  br i1 %r3958, label %tav.get.fast.583, label %tav.get.slow.585

tav.k.i8.588:                                     ; preds = %tav.get.load.584
  %r3982 = shl nuw nsw i64 %r3965, 0
  %r3983 = add nuw nsw i64 %r3973, %r3982
  %r3984 = inttoptr i64 %r3983 to ptr
  %r3985 = load i8, ptr %r3984, align 1
  %r3986 = sext i8 %r3985 to i32
  %r3987 = sitofp i32 %r3986 to double
  br label %tav.get.merge.586

tav.k.u8.589:                                     ; preds = %tav.kd7.602, %tav.kd1.596
  %r3988 = shl nuw nsw i64 %r3965, 0
  %r3989 = add nuw nsw i64 %r3973, %r3988
  %r3990 = inttoptr i64 %r3989 to ptr
  %r3991 = load i8, ptr %r3990, align 1
  %r3992 = zext i8 %r3991 to i32
  %r3993 = uitofp nneg i32 %r3992 to double
  br label %tav.get.merge.586

tav.k.i16.590:                                    ; preds = %tav.kd2.597
  %r3994 = shl nuw nsw i64 %r3965, 1
  %r3995 = add nuw nsw i64 %r3973, %r3994
  %r3996 = inttoptr i64 %r3995 to ptr
  %r3997 = load i16, ptr %r3996, align 2
  %r3998 = sext i16 %r3997 to i32
  %r3999 = sitofp i32 %r3998 to double
  br label %tav.get.merge.586

tav.k.u16.591:                                    ; preds = %tav.kd3.598
  %r4000 = shl nuw nsw i64 %r3965, 1
  %r4001 = add nuw nsw i64 %r3973, %r4000
  %r4002 = inttoptr i64 %r4001 to ptr
  %r4003 = load i16, ptr %r4002, align 2
  %r4004 = zext i16 %r4003 to i32
  %r4005 = uitofp nneg i32 %r4004 to double
  br label %tav.get.merge.586

tav.k.i32.592:                                    ; preds = %tav.kd4.599
  %r4006 = shl nuw nsw i64 %r3965, 2
  %r4007 = add nuw nsw i64 %r3973, %r4006
  %r4008 = inttoptr i64 %r4007 to ptr
  %r4009 = load i32, ptr %r4008, align 4
  %r4010 = sitofp i32 %r4009 to double
  br label %tav.get.merge.586

tav.k.u32.593:                                    ; preds = %tav.kd5.600
  %r4011 = shl nuw nsw i64 %r3965, 2
  %r4012 = add nuw nsw i64 %r3973, %r4011
  %r4013 = inttoptr i64 %r4012 to ptr
  %r4014 = load i32, ptr %r4013, align 4
  %r4015 = uitofp i32 %r4014 to double
  br label %tav.get.merge.586

tav.k.f32.594:                                    ; preds = %tav.kd6.601
  %r4016 = shl nuw nsw i64 %r3965, 2
  %r4017 = add nuw nsw i64 %r3973, %r4016
  %r4018 = inttoptr i64 %r4017 to ptr
  %r4019 = load float, ptr %r4018, align 4
  %r4020 = fpext float %r4019 to double
  br label %tav.get.merge.586

tav.k.f64.595:                                    ; preds = %tav.kd7.602
  %r4021 = shl nuw nsw i64 %r3965, 3
  %r4022 = add nuw nsw i64 %r3973, %r4021
  %r4023 = inttoptr i64 %r4022 to ptr
  %r4024 = load double, ptr %r4023, align 8
  br label %tav.get.merge.586

tav.kd1.596:                                      ; preds = %tav.get.load.584
  %r3975 = icmp eq i64 %r3964, 1
  br i1 %r3975, label %tav.k.u8.589, label %tav.kd2.597

tav.kd2.597:                                      ; preds = %tav.kd1.596
  %r3976 = icmp eq i64 %r3964, 2
  br i1 %r3976, label %tav.k.i16.590, label %tav.kd3.598

tav.kd3.598:                                      ; preds = %tav.kd2.597
  %r3977 = icmp eq i64 %r3964, 3
  br i1 %r3977, label %tav.k.u16.591, label %tav.kd4.599

tav.kd4.599:                                      ; preds = %tav.kd3.598
  %r3978 = icmp eq i64 %r3964, 4
  br i1 %r3978, label %tav.k.i32.592, label %tav.kd5.600

tav.kd5.600:                                      ; preds = %tav.kd4.599
  %r3979 = icmp eq i64 %r3964, 5
  br i1 %r3979, label %tav.k.u32.593, label %tav.kd6.601

tav.kd6.601:                                      ; preds = %tav.kd5.600
  %r3980 = icmp eq i64 %r3964, 6
  br i1 %r3980, label %tav.k.f32.594, label %tav.kd7.602

tav.kd7.602:                                      ; preds = %tav.kd6.601
  %r3981 = icmp eq i64 %r3964, 7
  br i1 %r3981, label %tav.k.f64.595, label %tav.k.u8.589

arrlike.ic.header.603:                            ; preds = %tav.get.slow.585
  %r4040 = fptosi double %r3931 to i64
  %r4041 = sitofp i64 %r4040 to double
  %r4042 = fcmp oeq double %r4041, %r3931
  %r4043 = sub nuw nsw i64 %r4029, 8
  %r4044 = inttoptr i64 %r4043 to ptr
  %r4045 = load i8, ptr %r4044, align 1
  %r4047 = sub nuw nsw i64 %r4029, 7
  %r4048 = inttoptr i64 %r4047 to ptr
  %r4049 = load i8, ptr %r4048, align 1
  %r4050 = and i8 %r4049, -128
  %r4051 = icmp eq i8 %r4050, 0
  %r4052 = and i1 %r4042, %r4051
  br i1 %r4052, label %arrlike.ic.brand.604, label %arrlike.ic.miss.622

arrlike.ic.brand.604:                             ; preds = %arrlike.ic.header.603
  %r4046 = icmp eq i8 %r4045, 1
  br i1 %r4046, label %arrlike.ic.array_guard.605, label %arrlike.elem.kind.623

arrlike.ic.array_guard.605:                       ; preds = %arrlike.ic.brand.604
  %r4084 = sub nuw nsw i64 %r4029, 6
  %r4085 = inttoptr i64 %r4084 to ptr
  %r4086 = load i16, ptr %r4085, align 2
  %r4087 = and i16 %r4086, 1024
  %r4088 = icmp eq i16 %r4087, 0
  %r4089 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r4090 = icmp eq i8 %r4089, 0
  %r4091 = inttoptr i64 %r4029 to ptr
  %r4092 = load i32, ptr %r4091, align 4
  %r4093 = add nuw nsw i64 %r4029, 4
  %r4094 = inttoptr i64 %r4093 to ptr
  %r4095 = load i32, ptr %r4094, align 4
  %r4096 = zext i32 %r4092 to i64
  %r4097 = zext i32 %r4095 to i64
  %r4098 = icmp ult i64 %r4040, %r4096
  %r4099 = icmp ule i64 %r4096, %r4097
  %r4100 = and i1 %r4088, %r4090
  %r4101 = and i1 %r4100, %r4098
  %r4102 = and i1 %r4101, %r4099
  br i1 %r4102, label %arrlike.ic.array_load.606, label %arrlike.ic.miss.622

arrlike.ic.array_load.606:                        ; preds = %arrlike.ic.array_guard.605
  %r4103 = add nuw nsw i64 %r4040, 1
  %r4104 = getelementptr inbounds nuw i64, ptr %r4091, i64 %r4103
  %r4105 = load double, ptr %r4104, align 8
  %r4106 = bitcast double %r4105 to i64
  %r4107 = icmp eq i64 %r4106, 9222246136947933200
  %r4109 = select i1 %r4107, double 0x7FFC000000000001, double %r4105
  br label %tav.get.merge.586

arrlike.ic.shape.607:                             ; preds = %arrlike.elem.store.625, %arrlike.elem.meta.624
  %r4111 = inttoptr i64 %r4029 to ptr
  %r4112 = load i32, ptr %r4111, align 4
  %r4113 = add nuw nsw i64 %r4029, 4
  %r4114 = inttoptr i64 %r4113 to ptr
  %r4115 = load i32, ptr %r4114, align 4
  %r4116 = zext i32 %r4112 to i64
  %r4117 = zext i32 %r4115 to i64
  %r4118 = shl nuw i64 %r4116, 32
  %r4119 = or i64 %r4118, %r4117
  %r4120 = getelementptr i64, ptr %r4027, i64 0
  %r4121 = load i64, ptr %r4120, align 8
  %r4122 = icmp ne i64 %r4121, 0
  %r4123 = and i1 true, %r4122
  br i1 %r4123, label %arrlike.ic.identity.608, label %arrlike.ic.miss.622

arrlike.ic.identity.608:                          ; preds = %arrlike.ic.shape.607
  %r4124 = and i64 %r4121, -9223372036854775808
  %0 = icmp slt i64 %r4121, 0
  br i1 %0, label %arrlike.ic.family_meta.610, label %arrlike.ic.exact.609

arrlike.ic.exact.609:                             ; preds = %arrlike.ic.identity.608
  %r4126 = icmp eq i64 %r4119, %r4121
  br i1 %r4126, label %arrlike.ic.bounds.612, label %arrlike.ic.miss.622

arrlike.ic.family_meta.610:                       ; preds = %arrlike.ic.identity.608
  %r4127 = add nuw nsw i64 %r4029, 8
  %r4128 = inttoptr i64 %r4127 to ptr
  %r4129 = load i64, ptr %r4128, align 8
  %r4130 = icmp ne i64 %r4129, 0
  br i1 %r4130, label %arrlike.ic.family_token.611, label %arrlike.ic.miss.622

arrlike.ic.family_token.611:                      ; preds = %arrlike.ic.family_meta.610
  %r4131 = inttoptr i64 %r4129 to ptr
  %r4132 = getelementptr i64, ptr %r4131, i64 6
  %r4133 = load i64, ptr %r4132, align 8
  %r4134 = icmp eq i64 %r4133, %r4121
  br i1 %r4134, label %arrlike.ic.bounds.612, label %arrlike.ic.miss.622

arrlike.ic.bounds.612:                            ; preds = %arrlike.ic.family_token.611, %arrlike.ic.exact.609
  %r4135 = getelementptr i64, ptr %r4025, i64 1
  %r4136 = load i64, ptr %r4135, align 8
  %r4137 = getelementptr i64, ptr %r4025, i64 2
  %r4138 = load i64, ptr %r4137, align 8
  %r4139 = getelementptr i64, ptr %r4025, i64 3
  %r4140 = load i64, ptr %r4139, align 8
  %r4141 = getelementptr i64, ptr %r4025, i64 4
  %r4142 = load i64, ptr %r4141, align 8
  %r4143 = icmp ult i64 %r4136, %r4142
  br i1 %r4143, label %arrlike.ic.length_inline.613, label %arrlike.ic.length_spill_meta.614

arrlike.ic.length_inline.613:                     ; preds = %arrlike.ic.bounds.612
  %r4144 = shl i64 %r4136, 3
  %r4145 = add i64 %r4144, 16
  %r4146 = add i64 %r4029, %r4145
  %r4147 = inttoptr i64 %r4146 to ptr
  %r4148 = load double, ptr %r4147, align 8
  br label %arrlike.ic.range.617

arrlike.ic.length_spill_meta.614:                 ; preds = %arrlike.ic.bounds.612
  %r4149 = add nuw nsw i64 %r4029, 8
  %r4150 = inttoptr i64 %r4149 to ptr
  %r4151 = load i64, ptr %r4150, align 8
  %r4152 = icmp ne i64 %r4151, 0
  br i1 %r4152, label %arrlike.ic.length_spill_ptr.615, label %arrlike.ic.miss.622

arrlike.ic.length_spill_ptr.615:                  ; preds = %arrlike.ic.length_spill_meta.614
  %r4153 = inttoptr i64 %r4151 to ptr
  %r4154 = getelementptr i64, ptr %r4153, i64 4
  %r4155 = load i64, ptr %r4154, align 8
  %r4156 = icmp ne i64 %r4155, 0
  %r4157 = select i1 %r4156, i64 %r4155, i64 %r4151
  %r4158 = inttoptr i64 %r4157 to ptr
  %r4159 = load i32, ptr %r4158, align 4
  %r4160 = zext i32 %r4159 to i64
  %r4161 = icmp ult i64 %r4136, %r4160
  %r4162 = and i1 %r4156, %r4161
  br i1 %r4162, label %arrlike.ic.length_spill_load.616, label %arrlike.ic.miss.622

arrlike.ic.length_spill_load.616:                 ; preds = %arrlike.ic.length_spill_ptr.615
  %r4163 = add nuw nsw i64 %r4136, 1
  %r4164 = getelementptr inbounds nuw i64, ptr %r4158, i64 %r4163
  %r4165 = load double, ptr %r4164, align 8
  br label %arrlike.ic.range.617

arrlike.ic.range.617:                             ; preds = %arrlike.ic.length_spill_load.616, %arrlike.ic.length_inline.613
  %r4166 = phi double [ %r4148, %arrlike.ic.length_inline.613 ], [ %r4165, %arrlike.ic.length_spill_load.616 ]
  %r4167 = fcmp olt double %r3931, %r4166
  %r4168 = icmp ult i64 %r4040, %r4140
  %r4169 = and i1 %r4167, %r4168
  %r4170 = add i64 %r4138, %r4040
  %r4171 = icmp ult i64 %r4170, %r4142
  %r4172 = and i1 %r4169, %r4171
  %r4173 = xor i1 %r4171, true
  %r4174 = and i1 %r4169, %r4173
  br i1 %r4172, label %arrlike.ic.inline.618, label %arrlike.ic.spill_or_miss.629

arrlike.ic.inline.618:                            ; preds = %arrlike.ic.range.617
  %r4175 = shl i64 %r4170, 3
  %r4176 = add i64 %r4175, 16
  %r4177 = add i64 %r4029, %r4176
  %r4178 = inttoptr i64 %r4177 to ptr
  %r4179 = load double, ptr %r4178, align 8
  br label %tav.get.merge.586

arrlike.ic.spill.619:                             ; preds = %arrlike.ic.spill_or_miss.629
  %r4180 = add nuw nsw i64 %r4029, 8
  %r4181 = inttoptr i64 %r4180 to ptr
  %r4182 = load i64, ptr %r4181, align 8
  %r4183 = icmp ne i64 %r4182, 0
  br i1 %r4183, label %arrlike.ic.spill_ptr.620, label %arrlike.ic.miss.622

arrlike.ic.spill_ptr.620:                         ; preds = %arrlike.ic.spill.619
  %r4184 = inttoptr i64 %r4182 to ptr
  %r4185 = getelementptr i64, ptr %r4184, i64 4
  %r4186 = load i64, ptr %r4185, align 8
  %r4187 = icmp ne i64 %r4186, 0
  %r4188 = select i1 %r4187, i64 %r4186, i64 %r4182
  %r4189 = inttoptr i64 %r4188 to ptr
  %r4190 = load i32, ptr %r4189, align 4
  %r4191 = zext i32 %r4190 to i64
  %r4192 = icmp ult i64 %r4170, %r4191
  %r4193 = and i1 %r4187, %r4192
  br i1 %r4193, label %arrlike.ic.spill_load.621, label %arrlike.ic.miss.622

arrlike.ic.spill_load.621:                        ; preds = %arrlike.ic.spill_ptr.620
  %r4194 = add nuw nsw i64 %r4170, 1
  %r4195 = getelementptr inbounds nuw i64, ptr %r4189, i64 %r4194
  %r4196 = load double, ptr %r4195, align 8
  br label %tav.get.merge.586

arrlike.ic.miss.622:                              ; preds = %arrlike.ic.spill_or_miss.629, %arrlike.elem.load.627, %arrlike.elem.bounds.626, %arrlike.elem.kind.623, %arrlike.ic.spill_ptr.620, %arrlike.ic.spill.619, %arrlike.ic.length_spill_ptr.615, %arrlike.ic.length_spill_meta.614, %arrlike.ic.family_token.611, %arrlike.ic.family_meta.610, %arrlike.ic.exact.609, %arrlike.ic.shape.607, %arrlike.ic.array_guard.605, %arrlike.ic.header.603, %tav.get.slow.585
  %statepoint_token430 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, ptr)) @js_packed_arraylike_index_get, i32 3, i32 0, double %r3929, double %r3931, ptr @perry_ic_test_json_warm_unique_keys_ts__8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s98, ptr addrspace(1) %.21001, ptr addrspace(1) %.2979, ptr addrspace(1) %.3963, ptr addrspace(1) %.2990) ]
  %r4197431 = call double @llvm.experimental.gc.result.f64(token %statepoint_token430)
  %rs4gc.s98.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token430, i32 0, i32 0) ; (%rs4gc.s98, %rs4gc.s98)
  %rs4gc.s93.relocated432 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token430, i32 1, i32 1) ; (%.21001, %.21001)
  %r3514.0.base.relocated433 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token430, i32 2, i32 2) ; (%.2979, %.2979)
  %rs4gc.s91.relocated434 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token430, i32 3, i32 3) ; (%.3963, %.3963)
  %r3514.0.relocated435 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token430, i32 2, i32 4) ; (%.2979, %.2990)
  br label %tav.get.merge.586

arrlike.elem.kind.623:                            ; preds = %arrlike.ic.brand.604
  %r4053 = icmp eq i8 %r4045, 2
  br i1 %r4053, label %arrlike.elem.meta.624, label %arrlike.ic.miss.622

arrlike.elem.meta.624:                            ; preds = %arrlike.elem.kind.623
  %r4054 = add nuw nsw i64 %r4029, 8
  %r4055 = inttoptr i64 %r4054 to ptr
  %r4056 = load i64, ptr %r4055, align 8
  %r4057 = icmp ne i64 %r4056, 0
  br i1 %r4057, label %arrlike.elem.store.625, label %arrlike.ic.shape.607

arrlike.elem.store.625:                           ; preds = %arrlike.elem.meta.624
  %r4058 = inttoptr i64 %r4056 to ptr
  %r4059 = getelementptr i64, ptr %r4058, i64 12
  %r4060 = load i64, ptr %r4059, align 8
  %r4061 = icmp ne i64 %r4060, 0
  br i1 %r4061, label %arrlike.elem.bounds.626, label %arrlike.ic.shape.607

arrlike.elem.bounds.626:                          ; preds = %arrlike.elem.store.625
  %r4062 = sub i64 %r4060, 8
  %r4063 = inttoptr i64 %r4062 to ptr
  %r4064 = load i8, ptr %r4063, align 1
  %r4065 = icmp eq i8 %r4064, 1
  %r4066 = sub i64 %r4060, 7
  %r4067 = inttoptr i64 %r4066 to ptr
  %r4068 = load i8, ptr %r4067, align 1
  %r4069 = and i8 %r4068, -128
  %r4070 = icmp eq i8 %r4069, 0
  %r4071 = inttoptr i64 %r4060 to ptr
  %r4072 = load i32, ptr %r4071, align 4
  %r4073 = zext i32 %r4072 to i64
  %r4074 = icmp ult i64 %r4040, %r4073
  %r4075 = and i1 %r4065, %r4070
  %r4076 = and i1 %r4075, %r4074
  br i1 %r4076, label %arrlike.elem.load.627, label %arrlike.ic.miss.622

arrlike.elem.load.627:                            ; preds = %arrlike.elem.bounds.626
  %r4077 = shl nuw nsw i64 %r4040, 3
  %r4078 = add i64 %r4060, 8
  %r4079 = add i64 %r4078, %r4077
  %r4080 = inttoptr i64 %r4079 to ptr
  %r4081 = load double, ptr %r4080, align 8
  %r4082 = bitcast double %r4081 to i64
  %r4083 = icmp eq i64 %r4082, 9222246136947933200
  br i1 %r4083, label %arrlike.ic.miss.622, label %arrlike.elem.value.628

arrlike.elem.value.628:                           ; preds = %arrlike.elem.load.627
  br label %tav.get.merge.586

arrlike.ic.spill_or_miss.629:                     ; preds = %arrlike.ic.range.617
  br i1 %r4174, label %arrlike.ic.spill.619, label %arrlike.ic.miss.622

pget.recv_sso.630:                                ; preds = %pget.recv_other.635
  %r4341 = load double, ptr @test_json_warm_unique_keys_ts_.str.0.handle, align 8
  %r4342 = bitcast double %r4341 to i64
  %r4343 = and i64 %r4342, 281474976710655
  %statepoint_token436 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r4199, i64 %r4343, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31002, ptr addrspace(1) %.3980, ptr addrspace(1) %.4964, ptr addrspace(1) %.01015, ptr addrspace(1) %.3991) ]
  %r4344437 = call double @llvm.experimental.gc.result.f64(token %statepoint_token436)
  %rs4gc.s93.relocated438 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token436, i32 0, i32 0) ; (%.31002, %.31002)
  %r3514.0.base.relocated439 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token436, i32 1, i32 1) ; (%.3980, %.3980)
  %rs4gc.s91.relocated440 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token436, i32 2, i32 2) ; (%.4964, %.4964)
  %rs4gc.s98.relocated441 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token436, i32 3, i32 3) ; (%.01015, %.01015)
  %r3514.0.relocated442 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token436, i32 1, i32 4) ; (%.3980, %.3991)
  br label %pget.recv_merge.634

pget.recv_ok.631:                                 ; preds = %tav.get.merge.586
  %r4210 = icmp ugt i64 %r4200, 1048575
  br i1 %r4210, label %pic.recv_hdr.652, label %pic.miss.cold.649

pget.recv_bad.632:                                ; preds = %pget.check_class_ref.636
  %r4333 = icmp eq i64 %r4199, 9222246136947933185
  %r4334 = icmp eq i64 %r4199, 9222246136947933186
  %r4335 = or i1 %r4333, %r4334
  br i1 %r4335, label %pget.throw_nullish.659, label %pget.recv_undef_return.660

pget.recv_class_ref.633:                          ; preds = %pget.check_class_ref.636
  %r4206 = load double, ptr @test_json_warm_unique_keys_ts_.str.0.handle, align 8
  %r4207 = bitcast double %r4206 to i64
  %r4208 = and i64 %r4207, 281474976710655
  %statepoint_token443 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 547434508618563593, i64 %r4199, i64 %r4208, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31002, ptr addrspace(1) %.3980, ptr addrspace(1) %.4964, ptr addrspace(1) %.01015, ptr addrspace(1) %.3991) ]
  %r4209444 = call double @llvm.experimental.gc.result.f64(token %statepoint_token443)
  %rs4gc.s93.relocated445 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token443, i32 0, i32 0) ; (%.31002, %.31002)
  %r3514.0.base.relocated446 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token443, i32 1, i32 1) ; (%.3980, %.3980)
  %rs4gc.s91.relocated447 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token443, i32 2, i32 2) ; (%.4964, %.4964)
  %rs4gc.s98.relocated448 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token443, i32 3, i32 3) ; (%.01015, %.01015)
  %r3514.0.relocated449 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token443, i32 1, i32 4) ; (%.3980, %.3991)
  br label %pget.recv_merge.634

pget.recv_merge.634:                              ; preds = %pget.recv_undef_return.660, %pic.merge.651, %pget.recv_class_ref.633, %pget.recv_sso.630
  %.11016 = phi ptr addrspace(1) [ %.21017, %pic.merge.651 ], [ %rs4gc.s98.relocated441, %pget.recv_sso.630 ], [ %rs4gc.s98.relocated448, %pget.recv_class_ref.633 ], [ %rs4gc.s98.relocated470, %pget.recv_undef_return.660 ]
  %.41003 = phi ptr addrspace(1) [ %.51004, %pic.merge.651 ], [ %rs4gc.s93.relocated438, %pget.recv_sso.630 ], [ %rs4gc.s93.relocated445, %pget.recv_class_ref.633 ], [ %rs4gc.s93.relocated467, %pget.recv_undef_return.660 ]
  %.4992 = phi ptr addrspace(1) [ %.5993, %pic.merge.651 ], [ %r3514.0.relocated442, %pget.recv_sso.630 ], [ %r3514.0.relocated449, %pget.recv_class_ref.633 ], [ %r3514.0.relocated471, %pget.recv_undef_return.660 ]
  %.4981 = phi ptr addrspace(1) [ %.5982, %pic.merge.651 ], [ %r3514.0.base.relocated439, %pget.recv_sso.630 ], [ %r3514.0.base.relocated446, %pget.recv_class_ref.633 ], [ %r3514.0.base.relocated468, %pget.recv_undef_return.660 ]
  %.5965 = phi ptr addrspace(1) [ %.6966, %pic.merge.651 ], [ %rs4gc.s91.relocated440, %pget.recv_sso.630 ], [ %rs4gc.s91.relocated447, %pget.recv_class_ref.633 ], [ %rs4gc.s91.relocated469, %pget.recv_undef_return.660 ]
  %r4345 = phi double [ %r4332, %pic.merge.651 ], [ %r4340466, %pget.recv_undef_return.660 ], [ %r4344437, %pget.recv_sso.630 ], [ %r4209444, %pget.recv_class_ref.633 ]
  %r4346.rs4i = ptrtoint ptr addrspace(1) %.11016 to i64
  %r4346 = call i64 asm "", "=r,0"(i64 %r4346.rs4i) #7
  %r4347 = bitcast i64 %r4346 to double
  %r4348 = and i64 %r4346, -281474976710656
  %r4349 = icmp ult i64 %r4348, 9221401712017801216
  %r4350 = icmp ugt i64 %r4348, 9223090561878065152
  %r4351 = or i1 %r4349, %r4350
  %r4352 = bitcast double %r4345 to i64
  %r4353 = and i64 %r4352, -281474976710656
  %r4354 = icmp ult i64 %r4353, 9221401712017801216
  %r4355 = icmp ugt i64 %r4353, 9223090561878065152
  %r4356 = or i1 %r4354, %r4355
  %r4357 = and i1 %r4351, %r4356
  br i1 %r4357, label %guarded_add.numeric.661, label %guarded_add.dynamic.662

pget.recv_other.635:                              ; preds = %tav.get.merge.586
  %r4204 = icmp eq i64 %r4201, 32761
  br i1 %r4204, label %pget.recv_sso.630, label %pget.check_class_ref.636

pget.check_class_ref.636:                         ; preds = %pget.recv_other.635
  %r4205 = icmp eq i64 %r4201, 32766
  br i1 %r4205, label %pget.recv_class_ref.633, label %pget.recv_bad.632

pic.hit.637:                                      ; preds = %pic.token.653
  %r4235 = getelementptr i64, ptr %r4220, i64 1
  %r4236 = load i64, ptr %r4235, align 8
  %r4237 = and i64 %r4236, 1073741824
  %r4238 = icmp ne i64 %r4237, 0
  br i1 %r4238, label %pic.hit.overflow.654, label %pic.hit.inline.655

pic.hit.live.638:                                 ; preds = %pic.hit.inline.655
  br label %pic.merge.651

pic.prefix.guard.639:                             ; preds = %pic.token.653
  %r4251 = getelementptr i64, ptr %r4220, i64 2
  %r4252 = load i64, ptr %r4251, align 8
  %r4253 = icmp ne i64 %r4252, 0
  br i1 %r4253, label %pic.prefix.meta.640, label %pic.miss.648

pic.prefix.meta.640:                              ; preds = %pic.prefix.guard.639
  %r4254 = add nuw nsw i64 %r4200, 8
  %r4255 = inttoptr i64 %r4254 to ptr
  %r4256 = load i64, ptr %r4255, align 8
  %r4257 = icmp ne i64 %r4256, 0
  br i1 %r4257, label %pic.prefix.token.641, label %pic.miss.648

pic.prefix.token.641:                             ; preds = %pic.prefix.meta.640
  %r4258 = inttoptr i64 %r4256 to ptr
  %r4259 = getelementptr i64, ptr %r4258, i64 6
  %r4260 = load i64, ptr %r4259, align 8
  %r4261 = icmp eq i64 %r4260, %r4252
  br i1 %r4261, label %pic.prefix.hit.642, label %pic.miss.648

pic.prefix.hit.642:                               ; preds = %pic.prefix.token.641
  %r4262 = getelementptr i64, ptr %r4220, i64 1
  %r4263 = load i64, ptr %r4262, align 8
  %r4264 = shl i64 %r4263, 3
  %r4265 = add nuw nsw i64 %r4200, 16
  %r4266 = add i64 %r4265, %r4264
  %r4267 = inttoptr i64 %r4266 to ptr
  %r4268 = load double, ptr %r4267, align 8
  br label %pic.merge.651

pic.desc.classify.643:                            ; preds = %pic.recv_hdr.652
  %r4224 = and i1 %r4214, %r4221
  br i1 %r4224, label %pic.desc.prefix.guard.644, label %pic.miss.cold.649

pic.desc.prefix.guard.644:                        ; preds = %pic.desc.classify.643
  %r4269 = getelementptr i64, ptr %r4220, i64 2
  %r4270 = load i64, ptr %r4269, align 8
  %r4271 = icmp ne i64 %r4270, 0
  br i1 %r4271, label %pic.desc.prefix.meta.645, label %pic.miss.cold.649

pic.desc.prefix.meta.645:                         ; preds = %pic.desc.prefix.guard.644
  %r4272 = add nuw nsw i64 %r4200, 8
  %r4273 = inttoptr i64 %r4272 to ptr
  %r4274 = load i64, ptr %r4273, align 8
  %r4275 = icmp ne i64 %r4274, 0
  br i1 %r4275, label %pic.desc.prefix.token.646, label %pic.miss.cold.649

pic.desc.prefix.token.646:                        ; preds = %pic.desc.prefix.meta.645
  %r4276 = inttoptr i64 %r4274 to ptr
  %r4277 = getelementptr i64, ptr %r4276, i64 6
  %r4278 = load i64, ptr %r4277, align 8
  %r4279 = icmp eq i64 %r4278, %r4270
  br i1 %r4279, label %pic.desc.prefix.hit.647, label %pic.miss.cold.649

pic.desc.prefix.hit.647:                          ; preds = %pic.desc.prefix.token.646
  %r4280 = getelementptr i64, ptr %r4220, i64 1
  %r4281 = load i64, ptr %r4280, align 8
  %r4282 = shl i64 %r4281, 3
  %r4283 = add nuw nsw i64 %r4200, 16
  %r4284 = add i64 %r4283, %r4282
  %r4285 = inttoptr i64 %r4284 to ptr
  %r4286 = load double, ptr %r4285, align 8
  br label %pic.merge.651

pic.miss.648:                                     ; preds = %pic.hit.inline.655, %pic.prefix.token.641, %pic.prefix.meta.640, %pic.prefix.guard.639
  %r4287 = getelementptr i64, ptr %r4220, i64 3
  %r4288 = load i64, ptr %r4287, align 8
  %r4289 = icmp sgt i64 %r4288, 0
  br i1 %r4289, label %pic.ways.656, label %pic.miss.call.650

pic.miss.cold.649:                                ; preds = %pic.desc.prefix.token.646, %pic.desc.prefix.meta.645, %pic.desc.prefix.guard.644, %pic.desc.classify.643, %pget.recv_ok.631
  br label %pic.miss.call.650

pic.miss.call.650:                                ; preds = %pic.way.load.657, %pic.ways.656, %pic.miss.cold.649, %pic.miss.648
  %r4328 = load double, ptr @test_json_warm_unique_keys_ts_.str.0.handle, align 8
  %r4329 = bitcast double %r4328 to i64
  %r4330 = and i64 %r4329, 281474976710655
  %statepoint_token450 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r4200, i64 %r4330, ptr @perry_ic_test_json_warm_unique_keys_ts__10, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31002, ptr addrspace(1) %.3980, ptr addrspace(1) %.4964, ptr addrspace(1) %.01015, ptr addrspace(1) %.3991) ]
  %r4331451 = call double @llvm.experimental.gc.result.f64(token %statepoint_token450)
  %rs4gc.s93.relocated452 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token450, i32 0, i32 0) ; (%.31002, %.31002)
  %r3514.0.base.relocated453 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token450, i32 1, i32 1) ; (%.3980, %.3980)
  %rs4gc.s91.relocated454 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token450, i32 2, i32 2) ; (%.4964, %.4964)
  %rs4gc.s98.relocated455 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token450, i32 3, i32 3) ; (%.01015, %.01015)
  %r3514.0.relocated456 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token450, i32 1, i32 4) ; (%.3980, %.3991)
  br label %pic.merge.651

pic.merge.651:                                    ; preds = %pic.way.live.658, %pic.hit.overflow.654, %pic.miss.call.650, %pic.desc.prefix.hit.647, %pic.prefix.hit.642, %pic.hit.live.638
  %.21017 = phi ptr addrspace(1) [ %rs4gc.s98.relocated462, %pic.hit.overflow.654 ], [ %rs4gc.s98.relocated455, %pic.miss.call.650 ], [ %.01015, %pic.way.live.658 ], [ %.01015, %pic.hit.live.638 ], [ %.01015, %pic.prefix.hit.642 ], [ %.01015, %pic.desc.prefix.hit.647 ]
  %.51004 = phi ptr addrspace(1) [ %rs4gc.s93.relocated459, %pic.hit.overflow.654 ], [ %rs4gc.s93.relocated452, %pic.miss.call.650 ], [ %.31002, %pic.way.live.658 ], [ %.31002, %pic.hit.live.638 ], [ %.31002, %pic.prefix.hit.642 ], [ %.31002, %pic.desc.prefix.hit.647 ]
  %.5993 = phi ptr addrspace(1) [ %r3514.0.relocated463, %pic.hit.overflow.654 ], [ %r3514.0.relocated456, %pic.miss.call.650 ], [ %.3991, %pic.way.live.658 ], [ %.3991, %pic.hit.live.638 ], [ %.3991, %pic.prefix.hit.642 ], [ %.3991, %pic.desc.prefix.hit.647 ]
  %.5982 = phi ptr addrspace(1) [ %r3514.0.base.relocated460, %pic.hit.overflow.654 ], [ %r3514.0.base.relocated453, %pic.miss.call.650 ], [ %.3980, %pic.way.live.658 ], [ %.3980, %pic.hit.live.638 ], [ %.3980, %pic.prefix.hit.642 ], [ %.3980, %pic.desc.prefix.hit.647 ]
  %.6966 = phi ptr addrspace(1) [ %rs4gc.s91.relocated461, %pic.hit.overflow.654 ], [ %rs4gc.s91.relocated454, %pic.miss.call.650 ], [ %.4964, %pic.way.live.658 ], [ %.4964, %pic.hit.live.638 ], [ %.4964, %pic.prefix.hit.642 ], [ %.4964, %pic.desc.prefix.hit.647 ]
  %r4332 = phi double [ %r4248, %pic.hit.live.638 ], [ %r4243458, %pic.hit.overflow.654 ], [ %r4268, %pic.prefix.hit.642 ], [ %r4286, %pic.desc.prefix.hit.647 ], [ %r4325, %pic.way.live.658 ], [ %r4331451, %pic.miss.call.650 ]
  br label %pget.recv_merge.634

pic.recv_hdr.652:                                 ; preds = %pget.recv_ok.631
  %r4211 = sub nuw nsw i64 %r4200, 8
  %r4212 = inttoptr i64 %r4211 to ptr
  %r4213 = load i8, ptr %r4212, align 1
  %r4214 = icmp eq i8 %r4213, 2
  %r4215 = sub nuw nsw i64 %r4200, 6
  %r4216 = inttoptr i64 %r4215 to ptr
  %r4217 = load i16, ptr %r4216, align 2
  %r4218 = and i16 %r4217, 2048
  %r4219 = icmp eq i16 %r4218, 0
  %r4220 = load ptr, ptr @perry_ic_test_json_warm_unique_keys_ts__10, align 8
  %r4221 = icmp ne ptr %r4220, null
  %r4222 = and i1 %r4214, %r4219
  %r4223 = and i1 %r4222, %r4221
  br i1 %r4223, label %pic.token.653, label %pic.desc.classify.643

pic.token.653:                                    ; preds = %pic.recv_hdr.652
  %r4225 = add nuw nsw i64 %r4200, 4
  %r4226 = inttoptr i64 %r4225 to ptr
  %r4227 = load i32, ptr %r4226, align 4
  %r4228 = zext i32 %r4227 to i64
  %r4229 = or i64 %r4228, 4611686018427387904
  %r4230 = icmp ne i32 %r4227, 0
  %r4231 = getelementptr i64, ptr %r4220, i64 0
  %r4232 = load i64, ptr %r4231, align 8
  %r4233 = icmp eq i64 %r4229, %r4232
  %r4234 = and i1 %r4233, %r4230
  br i1 %r4234, label %pic.hit.637, label %pic.prefix.guard.639

pic.hit.overflow.654:                             ; preds = %pic.hit.637
  %r4239 = load double, ptr @test_json_warm_unique_keys_ts_.str.0.handle, align 8
  %r4240 = bitcast double %r4239 to i64
  %r4241 = and i64 %r4240, 281474976710655
  %r4242 = trunc i64 %r4236 to i32
  %statepoint_token457 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r4200, i64 %r4241, i32 %r4242, ptr @perry_ic_test_json_warm_unique_keys_ts__10, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31002, ptr addrspace(1) %.3980, ptr addrspace(1) %.4964, ptr addrspace(1) %.01015, ptr addrspace(1) %.3991) ]
  %r4243458 = call double @llvm.experimental.gc.result.f64(token %statepoint_token457)
  %rs4gc.s93.relocated459 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token457, i32 0, i32 0) ; (%.31002, %.31002)
  %r3514.0.base.relocated460 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token457, i32 1, i32 1) ; (%.3980, %.3980)
  %rs4gc.s91.relocated461 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token457, i32 2, i32 2) ; (%.4964, %.4964)
  %rs4gc.s98.relocated462 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token457, i32 3, i32 3) ; (%.01015, %.01015)
  %r3514.0.relocated463 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token457, i32 1, i32 4) ; (%.3980, %.3991)
  br label %pic.merge.651

pic.hit.inline.655:                               ; preds = %pic.hit.637
  %r4244 = shl i64 %r4236, 3
  %r4245 = add nuw nsw i64 %r4200, 16
  %r4246 = add i64 %r4245, %r4244
  %r4247 = inttoptr i64 %r4246 to ptr
  %r4248 = load double, ptr %r4247, align 8
  %r4249 = bitcast double %r4248 to i64
  %r4250 = icmp eq i64 %r4249, 9222246136947933200
  br i1 %r4250, label %pic.miss.648, label %pic.hit.live.638

pic.ways.656:                                     ; preds = %pic.miss.648
  %r4290 = getelementptr i64, ptr %r4220, i64 4
  %r4291 = load i64, ptr %r4290, align 8
  %r4292 = icmp eq i64 %r4291, %r4229
  %r4293 = getelementptr i64, ptr %r4220, i64 5
  %r4294 = load i64, ptr %r4293, align 8
  %r4295 = select i1 %r4292, i64 %r4294, i64 0
  %r4296 = getelementptr i64, ptr %r4220, i64 6
  %r4297 = load i64, ptr %r4296, align 8
  %r4298 = icmp eq i64 %r4297, %r4229
  %r4299 = getelementptr i64, ptr %r4220, i64 7
  %r4300 = load i64, ptr %r4299, align 8
  %r4301 = select i1 %r4298, i64 %r4300, i64 0
  %r4302 = getelementptr i64, ptr %r4220, i64 8
  %r4303 = load i64, ptr %r4302, align 8
  %r4304 = icmp eq i64 %r4303, %r4229
  %r4305 = getelementptr i64, ptr %r4220, i64 9
  %r4306 = load i64, ptr %r4305, align 8
  %r4307 = select i1 %r4304, i64 %r4306, i64 0
  %r4308 = getelementptr i64, ptr %r4220, i64 10
  %r4309 = load i64, ptr %r4308, align 8
  %r4310 = icmp eq i64 %r4309, %r4229
  %r4311 = getelementptr i64, ptr %r4220, i64 11
  %r4312 = load i64, ptr %r4311, align 8
  %r4313 = select i1 %r4310, i64 %r4312, i64 0
  %r4314 = or i1 %r4292, %r4298
  %r4315 = select i1 %r4292, i64 %r4295, i64 %r4301
  %r4316 = or i1 %r4304, %r4310
  %r4317 = select i1 %r4304, i64 %r4307, i64 %r4313
  %r4318 = or i1 %r4314, %r4316
  %r4319 = select i1 %r4314, i64 %r4315, i64 %r4317
  %r4320 = and i1 %r4230, %r4318
  br i1 %r4320, label %pic.way.load.657, label %pic.miss.call.650

pic.way.load.657:                                 ; preds = %pic.ways.656
  %r4321 = shl i64 %r4319, 3
  %r4322 = add nuw nsw i64 %r4200, 16
  %r4323 = add i64 %r4322, %r4321
  %r4324 = inttoptr i64 %r4323 to ptr
  %r4325 = load double, ptr %r4324, align 8
  %r4326 = bitcast double %r4325 to i64
  %r4327 = icmp eq i64 %r4326, 9222246136947933200
  br i1 %r4327, label %pic.miss.call.650, label %pic.way.live.658

pic.way.live.658:                                 ; preds = %pic.way.load.657
  br label %pic.merge.651

pget.throw_nullish.659:                           ; preds = %pget.recv_bad.632
  %r4336 = zext i1 %r4334 to i32
  %statepoint_token464 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r4336, ptr @test_json_warm_unique_keys_ts_.str.0.bytes, i64 1, i32 0, i32 0)
  unreachable

pget.recv_undef_return.660:                       ; preds = %pget.recv_bad.632
  %r4337 = load double, ptr @test_json_warm_unique_keys_ts_.str.0.handle, align 8
  %r4338 = bitcast double %r4337 to i64
  %r4339 = and i64 %r4338, 281474976710655
  %statepoint_token465 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r4199, i64 %r4339, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31002, ptr addrspace(1) %.3980, ptr addrspace(1) %.4964, ptr addrspace(1) %.01015, ptr addrspace(1) %.3991) ]
  %r4340466 = call double @llvm.experimental.gc.result.f64(token %statepoint_token465)
  %rs4gc.s93.relocated467 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token465, i32 0, i32 0) ; (%.31002, %.31002)
  %r3514.0.base.relocated468 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token465, i32 1, i32 1) ; (%.3980, %.3980)
  %rs4gc.s91.relocated469 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token465, i32 2, i32 2) ; (%.4964, %.4964)
  %rs4gc.s98.relocated470 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token465, i32 3, i32 3) ; (%.01015, %.01015)
  %r3514.0.relocated471 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token465, i32 1, i32 4) ; (%.3980, %.3991)
  br label %pget.recv_merge.634

guarded_add.numeric.661:                          ; preds = %pget.recv_merge.634
  %r4358 = fadd double %r4347, %r4345
  br label %guarded_add.merge.663

guarded_add.dynamic.662:                          ; preds = %pget.recv_merge.634
  %statepoint_token472 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r4347, double %r4345, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.41003, ptr addrspace(1) %.4981, ptr addrspace(1) %.5965, ptr addrspace(1) %.4992) ]
  %r4359473 = call double @llvm.experimental.gc.result.f64(token %statepoint_token472)
  %rs4gc.s93.relocated474 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token472, i32 0, i32 0) ; (%.41003, %.41003)
  %r3514.0.base.relocated475 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token472, i32 1, i32 1) ; (%.4981, %.4981)
  %rs4gc.s91.relocated476 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token472, i32 2, i32 2) ; (%.5965, %.5965)
  %r3514.0.relocated477 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token472, i32 1, i32 3) ; (%.4981, %.4992)
  br label %guarded_add.merge.663

guarded_add.merge.663:                            ; preds = %guarded_add.dynamic.662, %guarded_add.numeric.661
  %.61005 = phi ptr addrspace(1) [ %.41003, %guarded_add.numeric.661 ], [ %rs4gc.s93.relocated474, %guarded_add.dynamic.662 ]
  %.6994 = phi ptr addrspace(1) [ %.4992, %guarded_add.numeric.661 ], [ %r3514.0.relocated477, %guarded_add.dynamic.662 ]
  %.6983 = phi ptr addrspace(1) [ %.4981, %guarded_add.numeric.661 ], [ %r3514.0.base.relocated475, %guarded_add.dynamic.662 ]
  %.7967 = phi ptr addrspace(1) [ %.5965, %guarded_add.numeric.661 ], [ %rs4gc.s91.relocated476, %guarded_add.dynamic.662 ]
  %r4360 = phi double [ %r4358, %guarded_add.numeric.661 ], [ %r4359473, %guarded_add.dynamic.662 ]
  %rs4gc.b99 = bitcast double %r4360 to i64
  %rs4gc.s99 = inttoptr i64 %rs4gc.b99 to ptr addrspace(1)
  %r4361.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s99 to i64
  %r4361 = call i64 asm "", "=r,0"(i64 %r4361.rs4i) #7
  %r4362 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4363 = icmp ne i32 %r4362, 0
  br i1 %r4363, label %shadow.root.barrier.664, label %shadow.root.barrier.done.665

shadow.root.barrier.664:                          ; preds = %guarded_add.merge.663
  call void @js_write_barrier_root_nanbox(i64 %r4361) #7
  br label %shadow.root.barrier.done.665

shadow.root.barrier.done.665:                     ; preds = %shadow.root.barrier.664, %guarded_add.merge.663
  %r4364 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r4365 = icmp ne i32 %r4364, 0
  br i1 %r4365, label %gcpoll.666, label %gcpoll.done.667

gcpoll.666:                                       ; preds = %shadow.root.barrier.done.665
  %statepoint_token478 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s99, ptr addrspace(1) %.61005, ptr addrspace(1) %.6983, ptr addrspace(1) %.7967, ptr addrspace(1) %.6994) ]
  %rs4gc.s99.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token478, i32 0, i32 0) ; (%rs4gc.s99, %rs4gc.s99)
  %rs4gc.s93.relocated479 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token478, i32 1, i32 1) ; (%.61005, %.61005)
  %r3514.0.base.relocated480 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token478, i32 2, i32 2) ; (%.6983, %.6983)
  %rs4gc.s91.relocated481 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token478, i32 3, i32 3) ; (%.7967, %.7967)
  %r3514.0.relocated482 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token478, i32 2, i32 4) ; (%.6983, %.6994)
  br label %gcpoll.done.667

gcpoll.done.667:                                  ; preds = %gcpoll.666, %shadow.root.barrier.done.665
  %.01018 = phi ptr addrspace(1) [ %rs4gc.s99.relocated, %gcpoll.666 ], [ %rs4gc.s99, %shadow.root.barrier.done.665 ]
  %.71006 = phi ptr addrspace(1) [ %rs4gc.s93.relocated479, %gcpoll.666 ], [ %.61005, %shadow.root.barrier.done.665 ]
  %.7995 = phi ptr addrspace(1) [ %r3514.0.relocated482, %gcpoll.666 ], [ %.6994, %shadow.root.barrier.done.665 ]
  %.7984 = phi ptr addrspace(1) [ %r3514.0.base.relocated480, %gcpoll.666 ], [ %.6983, %shadow.root.barrier.done.665 ]
  %.8968 = phi ptr addrspace(1) [ %rs4gc.s91.relocated481, %gcpoll.666 ], [ %.7967, %shadow.root.barrier.done.665 ]
  br label %for.stable_packed_slow.update.579

shadow.root.barrier.668:                          ; preds = %stable_packed.loop.merge.497
  call void @js_write_barrier_root_nanbox(i64 %r4385) #7
  br label %shadow.root.barrier.done.669

shadow.root.barrier.done.669:                     ; preds = %shadow.root.barrier.668, %stable_packed.loop.merge.497
  %r4388.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s93.relocated402 to i64
  %r4388.rs4o = call i64 asm "", "=r,0"(i64 %r4388.rs4i) #7
  %r4388 = bitcast i64 %r4388.rs4o to double
  %statepoint_token483 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r4388, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s95, ptr addrspace(1) %r3535.0.relocated400, ptr addrspace(1) %r3514.0.base.relocated401, ptr addrspace(1) %rs4gc.s93.relocated402, ptr addrspace(1) %rs4gc.s91.relocated403, ptr addrspace(1) %r3514.0.relocated404) ]
  %r4389484 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token483)
  %rs4gc.s95.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token483, i32 0, i32 0) ; (%rs4gc.s95, %rs4gc.s95)
  %r3535.0.relocated485 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token483, i32 1, i32 1) ; (%r3535.0.relocated400, %r3535.0.relocated400)
  %r3514.0.base.relocated486 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token483, i32 2, i32 2) ; (%r3514.0.base.relocated401, %r3514.0.base.relocated401)
  %rs4gc.s93.relocated487 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token483, i32 3, i32 3) ; (%rs4gc.s93.relocated402, %rs4gc.s93.relocated402)
  %rs4gc.s91.relocated488 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token483, i32 4, i32 4) ; (%rs4gc.s91.relocated403, %rs4gc.s91.relocated403)
  %r3514.0.relocated489 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token483, i32 2, i32 5) ; (%r3514.0.base.relocated401, %r3514.0.relocated404)
  %r4390 = bitcast i64 %r4389484 to double
  %rs4gc.s100 = inttoptr i64 %r4389484 to ptr addrspace(1)
  %r4391.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s100 to i64
  %r4391 = call i64 asm "", "=r,0"(i64 %r4391.rs4i) #7
  %r4392 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4393 = icmp ne i32 %r4392, 0
  br i1 %r4393, label %shadow.root.barrier.670, label %shadow.root.barrier.done.671

shadow.root.barrier.670:                          ; preds = %shadow.root.barrier.done.669
  call void @js_write_barrier_root_nanbox(i64 %r4391) #7
  br label %shadow.root.barrier.done.671

shadow.root.barrier.done.671:                     ; preds = %shadow.root.barrier.670, %shadow.root.barrier.done.669
  %r4394.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s95.relocated to i64
  %r4394.rs4o = call i64 asm "", "=r,0"(i64 %r4394.rs4i) #7
  %r4394 = bitcast i64 %r4394.rs4o to double
  %r4395 = bitcast double %r4394 to i64
  %r4396 = and i64 %r4395, 281474976710655
  %r4397 = lshr i64 %r4395, 48
  %r4398 = and i64 %r4397, 65533
  %r4399 = icmp eq i64 %r4398, 32765
  br i1 %r4399, label %pget.recv_ok.673, label %pget.recv_other.677

pget.recv_sso.672:                                ; preds = %pget.recv_other.677
  %r4537 = load double, ptr @test_json_warm_unique_keys_ts_.str.26.handle, align 8
  %r4538 = bitcast double %r4537 to i64
  %r4539 = and i64 %r4538, 281474976710655
  %statepoint_token490 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r4395, i64 %r4539, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s95.relocated, ptr addrspace(1) %r3535.0.relocated485, ptr addrspace(1) %rs4gc.s91.relocated488, ptr addrspace(1) %r3514.0.base.relocated486, ptr addrspace(1) %r3514.0.relocated489, ptr addrspace(1) %rs4gc.s93.relocated487, ptr addrspace(1) %rs4gc.s100) ]
  %r4540491 = call double @llvm.experimental.gc.result.f64(token %statepoint_token490)
  %rs4gc.s95.relocated492 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token490, i32 0, i32 0) ; (%rs4gc.s95.relocated, %rs4gc.s95.relocated)
  %r3535.0.relocated493 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token490, i32 1, i32 1) ; (%r3535.0.relocated485, %r3535.0.relocated485)
  %rs4gc.s91.relocated494 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token490, i32 2, i32 2) ; (%rs4gc.s91.relocated488, %rs4gc.s91.relocated488)
  %r3514.0.base.relocated495 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token490, i32 3, i32 3) ; (%r3514.0.base.relocated486, %r3514.0.base.relocated486)
  %r3514.0.relocated496 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token490, i32 3, i32 4) ; (%r3514.0.base.relocated486, %r3514.0.relocated489)
  %rs4gc.s93.relocated497 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token490, i32 5, i32 5) ; (%rs4gc.s93.relocated487, %rs4gc.s93.relocated487)
  %rs4gc.s100.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token490, i32 6, i32 6) ; (%rs4gc.s100, %rs4gc.s100)
  br label %pget.recv_merge.676

pget.recv_ok.673:                                 ; preds = %shadow.root.barrier.done.671
  %r4406 = icmp ugt i64 %r4396, 1048575
  br i1 %r4406, label %pic.recv_hdr.694, label %pic.miss.cold.691

pget.recv_bad.674:                                ; preds = %pget.check_class_ref.678
  %r4529 = icmp eq i64 %r4395, 9222246136947933185
  %r4530 = icmp eq i64 %r4395, 9222246136947933186
  %r4531 = or i1 %r4529, %r4530
  br i1 %r4531, label %pget.throw_nullish.701, label %pget.recv_undef_return.702

pget.recv_class_ref.675:                          ; preds = %pget.check_class_ref.678
  %r4402 = load double, ptr @test_json_warm_unique_keys_ts_.str.26.handle, align 8
  %r4403 = bitcast double %r4402 to i64
  %r4404 = and i64 %r4403, 281474976710655
  %statepoint_token498 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 547434508618563595, i64 %r4395, i64 %r4404, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s95.relocated, ptr addrspace(1) %r3535.0.relocated485, ptr addrspace(1) %rs4gc.s91.relocated488, ptr addrspace(1) %r3514.0.base.relocated486, ptr addrspace(1) %r3514.0.relocated489, ptr addrspace(1) %rs4gc.s93.relocated487, ptr addrspace(1) %rs4gc.s100) ]
  %r4405499 = call double @llvm.experimental.gc.result.f64(token %statepoint_token498)
  %rs4gc.s95.relocated500 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 0, i32 0) ; (%rs4gc.s95.relocated, %rs4gc.s95.relocated)
  %r3535.0.relocated501 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 1, i32 1) ; (%r3535.0.relocated485, %r3535.0.relocated485)
  %rs4gc.s91.relocated502 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 2, i32 2) ; (%rs4gc.s91.relocated488, %rs4gc.s91.relocated488)
  %r3514.0.base.relocated503 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 3, i32 3) ; (%r3514.0.base.relocated486, %r3514.0.base.relocated486)
  %r3514.0.relocated504 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 3, i32 4) ; (%r3514.0.base.relocated486, %r3514.0.relocated489)
  %rs4gc.s93.relocated505 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 5, i32 5) ; (%rs4gc.s93.relocated487, %rs4gc.s93.relocated487)
  %rs4gc.s100.relocated506 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 6, i32 6) ; (%rs4gc.s100, %rs4gc.s100)
  br label %pget.recv_merge.676

pget.recv_merge.676:                              ; preds = %pget.recv_undef_return.702, %pic.merge.693, %pget.recv_class_ref.675, %pget.recv_sso.672
  %.01024 = phi ptr addrspace(1) [ %.11025, %pic.merge.693 ], [ %rs4gc.s100.relocated, %pget.recv_sso.672 ], [ %rs4gc.s100.relocated506, %pget.recv_class_ref.675 ], [ %rs4gc.s100.relocated543, %pget.recv_undef_return.702 ]
  %.01019 = phi ptr addrspace(1) [ %.11020, %pic.merge.693 ], [ %rs4gc.s95.relocated492, %pget.recv_sso.672 ], [ %rs4gc.s95.relocated500, %pget.recv_class_ref.675 ], [ %rs4gc.s95.relocated537, %pget.recv_undef_return.702 ]
  %.01010 = phi ptr addrspace(1) [ %.11011, %pic.merge.693 ], [ %r3535.0.relocated493, %pget.recv_sso.672 ], [ %r3535.0.relocated501, %pget.recv_class_ref.675 ], [ %r3535.0.relocated538, %pget.recv_undef_return.702 ]
  %.81007 = phi ptr addrspace(1) [ %.91008, %pic.merge.693 ], [ %rs4gc.s93.relocated497, %pget.recv_sso.672 ], [ %rs4gc.s93.relocated505, %pget.recv_class_ref.675 ], [ %rs4gc.s93.relocated542, %pget.recv_undef_return.702 ]
  %.8996 = phi ptr addrspace(1) [ %.9997, %pic.merge.693 ], [ %r3514.0.relocated496, %pget.recv_sso.672 ], [ %r3514.0.relocated504, %pget.recv_class_ref.675 ], [ %r3514.0.relocated541, %pget.recv_undef_return.702 ]
  %.8985 = phi ptr addrspace(1) [ %.9986, %pic.merge.693 ], [ %r3514.0.base.relocated495, %pget.recv_sso.672 ], [ %r3514.0.base.relocated503, %pget.recv_class_ref.675 ], [ %r3514.0.base.relocated540, %pget.recv_undef_return.702 ]
  %.9969 = phi ptr addrspace(1) [ %.10970, %pic.merge.693 ], [ %rs4gc.s91.relocated494, %pget.recv_sso.672 ], [ %rs4gc.s91.relocated502, %pget.recv_class_ref.675 ], [ %rs4gc.s91.relocated539, %pget.recv_undef_return.702 ]
  %r4541 = phi double [ %r4528, %pic.merge.693 ], [ %r4536536, %pget.recv_undef_return.702 ], [ %r4540491, %pget.recv_sso.672 ], [ %r4405499, %pget.recv_class_ref.675 ]
  %statepoint_token507 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r4541, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01019, ptr addrspace(1) %.01010, ptr addrspace(1) %.9969, ptr addrspace(1) %.8985, ptr addrspace(1) %.8996, ptr addrspace(1) %.81007, ptr addrspace(1) %.01024) ]
  %r4542508 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token507)
  %rs4gc.s95.relocated509 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token507, i32 0, i32 0) ; (%.01019, %.01019)
  %r3535.0.relocated510 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token507, i32 1, i32 1) ; (%.01010, %.01010)
  %rs4gc.s91.relocated511 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token507, i32 2, i32 2) ; (%.9969, %.9969)
  %r3514.0.base.relocated512 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token507, i32 3, i32 3) ; (%.8985, %.8985)
  %r3514.0.relocated513 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token507, i32 3, i32 4) ; (%.8985, %.8996)
  %rs4gc.s93.relocated514 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token507, i32 5, i32 5) ; (%.81007, %.81007)
  %rs4gc.s100.relocated515 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token507, i32 6, i32 6) ; (%.01024, %.01024)
  %r4543 = bitcast i64 %r4542508 to double
  %r4544.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s100.relocated515 to i64
  %r4544 = call i64 asm "", "=r,0"(i64 %r4544.rs4i) #7
  %r4545 = bitcast i64 %r4544 to double
  %r4546 = icmp eq i64 %r4544, %r4542508
  br i1 %r4546, label %streq.true.707, label %streq.tag.703

pget.recv_other.677:                              ; preds = %shadow.root.barrier.done.671
  %r4400 = icmp eq i64 %r4397, 32761
  br i1 %r4400, label %pget.recv_sso.672, label %pget.check_class_ref.678

pget.check_class_ref.678:                         ; preds = %pget.recv_other.677
  %r4401 = icmp eq i64 %r4397, 32766
  br i1 %r4401, label %pget.recv_class_ref.675, label %pget.recv_bad.674

pic.hit.679:                                      ; preds = %pic.token.695
  %r4431 = getelementptr i64, ptr %r4416, i64 1
  %r4432 = load i64, ptr %r4431, align 8
  %r4433 = and i64 %r4432, 1073741824
  %r4434 = icmp ne i64 %r4433, 0
  br i1 %r4434, label %pic.hit.overflow.696, label %pic.hit.inline.697

pic.hit.live.680:                                 ; preds = %pic.hit.inline.697
  br label %pic.merge.693

pic.prefix.guard.681:                             ; preds = %pic.token.695
  %r4447 = getelementptr i64, ptr %r4416, i64 2
  %r4448 = load i64, ptr %r4447, align 8
  %r4449 = icmp ne i64 %r4448, 0
  br i1 %r4449, label %pic.prefix.meta.682, label %pic.miss.690

pic.prefix.meta.682:                              ; preds = %pic.prefix.guard.681
  %r4450 = add nuw nsw i64 %r4396, 8
  %r4451 = inttoptr i64 %r4450 to ptr
  %r4452 = load i64, ptr %r4451, align 8
  %r4453 = icmp ne i64 %r4452, 0
  br i1 %r4453, label %pic.prefix.token.683, label %pic.miss.690

pic.prefix.token.683:                             ; preds = %pic.prefix.meta.682
  %r4454 = inttoptr i64 %r4452 to ptr
  %r4455 = getelementptr i64, ptr %r4454, i64 6
  %r4456 = load i64, ptr %r4455, align 8
  %r4457 = icmp eq i64 %r4456, %r4448
  br i1 %r4457, label %pic.prefix.hit.684, label %pic.miss.690

pic.prefix.hit.684:                               ; preds = %pic.prefix.token.683
  %r4458 = getelementptr i64, ptr %r4416, i64 1
  %r4459 = load i64, ptr %r4458, align 8
  %r4460 = shl i64 %r4459, 3
  %r4461 = add nuw nsw i64 %r4396, 16
  %r4462 = add i64 %r4461, %r4460
  %r4463 = inttoptr i64 %r4462 to ptr
  %r4464 = load double, ptr %r4463, align 8
  br label %pic.merge.693

pic.desc.classify.685:                            ; preds = %pic.recv_hdr.694
  %r4420 = and i1 %r4410, %r4417
  br i1 %r4420, label %pic.desc.prefix.guard.686, label %pic.miss.cold.691

pic.desc.prefix.guard.686:                        ; preds = %pic.desc.classify.685
  %r4465 = getelementptr i64, ptr %r4416, i64 2
  %r4466 = load i64, ptr %r4465, align 8
  %r4467 = icmp ne i64 %r4466, 0
  br i1 %r4467, label %pic.desc.prefix.meta.687, label %pic.miss.cold.691

pic.desc.prefix.meta.687:                         ; preds = %pic.desc.prefix.guard.686
  %r4468 = add nuw nsw i64 %r4396, 8
  %r4469 = inttoptr i64 %r4468 to ptr
  %r4470 = load i64, ptr %r4469, align 8
  %r4471 = icmp ne i64 %r4470, 0
  br i1 %r4471, label %pic.desc.prefix.token.688, label %pic.miss.cold.691

pic.desc.prefix.token.688:                        ; preds = %pic.desc.prefix.meta.687
  %r4472 = inttoptr i64 %r4470 to ptr
  %r4473 = getelementptr i64, ptr %r4472, i64 6
  %r4474 = load i64, ptr %r4473, align 8
  %r4475 = icmp eq i64 %r4474, %r4466
  br i1 %r4475, label %pic.desc.prefix.hit.689, label %pic.miss.cold.691

pic.desc.prefix.hit.689:                          ; preds = %pic.desc.prefix.token.688
  %r4476 = getelementptr i64, ptr %r4416, i64 1
  %r4477 = load i64, ptr %r4476, align 8
  %r4478 = shl i64 %r4477, 3
  %r4479 = add nuw nsw i64 %r4396, 16
  %r4480 = add i64 %r4479, %r4478
  %r4481 = inttoptr i64 %r4480 to ptr
  %r4482 = load double, ptr %r4481, align 8
  br label %pic.merge.693

pic.miss.690:                                     ; preds = %pic.hit.inline.697, %pic.prefix.token.683, %pic.prefix.meta.682, %pic.prefix.guard.681
  %r4483 = getelementptr i64, ptr %r4416, i64 3
  %r4484 = load i64, ptr %r4483, align 8
  %r4485 = icmp sgt i64 %r4484, 0
  br i1 %r4485, label %pic.ways.698, label %pic.miss.call.692

pic.miss.cold.691:                                ; preds = %pic.desc.prefix.token.688, %pic.desc.prefix.meta.687, %pic.desc.prefix.guard.686, %pic.desc.classify.685, %pget.recv_ok.673
  br label %pic.miss.call.692

pic.miss.call.692:                                ; preds = %pic.way.load.699, %pic.ways.698, %pic.miss.cold.691, %pic.miss.690
  %r4524 = load double, ptr @test_json_warm_unique_keys_ts_.str.26.handle, align 8
  %r4525 = bitcast double %r4524 to i64
  %r4526 = and i64 %r4525, 281474976710655
  %statepoint_token516 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r4396, i64 %r4526, ptr @perry_ic_test_json_warm_unique_keys_ts__12, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s95.relocated, ptr addrspace(1) %r3535.0.relocated485, ptr addrspace(1) %rs4gc.s91.relocated488, ptr addrspace(1) %r3514.0.base.relocated486, ptr addrspace(1) %r3514.0.relocated489, ptr addrspace(1) %rs4gc.s93.relocated487, ptr addrspace(1) %rs4gc.s100) ]
  %r4527517 = call double @llvm.experimental.gc.result.f64(token %statepoint_token516)
  %rs4gc.s95.relocated518 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token516, i32 0, i32 0) ; (%rs4gc.s95.relocated, %rs4gc.s95.relocated)
  %r3535.0.relocated519 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token516, i32 1, i32 1) ; (%r3535.0.relocated485, %r3535.0.relocated485)
  %rs4gc.s91.relocated520 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token516, i32 2, i32 2) ; (%rs4gc.s91.relocated488, %rs4gc.s91.relocated488)
  %r3514.0.base.relocated521 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token516, i32 3, i32 3) ; (%r3514.0.base.relocated486, %r3514.0.base.relocated486)
  %r3514.0.relocated522 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token516, i32 3, i32 4) ; (%r3514.0.base.relocated486, %r3514.0.relocated489)
  %rs4gc.s93.relocated523 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token516, i32 5, i32 5) ; (%rs4gc.s93.relocated487, %rs4gc.s93.relocated487)
  %rs4gc.s100.relocated524 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token516, i32 6, i32 6) ; (%rs4gc.s100, %rs4gc.s100)
  br label %pic.merge.693

pic.merge.693:                                    ; preds = %pic.way.live.700, %pic.hit.overflow.696, %pic.miss.call.692, %pic.desc.prefix.hit.689, %pic.prefix.hit.684, %pic.hit.live.680
  %.11025 = phi ptr addrspace(1) [ %rs4gc.s100.relocated533, %pic.hit.overflow.696 ], [ %rs4gc.s100.relocated524, %pic.miss.call.692 ], [ %rs4gc.s100, %pic.way.live.700 ], [ %rs4gc.s100, %pic.hit.live.680 ], [ %rs4gc.s100, %pic.prefix.hit.684 ], [ %rs4gc.s100, %pic.desc.prefix.hit.689 ]
  %.11020 = phi ptr addrspace(1) [ %rs4gc.s95.relocated527, %pic.hit.overflow.696 ], [ %rs4gc.s95.relocated518, %pic.miss.call.692 ], [ %rs4gc.s95.relocated, %pic.way.live.700 ], [ %rs4gc.s95.relocated, %pic.hit.live.680 ], [ %rs4gc.s95.relocated, %pic.prefix.hit.684 ], [ %rs4gc.s95.relocated, %pic.desc.prefix.hit.689 ]
  %.11011 = phi ptr addrspace(1) [ %r3535.0.relocated528, %pic.hit.overflow.696 ], [ %r3535.0.relocated519, %pic.miss.call.692 ], [ %r3535.0.relocated485, %pic.way.live.700 ], [ %r3535.0.relocated485, %pic.hit.live.680 ], [ %r3535.0.relocated485, %pic.prefix.hit.684 ], [ %r3535.0.relocated485, %pic.desc.prefix.hit.689 ]
  %.91008 = phi ptr addrspace(1) [ %rs4gc.s93.relocated532, %pic.hit.overflow.696 ], [ %rs4gc.s93.relocated523, %pic.miss.call.692 ], [ %rs4gc.s93.relocated487, %pic.way.live.700 ], [ %rs4gc.s93.relocated487, %pic.hit.live.680 ], [ %rs4gc.s93.relocated487, %pic.prefix.hit.684 ], [ %rs4gc.s93.relocated487, %pic.desc.prefix.hit.689 ]
  %.9997 = phi ptr addrspace(1) [ %r3514.0.relocated531, %pic.hit.overflow.696 ], [ %r3514.0.relocated522, %pic.miss.call.692 ], [ %r3514.0.relocated489, %pic.way.live.700 ], [ %r3514.0.relocated489, %pic.hit.live.680 ], [ %r3514.0.relocated489, %pic.prefix.hit.684 ], [ %r3514.0.relocated489, %pic.desc.prefix.hit.689 ]
  %.9986 = phi ptr addrspace(1) [ %r3514.0.base.relocated530, %pic.hit.overflow.696 ], [ %r3514.0.base.relocated521, %pic.miss.call.692 ], [ %r3514.0.base.relocated486, %pic.way.live.700 ], [ %r3514.0.base.relocated486, %pic.hit.live.680 ], [ %r3514.0.base.relocated486, %pic.prefix.hit.684 ], [ %r3514.0.base.relocated486, %pic.desc.prefix.hit.689 ]
  %.10970 = phi ptr addrspace(1) [ %rs4gc.s91.relocated529, %pic.hit.overflow.696 ], [ %rs4gc.s91.relocated520, %pic.miss.call.692 ], [ %rs4gc.s91.relocated488, %pic.way.live.700 ], [ %rs4gc.s91.relocated488, %pic.hit.live.680 ], [ %rs4gc.s91.relocated488, %pic.prefix.hit.684 ], [ %rs4gc.s91.relocated488, %pic.desc.prefix.hit.689 ]
  %r4528 = phi double [ %r4444, %pic.hit.live.680 ], [ %r4439526, %pic.hit.overflow.696 ], [ %r4464, %pic.prefix.hit.684 ], [ %r4482, %pic.desc.prefix.hit.689 ], [ %r4521, %pic.way.live.700 ], [ %r4527517, %pic.miss.call.692 ]
  br label %pget.recv_merge.676

pic.recv_hdr.694:                                 ; preds = %pget.recv_ok.673
  %r4407 = sub nuw nsw i64 %r4396, 8
  %r4408 = inttoptr i64 %r4407 to ptr
  %r4409 = load i8, ptr %r4408, align 1
  %r4410 = icmp eq i8 %r4409, 2
  %r4411 = sub nuw nsw i64 %r4396, 6
  %r4412 = inttoptr i64 %r4411 to ptr
  %r4413 = load i16, ptr %r4412, align 2
  %r4414 = and i16 %r4413, 2048
  %r4415 = icmp eq i16 %r4414, 0
  %r4416 = load ptr, ptr @perry_ic_test_json_warm_unique_keys_ts__12, align 8
  %r4417 = icmp ne ptr %r4416, null
  %r4418 = and i1 %r4410, %r4415
  %r4419 = and i1 %r4418, %r4417
  br i1 %r4419, label %pic.token.695, label %pic.desc.classify.685

pic.token.695:                                    ; preds = %pic.recv_hdr.694
  %r4421 = add nuw nsw i64 %r4396, 4
  %r4422 = inttoptr i64 %r4421 to ptr
  %r4423 = load i32, ptr %r4422, align 4
  %r4424 = zext i32 %r4423 to i64
  %r4425 = or i64 %r4424, 4611686018427387904
  %r4426 = icmp ne i32 %r4423, 0
  %r4427 = getelementptr i64, ptr %r4416, i64 0
  %r4428 = load i64, ptr %r4427, align 8
  %r4429 = icmp eq i64 %r4425, %r4428
  %r4430 = and i1 %r4429, %r4426
  br i1 %r4430, label %pic.hit.679, label %pic.prefix.guard.681

pic.hit.overflow.696:                             ; preds = %pic.hit.679
  %r4435 = load double, ptr @test_json_warm_unique_keys_ts_.str.26.handle, align 8
  %r4436 = bitcast double %r4435 to i64
  %r4437 = and i64 %r4436, 281474976710655
  %r4438 = trunc i64 %r4432 to i32
  %statepoint_token525 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r4396, i64 %r4437, i32 %r4438, ptr @perry_ic_test_json_warm_unique_keys_ts__12, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s95.relocated, ptr addrspace(1) %r3535.0.relocated485, ptr addrspace(1) %rs4gc.s91.relocated488, ptr addrspace(1) %r3514.0.base.relocated486, ptr addrspace(1) %r3514.0.relocated489, ptr addrspace(1) %rs4gc.s93.relocated487, ptr addrspace(1) %rs4gc.s100) ]
  %r4439526 = call double @llvm.experimental.gc.result.f64(token %statepoint_token525)
  %rs4gc.s95.relocated527 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token525, i32 0, i32 0) ; (%rs4gc.s95.relocated, %rs4gc.s95.relocated)
  %r3535.0.relocated528 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token525, i32 1, i32 1) ; (%r3535.0.relocated485, %r3535.0.relocated485)
  %rs4gc.s91.relocated529 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token525, i32 2, i32 2) ; (%rs4gc.s91.relocated488, %rs4gc.s91.relocated488)
  %r3514.0.base.relocated530 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token525, i32 3, i32 3) ; (%r3514.0.base.relocated486, %r3514.0.base.relocated486)
  %r3514.0.relocated531 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token525, i32 3, i32 4) ; (%r3514.0.base.relocated486, %r3514.0.relocated489)
  %rs4gc.s93.relocated532 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token525, i32 5, i32 5) ; (%rs4gc.s93.relocated487, %rs4gc.s93.relocated487)
  %rs4gc.s100.relocated533 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token525, i32 6, i32 6) ; (%rs4gc.s100, %rs4gc.s100)
  br label %pic.merge.693

pic.hit.inline.697:                               ; preds = %pic.hit.679
  %r4440 = shl i64 %r4432, 3
  %r4441 = add nuw nsw i64 %r4396, 16
  %r4442 = add i64 %r4441, %r4440
  %r4443 = inttoptr i64 %r4442 to ptr
  %r4444 = load double, ptr %r4443, align 8
  %r4445 = bitcast double %r4444 to i64
  %r4446 = icmp eq i64 %r4445, 9222246136947933200
  br i1 %r4446, label %pic.miss.690, label %pic.hit.live.680

pic.ways.698:                                     ; preds = %pic.miss.690
  %r4486 = getelementptr i64, ptr %r4416, i64 4
  %r4487 = load i64, ptr %r4486, align 8
  %r4488 = icmp eq i64 %r4487, %r4425
  %r4489 = getelementptr i64, ptr %r4416, i64 5
  %r4490 = load i64, ptr %r4489, align 8
  %r4491 = select i1 %r4488, i64 %r4490, i64 0
  %r4492 = getelementptr i64, ptr %r4416, i64 6
  %r4493 = load i64, ptr %r4492, align 8
  %r4494 = icmp eq i64 %r4493, %r4425
  %r4495 = getelementptr i64, ptr %r4416, i64 7
  %r4496 = load i64, ptr %r4495, align 8
  %r4497 = select i1 %r4494, i64 %r4496, i64 0
  %r4498 = getelementptr i64, ptr %r4416, i64 8
  %r4499 = load i64, ptr %r4498, align 8
  %r4500 = icmp eq i64 %r4499, %r4425
  %r4501 = getelementptr i64, ptr %r4416, i64 9
  %r4502 = load i64, ptr %r4501, align 8
  %r4503 = select i1 %r4500, i64 %r4502, i64 0
  %r4504 = getelementptr i64, ptr %r4416, i64 10
  %r4505 = load i64, ptr %r4504, align 8
  %r4506 = icmp eq i64 %r4505, %r4425
  %r4507 = getelementptr i64, ptr %r4416, i64 11
  %r4508 = load i64, ptr %r4507, align 8
  %r4509 = select i1 %r4506, i64 %r4508, i64 0
  %r4510 = or i1 %r4488, %r4494
  %r4511 = select i1 %r4488, i64 %r4491, i64 %r4497
  %r4512 = or i1 %r4500, %r4506
  %r4513 = select i1 %r4500, i64 %r4503, i64 %r4509
  %r4514 = or i1 %r4510, %r4512
  %r4515 = select i1 %r4510, i64 %r4511, i64 %r4513
  %r4516 = and i1 %r4426, %r4514
  br i1 %r4516, label %pic.way.load.699, label %pic.miss.call.692

pic.way.load.699:                                 ; preds = %pic.ways.698
  %r4517 = shl i64 %r4515, 3
  %r4518 = add nuw nsw i64 %r4396, 16
  %r4519 = add i64 %r4518, %r4517
  %r4520 = inttoptr i64 %r4519 to ptr
  %r4521 = load double, ptr %r4520, align 8
  %r4522 = bitcast double %r4521 to i64
  %r4523 = icmp eq i64 %r4522, 9222246136947933200
  br i1 %r4523, label %pic.miss.call.692, label %pic.way.live.700

pic.way.live.700:                                 ; preds = %pic.way.load.699
  br label %pic.merge.693

pget.throw_nullish.701:                           ; preds = %pget.recv_bad.674
  %r4532 = zext i1 %r4530 to i32
  %statepoint_token534 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r4532, ptr @test_json_warm_unique_keys_ts_.str.26.bytes, i64 7, i32 0, i32 0)
  unreachable

pget.recv_undef_return.702:                       ; preds = %pget.recv_bad.674
  %r4533 = load double, ptr @test_json_warm_unique_keys_ts_.str.26.handle, align 8
  %r4534 = bitcast double %r4533 to i64
  %r4535 = and i64 %r4534, 281474976710655
  %statepoint_token535 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r4395, i64 %r4535, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s95.relocated, ptr addrspace(1) %r3535.0.relocated485, ptr addrspace(1) %rs4gc.s91.relocated488, ptr addrspace(1) %r3514.0.base.relocated486, ptr addrspace(1) %r3514.0.relocated489, ptr addrspace(1) %rs4gc.s93.relocated487, ptr addrspace(1) %rs4gc.s100) ]
  %r4536536 = call double @llvm.experimental.gc.result.f64(token %statepoint_token535)
  %rs4gc.s95.relocated537 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token535, i32 0, i32 0) ; (%rs4gc.s95.relocated, %rs4gc.s95.relocated)
  %r3535.0.relocated538 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token535, i32 1, i32 1) ; (%r3535.0.relocated485, %r3535.0.relocated485)
  %rs4gc.s91.relocated539 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token535, i32 2, i32 2) ; (%rs4gc.s91.relocated488, %rs4gc.s91.relocated488)
  %r3514.0.base.relocated540 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token535, i32 3, i32 3) ; (%r3514.0.base.relocated486, %r3514.0.base.relocated486)
  %r3514.0.relocated541 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token535, i32 3, i32 4) ; (%r3514.0.base.relocated486, %r3514.0.relocated489)
  %rs4gc.s93.relocated542 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token535, i32 5, i32 5) ; (%rs4gc.s93.relocated487, %rs4gc.s93.relocated487)
  %rs4gc.s100.relocated543 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token535, i32 6, i32 6) ; (%rs4gc.s100, %rs4gc.s100)
  br label %pget.recv_merge.676

streq.tag.703:                                    ; preds = %pget.recv_merge.676
  %r4547 = lshr i64 %r4544, 48
  %r4548 = lshr i64 %r4542508, 48
  %r4549 = icmp eq i64 %r4547, 32767
  %r4550 = icmp eq i64 %r4548, 32767
  %r4551 = and i1 %r4549, %r4550
  br i1 %r4551, label %streq.heap.704, label %streq.ssochk.705

streq.heap.704:                                   ; preds = %streq.tag.703
  %r4552 = and i64 %r4544, 281474976710655
  %r4553 = and i64 %r4542508, 281474976710655
  %r4554 = icmp ugt i64 %r4552, 4095
  %r4555 = icmp ugt i64 %r4553, 4095
  %r4556 = and i1 %r4554, %r4555
  br i1 %r4556, label %streq.heap.valid.710, label %streq.heap.slow.718

streq.ssochk.705:                                 ; preds = %streq.tag.703
  %r4586 = icmp eq i64 %r4547, 32761
  %r4587 = icmp eq i64 %r4548, 32761
  %r4588 = and i1 %r4586, %r4587
  br i1 %r4588, label %streq.false.708, label %streq.boxed.706

streq.boxed.706:                                  ; preds = %streq.ssochk.705
  %statepoint_token544 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r4545, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s95.relocated509, ptr addrspace(1) %r3535.0.relocated510, ptr addrspace(1) %rs4gc.s91.relocated511, ptr addrspace(1) %r3514.0.base.relocated512, ptr addrspace(1) %r3514.0.relocated513, ptr addrspace(1) %rs4gc.s93.relocated514) ]
  %r4589545 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token544)
  %rs4gc.s95.relocated546 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token544, i32 0, i32 0) ; (%rs4gc.s95.relocated509, %rs4gc.s95.relocated509)
  %r3535.0.relocated547 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token544, i32 1, i32 1) ; (%r3535.0.relocated510, %r3535.0.relocated510)
  %rs4gc.s91.relocated548 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token544, i32 2, i32 2) ; (%rs4gc.s91.relocated511, %rs4gc.s91.relocated511)
  %r3514.0.base.relocated549 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token544, i32 3, i32 3) ; (%r3514.0.base.relocated512, %r3514.0.base.relocated512)
  %r3514.0.relocated550 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token544, i32 3, i32 4) ; (%r3514.0.base.relocated512, %r3514.0.relocated513)
  %rs4gc.s93.relocated551 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token544, i32 5, i32 5) ; (%rs4gc.s93.relocated514, %rs4gc.s93.relocated514)
  %statepoint_token552 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r4543, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s95.relocated546, ptr addrspace(1) %r3535.0.relocated547, ptr addrspace(1) %rs4gc.s91.relocated548, ptr addrspace(1) %r3514.0.base.relocated549, ptr addrspace(1) %r3514.0.relocated550, ptr addrspace(1) %rs4gc.s93.relocated551) ]
  %r4590553 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token552)
  %rs4gc.s95.relocated554 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token552, i32 0, i32 0) ; (%rs4gc.s95.relocated546, %rs4gc.s95.relocated546)
  %r3535.0.relocated555 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token552, i32 1, i32 1) ; (%r3535.0.relocated547, %r3535.0.relocated547)
  %rs4gc.s91.relocated556 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token552, i32 2, i32 2) ; (%rs4gc.s91.relocated548, %rs4gc.s91.relocated548)
  %r3514.0.base.relocated557 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token552, i32 3, i32 3) ; (%r3514.0.base.relocated549, %r3514.0.base.relocated549)
  %r3514.0.relocated558 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token552, i32 3, i32 4) ; (%r3514.0.base.relocated549, %r3514.0.relocated550)
  %rs4gc.s93.relocated559 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token552, i32 5, i32 5) ; (%rs4gc.s93.relocated551, %rs4gc.s93.relocated551)
  %statepoint_token560 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r4589545, i64 %r4590553, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s95.relocated554, ptr addrspace(1) %r3535.0.relocated555, ptr addrspace(1) %rs4gc.s91.relocated556, ptr addrspace(1) %r3514.0.base.relocated557, ptr addrspace(1) %r3514.0.relocated558, ptr addrspace(1) %rs4gc.s93.relocated559) ]
  %r4591561 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token560)
  %rs4gc.s95.relocated562 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token560, i32 0, i32 0) ; (%rs4gc.s95.relocated554, %rs4gc.s95.relocated554)
  %r3535.0.relocated563 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token560, i32 1, i32 1) ; (%r3535.0.relocated555, %r3535.0.relocated555)
  %rs4gc.s91.relocated564 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token560, i32 2, i32 2) ; (%rs4gc.s91.relocated556, %rs4gc.s91.relocated556)
  %r3514.0.base.relocated565 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token560, i32 3, i32 3) ; (%r3514.0.base.relocated557, %r3514.0.base.relocated557)
  %r3514.0.relocated566 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token560, i32 3, i32 4) ; (%r3514.0.base.relocated557, %r3514.0.relocated558)
  %rs4gc.s93.relocated567 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token560, i32 5, i32 5) ; (%rs4gc.s93.relocated559, %rs4gc.s93.relocated559)
  br label %streq.merge.709

streq.true.707:                                   ; preds = %streq.heap.middle.byte.717, %streq.heap.two.715, %streq.heap.one.713, %streq.heap.len.711, %pget.recv_merge.676
  br label %streq.merge.709

streq.false.708:                                  ; preds = %streq.heap.middle.byte.717, %streq.heap.last.714, %streq.heap.first.712, %streq.heap.valid.710, %streq.ssochk.705
  br label %streq.merge.709

streq.merge.709:                                  ; preds = %streq.heap.slow.718, %streq.false.708, %streq.true.707, %streq.boxed.706
  %.21021 = phi ptr addrspace(1) [ %rs4gc.s95.relocated509, %streq.true.707 ], [ %rs4gc.s95.relocated509, %streq.false.708 ], [ %rs4gc.s95.relocated570, %streq.heap.slow.718 ], [ %rs4gc.s95.relocated562, %streq.boxed.706 ]
  %.21012 = phi ptr addrspace(1) [ %r3535.0.relocated510, %streq.true.707 ], [ %r3535.0.relocated510, %streq.false.708 ], [ %r3535.0.relocated571, %streq.heap.slow.718 ], [ %r3535.0.relocated563, %streq.boxed.706 ]
  %.101009 = phi ptr addrspace(1) [ %rs4gc.s93.relocated514, %streq.true.707 ], [ %rs4gc.s93.relocated514, %streq.false.708 ], [ %rs4gc.s93.relocated575, %streq.heap.slow.718 ], [ %rs4gc.s93.relocated567, %streq.boxed.706 ]
  %.10998 = phi ptr addrspace(1) [ %r3514.0.relocated513, %streq.true.707 ], [ %r3514.0.relocated513, %streq.false.708 ], [ %r3514.0.relocated574, %streq.heap.slow.718 ], [ %r3514.0.relocated566, %streq.boxed.706 ]
  %.10987 = phi ptr addrspace(1) [ %r3514.0.base.relocated512, %streq.true.707 ], [ %r3514.0.base.relocated512, %streq.false.708 ], [ %r3514.0.base.relocated573, %streq.heap.slow.718 ], [ %r3514.0.base.relocated565, %streq.boxed.706 ]
  %.11971 = phi ptr addrspace(1) [ %rs4gc.s91.relocated511, %streq.true.707 ], [ %rs4gc.s91.relocated511, %streq.false.708 ], [ %rs4gc.s91.relocated572, %streq.heap.slow.718 ], [ %rs4gc.s91.relocated564, %streq.boxed.706 ]
  %r4592 = phi i32 [ 1, %streq.true.707 ], [ 0, %streq.false.708 ], [ %r4585569, %streq.heap.slow.718 ], [ %r4591561, %streq.boxed.706 ]
  %r4593 = icmp ne i32 %r4592, 0
  %r4594 = xor i1 %r4593, true
  %r4595 = select i1 %r4594, i64 9222246136947933188, i64 9222246136947933187
  %r4596 = bitcast i64 %r4595 to double
  %r4597 = icmp eq i64 %r4595, 9222246136947933188
  br i1 %r4597, label %if.then.719, label %if.else.720

streq.heap.valid.710:                             ; preds = %streq.heap.704
  %r4557 = inttoptr i64 %r4552 to ptr
  %r4558 = inttoptr i64 %r4553 to ptr
  %r4559 = getelementptr inbounds nuw i8, ptr %r4557, i64 4
  %r4560 = getelementptr inbounds nuw i8, ptr %r4558, i64 4
  %r4561 = load i32, ptr %r4559, align 4
  %r4562 = load i32, ptr %r4560, align 4
  %r4563 = icmp eq i32 %r4561, %r4562
  br i1 %r4563, label %streq.heap.len.711, label %streq.false.708

streq.heap.len.711:                               ; preds = %streq.heap.valid.710
  %r4564 = icmp eq i32 %r4561, 0
  br i1 %r4564, label %streq.true.707, label %streq.heap.first.712

streq.heap.first.712:                             ; preds = %streq.heap.len.711
  %r4565 = getelementptr inbounds nuw i8, ptr %r4557, i64 20
  %r4566 = getelementptr inbounds nuw i8, ptr %r4558, i64 20
  %r4567 = load i8, ptr %r4565, align 1
  %r4568 = load i8, ptr %r4566, align 1
  %r4569 = icmp eq i8 %r4567, %r4568
  br i1 %r4569, label %streq.heap.one.713, label %streq.false.708

streq.heap.one.713:                               ; preds = %streq.heap.first.712
  %r4570 = icmp eq i32 %r4561, 1
  br i1 %r4570, label %streq.true.707, label %streq.heap.last.714

streq.heap.last.714:                              ; preds = %streq.heap.one.713
  %r4571 = zext i32 %r4561 to i64
  %r4572 = add nuw nsw i64 %r4571, 19
  %r4573 = getelementptr inbounds nuw i8, ptr %r4557, i64 %r4572
  %r4574 = getelementptr inbounds nuw i8, ptr %r4558, i64 %r4572
  %r4575 = load i8, ptr %r4573, align 1
  %r4576 = load i8, ptr %r4574, align 1
  %r4577 = icmp eq i8 %r4575, %r4576
  br i1 %r4577, label %streq.heap.two.715, label %streq.false.708

streq.heap.two.715:                               ; preds = %streq.heap.last.714
  %r4578 = icmp eq i32 %r4561, 2
  br i1 %r4578, label %streq.true.707, label %streq.heap.middle.716

streq.heap.middle.716:                            ; preds = %streq.heap.two.715
  %r4579 = icmp eq i32 %r4561, 3
  br i1 %r4579, label %streq.heap.middle.byte.717, label %streq.heap.slow.718

streq.heap.middle.byte.717:                       ; preds = %streq.heap.middle.716
  %r4580 = getelementptr inbounds nuw i8, ptr %r4557, i64 21
  %r4581 = getelementptr inbounds nuw i8, ptr %r4558, i64 21
  %r4582 = load i8, ptr %r4580, align 1
  %r4583 = load i8, ptr %r4581, align 1
  %r4584 = icmp eq i8 %r4582, %r4583
  br i1 %r4584, label %streq.true.707, label %streq.false.708

streq.heap.slow.718:                              ; preds = %streq.heap.middle.716, %streq.heap.704
  %statepoint_token568 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r4552, i64 %r4553, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s95.relocated509, ptr addrspace(1) %r3535.0.relocated510, ptr addrspace(1) %rs4gc.s91.relocated511, ptr addrspace(1) %r3514.0.base.relocated512, ptr addrspace(1) %r3514.0.relocated513, ptr addrspace(1) %rs4gc.s93.relocated514) ]
  %r4585569 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token568)
  %rs4gc.s95.relocated570 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token568, i32 0, i32 0) ; (%rs4gc.s95.relocated509, %rs4gc.s95.relocated509)
  %r3535.0.relocated571 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token568, i32 1, i32 1) ; (%r3535.0.relocated510, %r3535.0.relocated510)
  %rs4gc.s91.relocated572 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token568, i32 2, i32 2) ; (%rs4gc.s91.relocated511, %rs4gc.s91.relocated511)
  %r3514.0.base.relocated573 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token568, i32 3, i32 3) ; (%r3514.0.base.relocated512, %r3514.0.base.relocated512)
  %r3514.0.relocated574 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token568, i32 3, i32 4) ; (%r3514.0.base.relocated512, %r3514.0.relocated513)
  %rs4gc.s93.relocated575 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token568, i32 5, i32 5) ; (%rs4gc.s93.relocated514, %rs4gc.s93.relocated514)
  br label %streq.merge.709

if.then.719:                                      ; preds = %streq.merge.709
  %r4598 = load double, ptr @test_json_warm_unique_keys_ts_.str.27.handle, align 8
  %statepoint_token576 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_error_new_from_value, i32 1, i32 0, double %r4598, i32 0, i32 0)
  %r4599577 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token576)
  %r4600 = or i64 %r4599577, 9222527611924643840
  %r4601 = bitcast i64 %r4600 to double
  %statepoint_token578 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r4601, i32 0, i32 0)
  unreachable

if.else.720:                                      ; preds = %streq.merge.709
  br label %if.merge.721

if.merge.721:                                     ; preds = %if.else.720
  %r4603 = fptosi double %r3521.0 to i64
  %r4605 = srem i64 %r4603, 4
  %r4606 = sitofp i64 %r4605 to double
  %r4607 = icmp eq i64 %r4605, 0
  %r4608 = fcmp olt double %r3521.0, 0.000000e+00
  %r4609 = and i1 %r4607, %r4608
  %r4610 = fneg double %r4606
  %r4611 = select i1 %r4609, double %r4610, double %r4606
  %r4612 = fcmp oeq double %r4611, 0.000000e+00
  %r4613 = select i1 %r4612, i64 9222246136947933188, i64 9222246136947933187
  %r4614 = bitcast i64 %r4613 to double
  %r4615 = icmp eq i64 %r4613, 9222246136947933188
  br i1 %r4615, label %if.then.722, label %if.else.723

if.then.722:                                      ; preds = %if.merge.721
  %r4616.rs4i = ptrtoint ptr addrspace(1) %.101009 to i64
  %r4616.rs4o = call i64 asm "", "=r,0"(i64 %r4616.rs4i) #7
  %r4616 = bitcast i64 %r4616.rs4o to double
  %r4617 = bitcast double %r4616 to i64
  %r4618.rs4i = ptrtoint ptr addrspace(1) %.10998 to i64
  %r4618.rs4o = call i64 asm "", "=r,0"(i64 %r4618.rs4i) #7
  %r4618 = bitcast i64 %r4618.rs4o to double
  %r4619 = bitcast double %r4618 to i64
  %r4620 = and i64 %r4619, 281474976710655
  %r4621 = sub nsw i64 %r4620, 8
  %r4622 = inttoptr i64 %r4621 to ptr
  %r4623 = load i8, ptr %r4622, align 1
  %r4624 = icmp ne i8 %r4623, 1
  %r4625 = sub nsw i64 %r4620, 7
  %r4626 = inttoptr i64 %r4625 to ptr
  %r4627 = load i8, ptr %r4626, align 1
  %r4628 = and i8 %r4627, -128
  %r4629 = icmp ne i8 %r4628, 0
  %r4630 = or i1 %r4624, %r4629
  br i1 %r4629, label %apush.fwd.725, label %apush.elements.726

if.else.723:                                      ; preds = %if.merge.721
  br label %if.merge.724

if.merge.724:                                     ; preds = %apush.merge.731, %if.else.723
  %.31022 = phi ptr addrspace(1) [ %.41023, %apush.merge.731 ], [ %.21021, %if.else.723 ]
  %.31013 = phi ptr addrspace(1) [ %.41014, %apush.merge.731 ], [ %.21012, %if.else.723 ]
  %.12972 = phi ptr addrspace(1) [ %.13973, %apush.merge.731 ], [ %.11971, %if.else.723 ]
  %r3514.1.base = phi ptr addrspace(1) [ %r3514.2.base, %apush.merge.731 ], [ %.10987, %if.else.723 ], !is_base_value !0
  %r3514.1 = phi ptr addrspace(1) [ %r3514.2, %apush.merge.731 ], [ %.10998, %if.else.723 ]
  %statepoint_token579 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_collect, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31022, ptr addrspace(1) %.31013, ptr addrspace(1) %r3514.1.base, ptr addrspace(1) %.12972, ptr addrspace(1) %r3514.1) ]
  %rs4gc.s95.relocated580 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token579, i32 0, i32 0) ; (%.31022, %.31022)
  %r3535.0.relocated581 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token579, i32 1, i32 1) ; (%.31013, %.31013)
  %r3514.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token579, i32 2, i32 2) ; (%r3514.1.base, %r3514.1.base)
  %rs4gc.s91.relocated582 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token579, i32 3, i32 3) ; (%.12972, %.12972)
  %r3514.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token579, i32 2, i32 4) ; (%r3514.1.base, %r3514.1)
  %statepoint_token583 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 4, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s95.relocated580, ptr addrspace(1) %r3535.0.relocated581, ptr addrspace(1) %r3514.1.base.relocated, ptr addrspace(1) %rs4gc.s91.relocated582, ptr addrspace(1) %r3514.1.relocated) ]
  %r4705584 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token583)
  %rs4gc.s95.relocated585 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token583, i32 0, i32 0) ; (%rs4gc.s95.relocated580, %rs4gc.s95.relocated580)
  %r3535.0.relocated586 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token583, i32 1, i32 1) ; (%r3535.0.relocated581, %r3535.0.relocated581)
  %r3514.1.base.relocated587 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token583, i32 2, i32 2) ; (%r3514.1.base.relocated, %r3514.1.base.relocated)
  %rs4gc.s91.relocated588 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token583, i32 3, i32 3) ; (%rs4gc.s91.relocated582, %rs4gc.s91.relocated582)
  %r3514.1.relocated589 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token583, i32 2, i32 4) ; (%r3514.1.base.relocated, %r3514.1.relocated)
  %rs4gc.s101 = inttoptr i64 %r4705584 to ptr addrspace(1)
  %r4706.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s101 to i64
  %r4706 = call i64 asm "", "=r,0"(i64 %r4706.rs4i) #7
  %r4707 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4708 = icmp ne i32 %r4707, 0
  br i1 %r4708, label %shadow.root.barrier.736, label %shadow.root.barrier.done.737

apush.fwd.725:                                    ; preds = %apush.elements.check.727, %if.then.722
  %statepoint_token590 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r4620, double %r4616, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.21021, ptr addrspace(1) %.21012, ptr addrspace(1) %.11971) ]
  %r4657591 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token590)
  %rs4gc.s95.relocated592 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token590, i32 0, i32 0) ; (%.21021, %.21021)
  %r3535.0.relocated593 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token590, i32 1, i32 1) ; (%.21012, %.21012)
  %rs4gc.s91.relocated594 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token590, i32 2, i32 2) ; (%.11971, %.11971)
  %r4658 = or i64 %r4657591, 9222527611924643840
  %r4659 = bitcast i64 %r4658 to double
  %rs4gc.b102 = bitcast double %r4659 to i64
  %rs4gc.s102 = inttoptr i64 %rs4gc.b102 to ptr addrspace(1)
  br label %apush.merge.731

apush.elements.726:                               ; preds = %if.then.722
  %r4632 = add nuw nsw i64 %r4620, 8
  %r4633 = inttoptr i64 %r4632 to ptr
  %r4634 = load i64, ptr %r4633, align 8
  %r4635 = icmp ne i64 %r4634, 0
  %r4636 = icmp eq i8 %r4623, 2
  %r4637 = and i1 %r4636, %r4635
  %r4638 = select i1 %r4637, i64 %r4634, i64 %r4620
  %r4639 = inttoptr i64 %r4638 to ptr
  %r4640 = getelementptr i64, ptr %r4639, i64 12
  %r4641 = load i64, ptr %r4640, align 8
  %r4642 = icmp ne i64 %r4641, 0
  %r4643 = and i1 %r4637, %r4642
  %r4644 = select i1 %r4643, i64 %r4641, i64 %r4620
  %r4631 = icmp eq i8 %r4623, 1
  br i1 %r4631, label %apush.nofwd.728, label %apush.elements.check.727

apush.elements.check.727:                         ; preds = %apush.elements.726
  %r4645 = icmp ne i64 %r4644, 0
  %r4646 = sub i64 %r4644, 8
  %r4647 = inttoptr i64 %r4646 to ptr
  %r4648 = load i8, ptr %r4647, align 1
  %r4649 = icmp eq i8 %r4648, 1
  %r4650 = sub i64 %r4644, 7
  %r4651 = inttoptr i64 %r4650 to ptr
  %r4652 = load i8, ptr %r4651, align 1
  %r4653 = and i8 %r4652, -128
  %r4654 = icmp eq i8 %r4653, 0
  %r4655 = and i1 %r4645, %r4649
  %r4656 = and i1 %r4655, %r4654
  br i1 %r4656, label %apush.nofwd.728, label %apush.fwd.725

apush.nofwd.728:                                  ; preds = %apush.elements.check.727, %apush.elements.726
  %r4660 = phi i64 [ %r4620, %apush.elements.726 ], [ %r4644, %apush.elements.check.727 ]
  %r4661 = sub i64 %r4660, 6
  %r4662 = inttoptr i64 %r4661 to ptr
  %r4663 = load i16, ptr %r4662, align 2
  %r4664 = and i16 %r4663, 1031
  %r4665 = icmp eq i16 %r4664, 0
  %r4666 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r4667 = icmp eq i8 %r4666, 0
  %r4668 = and i1 %r4665, %r4667
  %r4669 = icmp ult i64 %r4660, 4096
  %r4670 = inttoptr i64 %r4660 to ptr
  %r4671 = select i1 %r4669, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r4670
  %r4672 = load i32, ptr %r4671, align 4
  %r4673 = add i64 %r4660, 4
  %r4674 = inttoptr i64 %r4673 to ptr
  %r4675 = load i32, ptr %r4674, align 4
  %r4676 = icmp ult i32 %r4672, %r4675
  %r4677 = and i1 %r4676, %r4668
  br i1 %r4677, label %apush.inbounds.729, label %apush.realloc.730

apush.inbounds.729:                               ; preds = %apush.nofwd.728
  %r4678 = icmp ult i64 %r4660, 4096
  %r4679 = inttoptr i64 %r4660 to ptr
  %r4680 = select i1 %r4678, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r4679
  %r4681 = load i32, ptr %r4680, align 4
  %r4682 = zext i32 %r4681 to i64
  %r4683 = shl nuw nsw i64 %r4682, 3
  %r4684 = add nuw nsw i64 %r4683, 8
  %r4685 = add i64 %r4660, %r4684
  %r4686 = inttoptr i64 %r4685 to ptr
  store double %r4616, ptr %r4686, align 8
  %r4687 = lshr i64 %r4617, 48
  %r4688 = icmp eq i64 %r4687, 32765
  %r4689 = and i16 %r4663, -1920
  %r4690 = icmp eq i16 %r4689, -24576
  %r4691 = and i1 %r4688, %r4690
  br i1 %r4691, label %apush.pointer_layout.done.733, label %apush.pointer_layout.bookkeeping.732

apush.realloc.730:                                ; preds = %apush.nofwd.728
  %statepoint_token595 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r4620, double %r4616, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.21021, ptr addrspace(1) %.21012, ptr addrspace(1) %.11971) ]
  %r4702596 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token595)
  %rs4gc.s95.relocated597 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token595, i32 0, i32 0) ; (%.21021, %.21021)
  %r3535.0.relocated598 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token595, i32 1, i32 1) ; (%.21012, %.21012)
  %rs4gc.s91.relocated599 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token595, i32 2, i32 2) ; (%.11971, %.11971)
  %r4703 = or i64 %r4702596, 9222527611924643840
  %r4704 = bitcast i64 %r4703 to double
  %rs4gc.b103 = bitcast double %r4704 to i64
  %rs4gc.s103 = inttoptr i64 %rs4gc.b103 to ptr addrspace(1)
  br label %apush.merge.731

apush.merge.731:                                  ; preds = %apush.barrier.done.735, %apush.realloc.730, %apush.fwd.725
  %.41023 = phi ptr addrspace(1) [ %rs4gc.s95.relocated592, %apush.fwd.725 ], [ %.21021, %apush.barrier.done.735 ], [ %rs4gc.s95.relocated597, %apush.realloc.730 ]
  %.41014 = phi ptr addrspace(1) [ %r3535.0.relocated593, %apush.fwd.725 ], [ %.21012, %apush.barrier.done.735 ], [ %r3535.0.relocated598, %apush.realloc.730 ]
  %.13973 = phi ptr addrspace(1) [ %rs4gc.s91.relocated594, %apush.fwd.725 ], [ %.11971, %apush.barrier.done.735 ], [ %rs4gc.s91.relocated599, %apush.realloc.730 ]
  %r3514.2.base = phi ptr addrspace(1) [ %rs4gc.s102, %apush.fwd.725 ], [ %.10987, %apush.barrier.done.735 ], [ %rs4gc.s103, %apush.realloc.730 ], !is_base_value !0
  %r3514.2 = phi ptr addrspace(1) [ %rs4gc.s102, %apush.fwd.725 ], [ %.10998, %apush.barrier.done.735 ], [ %rs4gc.s103, %apush.realloc.730 ]
  br label %if.merge.724

apush.pointer_layout.bookkeeping.732:             ; preds = %apush.inbounds.729
  call void @js_string_addref_if_heap_string(double %r4616) #7
  %r5738.rs4i = ptrtoint ptr addrspace(1) %.101009 to i64
  %r5738.rs4o = call i64 asm "", "=r,0"(i64 %r5738.rs4i) #7
  %r5738 = bitcast i64 %r5738.rs4o to double
  %r5739 = bitcast double %r5738 to i64
  call void @js_gc_note_slot_layout(i64 %r4660, i32 %r4681, i64 %r5739) #7
  %r5736.rs4i = ptrtoint ptr addrspace(1) %.101009 to i64
  %r5736.rs4o = call i64 asm "", "=r,0"(i64 %r5736.rs4i) #7
  %r5736 = bitcast i64 %r5736.rs4o to double
  %r5737 = bitcast double %r5736 to i64
  call void @js_array_note_numeric_write(i64 %r4660, i64 %r5737) #7
  br label %apush.pointer_layout.done.733

apush.pointer_layout.done.733:                    ; preds = %apush.pointer_layout.bookkeeping.732, %apush.inbounds.729
  %r4692 = sub i64 %r4660, 7
  %r4693 = inttoptr i64 %r4692 to ptr
  %r4694 = load i8, ptr %r4693, align 1
  %r4695 = and i8 %r4694, 32
  %r4696 = icmp ne i8 %r4695, 0
  %r4697 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4698 = icmp ne i32 %r4697, 0
  %r4699 = or i1 %r4696, %r4698
  br i1 %r4699, label %apush.barrier.734, label %apush.barrier.done.735

apush.barrier.734:                                ; preds = %apush.pointer_layout.done.733
  %r5734.rs4i = ptrtoint ptr addrspace(1) %.101009 to i64
  %r5734.rs4o = call i64 asm "", "=r,0"(i64 %r5734.rs4i) #7
  %r5734 = bitcast i64 %r5734.rs4o to double
  %r5735 = bitcast double %r5734 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r4660, i64 %r4685, i64 %r5735) #7
  br label %apush.barrier.done.735

apush.barrier.done.735:                           ; preds = %apush.barrier.734, %apush.pointer_layout.done.733
  %r4700 = add i32 %r4681, 1
  %r4701 = inttoptr i64 %r4660 to ptr
  store i32 %r4700, ptr %r4701, align 4
  br label %apush.merge.731

shadow.root.barrier.736:                          ; preds = %if.merge.724
  call void @js_write_barrier_root_nanbox(i64 %r4706) #7
  br label %shadow.root.barrier.done.737

shadow.root.barrier.done.737:                     ; preds = %shadow.root.barrier.736, %if.merge.724
  %r4709 = load double, ptr @test_json_warm_unique_keys_ts_.str.28.handle, align 8
  %r4710.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s101 to i64
  %r4710 = call i64 asm "", "=r,0"(i64 %r4710.rs4i) #7
  %statepoint_token600 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4710, double %r4709, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s95.relocated585, ptr addrspace(1) %r3535.0.relocated586, ptr addrspace(1) %r3514.1.base.relocated587, ptr addrspace(1) %rs4gc.s91.relocated588, ptr addrspace(1) %r3514.1.relocated589) ]
  %r4711601 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token600)
  %rs4gc.s95.relocated602 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token600, i32 0, i32 0) ; (%rs4gc.s95.relocated585, %rs4gc.s95.relocated585)
  %r3535.0.relocated603 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token600, i32 1, i32 1) ; (%r3535.0.relocated586, %r3535.0.relocated586)
  %r3514.1.base.relocated604 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token600, i32 2, i32 2) ; (%r3514.1.base.relocated587, %r3514.1.base.relocated587)
  %rs4gc.s91.relocated605 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token600, i32 3, i32 3) ; (%rs4gc.s91.relocated588, %rs4gc.s91.relocated588)
  %r3514.1.relocated606 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token600, i32 2, i32 4) ; (%r3514.1.base.relocated587, %r3514.1.relocated589)
  %rs4gc.s104 = inttoptr i64 %r4711601 to ptr addrspace(1)
  %r4712.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s104 to i64
  %r4712 = call i64 asm "", "=r,0"(i64 %r4712.rs4i) #7
  %r4713 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4714 = icmp ne i32 %r4713, 0
  br i1 %r4714, label %shadow.root.barrier.738, label %shadow.root.barrier.done.739

shadow.root.barrier.738:                          ; preds = %shadow.root.barrier.done.737
  call void @js_write_barrier_root_nanbox(i64 %r4712) #7
  br label %shadow.root.barrier.done.739

shadow.root.barrier.done.739:                     ; preds = %shadow.root.barrier.738, %shadow.root.barrier.done.737
  %r4716.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s104 to i64
  %r4716 = call i64 asm "", "=r,0"(i64 %r4716.rs4i) #7
  %statepoint_token607 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4716, double %r3521.0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s95.relocated602, ptr addrspace(1) %r3514.1.base.relocated604, ptr addrspace(1) %rs4gc.s91.relocated605, ptr addrspace(1) %r3535.0.relocated603, ptr addrspace(1) %r3514.1.relocated606) ]
  %r4717608 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token607)
  %rs4gc.s95.relocated609 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token607, i32 0, i32 0) ; (%rs4gc.s95.relocated602, %rs4gc.s95.relocated602)
  %r3514.1.base.relocated610 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token607, i32 1, i32 1) ; (%r3514.1.base.relocated604, %r3514.1.base.relocated604)
  %rs4gc.s91.relocated611 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token607, i32 2, i32 2) ; (%rs4gc.s91.relocated605, %rs4gc.s91.relocated605)
  %r3535.0.relocated612 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token607, i32 3, i32 3) ; (%r3535.0.relocated603, %r3535.0.relocated603)
  %r3514.1.relocated613 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token607, i32 1, i32 4) ; (%r3514.1.base.relocated604, %r3514.1.relocated606)
  %rs4gc.s105 = inttoptr i64 %r4717608 to ptr addrspace(1)
  %r4718.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s105 to i64
  %r4718 = call i64 asm "", "=r,0"(i64 %r4718.rs4i) #7
  %r4719 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4720 = icmp ne i32 %r4719, 0
  br i1 %r4720, label %shadow.root.barrier.740, label %shadow.root.barrier.done.741

shadow.root.barrier.740:                          ; preds = %shadow.root.barrier.done.739
  call void @js_write_barrier_root_nanbox(i64 %r4718) #7
  br label %shadow.root.barrier.done.741

shadow.root.barrier.done.741:                     ; preds = %shadow.root.barrier.740, %shadow.root.barrier.done.739
  %r4721.rs4i = ptrtoint ptr addrspace(1) %r3535.0.relocated612 to i64
  %r4721.rs4o = call i64 asm "", "=r,0"(i64 %r4721.rs4i) #7
  %r4721 = bitcast i64 %r4721.rs4o to double
  %r4722.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s105 to i64
  %r4722 = call i64 asm "", "=r,0"(i64 %r4722.rs4i) #7
  %statepoint_token614 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4722, double %r4721, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r3514.1.base.relocated610, ptr addrspace(1) %rs4gc.s91.relocated611, ptr addrspace(1) %rs4gc.s95.relocated609, ptr addrspace(1) %r3514.1.relocated613) ]
  %r4723615 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token614)
  %r3514.1.base.relocated616 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token614, i32 0, i32 0) ; (%r3514.1.base.relocated610, %r3514.1.base.relocated610)
  %rs4gc.s91.relocated617 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token614, i32 1, i32 1) ; (%rs4gc.s91.relocated611, %rs4gc.s91.relocated611)
  %rs4gc.s95.relocated618 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token614, i32 2, i32 2) ; (%rs4gc.s95.relocated609, %rs4gc.s95.relocated609)
  %r3514.1.relocated619 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token614, i32 0, i32 3) ; (%r3514.1.base.relocated610, %r3514.1.relocated613)
  %rs4gc.s106 = inttoptr i64 %r4723615 to ptr addrspace(1)
  %r4724.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s106 to i64
  %r4724 = call i64 asm "", "=r,0"(i64 %r4724.rs4i) #7
  %r4725 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4726 = icmp ne i32 %r4725, 0
  br i1 %r4726, label %shadow.root.barrier.742, label %shadow.root.barrier.done.743

shadow.root.barrier.742:                          ; preds = %shadow.root.barrier.done.741
  call void @js_write_barrier_root_nanbox(i64 %r4724) #7
  br label %shadow.root.barrier.done.743

shadow.root.barrier.done.743:                     ; preds = %shadow.root.barrier.742, %shadow.root.barrier.done.741
  %r4727.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s95.relocated618 to i64
  %r4727.rs4o = call i64 asm "", "=r,0"(i64 %r4727.rs4i) #7
  %r4727 = bitcast i64 %r4727.rs4o to double
  %r4728 = bitcast double %r4727 to i64
  %r4729 = and i64 %r4728, 281474976710655
  %r4730 = lshr i64 %r4728, 48
  %r4731 = and i64 %r4730, 65533
  %r4732 = icmp eq i64 %r4731, 32765
  br i1 %r4732, label %pget.recv_ok.745, label %pget.recv_other.749

pget.recv_sso.744:                                ; preds = %pget.recv_other.749
  %r4870 = load double, ptr @test_json_warm_unique_keys_ts_.str.26.handle, align 8
  %r4871 = bitcast double %r4870 to i64
  %r4872 = and i64 %r4871, 281474976710655
  %statepoint_token620 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r4728, i64 %r4872, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r3514.1.base.relocated616, ptr addrspace(1) %rs4gc.s91.relocated617, ptr addrspace(1) %rs4gc.s106, ptr addrspace(1) %r3514.1.relocated619) ]
  %r4873621 = call double @llvm.experimental.gc.result.f64(token %statepoint_token620)
  %r3514.1.base.relocated622 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token620, i32 0, i32 0) ; (%r3514.1.base.relocated616, %r3514.1.base.relocated616)
  %rs4gc.s91.relocated623 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token620, i32 1, i32 1) ; (%rs4gc.s91.relocated617, %rs4gc.s91.relocated617)
  %rs4gc.s106.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token620, i32 2, i32 2) ; (%rs4gc.s106, %rs4gc.s106)
  %r3514.1.relocated624 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token620, i32 0, i32 3) ; (%r3514.1.base.relocated616, %r3514.1.relocated619)
  br label %pget.recv_merge.748

pget.recv_ok.745:                                 ; preds = %shadow.root.barrier.done.743
  %r4739 = icmp ugt i64 %r4729, 1048575
  br i1 %r4739, label %pic.recv_hdr.766, label %pic.miss.cold.763

pget.recv_bad.746:                                ; preds = %pget.check_class_ref.750
  %r4862 = icmp eq i64 %r4728, 9222246136947933185
  %r4863 = icmp eq i64 %r4728, 9222246136947933186
  %r4864 = or i1 %r4862, %r4863
  br i1 %r4864, label %pget.throw_nullish.773, label %pget.recv_undef_return.774

pget.recv_class_ref.747:                          ; preds = %pget.check_class_ref.750
  %r4735 = load double, ptr @test_json_warm_unique_keys_ts_.str.26.handle, align 8
  %r4736 = bitcast double %r4735 to i64
  %r4737 = and i64 %r4736, 281474976710655
  %statepoint_token625 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 547434508618563597, i64 %r4728, i64 %r4737, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r3514.1.base.relocated616, ptr addrspace(1) %rs4gc.s91.relocated617, ptr addrspace(1) %rs4gc.s106, ptr addrspace(1) %r3514.1.relocated619) ]
  %r4738626 = call double @llvm.experimental.gc.result.f64(token %statepoint_token625)
  %r3514.1.base.relocated627 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token625, i32 0, i32 0) ; (%r3514.1.base.relocated616, %r3514.1.base.relocated616)
  %rs4gc.s91.relocated628 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token625, i32 1, i32 1) ; (%rs4gc.s91.relocated617, %rs4gc.s91.relocated617)
  %rs4gc.s106.relocated629 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token625, i32 2, i32 2) ; (%rs4gc.s106, %rs4gc.s106)
  %r3514.1.relocated630 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token625, i32 0, i32 3) ; (%r3514.1.base.relocated616, %r3514.1.relocated619)
  br label %pget.recv_merge.748

pget.recv_merge.748:                              ; preds = %pget.recv_undef_return.774, %pic.merge.765, %pget.recv_class_ref.747, %pget.recv_sso.744
  %.01032 = phi ptr addrspace(1) [ %.11033, %pic.merge.765 ], [ %rs4gc.s106.relocated, %pget.recv_sso.744 ], [ %rs4gc.s106.relocated629, %pget.recv_class_ref.747 ], [ %rs4gc.s106.relocated659, %pget.recv_undef_return.774 ]
  %.01029 = phi ptr addrspace(1) [ %.11030, %pic.merge.765 ], [ %r3514.1.relocated624, %pget.recv_sso.744 ], [ %r3514.1.relocated630, %pget.recv_class_ref.747 ], [ %r3514.1.relocated660, %pget.recv_undef_return.774 ]
  %.01026 = phi ptr addrspace(1) [ %.11027, %pic.merge.765 ], [ %r3514.1.base.relocated622, %pget.recv_sso.744 ], [ %r3514.1.base.relocated627, %pget.recv_class_ref.747 ], [ %r3514.1.base.relocated657, %pget.recv_undef_return.774 ]
  %.14974 = phi ptr addrspace(1) [ %.15975, %pic.merge.765 ], [ %rs4gc.s91.relocated623, %pget.recv_sso.744 ], [ %rs4gc.s91.relocated628, %pget.recv_class_ref.747 ], [ %rs4gc.s91.relocated658, %pget.recv_undef_return.774 ]
  %r4874 = phi double [ %r4861, %pic.merge.765 ], [ %r4869656, %pget.recv_undef_return.774 ], [ %r4873621, %pget.recv_sso.744 ], [ %r4738626, %pget.recv_class_ref.747 ]
  %statepoint_token631 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r4874, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01026, ptr addrspace(1) %.14974, ptr addrspace(1) %.01029, ptr addrspace(1) %.01032) ]
  %r4875632 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token631)
  %r3514.1.base.relocated633 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token631, i32 0, i32 0) ; (%.01026, %.01026)
  %rs4gc.s91.relocated634 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token631, i32 1, i32 1) ; (%.14974, %.14974)
  %r3514.1.relocated635 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token631, i32 0, i32 2) ; (%.01026, %.01029)
  %rs4gc.s106.relocated636 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token631, i32 3, i32 3) ; (%.01032, %.01032)
  %r4876 = bitcast i64 %r4875632 to double
  %r4877.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s106.relocated636 to i64
  %r4877 = call i64 asm "", "=r,0"(i64 %r4877.rs4i) #7
  %statepoint_token637 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4877, double %r4876, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r3514.1.base.relocated633, ptr addrspace(1) %rs4gc.s91.relocated634, ptr addrspace(1) %r3514.1.relocated635) ]
  %r4878638 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token637)
  %r3514.1.base.relocated639 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token637, i32 0, i32 0) ; (%r3514.1.base.relocated633, %r3514.1.base.relocated633)
  %rs4gc.s91.relocated640 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token637, i32 1, i32 1) ; (%rs4gc.s91.relocated634, %rs4gc.s91.relocated634)
  %r3514.1.relocated641 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token637, i32 0, i32 2) ; (%r3514.1.base.relocated633, %r3514.1.relocated635)
  %rs4gc.s107 = inttoptr i64 %r4878638 to ptr addrspace(1)
  %r4879.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s107 to i64
  %r4879 = call i64 asm "", "=r,0"(i64 %r4879.rs4i) #7
  %r4880 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4881 = icmp ne i32 %r4880, 0
  br i1 %r4881, label %shadow.root.barrier.775, label %shadow.root.barrier.done.776

pget.recv_other.749:                              ; preds = %shadow.root.barrier.done.743
  %r4733 = icmp eq i64 %r4730, 32761
  br i1 %r4733, label %pget.recv_sso.744, label %pget.check_class_ref.750

pget.check_class_ref.750:                         ; preds = %pget.recv_other.749
  %r4734 = icmp eq i64 %r4730, 32766
  br i1 %r4734, label %pget.recv_class_ref.747, label %pget.recv_bad.746

pic.hit.751:                                      ; preds = %pic.token.767
  %r4764 = getelementptr i64, ptr %r4749, i64 1
  %r4765 = load i64, ptr %r4764, align 8
  %r4766 = and i64 %r4765, 1073741824
  %r4767 = icmp ne i64 %r4766, 0
  br i1 %r4767, label %pic.hit.overflow.768, label %pic.hit.inline.769

pic.hit.live.752:                                 ; preds = %pic.hit.inline.769
  br label %pic.merge.765

pic.prefix.guard.753:                             ; preds = %pic.token.767
  %r4780 = getelementptr i64, ptr %r4749, i64 2
  %r4781 = load i64, ptr %r4780, align 8
  %r4782 = icmp ne i64 %r4781, 0
  br i1 %r4782, label %pic.prefix.meta.754, label %pic.miss.762

pic.prefix.meta.754:                              ; preds = %pic.prefix.guard.753
  %r4783 = add nuw nsw i64 %r4729, 8
  %r4784 = inttoptr i64 %r4783 to ptr
  %r4785 = load i64, ptr %r4784, align 8
  %r4786 = icmp ne i64 %r4785, 0
  br i1 %r4786, label %pic.prefix.token.755, label %pic.miss.762

pic.prefix.token.755:                             ; preds = %pic.prefix.meta.754
  %r4787 = inttoptr i64 %r4785 to ptr
  %r4788 = getelementptr i64, ptr %r4787, i64 6
  %r4789 = load i64, ptr %r4788, align 8
  %r4790 = icmp eq i64 %r4789, %r4781
  br i1 %r4790, label %pic.prefix.hit.756, label %pic.miss.762

pic.prefix.hit.756:                               ; preds = %pic.prefix.token.755
  %r4791 = getelementptr i64, ptr %r4749, i64 1
  %r4792 = load i64, ptr %r4791, align 8
  %r4793 = shl i64 %r4792, 3
  %r4794 = add nuw nsw i64 %r4729, 16
  %r4795 = add i64 %r4794, %r4793
  %r4796 = inttoptr i64 %r4795 to ptr
  %r4797 = load double, ptr %r4796, align 8
  br label %pic.merge.765

pic.desc.classify.757:                            ; preds = %pic.recv_hdr.766
  %r4753 = and i1 %r4743, %r4750
  br i1 %r4753, label %pic.desc.prefix.guard.758, label %pic.miss.cold.763

pic.desc.prefix.guard.758:                        ; preds = %pic.desc.classify.757
  %r4798 = getelementptr i64, ptr %r4749, i64 2
  %r4799 = load i64, ptr %r4798, align 8
  %r4800 = icmp ne i64 %r4799, 0
  br i1 %r4800, label %pic.desc.prefix.meta.759, label %pic.miss.cold.763

pic.desc.prefix.meta.759:                         ; preds = %pic.desc.prefix.guard.758
  %r4801 = add nuw nsw i64 %r4729, 8
  %r4802 = inttoptr i64 %r4801 to ptr
  %r4803 = load i64, ptr %r4802, align 8
  %r4804 = icmp ne i64 %r4803, 0
  br i1 %r4804, label %pic.desc.prefix.token.760, label %pic.miss.cold.763

pic.desc.prefix.token.760:                        ; preds = %pic.desc.prefix.meta.759
  %r4805 = inttoptr i64 %r4803 to ptr
  %r4806 = getelementptr i64, ptr %r4805, i64 6
  %r4807 = load i64, ptr %r4806, align 8
  %r4808 = icmp eq i64 %r4807, %r4799
  br i1 %r4808, label %pic.desc.prefix.hit.761, label %pic.miss.cold.763

pic.desc.prefix.hit.761:                          ; preds = %pic.desc.prefix.token.760
  %r4809 = getelementptr i64, ptr %r4749, i64 1
  %r4810 = load i64, ptr %r4809, align 8
  %r4811 = shl i64 %r4810, 3
  %r4812 = add nuw nsw i64 %r4729, 16
  %r4813 = add i64 %r4812, %r4811
  %r4814 = inttoptr i64 %r4813 to ptr
  %r4815 = load double, ptr %r4814, align 8
  br label %pic.merge.765

pic.miss.762:                                     ; preds = %pic.hit.inline.769, %pic.prefix.token.755, %pic.prefix.meta.754, %pic.prefix.guard.753
  %r4816 = getelementptr i64, ptr %r4749, i64 3
  %r4817 = load i64, ptr %r4816, align 8
  %r4818 = icmp sgt i64 %r4817, 0
  br i1 %r4818, label %pic.ways.770, label %pic.miss.call.764

pic.miss.cold.763:                                ; preds = %pic.desc.prefix.token.760, %pic.desc.prefix.meta.759, %pic.desc.prefix.guard.758, %pic.desc.classify.757, %pget.recv_ok.745
  br label %pic.miss.call.764

pic.miss.call.764:                                ; preds = %pic.way.load.771, %pic.ways.770, %pic.miss.cold.763, %pic.miss.762
  %r4857 = load double, ptr @test_json_warm_unique_keys_ts_.str.26.handle, align 8
  %r4858 = bitcast double %r4857 to i64
  %r4859 = and i64 %r4858, 281474976710655
  %statepoint_token642 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r4729, i64 %r4859, ptr @perry_ic_test_json_warm_unique_keys_ts__14, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r3514.1.base.relocated616, ptr addrspace(1) %rs4gc.s91.relocated617, ptr addrspace(1) %rs4gc.s106, ptr addrspace(1) %r3514.1.relocated619) ]
  %r4860643 = call double @llvm.experimental.gc.result.f64(token %statepoint_token642)
  %r3514.1.base.relocated644 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token642, i32 0, i32 0) ; (%r3514.1.base.relocated616, %r3514.1.base.relocated616)
  %rs4gc.s91.relocated645 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token642, i32 1, i32 1) ; (%rs4gc.s91.relocated617, %rs4gc.s91.relocated617)
  %rs4gc.s106.relocated646 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token642, i32 2, i32 2) ; (%rs4gc.s106, %rs4gc.s106)
  %r3514.1.relocated647 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token642, i32 0, i32 3) ; (%r3514.1.base.relocated616, %r3514.1.relocated619)
  br label %pic.merge.765

pic.merge.765:                                    ; preds = %pic.way.live.772, %pic.hit.overflow.768, %pic.miss.call.764, %pic.desc.prefix.hit.761, %pic.prefix.hit.756, %pic.hit.live.752
  %.11033 = phi ptr addrspace(1) [ %rs4gc.s106.relocated652, %pic.hit.overflow.768 ], [ %rs4gc.s106.relocated646, %pic.miss.call.764 ], [ %rs4gc.s106, %pic.way.live.772 ], [ %rs4gc.s106, %pic.hit.live.752 ], [ %rs4gc.s106, %pic.prefix.hit.756 ], [ %rs4gc.s106, %pic.desc.prefix.hit.761 ]
  %.11030 = phi ptr addrspace(1) [ %r3514.1.relocated653, %pic.hit.overflow.768 ], [ %r3514.1.relocated647, %pic.miss.call.764 ], [ %r3514.1.relocated619, %pic.way.live.772 ], [ %r3514.1.relocated619, %pic.hit.live.752 ], [ %r3514.1.relocated619, %pic.prefix.hit.756 ], [ %r3514.1.relocated619, %pic.desc.prefix.hit.761 ]
  %.11027 = phi ptr addrspace(1) [ %r3514.1.base.relocated650, %pic.hit.overflow.768 ], [ %r3514.1.base.relocated644, %pic.miss.call.764 ], [ %r3514.1.base.relocated616, %pic.way.live.772 ], [ %r3514.1.base.relocated616, %pic.hit.live.752 ], [ %r3514.1.base.relocated616, %pic.prefix.hit.756 ], [ %r3514.1.base.relocated616, %pic.desc.prefix.hit.761 ]
  %.15975 = phi ptr addrspace(1) [ %rs4gc.s91.relocated651, %pic.hit.overflow.768 ], [ %rs4gc.s91.relocated645, %pic.miss.call.764 ], [ %rs4gc.s91.relocated617, %pic.way.live.772 ], [ %rs4gc.s91.relocated617, %pic.hit.live.752 ], [ %rs4gc.s91.relocated617, %pic.prefix.hit.756 ], [ %rs4gc.s91.relocated617, %pic.desc.prefix.hit.761 ]
  %r4861 = phi double [ %r4777, %pic.hit.live.752 ], [ %r4772649, %pic.hit.overflow.768 ], [ %r4797, %pic.prefix.hit.756 ], [ %r4815, %pic.desc.prefix.hit.761 ], [ %r4854, %pic.way.live.772 ], [ %r4860643, %pic.miss.call.764 ]
  br label %pget.recv_merge.748

pic.recv_hdr.766:                                 ; preds = %pget.recv_ok.745
  %r4740 = sub nuw nsw i64 %r4729, 8
  %r4741 = inttoptr i64 %r4740 to ptr
  %r4742 = load i8, ptr %r4741, align 1
  %r4743 = icmp eq i8 %r4742, 2
  %r4744 = sub nuw nsw i64 %r4729, 6
  %r4745 = inttoptr i64 %r4744 to ptr
  %r4746 = load i16, ptr %r4745, align 2
  %r4747 = and i16 %r4746, 2048
  %r4748 = icmp eq i16 %r4747, 0
  %r4749 = load ptr, ptr @perry_ic_test_json_warm_unique_keys_ts__14, align 8
  %r4750 = icmp ne ptr %r4749, null
  %r4751 = and i1 %r4743, %r4748
  %r4752 = and i1 %r4751, %r4750
  br i1 %r4752, label %pic.token.767, label %pic.desc.classify.757

pic.token.767:                                    ; preds = %pic.recv_hdr.766
  %r4754 = add nuw nsw i64 %r4729, 4
  %r4755 = inttoptr i64 %r4754 to ptr
  %r4756 = load i32, ptr %r4755, align 4
  %r4757 = zext i32 %r4756 to i64
  %r4758 = or i64 %r4757, 4611686018427387904
  %r4759 = icmp ne i32 %r4756, 0
  %r4760 = getelementptr i64, ptr %r4749, i64 0
  %r4761 = load i64, ptr %r4760, align 8
  %r4762 = icmp eq i64 %r4758, %r4761
  %r4763 = and i1 %r4762, %r4759
  br i1 %r4763, label %pic.hit.751, label %pic.prefix.guard.753

pic.hit.overflow.768:                             ; preds = %pic.hit.751
  %r4768 = load double, ptr @test_json_warm_unique_keys_ts_.str.26.handle, align 8
  %r4769 = bitcast double %r4768 to i64
  %r4770 = and i64 %r4769, 281474976710655
  %r4771 = trunc i64 %r4765 to i32
  %statepoint_token648 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r4729, i64 %r4770, i32 %r4771, ptr @perry_ic_test_json_warm_unique_keys_ts__14, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r3514.1.base.relocated616, ptr addrspace(1) %rs4gc.s91.relocated617, ptr addrspace(1) %rs4gc.s106, ptr addrspace(1) %r3514.1.relocated619) ]
  %r4772649 = call double @llvm.experimental.gc.result.f64(token %statepoint_token648)
  %r3514.1.base.relocated650 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token648, i32 0, i32 0) ; (%r3514.1.base.relocated616, %r3514.1.base.relocated616)
  %rs4gc.s91.relocated651 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token648, i32 1, i32 1) ; (%rs4gc.s91.relocated617, %rs4gc.s91.relocated617)
  %rs4gc.s106.relocated652 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token648, i32 2, i32 2) ; (%rs4gc.s106, %rs4gc.s106)
  %r3514.1.relocated653 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token648, i32 0, i32 3) ; (%r3514.1.base.relocated616, %r3514.1.relocated619)
  br label %pic.merge.765

pic.hit.inline.769:                               ; preds = %pic.hit.751
  %r4773 = shl i64 %r4765, 3
  %r4774 = add nuw nsw i64 %r4729, 16
  %r4775 = add i64 %r4774, %r4773
  %r4776 = inttoptr i64 %r4775 to ptr
  %r4777 = load double, ptr %r4776, align 8
  %r4778 = bitcast double %r4777 to i64
  %r4779 = icmp eq i64 %r4778, 9222246136947933200
  br i1 %r4779, label %pic.miss.762, label %pic.hit.live.752

pic.ways.770:                                     ; preds = %pic.miss.762
  %r4819 = getelementptr i64, ptr %r4749, i64 4
  %r4820 = load i64, ptr %r4819, align 8
  %r4821 = icmp eq i64 %r4820, %r4758
  %r4822 = getelementptr i64, ptr %r4749, i64 5
  %r4823 = load i64, ptr %r4822, align 8
  %r4824 = select i1 %r4821, i64 %r4823, i64 0
  %r4825 = getelementptr i64, ptr %r4749, i64 6
  %r4826 = load i64, ptr %r4825, align 8
  %r4827 = icmp eq i64 %r4826, %r4758
  %r4828 = getelementptr i64, ptr %r4749, i64 7
  %r4829 = load i64, ptr %r4828, align 8
  %r4830 = select i1 %r4827, i64 %r4829, i64 0
  %r4831 = getelementptr i64, ptr %r4749, i64 8
  %r4832 = load i64, ptr %r4831, align 8
  %r4833 = icmp eq i64 %r4832, %r4758
  %r4834 = getelementptr i64, ptr %r4749, i64 9
  %r4835 = load i64, ptr %r4834, align 8
  %r4836 = select i1 %r4833, i64 %r4835, i64 0
  %r4837 = getelementptr i64, ptr %r4749, i64 10
  %r4838 = load i64, ptr %r4837, align 8
  %r4839 = icmp eq i64 %r4838, %r4758
  %r4840 = getelementptr i64, ptr %r4749, i64 11
  %r4841 = load i64, ptr %r4840, align 8
  %r4842 = select i1 %r4839, i64 %r4841, i64 0
  %r4843 = or i1 %r4821, %r4827
  %r4844 = select i1 %r4821, i64 %r4824, i64 %r4830
  %r4845 = or i1 %r4833, %r4839
  %r4846 = select i1 %r4833, i64 %r4836, i64 %r4842
  %r4847 = or i1 %r4843, %r4845
  %r4848 = select i1 %r4843, i64 %r4844, i64 %r4846
  %r4849 = and i1 %r4759, %r4847
  br i1 %r4849, label %pic.way.load.771, label %pic.miss.call.764

pic.way.load.771:                                 ; preds = %pic.ways.770
  %r4850 = shl i64 %r4848, 3
  %r4851 = add nuw nsw i64 %r4729, 16
  %r4852 = add i64 %r4851, %r4850
  %r4853 = inttoptr i64 %r4852 to ptr
  %r4854 = load double, ptr %r4853, align 8
  %r4855 = bitcast double %r4854 to i64
  %r4856 = icmp eq i64 %r4855, 9222246136947933200
  br i1 %r4856, label %pic.miss.call.764, label %pic.way.live.772

pic.way.live.772:                                 ; preds = %pic.way.load.771
  br label %pic.merge.765

pget.throw_nullish.773:                           ; preds = %pget.recv_bad.746
  %r4865 = zext i1 %r4863 to i32
  %statepoint_token654 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r4865, ptr @test_json_warm_unique_keys_ts_.str.26.bytes, i64 7, i32 0, i32 0)
  unreachable

pget.recv_undef_return.774:                       ; preds = %pget.recv_bad.746
  %r4866 = load double, ptr @test_json_warm_unique_keys_ts_.str.26.handle, align 8
  %r4867 = bitcast double %r4866 to i64
  %r4868 = and i64 %r4867, 281474976710655
  %statepoint_token655 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r4728, i64 %r4868, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r3514.1.base.relocated616, ptr addrspace(1) %rs4gc.s91.relocated617, ptr addrspace(1) %rs4gc.s106, ptr addrspace(1) %r3514.1.relocated619) ]
  %r4869656 = call double @llvm.experimental.gc.result.f64(token %statepoint_token655)
  %r3514.1.base.relocated657 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token655, i32 0, i32 0) ; (%r3514.1.base.relocated616, %r3514.1.base.relocated616)
  %rs4gc.s91.relocated658 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token655, i32 1, i32 1) ; (%rs4gc.s91.relocated617, %rs4gc.s91.relocated617)
  %rs4gc.s106.relocated659 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token655, i32 2, i32 2) ; (%rs4gc.s106, %rs4gc.s106)
  %r3514.1.relocated660 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token655, i32 0, i32 3) ; (%r3514.1.base.relocated616, %r3514.1.relocated619)
  br label %pget.recv_merge.748

shadow.root.barrier.775:                          ; preds = %pget.recv_merge.748
  call void @js_write_barrier_root_nanbox(i64 %r4879) #7
  br label %shadow.root.barrier.done.776

shadow.root.barrier.done.776:                     ; preds = %shadow.root.barrier.775, %pget.recv_merge.748
  %r4882.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s107 to i64
  %r4882 = call i64 asm "", "=r,0"(i64 %r4882.rs4i) #7
  %statepoint_token661 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r4882, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r3514.1.base.relocated639, ptr addrspace(1) %rs4gc.s91.relocated640, ptr addrspace(1) %r3514.1.relocated641) ]
  %r3514.1.base.relocated662 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token661, i32 0, i32 0) ; (%r3514.1.base.relocated639, %r3514.1.base.relocated639)
  %rs4gc.s91.relocated663 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token661, i32 1, i32 1) ; (%rs4gc.s91.relocated640, %rs4gc.s91.relocated640)
  %r3514.1.relocated664 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token661, i32 0, i32 2) ; (%r3514.1.base.relocated639, %r3514.1.relocated641)
  %r4883 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r4884 = icmp ne i32 %r4883, 0
  br i1 %r4884, label %gcpoll.777, label %gcpoll.done.778

gcpoll.777:                                       ; preds = %shadow.root.barrier.done.776
  %statepoint_token665 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r3514.1.base.relocated662, ptr addrspace(1) %r3514.1.relocated664, ptr addrspace(1) %rs4gc.s91.relocated663) ]
  %r3514.1.base.relocated666 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token665, i32 0, i32 0) ; (%r3514.1.base.relocated662, %r3514.1.base.relocated662)
  %r3514.1.relocated667 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token665, i32 0, i32 1) ; (%r3514.1.base.relocated662, %r3514.1.relocated664)
  %rs4gc.s91.relocated668 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token665, i32 2, i32 2) ; (%rs4gc.s91.relocated663, %rs4gc.s91.relocated663)
  br label %gcpoll.done.778

gcpoll.done.778:                                  ; preds = %gcpoll.777, %shadow.root.barrier.done.776
  %.21031 = phi ptr addrspace(1) [ %r3514.1.relocated667, %gcpoll.777 ], [ %r3514.1.relocated664, %shadow.root.barrier.done.776 ]
  %.21028 = phi ptr addrspace(1) [ %r3514.1.base.relocated666, %gcpoll.777 ], [ %r3514.1.base.relocated662, %shadow.root.barrier.done.776 ]
  %.16976 = phi ptr addrspace(1) [ %rs4gc.s91.relocated668, %gcpoll.777 ], [ %rs4gc.s91.relocated663, %shadow.root.barrier.done.776 ]
  br label %for.update.491

truthy.tag.780:                                   ; preds = %for.exit.492
  %r4895 = icmp eq i64 %r4890, 9222246136947933188
  %r4896 = icmp eq i64 %r4890, 9222246136947933187
  %r4899 = or i1 %r4896, false
  %r4900 = or i1 %r4899, false
  %r4901 = or i1 %r4895, %r4900
  br i1 %r4901, label %truthy.merge.782, label %truthy.obj.783

truthy.slow.781:                                  ; preds = %truthy.obj.783
  %r4907 = call i32 @js_is_truthy(double %r4891) #7
  %r4908 = icmp ne i32 %r4907, 0
  br label %truthy.merge.782

truthy.merge.782:                                 ; preds = %truthy.obj.783, %truthy.slow.781, %truthy.tag.780
  %r4909 = phi i1 [ %r4908, %truthy.slow.781 ], [ %r4895, %truthy.tag.780 ], [ true, %truthy.obj.783 ]
  br i1 %r4909, label %if.then.784, label %if.else.785

truthy.obj.783:                                   ; preds = %truthy.tag.780
  %r4902 = lshr i64 9222246136947933187, 48
  %r4903 = icmp eq i64 %r4902, 32765
  %r4904 = and i64 9222246136947933187, 281474976710655
  %r4905 = icmp ne i64 %r4904, 0
  %r4906 = and i1 %r4903, %r4905
  br i1 %r4906, label %truthy.merge.782, label %truthy.slow.781

if.then.784:                                      ; preds = %truthy.merge.782
  %r4911.rs4i = ptrtoint ptr addrspace(1) %r3514.0.relocated378 to i64
  %r4911.rs4o = call i64 asm "", "=r,0"(i64 %r4911.rs4i) #7
  %r4911 = bitcast i64 %r4911.rs4o to double
  %statepoint_token669 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_get_iterator, i32 1, i32 0, double %r4911, i32 0, i32 0)
  %r4912670 = call double @llvm.experimental.gc.result.f64(token %statepoint_token669)
  %rs4gc.b108 = bitcast double %r4912670 to i64
  %rs4gc.s108 = inttoptr i64 %rs4gc.b108 to ptr addrspace(1)
  %r4913.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s108 to i64
  %r4913 = call i64 asm "", "=r,0"(i64 %r4913.rs4i) #7
  %r4914 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4915 = icmp ne i32 %r4914, 0
  br i1 %r4915, label %shadow.root.barrier.787, label %shadow.root.barrier.done.788

if.else.785:                                      ; preds = %truthy.merge.782
  %r5471.rs4i = ptrtoint ptr addrspace(1) %r3514.0.relocated378 to i64
  %r5471.rs4o = call i64 asm "", "=r,0"(i64 %r5471.rs4i) #7
  %r5471 = bitcast i64 %r5471.rs4o to double
  %r5472 = bitcast double %r5471 to i64
  %r5473 = and i64 %r5472, -281474976710656
  %r5474 = icmp ne i64 %r5473, 9223090561878065152
  br i1 %r5474, label %str_addref.done.925, label %str_addref.call.924

if.merge.786:                                     ; preds = %for.exit.931, %for.exit.794
  %statepoint_token671 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token672 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token673 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token674 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token675 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.972

shadow.root.barrier.787:                          ; preds = %if.then.784
  call void @js_write_barrier_root_nanbox(i64 %r4913) #7
  br label %shadow.root.barrier.done.788

shadow.root.barrier.done.788:                     ; preds = %shadow.root.barrier.787, %if.then.784
  %r4917.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s108 to i64
  %r4917.rs4o = call i64 asm "", "=r,0"(i64 %r4917.rs4i) #7
  %r4917 = bitcast i64 %r4917.rs4o to double
  %statepoint_token676 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_for_of_next, i32 1, i32 0, double %r4917, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s108) ]
  %r4918677 = call double @llvm.experimental.gc.result.f64(token %statepoint_token676)
  %rs4gc.s108.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token676, i32 0, i32 0) ; (%rs4gc.s108, %rs4gc.s108)
  %rs4gc.b109 = bitcast double %r4918677 to i64
  %rs4gc.s109 = inttoptr i64 %rs4gc.b109 to ptr addrspace(1)
  %r4919.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s109 to i64
  %r4919 = call i64 asm "", "=r,0"(i64 %r4919.rs4i) #7
  %r4920 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4921 = icmp ne i32 %r4920, 0
  br i1 %r4921, label %shadow.root.barrier.789, label %shadow.root.barrier.done.790

shadow.root.barrier.789:                          ; preds = %shadow.root.barrier.done.788
  call void @js_write_barrier_root_nanbox(i64 %r4919) #7
  br label %shadow.root.barrier.done.790

shadow.root.barrier.done.790:                     ; preds = %shadow.root.barrier.789, %shadow.root.barrier.done.788
  br label %for.cond.791

for.cond.791:                                     ; preds = %gcpoll.done.923, %shadow.root.barrier.done.790
  %.01034 = phi ptr addrspace(1) [ %rs4gc.s108.relocated, %shadow.root.barrier.done.790 ], [ %.131047, %gcpoll.done.923 ]
  %r4916.0 = phi ptr addrspace(1) [ %rs4gc.s109, %shadow.root.barrier.done.790 ], [ %.01072, %gcpoll.done.923 ]
  %r4922.rs4i = ptrtoint ptr addrspace(1) %r4916.0 to i64
  %r4922.rs4o = call i64 asm "", "=r,0"(i64 %r4922.rs4i) #7
  %r4922 = bitcast i64 %r4922.rs4o to double
  %r4923 = bitcast double %r4922 to i64
  %r4924 = and i64 %r4923, 281474976710655
  %r4925 = lshr i64 %r4923, 48
  %r4926 = and i64 %r4925, 65533
  %r4927 = icmp eq i64 %r4926, 32765
  br i1 %r4927, label %pget.recv_ok.796, label %pget.recv_other.800

for.body.792:                                     ; preds = %gcpoll.done.832
  %r5096.rs4i = ptrtoint ptr addrspace(1) %.21056 to i64
  %r5096.rs4o = call i64 asm "", "=r,0"(i64 %r5096.rs4i) #7
  %r5096 = bitcast i64 %r5096.rs4o to double
  %r5097 = bitcast double %r5096 to i64
  %r5098 = and i64 %r5097, 281474976710655
  %r5099 = lshr i64 %r5097, 48
  %r5100 = and i64 %r5099, 65533
  %r5101 = icmp eq i64 %r5100, 32765
  br i1 %r5101, label %pget.recv_ok.834, label %pget.recv_other.838

for.update.793:                                   ; preds = %gcpoll.done.919
  %r5463.rs4i = ptrtoint ptr addrspace(1) %.81042 to i64
  %r5463.rs4o = call i64 asm "", "=r,0"(i64 %r5463.rs4i) #7
  %r5463 = bitcast i64 %r5463.rs4o to double
  %statepoint_token678 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_for_of_next, i32 1, i32 0, double %r5463, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.81042) ]
  %r5464679 = call double @llvm.experimental.gc.result.f64(token %statepoint_token678)
  %rs4gc.s108.relocated680 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token678, i32 0, i32 0) ; (%.81042, %.81042)
  %rs4gc.b110 = bitcast double %r5464679 to i64
  %rs4gc.s110 = inttoptr i64 %rs4gc.b110 to ptr addrspace(1)
  %r5465.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s110 to i64
  %r5465 = call i64 asm "", "=r,0"(i64 %r5465.rs4i) #7
  %r5466 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5467 = icmp ne i32 %r5466, 0
  br i1 %r5467, label %shadow.root.barrier.920, label %shadow.root.barrier.done.921

for.exit.794:                                     ; preds = %gcpoll.done.832
  br label %if.merge.786

pget.recv_sso.795:                                ; preds = %pget.recv_other.800
  %r5065 = load double, ptr @test_json_warm_unique_keys_ts_.str.29.handle, align 8
  %r5066 = bitcast double %r5065 to i64
  %r5067 = and i64 %r5066, 281474976710655
  %statepoint_token681 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r4923, i64 %r5067, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01034, ptr addrspace(1) %r4916.0) ]
  %r5068682 = call double @llvm.experimental.gc.result.f64(token %statepoint_token681)
  %rs4gc.s108.relocated683 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token681, i32 0, i32 0) ; (%.01034, %.01034)
  %r4916.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token681, i32 1, i32 1) ; (%r4916.0, %r4916.0)
  br label %pget.recv_merge.799

pget.recv_ok.796:                                 ; preds = %for.cond.791
  %r4934 = icmp ugt i64 %r4924, 1048575
  br i1 %r4934, label %pic.recv_hdr.817, label %pic.miss.cold.814

pget.recv_bad.797:                                ; preds = %pget.check_class_ref.801
  %r5057 = icmp eq i64 %r4923, 9222246136947933185
  %r5058 = icmp eq i64 %r4923, 9222246136947933186
  %r5059 = or i1 %r5057, %r5058
  br i1 %r5059, label %pget.throw_nullish.824, label %pget.recv_undef_return.825

pget.recv_class_ref.798:                          ; preds = %pget.check_class_ref.801
  %r4930 = load double, ptr @test_json_warm_unique_keys_ts_.str.29.handle, align 8
  %r4931 = bitcast double %r4930 to i64
  %r4932 = and i64 %r4931, 281474976710655
  %statepoint_token684 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 547434508618563599, i64 %r4923, i64 %r4932, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01034, ptr addrspace(1) %r4916.0) ]
  %r4933685 = call double @llvm.experimental.gc.result.f64(token %statepoint_token684)
  %rs4gc.s108.relocated686 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token684, i32 0, i32 0) ; (%.01034, %.01034)
  %r4916.0.relocated687 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token684, i32 1, i32 1) ; (%r4916.0, %r4916.0)
  br label %pget.recv_merge.799

pget.recv_merge.799:                              ; preds = %pget.recv_undef_return.825, %pic.merge.816, %pget.recv_class_ref.798, %pget.recv_sso.795
  %.01054 = phi ptr addrspace(1) [ %.11055, %pic.merge.816 ], [ %r4916.0.relocated, %pget.recv_sso.795 ], [ %r4916.0.relocated687, %pget.recv_class_ref.798 ], [ %r4916.0.relocated700, %pget.recv_undef_return.825 ]
  %.11035 = phi ptr addrspace(1) [ %.21036, %pic.merge.816 ], [ %rs4gc.s108.relocated683, %pget.recv_sso.795 ], [ %rs4gc.s108.relocated686, %pget.recv_class_ref.798 ], [ %rs4gc.s108.relocated699, %pget.recv_undef_return.825 ]
  %r5069 = phi double [ %r5056, %pic.merge.816 ], [ %r5064698, %pget.recv_undef_return.825 ], [ %r5068682, %pget.recv_sso.795 ], [ %r4933685, %pget.recv_class_ref.798 ]
  %r5070 = bitcast double %r5069 to i64
  %r5071 = and i64 %r5070, 9221120237041090560
  %r5072 = icmp ne i64 %r5071, 9221120237041090560
  br i1 %r5072, label %truthy.num.826, label %truthy.tag.827

pget.recv_other.800:                              ; preds = %for.cond.791
  %r4928 = icmp eq i64 %r4925, 32761
  br i1 %r4928, label %pget.recv_sso.795, label %pget.check_class_ref.801

pget.check_class_ref.801:                         ; preds = %pget.recv_other.800
  %r4929 = icmp eq i64 %r4925, 32766
  br i1 %r4929, label %pget.recv_class_ref.798, label %pget.recv_bad.797

pic.hit.802:                                      ; preds = %pic.token.818
  %r4959 = getelementptr i64, ptr %r4944, i64 1
  %r4960 = load i64, ptr %r4959, align 8
  %r4961 = and i64 %r4960, 1073741824
  %r4962 = icmp ne i64 %r4961, 0
  br i1 %r4962, label %pic.hit.overflow.819, label %pic.hit.inline.820

pic.hit.live.803:                                 ; preds = %pic.hit.inline.820
  br label %pic.merge.816

pic.prefix.guard.804:                             ; preds = %pic.token.818
  %r4975 = getelementptr i64, ptr %r4944, i64 2
  %r4976 = load i64, ptr %r4975, align 8
  %r4977 = icmp ne i64 %r4976, 0
  br i1 %r4977, label %pic.prefix.meta.805, label %pic.miss.813

pic.prefix.meta.805:                              ; preds = %pic.prefix.guard.804
  %r4978 = add nuw nsw i64 %r4924, 8
  %r4979 = inttoptr i64 %r4978 to ptr
  %r4980 = load i64, ptr %r4979, align 8
  %r4981 = icmp ne i64 %r4980, 0
  br i1 %r4981, label %pic.prefix.token.806, label %pic.miss.813

pic.prefix.token.806:                             ; preds = %pic.prefix.meta.805
  %r4982 = inttoptr i64 %r4980 to ptr
  %r4983 = getelementptr i64, ptr %r4982, i64 6
  %r4984 = load i64, ptr %r4983, align 8
  %r4985 = icmp eq i64 %r4984, %r4976
  br i1 %r4985, label %pic.prefix.hit.807, label %pic.miss.813

pic.prefix.hit.807:                               ; preds = %pic.prefix.token.806
  %r4986 = getelementptr i64, ptr %r4944, i64 1
  %r4987 = load i64, ptr %r4986, align 8
  %r4988 = shl i64 %r4987, 3
  %r4989 = add nuw nsw i64 %r4924, 16
  %r4990 = add i64 %r4989, %r4988
  %r4991 = inttoptr i64 %r4990 to ptr
  %r4992 = load double, ptr %r4991, align 8
  br label %pic.merge.816

pic.desc.classify.808:                            ; preds = %pic.recv_hdr.817
  %r4948 = and i1 %r4938, %r4945
  br i1 %r4948, label %pic.desc.prefix.guard.809, label %pic.miss.cold.814

pic.desc.prefix.guard.809:                        ; preds = %pic.desc.classify.808
  %r4993 = getelementptr i64, ptr %r4944, i64 2
  %r4994 = load i64, ptr %r4993, align 8
  %r4995 = icmp ne i64 %r4994, 0
  br i1 %r4995, label %pic.desc.prefix.meta.810, label %pic.miss.cold.814

pic.desc.prefix.meta.810:                         ; preds = %pic.desc.prefix.guard.809
  %r4996 = add nuw nsw i64 %r4924, 8
  %r4997 = inttoptr i64 %r4996 to ptr
  %r4998 = load i64, ptr %r4997, align 8
  %r4999 = icmp ne i64 %r4998, 0
  br i1 %r4999, label %pic.desc.prefix.token.811, label %pic.miss.cold.814

pic.desc.prefix.token.811:                        ; preds = %pic.desc.prefix.meta.810
  %r5000 = inttoptr i64 %r4998 to ptr
  %r5001 = getelementptr i64, ptr %r5000, i64 6
  %r5002 = load i64, ptr %r5001, align 8
  %r5003 = icmp eq i64 %r5002, %r4994
  br i1 %r5003, label %pic.desc.prefix.hit.812, label %pic.miss.cold.814

pic.desc.prefix.hit.812:                          ; preds = %pic.desc.prefix.token.811
  %r5004 = getelementptr i64, ptr %r4944, i64 1
  %r5005 = load i64, ptr %r5004, align 8
  %r5006 = shl i64 %r5005, 3
  %r5007 = add nuw nsw i64 %r4924, 16
  %r5008 = add i64 %r5007, %r5006
  %r5009 = inttoptr i64 %r5008 to ptr
  %r5010 = load double, ptr %r5009, align 8
  br label %pic.merge.816

pic.miss.813:                                     ; preds = %pic.hit.inline.820, %pic.prefix.token.806, %pic.prefix.meta.805, %pic.prefix.guard.804
  %r5011 = getelementptr i64, ptr %r4944, i64 3
  %r5012 = load i64, ptr %r5011, align 8
  %r5013 = icmp sgt i64 %r5012, 0
  br i1 %r5013, label %pic.ways.821, label %pic.miss.call.815

pic.miss.cold.814:                                ; preds = %pic.desc.prefix.token.811, %pic.desc.prefix.meta.810, %pic.desc.prefix.guard.809, %pic.desc.classify.808, %pget.recv_ok.796
  br label %pic.miss.call.815

pic.miss.call.815:                                ; preds = %pic.way.load.822, %pic.ways.821, %pic.miss.cold.814, %pic.miss.813
  %r5052 = load double, ptr @test_json_warm_unique_keys_ts_.str.29.handle, align 8
  %r5053 = bitcast double %r5052 to i64
  %r5054 = and i64 %r5053, 281474976710655
  %statepoint_token688 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r4924, i64 %r5054, ptr @perry_ic_test_json_warm_unique_keys_ts__16, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01034, ptr addrspace(1) %r4916.0) ]
  %r5055689 = call double @llvm.experimental.gc.result.f64(token %statepoint_token688)
  %rs4gc.s108.relocated690 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token688, i32 0, i32 0) ; (%.01034, %.01034)
  %r4916.0.relocated691 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token688, i32 1, i32 1) ; (%r4916.0, %r4916.0)
  br label %pic.merge.816

pic.merge.816:                                    ; preds = %pic.way.live.823, %pic.hit.overflow.819, %pic.miss.call.815, %pic.desc.prefix.hit.812, %pic.prefix.hit.807, %pic.hit.live.803
  %.11055 = phi ptr addrspace(1) [ %r4916.0.relocated695, %pic.hit.overflow.819 ], [ %r4916.0.relocated691, %pic.miss.call.815 ], [ %r4916.0, %pic.way.live.823 ], [ %r4916.0, %pic.hit.live.803 ], [ %r4916.0, %pic.prefix.hit.807 ], [ %r4916.0, %pic.desc.prefix.hit.812 ]
  %.21036 = phi ptr addrspace(1) [ %rs4gc.s108.relocated694, %pic.hit.overflow.819 ], [ %rs4gc.s108.relocated690, %pic.miss.call.815 ], [ %.01034, %pic.way.live.823 ], [ %.01034, %pic.hit.live.803 ], [ %.01034, %pic.prefix.hit.807 ], [ %.01034, %pic.desc.prefix.hit.812 ]
  %r5056 = phi double [ %r4972, %pic.hit.live.803 ], [ %r4967693, %pic.hit.overflow.819 ], [ %r4992, %pic.prefix.hit.807 ], [ %r5010, %pic.desc.prefix.hit.812 ], [ %r5049, %pic.way.live.823 ], [ %r5055689, %pic.miss.call.815 ]
  br label %pget.recv_merge.799

pic.recv_hdr.817:                                 ; preds = %pget.recv_ok.796
  %r4935 = sub nuw nsw i64 %r4924, 8
  %r4936 = inttoptr i64 %r4935 to ptr
  %r4937 = load i8, ptr %r4936, align 1
  %r4938 = icmp eq i8 %r4937, 2
  %r4939 = sub nuw nsw i64 %r4924, 6
  %r4940 = inttoptr i64 %r4939 to ptr
  %r4941 = load i16, ptr %r4940, align 2
  %r4942 = and i16 %r4941, 2048
  %r4943 = icmp eq i16 %r4942, 0
  %r4944 = load ptr, ptr @perry_ic_test_json_warm_unique_keys_ts__16, align 8
  %r4945 = icmp ne ptr %r4944, null
  %r4946 = and i1 %r4938, %r4943
  %r4947 = and i1 %r4946, %r4945
  br i1 %r4947, label %pic.token.818, label %pic.desc.classify.808

pic.token.818:                                    ; preds = %pic.recv_hdr.817
  %r4949 = add nuw nsw i64 %r4924, 4
  %r4950 = inttoptr i64 %r4949 to ptr
  %r4951 = load i32, ptr %r4950, align 4
  %r4952 = zext i32 %r4951 to i64
  %r4953 = or i64 %r4952, 4611686018427387904
  %r4954 = icmp ne i32 %r4951, 0
  %r4955 = getelementptr i64, ptr %r4944, i64 0
  %r4956 = load i64, ptr %r4955, align 8
  %r4957 = icmp eq i64 %r4953, %r4956
  %r4958 = and i1 %r4957, %r4954
  br i1 %r4958, label %pic.hit.802, label %pic.prefix.guard.804

pic.hit.overflow.819:                             ; preds = %pic.hit.802
  %r4963 = load double, ptr @test_json_warm_unique_keys_ts_.str.29.handle, align 8
  %r4964 = bitcast double %r4963 to i64
  %r4965 = and i64 %r4964, 281474976710655
  %r4966 = trunc i64 %r4960 to i32
  %statepoint_token692 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r4924, i64 %r4965, i32 %r4966, ptr @perry_ic_test_json_warm_unique_keys_ts__16, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01034, ptr addrspace(1) %r4916.0) ]
  %r4967693 = call double @llvm.experimental.gc.result.f64(token %statepoint_token692)
  %rs4gc.s108.relocated694 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token692, i32 0, i32 0) ; (%.01034, %.01034)
  %r4916.0.relocated695 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token692, i32 1, i32 1) ; (%r4916.0, %r4916.0)
  br label %pic.merge.816

pic.hit.inline.820:                               ; preds = %pic.hit.802
  %r4968 = shl i64 %r4960, 3
  %r4969 = add nuw nsw i64 %r4924, 16
  %r4970 = add i64 %r4969, %r4968
  %r4971 = inttoptr i64 %r4970 to ptr
  %r4972 = load double, ptr %r4971, align 8
  %r4973 = bitcast double %r4972 to i64
  %r4974 = icmp eq i64 %r4973, 9222246136947933200
  br i1 %r4974, label %pic.miss.813, label %pic.hit.live.803

pic.ways.821:                                     ; preds = %pic.miss.813
  %r5014 = getelementptr i64, ptr %r4944, i64 4
  %r5015 = load i64, ptr %r5014, align 8
  %r5016 = icmp eq i64 %r5015, %r4953
  %r5017 = getelementptr i64, ptr %r4944, i64 5
  %r5018 = load i64, ptr %r5017, align 8
  %r5019 = select i1 %r5016, i64 %r5018, i64 0
  %r5020 = getelementptr i64, ptr %r4944, i64 6
  %r5021 = load i64, ptr %r5020, align 8
  %r5022 = icmp eq i64 %r5021, %r4953
  %r5023 = getelementptr i64, ptr %r4944, i64 7
  %r5024 = load i64, ptr %r5023, align 8
  %r5025 = select i1 %r5022, i64 %r5024, i64 0
  %r5026 = getelementptr i64, ptr %r4944, i64 8
  %r5027 = load i64, ptr %r5026, align 8
  %r5028 = icmp eq i64 %r5027, %r4953
  %r5029 = getelementptr i64, ptr %r4944, i64 9
  %r5030 = load i64, ptr %r5029, align 8
  %r5031 = select i1 %r5028, i64 %r5030, i64 0
  %r5032 = getelementptr i64, ptr %r4944, i64 10
  %r5033 = load i64, ptr %r5032, align 8
  %r5034 = icmp eq i64 %r5033, %r4953
  %r5035 = getelementptr i64, ptr %r4944, i64 11
  %r5036 = load i64, ptr %r5035, align 8
  %r5037 = select i1 %r5034, i64 %r5036, i64 0
  %r5038 = or i1 %r5016, %r5022
  %r5039 = select i1 %r5016, i64 %r5019, i64 %r5025
  %r5040 = or i1 %r5028, %r5034
  %r5041 = select i1 %r5028, i64 %r5031, i64 %r5037
  %r5042 = or i1 %r5038, %r5040
  %r5043 = select i1 %r5038, i64 %r5039, i64 %r5041
  %r5044 = and i1 %r4954, %r5042
  br i1 %r5044, label %pic.way.load.822, label %pic.miss.call.815

pic.way.load.822:                                 ; preds = %pic.ways.821
  %r5045 = shl i64 %r5043, 3
  %r5046 = add nuw nsw i64 %r4924, 16
  %r5047 = add i64 %r5046, %r5045
  %r5048 = inttoptr i64 %r5047 to ptr
  %r5049 = load double, ptr %r5048, align 8
  %r5050 = bitcast double %r5049 to i64
  %r5051 = icmp eq i64 %r5050, 9222246136947933200
  br i1 %r5051, label %pic.miss.call.815, label %pic.way.live.823

pic.way.live.823:                                 ; preds = %pic.way.load.822
  br label %pic.merge.816

pget.throw_nullish.824:                           ; preds = %pget.recv_bad.797
  %r5060 = zext i1 %r5058 to i32
  %statepoint_token696 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r5060, ptr @test_json_warm_unique_keys_ts_.str.29.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.825:                       ; preds = %pget.recv_bad.797
  %r5061 = load double, ptr @test_json_warm_unique_keys_ts_.str.29.handle, align 8
  %r5062 = bitcast double %r5061 to i64
  %r5063 = and i64 %r5062, 281474976710655
  %statepoint_token697 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r4923, i64 %r5063, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01034, ptr addrspace(1) %r4916.0) ]
  %r5064698 = call double @llvm.experimental.gc.result.f64(token %statepoint_token697)
  %rs4gc.s108.relocated699 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token697, i32 0, i32 0) ; (%.01034, %.01034)
  %r4916.0.relocated700 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token697, i32 1, i32 1) ; (%r4916.0, %r4916.0)
  br label %pget.recv_merge.799

truthy.num.826:                                   ; preds = %pget.recv_merge.799
  %r5073 = fcmp one double %r5069, 0.000000e+00
  br label %truthy.merge.829

truthy.tag.827:                                   ; preds = %pget.recv_merge.799
  %r5074 = icmp eq i64 %r5070, 9222246136947933188
  %r5075 = icmp eq i64 %r5070, 9222246136947933187
  %r5076 = icmp eq i64 %r5070, 9222246136947933185
  %r5077 = icmp eq i64 %r5070, 9222246136947933186
  %r5078 = or i1 %r5075, %r5076
  %r5079 = or i1 %r5078, %r5077
  %r5080 = or i1 %r5074, %r5079
  br i1 %r5080, label %truthy.merge.829, label %truthy.obj.830

truthy.slow.828:                                  ; preds = %truthy.obj.830
  %r5086 = call i32 @js_is_truthy(double %r5069) #7
  %r5087 = icmp ne i32 %r5086, 0
  br label %truthy.merge.829

truthy.merge.829:                                 ; preds = %truthy.obj.830, %truthy.slow.828, %truthy.tag.827, %truthy.num.826
  %r5088 = phi i1 [ %r5073, %truthy.num.826 ], [ %r5074, %truthy.tag.827 ], [ true, %truthy.obj.830 ], [ %r5087, %truthy.slow.828 ]
  %r5089 = xor i1 %r5088, true
  %r5090 = select i1 %r5089, i64 9222246136947933188, i64 9222246136947933187
  %r5091 = bitcast i64 %r5090 to double
  %r5093 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r5094 = icmp ne i32 %r5093, 0
  br i1 %r5094, label %gcpoll.831, label %gcpoll.done.832

truthy.obj.830:                                   ; preds = %truthy.tag.827
  %r5081 = lshr i64 %r5070, 48
  %r5082 = icmp eq i64 %r5081, 32765
  %r5083 = and i64 %r5070, 281474976710655
  %r5084 = icmp ne i64 %r5083, 0
  %r5085 = and i1 %r5082, %r5084
  br i1 %r5085, label %truthy.merge.829, label %truthy.slow.828

gcpoll.831:                                       ; preds = %truthy.merge.829
  %statepoint_token701 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11035, ptr addrspace(1) %.01054) ]
  %rs4gc.s108.relocated702 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token701, i32 0, i32 0) ; (%.11035, %.11035)
  %r4916.0.relocated703 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token701, i32 1, i32 1) ; (%.01054, %.01054)
  br label %gcpoll.done.832

gcpoll.done.832:                                  ; preds = %gcpoll.831, %truthy.merge.829
  %.21056 = phi ptr addrspace(1) [ %r4916.0.relocated703, %gcpoll.831 ], [ %.01054, %truthy.merge.829 ]
  %.31037 = phi ptr addrspace(1) [ %rs4gc.s108.relocated702, %gcpoll.831 ], [ %.11035, %truthy.merge.829 ]
  %r5092 = icmp eq i64 %r5090, 9222246136947933188
  br i1 %r5092, label %for.body.792, label %for.exit.794

pget.recv_sso.833:                                ; preds = %pget.recv_other.838
  %r5239 = load double, ptr @test_json_warm_unique_keys_ts_.str.30.handle, align 8
  %r5240 = bitcast double %r5239 to i64
  %r5241 = and i64 %r5240, 281474976710655
  %statepoint_token704 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r5097, i64 %r5241, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31037) ]
  %r5242705 = call double @llvm.experimental.gc.result.f64(token %statepoint_token704)
  %rs4gc.s108.relocated706 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token704, i32 0, i32 0) ; (%.31037, %.31037)
  br label %pget.recv_merge.837

pget.recv_ok.834:                                 ; preds = %for.body.792
  %r5108 = icmp ugt i64 %r5098, 1048575
  br i1 %r5108, label %pic.recv_hdr.855, label %pic.miss.cold.852

pget.recv_bad.835:                                ; preds = %pget.check_class_ref.839
  %r5231 = icmp eq i64 %r5097, 9222246136947933185
  %r5232 = icmp eq i64 %r5097, 9222246136947933186
  %r5233 = or i1 %r5231, %r5232
  br i1 %r5233, label %pget.throw_nullish.862, label %pget.recv_undef_return.863

pget.recv_class_ref.836:                          ; preds = %pget.check_class_ref.839
  %r5104 = load double, ptr @test_json_warm_unique_keys_ts_.str.30.handle, align 8
  %r5105 = bitcast double %r5104 to i64
  %r5106 = and i64 %r5105, 281474976710655
  %statepoint_token707 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 547434508618563601, i64 %r5097, i64 %r5106, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31037) ]
  %r5107708 = call double @llvm.experimental.gc.result.f64(token %statepoint_token707)
  %rs4gc.s108.relocated709 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token707, i32 0, i32 0) ; (%.31037, %.31037)
  br label %pget.recv_merge.837

pget.recv_merge.837:                              ; preds = %pget.recv_undef_return.863, %pic.merge.854, %pget.recv_class_ref.836, %pget.recv_sso.833
  %.41038 = phi ptr addrspace(1) [ %.51039, %pic.merge.854 ], [ %rs4gc.s108.relocated706, %pget.recv_sso.833 ], [ %rs4gc.s108.relocated709, %pget.recv_class_ref.836 ], [ %rs4gc.s108.relocated719, %pget.recv_undef_return.863 ]
  %r5243 = phi double [ %r5230, %pic.merge.854 ], [ %r5238718, %pget.recv_undef_return.863 ], [ %r5242705, %pget.recv_sso.833 ], [ %r5107708, %pget.recv_class_ref.836 ]
  %rs4gc.b111 = bitcast double %r5243 to i64
  %rs4gc.s111 = inttoptr i64 %rs4gc.b111 to ptr addrspace(1)
  %r5244.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s111 to i64
  %r5244 = call i64 asm "", "=r,0"(i64 %r5244.rs4i) #7
  %r5245 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5246 = icmp ne i32 %r5245, 0
  br i1 %r5246, label %shadow.root.barrier.864, label %shadow.root.barrier.done.865

pget.recv_other.838:                              ; preds = %for.body.792
  %r5102 = icmp eq i64 %r5099, 32761
  br i1 %r5102, label %pget.recv_sso.833, label %pget.check_class_ref.839

pget.check_class_ref.839:                         ; preds = %pget.recv_other.838
  %r5103 = icmp eq i64 %r5099, 32766
  br i1 %r5103, label %pget.recv_class_ref.836, label %pget.recv_bad.835

pic.hit.840:                                      ; preds = %pic.token.856
  %r5133 = getelementptr i64, ptr %r5118, i64 1
  %r5134 = load i64, ptr %r5133, align 8
  %r5135 = and i64 %r5134, 1073741824
  %r5136 = icmp ne i64 %r5135, 0
  br i1 %r5136, label %pic.hit.overflow.857, label %pic.hit.inline.858

pic.hit.live.841:                                 ; preds = %pic.hit.inline.858
  br label %pic.merge.854

pic.prefix.guard.842:                             ; preds = %pic.token.856
  %r5149 = getelementptr i64, ptr %r5118, i64 2
  %r5150 = load i64, ptr %r5149, align 8
  %r5151 = icmp ne i64 %r5150, 0
  br i1 %r5151, label %pic.prefix.meta.843, label %pic.miss.851

pic.prefix.meta.843:                              ; preds = %pic.prefix.guard.842
  %r5152 = add nuw nsw i64 %r5098, 8
  %r5153 = inttoptr i64 %r5152 to ptr
  %r5154 = load i64, ptr %r5153, align 8
  %r5155 = icmp ne i64 %r5154, 0
  br i1 %r5155, label %pic.prefix.token.844, label %pic.miss.851

pic.prefix.token.844:                             ; preds = %pic.prefix.meta.843
  %r5156 = inttoptr i64 %r5154 to ptr
  %r5157 = getelementptr i64, ptr %r5156, i64 6
  %r5158 = load i64, ptr %r5157, align 8
  %r5159 = icmp eq i64 %r5158, %r5150
  br i1 %r5159, label %pic.prefix.hit.845, label %pic.miss.851

pic.prefix.hit.845:                               ; preds = %pic.prefix.token.844
  %r5160 = getelementptr i64, ptr %r5118, i64 1
  %r5161 = load i64, ptr %r5160, align 8
  %r5162 = shl i64 %r5161, 3
  %r5163 = add nuw nsw i64 %r5098, 16
  %r5164 = add i64 %r5163, %r5162
  %r5165 = inttoptr i64 %r5164 to ptr
  %r5166 = load double, ptr %r5165, align 8
  br label %pic.merge.854

pic.desc.classify.846:                            ; preds = %pic.recv_hdr.855
  %r5122 = and i1 %r5112, %r5119
  br i1 %r5122, label %pic.desc.prefix.guard.847, label %pic.miss.cold.852

pic.desc.prefix.guard.847:                        ; preds = %pic.desc.classify.846
  %r5167 = getelementptr i64, ptr %r5118, i64 2
  %r5168 = load i64, ptr %r5167, align 8
  %r5169 = icmp ne i64 %r5168, 0
  br i1 %r5169, label %pic.desc.prefix.meta.848, label %pic.miss.cold.852

pic.desc.prefix.meta.848:                         ; preds = %pic.desc.prefix.guard.847
  %r5170 = add nuw nsw i64 %r5098, 8
  %r5171 = inttoptr i64 %r5170 to ptr
  %r5172 = load i64, ptr %r5171, align 8
  %r5173 = icmp ne i64 %r5172, 0
  br i1 %r5173, label %pic.desc.prefix.token.849, label %pic.miss.cold.852

pic.desc.prefix.token.849:                        ; preds = %pic.desc.prefix.meta.848
  %r5174 = inttoptr i64 %r5172 to ptr
  %r5175 = getelementptr i64, ptr %r5174, i64 6
  %r5176 = load i64, ptr %r5175, align 8
  %r5177 = icmp eq i64 %r5176, %r5168
  br i1 %r5177, label %pic.desc.prefix.hit.850, label %pic.miss.cold.852

pic.desc.prefix.hit.850:                          ; preds = %pic.desc.prefix.token.849
  %r5178 = getelementptr i64, ptr %r5118, i64 1
  %r5179 = load i64, ptr %r5178, align 8
  %r5180 = shl i64 %r5179, 3
  %r5181 = add nuw nsw i64 %r5098, 16
  %r5182 = add i64 %r5181, %r5180
  %r5183 = inttoptr i64 %r5182 to ptr
  %r5184 = load double, ptr %r5183, align 8
  br label %pic.merge.854

pic.miss.851:                                     ; preds = %pic.hit.inline.858, %pic.prefix.token.844, %pic.prefix.meta.843, %pic.prefix.guard.842
  %r5185 = getelementptr i64, ptr %r5118, i64 3
  %r5186 = load i64, ptr %r5185, align 8
  %r5187 = icmp sgt i64 %r5186, 0
  br i1 %r5187, label %pic.ways.859, label %pic.miss.call.853

pic.miss.cold.852:                                ; preds = %pic.desc.prefix.token.849, %pic.desc.prefix.meta.848, %pic.desc.prefix.guard.847, %pic.desc.classify.846, %pget.recv_ok.834
  br label %pic.miss.call.853

pic.miss.call.853:                                ; preds = %pic.way.load.860, %pic.ways.859, %pic.miss.cold.852, %pic.miss.851
  %r5226 = load double, ptr @test_json_warm_unique_keys_ts_.str.30.handle, align 8
  %r5227 = bitcast double %r5226 to i64
  %r5228 = and i64 %r5227, 281474976710655
  %statepoint_token710 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r5098, i64 %r5228, ptr @perry_ic_test_json_warm_unique_keys_ts__18, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31037) ]
  %r5229711 = call double @llvm.experimental.gc.result.f64(token %statepoint_token710)
  %rs4gc.s108.relocated712 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token710, i32 0, i32 0) ; (%.31037, %.31037)
  br label %pic.merge.854

pic.merge.854:                                    ; preds = %pic.way.live.861, %pic.hit.overflow.857, %pic.miss.call.853, %pic.desc.prefix.hit.850, %pic.prefix.hit.845, %pic.hit.live.841
  %.51039 = phi ptr addrspace(1) [ %rs4gc.s108.relocated715, %pic.hit.overflow.857 ], [ %rs4gc.s108.relocated712, %pic.miss.call.853 ], [ %.31037, %pic.way.live.861 ], [ %.31037, %pic.hit.live.841 ], [ %.31037, %pic.prefix.hit.845 ], [ %.31037, %pic.desc.prefix.hit.850 ]
  %r5230 = phi double [ %r5146, %pic.hit.live.841 ], [ %r5141714, %pic.hit.overflow.857 ], [ %r5166, %pic.prefix.hit.845 ], [ %r5184, %pic.desc.prefix.hit.850 ], [ %r5223, %pic.way.live.861 ], [ %r5229711, %pic.miss.call.853 ]
  br label %pget.recv_merge.837

pic.recv_hdr.855:                                 ; preds = %pget.recv_ok.834
  %r5109 = sub nuw nsw i64 %r5098, 8
  %r5110 = inttoptr i64 %r5109 to ptr
  %r5111 = load i8, ptr %r5110, align 1
  %r5112 = icmp eq i8 %r5111, 2
  %r5113 = sub nuw nsw i64 %r5098, 6
  %r5114 = inttoptr i64 %r5113 to ptr
  %r5115 = load i16, ptr %r5114, align 2
  %r5116 = and i16 %r5115, 2048
  %r5117 = icmp eq i16 %r5116, 0
  %r5118 = load ptr, ptr @perry_ic_test_json_warm_unique_keys_ts__18, align 8
  %r5119 = icmp ne ptr %r5118, null
  %r5120 = and i1 %r5112, %r5117
  %r5121 = and i1 %r5120, %r5119
  br i1 %r5121, label %pic.token.856, label %pic.desc.classify.846

pic.token.856:                                    ; preds = %pic.recv_hdr.855
  %r5123 = add nuw nsw i64 %r5098, 4
  %r5124 = inttoptr i64 %r5123 to ptr
  %r5125 = load i32, ptr %r5124, align 4
  %r5126 = zext i32 %r5125 to i64
  %r5127 = or i64 %r5126, 4611686018427387904
  %r5128 = icmp ne i32 %r5125, 0
  %r5129 = getelementptr i64, ptr %r5118, i64 0
  %r5130 = load i64, ptr %r5129, align 8
  %r5131 = icmp eq i64 %r5127, %r5130
  %r5132 = and i1 %r5131, %r5128
  br i1 %r5132, label %pic.hit.840, label %pic.prefix.guard.842

pic.hit.overflow.857:                             ; preds = %pic.hit.840
  %r5137 = load double, ptr @test_json_warm_unique_keys_ts_.str.30.handle, align 8
  %r5138 = bitcast double %r5137 to i64
  %r5139 = and i64 %r5138, 281474976710655
  %r5140 = trunc i64 %r5134 to i32
  %statepoint_token713 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r5098, i64 %r5139, i32 %r5140, ptr @perry_ic_test_json_warm_unique_keys_ts__18, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31037) ]
  %r5141714 = call double @llvm.experimental.gc.result.f64(token %statepoint_token713)
  %rs4gc.s108.relocated715 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token713, i32 0, i32 0) ; (%.31037, %.31037)
  br label %pic.merge.854

pic.hit.inline.858:                               ; preds = %pic.hit.840
  %r5142 = shl i64 %r5134, 3
  %r5143 = add nuw nsw i64 %r5098, 16
  %r5144 = add i64 %r5143, %r5142
  %r5145 = inttoptr i64 %r5144 to ptr
  %r5146 = load double, ptr %r5145, align 8
  %r5147 = bitcast double %r5146 to i64
  %r5148 = icmp eq i64 %r5147, 9222246136947933200
  br i1 %r5148, label %pic.miss.851, label %pic.hit.live.841

pic.ways.859:                                     ; preds = %pic.miss.851
  %r5188 = getelementptr i64, ptr %r5118, i64 4
  %r5189 = load i64, ptr %r5188, align 8
  %r5190 = icmp eq i64 %r5189, %r5127
  %r5191 = getelementptr i64, ptr %r5118, i64 5
  %r5192 = load i64, ptr %r5191, align 8
  %r5193 = select i1 %r5190, i64 %r5192, i64 0
  %r5194 = getelementptr i64, ptr %r5118, i64 6
  %r5195 = load i64, ptr %r5194, align 8
  %r5196 = icmp eq i64 %r5195, %r5127
  %r5197 = getelementptr i64, ptr %r5118, i64 7
  %r5198 = load i64, ptr %r5197, align 8
  %r5199 = select i1 %r5196, i64 %r5198, i64 0
  %r5200 = getelementptr i64, ptr %r5118, i64 8
  %r5201 = load i64, ptr %r5200, align 8
  %r5202 = icmp eq i64 %r5201, %r5127
  %r5203 = getelementptr i64, ptr %r5118, i64 9
  %r5204 = load i64, ptr %r5203, align 8
  %r5205 = select i1 %r5202, i64 %r5204, i64 0
  %r5206 = getelementptr i64, ptr %r5118, i64 10
  %r5207 = load i64, ptr %r5206, align 8
  %r5208 = icmp eq i64 %r5207, %r5127
  %r5209 = getelementptr i64, ptr %r5118, i64 11
  %r5210 = load i64, ptr %r5209, align 8
  %r5211 = select i1 %r5208, i64 %r5210, i64 0
  %r5212 = or i1 %r5190, %r5196
  %r5213 = select i1 %r5190, i64 %r5193, i64 %r5199
  %r5214 = or i1 %r5202, %r5208
  %r5215 = select i1 %r5202, i64 %r5205, i64 %r5211
  %r5216 = or i1 %r5212, %r5214
  %r5217 = select i1 %r5212, i64 %r5213, i64 %r5215
  %r5218 = and i1 %r5128, %r5216
  br i1 %r5218, label %pic.way.load.860, label %pic.miss.call.853

pic.way.load.860:                                 ; preds = %pic.ways.859
  %r5219 = shl i64 %r5217, 3
  %r5220 = add nuw nsw i64 %r5098, 16
  %r5221 = add i64 %r5220, %r5219
  %r5222 = inttoptr i64 %r5221 to ptr
  %r5223 = load double, ptr %r5222, align 8
  %r5224 = bitcast double %r5223 to i64
  %r5225 = icmp eq i64 %r5224, 9222246136947933200
  br i1 %r5225, label %pic.miss.call.853, label %pic.way.live.861

pic.way.live.861:                                 ; preds = %pic.way.load.860
  br label %pic.merge.854

pget.throw_nullish.862:                           ; preds = %pget.recv_bad.835
  %r5234 = zext i1 %r5232 to i32
  %statepoint_token716 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r5234, ptr @test_json_warm_unique_keys_ts_.str.30.bytes, i64 5, i32 0, i32 0)
  unreachable

pget.recv_undef_return.863:                       ; preds = %pget.recv_bad.835
  %r5235 = load double, ptr @test_json_warm_unique_keys_ts_.str.30.handle, align 8
  %r5236 = bitcast double %r5235 to i64
  %r5237 = and i64 %r5236, 281474976710655
  %statepoint_token717 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r5097, i64 %r5237, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31037) ]
  %r5238718 = call double @llvm.experimental.gc.result.f64(token %statepoint_token717)
  %rs4gc.s108.relocated719 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token717, i32 0, i32 0) ; (%.31037, %.31037)
  br label %pget.recv_merge.837

shadow.root.barrier.864:                          ; preds = %pget.recv_merge.837
  call void @js_write_barrier_root_nanbox(i64 %r5244) #7
  br label %shadow.root.barrier.done.865

shadow.root.barrier.done.865:                     ; preds = %shadow.root.barrier.864, %pget.recv_merge.837
  %statepoint_token720 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_eh_try_push, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.41038, ptr addrspace(1) %rs4gc.s111) ]
  %rs4gc.s108.relocated721 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token720, i32 0, i32 0) ; (%.41038, %.41038)
  %rs4gc.s111.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token720, i32 1, i32 1) ; (%rs4gc.s111, %rs4gc.s111)
  br label %try.body.866

try.body.866:                                     ; preds = %shadow.root.barrier.done.865
  %statepoint_token725 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s108.relocated721, ptr addrspace(1) %rs4gc.s111.relocated) ]
          to label %eh.cont5249 unwind label %eh.lpad.8691

eh.cont5249:                                      ; preds = %try.body.866
  %r5248726 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token725)
  %rs4gc.s108.relocated727 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token725, i32 0, i32 0) ; (%rs4gc.s108.relocated721, %rs4gc.s108.relocated721)
  %rs4gc.s111.relocated728 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token725, i32 1, i32 1) ; (%rs4gc.s111.relocated, %rs4gc.s111.relocated)
  %rs4gc.s112 = inttoptr i64 %r5248726 to ptr addrspace(1)
  %r5250.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s112 to i64
  %r5250 = call i64 asm "", "=r,0"(i64 %r5250.rs4i) #7
  %r5251 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5252 = icmp ne i32 %r5251, 0
  br i1 %r5252, label %shadow.root.barrier.870, label %shadow.root.barrier.done.871

try.catch.867:                                    ; preds = %eh.lpad.869
  %statepoint_token729 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_try_end, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61040) ]
  %rs4gc.s108.relocated730 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token729, i32 0, i32 0) ; (%.61040, %.61040)
  %statepoint_token731 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_get_exception, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s108.relocated730) ]
  %r5275732 = call double @llvm.experimental.gc.result.f64(token %statepoint_token731)
  %rs4gc.s108.relocated733 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token731, i32 0, i32 0) ; (%rs4gc.s108.relocated730, %rs4gc.s108.relocated730)
  %statepoint_token734 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_clear_exception, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s108.relocated733) ]
  %rs4gc.s108.relocated735 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token734, i32 0, i32 0) ; (%rs4gc.s108.relocated733, %rs4gc.s108.relocated733)
  %rs4gc.b113 = bitcast double %r5275732 to i64
  %rs4gc.s113 = inttoptr i64 %rs4gc.b113 to ptr addrspace(1)
  %r5277.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s113 to i64
  %r5277 = call i64 asm "", "=r,0"(i64 %r5277.rs4i) #7
  %r5278 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5279 = icmp ne i32 %r5278, 0
  br i1 %r5279, label %shadow.root.barrier.876, label %shadow.root.barrier.done.877

try.finally.868:                                  ; preds = %eh.cont5274
  %r5461 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r5462 = icmp ne i32 %r5461, 0
  br i1 %r5462, label %gcpoll.918, label %gcpoll.done.919

eh.lpad.8691:                                     ; preds = %try.body.866
  %lpad = landingpad token
          cleanup
  %rs4gc.s108.relocated723 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad, i32 0, i32 0) ; (%rs4gc.s108.relocated721, %rs4gc.s108.relocated721)
  %rs4gc.s111.relocated724 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad, i32 1, i32 1) ; (%rs4gc.s111.relocated, %rs4gc.s111.relocated)
  br label %eh.lpad.869

eh.lpad.869.split-lp2:                            ; preds = %shadow.root.barrier.870
  %lpad3 = landingpad token
          cleanup
  %rs4gc.s108.relocated737 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad3, i32 0, i32 0) ; (%rs4gc.s108.relocated727, %rs4gc.s108.relocated727)
  %rs4gc.s111.relocated738 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad3, i32 1, i32 1) ; (%rs4gc.s111.relocated728, %rs4gc.s111.relocated728)
  %rs4gc.s112.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad3, i32 2, i32 2) ; (%rs4gc.s112, %rs4gc.s112)
  br label %eh.lpad.869.split-lp

eh.lpad.869.split-lp.split-lp5:                   ; preds = %shadow.root.barrier.done.871
  %lpad6 = landingpad token
          cleanup
  %rs4gc.s108.relocated744 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad6, i32 0, i32 0) ; (%.71041, %.71041)
  %rs4gc.s111.relocated745 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad6, i32 1, i32 1) ; (%.01057, %.01057)
  br label %eh.lpad.869.split-lp.split-lp

eh.lpad.869.split-lp.split-lp.split-lp7:          ; preds = %shadow.root.barrier.872
  %lpad8 = landingpad token
          cleanup
  %rs4gc.s108.relocated751 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad8, i32 0, i32 0) ; (%rs4gc.s108.relocated748, %rs4gc.s108.relocated748)
  %rs4gc.s114.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad8, i32 1, i32 1) ; (%rs4gc.s114, %rs4gc.s114)
  %rs4gc.s111.relocated752 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad8, i32 2, i32 2) ; (%rs4gc.s111.relocated749, %rs4gc.s111.relocated749)
  br label %eh.lpad.869.split-lp.split-lp.split-lp

eh.lpad.869.split-lp.split-lp.split-lp.split-lp10: ; preds = %shadow.root.barrier.done.873
  %lpad11 = landingpad token
          cleanup
  %rs4gc.s114.relocated758 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad11, i32 0, i32 0) ; (%.01060, %.01060)
  %rs4gc.s108.relocated759 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad11, i32 1, i32 1) ; (%.91043, %.91043)
  br label %eh.lpad.869.split-lp.split-lp.split-lp.split-lp

eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp12: ; preds = %eh.cont5264
  %lpad13 = landingpad token
          cleanup
  %rs4gc.s108.relocated765 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad13, i32 0, i32 0) ; (%rs4gc.s108.relocated763, %rs4gc.s108.relocated763)
  br label %eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp15: ; preds = %shadow.root.barrier.874
  %lpad16 = landingpad token
          cleanup
  %rs4gc.s108.relocated770 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad16, i32 0, i32 0) ; (%rs4gc.s108.relocated768, %rs4gc.s108.relocated768)
  %rs4gc.s115.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad16, i32 1, i32 1) ; (%rs4gc.s115, %rs4gc.s115)
  br label %eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %shadow.root.barrier.done.875
  %lpad.split-lp = landingpad token
          cleanup
  %rs4gc.s108.relocated775 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad.split-lp, i32 0, i32 0) ; (%.101044, %.101044)
  br label %eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp15
  %.191053 = phi ptr addrspace(1) [ %rs4gc.s108.relocated775, %eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s108.relocated770, %eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp15 ]
  br label %eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp12
  %.181052 = phi ptr addrspace(1) [ %.191053, %eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s108.relocated765, %eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp12 ]
  br label %eh.lpad.869.split-lp.split-lp.split-lp.split-lp

eh.lpad.869.split-lp.split-lp.split-lp.split-lp:  ; preds = %eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.869.split-lp.split-lp.split-lp.split-lp10
  %.171051 = phi ptr addrspace(1) [ %.181052, %eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s108.relocated759, %eh.lpad.869.split-lp.split-lp.split-lp.split-lp10 ]
  br label %eh.lpad.869.split-lp.split-lp.split-lp

eh.lpad.869.split-lp.split-lp.split-lp:           ; preds = %eh.lpad.869.split-lp.split-lp.split-lp.split-lp, %eh.lpad.869.split-lp.split-lp.split-lp7
  %.161050 = phi ptr addrspace(1) [ %.171051, %eh.lpad.869.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s108.relocated751, %eh.lpad.869.split-lp.split-lp.split-lp7 ]
  br label %eh.lpad.869.split-lp.split-lp

eh.lpad.869.split-lp.split-lp:                    ; preds = %eh.lpad.869.split-lp.split-lp.split-lp, %eh.lpad.869.split-lp.split-lp5
  %.151049 = phi ptr addrspace(1) [ %.161050, %eh.lpad.869.split-lp.split-lp.split-lp ], [ %rs4gc.s108.relocated744, %eh.lpad.869.split-lp.split-lp5 ]
  br label %eh.lpad.869.split-lp

eh.lpad.869.split-lp:                             ; preds = %eh.lpad.869.split-lp.split-lp, %eh.lpad.869.split-lp2
  %.141048 = phi ptr addrspace(1) [ %.151049, %eh.lpad.869.split-lp.split-lp ], [ %rs4gc.s108.relocated737, %eh.lpad.869.split-lp2 ]
  br label %eh.lpad.869

eh.lpad.869:                                      ; preds = %eh.lpad.869.split-lp, %eh.lpad.8691
  %.61040 = phi ptr addrspace(1) [ %.141048, %eh.lpad.869.split-lp ], [ %rs4gc.s108.relocated723, %eh.lpad.8691 ]
  br label %try.catch.867

shadow.root.barrier.870:                          ; preds = %eh.cont5249
  %statepoint_token739 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_write_barrier_root_nanbox, i32 1, i32 0, i64 %r5250, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s108.relocated727, ptr addrspace(1) %rs4gc.s111.relocated728, ptr addrspace(1) %rs4gc.s112) ]
          to label %eh.cont5253 unwind label %eh.lpad.869.split-lp2

eh.cont5253:                                      ; preds = %shadow.root.barrier.870
  %rs4gc.s108.relocated740 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token739, i32 0, i32 0) ; (%rs4gc.s108.relocated727, %rs4gc.s108.relocated727)
  %rs4gc.s111.relocated741 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token739, i32 1, i32 1) ; (%rs4gc.s111.relocated728, %rs4gc.s111.relocated728)
  %rs4gc.s112.relocated742 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token739, i32 2, i32 2) ; (%rs4gc.s112, %rs4gc.s112)
  br label %shadow.root.barrier.done.871

shadow.root.barrier.done.871:                     ; preds = %eh.cont5253, %eh.cont5249
  %.01059 = phi ptr addrspace(1) [ %rs4gc.s112.relocated742, %eh.cont5253 ], [ %rs4gc.s112, %eh.cont5249 ]
  %.01057 = phi ptr addrspace(1) [ %rs4gc.s111.relocated741, %eh.cont5253 ], [ %rs4gc.s111.relocated728, %eh.cont5249 ]
  %.71041 = phi ptr addrspace(1) [ %rs4gc.s108.relocated740, %eh.cont5253 ], [ %rs4gc.s108.relocated727, %eh.cont5249 ]
  %r5254 = load double, ptr @test_json_warm_unique_keys_ts_.str.31.handle, align 8
  %r5255.rs4i = ptrtoint ptr addrspace(1) %.01059 to i64
  %r5255 = call i64 asm "", "=r,0"(i64 %r5255.rs4i) #7
  %statepoint_token746 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r5255, double %r5254, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.71041, ptr addrspace(1) %.01057) ]
          to label %eh.cont5257 unwind label %eh.lpad.869.split-lp.split-lp5

eh.cont5257:                                      ; preds = %shadow.root.barrier.done.871
  %r5256747 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token746)
  %rs4gc.s108.relocated748 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token746, i32 0, i32 0) ; (%.71041, %.71041)
  %rs4gc.s111.relocated749 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token746, i32 1, i32 1) ; (%.01057, %.01057)
  %rs4gc.s114 = inttoptr i64 %r5256747 to ptr addrspace(1)
  %r5258.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s114 to i64
  %r5258 = call i64 asm "", "=r,0"(i64 %r5258.rs4i) #7
  %r5259 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5260 = icmp ne i32 %r5259, 0
  br i1 %r5260, label %shadow.root.barrier.872, label %shadow.root.barrier.done.873

shadow.root.barrier.872:                          ; preds = %eh.cont5257
  %statepoint_token753 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_write_barrier_root_nanbox, i32 1, i32 0, i64 %r5258, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s108.relocated748, ptr addrspace(1) %rs4gc.s114, ptr addrspace(1) %rs4gc.s111.relocated749) ]
          to label %eh.cont5261 unwind label %eh.lpad.869.split-lp.split-lp.split-lp7

eh.cont5261:                                      ; preds = %shadow.root.barrier.872
  %rs4gc.s108.relocated754 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token753, i32 0, i32 0) ; (%rs4gc.s108.relocated748, %rs4gc.s108.relocated748)
  %rs4gc.s114.relocated755 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token753, i32 1, i32 1) ; (%rs4gc.s114, %rs4gc.s114)
  %rs4gc.s111.relocated756 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token753, i32 2, i32 2) ; (%rs4gc.s111.relocated749, %rs4gc.s111.relocated749)
  br label %shadow.root.barrier.done.873

shadow.root.barrier.done.873:                     ; preds = %eh.cont5261, %eh.cont5257
  %.01060 = phi ptr addrspace(1) [ %rs4gc.s114.relocated755, %eh.cont5261 ], [ %rs4gc.s114, %eh.cont5257 ]
  %.11058 = phi ptr addrspace(1) [ %rs4gc.s111.relocated756, %eh.cont5261 ], [ %rs4gc.s111.relocated749, %eh.cont5257 ]
  %.91043 = phi ptr addrspace(1) [ %rs4gc.s108.relocated754, %eh.cont5261 ], [ %rs4gc.s108.relocated748, %eh.cont5257 ]
  %r5262.rs4i = ptrtoint ptr addrspace(1) %.11058 to i64
  %r5262.rs4o = call i64 asm "", "=r,0"(i64 %r5262.rs4i) #7
  %r5262 = bitcast i64 %r5262.rs4o to double
  %statepoint_token760 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r5262, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01060, ptr addrspace(1) %.91043) ]
          to label %eh.cont5264 unwind label %eh.lpad.869.split-lp.split-lp.split-lp.split-lp10

eh.cont5264:                                      ; preds = %shadow.root.barrier.done.873
  %r5263761 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token760)
  %rs4gc.s114.relocated762 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token760, i32 0, i32 0) ; (%.01060, %.01060)
  %rs4gc.s108.relocated763 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token760, i32 1, i32 1) ; (%.91043, %.91043)
  %r5265 = bitcast i64 %r5263761 to double
  %r5266.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s114.relocated762 to i64
  %r5266 = call i64 asm "", "=r,0"(i64 %r5266.rs4i) #7
  %statepoint_token766 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r5266, double %r5265, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s108.relocated763) ]
          to label %eh.cont5268 unwind label %eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp12

eh.cont5268:                                      ; preds = %eh.cont5264
  %r5267767 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token766)
  %rs4gc.s108.relocated768 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token766, i32 0, i32 0) ; (%rs4gc.s108.relocated763, %rs4gc.s108.relocated763)
  %rs4gc.s115 = inttoptr i64 %r5267767 to ptr addrspace(1)
  %r5269.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s115 to i64
  %r5269 = call i64 asm "", "=r,0"(i64 %r5269.rs4i) #7
  %r5270 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5271 = icmp ne i32 %r5270, 0
  br i1 %r5271, label %shadow.root.barrier.874, label %shadow.root.barrier.done.875

shadow.root.barrier.874:                          ; preds = %eh.cont5268
  %statepoint_token771 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_write_barrier_root_nanbox, i32 1, i32 0, i64 %r5269, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s108.relocated768, ptr addrspace(1) %rs4gc.s115) ]
          to label %eh.cont5272 unwind label %eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp15

eh.cont5272:                                      ; preds = %shadow.root.barrier.874
  %rs4gc.s108.relocated772 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token771, i32 0, i32 0) ; (%rs4gc.s108.relocated768, %rs4gc.s108.relocated768)
  %rs4gc.s115.relocated773 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token771, i32 1, i32 1) ; (%rs4gc.s115, %rs4gc.s115)
  br label %shadow.root.barrier.done.875

shadow.root.barrier.done.875:                     ; preds = %eh.cont5272, %eh.cont5268
  %.01061 = phi ptr addrspace(1) [ %rs4gc.s115.relocated773, %eh.cont5272 ], [ %rs4gc.s115, %eh.cont5268 ]
  %.101044 = phi ptr addrspace(1) [ %rs4gc.s108.relocated772, %eh.cont5272 ], [ %rs4gc.s108.relocated768, %eh.cont5268 ]
  %r5273.rs4i = ptrtoint ptr addrspace(1) %.01061 to i64
  %r5273 = call i64 asm "", "=r,0"(i64 %r5273.rs4i) #7
  %statepoint_token776 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r5273, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.101044) ]
          to label %eh.cont5274 unwind label %eh.lpad.869.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.cont5274:                                      ; preds = %shadow.root.barrier.done.875
  %rs4gc.s108.relocated777 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token776, i32 0, i32 0) ; (%.101044, %.101044)
  %statepoint_token778 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_try_end, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s108.relocated777) ]
  %rs4gc.s108.relocated779 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token778, i32 0, i32 0) ; (%rs4gc.s108.relocated777, %rs4gc.s108.relocated777)
  br label %try.finally.868

shadow.root.barrier.876:                          ; preds = %try.catch.867
  call void @js_write_barrier_root_nanbox(i64 %r5277) #7
  br label %shadow.root.barrier.done.877

shadow.root.barrier.done.877:                     ; preds = %shadow.root.barrier.876, %try.catch.867
  %statepoint_token780 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_eh_try_push, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s108.relocated735, ptr addrspace(1) %rs4gc.s113) ]
  %rs4gc.s108.relocated781 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token780, i32 0, i32 0) ; (%rs4gc.s108.relocated735, %rs4gc.s108.relocated735)
  %rs4gc.s113.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token780, i32 1, i32 1) ; (%rs4gc.s113, %rs4gc.s113)
  br label %try.body.878

try.body.878:                                     ; preds = %shadow.root.barrier.done.877
  %r5281.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s108.relocated781 to i64
  %r5281.rs4o = call i64 asm "", "=r,0"(i64 %r5281.rs4i) #7
  %r5281 = bitcast i64 %r5281.rs4o to double
  %r5282 = bitcast double %r5281 to i64
  %r5283 = and i64 %r5282, 281474976710655
  %r5284 = lshr i64 %r5282, 48
  %r5285 = and i64 %r5284, 65533
  %r5286 = icmp eq i64 %r5285, 32765
  br i1 %r5286, label %pget.recv_ok.883, label %pget.recv_other.887

try.catch.879:                                    ; preds = %eh.lpad.881
  %statepoint_token782 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_try_end, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11063) ]
  %rs4gc.s113.relocated783 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token782, i32 0, i32 0) ; (%.11063, %.11063)
  %statepoint_token784 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_get_exception, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s113.relocated783) ]
  %r5455785 = call double @llvm.experimental.gc.result.f64(token %statepoint_token784)
  %rs4gc.s113.relocated786 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token784, i32 0, i32 0) ; (%rs4gc.s113.relocated783, %rs4gc.s113.relocated783)
  %statepoint_token787 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_clear_exception, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s113.relocated786) ]
  %rs4gc.s113.relocated788 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token787, i32 0, i32 0) ; (%rs4gc.s113.relocated786, %rs4gc.s113.relocated786)
  %rs4gc.b116 = bitcast double %r5455785 to i64
  %rs4gc.s116 = inttoptr i64 %rs4gc.b116 to ptr addrspace(1)
  %r5457.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s116 to i64
  %r5457 = call i64 asm "", "=r,0"(i64 %r5457.rs4i) #7
  %r5458 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5459 = icmp ne i32 %r5458, 0
  br i1 %r5459, label %shadow.root.barrier.916, label %shadow.root.barrier.done.917

try.finally.880:                                  ; preds = %shadow.root.barrier.done.917, %if.merge.915
  %.01062 = phi ptr addrspace(1) [ %rs4gc.s113.relocated834, %if.merge.915 ], [ %rs4gc.s113.relocated788, %shadow.root.barrier.done.917 ]
  %r5460.rs4i = ptrtoint ptr addrspace(1) %.01062 to i64
  %r5460.rs4o = call i64 asm "", "=r,0"(i64 %r5460.rs4i) #7
  %r5460 = bitcast i64 %r5460.rs4o to double
  %statepoint_token789 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r5460, i32 0, i32 0)
  unreachable

eh.lpad.88117:                                    ; preds = %pget.recv_sso.882
  %lpad18 = landingpad token
          cleanup
  %rs4gc.s108.relocated791 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad18, i32 0, i32 0) ; (%rs4gc.s108.relocated781, %rs4gc.s108.relocated781)
  %rs4gc.s113.relocated792 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad18, i32 1, i32 1) ; (%rs4gc.s113.relocated, %rs4gc.s113.relocated)
  br label %eh.lpad.881

eh.lpad.881.split-lp20:                           ; preds = %pget.recv_class_ref.885
  %lpad21 = landingpad token
          cleanup
  %rs4gc.s108.relocated798 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad21, i32 0, i32 0) ; (%rs4gc.s108.relocated781, %rs4gc.s108.relocated781)
  %rs4gc.s113.relocated799 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad21, i32 1, i32 1) ; (%rs4gc.s113.relocated, %rs4gc.s113.relocated)
  br label %eh.lpad.881.split-lp

eh.lpad.881.split-lp.split-lp23:                  ; preds = %pic.miss.call.902
  %lpad24 = landingpad token
          cleanup
  %rs4gc.s108.relocated805 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad24, i32 0, i32 0) ; (%rs4gc.s108.relocated781, %rs4gc.s108.relocated781)
  %rs4gc.s113.relocated806 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad24, i32 1, i32 1) ; (%rs4gc.s113.relocated, %rs4gc.s113.relocated)
  br label %eh.lpad.881.split-lp.split-lp

eh.lpad.881.split-lp.split-lp.split-lp26:         ; preds = %pic.hit.overflow.906
  %lpad27 = landingpad token
          cleanup
  %rs4gc.s108.relocated812 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad27, i32 0, i32 0) ; (%rs4gc.s108.relocated781, %rs4gc.s108.relocated781)
  %rs4gc.s113.relocated813 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad27, i32 1, i32 1) ; (%rs4gc.s113.relocated, %rs4gc.s113.relocated)
  br label %eh.lpad.881.split-lp.split-lp.split-lp

eh.lpad.881.split-lp.split-lp.split-lp.split-lp29: ; preds = %pget.throw_nullish.911
  %lpad30 = landingpad token
          cleanup
  %rs4gc.s113.relocated819 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad30, i32 0, i32 0) ; (%rs4gc.s113.relocated, %rs4gc.s113.relocated)
  br label %eh.lpad.881.split-lp.split-lp.split-lp.split-lp

eh.lpad.881.split-lp.split-lp.split-lp.split-lp.split-lp32: ; preds = %pget.recv_undef_return.912
  %lpad33 = landingpad token
          cleanup
  %rs4gc.s108.relocated823 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad33, i32 0, i32 0) ; (%rs4gc.s108.relocated781, %rs4gc.s108.relocated781)
  %rs4gc.s113.relocated824 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad33, i32 1, i32 1) ; (%rs4gc.s113.relocated, %rs4gc.s113.relocated)
  br label %eh.lpad.881.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.881.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %if.then.913
  %lpad.split-lp34 = landingpad token
          cleanup
  %rs4gc.s113.relocated830 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %lpad.split-lp34, i32 0, i32 0) ; (%.21064, %.21064)
  br label %eh.lpad.881.split-lp.split-lp.split-lp.split-lp.split-lp

eh.lpad.881.split-lp.split-lp.split-lp.split-lp.split-lp: ; preds = %eh.lpad.881.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.881.split-lp.split-lp.split-lp.split-lp.split-lp32
  %.91071 = phi ptr addrspace(1) [ %rs4gc.s113.relocated830, %eh.lpad.881.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s113.relocated824, %eh.lpad.881.split-lp.split-lp.split-lp.split-lp.split-lp32 ]
  br label %eh.lpad.881.split-lp.split-lp.split-lp.split-lp

eh.lpad.881.split-lp.split-lp.split-lp.split-lp:  ; preds = %eh.lpad.881.split-lp.split-lp.split-lp.split-lp.split-lp, %eh.lpad.881.split-lp.split-lp.split-lp.split-lp29
  %.81070 = phi ptr addrspace(1) [ %.91071, %eh.lpad.881.split-lp.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s113.relocated819, %eh.lpad.881.split-lp.split-lp.split-lp.split-lp29 ]
  br label %eh.lpad.881.split-lp.split-lp.split-lp

eh.lpad.881.split-lp.split-lp.split-lp:           ; preds = %eh.lpad.881.split-lp.split-lp.split-lp.split-lp, %eh.lpad.881.split-lp.split-lp.split-lp26
  %.71069 = phi ptr addrspace(1) [ %.81070, %eh.lpad.881.split-lp.split-lp.split-lp.split-lp ], [ %rs4gc.s113.relocated813, %eh.lpad.881.split-lp.split-lp.split-lp26 ]
  br label %eh.lpad.881.split-lp.split-lp

eh.lpad.881.split-lp.split-lp:                    ; preds = %eh.lpad.881.split-lp.split-lp.split-lp, %eh.lpad.881.split-lp.split-lp23
  %.61068 = phi ptr addrspace(1) [ %.71069, %eh.lpad.881.split-lp.split-lp.split-lp ], [ %rs4gc.s113.relocated806, %eh.lpad.881.split-lp.split-lp23 ]
  br label %eh.lpad.881.split-lp

eh.lpad.881.split-lp:                             ; preds = %eh.lpad.881.split-lp.split-lp, %eh.lpad.881.split-lp20
  %.51067 = phi ptr addrspace(1) [ %.61068, %eh.lpad.881.split-lp.split-lp ], [ %rs4gc.s113.relocated799, %eh.lpad.881.split-lp20 ]
  br label %eh.lpad.881

eh.lpad.881:                                      ; preds = %eh.lpad.881.split-lp, %eh.lpad.88117
  %.11063 = phi ptr addrspace(1) [ %.51067, %eh.lpad.881.split-lp ], [ %rs4gc.s113.relocated792, %eh.lpad.88117 ]
  br label %try.catch.879

pget.recv_sso.882:                                ; preds = %pget.recv_other.887
  %r5429 = load double, ptr @test_json_warm_unique_keys_ts_.str.32.handle, align 8
  %r5430 = bitcast double %r5429 to i64
  %r5431 = and i64 %r5430, 281474976710655
  %statepoint_token793 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r5282, i64 %r5431, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s108.relocated781, ptr addrspace(1) %rs4gc.s113.relocated) ]
          to label %eh.cont5433 unwind label %eh.lpad.88117

eh.cont5433:                                      ; preds = %pget.recv_sso.882
  %r5432794 = call double @llvm.experimental.gc.result.f64(token %statepoint_token793)
  %rs4gc.s108.relocated795 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token793, i32 0, i32 0) ; (%rs4gc.s108.relocated781, %rs4gc.s108.relocated781)
  %rs4gc.s113.relocated796 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token793, i32 1, i32 1) ; (%rs4gc.s113.relocated, %rs4gc.s113.relocated)
  br label %pget.recv_merge.886

pget.recv_ok.883:                                 ; preds = %try.body.878
  %r5294 = icmp ugt i64 %r5283, 1048575
  br i1 %r5294, label %pic.recv_hdr.904, label %pic.miss.cold.901

pget.recv_bad.884:                                ; preds = %pget.check_class_ref.888
  %r5419 = icmp eq i64 %r5282, 9222246136947933185
  %r5420 = icmp eq i64 %r5282, 9222246136947933186
  %r5421 = or i1 %r5419, %r5420
  br i1 %r5421, label %pget.throw_nullish.911, label %pget.recv_undef_return.912

pget.recv_class_ref.885:                          ; preds = %pget.check_class_ref.888
  %r5289 = load double, ptr @test_json_warm_unique_keys_ts_.str.32.handle, align 8
  %r5290 = bitcast double %r5289 to i64
  %r5291 = and i64 %r5290, 281474976710655
  %statepoint_token800 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 547434508618563603, i64 %r5282, i64 %r5291, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s108.relocated781, ptr addrspace(1) %rs4gc.s113.relocated) ]
          to label %eh.cont5293 unwind label %eh.lpad.881.split-lp20

eh.cont5293:                                      ; preds = %pget.recv_class_ref.885
  %r5292801 = call double @llvm.experimental.gc.result.f64(token %statepoint_token800)
  %rs4gc.s108.relocated802 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token800, i32 0, i32 0) ; (%rs4gc.s108.relocated781, %rs4gc.s108.relocated781)
  %rs4gc.s113.relocated803 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token800, i32 1, i32 1) ; (%rs4gc.s113.relocated, %rs4gc.s113.relocated)
  br label %pget.recv_merge.886

pget.recv_merge.886:                              ; preds = %eh.cont5428, %pic.merge.903, %eh.cont5293, %eh.cont5433
  %.21064 = phi ptr addrspace(1) [ %.31065, %pic.merge.903 ], [ %rs4gc.s113.relocated796, %eh.cont5433 ], [ %rs4gc.s113.relocated803, %eh.cont5293 ], [ %rs4gc.s113.relocated828, %eh.cont5428 ]
  %.111045 = phi ptr addrspace(1) [ %.121046, %pic.merge.903 ], [ %rs4gc.s108.relocated795, %eh.cont5433 ], [ %rs4gc.s108.relocated802, %eh.cont5293 ], [ %rs4gc.s108.relocated827, %eh.cont5428 ]
  %r5434 = phi double [ %r5418, %pic.merge.903 ], [ %r5427826, %eh.cont5428 ], [ %r5432794, %eh.cont5433 ], [ %r5292801, %eh.cont5293 ]
  %r5435 = bitcast double %r5434 to i64
  %r5437 = icmp eq i64 %r5435, 9222246136947933186
  %r5438 = icmp eq i64 %r5435, 9222246136947933186
  %r5439 = icmp eq i64 %r5435, 9222246136947933185
  %r5442 = or i1 %r5438, %r5439
  %r5445 = or i1 %r5437, %r5442
  %r5446 = xor i1 %r5445, true
  %r5447 = select i1 %r5446, i64 9222246136947933188, i64 9222246136947933187
  %r5448 = bitcast i64 %r5447 to double
  %r5449 = icmp eq i64 %r5447, 9222246136947933188
  br i1 %r5449, label %if.then.913, label %if.else.914

pget.recv_other.887:                              ; preds = %try.body.878
  %r5287 = icmp eq i64 %r5284, 32761
  br i1 %r5287, label %pget.recv_sso.882, label %pget.check_class_ref.888

pget.check_class_ref.888:                         ; preds = %pget.recv_other.887
  %r5288 = icmp eq i64 %r5284, 32766
  br i1 %r5288, label %pget.recv_class_ref.885, label %pget.recv_bad.884

pic.hit.889:                                      ; preds = %pic.token.905
  %r5319 = getelementptr i64, ptr %r5304, i64 1
  %r5320 = load i64, ptr %r5319, align 8
  %r5321 = and i64 %r5320, 1073741824
  %r5322 = icmp ne i64 %r5321, 0
  br i1 %r5322, label %pic.hit.overflow.906, label %pic.hit.inline.907

pic.hit.live.890:                                 ; preds = %pic.hit.inline.907
  br label %pic.merge.903

pic.prefix.guard.891:                             ; preds = %pic.token.905
  %r5336 = getelementptr i64, ptr %r5304, i64 2
  %r5337 = load i64, ptr %r5336, align 8
  %r5338 = icmp ne i64 %r5337, 0
  br i1 %r5338, label %pic.prefix.meta.892, label %pic.miss.900

pic.prefix.meta.892:                              ; preds = %pic.prefix.guard.891
  %r5339 = add nuw nsw i64 %r5283, 8
  %r5340 = inttoptr i64 %r5339 to ptr
  %r5341 = load i64, ptr %r5340, align 8
  %r5342 = icmp ne i64 %r5341, 0
  br i1 %r5342, label %pic.prefix.token.893, label %pic.miss.900

pic.prefix.token.893:                             ; preds = %pic.prefix.meta.892
  %r5343 = inttoptr i64 %r5341 to ptr
  %r5344 = getelementptr i64, ptr %r5343, i64 6
  %r5345 = load i64, ptr %r5344, align 8
  %r5346 = icmp eq i64 %r5345, %r5337
  br i1 %r5346, label %pic.prefix.hit.894, label %pic.miss.900

pic.prefix.hit.894:                               ; preds = %pic.prefix.token.893
  %r5347 = getelementptr i64, ptr %r5304, i64 1
  %r5348 = load i64, ptr %r5347, align 8
  %r5349 = shl i64 %r5348, 3
  %r5350 = add nuw nsw i64 %r5283, 16
  %r5351 = add i64 %r5350, %r5349
  %r5352 = inttoptr i64 %r5351 to ptr
  %r5353 = load double, ptr %r5352, align 8
  br label %pic.merge.903

pic.desc.classify.895:                            ; preds = %pic.recv_hdr.904
  %r5308 = and i1 %r5298, %r5305
  br i1 %r5308, label %pic.desc.prefix.guard.896, label %pic.miss.cold.901

pic.desc.prefix.guard.896:                        ; preds = %pic.desc.classify.895
  %r5354 = getelementptr i64, ptr %r5304, i64 2
  %r5355 = load i64, ptr %r5354, align 8
  %r5356 = icmp ne i64 %r5355, 0
  br i1 %r5356, label %pic.desc.prefix.meta.897, label %pic.miss.cold.901

pic.desc.prefix.meta.897:                         ; preds = %pic.desc.prefix.guard.896
  %r5357 = add nuw nsw i64 %r5283, 8
  %r5358 = inttoptr i64 %r5357 to ptr
  %r5359 = load i64, ptr %r5358, align 8
  %r5360 = icmp ne i64 %r5359, 0
  br i1 %r5360, label %pic.desc.prefix.token.898, label %pic.miss.cold.901

pic.desc.prefix.token.898:                        ; preds = %pic.desc.prefix.meta.897
  %r5361 = inttoptr i64 %r5359 to ptr
  %r5362 = getelementptr i64, ptr %r5361, i64 6
  %r5363 = load i64, ptr %r5362, align 8
  %r5364 = icmp eq i64 %r5363, %r5355
  br i1 %r5364, label %pic.desc.prefix.hit.899, label %pic.miss.cold.901

pic.desc.prefix.hit.899:                          ; preds = %pic.desc.prefix.token.898
  %r5365 = getelementptr i64, ptr %r5304, i64 1
  %r5366 = load i64, ptr %r5365, align 8
  %r5367 = shl i64 %r5366, 3
  %r5368 = add nuw nsw i64 %r5283, 16
  %r5369 = add i64 %r5368, %r5367
  %r5370 = inttoptr i64 %r5369 to ptr
  %r5371 = load double, ptr %r5370, align 8
  br label %pic.merge.903

pic.miss.900:                                     ; preds = %pic.hit.inline.907, %pic.prefix.token.893, %pic.prefix.meta.892, %pic.prefix.guard.891
  %r5372 = getelementptr i64, ptr %r5304, i64 3
  %r5373 = load i64, ptr %r5372, align 8
  %r5374 = icmp sgt i64 %r5373, 0
  br i1 %r5374, label %pic.ways.908, label %pic.miss.call.902

pic.miss.cold.901:                                ; preds = %pic.desc.prefix.token.898, %pic.desc.prefix.meta.897, %pic.desc.prefix.guard.896, %pic.desc.classify.895, %pget.recv_ok.883
  br label %pic.miss.call.902

pic.miss.call.902:                                ; preds = %pic.way.load.909, %pic.ways.908, %pic.miss.cold.901, %pic.miss.900
  %r5413 = load double, ptr @test_json_warm_unique_keys_ts_.str.32.handle, align 8
  %r5414 = bitcast double %r5413 to i64
  %r5415 = and i64 %r5414, 281474976710655
  %statepoint_token807 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r5283, i64 %r5415, ptr @perry_ic_test_json_warm_unique_keys_ts__20, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s108.relocated781, ptr addrspace(1) %rs4gc.s113.relocated) ]
          to label %eh.cont5417 unwind label %eh.lpad.881.split-lp.split-lp23

eh.cont5417:                                      ; preds = %pic.miss.call.902
  %r5416808 = call double @llvm.experimental.gc.result.f64(token %statepoint_token807)
  %rs4gc.s108.relocated809 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token807, i32 0, i32 0) ; (%rs4gc.s108.relocated781, %rs4gc.s108.relocated781)
  %rs4gc.s113.relocated810 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token807, i32 1, i32 1) ; (%rs4gc.s113.relocated, %rs4gc.s113.relocated)
  br label %pic.merge.903

pic.merge.903:                                    ; preds = %pic.way.live.910, %eh.cont5328, %eh.cont5417, %pic.desc.prefix.hit.899, %pic.prefix.hit.894, %pic.hit.live.890
  %.31065 = phi ptr addrspace(1) [ %rs4gc.s113.relocated817, %eh.cont5328 ], [ %rs4gc.s113.relocated810, %eh.cont5417 ], [ %rs4gc.s113.relocated, %pic.way.live.910 ], [ %rs4gc.s113.relocated, %pic.hit.live.890 ], [ %rs4gc.s113.relocated, %pic.prefix.hit.894 ], [ %rs4gc.s113.relocated, %pic.desc.prefix.hit.899 ]
  %.121046 = phi ptr addrspace(1) [ %rs4gc.s108.relocated816, %eh.cont5328 ], [ %rs4gc.s108.relocated809, %eh.cont5417 ], [ %rs4gc.s108.relocated781, %pic.way.live.910 ], [ %rs4gc.s108.relocated781, %pic.hit.live.890 ], [ %rs4gc.s108.relocated781, %pic.prefix.hit.894 ], [ %rs4gc.s108.relocated781, %pic.desc.prefix.hit.899 ]
  %r5418 = phi double [ %r5333, %pic.hit.live.890 ], [ %r5327815, %eh.cont5328 ], [ %r5353, %pic.prefix.hit.894 ], [ %r5371, %pic.desc.prefix.hit.899 ], [ %r5410, %pic.way.live.910 ], [ %r5416808, %eh.cont5417 ]
  br label %pget.recv_merge.886

pic.recv_hdr.904:                                 ; preds = %pget.recv_ok.883
  %r5295 = sub nuw nsw i64 %r5283, 8
  %r5296 = inttoptr i64 %r5295 to ptr
  %r5297 = load i8, ptr %r5296, align 1
  %r5298 = icmp eq i8 %r5297, 2
  %r5299 = sub nuw nsw i64 %r5283, 6
  %r5300 = inttoptr i64 %r5299 to ptr
  %r5301 = load i16, ptr %r5300, align 2
  %r5302 = and i16 %r5301, 2048
  %r5303 = icmp eq i16 %r5302, 0
  %r5304 = load ptr, ptr @perry_ic_test_json_warm_unique_keys_ts__20, align 8
  %r5305 = icmp ne ptr %r5304, null
  %r5306 = and i1 %r5298, %r5303
  %r5307 = and i1 %r5306, %r5305
  br i1 %r5307, label %pic.token.905, label %pic.desc.classify.895

pic.token.905:                                    ; preds = %pic.recv_hdr.904
  %r5309 = add nuw nsw i64 %r5283, 4
  %r5310 = inttoptr i64 %r5309 to ptr
  %r5311 = load i32, ptr %r5310, align 4
  %r5312 = zext i32 %r5311 to i64
  %r5313 = or i64 %r5312, 4611686018427387904
  %r5314 = icmp ne i32 %r5311, 0
  %r5315 = getelementptr i64, ptr %r5304, i64 0
  %r5316 = load i64, ptr %r5315, align 8
  %r5317 = icmp eq i64 %r5313, %r5316
  %r5318 = and i1 %r5317, %r5314
  br i1 %r5318, label %pic.hit.889, label %pic.prefix.guard.891

pic.hit.overflow.906:                             ; preds = %pic.hit.889
  %r5323 = load double, ptr @test_json_warm_unique_keys_ts_.str.32.handle, align 8
  %r5324 = bitcast double %r5323 to i64
  %r5325 = and i64 %r5324, 281474976710655
  %r5326 = trunc i64 %r5320 to i32
  %statepoint_token814 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r5283, i64 %r5325, i32 %r5326, ptr @perry_ic_test_json_warm_unique_keys_ts__20, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s108.relocated781, ptr addrspace(1) %rs4gc.s113.relocated) ]
          to label %eh.cont5328 unwind label %eh.lpad.881.split-lp.split-lp.split-lp26

eh.cont5328:                                      ; preds = %pic.hit.overflow.906
  %r5327815 = call double @llvm.experimental.gc.result.f64(token %statepoint_token814)
  %rs4gc.s108.relocated816 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token814, i32 0, i32 0) ; (%rs4gc.s108.relocated781, %rs4gc.s108.relocated781)
  %rs4gc.s113.relocated817 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token814, i32 1, i32 1) ; (%rs4gc.s113.relocated, %rs4gc.s113.relocated)
  br label %pic.merge.903

pic.hit.inline.907:                               ; preds = %pic.hit.889
  %r5329 = shl i64 %r5320, 3
  %r5330 = add nuw nsw i64 %r5283, 16
  %r5331 = add i64 %r5330, %r5329
  %r5332 = inttoptr i64 %r5331 to ptr
  %r5333 = load double, ptr %r5332, align 8
  %r5334 = bitcast double %r5333 to i64
  %r5335 = icmp eq i64 %r5334, 9222246136947933200
  br i1 %r5335, label %pic.miss.900, label %pic.hit.live.890

pic.ways.908:                                     ; preds = %pic.miss.900
  %r5375 = getelementptr i64, ptr %r5304, i64 4
  %r5376 = load i64, ptr %r5375, align 8
  %r5377 = icmp eq i64 %r5376, %r5313
  %r5378 = getelementptr i64, ptr %r5304, i64 5
  %r5379 = load i64, ptr %r5378, align 8
  %r5380 = select i1 %r5377, i64 %r5379, i64 0
  %r5381 = getelementptr i64, ptr %r5304, i64 6
  %r5382 = load i64, ptr %r5381, align 8
  %r5383 = icmp eq i64 %r5382, %r5313
  %r5384 = getelementptr i64, ptr %r5304, i64 7
  %r5385 = load i64, ptr %r5384, align 8
  %r5386 = select i1 %r5383, i64 %r5385, i64 0
  %r5387 = getelementptr i64, ptr %r5304, i64 8
  %r5388 = load i64, ptr %r5387, align 8
  %r5389 = icmp eq i64 %r5388, %r5313
  %r5390 = getelementptr i64, ptr %r5304, i64 9
  %r5391 = load i64, ptr %r5390, align 8
  %r5392 = select i1 %r5389, i64 %r5391, i64 0
  %r5393 = getelementptr i64, ptr %r5304, i64 10
  %r5394 = load i64, ptr %r5393, align 8
  %r5395 = icmp eq i64 %r5394, %r5313
  %r5396 = getelementptr i64, ptr %r5304, i64 11
  %r5397 = load i64, ptr %r5396, align 8
  %r5398 = select i1 %r5395, i64 %r5397, i64 0
  %r5399 = or i1 %r5377, %r5383
  %r5400 = select i1 %r5377, i64 %r5380, i64 %r5386
  %r5401 = or i1 %r5389, %r5395
  %r5402 = select i1 %r5389, i64 %r5392, i64 %r5398
  %r5403 = or i1 %r5399, %r5401
  %r5404 = select i1 %r5399, i64 %r5400, i64 %r5402
  %r5405 = and i1 %r5314, %r5403
  br i1 %r5405, label %pic.way.load.909, label %pic.miss.call.902

pic.way.load.909:                                 ; preds = %pic.ways.908
  %r5406 = shl i64 %r5404, 3
  %r5407 = add nuw nsw i64 %r5283, 16
  %r5408 = add i64 %r5407, %r5406
  %r5409 = inttoptr i64 %r5408 to ptr
  %r5410 = load double, ptr %r5409, align 8
  %r5411 = bitcast double %r5410 to i64
  %r5412 = icmp eq i64 %r5411, 9222246136947933200
  br i1 %r5412, label %pic.miss.call.902, label %pic.way.live.910

pic.way.live.910:                                 ; preds = %pic.way.load.909
  br label %pic.merge.903

pget.throw_nullish.911:                           ; preds = %pget.recv_bad.884
  %r5422 = zext i1 %r5420 to i32
  %statepoint_token820 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r5422, ptr @test_json_warm_unique_keys_ts_.str.32.bytes, i64 6, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s113.relocated) ]
          to label %eh.cont5423 unwind label %eh.lpad.881.split-lp.split-lp.split-lp.split-lp29

eh.cont5423:                                      ; preds = %pget.throw_nullish.911
  %rs4gc.s113.relocated821 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token820, i32 0, i32 0) ; (%rs4gc.s113.relocated, %rs4gc.s113.relocated)
  unreachable

pget.recv_undef_return.912:                       ; preds = %pget.recv_bad.884
  %r5424 = load double, ptr @test_json_warm_unique_keys_ts_.str.32.handle, align 8
  %r5425 = bitcast double %r5424 to i64
  %r5426 = and i64 %r5425, 281474976710655
  %statepoint_token825 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r5282, i64 %r5426, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s108.relocated781, ptr addrspace(1) %rs4gc.s113.relocated) ]
          to label %eh.cont5428 unwind label %eh.lpad.881.split-lp.split-lp.split-lp.split-lp.split-lp32

eh.cont5428:                                      ; preds = %pget.recv_undef_return.912
  %r5427826 = call double @llvm.experimental.gc.result.f64(token %statepoint_token825)
  %rs4gc.s108.relocated827 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token825, i32 0, i32 0) ; (%rs4gc.s108.relocated781, %rs4gc.s108.relocated781)
  %rs4gc.s113.relocated828 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token825, i32 1, i32 1) ; (%rs4gc.s113.relocated, %rs4gc.s113.relocated)
  br label %pget.recv_merge.886

if.then.913:                                      ; preds = %pget.recv_merge.886
  %r5450.rs4i = ptrtoint ptr addrspace(1) %.111045 to i64
  %r5450.rs4o = call i64 asm "", "=r,0"(i64 %r5450.rs4i) #7
  %r5450 = bitcast i64 %r5450.rs4o to double
  %r5452 = or i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.32.dispatch to i64), 9221120237041090560
  %statepoint_token831 = invoke token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, i64, ptr, i64)) @js_typed_feedback_native_call_method_by_id, i32 5, i32 0, i64 547434508618563605, double %r5450, i64 %r5452, ptr null, i64 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.21064) ]
          to label %eh.cont5454 unwind label %eh.lpad.881.split-lp.split-lp.split-lp.split-lp.split-lp.split-lp

eh.cont5454:                                      ; preds = %if.then.913
  %rs4gc.s113.relocated832 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token831, i32 0, i32 0) ; (%.21064, %.21064)
  br label %if.merge.915

if.else.914:                                      ; preds = %pget.recv_merge.886
  br label %if.merge.915

if.merge.915:                                     ; preds = %if.else.914, %eh.cont5454
  %.41066 = phi ptr addrspace(1) [ %rs4gc.s113.relocated832, %eh.cont5454 ], [ %.21064, %if.else.914 ]
  %statepoint_token833 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_try_end, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.41066) ]
  %rs4gc.s113.relocated834 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token833, i32 0, i32 0) ; (%.41066, %.41066)
  br label %try.finally.880

shadow.root.barrier.916:                          ; preds = %try.catch.879
  call void @js_write_barrier_root_nanbox(i64 %r5457) #7
  br label %shadow.root.barrier.done.917

shadow.root.barrier.done.917:                     ; preds = %shadow.root.barrier.916, %try.catch.879
  br label %try.finally.880

gcpoll.918:                                       ; preds = %try.finally.868
  %statepoint_token835 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s108.relocated779) ]
  %rs4gc.s108.relocated836 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token835, i32 0, i32 0) ; (%rs4gc.s108.relocated779, %rs4gc.s108.relocated779)
  br label %gcpoll.done.919

gcpoll.done.919:                                  ; preds = %gcpoll.918, %try.finally.868
  %.81042 = phi ptr addrspace(1) [ %rs4gc.s108.relocated836, %gcpoll.918 ], [ %rs4gc.s108.relocated779, %try.finally.868 ]
  br label %for.update.793

shadow.root.barrier.920:                          ; preds = %for.update.793
  call void @js_write_barrier_root_nanbox(i64 %r5465) #7
  br label %shadow.root.barrier.done.921

shadow.root.barrier.done.921:                     ; preds = %shadow.root.barrier.920, %for.update.793
  %r5468 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r5469 = icmp ne i32 %r5468, 0
  br i1 %r5469, label %gcpoll.922, label %gcpoll.done.923

gcpoll.922:                                       ; preds = %shadow.root.barrier.done.921
  %statepoint_token837 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s110, ptr addrspace(1) %rs4gc.s108.relocated680) ]
  %rs4gc.s110.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token837, i32 0, i32 0) ; (%rs4gc.s110, %rs4gc.s110)
  %rs4gc.s108.relocated838 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token837, i32 1, i32 1) ; (%rs4gc.s108.relocated680, %rs4gc.s108.relocated680)
  br label %gcpoll.done.923

gcpoll.done.923:                                  ; preds = %gcpoll.922, %shadow.root.barrier.done.921
  %.01072 = phi ptr addrspace(1) [ %rs4gc.s110.relocated, %gcpoll.922 ], [ %rs4gc.s110, %shadow.root.barrier.done.921 ]
  %.131047 = phi ptr addrspace(1) [ %rs4gc.s108.relocated838, %gcpoll.922 ], [ %rs4gc.s108.relocated680, %shadow.root.barrier.done.921 ]
  br label %for.cond.791

str_addref.call.924:                              ; preds = %if.else.785
  call void @js_string_addref_if_heap_string(double %r5471) #7
  br label %str_addref.done.925

str_addref.done.925:                              ; preds = %str_addref.call.924, %if.else.785
  %r5733.rs4i = ptrtoint ptr addrspace(1) %r3514.0.relocated378 to i64
  %r5733.rs4o = call i64 asm "", "=r,0"(i64 %r5733.rs4i) #7
  %r5733 = bitcast i64 %r5733.rs4o to double
  %rs4gc.b117 = bitcast double %r5733 to i64
  %rs4gc.s117 = inttoptr i64 %rs4gc.b117 to ptr addrspace(1)
  %r5475.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s117 to i64
  %r5475 = call i64 asm "", "=r,0"(i64 %r5475.rs4i) #7
  %r5476 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5477 = icmp ne i32 %r5476, 0
  br i1 %r5477, label %shadow.root.barrier.926, label %shadow.root.barrier.done.927

shadow.root.barrier.926:                          ; preds = %str_addref.done.925
  call void @js_write_barrier_root_nanbox(i64 %r5475) #7
  br label %shadow.root.barrier.done.927

shadow.root.barrier.done.927:                     ; preds = %shadow.root.barrier.926, %str_addref.done.925
  br label %for.cond.928

for.cond.928:                                     ; preds = %for.update.930, %shadow.root.barrier.done.927
  %.01073 = phi ptr addrspace(1) [ %rs4gc.s117, %shadow.root.barrier.done.927 ], [ %.51078, %for.update.930 ]
  %r5478.0 = phi i32 [ 0, %shadow.root.barrier.done.927 ], [ %r5694, %for.update.930 ]
  %r5480 = sitofp i32 %r5478.0 to double
  %r5481.rs4i = ptrtoint ptr addrspace(1) %.01073 to i64
  %r5481.rs4o = call i64 asm "", "=r,0"(i64 %r5481.rs4i) #7
  %r5481 = bitcast i64 %r5481.rs4o to double
  %r5482 = bitcast double %r5481 to i64
  %r5483 = and i64 %r5482, 281474976710655
  %r5484 = lshr i64 %r5482, 48
  %r5485 = and i64 %r5484, 65533
  %r5486 = icmp eq i64 %r5485, 32765
  %r5487 = icmp ugt i64 %r5483, 1048575
  %r5488 = and i1 %r5486, %r5487
  br i1 %r5488, label %plen.check_gc.932, label %plen.slow.934

for.body.929:                                     ; preds = %gcpoll.done.954
  %r5595.rs4i = ptrtoint ptr addrspace(1) %.31076 to i64
  %r5595.rs4o = call i64 asm "", "=r,0"(i64 %r5595.rs4i) #7
  %r5595 = bitcast i64 %r5595.rs4o to double
  %r5597 = bitcast double %r5595 to i64
  %r5598 = and i64 %r5597, 281474976710655
  %r5599 = lshr i64 %r5597, 48
  %r5600 = icmp eq i64 %r5599, 32765
  %r5601 = icmp ugt i64 %r5598, 1048575
  %r5602 = and i1 %r5600, %r5601
  br i1 %r5602, label %arr.guard.deref.959, label %arr.fallback.956

for.update.930:                                   ; preds = %gcpoll.done.971
  %r5694 = add i32 %r5478.0, 1
  %r5695 = sitofp i32 %r5478.0 to double
  %r5696 = sitofp i32 %r5694 to double
  br label %for.cond.928

for.exit.931:                                     ; preds = %gcpoll.done.954
  br label %if.merge.786

plen.check_gc.932:                                ; preds = %for.cond.928
  %r5489 = sub nuw nsw i64 %r5483, 8
  %r5490 = inttoptr i64 %r5489 to ptr
  %r5491 = load i8, ptr %r5490, align 1
  %r5492 = icmp eq i8 %r5491, 1
  %r5493 = icmp eq i8 %r5491, 3
  %r5494 = or i1 %r5492, %r5493
  %r5495 = sub nuw nsw i64 %r5483, 7
  %r5496 = inttoptr i64 %r5495 to ptr
  %r5497 = load i8, ptr %r5496, align 1
  %r5498 = and i8 %r5497, -128
  %r5499 = icmp eq i8 %r5498, 0
  %r5500 = and i1 %r5494, %r5499
  br i1 %r5500, label %plen.fast.933, label %plen.slow.934

plen.fast.933:                                    ; preds = %plen.check_gc.932
  %r5502 = inttoptr i64 %r5483 to ptr
  %r5503 = select i1 false, ptr @perry_null_guard_zero_test_json_warm_unique_keys_ts, ptr %r5502
  %r5504 = load i32, ptr %r5503, align 4
  %r5505 = uitofp i32 %r5504 to double
  br label %plen.merge.935

plen.slow.934:                                    ; preds = %plen.check_gc.932, %for.cond.928
  %r5506 = lshr i64 %r5482, 48
  %r5507 = icmp eq i64 %r5506, 32765
  %r5508 = icmp uge i64 %r5483, 2199023255552
  %r5509 = icmp ult i64 %r5483, 140737488355328
  %r5510 = and i1 %r5507, %r5508
  %r5511 = and i1 %r5510, %r5509
  %r5512 = load ptr, ptr @perry_ic_test_json_warm_unique_keys_ts__22, align 8
  br i1 %r5511, label %plen.ic.header.936, label %plen.ic.miss.948

plen.merge.935:                                   ; preds = %plen.ic.merge.949, %plen.fast.933
  %.11074 = phi ptr addrspace(1) [ %.01073, %plen.fast.933 ], [ %.21075, %plen.ic.merge.949 ]
  %r5587 = phi double [ %r5505, %plen.fast.933 ], [ %r5586, %plen.ic.merge.949 ]
  %r5588 = fcmp olt double %r5480, %r5587
  %r5589 = select i1 %r5588, i64 9222246136947933188, i64 9222246136947933187
  %r5590 = bitcast i64 %r5589 to double
  %r5592 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r5593 = icmp ne i32 %r5592, 0
  br i1 %r5593, label %gcpoll.953, label %gcpoll.done.954

plen.ic.header.936:                               ; preds = %plen.slow.934
  %r5514 = sub nuw nsw i64 %r5483, 8
  %r5515 = inttoptr i64 %r5514 to ptr
  %r5516 = load i8, ptr %r5515, align 1
  %r5517 = icmp eq i8 %r5516, 2
  %r5518 = sub nuw nsw i64 %r5483, 7
  %r5519 = inttoptr i64 %r5518 to ptr
  %r5520 = load i8, ptr %r5519, align 1
  %r5521 = and i8 %r5520, -128
  %r5522 = icmp eq i8 %r5521, 0
  %r5523 = and i1 %r5517, %r5522
  br i1 %r5523, label %plen.elem.meta.950, label %plen.ic.miss.948

plen.ic.shape.937:                                ; preds = %plen.elem.store.951, %plen.elem.meta.950
  %r5513 = icmp ne ptr %r5512, null
  br i1 %r5513, label %plen.ic.shape.probe.938, label %plen.ic.miss.948

plen.ic.shape.probe.938:                          ; preds = %plen.ic.shape.937
  %r5535 = inttoptr i64 %r5483 to ptr
  %r5536 = load i32, ptr %r5535, align 4
  %r5537 = add nuw nsw i64 %r5483, 4
  %r5538 = inttoptr i64 %r5537 to ptr
  %r5539 = load i32, ptr %r5538, align 4
  %r5540 = zext i32 %r5536 to i64
  %r5541 = zext i32 %r5539 to i64
  %r5542 = shl nuw i64 %r5540, 32
  %r5543 = or i64 %r5542, %r5541
  %r5544 = getelementptr i64, ptr %r5512, i64 0
  %r5545 = load i64, ptr %r5544, align 8
  %r5546 = icmp ne i64 %r5545, 0
  br i1 %r5546, label %plen.ic.identity.939, label %plen.ic.miss.948

plen.ic.identity.939:                             ; preds = %plen.ic.shape.probe.938
  %r5547 = and i64 %r5545, -9223372036854775808
  %1 = icmp slt i64 %r5545, 0
  br i1 %1, label %plen.ic.family_meta.941, label %plen.ic.exact.940

plen.ic.exact.940:                                ; preds = %plen.ic.identity.939
  %r5549 = icmp eq i64 %r5543, %r5545
  br i1 %r5549, label %plen.ic.slot.943, label %plen.ic.miss.948

plen.ic.family_meta.941:                          ; preds = %plen.ic.identity.939
  %r5550 = add nuw nsw i64 %r5483, 8
  %r5551 = inttoptr i64 %r5550 to ptr
  %r5552 = load i64, ptr %r5551, align 8
  %r5553 = icmp ne i64 %r5552, 0
  br i1 %r5553, label %plen.ic.family_token.942, label %plen.ic.miss.948

plen.ic.family_token.942:                         ; preds = %plen.ic.family_meta.941
  %r5554 = inttoptr i64 %r5552 to ptr
  %r5555 = getelementptr i64, ptr %r5554, i64 6
  %r5556 = load i64, ptr %r5555, align 8
  %r5557 = icmp eq i64 %r5556, %r5545
  br i1 %r5557, label %plen.ic.slot.943, label %plen.ic.miss.948

plen.ic.slot.943:                                 ; preds = %plen.ic.family_token.942, %plen.ic.exact.940
  %r5558 = getelementptr i64, ptr %r5512, i64 1
  %r5559 = load i64, ptr %r5558, align 8
  %r5560 = getelementptr i64, ptr %r5512, i64 2
  %r5561 = load i64, ptr %r5560, align 8
  %r5562 = icmp ult i64 %r5559, %r5561
  br i1 %r5562, label %plen.ic.inline.944, label %plen.ic.spill_meta.945

plen.ic.inline.944:                               ; preds = %plen.ic.slot.943
  %r5563 = shl i64 %r5559, 3
  %r5564 = add i64 %r5563, 16
  %r5565 = add i64 %r5483, %r5564
  %r5566 = inttoptr i64 %r5565 to ptr
  %r5567 = load double, ptr %r5566, align 8
  br label %plen.ic.merge.949

plen.ic.spill_meta.945:                           ; preds = %plen.ic.slot.943
  %r5568 = add nuw nsw i64 %r5483, 8
  %r5569 = inttoptr i64 %r5568 to ptr
  %r5570 = load i64, ptr %r5569, align 8
  %r5571 = icmp ne i64 %r5570, 0
  br i1 %r5571, label %plen.ic.spill_ptr.946, label %plen.ic.miss.948

plen.ic.spill_ptr.946:                            ; preds = %plen.ic.spill_meta.945
  %r5572 = inttoptr i64 %r5570 to ptr
  %r5573 = getelementptr i64, ptr %r5572, i64 4
  %r5574 = load i64, ptr %r5573, align 8
  %r5575 = icmp ne i64 %r5574, 0
  %r5576 = select i1 %r5575, i64 %r5574, i64 %r5570
  %r5577 = inttoptr i64 %r5576 to ptr
  %r5578 = load i32, ptr %r5577, align 4
  %r5579 = zext i32 %r5578 to i64
  %r5580 = icmp ult i64 %r5559, %r5579
  %r5581 = and i1 %r5575, %r5580
  br i1 %r5581, label %plen.ic.spill_load.947, label %plen.ic.miss.948

plen.ic.spill_load.947:                           ; preds = %plen.ic.spill_ptr.946
  %r5582 = add nuw nsw i64 %r5559, 1
  %r5583 = getelementptr inbounds nuw i64, ptr %r5577, i64 %r5582
  %r5584 = load double, ptr %r5583, align 8
  br label %plen.ic.merge.949

plen.ic.miss.948:                                 ; preds = %plen.ic.spill_ptr.946, %plen.ic.spill_meta.945, %plen.ic.family_token.942, %plen.ic.family_meta.941, %plen.ic.exact.940, %plen.ic.shape.probe.938, %plen.ic.shape.937, %plen.ic.header.936, %plen.slow.934
  %statepoint_token839 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r5481, ptr @perry_ic_test_json_warm_unique_keys_ts__22, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01073) ]
  %r5585840 = call double @llvm.experimental.gc.result.f64(token %statepoint_token839)
  %rs4gc.s117.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token839, i32 0, i32 0) ; (%.01073, %.01073)
  br label %plen.ic.merge.949

plen.ic.merge.949:                                ; preds = %plen.elem.length.952, %plen.ic.miss.948, %plen.ic.spill_load.947, %plen.ic.inline.944
  %.21075 = phi ptr addrspace(1) [ %.01073, %plen.elem.length.952 ], [ %.01073, %plen.ic.inline.944 ], [ %.01073, %plen.ic.spill_load.947 ], [ %rs4gc.s117.relocated, %plen.ic.miss.948 ]
  %r5586 = phi double [ %r5534, %plen.elem.length.952 ], [ %r5567, %plen.ic.inline.944 ], [ %r5584, %plen.ic.spill_load.947 ], [ %r5585840, %plen.ic.miss.948 ]
  br label %plen.merge.935

plen.elem.meta.950:                               ; preds = %plen.ic.header.936
  %r5524 = add nuw nsw i64 %r5483, 8
  %r5525 = inttoptr i64 %r5524 to ptr
  %r5526 = load i64, ptr %r5525, align 8
  %r5527 = icmp ne i64 %r5526, 0
  br i1 %r5527, label %plen.elem.store.951, label %plen.ic.shape.937

plen.elem.store.951:                              ; preds = %plen.elem.meta.950
  %r5528 = inttoptr i64 %r5526 to ptr
  %r5529 = getelementptr i64, ptr %r5528, i64 12
  %r5530 = load i64, ptr %r5529, align 8
  %r5531 = icmp ne i64 %r5530, 0
  br i1 %r5531, label %plen.elem.length.952, label %plen.ic.shape.937

plen.elem.length.952:                             ; preds = %plen.elem.store.951
  %r5532 = inttoptr i64 %r5530 to ptr
  %r5533 = load i32, ptr %r5532, align 4
  %r5534 = uitofp i32 %r5533 to double
  br label %plen.ic.merge.949

gcpoll.953:                                       ; preds = %plen.merge.935
  %statepoint_token841 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11074) ]
  %rs4gc.s117.relocated842 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token841, i32 0, i32 0) ; (%.11074, %.11074)
  br label %gcpoll.done.954

gcpoll.done.954:                                  ; preds = %gcpoll.953, %plen.merge.935
  %.31076 = phi ptr addrspace(1) [ %rs4gc.s117.relocated842, %gcpoll.953 ], [ %.11074, %plen.merge.935 ]
  %r5591 = icmp eq i64 %r5589, 9222246136947933188
  br i1 %r5591, label %for.body.929, label %for.exit.931

arr.fast.955:                                     ; preds = %arr.guard.range.961
  %r5658 = zext i32 %r5478.0 to i64
  %r5659 = shl nuw nsw i64 %r5658, 3
  %r5660 = add nuw nsw i64 %r5659, 8
  %r5661 = add i64 %r5617, %r5660
  %r5662 = inttoptr i64 %r5661 to ptr
  %r5663 = load double, ptr %r5662, align 8
  %r5664 = bitcast double %r5663 to i64
  %r5665 = icmp eq i64 %r5664, 9222246136947933200
  %r5667 = select i1 %r5665, double 0x7FFC000000000001, double %r5663
  br label %arr.merge.958

arr.fallback.956:                                 ; preds = %arr.guard.live.960, %arr.guard.deref.959, %for.body.929
  %r5656 = sitofp i32 %r5478.0 to double
  %statepoint_token843 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 547434508618563607, double %r5595, double %r5656, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31076) ]
  %r5657844 = call double @llvm.experimental.gc.result.f64(token %statepoint_token843)
  %rs4gc.s117.relocated845 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token843, i32 0, i32 0) ; (%.31076, %.31076)
  br label %arr.merge.958

arr.guard.oob.957:                                ; preds = %arr.guard.range.961
  br label %arr.merge.958

arr.merge.958:                                    ; preds = %arr.guard.oob.957, %arr.fallback.956, %arr.fast.955
  %.41077 = phi ptr addrspace(1) [ %.31076, %arr.fast.955 ], [ %.31076, %arr.guard.oob.957 ], [ %rs4gc.s117.relocated845, %arr.fallback.956 ]
  %r5668 = phi double [ %r5667, %arr.fast.955 ], [ %r5657844, %arr.fallback.956 ], [ 0x7FFC000000000001, %arr.guard.oob.957 ]
  %rs4gc.b118 = bitcast double %r5668 to i64
  %rs4gc.s118 = inttoptr i64 %rs4gc.b118 to ptr addrspace(1)
  %r5669 = bitcast double %r5668 to i64
  %r5670 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5671 = icmp ne i32 %r5670, 0
  br i1 %r5671, label %shadow.root.barrier.962, label %shadow.root.barrier.done.963

arr.guard.deref.959:                              ; preds = %for.body.929
  %r5603 = bitcast double %r5595 to i64
  %r5604 = and i64 %r5603, 281474976710655
  %r5605 = sub nsw i64 %r5604, 8
  %r5606 = inttoptr i64 %r5605 to ptr
  %r5607 = load i8, ptr %r5606, align 1
  %r5608 = icmp eq i8 %r5607, 1
  %r5609 = sub nsw i64 %r5604, 7
  %r5610 = inttoptr i64 %r5609 to ptr
  %r5611 = load i8, ptr %r5610, align 1
  %r5612 = and i8 %r5611, -128
  %r5613 = icmp ne i8 %r5612, 0
  %r5614 = inttoptr i64 %r5604 to ptr
  %r5615 = load i64, ptr %r5614, align 8
  %r5616 = and i1 %r5608, %r5613
  %r5617 = select i1 %r5616, i64 %r5615, i64 %r5604
  %r5618 = lshr i64 %r5617, 48
  %r5619 = icmp eq i64 %r5618, 0
  %r5620 = icmp ugt i64 %r5617, 1048575
  %r5621 = and i1 %r5619, %r5620
  br i1 %r5621, label %arr.guard.live.960, label %arr.fallback.956

arr.guard.live.960:                               ; preds = %arr.guard.deref.959
  %r5622 = sub nuw i64 %r5617, 8
  %r5623 = inttoptr i64 %r5622 to ptr
  %r5624 = load i8, ptr %r5623, align 1
  %r5625 = icmp eq i8 %r5624, 1
  %r5626 = sub nuw i64 %r5617, 7
  %r5627 = inttoptr i64 %r5626 to ptr
  %r5628 = load i8, ptr %r5627, align 1
  %r5629 = and i8 %r5628, -128
  %r5630 = icmp eq i8 %r5629, 0
  %r5631 = sub nuw i64 %r5617, 6
  %r5632 = inttoptr i64 %r5631 to ptr
  %r5633 = load i16, ptr %r5632, align 2
  %r5634 = and i16 %r5633, 1024
  %r5635 = icmp eq i16 %r5634, 0
  %r5636 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r5637 = icmp eq i8 %r5636, 0
  %r5638 = inttoptr i64 %r5617 to ptr
  %r5639 = load i32, ptr %r5638, align 4
  %r5640 = getelementptr i8, ptr %r5638, i64 4
  %r5641 = load i32, ptr %r5640, align 4
  %r5642 = icmp slt i32 %r5478.0, 0
  %r5643 = icmp eq i1 %r5642, false
  %r5645 = icmp ule i32 %r5639, 16000000
  %r5646 = icmp ule i32 %r5641, 16000000
  %r5647 = icmp ule i32 %r5639, %r5641
  %r5648 = and i1 %r5625, %r5630
  %r5649 = and i1 %r5648, %r5635
  %r5650 = and i1 %r5649, %r5637
  %r5651 = and i1 %r5650, %r5643
  %r5652 = and i1 %r5651, %r5645
  %r5653 = and i1 %r5652, %r5646
  %r5654 = and i1 %r5653, %r5647
  br i1 %r5654, label %arr.guard.range.961, label %arr.fallback.956

arr.guard.range.961:                              ; preds = %arr.guard.live.960
  %r5644 = icmp ult i32 %r5478.0, %r5639
  br i1 %r5644, label %arr.fast.955, label %arr.guard.oob.957

shadow.root.barrier.962:                          ; preds = %arr.merge.958
  call void @js_write_barrier_root_nanbox(i64 %r5669) #7
  br label %shadow.root.barrier.done.963

shadow.root.barrier.done.963:                     ; preds = %shadow.root.barrier.962, %arr.merge.958
  %statepoint_token846 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s118, ptr addrspace(1) %.41077) ]
  %r5672847 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token846)
  %rs4gc.s118.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token846, i32 0, i32 0) ; (%rs4gc.s118, %rs4gc.s118)
  %rs4gc.s117.relocated848 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token846, i32 1, i32 1) ; (%.41077, %.41077)
  %rs4gc.s119 = inttoptr i64 %r5672847 to ptr addrspace(1)
  %r5673.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s119 to i64
  %r5673 = call i64 asm "", "=r,0"(i64 %r5673.rs4i) #7
  %r5674 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5675 = icmp ne i32 %r5674, 0
  br i1 %r5675, label %shadow.root.barrier.964, label %shadow.root.barrier.done.965

shadow.root.barrier.964:                          ; preds = %shadow.root.barrier.done.963
  call void @js_write_barrier_root_nanbox(i64 %r5673) #7
  br label %shadow.root.barrier.done.965

shadow.root.barrier.done.965:                     ; preds = %shadow.root.barrier.964, %shadow.root.barrier.done.963
  %r5676 = load double, ptr @test_json_warm_unique_keys_ts_.str.31.handle, align 8
  %r5677.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s119 to i64
  %r5677 = call i64 asm "", "=r,0"(i64 %r5677.rs4i) #7
  %statepoint_token849 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r5677, double %r5676, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s117.relocated848, ptr addrspace(1) %rs4gc.s118.relocated) ]
  %r5678850 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token849)
  %rs4gc.s117.relocated851 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token849, i32 0, i32 0) ; (%rs4gc.s117.relocated848, %rs4gc.s117.relocated848)
  %rs4gc.s118.relocated852 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token849, i32 1, i32 1) ; (%rs4gc.s118.relocated, %rs4gc.s118.relocated)
  %rs4gc.s120 = inttoptr i64 %r5678850 to ptr addrspace(1)
  %r5679.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s120 to i64
  %r5679 = call i64 asm "", "=r,0"(i64 %r5679.rs4i) #7
  %r5680 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5681 = icmp ne i32 %r5680, 0
  br i1 %r5681, label %shadow.root.barrier.966, label %shadow.root.barrier.done.967

shadow.root.barrier.966:                          ; preds = %shadow.root.barrier.done.965
  call void @js_write_barrier_root_nanbox(i64 %r5679) #7
  br label %shadow.root.barrier.done.967

shadow.root.barrier.done.967:                     ; preds = %shadow.root.barrier.966, %shadow.root.barrier.done.965
  %r5682.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s118.relocated852 to i64
  %r5682.rs4o = call i64 asm "", "=r,0"(i64 %r5682.rs4i) #7
  %r5682 = bitcast i64 %r5682.rs4o to double
  %statepoint_token853 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r5682, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s117.relocated851, ptr addrspace(1) %rs4gc.s120) ]
  %r5683854 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token853)
  %rs4gc.s117.relocated855 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token853, i32 0, i32 0) ; (%rs4gc.s117.relocated851, %rs4gc.s117.relocated851)
  %rs4gc.s120.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token853, i32 1, i32 1) ; (%rs4gc.s120, %rs4gc.s120)
  %r5684 = bitcast i64 %r5683854 to double
  %r5685.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s120.relocated to i64
  %r5685 = call i64 asm "", "=r,0"(i64 %r5685.rs4i) #7
  %statepoint_token856 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r5685, double %r5684, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s117.relocated855) ]
  %r5686857 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token856)
  %rs4gc.s117.relocated858 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token856, i32 0, i32 0) ; (%rs4gc.s117.relocated855, %rs4gc.s117.relocated855)
  %rs4gc.s121 = inttoptr i64 %r5686857 to ptr addrspace(1)
  %r5687.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s121 to i64
  %r5687 = call i64 asm "", "=r,0"(i64 %r5687.rs4i) #7
  %r5688 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r5689 = icmp ne i32 %r5688, 0
  br i1 %r5689, label %shadow.root.barrier.968, label %shadow.root.barrier.done.969

shadow.root.barrier.968:                          ; preds = %shadow.root.barrier.done.967
  call void @js_write_barrier_root_nanbox(i64 %r5687) #7
  br label %shadow.root.barrier.done.969

shadow.root.barrier.done.969:                     ; preds = %shadow.root.barrier.968, %shadow.root.barrier.done.967
  %r5690.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s121 to i64
  %r5690 = call i64 asm "", "=r,0"(i64 %r5690.rs4i) #7
  %statepoint_token859 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r5690, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s117.relocated858) ]
  %rs4gc.s117.relocated860 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token859, i32 0, i32 0) ; (%rs4gc.s117.relocated858, %rs4gc.s117.relocated858)
  %r5691 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r5692 = icmp ne i32 %r5691, 0
  br i1 %r5692, label %gcpoll.970, label %gcpoll.done.971

gcpoll.970:                                       ; preds = %shadow.root.barrier.done.969
  %statepoint_token861 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s117.relocated860) ]
  %rs4gc.s117.relocated862 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token861, i32 0, i32 0) ; (%rs4gc.s117.relocated860, %rs4gc.s117.relocated860)
  br label %gcpoll.done.971

gcpoll.done.971:                                  ; preds = %gcpoll.970, %shadow.root.barrier.done.969
  %.51078 = phi ptr addrspace(1) [ %rs4gc.s117.relocated862, %gcpoll.970 ], [ %rs4gc.s117.relocated860, %shadow.root.barrier.done.969 ]
  br label %for.update.930

event_loop.header.972:                            ; preds = %event_loop.body_wait.977, %event_loop.body_check.976, %if.merge.786
  %statepoint_token863 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_event_loop_host_driven, i32 0, i32 0, i32 0, i32 0)
  %r5701864 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token863)
  %r5702 = icmp ne i32 %r5701864, 0
  br i1 %r5702, label %event_loop.host_return.974, label %event_loop.check_pending.973

event_loop.check_pending.973:                     ; preds = %event_loop.header.972
  %statepoint_token865 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r5703866 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token865)
  %statepoint_token867 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r5704868 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token867)
  %statepoint_token869 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r5705870 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token869)
  %statepoint_token871 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r5706872 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token871)
  %statepoint_token873 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r5707874 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token873)
  %statepoint_token875 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r5708876 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token875)
  %r5709 = or i32 %r5703866, %r5704868
  %r5710 = or i32 %r5705870, %r5706872
  %r5711 = or i32 %r5710, %r5707874
  %r5712 = or i32 %r5709, %r5711
  %r5713 = or i32 %r5712, 0
  %r5714 = or i32 %r5713, %r5708876
  %r5715 = icmp ne i32 %r5714, 0
  br i1 %r5715, label %event_loop.body.975, label %event_loop.exit.978

event_loop.host_return.974:                       ; preds = %event_loop.header.972
  call void @js_typed_feedback_maybe_dump_trace() #7
  ret i32 0

event_loop.body.975:                              ; preds = %event_loop.check_pending.973
  %statepoint_token877 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token878 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.body_check.976

event_loop.body_check.976:                        ; preds = %event_loop.body.975
  %statepoint_token879 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r5717880 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token879)
  %statepoint_token881 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r5718882 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token881)
  %statepoint_token883 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r5719884 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token883)
  %statepoint_token885 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r5720886 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token885)
  %statepoint_token887 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r5721888 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token887)
  %statepoint_token889 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r5722890 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token889)
  %r5723 = or i32 %r5717880, %r5718882
  %r5724 = or i32 %r5719884, %r5720886
  %r5725 = or i32 %r5724, %r5721888
  %r5726 = or i32 %r5723, %r5725
  %r5727 = or i32 %r5726, 0
  %r5728 = or i32 %r5727, %r5722890
  %r5729 = icmp ne i32 %r5728, 0
  br i1 %r5729, label %event_loop.body_wait.977, label %event_loop.header.972

event_loop.body_wait.977:                         ; preds = %event_loop.body_check.976
  %statepoint_token891 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_wait_for_event, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.972

event_loop.exit.978:                              ; preds = %event_loop.check_pending.973
  %statepoint_token892 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_emit_before_exit_pending, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token893 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token894 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_exit_sequence, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token895 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_finalization_exit, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token896 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_promise_jobs, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token897 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_trace_events_flush_output, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token898 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_promise_report_unhandled_rejections, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token899 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_release_current_thread_collection_side_allocations, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token900 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_process_pending_exit_code, i32 0, i32 0, i32 0, i32 0)
  %r5732901 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token900)
  call void @js_typed_feedback_maybe_dump_trace() #7
  ret i32 %r5732901
}

; Function Attrs: optsize
define void @__perry_init_strings_test_json_warm_unique_keys_ts_chunk0() #6 {
entry.0:
  %r1 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.0.bytes, i32 1)
  %r2 = call double @js_nanbox_string(i64 %r1)
  store double %r2, ptr @test_json_warm_unique_keys_ts_.str.0.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.0.handle to i64))
  %r4 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.1.bytes, i32 1)
  %r5 = call double @js_nanbox_string(i64 %r4)
  store double %r5, ptr @test_json_warm_unique_keys_ts_.str.1.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.1.handle to i64))
  %r7 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.2.bytes, i32 1)
  %r8 = call double @js_nanbox_string(i64 %r7)
  store double %r8, ptr @test_json_warm_unique_keys_ts_.str.2.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.2.handle to i64))
  %r10 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.3.bytes, i32 1)
  %r11 = call double @js_nanbox_string(i64 %r10)
  store double %r11, ptr @test_json_warm_unique_keys_ts_.str.3.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.3.handle to i64))
  %r13 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.4.bytes, i32 1)
  %r14 = call double @js_nanbox_string(i64 %r13)
  store double %r14, ptr @test_json_warm_unique_keys_ts_.str.4.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.4.handle to i64))
  %r16 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.5.bytes, i32 1)
  %r17 = call double @js_nanbox_string(i64 %r16)
  store double %r17, ptr @test_json_warm_unique_keys_ts_.str.5.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.5.handle to i64))
  %r19 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.6.bytes, i32 1)
  %r20 = call double @js_nanbox_string(i64 %r19)
  store double %r20, ptr @test_json_warm_unique_keys_ts_.str.6.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.6.handle to i64))
  %r22 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.7.bytes, i32 1)
  %r23 = call double @js_nanbox_string(i64 %r22)
  store double %r23, ptr @test_json_warm_unique_keys_ts_.str.7.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.7.handle to i64))
  %r25 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.8.bytes, i32 49)
  %r26 = call double @js_nanbox_string(i64 %r25)
  store double %r26, ptr @test_json_warm_unique_keys_ts_.str.8.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.8.handle to i64))
  %r28 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.9.bytes, i32 1)
  %r29 = call double @js_nanbox_string(i64 %r28)
  store double %r29, ptr @test_json_warm_unique_keys_ts_.str.9.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.9.handle to i64))
  %r31 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.10.bytes, i32 2)
  %r32 = call double @js_nanbox_string(i64 %r31)
  store double %r32, ptr @test_json_warm_unique_keys_ts_.str.10.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.10.handle to i64))
  %r34 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.11.bytes, i32 6)
  %r35 = call double @js_nanbox_string(i64 %r34)
  store double %r35, ptr @test_json_warm_unique_keys_ts_.str.11.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.11.handle to i64))
  %r37 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.12.bytes, i32 11)
  %r38 = call double @js_nanbox_string(i64 %r37)
  store double %r38, ptr @test_json_warm_unique_keys_ts_.str.12.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.12.handle to i64))
  %r40 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.13.bytes, i32 16)
  %r41 = call double @js_nanbox_string(i64 %r40)
  store double %r41, ptr @test_json_warm_unique_keys_ts_.str.13.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.13.handle to i64))
  %r43 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.14.bytes, i32 29)
  %r44 = call double @js_nanbox_string(i64 %r43)
  store double %r44, ptr @test_json_warm_unique_keys_ts_.str.14.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.14.handle to i64))
  %r46 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.15.bytes, i32 1)
  %r47 = call double @js_nanbox_string(i64 %r46)
  store double %r47, ptr @test_json_warm_unique_keys_ts_.str.15.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.15.handle to i64))
  %r49 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.16.bytes, i32 1)
  %r50 = call double @js_nanbox_string(i64 %r49)
  store double %r50, ptr @test_json_warm_unique_keys_ts_.str.16.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.16.handle to i64))
  %r52 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.17.bytes, i32 1)
  %r53 = call double @js_nanbox_string(i64 %r52)
  store double %r53, ptr @test_json_warm_unique_keys_ts_.str.17.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.17.handle to i64))
  %r55 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.18.bytes, i32 31)
  %r56 = call double @js_nanbox_string(i64 %r55)
  store double %r56, ptr @test_json_warm_unique_keys_ts_.str.18.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.18.handle to i64))
  %r58 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.19.bytes, i32 50)
  %r59 = call double @js_nanbox_string(i64 %r58)
  store double %r59, ptr @test_json_warm_unique_keys_ts_.str.19.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.19.handle to i64))
  %r61 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.20.bytes, i32 19)
  %r62 = call double @js_nanbox_string(i64 %r61)
  store double %r62, ptr @test_json_warm_unique_keys_ts_.str.20.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.20.handle to i64))
  %r64 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.21.bytes, i32 22)
  %r65 = call double @js_nanbox_string(i64 %r64)
  store double %r65, ptr @test_json_warm_unique_keys_ts_.str.21.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.21.handle to i64))
  %r67 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.22.bytes, i32 1)
  %r68 = call double @js_nanbox_string(i64 %r67)
  store double %r68, ptr @test_json_warm_unique_keys_ts_.str.22.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.22.handle to i64))
  %r70 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.23.bytes, i32 1)
  %r71 = call double @js_nanbox_string(i64 %r70)
  store double %r71, ptr @test_json_warm_unique_keys_ts_.str.23.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.23.handle to i64))
  %r73 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.24.bytes, i32 6)
  %r74 = call double @js_nanbox_string(i64 %r73)
  store double %r74, ptr @test_json_warm_unique_keys_ts_.str.24.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.24.handle to i64))
  %r76 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.25.bytes, i32 11)
  %r77 = call double @js_nanbox_string(i64 %r76)
  store double %r77, ptr @test_json_warm_unique_keys_ts_.str.25.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.25.handle to i64))
  %r79 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.26.bytes, i32 7)
  %r80 = call double @js_nanbox_string(i64 %r79)
  store double %r80, ptr @test_json_warm_unique_keys_ts_.str.26.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.26.handle to i64))
  %r82 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.27.bytes, i32 31)
  %r83 = call double @js_nanbox_string(i64 %r82)
  store double %r83, ptr @test_json_warm_unique_keys_ts_.str.27.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.27.handle to i64))
  %r85 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.28.bytes, i32 5)
  %r86 = call double @js_nanbox_string(i64 %r85)
  store double %r86, ptr @test_json_warm_unique_keys_ts_.str.28.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.28.handle to i64))
  %r88 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.29.bytes, i32 4)
  %r89 = call double @js_nanbox_string(i64 %r88)
  store double %r89, ptr @test_json_warm_unique_keys_ts_.str.29.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.29.handle to i64))
  %r91 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.30.bytes, i32 5)
  %r92 = call double @js_nanbox_string(i64 %r91)
  store double %r92, ptr @test_json_warm_unique_keys_ts_.str.30.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.30.handle to i64))
  %r94 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.31.bytes, i32 8)
  %r95 = call double @js_nanbox_string(i64 %r94)
  store double %r95, ptr @test_json_warm_unique_keys_ts_.str.31.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.31.handle to i64))
  %r97 = call i64 @js_string_from_bytes(ptr @test_json_warm_unique_keys_ts_.str.32.bytes, i32 6)
  %r98 = call double @js_nanbox_string(i64 %r97)
  store double %r98, ptr @test_json_warm_unique_keys_ts_.str.32.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_warm_unique_keys_ts_.str.32.handle to i64))
  ret void
}

; Function Attrs: optsize
define void @__perry_init_strings_test_json_warm_unique_keys_ts() #6 {
entry.0:
  call void @__perry_init_strings_test_json_warm_unique_keys_ts_chunk0()
  ret void
}

declare void @__tmp_use(...)

attributes #0 = { nounwind willreturn }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { optsize "frame-pointer"="non-leaf" }
attributes #7 = { "gc-leaf-function" }

!0 = !{}
