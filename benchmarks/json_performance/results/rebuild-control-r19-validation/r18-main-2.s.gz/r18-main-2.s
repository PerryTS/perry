
benchmarks/json_performance/.work/tape-batch-r18/main-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100245dc8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value>:
100245dc8:     	sub	sp, sp, #0x60
100245dcc:     	stp	x24, x23, [sp, #0x20]
100245dd0:     	stp	x22, x21, [sp, #0x30]
100245dd4:     	stp	x20, x19, [sp, #0x40]
100245dd8:     	stp	x29, x30, [sp, #0x50]
100245ddc:     	add	x29, sp, #0x50
100245de0:     	mov	x21, x0
100245de4:     	ldr	x23, [x0, #0x70]
100245de8:     	ldp	x8, x9, [x0]
100245dec:     	cmp	x8, #0x0
100245df0:     	ccmp	x9, x23, #0x0, ne
100245df4:     	b.eq	0x100245e20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x58>
100245df8:     	add	x0, sp, #0x8
100245dfc:     	mov	x1, x21
100245e00:     	bl	0x100245978 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes>
100245e04:     	ldr	x22, [sp, #0x8]
100245e08:     	cmn	x22, #0x2
100245e0c:     	b.ne	0x100245e48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x80>
100245e10:     	strb	wzr, [x21, #0xd4]
100245e14:     	mov	x0, #0x2                ; =2
100245e18:     	movk	x0, #0x7ffc, lsl #48
100245e1c:     	b	0x100245e30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100245e20:     	ldp	x8, x9, [x21, #0x10]
100245e24:     	str	x8, [x21, #0x70]
100245e28:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100245e2c:     	bfxil	x0, x9, #0, #48
100245e30:     	ldp	x29, x30, [sp, #0x50]
100245e34:     	ldp	x20, x19, [sp, #0x40]
100245e38:     	ldp	x22, x21, [sp, #0x30]
100245e3c:     	ldp	x24, x23, [sp, #0x20]
100245e40:     	add	sp, sp, #0x60
100245e44:     	ret
100245e48:     	ldp	x20, x19, [sp, #0x10]
100245e4c:     	cmp	x19, #0x6
100245e50:     	b.hs	0x100245ee0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x118>
100245e54:     	subs	x8, x19, #0x3
100245e58:     	b.lo	0x100245f0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100245e5c:     	ldrb	w9, [x20]
100245e60:     	cmp	w9, #0xed
100245e64:     	b.ne	0x100245e84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xbc>
100245e68:     	ldrb	w9, [x20, #0x1]
100245e6c:     	and	w9, w9, #0xe0
100245e70:     	cmp	w9, #0xa0
100245e74:     	b.ne	0x100245e84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xbc>
100245e78:     	ldrsb	w9, [x20, #0x2]
100245e7c:     	cmn	w9, #0x40
100245e80:     	b.lt	0x100245ee0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x118>
100245e84:     	cbz	x8, 0x100245f0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100245e88:     	ldrb	w9, [x20, #0x1]
100245e8c:     	cmp	w9, #0xed
100245e90:     	b.ne	0x100245eb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xe8>
100245e94:     	ldrb	w9, [x20, #0x2]
100245e98:     	and	w9, w9, #0xe0
100245e9c:     	cmp	w9, #0xa0
100245ea0:     	b.ne	0x100245eb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xe8>
100245ea4:     	ldrsb	w9, [x20, #0x3]
100245ea8:     	cmn	w9, #0x40
100245eac:     	b.lt	0x100245ee0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x118>
100245eb0:     	cmp	x8, #0x1
100245eb4:     	b.eq	0x100245f0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100245eb8:     	ldrb	w8, [x20, #0x2]
100245ebc:     	cmp	w8, #0xed
100245ec0:     	b.ne	0x100245f0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100245ec4:     	ldrb	w8, [x20, #0x3]
100245ec8:     	and	w8, w8, #0xe0
100245ecc:     	cmp	w8, #0xa0
100245ed0:     	b.ne	0x100245f0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100245ed4:     	ldrsb	w8, [x20, #0x4]
100245ed8:     	cmn	w8, #0x40
100245edc:     	b.ge	0x100245f0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100245ee0:     	cmn	x22, #0x1
100245ee4:     	b.eq	0x100245f28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x160>
100245ee8:     	mov	x0, x20
100245eec:     	mov	x1, x19
100245ef0:     	bl	0x10034b7f0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
100245ef4:     	mov	x8, x0
100245ef8:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100245efc:     	bfxil	x0, x8, #0, #48
100245f00:     	cmp	x22, #0x1
100245f04:     	b.ge	0x1002460b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2f0>
100245f08:     	b	0x100245e30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100245f0c:     	cbz	x19, 0x100245fec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x224>
100245f10:     	cmp	x19, #0x4
100245f14:     	b.hs	0x100245ff4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x22c>
100245f18:     	mov	x10, #0x0               ; =0
100245f1c:     	mov	x9, #0x0                ; =0
100245f20:     	mov	x8, x20
100245f24:     	b	0x100246084 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2bc>
100245f28:     	add	x0, x21, #0x20
100245f2c:     	mov	x1, x20
100245f30:     	mov	x2, x19
100245f34:     	bl	0x1005eaf04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>
100245f38:     	ldr	x22, [x21, #0x68]
100245f3c:     	cmp	x22, #0x200, lsl #12    ; =0x200000
100245f40:     	b.hi	0x10024612c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100245f44:     	cmp	x19, #0x100
100245f48:     	b.lo	0x10024612c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100245f4c:     	cbz	x0, 0x10024612c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100245f50:     	ldr	x20, [x21, #0xc8]
100245f54:     	cbz	x20, 0x10024612c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100245f58:     	ldr	x21, [x21, #0x70]
100245f5c:     	sub	x8, x22, x22, lsr #1
100245f60:     	cmp	x19, x8
100245f64:     	orr	x8, x21, x23
100245f68:     	and	x8, x8, #0xffffffff00000000
100245f6c:     	ccmp	x8, #0x0, #0x0, hs
100245f70:     	b.ne	0x10024612c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100245f74:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100245f78:     	ldr	w19, [x8, #0x560]
100245f7c:     	cmp	w19, #0x300
100245f80:     	b.hs	0x100246158 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x390>
100245f84:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
100245f88:     	ldr	x8, [x8, #0x48]
100245f8c:     	cmn	x8, #0x1
100245f90:     	b.eq	0x10024613c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x374>
100245f94:     	mrs	x9, TPIDRRO_EL0
100245f98:     	and	x9, x9, #0xfffffffffffffff8
100245f9c:     	ldr	x8, [x9, x8, lsl #3]
100245fa0:     	cbz	x8, 0x10024613c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x374>
100245fa4:     	add	x8, x8, x19, lsl #3
100245fa8:     	ldr	x19, [x8, #0x1e8]
100245fac:     	cbz	x19, 0x100246158 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x390>
100245fb0:     	ldr	x8, [x19]
100245fb4:     	cbnz	x8, 0x100246178 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3b0>
100245fb8:     	mov	x8, #-0x1               ; =-1
100245fbc:     	str	x8, [x19]
100245fc0:     	ldrb	w8, [x19, #0x24]
100245fc4:     	cmp	w8, #0x2
100245fc8:     	b.eq	0x1002460cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x304>
100245fcc:     	ldr	x8, [x19, #0x8]
100245fd0:     	cmp	x8, x20
100245fd4:     	b.ne	0x1002460cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x304>
100245fd8:     	ldr	w8, [x19, #0x18]
100245fdc:     	cmp	w8, w22
100245fe0:     	b.ne	0x1002460cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x304>
100245fe4:     	mov	x8, #0x0                ; =0
100245fe8:     	b	0x100246128 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x360>
100245fec:     	mov	x10, #0x0               ; =0
100245ff0:     	b	0x1002460a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2dc>
100245ff4:     	and	x9, x19, #0x4
100245ff8:     	add	x8, x20, x9
100245ffc:     	adrp	x10, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4f30>
100246000:     	ldr	q0, [x10, #0x940]
100246004:     	adrp	x10, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x3373a>
100246008:     	ldr	q2, [x10, #0x840]
10024600c:     	movi.2d	v1, #0000000000000000
100246010:     	movi.2d	v3, #0x000000000000ff
100246014:     	mov	w10, #0x4               ; =4
100246018:     	dup.2d	v4, x10
10024601c:     	mov	x10, x20
100246020:     	and	x11, x19, #0x4
100246024:     	movi.2d	v5, #0000000000000000
100246028:     	ldr	s6, [x10], #0x4
10024602c:     	ushll.8h	v6, v6, #0x0
100246030:     	ushll.4s	v6, v6, #0x0
100246034:     	ushll2.2d	v7, v6, #0x0
100246038:     	and.16b	v7, v7, v3
10024603c:     	ushll.2d	v6, v6, #0x0
100246040:     	and.16b	v6, v6, v3
100246044:     	shl.2d	v16, v0, #0x3
100246048:     	shl.2d	v17, v2, #0x3
10024604c:     	ushl.2d	v6, v6, v17
100246050:     	ushl.2d	v7, v7, v16
100246054:     	orr.16b	v1, v7, v1
100246058:     	orr.16b	v5, v6, v5
10024605c:     	add.2d	v0, v0, v4
100246060:     	add.2d	v2, v2, v4
100246064:     	subs	x11, x11, #0x4
100246068:     	b.ne	0x100246028 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x260>
10024606c:     	orr.16b	v0, v5, v1
100246070:     	mov	d1, v0[1]
100246074:     	orr.8b	v0, v0, v1
100246078:     	fmov	x10, d0
10024607c:     	cmp	x19, x9
100246080:     	b.eq	0x1002460a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2dc>
100246084:     	add	x11, x20, x19
100246088:     	lsl	x9, x9, #3
10024608c:     	ldrb	w12, [x8], #0x1
100246090:     	lsl	x12, x12, x9
100246094:     	orr	x10, x12, x10
100246098:     	add	x9, x9, #0x8
10024609c:     	cmp	x8, x11
1002460a0:     	b.ne	0x10024608c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2c4>
1002460a4:     	orr	x8, x10, x19, lsl #40
1002460a8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1002460ac:     	orr	x0, x8, x9
1002460b0:     	cmp	x22, #0x1
1002460b4:     	b.lt	0x100245e30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
1002460b8:     	mov	x19, x0
1002460bc:     	mov	x0, x20
1002460c0:     	bl	0x100b5eec0 <_mi_free>
1002460c4:     	mov	x0, x19
1002460c8:     	b	0x100245e30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
1002460cc:     	stp	x20, x0, [x19, #0x8]
1002460d0:     	stp	w22, w23, [x19, #0x18]
1002460d4:     	str	w21, [x19, #0x20]
1002460d8:     	strb	wzr, [x19, #0x24]
1002460dc:     	adrp	x21, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1002460e0:     	ldr	w8, [x21, #0x864]
1002460e4:     	cbz	w8, 0x100246100 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x338>
1002460e8:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
1002460ec:     	bfxil	x8, x20, #0, #48
1002460f0:     	mov	x20, x0
1002460f4:     	mov	x0, x8
1002460f8:     	bl	0x100476730 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1002460fc:     	mov	x0, x20
100246100:     	ldr	w8, [x21, #0x864]
100246104:     	cbz	w8, 0x100246120 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x358>
100246108:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
10024610c:     	bfxil	x8, x0, #0, #48
100246110:     	mov	x20, x0
100246114:     	mov	x0, x8
100246118:     	bl	0x100476730 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
10024611c:     	mov	x0, x20
100246120:     	ldr	x8, [x19]
100246124:     	add	x8, x8, #0x1
100246128:     	str	x8, [x19]
10024612c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100246130:     	bfxil	x8, x0, #0, #48
100246134:     	mov	x0, x8
100246138:     	b	0x100245e30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
10024613c:     	mov	x24, x0
100246140:     	bl	0x100b3f2fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100246144:     	mov	x8, x0
100246148:     	mov	x0, x24
10024614c:     	add	x8, x8, x19, lsl #3
100246150:     	ldr	x19, [x8, #0x1e8]
100246154:     	cbnz	x19, 0x100245fb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x1e8>
100246158:     	str	x0, [sp]
10024615c:     	adrp	x0, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
100246160:     	add	x0, x0, #0xfa0
100246164:     	bl	0x100b3cb1c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100246168:     	mov	x19, x0
10024616c:     	ldr	x0, [sp]
100246170:     	ldr	x8, [x19]
100246174:     	cbz	x8, 0x100245fb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x1f0>
100246178:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10024617c:     	add	x0, x0, #0xce0
100246180:     	bl	0x100b1262c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
		...
