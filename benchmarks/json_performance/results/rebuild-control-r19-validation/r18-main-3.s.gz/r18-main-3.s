
benchmarks/json_performance/.work/tape-batch-r18/main-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100246198 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped>:
100246198:     	stp	x28, x27, [sp, #-0x60]!
10024619c:     	stp	x26, x25, [sp, #0x10]
1002461a0:     	stp	x24, x23, [sp, #0x20]
1002461a4:     	stp	x22, x21, [sp, #0x30]
1002461a8:     	stp	x20, x19, [sp, #0x40]
1002461ac:     	stp	x29, x30, [sp, #0x50]
1002461b0:     	add	x29, sp, #0x50
1002461b4:     	sub	sp, sp, #0x2e0
1002461b8:     	mov	x19, x0
1002461bc:     	ldp	x8, x9, [x0, #0x68]
1002461c0:     	add	x9, x9, #0x1
1002461c4:     	str	x9, [x0, #0x70]
1002461c8:     	cmp	x9, x8
1002461cc:     	b.hs	0x100246200 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x68>
1002461d0:     	ldr	x10, [x19, #0x60]
1002461d4:     	mov	x11, #0x2600            ; =9728
1002461d8:     	movk	x11, #0x1, lsl #32
1002461dc:     	ldrb	w12, [x10, x9]
1002461e0:     	cmp	w12, #0x20
1002461e4:     	b.hi	0x100246200 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x68>
1002461e8:     	lsr	x12, x11, x12
1002461ec:     	tbz	w12, #0x0, 0x100246200 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x68>
1002461f0:     	add	x9, x9, #0x1
1002461f4:     	str	x9, [x19, #0x70]
1002461f8:     	cmp	x8, x9
1002461fc:     	b.ne	0x1002461dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x44>
100246200:     	ldrb	w8, [x19, #0xd5]
100246204:     	tbz	w8, #0x0, 0x100246230 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x98>
100246208:     	strb	wzr, [x19, #0xd5]
10024620c:     	ldr	x21, [x19, #0x78]
100246210:     	ldp	q0, q1, [x19, #0x80]
100246214:     	stur	q0, [sp, #0xa8]
100246218:     	stur	q1, [sp, #0xb8]
10024621c:     	ldp	q0, q1, [x19, #0xa0]
100246220:     	stur	q0, [sp, #0xc8]
100246224:     	stur	q1, [sp, #0xd8]
100246228:     	ldr	x9, [x19, #0xc0]
10024622c:     	b	0x100246268 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd0>
100246230:     	mov	w26, #0x0               ; =0
100246234:     	mov	x8, #0x0                ; =0
100246238:     	ldr	x21, [x19, #0x78]
10024623c:     	cbz	x21, 0x100247394 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11fc>
100246240:     	ldr	x10, [x19, #0xc0]
100246244:     	str	x10, [sp, #0x88]
100246248:     	cbz	x10, 0x100246284 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xec>
10024624c:     	ldp	q0, q1, [x19, #0x80]
100246250:     	stur	q0, [sp, #0xa8]
100246254:     	stur	q1, [sp, #0xb8]
100246258:     	ldp	q0, q1, [x19, #0xa0]
10024625c:     	stur	q0, [sp, #0xc8]
100246260:     	stur	q1, [sp, #0xd8]
100246264:     	ldr	x9, [sp, #0x88]
100246268:     	ldr	w8, [x19, #0xd0]
10024626c:     	stp	x21, x9, [sp, #0xe8]
100246270:     	str	x9, [sp, #0x88]
100246274:     	str	w8, [sp, #0x64]
100246278:     	str	w8, [sp, #0xf8]
10024627c:     	mov	w8, #0x1                ; =1
100246280:     	mov	w26, #0x1               ; =1
100246284:     	str	x8, [sp, #0xa0]
100246288:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10024628c:     	add	x0, x0, #0xce8
100246290:     	ldr	x8, [x0]
100246294:     	blr	x8
100246298:     	mov	x20, x0
10024629c:     	ldrb	w8, [x0, #0x20]
1002462a0:     	cbnz	w8, 0x10024762c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1494>
1002462a4:     	ldr	x8, [x20]
1002462a8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1002462ac:     	cmp	x8, x9
1002462b0:     	b.hs	0x100247658 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x14c0>
1002462b4:     	ldr	x22, [x20, #0x18]
1002462b8:     	ldp	x23, x24, [x19, #0x68]
1002462bc:     	cmp	x24, x23
1002462c0:     	b.hs	0x1002462f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15c>
1002462c4:     	ldr	x8, [x19, #0x60]
1002462c8:     	ldrb	w8, [x8, x24]
1002462cc:     	cmp	w8, #0x7d
1002462d0:     	b.ne	0x1002462f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15c>
1002462d4:     	add	x8, x24, #0x1
1002462d8:     	str	x8, [x19, #0x70]
1002462dc:     	ldr	x8, [x19, #0x78]
1002462e0:     	cbnz	x8, 0x100247398 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1200>
1002462e4:     	ldr	x1, [x19, #0xc0]
1002462e8:     	cbz	x1, 0x100247398 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1200>
1002462ec:     	ldr	w2, [x19, #0xd0]
1002462f0:     	b	0x1002473b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1220>
1002462f4:     	movi.2d	v0, #0000000000000000
1002462f8:     	stp	q0, q0, [sp, #0x120]
1002462fc:     	stp	q0, q0, [sp, #0x100]
100246300:     	adrp	x1, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6f30>
100246304:     	add	x1, x1, #0xbb0
100246308:     	add	x0, sp, #0x148
10024630c:     	mov	w2, #0x40               ; =64
100246310:     	bl	0x100b61d90 <_writev+0x100b61d90>
100246314:     	mov	x27, #0x0               ; =0
100246318:     	str	xzr, [sp, #0x90]
10024631c:     	mov	x8, #-0x1               ; =-1
100246320:     	str	x8, [sp, #0x188]
100246324:     	add	x8, sp, #0xa0
100246328:     	add	x8, x8, #0x8
10024632c:     	stp	x8, xzr, [sp, #0x68]
100246330:     	mov	x25, #0x2600            ; =9728
100246334:     	movk	x25, #0x1, lsl #32
100246338:     	adrp	x8, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4f30>
10024633c:     	ldr	q0, [x8, #0x960]
100246340:     	str	q0, [sp, #0x40]
100246344:     	adrp	x8, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4f30>
100246348:     	ldr	q0, [x8, #0x970]
10024634c:     	str	q0, [sp, #0x30]
100246350:     	adrp	x8, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4f30>
100246354:     	ldr	q0, [x8, #0x950]
100246358:     	str	q0, [sp, #0x50]
10024635c:     	mov	x11, x26
100246360:     	mov	x8, x26
100246364:     	str	w26, [sp, #0x80]
100246368:     	str	w8, [sp, #0x84]
10024636c:     	cmp	x24, x23
100246370:     	b.hs	0x1002463a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x208>
100246374:     	ldr	x8, [x19, #0x60]
100246378:     	ldrb	w9, [x8, x24]
10024637c:     	cmp	w9, #0x20
100246380:     	b.hi	0x1002463a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x208>
100246384:     	lsr	x9, x25, x9
100246388:     	tbz	w9, #0x0, 0x1002463a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x208>
10024638c:     	add	x24, x24, #0x1
100246390:     	str	x24, [x19, #0x70]
100246394:     	cmp	x23, x24
100246398:     	b.ne	0x100246378 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1e0>
10024639c:     	mov	x24, x23
1002463a0:     	str	w11, [sp, #0x7c]
1002463a4:     	str	x27, [sp, #0x98]
1002463a8:     	cbz	w26, 0x100246460 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
1002463ac:     	cmp	x27, x21
1002463b0:     	cset	w8, lo
1002463b4:     	tst	w11, w8
1002463b8:     	b.eq	0x100246460 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
1002463bc:     	cmp	x27, #0x8
1002463c0:     	b.hs	0x100247700 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1568>
1002463c4:     	cmp	x24, x23
1002463c8:     	b.hs	0x100246460 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
1002463cc:     	ldr	x8, [sp, #0x68]
1002463d0:     	ldr	x9, [x8, x27, lsl #3]
1002463d4:     	cbz	x9, 0x100246460 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
1002463d8:     	ldr	x10, [x19, #0x60]
1002463dc:     	ldrb	w8, [x10, x24]
1002463e0:     	cmp	w8, #0x22
1002463e4:     	b.ne	0x100246460 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
1002463e8:     	add	x11, x24, #0x1
1002463ec:     	ldr	w14, [x9, #0x4]
1002463f0:     	add	x8, x11, x14
1002463f4:     	cmp	x8, x23
1002463f8:     	ccmp	x8, x24, #0x0, lo
1002463fc:     	b.ls	0x100246460 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100246400:     	ldrb	w12, [x10, x8]
100246404:     	cmp	w12, #0x22
100246408:     	b.ne	0x100246460 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
10024640c:     	add	x24, x10, x11
100246410:     	cbz	w14, 0x10024644c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2b4>
100246414:     	add	x9, x9, #0x14
100246418:     	mov	x10, x14
10024641c:     	mov	x11, x24
100246420:     	ldrb	w12, [x11], #0x1
100246424:     	cmp	w12, #0x5c
100246428:     	b.eq	0x100246460 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
10024642c:     	cmp	w12, #0x22
100246430:     	b.eq	0x100246460 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100246434:     	ldrb	w13, [x9], #0x1
100246438:     	cmp	w12, #0x20
10024643c:     	ccmp	w12, w13, #0x0, hs
100246440:     	b.ne	0x100246460 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100246444:     	subs	x10, x10, #0x1
100246448:     	b.ne	0x100246420 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x288>
10024644c:     	add	x8, x8, #0x1
100246450:     	str	x8, [x19, #0x70]
100246454:     	mov	w23, #0x1               ; =1
100246458:     	mov	x27, #-0x1              ; =-1
10024645c:     	b	0x100246480 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
100246460:     	sub	x0, x29, #0xc0
100246464:     	mov	x1, x19
100246468:     	bl	0x100245978 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes>
10024646c:     	ldur	x27, [x29, #-0xc0]
100246470:     	cmn	x27, #0x2
100246474:     	b.eq	0x1002471d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1038>
100246478:     	mov	w23, #0x0               ; =0
10024647c:     	ldp	x24, x14, [x29, #-0xb8]
100246480:     	ldp	x9, x8, [x19, #0x68]
100246484:     	cmp	x8, x9
100246488:     	b.hs	0x1002471bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1024>
10024648c:     	ldr	x10, [x19, #0x60]
100246490:     	ldrb	w11, [x10, x8]
100246494:     	cmp	w11, #0x3a
100246498:     	b.hi	0x1002471bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1024>
10024649c:     	lsr	x12, x25, x11
1002464a0:     	tbz	w12, #0x0, 0x1002464b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x320>
1002464a4:     	add	x8, x8, #0x1
1002464a8:     	str	x8, [x19, #0x70]
1002464ac:     	cmp	x9, x8
1002464b0:     	b.ne	0x100246490 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2f8>
1002464b4:     	b	0x1002471bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1024>
1002464b8:     	cmp	x11, #0x3a
1002464bc:     	b.ne	0x1002471bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1024>
1002464c0:     	str	x14, [sp, #0x28]
1002464c4:     	add	x8, x8, #0x1
1002464c8:     	str	x8, [x19, #0x70]
1002464cc:     	mov	x0, x19
1002464d0:     	bl	0x1002448c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value>
1002464d4:     	str	x0, [sp, #0x10]
1002464d8:     	ldrb	w8, [x19, #0xd4]
1002464dc:     	tbz	w8, #0x0, 0x1002471c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1028>
1002464e0:     	ldr	x8, [sp, #0x188]
1002464e4:     	cmn	x8, #0x1
1002464e8:     	str	x24, [sp, #0x18]
1002464ec:     	b.eq	0x1002465b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x418>
1002464f0:     	ldr	x8, [sp, #0x1b8]
1002464f4:     	ldr	x1, [sp, #0x198]
1002464f8:     	cmn	x8, #0x1
1002464fc:     	ldr	x2, [sp, #0x28]
100246500:     	str	x22, [sp, #0x8]
100246504:     	b.eq	0x1002465fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x464>
100246508:     	mov	x28, #0x7f2d            ; =32557
10024650c:     	movk	x28, #0x4c95, lsl #16
100246510:     	movk	x28, #0xf42d, lsl #32
100246514:     	movk	x28, #0x5851, lsl #48
100246518:     	ldp	x8, x11, [sp, #0x1f0]
10024651c:     	ldr	x10, [sp, #0x200]
100246520:     	ldr	x9, [sp, #0x208]
100246524:     	eor	x11, x11, x2
100246528:     	mul	x12, x11, x28
10024652c:     	umulh	x11, x11, x28
100246530:     	eor	x11, x11, x12
100246534:     	add	x11, x2, x11
100246538:     	mul	x11, x11, x28
10024653c:     	cmp	x2, #0x8
100246540:     	b.ls	0x10024682c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x694>
100246544:     	cmp	x2, #0x10
100246548:     	b.ls	0x100246914 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x77c>
10024654c:     	add	x12, x24, x2
100246550:     	ldp	x12, x13, [x12, #-0x10]
100246554:     	eor	x12, x10, x12
100246558:     	eor	x13, x13, x9
10024655c:     	mul	x14, x13, x12
100246560:     	umulh	x12, x13, x12
100246564:     	eor	x12, x12, x14
100246568:     	add	x11, x11, x8
10024656c:     	eor	x11, x11, x12
100246570:     	ror	x11, x11, #0x29
100246574:     	mov	x13, x24
100246578:     	mov	x12, x2
10024657c:     	ldp	x15, x14, [x13], #0x10
100246580:     	sub	x12, x12, #0x10
100246584:     	eor	x15, x10, x15
100246588:     	eor	x14, x14, x9
10024658c:     	mul	x16, x14, x15
100246590:     	umulh	x14, x14, x15
100246594:     	eor	x14, x14, x16
100246598:     	add	x11, x11, x8
10024659c:     	eor	x11, x11, x14
1002465a0:     	ror	x11, x11, #0x29
1002465a4:     	cmp	x12, #0x10
1002465a8:     	b.hi	0x10024657c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x3e4>
1002465ac:     	b	0x100246968 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7d0>
1002465b0:     	ldr	w8, [sp, #0x84]
1002465b4:     	ldr	x1, [sp, #0x28]
1002465b8:     	tbz	w8, #0x0, 0x10024684c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6b4>
1002465bc:     	ldr	w8, [sp, #0x80]
1002465c0:     	tbz	w8, #0x0, 0x1002476f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x155c>
1002465c4:     	ldr	x8, [sp, #0x98]
1002465c8:     	cmp	x8, x21
1002465cc:     	ldr	w11, [sp, #0x7c]
1002465d0:     	b.hs	0x100246b80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9e8>
1002465d4:     	tbz	w23, #0x0, 0x100246b44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9ac>
1002465d8:     	ldr	x0, [sp, #0x98]
1002465dc:     	cmp	x0, #0x7
1002465e0:     	b.hi	0x100247760 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15c8>
1002465e4:     	ldr	x8, [sp, #0x68]
1002465e8:     	ldr	x10, [x8, x0, lsl #3]
1002465ec:     	add	x0, x0, #0x1
1002465f0:     	str	x0, [sp, #0x98]
1002465f4:     	mov	w8, #0x1                ; =1
1002465f8:     	b	0x100246b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9fc>
1002465fc:     	ldr	x26, [sp, #0x190]
100246600:     	cmp	x1, #0x80
100246604:     	mov	x28, #0x7f2d            ; =32557
100246608:     	movk	x28, #0x4c95, lsl #16
10024660c:     	movk	x28, #0xf42d, lsl #32
100246610:     	movk	x28, #0x5851, lsl #48
100246614:     	b.ne	0x100246864 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6cc>
100246618:     	mov	w8, #0x1                ; =1
10024661c:     	strb	w8, [x19, #0xd6]
100246620:     	adrp	x8, 0x10104d000 <_out_buf+0x3988>
100246624:     	add	x8, x8, #0x840
100246628:     	ldapr	x8, [x8]
10024662c:     	cbz	x8, 0x100247180 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfe8>
100246630:     	ldp	x0, x22, [x8]
100246634:     	adrp	x8, 0x10104d000 <_out_buf+0x3988>
100246638:     	add	x8, x8, #0x848
10024663c:     	ldapr	x24, [x8]
100246640:     	cbz	x24, 0x1002471a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1008>
100246644:     	ldr	x8, [x22, #0x18]
100246648:     	blr	x8
10024664c:     	mov	x2, x0
100246650:     	sub	x8, x29, #0xc0
100246654:     	add	x8, x8, #0x38
100246658:     	add	x1, x24, #0x20
10024665c:     	mov	x0, x24
100246660:     	bl	0x1000091dc <__RNvMs1_NtCs3SoQS4yp3pP_5ahash12random_stateNtB5_11RandomState9from_keys>
100246664:     	mov	w0, #0x1108             ; =4360
100246668:     	mov	w1, #0x8                ; =8
10024666c:     	bl	0x100b5f148 <_mi_malloc_aligned>
100246670:     	cbz	x0, 0x100247734 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x159c>
100246674:     	mov	x24, #0x0               ; =0
100246678:     	mov	x2, #0x0                ; =0
10024667c:     	movi.2d	v0, #0xffffffffffffffff
100246680:     	str	q0, [x0, #0x10f0]
100246684:     	str	q0, [x0, #0x10e0]
100246688:     	str	q0, [x0, #0x10d0]
10024668c:     	str	q0, [x0, #0x10c0]
100246690:     	str	q0, [x0, #0x10b0]
100246694:     	str	q0, [x0, #0x10a0]
100246698:     	str	q0, [x0, #0x1090]
10024669c:     	str	q0, [x0, #0x1080]
1002466a0:     	str	q0, [x0, #0x1070]
1002466a4:     	str	q0, [x0, #0x1060]
1002466a8:     	str	q0, [x0, #0x1050]
1002466ac:     	str	q0, [x0, #0x1040]
1002466b0:     	str	q0, [x0, #0x1030]
1002466b4:     	str	q0, [x0, #0x1020]
1002466b8:     	str	q0, [x0, #0x1010]
1002466bc:     	str	q0, [x0, #0x1000]
1002466c0:     	str	d0, [x0, #0x1100]
1002466c4:     	add	x8, x0, #0x1, lsl #12   ; =0x1000
1002466c8:     	stur	xzr, [x29, #-0x90]
1002466cc:     	ldr	q0, [sp, #0x50]
1002466d0:     	stur	q0, [x29, #-0xa0]
1002466d4:     	mov	w9, #0x8                ; =8
1002466d8:     	stp	xzr, x9, [x29, #-0xc0]
1002466dc:     	stp	xzr, x8, [x29, #-0xb0]
1002466e0:     	b	0x10024673c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x5a4>
1002466e4:     	ldr	w11, [x11]
1002466e8:     	ldur	w12, [x14, #-0x4]
1002466ec:     	eor	x10, x11, x10
1002466f0:     	eor	x9, x12, x9
1002466f4:     	mul	x11, x9, x10
1002466f8:     	umulh	x9, x9, x10
1002466fc:     	eor	x9, x9, x11
100246700:     	add	x10, x13, x8
100246704:     	eor	x9, x10, x9
100246708:     	ror	x13, x9, #0x29
10024670c:     	add	x24, x24, #0x8
100246710:     	add	x22, x2, #0x1
100246714:     	mul	x9, x13, x8
100246718:     	umulh	x8, x13, x8
10024671c:     	eor	x8, x8, x9
100246720:     	neg	w9, w13
100246724:     	ror	x1, x8, x9
100246728:     	sub	x0, x29, #0xc0
10024672c:     	bl	0x100288d0c <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11insert_hash>
100246730:     	mov	x2, x22
100246734:     	cmp	x24, #0x400
100246738:     	b.eq	0x10024686c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6d4>
10024673c:     	ldr	x8, [x26, x24]
100246740:     	add	x11, x8, #0x14
100246744:     	ldr	w12, [x8, #0x4]
100246748:     	ldp	x8, x13, [x29, #-0x88]
10024674c:     	ldp	x10, x9, [x29, #-0x78]
100246750:     	eor	x13, x13, x12
100246754:     	mul	x14, x13, x28
100246758:     	umulh	x13, x13, x28
10024675c:     	eor	x13, x13, x14
100246760:     	add	x13, x13, x12
100246764:     	mul	x13, x13, x28
100246768:     	cmp	w12, #0x8
10024676c:     	b.ls	0x1002467d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x63c>
100246770:     	cmp	w12, #0x10
100246774:     	b.ls	0x1002467f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x65c>
100246778:     	add	x14, x11, x12
10024677c:     	ldp	x14, x15, [x14, #-0x10]
100246780:     	eor	x14, x10, x14
100246784:     	eor	x15, x15, x9
100246788:     	mul	x16, x15, x14
10024678c:     	umulh	x14, x15, x14
100246790:     	eor	x14, x14, x16
100246794:     	add	x13, x13, x8
100246798:     	eor	x13, x13, x14
10024679c:     	ror	x13, x13, #0x29
1002467a0:     	ldp	x15, x14, [x11], #0x10
1002467a4:     	sub	x12, x12, #0x10
1002467a8:     	eor	x15, x10, x15
1002467ac:     	eor	x14, x14, x9
1002467b0:     	mul	x16, x14, x15
1002467b4:     	umulh	x14, x14, x15
1002467b8:     	eor	x14, x14, x16
1002467bc:     	add	x13, x13, x8
1002467c0:     	eor	x13, x13, x14
1002467c4:     	ror	x13, x13, #0x29
1002467c8:     	cmp	x12, #0x10
1002467cc:     	b.hi	0x1002467a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x608>
1002467d0:     	b	0x10024670c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x574>
1002467d4:     	cmp	w12, #0x1
1002467d8:     	b.ls	0x10024680c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x674>
1002467dc:     	add	x14, x11, x12
1002467e0:     	cmp	w12, #0x3
1002467e4:     	b.hi	0x1002466e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x54c>
1002467e8:     	ldrh	w11, [x11]
1002467ec:     	ldurb	w12, [x14, #-0x1]
1002467f0:     	b	0x1002466ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x554>
1002467f4:     	ldr	x14, [x11]
1002467f8:     	add	x11, x11, x12
1002467fc:     	ldur	x11, [x11, #-0x8]
100246800:     	eor	x10, x14, x10
100246804:     	eor	x9, x11, x9
100246808:     	b	0x1002466f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x55c>
10024680c:     	cmp	w12, #0x1
100246810:     	b.ne	0x100246820 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x688>
100246814:     	ldrb	w11, [x11]
100246818:     	mov	x12, x11
10024681c:     	b	0x1002466ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x554>
100246820:     	mov	x11, #0x0               ; =0
100246824:     	mov	x12, #0x0               ; =0
100246828:     	b	0x1002466ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x554>
10024682c:     	cmp	x2, #0x1
100246830:     	b.ls	0x100246924 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x78c>
100246834:     	add	x13, x24, x2
100246838:     	cmp	x2, #0x3
10024683c:     	b.ls	0x100246934 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x79c>
100246840:     	ldr	w12, [x24]
100246844:     	ldur	w13, [x13, #-0x4]
100246848:     	b	0x100246948 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7b0>
10024684c:     	mov	x0, x24
100246850:     	bl	0x10032823c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100246854:     	mov	x10, x0
100246858:     	mov	w8, #0x0                ; =0
10024685c:     	ldr	w11, [sp, #0x7c]
100246860:     	b	0x100246b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9fc>
100246864:     	str	x1, [sp, #0x20]
100246868:     	b	0x100246fa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe10>
10024686c:     	ldur	q2, [x29, #-0x80]
100246870:     	ldur	x8, [x29, #-0x70]
100246874:     	str	x8, [sp, #0x260]
100246878:     	ldp	q0, q1, [x29, #-0xc0]
10024687c:     	stp	q0, q1, [sp, #0x210]
100246880:     	ldp	q0, q1, [x29, #-0xa0]
100246884:     	str	q0, [sp, #0x230]
100246888:     	stp	q1, q2, [sp, #0x240]
10024688c:     	ldr	x22, [sp, #0x1b8]
100246890:     	cmn	x22, #0x1
100246894:     	ldr	x24, [sp, #0x18]
100246898:     	ldr	x2, [sp, #0x28]
10024689c:     	b.eq	0x1002468dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x744>
1002468a0:     	ldr	x9, [sp, #0x1d8]
1002468a4:     	cbz	x9, 0x1002468cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x734>
1002468a8:     	lsl	x8, x9, #4
1002468ac:     	add	x9, x8, x9
1002468b0:     	cmn	x9, #0x19
1002468b4:     	b.eq	0x1002468cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x734>
1002468b8:     	ldr	x9, [sp, #0x1d0]
1002468bc:     	sub	x8, x9, x8
1002468c0:     	sub	x0, x8, #0x10
1002468c4:     	bl	0x100b5eec0 <_mi_free>
1002468c8:     	ldr	x2, [sp, #0x28]
1002468cc:     	cbz	x22, 0x1002468dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x744>
1002468d0:     	ldr	x0, [sp, #0x1c0]
1002468d4:     	bl	0x100b5eec0 <_mi_free>
1002468d8:     	ldr	x2, [sp, #0x28]
1002468dc:     	ldr	x8, [sp, #0x260]
1002468e0:     	add	x9, sp, #0x188
1002468e4:     	stur	x8, [x9, #0x80]
1002468e8:     	ldr	q2, [sp, #0x250]
1002468ec:     	ldp	q0, q1, [sp, #0x210]
1002468f0:     	stp	q0, q1, [x9, #0x30]
1002468f4:     	ldp	q0, q1, [sp, #0x230]
1002468f8:     	stur	q0, [x9, #0x50]
1002468fc:     	stp	q1, q2, [x9, #0x60]
100246900:     	ldr	x8, [sp, #0x1b8]
100246904:     	cmn	x8, #0x1
100246908:     	b.eq	0x100246fa0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe08>
10024690c:     	ldr	x1, [sp, #0x198]
100246910:     	b	0x100246518 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x380>
100246914:     	ldr	x12, [x24]
100246918:     	add	x13, x24, x2
10024691c:     	ldur	x13, [x13, #-0x8]
100246920:     	b	0x100246948 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7b0>
100246924:     	b.ne	0x100246940 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7a8>
100246928:     	ldrb	w12, [x24]
10024692c:     	mov	x13, x12
100246930:     	b	0x100246948 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7b0>
100246934:     	ldrh	w12, [x24]
100246938:     	ldurb	w13, [x13, #-0x1]
10024693c:     	b	0x100246948 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7b0>
100246940:     	mov	x12, #0x0               ; =0
100246944:     	mov	x13, #0x0               ; =0
100246948:     	eor	x10, x12, x10
10024694c:     	eor	x9, x13, x9
100246950:     	mul	x12, x9, x10
100246954:     	umulh	x9, x9, x10
100246958:     	eor	x9, x9, x12
10024695c:     	add	x10, x11, x8
100246960:     	eor	x9, x10, x9
100246964:     	ror	x11, x9, #0x29
100246968:     	mul	x9, x11, x8
10024696c:     	umulh	x8, x11, x8
100246970:     	eor	x8, x8, x9
100246974:     	neg	w9, w11
100246978:     	ror	x28, x8, x9
10024697c:     	ldr	x8, [sp, #0x1e8]
100246980:     	cbz	x8, 0x100246ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x93c>
100246984:     	mov	x8, #0x0                ; =0
100246988:     	mov	x9, #0x7c15             ; =31765
10024698c:     	movk	x9, #0x7f4a, lsl #16
100246990:     	movk	x9, #0x79b9, lsl #32
100246994:     	movk	x9, #0x9e37, lsl #48
100246998:     	mul	x9, x28, x9
10024699c:     	eor	x11, x9, x9, lsr #32
1002469a0:     	lsr	x12, x9, #57
1002469a4:     	ldp	x10, x9, [sp, #0x1d0]
1002469a8:     	ldr	x26, [sp, #0x190]
1002469ac:     	dup.8b	v0, w12
1002469b0:     	and	x11, x11, x9
1002469b4:     	ldr	d1, [x10, x11]
1002469b8:     	cmeq.8b	v2, v1, v0
1002469bc:     	fmov	x12, d2
1002469c0:     	ands	x12, x12, #0x8080808080808080
1002469c4:     	b.eq	0x1002469f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x85c>
1002469c8:     	rbit	x13, x12
1002469cc:     	clz	x13, x13
1002469d0:     	add	x13, x11, x13, lsr #3
1002469d4:     	and	x13, x13, x9
1002469d8:     	sub	x13, x10, x13, lsl #4
1002469dc:     	ldur	x14, [x13, #-0x10]
1002469e0:     	cmp	x28, x14
1002469e4:     	b.eq	0x100246a28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x890>
1002469e8:     	sub	x13, x12, #0x2
1002469ec:     	ands	x12, x13, x12
1002469f0:     	b.ne	0x1002469c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x830>
1002469f4:     	movi.2d	v2, #0xffffffffffffffff
1002469f8:     	cmeq.8b	v1, v1, v2
1002469fc:     	fmov	x12, d1
100246a00:     	cbnz	x12, 0x100246ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x93c>
100246a04:     	add	x8, x8, #0x8
100246a08:     	add	x11, x11, x8
100246a0c:     	and	x11, x11, x9
100246a10:     	ldr	d1, [x10, x11]
100246a14:     	cmeq.8b	v2, v1, v0
100246a18:     	fmov	x12, d2
100246a1c:     	ands	x12, x12, #0x8080808080808080
100246a20:     	b.ne	0x1002469c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x830>
100246a24:     	b	0x1002469f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x85c>
100246a28:     	ldur	x24, [x13, #-0x8]
100246a2c:     	cmp	x24, x1
100246a30:     	b.hs	0x100247724 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x158c>
100246a34:     	ldr	x8, [x26, x24, lsl #3]
100246a38:     	ldr	w9, [x8, #0x4]
100246a3c:     	cmp	x2, x9
100246a40:     	str	x1, [sp, #0x20]
100246a44:     	b.ne	0x100246a60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x8c8>
100246a48:     	add	x0, x8, #0x14
100246a4c:     	ldr	x1, [sp, #0x18]
100246a50:     	ldr	x2, [sp, #0x28]
100246a54:     	bl	0x100b61d60 <_writev+0x100b61d60>
100246a58:     	ldp	x1, x2, [sp, #0x20]
100246a5c:     	cbz	w0, 0x100246ac4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x92c>
100246a60:     	ldr	x8, [sp, #0x1c8]
100246a64:     	cbz	x8, 0x100246ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x93c>
100246a68:     	ldr	x9, [sp, #0x1c0]
100246a6c:     	lsl	x23, x8, #4
100246a70:     	add	x22, x9, #0x8
100246a74:     	b	0x100246a84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x8ec>
100246a78:     	add	x22, x22, #0x10
100246a7c:     	subs	x23, x23, #0x10
100246a80:     	b.eq	0x100246ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x93c>
100246a84:     	ldur	x8, [x22, #-0x8]
100246a88:     	cmp	x8, x28
100246a8c:     	b.ne	0x100246a78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x8e0>
100246a90:     	ldr	x24, [x22]
100246a94:     	cmp	x24, x1
100246a98:     	b.hs	0x100247714 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x157c>
100246a9c:     	ldr	x8, [x26, x24, lsl #3]
100246aa0:     	ldr	w9, [x8, #0x4]
100246aa4:     	cmp	x2, x9
100246aa8:     	b.ne	0x100246a78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x8e0>
100246aac:     	add	x0, x8, #0x14
100246ab0:     	ldr	x1, [sp, #0x18]
100246ab4:     	ldr	x2, [sp, #0x28]
100246ab8:     	bl	0x100b61d60 <_writev+0x100b61d60>
100246abc:     	ldp	x1, x2, [sp, #0x20]
100246ac0:     	cbnz	w0, 0x100246a78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x8e0>
100246ac4:     	ldr	x1, [sp, #0x1b0]
100246ac8:     	cmp	x24, x1
100246acc:     	b.lo	0x100247030 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe98>
100246ad0:     	b	0x100247750 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15b8>
100246ad4:     	add	x0, x19, #0x20
100246ad8:     	mov	x22, x1
100246adc:     	ldr	x1, [sp, #0x18]
100246ae0:     	bl	0x1005eaf04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>
100246ae4:     	mov	x24, x0
100246ae8:     	add	x8, sp, #0x188
100246aec:     	add	x0, x8, #0x30
100246af0:     	mov	x1, x28
100246af4:     	mov	x2, x22
100246af8:     	bl	0x100288d0c <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11insert_hash>
100246afc:     	ldr	x22, [sp, #0x198]
100246b00:     	ldr	x8, [sp, #0x188]
100246b04:     	cmp	x22, x8
100246b08:     	b.eq	0x100247124 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf8c>
100246b0c:     	ldr	x8, [sp, #0x190]
100246b10:     	str	x24, [x8, x22, lsl #3]
100246b14:     	add	x8, x22, #0x1
100246b18:     	str	x8, [sp, #0x198]
100246b1c:     	ldr	x22, [sp, #0x1b0]
100246b20:     	ldr	x8, [sp, #0x1a0]
100246b24:     	cmp	x22, x8
100246b28:     	b.eq	0x100247130 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf98>
100246b2c:     	ldr	x28, [sp, #0x1a8]
100246b30:     	ldr	x8, [sp, #0x10]
100246b34:     	str	x8, [x28, x22, lsl #3]
100246b38:     	add	x1, x22, #0x1
100246b3c:     	str	x1, [sp, #0x1b0]
100246b40:     	b	0x10024703c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xea4>
100246b44:     	ldr	x0, [sp, #0x98]
100246b48:     	cmp	x0, #0x8
100246b4c:     	b.hs	0x100247770 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15d8>
100246b50:     	ldr	x8, [sp, #0x68]
100246b54:     	ldr	x23, [x8, x0, lsl #3]
100246b58:     	ldr	w8, [x23, #0x4]
100246b5c:     	cmp	x1, x8
100246b60:     	b.ne	0x100246b80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9e8>
100246b64:     	add	x0, x23, #0x14
100246b68:     	mov	x1, x24
100246b6c:     	ldr	x2, [sp, #0x28]
100246b70:     	bl	0x100b61d60 <_writev+0x100b61d60>
100246b74:     	ldr	x1, [sp, #0x28]
100246b78:     	ldr	w11, [sp, #0x7c]
100246b7c:     	cbz	w0, 0x100247140 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfa8>
100246b80:     	mov	x0, x24
100246b84:     	bl	0x10032823c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100246b88:     	mov	x10, x0
100246b8c:     	mov	w11, #0x0               ; =0
100246b90:     	mov	w8, #0x0                ; =0
100246b94:     	ldp	x1, x9, [sp, #0x90]
100246b98:     	cmp	x9, #0x0
100246b9c:     	str	w8, [sp, #0x84]
100246ba0:     	csinc	w23, w8, wzr, ne
100246ba4:     	cmp	x1, #0x9
100246ba8:     	b.hs	0x1002476b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1520>
100246bac:     	ldr	x2, [sp, #0x28]
100246bb0:     	cbz	x1, 0x100246f44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
100246bb4:     	ldr	x8, [sp, #0x100]
100246bb8:     	cmp	x8, x10
100246bbc:     	b.eq	0x100246f7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde4>
100246bc0:     	tbnz	w23, #0x0, 0x100246bfc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa64>
100246bc4:     	ldr	w9, [x8, #0x4]
100246bc8:     	cmp	x2, x9
100246bcc:     	b.ne	0x100246bfc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa64>
100246bd0:     	add	x0, x8, #0x14
100246bd4:     	mov	x1, x24
100246bd8:     	ldr	x2, [sp, #0x28]
100246bdc:     	str	w11, [sp, #0x7c]
100246be0:     	mov	x24, x10
100246be4:     	bl	0x100b61d60 <_writev+0x100b61d60>
100246be8:     	mov	x10, x24
100246bec:     	ldr	x2, [sp, #0x28]
100246bf0:     	ldr	w11, [sp, #0x7c]
100246bf4:     	ldr	x24, [sp, #0x18]
100246bf8:     	cbz	w0, 0x100246f7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde4>
100246bfc:     	ldr	x1, [sp, #0x90]
100246c00:     	cmp	x1, #0x1
100246c04:     	b.eq	0x100246f44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
100246c08:     	ldr	x9, [sp, #0x108]
100246c0c:     	add	x8, sp, #0x148
100246c10:     	add	x8, x8, #0x8
100246c14:     	cmp	x9, x10
100246c18:     	b.eq	0x100246f80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100246c1c:     	tbnz	w23, #0x0, 0x100246c60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xac8>
100246c20:     	ldr	w8, [x9, #0x4]
100246c24:     	cmp	x2, x8
100246c28:     	b.ne	0x100246c60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xac8>
100246c2c:     	add	x0, x9, #0x14
100246c30:     	mov	x1, x24
100246c34:     	ldr	x2, [sp, #0x28]
100246c38:     	str	w11, [sp, #0x7c]
100246c3c:     	mov	x24, x10
100246c40:     	bl	0x100b61d60 <_writev+0x100b61d60>
100246c44:     	mov	x10, x24
100246c48:     	ldr	x2, [sp, #0x28]
100246c4c:     	ldr	w11, [sp, #0x7c]
100246c50:     	ldr	x24, [sp, #0x18]
100246c54:     	add	x8, sp, #0x148
100246c58:     	add	x8, x8, #0x8
100246c5c:     	cbz	w0, 0x100246f80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100246c60:     	ldr	x1, [sp, #0x90]
100246c64:     	cmp	x1, #0x2
100246c68:     	b.eq	0x100246f44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
100246c6c:     	ldr	x9, [sp, #0x110]
100246c70:     	add	x8, sp, #0x148
100246c74:     	add	x8, x8, #0x10
100246c78:     	cmp	x9, x10
100246c7c:     	b.eq	0x100246f80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100246c80:     	tbnz	w23, #0x0, 0x100246cc4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb2c>
100246c84:     	ldr	w8, [x9, #0x4]
100246c88:     	cmp	x2, x8
100246c8c:     	b.ne	0x100246cc4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb2c>
100246c90:     	add	x0, x9, #0x14
100246c94:     	mov	x1, x24
100246c98:     	ldr	x2, [sp, #0x28]
100246c9c:     	str	w11, [sp, #0x7c]
100246ca0:     	mov	x24, x10
100246ca4:     	bl	0x100b61d60 <_writev+0x100b61d60>
100246ca8:     	mov	x10, x24
100246cac:     	ldr	x2, [sp, #0x28]
100246cb0:     	ldr	w11, [sp, #0x7c]
100246cb4:     	ldr	x24, [sp, #0x18]
100246cb8:     	add	x8, sp, #0x148
100246cbc:     	add	x8, x8, #0x10
100246cc0:     	cbz	w0, 0x100246f80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100246cc4:     	ldr	x1, [sp, #0x90]
100246cc8:     	cmp	x1, #0x3
100246ccc:     	b.eq	0x100246f44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
100246cd0:     	ldr	x9, [sp, #0x118]
100246cd4:     	add	x8, sp, #0x148
100246cd8:     	add	x8, x8, #0x18
100246cdc:     	cmp	x9, x10
100246ce0:     	b.eq	0x100246f80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100246ce4:     	tbnz	w23, #0x0, 0x100246d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb90>
100246ce8:     	ldr	w8, [x9, #0x4]
100246cec:     	cmp	x2, x8
100246cf0:     	b.ne	0x100246d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb90>
100246cf4:     	add	x0, x9, #0x14
100246cf8:     	mov	x1, x24
100246cfc:     	ldr	x2, [sp, #0x28]
100246d00:     	str	w11, [sp, #0x7c]
100246d04:     	mov	x24, x10
100246d08:     	bl	0x100b61d60 <_writev+0x100b61d60>
100246d0c:     	mov	x10, x24
100246d10:     	ldr	x2, [sp, #0x28]
100246d14:     	ldr	w11, [sp, #0x7c]
100246d18:     	ldr	x24, [sp, #0x18]
100246d1c:     	add	x8, sp, #0x148
100246d20:     	add	x8, x8, #0x18
100246d24:     	cbz	w0, 0x100246f80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100246d28:     	ldr	x1, [sp, #0x90]
100246d2c:     	cmp	x1, #0x4
100246d30:     	b.eq	0x100246f44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
100246d34:     	ldr	x9, [sp, #0x120]
100246d38:     	add	x8, sp, #0x148
100246d3c:     	add	x8, x8, #0x20
100246d40:     	cmp	x9, x10
100246d44:     	b.eq	0x100246f80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100246d48:     	tbnz	w23, #0x0, 0x100246d8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xbf4>
100246d4c:     	ldr	w8, [x9, #0x4]
100246d50:     	cmp	x2, x8
100246d54:     	b.ne	0x100246d8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xbf4>
100246d58:     	add	x0, x9, #0x14
100246d5c:     	mov	x1, x24
100246d60:     	ldr	x2, [sp, #0x28]
100246d64:     	str	w11, [sp, #0x7c]
100246d68:     	mov	x24, x10
100246d6c:     	bl	0x100b61d60 <_writev+0x100b61d60>
100246d70:     	mov	x10, x24
100246d74:     	ldr	x2, [sp, #0x28]
100246d78:     	ldr	w11, [sp, #0x7c]
100246d7c:     	ldr	x24, [sp, #0x18]
100246d80:     	add	x8, sp, #0x148
100246d84:     	add	x8, x8, #0x20
100246d88:     	cbz	w0, 0x100246f80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100246d8c:     	ldr	x1, [sp, #0x90]
100246d90:     	cmp	x1, #0x5
100246d94:     	b.eq	0x100246f44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
100246d98:     	ldr	x9, [sp, #0x128]
100246d9c:     	add	x8, sp, #0x148
100246da0:     	add	x8, x8, #0x28
100246da4:     	cmp	x9, x10
100246da8:     	b.eq	0x100246f80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100246dac:     	tbnz	w23, #0x0, 0x100246df0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xc58>
100246db0:     	ldr	w8, [x9, #0x4]
100246db4:     	cmp	x2, x8
100246db8:     	b.ne	0x100246df0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xc58>
100246dbc:     	add	x0, x9, #0x14
100246dc0:     	mov	x1, x24
100246dc4:     	ldr	x2, [sp, #0x28]
100246dc8:     	str	w11, [sp, #0x7c]
100246dcc:     	mov	x24, x10
100246dd0:     	bl	0x100b61d60 <_writev+0x100b61d60>
100246dd4:     	mov	x10, x24
100246dd8:     	ldr	x2, [sp, #0x28]
100246ddc:     	ldr	w11, [sp, #0x7c]
100246de0:     	ldr	x24, [sp, #0x18]
100246de4:     	add	x8, sp, #0x148
100246de8:     	add	x8, x8, #0x28
100246dec:     	cbz	w0, 0x100246f80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100246df0:     	ldr	x1, [sp, #0x90]
100246df4:     	cmp	x1, #0x6
100246df8:     	b.eq	0x100246f44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
100246dfc:     	ldr	x9, [sp, #0x130]
100246e00:     	add	x8, sp, #0x148
100246e04:     	add	x8, x8, #0x30
100246e08:     	cmp	x9, x10
100246e0c:     	b.eq	0x100246f80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100246e10:     	tbnz	w23, #0x0, 0x100246e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xcbc>
100246e14:     	ldr	w8, [x9, #0x4]
100246e18:     	cmp	x2, x8
100246e1c:     	b.ne	0x100246e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xcbc>
100246e20:     	add	x0, x9, #0x14
100246e24:     	mov	x1, x24
100246e28:     	ldr	x2, [sp, #0x28]
100246e2c:     	str	w11, [sp, #0x7c]
100246e30:     	mov	x24, x10
100246e34:     	bl	0x100b61d60 <_writev+0x100b61d60>
100246e38:     	mov	x10, x24
100246e3c:     	ldr	x2, [sp, #0x28]
100246e40:     	ldr	w11, [sp, #0x7c]
100246e44:     	ldr	x24, [sp, #0x18]
100246e48:     	add	x8, sp, #0x148
100246e4c:     	add	x8, x8, #0x30
100246e50:     	cbz	w0, 0x100246f80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100246e54:     	ldr	x1, [sp, #0x90]
100246e58:     	cmp	x1, #0x7
100246e5c:     	b.eq	0x100246f44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
100246e60:     	ldr	x9, [sp, #0x138]
100246e64:     	add	x8, sp, #0x148
100246e68:     	add	x8, x8, #0x38
100246e6c:     	cmp	x9, x10
100246e70:     	b.eq	0x100246f80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100246e74:     	tbnz	w23, #0x0, 0x100246eac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd14>
100246e78:     	ldr	w8, [x9, #0x4]
100246e7c:     	cmp	x2, x8
100246e80:     	b.ne	0x100246eac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd14>
100246e84:     	add	x0, x9, #0x14
100246e88:     	mov	x1, x24
100246e8c:     	str	w11, [sp, #0x7c]
100246e90:     	mov	x23, x10
100246e94:     	bl	0x100b61d60 <_writev+0x100b61d60>
100246e98:     	mov	x10, x23
100246e9c:     	ldr	w11, [sp, #0x7c]
100246ea0:     	add	x8, sp, #0x148
100246ea4:     	add	x8, x8, #0x38
100246ea8:     	cbz	w0, 0x100246f80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100246eac:     	ldr	x1, [sp, #0x90]
100246eb0:     	cmp	x1, #0x8
100246eb4:     	b.ne	0x100246f44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
100246eb8:     	mov	x24, x10
100246ebc:     	str	w11, [sp, #0x7c]
100246ec0:     	mov	x23, x22
100246ec4:     	mov	w0, #0x80               ; =128
100246ec8:     	bl	0x100b5f148 <_mi_malloc_aligned>
100246ecc:     	cbz	x0, 0x100247780 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15e8>
100246ed0:     	mov	x22, x0
100246ed4:     	mov	w0, #0x80               ; =128
100246ed8:     	mov	w1, #0x8                ; =8
100246edc:     	bl	0x100b5f148 <_mi_malloc_aligned>
100246ee0:     	cbz	x0, 0x100247780 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15e8>
100246ee4:     	mov	x28, x0
100246ee8:     	ldp	q0, q1, [sp, #0x100]
100246eec:     	stp	q0, q1, [x22]
100246ef0:     	ldp	q0, q1, [sp, #0x120]
100246ef4:     	stp	q0, q1, [x22, #0x20]
100246ef8:     	add	x9, sp, #0x148
100246efc:     	ldp	q0, q1, [x9]
100246f00:     	stp	q0, q1, [x0]
100246f04:     	ldp	q0, q1, [x9, #0x20]
100246f08:     	stp	q0, q1, [x0, #0x20]
100246f0c:     	str	x24, [x22, #0x40]
100246f10:     	ldr	x8, [sp, #0x10]
100246f14:     	str	x8, [x0, #0x40]
100246f18:     	mov	w8, #0x10               ; =16
100246f1c:     	stp	x8, x22, [sp, #0x188]
100246f20:     	ldp	q0, q1, [sp, #0x30]
100246f24:     	str	q1, [x9, #0x50]
100246f28:     	str	x0, [sp, #0x1a8]
100246f2c:     	mov	w8, #0x8                ; =8
100246f30:     	str	x8, [sp, #0x90]
100246f34:     	stur	q0, [x9, #0x68]
100246f38:     	mov	w1, #0x9                ; =9
100246f3c:     	mov	x22, x23
100246f40:     	b	0x100247040 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xea8>
100246f44:     	add	x8, sp, #0x100
100246f48:     	str	x10, [x8, x1, lsl #3]
100246f4c:     	add	x8, sp, #0x148
100246f50:     	ldr	x9, [sp, #0x10]
100246f54:     	str	x9, [x8, x1, lsl #3]
100246f58:     	add	x8, x1, #0x1
100246f5c:     	str	x8, [sp, #0x70]
100246f60:     	str	x8, [sp, #0x90]
100246f64:     	ldr	x1, [sp, #0x20]
100246f68:     	ldp	x23, x8, [x19, #0x68]
100246f6c:     	cmp	x8, x23
100246f70:     	str	x1, [sp, #0x20]
100246f74:     	b.lo	0x100247058 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xec0>
100246f78:     	b	0x1002470d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf40>
100246f7c:     	add	x8, sp, #0x148
100246f80:     	ldr	x9, [sp, #0x10]
100246f84:     	str	x9, [x8]
100246f88:     	ldr	x1, [sp, #0x20]
100246f8c:     	ldp	x23, x8, [x19, #0x68]
100246f90:     	cmp	x8, x23
100246f94:     	str	x1, [sp, #0x20]
100246f98:     	b.lo	0x100247058 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xec0>
100246f9c:     	b	0x1002470d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf40>
100246fa0:     	ldp	x26, x8, [sp, #0x190]
100246fa4:     	str	x8, [sp, #0x20]
100246fa8:     	mov	x0, x24
100246fac:     	mov	x1, x2
100246fb0:     	bl	0x10032823c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100246fb4:     	mov	x28, x0
100246fb8:     	ldr	x8, [sp, #0x98]
100246fbc:     	cmp	x8, #0x0
100246fc0:     	cset	w8, eq
100246fc4:     	ldr	x12, [sp, #0x20]
100246fc8:     	cbz	x12, 0x100247084 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xeec>
100246fcc:     	mov	x24, #0x0               ; =0
100246fd0:     	ldr	w9, [sp, #0x84]
100246fd4:     	orr	w22, w8, w9
100246fd8:     	lsl	x23, x12, #3
100246fdc:     	b	0x100246fec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe54>
100246fe0:     	add	x24, x24, #0x1
100246fe4:     	subs	x23, x23, #0x8
100246fe8:     	b.eq	0x100247084 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xeec>
100246fec:     	ldr	x8, [x26, x24, lsl #3]
100246ff0:     	cmp	x8, x28
100246ff4:     	b.eq	0x100247024 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe8c>
100246ff8:     	tbnz	w22, #0x0, 0x100246fe0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe48>
100246ffc:     	ldr	w9, [x8, #0x4]
100247000:     	ldr	x10, [sp, #0x28]
100247004:     	cmp	x10, x9
100247008:     	b.ne	0x100246fe0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe48>
10024700c:     	add	x0, x8, #0x14
100247010:     	ldr	x1, [sp, #0x18]
100247014:     	ldr	x2, [sp, #0x28]
100247018:     	bl	0x100b61d60 <_writev+0x100b61d60>
10024701c:     	ldr	x12, [sp, #0x20]
100247020:     	cbnz	w0, 0x100246fe0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe48>
100247024:     	ldr	x1, [sp, #0x1b0]
100247028:     	cmp	x24, x1
10024702c:     	b.hs	0x100247740 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15a8>
100247030:     	ldr	x28, [sp, #0x1a8]
100247034:     	ldr	x8, [sp, #0x10]
100247038:     	str	x8, [x28, x24, lsl #3]
10024703c:     	ldr	x22, [sp, #0x8]
100247040:     	ldr	w11, [sp, #0x7c]
100247044:     	ldr	x24, [sp, #0x18]
100247048:     	ldp	x23, x8, [x19, #0x68]
10024704c:     	cmp	x8, x23
100247050:     	str	x1, [sp, #0x20]
100247054:     	b.hs	0x1002470d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf40>
100247058:     	ldr	x9, [x19, #0x60]
10024705c:     	ldrb	w10, [x9, x8]
100247060:     	cmp	w10, #0x20
100247064:     	b.hi	0x1002470d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf40>
100247068:     	lsr	x10, x25, x10
10024706c:     	tbz	w10, #0x0, 0x1002470d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf40>
100247070:     	add	x8, x8, #0x1
100247074:     	str	x8, [x19, #0x70]
100247078:     	cmp	x23, x8
10024707c:     	b.ne	0x10024705c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xec4>
100247080:     	b	0x1002471c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1028>
100247084:     	ldr	x8, [sp, #0x188]
100247088:     	cmp	x12, x8
10024708c:     	ldr	w11, [sp, #0x7c]
100247090:     	b.eq	0x10024714c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfb4>
100247094:     	str	x28, [x26, x12, lsl #3]
100247098:     	add	x8, x12, #0x1
10024709c:     	str	x8, [sp, #0x198]
1002470a0:     	ldr	x22, [sp, #0x1b0]
1002470a4:     	ldr	x8, [sp, #0x1a0]
1002470a8:     	cmp	x22, x8
1002470ac:     	b.eq	0x100247168 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfd0>
1002470b0:     	ldr	x28, [sp, #0x1a8]
1002470b4:     	ldp	x8, x24, [sp, #0x10]
1002470b8:     	str	x8, [x28, x22, lsl #3]
1002470bc:     	add	x1, x22, #0x1
1002470c0:     	str	x1, [sp, #0x1b0]
1002470c4:     	ldr	x22, [sp, #0x8]
1002470c8:     	ldp	x23, x8, [x19, #0x68]
1002470cc:     	cmp	x8, x23
1002470d0:     	str	x1, [sp, #0x20]
1002470d4:     	b.lo	0x100247058 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xec0>
1002470d8:     	cmp	x8, x23
1002470dc:     	b.hs	0x1002471c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1028>
1002470e0:     	ldr	x9, [x19, #0x60]
1002470e4:     	ldrb	w9, [x9, x8]
1002470e8:     	cmp	w9, #0x2c
1002470ec:     	b.ne	0x1002471c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1028>
1002470f0:     	add	x24, x8, #0x1
1002470f4:     	str	x24, [x19, #0x70]
1002470f8:     	cmp	x27, #0x1
1002470fc:     	ldr	x27, [sp, #0x98]
100247100:     	ldp	w26, w8, [sp, #0x80]
100247104:     	b.lt	0x100246368 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0>
100247108:     	ldr	x0, [sp, #0x18]
10024710c:     	mov	x23, x11
100247110:     	bl	0x100b5eec0 <_mi_free>
100247114:     	mov	x11, x23
100247118:     	ldr	w8, [sp, #0x84]
10024711c:     	ldp	x23, x24, [x19, #0x68]
100247120:     	b	0x100246368 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0>
100247124:     	add	x0, sp, #0x188
100247128:     	bl	0x100b3bbec <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10024712c:     	b	0x100246b0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x974>
100247130:     	add	x8, sp, #0x188
100247134:     	add	x0, x8, #0x18
100247138:     	bl	0x100b3bbec <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10024713c:     	b	0x100246b2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x994>
100247140:     	mov	x10, x23
100247144:     	ldr	x0, [sp, #0x98]
100247148:     	b	0x1002465ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x454>
10024714c:     	add	x0, sp, #0x188
100247150:     	mov	x22, x11
100247154:     	bl	0x100b3bbec <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100247158:     	ldr	x12, [sp, #0x20]
10024715c:     	mov	x11, x22
100247160:     	ldr	x26, [sp, #0x190]
100247164:     	b	0x100247094 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xefc>
100247168:     	add	x8, sp, #0x188
10024716c:     	add	x0, x8, #0x18
100247170:     	mov	x23, x11
100247174:     	bl	0x100b3bbec <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100247178:     	mov	x11, x23
10024717c:     	b	0x1002470b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf18>
100247180:     	adrp	x0, 0x10104d000 <_out_buf+0x3988>
100247184:     	add	x0, x0, #0x840
100247188:     	bl	0x100b216c0 <__RINvMs1_NtNtCs4KWsSNcQanT_9once_cell4race8once_boxINtB6_7OnceBoxINtNtCsctvjasLqLe9_5alloc5boxed3BoxDNtNtCs3SoQS4yp3pP_5ahash12random_state12RandomSourceNtNtCsjgY6bXVaRmE_4core6marker4SendNtB2s_4SyncEL_EE4initNtNvMs1_B6_IBN_pE11get_or_init4VoidNCINvB2_11get_or_initNCNvB1C_7get_src0E0ECs3gRpqoBkMHm_13perry_runtime>
10024718c:     	ldp	x0, x22, [x0]
100247190:     	adrp	x8, 0x10104d000 <_out_buf+0x3988>
100247194:     	add	x8, x8, #0x848
100247198:     	ldapr	x24, [x8]
10024719c:     	cbnz	x24, 0x100246644 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x4ac>
1002471a0:     	mov	x23, x0
1002471a4:     	adrp	x0, 0x10104d000 <_out_buf+0x3988>
1002471a8:     	add	x0, x0, #0x848
1002471ac:     	bl	0x100b21600 <__RINvMs1_NtNtCs4KWsSNcQanT_9once_cell4race8once_boxINtB6_7OnceBoxAAyj4_j2_E4initNtNvMs1_B6_IBN_pE11get_or_init4VoidNCINvB2_11get_or_initNCNvNtCs3SoQS4yp3pP_5ahash12random_state15get_fixed_seeds0E0ECs3gRpqoBkMHm_13perry_runtime>
1002471b0:     	mov	x24, x0
1002471b4:     	mov	x0, x23
1002471b8:     	b	0x100246644 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x4ac>
1002471bc:     	strb	wzr, [x19, #0xd4]
1002471c0:     	cmp	x27, #0x1
1002471c4:     	b.lt	0x1002471d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1038>
1002471c8:     	mov	x0, x24
1002471cc:     	bl	0x100b5eec0 <_mi_free>
1002471d0:     	ldr	x26, [sp, #0x98]
1002471d4:     	ldp	x9, x8, [x19, #0x68]
1002471d8:     	cmp	x8, x9
1002471dc:     	b.hs	0x100247264 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x10cc>
1002471e0:     	ldr	x10, [x19, #0x60]
1002471e4:     	mov	x11, #0x2600            ; =9728
1002471e8:     	movk	x11, #0x1, lsl #32
1002471ec:     	ldrb	w12, [x10, x8]
1002471f0:     	cmp	w12, #0x20
1002471f4:     	b.hi	0x100247214 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x107c>
1002471f8:     	lsr	x13, x11, x12
1002471fc:     	tbz	w13, #0x0, 0x100247214 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x107c>
100247200:     	add	x8, x8, #0x1
100247204:     	str	x8, [x19, #0x70]
100247208:     	cmp	x9, x8
10024720c:     	b.ne	0x1002471ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1054>
100247210:     	b	0x100247264 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x10cc>
100247214:     	cmp	w12, #0x7d
100247218:     	b.ne	0x100247264 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x10cc>
10024721c:     	add	x8, x8, #0x1
100247220:     	str	x8, [x19, #0x70]
100247224:     	ldr	x8, [sp, #0x188]
100247228:     	cmn	x8, #0x1
10024722c:     	b.ne	0x100247274 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x10dc>
100247230:     	ldp	w8, w9, [sp, #0x80]
100247234:     	and	w8, w8, w9
100247238:     	tbz	w8, #0x0, 0x100247328 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1190>
10024723c:     	ldr	x8, [sp, #0x70]
100247240:     	cmp	x21, x8
100247244:     	b.ne	0x100247328 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1190>
100247248:     	cmp	x26, x21
10024724c:     	b.ne	0x100247328 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1190>
100247250:     	ldp	x21, x23, [sp, #0x88]
100247254:     	cmp	x23, #0x9
100247258:     	ldr	w2, [sp, #0x64]
10024725c:     	b.lo	0x100247418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1280>
100247260:     	b	0x1002472ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1154>
100247264:     	strb	wzr, [x19, #0xd4]
100247268:     	ldr	x8, [sp, #0x188]
10024726c:     	cmn	x8, #0x1
100247270:     	b.eq	0x100247230 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1098>
100247274:     	ldp	x0, x1, [sp, #0x190]
100247278:     	cmp	x1, #0x9
10024727c:     	b.hs	0x100247304 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x116c>
100247280:     	ldr	x8, [x19, #0x78]
100247284:     	cmp	x1, x8
100247288:     	ldr	x23, [sp, #0x90]
10024728c:     	b.ne	0x1002472ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
100247290:     	ldr	x21, [x19, #0xc0]
100247294:     	cbz	x21, 0x1002472ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
100247298:     	cbz	x1, 0x1002473f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
10024729c:     	ldr	x8, [x19, #0x80]
1002472a0:     	ldr	x9, [x0]
1002472a4:     	cmp	x8, x9
1002472a8:     	b.eq	0x1002473f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1258>
1002472ac:     	mov	x24, x0
1002472b0:     	mov	x25, x1
1002472b4:     	bl	0x10032991c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
1002472b8:     	mov	x21, x0
1002472bc:     	mov	x26, x1
1002472c0:     	str	x25, [x19, #0x78]
1002472c4:     	lsl	x2, x25, #3
1002472c8:     	add	x0, x19, #0x80
1002472cc:     	mov	x1, x24
1002472d0:     	bl	0x100b61d6c <_writev+0x100b61d6c>
1002472d4:     	mov	x2, x26
1002472d8:     	str	x21, [x19, #0xc0]
1002472dc:     	str	w26, [x19, #0xd0]
1002472e0:     	cmp	x23, #0x9
1002472e4:     	ldr	x8, [sp, #0x20]
1002472e8:     	b.lo	0x100247320 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1188>
1002472ec:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002472f0:     	add	x3, x3, #0x710
1002472f4:     	mov	x0, #0x0                ; =0
1002472f8:     	mov	x1, x23
1002472fc:     	mov	w2, #0x8                ; =8
100247300:     	bl	0x100b1294c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100247304:     	bl	0x10032991c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100247308:     	mov	x21, x0
10024730c:     	mov	x2, x1
100247310:     	ldr	x23, [sp, #0x90]
100247314:     	cmp	x23, #0x9
100247318:     	ldr	x8, [sp, #0x20]
10024731c:     	b.hs	0x1002472ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1154>
100247320:     	mov	x23, x8
100247324:     	b	0x10024741c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1284>
100247328:     	ldr	x23, [sp, #0x90]
10024732c:     	cmp	x23, #0x9
100247330:     	b.hs	0x10024768c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x14f4>
100247334:     	ldr	x8, [x19, #0x78]
100247338:     	cmp	x23, x8
10024733c:     	b.ne	0x10024735c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
100247340:     	ldr	x21, [x19, #0xc0]
100247344:     	cbz	x21, 0x10024735c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
100247348:     	cbz	x23, 0x100247414 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
10024734c:     	ldr	x8, [x19, #0x80]
100247350:     	ldr	x9, [sp, #0x100]
100247354:     	cmp	x8, x9
100247358:     	b.eq	0x10024740c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1274>
10024735c:     	add	x0, sp, #0x100
100247360:     	mov	x1, x23
100247364:     	bl	0x10032991c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100247368:     	mov	x21, x0
10024736c:     	mov	x24, x1
100247370:     	str	x23, [x19, #0x78]
100247374:     	lsl	x2, x23, #3
100247378:     	add	x0, x19, #0x80
10024737c:     	add	x1, sp, #0x100
100247380:     	bl	0x100b61d6c <_writev+0x100b61d6c>
100247384:     	mov	x2, x24
100247388:     	str	x21, [x19, #0xc0]
10024738c:     	str	w24, [x19, #0xd0]
100247390:     	b	0x100247418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1280>
100247394:     	b	0x100246284 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xec>
100247398:     	sub	x0, x29, #0x68
10024739c:     	mov	x1, #0x0                ; =0
1002473a0:     	bl	0x10032991c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
1002473a4:     	mov	x2, x1
1002473a8:     	mov	x1, x0
1002473ac:     	str	xzr, [x19, #0x78]
1002473b0:     	str	x0, [x19, #0xc0]
1002473b4:     	str	w2, [x19, #0xd0]
1002473b8:     	add	x0, x19, #0x20
1002473bc:     	mov	w3, #0x8                ; =8
1002473c0:     	mov	x4, #0x0                ; =0
1002473c4:     	bl	0x1005bc7c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
1002473c8:     	mov	x19, x0
1002473cc:     	ldrb	w8, [x20, #0x20]
1002473d0:     	cbnz	w8, 0x1002476a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x150c>
1002473d4:     	ldr	x8, [x20]
1002473d8:     	cbnz	x8, 0x1002476e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1550>
1002473dc:     	ldr	x8, [x20, #0x18]
1002473e0:     	cmp	x22, x8
1002473e4:     	b.hi	0x1002474bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1324>
1002473e8:     	str	x22, [x20, #0x18]
1002473ec:     	b	0x1002474bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1324>
1002473f0:     	cmp	x1, #0x1
1002473f4:     	b.ne	0x1002474e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x134c>
1002473f8:     	ldr	w2, [x19, #0xd0]
1002473fc:     	cmp	x23, #0x9
100247400:     	ldr	x8, [sp, #0x20]
100247404:     	b.lo	0x100247320 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1188>
100247408:     	b	0x1002472ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1154>
10024740c:     	cmp	x23, #0x1
100247410:     	b.ne	0x100247588 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x13f0>
100247414:     	ldr	w2, [x19, #0xd0]
100247418:     	add	x28, sp, #0x148
10024741c:     	add	x0, x19, #0x20
100247420:     	mov	x1, x21
100247424:     	mov	x3, x28
100247428:     	mov	x4, x23
10024742c:     	bl	0x1005bc7c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
100247430:     	mov	x19, x0
100247434:     	ldrb	w8, [x20, #0x20]
100247438:     	cbnz	w8, 0x100247664 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x14cc>
10024743c:     	ldr	x8, [x20]
100247440:     	cbnz	x8, 0x1002476e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1550>
100247444:     	ldr	x8, [x20, #0x18]
100247448:     	cmp	x22, x8
10024744c:     	b.hi	0x100247454 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x12bc>
100247450:     	str	x22, [x20, #0x18]
100247454:     	ldr	x8, [sp, #0x188]
100247458:     	cmn	x8, #0x1
10024745c:     	b.eq	0x1002474bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1324>
100247460:     	cbz	x8, 0x10024746c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x12d4>
100247464:     	ldr	x0, [sp, #0x190]
100247468:     	bl	0x100b5eec0 <_mi_free>
10024746c:     	ldr	x8, [sp, #0x1a0]
100247470:     	cbz	x8, 0x10024747c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x12e4>
100247474:     	ldr	x0, [sp, #0x1a8]
100247478:     	bl	0x100b5eec0 <_mi_free>
10024747c:     	ldr	x20, [sp, #0x1b8]
100247480:     	cmn	x20, #0x1
100247484:     	b.eq	0x1002474bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1324>
100247488:     	ldr	x9, [sp, #0x1d8]
10024748c:     	cbz	x9, 0x1002474b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1318>
100247490:     	lsl	x8, x9, #4
100247494:     	add	x9, x8, x9
100247498:     	cmn	x9, #0x19
10024749c:     	b.eq	0x1002474b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1318>
1002474a0:     	ldr	x9, [sp, #0x1d0]
1002474a4:     	sub	x8, x9, x8
1002474a8:     	sub	x0, x8, #0x10
1002474ac:     	bl	0x100b5eec0 <_mi_free>
1002474b0:     	cbz	x20, 0x1002474bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1324>
1002474b4:     	ldr	x0, [sp, #0x1c0]
1002474b8:     	bl	0x100b5eec0 <_mi_free>
1002474bc:     	mov	x0, #0x7ffd000000000000 ; =9222527611924643840
1002474c0:     	bfxil	x0, x19, #0, #48
1002474c4:     	add	sp, sp, #0x2e0
1002474c8:     	ldp	x29, x30, [sp, #0x50]
1002474cc:     	ldp	x20, x19, [sp, #0x40]
1002474d0:     	ldp	x22, x21, [sp, #0x30]
1002474d4:     	ldp	x24, x23, [sp, #0x20]
1002474d8:     	ldp	x26, x25, [sp, #0x10]
1002474dc:     	ldp	x28, x27, [sp], #0x60
1002474e0:     	ret
1002474e4:     	ldr	x8, [x19, #0x88]
1002474e8:     	ldr	x9, [x0, #0x8]
1002474ec:     	cmp	x8, x9
1002474f0:     	b.ne	0x1002472ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
1002474f4:     	cmp	x1, #0x2
1002474f8:     	b.eq	0x1002473f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
1002474fc:     	ldr	x8, [x19, #0x90]
100247500:     	ldr	x9, [x0, #0x10]
100247504:     	cmp	x8, x9
100247508:     	b.ne	0x1002472ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
10024750c:     	cmp	x1, #0x3
100247510:     	b.eq	0x1002473f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
100247514:     	ldr	x8, [x19, #0x98]
100247518:     	ldr	x9, [x0, #0x18]
10024751c:     	cmp	x8, x9
100247520:     	b.ne	0x1002472ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
100247524:     	cmp	x1, #0x4
100247528:     	b.eq	0x1002473f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
10024752c:     	ldr	x8, [x19, #0xa0]
100247530:     	ldr	x9, [x0, #0x20]
100247534:     	cmp	x8, x9
100247538:     	b.ne	0x1002472ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
10024753c:     	cmp	x1, #0x5
100247540:     	b.eq	0x1002473f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
100247544:     	ldr	x8, [x19, #0xa8]
100247548:     	ldr	x9, [x0, #0x28]
10024754c:     	cmp	x8, x9
100247550:     	b.ne	0x1002472ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
100247554:     	cmp	x1, #0x6
100247558:     	b.eq	0x1002473f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
10024755c:     	ldr	x8, [x19, #0xb0]
100247560:     	ldr	x9, [x0, #0x30]
100247564:     	cmp	x8, x9
100247568:     	b.ne	0x1002472ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
10024756c:     	cmp	x1, #0x7
100247570:     	b.eq	0x1002473f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
100247574:     	ldr	x8, [x19, #0xb8]
100247578:     	ldr	x9, [x0, #0x38]
10024757c:     	cmp	x8, x9
100247580:     	b.ne	0x1002472ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
100247584:     	b	0x1002473f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
100247588:     	ldr	x8, [x19, #0x88]
10024758c:     	ldr	x9, [sp, #0x108]
100247590:     	cmp	x8, x9
100247594:     	b.ne	0x10024735c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
100247598:     	cmp	x23, #0x2
10024759c:     	b.eq	0x100247414 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
1002475a0:     	ldr	x8, [x19, #0x90]
1002475a4:     	ldr	x9, [sp, #0x110]
1002475a8:     	cmp	x8, x9
1002475ac:     	b.ne	0x10024735c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
1002475b0:     	cmp	x23, #0x3
1002475b4:     	b.eq	0x100247414 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
1002475b8:     	ldr	x8, [x19, #0x98]
1002475bc:     	ldr	x9, [sp, #0x118]
1002475c0:     	cmp	x8, x9
1002475c4:     	b.ne	0x10024735c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
1002475c8:     	cmp	x23, #0x4
1002475cc:     	b.eq	0x100247414 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
1002475d0:     	ldr	x8, [x19, #0xa0]
1002475d4:     	ldr	x9, [sp, #0x120]
1002475d8:     	cmp	x8, x9
1002475dc:     	b.ne	0x10024735c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
1002475e0:     	cmp	x23, #0x5
1002475e4:     	b.eq	0x100247414 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
1002475e8:     	ldr	x8, [x19, #0xa8]
1002475ec:     	ldr	x9, [sp, #0x128]
1002475f0:     	cmp	x8, x9
1002475f4:     	b.ne	0x10024735c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
1002475f8:     	cmp	x23, #0x6
1002475fc:     	b.eq	0x100247414 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
100247600:     	ldr	x8, [x19, #0xb0]
100247604:     	ldr	x9, [sp, #0x130]
100247608:     	cmp	x8, x9
10024760c:     	b.ne	0x10024735c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
100247610:     	cmp	x23, #0x7
100247614:     	b.eq	0x100247414 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
100247618:     	ldr	x8, [x19, #0xb8]
10024761c:     	ldr	x9, [sp, #0x138]
100247620:     	cmp	x8, x9
100247624:     	b.ne	0x10024735c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
100247628:     	b	0x100247414 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
10024762c:     	cmp	w8, #0x1
100247630:     	b.ne	0x1002476ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1514>
100247634:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100247638:     	add	x1, x1, #0x998
10024763c:     	mov	x0, x20
100247640:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100247644:     	strb	wzr, [x20, #0x20]
100247648:     	ldr	x8, [x20]
10024764c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100247650:     	cmp	x8, x9
100247654:     	b.lo	0x1002462b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c>
100247658:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
10024765c:     	add	x0, x0, #0x4a0
100247660:     	bl	0x100b1265c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100247664:     	cmp	w8, #0x2
100247668:     	b.eq	0x1002476ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1514>
10024766c:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100247670:     	add	x1, x1, #0x998
100247674:     	mov	x0, x20
100247678:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10024767c:     	strb	wzr, [x20, #0x20]
100247680:     	ldr	x8, [x20]
100247684:     	cbz	x8, 0x100247444 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x12ac>
100247688:     	b	0x1002476e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1550>
10024768c:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100247690:     	add	x3, x3, #0x6f8
100247694:     	mov	x0, #0x0                ; =0
100247698:     	mov	x1, x23
10024769c:     	mov	w2, #0x8                ; =8
1002476a0:     	bl	0x100b1294c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1002476a4:     	cmp	w8, #0x2
1002476a8:     	b.ne	0x1002476cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1534>
1002476ac:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
1002476b0:     	add	x0, x0, #0xc18
1002476b4:     	bl	0x100b5851c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
1002476b8:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002476bc:     	add	x3, x3, #0x6b0
1002476c0:     	mov	x0, #0x0                ; =0
1002476c4:     	mov	w2, #0x8                ; =8
1002476c8:     	bl	0x100b1294c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1002476cc:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
1002476d0:     	add	x1, x1, #0x998
1002476d4:     	mov	x0, x20
1002476d8:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1002476dc:     	strb	wzr, [x20, #0x20]
1002476e0:     	ldr	x8, [x20]
1002476e4:     	cbz	x8, 0x1002473dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1244>
1002476e8:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
1002476ec:     	add	x0, x0, #0x488
1002476f0:     	bl	0x100b1262c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1002476f4:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002476f8:     	add	x0, x0, #0x668
1002476fc:     	bl	0x100b126f0 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100247700:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100247704:     	add	x2, x2, #0x800
100247708:     	mov	x0, x27
10024770c:     	mov	w1, #0x8                ; =8
100247710:     	bl	0x100b1278c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100247714:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100247718:     	add	x2, x2, #0xab8
10024771c:     	mov	x0, x24
100247720:     	bl	0x100b1278c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100247724:     	adrp	x2, 0x100f02000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x10ed0>
100247728:     	add	x2, x2, #0x320
10024772c:     	mov	x0, x24
100247730:     	bl	0x100b1278c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100247734:     	mov	w0, #0x8                ; =8
100247738:     	mov	w1, #0x1108             ; =4360
10024773c:     	bl	0x100b12268 <__RNvNtCsctvjasLqLe9_5alloc5alloc18handle_alloc_error>
100247740:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100247744:     	add	x2, x2, #0x6e0
100247748:     	mov	x0, x24
10024774c:     	bl	0x100b1278c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100247750:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100247754:     	add	x2, x2, #0x6c8
100247758:     	mov	x0, x24
10024775c:     	bl	0x100b1278c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100247760:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100247764:     	add	x2, x2, #0x698
100247768:     	mov	w1, #0x8                ; =8
10024776c:     	bl	0x100b1278c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100247770:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100247774:     	add	x2, x2, #0x680
100247778:     	mov	w1, #0x8                ; =8
10024777c:     	bl	0x100b1278c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100247780:     	mov	w0, #0x8                ; =8
100247784:     	mov	w1, #0x80               ; =128
100247788:     	bl	0x100b12280 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
