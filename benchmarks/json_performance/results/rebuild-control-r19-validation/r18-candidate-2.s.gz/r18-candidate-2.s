
benchmarks/json_performance/.work/tape-batch-r18/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001002468c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value>:
1002468c8:     	sub	sp, sp, #0x60
1002468cc:     	stp	x24, x23, [sp, #0x20]
1002468d0:     	stp	x22, x21, [sp, #0x30]
1002468d4:     	stp	x20, x19, [sp, #0x40]
1002468d8:     	stp	x29, x30, [sp, #0x50]
1002468dc:     	add	x29, sp, #0x50
1002468e0:     	mov	x21, x0
1002468e4:     	ldr	x23, [x0, #0x70]
1002468e8:     	ldp	x8, x9, [x0]
1002468ec:     	cmp	x8, #0x0
1002468f0:     	ccmp	x9, x23, #0x0, ne
1002468f4:     	b.eq	0x100246920 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x58>
1002468f8:     	add	x0, sp, #0x8
1002468fc:     	mov	x1, x21
100246900:     	bl	0x100246478 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes>
100246904:     	ldr	x22, [sp, #0x8]
100246908:     	cmn	x22, #0x2
10024690c:     	b.ne	0x100246948 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x80>
100246910:     	strb	wzr, [x21, #0xd4]
100246914:     	mov	x0, #0x2                ; =2
100246918:     	movk	x0, #0x7ffc, lsl #48
10024691c:     	b	0x100246930 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100246920:     	ldp	x8, x9, [x21, #0x10]
100246924:     	str	x8, [x21, #0x70]
100246928:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
10024692c:     	bfxil	x0, x9, #0, #48
100246930:     	ldp	x29, x30, [sp, #0x50]
100246934:     	ldp	x20, x19, [sp, #0x40]
100246938:     	ldp	x22, x21, [sp, #0x30]
10024693c:     	ldp	x24, x23, [sp, #0x20]
100246940:     	add	sp, sp, #0x60
100246944:     	ret
100246948:     	ldp	x20, x19, [sp, #0x10]
10024694c:     	cmp	x19, #0x6
100246950:     	b.hs	0x1002469e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x118>
100246954:     	subs	x8, x19, #0x3
100246958:     	b.lo	0x100246a0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
10024695c:     	ldrb	w9, [x20]
100246960:     	cmp	w9, #0xed
100246964:     	b.ne	0x100246984 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xbc>
100246968:     	ldrb	w9, [x20, #0x1]
10024696c:     	and	w9, w9, #0xe0
100246970:     	cmp	w9, #0xa0
100246974:     	b.ne	0x100246984 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xbc>
100246978:     	ldrsb	w9, [x20, #0x2]
10024697c:     	cmn	w9, #0x40
100246980:     	b.lt	0x1002469e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x118>
100246984:     	cbz	x8, 0x100246a0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100246988:     	ldrb	w9, [x20, #0x1]
10024698c:     	cmp	w9, #0xed
100246990:     	b.ne	0x1002469b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xe8>
100246994:     	ldrb	w9, [x20, #0x2]
100246998:     	and	w9, w9, #0xe0
10024699c:     	cmp	w9, #0xa0
1002469a0:     	b.ne	0x1002469b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xe8>
1002469a4:     	ldrsb	w9, [x20, #0x3]
1002469a8:     	cmn	w9, #0x40
1002469ac:     	b.lt	0x1002469e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x118>
1002469b0:     	cmp	x8, #0x1
1002469b4:     	b.eq	0x100246a0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
1002469b8:     	ldrb	w8, [x20, #0x2]
1002469bc:     	cmp	w8, #0xed
1002469c0:     	b.ne	0x100246a0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
1002469c4:     	ldrb	w8, [x20, #0x3]
1002469c8:     	and	w8, w8, #0xe0
1002469cc:     	cmp	w8, #0xa0
1002469d0:     	b.ne	0x100246a0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
1002469d4:     	ldrsb	w8, [x20, #0x4]
1002469d8:     	cmn	w8, #0x40
1002469dc:     	b.ge	0x100246a0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
1002469e0:     	cmn	x22, #0x1
1002469e4:     	b.eq	0x100246a28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x160>
1002469e8:     	mov	x0, x20
1002469ec:     	mov	x1, x19
1002469f0:     	bl	0x10034c470 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
1002469f4:     	mov	x8, x0
1002469f8:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
1002469fc:     	bfxil	x0, x8, #0, #48
100246a00:     	cmp	x22, #0x1
100246a04:     	b.ge	0x100246bb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2f0>
100246a08:     	b	0x100246930 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100246a0c:     	cbz	x19, 0x100246aec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x224>
100246a10:     	cmp	x19, #0x4
100246a14:     	b.hs	0x100246af4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x22c>
100246a18:     	mov	x10, #0x0               ; =0
100246a1c:     	mov	x9, #0x0                ; =0
100246a20:     	mov	x8, x20
100246a24:     	b	0x100246b84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2bc>
100246a28:     	add	x0, x21, #0x20
100246a2c:     	mov	x1, x20
100246a30:     	mov	x2, x19
100246a34:     	bl	0x1005eb984 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>
100246a38:     	ldr	x22, [x21, #0x68]
100246a3c:     	cmp	x22, #0x200, lsl #12    ; =0x200000
100246a40:     	b.hi	0x100246c2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100246a44:     	cmp	x19, #0x100
100246a48:     	b.lo	0x100246c2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100246a4c:     	cbz	x0, 0x100246c2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100246a50:     	ldr	x20, [x21, #0xc8]
100246a54:     	cbz	x20, 0x100246c2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100246a58:     	ldr	x21, [x21, #0x70]
100246a5c:     	sub	x8, x22, x22, lsr #1
100246a60:     	cmp	x19, x8
100246a64:     	orr	x8, x21, x23
100246a68:     	and	x8, x8, #0xffffffff00000000
100246a6c:     	ccmp	x8, #0x0, #0x0, hs
100246a70:     	b.ne	0x100246c2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100246a74:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
100246a78:     	ldr	w19, [x8, #0x560]
100246a7c:     	cmp	w19, #0x300
100246a80:     	b.hs	0x100246c58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x390>
100246a84:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100246a88:     	ldr	x8, [x8, #0x48]
100246a8c:     	cmn	x8, #0x1
100246a90:     	b.eq	0x100246c3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x374>
100246a94:     	mrs	x9, TPIDRRO_EL0
100246a98:     	and	x9, x9, #0xfffffffffffffff8
100246a9c:     	ldr	x8, [x9, x8, lsl #3]
100246aa0:     	cbz	x8, 0x100246c3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x374>
100246aa4:     	add	x8, x8, x19, lsl #3
100246aa8:     	ldr	x19, [x8, #0x1e8]
100246aac:     	cbz	x19, 0x100246c58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x390>
100246ab0:     	ldr	x8, [x19]
100246ab4:     	cbnz	x8, 0x100246c78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3b0>
100246ab8:     	mov	x8, #-0x1               ; =-1
100246abc:     	str	x8, [x19]
100246ac0:     	ldrb	w8, [x19, #0x24]
100246ac4:     	cmp	w8, #0x2
100246ac8:     	b.eq	0x100246bcc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x304>
100246acc:     	ldr	x8, [x19, #0x8]
100246ad0:     	cmp	x8, x20
100246ad4:     	b.ne	0x100246bcc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x304>
100246ad8:     	ldr	w8, [x19, #0x18]
100246adc:     	cmp	w8, w22
100246ae0:     	b.ne	0x100246bcc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x304>
100246ae4:     	mov	x8, #0x0                ; =0
100246ae8:     	b	0x100246c28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x360>
100246aec:     	mov	x10, #0x0               ; =0
100246af0:     	b	0x100246ba4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2dc>
100246af4:     	and	x9, x19, #0x4
100246af8:     	add	x8, x20, x9
100246afc:     	adrp	x10, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5060>
100246b00:     	ldr	q0, [x10, #0x810]
100246b04:     	adrp	x10, 0x100c3a000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x338fa>
100246b08:     	ldr	q2, [x10, #0x680]
100246b0c:     	movi.2d	v1, #0000000000000000
100246b10:     	movi.2d	v3, #0x000000000000ff
100246b14:     	mov	w10, #0x4               ; =4
100246b18:     	dup.2d	v4, x10
100246b1c:     	mov	x10, x20
100246b20:     	and	x11, x19, #0x4
100246b24:     	movi.2d	v5, #0000000000000000
100246b28:     	ldr	s6, [x10], #0x4
100246b2c:     	ushll.8h	v6, v6, #0x0
100246b30:     	ushll.4s	v6, v6, #0x0
100246b34:     	ushll2.2d	v7, v6, #0x0
100246b38:     	and.16b	v7, v7, v3
100246b3c:     	ushll.2d	v6, v6, #0x0
100246b40:     	and.16b	v6, v6, v3
100246b44:     	shl.2d	v16, v0, #0x3
100246b48:     	shl.2d	v17, v2, #0x3
100246b4c:     	ushl.2d	v6, v6, v17
100246b50:     	ushl.2d	v7, v7, v16
100246b54:     	orr.16b	v1, v7, v1
100246b58:     	orr.16b	v5, v6, v5
100246b5c:     	add.2d	v0, v0, v4
100246b60:     	add.2d	v2, v2, v4
100246b64:     	subs	x11, x11, #0x4
100246b68:     	b.ne	0x100246b28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x260>
100246b6c:     	orr.16b	v0, v5, v1
100246b70:     	mov	d1, v0[1]
100246b74:     	orr.8b	v0, v0, v1
100246b78:     	fmov	x10, d0
100246b7c:     	cmp	x19, x9
100246b80:     	b.eq	0x100246ba4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2dc>
100246b84:     	add	x11, x20, x19
100246b88:     	lsl	x9, x9, #3
100246b8c:     	ldrb	w12, [x8], #0x1
100246b90:     	lsl	x12, x12, x9
100246b94:     	orr	x10, x12, x10
100246b98:     	add	x9, x9, #0x8
100246b9c:     	cmp	x8, x11
100246ba0:     	b.ne	0x100246b8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2c4>
100246ba4:     	orr	x8, x10, x19, lsl #40
100246ba8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100246bac:     	orr	x0, x8, x9
100246bb0:     	cmp	x22, #0x1
100246bb4:     	b.lt	0x100246930 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100246bb8:     	mov	x19, x0
100246bbc:     	mov	x0, x20
100246bc0:     	bl	0x100b5fd00 <_mi_free>
100246bc4:     	mov	x0, x19
100246bc8:     	b	0x100246930 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100246bcc:     	stp	x20, x0, [x19, #0x8]
100246bd0:     	stp	w22, w23, [x19, #0x18]
100246bd4:     	str	w21, [x19, #0x20]
100246bd8:     	strb	wzr, [x19, #0x24]
100246bdc:     	adrp	x21, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
100246be0:     	ldr	w8, [x21, #0x864]
100246be4:     	cbz	w8, 0x100246c00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x338>
100246be8:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100246bec:     	bfxil	x8, x20, #0, #48
100246bf0:     	mov	x20, x0
100246bf4:     	mov	x0, x8
100246bf8:     	bl	0x1004773f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
100246bfc:     	mov	x0, x20
100246c00:     	ldr	w8, [x21, #0x864]
100246c04:     	cbz	w8, 0x100246c20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x358>
100246c08:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100246c0c:     	bfxil	x8, x0, #0, #48
100246c10:     	mov	x20, x0
100246c14:     	mov	x0, x8
100246c18:     	bl	0x1004773f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
100246c1c:     	mov	x0, x20
100246c20:     	ldr	x8, [x19]
100246c24:     	add	x8, x8, #0x1
100246c28:     	str	x8, [x19]
100246c2c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100246c30:     	bfxil	x8, x0, #0, #48
100246c34:     	mov	x0, x8
100246c38:     	b	0x100246930 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100246c3c:     	mov	x24, x0
100246c40:     	bl	0x100b4013c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100246c44:     	mov	x8, x0
100246c48:     	mov	x0, x24
100246c4c:     	add	x8, x8, x19, lsl #3
100246c50:     	ldr	x19, [x8, #0x1e8]
100246c54:     	cbnz	x19, 0x100246ab0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x1e8>
100246c58:     	str	x0, [sp]
100246c5c:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x2dc8>
100246c60:     	add	x0, x0, #0x90
100246c64:     	bl	0x100b3d95c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100246c68:     	mov	x19, x0
100246c6c:     	ldr	x0, [sp]
100246c70:     	ldr	x8, [x19]
100246c74:     	cbz	x8, 0x100246ab8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x1f0>
100246c78:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100246c7c:     	add	x0, x0, #0xcf8
100246c80:     	bl	0x100b132ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
		...
