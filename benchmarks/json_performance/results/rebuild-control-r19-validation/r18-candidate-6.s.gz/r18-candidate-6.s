
benchmarks/json_performance/.work/tape-batch-r18/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001005eb984 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>:
1005eb984:     	sub	sp, sp, #0x60
1005eb988:     	stp	x24, x23, [sp, #0x20]
1005eb98c:     	stp	x22, x21, [sp, #0x30]
1005eb990:     	stp	x20, x19, [sp, #0x40]
1005eb994:     	stp	x29, x30, [sp, #0x50]
1005eb998:     	add	x29, sp, #0x50
1005eb99c:     	mov	x19, x1
1005eb9a0:     	cmp	x2, #0x40
1005eb9a4:     	b.hs	0x1005ebad8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x154>
1005eb9a8:     	ands	x8, x2, #0x38
1005eb9ac:     	b.eq	0x1005eb9d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4c>
1005eb9b0:     	and	x9, x2, #0x38
1005eb9b4:     	neg	x9, x9
1005eb9b8:     	mov	x10, x19
1005eb9bc:     	ldr	x11, [x10], #0x8
1005eb9c0:     	tst	x11, #0x8080808080808080
1005eb9c4:     	b.ne	0x1005eba64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eb9c8:     	adds	x9, x9, #0x8
1005eb9cc:     	b.ne	0x1005eb9bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x38>
1005eb9d0:     	mov	x20, x2
1005eb9d4:     	and	x9, x2, #0x7
1005eb9d8:     	cbz	x9, 0x1005ebba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb9dc:     	add	x8, x19, x8
1005eb9e0:     	ldrsb	w10, [x8]
1005eb9e4:     	tbnz	w10, #0x1f, 0x1005eba64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eb9e8:     	mov	x20, x2
1005eb9ec:     	cmp	x9, #0x1
1005eb9f0:     	b.eq	0x1005ebba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eb9f4:     	ldrsb	w10, [x8, #0x1]
1005eb9f8:     	tbnz	w10, #0x1f, 0x1005eba64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eb9fc:     	mov	x20, x2
1005eba00:     	cmp	x9, #0x2
1005eba04:     	b.eq	0x1005ebba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eba08:     	ldrsb	w10, [x8, #0x2]
1005eba0c:     	tbnz	w10, #0x1f, 0x1005eba64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eba10:     	mov	x20, x2
1005eba14:     	cmp	x9, #0x3
1005eba18:     	b.eq	0x1005ebba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eba1c:     	ldrsb	w10, [x8, #0x3]
1005eba20:     	tbnz	w10, #0x1f, 0x1005eba64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eba24:     	mov	x20, x2
1005eba28:     	cmp	x9, #0x4
1005eba2c:     	b.eq	0x1005ebba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eba30:     	ldrsb	w10, [x8, #0x4]
1005eba34:     	tbnz	w10, #0x1f, 0x1005eba64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eba38:     	mov	x20, x2
1005eba3c:     	cmp	x9, #0x5
1005eba40:     	b.eq	0x1005ebba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eba44:     	ldrsb	w10, [x8, #0x5]
1005eba48:     	tbnz	w10, #0x1f, 0x1005eba64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005eba4c:     	mov	x20, x2
1005eba50:     	cmp	x9, #0x6
1005eba54:     	b.eq	0x1005ebba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eba58:     	ldrsb	w8, [x8, #0x6]
1005eba5c:     	mov	x20, x2
1005eba60:     	tbz	w8, #0x1f, 0x1005ebba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eba64:     	cbz	w2, 0x1005ebb64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1e0>
1005eba68:     	mov	x20, x2
1005eba6c:     	mov	w21, w2
1005eba70:     	cbz	x21, 0x1005ebba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005eba74:     	mov	x8, x19
1005eba78:     	ands	x9, x2, #0x3
1005eba7c:     	b.eq	0x1005eba98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x114>
1005eba80:     	mov	x8, x19
1005eba84:     	ldrsb	w10, [x8]
1005eba88:     	tbnz	w10, #0x1f, 0x1005ebb7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005eba8c:     	add	x8, x8, #0x1
1005eba90:     	subs	x9, x9, #0x1
1005eba94:     	b.ne	0x1005eba84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x100>
1005eba98:     	mov	x20, x2
1005eba9c:     	cmp	x21, #0x4
1005ebaa0:     	b.lo	0x1005ebba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005ebaa4:     	add	x9, x19, x21
1005ebaa8:     	ldrsb	w10, [x8]
1005ebaac:     	tbnz	w10, #0x1f, 0x1005ebb7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005ebab0:     	ldrsb	w10, [x8, #0x1]
1005ebab4:     	tbnz	w10, #0x1f, 0x1005ebb7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005ebab8:     	ldrsb	w10, [x8, #0x2]
1005ebabc:     	tbnz	w10, #0x1f, 0x1005ebb7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005ebac0:     	ldrsb	w10, [x8, #0x3]
1005ebac4:     	tbnz	w10, #0x1f, 0x1005ebb7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005ebac8:     	add	x8, x8, #0x4
1005ebacc:     	cmp	x8, x9
1005ebad0:     	b.ne	0x1005ebaa8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x124>
1005ebad4:     	b	0x1005ebb5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1d8>
1005ebad8:     	and	x8, x2, #0x7fffffffffffffc0
1005ebadc:     	add	x8, x19, x8
1005ebae0:     	mov	x9, x19
1005ebae4:     	ldp	q0, q1, [x9]
1005ebae8:     	ldp	q2, q3, [x9, #0x20]
1005ebaec:     	orr.16b	v0, v1, v0
1005ebaf0:     	orr.16b	v1, v2, v3
1005ebaf4:     	orr.16b	v0, v0, v1
1005ebaf8:     	umaxv.16b	b0, v0
1005ebafc:     	fmov	w10, s0
1005ebb00:     	tbnz	w10, #0x7, 0x1005eba64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005ebb04:     	add	x9, x9, #0x40
1005ebb08:     	cmp	x9, x8
1005ebb0c:     	b.ne	0x1005ebae4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x160>
1005ebb10:     	ands	x9, x2, #0x30
1005ebb14:     	b.eq	0x1005ebb38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1b4>
1005ebb18:     	mov	x10, x9
1005ebb1c:     	mov	x11, x8
1005ebb20:     	ldr	q0, [x11], #0x10
1005ebb24:     	umaxv.16b	b0, v0
1005ebb28:     	fmov	w12, s0
1005ebb2c:     	tbnz	w12, #0x7, 0x1005eba64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005ebb30:     	subs	x10, x10, #0x10
1005ebb34:     	b.ne	0x1005ebb20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x19c>
1005ebb38:     	mov	x20, x2
1005ebb3c:     	and	x10, x2, #0xf
1005ebb40:     	cbz	x10, 0x1005ebba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005ebb44:     	add	x8, x8, x9
1005ebb48:     	ldrsb	w9, [x8]
1005ebb4c:     	tbnz	w9, #0x1f, 0x1005eba64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005ebb50:     	add	x8, x8, #0x1
1005ebb54:     	subs	x10, x10, #0x1
1005ebb58:     	b.ne	0x1005ebb48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1c4>
1005ebb5c:     	mov	x20, x2
1005ebb60:     	b	0x1005ebba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005ebb64:     	mov	w20, #0x0               ; =0
1005ebb68:     	mov	w8, #0x14               ; =20
1005ebb6c:     	orr	x8, x2, x8
1005ebb70:     	ldr	x9, [x0]
1005ebb74:     	cbnz	x9, 0x1005ebc4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x2c8>
1005ebb78:     	b	0x1005ebc88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005ebb7c:     	mov	x22, x0
1005ebb80:     	mov	x23, x2
1005ebb84:     	cmp	w2, #0x3f
1005ebb88:     	b.ls	0x1005ebcd4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x350>
1005ebb8c:     	mov	x0, x19
1005ebb90:     	mov	x1, x21
1005ebb94:     	bl	0x1005eb3a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
1005ebb98:     	mov	x20, x0
1005ebb9c:     	mov	x2, x23
1005ebba0:     	mov	x0, x22
1005ebba4:     	lsr	w8, w2, #19
1005ebba8:     	cbz	w8, 0x1005ebc40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x2bc>
1005ebbac:     	mov	w23, w2
1005ebbb0:     	add	x0, x23, #0x14
1005ebbb4:     	mov	w1, #0x3                ; =3
1005ebbb8:     	mov	x22, x2
1005ebbbc:     	bl	0x100459040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
1005ebbc0:     	mov	x21, x0
1005ebbc4:     	stp	w20, w22, [x0]
1005ebbc8:     	str	w22, [x0, #0x8]
1005ebbcc:     	mov	x8, #0x200000000        ; =8589934592
1005ebbd0:     	stur	x8, [x0, #0xc]
1005ebbd4:     	add	x0, x0, #0x14
1005ebbd8:     	mov	x1, x19
1005ebbdc:     	mov	x2, x22
1005ebbe0:     	bl	0x100b62bac <_writev+0x100b62bac>
1005ebbe4:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
1005ebbe8:     	ldr	w19, [x8, #0x590]
1005ebbec:     	cmp	w19, #0x300
1005ebbf0:     	b.hs	0x1005ebdd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x454>
1005ebbf4:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1005ebbf8:     	ldr	x8, [x8, #0x48]
1005ebbfc:     	cmn	x8, #0x1
1005ebc00:     	b.eq	0x1005ebdc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x444>
1005ebc04:     	mrs	x9, TPIDRRO_EL0
1005ebc08:     	and	x9, x9, #0xfffffffffffffff8
1005ebc0c:     	ldr	x0, [x9, x8, lsl #3]
1005ebc10:     	cbz	x0, 0x1005ebdc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x444>
1005ebc14:     	add	x8, x0, x19, lsl #3
1005ebc18:     	ldr	x0, [x8, #0x1e8]
1005ebc1c:     	cbz	x0, 0x1005ebdd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x454>
1005ebc20:     	ldr	x8, [x0]
1005ebc24:     	adds	x8, x8, x23
1005ebc28:     	csinv	x8, x8, xzr, lo
1005ebc2c:     	str	x8, [x0]
1005ebc30:     	lsr	x8, x8, #25
1005ebc34:     	cbz	x8, 0x1005ebcb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x334>
1005ebc38:     	bl	0x10045ff74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
1005ebc3c:     	b	0x1005ebcb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x334>
1005ebc40:     	add	x8, x2, #0x14
1005ebc44:     	ldr	x9, [x0]
1005ebc48:     	cbz	x9, 0x1005ebc88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005ebc4c:     	add	x9, x8, #0xf
1005ebc50:     	and	x9, x9, #0xfffffffffffffff8
1005ebc54:     	cmp	x9, #0x4, lsl #12       ; =0x4000
1005ebc58:     	b.hi	0x1005ebc88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005ebc5c:     	ldr	x10, [x0, #0x10]
1005ebc60:     	ldrb	w10, [x10]
1005ebc64:     	tbnz	w10, #0x0, 0x1005ebc88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005ebc68:     	ldr	x10, [x0, #0x8]
1005ebc6c:     	ldp	x11, x12, [x10, #0x8]
1005ebc70:     	add	x11, x11, #0x7
1005ebc74:     	and	x11, x11, #0xfffffffffffffff8
1005ebc78:     	subs	x12, x12, x11
1005ebc7c:     	csel	x12, xzr, x12, lo
1005ebc80:     	cmp	x9, x12
1005ebc84:     	b.ls	0x1005ebd60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x3dc>
1005ebc88:     	mov	x0, x2
1005ebc8c:     	mov	x22, x2
1005ebc90:     	bl	0x10034be2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
1005ebc94:     	mov	x21, x0
1005ebc98:     	mov	x0, x1
1005ebc9c:     	stp	w20, w22, [x21]
1005ebca0:     	str	w22, [x21, #0x8]
1005ebca4:     	mov	x8, #0x200000000        ; =8589934592
1005ebca8:     	stur	x8, [x21, #0xc]
1005ebcac:     	mov	x1, x19
1005ebcb0:     	mov	x2, x22
1005ebcb4:     	bl	0x100b62bac <_writev+0x100b62bac>
1005ebcb8:     	mov	x0, x21
1005ebcbc:     	ldp	x29, x30, [sp, #0x50]
1005ebcc0:     	ldp	x20, x19, [sp, #0x40]
1005ebcc4:     	ldp	x22, x21, [sp, #0x30]
1005ebcc8:     	ldp	x24, x23, [sp, #0x20]
1005ebccc:     	add	sp, sp, #0x60
1005ebcd0:     	ret
1005ebcd4:     	add	x8, sp, #0x8
1005ebcd8:     	mov	x0, x19
1005ebcdc:     	mov	x1, x21
1005ebce0:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
1005ebce4:     	ldr	x8, [sp, #0x8]
1005ebce8:     	cbz	x8, 0x1005ebda0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x41c>
1005ebcec:     	mov	w20, #0x0               ; =0
1005ebcf0:     	mov	x8, #0x0                ; =0
1005ebcf4:     	mov	w9, #0x2                ; =2
1005ebcf8:     	mov	w10, #0x3               ; =3
1005ebcfc:     	mov	w11, #0x4               ; =4
1005ebd00:     	mov	x2, x23
1005ebd04:     	mov	x0, x22
1005ebd08:     	b	0x1005ebd20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x39c>
1005ebd0c:     	add	w20, w20, #0x1
1005ebd10:     	mov	w12, #0x1               ; =1
1005ebd14:     	add	x8, x12, x8
1005ebd18:     	cmp	x8, x21
1005ebd1c:     	b.hs	0x1005ebba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005ebd20:     	ldrsb	w12, [x19, x8]
1005ebd24:     	tbz	w12, #0x1f, 0x1005ebd0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x388>
1005ebd28:     	and	w12, w12, #0xff
1005ebd2c:     	cmp	w12, #0xc0
1005ebd30:     	b.lo	0x1005ebd10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x38c>
1005ebd34:     	cmp	w12, #0xf0
1005ebd38:     	add	w13, w20, #0x2
1005ebd3c:     	csel	x14, x10, x11, lo
1005ebd40:     	csinc	w13, w13, w20, hs
1005ebd44:     	cmp	w12, #0xe0
1005ebd48:     	csel	x12, x9, x14, lo
1005ebd4c:     	csinc	w20, w13, w20, hs
1005ebd50:     	add	x8, x12, x8
1005ebd54:     	cmp	x8, x21
1005ebd58:     	b.lo	0x1005ebd20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x39c>
1005ebd5c:     	b	0x1005ebba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005ebd60:     	ldr	x12, [x10]
1005ebd64:     	add	x22, x12, x11
1005ebd68:     	add	x11, x11, x9
1005ebd6c:     	str	x11, [x10, #0x8]
1005ebd70:     	mov	w10, #0x203             ; =515
1005ebd74:     	stp	w10, w9, [x22]
1005ebd78:     	add	x21, x22, #0x8
1005ebd7c:     	sub	x10, x9, #0x8
1005ebd80:     	subs	x10, x10, x8
1005ebd84:     	csel	x1, xzr, x10, lo
1005ebd88:     	b.ls	0x1005ebe2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4a8>
1005ebd8c:     	cmp	x1, #0x9
1005ebd90:     	b.hs	0x1005ebe1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x498>
1005ebd94:     	add	x8, x22, x9
1005ebd98:     	stur	xzr, [x8, #-0x8]
1005ebd9c:     	b	0x1005ebe2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4a8>
1005ebda0:     	ldr	x8, [sp, #0x18]
1005ebda4:     	mov	x2, x23
1005ebda8:     	mov	x0, x22
1005ebdac:     	cbz	x8, 0x1005ebe00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x47c>
1005ebdb0:     	ldr	x9, [sp, #0x10]
1005ebdb4:     	cmp	x8, #0x8
1005ebdb8:     	b.hs	0x1005ebe08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x484>
1005ebdbc:     	mov	x10, #0x0               ; =0
1005ebdc0:     	mov	w20, #0x0               ; =0
1005ebdc4:     	b	0x1005ec0fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x778>
1005ebdc8:     	bl	0x100b4013c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005ebdcc:     	add	x8, x0, x19, lsl #3
1005ebdd0:     	ldr	x0, [x8, #0x1e8]
1005ebdd4:     	cbnz	x0, 0x1005ebc20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x29c>
1005ebdd8:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x2dc8>
1005ebddc:     	add	x0, x0, #0x168
1005ebde0:     	bl	0x100b3d95c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1005ebde4:     	ldr	x8, [x0]
1005ebde8:     	adds	x8, x8, x23
1005ebdec:     	csinv	x8, x8, xzr, lo
1005ebdf0:     	str	x8, [x0]
1005ebdf4:     	lsr	x8, x8, #25
1005ebdf8:     	cbnz	x8, 0x1005ebc38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x2b4>
1005ebdfc:     	b	0x1005ebcb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x334>
1005ebe00:     	mov	w20, #0x0               ; =0
1005ebe04:     	b	0x1005ebba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005ebe08:     	cmp	x8, #0x20
1005ebe0c:     	b.hs	0x1005ebe48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4c4>
1005ebe10:     	mov	x10, #0x0               ; =0
1005ebe14:     	mov	w20, #0x0               ; =0
1005ebe18:     	b	0x1005ec04c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x6c8>
1005ebe1c:     	add	x0, x21, x8
1005ebe20:     	mov	x23, x2
1005ebe24:     	bl	0x100b626e4 <_writev+0x100b626e4>
1005ebe28:     	mov	x2, x23
1005ebe2c:     	stp	w20, w2, [x22, #0x8]
1005ebe30:     	str	w2, [x22, #0x10]
1005ebe34:     	mov	x8, #0x200000000        ; =8589934592
1005ebe38:     	stur	x8, [x22, #0x14]
1005ebe3c:     	add	x0, x22, #0x1c
1005ebe40:     	mov	x1, x19
1005ebe44:     	b	0x1005ebcb4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x330>
1005ebe48:     	movi.2d	v0, #0000000000000000
1005ebe4c:     	and	x11, x8, #0x18
1005ebe50:     	movi.16b	v1, #0xf0
1005ebe54:     	and	x10, x8, #0xffffffffffffffe0
1005ebe58:     	movi.4s	v2, #0x2
1005ebe5c:     	add	x12, x9, #0x10
1005ebe60:     	movi.16b	v4, #0xc0
1005ebe64:     	and	x13, x8, #0xffffffffffffffe0
1005ebe68:     	movi.2d	v3, #0000000000000000
1005ebe6c:     	movi.2d	v6, #0000000000000000
1005ebe70:     	movi.2d	v5, #0000000000000000
1005ebe74:     	movi.2d	v7, #0000000000000000
1005ebe78:     	movi.2d	v16, #0000000000000000
1005ebe7c:     	movi.2d	v17, #0000000000000000
1005ebe80:     	movi.2d	v18, #0000000000000000
1005ebe84:     	ldp	q20, q19, [x12, #-0x10]
1005ebe88:     	cmhi.16b	v21, v1, v20
1005ebe8c:     	sshll2.8h	v22, v21, #0x0
1005ebe90:     	sshll2.4s	v23, v22, #0x0
1005ebe94:     	sshll.4s	v24, v22, #0x0
1005ebe98:     	sshll.8h	v21, v21, #0x0
1005ebe9c:     	sshll2.4s	v25, v21, #0x0
1005ebea0:     	sshll.4s	v26, v21, #0x0
1005ebea4:     	cmhi.16b	v27, v1, v19
1005ebea8:     	sshll2.8h	v28, v27, #0x0
1005ebeac:     	sshll2.4s	v29, v28, #0x0
1005ebeb0:     	sshll.4s	v30, v28, #0x0
1005ebeb4:     	sshll.8h	v27, v27, #0x0
1005ebeb8:     	sshll2.4s	v31, v27, #0x0
1005ebebc:     	bic.16b	v26, v2, v26
1005ebec0:     	ssubw.4s	v26, v26, v21
1005ebec4:     	bic.16b	v25, v2, v25
1005ebec8:     	ssubw2.4s	v25, v25, v21
1005ebecc:     	sshll.4s	v21, v27, #0x0
1005ebed0:     	bic.16b	v24, v2, v24
1005ebed4:     	ssubw.4s	v24, v24, v22
1005ebed8:     	bic.16b	v23, v2, v23
1005ebedc:     	ssubw2.4s	v22, v23, v22
1005ebee0:     	bic.16b	v21, v2, v21
1005ebee4:     	ssubw.4s	v21, v21, v27
1005ebee8:     	bic.16b	v23, v2, v31
1005ebeec:     	ssubw2.4s	v23, v23, v27
1005ebef0:     	bic.16b	v27, v2, v30
1005ebef4:     	ssubw.4s	v27, v27, v28
1005ebef8:     	bic.16b	v29, v2, v29
1005ebefc:     	ssubw2.4s	v28, v29, v28
1005ebf00:     	cmgt.16b	v29, v4, v20
1005ebf04:     	sshll2.8h	v30, v29, #0x0
1005ebf08:     	ushll2.4s	v31, v30, #0x0
1005ebf0c:     	bic.16b	v22, v22, v31
1005ebf10:     	cmlt.16b	v20, v20, #0
1005ebf14:     	sshll.8h	v29, v29, #0x0
1005ebf18:     	ushll.4s	v30, v30, #0x0
1005ebf1c:     	bic.16b	v24, v24, v30
1005ebf20:     	ushll2.4s	v30, v29, #0x0
1005ebf24:     	bic.16b	v25, v25, v30
1005ebf28:     	sshll2.8h	v30, v20, #0x0
1005ebf2c:     	sshll.8h	v20, v20, #0x0
1005ebf30:     	ushll.4s	v29, v29, #0x0
1005ebf34:     	bic.16b	v26, v26, v29
1005ebf38:     	sshll.4s	v29, v20, #0x0
1005ebf3c:     	and.16b	v26, v26, v29
1005ebf40:     	mvn.16b	v29, v29
1005ebf44:     	sub.4s	v26, v26, v29
1005ebf48:     	sshll2.4s	v29, v30, #0x0
1005ebf4c:     	sshll.4s	v30, v30, #0x0
1005ebf50:     	sshll2.4s	v20, v20, #0x0
1005ebf54:     	and.16b	v25, v25, v20
1005ebf58:     	mvn.16b	v20, v20
1005ebf5c:     	sub.4s	v20, v25, v20
1005ebf60:     	cmgt.16b	v25, v4, v19
1005ebf64:     	and.16b	v24, v24, v30
1005ebf68:     	mvn.16b	v30, v30
1005ebf6c:     	sub.4s	v24, v24, v30
1005ebf70:     	sshll2.8h	v30, v25, #0x0
1005ebf74:     	and.16b	v22, v22, v29
1005ebf78:     	mvn.16b	v29, v29
1005ebf7c:     	sub.4s	v22, v22, v29
1005ebf80:     	ushll2.4s	v29, v30, #0x0
1005ebf84:     	bic.16b	v28, v28, v29
1005ebf88:     	cmlt.16b	v19, v19, #0
1005ebf8c:     	sshll.8h	v25, v25, #0x0
1005ebf90:     	ushll.4s	v29, v30, #0x0
1005ebf94:     	bic.16b	v27, v27, v29
1005ebf98:     	ushll2.4s	v29, v25, #0x0
1005ebf9c:     	bic.16b	v23, v23, v29
1005ebfa0:     	sshll.8h	v29, v19, #0x0
1005ebfa4:     	ushll.4s	v25, v25, #0x0
1005ebfa8:     	bic.16b	v21, v21, v25
1005ebfac:     	sshll.4s	v25, v29, #0x0
1005ebfb0:     	and.16b	v21, v21, v25
1005ebfb4:     	mvn.16b	v25, v25
1005ebfb8:     	sub.4s	v21, v21, v25
1005ebfbc:     	sshll2.8h	v19, v19, #0x0
1005ebfc0:     	sshll2.4s	v25, v29, #0x0
1005ebfc4:     	and.16b	v23, v23, v25
1005ebfc8:     	mvn.16b	v25, v25
1005ebfcc:     	sub.4s	v23, v23, v25
1005ebfd0:     	sshll.4s	v25, v19, #0x0
1005ebfd4:     	and.16b	v27, v27, v25
1005ebfd8:     	mvn.16b	v25, v25
1005ebfdc:     	sub.4s	v25, v27, v25
1005ebfe0:     	sshll2.4s	v19, v19, #0x0
1005ebfe4:     	and.16b	v27, v28, v19
1005ebfe8:     	mvn.16b	v19, v19
1005ebfec:     	sub.4s	v19, v27, v19
1005ebff0:     	add.4s	v7, v22, v7
1005ebff4:     	add.4s	v5, v24, v5
1005ebff8:     	add.4s	v6, v20, v6
1005ebffc:     	add.4s	v3, v26, v3
1005ec000:     	add.4s	v18, v19, v18
1005ec004:     	add.4s	v17, v25, v17
1005ec008:     	add.4s	v0, v23, v0
1005ec00c:     	add.4s	v16, v21, v16
1005ec010:     	add	x12, x12, #0x20
1005ec014:     	subs	x13, x13, #0x20
1005ec018:     	b.ne	0x1005ebe84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x500>
1005ec01c:     	add.4s	v0, v0, v6
1005ec020:     	add.4s	v1, v18, v7
1005ec024:     	add.4s	v2, v16, v3
1005ec028:     	add.4s	v3, v17, v5
1005ec02c:     	add.4s	v2, v2, v3
1005ec030:     	add.4s	v0, v0, v1
1005ec034:     	add.4s	v0, v2, v0
1005ec038:     	addv.4s	s0, v0
1005ec03c:     	fmov	w20, s0
1005ec040:     	cmp	x8, x10
1005ec044:     	b.eq	0x1005ebba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005ec048:     	cbz	x11, 0x1005ec0fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x778>
1005ec04c:     	mov	x12, x10
1005ec050:     	and	x10, x8, #0xfffffffffffffff8
1005ec054:     	movi.2d	v0, #0000000000000000
1005ec058:     	mov.s	v0[0], w20
1005ec05c:     	movi.2d	v1, #0000000000000000
1005ec060:     	sub	x11, x12, x10
1005ec064:     	add	x12, x9, x12
1005ec068:     	movi.8b	v2, #0xf0
1005ec06c:     	movi.4s	v3, #0x2
1005ec070:     	movi.8b	v4, #0xc0
1005ec074:     	ldr	d5, [x12], #0x8
1005ec078:     	sshll.8h	v6, v5, #0x0
1005ec07c:     	cmlt.8h	v6, v6, #0
1005ec080:     	sshll2.4s	v7, v6, #0x0
1005ec084:     	sshll.4s	v6, v6, #0x0
1005ec088:     	cmhi.8b	v16, v2, v5
1005ec08c:     	sshll.8h	v16, v16, #0x0
1005ec090:     	sshll2.4s	v17, v16, #0x0
1005ec094:     	sshll.4s	v18, v16, #0x0
1005ec098:     	bic.16b	v18, v3, v18
1005ec09c:     	ssubw.4s	v18, v18, v16
1005ec0a0:     	bic.16b	v17, v3, v17
1005ec0a4:     	ssubw2.4s	v16, v17, v16
1005ec0a8:     	cmgt.8b	v5, v4, v5
1005ec0ac:     	sshll.8h	v5, v5, #0x0
1005ec0b0:     	ushll.4s	v17, v5, #0x0
1005ec0b4:     	ushll2.4s	v5, v5, #0x0
1005ec0b8:     	bic.16b	v5, v16, v5
1005ec0bc:     	bic.16b	v16, v18, v17
1005ec0c0:     	and.16b	v16, v16, v6
1005ec0c4:     	mvn.16b	v6, v6
1005ec0c8:     	sub.4s	v6, v16, v6
1005ec0cc:     	and.16b	v5, v5, v7
1005ec0d0:     	mvn.16b	v7, v7
1005ec0d4:     	sub.4s	v5, v5, v7
1005ec0d8:     	add.4s	v1, v5, v1
1005ec0dc:     	add.4s	v0, v6, v0
1005ec0e0:     	adds	x11, x11, #0x8
1005ec0e4:     	b.ne	0x1005ec074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x6f0>
1005ec0e8:     	add.4s	v0, v0, v1
1005ec0ec:     	addv.4s	s0, v0
1005ec0f0:     	fmov	w20, s0
1005ec0f4:     	cmp	x8, x10
1005ec0f8:     	b.eq	0x1005ebba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005ec0fc:     	sub	x8, x8, x10
1005ec100:     	add	x9, x9, x10
1005ec104:     	mov	w10, #0x1               ; =1
1005ec108:     	ldrsb	w11, [x9], #0x1
1005ec10c:     	and	w12, w11, #0xff
1005ec110:     	cmp	w12, #0xf0
1005ec114:     	cinc	w13, w10, hs
1005ec118:     	cmp	w12, #0xc0
1005ec11c:     	csel	w12, wzr, w13, lo
1005ec120:     	tst	w11, #0x80000000
1005ec124:     	csinc	w11, w12, wzr, ne
1005ec128:     	add	w20, w11, w20
1005ec12c:     	subs	x8, x8, #0x1
1005ec130:     	b.ne	0x1005ec108 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x784>
1005ec134:     	b	0x1005ebba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
