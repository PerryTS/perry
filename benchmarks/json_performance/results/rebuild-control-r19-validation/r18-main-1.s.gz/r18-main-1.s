
benchmarks/json_performance/.work/tape-batch-r18/main-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100244a9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number>:
100244a9c:     	sub	sp, sp, #0x30
100244aa0:     	stp	x20, x19, [sp, #0x10]
100244aa4:     	stp	x29, x30, [sp, #0x20]
100244aa8:     	add	x29, sp, #0x20
100244aac:     	ldp	x2, x9, [x0, #0x68]
100244ab0:     	cmp	x9, x2
100244ab4:     	b.hs	0x100244ae0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x44>
100244ab8:     	ldr	x8, [x0, #0x60]
100244abc:     	ldrb	w8, [x8, x9]
100244ac0:     	cmp	w8, #0x2d
100244ac4:     	b.ne	0x100244ae0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x44>
100244ac8:     	add	x10, x9, #0x1
100244acc:     	str	x10, [x0, #0x70]
100244ad0:     	mov	w13, #0x1               ; =1
100244ad4:     	cmp	x10, x2
100244ad8:     	b.lo	0x100244af0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x54>
100244adc:     	b	0x100244d0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x270>
100244ae0:     	mov	w13, #0x0               ; =0
100244ae4:     	mov	x10, x9
100244ae8:     	cmp	x9, x2
100244aec:     	b.hs	0x100244d0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x270>
100244af0:     	ldr	x12, [x0, #0x60]
100244af4:     	add	x14, x12, x10
100244af8:     	ldrb	w8, [x14]
100244afc:     	cmp	w8, #0x30
100244b00:     	b.ne	0x100244b48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0xac>
100244b04:     	add	x1, x10, #0x1
100244b08:     	str	x1, [x0, #0x70]
100244b0c:     	cmp	x1, x2
100244b10:     	b.hs	0x100244b80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0xe4>
100244b14:     	ldrb	w8, [x12, x1]
100244b18:     	sub	w8, w8, #0x30
100244b1c:     	cmp	w8, #0x9
100244b20:     	b.hi	0x100244b80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0xe4>
100244b24:     	ldrb	w8, [x12, x1]
100244b28:     	sub	w8, w8, #0x30
100244b2c:     	cmp	w8, #0xa
100244b30:     	b.hs	0x100244d0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x270>
100244b34:     	add	x1, x1, #0x1
100244b38:     	str	x1, [x0, #0x70]
100244b3c:     	cmp	x2, x1
100244b40:     	b.ne	0x100244b24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x88>
100244b44:     	b	0x100244d0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x270>
100244b48:     	sub	w8, w8, #0x31
100244b4c:     	cmp	w8, #0x8
100244b50:     	b.hi	0x100244d0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x270>
100244b54:     	mov	x1, x10
100244b58:     	ldrb	w8, [x12, x1]
100244b5c:     	sub	w8, w8, #0x30
100244b60:     	cmp	w8, #0x9
100244b64:     	b.hi	0x100244b80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0xe4>
100244b68:     	add	x1, x1, #0x1
100244b6c:     	str	x1, [x0, #0x70]
100244b70:     	cmp	x2, x1
100244b74:     	b.ne	0x100244b58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0xbc>
100244b78:     	mov	x1, x2
100244b7c:     	b	0x100244ba8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x10c>
100244b80:     	subs	x8, x1, x2
100244b84:     	b.hs	0x100244ba8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x10c>
100244b88:     	ldrb	w11, [x12, x1]
100244b8c:     	cmp	w11, #0x2e
100244b90:     	b.eq	0x100244cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x220>
100244b94:     	cmp	w11, #0x45
100244b98:     	b.eq	0x100244bfc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x160>
100244b9c:     	mov	x8, x1
100244ba0:     	cmp	w11, #0x65
100244ba4:     	b.eq	0x100244c00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x164>
100244ba8:     	subs	x8, x1, x10
100244bac:     	ccmp	x8, #0x13, #0x2, ne
100244bb0:     	b.hs	0x100244bfc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x160>
100244bb4:     	cmp	x1, x10
100244bb8:     	b.lo	0x100244e0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x370>
100244bbc:     	cmp	x1, x2
100244bc0:     	b.hi	0x100244e0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x370>
100244bc4:     	mov	x9, #0x0                ; =0
100244bc8:     	mov	w10, #0xa               ; =10
100244bcc:     	ldrb	w11, [x14], #0x1
100244bd0:     	mul	x9, x9, x10
100244bd4:     	sub	w11, w11, #0x30
100244bd8:     	add	x9, x9, w11, uxtb
100244bdc:     	subs	x8, x8, #0x1
100244be0:     	b.ne	0x100244bcc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x130>
100244be4:     	ucvtf	d0, x9
100244be8:     	fneg	d1, d0
100244bec:     	cmp	w13, #0x0
100244bf0:     	fcsel	d0, d1, d0, ne
100244bf4:     	fmov	x8, d0
100244bf8:     	b	0x100244d18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x27c>
100244bfc:     	mov	x8, x1
100244c00:     	cmp	x8, x2
100244c04:     	b.hs	0x100244c7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x1e0>
100244c08:     	ldrb	w10, [x12, x8]
100244c0c:     	orr	w10, w10, #0x20
100244c10:     	cmp	w10, #0x65
100244c14:     	b.ne	0x100244c7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x1e0>
100244c18:     	add	x10, x8, #0x1
100244c1c:     	str	x10, [x0, #0x70]
100244c20:     	cmp	x10, x2
100244c24:     	b.hs	0x100244c44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x1a8>
100244c28:     	ldrb	w11, [x12, x10]
100244c2c:     	cmp	w11, #0x2d
100244c30:     	b.eq	0x100244c3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x1a0>
100244c34:     	cmp	w11, #0x2b
100244c38:     	b.ne	0x100244c44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x1a8>
100244c3c:     	add	x10, x8, #0x2
100244c40:     	str	x10, [x0, #0x70]
100244c44:     	cmp	x10, x2
100244c48:     	b.hs	0x100244d0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x270>
100244c4c:     	mov	x8, x10
100244c50:     	ldrb	w11, [x12, x8]
100244c54:     	sub	w11, w11, #0x30
100244c58:     	cmp	w11, #0x9
100244c5c:     	b.hi	0x100244c74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x1d8>
100244c60:     	add	x8, x8, #0x1
100244c64:     	str	x8, [x0, #0x70]
100244c68:     	cmp	x2, x8
100244c6c:     	b.ne	0x100244c50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x1b4>
100244c70:     	mov	x8, x2
100244c74:     	cmp	x8, x10
100244c78:     	b.eq	0x100244d0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x270>
100244c7c:     	subs	x1, x8, x9
100244c80:     	b.lo	0x100244df8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x35c>
100244c84:     	cmp	x8, x2
100244c88:     	b.hi	0x100244df8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x35c>
100244c8c:     	mov	x19, x0
100244c90:     	mov	x8, sp
100244c94:     	add	x0, x12, x9
100244c98:     	bl	0x1000335ac <__RNvXs2_NtNtCsjgY6bXVaRmE_4core3num11float_parsedNtNtNtB9_3str6traits7FromStr8from_str>
100244c9c:     	ldrb	w8, [sp]
100244ca0:     	tbz	w8, #0x0, 0x100244cb4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x218>
100244ca4:     	mov	x8, #0x2                ; =2
100244ca8:     	movk	x8, #0x7ffc, lsl #48
100244cac:     	strb	wzr, [x19, #0xd4]
100244cb0:     	b	0x100244d18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x27c>
100244cb4:     	ldr	x8, [sp, #0x8]
100244cb8:     	b	0x100244d18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x27c>
100244cbc:     	add	x11, x1, #0x1
100244cc0:     	cmp	x11, x2
100244cc4:     	b.hs	0x100244d08 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x26c>
100244cc8:     	add	x16, x12, #0x1
100244ccc:     	mov	x15, #-0x1              ; =-1
100244cd0:     	ldrb	w17, [x16, x1]
100244cd4:     	sub	w3, w17, #0x30
100244cd8:     	cmp	w3, #0x9
100244cdc:     	b.hi	0x100244d2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x290>
100244ce0:     	add	x16, x16, #0x1
100244ce4:     	sub	x15, x15, #0x1
100244ce8:     	cmp	x8, x15
100244cec:     	b.ne	0x100244cd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x234>
100244cf0:     	str	x2, [x0, #0x70]
100244cf4:     	mov	x8, x2
100244cf8:     	subs	x16, x1, x10
100244cfc:     	b.eq	0x100244c7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x1e0>
100244d00:     	mov	x8, x2
100244d04:     	b	0x100244d60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x2c4>
100244d08:     	str	x11, [x0, #0x70]
100244d0c:     	mov	x8, #0x2                ; =2
100244d10:     	movk	x8, #0x7ffc, lsl #48
100244d14:     	strb	wzr, [x0, #0xd4]
100244d18:     	mov	x0, x8
100244d1c:     	ldp	x29, x30, [sp, #0x20]
100244d20:     	ldp	x20, x19, [sp, #0x10]
100244d24:     	add	sp, sp, #0x30
100244d28:     	ret
100244d2c:     	sub	x8, x1, x15
100244d30:     	str	x8, [x0, #0x70]
100244d34:     	cmp	w17, #0x65
100244d38:     	b.ne	0x100244d48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x2ac>
100244d3c:     	cmn	x15, #0x1
100244d40:     	b.ne	0x100244c00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x164>
100244d44:     	b	0x100244d0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x270>
100244d48:     	cmn	x15, #0x1
100244d4c:     	b.eq	0x100244d0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x270>
100244d50:     	subs	x16, x1, x10
100244d54:     	b.eq	0x100244c00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x164>
100244d58:     	cmp	w17, #0x45
100244d5c:     	b.eq	0x100244c00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x164>
100244d60:     	sub	x15, x8, x11
100244d64:     	cmp	x15, #0x9
100244d68:     	b.hi	0x100244c00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x164>
100244d6c:     	add	x17, x16, x15
100244d70:     	cmp	x17, #0x11
100244d74:     	b.hi	0x100244c00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x164>
100244d78:     	cmp	x1, x10
100244d7c:     	b.lo	0x100244e1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x380>
100244d80:     	mov	x10, #0x0               ; =0
100244d84:     	b.eq	0x100244da4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x308>
100244d88:     	mov	w17, #0xa               ; =10
100244d8c:     	ldrb	w3, [x14], #0x1
100244d90:     	mul	x10, x10, x17
100244d94:     	sub	w3, w3, #0x30
100244d98:     	add	x10, x10, w3, uxtb
100244d9c:     	subs	x16, x16, #0x1
100244da0:     	b.ne	0x100244d8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x2f0>
100244da4:     	cmp	x8, x1
100244da8:     	b.ls	0x100244e2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x390>
100244dac:     	cmp	x8, x2
100244db0:     	b.hi	0x100244e2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x390>
100244db4:     	mov	w14, #0xa               ; =10
100244db8:     	ldrb	w16, [x12, x11]
100244dbc:     	mul	x10, x10, x14
100244dc0:     	sub	w16, w16, #0x30
100244dc4:     	add	x10, x10, w16, uxtb
100244dc8:     	add	x11, x11, #0x1
100244dcc:     	cmp	x8, x11
100244dd0:     	b.ne	0x100244db8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x31c>
100244dd4:     	mov	x11, #0x20000000000000  ; =9007199254740992
100244dd8:     	cmp	x10, x11
100244ddc:     	b.hi	0x100244c00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x164>
100244de0:     	ucvtf	d0, x10
100244de4:     	adrp	x8, 0x100c46000 <_PERRY_EMPTY_STRING+0x4b74>
100244de8:     	add	x8, x8, #0x368
100244dec:     	ldr	d1, [x8, x15, lsl #3]
100244df0:     	fdiv	d0, d0, d1
100244df4:     	b	0x100244be8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x14c>
100244df8:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100244dfc:     	add	x3, x3, #0x620
100244e00:     	mov	x0, x9
100244e04:     	mov	x1, x8
100244e08:     	bl	0x100b1294c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100244e0c:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100244e10:     	add	x3, x3, #0x5d8
100244e14:     	mov	x0, x10
100244e18:     	bl	0x100b1294c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100244e1c:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100244e20:     	add	x3, x3, #0x608
100244e24:     	mov	x0, x10
100244e28:     	bl	0x100b1294c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100244e2c:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100244e30:     	add	x3, x3, #0x5f0
100244e34:     	mov	x0, x11
100244e38:     	mov	x1, x8
100244e3c:     	bl	0x100b1294c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
