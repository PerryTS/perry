
benchmarks/json_performance/.work/tape-batch-r18/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100506a38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>:
100506a38:     	stp	x28, x27, [sp, #-0x60]!
100506a3c:     	stp	x26, x25, [sp, #0x10]
100506a40:     	stp	x24, x23, [sp, #0x20]
100506a44:     	stp	x22, x21, [sp, #0x30]
100506a48:     	stp	x20, x19, [sp, #0x40]
100506a4c:     	stp	x29, x30, [sp, #0x50]
100506a50:     	add	x29, sp, #0x50
100506a54:     	sub	sp, sp, #0x1a0
100506a58:     	mov	x19, x1
100506a5c:     	mov	x21, x0
100506a60:     	bl	0x1004ee310 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template>
100506a64:     	cmp	x0, #0x1
100506a68:     	b.ne	0x100506a94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5c>
100506a6c:     	mov	x23, x1
100506a70:     	mov	x0, x23
100506a74:     	add	sp, sp, #0x1a0
100506a78:     	ldp	x29, x30, [sp, #0x50]
100506a7c:     	ldp	x20, x19, [sp, #0x40]
100506a80:     	ldp	x22, x21, [sp, #0x30]
100506a84:     	ldp	x24, x23, [sp, #0x20]
100506a88:     	ldp	x26, x25, [sp, #0x10]
100506a8c:     	ldp	x28, x27, [sp], #0x60
100506a90:     	ret
100506a94:     	add	x24, x21, #0x14
100506a98:     	cmp	x19, #0x2
100506a9c:     	b.ne	0x100506ab4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7c>
100506aa0:     	ldrh	w8, [x24]
100506aa4:     	mov	w9, #0x7d7b             ; =32123
100506aa8:     	cmp	w8, w9
100506aac:     	b.ne	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506ab0:     	b	0x100506b4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x114>
100506ab4:     	cmp	x19, #0x3
100506ab8:     	b.hs	0x100506b20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe8>
100506abc:     	add	x0, sp, #0xa0
100506ac0:     	add	x1, x21, #0x14
100506ac4:     	mov	x2, x19
100506ac8:     	bl	0x1004f6d18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object6decode>
100506acc:     	ldr	w8, [sp, #0xa0]
100506ad0:     	tbz	w8, #0x0, 0x100506c24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1ec>
100506ad4:     	add	x8, sp, #0xa0
100506ad8:     	ldr	x9, [sp, #0x128]
100506adc:     	str	x9, [sp, #0x90]
100506ae0:     	ldur	q0, [x8, #0x48]
100506ae4:     	ldur	q1, [x8, #0x58]
100506ae8:     	stp	q0, q1, [sp, #0x50]
100506aec:     	ldur	q0, [x8, #0x68]
100506af0:     	ldur	q1, [x8, #0x78]
100506af4:     	stp	q0, q1, [sp, #0x70]
100506af8:     	ldur	q0, [x8, #0x8]
100506afc:     	ldur	q1, [x8, #0x18]
100506b00:     	stp	q0, q1, [sp, #0x10]
100506b04:     	ldur	q0, [x8, #0x28]
100506b08:     	ldur	q1, [x8, #0x38]
100506b0c:     	stp	q0, q1, [sp, #0x30]
100506b10:     	add	x0, sp, #0x10
100506b14:     	bl	0x1004f74c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object8allocate>
100506b18:     	tbnz	w0, #0x0, 0x100506a6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x34>
100506b1c:     	b	0x100506c24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1ec>
100506b20:     	ldrb	w20, [x24]
100506b24:     	cmp	w20, #0x20
100506b28:     	b.hi	0x100506b6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x134>
100506b2c:     	mov	x8, #0x2600             ; =9728
100506b30:     	movk	x8, #0x1, lsl #32
100506b34:     	lsr	x8, x8, x20
100506b38:     	tbz	w8, #0x0, 0x100506b6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x134>
100506b3c:     	add	x0, x21, #0x14
100506b40:     	mov	x1, x19
100506b44:     	bl	0x1004ed4e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty19padded_empty_object>
100506b48:     	tbz	w0, #0x0, 0x100506b98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x160>
100506b4c:     	add	sp, sp, #0x1a0
100506b50:     	ldp	x29, x30, [sp, #0x50]
100506b54:     	ldp	x20, x19, [sp, #0x40]
100506b58:     	ldp	x22, x21, [sp, #0x30]
100506b5c:     	ldp	x24, x23, [sp, #0x20]
100506b60:     	ldp	x26, x25, [sp, #0x10]
100506b64:     	ldp	x28, x27, [sp], #0x60
100506b68:     	b	0x1004ed5c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100506b6c:     	cmp	w20, #0x7b
100506b70:     	b.ne	0x100506b98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x160>
100506b74:     	ldrb	w8, [x21, #0x15]
100506b78:     	cmp	w8, #0x20
100506b7c:     	b.hi	0x100506b90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x158>
100506b80:     	mov	x9, #0x2600             ; =9728
100506b84:     	movk	x9, #0x1, lsl #32
100506b88:     	lsr	x9, x9, x8
100506b8c:     	tbnz	w9, #0x0, 0x100506b3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104>
100506b90:     	cmp	w8, #0x7d
100506b94:     	b.eq	0x100506b3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104>
100506b98:     	cmp	x19, #0x41
100506b9c:     	b.hs	0x100506c24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1ec>
100506ba0:     	cmp	w20, #0x7b
100506ba4:     	ccmp	x19, #0x7, #0x0, eq
100506ba8:     	b.lo	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506bac:     	add	x8, x24, x19
100506bb0:     	ldurb	w8, [x8, #-0x1]
100506bb4:     	cmp	w8, #0x7d
100506bb8:     	b.ne	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506bbc:     	ldrb	w8, [x21, #0x15]
100506bc0:     	cmp	w8, #0x22
100506bc4:     	b.ne	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506bc8:     	sub	x9, x19, #0x1
100506bcc:     	mov	x22, x21
100506bd0:     	ldrb	w25, [x22, #0x16]!
100506bd4:     	cmp	w25, #0x22
100506bd8:     	b.ne	0x100506c68 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x230>
100506bdc:     	mov	w23, #0x0               ; =0
100506be0:     	mov	w28, #0x0               ; =0
100506be4:     	mov	w27, #0x0               ; =0
100506be8:     	mov	w26, #0x0               ; =0
100506bec:     	mov	x20, #0x0               ; =0
100506bf0:     	cmp	w25, #0x22
100506bf4:     	b.ne	0x100506c94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x25c>
100506bf8:     	add	x8, sp, #0xa0
100506bfc:     	mov	x0, x22
100506c00:     	mov	x1, x20
100506c04:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100506c08:     	sub	x11, x19, #0x1
100506c0c:     	ldr	w8, [sp, #0xa0]
100506c10:     	tbnz	w8, #0x0, 0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506c14:     	cmp	w25, #0x22
100506c18:     	b.ne	0x100506d38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x300>
100506c1c:     	mov	x8, #0x0                ; =0
100506c20:     	b	0x100506d6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100506c24:     	adrp	x8, 0x100f81000 <__MergedGlobals+0xb8>
100506c28:     	add	x8, x8, #0x2d8
100506c2c:     	ldapr	x8, [x8]
100506c30:     	cbnz	x8, 0x100506e04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3cc>
100506c34:     	adrp	x8, 0x100f81000 <__MergedGlobals+0xb8>
100506c38:     	ldrb	w8, [x8, #0x2e0]
100506c3c:     	adrp	x12, 0x100f82000 <__MergedGlobals.1917+0xc8>
100506c40:     	adrp	x27, 0x100f80000 <_perry_global_worker_ts__1>
100506c44:     	cbz	w8, 0x100506e1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3e4>
100506c48:     	cmp	w8, #0x1
100506c4c:     	b.ne	0x100506e58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x420>
100506c50:     	mov	w28, #0x1               ; =1
100506c54:     	mov	w8, #0x1000000          ; =16777216
100506c58:     	mov	w22, #0x1               ; =1
100506c5c:     	cmp	x19, x8
100506c60:     	b.hi	0x100506e5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x424>
100506c64:     	b	0x100506f40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x508>
100506c68:     	cmp	x9, #0x3
100506c6c:     	b.eq	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506c70:     	ldrb	w8, [x21, #0x17]
100506c74:     	cmp	w8, #0x22
100506c78:     	b.ne	0x100506d0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x2d4>
100506c7c:     	mov	w28, #0x0               ; =0
100506c80:     	mov	w27, #0x0               ; =0
100506c84:     	mov	w26, #0x0               ; =0
100506c88:     	mov	w23, #0x1               ; =1
100506c8c:     	mov	w20, #0x1               ; =1
100506c90:     	b	0x100506bf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100506c94:     	ldrb	w8, [x22]
100506c98:     	cmp	w8, #0x20
100506c9c:     	b.lo	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506ca0:     	cmp	w8, #0x5c
100506ca4:     	b.eq	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506ca8:     	tbnz	w23, #0x0, 0x100506bf8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100506cac:     	ldrb	w8, [x21, #0x17]
100506cb0:     	cmp	w8, #0x20
100506cb4:     	b.lo	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506cb8:     	cmp	w8, #0x5c
100506cbc:     	b.eq	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506cc0:     	tbnz	w28, #0x0, 0x100506bf8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100506cc4:     	ldrb	w8, [x21, #0x18]
100506cc8:     	cmp	w8, #0x20
100506ccc:     	b.lo	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506cd0:     	cmp	w8, #0x5c
100506cd4:     	b.eq	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506cd8:     	tbnz	w27, #0x0, 0x100506bf8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100506cdc:     	ldrb	w8, [x21, #0x19]
100506ce0:     	cmp	w8, #0x20
100506ce4:     	b.lo	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506ce8:     	cmp	w8, #0x5c
100506cec:     	b.eq	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506cf0:     	tbnz	w26, #0x0, 0x100506bf8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100506cf4:     	ldrb	w8, [x21, #0x1a]
100506cf8:     	cmp	w8, #0x20
100506cfc:     	b.lo	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506d00:     	cmp	w8, #0x5c
100506d04:     	b.ne	0x100506bf8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100506d08:     	b	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506d0c:     	cmp	x9, #0x4
100506d10:     	b.eq	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506d14:     	ldrb	w8, [x21, #0x18]
100506d18:     	cmp	w8, #0x22
100506d1c:     	b.ne	0x100506dd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3a0>
100506d20:     	mov	w23, #0x0               ; =0
100506d24:     	mov	w27, #0x0               ; =0
100506d28:     	mov	w26, #0x0               ; =0
100506d2c:     	mov	w28, #0x1               ; =1
100506d30:     	mov	w20, #0x2               ; =2
100506d34:     	b	0x100506bf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100506d38:     	ldrb	w8, [x22]
100506d3c:     	tbnz	w23, #0x0, 0x100506d6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100506d40:     	ldrb	w9, [x21, #0x17]
100506d44:     	orr	x8, x8, x9, lsl #8
100506d48:     	tbnz	w28, #0x0, 0x100506d6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100506d4c:     	ldrb	w9, [x21, #0x18]
100506d50:     	orr	x8, x8, x9, lsl #16
100506d54:     	tbnz	w27, #0x0, 0x100506d6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100506d58:     	ldrb	w9, [x21, #0x19]
100506d5c:     	orr	x8, x8, x9, lsl #24
100506d60:     	tbnz	w26, #0x0, 0x100506d6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100506d64:     	ldrb	w9, [x21, #0x1a]
100506d68:     	orr	x8, x8, x9, lsl #32
100506d6c:     	add	x9, x20, #0x3
100506d70:     	cmp	x9, x19
100506d74:     	b.hs	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506d78:     	ldrb	w9, [x24, x9]
100506d7c:     	cmp	w9, #0x3a
100506d80:     	b.ne	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506d84:     	add	x10, x20, #0x4
100506d88:     	subs	x9, x11, x10
100506d8c:     	b.lo	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506d90:     	b.eq	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506d94:     	orr	x25, x8, x20, lsl #40
100506d98:     	mov	x26, #0x7ff9000000000000 ; =9221401712017801216
100506d9c:     	add	x8, x24, x10
100506da0:     	mov	x10, #0x2600            ; =9728
100506da4:     	movk	x10, #0x1, lsl #32
100506da8:     	mov	x11, x9
100506dac:     	mov	x12, x8
100506db0:     	b	0x100506dc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x388>
100506db4:     	add	x12, x12, #0x1
100506db8:     	subs	x11, x11, #0x1
100506dbc:     	b.eq	0x100507c64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x122c>
100506dc0:     	ldrb	w13, [x12]
100506dc4:     	cmp	w13, #0x20
100506dc8:     	b.hi	0x100506db4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x37c>
100506dcc:     	lsr	x13, x10, x13
100506dd0:     	tbz	w13, #0x0, 0x100506db4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x37c>
100506dd4:     	b	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506dd8:     	cmp	x9, #0x5
100506ddc:     	b.eq	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506de0:     	ldrb	w8, [x21, #0x19]
100506de4:     	cmp	w8, #0x22
100506de8:     	b.ne	0x100507bb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1178>
100506dec:     	mov	w23, #0x0               ; =0
100506df0:     	mov	w28, #0x0               ; =0
100506df4:     	mov	w26, #0x0               ; =0
100506df8:     	mov	w27, #0x1               ; =1
100506dfc:     	mov	w20, #0x3               ; =3
100506e00:     	b	0x100506bf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100506e04:     	bl	0x100b199c4 <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockNtNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api8TapeModeE10initializeNCINvB2_11get_or_initNCNvBV_18tape_mode_from_env0E0zEBZ_>
100506e08:     	adrp	x8, 0x100f81000 <__MergedGlobals+0xb8>
100506e0c:     	ldrb	w8, [x8, #0x2e0]
100506e10:     	adrp	x12, 0x100f82000 <__MergedGlobals.1917+0xc8>
100506e14:     	adrp	x27, 0x100f80000 <_perry_global_worker_ts__1>
100506e18:     	cbnz	w8, 0x100506c48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x210>
100506e1c:     	sub	x8, x19, #0x400
100506e20:     	mov	w9, #0xfffc00           ; =16776192
100506e24:     	cmp	x8, x9
100506e28:     	b.hi	0x100506e58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x420>
100506e2c:     	mov	x8, #0x0                ; =0
100506e30:     	mov	x9, #0x2600             ; =9728
100506e34:     	movk	x9, #0x1, lsl #32
100506e38:     	ldrb	w10, [x24, x8]
100506e3c:     	cmp	w10, #0x20
100506e40:     	b.hi	0x100507338 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x900>
100506e44:     	lsr	x11, x9, x10
100506e48:     	tbz	w11, #0x0, 0x100507338 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x900>
100506e4c:     	add	x8, x8, #0x1
100506e50:     	cmp	x19, x8
100506e54:     	b.ne	0x100506e38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x400>
100506e58:     	mov	w22, #0x0               ; =0
100506e5c:     	ldr	w20, [x12, #0x560]
100506e60:     	cmp	w20, #0x300
100506e64:     	b.hs	0x100507310 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8d8>
100506e68:     	ldr	x8, [x27, #0x48]
100506e6c:     	cmn	x8, #0x1
100506e70:     	b.eq	0x100507300 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8c8>
100506e74:     	mrs	x9, TPIDRRO_EL0
100506e78:     	and	x9, x9, #0xfffffffffffffff8
100506e7c:     	ldr	x0, [x9, x8, lsl #3]
100506e80:     	cbz	x0, 0x100507300 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8c8>
100506e84:     	add	x8, x0, x20, lsl #3
100506e88:     	ldr	x0, [x8, #0x1e8]
100506e8c:     	cbz	x0, 0x100507310 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8d8>
100506e90:     	ldr	x8, [x0]
100506e94:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100506e98:     	cmp	x8, x9
100506e9c:     	b.hs	0x10050732c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8f4>
100506ea0:     	ldrb	w8, [x0, #0x24]
100506ea4:     	cmp	w8, #0x2
100506ea8:     	b.eq	0x100506eb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x480>
100506eac:     	ldr	x9, [x0, #0x8]
100506eb0:     	cmp	x9, x21
100506eb4:     	b.eq	0x100506f20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4e8>
100506eb8:     	cmp	x19, #0x3e9
100506ebc:     	b.lo	0x100506f3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100506ec0:     	mov	x8, #0x0                ; =0
100506ec4:     	mov	x9, #0x2600             ; =9728
100506ec8:     	movk	x9, #0x1, lsl #32
100506ecc:     	add	x10, x21, x8
100506ed0:     	ldrb	w10, [x10, #0x14]
100506ed4:     	cmp	w10, #0x20
100506ed8:     	b.hi	0x100506ef4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4bc>
100506edc:     	lsr	x11, x9, x10
100506ee0:     	tbz	w11, #0x0, 0x100506ef4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4bc>
100506ee4:     	add	x8, x8, #0x1
100506ee8:     	cmp	x19, x8
100506eec:     	b.ne	0x100506ecc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x494>
100506ef0:     	b	0x100506f3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100506ef4:     	cmp	w10, #0x5b
100506ef8:     	b.eq	0x100506f04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4cc>
100506efc:     	cmp	w10, #0x7b
100506f00:     	b.ne	0x100506f3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100506f04:     	add	x0, x21, #0x14
100506f08:     	mov	x1, x19
100506f0c:     	mov	w2, #0x3e8              ; =1000
100506f10:     	bl	0x1006c5714 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser12depth_blocks21nesting_depth_exceeds>
100506f14:     	cbz	w0, 0x100506f3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100506f18:     	mov	x0, x21
100506f1c:     	b	0x100507b70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1138>
100506f20:     	ldr	w9, [x0, #0x18]
100506f24:     	cmp	x19, x9
100506f28:     	cset	w9, eq
100506f2c:     	and	w8, w9, w8
100506f30:     	cmp	x19, #0x3e9
100506f34:     	csinc	w8, w8, wzr, hs
100506f38:     	tbz	w8, #0x0, 0x100506ec0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x488>
100506f3c:     	mov	w28, #0x0               ; =0
100506f40:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100506f44:     	add	x0, x0, #0xce8
100506f48:     	ldr	x8, [x0]
100506f4c:     	blr	x8
100506f50:     	mov	x20, x0
100506f54:     	ldrb	w8, [x0, #0x20]
100506f58:     	cbnz	w8, 0x100507ac8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1090>
100506f5c:     	ldr	x8, [x20]
100506f60:     	cbnz	x8, 0x100507b44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
100506f64:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
100506f68:     	bfxil	x23, x21, #0, #48
100506f6c:     	mov	x8, #-0x1               ; =-1
100506f70:     	str	x8, [x20]
100506f74:     	ldr	x21, [x20, #0x18]
100506f78:     	ldr	x8, [x20, #0x8]
100506f7c:     	cmp	x21, x8
100506f80:     	b.eq	0x1005072c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x88c>
100506f84:     	ldr	x8, [x20, #0x10]
100506f88:     	str	x23, [x8, x21, lsl #3]
100506f8c:     	add	x8, x21, #0x1
100506f90:     	str	x8, [x20, #0x18]
100506f94:     	ldr	x8, [x20]
100506f98:     	add	x8, x8, #0x1
100506f9c:     	str	x8, [x20]
100506fa0:     	adrp	x24, 0x100f80000 <_perry_global_worker_ts__1>
100506fa4:     	ldr	w23, [x24, #0x948]
100506fa8:     	cmp	w23, #0x300
100506fac:     	b.hs	0x1005072e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8a8>
100506fb0:     	ldr	x8, [x27, #0x48]
100506fb4:     	cmn	x8, #0x1
100506fb8:     	b.eq	0x1005072d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x898>
100506fbc:     	mrs	x9, TPIDRRO_EL0
100506fc0:     	and	x9, x9, #0xfffffffffffffff8
100506fc4:     	ldr	x0, [x9, x8, lsl #3]
100506fc8:     	cbz	x0, 0x1005072d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x898>
100506fcc:     	add	x8, x0, x23, lsl #3
100506fd0:     	ldr	x0, [x8, #0x1e8]
100506fd4:     	cbz	x0, 0x1005072e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8a8>
100506fd8:     	ldrb	w8, [x0]
100506fdc:     	cbnz	w8, 0x1005072f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8bc>
100506fe0:     	tbz	w22, #0x0, 0x100507668 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100506fe4:     	ldrb	w8, [x20, #0x20]
100506fe8:     	cbnz	w8, 0x100507b80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1148>
100506fec:     	ldr	x8, [x20]
100506ff0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100506ff4:     	cmp	x8, x9
100506ff8:     	b.hs	0x100507cc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100506ffc:     	add	x9, x8, #0x1
100507000:     	str	x9, [x20]
100507004:     	ldr	x9, [x20, #0x18]
100507008:     	cmp	x21, x9
10050700c:     	b.hs	0x100507020 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5e8>
100507010:     	ldr	x9, [x20, #0x10]
100507014:     	ldr	x9, [x9, x21, lsl #3]
100507018:     	and	x23, x9, #0xffffffffffff
10050701c:     	b	0x100507024 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5ec>
100507020:     	mov	w23, #0x1               ; =1
100507024:     	str	x8, [x20]
100507028:     	adrp	x0, 0x100f88000 <__RNvNCNKNvNtCs3gRpqoBkMHm_13perry_runtime7process29PROCESS_FINALIZATION_EXIT_RAN0s_023___RUST_STD_INTERNAL_VAL>
10050702c:     	add	x0, x0, #0x168
100507030:     	ldr	x8, [x0]
100507034:     	blr	x8
100507038:     	mov	x22, x0
10050703c:     	ldrb	w8, [x0, #0x30]
100507040:     	cmp	w8, #0x1
100507044:     	b.ne	0x100507b50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1118>
100507048:     	ldr	x8, [x22]
10050704c:     	mov	x10, #-0x1              ; =-1
100507050:     	mov	x9, x22
100507054:     	str	x10, [x9], #0x8
100507058:     	cmn	x8, #0x1
10050705c:     	b.eq	0x10050707c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x644>
100507060:     	add	x10, sp, #0xa0
100507064:     	ldp	q0, q1, [x9]
100507068:     	ldr	x9, [x9, #0x20]
10050706c:     	stur	x9, [x10, #0x28]
100507070:     	stur	q1, [x10, #0x18]
100507074:     	stur	q0, [x10, #0x8]
100507078:     	b	0x100507090 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x658>
10050707c:     	mov	x8, #0x0                ; =0
100507080:     	mov	w9, #0x4                ; =4
100507084:     	stp	x9, xzr, [sp, #0xa8]
100507088:     	stp	xzr, x9, [sp, #0xb8]
10050708c:     	str	xzr, [sp, #0xc8]
100507090:     	str	x8, [sp, #0xa0]
100507094:     	stur	xzr, [x29, #-0x78]
100507098:     	add	x8, sp, #0xa0
10050709c:     	add	x0, x23, #0x14
1005070a0:     	add	x2, sp, #0xa0
1005070a4:     	add	x3, x8, #0x18
1005070a8:     	sub	x4, x29, #0x78
1005070ac:     	mov	x1, x19
1005070b0:     	bl	0x100150be4 <__RINvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15build_tape_intoKb1_EB4_>
1005070b4:     	tbz	w0, #0x0, 0x1005071c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x78c>
1005070b8:     	ldur	x23, [x29, #-0x78]
1005070bc:     	ldr	w24, [x24, #0x948]
1005070c0:     	cmp	w24, #0x300
1005070c4:     	b.hs	0x1005079dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfa4>
1005070c8:     	ldr	x8, [x27, #0x48]
1005070cc:     	cmn	x8, #0x1
1005070d0:     	b.eq	0x1005079cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf94>
1005070d4:     	mrs	x9, TPIDRRO_EL0
1005070d8:     	and	x9, x9, #0xfffffffffffffff8
1005070dc:     	ldr	x0, [x9, x8, lsl #3]
1005070e0:     	cbz	x0, 0x1005079cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf94>
1005070e4:     	add	x8, x0, x24, lsl #3
1005070e8:     	ldr	x0, [x8, #0x1e8]
1005070ec:     	cbz	x0, 0x1005079dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfa4>
1005070f0:     	ldrb	w8, [x0]
1005070f4:     	cbnz	w8, 0x1005079f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfb8>
1005070f8:     	bl	0x1004f0bc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
1005070fc:     	bl	0x10045aa80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy16gc_check_trigger>
100507100:     	mov	x0, x19
100507104:     	bl	0x100231eac <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation5begin>
100507108:     	mov	x24, x0
10050710c:     	mov	x25, x1
100507110:     	bl	0x10045a894 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy11gc_suppress>
100507114:     	ldrb	w8, [x20, #0x20]
100507118:     	cbnz	w8, 0x100507c0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11d4>
10050711c:     	ldr	x8, [x20]
100507120:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100507124:     	cmp	x8, x9
100507128:     	b.hs	0x100507cc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
10050712c:     	add	x9, x8, #0x1
100507130:     	str	x9, [x20]
100507134:     	ldr	x9, [x20, #0x18]
100507138:     	cmp	x21, x9
10050713c:     	b.hs	0x10050725c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x824>
100507140:     	ldr	x9, [x20, #0x10]
100507144:     	ldr	x9, [x9, x21, lsl #3]
100507148:     	and	x2, x9, #0xffffffffffff
10050714c:     	stp	x25, x24, [sp]
100507150:     	str	x8, [x20]
100507154:     	add	x26, x2, #0x14
100507158:     	cmp	x23, #0x3e8
10050715c:     	b.hi	0x100507274 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x83c>
100507160:     	ldp	x24, x25, [sp, #0xa8]
100507164:     	cbz	x25, 0x100507290 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x858>
100507168:     	ldrb	w8, [x24, #0x8]
10050716c:     	cmp	w8, #0x3
100507170:     	b.ne	0x100507290 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x858>
100507174:     	ldr	w8, [x24, #0x4]
100507178:     	cmp	w8, #0x2
10050717c:     	b.lo	0x100507360 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x928>
100507180:     	mov	w1, #0x0                ; =0
100507184:     	mov	w0, #0x1                ; =1
100507188:     	mov	w9, #0xc                ; =12
10050718c:     	b	0x1005071a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x768>
100507190:     	add	x0, x0, #0x1
100507194:     	add	w1, w1, #0x1
100507198:     	cmp	x0, x8
10050719c:     	b.hs	0x100507364 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x92c>
1005071a0:     	cmp	x0, x25
1005071a4:     	b.hs	0x100507dc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1388>
1005071a8:     	madd	x10, x0, x9, x24
1005071ac:     	ldrb	w11, [x10, #0x8]
1005071b0:     	orr	w11, w11, #0x2
1005071b4:     	cmp	w11, #0x3
1005071b8:     	b.ne	0x100507190 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x758>
1005071bc:     	ldr	w0, [x10, #0x4]
1005071c0:     	b	0x100507190 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x758>
1005071c4:     	str	xzr, [sp, #0xb0]
1005071c8:     	str	xzr, [sp, #0xc8]
1005071cc:     	ldr	x8, [sp, #0xa0]
1005071d0:     	add	x9, x8, x8, lsl #1
1005071d4:     	lsl	x9, x9, #2
1005071d8:     	cmp	x9, #0x100, lsl #12     ; =0x100000
1005071dc:     	b.ls	0x1005071f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7c0>
1005071e0:     	cbz	x8, 0x1005071ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7b4>
1005071e4:     	ldr	x0, [sp, #0xa8]
1005071e8:     	bl	0x100b5fd00 <_mi_free>
1005071ec:     	mov	w8, #0x4                ; =4
1005071f0:     	stp	xzr, x8, [sp, #0xa0]
1005071f4:     	str	xzr, [sp, #0xb0]
1005071f8:     	ldr	x8, [sp, #0xb8]
1005071fc:     	lsl	x9, x8, #2
100507200:     	cmp	x9, #0x10, lsl #12      ; =0x10000
100507204:     	b.ls	0x100507220 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7e8>
100507208:     	cbz	x8, 0x100507214 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7dc>
10050720c:     	ldr	x0, [sp, #0xc0]
100507210:     	bl	0x100b5fd00 <_mi_free>
100507214:     	mov	w8, #0x4                ; =4
100507218:     	stp	xzr, x8, [sp, #0xb8]
10050721c:     	str	xzr, [sp, #0xc8]
100507220:     	ldp	x8, x0, [x22]
100507224:     	ldp	x24, x23, [x22, #0x18]
100507228:     	ldp	q1, q0, [sp, #0xb0]
10050722c:     	ldr	q2, [sp, #0xa0]
100507230:     	stp	q2, q1, [x22]
100507234:     	str	q0, [x22, #0x20]
100507238:     	cmn	x8, #0x1
10050723c:     	b.eq	0x100507254 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x81c>
100507240:     	cbz	x8, 0x100507248 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x810>
100507244:     	bl	0x100b5fd00 <_mi_free>
100507248:     	cbz	x24, 0x100507254 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x81c>
10050724c:     	mov	x0, x23
100507250:     	bl	0x100b5fd00 <_mi_free>
100507254:     	ldrb	w8, [x20, #0x20]
100507258:     	b	0x10050758c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb54>
10050725c:     	mov	w2, #0x1                ; =1
100507260:     	stp	x25, x24, [sp]
100507264:     	str	x8, [x20]
100507268:     	add	x26, x2, #0x14
10050726c:     	cmp	x23, #0x3e8
100507270:     	b.ls	0x100507160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x728>
100507274:     	ldp	x0, x1, [sp, #0xa8]
100507278:     	mov	x2, x26
10050727c:     	mov	x3, x19
100507280:     	bl	0x1006891d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape9iterative21materialize_iterative>
100507284:     	tbz	w0, #0x0, 0x1005072bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x884>
100507288:     	mov	x25, x1
10050728c:     	b	0x1005073b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x97c>
100507290:     	bl	0x10028bf18 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
100507294:     	stp	x0, xzr, [x29, #-0x70]
100507298:     	stp	x24, x25, [sp, #0x10]
10050729c:     	stp	x26, x19, [sp, #0x20]
1005072a0:     	add	x0, sp, #0x10
1005072a4:     	sub	x1, x29, #0x68
1005072a8:     	bl	0x100378a98 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24materialize_value_source>
1005072ac:     	mov	x25, x0
1005072b0:     	sub	x0, x29, #0x70
1005072b4:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
1005072b8:     	b	0x1005073b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x97c>
1005072bc:     	mov	w25, #0x0               ; =0
1005072c0:     	b	0x1005073fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9c4>
1005072c4:     	add	x0, x20, #0x8
1005072c8:     	bl	0x100b3ca2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1005072cc:     	b	0x100506f84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x54c>
1005072d0:     	bl	0x100b4013c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005072d4:     	add	x8, x0, x23, lsl #3
1005072d8:     	ldr	x0, [x8, #0x1e8]
1005072dc:     	cbnz	x0, 0x100506fd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5a0>
1005072e0:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x150>
1005072e4:     	add	x0, x0, #0xd98
1005072e8:     	bl	0x100b3d9a8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1005072ec:     	ldrb	w8, [x0]
1005072f0:     	cbz	w8, 0x100506fe0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5a8>
1005072f4:     	bl	0x100b450dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
1005072f8:     	tbnz	w22, #0x0, 0x100506fe4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5ac>
1005072fc:     	b	0x100507668 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100507300:     	bl	0x100b4013c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100507304:     	add	x8, x0, x20, lsl #3
100507308:     	ldr	x0, [x8, #0x1e8]
10050730c:     	cbnz	x0, 0x100506e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x458>
100507310:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x2dc8>
100507314:     	add	x0, x0, #0x90
100507318:     	bl	0x100b3d95c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10050731c:     	ldr	x8, [x0]
100507320:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100507324:     	cmp	x8, x9
100507328:     	b.lo	0x100506ea0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x468>
10050732c:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100507330:     	add	x0, x0, #0xd28
100507334:     	bl	0x100b1331c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100507338:     	cmp	w10, #0x5b
10050733c:     	cset	w22, eq
100507340:     	mov	w8, #0x1000000          ; =16777216
100507344:     	cmp	x19, x8
100507348:     	mov	w8, #0x5b               ; =91
10050734c:     	ccmp	w10, w8, #0x0, ls
100507350:     	b.ne	0x100506e5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x424>
100507354:     	mov	w28, #0x1               ; =1
100507358:     	mov	w22, #0x1               ; =1
10050735c:     	b	0x100506f40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x508>
100507360:     	mov	w1, #0x0                ; =0
100507364:     	ldr	x8, [sp, #0xa0]
100507368:     	add	x8, x8, x8, lsl #1
10050736c:     	lsl	x8, x8, #2
100507370:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100507374:     	b.ls	0x100507398 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x960>
100507378:     	ldr	q0, [sp, #0xa0]
10050737c:     	str	q0, [sp, #0x10]
100507380:     	ldr	x8, [sp, #0xb0]
100507384:     	str	x8, [sp, #0x20]
100507388:     	mov	w8, #0x4                ; =4
10050738c:     	stp	xzr, x8, [sp, #0xa0]
100507390:     	str	xzr, [sp, #0xb0]
100507394:     	b	0x1005073a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x96c>
100507398:     	stp	x24, x25, [sp, #0x18]
10050739c:     	mov	x8, #-0x1               ; =-1
1005073a0:     	str	x8, [sp, #0x10]
1005073a4:     	add	x0, sp, #0x10
1005073a8:     	bl	0x100377be8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24alloc_lazy_array_backing>
1005073ac:     	mov	x25, #0x7ffd000000000000 ; =9222527611924643840
1005073b0:     	bfxil	x25, x0, #0, #48
1005073b4:     	ldrb	w8, [x20, #0x20]
1005073b8:     	cbnz	w8, 0x100507c3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1204>
1005073bc:     	ldr	x8, [x20]
1005073c0:     	cbnz	x8, 0x100507b44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
1005073c4:     	mov	x8, #-0x1               ; =-1
1005073c8:     	str	x8, [x20]
1005073cc:     	ldr	x26, [x20, #0x18]
1005073d0:     	ldr	x8, [x20, #0x8]
1005073d4:     	cmp	x26, x8
1005073d8:     	b.eq	0x100507a6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1034>
1005073dc:     	ldr	x8, [x20, #0x10]
1005073e0:     	str	x25, [x8, x26, lsl #3]
1005073e4:     	add	x8, x26, #0x1
1005073e8:     	str	x8, [x20, #0x18]
1005073ec:     	ldr	x8, [x20]
1005073f0:     	add	x8, x8, #0x1
1005073f4:     	str	x8, [x20]
1005073f8:     	mov	w25, #0x1               ; =1
1005073fc:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
100507400:     	ldr	w24, [x8, #0x308]
100507404:     	cmp	w24, #0x300
100507408:     	b.hs	0x100507a08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfd0>
10050740c:     	ldr	x8, [x27, #0x48]
100507410:     	cmn	x8, #0x1
100507414:     	b.eq	0x1005079f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfc0>
100507418:     	mrs	x9, TPIDRRO_EL0
10050741c:     	and	x9, x9, #0xfffffffffffffff8
100507420:     	ldr	x0, [x9, x8, lsl #3]
100507424:     	cbz	x0, 0x1005079f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfc0>
100507428:     	add	x8, x0, x24, lsl #3
10050742c:     	ldr	x0, [x8, #0x1e8]
100507430:     	cbz	x0, 0x100507a08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfd0>
100507434:     	ldrb	w8, [x0]
100507438:     	and	w8, w8, #0xfffffffd
10050743c:     	strb	w8, [x0]
100507440:     	mov	w0, #0x0                ; =0
100507444:     	bl	0x10045e1c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy28gc_bump_malloc_trigger_inner>
100507448:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
10050744c:     	ldr	w24, [x8, #0x590]
100507450:     	cmp	w24, #0x300
100507454:     	b.hs	0x100507a28 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xff0>
100507458:     	ldr	x8, [x27, #0x48]
10050745c:     	cmn	x8, #0x1
100507460:     	b.eq	0x100507a18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfe0>
100507464:     	mrs	x9, TPIDRRO_EL0
100507468:     	and	x9, x9, #0xfffffffffffffff8
10050746c:     	ldr	x0, [x9, x8, lsl #3]
100507470:     	cbz	x0, 0x100507a18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfe0>
100507474:     	add	x8, x0, x24, lsl #3
100507478:     	ldr	x0, [x8, #0x1e8]
10050747c:     	cbz	x0, 0x100507a28 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xff0>
100507480:     	ldr	x8, [x0]
100507484:     	lsr	x8, x8, #25
100507488:     	cbz	x8, 0x100507a40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1008>
10050748c:     	bl	0x10045ff74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100507490:     	cmp	x23, #0x3e8
100507494:     	b.hi	0x100507a48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1010>
100507498:     	ldp	x1, x0, [sp]
10050749c:     	bl	0x100231ff8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
1005074a0:     	adrp	x8, 0x100fca000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1005074a4:     	ldr	x8, [x8, #0x7f8]
1005074a8:     	cbnz	x8, 0x100507a60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1028>
1005074ac:     	tbz	w25, #0x0, 0x1005074f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xabc>
1005074b0:     	ldrb	w8, [x20, #0x20]
1005074b4:     	cbnz	w8, 0x100507c98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1260>
1005074b8:     	ldr	x8, [x20]
1005074bc:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1005074c0:     	cmp	x8, x9
1005074c4:     	b.hs	0x100507cc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
1005074c8:     	add	x9, x8, #0x1
1005074cc:     	str	x9, [x20]
1005074d0:     	ldr	x9, [x20, #0x18]
1005074d4:     	cmp	x26, x9
1005074d8:     	b.hs	0x1005074e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xab0>
1005074dc:     	ldr	x9, [x20, #0x10]
1005074e0:     	ldr	x23, [x9, x26, lsl #3]
1005074e4:     	b	0x1005074f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xab8>
1005074e8:     	mov	x23, #0x1               ; =1
1005074ec:     	movk	x23, #0x7ffc, lsl #48
1005074f0:     	str	x8, [x20]
1005074f4:     	str	xzr, [sp, #0xb0]
1005074f8:     	str	xzr, [sp, #0xc8]
1005074fc:     	ldr	x8, [sp, #0xa0]
100507500:     	add	x9, x8, x8, lsl #1
100507504:     	lsl	x9, x9, #2
100507508:     	cmp	x9, #0x100, lsl #12     ; =0x100000
10050750c:     	b.ls	0x100507528 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xaf0>
100507510:     	cbz	x8, 0x10050751c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xae4>
100507514:     	ldr	x0, [sp, #0xa8]
100507518:     	bl	0x100b5fd00 <_mi_free>
10050751c:     	mov	w8, #0x4                ; =4
100507520:     	stp	xzr, x8, [sp, #0xa0]
100507524:     	str	xzr, [sp, #0xb0]
100507528:     	ldr	x8, [sp, #0xb8]
10050752c:     	lsl	x9, x8, #2
100507530:     	cmp	x9, #0x10, lsl #12      ; =0x10000
100507534:     	b.ls	0x100507550 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb18>
100507538:     	cbz	x8, 0x100507544 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb0c>
10050753c:     	ldr	x0, [sp, #0xc0]
100507540:     	bl	0x100b5fd00 <_mi_free>
100507544:     	mov	w8, #0x4                ; =4
100507548:     	stp	xzr, x8, [sp, #0xb8]
10050754c:     	str	xzr, [sp, #0xc8]
100507550:     	ldp	x8, x0, [x22]
100507554:     	ldp	x26, x24, [x22, #0x18]
100507558:     	ldp	q1, q0, [sp, #0xb0]
10050755c:     	ldr	q2, [sp, #0xa0]
100507560:     	stp	q2, q1, [x22]
100507564:     	str	q0, [x22, #0x20]
100507568:     	cmn	x8, #0x1
10050756c:     	b.eq	0x10050761c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbe4>
100507570:     	cbz	x8, 0x100507578 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb40>
100507574:     	bl	0x100b5fd00 <_mi_free>
100507578:     	cbz	x26, 0x10050761c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbe4>
10050757c:     	mov	x0, x24
100507580:     	bl	0x100b5fd00 <_mi_free>
100507584:     	ldrb	w8, [x20, #0x20]
100507588:     	tbnz	w25, #0x0, 0x100507624 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbec>
10050758c:     	cbnz	w8, 0x100507bdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11a4>
100507590:     	ldr	x8, [x20]
100507594:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100507598:     	cmp	x8, x9
10050759c:     	b.hs	0x100507cc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
1005075a0:     	add	x9, x8, #0x1
1005075a4:     	str	x9, [x20]
1005075a8:     	ldr	x9, [x20, #0x18]
1005075ac:     	cmp	x21, x9
1005075b0:     	b.hs	0x1005075d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb9c>
1005075b4:     	ldr	x9, [x20, #0x10]
1005075b8:     	ldr	x9, [x9, x21, lsl #3]
1005075bc:     	and	x22, x9, #0xffffffffffff
1005075c0:     	str	x8, [x20]
1005075c4:     	cmp	x19, #0x3e8
1005075c8:     	csel	w8, wzr, w28, ls
1005075cc:     	cbnz	w8, 0x1005075e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbb0>
1005075d0:     	b	0x100507668 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
1005075d4:     	mov	w22, #0x1               ; =1
1005075d8:     	str	x8, [x20]
1005075dc:     	cmp	x19, #0x3e8
1005075e0:     	csel	w8, wzr, w28, ls
1005075e4:     	cbz	w8, 0x100507668 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
1005075e8:     	mov	x8, #0x0                ; =0
1005075ec:     	mov	x9, #0x2600             ; =9728
1005075f0:     	movk	x9, #0x1, lsl #32
1005075f4:     	add	x10, x22, x8
1005075f8:     	ldrb	w10, [x10, #0x14]
1005075fc:     	cmp	w10, #0x20
100507600:     	b.hi	0x100507644 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc0c>
100507604:     	lsr	x11, x9, x10
100507608:     	tbz	w11, #0x0, 0x100507644 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc0c>
10050760c:     	add	x8, x8, #0x1
100507610:     	cmp	x19, x8
100507614:     	b.ne	0x1005075f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbbc>
100507618:     	b	0x100507668 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
10050761c:     	ldrb	w8, [x20, #0x20]
100507620:     	cbz	w25, 0x10050758c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb54>
100507624:     	cbnz	w8, 0x100507cd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1298>
100507628:     	ldr	x8, [x20]
10050762c:     	cbnz	x8, 0x100507d74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x133c>
100507630:     	ldr	x8, [x20, #0x18]
100507634:     	cmp	x21, x8
100507638:     	b.hi	0x100506a70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
10050763c:     	str	x21, [x20, #0x18]
100507640:     	b	0x100506a70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100507644:     	cmp	w10, #0x5b
100507648:     	b.eq	0x100507654 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc1c>
10050764c:     	cmp	w10, #0x7b
100507650:     	b.ne	0x100507668 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100507654:     	add	x0, x22, #0x14
100507658:     	mov	x1, x19
10050765c:     	mov	w2, #0x3e8              ; =1000
100507660:     	bl	0x1006c5714 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser12depth_blocks21nesting_depth_exceeds>
100507664:     	cbnz	w0, 0x100507b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x112c>
100507668:     	bl	0x1004f0bc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
10050766c:     	bl	0x10045aa80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy16gc_check_trigger>
100507670:     	mov	x0, x19
100507674:     	bl	0x100231eac <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation5begin>
100507678:     	mov	x24, x0
10050767c:     	mov	x22, x1
100507680:     	bl	0x10045a894 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy11gc_suppress>
100507684:     	ldrb	w8, [x20, #0x20]
100507688:     	cbnz	w8, 0x100507af0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10b8>
10050768c:     	ldr	x8, [x20]
100507690:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100507694:     	cmp	x8, x9
100507698:     	b.hs	0x100507cc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
10050769c:     	add	x9, x8, #0x1
1005076a0:     	str	x9, [x20]
1005076a4:     	ldr	x9, [x20, #0x18]
1005076a8:     	cmp	x21, x9
1005076ac:     	b.hs	0x1005076c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc8c>
1005076b0:     	ldr	x9, [x20, #0x10]
1005076b4:     	ldr	x9, [x9, x21, lsl #3]
1005076b8:     	and	x25, x9, #0xffffffffffff
1005076bc:     	add	x1, x25, #0x14
1005076c0:     	b	0x1005076cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc94>
1005076c4:     	mov	w25, #0x1               ; =1
1005076c8:     	mov	w1, #0x15               ; =21
1005076cc:     	str	x8, [x20]
1005076d0:     	add	x0, sp, #0xa0
1005076d4:     	mov	x2, x19
1005076d8:     	mov	x3, x25
1005076dc:     	bl	0x10024828c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23new_batched_from_string>
1005076e0:     	add	x0, sp, #0xa0
1005076e4:     	bl	0x1002453c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value>
1005076e8:     	mov	x23, x0
1005076ec:     	ldp	x26, x28, [sp, #0x108]
1005076f0:     	cmp	x28, x26
1005076f4:     	b.hs	0x100507728 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcf0>
1005076f8:     	ldr	x8, [sp, #0x100]
1005076fc:     	mov	x9, #0x2600             ; =9728
100507700:     	movk	x9, #0x1, lsl #32
100507704:     	ldrb	w10, [x8, x28]
100507708:     	cmp	w10, #0x20
10050770c:     	b.hi	0x100507728 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcf0>
100507710:     	lsr	x10, x9, x10
100507714:     	tbz	w10, #0x0, 0x100507728 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcf0>
100507718:     	add	x28, x28, #0x1
10050771c:     	cmp	x26, x28
100507720:     	b.ne	0x100507704 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xccc>
100507724:     	mov	x28, x26
100507728:     	ldrb	w8, [sp, #0x176]
10050772c:     	tbnz	w8, #0x0, 0x100507a78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1040>
100507730:     	cmp	x28, x26
100507734:     	b.ne	0x100507a84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104c>
100507738:     	ldrb	w8, [sp, #0x174]
10050773c:     	tbz	w8, #0x0, 0x100507a84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104c>
100507740:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
100507744:     	ldr	w26, [x8, #0x560]
100507748:     	cmp	w26, #0x300
10050774c:     	b.hs	0x1005078e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xeac>
100507750:     	ldr	x8, [x27, #0x48]
100507754:     	cmn	x8, #0x1
100507758:     	b.eq	0x1005078d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe9c>
10050775c:     	mrs	x9, TPIDRRO_EL0
100507760:     	and	x9, x9, #0xfffffffffffffff8
100507764:     	ldr	x0, [x9, x8, lsl #3]
100507768:     	cbz	x0, 0x1005078d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe9c>
10050776c:     	add	x8, x0, x26, lsl #3
100507770:     	ldr	x0, [x8, #0x1e8]
100507774:     	cbz	x0, 0x1005078e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xeac>
100507778:     	ldr	x8, [x0]
10050777c:     	cbnz	x8, 0x1005078f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xec0>
100507780:     	ldrb	w8, [x0, #0x24]
100507784:     	cmp	w8, #0x2
100507788:     	b.eq	0x1005077ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd74>
10050778c:     	ldr	x8, [x0, #0x8]
100507790:     	cmp	x8, x25
100507794:     	b.ne	0x1005077ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd74>
100507798:     	ldr	w8, [x0, #0x18]
10050779c:     	cmp	x19, x8
1005077a0:     	b.ne	0x1005077ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd74>
1005077a4:     	mov	w8, #0x1                ; =1
1005077a8:     	strb	w8, [x0, #0x24]
1005077ac:     	mov	x0, x25
1005077b0:     	mov	x1, x19
1005077b4:     	mov	x2, x23
1005077b8:     	bl	0x1004edd00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template>
1005077bc:     	ldrb	w8, [x20, #0x20]
1005077c0:     	cbnz	w8, 0x100507b20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10e8>
1005077c4:     	ldr	x8, [x20]
1005077c8:     	cbnz	x8, 0x100507b44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
1005077cc:     	mov	x8, #-0x1               ; =-1
1005077d0:     	str	x8, [x20]
1005077d4:     	ldr	x19, [x20, #0x18]
1005077d8:     	ldr	x8, [x20, #0x8]
1005077dc:     	cmp	x19, x8
1005077e0:     	b.eq	0x100507904 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xecc>
1005077e4:     	ldr	x8, [x20, #0x10]
1005077e8:     	str	x23, [x8, x19, lsl #3]
1005077ec:     	add	x8, x19, #0x1
1005077f0:     	str	x8, [x20, #0x18]
1005077f4:     	ldr	x8, [x20]
1005077f8:     	add	x8, x8, #0x1
1005077fc:     	str	x8, [x20]
100507800:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
100507804:     	ldr	w19, [x8, #0x308]
100507808:     	cmp	w19, #0x300
10050780c:     	b.hs	0x100507920 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xee8>
100507810:     	ldr	x8, [x27, #0x48]
100507814:     	cmn	x8, #0x1
100507818:     	b.eq	0x100507910 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xed8>
10050781c:     	mrs	x9, TPIDRRO_EL0
100507820:     	and	x9, x9, #0xfffffffffffffff8
100507824:     	ldr	x0, [x9, x8, lsl #3]
100507828:     	cbz	x0, 0x100507910 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xed8>
10050782c:     	add	x8, x0, x19, lsl #3
100507830:     	ldr	x0, [x8, #0x1e8]
100507834:     	cbz	x0, 0x100507920 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xee8>
100507838:     	ldrb	w8, [x0]
10050783c:     	and	w8, w8, #0xfffffffd
100507840:     	strb	w8, [x0]
100507844:     	mov	w0, #0x0                ; =0
100507848:     	bl	0x10045e1c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy28gc_bump_malloc_trigger_inner>
10050784c:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
100507850:     	ldr	w19, [x8, #0x590]
100507854:     	cmp	w19, #0x300
100507858:     	b.hs	0x100507940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf08>
10050785c:     	ldr	x8, [x27, #0x48]
100507860:     	cmn	x8, #0x1
100507864:     	b.eq	0x100507930 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xef8>
100507868:     	mrs	x9, TPIDRRO_EL0
10050786c:     	and	x9, x9, #0xfffffffffffffff8
100507870:     	ldr	x0, [x9, x8, lsl #3]
100507874:     	cbz	x0, 0x100507930 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xef8>
100507878:     	add	x8, x0, x19, lsl #3
10050787c:     	ldr	x0, [x8, #0x1e8]
100507880:     	cbz	x0, 0x100507940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf08>
100507884:     	ldr	x8, [x0]
100507888:     	lsr	x8, x8, #25
10050788c:     	cbz	x8, 0x100507958 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf20>
100507890:     	bl	0x10045ff74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100507894:     	bl	0x1004622a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100507898:     	mov	x0, x24
10050789c:     	mov	x1, x22
1005078a0:     	bl	0x100231ff8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
1005078a4:     	ldrb	w8, [x20, #0x20]
1005078a8:     	cbz	w8, 0x100507970 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf38>
1005078ac:     	cmp	w8, #0x2
1005078b0:     	b.eq	0x100507cd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
1005078b4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
1005078b8:     	add	x1, x1, #0x998
1005078bc:     	mov	x0, x20
1005078c0:     	bl	0x100a2101c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1005078c4:     	strb	wzr, [x20, #0x20]
1005078c8:     	ldr	x8, [x20]
1005078cc:     	cbz	x8, 0x100507978 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf40>
1005078d0:     	b	0x100507d74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x133c>
1005078d4:     	bl	0x100b4013c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005078d8:     	add	x8, x0, x26, lsl #3
1005078dc:     	ldr	x0, [x8, #0x1e8]
1005078e0:     	cbnz	x0, 0x100507778 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd40>
1005078e4:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x2dc8>
1005078e8:     	add	x0, x0, #0x90
1005078ec:     	bl	0x100b3d95c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1005078f0:     	ldr	x8, [x0]
1005078f4:     	cbz	x8, 0x100507780 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd48>
1005078f8:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1005078fc:     	add	x0, x0, #0xd10
100507900:     	bl	0x100b132ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100507904:     	add	x0, x20, #0x8
100507908:     	bl	0x100b3ca2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10050790c:     	b	0x1005077e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xdac>
100507910:     	bl	0x100b4013c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100507914:     	add	x8, x0, x19, lsl #3
100507918:     	ldr	x0, [x8, #0x1e8]
10050791c:     	cbnz	x0, 0x100507838 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe00>
100507920:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x150>
100507924:     	add	x0, x0, #0xdc8
100507928:     	bl	0x100b3d9a8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
10050792c:     	b	0x100507838 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe00>
100507930:     	bl	0x100b4013c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100507934:     	add	x8, x0, x19, lsl #3
100507938:     	ldr	x0, [x8, #0x1e8]
10050793c:     	cbnz	x0, 0x100507884 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe4c>
100507940:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x2dc8>
100507944:     	add	x0, x0, #0x168
100507948:     	bl	0x100b3d95c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10050794c:     	ldr	x8, [x0]
100507950:     	lsr	x8, x8, #25
100507954:     	cbnz	x8, 0x100507890 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe58>
100507958:     	bl	0x1004622a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
10050795c:     	mov	x0, x24
100507960:     	mov	x1, x22
100507964:     	bl	0x100231ff8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100507968:     	ldrb	w8, [x20, #0x20]
10050796c:     	cbnz	w8, 0x1005078ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe74>
100507970:     	ldr	x8, [x20]
100507974:     	cbnz	x8, 0x100507d74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x133c>
100507978:     	ldr	x8, [x20, #0x18]
10050797c:     	cmp	x21, x8
100507980:     	b.ls	0x1005079a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf70>
100507984:     	adrp	x8, 0x100fca000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100507988:     	ldr	x8, [x8, #0x7f8]
10050798c:     	cbnz	x8, 0x1005079b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf80>
100507990:     	ldr	x8, [sp, #0xd8]
100507994:     	cmp	x8, #0x1
100507998:     	b.lt	0x100506a70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
10050799c:     	ldr	x0, [sp, #0xe0]
1005079a0:     	bl	0x100b5fd00 <_mi_free>
1005079a4:     	b	0x100506a70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
1005079a8:     	str	x21, [x20, #0x18]
1005079ac:     	adrp	x8, 0x100fca000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1005079b0:     	ldr	x8, [x8, #0x7f8]
1005079b4:     	cbz	x8, 0x100507990 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf58>
1005079b8:     	bl	0x100b46830 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
1005079bc:     	ldr	x8, [sp, #0xd8]
1005079c0:     	cmp	x8, #0x1
1005079c4:     	b.ge	0x10050799c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf64>
1005079c8:     	b	0x100506a70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
1005079cc:     	bl	0x100b4013c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005079d0:     	add	x8, x0, x24, lsl #3
1005079d4:     	ldr	x0, [x8, #0x1e8]
1005079d8:     	cbnz	x0, 0x1005070f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6b8>
1005079dc:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x150>
1005079e0:     	add	x0, x0, #0xd98
1005079e4:     	bl	0x100b3d9a8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1005079e8:     	ldrb	w8, [x0]
1005079ec:     	cbz	w8, 0x1005070f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6c0>
1005079f0:     	bl	0x100b450dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
1005079f4:     	b	0x1005070f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6c0>
1005079f8:     	bl	0x100b4013c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005079fc:     	add	x8, x0, x24, lsl #3
100507a00:     	ldr	x0, [x8, #0x1e8]
100507a04:     	cbnz	x0, 0x100507434 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9fc>
100507a08:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x150>
100507a0c:     	add	x0, x0, #0xdc8
100507a10:     	bl	0x100b3d9a8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
100507a14:     	b	0x100507434 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9fc>
100507a18:     	bl	0x100b4013c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100507a1c:     	add	x8, x0, x24, lsl #3
100507a20:     	ldr	x0, [x8, #0x1e8]
100507a24:     	cbnz	x0, 0x100507480 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa48>
100507a28:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x2dc8>
100507a2c:     	add	x0, x0, #0x168
100507a30:     	bl	0x100b3d95c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100507a34:     	ldr	x8, [x0]
100507a38:     	lsr	x8, x8, #25
100507a3c:     	cbnz	x8, 0x10050748c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa54>
100507a40:     	cmp	x23, #0x3e8
100507a44:     	b.ls	0x100507498 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa60>
100507a48:     	bl	0x1004622a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100507a4c:     	ldp	x1, x0, [sp]
100507a50:     	bl	0x100231ff8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100507a54:     	adrp	x8, 0x100fca000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100507a58:     	ldr	x8, [x8, #0x7f8]
100507a5c:     	cbz	x8, 0x1005074ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa74>
100507a60:     	bl	0x100b46830 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
100507a64:     	tbnz	w25, #0x0, 0x1005074b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa78>
100507a68:     	b	0x1005074f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xabc>
100507a6c:     	add	x0, x20, #0x8
100507a70:     	bl	0x100b3ca2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100507a74:     	b	0x1005073dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9a4>
100507a78:     	bl	0x100b46604 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar15clear_key_cache>
100507a7c:     	cmp	x28, x26
100507a80:     	b.eq	0x100507738 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd00>
100507a84:     	mov	x0, x23
100507a88:     	bl	0x10032894c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15parse_root_push>
100507a8c:     	bl	0x10045a9fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy13gc_unsuppress>
100507a90:     	bl	0x1004f0b24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat26finish_parse_gc_accounting>
100507a94:     	bl	0x1004622a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100507a98:     	mov	x0, x24
100507a9c:     	mov	x1, x22
100507aa0:     	bl	0x100231ff8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100507aa4:     	mov	x0, x21
100507aa8:     	bl	0x100328b5c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json18parse_root_restore>
100507aac:     	adrp	x8, 0x100fca000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100507ab0:     	ldr	x8, [x8, #0x7f8]
100507ab4:     	cbnz	x8, 0x10050801c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15e4>
100507ab8:     	adrp	x0, 0x100c76000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x710c>
100507abc:     	add	x0, x0, #0x3b0
100507ac0:     	mov	w1, #0x21               ; =33
100507ac4:     	bl	0x1005094e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
100507ac8:     	cmp	w8, #0x2
100507acc:     	b.eq	0x100507cd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100507ad0:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100507ad4:     	add	x1, x1, #0x998
100507ad8:     	mov	x0, x20
100507adc:     	bl	0x100a2101c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100507ae0:     	strb	wzr, [x20, #0x20]
100507ae4:     	ldr	x8, [x20]
100507ae8:     	cbz	x8, 0x100506f64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x52c>
100507aec:     	b	0x100507b44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
100507af0:     	cmp	w8, #0x2
100507af4:     	b.eq	0x100507cd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100507af8:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100507afc:     	add	x1, x1, #0x998
100507b00:     	mov	x0, x20
100507b04:     	bl	0x100a2101c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100507b08:     	strb	wzr, [x20, #0x20]
100507b0c:     	ldr	x8, [x20]
100507b10:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100507b14:     	cmp	x8, x9
100507b18:     	b.lo	0x10050769c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc64>
100507b1c:     	b	0x100507cc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100507b20:     	cmp	w8, #0x2
100507b24:     	b.eq	0x100507cd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100507b28:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100507b2c:     	add	x1, x1, #0x998
100507b30:     	mov	x0, x20
100507b34:     	bl	0x100a2101c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100507b38:     	strb	wzr, [x20, #0x20]
100507b3c:     	ldr	x8, [x20]
100507b40:     	cbz	x8, 0x1005077cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd94>
100507b44:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100507b48:     	add	x0, x0, #0x440
100507b4c:     	bl	0x100b132ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100507b50:     	mov	x0, x22
100507b54:     	bl	0x100b1f0ec <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11TapeScratchEEuE16get_or_init_slowNvNvB2b_12TAPE_SCRATCH27___rust_std_internal_init_fnEB2d_>
100507b58:     	mov	x22, x0
100507b5c:     	cbnz	x0, 0x100507048 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x610>
100507b60:     	b	0x100507cd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100507b64:     	mov	x0, x21
100507b68:     	bl	0x100328b5c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json18parse_root_restore>
100507b6c:     	mov	x0, x22
100507b70:     	mov	x1, x19
100507b74:     	bl	0x100b46b78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api19parse_deep_or_throw>
100507b78:     	mov	x23, x0
100507b7c:     	b	0x100506a70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100507b80:     	cmp	w8, #0x2
100507b84:     	b.eq	0x100507cd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100507b88:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100507b8c:     	add	x1, x1, #0x998
100507b90:     	mov	x0, x20
100507b94:     	bl	0x100a2101c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100507b98:     	strb	wzr, [x20, #0x20]
100507b9c:     	ldr	x8, [x20]
100507ba0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100507ba4:     	cmp	x8, x9
100507ba8:     	b.lo	0x100506ffc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5c4>
100507bac:     	b	0x100507cc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100507bb0:     	cmp	x9, #0x6
100507bb4:     	b.eq	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507bb8:     	ldrb	w8, [x21, #0x1a]
100507bbc:     	cmp	w8, #0x22
100507bc0:     	b.ne	0x100507ce4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12ac>
100507bc4:     	mov	w23, #0x0               ; =0
100507bc8:     	mov	w28, #0x0               ; =0
100507bcc:     	mov	w27, #0x0               ; =0
100507bd0:     	mov	w26, #0x1               ; =1
100507bd4:     	mov	w20, #0x4               ; =4
100507bd8:     	b	0x100506bf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100507bdc:     	cmp	w8, #0x2
100507be0:     	b.eq	0x100507cd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100507be4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100507be8:     	add	x1, x1, #0x998
100507bec:     	mov	x0, x20
100507bf0:     	bl	0x100a2101c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100507bf4:     	strb	wzr, [x20, #0x20]
100507bf8:     	ldr	x8, [x20]
100507bfc:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100507c00:     	cmp	x8, x9
100507c04:     	b.lo	0x1005075a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb68>
100507c08:     	b	0x100507cc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100507c0c:     	cmp	w8, #0x2
100507c10:     	b.eq	0x100507cd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100507c14:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100507c18:     	add	x1, x1, #0x998
100507c1c:     	mov	x0, x20
100507c20:     	bl	0x100a2101c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100507c24:     	strb	wzr, [x20, #0x20]
100507c28:     	ldr	x8, [x20]
100507c2c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100507c30:     	cmp	x8, x9
100507c34:     	b.lo	0x10050712c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6f4>
100507c38:     	b	0x100507cc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100507c3c:     	cmp	w8, #0x2
100507c40:     	b.eq	0x100507cd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100507c44:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100507c48:     	add	x1, x1, #0x998
100507c4c:     	mov	x0, x20
100507c50:     	bl	0x100a2101c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100507c54:     	strb	wzr, [x20, #0x20]
100507c58:     	ldr	x8, [x20]
100507c5c:     	cbz	x8, 0x1005073c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x98c>
100507c60:     	b	0x100507b44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
100507c64:     	cmp	x9, #0x1
100507c68:     	b.ne	0x100507d14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12dc>
100507c6c:     	ldrb	w8, [x8]
100507c70:     	sub	w9, w8, #0x30
100507c74:     	cmp	w9, #0xa
100507c78:     	b.hs	0x100507d18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12e0>
100507c7c:     	and	w8, w9, #0xff
100507c80:     	ucvtf	d0, w8
100507c84:     	fmov	x1, d0
100507c88:     	orr	x0, x25, x26
100507c8c:     	bl	0x1004f6cf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object18allocate_one_field>
100507c90:     	tbnz	w0, #0x0, 0x100506a6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x34>
100507c94:     	b	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507c98:     	cmp	w8, #0x2
100507c9c:     	b.eq	0x100507cd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100507ca0:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100507ca4:     	add	x1, x1, #0x998
100507ca8:     	mov	x0, x20
100507cac:     	bl	0x100a2101c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100507cb0:     	strb	wzr, [x20, #0x20]
100507cb4:     	ldr	x8, [x20]
100507cb8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100507cbc:     	cmp	x8, x9
100507cc0:     	b.lo	0x1005074c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa90>
100507cc4:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100507cc8:     	add	x0, x0, #0x410
100507ccc:     	bl	0x100b1331c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100507cd0:     	cmp	w8, #0x2
100507cd4:     	b.ne	0x100507d58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1320>
100507cd8:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100507cdc:     	add	x0, x0, #0xc18
100507ce0:     	bl	0x100b5935c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100507ce4:     	sub	x8, x19, #0x1
100507ce8:     	cmp	x8, #0x7
100507cec:     	b.eq	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507cf0:     	ldrb	w8, [x21, #0x1b]
100507cf4:     	cmp	w8, #0x22
100507cf8:     	b.ne	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507cfc:     	mov	w23, #0x0               ; =0
100507d00:     	mov	w28, #0x0               ; =0
100507d04:     	mov	w27, #0x0               ; =0
100507d08:     	mov	w26, #0x0               ; =0
100507d0c:     	mov	w20, #0x5               ; =5
100507d10:     	b	0x100506bf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100507d14:     	ldrb	w8, [x8]
100507d18:     	orr	w8, w8, #0x20
100507d1c:     	cmp	w8, #0x7b
100507d20:     	b.eq	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507d24:     	sub	x11, x19, #0x5
100507d28:     	mov	x10, #0x2600            ; =9728
100507d2c:     	movk	x10, #0x1, lsl #32
100507d30:     	add	x8, x21, x20
100507d34:     	ldrb	w9, [x8, #0x18]
100507d38:     	cmp	w9, #0x20
100507d3c:     	b.hi	0x100507d80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1348>
100507d40:     	lsr	x12, x10, x9
100507d44:     	tbz	w12, #0x0, 0x100507d80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1348>
100507d48:     	add	x20, x20, #0x1
100507d4c:     	cmp	x11, x20
100507d50:     	b.ne	0x100507d30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12f8>
100507d54:     	b	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507d58:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100507d5c:     	add	x1, x1, #0x998
100507d60:     	mov	x0, x20
100507d64:     	bl	0x100a2101c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100507d68:     	strb	wzr, [x20, #0x20]
100507d6c:     	ldr	x8, [x20]
100507d70:     	cbz	x8, 0x100507630 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbf8>
100507d74:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100507d78:     	add	x0, x0, #0x4a0
100507d7c:     	bl	0x100b132ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100507d80:     	cmp	x11, x20
100507d84:     	b.eq	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507d88:     	add	x13, x21, #0x12
100507d8c:     	mov	x14, #0x2600            ; =9728
100507d90:     	movk	x14, #0x1, lsl #32
100507d94:     	mov	x10, x20
100507d98:     	ldrb	w12, [x13, x19]
100507d9c:     	cmp	w12, #0x20
100507da0:     	b.hi	0x100507dd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1398>
100507da4:     	lsr	x15, x14, x12
100507da8:     	tbz	w15, #0x0, 0x100507dd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1398>
100507dac:     	sub	x13, x13, #0x1
100507db0:     	add	x10, x10, #0x1
100507db4:     	cmp	x11, x10
100507db8:     	b.ne	0x100507d98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1360>
100507dbc:     	b	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507dc0:     	adrp	x2, 0x100f0b000 <__RNvNtCs3gRpqoBkMHm_13perry_runtime7promise17ITER_RESULT_VALUE+0x10>
100507dc4:     	add	x2, x2, #0x260
100507dc8:     	mov	x1, x25
100507dcc:     	bl	0x100b1344c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100507dd0:     	sub	x11, x19, x10
100507dd4:     	sub	x1, x11, #0x5
100507dd8:     	cmp	x1, #0x4
100507ddc:     	b.eq	0x100507e48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1410>
100507de0:     	cmp	x1, #0x5
100507de4:     	b.ne	0x100507e50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1418>
100507de8:     	cmp	w9, #0x22
100507dec:     	b.eq	0x100507e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1444>
100507df0:     	cmp	w9, #0x2d
100507df4:     	b.eq	0x100507e6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1434>
100507df8:     	cmp	w9, #0x66
100507dfc:     	b.ne	0x100507e60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1428>
100507e00:     	add	x8, x21, x20
100507e04:     	ldrb	w9, [x8, #0x19]
100507e08:     	cmp	w9, #0x61
100507e0c:     	b.ne	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507e10:     	ldrb	w8, [x8, #0x1a]
100507e14:     	cmp	w8, #0x6c
100507e18:     	b.ne	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507e1c:     	add	x8, x21, x20
100507e20:     	ldrb	w9, [x8, #0x1b]
100507e24:     	cmp	w9, #0x73
100507e28:     	b.ne	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507e2c:     	ldrb	w8, [x8, #0x1c]
100507e30:     	cmp	w8, #0x65
100507e34:     	b.ne	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507e38:     	mov	x8, #0x1                ; =1
100507e3c:     	movk	x8, #0x7ffc, lsl #48
100507e40:     	orr	x1, x8, #0x2
100507e44:     	b	0x100507c88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100507e48:     	cmp	w9, #0x6d
100507e4c:     	b.gt	0x100507ee8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14b0>
100507e50:     	cmp	w9, #0x22
100507e54:     	b.eq	0x100507e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1444>
100507e58:     	cmp	w9, #0x2d
100507e5c:     	b.eq	0x100507e6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1434>
100507e60:     	sub	w9, w9, #0x30
100507e64:     	cmp	w9, #0xa
100507e68:     	b.hs	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507e6c:     	add	x0, x8, #0x18
100507e70:     	bl	0x1004ee908 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar12parse_number>
100507e74:     	tbz	w0, #0x0, 0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507e78:     	b	0x100507c88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100507e7c:     	sub	x8, x19, #0x6
100507e80:     	cmp	x8, x10
100507e84:     	b.eq	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507e88:     	cmp	x1, #0x7
100507e8c:     	b.hi	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507e90:     	cmp	w12, #0x22
100507e94:     	b.ne	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507e98:     	sub	x23, x11, #0x7
100507e9c:     	sub	x8, x19, #0x7
100507ea0:     	add	x9, x21, x20
100507ea4:     	add	x22, x9, #0x19
100507ea8:     	cmp	x8, x10
100507eac:     	b.ne	0x100507f70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1538>
100507eb0:     	add	x8, sp, #0xa0
100507eb4:     	mov	x0, x22
100507eb8:     	mov	x1, x23
100507ebc:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100507ec0:     	ldr	x8, [sp, #0xa0]
100507ec4:     	cbnz	x8, 0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507ec8:     	cmp	x23, #0x2
100507ecc:     	b.gt	0x100507fa0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1568>
100507ed0:     	cbz	x23, 0x100507fbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1584>
100507ed4:     	cmp	x23, #0x1
100507ed8:     	b.ne	0x100507fc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x158c>
100507edc:     	ldrb	w8, [x22]
100507ee0:     	mov	x9, #0x10000000000      ; =1099511627776
100507ee4:     	b	0x100508010 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
100507ee8:     	cmp	w9, #0x74
100507eec:     	b.eq	0x100507f34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14fc>
100507ef0:     	cmp	w9, #0x6e
100507ef4:     	b.ne	0x100507e60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1428>
100507ef8:     	add	x8, x21, x20
100507efc:     	ldrb	w9, [x8, #0x19]
100507f00:     	cmp	w9, #0x75
100507f04:     	b.ne	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507f08:     	ldrb	w8, [x8, #0x1a]
100507f0c:     	cmp	w8, #0x6c
100507f10:     	b.ne	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507f14:     	add	x8, x21, x20
100507f18:     	ldrb	w8, [x8, #0x1b]
100507f1c:     	cmp	w8, #0x6c
100507f20:     	b.ne	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507f24:     	mov	x8, #0x1                ; =1
100507f28:     	movk	x8, #0x7ffc, lsl #48
100507f2c:     	add	x1, x8, #0x1
100507f30:     	b	0x100507c88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100507f34:     	add	x8, x21, x20
100507f38:     	ldrb	w9, [x8, #0x19]
100507f3c:     	cmp	w9, #0x72
100507f40:     	b.ne	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507f44:     	ldrb	w8, [x8, #0x1a]
100507f48:     	cmp	w8, #0x75
100507f4c:     	b.ne	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507f50:     	add	x8, x21, x20
100507f54:     	ldrb	w8, [x8, #0x1b]
100507f58:     	cmp	w8, #0x65
100507f5c:     	b.ne	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507f60:     	mov	x8, #0x1                ; =1
100507f64:     	movk	x8, #0x7ffc, lsl #48
100507f68:     	add	x1, x8, #0x3
100507f6c:     	b	0x100507c88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100507f70:     	mov	x8, x23
100507f74:     	mov	x9, x22
100507f78:     	ldrb	w10, [x9], #0x1
100507f7c:     	cmp	w10, #0x20
100507f80:     	b.lo	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507f84:     	cmp	w10, #0x22
100507f88:     	b.eq	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507f8c:     	cmp	w10, #0x5c
100507f90:     	b.eq	0x100506abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507f94:     	subs	x8, x8, #0x1
100507f98:     	b.ne	0x100507f78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1540>
100507f9c:     	b	0x100507eb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1478>
100507fa0:     	cmp	x23, #0x3
100507fa4:     	b.eq	0x100507fdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15a4>
100507fa8:     	cmp	x23, #0x4
100507fac:     	b.ne	0x100507ffc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15c4>
100507fb0:     	ldr	w8, [x22]
100507fb4:     	mov	x9, #0x40000000000      ; =4398046511104
100507fb8:     	b	0x100508010 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
100507fbc:     	mov	x1, #0x7ff9000000000000 ; =9221401712017801216
100507fc0:     	b	0x100507c88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100507fc4:     	ldrb	w8, [x22]
100507fc8:     	add	x9, x21, x20
100507fcc:     	ldrb	w9, [x9, #0x1a]
100507fd0:     	orr	x8, x8, x9, lsl #8
100507fd4:     	mov	x9, #0x20000000000      ; =2199023255552
100507fd8:     	b	0x100508010 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
100507fdc:     	ldrb	w8, [x22]
100507fe0:     	add	x9, x21, x20
100507fe4:     	ldrb	w10, [x9, #0x1a]
100507fe8:     	ldrb	w9, [x9, #0x1b]
100507fec:     	orr	x8, x8, x10, lsl #8
100507ff0:     	orr	x8, x8, x9, lsl #16
100507ff4:     	mov	x9, #0x30000000000      ; =3298534883328
100507ff8:     	b	0x100508010 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
100507ffc:     	ldr	w8, [x22]
100508000:     	add	x9, x21, x20
100508004:     	ldrb	w9, [x9, #0x1d]
100508008:     	orr	x8, x8, x9, lsl #32
10050800c:     	mov	x9, #0x50000000000      ; =5497558138880
100508010:     	movk	x9, #0x7ff9, lsl #48
100508014:     	orr	x1, x8, x9
100508018:     	b	0x100507c88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
10050801c:     	bl	0x100b46830 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
100508020:     	adrp	x0, 0x100c76000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x710c>
100508024:     	add	x0, x0, #0x3b0
100508028:     	mov	w1, #0x21               ; =33
10050802c:     	bl	0x1005094e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
