
benchmarks/json_performance/.work/tape-batch-r18/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100246c98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped>:
100246c98:     	stp	x28, x27, [sp, #-0x60]!
100246c9c:     	stp	x26, x25, [sp, #0x10]
100246ca0:     	stp	x24, x23, [sp, #0x20]
100246ca4:     	stp	x22, x21, [sp, #0x30]
100246ca8:     	stp	x20, x19, [sp, #0x40]
100246cac:     	stp	x29, x30, [sp, #0x50]
100246cb0:     	add	x29, sp, #0x50
100246cb4:     	sub	sp, sp, #0x2e0
100246cb8:     	mov	x19, x0
100246cbc:     	ldp	x8, x9, [x0, #0x68]
100246cc0:     	add	x9, x9, #0x1
100246cc4:     	str	x9, [x0, #0x70]
100246cc8:     	cmp	x9, x8
100246ccc:     	b.hs	0x100246d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x68>
100246cd0:     	ldr	x10, [x19, #0x60]
100246cd4:     	mov	x11, #0x2600            ; =9728
100246cd8:     	movk	x11, #0x1, lsl #32
100246cdc:     	ldrb	w12, [x10, x9]
100246ce0:     	cmp	w12, #0x20
100246ce4:     	b.hi	0x100246d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x68>
100246ce8:     	lsr	x12, x11, x12
100246cec:     	tbz	w12, #0x0, 0x100246d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x68>
100246cf0:     	add	x9, x9, #0x1
100246cf4:     	str	x9, [x19, #0x70]
100246cf8:     	cmp	x8, x9
100246cfc:     	b.ne	0x100246cdc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x44>
100246d00:     	ldrb	w8, [x19, #0xd5]
100246d04:     	tbz	w8, #0x0, 0x100246d30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x98>
100246d08:     	strb	wzr, [x19, #0xd5]
100246d0c:     	ldr	x21, [x19, #0x78]
100246d10:     	ldp	q0, q1, [x19, #0x80]
100246d14:     	stur	q0, [sp, #0xa8]
100246d18:     	stur	q1, [sp, #0xb8]
100246d1c:     	ldp	q0, q1, [x19, #0xa0]
100246d20:     	stur	q0, [sp, #0xc8]
100246d24:     	stur	q1, [sp, #0xd8]
100246d28:     	ldr	x9, [x19, #0xc0]
100246d2c:     	b	0x100246d68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd0>
100246d30:     	mov	w26, #0x0               ; =0
100246d34:     	mov	x8, #0x0                ; =0
100246d38:     	ldr	x21, [x19, #0x78]
100246d3c:     	cbz	x21, 0x100247e94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11fc>
100246d40:     	ldr	x10, [x19, #0xc0]
100246d44:     	str	x10, [sp, #0x88]
100246d48:     	cbz	x10, 0x100246d84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xec>
100246d4c:     	ldp	q0, q1, [x19, #0x80]
100246d50:     	stur	q0, [sp, #0xa8]
100246d54:     	stur	q1, [sp, #0xb8]
100246d58:     	ldp	q0, q1, [x19, #0xa0]
100246d5c:     	stur	q0, [sp, #0xc8]
100246d60:     	stur	q1, [sp, #0xd8]
100246d64:     	ldr	x9, [sp, #0x88]
100246d68:     	ldr	w8, [x19, #0xd0]
100246d6c:     	stp	x21, x9, [sp, #0xe8]
100246d70:     	str	x9, [sp, #0x88]
100246d74:     	str	w8, [sp, #0x64]
100246d78:     	str	w8, [sp, #0xf8]
100246d7c:     	mov	w8, #0x1                ; =1
100246d80:     	mov	w26, #0x1               ; =1
100246d84:     	str	x8, [sp, #0xa0]
100246d88:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100246d8c:     	add	x0, x0, #0xce8
100246d90:     	ldr	x8, [x0]
100246d94:     	blr	x8
100246d98:     	mov	x20, x0
100246d9c:     	ldrb	w8, [x0, #0x20]
100246da0:     	cbnz	w8, 0x10024812c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1494>
100246da4:     	ldr	x8, [x20]
100246da8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100246dac:     	cmp	x8, x9
100246db0:     	b.hs	0x100248158 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x14c0>
100246db4:     	ldr	x22, [x20, #0x18]
100246db8:     	ldp	x23, x24, [x19, #0x68]
100246dbc:     	cmp	x24, x23
100246dc0:     	b.hs	0x100246df4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15c>
100246dc4:     	ldr	x8, [x19, #0x60]
100246dc8:     	ldrb	w8, [x8, x24]
100246dcc:     	cmp	w8, #0x7d
100246dd0:     	b.ne	0x100246df4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15c>
100246dd4:     	add	x8, x24, #0x1
100246dd8:     	str	x8, [x19, #0x70]
100246ddc:     	ldr	x8, [x19, #0x78]
100246de0:     	cbnz	x8, 0x100247e98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1200>
100246de4:     	ldr	x1, [x19, #0xc0]
100246de8:     	cbz	x1, 0x100247e98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1200>
100246dec:     	ldr	w2, [x19, #0xd0]
100246df0:     	b	0x100247eb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1220>
100246df4:     	movi.2d	v0, #0000000000000000
100246df8:     	stp	q0, q0, [sp, #0x120]
100246dfc:     	stp	q0, q0, [sp, #0x100]
100246e00:     	adrp	x1, 0x100c9c000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x7060>
100246e04:     	add	x1, x1, #0xa80
100246e08:     	add	x0, sp, #0x148
100246e0c:     	mov	w2, #0x40               ; =64
100246e10:     	bl	0x100b62bd0 <_writev+0x100b62bd0>
100246e14:     	mov	x27, #0x0               ; =0
100246e18:     	str	xzr, [sp, #0x90]
100246e1c:     	mov	x8, #-0x1               ; =-1
100246e20:     	str	x8, [sp, #0x188]
100246e24:     	add	x8, sp, #0xa0
100246e28:     	add	x8, x8, #0x8
100246e2c:     	stp	x8, xzr, [sp, #0x68]
100246e30:     	mov	x25, #0x2600            ; =9728
100246e34:     	movk	x25, #0x1, lsl #32
100246e38:     	adrp	x8, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5060>
100246e3c:     	ldr	q0, [x8, #0x830]
100246e40:     	str	q0, [sp, #0x40]
100246e44:     	adrp	x8, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5060>
100246e48:     	ldr	q0, [x8, #0x840]
100246e4c:     	str	q0, [sp, #0x30]
100246e50:     	adrp	x8, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5060>
100246e54:     	ldr	q0, [x8, #0x820]
100246e58:     	str	q0, [sp, #0x50]
100246e5c:     	mov	x11, x26
100246e60:     	mov	x8, x26
100246e64:     	str	w26, [sp, #0x80]
100246e68:     	str	w8, [sp, #0x84]
100246e6c:     	cmp	x24, x23
100246e70:     	b.hs	0x100246ea0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x208>
100246e74:     	ldr	x8, [x19, #0x60]
100246e78:     	ldrb	w9, [x8, x24]
100246e7c:     	cmp	w9, #0x20
100246e80:     	b.hi	0x100246ea0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x208>
100246e84:     	lsr	x9, x25, x9
100246e88:     	tbz	w9, #0x0, 0x100246ea0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x208>
100246e8c:     	add	x24, x24, #0x1
100246e90:     	str	x24, [x19, #0x70]
100246e94:     	cmp	x23, x24
100246e98:     	b.ne	0x100246e78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1e0>
100246e9c:     	mov	x24, x23
100246ea0:     	str	w11, [sp, #0x7c]
100246ea4:     	str	x27, [sp, #0x98]
100246ea8:     	cbz	w26, 0x100246f60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100246eac:     	cmp	x27, x21
100246eb0:     	cset	w8, lo
100246eb4:     	tst	w11, w8
100246eb8:     	b.eq	0x100246f60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100246ebc:     	cmp	x27, #0x8
100246ec0:     	b.hs	0x100248200 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1568>
100246ec4:     	cmp	x24, x23
100246ec8:     	b.hs	0x100246f60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100246ecc:     	ldr	x8, [sp, #0x68]
100246ed0:     	ldr	x9, [x8, x27, lsl #3]
100246ed4:     	cbz	x9, 0x100246f60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100246ed8:     	ldr	x10, [x19, #0x60]
100246edc:     	ldrb	w8, [x10, x24]
100246ee0:     	cmp	w8, #0x22
100246ee4:     	b.ne	0x100246f60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100246ee8:     	add	x11, x24, #0x1
100246eec:     	ldr	w14, [x9, #0x4]
100246ef0:     	add	x8, x11, x14
100246ef4:     	cmp	x8, x23
100246ef8:     	ccmp	x8, x24, #0x0, lo
100246efc:     	b.ls	0x100246f60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100246f00:     	ldrb	w12, [x10, x8]
100246f04:     	cmp	w12, #0x22
100246f08:     	b.ne	0x100246f60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100246f0c:     	add	x24, x10, x11
100246f10:     	cbz	w14, 0x100246f4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2b4>
100246f14:     	add	x9, x9, #0x14
100246f18:     	mov	x10, x14
100246f1c:     	mov	x11, x24
100246f20:     	ldrb	w12, [x11], #0x1
100246f24:     	cmp	w12, #0x5c
100246f28:     	b.eq	0x100246f60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100246f2c:     	cmp	w12, #0x22
100246f30:     	b.eq	0x100246f60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100246f34:     	ldrb	w13, [x9], #0x1
100246f38:     	cmp	w12, #0x20
100246f3c:     	ccmp	w12, w13, #0x0, hs
100246f40:     	b.ne	0x100246f60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100246f44:     	subs	x10, x10, #0x1
100246f48:     	b.ne	0x100246f20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x288>
100246f4c:     	add	x8, x8, #0x1
100246f50:     	str	x8, [x19, #0x70]
100246f54:     	mov	w23, #0x1               ; =1
100246f58:     	mov	x27, #-0x1              ; =-1
100246f5c:     	b	0x100246f80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
100246f60:     	sub	x0, x29, #0xc0
100246f64:     	mov	x1, x19
100246f68:     	bl	0x100246478 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes>
100246f6c:     	ldur	x27, [x29, #-0xc0]
100246f70:     	cmn	x27, #0x2
100246f74:     	b.eq	0x100247cd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1038>
100246f78:     	mov	w23, #0x0               ; =0
100246f7c:     	ldp	x24, x14, [x29, #-0xb8]
100246f80:     	ldp	x9, x8, [x19, #0x68]
100246f84:     	cmp	x8, x9
100246f88:     	b.hs	0x100247cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1024>
100246f8c:     	ldr	x10, [x19, #0x60]
100246f90:     	ldrb	w11, [x10, x8]
100246f94:     	cmp	w11, #0x3a
100246f98:     	b.hi	0x100247cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1024>
100246f9c:     	lsr	x12, x25, x11
100246fa0:     	tbz	w12, #0x0, 0x100246fb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x320>
100246fa4:     	add	x8, x8, #0x1
100246fa8:     	str	x8, [x19, #0x70]
100246fac:     	cmp	x9, x8
100246fb0:     	b.ne	0x100246f90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2f8>
100246fb4:     	b	0x100247cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1024>
100246fb8:     	cmp	x11, #0x3a
100246fbc:     	b.ne	0x100247cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1024>
100246fc0:     	str	x14, [sp, #0x28]
100246fc4:     	add	x8, x8, #0x1
100246fc8:     	str	x8, [x19, #0x70]
100246fcc:     	mov	x0, x19
100246fd0:     	bl	0x1002453c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value>
100246fd4:     	str	x0, [sp, #0x10]
100246fd8:     	ldrb	w8, [x19, #0xd4]
100246fdc:     	tbz	w8, #0x0, 0x100247cc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1028>
100246fe0:     	ldr	x8, [sp, #0x188]
100246fe4:     	cmn	x8, #0x1
100246fe8:     	str	x24, [sp, #0x18]
100246fec:     	b.eq	0x1002470b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x418>
100246ff0:     	ldr	x8, [sp, #0x1b8]
100246ff4:     	ldr	x1, [sp, #0x198]
100246ff8:     	cmn	x8, #0x1
100246ffc:     	ldr	x2, [sp, #0x28]
100247000:     	str	x22, [sp, #0x8]
100247004:     	b.eq	0x1002470fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x464>
100247008:     	mov	x28, #0x7f2d            ; =32557
10024700c:     	movk	x28, #0x4c95, lsl #16
100247010:     	movk	x28, #0xf42d, lsl #32
100247014:     	movk	x28, #0x5851, lsl #48
100247018:     	ldp	x8, x11, [sp, #0x1f0]
10024701c:     	ldr	x10, [sp, #0x200]
100247020:     	ldr	x9, [sp, #0x208]
100247024:     	eor	x11, x11, x2
100247028:     	mul	x12, x11, x28
10024702c:     	umulh	x11, x11, x28
100247030:     	eor	x11, x11, x12
100247034:     	add	x11, x2, x11
100247038:     	mul	x11, x11, x28
10024703c:     	cmp	x2, #0x8
100247040:     	b.ls	0x10024732c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x694>
100247044:     	cmp	x2, #0x10
100247048:     	b.ls	0x100247414 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x77c>
10024704c:     	add	x12, x24, x2
100247050:     	ldp	x12, x13, [x12, #-0x10]
100247054:     	eor	x12, x10, x12
100247058:     	eor	x13, x13, x9
10024705c:     	mul	x14, x13, x12
100247060:     	umulh	x12, x13, x12
100247064:     	eor	x12, x12, x14
100247068:     	add	x11, x11, x8
10024706c:     	eor	x11, x11, x12
100247070:     	ror	x11, x11, #0x29
100247074:     	mov	x13, x24
100247078:     	mov	x12, x2
10024707c:     	ldp	x15, x14, [x13], #0x10
100247080:     	sub	x12, x12, #0x10
100247084:     	eor	x15, x10, x15
100247088:     	eor	x14, x14, x9
10024708c:     	mul	x16, x14, x15
100247090:     	umulh	x14, x14, x15
100247094:     	eor	x14, x14, x16
100247098:     	add	x11, x11, x8
10024709c:     	eor	x11, x11, x14
1002470a0:     	ror	x11, x11, #0x29
1002470a4:     	cmp	x12, #0x10
1002470a8:     	b.hi	0x10024707c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x3e4>
1002470ac:     	b	0x100247468 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7d0>
1002470b0:     	ldr	w8, [sp, #0x84]
1002470b4:     	ldr	x1, [sp, #0x28]
1002470b8:     	tbz	w8, #0x0, 0x10024734c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6b4>
1002470bc:     	ldr	w8, [sp, #0x80]
1002470c0:     	tbz	w8, #0x0, 0x1002481f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x155c>
1002470c4:     	ldr	x8, [sp, #0x98]
1002470c8:     	cmp	x8, x21
1002470cc:     	ldr	w11, [sp, #0x7c]
1002470d0:     	b.hs	0x100247680 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9e8>
1002470d4:     	tbz	w23, #0x0, 0x100247644 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9ac>
1002470d8:     	ldr	x0, [sp, #0x98]
1002470dc:     	cmp	x0, #0x7
1002470e0:     	b.hi	0x100248260 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15c8>
1002470e4:     	ldr	x8, [sp, #0x68]
1002470e8:     	ldr	x10, [x8, x0, lsl #3]
1002470ec:     	add	x0, x0, #0x1
1002470f0:     	str	x0, [sp, #0x98]
1002470f4:     	mov	w8, #0x1                ; =1
1002470f8:     	b	0x100247694 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9fc>
1002470fc:     	ldr	x26, [sp, #0x190]
100247100:     	cmp	x1, #0x80
100247104:     	mov	x28, #0x7f2d            ; =32557
100247108:     	movk	x28, #0x4c95, lsl #16
10024710c:     	movk	x28, #0xf42d, lsl #32
100247110:     	movk	x28, #0x5851, lsl #48
100247114:     	b.ne	0x100247364 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6cc>
100247118:     	mov	w8, #0x1                ; =1
10024711c:     	strb	w8, [x19, #0xd6]
100247120:     	adrp	x8, 0x101051000 <_out_buf+0x3988>
100247124:     	add	x8, x8, #0x840
100247128:     	ldapr	x8, [x8]
10024712c:     	cbz	x8, 0x100247c80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfe8>
100247130:     	ldp	x0, x22, [x8]
100247134:     	adrp	x8, 0x101051000 <_out_buf+0x3988>
100247138:     	add	x8, x8, #0x848
10024713c:     	ldapr	x24, [x8]
100247140:     	cbz	x24, 0x100247ca0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1008>
100247144:     	ldr	x8, [x22, #0x18]
100247148:     	blr	x8
10024714c:     	mov	x2, x0
100247150:     	sub	x8, x29, #0xc0
100247154:     	add	x8, x8, #0x38
100247158:     	add	x1, x24, #0x20
10024715c:     	mov	x0, x24
100247160:     	bl	0x1000091dc <__RNvMs1_NtCs3SoQS4yp3pP_5ahash12random_stateNtB5_11RandomState9from_keys>
100247164:     	mov	w0, #0x1108             ; =4360
100247168:     	mov	w1, #0x8                ; =8
10024716c:     	bl	0x100b5ff88 <_mi_malloc_aligned>
100247170:     	cbz	x0, 0x100248234 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x159c>
100247174:     	mov	x24, #0x0               ; =0
100247178:     	mov	x2, #0x0                ; =0
10024717c:     	movi.2d	v0, #0xffffffffffffffff
100247180:     	str	q0, [x0, #0x10f0]
100247184:     	str	q0, [x0, #0x10e0]
100247188:     	str	q0, [x0, #0x10d0]
10024718c:     	str	q0, [x0, #0x10c0]
100247190:     	str	q0, [x0, #0x10b0]
100247194:     	str	q0, [x0, #0x10a0]
100247198:     	str	q0, [x0, #0x1090]
10024719c:     	str	q0, [x0, #0x1080]
1002471a0:     	str	q0, [x0, #0x1070]
1002471a4:     	str	q0, [x0, #0x1060]
1002471a8:     	str	q0, [x0, #0x1050]
1002471ac:     	str	q0, [x0, #0x1040]
1002471b0:     	str	q0, [x0, #0x1030]
1002471b4:     	str	q0, [x0, #0x1020]
1002471b8:     	str	q0, [x0, #0x1010]
1002471bc:     	str	q0, [x0, #0x1000]
1002471c0:     	str	d0, [x0, #0x1100]
1002471c4:     	add	x8, x0, #0x1, lsl #12   ; =0x1000
1002471c8:     	stur	xzr, [x29, #-0x90]
1002471cc:     	ldr	q0, [sp, #0x50]
1002471d0:     	stur	q0, [x29, #-0xa0]
1002471d4:     	mov	w9, #0x8                ; =8
1002471d8:     	stp	xzr, x9, [x29, #-0xc0]
1002471dc:     	stp	xzr, x8, [x29, #-0xb0]
1002471e0:     	b	0x10024723c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x5a4>
1002471e4:     	ldr	w11, [x11]
1002471e8:     	ldur	w12, [x14, #-0x4]
1002471ec:     	eor	x10, x11, x10
1002471f0:     	eor	x9, x12, x9
1002471f4:     	mul	x11, x9, x10
1002471f8:     	umulh	x9, x9, x10
1002471fc:     	eor	x9, x9, x11
100247200:     	add	x10, x13, x8
100247204:     	eor	x9, x10, x9
100247208:     	ror	x13, x9, #0x29
10024720c:     	add	x24, x24, #0x8
100247210:     	add	x22, x2, #0x1
100247214:     	mul	x9, x13, x8
100247218:     	umulh	x8, x13, x8
10024721c:     	eor	x8, x8, x9
100247220:     	neg	w9, w13
100247224:     	ror	x1, x8, x9
100247228:     	sub	x0, x29, #0xc0
10024722c:     	bl	0x10028980c <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11insert_hash>
100247230:     	mov	x2, x22
100247234:     	cmp	x24, #0x400
100247238:     	b.eq	0x10024736c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6d4>
10024723c:     	ldr	x8, [x26, x24]
100247240:     	add	x11, x8, #0x14
100247244:     	ldr	w12, [x8, #0x4]
100247248:     	ldp	x8, x13, [x29, #-0x88]
10024724c:     	ldp	x10, x9, [x29, #-0x78]
100247250:     	eor	x13, x13, x12
100247254:     	mul	x14, x13, x28
100247258:     	umulh	x13, x13, x28
10024725c:     	eor	x13, x13, x14
100247260:     	add	x13, x13, x12
100247264:     	mul	x13, x13, x28
100247268:     	cmp	w12, #0x8
10024726c:     	b.ls	0x1002472d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x63c>
100247270:     	cmp	w12, #0x10
100247274:     	b.ls	0x1002472f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x65c>
100247278:     	add	x14, x11, x12
10024727c:     	ldp	x14, x15, [x14, #-0x10]
100247280:     	eor	x14, x10, x14
100247284:     	eor	x15, x15, x9
100247288:     	mul	x16, x15, x14
10024728c:     	umulh	x14, x15, x14
100247290:     	eor	x14, x14, x16
100247294:     	add	x13, x13, x8
100247298:     	eor	x13, x13, x14
10024729c:     	ror	x13, x13, #0x29
1002472a0:     	ldp	x15, x14, [x11], #0x10
1002472a4:     	sub	x12, x12, #0x10
1002472a8:     	eor	x15, x10, x15
1002472ac:     	eor	x14, x14, x9
1002472b0:     	mul	x16, x14, x15
1002472b4:     	umulh	x14, x14, x15
1002472b8:     	eor	x14, x14, x16
1002472bc:     	add	x13, x13, x8
1002472c0:     	eor	x13, x13, x14
1002472c4:     	ror	x13, x13, #0x29
1002472c8:     	cmp	x12, #0x10
1002472cc:     	b.hi	0x1002472a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x608>
1002472d0:     	b	0x10024720c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x574>
1002472d4:     	cmp	w12, #0x1
1002472d8:     	b.ls	0x10024730c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x674>
1002472dc:     	add	x14, x11, x12
1002472e0:     	cmp	w12, #0x3
1002472e4:     	b.hi	0x1002471e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x54c>
1002472e8:     	ldrh	w11, [x11]
1002472ec:     	ldurb	w12, [x14, #-0x1]
1002472f0:     	b	0x1002471ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x554>
1002472f4:     	ldr	x14, [x11]
1002472f8:     	add	x11, x11, x12
1002472fc:     	ldur	x11, [x11, #-0x8]
100247300:     	eor	x10, x14, x10
100247304:     	eor	x9, x11, x9
100247308:     	b	0x1002471f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x55c>
10024730c:     	cmp	w12, #0x1
100247310:     	b.ne	0x100247320 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x688>
100247314:     	ldrb	w11, [x11]
100247318:     	mov	x12, x11
10024731c:     	b	0x1002471ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x554>
100247320:     	mov	x11, #0x0               ; =0
100247324:     	mov	x12, #0x0               ; =0
100247328:     	b	0x1002471ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x554>
10024732c:     	cmp	x2, #0x1
100247330:     	b.ls	0x100247424 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x78c>
100247334:     	add	x13, x24, x2
100247338:     	cmp	x2, #0x3
10024733c:     	b.ls	0x100247434 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x79c>
100247340:     	ldr	w12, [x24]
100247344:     	ldur	w13, [x13, #-0x4]
100247348:     	b	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7b0>
10024734c:     	mov	x0, x24
100247350:     	bl	0x100328d3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100247354:     	mov	x10, x0
100247358:     	mov	w8, #0x0                ; =0
10024735c:     	ldr	w11, [sp, #0x7c]
100247360:     	b	0x100247694 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9fc>
100247364:     	str	x1, [sp, #0x20]
100247368:     	b	0x100247aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe10>
10024736c:     	ldur	q2, [x29, #-0x80]
100247370:     	ldur	x8, [x29, #-0x70]
100247374:     	str	x8, [sp, #0x260]
100247378:     	ldp	q0, q1, [x29, #-0xc0]
10024737c:     	stp	q0, q1, [sp, #0x210]
100247380:     	ldp	q0, q1, [x29, #-0xa0]
100247384:     	str	q0, [sp, #0x230]
100247388:     	stp	q1, q2, [sp, #0x240]
10024738c:     	ldr	x22, [sp, #0x1b8]
100247390:     	cmn	x22, #0x1
100247394:     	ldr	x24, [sp, #0x18]
100247398:     	ldr	x2, [sp, #0x28]
10024739c:     	b.eq	0x1002473dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x744>
1002473a0:     	ldr	x9, [sp, #0x1d8]
1002473a4:     	cbz	x9, 0x1002473cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x734>
1002473a8:     	lsl	x8, x9, #4
1002473ac:     	add	x9, x8, x9
1002473b0:     	cmn	x9, #0x19
1002473b4:     	b.eq	0x1002473cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x734>
1002473b8:     	ldr	x9, [sp, #0x1d0]
1002473bc:     	sub	x8, x9, x8
1002473c0:     	sub	x0, x8, #0x10
1002473c4:     	bl	0x100b5fd00 <_mi_free>
1002473c8:     	ldr	x2, [sp, #0x28]
1002473cc:     	cbz	x22, 0x1002473dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x744>
1002473d0:     	ldr	x0, [sp, #0x1c0]
1002473d4:     	bl	0x100b5fd00 <_mi_free>
1002473d8:     	ldr	x2, [sp, #0x28]
1002473dc:     	ldr	x8, [sp, #0x260]
1002473e0:     	add	x9, sp, #0x188
1002473e4:     	stur	x8, [x9, #0x80]
1002473e8:     	ldr	q2, [sp, #0x250]
1002473ec:     	ldp	q0, q1, [sp, #0x210]
1002473f0:     	stp	q0, q1, [x9, #0x30]
1002473f4:     	ldp	q0, q1, [sp, #0x230]
1002473f8:     	stur	q0, [x9, #0x50]
1002473fc:     	stp	q1, q2, [x9, #0x60]
100247400:     	ldr	x8, [sp, #0x1b8]
100247404:     	cmn	x8, #0x1
100247408:     	b.eq	0x100247aa0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe08>
10024740c:     	ldr	x1, [sp, #0x198]
100247410:     	b	0x100247018 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x380>
100247414:     	ldr	x12, [x24]
100247418:     	add	x13, x24, x2
10024741c:     	ldur	x13, [x13, #-0x8]
100247420:     	b	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7b0>
100247424:     	b.ne	0x100247440 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7a8>
100247428:     	ldrb	w12, [x24]
10024742c:     	mov	x13, x12
100247430:     	b	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7b0>
100247434:     	ldrh	w12, [x24]
100247438:     	ldurb	w13, [x13, #-0x1]
10024743c:     	b	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7b0>
100247440:     	mov	x12, #0x0               ; =0
100247444:     	mov	x13, #0x0               ; =0
100247448:     	eor	x10, x12, x10
10024744c:     	eor	x9, x13, x9
100247450:     	mul	x12, x9, x10
100247454:     	umulh	x9, x9, x10
100247458:     	eor	x9, x9, x12
10024745c:     	add	x10, x11, x8
100247460:     	eor	x9, x10, x9
100247464:     	ror	x11, x9, #0x29
100247468:     	mul	x9, x11, x8
10024746c:     	umulh	x8, x11, x8
100247470:     	eor	x8, x8, x9
100247474:     	neg	w9, w11
100247478:     	ror	x28, x8, x9
10024747c:     	ldr	x8, [sp, #0x1e8]
100247480:     	cbz	x8, 0x1002475d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x93c>
100247484:     	mov	x8, #0x0                ; =0
100247488:     	mov	x9, #0x7c15             ; =31765
10024748c:     	movk	x9, #0x7f4a, lsl #16
100247490:     	movk	x9, #0x79b9, lsl #32
100247494:     	movk	x9, #0x9e37, lsl #48
100247498:     	mul	x9, x28, x9
10024749c:     	eor	x11, x9, x9, lsr #32
1002474a0:     	lsr	x12, x9, #57
1002474a4:     	ldp	x10, x9, [sp, #0x1d0]
1002474a8:     	ldr	x26, [sp, #0x190]
1002474ac:     	dup.8b	v0, w12
1002474b0:     	and	x11, x11, x9
1002474b4:     	ldr	d1, [x10, x11]
1002474b8:     	cmeq.8b	v2, v1, v0
1002474bc:     	fmov	x12, d2
1002474c0:     	ands	x12, x12, #0x8080808080808080
1002474c4:     	b.eq	0x1002474f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x85c>
1002474c8:     	rbit	x13, x12
1002474cc:     	clz	x13, x13
1002474d0:     	add	x13, x11, x13, lsr #3
1002474d4:     	and	x13, x13, x9
1002474d8:     	sub	x13, x10, x13, lsl #4
1002474dc:     	ldur	x14, [x13, #-0x10]
1002474e0:     	cmp	x28, x14
1002474e4:     	b.eq	0x100247528 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x890>
1002474e8:     	sub	x13, x12, #0x2
1002474ec:     	ands	x12, x13, x12
1002474f0:     	b.ne	0x1002474c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x830>
1002474f4:     	movi.2d	v2, #0xffffffffffffffff
1002474f8:     	cmeq.8b	v1, v1, v2
1002474fc:     	fmov	x12, d1
100247500:     	cbnz	x12, 0x1002475d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x93c>
100247504:     	add	x8, x8, #0x8
100247508:     	add	x11, x11, x8
10024750c:     	and	x11, x11, x9
100247510:     	ldr	d1, [x10, x11]
100247514:     	cmeq.8b	v2, v1, v0
100247518:     	fmov	x12, d2
10024751c:     	ands	x12, x12, #0x8080808080808080
100247520:     	b.ne	0x1002474c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x830>
100247524:     	b	0x1002474f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x85c>
100247528:     	ldur	x24, [x13, #-0x8]
10024752c:     	cmp	x24, x1
100247530:     	b.hs	0x100248224 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x158c>
100247534:     	ldr	x8, [x26, x24, lsl #3]
100247538:     	ldr	w9, [x8, #0x4]
10024753c:     	cmp	x2, x9
100247540:     	str	x1, [sp, #0x20]
100247544:     	b.ne	0x100247560 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x8c8>
100247548:     	add	x0, x8, #0x14
10024754c:     	ldr	x1, [sp, #0x18]
100247550:     	ldr	x2, [sp, #0x28]
100247554:     	bl	0x100b62ba0 <_writev+0x100b62ba0>
100247558:     	ldp	x1, x2, [sp, #0x20]
10024755c:     	cbz	w0, 0x1002475c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x92c>
100247560:     	ldr	x8, [sp, #0x1c8]
100247564:     	cbz	x8, 0x1002475d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x93c>
100247568:     	ldr	x9, [sp, #0x1c0]
10024756c:     	lsl	x23, x8, #4
100247570:     	add	x22, x9, #0x8
100247574:     	b	0x100247584 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x8ec>
100247578:     	add	x22, x22, #0x10
10024757c:     	subs	x23, x23, #0x10
100247580:     	b.eq	0x1002475d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x93c>
100247584:     	ldur	x8, [x22, #-0x8]
100247588:     	cmp	x8, x28
10024758c:     	b.ne	0x100247578 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x8e0>
100247590:     	ldr	x24, [x22]
100247594:     	cmp	x24, x1
100247598:     	b.hs	0x100248214 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x157c>
10024759c:     	ldr	x8, [x26, x24, lsl #3]
1002475a0:     	ldr	w9, [x8, #0x4]
1002475a4:     	cmp	x2, x9
1002475a8:     	b.ne	0x100247578 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x8e0>
1002475ac:     	add	x0, x8, #0x14
1002475b0:     	ldr	x1, [sp, #0x18]
1002475b4:     	ldr	x2, [sp, #0x28]
1002475b8:     	bl	0x100b62ba0 <_writev+0x100b62ba0>
1002475bc:     	ldp	x1, x2, [sp, #0x20]
1002475c0:     	cbnz	w0, 0x100247578 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x8e0>
1002475c4:     	ldr	x1, [sp, #0x1b0]
1002475c8:     	cmp	x24, x1
1002475cc:     	b.lo	0x100247b30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe98>
1002475d0:     	b	0x100248250 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15b8>
1002475d4:     	add	x0, x19, #0x20
1002475d8:     	mov	x22, x1
1002475dc:     	ldr	x1, [sp, #0x18]
1002475e0:     	bl	0x1005eb984 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>
1002475e4:     	mov	x24, x0
1002475e8:     	add	x8, sp, #0x188
1002475ec:     	add	x0, x8, #0x30
1002475f0:     	mov	x1, x28
1002475f4:     	mov	x2, x22
1002475f8:     	bl	0x10028980c <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11insert_hash>
1002475fc:     	ldr	x22, [sp, #0x198]
100247600:     	ldr	x8, [sp, #0x188]
100247604:     	cmp	x22, x8
100247608:     	b.eq	0x100247c24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf8c>
10024760c:     	ldr	x8, [sp, #0x190]
100247610:     	str	x24, [x8, x22, lsl #3]
100247614:     	add	x8, x22, #0x1
100247618:     	str	x8, [sp, #0x198]
10024761c:     	ldr	x22, [sp, #0x1b0]
100247620:     	ldr	x8, [sp, #0x1a0]
100247624:     	cmp	x22, x8
100247628:     	b.eq	0x100247c30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf98>
10024762c:     	ldr	x28, [sp, #0x1a8]
100247630:     	ldr	x8, [sp, #0x10]
100247634:     	str	x8, [x28, x22, lsl #3]
100247638:     	add	x1, x22, #0x1
10024763c:     	str	x1, [sp, #0x1b0]
100247640:     	b	0x100247b3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xea4>
100247644:     	ldr	x0, [sp, #0x98]
100247648:     	cmp	x0, #0x8
10024764c:     	b.hs	0x100248270 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15d8>
100247650:     	ldr	x8, [sp, #0x68]
100247654:     	ldr	x23, [x8, x0, lsl #3]
100247658:     	ldr	w8, [x23, #0x4]
10024765c:     	cmp	x1, x8
100247660:     	b.ne	0x100247680 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9e8>
100247664:     	add	x0, x23, #0x14
100247668:     	mov	x1, x24
10024766c:     	ldr	x2, [sp, #0x28]
100247670:     	bl	0x100b62ba0 <_writev+0x100b62ba0>
100247674:     	ldr	x1, [sp, #0x28]
100247678:     	ldr	w11, [sp, #0x7c]
10024767c:     	cbz	w0, 0x100247c40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfa8>
100247680:     	mov	x0, x24
100247684:     	bl	0x100328d3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100247688:     	mov	x10, x0
10024768c:     	mov	w11, #0x0               ; =0
100247690:     	mov	w8, #0x0                ; =0
100247694:     	ldp	x1, x9, [sp, #0x90]
100247698:     	cmp	x9, #0x0
10024769c:     	str	w8, [sp, #0x84]
1002476a0:     	csinc	w23, w8, wzr, ne
1002476a4:     	cmp	x1, #0x9
1002476a8:     	b.hs	0x1002481b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1520>
1002476ac:     	ldr	x2, [sp, #0x28]
1002476b0:     	cbz	x1, 0x100247a44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
1002476b4:     	ldr	x8, [sp, #0x100]
1002476b8:     	cmp	x8, x10
1002476bc:     	b.eq	0x100247a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde4>
1002476c0:     	tbnz	w23, #0x0, 0x1002476fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa64>
1002476c4:     	ldr	w9, [x8, #0x4]
1002476c8:     	cmp	x2, x9
1002476cc:     	b.ne	0x1002476fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa64>
1002476d0:     	add	x0, x8, #0x14
1002476d4:     	mov	x1, x24
1002476d8:     	ldr	x2, [sp, #0x28]
1002476dc:     	str	w11, [sp, #0x7c]
1002476e0:     	mov	x24, x10
1002476e4:     	bl	0x100b62ba0 <_writev+0x100b62ba0>
1002476e8:     	mov	x10, x24
1002476ec:     	ldr	x2, [sp, #0x28]
1002476f0:     	ldr	w11, [sp, #0x7c]
1002476f4:     	ldr	x24, [sp, #0x18]
1002476f8:     	cbz	w0, 0x100247a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde4>
1002476fc:     	ldr	x1, [sp, #0x90]
100247700:     	cmp	x1, #0x1
100247704:     	b.eq	0x100247a44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
100247708:     	ldr	x9, [sp, #0x108]
10024770c:     	add	x8, sp, #0x148
100247710:     	add	x8, x8, #0x8
100247714:     	cmp	x9, x10
100247718:     	b.eq	0x100247a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
10024771c:     	tbnz	w23, #0x0, 0x100247760 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xac8>
100247720:     	ldr	w8, [x9, #0x4]
100247724:     	cmp	x2, x8
100247728:     	b.ne	0x100247760 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xac8>
10024772c:     	add	x0, x9, #0x14
100247730:     	mov	x1, x24
100247734:     	ldr	x2, [sp, #0x28]
100247738:     	str	w11, [sp, #0x7c]
10024773c:     	mov	x24, x10
100247740:     	bl	0x100b62ba0 <_writev+0x100b62ba0>
100247744:     	mov	x10, x24
100247748:     	ldr	x2, [sp, #0x28]
10024774c:     	ldr	w11, [sp, #0x7c]
100247750:     	ldr	x24, [sp, #0x18]
100247754:     	add	x8, sp, #0x148
100247758:     	add	x8, x8, #0x8
10024775c:     	cbz	w0, 0x100247a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100247760:     	ldr	x1, [sp, #0x90]
100247764:     	cmp	x1, #0x2
100247768:     	b.eq	0x100247a44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
10024776c:     	ldr	x9, [sp, #0x110]
100247770:     	add	x8, sp, #0x148
100247774:     	add	x8, x8, #0x10
100247778:     	cmp	x9, x10
10024777c:     	b.eq	0x100247a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100247780:     	tbnz	w23, #0x0, 0x1002477c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb2c>
100247784:     	ldr	w8, [x9, #0x4]
100247788:     	cmp	x2, x8
10024778c:     	b.ne	0x1002477c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb2c>
100247790:     	add	x0, x9, #0x14
100247794:     	mov	x1, x24
100247798:     	ldr	x2, [sp, #0x28]
10024779c:     	str	w11, [sp, #0x7c]
1002477a0:     	mov	x24, x10
1002477a4:     	bl	0x100b62ba0 <_writev+0x100b62ba0>
1002477a8:     	mov	x10, x24
1002477ac:     	ldr	x2, [sp, #0x28]
1002477b0:     	ldr	w11, [sp, #0x7c]
1002477b4:     	ldr	x24, [sp, #0x18]
1002477b8:     	add	x8, sp, #0x148
1002477bc:     	add	x8, x8, #0x10
1002477c0:     	cbz	w0, 0x100247a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
1002477c4:     	ldr	x1, [sp, #0x90]
1002477c8:     	cmp	x1, #0x3
1002477cc:     	b.eq	0x100247a44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
1002477d0:     	ldr	x9, [sp, #0x118]
1002477d4:     	add	x8, sp, #0x148
1002477d8:     	add	x8, x8, #0x18
1002477dc:     	cmp	x9, x10
1002477e0:     	b.eq	0x100247a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
1002477e4:     	tbnz	w23, #0x0, 0x100247828 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb90>
1002477e8:     	ldr	w8, [x9, #0x4]
1002477ec:     	cmp	x2, x8
1002477f0:     	b.ne	0x100247828 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb90>
1002477f4:     	add	x0, x9, #0x14
1002477f8:     	mov	x1, x24
1002477fc:     	ldr	x2, [sp, #0x28]
100247800:     	str	w11, [sp, #0x7c]
100247804:     	mov	x24, x10
100247808:     	bl	0x100b62ba0 <_writev+0x100b62ba0>
10024780c:     	mov	x10, x24
100247810:     	ldr	x2, [sp, #0x28]
100247814:     	ldr	w11, [sp, #0x7c]
100247818:     	ldr	x24, [sp, #0x18]
10024781c:     	add	x8, sp, #0x148
100247820:     	add	x8, x8, #0x18
100247824:     	cbz	w0, 0x100247a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100247828:     	ldr	x1, [sp, #0x90]
10024782c:     	cmp	x1, #0x4
100247830:     	b.eq	0x100247a44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
100247834:     	ldr	x9, [sp, #0x120]
100247838:     	add	x8, sp, #0x148
10024783c:     	add	x8, x8, #0x20
100247840:     	cmp	x9, x10
100247844:     	b.eq	0x100247a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100247848:     	tbnz	w23, #0x0, 0x10024788c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xbf4>
10024784c:     	ldr	w8, [x9, #0x4]
100247850:     	cmp	x2, x8
100247854:     	b.ne	0x10024788c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xbf4>
100247858:     	add	x0, x9, #0x14
10024785c:     	mov	x1, x24
100247860:     	ldr	x2, [sp, #0x28]
100247864:     	str	w11, [sp, #0x7c]
100247868:     	mov	x24, x10
10024786c:     	bl	0x100b62ba0 <_writev+0x100b62ba0>
100247870:     	mov	x10, x24
100247874:     	ldr	x2, [sp, #0x28]
100247878:     	ldr	w11, [sp, #0x7c]
10024787c:     	ldr	x24, [sp, #0x18]
100247880:     	add	x8, sp, #0x148
100247884:     	add	x8, x8, #0x20
100247888:     	cbz	w0, 0x100247a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
10024788c:     	ldr	x1, [sp, #0x90]
100247890:     	cmp	x1, #0x5
100247894:     	b.eq	0x100247a44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
100247898:     	ldr	x9, [sp, #0x128]
10024789c:     	add	x8, sp, #0x148
1002478a0:     	add	x8, x8, #0x28
1002478a4:     	cmp	x9, x10
1002478a8:     	b.eq	0x100247a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
1002478ac:     	tbnz	w23, #0x0, 0x1002478f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xc58>
1002478b0:     	ldr	w8, [x9, #0x4]
1002478b4:     	cmp	x2, x8
1002478b8:     	b.ne	0x1002478f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xc58>
1002478bc:     	add	x0, x9, #0x14
1002478c0:     	mov	x1, x24
1002478c4:     	ldr	x2, [sp, #0x28]
1002478c8:     	str	w11, [sp, #0x7c]
1002478cc:     	mov	x24, x10
1002478d0:     	bl	0x100b62ba0 <_writev+0x100b62ba0>
1002478d4:     	mov	x10, x24
1002478d8:     	ldr	x2, [sp, #0x28]
1002478dc:     	ldr	w11, [sp, #0x7c]
1002478e0:     	ldr	x24, [sp, #0x18]
1002478e4:     	add	x8, sp, #0x148
1002478e8:     	add	x8, x8, #0x28
1002478ec:     	cbz	w0, 0x100247a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
1002478f0:     	ldr	x1, [sp, #0x90]
1002478f4:     	cmp	x1, #0x6
1002478f8:     	b.eq	0x100247a44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
1002478fc:     	ldr	x9, [sp, #0x130]
100247900:     	add	x8, sp, #0x148
100247904:     	add	x8, x8, #0x30
100247908:     	cmp	x9, x10
10024790c:     	b.eq	0x100247a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100247910:     	tbnz	w23, #0x0, 0x100247954 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xcbc>
100247914:     	ldr	w8, [x9, #0x4]
100247918:     	cmp	x2, x8
10024791c:     	b.ne	0x100247954 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xcbc>
100247920:     	add	x0, x9, #0x14
100247924:     	mov	x1, x24
100247928:     	ldr	x2, [sp, #0x28]
10024792c:     	str	w11, [sp, #0x7c]
100247930:     	mov	x24, x10
100247934:     	bl	0x100b62ba0 <_writev+0x100b62ba0>
100247938:     	mov	x10, x24
10024793c:     	ldr	x2, [sp, #0x28]
100247940:     	ldr	w11, [sp, #0x7c]
100247944:     	ldr	x24, [sp, #0x18]
100247948:     	add	x8, sp, #0x148
10024794c:     	add	x8, x8, #0x30
100247950:     	cbz	w0, 0x100247a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100247954:     	ldr	x1, [sp, #0x90]
100247958:     	cmp	x1, #0x7
10024795c:     	b.eq	0x100247a44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
100247960:     	ldr	x9, [sp, #0x138]
100247964:     	add	x8, sp, #0x148
100247968:     	add	x8, x8, #0x38
10024796c:     	cmp	x9, x10
100247970:     	b.eq	0x100247a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100247974:     	tbnz	w23, #0x0, 0x1002479ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd14>
100247978:     	ldr	w8, [x9, #0x4]
10024797c:     	cmp	x2, x8
100247980:     	b.ne	0x1002479ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd14>
100247984:     	add	x0, x9, #0x14
100247988:     	mov	x1, x24
10024798c:     	str	w11, [sp, #0x7c]
100247990:     	mov	x23, x10
100247994:     	bl	0x100b62ba0 <_writev+0x100b62ba0>
100247998:     	mov	x10, x23
10024799c:     	ldr	w11, [sp, #0x7c]
1002479a0:     	add	x8, sp, #0x148
1002479a4:     	add	x8, x8, #0x38
1002479a8:     	cbz	w0, 0x100247a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
1002479ac:     	ldr	x1, [sp, #0x90]
1002479b0:     	cmp	x1, #0x8
1002479b4:     	b.ne	0x100247a44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
1002479b8:     	mov	x24, x10
1002479bc:     	str	w11, [sp, #0x7c]
1002479c0:     	mov	x23, x22
1002479c4:     	mov	w0, #0x80               ; =128
1002479c8:     	bl	0x100b5ff88 <_mi_malloc_aligned>
1002479cc:     	cbz	x0, 0x100248280 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15e8>
1002479d0:     	mov	x22, x0
1002479d4:     	mov	w0, #0x80               ; =128
1002479d8:     	mov	w1, #0x8                ; =8
1002479dc:     	bl	0x100b5ff88 <_mi_malloc_aligned>
1002479e0:     	cbz	x0, 0x100248280 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15e8>
1002479e4:     	mov	x28, x0
1002479e8:     	ldp	q0, q1, [sp, #0x100]
1002479ec:     	stp	q0, q1, [x22]
1002479f0:     	ldp	q0, q1, [sp, #0x120]
1002479f4:     	stp	q0, q1, [x22, #0x20]
1002479f8:     	add	x9, sp, #0x148
1002479fc:     	ldp	q0, q1, [x9]
100247a00:     	stp	q0, q1, [x0]
100247a04:     	ldp	q0, q1, [x9, #0x20]
100247a08:     	stp	q0, q1, [x0, #0x20]
100247a0c:     	str	x24, [x22, #0x40]
100247a10:     	ldr	x8, [sp, #0x10]
100247a14:     	str	x8, [x0, #0x40]
100247a18:     	mov	w8, #0x10               ; =16
100247a1c:     	stp	x8, x22, [sp, #0x188]
100247a20:     	ldp	q0, q1, [sp, #0x30]
100247a24:     	str	q1, [x9, #0x50]
100247a28:     	str	x0, [sp, #0x1a8]
100247a2c:     	mov	w8, #0x8                ; =8
100247a30:     	str	x8, [sp, #0x90]
100247a34:     	stur	q0, [x9, #0x68]
100247a38:     	mov	w1, #0x9                ; =9
100247a3c:     	mov	x22, x23
100247a40:     	b	0x100247b40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xea8>
100247a44:     	add	x8, sp, #0x100
100247a48:     	str	x10, [x8, x1, lsl #3]
100247a4c:     	add	x8, sp, #0x148
100247a50:     	ldr	x9, [sp, #0x10]
100247a54:     	str	x9, [x8, x1, lsl #3]
100247a58:     	add	x8, x1, #0x1
100247a5c:     	str	x8, [sp, #0x70]
100247a60:     	str	x8, [sp, #0x90]
100247a64:     	ldr	x1, [sp, #0x20]
100247a68:     	ldp	x23, x8, [x19, #0x68]
100247a6c:     	cmp	x8, x23
100247a70:     	str	x1, [sp, #0x20]
100247a74:     	b.lo	0x100247b58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xec0>
100247a78:     	b	0x100247bd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf40>
100247a7c:     	add	x8, sp, #0x148
100247a80:     	ldr	x9, [sp, #0x10]
100247a84:     	str	x9, [x8]
100247a88:     	ldr	x1, [sp, #0x20]
100247a8c:     	ldp	x23, x8, [x19, #0x68]
100247a90:     	cmp	x8, x23
100247a94:     	str	x1, [sp, #0x20]
100247a98:     	b.lo	0x100247b58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xec0>
100247a9c:     	b	0x100247bd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf40>
100247aa0:     	ldp	x26, x8, [sp, #0x190]
100247aa4:     	str	x8, [sp, #0x20]
100247aa8:     	mov	x0, x24
100247aac:     	mov	x1, x2
100247ab0:     	bl	0x100328d3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100247ab4:     	mov	x28, x0
100247ab8:     	ldr	x8, [sp, #0x98]
100247abc:     	cmp	x8, #0x0
100247ac0:     	cset	w8, eq
100247ac4:     	ldr	x12, [sp, #0x20]
100247ac8:     	cbz	x12, 0x100247b84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xeec>
100247acc:     	mov	x24, #0x0               ; =0
100247ad0:     	ldr	w9, [sp, #0x84]
100247ad4:     	orr	w22, w8, w9
100247ad8:     	lsl	x23, x12, #3
100247adc:     	b	0x100247aec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe54>
100247ae0:     	add	x24, x24, #0x1
100247ae4:     	subs	x23, x23, #0x8
100247ae8:     	b.eq	0x100247b84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xeec>
100247aec:     	ldr	x8, [x26, x24, lsl #3]
100247af0:     	cmp	x8, x28
100247af4:     	b.eq	0x100247b24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe8c>
100247af8:     	tbnz	w22, #0x0, 0x100247ae0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe48>
100247afc:     	ldr	w9, [x8, #0x4]
100247b00:     	ldr	x10, [sp, #0x28]
100247b04:     	cmp	x10, x9
100247b08:     	b.ne	0x100247ae0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe48>
100247b0c:     	add	x0, x8, #0x14
100247b10:     	ldr	x1, [sp, #0x18]
100247b14:     	ldr	x2, [sp, #0x28]
100247b18:     	bl	0x100b62ba0 <_writev+0x100b62ba0>
100247b1c:     	ldr	x12, [sp, #0x20]
100247b20:     	cbnz	w0, 0x100247ae0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe48>
100247b24:     	ldr	x1, [sp, #0x1b0]
100247b28:     	cmp	x24, x1
100247b2c:     	b.hs	0x100248240 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15a8>
100247b30:     	ldr	x28, [sp, #0x1a8]
100247b34:     	ldr	x8, [sp, #0x10]
100247b38:     	str	x8, [x28, x24, lsl #3]
100247b3c:     	ldr	x22, [sp, #0x8]
100247b40:     	ldr	w11, [sp, #0x7c]
100247b44:     	ldr	x24, [sp, #0x18]
100247b48:     	ldp	x23, x8, [x19, #0x68]
100247b4c:     	cmp	x8, x23
100247b50:     	str	x1, [sp, #0x20]
100247b54:     	b.hs	0x100247bd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf40>
100247b58:     	ldr	x9, [x19, #0x60]
100247b5c:     	ldrb	w10, [x9, x8]
100247b60:     	cmp	w10, #0x20
100247b64:     	b.hi	0x100247bd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf40>
100247b68:     	lsr	x10, x25, x10
100247b6c:     	tbz	w10, #0x0, 0x100247bd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf40>
100247b70:     	add	x8, x8, #0x1
100247b74:     	str	x8, [x19, #0x70]
100247b78:     	cmp	x23, x8
100247b7c:     	b.ne	0x100247b5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xec4>
100247b80:     	b	0x100247cc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1028>
100247b84:     	ldr	x8, [sp, #0x188]
100247b88:     	cmp	x12, x8
100247b8c:     	ldr	w11, [sp, #0x7c]
100247b90:     	b.eq	0x100247c4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfb4>
100247b94:     	str	x28, [x26, x12, lsl #3]
100247b98:     	add	x8, x12, #0x1
100247b9c:     	str	x8, [sp, #0x198]
100247ba0:     	ldr	x22, [sp, #0x1b0]
100247ba4:     	ldr	x8, [sp, #0x1a0]
100247ba8:     	cmp	x22, x8
100247bac:     	b.eq	0x100247c68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfd0>
100247bb0:     	ldr	x28, [sp, #0x1a8]
100247bb4:     	ldp	x8, x24, [sp, #0x10]
100247bb8:     	str	x8, [x28, x22, lsl #3]
100247bbc:     	add	x1, x22, #0x1
100247bc0:     	str	x1, [sp, #0x1b0]
100247bc4:     	ldr	x22, [sp, #0x8]
100247bc8:     	ldp	x23, x8, [x19, #0x68]
100247bcc:     	cmp	x8, x23
100247bd0:     	str	x1, [sp, #0x20]
100247bd4:     	b.lo	0x100247b58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xec0>
100247bd8:     	cmp	x8, x23
100247bdc:     	b.hs	0x100247cc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1028>
100247be0:     	ldr	x9, [x19, #0x60]
100247be4:     	ldrb	w9, [x9, x8]
100247be8:     	cmp	w9, #0x2c
100247bec:     	b.ne	0x100247cc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1028>
100247bf0:     	add	x24, x8, #0x1
100247bf4:     	str	x24, [x19, #0x70]
100247bf8:     	cmp	x27, #0x1
100247bfc:     	ldr	x27, [sp, #0x98]
100247c00:     	ldp	w26, w8, [sp, #0x80]
100247c04:     	b.lt	0x100246e68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0>
100247c08:     	ldr	x0, [sp, #0x18]
100247c0c:     	mov	x23, x11
100247c10:     	bl	0x100b5fd00 <_mi_free>
100247c14:     	mov	x11, x23
100247c18:     	ldr	w8, [sp, #0x84]
100247c1c:     	ldp	x23, x24, [x19, #0x68]
100247c20:     	b	0x100246e68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0>
100247c24:     	add	x0, sp, #0x188
100247c28:     	bl	0x100b3ca2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100247c2c:     	b	0x10024760c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x974>
100247c30:     	add	x8, sp, #0x188
100247c34:     	add	x0, x8, #0x18
100247c38:     	bl	0x100b3ca2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100247c3c:     	b	0x10024762c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x994>
100247c40:     	mov	x10, x23
100247c44:     	ldr	x0, [sp, #0x98]
100247c48:     	b	0x1002470ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x454>
100247c4c:     	add	x0, sp, #0x188
100247c50:     	mov	x22, x11
100247c54:     	bl	0x100b3ca2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100247c58:     	ldr	x12, [sp, #0x20]
100247c5c:     	mov	x11, x22
100247c60:     	ldr	x26, [sp, #0x190]
100247c64:     	b	0x100247b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xefc>
100247c68:     	add	x8, sp, #0x188
100247c6c:     	add	x0, x8, #0x18
100247c70:     	mov	x23, x11
100247c74:     	bl	0x100b3ca2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100247c78:     	mov	x11, x23
100247c7c:     	b	0x100247bb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf18>
100247c80:     	adrp	x0, 0x101051000 <_out_buf+0x3988>
100247c84:     	add	x0, x0, #0x840
100247c88:     	bl	0x100b22380 <__RINvMs1_NtNtCs4KWsSNcQanT_9once_cell4race8once_boxINtB6_7OnceBoxINtNtCsctvjasLqLe9_5alloc5boxed3BoxDNtNtCs3SoQS4yp3pP_5ahash12random_state12RandomSourceNtNtCsjgY6bXVaRmE_4core6marker4SendNtB2s_4SyncEL_EE4initNtNvMs1_B6_IBN_pE11get_or_init4VoidNCINvB2_11get_or_initNCNvB1C_7get_src0E0ECs3gRpqoBkMHm_13perry_runtime>
100247c8c:     	ldp	x0, x22, [x0]
100247c90:     	adrp	x8, 0x101051000 <_out_buf+0x3988>
100247c94:     	add	x8, x8, #0x848
100247c98:     	ldapr	x24, [x8]
100247c9c:     	cbnz	x24, 0x100247144 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x4ac>
100247ca0:     	mov	x23, x0
100247ca4:     	adrp	x0, 0x101051000 <_out_buf+0x3988>
100247ca8:     	add	x0, x0, #0x848
100247cac:     	bl	0x100b222c0 <__RINvMs1_NtNtCs4KWsSNcQanT_9once_cell4race8once_boxINtB6_7OnceBoxAAyj4_j2_E4initNtNvMs1_B6_IBN_pE11get_or_init4VoidNCINvB2_11get_or_initNCNvNtCs3SoQS4yp3pP_5ahash12random_state15get_fixed_seeds0E0ECs3gRpqoBkMHm_13perry_runtime>
100247cb0:     	mov	x24, x0
100247cb4:     	mov	x0, x23
100247cb8:     	b	0x100247144 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x4ac>
100247cbc:     	strb	wzr, [x19, #0xd4]
100247cc0:     	cmp	x27, #0x1
100247cc4:     	b.lt	0x100247cd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1038>
100247cc8:     	mov	x0, x24
100247ccc:     	bl	0x100b5fd00 <_mi_free>
100247cd0:     	ldr	x26, [sp, #0x98]
100247cd4:     	ldp	x9, x8, [x19, #0x68]
100247cd8:     	cmp	x8, x9
100247cdc:     	b.hs	0x100247d64 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x10cc>
100247ce0:     	ldr	x10, [x19, #0x60]
100247ce4:     	mov	x11, #0x2600            ; =9728
100247ce8:     	movk	x11, #0x1, lsl #32
100247cec:     	ldrb	w12, [x10, x8]
100247cf0:     	cmp	w12, #0x20
100247cf4:     	b.hi	0x100247d14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x107c>
100247cf8:     	lsr	x13, x11, x12
100247cfc:     	tbz	w13, #0x0, 0x100247d14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x107c>
100247d00:     	add	x8, x8, #0x1
100247d04:     	str	x8, [x19, #0x70]
100247d08:     	cmp	x9, x8
100247d0c:     	b.ne	0x100247cec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1054>
100247d10:     	b	0x100247d64 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x10cc>
100247d14:     	cmp	w12, #0x7d
100247d18:     	b.ne	0x100247d64 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x10cc>
100247d1c:     	add	x8, x8, #0x1
100247d20:     	str	x8, [x19, #0x70]
100247d24:     	ldr	x8, [sp, #0x188]
100247d28:     	cmn	x8, #0x1
100247d2c:     	b.ne	0x100247d74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x10dc>
100247d30:     	ldp	w8, w9, [sp, #0x80]
100247d34:     	and	w8, w8, w9
100247d38:     	tbz	w8, #0x0, 0x100247e28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1190>
100247d3c:     	ldr	x8, [sp, #0x70]
100247d40:     	cmp	x21, x8
100247d44:     	b.ne	0x100247e28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1190>
100247d48:     	cmp	x26, x21
100247d4c:     	b.ne	0x100247e28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1190>
100247d50:     	ldp	x21, x23, [sp, #0x88]
100247d54:     	cmp	x23, #0x9
100247d58:     	ldr	w2, [sp, #0x64]
100247d5c:     	b.lo	0x100247f18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1280>
100247d60:     	b	0x100247dec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1154>
100247d64:     	strb	wzr, [x19, #0xd4]
100247d68:     	ldr	x8, [sp, #0x188]
100247d6c:     	cmn	x8, #0x1
100247d70:     	b.eq	0x100247d30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1098>
100247d74:     	ldp	x0, x1, [sp, #0x190]
100247d78:     	cmp	x1, #0x9
100247d7c:     	b.hs	0x100247e04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x116c>
100247d80:     	ldr	x8, [x19, #0x78]
100247d84:     	cmp	x1, x8
100247d88:     	ldr	x23, [sp, #0x90]
100247d8c:     	b.ne	0x100247dac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
100247d90:     	ldr	x21, [x19, #0xc0]
100247d94:     	cbz	x21, 0x100247dac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
100247d98:     	cbz	x1, 0x100247ef8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
100247d9c:     	ldr	x8, [x19, #0x80]
100247da0:     	ldr	x9, [x0]
100247da4:     	cmp	x8, x9
100247da8:     	b.eq	0x100247ef0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1258>
100247dac:     	mov	x24, x0
100247db0:     	mov	x25, x1
100247db4:     	bl	0x10032a41c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100247db8:     	mov	x21, x0
100247dbc:     	mov	x26, x1
100247dc0:     	str	x25, [x19, #0x78]
100247dc4:     	lsl	x2, x25, #3
100247dc8:     	add	x0, x19, #0x80
100247dcc:     	mov	x1, x24
100247dd0:     	bl	0x100b62bac <_writev+0x100b62bac>
100247dd4:     	mov	x2, x26
100247dd8:     	str	x21, [x19, #0xc0]
100247ddc:     	str	w26, [x19, #0xd0]
100247de0:     	cmp	x23, #0x9
100247de4:     	ldr	x8, [sp, #0x20]
100247de8:     	b.lo	0x100247e20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1188>
100247dec:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100247df0:     	add	x3, x3, #0x800
100247df4:     	mov	x0, #0x0                ; =0
100247df8:     	mov	x1, x23
100247dfc:     	mov	w2, #0x8                ; =8
100247e00:     	bl	0x100b1360c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100247e04:     	bl	0x10032a41c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100247e08:     	mov	x21, x0
100247e0c:     	mov	x2, x1
100247e10:     	ldr	x23, [sp, #0x90]
100247e14:     	cmp	x23, #0x9
100247e18:     	ldr	x8, [sp, #0x20]
100247e1c:     	b.hs	0x100247dec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1154>
100247e20:     	mov	x23, x8
100247e24:     	b	0x100247f1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1284>
100247e28:     	ldr	x23, [sp, #0x90]
100247e2c:     	cmp	x23, #0x9
100247e30:     	b.hs	0x10024818c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x14f4>
100247e34:     	ldr	x8, [x19, #0x78]
100247e38:     	cmp	x23, x8
100247e3c:     	b.ne	0x100247e5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
100247e40:     	ldr	x21, [x19, #0xc0]
100247e44:     	cbz	x21, 0x100247e5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
100247e48:     	cbz	x23, 0x100247f14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
100247e4c:     	ldr	x8, [x19, #0x80]
100247e50:     	ldr	x9, [sp, #0x100]
100247e54:     	cmp	x8, x9
100247e58:     	b.eq	0x100247f0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1274>
100247e5c:     	add	x0, sp, #0x100
100247e60:     	mov	x1, x23
100247e64:     	bl	0x10032a41c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100247e68:     	mov	x21, x0
100247e6c:     	mov	x24, x1
100247e70:     	str	x23, [x19, #0x78]
100247e74:     	lsl	x2, x23, #3
100247e78:     	add	x0, x19, #0x80
100247e7c:     	add	x1, sp, #0x100
100247e80:     	bl	0x100b62bac <_writev+0x100b62bac>
100247e84:     	mov	x2, x24
100247e88:     	str	x21, [x19, #0xc0]
100247e8c:     	str	w24, [x19, #0xd0]
100247e90:     	b	0x100247f18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1280>
100247e94:     	b	0x100246d84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xec>
100247e98:     	sub	x0, x29, #0x68
100247e9c:     	mov	x1, #0x0                ; =0
100247ea0:     	bl	0x10032a41c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100247ea4:     	mov	x2, x1
100247ea8:     	mov	x1, x0
100247eac:     	str	xzr, [x19, #0x78]
100247eb0:     	str	x0, [x19, #0xc0]
100247eb4:     	str	w2, [x19, #0xd0]
100247eb8:     	add	x0, x19, #0x20
100247ebc:     	mov	w3, #0x8                ; =8
100247ec0:     	mov	x4, #0x0                ; =0
100247ec4:     	bl	0x1005bd408 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
100247ec8:     	mov	x19, x0
100247ecc:     	ldrb	w8, [x20, #0x20]
100247ed0:     	cbnz	w8, 0x1002481a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x150c>
100247ed4:     	ldr	x8, [x20]
100247ed8:     	cbnz	x8, 0x1002481e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1550>
100247edc:     	ldr	x8, [x20, #0x18]
100247ee0:     	cmp	x22, x8
100247ee4:     	b.hi	0x100247fbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1324>
100247ee8:     	str	x22, [x20, #0x18]
100247eec:     	b	0x100247fbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1324>
100247ef0:     	cmp	x1, #0x1
100247ef4:     	b.ne	0x100247fe4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x134c>
100247ef8:     	ldr	w2, [x19, #0xd0]
100247efc:     	cmp	x23, #0x9
100247f00:     	ldr	x8, [sp, #0x20]
100247f04:     	b.lo	0x100247e20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1188>
100247f08:     	b	0x100247dec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1154>
100247f0c:     	cmp	x23, #0x1
100247f10:     	b.ne	0x100248088 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x13f0>
100247f14:     	ldr	w2, [x19, #0xd0]
100247f18:     	add	x28, sp, #0x148
100247f1c:     	add	x0, x19, #0x20
100247f20:     	mov	x1, x21
100247f24:     	mov	x3, x28
100247f28:     	mov	x4, x23
100247f2c:     	bl	0x1005bd408 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
100247f30:     	mov	x19, x0
100247f34:     	ldrb	w8, [x20, #0x20]
100247f38:     	cbnz	w8, 0x100248164 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x14cc>
100247f3c:     	ldr	x8, [x20]
100247f40:     	cbnz	x8, 0x1002481e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1550>
100247f44:     	ldr	x8, [x20, #0x18]
100247f48:     	cmp	x22, x8
100247f4c:     	b.hi	0x100247f54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x12bc>
100247f50:     	str	x22, [x20, #0x18]
100247f54:     	ldr	x8, [sp, #0x188]
100247f58:     	cmn	x8, #0x1
100247f5c:     	b.eq	0x100247fbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1324>
100247f60:     	cbz	x8, 0x100247f6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x12d4>
100247f64:     	ldr	x0, [sp, #0x190]
100247f68:     	bl	0x100b5fd00 <_mi_free>
100247f6c:     	ldr	x8, [sp, #0x1a0]
100247f70:     	cbz	x8, 0x100247f7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x12e4>
100247f74:     	ldr	x0, [sp, #0x1a8]
100247f78:     	bl	0x100b5fd00 <_mi_free>
100247f7c:     	ldr	x20, [sp, #0x1b8]
100247f80:     	cmn	x20, #0x1
100247f84:     	b.eq	0x100247fbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1324>
100247f88:     	ldr	x9, [sp, #0x1d8]
100247f8c:     	cbz	x9, 0x100247fb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1318>
100247f90:     	lsl	x8, x9, #4
100247f94:     	add	x9, x8, x9
100247f98:     	cmn	x9, #0x19
100247f9c:     	b.eq	0x100247fb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1318>
100247fa0:     	ldr	x9, [sp, #0x1d0]
100247fa4:     	sub	x8, x9, x8
100247fa8:     	sub	x0, x8, #0x10
100247fac:     	bl	0x100b5fd00 <_mi_free>
100247fb0:     	cbz	x20, 0x100247fbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1324>
100247fb4:     	ldr	x0, [sp, #0x1c0]
100247fb8:     	bl	0x100b5fd00 <_mi_free>
100247fbc:     	mov	x0, #0x7ffd000000000000 ; =9222527611924643840
100247fc0:     	bfxil	x0, x19, #0, #48
100247fc4:     	add	sp, sp, #0x2e0
100247fc8:     	ldp	x29, x30, [sp, #0x50]
100247fcc:     	ldp	x20, x19, [sp, #0x40]
100247fd0:     	ldp	x22, x21, [sp, #0x30]
100247fd4:     	ldp	x24, x23, [sp, #0x20]
100247fd8:     	ldp	x26, x25, [sp, #0x10]
100247fdc:     	ldp	x28, x27, [sp], #0x60
100247fe0:     	ret
100247fe4:     	ldr	x8, [x19, #0x88]
100247fe8:     	ldr	x9, [x0, #0x8]
100247fec:     	cmp	x8, x9
100247ff0:     	b.ne	0x100247dac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
100247ff4:     	cmp	x1, #0x2
100247ff8:     	b.eq	0x100247ef8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
100247ffc:     	ldr	x8, [x19, #0x90]
100248000:     	ldr	x9, [x0, #0x10]
100248004:     	cmp	x8, x9
100248008:     	b.ne	0x100247dac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
10024800c:     	cmp	x1, #0x3
100248010:     	b.eq	0x100247ef8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
100248014:     	ldr	x8, [x19, #0x98]
100248018:     	ldr	x9, [x0, #0x18]
10024801c:     	cmp	x8, x9
100248020:     	b.ne	0x100247dac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
100248024:     	cmp	x1, #0x4
100248028:     	b.eq	0x100247ef8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
10024802c:     	ldr	x8, [x19, #0xa0]
100248030:     	ldr	x9, [x0, #0x20]
100248034:     	cmp	x8, x9
100248038:     	b.ne	0x100247dac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
10024803c:     	cmp	x1, #0x5
100248040:     	b.eq	0x100247ef8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
100248044:     	ldr	x8, [x19, #0xa8]
100248048:     	ldr	x9, [x0, #0x28]
10024804c:     	cmp	x8, x9
100248050:     	b.ne	0x100247dac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
100248054:     	cmp	x1, #0x6
100248058:     	b.eq	0x100247ef8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
10024805c:     	ldr	x8, [x19, #0xb0]
100248060:     	ldr	x9, [x0, #0x30]
100248064:     	cmp	x8, x9
100248068:     	b.ne	0x100247dac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
10024806c:     	cmp	x1, #0x7
100248070:     	b.eq	0x100247ef8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
100248074:     	ldr	x8, [x19, #0xb8]
100248078:     	ldr	x9, [x0, #0x38]
10024807c:     	cmp	x8, x9
100248080:     	b.ne	0x100247dac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
100248084:     	b	0x100247ef8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
100248088:     	ldr	x8, [x19, #0x88]
10024808c:     	ldr	x9, [sp, #0x108]
100248090:     	cmp	x8, x9
100248094:     	b.ne	0x100247e5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
100248098:     	cmp	x23, #0x2
10024809c:     	b.eq	0x100247f14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
1002480a0:     	ldr	x8, [x19, #0x90]
1002480a4:     	ldr	x9, [sp, #0x110]
1002480a8:     	cmp	x8, x9
1002480ac:     	b.ne	0x100247e5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
1002480b0:     	cmp	x23, #0x3
1002480b4:     	b.eq	0x100247f14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
1002480b8:     	ldr	x8, [x19, #0x98]
1002480bc:     	ldr	x9, [sp, #0x118]
1002480c0:     	cmp	x8, x9
1002480c4:     	b.ne	0x100247e5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
1002480c8:     	cmp	x23, #0x4
1002480cc:     	b.eq	0x100247f14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
1002480d0:     	ldr	x8, [x19, #0xa0]
1002480d4:     	ldr	x9, [sp, #0x120]
1002480d8:     	cmp	x8, x9
1002480dc:     	b.ne	0x100247e5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
1002480e0:     	cmp	x23, #0x5
1002480e4:     	b.eq	0x100247f14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
1002480e8:     	ldr	x8, [x19, #0xa8]
1002480ec:     	ldr	x9, [sp, #0x128]
1002480f0:     	cmp	x8, x9
1002480f4:     	b.ne	0x100247e5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
1002480f8:     	cmp	x23, #0x6
1002480fc:     	b.eq	0x100247f14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
100248100:     	ldr	x8, [x19, #0xb0]
100248104:     	ldr	x9, [sp, #0x130]
100248108:     	cmp	x8, x9
10024810c:     	b.ne	0x100247e5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
100248110:     	cmp	x23, #0x7
100248114:     	b.eq	0x100247f14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
100248118:     	ldr	x8, [x19, #0xb8]
10024811c:     	ldr	x9, [sp, #0x138]
100248120:     	cmp	x8, x9
100248124:     	b.ne	0x100247e5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
100248128:     	b	0x100247f14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
10024812c:     	cmp	w8, #0x1
100248130:     	b.ne	0x1002481ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1514>
100248134:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100248138:     	add	x1, x1, #0x998
10024813c:     	mov	x0, x20
100248140:     	bl	0x100a2101c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100248144:     	strb	wzr, [x20, #0x20]
100248148:     	ldr	x8, [x20]
10024814c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100248150:     	cmp	x8, x9
100248154:     	b.lo	0x100246db4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c>
100248158:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
10024815c:     	add	x0, x0, #0x4b8
100248160:     	bl	0x100b1331c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100248164:     	cmp	w8, #0x2
100248168:     	b.eq	0x1002481ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1514>
10024816c:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100248170:     	add	x1, x1, #0x998
100248174:     	mov	x0, x20
100248178:     	bl	0x100a2101c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10024817c:     	strb	wzr, [x20, #0x20]
100248180:     	ldr	x8, [x20]
100248184:     	cbz	x8, 0x100247f44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x12ac>
100248188:     	b	0x1002481e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1550>
10024818c:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100248190:     	add	x3, x3, #0x7e8
100248194:     	mov	x0, #0x0                ; =0
100248198:     	mov	x1, x23
10024819c:     	mov	w2, #0x8                ; =8
1002481a0:     	bl	0x100b1360c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1002481a4:     	cmp	w8, #0x2
1002481a8:     	b.ne	0x1002481cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1534>
1002481ac:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
1002481b0:     	add	x0, x0, #0xc18
1002481b4:     	bl	0x100b5935c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
1002481b8:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002481bc:     	add	x3, x3, #0x7a0
1002481c0:     	mov	x0, #0x0                ; =0
1002481c4:     	mov	w2, #0x8                ; =8
1002481c8:     	bl	0x100b1360c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1002481cc:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
1002481d0:     	add	x1, x1, #0x998
1002481d4:     	mov	x0, x20
1002481d8:     	bl	0x100a2101c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1002481dc:     	strb	wzr, [x20, #0x20]
1002481e0:     	ldr	x8, [x20]
1002481e4:     	cbz	x8, 0x100247edc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1244>
1002481e8:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
1002481ec:     	add	x0, x0, #0x4a0
1002481f0:     	bl	0x100b132ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1002481f4:     	adrp	x0, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002481f8:     	add	x0, x0, #0x758
1002481fc:     	bl	0x100b133b0 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100248200:     	adrp	x2, 0x100ef8000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100248204:     	add	x2, x2, #0x818
100248208:     	mov	x0, x27
10024820c:     	mov	w1, #0x8                ; =8
100248210:     	bl	0x100b1344c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100248214:     	adrp	x2, 0x100ef8000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100248218:     	add	x2, x2, #0xad0
10024821c:     	mov	x0, x24
100248220:     	bl	0x100b1344c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100248224:     	adrp	x2, 0x100f06000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x10ed0>
100248228:     	add	x2, x2, #0x410
10024822c:     	mov	x0, x24
100248230:     	bl	0x100b1344c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100248234:     	mov	w0, #0x8                ; =8
100248238:     	mov	w1, #0x1108             ; =4360
10024823c:     	bl	0x100b12f28 <__RNvNtCsctvjasLqLe9_5alloc5alloc18handle_alloc_error>
100248240:     	adrp	x2, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100248244:     	add	x2, x2, #0x7d0
100248248:     	mov	x0, x24
10024824c:     	bl	0x100b1344c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100248250:     	adrp	x2, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100248254:     	add	x2, x2, #0x7b8
100248258:     	mov	x0, x24
10024825c:     	bl	0x100b1344c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100248260:     	adrp	x2, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100248264:     	add	x2, x2, #0x788
100248268:     	mov	w1, #0x8                ; =8
10024826c:     	bl	0x100b1344c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100248270:     	adrp	x2, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100248274:     	add	x2, x2, #0x770
100248278:     	mov	w1, #0x8                ; =8
10024827c:     	bl	0x100b1344c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100248280:     	mov	w0, #0x8                ; =8
100248284:     	mov	w1, #0x80               ; =128
100248288:     	bl	0x100b12f40 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
