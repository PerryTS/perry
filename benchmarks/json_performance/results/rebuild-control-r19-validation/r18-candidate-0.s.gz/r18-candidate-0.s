
benchmarks/json_performance/.work/tape-batch-r18/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100245268 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array>:
100245268:     	sub	sp, sp, #0x40
10024526c:     	stp	x22, x21, [sp, #0x10]
100245270:     	stp	x20, x19, [sp, #0x20]
100245274:     	stp	x29, x30, [sp, #0x30]
100245278:     	add	x29, sp, #0x30
10024527c:     	mov	x19, x0
100245280:     	ldp	x22, x8, [x0, #0x68]
100245284:     	add	x21, x8, #0x1
100245288:     	str	x21, [x0, #0x70]
10024528c:     	cmp	x21, x22
100245290:     	b.hs	0x1002452c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x60>
100245294:     	ldr	x8, [x19, #0x60]
100245298:     	mov	x9, #0x2600             ; =9728
10024529c:     	movk	x9, #0x1, lsl #32
1002452a0:     	ldrb	w10, [x8, x21]
1002452a4:     	cmp	w10, #0x20
1002452a8:     	b.hi	0x1002452c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x60>
1002452ac:     	lsr	x10, x9, x10
1002452b0:     	tbz	w10, #0x0, 0x1002452c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x60>
1002452b4:     	add	x21, x21, #0x1
1002452b8:     	str	x21, [x19, #0x70]
1002452bc:     	cmp	x22, x21
1002452c0:     	b.ne	0x1002452a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x38>
1002452c4:     	mov	x21, x22
1002452c8:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1002452cc:     	add	x0, x0, #0xce8
1002452d0:     	ldr	x8, [x0]
1002452d4:     	blr	x8
1002452d8:     	ldrb	w8, [x0, #0x20]
1002452dc:     	cbnz	w8, 0x100245380 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x118>
1002452e0:     	ldr	x8, [x0]
1002452e4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1002452e8:     	cmp	x8, x9
1002452ec:     	b.hs	0x1002453b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x148>
1002452f0:     	ldr	x1, [x0, #0x18]
1002452f4:     	subs	x8, x22, x21
1002452f8:     	b.ls	0x100245368 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x100>
1002452fc:     	ldr	x9, [x19, #0x60]
100245300:     	ldrb	w9, [x9, x21]
100245304:     	cmp	w9, #0x7b
100245308:     	b.ne	0x100245368 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x100>
10024530c:     	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
100245310:     	movk	x9, #0xaaab
100245314:     	umulh	x8, x8, x9
100245318:     	lsr	x8, x8, #6
10024531c:     	mov	w9, #0x10               ; =16
100245320:     	cmp	x8, #0x10
100245324:     	csel	x8, x8, x9, hi
100245328:     	mov	w9, #0x4000             ; =16384
10024532c:     	cmp	x8, #0x4, lsl #12       ; =0x4000
100245330:     	csel	x2, x8, x9, lo
100245334:     	mov	x0, sp
100245338:     	mov	x20, x1
10024533c:     	add	x1, x19, #0x20
100245340:     	bl	0x100235ad0 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray3new>
100245344:     	mov	x1, sp
100245348:     	mov	x0, x19
10024534c:     	mov	x2, x20
100245350:     	bl	0x100245940 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser16parse_array_tail>
100245354:     	ldp	x29, x30, [sp, #0x30]
100245358:     	ldp	x20, x19, [sp, #0x20]
10024535c:     	ldp	x22, x21, [sp, #0x10]
100245360:     	add	sp, sp, #0x40
100245364:     	ret
100245368:     	mov	x0, x19
10024536c:     	ldp	x29, x30, [sp, #0x30]
100245370:     	ldp	x20, x19, [sp, #0x20]
100245374:     	ldp	x22, x21, [sp, #0x10]
100245378:     	add	sp, sp, #0x40
10024537c:     	b	0x100245dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_array_prefix>
100245380:     	cmp	w8, #0x1
100245384:     	b.ne	0x1002453bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x154>
100245388:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
10024538c:     	add	x1, x1, #0x998
100245390:     	mov	x20, x0
100245394:     	bl	0x100a2101c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100245398:     	mov	x0, x20
10024539c:     	strb	wzr, [x20, #0x20]
1002453a0:     	ldr	x8, [x20]
1002453a4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1002453a8:     	cmp	x8, x9
1002453ac:     	b.lo	0x1002452f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x88>
1002453b0:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
1002453b4:     	add	x0, x0, #0x4b8
1002453b8:     	bl	0x100b1331c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1002453bc:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
1002453c0:     	add	x0, x0, #0xc18
1002453c4:     	bl	0x100b5935c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
