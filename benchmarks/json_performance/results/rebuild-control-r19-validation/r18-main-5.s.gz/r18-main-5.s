
benchmarks/json_performance/.work/tape-batch-r18/main-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001005bc7c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>:
1005bc7c8:     	sub	sp, sp, #0xa0
1005bc7cc:     	stp	d9, d8, [sp, #0x30]
1005bc7d0:     	stp	x28, x27, [sp, #0x40]
1005bc7d4:     	stp	x26, x25, [sp, #0x50]
1005bc7d8:     	stp	x24, x23, [sp, #0x60]
1005bc7dc:     	stp	x22, x21, [sp, #0x70]
1005bc7e0:     	stp	x20, x19, [sp, #0x80]
1005bc7e4:     	stp	x29, x30, [sp, #0x90]
1005bc7e8:     	add	x29, sp, #0x90
1005bc7ec:     	mov	x19, x4
1005bc7f0:     	mov	x21, x3
1005bc7f4:     	mov	x23, x2
1005bc7f8:     	mov	x22, x1
1005bc7fc:     	mov	w8, #0x2                ; =2
1005bc800:     	cmp	x4, #0x2
1005bc804:     	csel	x25, x4, x8, hi
1005bc808:     	ldr	x24, [x0]
1005bc80c:     	cbz	x24, 0x1005bc850 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x88>
1005bc810:     	mov	w8, #0x3ffd             ; =16381
1005bc814:     	cmp	x19, x8
1005bc818:     	b.hi	0x1005bc850 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x88>
1005bc81c:     	ldr	x8, [x0, #0x10]
1005bc820:     	ldrb	w8, [x8]
1005bc824:     	tbnz	w8, #0x0, 0x1005bc850 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x88>
1005bc828:     	lsl	x8, x25, #3
1005bc82c:     	ldr	x9, [x0, #0x8]
1005bc830:     	add	x8, x8, #0x18
1005bc834:     	ldp	x10, x11, [x9, #0x8]
1005bc838:     	add	x10, x10, #0x7
1005bc83c:     	and	x10, x10, #0xfffffffffffffff8
1005bc840:     	subs	x11, x11, x10
1005bc844:     	csel	x11, xzr, x11, lo
1005bc848:     	cmp	x8, x11
1005bc84c:     	b.ls	0x1005bca10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x248>
1005bc850:     	add	x0, sp, #0x8
1005bc854:     	mov	w1, #0x0                ; =0
1005bc858:     	mov	w2, #0x0                ; =0
1005bc85c:     	mov	x3, x19
1005bc860:     	mov	x4, x22
1005bc864:     	mov	x5, x23
1005bc868:     	bl	0x1005da400 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object5alloc35object_alloc_class_inline_keys_impl>
1005bc86c:     	ldr	x20, [sp, #0x8]
1005bc870:     	ldrb	w8, [sp, #0x14]
1005bc874:     	tbnz	w8, #0x0, 0x1005bc888 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0xc0>
1005bc878:     	ldr	w2, [sp, #0x10]
1005bc87c:     	mov	x0, x20
1005bc880:     	mov	x1, x23
1005bc884:     	bl	0x1005dfec0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes24birth_stamp_object_shape>
1005bc888:     	cbz	x20, 0x1005bc898 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0xd0>
1005bc88c:     	ldurh	w8, [x20, #-0x6]
1005bc890:     	orr	w8, w8, #0x200
1005bc894:     	sturh	w8, [x20, #-0x6]
1005bc898:     	lsl	x22, x19, #3
1005bc89c:     	cbz	x24, 0x1005bc904 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x13c>
1005bc8a0:     	cbz	x19, 0x1005bc9d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x20c>
1005bc8a4:     	sub	x8, x22, #0x8
1005bc8a8:     	cmp	x8, #0x18
1005bc8ac:     	b.lo	0x1005bc8c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0xf8>
1005bc8b0:     	sub	x9, x20, x21
1005bc8b4:     	add	x9, x9, #0xf
1005bc8b8:     	cmp	x9, #0xff
1005bc8bc:     	b.hs	0x1005bc9f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x22c>
1005bc8c0:     	mov	w23, #0x0               ; =0
1005bc8c4:     	mov	x8, #0x0                ; =0
1005bc8c8:     	mov	x9, x21
1005bc8cc:     	add	x10, x21, x22
1005bc8d0:     	add	x8, x20, x8, lsl #3
1005bc8d4:     	add	x8, x8, #0x10
1005bc8d8:     	mov	x11, #-0x3000000000000  ; =-844424930131968
1005bc8dc:     	mov	x12, #0x7ffd000000000000 ; =9222527611924643840
1005bc8e0:     	ldr	x13, [x9], #0x8
1005bc8e4:     	str	x13, [x8], #0x8
1005bc8e8:     	and	x13, x13, x11
1005bc8ec:     	cmp	x13, x12
1005bc8f0:     	cset	w13, eq
1005bc8f4:     	orr	w23, w23, w13
1005bc8f8:     	cmp	x9, x10
1005bc8fc:     	b.ne	0x1005bc8e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x118>
1005bc900:     	b	0x1005bc934 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x16c>
1005bc904:     	cbz	x19, 0x1005bc9d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x20c>
1005bc908:     	mov	w23, #0x0               ; =0
1005bc90c:     	mov	x1, #0x0                ; =0
1005bc910:     	mov	x26, x22
1005bc914:     	add	x27, x1, #0x1
1005bc918:     	ldr	x2, [x21, x1, lsl #3]
1005bc91c:     	mov	x0, x20
1005bc920:     	bl	0x10034a348 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object39store_object_field_slot_layout_deferred>
1005bc924:     	orr	w23, w23, w0
1005bc928:     	mov	x1, x27
1005bc92c:     	subs	x26, x26, #0x8
1005bc930:     	b.ne	0x1005bc914 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x14c>
1005bc934:     	cmp	x19, #0x2
1005bc938:     	b.hs	0x1005bc958 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x190>
1005bc93c:     	add	x8, x20, x22
1005bc940:     	sub	x9, x25, x19
1005bc944:     	lsl	x2, x9, #3
1005bc948:     	adrp	x1, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6f30>
1005bc94c:     	add	x1, x1, #0xbb0
1005bc950:     	add	x0, x8, #0x10
1005bc954:     	bl	0x100b61d90 <_writev+0x100b61d90>
1005bc958:     	tbz	w23, #0x0, 0x1005bcd8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5c4>
1005bc95c:     	lsr	x8, x20, #3
1005bc960:     	cmp	x8, #0x201
1005bc964:     	b.lo	0x1005bcd78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5b0>
1005bc968:     	ldurb	w8, [x20, #-0x8]
1005bc96c:     	sub	w9, w8, #0x15
1005bc970:     	cmn	w9, #0x14
1005bc974:     	b.lo	0x1005bcd78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5b0>
1005bc978:     	adrp	x9, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
1005bc97c:     	add	x9, x9, #0x5a0
1005bc980:     	add	x8, x9, x8, lsl #5
1005bc984:     	ldrb	w8, [x8, #0x14]
1005bc988:     	mov	w9, #0x16               ; =22
1005bc98c:     	lsr	w8, w9, w8
1005bc990:     	tbz	w8, #0x0, 0x1005bcd78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5b0>
1005bc994:     	ldurh	w8, [x20, #-0x6]
1005bc998:     	and	w9, w8, #0xffffefff
1005bc99c:     	sturh	w9, [x20, #-0x6]
1005bc9a0:     	ands	w21, w8, #0xc000
1005bc9a4:     	b.eq	0x1005bcd70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5a8>
1005bc9a8:     	and	w8, w8, #0xfff
1005bc9ac:     	sturh	w8, [x20, #-0x6]
1005bc9b0:     	mov	x0, x20
1005bc9b4:     	bl	0x100434e20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc13layout_tables20typed_layouts_remove>
1005bc9b8:     	cmp	w21, #0x4, lsl #12      ; =0x4000
1005bc9bc:     	b.eq	0x1005bc9c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x200>
1005bc9c0:     	mov	x0, x20
1005bc9c4:     	bl	0x100434434 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc13layout_tables17slot_masks_remove>
1005bc9c8:     	mov	x0, x20
1005bc9cc:     	bl	0x1002d8700 <__RNvNtCs3gRpqoBkMHm_13perry_runtime14typed_feedback32invalidate_representation_change>
1005bc9d0:     	b	0x1005bcd78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5b0>
1005bc9d4:     	add	x8, x20, x22
1005bc9d8:     	sub	x9, x25, x19
1005bc9dc:     	lsl	x2, x9, #3
1005bc9e0:     	adrp	x1, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6f30>
1005bc9e4:     	add	x1, x1, #0xbb0
1005bc9e8:     	add	x0, x8, #0x10
1005bc9ec:     	bl	0x100b61d90 <_writev+0x100b61d90>
1005bc9f0:     	b	0x1005bcd8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5c4>
1005bc9f4:     	lsr	x9, x8, #3
1005bc9f8:     	add	x10, x9, #0x1
1005bc9fc:     	cmp	x8, #0xf8
1005bca00:     	b.hs	0x1005bcb88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x3c0>
1005bca04:     	mov	x8, #0x0                ; =0
1005bca08:     	mov	w23, #0x0               ; =0
1005bca0c:     	b	0x1005bccec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x524>
1005bca10:     	ldr	x11, [x9]
1005bca14:     	add	x26, x11, x10
1005bca18:     	add	x10, x10, x8
1005bca1c:     	str	x10, [x9, #0x8]
1005bca20:     	mov	w9, #0x202              ; =514
1005bca24:     	stp	w9, w8, [x26]
1005bca28:     	mov	x20, x26
1005bca2c:     	str	xzr, [x20, #0x8]!
1005bca30:     	str	xzr, [x26, #0x10]
1005bca34:     	mov	x0, x20
1005bca38:     	mov	x1, x23
1005bca3c:     	mov	x2, x22
1005bca40:     	mov	x3, x19
1005bca44:     	bl	0x1005e57f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34try_birth_stamp_preinstalled_shape>
1005bca48:     	lsr	x27, x20, #3
1005bca4c:     	tbnz	w0, #0x0, 0x1005bcb2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x364>
1005bca50:     	mov	x0, x22
1005bca54:     	mov	x1, x19
1005bca58:     	mov	x2, x19
1005bca5c:     	mov	x3, #0x0                ; =0
1005bca60:     	mov	w4, #0x0                ; =0
1005bca64:     	mov	w5, #0x0                ; =0
1005bca68:     	bl	0x1005e4e80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_descriptor_ensure_with_holes>
1005bca6c:     	tbnz	w0, #0x0, 0x1005bce88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x6c0>
1005bca70:     	ldr	w28, [x26, #0xc]
1005bca74:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1005bca78:     	ldr	w23, [x8, #0x800]
1005bca7c:     	cmp	w23, #0x300
1005bca80:     	b.hs	0x1005bcdd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x608>
1005bca84:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1005bca88:     	ldr	x8, [x8, #0x48]
1005bca8c:     	cmn	x8, #0x1
1005bca90:     	b.eq	0x1005bcdb4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5ec>
1005bca94:     	mrs	x9, TPIDRRO_EL0
1005bca98:     	and	x9, x9, #0xfffffffffffffff8
1005bca9c:     	ldr	x8, [x9, x8, lsl #3]
1005bcaa0:     	cbz	x8, 0x1005bcdb4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5ec>
1005bcaa4:     	add	x8, x8, x23, lsl #3
1005bcaa8:     	ldr	x8, [x8, #0x1e8]
1005bcaac:     	cbz	x8, 0x1005bcdd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x608>
1005bcab0:     	lsr	x23, x0, #32
1005bcab4:     	ldr	x0, [x8]
1005bcab8:     	cbz	x0, 0x1005bcdf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x62c>
1005bcabc:     	ldr	x9, [x0, #0x51d0]
1005bcac0:     	mov	w8, #-0x40000001        ; =-1073741825
1005bcac4:     	cmp	w28, w8
1005bcac8:     	ubfx	x8, x28, #15, #15
1005bcacc:     	ccmp	x8, x9, #0x2, le
1005bcad0:     	b.lo	0x1005bce10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x648>
1005bcad4:     	mov	w8, #0x2                ; =2
1005bcad8:     	strb	w8, [sp, #0x2e]
1005bcadc:     	cbz	x22, 0x1005bcb08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x340>
1005bcae0:     	cmp	x27, #0x201
1005bcae4:     	b.lo	0x1005bcb08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x340>
1005bcae8:     	ldrh	w8, [x26, #0x2]
1005bcaec:     	sxth	w9, w8
1005bcaf0:     	tst	w8, #0x1000
1005bcaf4:     	mov	w8, #-0x4001            ; =-16385
1005bcaf8:     	ccmp	w9, w8, #0x4, eq
1005bcafc:     	b.gt	0x1005bcb08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x340>
1005bcb00:     	mov	x0, x20
1005bcb04:     	bl	0x1004564cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6layout19layout_mark_unknown>
1005bcb08:     	add	x1, sp, #0x8
1005bcb0c:     	mov	x0, x20
1005bcb10:     	mov	x2, x22
1005bcb14:     	mov	x3, x19
1005bcb18:     	bl	0x1005e066c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes25publish_object_shape_from>
1005bcb1c:     	mov	x0, x20
1005bcb20:     	mov	x1, x23
1005bcb24:     	mov	x2, x19
1005bcb28:     	bl	0x1005dfec0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes24birth_stamp_object_shape>
1005bcb2c:     	cmp	x27, #0x201
1005bcb30:     	b.lo	0x1005bc88c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0xc4>
1005bcb34:     	ldrb	w8, [x26]
1005bcb38:     	sub	w9, w8, #0x15
1005bcb3c:     	cmn	w9, #0x14
1005bcb40:     	b.lo	0x1005bc88c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0xc4>
1005bcb44:     	adrp	x9, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
1005bcb48:     	add	x9, x9, #0x5a0
1005bcb4c:     	add	x8, x9, x8, lsl #5
1005bcb50:     	ldrb	w8, [x8, #0x14]
1005bcb54:     	mov	w9, #0x16               ; =22
1005bcb58:     	lsr	w8, w9, w8
1005bcb5c:     	tbz	w8, #0x0, 0x1005bc88c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0xc4>
1005bcb60:     	ldrh	w8, [x26, #0x2]
1005bcb64:     	mov	w9, #0x4000             ; =16384
1005bcb68:     	bfxil	w9, w8, #0, #13
1005bcb6c:     	strh	w9, [x26, #0x2]
1005bcb70:     	mov	x0, x20
1005bcb74:     	bl	0x100434774 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc13layout_tables20layout_forget_object>
1005bcb78:     	ldrh	w8, [x26, #0x2]
1005bcb7c:     	and	w8, w8, #0xffffefff
1005bcb80:     	strh	w8, [x26, #0x2]
1005bcb84:     	b	0x1005bc88c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0xc4>
1005bcb88:     	and	x11, x10, #0x1c
1005bcb8c:     	and	x8, x10, #0x3fffffffffffffe0
1005bcb90:     	add	x12, x20, #0x90
1005bcb94:     	add	x13, x21, #0x80
1005bcb98:     	movi.2d	v0, #0000000000000000
1005bcb9c:     	mov	x9, #-0x3000000000000   ; =-844424930131968
1005bcba0:     	dup.2d	v1, x9
1005bcba4:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
1005bcba8:     	dup.2d	v2, x9
1005bcbac:     	and	x14, x10, #0x3fffffffffffffe0
1005bcbb0:     	add	x9, x21, x8, lsl #3
1005bcbb4:     	movi.2d	v3, #0000000000000000
1005bcbb8:     	ldp	q17, q16, [x13, #-0x80]
1005bcbbc:     	ldp	q19, q18, [x13, #-0x60]
1005bcbc0:     	ldp	q21, q20, [x13, #-0x40]
1005bcbc4:     	ldp	q23, q22, [x13, #-0x20]
1005bcbc8:     	ldp	q5, q4, [x13]
1005bcbcc:     	ldp	q7, q6, [x13, #0x20]
1005bcbd0:     	ldp	q25, q24, [x13, #0x40]
1005bcbd4:     	and.16b	v26, v17, v1
1005bcbd8:     	and.16b	v27, v16, v1
1005bcbdc:     	and.16b	v28, v19, v1
1005bcbe0:     	and.16b	v29, v18, v1
1005bcbe4:     	and.16b	v30, v21, v1
1005bcbe8:     	and.16b	v31, v20, v1
1005bcbec:     	ldp	q9, q8, [x13, #0x60]
1005bcbf0:     	stp	q21, q20, [x12, #-0x40]
1005bcbf4:     	and.16b	v20, v23, v1
1005bcbf8:     	stp	q23, q22, [x12, #-0x20]
1005bcbfc:     	and.16b	v21, v22, v1
1005bcc00:     	cmeq.2d	v21, v21, v2
1005bcc04:     	cmeq.2d	v20, v20, v2
1005bcc08:     	uzp1.4s	v20, v20, v21
1005bcc0c:     	and.16b	v21, v5, v1
1005bcc10:     	stp	q19, q18, [x12, #-0x60]
1005bcc14:     	and.16b	v18, v4, v1
1005bcc18:     	cmeq.2d	v19, v31, v2
1005bcc1c:     	cmeq.2d	v22, v30, v2
1005bcc20:     	uzp1.4s	v19, v22, v19
1005bcc24:     	and.16b	v22, v7, v1
1005bcc28:     	stp	q17, q16, [x12, #-0x80]
1005bcc2c:     	and.16b	v16, v6, v1
1005bcc30:     	uzp1.8h	v17, v19, v20
1005bcc34:     	and.16b	v19, v25, v1
1005bcc38:     	stp	q25, q24, [x12, #0x40]
1005bcc3c:     	and.16b	v20, v24, v1
1005bcc40:     	cmeq.2d	v23, v29, v2
1005bcc44:     	cmeq.2d	v24, v28, v2
1005bcc48:     	uzp1.4s	v23, v24, v23
1005bcc4c:     	and.16b	v24, v9, v1
1005bcc50:     	stp	q9, q8, [x12, #0x60]
1005bcc54:     	and.16b	v25, v8, v1
1005bcc58:     	cmeq.2d	v27, v27, v2
1005bcc5c:     	cmeq.2d	v26, v26, v2
1005bcc60:     	uzp1.4s	v26, v26, v27
1005bcc64:     	uzp1.8h	v23, v26, v23
1005bcc68:     	uzp1.16b	v17, v23, v17
1005bcc6c:     	cmeq.2d	v23, v25, v2
1005bcc70:     	cmeq.2d	v24, v24, v2
1005bcc74:     	uzp1.4s	v23, v24, v23
1005bcc78:     	cmeq.2d	v20, v20, v2
1005bcc7c:     	cmeq.2d	v19, v19, v2
1005bcc80:     	uzp1.4s	v19, v19, v20
1005bcc84:     	uzp1.8h	v19, v19, v23
1005bcc88:     	cmeq.2d	v16, v16, v2
1005bcc8c:     	cmeq.2d	v20, v22, v2
1005bcc90:     	uzp1.4s	v16, v20, v16
1005bcc94:     	stp	q7, q6, [x12, #0x20]
1005bcc98:     	cmeq.2d	v6, v18, v2
1005bcc9c:     	cmeq.2d	v7, v21, v2
1005bcca0:     	uzp1.4s	v6, v7, v6
1005bcca4:     	uzp1.8h	v6, v6, v16
1005bcca8:     	stp	q5, q4, [x12], #0x100
1005bccac:     	uzp1.16b	v4, v6, v19
1005bccb0:     	orr.16b	v0, v0, v17
1005bccb4:     	orr.16b	v3, v3, v4
1005bccb8:     	add	x13, x13, #0x100
1005bccbc:     	subs	x14, x14, #0x20
1005bccc0:     	b.ne	0x1005bcbb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x3f0>
1005bccc4:     	orr.16b	v0, v3, v0
1005bccc8:     	shl.16b	v0, v0, #0x7
1005bcccc:     	cmlt.16b	v0, v0, #0
1005bccd0:     	addp.2d	d0, v0
1005bccd4:     	fmov	x12, d0
1005bccd8:     	cmp	x12, #0x0
1005bccdc:     	cset	w23, ne
1005bcce0:     	cmp	x10, x8
1005bcce4:     	b.eq	0x1005bc934 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x16c>
1005bcce8:     	cbz	x11, 0x1005bc8cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x104>
1005bccec:     	mov	x12, x8
1005bccf0:     	and	x8, x10, #0x3ffffffffffffffc
1005bccf4:     	movi.2d	v0, #0000000000000000
1005bccf8:     	mov.h	v0[0], w23
1005bccfc:     	add	x9, x21, x8, lsl #3
1005bcd00:     	sub	x11, x12, x8
1005bcd04:     	lsl	x13, x12, #3
1005bcd08:     	add	x12, x13, x20
1005bcd0c:     	add	x12, x12, #0x10
1005bcd10:     	add	x13, x21, x13
1005bcd14:     	mov	x14, #-0x3000000000000  ; =-844424930131968
1005bcd18:     	dup.2d	v1, x14
1005bcd1c:     	mov	x14, #0x7ffd000000000000 ; =9222527611924643840
1005bcd20:     	dup.2d	v2, x14
1005bcd24:     	ldp	q3, q4, [x13], #0x20
1005bcd28:     	stp	q3, q4, [x12], #0x20
1005bcd2c:     	and.16b	v3, v3, v1
1005bcd30:     	and.16b	v4, v4, v1
1005bcd34:     	cmeq.2d	v4, v4, v2
1005bcd38:     	cmeq.2d	v3, v3, v2
1005bcd3c:     	uzp1.4s	v3, v3, v4
1005bcd40:     	xtn.4h	v3, v3
1005bcd44:     	orr.8b	v0, v0, v3
1005bcd48:     	adds	x11, x11, #0x4
1005bcd4c:     	b.ne	0x1005bcd24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x55c>
1005bcd50:     	shl.4h	v0, v0, #0xf
1005bcd54:     	cmlt.4h	v0, v0, #0
1005bcd58:     	fmov	x11, d0
1005bcd5c:     	cmp	x11, #0x0
1005bcd60:     	cset	w23, ne
1005bcd64:     	cmp	x10, x8
1005bcd68:     	b.ne	0x1005bc8cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x104>
1005bcd6c:     	b	0x1005bc934 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x16c>
1005bcd70:     	mov	x0, x20
1005bcd74:     	bl	0x100434774 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc13layout_tables20layout_forget_object>
1005bcd78:     	tbz	w24, #0x0, 0x1005bcd8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5c4>
1005bcd7c:     	add	x1, x20, #0x10
1005bcd80:     	mov	x0, x20
1005bcd84:     	mov	x2, x19
1005bcd88:     	bl	0x100237d9c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime5arena12constructionNtB2_17ConstructionBatch17finish_json_slots>
1005bcd8c:     	mov	x0, x20
1005bcd90:     	ldp	x29, x30, [sp, #0x90]
1005bcd94:     	ldp	x20, x19, [sp, #0x80]
1005bcd98:     	ldp	x22, x21, [sp, #0x70]
1005bcd9c:     	ldp	x24, x23, [sp, #0x60]
1005bcda0:     	ldp	x26, x25, [sp, #0x50]
1005bcda4:     	ldp	x28, x27, [sp, #0x40]
1005bcda8:     	ldp	d9, d8, [sp, #0x30]
1005bcdac:     	add	sp, sp, #0xa0
1005bcdb0:     	ret
1005bcdb4:     	str	x0, [sp]
1005bcdb8:     	bl	0x100b3f2fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005bcdbc:     	mov	x8, x0
1005bcdc0:     	ldr	x0, [sp]
1005bcdc4:     	add	x8, x8, x23, lsl #3
1005bcdc8:     	ldr	x8, [x8, #0x1e8]
1005bcdcc:     	cbnz	x8, 0x1005bcab0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x2e8>
1005bcdd0:     	adrp	x8, 0x100f06000 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json25PARSE_KEY_CACHE_OVERSIZED+0x3b0>
1005bcdd4:     	add	x8, x8, #0x578
1005bcdd8:     	mov	x23, x0
1005bcddc:     	mov	x0, x8
1005bcde0:     	bl	0x100b3cb1c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1005bcde4:     	mov	x8, x0
1005bcde8:     	lsr	x23, x23, #32
1005bcdec:     	ldr	x0, [x8]
1005bcdf0:     	cbnz	x0, 0x1005bcabc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x2f4>
1005bcdf4:     	bl	0x100b3e7a0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime5state10init_state>
1005bcdf8:     	ldr	x9, [x0, #0x51d0]
1005bcdfc:     	mov	w8, #-0x40000001        ; =-1073741825
1005bce00:     	cmp	w28, w8
1005bce04:     	ubfx	x8, x28, #15, #15
1005bce08:     	ccmp	x8, x9, #0x2, le
1005bce0c:     	b.hs	0x1005bcad4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x30c>
1005bce10:     	ldr	x9, [x0, #0x51c8]
1005bce14:     	ldr	x8, [x9, x8, lsl #3]
1005bce18:     	cbz	x8, 0x1005bcad4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x30c>
1005bce1c:     	ubfx	x9, x28, #5, #10
1005bce20:     	ldr	x8, [x8, x9, lsl #3]
1005bce24:     	cbz	x8, 0x1005bcad4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x30c>
1005bce28:     	and	x9, x28, #0x1f
1005bce2c:     	add	x8, x8, x9, lsl #5
1005bce30:     	ldrb	w10, [x8, #0x1c]
1005bce34:     	tbz	w10, #0x0, 0x1005bcad4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x30c>
1005bce38:     	mov	w9, #0x90               ; =144
1005bce3c:     	tst	w10, w9
1005bce40:     	cset	w11, ne
1005bce44:     	ldp	x9, x12, [x8]
1005bce48:     	ubfx	w13, w10, #5, #1
1005bce4c:     	ldr	w14, [x8, #0x18]
1005bce50:     	ubfx	w10, w10, #2, #1
1005bce54:     	stp	x9, x8, [sp, #0x8]
1005bce58:     	str	x12, [sp, #0x18]
1005bce5c:     	ldr	d0, [x8, #0x10]
1005bce60:     	str	d0, [sp, #0x20]
1005bce64:     	str	w14, [sp, #0x28]
1005bce68:     	strb	w10, [sp, #0x2c]
1005bce6c:     	strb	w11, [sp, #0x2d]
1005bce70:     	strb	w13, [sp, #0x2e]
1005bce74:     	cmp	x27, #0x201
1005bce78:     	b.lo	0x1005bcb08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x340>
1005bce7c:     	cmp	x9, x22
1005bce80:     	b.ne	0x1005bcae8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x320>
1005bce84:     	b	0x1005bcb08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x340>
1005bce88:     	tbnz	w0, #0x8, 0x1005bce90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x6c8>
1005bce8c:     	bl	0x100b4acf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes24shape_id_exhausted_abort>
1005bce90:     	bl	0x100b4ad10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes25invalid_shape_facts_abort>
