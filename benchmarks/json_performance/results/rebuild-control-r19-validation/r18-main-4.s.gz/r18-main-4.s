
benchmarks/json_performance/.work/tape-batch-r18/main-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100505d78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>:
100505d78:     	stp	x28, x27, [sp, #-0x60]!
100505d7c:     	stp	x26, x25, [sp, #0x10]
100505d80:     	stp	x24, x23, [sp, #0x20]
100505d84:     	stp	x22, x21, [sp, #0x30]
100505d88:     	stp	x20, x19, [sp, #0x40]
100505d8c:     	stp	x29, x30, [sp, #0x50]
100505d90:     	add	x29, sp, #0x50
100505d94:     	sub	sp, sp, #0x1a0
100505d98:     	mov	x19, x1
100505d9c:     	mov	x21, x0
100505da0:     	bl	0x1004ed650 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template>
100505da4:     	cmp	x0, #0x1
100505da8:     	b.ne	0x100505dd4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5c>
100505dac:     	mov	x23, x1
100505db0:     	mov	x0, x23
100505db4:     	add	sp, sp, #0x1a0
100505db8:     	ldp	x29, x30, [sp, #0x50]
100505dbc:     	ldp	x20, x19, [sp, #0x40]
100505dc0:     	ldp	x22, x21, [sp, #0x30]
100505dc4:     	ldp	x24, x23, [sp, #0x20]
100505dc8:     	ldp	x26, x25, [sp, #0x10]
100505dcc:     	ldp	x28, x27, [sp], #0x60
100505dd0:     	ret
100505dd4:     	add	x24, x21, #0x14
100505dd8:     	cmp	x19, #0x2
100505ddc:     	b.ne	0x100505df4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7c>
100505de0:     	ldrh	w8, [x24]
100505de4:     	mov	w9, #0x7d7b             ; =32123
100505de8:     	cmp	w8, w9
100505dec:     	b.ne	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100505df0:     	b	0x100505e8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x114>
100505df4:     	cmp	x19, #0x3
100505df8:     	b.hs	0x100505e60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe8>
100505dfc:     	add	x0, sp, #0xa0
100505e00:     	add	x1, x21, #0x14
100505e04:     	mov	x2, x19
100505e08:     	bl	0x1004f6058 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object6decode>
100505e0c:     	ldr	w8, [sp, #0xa0]
100505e10:     	tbz	w8, #0x0, 0x100505f64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1ec>
100505e14:     	add	x8, sp, #0xa0
100505e18:     	ldr	x9, [sp, #0x128]
100505e1c:     	str	x9, [sp, #0x90]
100505e20:     	ldur	q0, [x8, #0x48]
100505e24:     	ldur	q1, [x8, #0x58]
100505e28:     	stp	q0, q1, [sp, #0x50]
100505e2c:     	ldur	q0, [x8, #0x68]
100505e30:     	ldur	q1, [x8, #0x78]
100505e34:     	stp	q0, q1, [sp, #0x70]
100505e38:     	ldur	q0, [x8, #0x8]
100505e3c:     	ldur	q1, [x8, #0x18]
100505e40:     	stp	q0, q1, [sp, #0x10]
100505e44:     	ldur	q0, [x8, #0x28]
100505e48:     	ldur	q1, [x8, #0x38]
100505e4c:     	stp	q0, q1, [sp, #0x30]
100505e50:     	add	x0, sp, #0x10
100505e54:     	bl	0x1004f6808 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object8allocate>
100505e58:     	tbnz	w0, #0x0, 0x100505dac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x34>
100505e5c:     	b	0x100505f64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1ec>
100505e60:     	ldrb	w20, [x24]
100505e64:     	cmp	w20, #0x20
100505e68:     	b.hi	0x100505eac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x134>
100505e6c:     	mov	x8, #0x2600             ; =9728
100505e70:     	movk	x8, #0x1, lsl #32
100505e74:     	lsr	x8, x8, x20
100505e78:     	tbz	w8, #0x0, 0x100505eac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x134>
100505e7c:     	add	x0, x21, #0x14
100505e80:     	mov	x1, x19
100505e84:     	bl	0x1004ec828 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty19padded_empty_object>
100505e88:     	tbz	w0, #0x0, 0x100505ed8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x160>
100505e8c:     	add	sp, sp, #0x1a0
100505e90:     	ldp	x29, x30, [sp, #0x50]
100505e94:     	ldp	x20, x19, [sp, #0x40]
100505e98:     	ldp	x22, x21, [sp, #0x30]
100505e9c:     	ldp	x24, x23, [sp, #0x20]
100505ea0:     	ldp	x26, x25, [sp, #0x10]
100505ea4:     	ldp	x28, x27, [sp], #0x60
100505ea8:     	b	0x1004ec900 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100505eac:     	cmp	w20, #0x7b
100505eb0:     	b.ne	0x100505ed8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x160>
100505eb4:     	ldrb	w8, [x21, #0x15]
100505eb8:     	cmp	w8, #0x20
100505ebc:     	b.hi	0x100505ed0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x158>
100505ec0:     	mov	x9, #0x2600             ; =9728
100505ec4:     	movk	x9, #0x1, lsl #32
100505ec8:     	lsr	x9, x9, x8
100505ecc:     	tbnz	w9, #0x0, 0x100505e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104>
100505ed0:     	cmp	w8, #0x7d
100505ed4:     	b.eq	0x100505e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104>
100505ed8:     	cmp	x19, #0x41
100505edc:     	b.hs	0x100505f64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1ec>
100505ee0:     	cmp	w20, #0x7b
100505ee4:     	ccmp	x19, #0x7, #0x0, eq
100505ee8:     	b.lo	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100505eec:     	add	x8, x24, x19
100505ef0:     	ldurb	w8, [x8, #-0x1]
100505ef4:     	cmp	w8, #0x7d
100505ef8:     	b.ne	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100505efc:     	ldrb	w8, [x21, #0x15]
100505f00:     	cmp	w8, #0x22
100505f04:     	b.ne	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100505f08:     	sub	x9, x19, #0x1
100505f0c:     	mov	x22, x21
100505f10:     	ldrb	w25, [x22, #0x16]!
100505f14:     	cmp	w25, #0x22
100505f18:     	b.ne	0x100505fa8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x230>
100505f1c:     	mov	w23, #0x0               ; =0
100505f20:     	mov	w28, #0x0               ; =0
100505f24:     	mov	w27, #0x0               ; =0
100505f28:     	mov	w26, #0x0               ; =0
100505f2c:     	mov	x20, #0x0               ; =0
100505f30:     	cmp	w25, #0x22
100505f34:     	b.ne	0x100505fd4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x25c>
100505f38:     	add	x8, sp, #0xa0
100505f3c:     	mov	x0, x22
100505f40:     	mov	x1, x20
100505f44:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100505f48:     	sub	x11, x19, #0x1
100505f4c:     	ldr	w8, [sp, #0xa0]
100505f50:     	tbnz	w8, #0x0, 0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100505f54:     	cmp	w25, #0x22
100505f58:     	b.ne	0x100506078 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x300>
100505f5c:     	mov	x8, #0x0                ; =0
100505f60:     	b	0x1005060ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100505f64:     	adrp	x8, 0x100f7d000 <__MergedGlobals+0xb8>
100505f68:     	add	x8, x8, #0x2d8
100505f6c:     	ldapr	x8, [x8]
100505f70:     	cbnz	x8, 0x100506144 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3cc>
100505f74:     	adrp	x8, 0x100f7d000 <__MergedGlobals+0xb8>
100505f78:     	ldrb	w8, [x8, #0x2e0]
100505f7c:     	adrp	x12, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100505f80:     	adrp	x27, 0x100f7c000 <_perry_global_worker_ts__1>
100505f84:     	cbz	w8, 0x10050615c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3e4>
100505f88:     	cmp	w8, #0x1
100505f8c:     	b.ne	0x100506198 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x420>
100505f90:     	mov	w28, #0x1               ; =1
100505f94:     	mov	w8, #0x1000000          ; =16777216
100505f98:     	mov	w22, #0x1               ; =1
100505f9c:     	cmp	x19, x8
100505fa0:     	b.hi	0x10050619c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x424>
100505fa4:     	b	0x100506280 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x508>
100505fa8:     	cmp	x9, #0x3
100505fac:     	b.eq	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100505fb0:     	ldrb	w8, [x21, #0x17]
100505fb4:     	cmp	w8, #0x22
100505fb8:     	b.ne	0x10050604c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x2d4>
100505fbc:     	mov	w28, #0x0               ; =0
100505fc0:     	mov	w27, #0x0               ; =0
100505fc4:     	mov	w26, #0x0               ; =0
100505fc8:     	mov	w23, #0x1               ; =1
100505fcc:     	mov	w20, #0x1               ; =1
100505fd0:     	b	0x100505f30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100505fd4:     	ldrb	w8, [x22]
100505fd8:     	cmp	w8, #0x20
100505fdc:     	b.lo	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100505fe0:     	cmp	w8, #0x5c
100505fe4:     	b.eq	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100505fe8:     	tbnz	w23, #0x0, 0x100505f38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100505fec:     	ldrb	w8, [x21, #0x17]
100505ff0:     	cmp	w8, #0x20
100505ff4:     	b.lo	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100505ff8:     	cmp	w8, #0x5c
100505ffc:     	b.eq	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506000:     	tbnz	w28, #0x0, 0x100505f38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100506004:     	ldrb	w8, [x21, #0x18]
100506008:     	cmp	w8, #0x20
10050600c:     	b.lo	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506010:     	cmp	w8, #0x5c
100506014:     	b.eq	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506018:     	tbnz	w27, #0x0, 0x100505f38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
10050601c:     	ldrb	w8, [x21, #0x19]
100506020:     	cmp	w8, #0x20
100506024:     	b.lo	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506028:     	cmp	w8, #0x5c
10050602c:     	b.eq	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506030:     	tbnz	w26, #0x0, 0x100505f38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100506034:     	ldrb	w8, [x21, #0x1a]
100506038:     	cmp	w8, #0x20
10050603c:     	b.lo	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506040:     	cmp	w8, #0x5c
100506044:     	b.ne	0x100505f38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100506048:     	b	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
10050604c:     	cmp	x9, #0x4
100506050:     	b.eq	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506054:     	ldrb	w8, [x21, #0x18]
100506058:     	cmp	w8, #0x22
10050605c:     	b.ne	0x100506118 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3a0>
100506060:     	mov	w23, #0x0               ; =0
100506064:     	mov	w27, #0x0               ; =0
100506068:     	mov	w26, #0x0               ; =0
10050606c:     	mov	w28, #0x1               ; =1
100506070:     	mov	w20, #0x2               ; =2
100506074:     	b	0x100505f30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100506078:     	ldrb	w8, [x22]
10050607c:     	tbnz	w23, #0x0, 0x1005060ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100506080:     	ldrb	w9, [x21, #0x17]
100506084:     	orr	x8, x8, x9, lsl #8
100506088:     	tbnz	w28, #0x0, 0x1005060ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
10050608c:     	ldrb	w9, [x21, #0x18]
100506090:     	orr	x8, x8, x9, lsl #16
100506094:     	tbnz	w27, #0x0, 0x1005060ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100506098:     	ldrb	w9, [x21, #0x19]
10050609c:     	orr	x8, x8, x9, lsl #24
1005060a0:     	tbnz	w26, #0x0, 0x1005060ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
1005060a4:     	ldrb	w9, [x21, #0x1a]
1005060a8:     	orr	x8, x8, x9, lsl #32
1005060ac:     	add	x9, x20, #0x3
1005060b0:     	cmp	x9, x19
1005060b4:     	b.hs	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005060b8:     	ldrb	w9, [x24, x9]
1005060bc:     	cmp	w9, #0x3a
1005060c0:     	b.ne	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005060c4:     	add	x10, x20, #0x4
1005060c8:     	subs	x9, x11, x10
1005060cc:     	b.lo	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005060d0:     	b.eq	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005060d4:     	orr	x25, x8, x20, lsl #40
1005060d8:     	mov	x26, #0x7ff9000000000000 ; =9221401712017801216
1005060dc:     	add	x8, x24, x10
1005060e0:     	mov	x10, #0x2600            ; =9728
1005060e4:     	movk	x10, #0x1, lsl #32
1005060e8:     	mov	x11, x9
1005060ec:     	mov	x12, x8
1005060f0:     	b	0x100506100 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x388>
1005060f4:     	add	x12, x12, #0x1
1005060f8:     	subs	x11, x11, #0x1
1005060fc:     	b.eq	0x100506fa4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x122c>
100506100:     	ldrb	w13, [x12]
100506104:     	cmp	w13, #0x20
100506108:     	b.hi	0x1005060f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x37c>
10050610c:     	lsr	x13, x10, x13
100506110:     	tbz	w13, #0x0, 0x1005060f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x37c>
100506114:     	b	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506118:     	cmp	x9, #0x5
10050611c:     	b.eq	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506120:     	ldrb	w8, [x21, #0x19]
100506124:     	cmp	w8, #0x22
100506128:     	b.ne	0x100506ef0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1178>
10050612c:     	mov	w23, #0x0               ; =0
100506130:     	mov	w28, #0x0               ; =0
100506134:     	mov	w26, #0x0               ; =0
100506138:     	mov	w27, #0x1               ; =1
10050613c:     	mov	w20, #0x3               ; =3
100506140:     	b	0x100505f30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100506144:     	bl	0x100b18d04 <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockNtNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api8TapeModeE10initializeNCINvB2_11get_or_initNCNvBV_18tape_mode_from_env0E0zEBZ_>
100506148:     	adrp	x8, 0x100f7d000 <__MergedGlobals+0xb8>
10050614c:     	ldrb	w8, [x8, #0x2e0]
100506150:     	adrp	x12, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100506154:     	adrp	x27, 0x100f7c000 <_perry_global_worker_ts__1>
100506158:     	cbnz	w8, 0x100505f88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x210>
10050615c:     	sub	x8, x19, #0x400
100506160:     	mov	w9, #0xfffc00           ; =16776192
100506164:     	cmp	x8, x9
100506168:     	b.hi	0x100506198 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x420>
10050616c:     	mov	x8, #0x0                ; =0
100506170:     	mov	x9, #0x2600             ; =9728
100506174:     	movk	x9, #0x1, lsl #32
100506178:     	ldrb	w10, [x24, x8]
10050617c:     	cmp	w10, #0x20
100506180:     	b.hi	0x100506678 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x900>
100506184:     	lsr	x11, x9, x10
100506188:     	tbz	w11, #0x0, 0x100506678 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x900>
10050618c:     	add	x8, x8, #0x1
100506190:     	cmp	x19, x8
100506194:     	b.ne	0x100506178 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x400>
100506198:     	mov	w22, #0x0               ; =0
10050619c:     	ldr	w20, [x12, #0x560]
1005061a0:     	cmp	w20, #0x300
1005061a4:     	b.hs	0x100506650 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8d8>
1005061a8:     	ldr	x8, [x27, #0x48]
1005061ac:     	cmn	x8, #0x1
1005061b0:     	b.eq	0x100506640 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8c8>
1005061b4:     	mrs	x9, TPIDRRO_EL0
1005061b8:     	and	x9, x9, #0xfffffffffffffff8
1005061bc:     	ldr	x0, [x9, x8, lsl #3]
1005061c0:     	cbz	x0, 0x100506640 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8c8>
1005061c4:     	add	x8, x0, x20, lsl #3
1005061c8:     	ldr	x0, [x8, #0x1e8]
1005061cc:     	cbz	x0, 0x100506650 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8d8>
1005061d0:     	ldr	x8, [x0]
1005061d4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1005061d8:     	cmp	x8, x9
1005061dc:     	b.hs	0x10050666c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8f4>
1005061e0:     	ldrb	w8, [x0, #0x24]
1005061e4:     	cmp	w8, #0x2
1005061e8:     	b.eq	0x1005061f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x480>
1005061ec:     	ldr	x9, [x0, #0x8]
1005061f0:     	cmp	x9, x21
1005061f4:     	b.eq	0x100506260 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4e8>
1005061f8:     	cmp	x19, #0x3e9
1005061fc:     	b.lo	0x10050627c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100506200:     	mov	x8, #0x0                ; =0
100506204:     	mov	x9, #0x2600             ; =9728
100506208:     	movk	x9, #0x1, lsl #32
10050620c:     	add	x10, x21, x8
100506210:     	ldrb	w10, [x10, #0x14]
100506214:     	cmp	w10, #0x20
100506218:     	b.hi	0x100506234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4bc>
10050621c:     	lsr	x11, x9, x10
100506220:     	tbz	w11, #0x0, 0x100506234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4bc>
100506224:     	add	x8, x8, #0x1
100506228:     	cmp	x19, x8
10050622c:     	b.ne	0x10050620c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x494>
100506230:     	b	0x10050627c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100506234:     	cmp	w10, #0x5b
100506238:     	b.eq	0x100506244 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4cc>
10050623c:     	cmp	w10, #0x7b
100506240:     	b.ne	0x10050627c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100506244:     	add	x0, x21, #0x14
100506248:     	mov	x1, x19
10050624c:     	mov	w2, #0x3e8              ; =1000
100506250:     	bl	0x1006c4c94 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser12depth_blocks21nesting_depth_exceeds>
100506254:     	cbz	w0, 0x10050627c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100506258:     	mov	x0, x21
10050625c:     	b	0x100506eb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1138>
100506260:     	ldr	w9, [x0, #0x18]
100506264:     	cmp	x19, x9
100506268:     	cset	w9, eq
10050626c:     	and	w8, w9, w8
100506270:     	cmp	x19, #0x3e9
100506274:     	csinc	w8, w8, wzr, hs
100506278:     	tbz	w8, #0x0, 0x100506200 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x488>
10050627c:     	mov	w28, #0x0               ; =0
100506280:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100506284:     	add	x0, x0, #0xce8
100506288:     	ldr	x8, [x0]
10050628c:     	blr	x8
100506290:     	mov	x20, x0
100506294:     	ldrb	w8, [x0, #0x20]
100506298:     	cbnz	w8, 0x100506e08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1090>
10050629c:     	ldr	x8, [x20]
1005062a0:     	cbnz	x8, 0x100506e84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
1005062a4:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
1005062a8:     	bfxil	x23, x21, #0, #48
1005062ac:     	mov	x8, #-0x1               ; =-1
1005062b0:     	str	x8, [x20]
1005062b4:     	ldr	x21, [x20, #0x18]
1005062b8:     	ldr	x8, [x20, #0x8]
1005062bc:     	cmp	x21, x8
1005062c0:     	b.eq	0x100506604 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x88c>
1005062c4:     	ldr	x8, [x20, #0x10]
1005062c8:     	str	x23, [x8, x21, lsl #3]
1005062cc:     	add	x8, x21, #0x1
1005062d0:     	str	x8, [x20, #0x18]
1005062d4:     	ldr	x8, [x20]
1005062d8:     	add	x8, x8, #0x1
1005062dc:     	str	x8, [x20]
1005062e0:     	adrp	x24, 0x100f7c000 <_perry_global_worker_ts__1>
1005062e4:     	ldr	w23, [x24, #0x948]
1005062e8:     	cmp	w23, #0x300
1005062ec:     	b.hs	0x100506620 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8a8>
1005062f0:     	ldr	x8, [x27, #0x48]
1005062f4:     	cmn	x8, #0x1
1005062f8:     	b.eq	0x100506610 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x898>
1005062fc:     	mrs	x9, TPIDRRO_EL0
100506300:     	and	x9, x9, #0xfffffffffffffff8
100506304:     	ldr	x0, [x9, x8, lsl #3]
100506308:     	cbz	x0, 0x100506610 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x898>
10050630c:     	add	x8, x0, x23, lsl #3
100506310:     	ldr	x0, [x8, #0x1e8]
100506314:     	cbz	x0, 0x100506620 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8a8>
100506318:     	ldrb	w8, [x0]
10050631c:     	cbnz	w8, 0x100506634 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8bc>
100506320:     	tbz	w22, #0x0, 0x1005069a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100506324:     	ldrb	w8, [x20, #0x20]
100506328:     	cbnz	w8, 0x100506ec0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1148>
10050632c:     	ldr	x8, [x20]
100506330:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100506334:     	cmp	x8, x9
100506338:     	b.hs	0x100507004 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
10050633c:     	add	x9, x8, #0x1
100506340:     	str	x9, [x20]
100506344:     	ldr	x9, [x20, #0x18]
100506348:     	cmp	x21, x9
10050634c:     	b.hs	0x100506360 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5e8>
100506350:     	ldr	x9, [x20, #0x10]
100506354:     	ldr	x9, [x9, x21, lsl #3]
100506358:     	and	x23, x9, #0xffffffffffff
10050635c:     	b	0x100506364 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5ec>
100506360:     	mov	w23, #0x1               ; =1
100506364:     	str	x8, [x20]
100506368:     	adrp	x0, 0x100f84000 <__RNvNCNKNvNtCs3gRpqoBkMHm_13perry_runtime7process29PROCESS_FINALIZATION_EXIT_RAN0s_023___RUST_STD_INTERNAL_VAL>
10050636c:     	add	x0, x0, #0x168
100506370:     	ldr	x8, [x0]
100506374:     	blr	x8
100506378:     	mov	x22, x0
10050637c:     	ldrb	w8, [x0, #0x30]
100506380:     	cmp	w8, #0x1
100506384:     	b.ne	0x100506e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1118>
100506388:     	ldr	x8, [x22]
10050638c:     	mov	x10, #-0x1              ; =-1
100506390:     	mov	x9, x22
100506394:     	str	x10, [x9], #0x8
100506398:     	cmn	x8, #0x1
10050639c:     	b.eq	0x1005063bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x644>
1005063a0:     	add	x10, sp, #0xa0
1005063a4:     	ldp	q0, q1, [x9]
1005063a8:     	ldr	x9, [x9, #0x20]
1005063ac:     	stur	x9, [x10, #0x28]
1005063b0:     	stur	q1, [x10, #0x18]
1005063b4:     	stur	q0, [x10, #0x8]
1005063b8:     	b	0x1005063d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x658>
1005063bc:     	mov	x8, #0x0                ; =0
1005063c0:     	mov	w9, #0x4                ; =4
1005063c4:     	stp	x9, xzr, [sp, #0xa8]
1005063c8:     	stp	xzr, x9, [sp, #0xb8]
1005063cc:     	str	xzr, [sp, #0xc8]
1005063d0:     	str	x8, [sp, #0xa0]
1005063d4:     	stur	xzr, [x29, #-0x78]
1005063d8:     	add	x8, sp, #0xa0
1005063dc:     	add	x0, x23, #0x14
1005063e0:     	add	x2, sp, #0xa0
1005063e4:     	add	x3, x8, #0x18
1005063e8:     	sub	x4, x29, #0x78
1005063ec:     	mov	x1, x19
1005063f0:     	bl	0x100150be4 <__RINvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15build_tape_intoKb1_EB4_>
1005063f4:     	tbz	w0, #0x0, 0x100506504 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x78c>
1005063f8:     	ldur	x23, [x29, #-0x78]
1005063fc:     	ldr	w24, [x24, #0x948]
100506400:     	cmp	w24, #0x300
100506404:     	b.hs	0x100506d1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfa4>
100506408:     	ldr	x8, [x27, #0x48]
10050640c:     	cmn	x8, #0x1
100506410:     	b.eq	0x100506d0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf94>
100506414:     	mrs	x9, TPIDRRO_EL0
100506418:     	and	x9, x9, #0xfffffffffffffff8
10050641c:     	ldr	x0, [x9, x8, lsl #3]
100506420:     	cbz	x0, 0x100506d0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf94>
100506424:     	add	x8, x0, x24, lsl #3
100506428:     	ldr	x0, [x8, #0x1e8]
10050642c:     	cbz	x0, 0x100506d1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfa4>
100506430:     	ldrb	w8, [x0]
100506434:     	cbnz	w8, 0x100506d30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfb8>
100506438:     	bl	0x1004eff00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
10050643c:     	bl	0x100459dc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy16gc_check_trigger>
100506440:     	mov	x0, x19
100506444:     	bl	0x100231eac <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation5begin>
100506448:     	mov	x24, x0
10050644c:     	mov	x25, x1
100506450:     	bl	0x100459bd4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy11gc_suppress>
100506454:     	ldrb	w8, [x20, #0x20]
100506458:     	cbnz	w8, 0x100506f4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11d4>
10050645c:     	ldr	x8, [x20]
100506460:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100506464:     	cmp	x8, x9
100506468:     	b.hs	0x100507004 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
10050646c:     	add	x9, x8, #0x1
100506470:     	str	x9, [x20]
100506474:     	ldr	x9, [x20, #0x18]
100506478:     	cmp	x21, x9
10050647c:     	b.hs	0x10050659c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x824>
100506480:     	ldr	x9, [x20, #0x10]
100506484:     	ldr	x9, [x9, x21, lsl #3]
100506488:     	and	x2, x9, #0xffffffffffff
10050648c:     	stp	x25, x24, [sp]
100506490:     	str	x8, [x20]
100506494:     	add	x26, x2, #0x14
100506498:     	cmp	x23, #0x3e8
10050649c:     	b.hi	0x1005065b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x83c>
1005064a0:     	ldp	x24, x25, [sp, #0xa8]
1005064a4:     	cbz	x25, 0x1005065d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x858>
1005064a8:     	ldrb	w8, [x24, #0x8]
1005064ac:     	cmp	w8, #0x3
1005064b0:     	b.ne	0x1005065d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x858>
1005064b4:     	ldr	w8, [x24, #0x4]
1005064b8:     	cmp	w8, #0x2
1005064bc:     	b.lo	0x1005066a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x928>
1005064c0:     	mov	w1, #0x0                ; =0
1005064c4:     	mov	w0, #0x1                ; =1
1005064c8:     	mov	w9, #0xc                ; =12
1005064cc:     	b	0x1005064e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x768>
1005064d0:     	add	x0, x0, #0x1
1005064d4:     	add	w1, w1, #0x1
1005064d8:     	cmp	x0, x8
1005064dc:     	b.hs	0x1005066a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x92c>
1005064e0:     	cmp	x0, x25
1005064e4:     	b.hs	0x100507100 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1388>
1005064e8:     	madd	x10, x0, x9, x24
1005064ec:     	ldrb	w11, [x10, #0x8]
1005064f0:     	orr	w11, w11, #0x2
1005064f4:     	cmp	w11, #0x3
1005064f8:     	b.ne	0x1005064d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x758>
1005064fc:     	ldr	w0, [x10, #0x4]
100506500:     	b	0x1005064d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x758>
100506504:     	str	xzr, [sp, #0xb0]
100506508:     	str	xzr, [sp, #0xc8]
10050650c:     	ldr	x8, [sp, #0xa0]
100506510:     	add	x9, x8, x8, lsl #1
100506514:     	lsl	x9, x9, #2
100506518:     	cmp	x9, #0x100, lsl #12     ; =0x100000
10050651c:     	b.ls	0x100506538 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7c0>
100506520:     	cbz	x8, 0x10050652c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7b4>
100506524:     	ldr	x0, [sp, #0xa8]
100506528:     	bl	0x100b5eec0 <_mi_free>
10050652c:     	mov	w8, #0x4                ; =4
100506530:     	stp	xzr, x8, [sp, #0xa0]
100506534:     	str	xzr, [sp, #0xb0]
100506538:     	ldr	x8, [sp, #0xb8]
10050653c:     	lsl	x9, x8, #2
100506540:     	cmp	x9, #0x10, lsl #12      ; =0x10000
100506544:     	b.ls	0x100506560 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7e8>
100506548:     	cbz	x8, 0x100506554 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7dc>
10050654c:     	ldr	x0, [sp, #0xc0]
100506550:     	bl	0x100b5eec0 <_mi_free>
100506554:     	mov	w8, #0x4                ; =4
100506558:     	stp	xzr, x8, [sp, #0xb8]
10050655c:     	str	xzr, [sp, #0xc8]
100506560:     	ldp	x8, x0, [x22]
100506564:     	ldp	x24, x23, [x22, #0x18]
100506568:     	ldp	q1, q0, [sp, #0xb0]
10050656c:     	ldr	q2, [sp, #0xa0]
100506570:     	stp	q2, q1, [x22]
100506574:     	str	q0, [x22, #0x20]
100506578:     	cmn	x8, #0x1
10050657c:     	b.eq	0x100506594 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x81c>
100506580:     	cbz	x8, 0x100506588 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x810>
100506584:     	bl	0x100b5eec0 <_mi_free>
100506588:     	cbz	x24, 0x100506594 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x81c>
10050658c:     	mov	x0, x23
100506590:     	bl	0x100b5eec0 <_mi_free>
100506594:     	ldrb	w8, [x20, #0x20]
100506598:     	b	0x1005068cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb54>
10050659c:     	mov	w2, #0x1                ; =1
1005065a0:     	stp	x25, x24, [sp]
1005065a4:     	str	x8, [x20]
1005065a8:     	add	x26, x2, #0x14
1005065ac:     	cmp	x23, #0x3e8
1005065b0:     	b.ls	0x1005064a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x728>
1005065b4:     	ldp	x0, x1, [sp, #0xa8]
1005065b8:     	mov	x2, x26
1005065bc:     	mov	x3, x19
1005065c0:     	bl	0x100688754 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape9iterative21materialize_iterative>
1005065c4:     	tbz	w0, #0x0, 0x1005065fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x884>
1005065c8:     	mov	x25, x1
1005065cc:     	b	0x1005066f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x97c>
1005065d0:     	bl	0x10028b418 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
1005065d4:     	stp	x0, xzr, [x29, #-0x70]
1005065d8:     	stp	x24, x25, [sp, #0x10]
1005065dc:     	stp	x26, x19, [sp, #0x20]
1005065e0:     	add	x0, sp, #0x10
1005065e4:     	sub	x1, x29, #0x68
1005065e8:     	bl	0x100377de0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24materialize_value_source>
1005065ec:     	mov	x25, x0
1005065f0:     	sub	x0, x29, #0x70
1005065f4:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
1005065f8:     	b	0x1005066f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x97c>
1005065fc:     	mov	w25, #0x0               ; =0
100506600:     	b	0x10050673c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9c4>
100506604:     	add	x0, x20, #0x8
100506608:     	bl	0x100b3bbec <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10050660c:     	b	0x1005062c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x54c>
100506610:     	bl	0x100b3f2fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100506614:     	add	x8, x0, x23, lsl #3
100506618:     	ldr	x0, [x8, #0x1e8]
10050661c:     	cbnz	x0, 0x100506318 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5a0>
100506620:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
100506624:     	add	x0, x0, #0xca8
100506628:     	bl	0x100b3cb68 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
10050662c:     	ldrb	w8, [x0]
100506630:     	cbz	w8, 0x100506320 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5a8>
100506634:     	bl	0x100b4429c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
100506638:     	tbnz	w22, #0x0, 0x100506324 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5ac>
10050663c:     	b	0x1005069a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100506640:     	bl	0x100b3f2fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100506644:     	add	x8, x0, x20, lsl #3
100506648:     	ldr	x0, [x8, #0x1e8]
10050664c:     	cbnz	x0, 0x1005061d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x458>
100506650:     	adrp	x0, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
100506654:     	add	x0, x0, #0xfa0
100506658:     	bl	0x100b3cb1c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10050665c:     	ldr	x8, [x0]
100506660:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100506664:     	cmp	x8, x9
100506668:     	b.lo	0x1005061e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x468>
10050666c:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100506670:     	add	x0, x0, #0xd10
100506674:     	bl	0x100b1265c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100506678:     	cmp	w10, #0x5b
10050667c:     	cset	w22, eq
100506680:     	mov	w8, #0x1000000          ; =16777216
100506684:     	cmp	x19, x8
100506688:     	mov	w8, #0x5b               ; =91
10050668c:     	ccmp	w10, w8, #0x0, ls
100506690:     	b.ne	0x10050619c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x424>
100506694:     	mov	w28, #0x1               ; =1
100506698:     	mov	w22, #0x1               ; =1
10050669c:     	b	0x100506280 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x508>
1005066a0:     	mov	w1, #0x0                ; =0
1005066a4:     	ldr	x8, [sp, #0xa0]
1005066a8:     	add	x8, x8, x8, lsl #1
1005066ac:     	lsl	x8, x8, #2
1005066b0:     	cmp	x8, #0x100, lsl #12     ; =0x100000
1005066b4:     	b.ls	0x1005066d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x960>
1005066b8:     	ldr	q0, [sp, #0xa0]
1005066bc:     	str	q0, [sp, #0x10]
1005066c0:     	ldr	x8, [sp, #0xb0]
1005066c4:     	str	x8, [sp, #0x20]
1005066c8:     	mov	w8, #0x4                ; =4
1005066cc:     	stp	xzr, x8, [sp, #0xa0]
1005066d0:     	str	xzr, [sp, #0xb0]
1005066d4:     	b	0x1005066e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x96c>
1005066d8:     	stp	x24, x25, [sp, #0x18]
1005066dc:     	mov	x8, #-0x1               ; =-1
1005066e0:     	str	x8, [sp, #0x10]
1005066e4:     	add	x0, sp, #0x10
1005066e8:     	bl	0x100376f30 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24alloc_lazy_array_backing>
1005066ec:     	mov	x25, #0x7ffd000000000000 ; =9222527611924643840
1005066f0:     	bfxil	x25, x0, #0, #48
1005066f4:     	ldrb	w8, [x20, #0x20]
1005066f8:     	cbnz	w8, 0x100506f7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1204>
1005066fc:     	ldr	x8, [x20]
100506700:     	cbnz	x8, 0x100506e84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
100506704:     	mov	x8, #-0x1               ; =-1
100506708:     	str	x8, [x20]
10050670c:     	ldr	x26, [x20, #0x18]
100506710:     	ldr	x8, [x20, #0x8]
100506714:     	cmp	x26, x8
100506718:     	b.eq	0x100506dac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1034>
10050671c:     	ldr	x8, [x20, #0x10]
100506720:     	str	x25, [x8, x26, lsl #3]
100506724:     	add	x8, x26, #0x1
100506728:     	str	x8, [x20, #0x18]
10050672c:     	ldr	x8, [x20]
100506730:     	add	x8, x8, #0x1
100506734:     	str	x8, [x20]
100506738:     	mov	w25, #0x1               ; =1
10050673c:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100506740:     	ldr	w24, [x8, #0x308]
100506744:     	cmp	w24, #0x300
100506748:     	b.hs	0x100506d48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfd0>
10050674c:     	ldr	x8, [x27, #0x48]
100506750:     	cmn	x8, #0x1
100506754:     	b.eq	0x100506d38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfc0>
100506758:     	mrs	x9, TPIDRRO_EL0
10050675c:     	and	x9, x9, #0xfffffffffffffff8
100506760:     	ldr	x0, [x9, x8, lsl #3]
100506764:     	cbz	x0, 0x100506d38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfc0>
100506768:     	add	x8, x0, x24, lsl #3
10050676c:     	ldr	x0, [x8, #0x1e8]
100506770:     	cbz	x0, 0x100506d48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfd0>
100506774:     	ldrb	w8, [x0]
100506778:     	and	w8, w8, #0xfffffffd
10050677c:     	strb	w8, [x0]
100506780:     	mov	w0, #0x0                ; =0
100506784:     	bl	0x10045d500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy28gc_bump_malloc_trigger_inner>
100506788:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
10050678c:     	ldr	w24, [x8, #0x590]
100506790:     	cmp	w24, #0x300
100506794:     	b.hs	0x100506d68 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xff0>
100506798:     	ldr	x8, [x27, #0x48]
10050679c:     	cmn	x8, #0x1
1005067a0:     	b.eq	0x100506d58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfe0>
1005067a4:     	mrs	x9, TPIDRRO_EL0
1005067a8:     	and	x9, x9, #0xfffffffffffffff8
1005067ac:     	ldr	x0, [x9, x8, lsl #3]
1005067b0:     	cbz	x0, 0x100506d58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfe0>
1005067b4:     	add	x8, x0, x24, lsl #3
1005067b8:     	ldr	x0, [x8, #0x1e8]
1005067bc:     	cbz	x0, 0x100506d68 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xff0>
1005067c0:     	ldr	x8, [x0]
1005067c4:     	lsr	x8, x8, #25
1005067c8:     	cbz	x8, 0x100506d80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1008>
1005067cc:     	bl	0x10045f2b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
1005067d0:     	cmp	x23, #0x3e8
1005067d4:     	b.hi	0x100506d88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1010>
1005067d8:     	ldp	x1, x0, [sp]
1005067dc:     	bl	0x100231ff8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
1005067e0:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1005067e4:     	ldr	x8, [x8, #0x7f8]
1005067e8:     	cbnz	x8, 0x100506da0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1028>
1005067ec:     	tbz	w25, #0x0, 0x100506834 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xabc>
1005067f0:     	ldrb	w8, [x20, #0x20]
1005067f4:     	cbnz	w8, 0x100506fd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1260>
1005067f8:     	ldr	x8, [x20]
1005067fc:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100506800:     	cmp	x8, x9
100506804:     	b.hs	0x100507004 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100506808:     	add	x9, x8, #0x1
10050680c:     	str	x9, [x20]
100506810:     	ldr	x9, [x20, #0x18]
100506814:     	cmp	x26, x9
100506818:     	b.hs	0x100506828 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xab0>
10050681c:     	ldr	x9, [x20, #0x10]
100506820:     	ldr	x23, [x9, x26, lsl #3]
100506824:     	b	0x100506830 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xab8>
100506828:     	mov	x23, #0x1               ; =1
10050682c:     	movk	x23, #0x7ffc, lsl #48
100506830:     	str	x8, [x20]
100506834:     	str	xzr, [sp, #0xb0]
100506838:     	str	xzr, [sp, #0xc8]
10050683c:     	ldr	x8, [sp, #0xa0]
100506840:     	add	x9, x8, x8, lsl #1
100506844:     	lsl	x9, x9, #2
100506848:     	cmp	x9, #0x100, lsl #12     ; =0x100000
10050684c:     	b.ls	0x100506868 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xaf0>
100506850:     	cbz	x8, 0x10050685c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xae4>
100506854:     	ldr	x0, [sp, #0xa8]
100506858:     	bl	0x100b5eec0 <_mi_free>
10050685c:     	mov	w8, #0x4                ; =4
100506860:     	stp	xzr, x8, [sp, #0xa0]
100506864:     	str	xzr, [sp, #0xb0]
100506868:     	ldr	x8, [sp, #0xb8]
10050686c:     	lsl	x9, x8, #2
100506870:     	cmp	x9, #0x10, lsl #12      ; =0x10000
100506874:     	b.ls	0x100506890 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb18>
100506878:     	cbz	x8, 0x100506884 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb0c>
10050687c:     	ldr	x0, [sp, #0xc0]
100506880:     	bl	0x100b5eec0 <_mi_free>
100506884:     	mov	w8, #0x4                ; =4
100506888:     	stp	xzr, x8, [sp, #0xb8]
10050688c:     	str	xzr, [sp, #0xc8]
100506890:     	ldp	x8, x0, [x22]
100506894:     	ldp	x26, x24, [x22, #0x18]
100506898:     	ldp	q1, q0, [sp, #0xb0]
10050689c:     	ldr	q2, [sp, #0xa0]
1005068a0:     	stp	q2, q1, [x22]
1005068a4:     	str	q0, [x22, #0x20]
1005068a8:     	cmn	x8, #0x1
1005068ac:     	b.eq	0x10050695c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbe4>
1005068b0:     	cbz	x8, 0x1005068b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb40>
1005068b4:     	bl	0x100b5eec0 <_mi_free>
1005068b8:     	cbz	x26, 0x10050695c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbe4>
1005068bc:     	mov	x0, x24
1005068c0:     	bl	0x100b5eec0 <_mi_free>
1005068c4:     	ldrb	w8, [x20, #0x20]
1005068c8:     	tbnz	w25, #0x0, 0x100506964 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbec>
1005068cc:     	cbnz	w8, 0x100506f1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11a4>
1005068d0:     	ldr	x8, [x20]
1005068d4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1005068d8:     	cmp	x8, x9
1005068dc:     	b.hs	0x100507004 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
1005068e0:     	add	x9, x8, #0x1
1005068e4:     	str	x9, [x20]
1005068e8:     	ldr	x9, [x20, #0x18]
1005068ec:     	cmp	x21, x9
1005068f0:     	b.hs	0x100506914 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb9c>
1005068f4:     	ldr	x9, [x20, #0x10]
1005068f8:     	ldr	x9, [x9, x21, lsl #3]
1005068fc:     	and	x22, x9, #0xffffffffffff
100506900:     	str	x8, [x20]
100506904:     	cmp	x19, #0x3e8
100506908:     	csel	w8, wzr, w28, ls
10050690c:     	cbnz	w8, 0x100506928 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbb0>
100506910:     	b	0x1005069a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100506914:     	mov	w22, #0x1               ; =1
100506918:     	str	x8, [x20]
10050691c:     	cmp	x19, #0x3e8
100506920:     	csel	w8, wzr, w28, ls
100506924:     	cbz	w8, 0x1005069a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100506928:     	mov	x8, #0x0                ; =0
10050692c:     	mov	x9, #0x2600             ; =9728
100506930:     	movk	x9, #0x1, lsl #32
100506934:     	add	x10, x22, x8
100506938:     	ldrb	w10, [x10, #0x14]
10050693c:     	cmp	w10, #0x20
100506940:     	b.hi	0x100506984 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc0c>
100506944:     	lsr	x11, x9, x10
100506948:     	tbz	w11, #0x0, 0x100506984 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc0c>
10050694c:     	add	x8, x8, #0x1
100506950:     	cmp	x19, x8
100506954:     	b.ne	0x100506934 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbbc>
100506958:     	b	0x1005069a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
10050695c:     	ldrb	w8, [x20, #0x20]
100506960:     	cbz	w25, 0x1005068cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb54>
100506964:     	cbnz	w8, 0x100507010 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1298>
100506968:     	ldr	x8, [x20]
10050696c:     	cbnz	x8, 0x1005070b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x133c>
100506970:     	ldr	x8, [x20, #0x18]
100506974:     	cmp	x21, x8
100506978:     	b.hi	0x100505db0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
10050697c:     	str	x21, [x20, #0x18]
100506980:     	b	0x100505db0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100506984:     	cmp	w10, #0x5b
100506988:     	b.eq	0x100506994 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc1c>
10050698c:     	cmp	w10, #0x7b
100506990:     	b.ne	0x1005069a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100506994:     	add	x0, x22, #0x14
100506998:     	mov	x1, x19
10050699c:     	mov	w2, #0x3e8              ; =1000
1005069a0:     	bl	0x1006c4c94 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser12depth_blocks21nesting_depth_exceeds>
1005069a4:     	cbnz	w0, 0x100506ea4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x112c>
1005069a8:     	bl	0x1004eff00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
1005069ac:     	bl	0x100459dc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy16gc_check_trigger>
1005069b0:     	mov	x0, x19
1005069b4:     	bl	0x100231eac <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation5begin>
1005069b8:     	mov	x24, x0
1005069bc:     	mov	x22, x1
1005069c0:     	bl	0x100459bd4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy11gc_suppress>
1005069c4:     	ldrb	w8, [x20, #0x20]
1005069c8:     	cbnz	w8, 0x100506e30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10b8>
1005069cc:     	ldr	x8, [x20]
1005069d0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1005069d4:     	cmp	x8, x9
1005069d8:     	b.hs	0x100507004 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
1005069dc:     	add	x9, x8, #0x1
1005069e0:     	str	x9, [x20]
1005069e4:     	ldr	x9, [x20, #0x18]
1005069e8:     	cmp	x21, x9
1005069ec:     	b.hs	0x100506a04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc8c>
1005069f0:     	ldr	x9, [x20, #0x10]
1005069f4:     	ldr	x9, [x9, x21, lsl #3]
1005069f8:     	and	x25, x9, #0xffffffffffff
1005069fc:     	add	x1, x25, #0x14
100506a00:     	b	0x100506a0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc94>
100506a04:     	mov	w25, #0x1               ; =1
100506a08:     	mov	w1, #0x15               ; =21
100506a0c:     	str	x8, [x20]
100506a10:     	add	x0, sp, #0xa0
100506a14:     	mov	x2, x19
100506a18:     	mov	x3, x25
100506a1c:     	bl	0x10024778c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23new_batched_from_string>
100506a20:     	add	x0, sp, #0xa0
100506a24:     	bl	0x1002448c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value>
100506a28:     	mov	x23, x0
100506a2c:     	ldp	x26, x28, [sp, #0x108]
100506a30:     	cmp	x28, x26
100506a34:     	b.hs	0x100506a68 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcf0>
100506a38:     	ldr	x8, [sp, #0x100]
100506a3c:     	mov	x9, #0x2600             ; =9728
100506a40:     	movk	x9, #0x1, lsl #32
100506a44:     	ldrb	w10, [x8, x28]
100506a48:     	cmp	w10, #0x20
100506a4c:     	b.hi	0x100506a68 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcf0>
100506a50:     	lsr	x10, x9, x10
100506a54:     	tbz	w10, #0x0, 0x100506a68 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcf0>
100506a58:     	add	x28, x28, #0x1
100506a5c:     	cmp	x26, x28
100506a60:     	b.ne	0x100506a44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xccc>
100506a64:     	mov	x28, x26
100506a68:     	ldrb	w8, [sp, #0x176]
100506a6c:     	tbnz	w8, #0x0, 0x100506db8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1040>
100506a70:     	cmp	x28, x26
100506a74:     	b.ne	0x100506dc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104c>
100506a78:     	ldrb	w8, [sp, #0x174]
100506a7c:     	tbz	w8, #0x0, 0x100506dc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104c>
100506a80:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100506a84:     	ldr	w26, [x8, #0x560]
100506a88:     	cmp	w26, #0x300
100506a8c:     	b.hs	0x100506c24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xeac>
100506a90:     	ldr	x8, [x27, #0x48]
100506a94:     	cmn	x8, #0x1
100506a98:     	b.eq	0x100506c14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe9c>
100506a9c:     	mrs	x9, TPIDRRO_EL0
100506aa0:     	and	x9, x9, #0xfffffffffffffff8
100506aa4:     	ldr	x0, [x9, x8, lsl #3]
100506aa8:     	cbz	x0, 0x100506c14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe9c>
100506aac:     	add	x8, x0, x26, lsl #3
100506ab0:     	ldr	x0, [x8, #0x1e8]
100506ab4:     	cbz	x0, 0x100506c24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xeac>
100506ab8:     	ldr	x8, [x0]
100506abc:     	cbnz	x8, 0x100506c38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xec0>
100506ac0:     	ldrb	w8, [x0, #0x24]
100506ac4:     	cmp	w8, #0x2
100506ac8:     	b.eq	0x100506aec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd74>
100506acc:     	ldr	x8, [x0, #0x8]
100506ad0:     	cmp	x8, x25
100506ad4:     	b.ne	0x100506aec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd74>
100506ad8:     	ldr	w8, [x0, #0x18]
100506adc:     	cmp	x19, x8
100506ae0:     	b.ne	0x100506aec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd74>
100506ae4:     	mov	w8, #0x1                ; =1
100506ae8:     	strb	w8, [x0, #0x24]
100506aec:     	mov	x0, x25
100506af0:     	mov	x1, x19
100506af4:     	mov	x2, x23
100506af8:     	bl	0x1004ed040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template>
100506afc:     	ldrb	w8, [x20, #0x20]
100506b00:     	cbnz	w8, 0x100506e60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10e8>
100506b04:     	ldr	x8, [x20]
100506b08:     	cbnz	x8, 0x100506e84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
100506b0c:     	mov	x8, #-0x1               ; =-1
100506b10:     	str	x8, [x20]
100506b14:     	ldr	x19, [x20, #0x18]
100506b18:     	ldr	x8, [x20, #0x8]
100506b1c:     	cmp	x19, x8
100506b20:     	b.eq	0x100506c44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xecc>
100506b24:     	ldr	x8, [x20, #0x10]
100506b28:     	str	x23, [x8, x19, lsl #3]
100506b2c:     	add	x8, x19, #0x1
100506b30:     	str	x8, [x20, #0x18]
100506b34:     	ldr	x8, [x20]
100506b38:     	add	x8, x8, #0x1
100506b3c:     	str	x8, [x20]
100506b40:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100506b44:     	ldr	w19, [x8, #0x308]
100506b48:     	cmp	w19, #0x300
100506b4c:     	b.hs	0x100506c60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xee8>
100506b50:     	ldr	x8, [x27, #0x48]
100506b54:     	cmn	x8, #0x1
100506b58:     	b.eq	0x100506c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xed8>
100506b5c:     	mrs	x9, TPIDRRO_EL0
100506b60:     	and	x9, x9, #0xfffffffffffffff8
100506b64:     	ldr	x0, [x9, x8, lsl #3]
100506b68:     	cbz	x0, 0x100506c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xed8>
100506b6c:     	add	x8, x0, x19, lsl #3
100506b70:     	ldr	x0, [x8, #0x1e8]
100506b74:     	cbz	x0, 0x100506c60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xee8>
100506b78:     	ldrb	w8, [x0]
100506b7c:     	and	w8, w8, #0xfffffffd
100506b80:     	strb	w8, [x0]
100506b84:     	mov	w0, #0x0                ; =0
100506b88:     	bl	0x10045d500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy28gc_bump_malloc_trigger_inner>
100506b8c:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100506b90:     	ldr	w19, [x8, #0x590]
100506b94:     	cmp	w19, #0x300
100506b98:     	b.hs	0x100506c80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf08>
100506b9c:     	ldr	x8, [x27, #0x48]
100506ba0:     	cmn	x8, #0x1
100506ba4:     	b.eq	0x100506c70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xef8>
100506ba8:     	mrs	x9, TPIDRRO_EL0
100506bac:     	and	x9, x9, #0xfffffffffffffff8
100506bb0:     	ldr	x0, [x9, x8, lsl #3]
100506bb4:     	cbz	x0, 0x100506c70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xef8>
100506bb8:     	add	x8, x0, x19, lsl #3
100506bbc:     	ldr	x0, [x8, #0x1e8]
100506bc0:     	cbz	x0, 0x100506c80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf08>
100506bc4:     	ldr	x8, [x0]
100506bc8:     	lsr	x8, x8, #25
100506bcc:     	cbz	x8, 0x100506c98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf20>
100506bd0:     	bl	0x10045f2b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100506bd4:     	bl	0x1004615e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100506bd8:     	mov	x0, x24
100506bdc:     	mov	x1, x22
100506be0:     	bl	0x100231ff8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100506be4:     	ldrb	w8, [x20, #0x20]
100506be8:     	cbz	w8, 0x100506cb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf38>
100506bec:     	cmp	w8, #0x2
100506bf0:     	b.eq	0x100507018 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100506bf4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100506bf8:     	add	x1, x1, #0x998
100506bfc:     	mov	x0, x20
100506c00:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100506c04:     	strb	wzr, [x20, #0x20]
100506c08:     	ldr	x8, [x20]
100506c0c:     	cbz	x8, 0x100506cb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf40>
100506c10:     	b	0x1005070b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x133c>
100506c14:     	bl	0x100b3f2fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100506c18:     	add	x8, x0, x26, lsl #3
100506c1c:     	ldr	x0, [x8, #0x1e8]
100506c20:     	cbnz	x0, 0x100506ab8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd40>
100506c24:     	adrp	x0, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
100506c28:     	add	x0, x0, #0xfa0
100506c2c:     	bl	0x100b3cb1c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100506c30:     	ldr	x8, [x0]
100506c34:     	cbz	x8, 0x100506ac0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd48>
100506c38:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100506c3c:     	add	x0, x0, #0xcf8
100506c40:     	bl	0x100b1262c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100506c44:     	add	x0, x20, #0x8
100506c48:     	bl	0x100b3bbec <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100506c4c:     	b	0x100506b24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xdac>
100506c50:     	bl	0x100b3f2fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100506c54:     	add	x8, x0, x19, lsl #3
100506c58:     	ldr	x0, [x8, #0x1e8]
100506c5c:     	cbnz	x0, 0x100506b78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe00>
100506c60:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
100506c64:     	add	x0, x0, #0xcd8
100506c68:     	bl	0x100b3cb68 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
100506c6c:     	b	0x100506b78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe00>
100506c70:     	bl	0x100b3f2fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100506c74:     	add	x8, x0, x19, lsl #3
100506c78:     	ldr	x0, [x8, #0x1e8]
100506c7c:     	cbnz	x0, 0x100506bc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe4c>
100506c80:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100506c84:     	add	x0, x0, #0x78
100506c88:     	bl	0x100b3cb1c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100506c8c:     	ldr	x8, [x0]
100506c90:     	lsr	x8, x8, #25
100506c94:     	cbnz	x8, 0x100506bd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe58>
100506c98:     	bl	0x1004615e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100506c9c:     	mov	x0, x24
100506ca0:     	mov	x1, x22
100506ca4:     	bl	0x100231ff8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100506ca8:     	ldrb	w8, [x20, #0x20]
100506cac:     	cbnz	w8, 0x100506bec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe74>
100506cb0:     	ldr	x8, [x20]
100506cb4:     	cbnz	x8, 0x1005070b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x133c>
100506cb8:     	ldr	x8, [x20, #0x18]
100506cbc:     	cmp	x21, x8
100506cc0:     	b.ls	0x100506ce8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf70>
100506cc4:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100506cc8:     	ldr	x8, [x8, #0x7f8]
100506ccc:     	cbnz	x8, 0x100506cf8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf80>
100506cd0:     	ldr	x8, [sp, #0xd8]
100506cd4:     	cmp	x8, #0x1
100506cd8:     	b.lt	0x100505db0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100506cdc:     	ldr	x0, [sp, #0xe0]
100506ce0:     	bl	0x100b5eec0 <_mi_free>
100506ce4:     	b	0x100505db0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100506ce8:     	str	x21, [x20, #0x18]
100506cec:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100506cf0:     	ldr	x8, [x8, #0x7f8]
100506cf4:     	cbz	x8, 0x100506cd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf58>
100506cf8:     	bl	0x100b459f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
100506cfc:     	ldr	x8, [sp, #0xd8]
100506d00:     	cmp	x8, #0x1
100506d04:     	b.ge	0x100506cdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf64>
100506d08:     	b	0x100505db0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100506d0c:     	bl	0x100b3f2fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100506d10:     	add	x8, x0, x24, lsl #3
100506d14:     	ldr	x0, [x8, #0x1e8]
100506d18:     	cbnz	x0, 0x100506430 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6b8>
100506d1c:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
100506d20:     	add	x0, x0, #0xca8
100506d24:     	bl	0x100b3cb68 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
100506d28:     	ldrb	w8, [x0]
100506d2c:     	cbz	w8, 0x100506438 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6c0>
100506d30:     	bl	0x100b4429c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
100506d34:     	b	0x100506438 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6c0>
100506d38:     	bl	0x100b3f2fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100506d3c:     	add	x8, x0, x24, lsl #3
100506d40:     	ldr	x0, [x8, #0x1e8]
100506d44:     	cbnz	x0, 0x100506774 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9fc>
100506d48:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
100506d4c:     	add	x0, x0, #0xcd8
100506d50:     	bl	0x100b3cb68 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
100506d54:     	b	0x100506774 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9fc>
100506d58:     	bl	0x100b3f2fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100506d5c:     	add	x8, x0, x24, lsl #3
100506d60:     	ldr	x0, [x8, #0x1e8]
100506d64:     	cbnz	x0, 0x1005067c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa48>
100506d68:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100506d6c:     	add	x0, x0, #0x78
100506d70:     	bl	0x100b3cb1c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100506d74:     	ldr	x8, [x0]
100506d78:     	lsr	x8, x8, #25
100506d7c:     	cbnz	x8, 0x1005067cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa54>
100506d80:     	cmp	x23, #0x3e8
100506d84:     	b.ls	0x1005067d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa60>
100506d88:     	bl	0x1004615e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100506d8c:     	ldp	x1, x0, [sp]
100506d90:     	bl	0x100231ff8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100506d94:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100506d98:     	ldr	x8, [x8, #0x7f8]
100506d9c:     	cbz	x8, 0x1005067ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa74>
100506da0:     	bl	0x100b459f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
100506da4:     	tbnz	w25, #0x0, 0x1005067f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa78>
100506da8:     	b	0x100506834 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xabc>
100506dac:     	add	x0, x20, #0x8
100506db0:     	bl	0x100b3bbec <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100506db4:     	b	0x10050671c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9a4>
100506db8:     	bl	0x100b457c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar15clear_key_cache>
100506dbc:     	cmp	x28, x26
100506dc0:     	b.eq	0x100506a78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd00>
100506dc4:     	mov	x0, x23
100506dc8:     	bl	0x100327e4c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15parse_root_push>
100506dcc:     	bl	0x100459d3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy13gc_unsuppress>
100506dd0:     	bl	0x1004efe64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat26finish_parse_gc_accounting>
100506dd4:     	bl	0x1004615e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100506dd8:     	mov	x0, x24
100506ddc:     	mov	x1, x22
100506de0:     	bl	0x100231ff8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100506de4:     	mov	x0, x21
100506de8:     	bl	0x10032805c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json18parse_root_restore>
100506dec:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100506df0:     	ldr	x8, [x8, #0x7f8]
100506df4:     	cbnz	x8, 0x10050735c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15e4>
100506df8:     	adrp	x0, 0x100c75000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x6fdc>
100506dfc:     	add	x0, x0, #0x4e0
100506e00:     	mov	w1, #0x21               ; =33
100506e04:     	bl	0x100508828 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
100506e08:     	cmp	w8, #0x2
100506e0c:     	b.eq	0x100507018 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100506e10:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100506e14:     	add	x1, x1, #0x998
100506e18:     	mov	x0, x20
100506e1c:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100506e20:     	strb	wzr, [x20, #0x20]
100506e24:     	ldr	x8, [x20]
100506e28:     	cbz	x8, 0x1005062a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x52c>
100506e2c:     	b	0x100506e84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
100506e30:     	cmp	w8, #0x2
100506e34:     	b.eq	0x100507018 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100506e38:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100506e3c:     	add	x1, x1, #0x998
100506e40:     	mov	x0, x20
100506e44:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100506e48:     	strb	wzr, [x20, #0x20]
100506e4c:     	ldr	x8, [x20]
100506e50:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100506e54:     	cmp	x8, x9
100506e58:     	b.lo	0x1005069dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc64>
100506e5c:     	b	0x100507004 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100506e60:     	cmp	w8, #0x2
100506e64:     	b.eq	0x100507018 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100506e68:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100506e6c:     	add	x1, x1, #0x998
100506e70:     	mov	x0, x20
100506e74:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100506e78:     	strb	wzr, [x20, #0x20]
100506e7c:     	ldr	x8, [x20]
100506e80:     	cbz	x8, 0x100506b0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd94>
100506e84:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100506e88:     	add	x0, x0, #0x428
100506e8c:     	bl	0x100b1262c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100506e90:     	mov	x0, x22
100506e94:     	bl	0x100b1e42c <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11TapeScratchEEuE16get_or_init_slowNvNvB2b_12TAPE_SCRATCH27___rust_std_internal_init_fnEB2d_>
100506e98:     	mov	x22, x0
100506e9c:     	cbnz	x0, 0x100506388 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x610>
100506ea0:     	b	0x100507018 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100506ea4:     	mov	x0, x21
100506ea8:     	bl	0x10032805c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json18parse_root_restore>
100506eac:     	mov	x0, x22
100506eb0:     	mov	x1, x19
100506eb4:     	bl	0x100b45d38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api19parse_deep_or_throw>
100506eb8:     	mov	x23, x0
100506ebc:     	b	0x100505db0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100506ec0:     	cmp	w8, #0x2
100506ec4:     	b.eq	0x100507018 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100506ec8:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100506ecc:     	add	x1, x1, #0x998
100506ed0:     	mov	x0, x20
100506ed4:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100506ed8:     	strb	wzr, [x20, #0x20]
100506edc:     	ldr	x8, [x20]
100506ee0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100506ee4:     	cmp	x8, x9
100506ee8:     	b.lo	0x10050633c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5c4>
100506eec:     	b	0x100507004 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100506ef0:     	cmp	x9, #0x6
100506ef4:     	b.eq	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506ef8:     	ldrb	w8, [x21, #0x1a]
100506efc:     	cmp	w8, #0x22
100506f00:     	b.ne	0x100507024 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12ac>
100506f04:     	mov	w23, #0x0               ; =0
100506f08:     	mov	w28, #0x0               ; =0
100506f0c:     	mov	w27, #0x0               ; =0
100506f10:     	mov	w26, #0x1               ; =1
100506f14:     	mov	w20, #0x4               ; =4
100506f18:     	b	0x100505f30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100506f1c:     	cmp	w8, #0x2
100506f20:     	b.eq	0x100507018 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100506f24:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100506f28:     	add	x1, x1, #0x998
100506f2c:     	mov	x0, x20
100506f30:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100506f34:     	strb	wzr, [x20, #0x20]
100506f38:     	ldr	x8, [x20]
100506f3c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100506f40:     	cmp	x8, x9
100506f44:     	b.lo	0x1005068e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb68>
100506f48:     	b	0x100507004 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100506f4c:     	cmp	w8, #0x2
100506f50:     	b.eq	0x100507018 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100506f54:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100506f58:     	add	x1, x1, #0x998
100506f5c:     	mov	x0, x20
100506f60:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100506f64:     	strb	wzr, [x20, #0x20]
100506f68:     	ldr	x8, [x20]
100506f6c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100506f70:     	cmp	x8, x9
100506f74:     	b.lo	0x10050646c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6f4>
100506f78:     	b	0x100507004 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100506f7c:     	cmp	w8, #0x2
100506f80:     	b.eq	0x100507018 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100506f84:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100506f88:     	add	x1, x1, #0x998
100506f8c:     	mov	x0, x20
100506f90:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100506f94:     	strb	wzr, [x20, #0x20]
100506f98:     	ldr	x8, [x20]
100506f9c:     	cbz	x8, 0x100506704 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x98c>
100506fa0:     	b	0x100506e84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
100506fa4:     	cmp	x9, #0x1
100506fa8:     	b.ne	0x100507054 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12dc>
100506fac:     	ldrb	w8, [x8]
100506fb0:     	sub	w9, w8, #0x30
100506fb4:     	cmp	w9, #0xa
100506fb8:     	b.hs	0x100507058 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12e0>
100506fbc:     	and	w8, w9, #0xff
100506fc0:     	ucvtf	d0, w8
100506fc4:     	fmov	x1, d0
100506fc8:     	orr	x0, x25, x26
100506fcc:     	bl	0x1004f6030 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object18allocate_one_field>
100506fd0:     	tbnz	w0, #0x0, 0x100505dac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x34>
100506fd4:     	b	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100506fd8:     	cmp	w8, #0x2
100506fdc:     	b.eq	0x100507018 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100506fe0:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100506fe4:     	add	x1, x1, #0x998
100506fe8:     	mov	x0, x20
100506fec:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100506ff0:     	strb	wzr, [x20, #0x20]
100506ff4:     	ldr	x8, [x20]
100506ff8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100506ffc:     	cmp	x8, x9
100507000:     	b.lo	0x100506808 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa90>
100507004:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100507008:     	add	x0, x0, #0x3f8
10050700c:     	bl	0x100b1265c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100507010:     	cmp	w8, #0x2
100507014:     	b.ne	0x100507098 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1320>
100507018:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
10050701c:     	add	x0, x0, #0xc18
100507020:     	bl	0x100b5851c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100507024:     	sub	x8, x19, #0x1
100507028:     	cmp	x8, #0x7
10050702c:     	b.eq	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507030:     	ldrb	w8, [x21, #0x1b]
100507034:     	cmp	w8, #0x22
100507038:     	b.ne	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
10050703c:     	mov	w23, #0x0               ; =0
100507040:     	mov	w28, #0x0               ; =0
100507044:     	mov	w27, #0x0               ; =0
100507048:     	mov	w26, #0x0               ; =0
10050704c:     	mov	w20, #0x5               ; =5
100507050:     	b	0x100505f30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100507054:     	ldrb	w8, [x8]
100507058:     	orr	w8, w8, #0x20
10050705c:     	cmp	w8, #0x7b
100507060:     	b.eq	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507064:     	sub	x11, x19, #0x5
100507068:     	mov	x10, #0x2600            ; =9728
10050706c:     	movk	x10, #0x1, lsl #32
100507070:     	add	x8, x21, x20
100507074:     	ldrb	w9, [x8, #0x18]
100507078:     	cmp	w9, #0x20
10050707c:     	b.hi	0x1005070c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1348>
100507080:     	lsr	x12, x10, x9
100507084:     	tbz	w12, #0x0, 0x1005070c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1348>
100507088:     	add	x20, x20, #0x1
10050708c:     	cmp	x11, x20
100507090:     	b.ne	0x100507070 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12f8>
100507094:     	b	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507098:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
10050709c:     	add	x1, x1, #0x998
1005070a0:     	mov	x0, x20
1005070a4:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1005070a8:     	strb	wzr, [x20, #0x20]
1005070ac:     	ldr	x8, [x20]
1005070b0:     	cbz	x8, 0x100506970 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbf8>
1005070b4:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
1005070b8:     	add	x0, x0, #0x488
1005070bc:     	bl	0x100b1262c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1005070c0:     	cmp	x11, x20
1005070c4:     	b.eq	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005070c8:     	add	x13, x21, #0x12
1005070cc:     	mov	x14, #0x2600            ; =9728
1005070d0:     	movk	x14, #0x1, lsl #32
1005070d4:     	mov	x10, x20
1005070d8:     	ldrb	w12, [x13, x19]
1005070dc:     	cmp	w12, #0x20
1005070e0:     	b.hi	0x100507110 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1398>
1005070e4:     	lsr	x15, x14, x12
1005070e8:     	tbz	w15, #0x0, 0x100507110 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1398>
1005070ec:     	sub	x13, x13, #0x1
1005070f0:     	add	x10, x10, #0x1
1005070f4:     	cmp	x11, x10
1005070f8:     	b.ne	0x1005070d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1360>
1005070fc:     	b	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507100:     	adrp	x2, 0x100f07000 <__RNvNtCs3gRpqoBkMHm_13perry_runtime7promise28ITER_RESULT_VALUE_IS_RAW_I32+0x40>
100507104:     	add	x2, x2, #0x170
100507108:     	mov	x1, x25
10050710c:     	bl	0x100b1278c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100507110:     	sub	x11, x19, x10
100507114:     	sub	x1, x11, #0x5
100507118:     	cmp	x1, #0x4
10050711c:     	b.eq	0x100507188 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1410>
100507120:     	cmp	x1, #0x5
100507124:     	b.ne	0x100507190 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1418>
100507128:     	cmp	w9, #0x22
10050712c:     	b.eq	0x1005071bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1444>
100507130:     	cmp	w9, #0x2d
100507134:     	b.eq	0x1005071ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1434>
100507138:     	cmp	w9, #0x66
10050713c:     	b.ne	0x1005071a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1428>
100507140:     	add	x8, x21, x20
100507144:     	ldrb	w9, [x8, #0x19]
100507148:     	cmp	w9, #0x61
10050714c:     	b.ne	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507150:     	ldrb	w8, [x8, #0x1a]
100507154:     	cmp	w8, #0x6c
100507158:     	b.ne	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
10050715c:     	add	x8, x21, x20
100507160:     	ldrb	w9, [x8, #0x1b]
100507164:     	cmp	w9, #0x73
100507168:     	b.ne	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
10050716c:     	ldrb	w8, [x8, #0x1c]
100507170:     	cmp	w8, #0x65
100507174:     	b.ne	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507178:     	mov	x8, #0x1                ; =1
10050717c:     	movk	x8, #0x7ffc, lsl #48
100507180:     	orr	x1, x8, #0x2
100507184:     	b	0x100506fc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100507188:     	cmp	w9, #0x6d
10050718c:     	b.gt	0x100507228 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14b0>
100507190:     	cmp	w9, #0x22
100507194:     	b.eq	0x1005071bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1444>
100507198:     	cmp	w9, #0x2d
10050719c:     	b.eq	0x1005071ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1434>
1005071a0:     	sub	w9, w9, #0x30
1005071a4:     	cmp	w9, #0xa
1005071a8:     	b.hs	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005071ac:     	add	x0, x8, #0x18
1005071b0:     	bl	0x1004edc48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar12parse_number>
1005071b4:     	tbz	w0, #0x0, 0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005071b8:     	b	0x100506fc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
1005071bc:     	sub	x8, x19, #0x6
1005071c0:     	cmp	x8, x10
1005071c4:     	b.eq	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005071c8:     	cmp	x1, #0x7
1005071cc:     	b.hi	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005071d0:     	cmp	w12, #0x22
1005071d4:     	b.ne	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005071d8:     	sub	x23, x11, #0x7
1005071dc:     	sub	x8, x19, #0x7
1005071e0:     	add	x9, x21, x20
1005071e4:     	add	x22, x9, #0x19
1005071e8:     	cmp	x8, x10
1005071ec:     	b.ne	0x1005072b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1538>
1005071f0:     	add	x8, sp, #0xa0
1005071f4:     	mov	x0, x22
1005071f8:     	mov	x1, x23
1005071fc:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100507200:     	ldr	x8, [sp, #0xa0]
100507204:     	cbnz	x8, 0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507208:     	cmp	x23, #0x2
10050720c:     	b.gt	0x1005072e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1568>
100507210:     	cbz	x23, 0x1005072fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1584>
100507214:     	cmp	x23, #0x1
100507218:     	b.ne	0x100507304 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x158c>
10050721c:     	ldrb	w8, [x22]
100507220:     	mov	x9, #0x10000000000      ; =1099511627776
100507224:     	b	0x100507350 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
100507228:     	cmp	w9, #0x74
10050722c:     	b.eq	0x100507274 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14fc>
100507230:     	cmp	w9, #0x6e
100507234:     	b.ne	0x1005071a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1428>
100507238:     	add	x8, x21, x20
10050723c:     	ldrb	w9, [x8, #0x19]
100507240:     	cmp	w9, #0x75
100507244:     	b.ne	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507248:     	ldrb	w8, [x8, #0x1a]
10050724c:     	cmp	w8, #0x6c
100507250:     	b.ne	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507254:     	add	x8, x21, x20
100507258:     	ldrb	w8, [x8, #0x1b]
10050725c:     	cmp	w8, #0x6c
100507260:     	b.ne	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507264:     	mov	x8, #0x1                ; =1
100507268:     	movk	x8, #0x7ffc, lsl #48
10050726c:     	add	x1, x8, #0x1
100507270:     	b	0x100506fc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100507274:     	add	x8, x21, x20
100507278:     	ldrb	w9, [x8, #0x19]
10050727c:     	cmp	w9, #0x72
100507280:     	b.ne	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507284:     	ldrb	w8, [x8, #0x1a]
100507288:     	cmp	w8, #0x75
10050728c:     	b.ne	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100507290:     	add	x8, x21, x20
100507294:     	ldrb	w8, [x8, #0x1b]
100507298:     	cmp	w8, #0x65
10050729c:     	b.ne	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005072a0:     	mov	x8, #0x1                ; =1
1005072a4:     	movk	x8, #0x7ffc, lsl #48
1005072a8:     	add	x1, x8, #0x3
1005072ac:     	b	0x100506fc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
1005072b0:     	mov	x8, x23
1005072b4:     	mov	x9, x22
1005072b8:     	ldrb	w10, [x9], #0x1
1005072bc:     	cmp	w10, #0x20
1005072c0:     	b.lo	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005072c4:     	cmp	w10, #0x22
1005072c8:     	b.eq	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005072cc:     	cmp	w10, #0x5c
1005072d0:     	b.eq	0x100505dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005072d4:     	subs	x8, x8, #0x1
1005072d8:     	b.ne	0x1005072b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1540>
1005072dc:     	b	0x1005071f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1478>
1005072e0:     	cmp	x23, #0x3
1005072e4:     	b.eq	0x10050731c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15a4>
1005072e8:     	cmp	x23, #0x4
1005072ec:     	b.ne	0x10050733c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15c4>
1005072f0:     	ldr	w8, [x22]
1005072f4:     	mov	x9, #0x40000000000      ; =4398046511104
1005072f8:     	b	0x100507350 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
1005072fc:     	mov	x1, #0x7ff9000000000000 ; =9221401712017801216
100507300:     	b	0x100506fc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100507304:     	ldrb	w8, [x22]
100507308:     	add	x9, x21, x20
10050730c:     	ldrb	w9, [x9, #0x1a]
100507310:     	orr	x8, x8, x9, lsl #8
100507314:     	mov	x9, #0x20000000000      ; =2199023255552
100507318:     	b	0x100507350 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
10050731c:     	ldrb	w8, [x22]
100507320:     	add	x9, x21, x20
100507324:     	ldrb	w10, [x9, #0x1a]
100507328:     	ldrb	w9, [x9, #0x1b]
10050732c:     	orr	x8, x8, x10, lsl #8
100507330:     	orr	x8, x8, x9, lsl #16
100507334:     	mov	x9, #0x30000000000      ; =3298534883328
100507338:     	b	0x100507350 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
10050733c:     	ldr	w8, [x22]
100507340:     	add	x9, x21, x20
100507344:     	ldrb	w9, [x9, #0x1d]
100507348:     	orr	x8, x8, x9, lsl #32
10050734c:     	mov	x9, #0x50000000000      ; =5497558138880
100507350:     	movk	x9, #0x7ff9, lsl #48
100507354:     	orr	x1, x8, x9
100507358:     	b	0x100506fc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
10050735c:     	bl	0x100b459f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
100507360:     	adrp	x0, 0x100c75000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x6fdc>
100507364:     	add	x0, x0, #0x4e0
100507368:     	mov	w1, #0x21               ; =33
10050736c:     	bl	0x100508828 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
