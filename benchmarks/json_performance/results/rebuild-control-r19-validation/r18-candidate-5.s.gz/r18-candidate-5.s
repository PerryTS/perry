
benchmarks/json_performance/.work/tape-batch-r18/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001005bd408 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>:
1005bd408:     	sub	sp, sp, #0xa0
1005bd40c:     	stp	d9, d8, [sp, #0x30]
1005bd410:     	stp	x28, x27, [sp, #0x40]
1005bd414:     	stp	x26, x25, [sp, #0x50]
1005bd418:     	stp	x24, x23, [sp, #0x60]
1005bd41c:     	stp	x22, x21, [sp, #0x70]
1005bd420:     	stp	x20, x19, [sp, #0x80]
1005bd424:     	stp	x29, x30, [sp, #0x90]
1005bd428:     	add	x29, sp, #0x90
1005bd42c:     	mov	x19, x4
1005bd430:     	mov	x21, x3
1005bd434:     	mov	x23, x2
1005bd438:     	mov	x22, x1
1005bd43c:     	mov	w8, #0x2                ; =2
1005bd440:     	cmp	x4, #0x2
1005bd444:     	csel	x25, x4, x8, hi
1005bd448:     	ldr	x24, [x0]
1005bd44c:     	cbz	x24, 0x1005bd490 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x88>
1005bd450:     	mov	w8, #0x3ffd             ; =16381
1005bd454:     	cmp	x19, x8
1005bd458:     	b.hi	0x1005bd490 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x88>
1005bd45c:     	ldr	x8, [x0, #0x10]
1005bd460:     	ldrb	w8, [x8]
1005bd464:     	tbnz	w8, #0x0, 0x1005bd490 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x88>
1005bd468:     	lsl	x8, x25, #3
1005bd46c:     	ldr	x9, [x0, #0x8]
1005bd470:     	add	x8, x8, #0x18
1005bd474:     	ldp	x10, x11, [x9, #0x8]
1005bd478:     	add	x10, x10, #0x7
1005bd47c:     	and	x10, x10, #0xfffffffffffffff8
1005bd480:     	subs	x11, x11, x10
1005bd484:     	csel	x11, xzr, x11, lo
1005bd488:     	cmp	x8, x11
1005bd48c:     	b.ls	0x1005bd650 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x248>
1005bd490:     	add	x0, sp, #0x8
1005bd494:     	mov	w1, #0x0                ; =0
1005bd498:     	mov	w2, #0x0                ; =0
1005bd49c:     	mov	x3, x19
1005bd4a0:     	mov	x4, x22
1005bd4a4:     	mov	x5, x23
1005bd4a8:     	bl	0x1005db040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object5alloc35object_alloc_class_inline_keys_impl>
1005bd4ac:     	ldr	x20, [sp, #0x8]
1005bd4b0:     	ldrb	w8, [sp, #0x14]
1005bd4b4:     	tbnz	w8, #0x0, 0x1005bd4c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0xc0>
1005bd4b8:     	ldr	w2, [sp, #0x10]
1005bd4bc:     	mov	x0, x20
1005bd4c0:     	mov	x1, x23
1005bd4c4:     	bl	0x1005e0b00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes24birth_stamp_object_shape>
1005bd4c8:     	cbz	x20, 0x1005bd4d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0xd0>
1005bd4cc:     	ldurh	w8, [x20, #-0x6]
1005bd4d0:     	orr	w8, w8, #0x200
1005bd4d4:     	sturh	w8, [x20, #-0x6]
1005bd4d8:     	lsl	x22, x19, #3
1005bd4dc:     	cbz	x24, 0x1005bd544 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x13c>
1005bd4e0:     	cbz	x19, 0x1005bd614 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x20c>
1005bd4e4:     	sub	x8, x22, #0x8
1005bd4e8:     	cmp	x8, #0x18
1005bd4ec:     	b.lo	0x1005bd500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0xf8>
1005bd4f0:     	sub	x9, x20, x21
1005bd4f4:     	add	x9, x9, #0xf
1005bd4f8:     	cmp	x9, #0xff
1005bd4fc:     	b.hs	0x1005bd634 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x22c>
1005bd500:     	mov	w23, #0x0               ; =0
1005bd504:     	mov	x8, #0x0                ; =0
1005bd508:     	mov	x9, x21
1005bd50c:     	add	x10, x21, x22
1005bd510:     	add	x8, x20, x8, lsl #3
1005bd514:     	add	x8, x8, #0x10
1005bd518:     	mov	x11, #-0x3000000000000  ; =-844424930131968
1005bd51c:     	mov	x12, #0x7ffd000000000000 ; =9222527611924643840
1005bd520:     	ldr	x13, [x9], #0x8
1005bd524:     	str	x13, [x8], #0x8
1005bd528:     	and	x13, x13, x11
1005bd52c:     	cmp	x13, x12
1005bd530:     	cset	w13, eq
1005bd534:     	orr	w23, w23, w13
1005bd538:     	cmp	x9, x10
1005bd53c:     	b.ne	0x1005bd520 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x118>
1005bd540:     	b	0x1005bd574 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x16c>
1005bd544:     	cbz	x19, 0x1005bd614 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x20c>
1005bd548:     	mov	w23, #0x0               ; =0
1005bd54c:     	mov	x1, #0x0                ; =0
1005bd550:     	mov	x26, x22
1005bd554:     	add	x27, x1, #0x1
1005bd558:     	ldr	x2, [x21, x1, lsl #3]
1005bd55c:     	mov	x0, x20
1005bd560:     	bl	0x10034afc8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object39store_object_field_slot_layout_deferred>
1005bd564:     	orr	w23, w23, w0
1005bd568:     	mov	x1, x27
1005bd56c:     	subs	x26, x26, #0x8
1005bd570:     	b.ne	0x1005bd554 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x14c>
1005bd574:     	cmp	x19, #0x2
1005bd578:     	b.hs	0x1005bd598 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x190>
1005bd57c:     	add	x8, x20, x22
1005bd580:     	sub	x9, x25, x19
1005bd584:     	lsl	x2, x9, #3
1005bd588:     	adrp	x1, 0x100c9c000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x7060>
1005bd58c:     	add	x1, x1, #0xa80
1005bd590:     	add	x0, x8, #0x10
1005bd594:     	bl	0x100b62bd0 <_writev+0x100b62bd0>
1005bd598:     	tbz	w23, #0x0, 0x1005bd9cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5c4>
1005bd59c:     	lsr	x8, x20, #3
1005bd5a0:     	cmp	x8, #0x201
1005bd5a4:     	b.lo	0x1005bd9b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5b0>
1005bd5a8:     	ldurb	w8, [x20, #-0x8]
1005bd5ac:     	sub	w9, w8, #0x15
1005bd5b0:     	cmn	w9, #0x14
1005bd5b4:     	b.lo	0x1005bd9b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5b0>
1005bd5b8:     	adrp	x9, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x150>
1005bd5bc:     	add	x9, x9, #0x690
1005bd5c0:     	add	x8, x9, x8, lsl #5
1005bd5c4:     	ldrb	w8, [x8, #0x14]
1005bd5c8:     	mov	w9, #0x16               ; =22
1005bd5cc:     	lsr	w8, w9, w8
1005bd5d0:     	tbz	w8, #0x0, 0x1005bd9b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5b0>
1005bd5d4:     	ldurh	w8, [x20, #-0x6]
1005bd5d8:     	and	w9, w8, #0xffffefff
1005bd5dc:     	sturh	w9, [x20, #-0x6]
1005bd5e0:     	ands	w21, w8, #0xc000
1005bd5e4:     	b.eq	0x1005bd9b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5a8>
1005bd5e8:     	and	w8, w8, #0xfff
1005bd5ec:     	sturh	w8, [x20, #-0x6]
1005bd5f0:     	mov	x0, x20
1005bd5f4:     	bl	0x100435ae0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc13layout_tables20typed_layouts_remove>
1005bd5f8:     	cmp	w21, #0x4, lsl #12      ; =0x4000
1005bd5fc:     	b.eq	0x1005bd608 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x200>
1005bd600:     	mov	x0, x20
1005bd604:     	bl	0x1004350f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc13layout_tables17slot_masks_remove>
1005bd608:     	mov	x0, x20
1005bd60c:     	bl	0x1002d9200 <__RNvNtCs3gRpqoBkMHm_13perry_runtime14typed_feedback32invalidate_representation_change>
1005bd610:     	b	0x1005bd9b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5b0>
1005bd614:     	add	x8, x20, x22
1005bd618:     	sub	x9, x25, x19
1005bd61c:     	lsl	x2, x9, #3
1005bd620:     	adrp	x1, 0x100c9c000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x7060>
1005bd624:     	add	x1, x1, #0xa80
1005bd628:     	add	x0, x8, #0x10
1005bd62c:     	bl	0x100b62bd0 <_writev+0x100b62bd0>
1005bd630:     	b	0x1005bd9cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5c4>
1005bd634:     	lsr	x9, x8, #3
1005bd638:     	add	x10, x9, #0x1
1005bd63c:     	cmp	x8, #0xf8
1005bd640:     	b.hs	0x1005bd7c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x3c0>
1005bd644:     	mov	x8, #0x0                ; =0
1005bd648:     	mov	w23, #0x0               ; =0
1005bd64c:     	b	0x1005bd92c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x524>
1005bd650:     	ldr	x11, [x9]
1005bd654:     	add	x26, x11, x10
1005bd658:     	add	x10, x10, x8
1005bd65c:     	str	x10, [x9, #0x8]
1005bd660:     	mov	w9, #0x202              ; =514
1005bd664:     	stp	w9, w8, [x26]
1005bd668:     	mov	x20, x26
1005bd66c:     	str	xzr, [x20, #0x8]!
1005bd670:     	str	xzr, [x26, #0x10]
1005bd674:     	mov	x0, x20
1005bd678:     	mov	x1, x23
1005bd67c:     	mov	x2, x22
1005bd680:     	mov	x3, x19
1005bd684:     	bl	0x1005e6274 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34try_birth_stamp_preinstalled_shape>
1005bd688:     	lsr	x27, x20, #3
1005bd68c:     	tbnz	w0, #0x0, 0x1005bd76c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x364>
1005bd690:     	mov	x0, x22
1005bd694:     	mov	x1, x19
1005bd698:     	mov	x2, x19
1005bd69c:     	mov	x3, #0x0                ; =0
1005bd6a0:     	mov	w4, #0x0                ; =0
1005bd6a4:     	mov	w5, #0x0                ; =0
1005bd6a8:     	bl	0x1005e5900 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_descriptor_ensure_with_holes>
1005bd6ac:     	tbnz	w0, #0x0, 0x1005bdac8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x6c0>
1005bd6b0:     	ldr	w28, [x26, #0xc]
1005bd6b4:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1005bd6b8:     	ldr	w23, [x8, #0x800]
1005bd6bc:     	cmp	w23, #0x300
1005bd6c0:     	b.hs	0x1005bda10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x608>
1005bd6c4:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1005bd6c8:     	ldr	x8, [x8, #0x48]
1005bd6cc:     	cmn	x8, #0x1
1005bd6d0:     	b.eq	0x1005bd9f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5ec>
1005bd6d4:     	mrs	x9, TPIDRRO_EL0
1005bd6d8:     	and	x9, x9, #0xfffffffffffffff8
1005bd6dc:     	ldr	x8, [x9, x8, lsl #3]
1005bd6e0:     	cbz	x8, 0x1005bd9f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5ec>
1005bd6e4:     	add	x8, x8, x23, lsl #3
1005bd6e8:     	ldr	x8, [x8, #0x1e8]
1005bd6ec:     	cbz	x8, 0x1005bda10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x608>
1005bd6f0:     	lsr	x23, x0, #32
1005bd6f4:     	ldr	x0, [x8]
1005bd6f8:     	cbz	x0, 0x1005bda34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x62c>
1005bd6fc:     	ldr	x9, [x0, #0x51d0]
1005bd700:     	mov	w8, #-0x40000001        ; =-1073741825
1005bd704:     	cmp	w28, w8
1005bd708:     	ubfx	x8, x28, #15, #15
1005bd70c:     	ccmp	x8, x9, #0x2, le
1005bd710:     	b.lo	0x1005bda50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x648>
1005bd714:     	mov	w8, #0x2                ; =2
1005bd718:     	strb	w8, [sp, #0x2e]
1005bd71c:     	cbz	x22, 0x1005bd748 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x340>
1005bd720:     	cmp	x27, #0x201
1005bd724:     	b.lo	0x1005bd748 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x340>
1005bd728:     	ldrh	w8, [x26, #0x2]
1005bd72c:     	sxth	w9, w8
1005bd730:     	tst	w8, #0x1000
1005bd734:     	mov	w8, #-0x4001            ; =-16385
1005bd738:     	ccmp	w9, w8, #0x4, eq
1005bd73c:     	b.gt	0x1005bd748 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x340>
1005bd740:     	mov	x0, x20
1005bd744:     	bl	0x10045718c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6layout19layout_mark_unknown>
1005bd748:     	add	x1, sp, #0x8
1005bd74c:     	mov	x0, x20
1005bd750:     	mov	x2, x22
1005bd754:     	mov	x3, x19
1005bd758:     	bl	0x1005e12ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes25publish_object_shape_from>
1005bd75c:     	mov	x0, x20
1005bd760:     	mov	x1, x23
1005bd764:     	mov	x2, x19
1005bd768:     	bl	0x1005e0b00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes24birth_stamp_object_shape>
1005bd76c:     	cmp	x27, #0x201
1005bd770:     	b.lo	0x1005bd4cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0xc4>
1005bd774:     	ldrb	w8, [x26]
1005bd778:     	sub	w9, w8, #0x15
1005bd77c:     	cmn	w9, #0x14
1005bd780:     	b.lo	0x1005bd4cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0xc4>
1005bd784:     	adrp	x9, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x150>
1005bd788:     	add	x9, x9, #0x690
1005bd78c:     	add	x8, x9, x8, lsl #5
1005bd790:     	ldrb	w8, [x8, #0x14]
1005bd794:     	mov	w9, #0x16               ; =22
1005bd798:     	lsr	w8, w9, w8
1005bd79c:     	tbz	w8, #0x0, 0x1005bd4cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0xc4>
1005bd7a0:     	ldrh	w8, [x26, #0x2]
1005bd7a4:     	mov	w9, #0x4000             ; =16384
1005bd7a8:     	bfxil	w9, w8, #0, #13
1005bd7ac:     	strh	w9, [x26, #0x2]
1005bd7b0:     	mov	x0, x20
1005bd7b4:     	bl	0x100435434 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc13layout_tables20layout_forget_object>
1005bd7b8:     	ldrh	w8, [x26, #0x2]
1005bd7bc:     	and	w8, w8, #0xffffefff
1005bd7c0:     	strh	w8, [x26, #0x2]
1005bd7c4:     	b	0x1005bd4cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0xc4>
1005bd7c8:     	and	x11, x10, #0x1c
1005bd7cc:     	and	x8, x10, #0x3fffffffffffffe0
1005bd7d0:     	add	x12, x20, #0x90
1005bd7d4:     	add	x13, x21, #0x80
1005bd7d8:     	movi.2d	v0, #0000000000000000
1005bd7dc:     	mov	x9, #-0x3000000000000   ; =-844424930131968
1005bd7e0:     	dup.2d	v1, x9
1005bd7e4:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
1005bd7e8:     	dup.2d	v2, x9
1005bd7ec:     	and	x14, x10, #0x3fffffffffffffe0
1005bd7f0:     	add	x9, x21, x8, lsl #3
1005bd7f4:     	movi.2d	v3, #0000000000000000
1005bd7f8:     	ldp	q17, q16, [x13, #-0x80]
1005bd7fc:     	ldp	q19, q18, [x13, #-0x60]
1005bd800:     	ldp	q21, q20, [x13, #-0x40]
1005bd804:     	ldp	q23, q22, [x13, #-0x20]
1005bd808:     	ldp	q5, q4, [x13]
1005bd80c:     	ldp	q7, q6, [x13, #0x20]
1005bd810:     	ldp	q25, q24, [x13, #0x40]
1005bd814:     	and.16b	v26, v17, v1
1005bd818:     	and.16b	v27, v16, v1
1005bd81c:     	and.16b	v28, v19, v1
1005bd820:     	and.16b	v29, v18, v1
1005bd824:     	and.16b	v30, v21, v1
1005bd828:     	and.16b	v31, v20, v1
1005bd82c:     	ldp	q9, q8, [x13, #0x60]
1005bd830:     	stp	q21, q20, [x12, #-0x40]
1005bd834:     	and.16b	v20, v23, v1
1005bd838:     	stp	q23, q22, [x12, #-0x20]
1005bd83c:     	and.16b	v21, v22, v1
1005bd840:     	cmeq.2d	v21, v21, v2
1005bd844:     	cmeq.2d	v20, v20, v2
1005bd848:     	uzp1.4s	v20, v20, v21
1005bd84c:     	and.16b	v21, v5, v1
1005bd850:     	stp	q19, q18, [x12, #-0x60]
1005bd854:     	and.16b	v18, v4, v1
1005bd858:     	cmeq.2d	v19, v31, v2
1005bd85c:     	cmeq.2d	v22, v30, v2
1005bd860:     	uzp1.4s	v19, v22, v19
1005bd864:     	and.16b	v22, v7, v1
1005bd868:     	stp	q17, q16, [x12, #-0x80]
1005bd86c:     	and.16b	v16, v6, v1
1005bd870:     	uzp1.8h	v17, v19, v20
1005bd874:     	and.16b	v19, v25, v1
1005bd878:     	stp	q25, q24, [x12, #0x40]
1005bd87c:     	and.16b	v20, v24, v1
1005bd880:     	cmeq.2d	v23, v29, v2
1005bd884:     	cmeq.2d	v24, v28, v2
1005bd888:     	uzp1.4s	v23, v24, v23
1005bd88c:     	and.16b	v24, v9, v1
1005bd890:     	stp	q9, q8, [x12, #0x60]
1005bd894:     	and.16b	v25, v8, v1
1005bd898:     	cmeq.2d	v27, v27, v2
1005bd89c:     	cmeq.2d	v26, v26, v2
1005bd8a0:     	uzp1.4s	v26, v26, v27
1005bd8a4:     	uzp1.8h	v23, v26, v23
1005bd8a8:     	uzp1.16b	v17, v23, v17
1005bd8ac:     	cmeq.2d	v23, v25, v2
1005bd8b0:     	cmeq.2d	v24, v24, v2
1005bd8b4:     	uzp1.4s	v23, v24, v23
1005bd8b8:     	cmeq.2d	v20, v20, v2
1005bd8bc:     	cmeq.2d	v19, v19, v2
1005bd8c0:     	uzp1.4s	v19, v19, v20
1005bd8c4:     	uzp1.8h	v19, v19, v23
1005bd8c8:     	cmeq.2d	v16, v16, v2
1005bd8cc:     	cmeq.2d	v20, v22, v2
1005bd8d0:     	uzp1.4s	v16, v20, v16
1005bd8d4:     	stp	q7, q6, [x12, #0x20]
1005bd8d8:     	cmeq.2d	v6, v18, v2
1005bd8dc:     	cmeq.2d	v7, v21, v2
1005bd8e0:     	uzp1.4s	v6, v7, v6
1005bd8e4:     	uzp1.8h	v6, v6, v16
1005bd8e8:     	stp	q5, q4, [x12], #0x100
1005bd8ec:     	uzp1.16b	v4, v6, v19
1005bd8f0:     	orr.16b	v0, v0, v17
1005bd8f4:     	orr.16b	v3, v3, v4
1005bd8f8:     	add	x13, x13, #0x100
1005bd8fc:     	subs	x14, x14, #0x20
1005bd900:     	b.ne	0x1005bd7f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x3f0>
1005bd904:     	orr.16b	v0, v3, v0
1005bd908:     	shl.16b	v0, v0, #0x7
1005bd90c:     	cmlt.16b	v0, v0, #0
1005bd910:     	addp.2d	d0, v0
1005bd914:     	fmov	x12, d0
1005bd918:     	cmp	x12, #0x0
1005bd91c:     	cset	w23, ne
1005bd920:     	cmp	x10, x8
1005bd924:     	b.eq	0x1005bd574 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x16c>
1005bd928:     	cbz	x11, 0x1005bd50c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x104>
1005bd92c:     	mov	x12, x8
1005bd930:     	and	x8, x10, #0x3ffffffffffffffc
1005bd934:     	movi.2d	v0, #0000000000000000
1005bd938:     	mov.h	v0[0], w23
1005bd93c:     	add	x9, x21, x8, lsl #3
1005bd940:     	sub	x11, x12, x8
1005bd944:     	lsl	x13, x12, #3
1005bd948:     	add	x12, x13, x20
1005bd94c:     	add	x12, x12, #0x10
1005bd950:     	add	x13, x21, x13
1005bd954:     	mov	x14, #-0x3000000000000  ; =-844424930131968
1005bd958:     	dup.2d	v1, x14
1005bd95c:     	mov	x14, #0x7ffd000000000000 ; =9222527611924643840
1005bd960:     	dup.2d	v2, x14
1005bd964:     	ldp	q3, q4, [x13], #0x20
1005bd968:     	stp	q3, q4, [x12], #0x20
1005bd96c:     	and.16b	v3, v3, v1
1005bd970:     	and.16b	v4, v4, v1
1005bd974:     	cmeq.2d	v4, v4, v2
1005bd978:     	cmeq.2d	v3, v3, v2
1005bd97c:     	uzp1.4s	v3, v3, v4
1005bd980:     	xtn.4h	v3, v3
1005bd984:     	orr.8b	v0, v0, v3
1005bd988:     	adds	x11, x11, #0x4
1005bd98c:     	b.ne	0x1005bd964 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x55c>
1005bd990:     	shl.4h	v0, v0, #0xf
1005bd994:     	cmlt.4h	v0, v0, #0
1005bd998:     	fmov	x11, d0
1005bd99c:     	cmp	x11, #0x0
1005bd9a0:     	cset	w23, ne
1005bd9a4:     	cmp	x10, x8
1005bd9a8:     	b.ne	0x1005bd50c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x104>
1005bd9ac:     	b	0x1005bd574 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x16c>
1005bd9b0:     	mov	x0, x20
1005bd9b4:     	bl	0x100435434 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc13layout_tables20layout_forget_object>
1005bd9b8:     	tbz	w24, #0x0, 0x1005bd9cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x5c4>
1005bd9bc:     	add	x1, x20, #0x10
1005bd9c0:     	mov	x0, x20
1005bd9c4:     	mov	x2, x19
1005bd9c8:     	bl	0x100237d9c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime5arena12constructionNtB2_17ConstructionBatch17finish_json_slots>
1005bd9cc:     	mov	x0, x20
1005bd9d0:     	ldp	x29, x30, [sp, #0x90]
1005bd9d4:     	ldp	x20, x19, [sp, #0x80]
1005bd9d8:     	ldp	x22, x21, [sp, #0x70]
1005bd9dc:     	ldp	x24, x23, [sp, #0x60]
1005bd9e0:     	ldp	x26, x25, [sp, #0x50]
1005bd9e4:     	ldp	x28, x27, [sp, #0x40]
1005bd9e8:     	ldp	d9, d8, [sp, #0x30]
1005bd9ec:     	add	sp, sp, #0xa0
1005bd9f0:     	ret
1005bd9f4:     	str	x0, [sp]
1005bd9f8:     	bl	0x100b4013c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005bd9fc:     	mov	x8, x0
1005bda00:     	ldr	x0, [sp]
1005bda04:     	add	x8, x8, x23, lsl #3
1005bda08:     	ldr	x8, [x8, #0x1e8]
1005bda0c:     	cbnz	x8, 0x1005bd6f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x2e8>
1005bda10:     	adrp	x8, 0x100f0a000 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json25PARSE_KEY_CACHE_OVERSIZED+0x2c0>
1005bda14:     	add	x8, x8, #0x668
1005bda18:     	mov	x23, x0
1005bda1c:     	mov	x0, x8
1005bda20:     	bl	0x100b3d95c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1005bda24:     	mov	x8, x0
1005bda28:     	lsr	x23, x23, #32
1005bda2c:     	ldr	x0, [x8]
1005bda30:     	cbnz	x0, 0x1005bd6fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x2f4>
1005bda34:     	bl	0x100b3f5e0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime5state10init_state>
1005bda38:     	ldr	x9, [x0, #0x51d0]
1005bda3c:     	mov	w8, #-0x40000001        ; =-1073741825
1005bda40:     	cmp	w28, w8
1005bda44:     	ubfx	x8, x28, #15, #15
1005bda48:     	ccmp	x8, x9, #0x2, le
1005bda4c:     	b.hs	0x1005bd714 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x30c>
1005bda50:     	ldr	x9, [x0, #0x51c8]
1005bda54:     	ldr	x8, [x9, x8, lsl #3]
1005bda58:     	cbz	x8, 0x1005bd714 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x30c>
1005bda5c:     	ubfx	x9, x28, #5, #10
1005bda60:     	ldr	x8, [x8, x9, lsl #3]
1005bda64:     	cbz	x8, 0x1005bd714 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x30c>
1005bda68:     	and	x9, x28, #0x1f
1005bda6c:     	add	x8, x8, x9, lsl #5
1005bda70:     	ldrb	w10, [x8, #0x1c]
1005bda74:     	tbz	w10, #0x0, 0x1005bd714 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x30c>
1005bda78:     	mov	w9, #0x90               ; =144
1005bda7c:     	tst	w10, w9
1005bda80:     	cset	w11, ne
1005bda84:     	ldp	x9, x12, [x8]
1005bda88:     	ubfx	w13, w10, #5, #1
1005bda8c:     	ldr	w14, [x8, #0x18]
1005bda90:     	ubfx	w10, w10, #2, #1
1005bda94:     	stp	x9, x8, [sp, #0x8]
1005bda98:     	str	x12, [sp, #0x18]
1005bda9c:     	ldr	d0, [x8, #0x10]
1005bdaa0:     	str	d0, [sp, #0x20]
1005bdaa4:     	str	w14, [sp, #0x28]
1005bdaa8:     	strb	w10, [sp, #0x2c]
1005bdaac:     	strb	w11, [sp, #0x2d]
1005bdab0:     	strb	w13, [sp, #0x2e]
1005bdab4:     	cmp	x27, #0x201
1005bdab8:     	b.lo	0x1005bd748 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x340>
1005bdabc:     	cmp	x9, x22
1005bdac0:     	b.ne	0x1005bd728 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x320>
1005bdac4:     	b	0x1005bd748 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x340>
1005bdac8:     	tbnz	w0, #0x8, 0x1005bdad0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled+0x6c8>
1005bdacc:     	bl	0x100b4bb34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes24shape_id_exhausted_abort>
1005bdad0:     	bl	0x100b4bb50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes25invalid_shape_facts_abort>
