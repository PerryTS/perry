
benchmarks/json_performance/.work/tape-batch-r18/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010024559c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number>:
10024559c:     	sub	sp, sp, #0x30
1002455a0:     	stp	x20, x19, [sp, #0x10]
1002455a4:     	stp	x29, x30, [sp, #0x20]
1002455a8:     	add	x29, sp, #0x20
1002455ac:     	ldp	x2, x9, [x0, #0x68]
1002455b0:     	cmp	x9, x2
1002455b4:     	b.hs	0x1002455e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x44>
1002455b8:     	ldr	x8, [x0, #0x60]
1002455bc:     	ldrb	w8, [x8, x9]
1002455c0:     	cmp	w8, #0x2d
1002455c4:     	b.ne	0x1002455e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x44>
1002455c8:     	add	x10, x9, #0x1
1002455cc:     	str	x10, [x0, #0x70]
1002455d0:     	mov	w13, #0x1               ; =1
1002455d4:     	cmp	x10, x2
1002455d8:     	b.lo	0x1002455f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x54>
1002455dc:     	b	0x10024580c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x270>
1002455e0:     	mov	w13, #0x0               ; =0
1002455e4:     	mov	x10, x9
1002455e8:     	cmp	x9, x2
1002455ec:     	b.hs	0x10024580c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x270>
1002455f0:     	ldr	x12, [x0, #0x60]
1002455f4:     	add	x14, x12, x10
1002455f8:     	ldrb	w8, [x14]
1002455fc:     	cmp	w8, #0x30
100245600:     	b.ne	0x100245648 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0xac>
100245604:     	add	x1, x10, #0x1
100245608:     	str	x1, [x0, #0x70]
10024560c:     	cmp	x1, x2
100245610:     	b.hs	0x100245680 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0xe4>
100245614:     	ldrb	w8, [x12, x1]
100245618:     	sub	w8, w8, #0x30
10024561c:     	cmp	w8, #0x9
100245620:     	b.hi	0x100245680 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0xe4>
100245624:     	ldrb	w8, [x12, x1]
100245628:     	sub	w8, w8, #0x30
10024562c:     	cmp	w8, #0xa
100245630:     	b.hs	0x10024580c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x270>
100245634:     	add	x1, x1, #0x1
100245638:     	str	x1, [x0, #0x70]
10024563c:     	cmp	x2, x1
100245640:     	b.ne	0x100245624 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x88>
100245644:     	b	0x10024580c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x270>
100245648:     	sub	w8, w8, #0x31
10024564c:     	cmp	w8, #0x8
100245650:     	b.hi	0x10024580c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x270>
100245654:     	mov	x1, x10
100245658:     	ldrb	w8, [x12, x1]
10024565c:     	sub	w8, w8, #0x30
100245660:     	cmp	w8, #0x9
100245664:     	b.hi	0x100245680 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0xe4>
100245668:     	add	x1, x1, #0x1
10024566c:     	str	x1, [x0, #0x70]
100245670:     	cmp	x2, x1
100245674:     	b.ne	0x100245658 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0xbc>
100245678:     	mov	x1, x2
10024567c:     	b	0x1002456a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x10c>
100245680:     	subs	x8, x1, x2
100245684:     	b.hs	0x1002456a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x10c>
100245688:     	ldrb	w11, [x12, x1]
10024568c:     	cmp	w11, #0x2e
100245690:     	b.eq	0x1002457bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x220>
100245694:     	cmp	w11, #0x45
100245698:     	b.eq	0x1002456fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x160>
10024569c:     	mov	x8, x1
1002456a0:     	cmp	w11, #0x65
1002456a4:     	b.eq	0x100245700 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x164>
1002456a8:     	subs	x8, x1, x10
1002456ac:     	ccmp	x8, #0x13, #0x2, ne
1002456b0:     	b.hs	0x1002456fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x160>
1002456b4:     	cmp	x1, x10
1002456b8:     	b.lo	0x10024590c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x370>
1002456bc:     	cmp	x1, x2
1002456c0:     	b.hi	0x10024590c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x370>
1002456c4:     	mov	x9, #0x0                ; =0
1002456c8:     	mov	w10, #0xa               ; =10
1002456cc:     	ldrb	w11, [x14], #0x1
1002456d0:     	mul	x9, x9, x10
1002456d4:     	sub	w11, w11, #0x30
1002456d8:     	add	x9, x9, w11, uxtb
1002456dc:     	subs	x8, x8, #0x1
1002456e0:     	b.ne	0x1002456cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x130>
1002456e4:     	ucvtf	d0, x9
1002456e8:     	fneg	d1, d0
1002456ec:     	cmp	w13, #0x0
1002456f0:     	fcsel	d0, d1, d0, ne
1002456f4:     	fmov	x8, d0
1002456f8:     	b	0x100245818 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x27c>
1002456fc:     	mov	x8, x1
100245700:     	cmp	x8, x2
100245704:     	b.hs	0x10024577c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x1e0>
100245708:     	ldrb	w10, [x12, x8]
10024570c:     	orr	w10, w10, #0x20
100245710:     	cmp	w10, #0x65
100245714:     	b.ne	0x10024577c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x1e0>
100245718:     	add	x10, x8, #0x1
10024571c:     	str	x10, [x0, #0x70]
100245720:     	cmp	x10, x2
100245724:     	b.hs	0x100245744 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x1a8>
100245728:     	ldrb	w11, [x12, x10]
10024572c:     	cmp	w11, #0x2d
100245730:     	b.eq	0x10024573c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x1a0>
100245734:     	cmp	w11, #0x2b
100245738:     	b.ne	0x100245744 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x1a8>
10024573c:     	add	x10, x8, #0x2
100245740:     	str	x10, [x0, #0x70]
100245744:     	cmp	x10, x2
100245748:     	b.hs	0x10024580c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x270>
10024574c:     	mov	x8, x10
100245750:     	ldrb	w11, [x12, x8]
100245754:     	sub	w11, w11, #0x30
100245758:     	cmp	w11, #0x9
10024575c:     	b.hi	0x100245774 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x1d8>
100245760:     	add	x8, x8, #0x1
100245764:     	str	x8, [x0, #0x70]
100245768:     	cmp	x2, x8
10024576c:     	b.ne	0x100245750 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x1b4>
100245770:     	mov	x8, x2
100245774:     	cmp	x8, x10
100245778:     	b.eq	0x10024580c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x270>
10024577c:     	subs	x1, x8, x9
100245780:     	b.lo	0x1002458f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x35c>
100245784:     	cmp	x8, x2
100245788:     	b.hi	0x1002458f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x35c>
10024578c:     	mov	x19, x0
100245790:     	mov	x8, sp
100245794:     	add	x0, x12, x9
100245798:     	bl	0x1000335ac <__RNvXs2_NtNtCsjgY6bXVaRmE_4core3num11float_parsedNtNtNtB9_3str6traits7FromStr8from_str>
10024579c:     	ldrb	w8, [sp]
1002457a0:     	tbz	w8, #0x0, 0x1002457b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x218>
1002457a4:     	mov	x8, #0x2                ; =2
1002457a8:     	movk	x8, #0x7ffc, lsl #48
1002457ac:     	strb	wzr, [x19, #0xd4]
1002457b0:     	b	0x100245818 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x27c>
1002457b4:     	ldr	x8, [sp, #0x8]
1002457b8:     	b	0x100245818 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x27c>
1002457bc:     	add	x11, x1, #0x1
1002457c0:     	cmp	x11, x2
1002457c4:     	b.hs	0x100245808 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x26c>
1002457c8:     	add	x16, x12, #0x1
1002457cc:     	mov	x15, #-0x1              ; =-1
1002457d0:     	ldrb	w17, [x16, x1]
1002457d4:     	sub	w3, w17, #0x30
1002457d8:     	cmp	w3, #0x9
1002457dc:     	b.hi	0x10024582c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x290>
1002457e0:     	add	x16, x16, #0x1
1002457e4:     	sub	x15, x15, #0x1
1002457e8:     	cmp	x8, x15
1002457ec:     	b.ne	0x1002457d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x234>
1002457f0:     	str	x2, [x0, #0x70]
1002457f4:     	mov	x8, x2
1002457f8:     	subs	x16, x1, x10
1002457fc:     	b.eq	0x10024577c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x1e0>
100245800:     	mov	x8, x2
100245804:     	b	0x100245860 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x2c4>
100245808:     	str	x11, [x0, #0x70]
10024580c:     	mov	x8, #0x2                ; =2
100245810:     	movk	x8, #0x7ffc, lsl #48
100245814:     	strb	wzr, [x0, #0xd4]
100245818:     	mov	x0, x8
10024581c:     	ldp	x29, x30, [sp, #0x20]
100245820:     	ldp	x20, x19, [sp, #0x10]
100245824:     	add	sp, sp, #0x30
100245828:     	ret
10024582c:     	sub	x8, x1, x15
100245830:     	str	x8, [x0, #0x70]
100245834:     	cmp	w17, #0x65
100245838:     	b.ne	0x100245848 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x2ac>
10024583c:     	cmn	x15, #0x1
100245840:     	b.ne	0x100245700 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x164>
100245844:     	b	0x10024580c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x270>
100245848:     	cmn	x15, #0x1
10024584c:     	b.eq	0x10024580c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x270>
100245850:     	subs	x16, x1, x10
100245854:     	b.eq	0x100245700 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x164>
100245858:     	cmp	w17, #0x45
10024585c:     	b.eq	0x100245700 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x164>
100245860:     	sub	x15, x8, x11
100245864:     	cmp	x15, #0x9
100245868:     	b.hi	0x100245700 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x164>
10024586c:     	add	x17, x16, x15
100245870:     	cmp	x17, #0x11
100245874:     	b.hi	0x100245700 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x164>
100245878:     	cmp	x1, x10
10024587c:     	b.lo	0x10024591c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x380>
100245880:     	mov	x10, #0x0               ; =0
100245884:     	b.eq	0x1002458a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x308>
100245888:     	mov	w17, #0xa               ; =10
10024588c:     	ldrb	w3, [x14], #0x1
100245890:     	mul	x10, x10, x17
100245894:     	sub	w3, w3, #0x30
100245898:     	add	x10, x10, w3, uxtb
10024589c:     	subs	x16, x16, #0x1
1002458a0:     	b.ne	0x10024588c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x2f0>
1002458a4:     	cmp	x8, x1
1002458a8:     	b.ls	0x10024592c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x390>
1002458ac:     	cmp	x8, x2
1002458b0:     	b.hi	0x10024592c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x390>
1002458b4:     	mov	w14, #0xa               ; =10
1002458b8:     	ldrb	w16, [x12, x11]
1002458bc:     	mul	x10, x10, x14
1002458c0:     	sub	w16, w16, #0x30
1002458c4:     	add	x10, x10, w16, uxtb
1002458c8:     	add	x11, x11, #0x1
1002458cc:     	cmp	x8, x11
1002458d0:     	b.ne	0x1002458b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x31c>
1002458d4:     	mov	x11, #0x20000000000000  ; =9007199254740992
1002458d8:     	cmp	x10, x11
1002458dc:     	b.hi	0x100245700 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x164>
1002458e0:     	ucvtf	d0, x10
1002458e4:     	adrp	x8, 0x100c47000 <_PERRY_EMPTY_STRING+0x4d34>
1002458e8:     	add	x8, x8, #0x238
1002458ec:     	ldr	d1, [x8, x15, lsl #3]
1002458f0:     	fdiv	d0, d0, d1
1002458f4:     	b	0x1002456e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number+0x14c>
1002458f8:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002458fc:     	add	x3, x3, #0x710
100245900:     	mov	x0, x9
100245904:     	mov	x1, x8
100245908:     	bl	0x100b1360c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
10024590c:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245910:     	add	x3, x3, #0x6c8
100245914:     	mov	x0, x10
100245918:     	bl	0x100b1360c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
10024591c:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245920:     	add	x3, x3, #0x6f8
100245924:     	mov	x0, x10
100245928:     	bl	0x100b1360c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
10024592c:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245930:     	add	x3, x3, #0x6e0
100245934:     	mov	x0, x11
100245938:     	mov	x1, x8
10024593c:     	bl	0x100b1360c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
