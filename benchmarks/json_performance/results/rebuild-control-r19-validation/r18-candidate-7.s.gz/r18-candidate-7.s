
benchmarks/json_performance/.work/tape-batch-r18/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100845294 <_js_json_parse>:
100845294:     	stp	x29, x30, [sp, #-0x10]!
100845298:     	mov	x29, sp
10084529c:     	cbz	x0, 0x1008452f4 <_js_json_parse+0x60>
1008452a0:     	ldr	w1, [x0, #0x4]
1008452a4:     	cmp	w1, #0x2
1008452a8:     	b.eq	0x1008452b8 <_js_json_parse+0x24>
1008452ac:     	cbz	w1, 0x1008452f4 <_js_json_parse+0x60>
1008452b0:     	ldrb	w8, [x0, #0x14]
1008452b4:     	b	0x1008452d8 <_js_json_parse+0x44>
1008452b8:     	ldrb	w8, [x0, #0x14]
1008452bc:     	cmp	w8, #0x7b
1008452c0:     	b.ne	0x1008452d8 <_js_json_parse+0x44>
1008452c4:     	ldrb	w8, [x0, #0x15]
1008452c8:     	cmp	w8, #0x7d
1008452cc:     	b.ne	0x1008452e4 <_js_json_parse+0x50>
1008452d0:     	ldp	x29, x30, [sp], #0x10
1008452d4:     	b	0x1004ed5c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
1008452d8:     	orr	w8, w8, #0x20
1008452dc:     	cmp	w8, #0x7b
1008452e0:     	b.ne	0x1008452ec <_js_json_parse+0x58>
1008452e4:     	ldp	x29, x30, [sp], #0x10
1008452e8:     	b	0x100506a38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
1008452ec:     	ldp	x29, x30, [sp], #0x10
1008452f0:     	b	0x1005090b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
1008452f4:     	adrp	x0, 0x100c76000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x710c>
1008452f8:     	add	x0, x0, #0x3d1
1008452fc:     	mov	w1, #0x1c               ; =28
100845300:     	bl	0x1005094e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
