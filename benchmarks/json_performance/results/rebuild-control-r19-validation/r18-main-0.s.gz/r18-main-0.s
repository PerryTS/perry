
benchmarks/json_performance/.work/tape-batch-r18/main-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100244768 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array>:
100244768:     	sub	sp, sp, #0x40
10024476c:     	stp	x22, x21, [sp, #0x10]
100244770:     	stp	x20, x19, [sp, #0x20]
100244774:     	stp	x29, x30, [sp, #0x30]
100244778:     	add	x29, sp, #0x30
10024477c:     	mov	x19, x0
100244780:     	ldp	x22, x8, [x0, #0x68]
100244784:     	add	x21, x8, #0x1
100244788:     	str	x21, [x0, #0x70]
10024478c:     	cmp	x21, x22
100244790:     	b.hs	0x1002447c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x60>
100244794:     	ldr	x8, [x19, #0x60]
100244798:     	mov	x9, #0x2600             ; =9728
10024479c:     	movk	x9, #0x1, lsl #32
1002447a0:     	ldrb	w10, [x8, x21]
1002447a4:     	cmp	w10, #0x20
1002447a8:     	b.hi	0x1002447c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x60>
1002447ac:     	lsr	x10, x9, x10
1002447b0:     	tbz	w10, #0x0, 0x1002447c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x60>
1002447b4:     	add	x21, x21, #0x1
1002447b8:     	str	x21, [x19, #0x70]
1002447bc:     	cmp	x22, x21
1002447c0:     	b.ne	0x1002447a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x38>
1002447c4:     	mov	x21, x22
1002447c8:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1002447cc:     	add	x0, x0, #0xce8
1002447d0:     	ldr	x8, [x0]
1002447d4:     	blr	x8
1002447d8:     	ldrb	w8, [x0, #0x20]
1002447dc:     	cbnz	w8, 0x100244880 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x118>
1002447e0:     	ldr	x8, [x0]
1002447e4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1002447e8:     	cmp	x8, x9
1002447ec:     	b.hs	0x1002448b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x148>
1002447f0:     	ldr	x1, [x0, #0x18]
1002447f4:     	subs	x8, x22, x21
1002447f8:     	b.ls	0x100244868 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x100>
1002447fc:     	ldr	x9, [x19, #0x60]
100244800:     	ldrb	w9, [x9, x21]
100244804:     	cmp	w9, #0x7b
100244808:     	b.ne	0x100244868 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x100>
10024480c:     	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
100244810:     	movk	x9, #0xaaab
100244814:     	umulh	x8, x8, x9
100244818:     	lsr	x8, x8, #6
10024481c:     	mov	w9, #0x10               ; =16
100244820:     	cmp	x8, #0x10
100244824:     	csel	x8, x8, x9, hi
100244828:     	mov	w9, #0x4000             ; =16384
10024482c:     	cmp	x8, #0x4, lsl #12       ; =0x4000
100244830:     	csel	x2, x8, x9, lo
100244834:     	mov	x0, sp
100244838:     	mov	x20, x1
10024483c:     	add	x1, x19, #0x20
100244840:     	bl	0x100235ad0 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray3new>
100244844:     	mov	x1, sp
100244848:     	mov	x0, x19
10024484c:     	mov	x2, x20
100244850:     	bl	0x100244e40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser16parse_array_tail>
100244854:     	ldp	x29, x30, [sp, #0x30]
100244858:     	ldp	x20, x19, [sp, #0x20]
10024485c:     	ldp	x22, x21, [sp, #0x10]
100244860:     	add	sp, sp, #0x40
100244864:     	ret
100244868:     	mov	x0, x19
10024486c:     	ldp	x29, x30, [sp, #0x30]
100244870:     	ldp	x20, x19, [sp, #0x20]
100244874:     	ldp	x22, x21, [sp, #0x10]
100244878:     	add	sp, sp, #0x40
10024487c:     	b	0x1002452c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_array_prefix>
100244880:     	cmp	w8, #0x1
100244884:     	b.ne	0x1002448bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x154>
100244888:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
10024488c:     	add	x1, x1, #0x998
100244890:     	mov	x20, x0
100244894:     	bl	0x100a2035c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100244898:     	mov	x0, x20
10024489c:     	strb	wzr, [x20, #0x20]
1002448a0:     	ldr	x8, [x20]
1002448a4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1002448a8:     	cmp	x8, x9
1002448ac:     	b.lo	0x1002447f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array+0x88>
1002448b0:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
1002448b4:     	add	x0, x0, #0x4a0
1002448b8:     	bl	0x100b1265c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1002448bc:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
1002448c0:     	add	x0, x0, #0xc18
1002448c4:     	bl	0x100b5851c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
