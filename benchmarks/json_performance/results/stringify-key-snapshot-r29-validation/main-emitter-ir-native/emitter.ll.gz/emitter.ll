; ModuleID = '/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/stringify-key-snapshot-r29/main-emitter-ir-native/.perry-trace/llvm/test_json_string_emitters_ts.ll'
source_filename = "perry_module"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx15.0.0"

module asm ".no_dead_strip __LLVM_StackMaps"

@test_json_string_emitters_ts_.str.0 = private unnamed_addr constant [88 x i8] c"/Users/amlug/projects/perry/json-merged-pr10022/test-files/test_json_string_emitters.ts\00"
@test_json_string_emitters_ts_.str.0.bytes = private unnamed_addr constant [5 x i8] c"text\00"
@test_json_string_emitters_ts_.str.1.bytes = private unnamed_addr constant [19 x i8] c"callback survivor \00"
@test_json_string_emitters_ts_.str.2.bytes = private unnamed_addr constant [26 x i8] c"{\22text\22:\22callback string \00"
@test_json_string_emitters_ts_.str.3.bytes = private unnamed_addr constant [3 x i8] c"id\00"
@test_json_string_emitters_ts_.str.4.bytes = private unnamed_addr constant [3 x i8] c"\22}\00"
@test_json_string_emitters_ts_.str.5.bytes = private unnamed_addr constant [6 x i8] c"short\00"
@test_json_string_emitters_ts_.str.6.bytes = private unnamed_addr constant [5 x i8] c"abcd\00"
@test_json_string_emitters_ts_.str.7.bytes = private unnamed_addr constant [1 x i8] zeroinitializer
@test_json_string_emitters_ts_.str.8.bytes = private unnamed_addr constant [2 x i8] c"a\00"
@test_json_string_emitters_ts_.str.9.bytes = private unnamed_addr constant [6 x i8] c"abcde\00"
@test_json_string_emitters_ts_.str.10.bytes = private unnamed_addr constant [7 x i8] c"abcdef\00"
@test_json_string_emitters_ts_.str.11.bytes = private unnamed_addr constant [16 x i8] c"plain heap text\00"
@test_json_string_emitters_ts_.str.12.bytes = private unnamed_addr constant [13 x i8] c"\E6\9D\B1\E4\BA\AC\F0\9F\99\82\C3\A9\00"
@test_json_string_emitters_ts_.str.13.bytes = private unnamed_addr constant [13 x i8] c"line\0Aquote\22\\\00"
@test_json_string_emitters_ts_.str.14.bytes = private unnamed_addr constant [4 x i8] c"\ED\A0\80\00"
@test_json_string_emitters_ts_.str.15.bytes = private unnamed_addr constant [4 x i8] c"\ED\B0\80\00"
@test_json_string_emitters_ts_.str.16.bytes = private unnamed_addr constant [5 x i8] c"\F0\90\80\80\00"
@test_json_string_emitters_ts_.str.17.bytes = private unnamed_addr constant [9 x i8] c"{\22text\22:\00"
@test_json_string_emitters_ts_.str.18.bytes = private unnamed_addr constant [17 x i8] c",\22short\22:\22abcd\22}\00"
@test_json_string_emitters_ts_.str.19.bytes = private unnamed_addr constant [7 x i8] c"pretty\00"
@test_json_string_emitters_ts_.str.20.bytes = private unnamed_addr constant [9 x i8] c"callback\00"
@test_json_string_emitters_ts_.str.21.bytes = private unnamed_addr constant [16 x i8] c"callback-pretty\00"
@test_json_string_emitters_ts_.str.22.bytes = private unnamed_addr constant [3 x i8] c"\0A\22\00"
@test_json_string_emitters_ts_.str.23.bytes = private unnamed_addr constant [2 x i8] c"\\\00"
@test_json_string_emitters_ts_.str.24.bytes = private unnamed_addr constant [15 x i8] c"mutated-pretty\00"
@test_json_string_emitters_ts_.str.25.bytes = private unnamed_addr constant [17 x i8] c"mutated-callback\00"
@test_json_string_emitters_ts_.str.26.bytes = private unnamed_addr constant [7 x i8] c"{\22id\22:\00"
@test_json_string_emitters_ts_.str.27.bytes = private unnamed_addr constant [40 x i8] c",\22text\22:\22source token\22,\22short\22:\22short\22}\00"
@test_json_string_emitters_ts_.str.28.bytes = private unnamed_addr constant [7 x i8] c"length\00"
@test_json_string_emitters_ts_.str.29.bytes = private unnamed_addr constant [19 x i8] c"callback string 47\00"
@test_json_string_emitters_ts_.str.30.bytes = private unnamed_addr constant [33 x i8] c"retained callback output changed\00"
@test_json_string_emitters_ts_.str.31.bytes = private unnamed_addr constant [9 x i8] c"retained\00"
@perry_class_keys_packed_test_json_string_emitters_ts__0 = private unnamed_addr constant [9 x i8] c"id\00text\00\00"
@test_json_string_emitters_ts_.str.1 = private unnamed_addr constant [9 x i8] c"identity\00"
@test_json_string_emitters_ts_.str.2 = private unnamed_addr constant [15 x i8] c"allocateString\00"
@test_json_string_emitters_ts_.str.3 = private unnamed_addr constant [33 x i8] c"new __AnonShape_6ef7d34fbe1f1d2c\00"
@test_json_string_emitters_ts_.str.4 = private unnamed_addr constant [66 x i8] c"function identity(key: string, value: any): any { return value; }\00"
@test_json_string_emitters_ts_.str.5 = private unnamed_addr constant [395 x i8] c"function allocateString(key: string, value: any): any {\0A    if (key === 'text') {\0A        const churn: any[] = [];\0A        for (let i = 0; i < 48; i++) churn.push({id: i, text: 'callback survivor ' + i});\0A        const parsed: any = JSON.parse('{\22text\22:\22callback string ' + churn[47].id + '\22}');\0A        return parsed.text;\0A    }\0A    if (key === 'short') return 'a' + 'bcd';\0A    return value;\0A}\00"
@PERRY_SYMBOL_PROPERTY_IC_EPOCH = external global i64
@PERRY_GC_POLL_ARMED = external global i32
@PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD = external global [65536 x i8]
@PERRY_PER_OBJECT_LAYOUTS_ANY = external global i32
@PERRY_LAYOUT_ADDR_FILTER = external global [64 x i64]
@PERRY_YOUNG_LAYOUT_RECORDS = external global i32
@PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED = external global i8
@PERRY_ARRAY_PROTO_ITERATOR_PATCHED = external global i8
@PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT = external global i32
@PERRY_HOT_TSD_KEY = external global i64
@PERRY_TA_KIND_CACHE = external global [64 x i64]
@PERRY_U8_INLINE_CACHE = external global [64 x i64]
@PERRY_TA_VIEW_GUARD = external global i64
@perry_null_guard_zero_test_json_string_emitters_ts = internal global i32 0
@perry_class_keys_test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c = internal global i64 0
@perry_class_shape_id_test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c = global i32 0
@perry_class_header_image_test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c = internal global <2 x i64> zeroinitializer
@perry_ic_test_json_string_emitters_ts__3 = private global ptr null
@perry_ic_test_json_string_emitters_ts__5 = private global ptr null
@perry_concat_site_test_json_string_emitters_ts__0 = private global [32 x i64] zeroinitializer
@perry_ic_test_json_string_emitters_ts__9 = private global ptr null
@perry_ic_test_json_string_emitters_ts__11 = private global ptr null
@perry_concat_site_test_json_string_emitters_ts__6 = private global [32 x i64] zeroinitializer
@perry_ic_test_json_string_emitters_ts__14 = private global ptr null
@perry_ic_test_json_string_emitters_ts__17 = private global ptr null
@perry_ic_test_json_string_emitters_ts__18 = private global ptr null
@perry_ic_test_json_string_emitters_ts__20 = private global ptr null
@perry_ic_test_json_string_emitters_ts__21 = private global ptr null
@perry_ic_test_json_string_emitters_ts__23 = private global ptr null
@perry_ic_test_json_string_emitters_ts__24 = private global ptr null
@perry_ic_test_json_string_emitters_ts__27 = private global ptr null
@perry_ic_test_json_string_emitters_ts__29 = private global ptr null
@perry_ic_test_json_string_emitters_ts__31 = private global ptr null
@perry_ic_test_json_string_emitters_ts__33 = private global ptr null
@perry_ic_test_json_string_emitters_ts__35 = private global ptr null
@perry_ic_test_json_string_emitters_ts__36 = private global ptr null
@test_json_string_emitters_ts_.str.0.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.1.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.2.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.3.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.4.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.5.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.6.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.7.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.8.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.9.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.10.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.11.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.12.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.13.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.14.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.15.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.16.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.17.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.18.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.19.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.20.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.21.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.22.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.23.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.24.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.25.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.26.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.27.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.28.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.29.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.30.handle = internal global double 0.000000e+00
@test_json_string_emitters_ts_.str.31.handle = internal global double 0.000000e+00
@perry_typed_shape_raw_f64_mask_test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c = private unnamed_addr constant [1 x i64] [i64 1]
@perry_typed_shape_mask_test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c = private unnamed_addr constant [1 x i64] [i64 2]

declare void @js_gc_init()

declare void @js_typed_feedback_maybe_dump_trace()

declare void @js_set_process_entry_path(ptr, i32)

declare void @js_stdlib_init_dispatch()

declare void @perry_app_group_init(ptr, i32)

declare void @perry_update_notify_startup(ptr, i32)

declare void @perry_macos_bundle_chdir()

declare i32 @perry_i18n_locale_index_for(i64, i32)

declare void @perry_i18n_init(ptr, ptr, i32, i32)

declare void @perry_i18n_set_currencies(ptr, i32)

declare i32 @perry_i18n_plural_category(i32, double)

declare void @js_register_function_name_static(ptr, ptr, i32)

declare void @js_register_function_name(ptr, ptr, i32)

declare void @js_register_function_source_static(ptr, ptr, i32, i32)

declare void @js_register_function_source(ptr, ptr, i32, i32)

declare void @js_console_log_dynamic(double)

declare void @js_console_log_number(double)

declare void @js_console_error_dynamic(double)

declare void @js_console_error_number(double)

declare void @js_console_warn_dynamic(double)

declare void @js_console_warn_number(double)

declare void @js_console_dir_with_options(double, double)

declare double @js_console_method_by_value(double)

declare double @js_nanbox_string(i64)

; Function Attrs: nounwind willreturn
declare double @js_nanbox_pointer(i64) #0

; Function Attrs: nounwind willreturn
declare i64 @js_nanbox_get_pointer(double) #0

declare double @js_native_handle_new_owned(i64, i64, i32, i32, ptr, ptr, i64)

declare double @js_native_handle_new_borrowed(i64, i64, i32, i32, ptr, i64)

declare i64 @js_native_handle_unwrap(double, i64, i32, i32, i32)

declare i64 @js_string_from_bytes(ptr, i32)

declare i64 @js_string_from_wtf8_bytes(ptr, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_is_truthy(double) #0

declare double @js_native_abi_check_f64(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_f64_arg_guard(double) #0

declare double @js_typed_f64_arg_to_raw(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_string_arg_guard(double) #0

declare i64 @js_typed_string_arg_to_raw(double)

declare i32 @js_param_type_guard(double, ptr, i32)

declare float @js_native_abi_check_f32(double)

declare i8 @js_native_abi_check_i8(double)

declare i16 @js_native_abi_check_i16(double)

declare i32 @js_native_abi_check_i32(double)

declare i64 @js_native_abi_check_i64(double)

declare i8 @js_native_abi_check_u8(double)

declare i16 @js_native_abi_check_u16(double)

declare i32 @js_native_abi_check_u32(double)

declare i64 @js_native_abi_check_u64(double)

declare i64 @js_native_abi_check_usize(double)

declare i64 @js_native_abi_check_isize(double)

declare double @js_native_abi_materialize_i64(i64)

declare double @js_native_abi_materialize_u64(i64)

declare i64 @js_native_abi_check_string_ptr(double)

declare i64 @js_native_abi_check_ptr(double)

declare ptr @js_native_abi_check_buffer_data_ptr(double)

declare i64 @js_native_abi_check_buffer_byte_len(double)

declare i64 @js_native_abi_check_promise(double)

declare i64 @js_native_abi_check_pod_object(double)

declare double @js_date_now()

declare void @js_gc_register_global_root(i64)

declare i64 @js_string_concat(i64, i64)

declare double @js_string_concat_box(double, double)

declare i64 @js_jsvalue_to_string(double)

declare i64 @js_jsvalue_to_string_method(double)

declare i64 @js_jsvalue_to_string_coerce(double)

declare i64 @js_string_concat_value(i64, double)

declare double @js_string_concat_site_value(i64, i64, double)

declare i64 @js_value_concat_string(double, i64)

declare double @js_string_concat_value_box(i64, double)

declare double @js_string_add_value(double, double)

declare double @js_value_add_string(double, double)

declare i64 @js_string_concat_chain(i64, i32)

declare i64 @js_string_append_chain(i64, i32)

declare i64 @js_string_append(i64, i64)

declare i64 @js_string_append_known_heap(i64, i64)

declare i32 @js_string_index_of(i64, i64)

declare i32 @js_string_index_of_from(i64, i64, i32)

declare i32 @js_string_position_to_index(double)

declare i64 @js_string_slice(i64, i32, i32)

declare i64 @js_string_substring(i64, i32, i32)

declare i64 @js_string_substr(i64, double, double)

declare i64 @js_string_split(i64, i64)

declare i64 @js_string_split_n(i64, i64, i32)

declare double @js_string_split_part_value(i64, i64, i32)

declare double @js_string_split_part_utf16_length(i64, i64, i32)

declare double @js_string_to_upper_case_split_part_utf16_length(i64, i64, i32)

declare i32 @js_string_to_upper_case_index_of(i64, i64)

declare i64 @js_string_split_value(i64, double, double)

declare double @js_math_trunc(double)

declare double @js_math_round(double)

declare double @js_math_sign(double)

declare double @js_math_imul(double, double)

declare double @js_math_pow(double, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.ceil.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.copysign.f64(double, double) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.aarch64.fjcvtzs(double) #3

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #5

declare i64 @js_json_stringify(double, i32)

declare i64 @js_map_alloc(i32)

declare i64 @js_text_encoder_encode_into_llvm(double, double)

declare i64 @js_value_typeof(double)

declare i32 @js_value_typeof_tag(double)

declare i32 @js_string_starts_with(i64, i64)

declare i32 @js_string_ends_with(i64, i64)

declare i64 @js_string_search_value_to_string(double, i32)

declare i32 @js_string_starts_with_at(i64, i64, i32)

declare i32 @js_string_ends_with_at(i64, i64, i32)

declare i64 @js_closure_alloc(ptr, i32)

declare i64 @js_closure_alloc_init(ptr, i32, ptr)

declare i64 @js_closure_alloc_singleton(ptr)

declare i64 @js_closure_alloc_with_captures_singleton(ptr, i32, ptr)

declare void @js_closure_set_capture_bits(i64, i32, i64)

declare void @js_closure_set_box_capture_ptr(i64, i32, i64)

declare i64 @js_closure_get_capture_bits(i64, i32)

declare void @js_closure_set_capture_f64(i64, i32, double)

declare double @js_closure_get_capture_f64(i64, i32)

declare void @js_register_closure_rest(ptr, i32)

declare void @js_register_closure_synthetic_arguments(ptr, i32)

declare void @js_register_closure_rest_and_arguments(ptr, i32)

declare void @js_register_closure_arity(ptr, i32)

declare void @js_register_closure_length(ptr, i32)

declare void @js_register_closure_arrow_function(ptr)

declare void @js_register_closure_trusted_direct(ptr, ptr, i32, i64)

declare void @js_register_closure_versioned_loop_direct(ptr, ptr, i32, i64)

declare ptr @js_closure_resolve_versioned_loop_direct_call(i64, i32)

declare void @js_register_closure_strict_function(ptr)

declare void @js_register_closure_async_function(ptr)

declare void @js_register_closure_generator_function(ptr)

declare void @js_register_closure_async_generator_function(ptr)

declare i64 @js_closure_unbox_callee_checked(double)

declare i64 @js_closure_unbox_callee_checked_rebind(double, double)

declare double @js_closure_call0(i64)

declare double @js_closure_call1(i64, double)

declare double @js_closure_call1_receiverless(i64, double)

declare double @js_closure_call2(i64, double, double)

declare double @js_closure_call3(i64, double, double, double)

declare ptr @js_closure_resolve_arrow_direct_call(i64, i32)

declare double @js_closure_call4(i64, double, double, double, double)

declare double @js_closure_call5(i64, double, double, double, double, double)

declare double @js_closure_call6(i64, double, double, double, double, double, double)

declare double @js_closure_call7(i64, double, double, double, double, double, double, double)

declare double @js_closure_call8(i64, double, double, double, double, double, double, double, double)

declare double @js_closure_call9(i64, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call10(i64, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call11(i64, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call12(i64, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call13(i64, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call14(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call15(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call16(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare i64 @js_array_map(i64, i64)

declare void @js_array_map_discard(i64, i64)

declare i64 @js_array_filter(i64, i64)

declare i64 @js_array_concat(i64, i64)

declare i64 @js_array_concat_new(i64, i64)

declare i64 @js_error_new()

declare i64 @js_error_new_with_message(i64)

declare i64 @js_error_new_from_value(double)

declare i64 @js_error_new_kind_from_value(i32, double)

declare i64 @js_error_new_with_cause_from_value(double, double)

declare i64 @js_error_new_kind_with_options_from_value(i32, double, double)

declare double @js_assert_assertion_error_ctor(double)

declare double @js_assert_assert_ctor(double)

declare void @js_throw_type_error_property_access(i32, ptr, i64)

declare void @js_throw_type_error_not_a_function(ptr, i64, ptr, i64)

declare void @js_throw_error_with_code(ptr, i64, ptr, i64, i32)

declare i64 @js_map_set(i64, double, double)

declare i64 @js_map_set_string_number(i64, i64, double)

declare i64 @js_map_set_string_key(i64, i64, double)

declare i64 @js_map_set_string_i32(i64, i64, i32)

declare i64 @js_map_set_string_u32(i64, i64, i32)

declare i64 @js_map_set_string_f32(i64, i64, float)

declare i64 @js_map_set_string_bool(i64, i64, i32)

declare i64 @js_map_set_string_string(i64, i64, i64)

declare i64 @js_map_set_number_key(i64, double, double)

declare double @js_map_get(i64, double)

declare double @js_declared_map_get(double, double)

declare double @js_map_get_string_key(i64, i64)

declare double @js_map_get_number_key(i64, double)

declare i32 @js_map_has(i64, double)

declare i32 @js_map_has_string_key(i64, i64)

declare i32 @js_map_has_number_key(i64, double)

declare i32 @js_map_delete(i64, double)

declare i32 @js_map_delete_string_key(i64, i64)

declare i32 @js_map_delete_number_key(i64, double)

declare i64 @js_object_keys(i64)

declare i64 @js_object_keys_value(double)

declare i64 @js_for_in_keys_value(double)

declare i64 @js_for_in_keys_stable_value(double)

declare double @js_is_finite(double)

declare i32 @js_is_undefined_or_bare_nan(double)

declare double @js_math_min_array(i64)

declare double @js_math_max_array(i64)

declare double @js_math_min2(double, double)

declare double @js_math_max2(double, double)

declare i64 @js_string_coerce(double)

declare i64 @js_string_coerce_method_this(double, ptr, i64)

declare i64 @js_array_slice(i64, i32, i32)

declare i64 @js_array_slice_values(i64, double, double)

declare double @js_array_shift_f64(i64)

declare i64 @js_set_alloc(i32)

declare i64 @js_set_from_array(i64)

declare i64 @js_set_from_iterable(double)

declare i64 @js_map_from_array(i64)

declare i64 @js_map_from_iterable(double)

declare double @js_object_has_property(double, double)

declare double @js_in_operator(double, double)

declare double @js_private_brand_check(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_guard(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_brand_add(double, i32)

declare double @js_private_field_add(double, i32, double, double)

declare double @js_class_field_add(double, double, double)

declare double @js_class_computed_field_key(double, i32, ptr, i64)

declare double @js_fs_to_unix_timestamp(double)

declare i32 @js_fs_write_file_sync(double, double)

declare i32 @js_fs_write_file_sync_options(double, double, double)

declare i32 @js_fs_append_file_sync(double, double)

declare i32 @js_fs_append_file_sync_options(double, double, double)

declare i32 @js_fs_exists_sync(double)

declare i64 @js_fs_read_file_sync(double)

declare double @js_fs_read_file_dispatch(double, double)

declare double @js_fs_open_as_blob(double, double)

declare double @js_fs_promises_read_file(double, double)

declare double @js_fs_promises_write_file(double, double, double)

declare double @js_fs_promises_append_file(double, double, double)

declare double @js_fs_promises_mkdir(double, double)

declare double @js_fs_promises_rmdir(double, double)

declare i32 @js_fs_mkdir_sync(double)

declare i32 @js_fs_mkdir_sync_options(double, double)

declare i32 @js_fs_unlink_sync(double)

declare double @js_fs_readdir_sync(double, double)

declare double @js_fs_stat_sync(double)

declare double @js_fs_stat_sync_options(double, double)

declare double @js_fs_lstat_sync(double)

declare double @js_fs_lstat_sync_options(double, double)

declare i32 @js_fs_rename_sync(double, double)

declare i32 @js_fs_copy_file_sync(double, double)

declare i32 @js_fs_copy_file_sync_flags(double, double, double)

declare i32 @js_fs_cp_sync(double, double)

declare i32 @js_fs_cp_sync_options(double, double, double)

declare i32 @js_fs_chmod_sync(double, double)

declare i32 @js_fs_chown_sync(double, double, double)

declare i32 @js_fs_lchown_sync(double, double, double)

declare i32 @js_fs_lchmod_sync(double, double)

declare i32 @js_fs_truncate_sync(double, double)

declare i32 @js_fs_ftruncate_sync(double, double)

declare i32 @js_fs_fsync_sync(double)

declare i32 @js_fs_fdatasync_sync(double)

declare i32 @js_fs_fchmod_sync(double, double)

declare i32 @js_fs_fchown_sync(double, double, double)

declare double @js_fs_fstat_sync(double)

declare double @js_fs_fstat_sync_options(double, double)

declare i32 @js_fs_utimes_sync(double, double, double)

declare i32 @js_fs_lutimes_sync(double, double, double)

declare i32 @js_fs_futimes_sync(double, double, double)

declare double @js_fs_readv_sync(double, double, double)

declare double @js_fs_writev_sync(double, double, double)

declare double @js_fs_statfs_sync(double)

declare double @js_fs_statfs_sync_options(double, double)

declare double @js_fs_opendir_sync(double)

declare double @js_fs_glob_sync(double)

declare double @js_fs_glob_sync_options(double, double)

declare i32 @js_fs_link_sync(double, double)

declare i32 @js_fs_symlink_sync(double, double)

declare double @js_fs_symlink_callback(double, double, double, double)

declare i64 @js_fs_readlink_sync(double)

declare i64 @js_fs_readlink_sync_options(double, double)

declare double @js_fs_readlink_dispatch(double, double)

declare double @js_fs_open_sync(double, double)

declare i32 @js_fs_close_sync(double)

declare double @js_fs_read_sync(double, double, double, double, double)

declare double @js_fs_read_sync_options(double, double, double)

declare double @js_fs_write_sync(double, double)

declare double @js_fs_write_string_sync_options(double, double, double)

declare double @js_fs_write_buffer_sync(double, double, double, double, double)

declare double @js_fs_write_sync_options_dispatch(double, double, double)

declare i32 @js_fs_access_sync(double)

declare i32 @js_fs_access_sync_mode(double, double)

declare double @js_fs_access_sync_throw(double)

declare double @js_fs_access_sync_throw_mode(double, double)

declare i64 @js_fs_realpath_sync(double)

declare double @js_fs_realpath_dispatch(double, double)

declare i64 @js_fs_mkdtemp_sync(double)

declare i64 @js_fs_mkdtemp_sync_options(double, double)

declare double @js_fs_mkdtemp_dispatch(double, double)

declare double @js_fs_mkdtemp_disposable_sync(double, double)

declare i32 @js_fs_rmdir_sync(double)

declare i32 @js_fs_rmdir_sync_options(double, double)

declare i32 @js_fs_rm_recursive(double)

declare i32 @js_fs_rm_recursive_options(double, double)

declare double @js_fs_create_write_stream(double, double)

declare double @js_fs_create_read_stream(double, double)

declare double @js_fs_utf8_stream_new(double)

declare double @js_fs_utf8_stream_call_without_new(double)

declare double @js_fs_utf8_stream_write(double, double)

declare double @js_fs_utf8_stream_flush(double, double)

declare double @js_fs_utf8_stream_flush_sync(double)

declare double @js_fs_utf8_stream_end(double, double)

declare double @js_fs_utf8_stream_destroy(double)

declare double @js_fs_utf8_stream_reopen(double, double)

declare double @js_fs_utf8_stream_on(double, double, double)

declare double @js_fs_utf8_stream_once(double, double, double)

declare double @js_fs_utf8_stream_off(double, double, double)

declare double @js_fs_utf8_stream_remove_all(double, double)

declare double @js_fs_utf8_stream_listener_count(double, double)

declare double @js_fs_utf8_stream_emit(double, double, double)

declare double @js_fs_read_file_callback(double, double, double)

declare double @js_fs_stats_is_file(double)

declare double @js_fs_stats_is_directory(double)

declare i64 @js_fs_read_file_binary(double)

declare double @js_number_coerce(double)

declare double @js_math_to_number(double)

declare i64 @js_set_add(i64, double)

declare i64 @js_set_add_string(i64, i64)

declare i64 @js_set_add_number(i64, double)

declare i64 @js_set_add_i32(i64, i32)

declare i64 @js_set_add_u32(i64, i32)

declare i64 @js_set_add_f32(i64, float)

declare i64 @js_set_add_bool(i64, i32)

declare i32 @js_set_has(i64, double)

declare double @js_readonly_set_has(double, double)

declare i32 @js_set_has_string(i64, i64)

declare i32 @js_set_has_number(i64, double)

declare i32 @js_set_has_i32(i64, i32)

declare i32 @js_set_has_u32(i64, i32)

declare i32 @js_set_has_f32(i64, float)

declare i32 @js_set_has_bool(i64, i32)

declare i32 @js_set_delete(i64, double)

declare i32 @js_set_delete_string(i64, i64)

declare i32 @js_set_delete_number(i64, double)

declare i32 @js_set_delete_i32(i64, i32)

declare i32 @js_set_delete_u32(i64, i32)

declare i32 @js_set_delete_f32(i64, float)

declare i32 @js_set_delete_bool(i64, i32)

declare i32 @js_set_size(i64)

declare i64 @js_set_union(i64, double)

declare i64 @js_set_intersection(i64, double)

declare i64 @js_set_difference(i64, double)

declare i64 @js_set_symmetric_difference(i64, double)

declare i32 @js_set_is_subset_of(i64, double)

declare i32 @js_set_is_superset_of(i64, double)

declare i32 @js_set_is_disjoint_from(i64, double)

declare i64 @js_string_to_lower_case(i64)

declare i64 @js_string_to_upper_case(i64)

declare i64 @js_string_to_locale_lower_case(i64, double)

declare i64 @js_string_to_locale_upper_case(i64, double)

declare void @js_string_validate_collator_args(double, double)

declare i64 @js_string_trim(i64)

declare i64 @js_string_trim_start(i64)

declare i64 @js_string_trim_end(i64)

declare i64 @js_string_big(i64)

declare i64 @js_string_blink(i64)

declare i64 @js_string_bold(i64)

declare i64 @js_string_fixed(i64)

declare i64 @js_string_italics(i64)

declare i64 @js_string_small(i64)

declare i64 @js_string_strike(i64)

declare i64 @js_string_sub(i64)

declare i64 @js_string_sup(i64)

declare i64 @js_string_anchor(i64, i64)

declare i64 @js_string_link(i64, i64)

declare i64 @js_string_fontcolor(i64, i64)

declare i64 @js_string_fontsize(i64, i64)

declare i64 @js_string_char_at(i64, i32)

declare double @js_string_index_get(i64, double)

declare double @js_string_index_get_boxed(double, double)

declare i32 @js_string_index_to_i32(double)

declare i32 @js_string_end_index_to_i32(double, i32)

declare double @js_typed_feedback_object_get_field_by_value_f64(i64, i64, double)

declare double @js_dyn_index_get(double, double)

declare double @js_packed_arraylike_index_get(double, double, ptr)

declare i32 @js_packed_arraylike_loop_guard(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_guard_live(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_revalidate_live(double, double, i32, ptr)

declare double @js_dyn_index_set(double, double, double)

declare double @js_dyn_index_set_strict(double, double, double, i32)

declare i64 @js_string_to_char_array(i64)

declare i64 @js_string_repeat(i64, double)

declare i64 @js_string_replace_string(i64, i64, i64)

declare i64 @js_string_replace_all_string(i64, i64, i64)

declare i32 @js_string_equals(i64, i64)

declare i32 @js_string_compare(i64, i64)

declare i32 @js_jsvalue_equals(double, double)

declare i32 @js_string_compare_value(double, double)

declare i64 @js_jsvalue_to_string_radix(double, double)

declare double @js_math_random()

declare double @js_webassembly_validate(double)

declare double @js_webassembly_compile(double)

declare double @js_webassembly_module_new(double)

declare double @js_webassembly_module_exports(double)

declare double @js_webassembly_module_imports(double)

declare double @js_webassembly_module_custom_sections(double, double)

declare double @js_webassembly_instantiate(double, double)

declare double @js_wasi_emit_warning()

declare double @js_webassembly_call_export_0(double, double)

declare double @js_webassembly_call_export_1(double, double, double)

declare double @js_webassembly_call_export_2(double, double, double, double)

declare double @js_webassembly_call_export_3(double, double, double, double, double)

declare double @js_webassembly_call_export_4(double, double, double, double, double, double)

declare void @js_console_log_spread(i64)

declare void @js_console_info_spread(i64)

declare void @js_console_debug_spread(i64)

declare void @js_console_error_spread(i64)

declare void @js_console_warn_spread(i64)

declare double @js_util_format(i64)

declare double @js_util_format_with_options(double, i64)

declare double @js_util_inspect(double, double)

declare double @js_util_debuglog(double, double)

declare double @js_util_diff(double, double)

declare double @js_util_inherits(double, double)

declare double @js_util_is_deep_strict_equal(double, double)

declare double @js_util_strip_vt_control_characters(double)

declare double @js_util_style_text(double, double, double)

declare double @js_util_get_call_sites(double, double)

declare double @js_util_promisify(double)

declare double @js_util_callbackify(double)

declare double @js_util_deprecate(double, double, double)

declare double @js_util_aborted(double, double)

declare double @js_util_transferable_abort_controller()

declare double @js_util_transferable_abort_signal(double)

declare double @js_util_parse_args(double)

declare double @js_boxed_number_new(double)

declare double @js_boxed_string_new(double, i32)

declare double @js_boxed_boolean_new(double)

declare double @js_util_types_is_arguments_object(double)

declare double @js_util_types_is_promise(double)

declare double @js_util_types_is_big_int_object(double)

declare double @js_util_types_is_symbol_object(double)

declare double @js_util_types_is_array_buffer(double)

declare double @js_util_types_is_shared_array_buffer(double)

declare double @js_util_types_is_any_array_buffer(double)

declare double @js_util_types_is_array_buffer_view(double)

declare double @js_util_types_is_data_view(double)

declare double @js_util_types_is_typed_array(double)

declare double @js_util_types_is_uint8_array(double)

declare double @js_util_types_is_int8_array(double)

declare double @js_util_types_is_int16_array(double)

declare double @js_util_types_is_uint16_array(double)

declare double @js_util_types_is_int32_array(double)

declare double @js_util_types_is_uint32_array(double)

declare double @js_util_types_is_float16_array(double)

declare double @js_util_types_is_float32_array(double)

declare double @js_util_types_is_float64_array(double)

declare double @js_util_types_is_uint8_clamped_array(double)

declare double @js_util_types_is_big_int64_array(double)

declare double @js_util_types_is_big_uint64_array(double)

declare double @js_util_types_is_map(double)

declare double @js_util_types_is_weak_map(double)

declare double @js_util_types_is_set(double)

declare double @js_util_types_is_weak_set(double)

declare double @js_util_types_is_date(double)

declare double @js_util_types_is_reg_exp(double)

declare double @js_util_types_is_async_function(double)

declare double @js_util_types_is_generator_function(double)

declare double @js_util_types_is_generator_object(double)

declare double @js_util_types_is_native_error(double)

declare double @js_util_types_is_number_object(double)

declare double @js_util_types_is_string_object(double)

declare double @js_util_types_is_boolean_object(double)

declare double @js_util_types_is_boxed_primitive(double)

declare double @js_util_types_is_external(double)

declare double @js_util_types_is_module_namespace_object(double)

declare double @js_util_types_is_key_object(double)

declare double @js_util_types_is_crypto_key(double)

declare double @js_util_types_is_proxy(double)

declare double @js_util_types_is_map_iterator(double)

declare double @js_util_types_is_set_iterator(double)

declare double @js_data_view_new(double, double, double)

declare double @js_data_view_get_direct(double, double, double, i32, i32)

declare double @js_data_view_set_direct(double, double, double, double, i32, i32)

declare i64 @js_getenv(i64)

declare double @js_getenv_value(i64)

declare void @js_setenv(i64, double)

declare void @js_removeenv(i64)

declare double @js_process_exit_code_get()

declare double @js_process_exit_code_set(double)

declare void @js_console_table(double)

declare void @js_console_table_with_properties(double, double)

declare void @js_console_trace(double)

declare void @js_console_trace_spread(i64)

declare i64 @js_process_cwd()

declare i64 @js_process_argv()

declare double @js_process_pid()

declare double @js_process_ppid()

declare double @js_process_uptime()

declare i64 @js_process_version()

declare double @js_process_versions()

declare double @js_process_memory_usage()

declare double @js_bigint_as_int_n_call(double, double)

declare double @js_bigint_as_uint_n_call(double, double)

declare double @js_v8_serialize(double)

declare double @js_v8_deserialize(double)

declare double @js_v8_get_heap_statistics()

declare double @js_v8_get_heap_code_statistics()

declare double @js_v8_get_heap_space_statistics()

declare double @js_v8_cached_data_version_tag()

declare double @js_v8_get_heap_snapshot(double)

declare double @js_v8_write_heap_snapshot(double, double)

declare double @js_v8_gc_profiler_new()

declare double @js_v8_gc_profiler_start(double)

declare double @js_v8_gc_profiler_stop(double)

declare double @js_v8_gc_profiler_report()

declare double @js_v8_serializer_new(double)

declare double @js_v8_deserializer_new(double)

declare double @js_v8_noop_undefined()

declare double @js_v8_is_building_snapshot()

declare double @js_v8_namespace(ptr, i64)

declare double @js_v8_throw_not_building_snapshot()

declare double @js_v8_promise_hook_register()

declare double @js_v8_promise_hooks_on_init(double)

declare double @js_v8_promise_hooks_on_before(double)

declare double @js_v8_promise_hooks_on_after(double)

declare double @js_v8_promise_hooks_on_settled(double)

declare double @js_v8_promise_hooks_create_hook(double)

declare double @js_process_thread_cpu_usage(double)

declare double @js_process_available_memory()

declare double @js_process_constrained_memory()

declare double @js_process_source_maps_enabled()

declare double @js_process_set_source_maps_enabled(double)

declare double @js_process_has_uncaught_exception_capture_callback()

declare double @js_process_set_uncaught_exception_capture_callback(double)

declare double @js_process_add_uncaught_exception_capture_callback(double)

declare double @js_process_getuid()

declare double @js_process_geteuid()

declare double @js_process_getgid()

declare double @js_process_getegid()

declare void @js_process_emit_warning(double, double, double)

declare double @js_process_cpu_usage(double)

declare double @js_process_resource_usage()

declare double @js_process_active_resources_info()

declare double @js_process_env()

declare double @js_process_hrtime_bigint()

declare double @js_process_hrtime(double)

declare double @js_process_title()

declare void @js_process_set_title(double)

declare void @js_process_chdir(i64)

declare void @js_process_chdir_jsv(double)

declare double @js_process_kill(double, double)

declare void @js_process_exit(double)

declare void @js_process_abort()

declare double @js_process_umask()

declare double @js_process_umask_set(double)

declare double @js_process_on(i64, i64)

declare double @js_process_add_listener(i64, i64)

declare double @js_process_once(i64, i64)

declare double @js_process_prepend_listener(i64, i64)

declare double @js_process_prepend_once_listener(i64, i64)

declare double @js_process_emit(i64, i64)

declare void @js_process_emit_before_exit(double)

declare void @js_process_emit_before_exit_pending()

declare void @js_process_run_exit_sequence()

declare void @js_process_run_finalization_exit()

declare void @js_trace_events_flush_output()

declare void @js_promise_report_unhandled_rejections()

declare i32 @js_process_pending_exit_code()

declare void @js_gc_release_current_thread_collection_side_allocations()

declare double @js_process_remove_listener(i64, i64)

declare double @js_process_off(i64, i64)

declare double @js_process_remove_all_listeners(i64)

declare double @js_process_listener_count(i64, i64)

declare i64 @js_process_listeners(i64)

declare i64 @js_process_raw_listeners(i64)

declare i64 @js_process_event_names()

declare double @js_process_set_max_listeners(double)

declare double @js_process_get_max_listeners()

declare double @js_process_get_builtin_module(double)

declare double @js_process_get_builtin_module_devirt(double)

declare double @js_process_execve(double, double, double)

declare double @js_module_is_builtin(double)

declare double @js_module_find_package_json(double, double, double)

declare double @js_module_find_source_map(double)

declare double @js_module_source_map_new(double, double)

declare double @js_module_register(double, double, double)

declare double @js_module_register_hooks(double)

declare void @js_process_next_tick(i64, i64)

declare double @js_process_stdin()

declare double @js_process_stdout()

declare double @js_process_stderr()

declare double @js_readline_set_raw_mode(double)

declare void @js_readline_stdin_on(i64, i64)

declare double @js_readline_stdin_remove_listener(i64, i64)

declare double @js_readline_stdin_pause()

declare double @js_readline_stdin_resume()

declare double @js_readline_stdin_unref()

declare double @js_readline_stdin_ref()

declare double @js_readline_stdin_destroy()

declare double @js_tty_isatty(double)

declare double @js_tty_read_stream_new(double)

declare double @js_tty_write_stream_new(double)

declare double @js_wasi_constructor_call(double)

declare double @js_process_stdin_isatty()

declare double @js_process_stdout_isatty()

declare double @js_process_stderr_isatty()

declare double @js_process_stdout_columns()

declare double @js_process_stdout_rows()

declare double @js_process_stdout_on(i64, i64)

declare i64 @js_os_platform()

declare i64 @js_os_arch()

declare i64 @js_os_type()

declare i64 @js_os_release()

declare i64 @js_os_hostname()

declare i64 @js_os_eol()

declare double @js_os_available_parallelism()

declare i64 @js_os_endianness()

declare i64 @js_os_dev_null()

declare i64 @js_os_machine()

declare i64 @js_os_loadavg()

declare i64 @js_os_version()

declare i64 @js_box_alloc_bits(i64)

declare i64 @js_box_get_bits(i64)

declare i64 @js_box_get_bits_named(i64, double)

declare void @js_box_set_bits(i64, i64)

declare i64 @js_box_get_bits_trusted(i64)

declare i64 @js_box_get_bits_trusted_named(i64, double)

declare void @js_box_set_bits_trusted_no_barrier(i64, i64)

declare i64 @js_box_alloc(double)

declare double @js_box_get(i64)

declare void @js_box_set(i64, double)

declare i64 @js_i32_box_alloc(i32)

declare i32 @js_i32_box_get(i64)

declare void @js_i32_box_set(i64, i32)

declare void @js_box_release(i64)

declare void @js_i32_box_release(i64)

declare void @js_bool_box_release(i64)

declare i64 @js_bool_box_alloc(i32)

declare i32 @js_bool_box_get(i64)

declare void @js_bool_box_set(i64, i32)

declare i64 @js_arguments_object_alloc(double, double, i32)

declare void @js_arguments_object_map_index(i64, i32, i64)

declare i64 @js_array_like_to_array(double)

declare i32 @js_object_get_class_id(i64)

declare i64 @js_object_alloc_with_parent(i32, i32, i32)

declare i64 @js_object_alloc_class_with_keys(i32, i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_dynamic_parent(i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_inline_keys(i32, i32, i32, i64)

declare i64 @js_object_alloc_class_inline_keys_stamped(i32, i32, i32, i64, i32)

declare i64 @js_build_class_keys_array(i32, i32, ptr, i32)

declare i32 @js_object_shape_id_for_keys(i64, i32)

declare i32 @js_gc_typed_shape_id_for_keys(i32, i64, i32, ptr, i32, ptr, i32)

declare ptr @js_inline_arena_state()

declare ptr @js_inline_arena_slow_alloc(ptr, i64, i64)

declare i32 @js_object_delete_field(i64, i64)

declare i32 @js_object_delete_field_value(double, i64)

declare i32 @js_object_delete_dynamic_value(double, double)

declare double @js_delete_result(i32, i32)

declare i64 @js_eq(i64, i64)

declare i64 @js_loose_eq(i64, i64)

declare i64 @js_number_to_fixed(double, double)

declare i64 @js_string_replace_regex(i64, i64, i64)

declare i64 @js_string_replace_all_regex(i64, i64, i64)

declare double @js_array_at(i64, double)

declare double @js_date_get_time(double)

declare double @js_date_get_full_year(double)

declare double @js_date_get_month(double)

declare double @js_date_get_date(double)

declare double @js_date_get_day(double)

declare double @js_date_get_hours(double)

declare double @js_date_get_minutes(double)

declare double @js_date_get_seconds(double)

declare double @js_date_get_milliseconds(double)

declare double @js_date_get_utc_day(double)

declare double @js_date_get_utc_full_year(double)

declare double @js_date_get_utc_month(double)

declare double @js_date_get_utc_date(double)

declare double @js_date_get_utc_hours(double)

declare double @js_date_get_utc_minutes(double)

declare double @js_date_get_utc_seconds(double)

declare double @js_date_get_utc_milliseconds(double)

declare double @js_date_value_of(double)

declare double @js_date_get_timezone_offset(double)

declare double @js_date_coerce_number(double)

declare double @js_rel_lt(double, double)

declare double @js_rel_le(double, double)

declare double @js_rel_gt(double, double)

declare double @js_rel_ge(double, double)

declare i64 @js_date_to_string(double)

declare i64 @js_date_to_iso_string(double)

declare i64 @js_date_to_iso_string_or_throw(double)

declare double @js_date_new_from_timestamp(double)

declare double @js_date_new_from_value(double)

declare i32 @js_array_indexOf_f64(i64, double)

declare i64 @js_array_indexOf_jsvalue(i64, double, double, i32)

declare i64 @js_array_last_index_of_jsvalue(i64, double, double, i32)

declare i32 @js_array_includes_f64(i64, double)

declare i32 @js_array_includes_jsvalue(i64, double, double, i32)

declare i32 @js_map_size(i64)

declare void @js_map_clear(i64)

declare void @js_set_clear(i64)

declare i64 @js_map_entries(i64)

declare i64 @js_map_keys(i64)

declare i64 @js_map_values(i64)

declare double @js_map_entry_key_at(i64, i32)

declare double @js_map_entry_value_at(i64, i32)

declare double @js_map_entry_key_raw_at(i64, i32)

declare double @js_map_entry_value_raw_at(i64, i32)

declare double @js_set_value_raw_at(i64, i32)

declare double @js_map_find_key_index(double, double)

declare double @js_set_find_value_index(double, double)

declare double @js_map_cursor_next(double, double, double)

declare double @js_map_compaction_epoch(double)

declare double @js_set_cursor_next(double, double, double)

declare double @js_set_compaction_epoch(double)

declare void @js_map_foreach(i64, double, double)

declare void @js_set_foreach(i64, double, double)

declare i64 @js_map_entries_iter_obj(i64)

declare i64 @js_map_keys_iter_obj(i64)

declare i64 @js_map_values_iter_obj(i64)

declare i64 @js_set_values_iter_obj(i64)

declare i64 @js_set_keys_iter_obj(i64)

declare i64 @js_set_entries_iter_obj(i64)

declare i64 @js_set_to_array(i64)

declare double @js_set_value_at(i64, i32)

declare i64 @js_array_splice(i64, i32, i32, ptr, i32, ptr)

declare i32 @js_array_splice_delete_count(double)

declare double @js_parse_int(i64, double)

declare double @js_parse_float(i64)

declare double @js_array_reduce(i64, i64, i32, double)

declare double @js_array_reduce_right(i64, i64, i32, double)

declare i64 @js_array_sort_default(i64)

declare i64 @js_array_reverse(i64)

declare double @js_array_reverse_value(double)

declare i64 @js_array_flat(i64)

declare i64 @js_array_flat_depth(i64, double)

declare i64 @js_array_flatMap(i64, i64)

declare i64 @js_array_sort_with_comparator(i64, i64)

declare i64 @js_validate_array_comparator(double)

declare i64 @js_validate_array_callback(double)

declare i64 @js_validate_array_map_callback(i64, double)

declare i64 @js_array_to_reversed(i64)

declare i64 @js_array_to_sorted_default(i64)

declare i64 @js_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_array_to_spliced(i64, double, double, ptr, i32)

declare i64 @js_array_with(i64, double, double)

declare i64 @js_array_copy_within(i64, double, double, i32, double)

declare double @js_array_copy_within_value(double, double, double, i32, double)

declare i64 @js_regexp_new(i64, i64)

declare i64 @js_regexp_new_site(i64, i64, i64)

declare i64 @js_regexp_new_factory_site(i64, i64, i64, i64)

declare i64 @js_regexp_site_test_new(i64, i64, i64)

declare double @js_regexp_site_factory_call_value(i64, double)

declare double @js_regexp_site_factory_call_method(i64, double, double)

declare double @js_regexp_site_test_get_method(i64, double)

declare double @js_regexp_site_test_dispatch(i64, double, double, double)

declare i64 @js_regexp_construct(double, double)

declare i64 @js_regexp_construct_call(double, double)

declare i32 @js_regexp_test(i64, i64)

declare double @js_regexp_escape(double)

declare i64 @js_get_string_pointer_unified(double)

declare i32 @js_switch_strict_equals(double, double)

declare i64 @js_value_to_str_ptr_for_ffi(double)

declare void @js_string_addref(i64)

declare void @js_string_addref_if_heap_string(double)

declare i64 @js_bigint_from_string(ptr, i32)

declare i64 @js_bigint_from_f64(double)

declare i64 @js_bigint_from_i128_parts(i64, i64)

declare i32 @js_bigint_cmp(i64, i64)

declare double @js_dynamic_add(double, double)

declare double @js_to_numeric(double)

declare double @js_numeric_step(double, i32)

declare i64 @js_box_capture_cell_ptr(i64)

declare double @js_dynamic_string_or_number_add(double, double)

declare double @js_dynamic_sub(double, double)

declare double @js_dynamic_mul(double, double)

declare double @js_dynamic_div(double, double)

declare double @js_dynamic_mod(double, double)

declare double @js_dynamic_bitand(double, double)

declare double @js_dynamic_bitor(double, double)

declare double @js_dynamic_bitxor(double, double)

declare double @js_dynamic_shl(double, double)

declare double @js_dynamic_shr(double, double)

declare double @js_dynamic_bitnot(double)

declare double @js_dynamic_pow(double, double)

declare double @js_dynamic_ushr(double, double)

declare double @js_instanceof(double, i32)

declare double @js_instanceof_dynamic(double, double)

declare double @js_instanceof_noncallable_rhs()

declare void @js_register_class_extends_error(i32)

declare void @js_register_class_extends_data_view(i32)

declare void @js_register_class_extends_typed_array(i32)

declare void @js_register_class_id(i32)

declare void @js_register_class_name(i32, ptr, i32)

declare void @js_register_class_source(i32, ptr, i32)

declare void @js_register_class_length(i32, i32)

declare void @js_register_anon_shape_class_id(i32)

declare double @js_get_global_this_builtin_value(ptr, i64)

declare double @js_promise_static_function_value(ptr, i64)

declare double @js_builtin_prototype_method_value(ptr, i64, ptr, i64)

declare void @js_register_class_parent(i32, i32)

declare void @js_register_class_generic_origin(i32, i32)

declare void @js_register_class_parent_dynamic(i32, double)

declare double @js_get_dynamic_parent_value(i32)

declare void @js_class_register_capture_values(i32, ptr, i64)

declare void @js_class_object_refresh_capture_values(double, i64, double)

declare void @js_tdz_suppress_begin()

declare void @js_tdz_suppress_end()

declare double @js_class_capture_value(i32, i32)

declare double @js_class_capture_value_for_receiver(double, i32, i32)

declare double @js_class_capture_value_or(i32, i32, double)

declare double @js_param_or_class_capture_value(double, i32, i32)

declare void @js_super_construct_apply(i32, double, double)

declare double @js_super_method_call_dynamic(i32, ptr, i64, double, ptr, i64)

declare double @js_super_method_call_dynamic_apply(i32, ptr, i64, double, double)

declare i64 @js_array_push_spread_any(i64, double)

declare i32 @js_set_function_prototype(double, double)

declare double @js_set_prototype_property(double, double, i32)

declare void @js_register_prototype_method(i32, ptr, i64, double)

declare i32 @js_register_function_prototype_method(double, ptr, i64, double)

declare double @js_new_function_construct(double, ptr, i64)

declare double @js_function_ctor_from_strings(ptr, i64)

declare double @js_new_function_construct_apply(double, double)

declare double @js_throw_not_a_constructor()

declare double @js_new_target_value()

declare double @js_get_function_prototype_method(double, ptr, i64)

declare double @js_function_prototype_value_for_read(double)

declare i64 @js_typeerror_new(i64)

declare i64 @js_rangeerror_new(i64)

declare i64 @js_syntaxerror_new(i64)

declare i64 @js_referenceerror_new(i64)

declare double @js_throw_symbol_constructor_type_error()

declare double @js_throw_bigint_constructor_type_error()

declare double @js_throw_strict_eval_arguments_syntax_error()

declare double @js_throw_eval_syntax_error(double)

declare double @js_throw_restricted_function_property_assignment()

declare double @js_throw_math_constructor_type_error()

declare double @js_throw_json_constructor_type_error()

declare double @js_webcrypto_illegal_constructor()

declare double @js_throw_type_error_const_assignment(double)

declare double @js_throw_reference_error_unresolvable_assignment(double)

declare double @js_throw_reference_error_unresolved_get()

declare double @js_with_implicit_unset()

declare double @js_with_implicit_read(double, double)

declare double @js_iterator_result_validate(double)

declare double @js_for_of_next(double)

declare double @js_segments_view_open(double, double)

declare double @js_segments_view_next(double)

declare double @js_segments_view_code_point_at(double, double)

declare double @js_segments_view_segment(double)

declare double @js_segments_view_regexp_test(double, double)

declare double @js_global_get_or_throw_unresolved(double)

declare double @js_module_ambient_require()

declare double @js_module_ambient_require_apply(double)

declare double @js_module_dynamic_import_fallback(double)

declare double @js_module_dynamic_import_deferred(double, double)

declare double @js_module_create_require_devirt(double)

declare double @js_global_get_optional(double)

declare double @js_global_update(double, double, double)

declare double @js_global_assign_existing_or_throw(double, double)

declare double @js_throw_reference_error_this_before_super()

declare double @js_throw_reference_error_super_delete()

declare double @js_throw_reference_error_unresolved_assignment()

declare i64 @js_evalerror_new(i64)

declare i64 @js_urierror_new(i64)

declare i64 @js_weakmap_new()

declare i64 @js_weakset_new()

declare double @js_weakmap_init_iterable(double, double)

declare double @js_weakset_init_iterable(double, double)

declare double @js_weakmap_set(double, double, double)

declare double @js_weakmap_get(double, double)

declare double @js_weakmap_has(double, double)

declare double @js_weakmap_delete(double, double)

declare double @js_weakset_add(double, double)

declare double @js_weakset_has(double, double)

declare double @js_weakset_delete(double, double)

declare double @js_weak_throw_primitive()

declare i64 @js_buffer_from_string(i64, i32)

declare i32 @js_encoding_tag_from_value(double)

declare i64 @js_value_to_string_with_encoding(double, i32)

declare i64 @js_value_to_string_with_encoding_or_radix(double, i32, double)

declare i64 @js_object_values(i64)

declare i64 @js_object_values_value(double)

declare i64 @js_object_entries(i64)

declare i64 @js_object_entries_value(double)

declare i64 @js_path_join(i64, i64)

declare i64 @js_path_win32_join(i64, i64)

declare i64 @js_path_win32_dirname(i64)

declare i64 @js_path_win32_basename(i64)

declare i64 @js_path_win32_basename_ext(i64, i64)

declare i64 @js_path_win32_extname(i64)

declare i32 @js_path_win32_is_absolute(i64)

declare i64 @js_path_win32_normalize(i64)

declare i64 @js_path_win32_parse(i64)

declare i64 @js_path_win32_format(double)

declare i64 @js_path_win32_relative(i64, i64)

declare i64 @js_path_win32_relative_checked(double, double)

declare i64 @js_path_win32_resolve(i64)

declare i64 @js_path_win32_resolve_join(i64, i64)

declare i64 @js_path_win32_to_namespaced_path(i64)

declare double @js_path_win32_to_namespaced_path_value(double)

declare i32 @js_path_win32_matches_glob(i64, i64)

declare i64 @js_path_win32_sep_get()

declare i64 @js_path_win32_delimiter_get()

declare i64 @js_path_dirname(i64)

declare i64 @js_path_resolve(i64)

declare i64 @js_path_relative(i64, i64)

declare i64 @js_path_relative_checked(double, double)

declare i64 @js_path_to_namespaced_path(i64)

declare double @js_path_to_namespaced_path_value(double)

declare i32 @js_path_matches_glob(i64, i64)

declare i64 @js_path_resolve_join(i64, i64)

declare i64 @js_path_arg_header(double)

declare i64 @js_path_join_value(double, double)

declare i64 @js_path_win32_join_value(double, double)

declare i64 @js_path_resolve_join_value(double, double)

declare i64 @js_path_win32_resolve_join_value(double, double)

declare i64 @js_path_basename_ext_value(double, double)

declare i64 @js_path_win32_basename_ext_value(double, double)

declare i32 @js_path_matches_glob_value(double, double)

declare i32 @js_path_win32_matches_glob_value(double, double)

declare double @js_object_from_entries(double)

declare i64 @js_string_match(i64, i64)

declare i64 @js_string_match_all(i64, i64)

declare i64 @js_string_match_all_value(i64, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log2.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log10.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.exp.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sin.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.cos.f64(double) #1

declare i64 @js_path_basename(i64)

declare i64 @js_path_basename_ext(i64, i64)

declare i64 @js_path_extname(i64)

declare i64 @js_path_sep_get()

declare i64 @js_path_delimiter_get()

declare i64 @js_path_parse(i64)

declare i64 @js_json_parse(i64)

declare i64 @js_json_text_to_string(double)

declare double @js_json_raw_json(double)

declare double @js_json_is_raw_json(double)

declare i64 @js_json_parse_or_null(i64)

declare i64 @js_json_parse_typed_array(i64, i64, i32, i32)

declare i64 @js_date_to_date_string(double)

declare i64 @js_date_to_time_string(double)

declare i64 @js_date_to_utc_string(double)

declare i64 @js_date_to_locale_date_string(double)

declare i64 @js_date_to_locale_time_string(double)

declare i64 @js_date_to_json(double)

declare i64 @js_regexp_exec(i64, i64)

declare i64 @js_number_to_precision(double, double)

declare i64 @js_number_to_exponential(double, double)

declare double @js_date_new()

declare double @js_number_is_integer(double)

declare double @js_number_is_nan(double)

declare double @js_number_is_safe_integer(double)

declare double @js_date_parse(i64)

declare double @js_date_utc(ptr, i32)

declare double @js_date_new_local_components(double, double, double, double, double, double, double)

declare double @js_date_apply_setter(double, i32, i32, ptr, i32)

declare double @js_math_clz32(double)

declare double @js_math_cbrt(double)

declare double @js_math_fround(double)

declare double @js_math_f16round(double)

declare double @js_math_sinh(double)

declare double @js_math_cosh(double)

declare double @js_math_tanh(double)

declare double @js_math_asinh(double)

declare double @js_math_acosh(double)

declare double @js_math_atanh(double)

declare double @js_math_hypot(double, double)

declare double @js_object_is(double, double)

declare i64 @js_path_normalize(i64)

declare i64 @js_path_format(double)

declare i32 @js_path_is_absolute(i64)

declare i64 @js_encode_uri(double)

declare i64 @js_decode_uri(double)

declare i64 @js_encode_uri_component(double)

declare i64 @js_decode_uri_component(double)

declare i64 @js_text_encoder_new()

declare i64 @js_text_decoder_new(double, double, double)

declare i64 @js_text_encoder_encode_llvm(double)

declare i64 @js_text_decoder_decode_llvm(double, double)

declare i64 @js_text_decoder_encoding(double)

declare double @js_text_decoder_fatal(double)

declare double @js_text_decoder_ignore_bom(double)

declare void @js_queue_microtask(i64)

declare void @js_queue_next_tick(i64)

declare void @js_queue_next_tick_args(i64, ptr, i32)

declare void @js_drain_queued_microtasks()

declare i64 @js_uint8array_from_array(i64)

declare i64 @js_uint8array_alloc(i32)

declare i64 @js_uint8array_new(double)

declare i64 @js_uint8array_view(double, double, double)

declare i64 @js_typed_array_new_empty(i32, i32)

declare i64 @js_typed_array_new_from_array(i32, i64)

declare i64 @js_typed_array_new(i32, double)

declare i64 @js_typed_array_view(i32, double, double, double)

declare i32 @js_typed_array_length(i64)

declare double @js_typed_array_get(i64, i32)

declare i32 @js_typed_array_read_int32(i64, i32)

declare double @js_typed_array_read_f64(i64, i32)

declare double @js_u8_buffer_read_f64(i64, i32)

declare double @js_typed_array_index_get_dynamic(i64, double)

declare double @js_typed_array_at(i64, double)

declare void @js_typed_array_set(i64, i32, double)

declare double @js_typed_array_index_set_dynamic(i64, double, double)

declare i32 @js_uint8array_get(i64, i32)

declare double @js_uint8array_index_get_value(i64, i32)

declare void @js_uint8array_set(i64, i32, i32)

declare i64 @js_native_arena_alloc(i64)

declare i64 @js_native_arena_view(i64, i32, i64, i64)

declare i64 @js_native_pod_view(i64, i64, i64, i64, i64, i64)

declare double @js_native_pod_view_length(double)

declare ptr @js_native_abi_check_pod_view_data_ptr(double, i64)

declare i64 @js_native_abi_check_pod_view_record_count(double, i64)

declare void @js_native_arena_dispose(i64)

declare void @js_native_memory_fill_u32(i64, double)

declare void @js_native_memory_copy(i64, i64)

declare i64 @js_typed_array_to_reversed(i64)

declare i64 @js_typed_array_to_sorted_default(i64)

declare i64 @js_typed_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_typed_array_with(i64, double, double)

declare double @js_typed_array_find_last(i64, i64)

declare double @js_typed_array_find_last_index(i64, i64)

declare double @js_typed_array_set_from(i64, double, double)

declare i64 @js_typed_array_subarray(i64, i32, double, i32, double)

declare double @js_object_has_own(double, double)

declare double @js_object_property_is_enumerable(double, double)

declare double @js_object_define_getter(double, double, double)

declare double @js_object_define_setter(double, double, double)

declare double @js_object_lookup_getter(double, double)

declare double @js_object_lookup_setter(double, double)

declare double @js_object_get_own_field_or_undef(double, ptr, i64)

declare double @js_unresolved_namespace_stub()

declare double @js_node_submodule_export_as_function(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace_member(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace(ptr, i32)

declare void @js_node_submod_install_vm()

declare void @js_node_submod_install_timers()

declare void @js_node_submod_install_timers_promises()

declare void @js_node_submod_install_fs_promises()

declare void @js_node_submod_install_readline_promises()

declare void @js_node_submod_install_stream_promises()

declare void @js_node_submod_install_stream_consumers()

declare void @js_node_submod_install_stream_web()

declare void @js_node_submod_install_hono_jsx_server()

declare void @js_node_submod_install_hono_jsx_streaming()

declare void @js_node_submod_install_sys()

declare void @js_node_submod_install_diagnostics_channel()

declare void @js_node_submod_install_trace_events()

declare void @js_node_submod_install_test()

declare void @js_node_submod_install_test_reporters()

declare void @js_node_submod_install_all()

declare void @js_node_submod_enable_install_all()

declare double @js_unresolved_default_call()

declare double @js_get_global_this()

declare double @js_module_top_this()

declare double @js_global_or_console_property_by_name(i64)

declare void @js_class_register_static_symbol(i32, double, double)

declare void @js_register_class_computed_method(i64, double, i64, i64, i64, i64, i64)

declare void @js_register_class_computed_accessor(i64, double, i64, i64, i64, i64)

declare void @js_class_register_static_field(i32, ptr, i64, double, ptr)

declare double @js_object_define_property(double, double, double)

declare double @js_object_define_get_accessor(double, double, double)

declare double @js_object_get_own_property_descriptor(double, double)

declare double @js_object_get_own_property_descriptors(double)

declare double @js_object_get_own_property_names(double)

declare double @js_symbol_new(double)

declare double @js_symbol_new_empty()

declare double @js_symbol_for(double)

declare double @js_symbol_computed_member(double, double)

declare double @js_symbol_key_for(double)

declare double @js_symbol_description(double)

declare i64 @js_symbol_to_string(double)

declare i32 @js_symbol_equals(double, double)

declare i32 @js_is_symbol(double)

declare i64 @js_object_get_own_property_symbols(double)

declare double @js_object_set_symbol_property(double, double, double)

declare double @js_to_property_key(double)

declare double @js_object_set_property_key(double, double, double)

declare double @js_object_get_property_key(double, double)

declare double @js_object_set_property_key_method(double, double, double)

declare double @js_object_super_get(double, double, double)

declare double @js_object_super_put_value_set(double, double, double, double, i32)

declare double @js_object_super_call(double, double, double, ptr, i64)

declare double @js_object_literal_infer_computed_function_name(double, double)

declare double @js_object_get_symbol_property(double, double)

declare double @js_object_get_symbol_property_ic_miss(double, double, ptr)

declare double @js_object_get_symbol_then_field_ic_miss(double, double, ptr, i64, ptr, ptr)

declare double @js_object_create(double)

declare double @js_object_create_with_props(double, double)

declare double @js_object_freeze(double)

declare double @js_object_seal(double)

declare double @js_object_prevent_extensions(double)

declare void @js_object_copy_own_fields(i64, double)

declare double @js_object_assign_validate_target(double)

declare double @js_object_assign_one(double, double)

declare double @js_string_at(i64, i32)

declare double @js_string_code_point_at(i64, i32)

declare i64 @js_string_from_code_point(double)

declare i64 @js_string_raw(double, double)

declare i64 @js_string_from_char_code(double)

declare i64 @js_string_from_char_code_array(double)

declare double @js_string_char_code_at(i64, i32)

declare i32 @js_string_last_index_of(i64, i64)

declare i32 @js_string_last_index_of_from(i64, i64, double, i32)

declare double @js_string_locale_compare(i64, i64)

declare double @js_string_locale_compare_opts(i64, i64, double)

declare i64 @js_string_normalize(i64, double)

declare i64 @js_string_pad_start(i64, double, i64)

declare i64 @js_string_pad_end(i64, double, i64)

declare i64 @js_string_pad_fill(double)

declare double @js_string_is_well_formed(i64)

declare i64 @js_string_to_well_formed(i64)

declare i32 @js_string_search_regex(i64, i64)

declare i32 @js_string_search_value(i64, double)

declare i64 @js_string_match_value(i64, double)

declare double @js_regexp_exec_get_index()

declare i64 @js_regexp_exec_get_groups()

declare double @js_regexp_get_last_index(i64)

declare void @js_regexp_set_last_index(i64, double)

declare i64 @js_regexp_get_source(i64)

declare i64 @js_regexp_get_flags(i64)

declare i64 @js_string_replace_regex_named(i64, i64, i64)

declare i64 @js_string_replace_all_regex_named(i64, i64, i64)

declare i64 @js_string_replace_string_fn(i64, i64, double)

declare i64 @js_string_replace_string_dyn(i64, i64, double)

declare i64 @js_string_replace_all_string_dyn(i64, i64, double)

declare i64 @js_string_replace_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_all_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_string_fn(i64, i64, double)

declare i64 @js_string_replace_regex_fn(i64, i64, double)

declare i64 @js_string_replace_all_regex_fn(i64, i64, double)

declare double @js_structured_clone(double)

declare double @js_structured_clone_with_options(double, double)

declare double @js_generator_attach_prototype(double, i32)

declare double @js_generator_attach_closure_prototype(double, i64)

declare i64 @js_weakref_new(double)

declare double @js_weakref_deref(double)

declare i64 @js_finreg_new(double)

declare double @js_finreg_register(double, double, double, double)

declare double @js_finreg_unregister(double, double)

declare i64 @js_atob(double)

declare i64 @js_btoa(double)

declare double @js_object_is_frozen(double)

declare double @js_object_is_sealed(double)

declare double @js_object_is_extensible(double)

declare i64 @js_aggregateerror_new(i64, i64)

declare i64 @js_error_new_with_cause(i64, double)

declare i64 @js_aggregateerror_new_full(double, i64, double)

declare i64 @js_error_new_kind_with_options(i32, i64, double)

declare double @js_error_is_error(double)

declare i64 @js_error_get_errors(i64)

declare i64 @js_crypto_sha256(i64)

declare i64 @js_crypto_sha256_bytes(i64)

declare i64 @js_crypto_md5(i64)

declare i64 @js_crypto_hmac_sha256(i64, i64)

declare i64 @js_crypto_hmac_sha256_bytes(i64, i64)

declare void @js_runtime_validate_string_arg(double, ptr, i32)

declare void @js_set_call_location(ptr, i64, i32)

declare void @js_runtime_validate_crypto_key_arg(double, ptr, i32)

declare void @js_runtime_validate_integer_arg(double, ptr, i32, double, double)

declare i64 @js_crypto_pbkdf2_bytes(i64, i64, double, double, i64)

declare double @js_crypto_pbkdf2_async_alg(i64, i64, double, double, i64, double)

declare i64 @js_crypto_argon2_sync(i64, double)

declare double @js_crypto_argon2_async(i64, double, double)

declare i64 @js_crypto_encapsulate(double)

declare double @js_crypto_encapsulate_async(double, double)

declare i64 @js_crypto_decapsulate(double, double)

declare double @js_crypto_decapsulate_async(double, double, double)

declare i64 @js_crypto_hkdf_bytes_alg(i64, i64, i64, i64, double)

declare double @js_crypto_hkdf_async_alg(i64, i64, i64, i64, double, double)

declare i64 @js_crypto_scrypt_bytes(i64, i64, double, double)

declare double @js_crypto_scrypt_async(i64, i64, double, double, double)

declare i64 @js_crypto_sign_rsa_sha256(i64, i64, double)

declare double @js_crypto_sign_async(i64, i64, double, double)

declare double @js_crypto_verify_rsa_sha256(i64, i64, double, i64)

declare double @js_crypto_verify_async(i64, i64, double, i64, double)

declare i64 @js_crypto_public_encrypt(i64, i64)

declare i64 @js_crypto_private_decrypt(i64, i64)

declare i64 @js_crypto_private_encrypt(i64, i64)

declare i64 @js_crypto_public_decrypt(i64, i64)

declare i64 @js_crypto_create_public_key(i64)

declare i64 @js_crypto_create_private_key_value(double)

declare i64 @js_crypto_create_public_key_value(double)

declare i64 @js_crypto_generate_key_pair_sync_rsa(double)

declare i64 @js_crypto_generate_key_pair_sync_ec_p256(double)

declare i64 @js_crypto_generate_key_pair_sync_ed25519(double)

declare i64 @js_crypto_generate_key_pair_sync_x25519(double)

declare double @js_crypto_generate_key_pair_async(i64, double, double)

declare i64 @js_crypto_diffie_hellman(double)

declare double @js_crypto_get_cipher_info(double, double)

declare i64 @js_crypto_get_curves()

declare i64 @js_crypto_secure_heap_used()

declare i64 @js_crypto_random_bytes_buffer(double)

declare double @js_crypto_random_bytes_async(double, double)

declare i64 @js_crypto_random_uuid(double)

declare i64 @js_crypto_random_uuidv7()

declare double @js_crypto_random_int(double, double)

declare double @js_crypto_random_int_async(double, double, double)

declare double @js_crypto_timing_safe_equal(double, double)

declare i64 @js_crypto_get_hashes()

declare i64 @js_crypto_get_ciphers()

declare double @js_crypto_generate_prime_sync(double, double)

declare double @js_crypto_generate_prime_async(double, double, double)

declare double @js_crypto_check_prime_sync(double, double)

declare double @js_crypto_check_prime_async(double, double, double)

declare i64 @js_crypto_create_secret_key(i64, i64)

declare i64 @js_crypto_generate_key_sync(i64, double)

declare double @js_crypto_generate_key_async(i64, double, double)

declare i64 @js_webcrypto_digest(double, double)

declare i64 @js_webcrypto_import_key(double, double, double, double, double)

declare i64 @js_webcrypto_export_key(double, double)

declare i64 @js_webcrypto_sign(double, double, double)

declare i64 @js_webcrypto_verify(double, double, double, double)

declare i64 @js_webcrypto_derive_bits(double, double, double)

declare i64 @js_webcrypto_derive_key(double, double, double, double, double)

declare i64 @js_webcrypto_encrypt(double, double, double)

declare i64 @js_webcrypto_decrypt(double, double, double)

declare i64 @js_webcrypto_generate_key(double, double, double)

declare i64 @js_webcrypto_wrap_key(double, double, double, double)

declare i64 @js_webcrypto_unwrap_key(double, double, double, double, double, double, double)

declare i64 @js_zlib_create_brotli_decompress(double)

declare double @js_crypto_random_fill_sync(double, double, double)

declare double @js_crypto_random_fill_async(double, double, double, double)

declare double @js_crypto_create_hash(i64)

declare double @js_crypto_create_hash_options(i64, double)

declare double @js_crypto_x509_new(i64)

declare double @js_crypto_certificate_verify_spkac(double)

declare double @js_crypto_certificate_export_public_key(double)

declare double @js_crypto_certificate_export_challenge(double)

declare double @js_crypto_create_sign(i64)

declare double @js_crypto_create_verify(i64)

declare double @js_crypto_create_ecdh(i64)

declare double @js_crypto_create_diffie_hellman(double, double, double)

declare double @js_crypto_get_diffie_hellman(double)

declare double @js_crypto_ecdh_convert_key(double, double, double, double, double)

declare double @js_crypto_create_hmac(i64, i64)

declare i64 @js_buffer_alloc(i32, i32)

declare i64 @js_buffer_alloc_fill_value(i32, double, i32)

declare i64 @js_array_buffer_new(i32)

declare i64 @js_shared_array_buffer_new(i32)

declare i64 @js_array_buffer_new_value(double)

declare i64 @js_shared_array_buffer_new_value(double)

declare i64 @js_json_stringify_full(double, double, double)

declare i64 @js_json_parse_with_reviver(i64, i64)

declare double @js_array_find(i64, i64)

declare i32 @js_array_findIndex(i64, i64)

declare double @js_array_find_last(i64, i64)

declare i32 @js_array_find_last_index(i64, i64)

declare double @js_array_some(i64, i64)

declare double @js_array_some_captureless(i64, ptr)

declare double @js_array_every(i64, i64)

declare i32 @js_promise_state(i64)

declare double @js_promise_value(i64)

declare double @js_promise_reason(i64)

declare i32 @js_value_is_promise(double)

declare double @js_assimilate_thenable(double)

declare i32 @js_promise_run_microtasks()

declare i32 @js_promise_run_microtasks_event_loop()

declare i32 @js_promise_run_microtasks_await_loop()

declare i32 @js_await_loop_tick_timers()

declare void @js_mark_entry_module_esm()

declare i32 @js_promise_run_promise_jobs()

declare void @js_run_stdlib_pump()

declare void @js_sleep_ms(double)

declare void @js_wait_for_event()

declare i32 @js_event_loop_host_driven()

declare void @js_unsettled_top_level_await_exit()

declare void @js_throw(double)

declare void @js_eh_try_push()

declare i32 @perry_eh_personality(...)

declare void @js_try_end()

declare double @js_get_exception()

declare void @js_clear_exception()

declare i32 @js_has_exception()

declare void @js_enter_finally()

declare void @js_leave_finally()

declare double @js_await_any_promise(double)

declare i64 @js_promise_new()

declare i64 @js_promise_new_with_executor(i64)

declare i32 @js_timer_tick()

declare i32 @js_timer_tick_if_refed()

declare i32 @js_callback_timer_tick()

declare i32 @js_interval_timer_tick()

declare i32 @js_timer_has_pending()

declare i32 @js_callback_timer_has_pending()

declare i32 @js_interval_timer_has_pending()

declare i32 @js_stdlib_has_active_handles()

declare i32 @js_bun_ffi_has_active_threadsafe_callbacks()

declare i32 @js_microtasks_pending()

declare i64 @js_timer_validate_callback(double, i32)

declare i64 @js_set_timeout_callback(i64, double)

declare i64 @js_set_timeout_callback_args(i64, double, ptr, i32)

declare i64 @js_set_immediate_callback(i64)

declare i64 @js_set_immediate_callback_args(i64, ptr, i32)

declare i64 @setInterval(i64, double)

declare i64 @js_set_interval_callback_args(i64, double, ptr, i32)

declare void @clearTimeout(i64)

declare void @clearInterval(i64)

declare void @clearImmediate(i64)

declare void @js_clear_timeout_value(double)

declare void @js_clear_interval_value(double)

declare void @js_clear_immediate_value(double)

declare i64 @js_buffer_from_array(i64)

declare i64 @js_buffer_from_arraybuffer_slice(i64, i32, i32)

declare i32 @js_buffer_length(i64)

declare i32 @js_buffer_get(i64, i32)

declare double @js_buffer_index_get_value(i64, i32)

declare ptr @js_native_buffer_data_ptr(double)

declare i64 @js_native_buffer_byte_len(double)

declare void @js_console_time(i64)

declare void @js_console_time_end(i64)

declare void @js_console_time_log(i64)

declare void @js_console_time_value(double)

declare void @js_console_time_end_value(double)

declare void @js_console_time_log_value(double)

declare void @js_console_time_log_spread(double, i64)

declare void @js_console_count(i64)

declare void @js_console_count_reset(i64)

declare void @js_console_count_value(double)

declare void @js_console_count_reset_value(double)

declare double @js_console_new(double)

declare double @js_console_new2(double, double)

declare void @js_console_group_begin()

declare void @js_console_group_end()

declare void @js_console_clear()

declare void @js_console_noop()

declare double @js_native_call_method(double, ptr, i64, ptr, i64)

declare double @js_native_call_method_by_id(double, i64, ptr, i64)

declare double @js_native_call_method_apply(double, ptr, i64, i64)

declare double @js_native_call_method_apply_by_id(double, i64, i64)

declare double @js_native_call_method_str_key(double, i64, ptr, i64)

declare double @js_native_call_method_value(double, double, ptr, i64)

declare double @js_native_call_method_value_apply(double, double, i64)

declare void @js_promise_resolve(i64, double)

declare void @js_promise_reject(i64, double)

declare void @js_promise_mark_internally_handled(i64)

declare i64 @js_promise_resolved(double)

declare i64 @js_async_fn_result(double)

declare i64 @js_promise_rejected(double)

declare double @js_create_namespace(i32, ptr, ptr, ptr, ptr)

declare double @js_finalize_namespace(double)

declare i64 @js_promise_then(i64, i64, i64)

declare i64 @js_promise_resolved_then(double, i64, i64)

declare i64 @js_promise_finally(i64, i64)

declare double @js_promise_then_checked(double, double, double)

declare double @js_promise_catch_checked(double, double)

declare double @js_promise_finally_checked(double, double)

declare i64 @js_promise_closure_arg(double)

declare i64 @js_promise_all(i64)

declare i64 @js_promise_race(i64)

declare i64 @js_promise_any(i64)

declare i64 @js_promise_all_settled(i64)

declare i64 @js_promise_all_iterable(double)

declare i64 @js_promise_race_iterable(double)

declare i64 @js_promise_any_iterable(double)

declare i64 @js_promise_all_settled_iterable(double)

declare i64 @js_promise_with_resolvers()

declare i64 @js_promise_try(double, i64)

declare i64 @js_array_unshift_f64(i64, double)

declare i64 @js_array_unshift_variadic(i64, ptr, i32)

declare i64 @js_array_entries(i64)

declare i64 @js_array_keys(i64)

declare i64 @js_array_values(i64)

declare i64 @js_array_entries_iter_obj(i64)

declare i64 @js_array_keys_iter_obj(i64)

declare i64 @js_array_values_iter_obj(i64)

declare double @js_response_new(i64, double, i64, double)

declare double @js_fetch_unwrap_handle(double)

declare double @js_response_body_init_reset()

declare i64 @js_response_body_init_ptr(double)

declare double @js_headers_new()

declare double @js_headers_set(double, i64, i64)

declare double @js_headers_append(double, i64, i64)

declare i64 @js_headers_get(double, i64)

declare double @js_headers_get_set_cookie(double)

declare double @js_headers_has(double, i64)

declare double @js_headers_delete(double, i64)

declare double @js_headers_for_each(double, double)

declare double @js_headers_keys(double)

declare double @js_headers_values(double)

declare double @js_headers_entries(double)

declare double @js_headers_init_from_value(double, double)

declare double @js_headers_method_value(double, i64, i64)

declare double @js_request_new(i64, i64, i64, double, i64, i64, i64, i64, i64, i64, i64, double, i64, double)

declare double @js_request_new_from_init(i64, double)

declare i64 @js_request_get_url(double)

declare i64 @js_request_input_to_url(double)

declare i64 @js_request_get_method(double)

declare double @js_request_get_body(double)

declare double @js_request_body_used(double)

declare i64 @js_request_get_destination(double)

declare i64 @js_request_get_referrer(double)

declare i64 @js_request_get_referrer_policy(double)

declare i64 @js_request_get_mode(double)

declare i64 @js_request_get_credentials(double)

declare i64 @js_request_get_cache(double)

declare i64 @js_request_get_redirect(double)

declare i64 @js_request_get_integrity(double)

declare double @js_request_get_keepalive(double)

declare i64 @js_request_get_duplex(double)

declare double @js_request_get_signal(double)

declare double @js_request_get_headers(double)

declare i64 @js_request_text(double)

declare i64 @js_request_json(double)

declare i64 @js_request_array_buffer(double)

declare i64 @js_request_blob(double)

declare i64 @js_request_bytes(double)

declare i64 @js_request_form_data(double)

declare double @js_request_clone(double)

declare double @js_fetch_response_status(double)

declare i64 @js_fetch_response_status_text(double)

declare double @js_fetch_response_ok(double)

declare i64 @js_fetch_response_type(double)

declare i64 @js_fetch_response_url(double)

declare double @js_fetch_response_redirected(double)

declare double @js_response_body_used(double)

declare i64 @js_fetch_response_text(double)

declare i64 @js_fetch_response_json(double)

declare double @js_response_get_headers(double)

declare double @js_response_clone(double)

declare i64 @js_response_array_buffer(double)

declare i64 @js_response_blob(double)

declare i64 @js_response_bytes(double)

declare i64 @js_response_form_data(double)

declare double @js_form_data_new()

declare double @js_form_data_append(double, double, double, double)

declare double @js_form_data_set(double, double, double, double)

declare double @js_form_data_delete(double, i64)

declare double @js_form_data_get(double, i64)

declare double @js_form_data_get_all(double, i64)

declare double @js_form_data_has(double, i64)

declare double @js_form_data_entries(double)

declare double @js_form_data_keys(double)

declare double @js_form_data_values(double)

declare double @js_form_data_for_each(double, double)

declare double @js_blob_size(double)

declare i64 @js_blob_type(double)

declare i64 @js_blob_array_buffer(double)

declare i64 @js_blob_bytes(double)

declare i64 @js_blob_text(double)

declare double @js_blob_slice(double, double, double, i64)

declare double @js_blob_new(double, double)

declare double @js_file_new(double, double, double, double)

declare i64 @js_file_name(double)

declare double @js_file_last_modified(double)

declare i64 @js_url_create_object_url(double)

declare void @js_url_revoke_object_url(double)

declare double @js_buffer_resolve_object_url(double)

declare double @js_response_static_json(double, double, i64, double)

declare double @js_response_static_redirect(i64, double)

declare double @js_response_static_error()

declare double @js_blob_stream(double)

declare double @js_response_body(double)

declare double @js_readable_stream_new(double, double, double, double)

declare double @js_readable_stream_new_with_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_with_strategy_and_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_from_source_object(double, double)

declare double @js_readable_stream_get_reader(double)

declare double @js_readable_stream_get_reader_with_options(double, double)

declare double @js_readable_stream_get_byob_reader(double)

declare double @js_readable_stream_controller_byob_request(double)

declare double @js_readable_stream_from_iterable(double)

declare double @js_readable_stream_locked(double)

declare i64 @js_readable_stream_cancel(double, double)

declare double @js_readable_stream_tee(double)

declare i64 @js_readable_stream_pipe_to(double, double, double)

declare double @js_readable_stream_pipe_through(double, double, double)

declare double @js_readable_stream_pipe_through_validate(double, double, double, double)

declare double @js_readable_stream_controller_enqueue(double, double)

declare double @js_readable_stream_controller_close(double)

declare double @js_readable_stream_controller_error(double, double)

declare double @js_readable_stream_controller_desired_size(double)

declare i64 @js_reader_read(double)

declare i64 @js_reader_read_with_view(double, double)

declare double @js_reader_release_lock(double)

declare i64 @js_reader_closed(double)

declare i64 @js_reader_cancel(double, double)

declare double @js_writable_stream_new(double, double, double, double, double)

declare double @js_writable_stream_new_with_sink_type(double, double, double, double, double, double)

declare double @js_writable_stream_new_from_sink_object(double, double)

declare double @js_writable_stream_throw_invalid_sink()

declare double @js_writable_stream_get_writer(double)

declare double @js_writable_stream_locked(double)

declare i64 @js_writable_stream_close(double)

declare i64 @js_writable_stream_abort(double, double)

declare i64 @js_writer_write(double, double)

declare i64 @js_writer_close(double)

declare i64 @js_writer_abort(double, double)

declare double @js_writer_release_lock(double)

declare i64 @js_writer_closed(double)

declare i64 @js_writer_ready(double)

declare double @js_writer_desired_size(double)

declare double @js_transform_stream_new(double, double, double, double, double)

declare double @js_transform_stream_new_from_transformer_object(double, double, double)

declare double @js_transform_stream_readable(double)

declare double @js_transform_stream_writable(double)

declare double @js_text_encoding_stream_new()

declare double @js_text_encoder_stream_new()

declare double @js_text_decoder_stream_new()

declare double @js_stream_web_text_encoder_stream_new()

declare double @js_stream_web_text_decoder_stream_new(double, double)

declare double @js_stream_web_compression_stream_new(double)

declare double @js_stream_web_decompression_stream_new(double)

declare double @js_streams_strategy_high_water_mark(double)

declare double @js_count_queuing_strategy_new(double)

declare double @js_byte_length_queuing_strategy_new(double)

declare double @js_stream_unwrap_handle(double)

declare double @js_readable_stream_subclass_init(double, double, double, double, double)

declare double @js_writable_stream_subclass_init(double, double, double, double, double)

declare double @js_transform_stream_subclass_init(double, double, double, double)

declare double @js_request_subclass_init(double, double, double)

declare double @js_response_subclass_init(double, double, double)

declare double @js_fetch_or_value_super(double, double, ptr, i64)

declare double @js_builtin_subclass_construct(i32, ptr, i64, ptr, i64)

declare i64 @js_abort_controller_new()

declare i64 @js_abort_controller_signal(i64)

declare void @js_abort_controller_abort(i64)

declare void @js_abort_controller_abort_reason(i64, double)

declare void @js_abort_signal_add_listener(i64, double, double)

declare i64 @js_abort_signal_timeout(double)

declare i64 @js_abort_signal_abort(double)

declare i64 @js_abort_signal_any(i64)

declare double @js_abort_signal_throw_if_aborted(i64)

declare i64 @js_event_target_new()

declare i64 @js_event_new(double, double, i32)

declare double @js_event_subclass_init(double, double, double, i32, i32)

declare i64 @js_custom_event_new(double, double, i32)

declare i64 @js_dom_exception_new(double, double)

declare double @js_dom_exception_subclass_init(double, double, double)

declare void @js_event_target_add_event_listener(i64, i64, i64)

declare void @js_event_target_add_event_listener_with_options(i64, i64, i64, double)

declare void @js_event_target_remove_event_listener(i64, i64, i64)

declare void @js_event_target_remove_event_listener_with_options(i64, i64, i64, double)

declare double @js_event_target_dispatch_event(i64, double)

declare i32 @js_event_target_is_event_target(i64)

declare i64 @js_event_target_get_event_listeners(i64, i64)

declare double @js_event_target_get_max_listeners(i64)

declare i32 @js_event_target_set_max_listeners(i64, double)

declare double @js_message_channel_new()

declare double @js_message_port_constructor_error()

declare double @js_broadcast_channel_new(double)

declare i64 @js_array_alloc(i32)

declare i64 @js_tagged_template_register_raw(i64, i64)

declare i64 @js_tagged_template_get_or_init(i64, i64, i64)

declare i64 @js_template_raw(i64)

declare i64 @js_array_create()

declare i64 @js_array_constructor_single(double)

declare i64 @js_array_alloc_literal(i32)

declare i64 @js_array_from_values(ptr, i32)

declare double @js_value_from_const_descriptor(ptr, i32)

declare i64 @js_array_push_f64(i64, double)

declare i64 @js_array_push_u31_with_length(i64, i32, ptr)

declare i64 @js_array_push_f64_spec(i64, double)

declare void @js_array_push_guard(i64)

declare i64 @js_array_push_hole(i64)

declare i64 @js_array_numeric_push_f64_unboxed(i64, double)

declare i64 @js_array_push_spread_f64(i64, i64)

declare double @js_array_get_f64(i64, i32)

declare i32 @js_array_ensure_element_shape(i64)

declare double @js_array_get_index_or_string(i64, double)

declare double @js_array_numeric_get_f64_unboxed(i64, i32)

declare void @js_array_set_f64(i64, i32, double)

declare i32 @js_array_numeric_set_f64_unboxed(i64, i32, double)

declare i64 @js_array_set_f64_extend(i64, i32, double)

declare i64 @js_array_set_f64_extend_strict(i64, i32, double)

declare i64 @js_array_fill_f64_const_extend(i64, i32, double)

declare i64 @js_array_fill_f64_iota_extend(i64, i32)

declare i64 @js_array_fill_f64_const_len_extend(i64, double)

declare i64 @js_array_fill_f64_iota_len_extend(i64)

declare i64 @js_array_numeric_range_add(double, double, double, double)

declare i64 @js_array_numeric_range_add_len(double, double, double)

declare i64 @js_array_fill_range_strided_tagged(double, double, double, double, i64)

declare i64 @js_array_set_string_key(i64, i64, double)

declare i64 @js_array_set_index_or_string(i64, double, double)

declare i64 @js_array_mark_arguments_object(i64)

declare i32 @js_array_mark_numeric_f64_layout(i64)

declare i32 @js_array_is_numeric_f64_layout(i64)

declare void @js_array_clear_numeric_layout(i64)

; Function Attrs: nounwind willreturn
declare double @js_array_numeric_value_to_raw_f64(double) #0

declare double @js_array_refresh_local_head(double)

declare void @js_array_note_numeric_write(i64, i64)

declare void @js_array_declare_all_pointer_elements(i64)

declare i32 @js_array_length(i64)

declare double @js_array_is_array(double)

declare double @js_value_length_f64(double)

declare double @js_value_length_property_f64(double)

declare double @js_value_length_property_ic_f64(double, ptr)

declare nonnull ptr @js_shadow_frame_enter(i32)

declare i64 @js_shadow_frame_push(i32)

declare void @js_shadow_frame_pop(i64)

declare void @js_shadow_slot_set(i32, i64)

declare void @js_shadow_slot_bind(i32, ptr)

declare void @js_gc_write_barriers_emitted(i32)

declare i32 @js_gc_temp_root_push(i64)

declare i64 @js_gc_temp_root_get(i32)

declare void @js_gc_temp_root_set(i32, i64)

declare void @js_gc_temp_root_truncate(i32)

declare void @js_array_push_f64_temp_rooted(i32, double)

declare void @js_gc_loop_safepoint()

declare void @js_write_barrier(i64, i64)

declare void @js_write_barrier_slot(i64, i64, i64)

declare i64 @js_array_live_head(i64)

declare void @js_write_barrier_slot_validated_parent(i64, i64, i64)

declare void @js_write_barrier_root_nanbox(i64)

declare void @js_write_barrier_root_heap_word(i64)

declare void @js_gc_note_slot_layout(i64, i32, i64)

declare void @js_gc_note_slot_layout_aware(i64, i32, i64, i64)

declare void @js_gc_init_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_declare_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_forget_object_layout(i64)

declare double @js_array_pop_f64(i64)

declare i64 @js_array_join(i64, i64)

declare i64 @js_array_join_value(i64, double)

declare void @js_array_forEach(i64, i64)

declare i64 @js_array_fill(i64, double)

declare i64 @js_array_fill_range(i64, double, double, double)

declare double @js_array_fill_generic(double, double, i32, double, i32, double)

declare i32 @js_array_delete(i64, i32)

declare void @js_array_set_length(i64, double)

declare void @js_array_set_length_strict(i64, double)

declare i64 @js_array_clone(i64)

declare i32 @js_short_packed_spread_values(double, ptr)

declare i64 @js_spread_tail_fallback_args(ptr, i64, double)

declare i64 @js_array_from_value(double)

declare i64 @js_array_from_arraylike_holey_value(double)

declare double @js_iterator_from(double)

declare i64 @js_array_from_mapped(double, double, double)

declare i64 @js_array_concat_variadic(i64, ptr, i32)

declare double @js_arraylike_forEach(double, double, double)

declare double @js_arraylike_map(double, double, double)

declare double @js_arraylike_filter(double, double, double)

declare double @js_arraylike_some(double, double, double)

declare double @js_arraylike_every(double, double, double)

declare double @js_arraylike_find(double, double, double)

declare double @js_arraylike_findIndex(double, double, double)

declare double @js_arraylike_findLast(double, double, double)

declare double @js_arraylike_findLastIndex(double, double, double)

declare double @js_arraylike_reduce(double, double, i32, double)

declare double @js_arraylike_reduceRight(double, double, i32, double)

declare double @js_arraylike_indexOf(double, double, double, i32)

declare double @js_arraylike_lastIndexOf(double, double, double, i32)

declare double @js_arraylike_includes(double, double, double, i32)

declare double @js_arraylike_at(double, double)

declare double @js_arraylike_join(double, double)

declare double @js_arraylike_flat(double, double)

declare double @js_arraylike_slice(double, double, i32, double, i32)

declare double @js_arraylike_sort(double, double)

declare double @js_arraylike_splice(double, ptr, i32)

declare double @js_arraylike_concat(double, ptr, i32)

declare double @js_arraylike_pop(double)

declare double @js_arraylike_shift(double)

declare double @js_arraylike_push(double, ptr, i32)

declare double @js_arraylike_unshift(double, ptr, i32)

declare i64 @js_array_clone_for_spread(double)

declare i64 @js_array_spread_append(i64, double)

declare i64 @js_iterator_to_array(double)

declare double @js_iterator_next_result(double)

declare double @js_iterator_close_if_not_done(double, double)

declare double @js_iterator_rest_to_array(double, double)

declare double @js_get_iterator(double)

declare double @js_get_async_iterator(double)

declare double @js_for_of_to_array(double)

declare i64 @js_object_alloc(i32, i32)

declare double @js_object_coerce(double)

declare void @js_object_mark_class(i64)

declare void @js_class_object_pin_parent(i64, i32)

declare i64 @js_object_alloc_with_shape(i32, i32, ptr, i32)

declare void @js_object_set_field(i64, i32, i64)

declare i64 @js_object_get_field(i64, i32)

declare void @js_object_set_field_by_name(i64, i64, double)

declare void @js_object_set_field_by_property_id(i64, i64, double)

declare void @js_object_set_field_by_name_nonenum(i64, i64, double)

declare void @js_error_subclass_default_init(double, double)

declare void @js_object_set_field_by_name_nonconfigurable(i64, i64, double)

declare void @js_error_apply_cause_to_object(i64, double)

declare void @js_error_subclass_capture_stack(double)

declare i32 @js_with_has_binding(double, i64)

declare double @js_with_get_binding(double, i64)

declare double @js_with_set_binding(double, i64, double, i32)

declare i32 @js_with_delete_binding(double, i64)

declare i32 @js_pod_scalar_write_compatible(double, i32)

declare void @js_typed_feedback_register_site(i64, i32, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64)

declare void @js_typed_feedback_record_guard_pass(i64)

declare void @js_typed_feedback_record_guard_fail(i64)

declare void @js_typed_feedback_record_fallback_call(i64)

declare void @js_typed_feedback_observe_property_get(i64, i64, i64)

declare void @js_typed_feedback_observe_property_set(i64, i64, i64)

declare double @js_typed_feedback_object_get_field_by_name_f64(i64, i64, i64)

declare void @js_typed_feedback_object_set_field_by_name(i64, i64, i64, double)

declare void @js_typed_feedback_object_set_field_by_name_fast(i64, i64, i64, double)

declare i32 @js_typed_feedback_class_field_set_guard(i64, double, i32, i32, i64, i32, double, i32)

declare void @js_class_field_set_fallback(i64, i64, i64, double)

declare void @js_class_field_set_ic(i64, double, i32, i32, i64, i32, double, i32)

declare i32 @js_typed_feedback_class_field_get_guard(i64, double, i32, i32, i64, i32, i32)

declare double @js_class_field_get_ic(i64, double, i32, i32, i64, i32, i32)

declare double @js_typed_feedback_native_call_method(i64, double, ptr, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_by_id(i64, double, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_apply(i64, double, ptr, i64, i64)

declare double @js_typed_feedback_native_call_method_apply_by_id(i64, double, i64, i64)

declare i32 @js_typed_feedback_method_direct_call_guard(i64, double, i32, i32, ptr, i64, ptr)

declare i32 @js_method_direct_shape_guard(double, i32, i32, i32)

declare i32 @js_method_direct_shape_class(double, ptr, i32)

declare i32 @js_typed_feedback_closure_direct_call_guard(i64, double, ptr, i32, i32)

declare i64 @js_closure_exact_func_guard(double, ptr)

declare i64 @js_object_own_method_cache_miss(double, i32, i32, ptr, i64, ptr, ptr)

declare void @js_typed_feedback_object_set_unboxed_f64_field(i64, i64, i32, i64, double)

declare double @js_typed_feedback_observe_helper_return(i64, double)

declare void @js_object_set_index_polymorphic(i64, double, double)

declare double @js_object_get_index_polymorphic(i64, double)

declare double @js_object_get_field_by_name_f64(i64, i64)

declare double @js_object_get_field_by_name_boxed(double, i64)

declare double @js_object_get_field_by_property_id_f64(i64, i64)

declare double @js_native_module_property_by_name(ptr, i64, ptr, i64)

declare double @js_native_module_esm_export_value(double, double)

declare double @js_native_module_named_esm_export_value(double, double)

declare double @js_create_native_module_namespace(ptr, i64)

declare void @js_nm_install_assert()

declare void @js_nm_install_async_hooks()

declare void @js_nm_install_bigint()

declare void @js_nm_install_buffer()

declare void @js_bun_tcp_nm_install()

declare void @js_nm_install_bun()

declare void @js_nm_install_bun_ffi()

declare void @js_nm_install_child_process()

declare void @js_nm_install_cluster()

declare void @js_nm_install_console()

declare void @js_nm_install_crypto()

declare void @js_nm_install_dgram()

declare void @js_nm_install_dns()

declare void @js_nm_install_domain()

declare void @js_nm_install_events()

declare void @js_nm_install_fs()

declare void @js_nm_install_http()

declare void @js_nm_install_inspector()

declare void @js_nm_install_module()

declare void @js_nm_install_net()

declare void @js_nm_install_node_pty()

declare void @js_nm_install_os()

declare void @js_nm_install_path()

declare void @js_nm_install_perf()

declare void @js_nm_install_process()

declare void @js_nm_install_punycode()

declare void @js_nm_install_querystring()

declare void @js_nm_install_readline()

declare void @js_nm_install_repl()

declare void @js_nm_install_sea()

declare void @js_nm_install_sqlite()

declare void @js_nm_install_stream()

declare void @js_nm_install_timers()

declare void @js_nm_install_tls()

declare void @js_nm_install_tty()

declare void @js_nm_install_url()

declare void @js_nm_install_util()

declare void @js_nm_install_v8()

declare void @js_nm_install_vm()

declare void @js_nm_install_wasi()

declare void @js_nm_install_zlib()

declare void @js_nm_install_all()

declare double @js_object_get_field_ic_miss(i64, i64, ptr)

declare double @js_object_get_field_ic(i64, i64, i64, ptr)

declare i64 @js_object_rest(i64, i64)

declare double @js_require_object_coercible(double)

declare double @js_require_json_disk(double)

declare double @js_require_resolve_node_modules(double, double)

declare void @js_globalthis_seed_async_local_storage()

declare void @js_register_path_module_partial(double, double)

declare void @js_register_path_module(double, double)

declare void @js_link_path_module_parent(double)

declare void @js_run_module_init_catching(i64)

declare double @js_require_path_module(double)

declare double @js_has_path_module(double)

declare void @js_register_path_init(ptr, i64, i64)

declare i64 @js_array_alloc_with_length(i32)

declare void @js_array_set_f64_unchecked(i64, i32, double)

declare double @js_typed_feedback_array_get_f64(i64, i64, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_get_guard(i64, double, i32, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_get_guard(i64, double, i32, i32) #0

declare i32 @js_typed_feedback_packed_f64_array_loop_guard(i64, double)

declare i32 @js_string_array_range_loop_guard(double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense_i32(i64, double, i32, i32)

declare i32 @js_typed_feedback_masked_window_ta_kind(i64, double, i32, i32)

declare i64 @js_typed_array_masked_window_data_ptr(double)

declare i64 @js_packed_ecs_u32_loop_guard(double, double, double, double, double, double, i32, ptr)

declare i32 @js_typed_feedback_packed_u32_array_loop_guard(i64, double)

declare double @js_typed_feedback_array_index_get_fallback_boxed(i64, double, double)

declare void @js_typed_feedback_array_set_f64(i64, i64, i32, double)

declare i64 @js_typed_feedback_array_set_f64_extend(i64, i64, i32, double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_push_guard(i64, double, double) #0

declare double @js_typed_feedback_array_index_set_fallback_boxed(i64, double, double, double, i32)

declare void @js_typed_feedback_observe_array_element(i64, i64, i32)

declare i64 @js_typed_feedback_array_set_string_key(i64, i64, i64, double)

declare i64 @js_typed_feedback_array_set_index_or_string(i64, i64, double, double, i32)

declare void @js_typed_feedback_object_set_index_polymorphic(i64, i64, double, double)

declare double @js_proxy_new(double, double)

declare double @js_proxy_revocable(double, double)

declare void @js_proxy_revoke(double)

declare i32 @js_proxy_is_revoked(double)

declare i32 @js_proxy_is_proxy(double)

declare double @js_proxy_target(double)

declare double @js_proxy_get(double, double)

declare double @js_proxy_set(double, double, double)

declare double @js_proxy_has(double, double)

declare double @js_proxy_delete(double, double)

declare double @js_proxy_apply(double, double, double)

declare double @js_proxy_construct(double, double, double)

declare double @js_reflect_construct(double, double, double)

declare double @js_reflect_get(double, double, double)

declare double @js_reflect_set(double, double, double, double)

declare double @js_put_value_set(double, double, double, double, i32)

declare i32 @js_transition_ic_spill_append(double, i64, i32, double)

declare ptr @perry_transition_cache_base()

declare void @js_transition_ic_note_hit()

declare double @js_put_value_set_dyn_ic(ptr, double, double, double, i32)

declare double @js_put_value_set_ic_miss(double, i64, double, i32, ptr, i32)

declare i32 @js_put_value_set_ic_overflow_store(double, i64, i32, double)

declare double @js_object_get_field_ic_overflow_load(i64, i64, i32, ptr)

declare double @js_put_value_set_ic_poly_tail(ptr, double, i64, double, i32)

declare i64 @js_object_array_numeric_write_guard(double, double, double, double, double, i32, i32)

declare i64 @js_object_array_numeric_write_range_guard(double, double, double, double, double, i32, i32, i32)

declare double @js_super_put_value_set(i32, double, double, double, i32)

declare double @js_super_accessor_get(i32, double, double)

declare double @js_reflect_has(double, double)

declare double @js_reflect_delete(double, double)

declare double @js_reflect_own_keys(double)

declare double @js_reflect_apply(double, double, double)

declare double @js_reflect_define_property(double, double, double)

declare double @js_reflect_get_own_property_descriptor(double, double)

declare double @js_reflect_get_prototype_of(double)

declare double @js_reflect_set_prototype_of(double, double)

declare double @js_reflect_is_extensible(double)

declare double @js_reflect_prevent_extensions(double)

declare double @js_reflect_define_metadata(double, double, double, double)

declare double @js_reflect_get_metadata(double, double, double)

declare double @js_reflect_get_own_metadata(double, double, double)

declare double @js_reflect_has_metadata(double, double, double)

declare double @js_reflect_has_own_metadata(double, double, double)

declare double @js_reflect_get_metadata_keys(double, double)

declare double @js_reflect_get_own_metadata_keys(double, double)

declare double @js_reflect_delete_metadata(double, double, double)

declare double @js_http_server_construct_with_this(double, double, double)

declare double @js_https_server_construct_with_this(double, double, double)

declare i64 @js_net_socket_set_encoding(i64, i64)

declare double @js_vm_create_context(double, double)

declare double @js_vm_create_script_branded(double, double)

declare double @js_vm_module_call()

declare double @js_vm_module_constructor_error()

declare double @js_repl_start(double)

declare double @js_repl_repl_server_new(double)

declare double @js_repl_recoverable_new(double)

declare double @js_worker_threads_worker_new(i64, double)

declare double @js_worker_threads_worker_post_message(i64, double)

declare double @js_worker_threads_worker_on(i64, double, i64)

declare double @js_worker_threads_worker_once(i64, double, i64)

declare double @js_worker_threads_worker_off(i64, double, i64)

declare double @js_worker_threads_worker_add_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_remove_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_terminate(i64)

declare double @js_worker_threads_worker_ref(i64)

declare double @js_worker_threads_worker_unref(i64)

declare double @js_worker_threads_worker_get_heap_statistics(i64)

declare double @js_worker_threads_worker_cpu_usage(i64, double)

declare double @js_worker_threads_worker_get_heap_snapshot(i64, double)

declare double @js_worker_threads_worker_start_cpu_profile(i64)

declare double @js_worker_threads_worker_start_heap_profile(i64)

declare i64 @js_http_client_request_end(i64, double)

declare i64 @js_http_client_request_write(i64, double)

declare i64 @js_http_client_request_end_full(i64, double, i64, i64)

declare double @js_http_client_request_write_full(i64, double, i64, i64)

declare i64 @js_http_set_timeout_full(i64, double, i64)

declare i64 @js_http_client_request_method(i64)

declare i64 @js_http_client_request_protocol(i64)

declare i64 @js_http_client_request_host(i64)

declare i64 @js_http_client_request_path(i64)

declare double @js_http_client_request_listener_count(i64, i64)

declare double @js_http_client_request_get_header(i64, i64)

declare double @js_http_client_request_has_header(i64, i64)

declare double @js_http_client_request_remove_header(i64, i64)

declare double @js_http_client_request_get_header_names(i64)

declare double @js_http_client_request_get_headers(i64)

declare double @js_http_client_request_get_raw_header_names(i64)

declare double @js_http_client_request_abort(i64)

declare i64 @js_http_client_request_destroy(i64, double)

declare double @js_http_client_request_noop_undefined(i64, double, double)

declare double @js_http_client_request_aborted(i64)

declare double @js_http_client_request_destroyed(i64)

declare double @js_http_client_request_finished(i64)

declare double @js_http_client_request_reused_socket(i64)

declare double @js_http_client_request_max_headers_count(i64)

declare double @js_http_client_request_writable_ended(i64)

declare double @js_http_client_request_writable_finished(i64)

declare double @js_http_client_request_socket(i64)

declare i64 @js_http_get(double, i64)

declare i64 @js_http_get_overload(i64)

declare i64 @js_http_request_overload(i64)

declare i64 @js_https_get_overload(i64)

declare i64 @js_https_request_overload(i64)

declare i64 @js_http_on(i64, i64, i64)

declare i64 @js_http_once(i64, i64, i64)

declare i64 @js_http_request(double, i64)

declare i64 @js_http_request_body(i64)

declare double @js_http_request_body_length(i64)

declare i64 @js_http_request_content_type(i64)

declare double @js_http_request_has_header(i64, i64)

declare i64 @js_http_request_header(i64, i64)

declare i64 @js_http_request_headers_all(i64)

declare double @js_http_request_id(i64)

declare double @js_http_request_is_method(i64, i64)

declare i64 @js_http_request_method(i64)

declare i64 @js_http_request_path(i64)

declare i64 @js_http_request_query(i64)

declare i64 @js_http_request_query_all(i64)

declare i64 @js_http_request_query_param(i64, i64)

declare double @js_http_respond_error(i64, double, i64)

declare double @js_http_respond_html(i64, double, i64)

declare double @js_http_respond_json(i64, double, i64)

declare double @js_http_respond_not_found(i64)

declare double @js_http_respond_redirect(i64, i64, double)

declare i64 @js_http_respond_status_text(double)

declare double @js_http_respond_text(i64, double, i64)

declare double @js_http_respond_with_headers(i64, double, i64, i64)

declare double @js_http_response_headers(i64)

declare double @js_http_response_trailers(i64)

declare double @js_http_incoming_message_socket(i64)

declare double @js_http_incoming_message_req(i64)

declare i64 @js_http_incoming_message_set_encoding(i64, i64)

declare i64 @js_http_server_accept_v2(i64)

declare double @js_http_server_close(i64)

declare i64 @js_http_server_create(double)

declare i64 @js_http_set_header(i64, i64, i64)

declare i64 @js_http_set_timeout(i64, double)

declare double @js_http_status_code(i64)

declare i64 @js_http_status_message(i64)

declare i64 @js_http_agent_new(double)

declare i64 @js_https_agent_new(double)

declare i64 @js_http_agent_get_name(i64, double)

declare i64 @js_http_agent_noop_self(i64)

declare double @js_http_agent_max_sockets(i64)

declare double @js_http_agent_max_free_sockets(i64)

declare double @js_http_agent_max_total_sockets(i64)

declare double @js_http_agent_keep_alive_msecs(i64)

declare double @js_http_agent_keep_alive(i64)

declare i64 @js_http_agent_protocol(i64)

declare double @js_http_agent_default_port(i64)

declare void @js_http_agent_set_protocol(i64, i64)

declare i64 @js_http_agent_destroy(i64)

declare double @js_http_agent_destroyed(i64)

declare double @js_http_agent_sockets(i64)

declare double @js_http_agent_free_sockets(i64)

declare double @js_http_agent_requests(i64)

declare void @js_http_agent_set_max_sockets(i64, double)

declare void @js_http_agent_set_max_free_sockets(i64, double)

declare void @js_http_agent_set_max_total_sockets(i64, double)

declare void @js_http_agent_set_keep_alive(i64, double)

declare void @js_http_agent_set_keep_alive_msecs(i64, double)

declare void @js_http_agent_set_create_connection(i64, i64)

declare void @js_http_agent_set_create_socket(i64, i64)

declare i64 @js_http_agent_create_connection(i64)

declare i64 @js_http_agent_create_socket(i64)

declare i64 @js_https_get(double, i64)

declare i64 @js_https_request(double, i64)

declare i64 @js_node_http_create_server(i64)

declare i64 @js_node_http_server_listen(i64, i64)

declare void @js_node_http_server_close(i64, i64)

declare void @js_node_http_server_close_all_connections(i64)

declare void @js_node_http_server_close_idle_connections(i64)

declare i64 @js_node_http_server_address_json(i64)

declare i32 @js_node_http_server_listening(i64)

declare double @js_node_http_server_listening_value(i64)

declare double @js_node_http_server_on(i64, i64, i64)

declare i64 @js_node_http_im_method(i64)

declare i64 @js_node_http_im_url(i64)

declare i64 @js_node_http_im_http_version(i64)

declare i64 @js_node_http_im_headers_json(i64)

declare i64 @js_node_http_im_raw_headers_json(i64)

declare i64 @js_node_http_im_headers_distinct_json(i64)

declare i64 @js_node_http_im_trailers_json(i64)

declare i64 @js_node_http_im_raw_trailers_json(i64)

declare i64 @js_node_http_im_trailers_distinct_json(i64)

declare i32 @js_node_http_im_complete(i64)

declare i32 @js_node_http_im_aborted(i64)

declare i32 @js_node_http_im_destroyed(i64)

declare i64 @js_node_http_im_remote_address(i64)

declare double @js_node_http_im_remote_port(i64)

declare void @js_node_http_im_pause(i64)

declare void @js_node_http_im_resume(i64)

declare void @js_node_http_im_destroy(i64)

declare double @js_node_http_im_on(i64, i64, i64)

declare double @js_node_http_im_once(i64, i64, i64)

declare double @js_node_http_im_read(i64)

declare i64 @js_node_http_im_set_timeout(i64, double, i64)

declare void @js_node_http_res_set_status(i64, double)

declare double @js_node_http_res_get_status(i64)

declare void @js_node_http_res_set_status_message(i64, i64)

declare void @js_node_http_res_set_header(i64, i64, double)

declare i64 @js_node_http_res_set_header_self(i64, i64, double)

declare double @js_node_http_res_get_header(i64, i64)

declare void @js_node_http_res_remove_header(i64, i64)

declare i32 @js_node_http_res_has_header(i64, i64)

declare double @js_node_http_res_has_header_value(i64, i64)

declare i64 @js_node_http_res_get_headers_json(i64)

declare i64 @js_node_http_res_get_header_names_json(i64)

declare i64 @js_node_http_res_append_header(i64, i64, i64)

declare i64 @js_node_http_res_set_headers(i64, double)

declare double @js_node_http_res_get_status_message(i64)

declare i32 @js_node_http_res_headers_sent(i64)

declare i32 @js_node_http_res_writable_ended(i64)

declare i32 @js_node_http_res_writable_finished(i64)

declare i32 @js_node_http_res_finished(i64)

declare i32 @js_node_http_res_send_date(i64)

declare void @js_node_http_res_set_send_date(i64, double)

declare i32 @js_node_http_res_strict_content_length(i64)

declare void @js_node_http_res_set_strict_content_length(i64, double)

declare i64 @js_node_http_res_req_handle(i64)

declare void @js_node_http_res_write_head(i64, double, i64, i64)

declare i32 @js_node_http_res_write(i64, double)

declare double @js_node_http_res_write_full(i64, double, i64, i64)

declare void @js_node_http_res_add_trailers(i64, double)

declare void @js_node_http_res_end(i64, double)

declare void @js_node_http_res_end_full(i64, double, i64, i64)

declare void @js_node_http_res_flush_headers(i64)

declare void @js_node_http_res_cork(i64)

declare void @js_node_http_res_uncork(i64)

declare i64 @js_node_http_res_set_timeout(i64, double, i64)

declare void @js_node_http_res_write_early_hints(i64, double, i64)

declare void @js_node_http_res_write_continue(i64)

declare void @js_node_http_res_write_processing(i64)

declare double @js_node_http_res_on(i64, i64, i64)

declare i64 @js_node_https_create_server(double, i64)

declare i64 @js_node_https_server_listen(i64, i64)

declare void @js_node_https_server_close(i64, i64)

declare void @js_node_https_server_close_all_connections(i64)

declare void @js_node_https_server_close_idle_connections(i64)

declare i64 @js_node_https_server_address_json(i64)

declare double @js_node_https_server_on(i64, i64, i64)

declare double @js_node_https_server_listening_value(i64)

declare double @js_node_https_server_headers_timeout(i64)

declare double @js_node_https_server_set_headers_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout(i64)

declare double @js_node_https_server_set_keep_alive_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout_buffer(i64)

declare double @js_node_https_server_set_keep_alive_timeout_buffer(i64, double)

declare double @js_node_https_server_request_timeout(i64)

declare double @js_node_https_server_set_request_timeout(i64, double)

declare double @js_node_https_server_idle_timeout(i64)

declare double @js_node_https_server_set_idle_timeout(i64, double)

declare double @js_node_https_server_max_headers_count(i64)

declare double @js_node_https_server_set_max_headers_count(i64, double)

declare double @js_node_https_server_max_requests_per_socket(i64)

declare double @js_node_https_server_set_max_requests_per_socket(i64, double)

declare i64 @js_node_https_server_set_timeout_method(i64, double, i64)

declare i64 @js_node_http2_create_server(double, double)

declare i64 @js_node_http2_create_secure_server(double, i64)

declare i64 @js_node_http2_connect(double, double, i64)

declare i64 @js_node_http2_server_listen(i64, i64)

declare void @js_node_http2_server_close(i64, i64)

declare i64 @js_node_http2_server_address_json(i64)

declare double @js_node_http2_server_on(i64, i64, i64)

declare i64 @js_node_http2_get_default_settings()

declare i64 @js_node_http2_get_packed_settings(i64)

declare i64 @js_node_http2_get_unpacked_settings(i64)

declare i64 @js_pg_client_connect(i64)

declare i64 @js_pg_client_end(i64)

declare i64 @js_pg_client_new(i64)

declare i64 @js_pg_client_query(i64, i64)

declare i64 @js_pg_client_query_params(i64, i64, i64)

declare i64 @js_pg_connect(i64)

declare i64 @js_pg_create_pool(i64)

declare i64 @js_pg_pool_end(i64)

declare i64 @js_pg_pool_new(i64)

declare i64 @js_pg_pool_query(i64, i64)

declare i64 @js_ioredis_connect(i64)

declare i64 @js_ioredis_decr(i64, i64)

declare i64 @js_ioredis_del(i64, i64)

declare void @js_ioredis_disconnect(i64)

declare i64 @js_ioredis_exists(i64, i64)

declare i64 @js_ioredis_expire(i64, i64, double)

declare i64 @js_ioredis_get(i64, i64)

declare i64 @js_ioredis_hdel(i64, i64, i64)

declare i64 @js_ioredis_hget(i64, i64, i64)

declare i64 @js_ioredis_hgetall(i64, i64)

declare i64 @js_ioredis_hlen(i64, i64)

declare i64 @js_ioredis_hset(i64, i64, i64, i64)

declare i64 @js_ioredis_incr(i64, i64)

declare i64 @js_ioredis_new(i64)

declare i64 @js_ioredis_ping(i64)

declare i64 @js_ioredis_quit(i64)

declare i64 @js_ioredis_set(i64, i64, i64)

declare i64 @js_ioredis_setex(i64, i64, double, i64)

declare i64 @js_mongodb_client_close(i64)

declare i64 @js_mongodb_client_connect(i64)

declare i64 @js_mongodb_client_db(i64, i64)

declare i64 @js_mongodb_client_list_databases(i64)

declare i64 @js_mongodb_client_new(i64)

declare i64 @js_mongodb_collection_count_value(i64, double)

declare i64 @js_mongodb_collection_delete_many_value(i64, double)

declare i64 @js_mongodb_collection_delete_one_value(i64, double)

declare i64 @js_mongodb_collection_find_one_value(i64, double)

declare i64 @js_mongodb_collection_find_value(i64, double)

declare i64 @js_mongodb_collection_insert_many_value(i64, double)

declare i64 @js_mongodb_collection_insert_one_value(i64, double)

declare i64 @js_mongodb_collection_update_many_value(i64, double, double)

declare i64 @js_mongodb_collection_update_one_value(i64, double, double)

declare i64 @js_mongodb_collection_count(i64, i64)

declare i64 @js_mongodb_collection_delete_many(i64, i64)

declare i64 @js_mongodb_collection_delete_one(i64, i64)

declare i64 @js_mongodb_collection_find(i64, i64)

declare i64 @js_mongodb_collection_find_one(i64, i64)

declare i64 @js_mongodb_collection_insert_many(i64, i64)

declare i64 @js_mongodb_collection_insert_one(i64, i64)

declare i64 @js_mongodb_collection_update_many(i64, i64, i64)

declare i64 @js_mongodb_collection_update_one(i64, i64, i64)

declare i64 @js_mongodb_connect(i64)

declare i64 @js_mongodb_db_collection(i64, i64)

declare i64 @js_mongodb_db_list_collections(i64)

declare void @js_sqlite_close(i64)

declare void @js_sqlite_exec(i64, i64)

declare i64 @js_sqlite_open(i64)

declare i64 @js_sqlite_pragma(i64, i64, i64)

declare i64 @js_sqlite_prepare(i64, i64)

declare i64 @js_sqlite_stmt_all(i64, i64)

declare i64 @js_sqlite_stmt_columns(i64)

declare i64 @js_sqlite_stmt_get(i64, i64)

declare i64 @js_sqlite_stmt_run(i64, i64)

declare i64 @js_sqlite_transaction(i64, i64)

declare void @js_sqlite_transaction_commit(i64)

declare void @js_sqlite_transaction_rollback(i64)

declare i64 @js_bun_sqlite_database_call(double, double)

declare i64 @js_bun_sqlite_database_new(double, double)

declare i64 @js_bun_sqlite_database_query(i64, double)

declare i64 @js_bun_sqlite_database_run(i64, double, i64)

declare i64 @js_bun_sqlite_database_filename(i64)

declare i64 @js_bun_sqlite_database_transaction(i64, double)

declare i64 @js_bun_sqlite_statement_values(i64, i64)

declare double @js_bun_sqlite_statement_safe_integers(i64, double)

declare void @js_bun_sqlite_statement_finalize(i64)

declare i64 @js_node_sqlite_backup(double, double, double)

declare i64 @js_node_sqlite_database_sync_call(double, double)

declare i64 @js_node_sqlite_database_sync_new(double, double)

declare i32 @js_node_sqlite_database_sync_open(i64)

declare i32 @js_node_sqlite_database_sync_close(i64)

declare i32 @js_node_sqlite_database_sync_dispose(i64)

declare i32 @js_node_sqlite_database_sync_exec(i64, double)

declare i64 @js_node_sqlite_database_sync_prepare(i64, double, double)

declare i32 @js_node_sqlite_database_sync_function(i64, double, double, double)

declare i32 @js_node_sqlite_database_sync_aggregate(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_defensive(i64, double)

declare i32 @js_node_sqlite_database_sync_set_authorizer(i64, double)

declare i64 @js_node_sqlite_database_sync_create_tag_store(i64, double)

declare i64 @js_node_sqlite_database_sync_create_session(i64, double)

declare double @js_node_sqlite_database_sync_apply_changeset(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_load_extension(i64, double)

declare i32 @js_node_sqlite_database_sync_load_extension(i64, double)

declare double @js_node_sqlite_database_sync_location(i64, double)

declare double @js_node_sqlite_database_sync_is_open(i64)

declare double @js_node_sqlite_database_sync_is_transaction(i64)

declare i64 @js_node_sqlite_database_sync_limits(i64)

declare i64 @js_node_sqlite_statement_sync_call(double, double)

declare i64 @js_node_sqlite_statement_sync_new(double, double)

declare i64 @js_node_sqlite_statement_sync_run(i64, i64)

declare double @js_node_sqlite_statement_sync_get(i64, i64)

declare i64 @js_node_sqlite_statement_sync_all(i64, i64)

declare double @js_node_sqlite_statement_sync_iterate(i64, i64)

declare i64 @js_node_sqlite_statement_sync_columns(i64)

declare i32 @js_node_sqlite_statement_sync_set_read_bigints(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_return_arrays(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_bare_named_parameters(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_unknown_named_parameters(i64, double)

declare i64 @js_node_sqlite_statement_sync_source_sql(i64)

declare i64 @js_node_sqlite_statement_sync_expanded_sql(i64)

declare i64 @js_node_sqlite_sql_tag_store_run(i64, i64)

declare double @js_node_sqlite_sql_tag_store_get(i64, i64)

declare i64 @js_node_sqlite_sql_tag_store_all(i64, i64)

declare double @js_node_sqlite_sql_tag_store_iterate(i64, i64)

declare i32 @js_node_sqlite_sql_tag_store_clear(i64)

declare double @js_node_sqlite_sql_tag_store_size(i64)

declare double @js_node_sqlite_sql_tag_store_capacity(i64)

declare i64 @js_node_sqlite_sql_tag_store_db(i64)

declare i64 @js_node_sqlite_session_call(double, double)

declare i64 @js_node_sqlite_session_new(double, double)

declare i64 @js_node_sqlite_session_changeset(i64)

declare i64 @js_node_sqlite_session_patchset(i64)

declare i32 @js_node_sqlite_session_close(i64)

declare i32 @js_node_sqlite_session_dispose(i64)

declare i64 @js_os_cpus()

declare double @js_os_freemem()

declare i64 @js_os_homedir()

declare i64 @js_os_network_interfaces()

declare i64 @js_os_tmpdir()

declare double @js_os_totalmem()

declare double @js_os_uptime()

declare i64 @js_os_user_info()

declare i64 @js_os_user_info_buffer()

declare i64 @js_os_user_info_options(i64)

declare i64 @js_crypto_aes256_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_encrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_encrypt(i64, i64, i64)

declare double @js_crypto_create_cipheriv(i64, i64, i64, double)

declare double @js_crypto_create_decipheriv(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sha256(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sync(i64, i64, i64, i64, double)

declare i64 @js_crypto_pbkdf2(i64, i64, double, double)

declare i64 @js_crypto_random_bytes_hex(double)

declare i64 @js_crypto_random_nonce()

declare i64 @js_crypto_scrypt(i64, i64, double)

declare double @js_crypto_generate_key_pair_sync(i64, i64)

declare i64 @js_crypto_scrypt_custom(i64, i64, double, double, double, double)

declare i64 @js_crypto_x25519_keypair()

declare i64 @js_crypto_x25519_shared_secret(i64, i64)

declare i64 @js_keccak256_native(i64)

declare i64 @js_keccak256_native_bytes(i64)

declare i64 @js_nanoid(double)

declare i64 @js_nanoid_custom(i64, double)

declare i64 @js_argon2_hash(i64)

declare i64 @js_argon2_hash_options(i64, i64)

declare i64 @js_argon2_verify(i64, i64)

declare i64 @js_bcrypt_compare(i64, i64)

declare double @js_bcrypt_compare_sync(i64, i64)

declare i64 @js_bcrypt_gen_salt(double)

declare i64 @js_bcrypt_hash(i64, double)

declare i64 @js_bcrypt_hash_sync(i64, double)

declare i64 @js_ads_interstitial_load(i64)

declare i64 @js_ads_interstitial_show()

declare i64 @js_ads_rewarded_load(i64)

declare i64 @js_ads_rewarded_show()

declare double @js_ads_banner_create(i64, i64)

declare void @js_ads_banner_destroy(double)

declare i64 @js_ads_request_consent()

declare i64 @js_perry_read_embedded(double)

declare i64 @js_perry_embedded_files()

declare double @js_thread_parallel_map(double, double)

declare double @js_thread_parallel_filter(double, double)

declare double @js_thread_spawn(double)

declare double @js_perry_native_i8(double)

declare double @js_perry_native_i16(double)

declare double @js_perry_native_u8(double)

declare double @js_perry_native_u16(double)

declare double @js_perry_native_i32(double)

declare double @js_perry_native_i64(double)

declare double @js_perry_native_u32(double)

declare double @js_perry_native_u64(double)

declare double @js_perry_native_usize(double)

declare double @js_perry_native_isize(double)

declare double @js_perry_native_f32(double)

declare double @js_perry_native_f64(double)

declare i64 @js_jwt_decode(i64)

declare i64 @js_jwt_sign(i64, i64, double, i64)

declare i64 @js_jwt_sign_es256(i64, i64, double, i64)

declare i64 @js_jwt_sign_rs256(i64, i64, double, i64)

declare i64 @js_jwt_verify(i64, i64)

declare i64 @js_jwt_verify_es256(i64, i64)

declare i64 @js_jwt_verify_rs256(i64, i64)

declare i64 @js_jwt_sign_dyn(i64, i64, i64, double, i64)

declare i64 @js_jwt_verify_dyn(i64, i64, i64)

declare i64 @js_jwt_sign_dyn_opts(i64, i64, double)

declare i64 @js_jwt_verify_dyn_opts(i64, i64, double)

declare double @js_axios_create(i64)

declare i64 @js_axios_delete(i64)

declare i64 @js_axios_get(i64)

declare i64 @js_axios_head(i64)

declare i64 @js_axios_options(i64)

declare i64 @js_axios_post(i64, double)

declare i64 @js_axios_put(i64, double)

declare i64 @js_axios_patch(i64, double)

declare i64 @js_axios_request(i64)

declare double @js_axios_response_status(i64)

declare i64 @js_axios_response_status_text(i64)

declare i64 @js_axios_response_data(i64)

declare double @js_axios_response_data_parsed(i64)

declare i64 @js_sharp_auto_orient(i64)

declare i64 @js_sharp_avif(i64, double)

declare i64 @js_sharp_blur(i64, double)

declare i64 @js_sharp_composite(i64, double)

declare i64 @js_sharp_extend(i64, double)

declare i64 @js_sharp_extract(i64, double)

declare i64 @js_sharp_flip(i64)

declare i64 @js_sharp_flop(i64)

declare i64 @js_sharp_from_buffer(i64, double)

declare i64 @js_sharp_from_file(i64)

declare i64 @js_sharp_from_input(i64)

declare i64 @js_sharp_grayscale(i64)

declare i64 @js_sharp_metadata(i64)

declare i64 @js_sharp_sharpen(i64)

declare i64 @js_sharp_trim(i64)

declare i64 @js_sharp_negate(i64)

declare i64 @js_sharp_quality(i64, double)

declare i64 @js_sharp_resize(i64, double, double)

declare i64 @js_sharp_rotate(i64, double)

declare i64 @js_sharp_to_buffer(i64)

declare i64 @js_sharp_to_file(i64, i64)

declare i64 @js_sharp_to_format(i64, i64)

declare void @js_cron_clear_interval(i64)

declare void @js_cron_clear_timeout(i64)

declare i64 @js_cron_describe(i64)

declare double @js_cron_job_is_running(i64)

declare i64 @js_cron_job_new(i64, i64, double)

declare void @js_cron_job_start(i64)

declare void @js_cron_job_stop(i64)

declare i64 @js_cron_next_date(i64)

declare i64 @js_cron_next_dates(i64, double)

declare i64 @js_cron_schedule(i64, i64)

declare i64 @js_cron_set_interval(double, double)

declare i64 @js_cron_set_timeout(double, double)

declare i32 @js_cron_timer_has_pending()

declare i32 @js_cron_timer_tick()

declare double @js_cron_validate(i64)

declare i64 @js_async_hooks_create_hook(double)

declare double @js_async_hooks_execution_async_id()

declare double @js_async_hooks_trigger_async_id()

declare double @js_async_hooks_execution_async_resource()

declare i64 @js_async_hook_enable(i64)

declare i64 @js_async_hook_disable(i64)

declare i64 @js_async_resource_new(double, double)

declare double @js_async_resource_subclass_init(double, double, double)

declare double @js_async_resource_async_id(i64)

declare double @js_async_resource_trigger_async_id(i64)

declare i64 @js_async_resource_emit_destroy(i64)

declare double @js_async_resource_run_in_async_scope(i64, double, double, i64)

declare i64 @js_async_resource_bind(i64, double, double)

declare i64 @js_async_resource_static_bind(i64, double)

declare void @js_async_local_storage_disable(i64)

declare void @js_async_local_storage_enter_with(i64, double)

declare double @js_async_local_storage_exit(i64, double, i64)

declare double @js_async_local_storage_get_store(i64)

declare i64 @js_async_local_storage_new()

declare double @js_async_local_storage_subclass_init(double)

declare double @js_async_local_storage_run(i64, double, double, i64)

declare i64 @js_disposable_stack_new()

declare i64 @js_async_disposable_stack_new()

declare double @js_suppressed_error_new(double, double, double)

declare i64 @js_zlib_deflate_sync(i64, double)

declare void @js_zlib_deflate(double, double)

declare i64 @js_zlib_gunzip_sync(i64)

declare void @js_zlib_gunzip(double, double)

declare i64 @js_zlib_gzip_sync(i64, double)

declare void @js_zlib_gzip(double, double)

declare i64 @js_zlib_inflate_sync(i64)

declare void @js_zlib_inflate(double, double)

declare i64 @js_zlib_deflate_raw_sync(double, double)

declare void @js_zlib_deflate_raw(double, double)

declare i64 @js_zlib_inflate_raw_sync(double)

declare void @js_zlib_inflate_raw(double, double)

declare i64 @js_zlib_unzip_sync(double)

declare void @js_zlib_unzip(double, double)

declare double @js_zlib_crc32(double, double)

declare i64 @js_zlib_brotli_compress_sync(i64)

declare i64 @js_zlib_brotli_decompress_sync(i64)

declare void @js_zlib_brotli_compress(double, double)

declare void @js_zlib_brotli_decompress(double, double)

declare i64 @js_zlib_zstd_compress_sync(double, double)

declare i64 @js_zlib_zstd_decompress_sync(double, double)

declare void @js_zlib_zstd_compress(double, double)

declare void @js_zlib_zstd_decompress(double, double)

declare i64 @js_zlib_create_gzip(double)

declare i64 @js_zlib_create_gunzip(double)

declare i64 @js_zlib_create_deflate(double)

declare i64 @js_zlib_create_inflate(double)

declare i64 @js_zlib_create_deflate_raw(double)

declare i64 @js_zlib_create_inflate_raw(double)

declare i64 @js_zlib_create_unzip(double)

declare i64 @js_zlib_create_brotli_compress(double)

declare i64 @js_zlib_create_zstd_compress(double)

declare i64 @js_zlib_create_zstd_decompress(double)

declare i64 @js_buffer_alloc_unsafe(i32)

declare i32 @js_buffer_byte_length(i64)

declare i32 @js_buffer_byte_length_value(double, double)

declare i64 @js_buffer_concat(i64)

declare i64 @js_buffer_concat_with_length(i64, double)

declare i32 @js_buffer_validate_size(double)

declare i64 @js_buffer_validate_concat_list(double)

declare i32 @js_buffer_copy(i64, i64, i32, i32, i32)

declare i32 @js_buffer_equals(i64, i64)

declare i64 @js_buffer_fill(i64, i32)

declare i64 @js_buffer_from_value(i64, i32)

declare double @js_buffer_is_ascii(double)

declare i32 @js_buffer_is_buffer(i64)

declare i32 @js_buffer_is_node_buffer(i64)

declare i32 @js_buffer_is_encoding(double)

declare double @js_buffer_is_utf8(double)

declare void @js_buffer_print(i64)

declare void @js_buffer_set(i64, i32, i32)

declare void @js_buffer_set_from(i64, i64, i32)

declare i64 @js_buffer_slice(i64, i32, i32)

declare i64 @js_buffer_to_string(i64, i32)

declare i64 @js_buffer_transcode(double, double, double)

declare i32 @js_buffer_write(i64, i64, i32, i32)

declare double @js_child_process_exec_sync(i64, i64)

declare double @js_child_process_exec(i64, double, double)

declare i64 @js_child_process_get_process_status(double)

declare i32 @js_child_process_kill_process(double)

declare i64 @js_child_process_spawn_background(double, i64, double, double)

declare i64 @js_child_process_spawn_sync(i64, i64, i64)

declare double @js_child_process_spawn_streams(i64, i64, i64)

declare double @js_pty_spawn(i64, i64, i64)

declare double @js_child_process_fork(i64, i64, i64)

declare double @js_child_process_exec_file(i64, double, double, double)

declare double @js_child_process_exec_file_sync(i64, double, double)

declare double @js_child_process_validate_command(double, ptr, i32)

declare double @js_child_process_validate_args(double)

declare double @js_child_process_validate_options(double, i32, i32)

declare double @js_child_process_validate_fork_module(double)

declare double @js_child_process_validate_spawn_args(double, i32, i32)

declare double @js_child_process_new()

declare i64 @js_cheerio_load(i64)

declare i64 @js_cheerio_load_fragment(i64)

declare i64 @js_cheerio_select(i64, i64)

declare i64 @js_cheerio_selection_attr(i64, i64)

declare i64 @js_cheerio_selection_attrs(i64, i64)

declare i64 @js_cheerio_selection_children(i64, i64)

declare i64 @js_cheerio_selection_eq(i64, double)

declare i64 @js_cheerio_selection_find(i64, i64)

declare i64 @js_cheerio_selection_first(i64)

declare double @js_cheerio_selection_has_class(i64, i64)

declare i64 @js_cheerio_selection_html(i64)

declare double @js_cheerio_selection_is(i64, i64)

declare i64 @js_cheerio_selection_last(i64)

declare double @js_cheerio_selection_length(i64)

declare i64 @js_cheerio_selection_parent(i64)

declare i64 @js_cheerio_selection_text(i64)

declare i64 @js_cheerio_selection_texts(i64)

declare i64 @js_cheerio_selection_to_array(i64)

declare double @js_url_file_url_to_path(double, double)

declare double @js_url_file_url_to_path_buffer(double, double)

declare double @js_url_get_hash(i64)

declare double @js_url_get_host(i64)

declare double @js_url_get_hostname(i64)

declare double @js_url_get_href(i64)

declare double @js_url_get_origin(i64)

declare double @js_url_get_pathname(i64)

declare double @js_url_get_port(i64)

declare double @js_url_get_protocol(i64)

declare double @js_url_get_search(i64)

declare double @js_url_get_search_params(i64)

declare i64 @js_url_new(i64)

declare i64 @js_url_new_with_base(i64, i64)

declare i64 @js_url_pattern_new(double, double)

declare double @js_url_pattern_constructor_call(double, double)

declare i32 @js_url_can_parse(i64)

declare i32 @js_url_can_parse_with_base(i64, i64)

declare i64 @js_url_parse(i64)

declare i64 @js_url_parse_with_base(i64, i64)

declare void @js_url_set_pathname(i64, double)

declare void @js_url_set_search(i64, double)

declare void @js_url_set_hash(i64, double)

declare void @js_url_set_protocol(i64, double)

declare void @js_url_set_hostname(i64, double)

declare void @js_url_set_port(i64, double)

declare void @js_url_set_username(i64, double)

declare void @js_url_set_password(i64, double)

declare void @js_url_set_href(i64, double)

declare double @js_url_search_params_has2(i64, double, double)

declare void @js_url_search_params_delete2(i64, double, double)

declare double @js_url_search_params_throw_missing_args(i32)

declare void @js_url_search_params_append(i64, double, double)

declare void @js_url_search_params_delete(i64, double)

declare i64 @js_url_search_params_get(i64, double)

declare double @js_url_search_params_get_all(i64, double)

declare double @js_url_search_params_has(i64, double)

declare i64 @js_url_search_params_new(i64)

declare i64 @js_url_search_params_new_any(double)

declare i64 @js_url_search_params_new_empty()

declare double @js_url_search_params_subclass_init(double, double)

declare void @js_url_search_params_set(i64, double, double)

declare i64 @js_url_search_params_to_string(i64)

declare i32 @js_url_search_params_size(i64)

declare double @js_url_search_params_entries_arr(i64)

declare double @js_url_search_params_keys_arr(i64)

declare double @js_url_search_params_values_arr(i64)

declare void @js_url_search_params_sort(i64)

declare void @js_url_search_params_for_each(i64, double, double)

declare i64 @js_url_coerce_string(double)

declare double @js_url_path_to_file_url(double, double)

declare double @js_url_domain_to_ascii(double)

declare double @js_url_domain_to_unicode(double)

declare double @js_url_to_http_options(double)

declare double @js_url_legacy_url_new()

declare double @js_url_format(double, double)

declare double @js_url_legacy_parse(double, double, double)

declare double @js_url_legacy_resolve(double, double)

declare double @js_url_legacy_resolve_object(double, double)

declare void @js_ws_close(i64)

declare i64 @js_ws_connect(i64)

declare double @js_ws_connect_start(double)

declare i64 @js_ws_handle_to_i64(double)

declare double @js_ws_is_open(i64)

declare double @js_ws_message_count(i64)

declare double @js_ws_ready_state(i64)

declare i64 @js_ws_on(i64, i64, i64)

declare i64 @js_ws_receive(i64)

declare void @js_ws_send(i64, i64)

declare void @js_ws_send_to_client(double, i64)

declare void @js_ws_close_client(double)

declare void @js_ws_send_client_i64(i64, i64)

declare void @js_ws_close_client_i64(i64)

declare i64 @js_ws_on_client_i64(i64, i64, i64)

declare void @js_ws_server_close(i64)

declare double @js_ws_server_clients(i64)

declare double @js_ws_server_address(i64)

declare i32 @js_ws_server_emit(i64, i64, double, double)

declare i64 @js_ws_server_new(double)

declare void @js_ws_handle_upgrade(i64, double, double, double, i64)

declare i64 @js_ws_wait_for_message(i64, double)

declare i64 @js_pdf_create_pdf(double)

declare void @js_pdf_add_text(i64, i64, double, double, double)

declare void @js_pdf_add_line(i64, double, double, double, double)

declare void @js_pdf_new_page(i64)

declare void @js_pdf_save(i64)

declare i64 @js_commander_action(i64, i64)

declare i64 @js_commander_command(i64, i64)

declare i64 @js_commander_description(i64, i64)

declare i64 @js_commander_get_option(i64, i64)

declare double @js_commander_get_option_bool(i64, i64)

declare double @js_commander_get_option_number(i64, i64)

declare i64 @js_commander_name(i64, i64)

declare i64 @js_commander_new()

declare i64 @js_commander_option(i64, i64, i64, i64)

declare i64 @js_commander_opts(i64)

declare i64 @js_commander_parse(i64, double)

declare i64 @js_commander_required_option(i64, i64, i64, i64)

declare i64 @js_commander_version(i64, i64)

declare double @js_dotenv_config()

declare double @js_dotenv_config_path(i64)

declare i64 @js_dotenv_parse(i64)

declare double @js_datefns_add_days(double, double)

declare double @js_datefns_add_months(double, double)

declare double @js_datefns_add_years(double, double)

declare double @js_datefns_difference_in_days(double, double)

declare double @js_datefns_difference_in_hours(double, double)

declare double @js_datefns_difference_in_minutes(double, double)

declare double @js_datefns_end_of_day(double)

declare i64 @js_datefns_format(double, i64)

declare double @js_datefns_is_after(double, double)

declare double @js_datefns_is_before(double, double)

declare double @js_datefns_parse_iso(i64)

declare double @js_datefns_start_of_day(double)

declare double @js_dayjs_add(i64, double, i64)

declare double @js_dayjs_date(i64)

declare double @js_dayjs_day(i64)

declare double @js_dayjs_diff(i64, i64, i64)

declare double @js_dayjs_end_of(i64, i64)

declare double @js_dayjs_factory(i64)

declare i64 @js_dayjs_format(i64, i64)

declare double @js_dayjs_from_timestamp(double)

declare double @js_dayjs_hour(i64)

declare double @js_dayjs_is_after(i64, i64)

declare double @js_dayjs_is_before(i64, i64)

declare double @js_dayjs_is_same(i64, i64)

declare double @js_dayjs_is_valid(i64)

declare double @js_dayjs_millisecond(i64)

declare double @js_dayjs_minute(i64)

declare double @js_dayjs_month(i64)

declare double @js_dayjs_now()

declare double @js_dayjs_parse(i64)

declare double @js_dayjs_second(i64)

declare double @js_dayjs_start_of(i64, i64)

declare double @js_dayjs_subtract(i64, double, i64)

declare i64 @js_dayjs_to_iso_string(i64)

declare double @js_dayjs_unix(i64)

declare double @js_dayjs_value_of(i64)

declare double @js_dayjs_year(i64)

declare double @js_moment_add(i64, double, i64)

declare double @js_moment_clone(i64)

declare double @js_moment_date(i64)

declare double @js_moment_day(i64)

declare double @js_moment_diff(i64, i64, i64)

declare double @js_moment_end_of(i64, i64)

declare double @js_moment_factory(i64)

declare i64 @js_moment_format(i64, i64)

declare i64 @js_moment_from_now(i64)

declare double @js_moment_from_timestamp(double)

declare double @js_moment_hour(i64)

declare double @js_moment_is_after(i64, i64)

declare double @js_moment_is_before(i64, i64)

declare double @js_moment_is_between(i64, i64, i64)

declare double @js_moment_is_same(i64, i64, i64)

declare double @js_moment_is_valid(i64)

declare double @js_moment_millisecond(i64)

declare double @js_moment_minute(i64)

declare double @js_moment_month(i64)

declare double @js_moment_now()

declare double @js_moment_parse(i64)

declare double @js_moment_second(i64)

declare double @js_moment_start_of(i64, i64)

declare double @js_moment_subtract(i64, double, i64)

declare double @js_moment_to_date(i64)

declare i64 @js_moment_to_iso_string(i64)

declare double @js_moment_unix(i64)

declare double @js_moment_value_of(i64)

declare double @js_moment_year(i64)

declare i64 @js_decimal_abs(i64)

declare i64 @js_decimal_ceil(i64)

declare double @js_decimal_cmp(i64, i64)

declare double @js_decimal_cmp_value(i64, double)

declare i64 @js_decimal_coerce_to_handle(double)

declare i64 @js_decimal_div(i64, i64)

declare i64 @js_decimal_div_number(i64, double)

declare i64 @js_decimal_div_value(i64, double)

declare double @js_decimal_eq(i64, i64)

declare double @js_decimal_eq_value(i64, double)

declare i64 @js_decimal_floor(i64)

declare i64 @js_decimal_from_number(double)

declare i64 @js_decimal_from_string(i64)

declare double @js_decimal_gt(i64, i64)

declare double @js_decimal_gt_value(i64, double)

declare double @js_decimal_gte(i64, i64)

declare double @js_decimal_gte_value(i64, double)

declare double @js_decimal_is_negative(i64)

declare double @js_decimal_is_positive(i64)

declare double @js_decimal_is_zero(i64)

declare double @js_decimal_lt(i64, i64)

declare double @js_decimal_lt_value(i64, double)

declare double @js_decimal_lte(i64, i64)

declare double @js_decimal_lte_value(i64, double)

declare i64 @js_decimal_minus(i64, i64)

declare i64 @js_decimal_minus_number(i64, double)

declare i64 @js_decimal_minus_value(i64, double)

declare i64 @js_decimal_mod(i64, i64)

declare i64 @js_decimal_mod_value(i64, double)

declare i64 @js_decimal_neg(i64)

declare i64 @js_decimal_plus(i64, i64)

declare i64 @js_decimal_plus_number(i64, double)

declare i64 @js_decimal_plus_value(i64, double)

declare i64 @js_decimal_pow(i64, double)

declare i64 @js_decimal_round(i64)

declare i64 @js_decimal_sqrt(i64)

declare i64 @js_decimal_times(i64, i64)

declare i64 @js_decimal_times_number(i64, double)

declare i64 @js_decimal_times_value(i64, double)

declare i64 @js_decimal_to_fixed(i64, double)

declare double @js_decimal_to_number(i64)

declare i64 @js_decimal_to_string(i64)

declare i64 @js_ethers_format_ether(i64)

declare i64 @js_ethers_format_units(i64, double)

declare i64 @js_ethers_get_address(i64)

declare i64 @js_ethers_parse_ether(i64)

declare i64 @js_ethers_parse_units(i64, double)

declare i64 @js_lodash_camel_case(i64)

declare i64 @js_lodash_capitalize(i64)

declare i64 @js_lodash_chunk(i64, double)

declare double @js_lodash_clamp(double, double, double)

declare i64 @js_lodash_compact(i64)

declare i64 @js_lodash_concat(i64, i64)

declare i64 @js_lodash_difference(i64, i64)

declare i64 @js_lodash_drop(i64, double)

declare i64 @js_lodash_drop_right(i64, double)

declare double @js_lodash_ends_with(i64, i64)

declare i64 @js_lodash_escape(i64)

declare double @js_lodash_first(i64)

declare i64 @js_lodash_flatten(i64)

declare double @js_lodash_in_range(double, double, double)

declare double @js_lodash_includes(i64, i64)

declare i64 @js_lodash_initial(i64)

declare i64 @js_lodash_kebab_case(i64)

declare double @js_lodash_last(i64)

declare i64 @js_lodash_lower_case(i64)

declare i64 @js_lodash_lower_first(i64)

declare double @js_lodash_max(i64)

declare double @js_lodash_max_by(i64, double)

declare double @js_lodash_mean(i64)

declare double @js_lodash_mean_by(i64, double)

declare double @js_lodash_min(i64)

declare double @js_lodash_min_by(i64, double)

declare i64 @js_lodash_pad(i64, double)

declare i64 @js_lodash_pad_end(i64, double)

declare i64 @js_lodash_pad_start(i64, double)

declare double @js_lodash_random(double, double)

declare i64 @js_lodash_repeat(i64, double)

declare i64 @js_lodash_replace(i64, i64, i64)

declare i64 @js_lodash_reverse(i64)

declare double @js_lodash_size(i64)

declare i64 @js_lodash_snake_case(i64)

declare i64 @js_lodash_split(i64, i64)

declare i64 @js_lodash_start_case(i64)

declare double @js_lodash_starts_with(i64, i64)

declare double @js_lodash_sum(i64)

declare double @js_lodash_sum_by(i64, double)

declare i64 @js_lodash_tail(i64)

declare i64 @js_lodash_take(i64, double)

declare i64 @js_lodash_take_right(i64, double)

declare i64 @js_lodash_trim(i64)

declare i64 @js_lodash_trim_end(i64)

declare i64 @js_lodash_trim_start(i64)

declare i64 @js_lodash_truncate(i64, double)

declare i64 @js_lodash_unescape(i64)

declare i64 @js_lodash_uniq(i64)

declare i64 @js_lodash_upper_case(i64)

declare i64 @js_lodash_upper_first(i64)

declare void @js_lru_cache_clear(i64)

declare double @js_lru_cache_delete(i64, double)

declare double @js_lru_cache_get(i64, double)

declare double @js_lru_cache_has(i64, double)

declare i64 @js_lru_cache_new(double)

declare double @js_lru_cache_peek(i64, double)

declare i64 @js_lru_cache_set(i64, double, double)

declare double @js_lru_cache_size(i64)

declare double @js_event_emitter_subclass_init(double)

declare double @js_event_emitter_async_resource_subclass_init(double, double)

declare double @js_array_subclass_init(double, double)

declare double @js_array_subclass_init_args(double, ptr, i64)

declare double @js_map_set_subclass_init(double, i32, double)

declare double @js_weak_collection_subclass_init(double, i32, double)

declare double @js_promise_subclass_init(double, double)

declare double @js_node_stream_readable_new(double)

declare double @js_node_stream_readable_subclass_init(double, double)

declare double @js_node_stream_writable_new(double)

declare double @js_node_stream_writable_subclass_init(double, double)

declare double @js_node_stream_duplex_new(double)

declare double @js_node_stream_duplex_subclass_init(double, double)

declare double @js_node_stream_transform_new(double)

declare double @js_node_stream_transform_subclass_init(double, double)

declare double @js_node_stream_passthrough_new(double)

declare double @js_node_stream_readable_from(double)

declare double @js_node_stream_readable_from_options(double, double)

declare double @js_node_stream_duplex_from_options(double, double)

declare double @js_node_stream_is_disturbed(double)

declare double @js_node_stream_is_errored(double)

declare double @js_node_stream_is_readable(double)

declare double @js_node_stream_is_writable(double)

declare double @js_node_stream_is_array_buffer_view(double)

declare double @js_node_stream_is_uint8_array(double)

declare double @js_node_stream_is_destroyed(double)

declare double @js_node_stream_uint8_array_to_buffer(double)

declare double @js_node_stream_get_default_hwm(double)

declare double @js_node_stream_set_default_hwm(double, double)

declare double @js_node_stream_add_abort_signal(double, double)

declare double @js_node_stream_compose(i64)

declare double @js_node_stream_pipeline(i64)

declare double @js_node_stream_finished(i64)

declare double @js_node_stream_duplex_pair(double)

declare double @js_node_stream_readable_to_web(double)

declare double @js_node_stream_writable_to_web(double)

declare double @js_node_stream_duplex_to_web(double)

declare double @js_node_stream_readable_from_web(double, double)

declare double @js_node_stream_writable_from_web(double, double)

declare double @js_node_stream_duplex_from_web(double, double)

declare double @js_node_stream_to_web(double)

declare double @js_node_stream_from_web(double)

declare double @js_node_stream_method_readable_aborted(i64)

declare double @js_node_stream_method_closed(i64)

declare double @js_node_stream_method_errored(i64)

declare double @js_node_stream_method_readable_did_read(i64)

declare double @js_node_stream_method_destroyed(i64)

declare double @js_node_stream_method_destroy(i64, double)

declare double @js_node_stream_method_pause(i64)

declare double @js_node_stream_method_readable(i64)

declare double @js_node_stream_method_readable_length(i64)

declare double @js_node_stream_method_readable_flowing(i64)

declare double @js_node_stream_method_readable_ended(i64)

declare double @js_node_stream_method_readable_object_mode(i64)

declare double @js_node_stream_method_pipe(i64, double, double)

declare double @js_node_stream_method_unpipe(i64, double)

declare double @js_node_stream_method_is_paused(i64)

declare double @js_node_stream_method_resume(i64)

declare double @js_node_stream_method_readable_encoding(i64)

declare double @js_node_stream_method_cork(i64)

declare double @js_node_stream_method_uncork(i64)

declare double @js_node_stream_method_writable_corked(i64)

declare double @js_node_stream_method_writable_length(i64)

declare double @js_node_stream_method_writable_need_drain(i64)

declare double @js_node_stream_method_writable(i64)

declare double @js_node_stream_method_writable_ended(i64)

declare double @js_node_stream_method_writable_finished(i64)

declare double @js_node_stream_method_allow_half_open(i64)

declare double @js_node_stream_method_set_encoding(i64, double)

declare double @js_node_stream_method_writable_object_mode(i64)

declare double @js_event_emitter_emit(i64, i64, i64)

declare double @js_event_emitter_emit0(i64, i64)

declare double @js_event_emitter_listener_count(i64, i64, i64)

declare i64 @js_event_emitter_new()

declare i64 @js_event_emitter_new_with_options(double)

declare i64 @js_event_emitter_on(i64, i64, i64)

declare i64 @js_event_emitter_once(i64, i64, i64)

declare i64 @js_event_emitter_prepend_listener(i64, i64, i64)

declare i64 @js_event_emitter_prepend_once_listener(i64, i64, i64)

declare i64 @js_event_emitter_remove_all_listeners(i64, i64)

declare i64 @js_event_emitter_remove_listener(i64, i64, i64)

declare i64 @js_event_emitter_set_max_listeners(i64, double)

declare double @js_event_emitter_get_max_listeners(i64)

declare i64 @js_event_emitter_event_names(i64)

declare i64 @js_event_emitter_listeners(i64, i64)

declare i64 @js_event_emitter_raw_listeners(i64, i64)

declare double @js_event_emitter_domain_value(i64)

declare i64 @js_event_emitter_async_resource_new(double)

declare double @js_event_emitter_async_resource_call(double)

declare double @js_event_emitter_async_resource_async_id(i64)

declare double @js_event_emitter_async_resource_trigger_async_id(i64)

declare double @js_event_emitter_async_resource_async_resource(i64)

declare double @js_event_emitter_async_resource_emit_destroy(i64)

declare i64 @js_events_once(double, i64, double)

declare i64 @js_events_on(double, i64, double)

declare i64 @js_events_add_abort_listener(double, double)

declare i64 @js_events_get_event_listeners(double, i64)

declare double @js_events_listener_count(double, i64)

declare double @js_events_get_max_listeners(double)

declare double @js_events_set_max_listeners(double, i64)

declare double @js_events_init()

declare i64 @js_domain_create()

declare i64 @js_domain_on(i64, i64, i64)

declare double @js_domain_emit(i64, i64, i64)

declare double @js_domain_run(i64, double, i64)

declare double @js_domain_bind(i64, double)

declare double @js_domain_intercept(i64, double)

declare i64 @js_domain_add(i64, double)

declare i64 @js_domain_remove(i64, double)

declare double @js_domain_enter(i64)

declare double @js_domain_exit(i64)

declare i64 @js_string_decoder_new(i64)

declare double @js_string_decoder_write(i64, double)

declare double @js_string_decoder_end(i64, double)

declare double @js_querystring_escape(double)

declare double @js_querystring_unescape(double)

declare i64 @js_querystring_unescape_buffer(double, double)

declare i64 @js_querystring_parse(double, double, double, double)

declare double @js_querystring_stringify(double, double, double, double)

declare i32 @js_fastify_add_hook(i64, i64, i64)

declare i32 @js_fastify_all(i64, i64, i64)

declare i64 @js_fastify_create()

declare i64 @js_fastify_create_with_opts(double)

declare double @js_fastify_ctx_html(i64, i64, double)

declare double @js_fastify_ctx_json(i64, double, double)

declare double @js_fastify_ctx_redirect(i64, i64, double)

declare double @js_fastify_ctx_text(i64, i64, double)

declare i32 @js_fastify_delete(i64, i64, i64)

declare i32 @js_fastify_get(i64, i64, i64)

declare i32 @js_fastify_head(i64, i64, i64)

declare void @js_fastify_listen(i64, double, i64)

declare void @js_fastify_app_close(i64)

declare i64 @js_fastify_app_server(i64)

declare void @js_fastify_app_on(i64, i64, i64)

declare i32 @js_fastify_options(i64, i64, i64)

declare i32 @js_fastify_patch(i64, i64, i64)

declare i32 @js_fastify_post(i64, i64, i64)

declare i32 @js_fastify_put(i64, i64, i64)

declare i32 @js_fastify_register(i64, i64, double)

declare i64 @js_fastify_reply_header(i64, i64, i64)

declare i32 @js_fastify_reply_send(i64, double)

declare i64 @js_fastify_reply_status(i64, double)

declare i64 @js_fastify_reply_type(i64, i64)

declare i64 @js_fastify_req_body(i64)

declare double @js_fastify_req_get_user_data(i64)

declare i64 @js_fastify_req_header(i64, i64)

declare i64 @js_fastify_req_headers(i64)

declare double @js_fastify_req_json(i64)

declare i64 @js_fastify_req_method(i64)

declare i64 @js_fastify_req_param(i64, i64)

declare i64 @js_fastify_req_params(i64)

declare i64 @js_fastify_req_query(i64)

declare double @js_fastify_req_query_object(i64)

declare void @js_fastify_req_set_user_data(i64, double)

declare i64 @js_fastify_req_url(i64)

declare i32 @js_fastify_route(i64, i64, i64, i64)

declare i32 @js_fastify_set_error_handler(i64, i64)

declare double @js_nodemailer_create_transport(i64)

declare i64 @js_nodemailer_send_mail(i64, i64)

declare i64 @js_nodemailer_verify(i64)

declare i64 @js_ratelimit_block(i64, i64, double)

declare i64 @js_ratelimit_consume(i64, i64, double)

declare i64 @js_ratelimit_create(i64)

declare i64 @js_ratelimit_delete(i64, i64)

declare i64 @js_ratelimit_get(i64, i64)

declare i64 @js_ratelimit_new_from_options(i64)

declare i64 @js_ratelimit_penalty(i64, i64, double)

declare i64 @js_ratelimit_reward(i64, i64, double)

declare double @js_validator_contains(i64, i64)

declare double @js_validator_equals(i64, i64)

declare double @js_validator_is_alpha(i64)

declare double @js_validator_is_alphanumeric(i64)

declare double @js_validator_is_email(i64)

declare double @js_validator_is_empty(i64)

declare double @js_validator_is_float(i64)

declare double @js_validator_is_hexadecimal(i64)

declare double @js_validator_is_int(i64)

declare double @js_validator_is_json(i64)

declare double @js_validator_is_length(i64, double, double)

declare double @js_validator_is_lowercase(i64)

declare double @js_validator_is_numeric(i64)

declare double @js_validator_is_uppercase(i64)

declare double @js_validator_is_url(i64)

declare double @js_validator_is_uuid(i64)

declare i64 @js_date_to_locale_string(double)

declare i64 @js_number_to_locale_string(double)

declare double @js_value_to_locale_string(double)

declare i64 @js_string_split_regex(i64, i64)

declare i32 @js_object_delete_dynamic(i64, double)

declare double @js_object_get_prototype_of(double)

declare double @js_object_set_prototype_of(double, double)

declare double @js_object_define_properties(double, double)

declare double @js_math_acos(double)

declare double @js_math_asin(double)

declare double @js_math_atan(double)

declare double @js_math_atan2(double, double)

declare double @js_math_cos(double)

declare double @js_math_expm1(double)

declare double @js_math_log(double)

declare double @js_math_log10(double)

declare double @js_math_log1p(double)

declare double @js_math_log2(double)

declare double @js_math_sin(double)

declare double @js_math_tan(double)

declare double @js_atomics_load(ptr, double, double)

declare double @js_atomics_is_lock_free(ptr, double)

declare double @js_atomics_store(ptr, double, double, double)

declare double @js_atomics_add(ptr, double, double, double)

declare double @js_atomics_sub(ptr, double, double, double)

declare double @js_atomics_and(ptr, double, double, double)

declare double @js_atomics_or(ptr, double, double, double)

declare double @js_atomics_xor(ptr, double, double, double)

declare double @js_atomics_exchange(ptr, double, double, double)

declare double @js_atomics_compare_exchange(ptr, double, double, double, double)

declare double @js_atomics_notify(ptr, double, double, double)

declare double @js_atomics_wait(ptr, double, double, double, double)

declare double @js_atomics_wait_async(ptr, double, double, double, double)

declare double @js_number_is_finite(double)

declare double @js_json_get_bool(i64, i64)

declare double @js_json_get_number(i64, i64)

declare i64 @js_json_get_string(i64, i64)

declare double @js_json_is_valid(i64)

declare i64 @js_json_stringify_bool(double)

declare i64 @js_json_stringify_null()

declare i64 @js_json_stringify_number(double)

declare i64 @js_json_stringify_string(i64)

declare void @js_set_property(double, i64, i64, double)

declare i64 @js_error_get_message(i64)

declare double @js_await_js_promise(double)

declare i64 @js_text_decoder_decode(i64)

declare i64 @js_text_encoder_encode(double)

declare double @js_call_function(i64, i64, i64, i64, i64)

declare double @js_call_method(double, i64, i64, i64, i64)

declare double @js_call_value(double, i64, i64)

declare double @js_closure_call_array(i64, ptr, i64)

declare double @js_closure_call_apply_with_spread(double, ptr, i64, i64)

declare double @js_create_callback(i64, i64, i64)

declare double @js_dynamic_neg(double)

declare double @js_dynamic_pos(double)

declare i32 @js_dynamic_string_equals(double, double)

declare double @js_is_nan(double)

declare i32 @js_jsvalue_compare(double, double)

declare i32 @js_jsvalue_loose_equals(double, double)

declare void @js_gc_collect()

declare void @js_console_assert(double, i64)

declare void @js_console_assert_spread(double, i64)

declare void @js_console_group(i64)

declare double @js_console_context(double)

declare double @js_console_create_task(double)

declare i64 @js_fetch_input_ptr(double)

declare i64 @js_fetch_get(i64)

declare i64 @js_fetch_get_with_auth(i64, i64)

declare i64 @js_fetch_post(i64, i64, i64)

declare i64 @js_fetch_post_with_auth(i64, i64, i64)

declare double @js_fetch_stream_close(double)

declare i64 @js_fetch_stream_poll(double)

declare double @js_fetch_stream_start(i64, i64, i64, i64)

declare double @js_fetch_stream_status(double)

declare i64 @js_fetch_text(i64)

declare i64 @js_fetch_with_options(i64, i64, i64, i64)

declare void @js_fetch_set_pending_signal(double)

declare i64 @js_fetch_headers_to_json(double)

declare double @js_net_create_connection(i32, i64, i64)

declare i64 @js_net_create_server(i64, i64)

declare i64 @js_ext_net_create_server(i64, i64)

declare i64 @js_ext_net_socket_connect(double, double, double)

declare double @js_net_normalize_args(double)

declare double @js_net_create_server_handle_stub(double, double, double, double, double)

declare void @js_net_validate_create_server_options(double)

declare i64 @js_net_socket_set_timeout(i64, double, i64)

declare void @js_net_server_listen(i64, double, double, double)

declare void @js_net_server_close(i64, i64)

declare i64 @js_net_server_address(i64)

declare void @js_net_server_on(i64, i64, i64)

declare double @js_net_server_get_listening(i64)

declare double @js_net_server_get_connections(i64)

declare double @js_net_server_get_max_connections(i64)

declare double @js_net_server_set_max_connections(i64, double)

declare double @js_net_server_get_drop_max_connection(i64)

declare double @js_net_server_set_drop_max_connection(i64, double)

declare i64 @js_net_block_list_new()

declare double @js_net_block_list_is_block_list(double)

declare double @js_net_block_list_add_address(i64, i64, i64)

declare double @js_net_block_list_add_range(i64, i64, i64, i64)

declare double @js_net_block_list_add_subnet(i64, i64, double, i64)

declare double @js_net_block_list_check(i64, i64, i64)

declare double @js_net_block_list_to_json(i64)

declare i64 @js_net_block_list_rules(i64)

declare double @js_net_block_list_from_json(i64, double)

declare i64 @js_net_socket_address_new(double)

declare double @js_net_socket_address_parse(i64)

declare i64 @js_net_socket_address_get_address(i64)

declare i64 @js_net_socket_address_get_family(i64)

declare double @js_net_socket_address_get_port(i64)

declare double @js_net_socket_address_get_flowlabel(i64)

declare double @js_net_socket_get_type_of_service(i64)

declare i64 @js_net_socket_set_type_of_service(i64, double)

declare i64 @js_net_socket_address(i64)

declare i64 @js_net_socket_once(i64, i64, i64)

declare i64 @js_ext_net_socket_once(i64, i64, i64)

declare void @js_ext_net_socket_on(i64, i64, i64)

declare i64 @js_ext_tls_connect(double, double, double, double)

declare i64 @js_net_socket_remove_listener(i64, i64, i64)

declare i64 @js_net_socket_remove_all_listeners(i64, i64)

declare double @js_net_socket_listener_count(i64, i64)

declare i64 @js_net_socket_event_names(i64)

declare i64 @js_net_socket_reset_and_destroy(i64)

declare i64 @js_net_server_once(i64, i64, i64)

declare i64 @js_net_server_remove_listener(i64, i64, i64)

declare i64 @js_net_server_remove_all_listeners(i64, i64)

declare double @js_net_server_listener_count(i64, i64)

declare i64 @js_net_server_event_names(i64)

declare double @js_performance_now()

declare double @js_perf_mark(double, double)

declare double @js_perf_measure(double, double, double)

declare double @js_perf_get_entries()

declare double @js_perf_get_entries_by_type(double)

declare double @js_perf_get_entries_by_name(double, double)

declare double @js_perf_clear_marks(double)

declare double @js_perf_clear_measures(double)

declare double @js_perf_event_loop_utilization(double, double)

declare double @js_perf_to_json()

declare double @js_perf_clear_resource_timings()

declare double @js_perf_set_resource_timing_buffer_size(double)

declare double @js_perf_mark_resource_timing(double, double, double, double, double, double, double, double)

declare double @js_perf_timerify(double, double)

declare double @js_perf_observer_new(double)

declare double @js_perf_observer_observe(double, double)

declare double @js_perf_observer_disconnect(double)

declare double @js_perf_observer_take_records(double)

declare double @js_perf_monitor_event_loop_delay(double)

declare double @js_perf_create_histogram(double)

declare double @js_iter_result_set(double, i32)

declare double @js_iter_result_set_f64(double, i32)

declare double @js_iter_result_set_i32(i32, i32)

declare double @js_iter_result_set_i1(i32, i32)

declare double @js_iter_result_get_value()

declare double @js_iter_result_get_value_f64()

declare i32 @js_iter_result_get_value_i32()

declare i32 @js_iter_result_get_value_i1()

declare double @js_iter_result_get_done()

declare i64 @js_async_step_chain(double, i64)

declare i64 @js_async_step_done(double, i64)

declare i64 @js_get_current_step_closure()

declare double @js_async_first_call(double)

declare double @js_async_generator_resume(double, double, double)

declare void @js_register_class_getter(i64, i64, i64, i64)

declare void @js_register_class_setter(i64, i64, i64, i64)

declare void @js_register_class_string_member_order(i64, i64, i64, i64, i64)

declare void @js_register_class_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_getter(i64, i64, i64, i64)

declare void @js_register_class_static_setter(i64, i64, i64, i64)

declare void @js_register_class_method(i64, i64, i64, i64, i64, i64, i64)

declare void @js_register_class_constructor(i64, i64, i64, i64)

declare void @js_register_class_constructor_flags(i64, i64, i64)

declare void @js_register_class_static_method(i64, i64, i64, i64, i64, i64)

declare double @js_class_static_method_call(double, i64, i64, ptr, i64)

declare double @js_class_method_bind(double, i64, i64)

declare double @js_class_method_snapshot_bind(double, i64, i64)

declare double @js_class_method_bind_by_id(double, i64)

declare double @js_class_lexical_binding_get(double)

declare double @js_class_lexical_binding_set(double, double)

declare double @js_class_prototype_method_value(double, double)

declare double @js_implicit_this_get()

declare double @js_implicit_this_get_sloppy()

declare double @js_implicit_this_set(double)

declare double @js_static_this_resolve(double)

declare void @js_static_this_arm_classref(i32)

declare void @js_static_this_arm_value(double)

declare double @js_ctor_return_override(double, double, i32)

declare double @js_new_target_get()

declare double @js_new_target_set(double)

declare void @js_derived_super_scope_push(ptr)

declare void @js_derived_super_scope_pop()

declare double @js_derived_super_bind_current()

declare double @js_derived_this_check_current()

declare double @js_get_export(i64, i64, i64)

declare double @js_get_property(double, i64, i64)

declare i64 @js_load_module(i64, i64)

declare double @js_module_dynamic_import_apply_hooks(double)

declare double @js_native_call_method_nullsafe(double, i64, i64, i64, i64)

declare double @js_native_call_value(double, i64, i64)

declare double @js_new_from_handle(double, i64, i64)

declare double @js_new_instance(i64, i64, i64, i64, i64)

declare void @js_runtime_init()

declare double @js_object_set_symbol_method(double, double, double)

declare double @js_object_set_method_by_name(double, double, double)

declare double @js_object_define_accessor(double, double, double, double)

declare double @js_object_literal_set_computed(double, double, double)

declare double @js_object_literal_to_property_key(double)

declare double @js_object_literal_set_prototype(double, double)

declare double @js_to_primitive(double, i32)

declare void @js_register_class_has_instance(i32, i64)

declare void @js_register_class_to_string_tag(i32, i64)

declare double @js_object_to_string(double)

declare double @js_object_group_by(double, double)

declare double @js_map_group_by(double, double)

declare double @js_array_from_async(double, double, double)

declare double @js_jsx(double, double)

declare double @js_jsxs(double, double)

declare i64 @js_node_http_server_ref(i64)

declare i64 @js_node_http_server_unref(i64)

declare i64 @js_node_https_server_ref(i64)

declare i64 @js_node_https_server_unref(i64)

declare double @js_http_client_request_flush_headers(i64, double, double)

declare double @js_node_http_im_http_version_major(i64)

declare double @js_node_http_im_http_version_minor(i64)

declare i64 @js_node_http_im_pause_self(i64)

declare i64 @js_node_http_im_resume_self(i64)

declare i64 @js_commander_args_array(i64)

declare i64 @js_commander_argument(i64, i64)

declare double @__ic_decl_3()

declare double @__ic_decl_5()

declare double @__ic_decl_9()

declare double @__ic_decl_11()

declare double @__ic_decl_17()

declare double @__ic_decl_20()

declare double @__ic_decl_23()

declare double @__ic_decl_27()

declare double @__ic_decl_29()

declare double @__ic_decl_31()

declare double @__ic_decl_33()

declare double @__ic_decl_35()

declare token @llvm.experimental.gc.statepoint.p0(i64 immarg, i32 immarg, ptr, i32 immarg, i32 immarg, ...)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token, i32 immarg, i32 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.experimental.gc.result.i1(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i8 @llvm.experimental.gc.result.i8(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i16 @llvm.experimental.gc.result.i16(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.experimental.gc.result.i32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i64 @llvm.experimental.gc.result.i64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i128 @llvm.experimental.gc.result.i128(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.experimental.gc.result.f32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare double @llvm.experimental.gc.result.f64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr @llvm.experimental.gc.result.p0(token) #3

; Function Attrs: optsize
define internal double @"perry_fn_test_json_string_emitters_ts__identity$spec_b_b"(double %arg3, double %arg4) #6 gc "statepoint-example" {
entry.0:
  %rs4gc.b1 = bitcast double %arg3 to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg4 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %r3.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r3.rs4o = call i64 asm "", "=r,0"(i64 %r3.rs4i) #9
  %r3 = bitcast i64 %r3.rs4o to double
  ret double %r3
}

; Function Attrs: optsize
define internal double @"perry_fn_test_json_string_emitters_ts__allocateString$spec_b_b"(double %arg8, double %arg9) #6 gc "statepoint-example" {
entry.0:
  %r104 = load <2 x i64>, ptr @perry_class_header_image_test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c, align 16
  %r486 = alloca [32 x double], align 8
  %rs4gc.b3 = bitcast double %arg8 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %rs4gc.b4 = bitcast double %arg9 to i64
  %rs4gc.s4 = inttoptr i64 %rs4gc.b4 to ptr addrspace(1)
  %r3.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3 to i64
  %r3.rs4o = call i64 asm "", "=r,0"(i64 %r3.rs4i) #9
  %r3 = bitcast i64 %r3.rs4o to double
  %r4 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r5 = bitcast double %r3 to i64
  %r6 = bitcast double %r4 to i64
  %r7 = icmp eq i64 %r5, %r6
  br i1 %r7, label %streqlit.true.7, label %streqlit.sso.1

streqlit.sso.1:                                   ; preds = %entry.0
  %r8 = icmp eq i64 %r5, 9221406112018359668
  br i1 %r8, label %streqlit.true.7, label %streqlit.tag.2

streqlit.tag.2:                                   ; preds = %streqlit.sso.1
  %r9 = lshr i64 %r5, 48
  %r10 = icmp eq i64 %r9, 32767
  %r11 = and i64 %r5, 281474976710655
  %r12 = icmp ugt i64 %r11, 4095
  %r13 = and i1 %r10, %r12
  br i1 %r13, label %streqlit.len.3, label %streqlit.false.8

streqlit.len.3:                                   ; preds = %streqlit.tag.2
  %r14 = inttoptr i64 %r11 to ptr
  %r15 = getelementptr inbounds nuw i8, ptr %r14, i64 4
  %r16 = load i32, ptr %r15, align 4
  %r17 = icmp eq i32 %r16, 4
  br i1 %r17, label %streqlit.b0.4, label %streqlit.false.8

streqlit.b0.4:                                    ; preds = %streqlit.len.3
  %r18 = getelementptr inbounds nuw i8, ptr %r14, i64 20
  %r19 = load i8, ptr %r18, align 1
  %r20 = icmp eq i8 %r19, 116
  br i1 %r20, label %streqlit.bl.5, label %streqlit.false.8

streqlit.bl.5:                                    ; preds = %streqlit.b0.4
  %r21 = getelementptr inbounds nuw i8, ptr %r14, i64 23
  %r22 = load i8, ptr %r21, align 1
  %r23 = icmp eq i8 %r22, 116
  br i1 %r23, label %streqlit.slow.6, label %streqlit.false.8

streqlit.slow.6:                                  ; preds = %streqlit.bl.5
  %r24 = and i64 %r6, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r11, i64 %r24, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4, ptr addrspace(1) %rs4gc.s3) ]
  %r2510 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token)
  %rs4gc.s4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s4, %rs4gc.s4)
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%rs4gc.s3, %rs4gc.s3)
  %r26 = icmp ne i32 %r2510, 0
  br label %streqlit.merge.9

streqlit.true.7:                                  ; preds = %streqlit.sso.1, %entry.0
  br label %streqlit.merge.9

streqlit.false.8:                                 ; preds = %streqlit.bl.5, %streqlit.b0.4, %streqlit.len.3, %streqlit.tag.2
  br label %streqlit.merge.9

streqlit.merge.9:                                 ; preds = %streqlit.false.8, %streqlit.true.7, %streqlit.slow.6
  %.074 = phi ptr addrspace(1) [ %rs4gc.s3, %streqlit.true.7 ], [ %rs4gc.s3.relocated, %streqlit.slow.6 ], [ %rs4gc.s3, %streqlit.false.8 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s4, %streqlit.true.7 ], [ %rs4gc.s4.relocated, %streqlit.slow.6 ], [ %rs4gc.s4, %streqlit.false.8 ]
  %r27 = phi i1 [ true, %streqlit.true.7 ], [ false, %streqlit.false.8 ], [ %r26, %streqlit.slow.6 ]
  %r28 = select i1 %r27, i64 9222246136947933188, i64 9222246136947933187
  %r29 = bitcast i64 %r28 to double
  %r30 = icmp eq i64 %r28, 9222246136947933188
  br i1 %r30, label %if.then.10, label %if.else.11

if.then.10:                                       ; preds = %streqlit.merge.9
  %statepoint_token11 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0)
  %r3212 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token11)
  %r33 = or i64 %r3212, 9222527611924643840
  %r34 = bitcast i64 %r33 to double
  %rs4gc.b5 = bitcast double %r34 to i64
  %rs4gc.s5 = inttoptr i64 %rs4gc.b5 to ptr addrspace(1)
  %r35.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s5 to i64
  %r35 = call i64 asm "", "=r,0"(i64 %r35.rs4i) #9
  %r36 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r37 = icmp ne i32 %r36, 0
  br i1 %r37, label %shadow.root.barrier.13, label %shadow.root.barrier.done.14

if.else.11:                                       ; preds = %streqlit.merge.9
  br label %if.merge.12

if.merge.12:                                      ; preds = %if.else.11
  %r648.rs4i = ptrtoint ptr addrspace(1) %.074 to i64
  %r648.rs4o = call i64 asm "", "=r,0"(i64 %r648.rs4i) #9
  %r648 = bitcast i64 %r648.rs4o to double
  %r649 = load double, ptr @test_json_string_emitters_ts_.str.5.handle, align 8
  %r650 = bitcast double %r648 to i64
  %r651 = bitcast double %r649 to i64
  %r652 = icmp eq i64 %r650, %r651
  br i1 %r652, label %streqlit.true.138, label %streqlit.sso.132

shadow.root.barrier.13:                           ; preds = %if.then.10
  call void @js_write_barrier_root_nanbox(i64 %r35) #9
  br label %shadow.root.barrier.done.14

shadow.root.barrier.done.14:                      ; preds = %shadow.root.barrier.13, %if.then.10
  %r38 = bitcast double %r34 to i64
  %r39 = and i64 %r38, 281474976710655
  call void @js_array_declare_all_pointer_elements(i64 %r39) #9
  br label %for.cond.15

for.cond.15:                                      ; preds = %for.update.17, %shadow.root.barrier.done.14
  %r74.0 = phi ptr [ null, %shadow.root.barrier.done.14 ], [ %r74.1, %for.update.17 ]
  %r40.0 = phi double [ 0.000000e+00, %shadow.root.barrier.done.14 ], [ %r261, %for.update.17 ]
  %r31.0.base = phi ptr addrspace(1) [ %rs4gc.s5, %shadow.root.barrier.done.14 ], [ %.087, %for.update.17 ], !is_base_value !0
  %r31.0 = phi ptr addrspace(1) [ %rs4gc.s5, %shadow.root.barrier.done.14 ], [ %.088, %for.update.17 ]
  %r42 = fcmp olt double %r40.0, 4.800000e+01
  %r43 = select i1 %r42, i64 9222246136947933188, i64 9222246136947933187
  %r44 = bitcast i64 %r43 to double
  %r45 = icmp eq i64 %r43, 9222246136947933188
  br i1 %r45, label %for.body.16, label %for.exit.18

for.body.16:                                      ; preds = %for.cond.15
  %r47 = load double, ptr @test_json_string_emitters_ts_.str.1.handle, align 8
  %r49 = fcmp oge double %r40.0, 0.000000e+00
  %r50 = fcmp olt double %r40.0, 3.200000e+01
  %r51 = and i1 %r49, %r50
  br i1 %r51, label %csite.chk.19, label %csite.plain.22

for.update.17:                                    ; preds = %gcpoll.done.60
  %r261 = fadd double %r40.0, 1.000000e+00
  br label %for.cond.15

for.exit.18:                                      ; preds = %for.cond.15
  %r263 = load double, ptr @test_json_string_emitters_ts_.str.2.handle, align 8
  %r264.rs4i = ptrtoint ptr addrspace(1) %r31.0 to i64
  %r264.rs4o = call i64 asm "", "=r,0"(i64 %r264.rs4i) #9
  %r264 = bitcast i64 %r264.rs4o to double
  %r265 = bitcast double %r264 to i64
  %r266 = and i64 %r265, 281474976710655
  %r267 = lshr i64 %r265, 48
  %r268 = icmp eq i64 %r267, 32765
  %r269 = icmp ugt i64 %r266, 1048575
  %r270 = and i1 %r268, %r269
  br i1 %r270, label %arr.guard.deref.65, label %arr.fallback.62

csite.chk.19:                                     ; preds = %for.body.16
  %r52 = fptosi double %r40.0 to i32
  %r53 = sitofp i32 %r52 to double
  %r54 = fcmp oeq double %r53, %r40.0
  %r55 = sext i32 %r52 to i64
  %r56 = getelementptr [32 x i64], ptr @perry_concat_site_test_json_string_emitters_ts__0, i64 0, i64 %r55
  %r57 = load i64, ptr %r56, align 8
  %r58 = icmp ne i64 %r57, 0
  %r59 = and i1 %r54, %r58
  br i1 %r59, label %csite.hit.20, label %csite.fill.21

csite.hit.20:                                     ; preds = %csite.chk.19
  %r60 = bitcast i64 %r57 to double
  br label %csite.merge.23

csite.fill.21:                                    ; preds = %csite.chk.19
  %r61 = bitcast double %r47 to i64
  %r62 = and i64 %r61, 281474976710655
  %statepoint_token13 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, double)) @js_string_concat_site_value, i32 3, i32 0, i64 ptrtoint (ptr @perry_concat_site_test_json_string_emitters_ts__0 to i64), i64 %r62, double %r40.0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r31.0.base, ptr addrspace(1) %r31.0) ]
  %r6414 = call double @llvm.experimental.gc.result.f64(token %statepoint_token13)
  %r31.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token13, i32 0, i32 0) ; (%r31.0.base, %r31.0.base)
  %r31.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token13, i32 0, i32 1) ; (%r31.0.base, %r31.0)
  br label %csite.merge.23

csite.plain.22:                                   ; preds = %for.body.16
  %r65 = bitcast double %r47 to i64
  %r66 = and i64 %r65, 281474976710655
  %statepoint_token15 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r66, double %r40.0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r31.0.base, ptr addrspace(1) %r31.0) ]
  %r6716 = call double @llvm.experimental.gc.result.f64(token %statepoint_token15)
  %r31.0.base.relocated17 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token15, i32 0, i32 0) ; (%r31.0.base, %r31.0.base)
  %r31.0.relocated18 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token15, i32 0, i32 1) ; (%r31.0.base, %r31.0)
  br label %csite.merge.23

csite.merge.23:                                   ; preds = %csite.plain.22, %csite.fill.21, %csite.hit.20
  %.077 = phi ptr addrspace(1) [ %r31.0, %csite.hit.20 ], [ %r31.0.relocated, %csite.fill.21 ], [ %r31.0.relocated18, %csite.plain.22 ]
  %.075 = phi ptr addrspace(1) [ %r31.0.base, %csite.hit.20 ], [ %r31.0.base.relocated, %csite.fill.21 ], [ %r31.0.base.relocated17, %csite.plain.22 ]
  %r68 = phi double [ %r60, %csite.hit.20 ], [ %r6414, %csite.fill.21 ], [ %r6716, %csite.plain.22 ]
  %r69 = bitcast double %r68 to i64
  %rs4gc.s6 = inttoptr i64 %r69 to ptr addrspace(1)
  %r71.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r71 = call i64 asm "", "=r,0"(i64 %r71.rs4i) #9
  %r72 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r73 = icmp ne i32 %r72, 0
  br i1 %r73, label %shadow.root.barrier.24, label %shadow.root.barrier.done.25

shadow.root.barrier.24:                           ; preds = %csite.merge.23
  call void @js_write_barrier_root_nanbox(i64 %r71) #9
  br label %shadow.root.barrier.done.25

shadow.root.barrier.done.25:                      ; preds = %shadow.root.barrier.24, %csite.merge.23
  %r76 = icmp eq ptr %r74.0, null
  br i1 %r76, label %arena_state.init.26, label %arena_state.ready.27

arena_state.init.26:                              ; preds = %shadow.root.barrier.done.25
  %r77 = load atomic i64, ptr @PERRY_HOT_TSD_KEY monotonic, align 8
  %r78 = icmp ne i64 %r77, -1
  br i1 %r78, label %arena_state.hot_tls.tsd.28, label %arena_state.hot_tls.slow.30

arena_state.ready.27:                             ; preds = %arena_state.hot_tls.resolved.32, %shadow.root.barrier.done.25
  %.083 = phi ptr addrspace(1) [ %.184, %arena_state.hot_tls.resolved.32 ], [ %rs4gc.s6, %shadow.root.barrier.done.25 ]
  %.178 = phi ptr addrspace(1) [ %.279, %arena_state.hot_tls.resolved.32 ], [ %.077, %shadow.root.barrier.done.25 ]
  %.176 = phi ptr addrspace(1) [ %.2, %arena_state.hot_tls.resolved.32 ], [ %.075, %shadow.root.barrier.done.25 ]
  %r74.1 = phi ptr [ %r74.2, %arena_state.hot_tls.resolved.32 ], [ %r74.0, %shadow.root.barrier.done.25 ]
  %r92 = phi ptr [ %r74.0, %shadow.root.barrier.done.25 ], [ %r91, %arena_state.hot_tls.resolved.32 ]
  %r93 = getelementptr i8, ptr %r92, i64 8
  %r94 = load i64, ptr %r93, align 8
  %r95 = add i64 %r94, 40
  %r96 = getelementptr i8, ptr %r92, i64 16
  %r97 = load i64, ptr %r96, align 8
  %r98 = icmp ule i64 %r95, %r97
  br i1 %r98, label %alloc.fast.33, label %alloc.slow.34

arena_state.hot_tls.tsd.28:                       ; preds = %arena_state.init.26
  %r79 = call i64 asm sideeffect "mrs $0, tpidrro_el0", "=r"() #9
  %r80 = and i64 %r79, -8
  %r81 = shl i64 %r77, 3
  %r82 = add i64 %r80, %r81
  %r83 = inttoptr i64 %r82 to ptr
  %r84 = load ptr, ptr %r83, align 8
  %r85 = icmp ne ptr %r84, null
  br i1 %r85, label %arena_state.hot_tls.fast.29, label %arena_state.hot_tls.slow.30

arena_state.hot_tls.fast.29:                      ; preds = %arena_state.hot_tls.tsd.28
  %r86 = getelementptr i8, ptr %r84, i64 8
  %r87 = load ptr, ptr %r86, align 8
  %r88 = load ptr, ptr %r87, align 8
  %r89 = icmp ne ptr %r88, null
  br i1 %r89, label %arena_state.hot_tls.ready.31, label %arena_state.hot_tls.slow.30

arena_state.hot_tls.slow.30:                      ; preds = %arena_state.hot_tls.fast.29, %arena_state.hot_tls.tsd.28, %arena_state.init.26
  %statepoint_token19 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr ()) @js_inline_arena_state, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.075, ptr addrspace(1) %.077, ptr addrspace(1) %rs4gc.s6) ]
  %r9020 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token19)
  %r31.0.base.relocated21 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 0, i32 0) ; (%.075, %.075)
  %r31.0.relocated22 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 0, i32 1) ; (%.075, %.077)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 2, i32 2) ; (%rs4gc.s6, %rs4gc.s6)
  br label %arena_state.hot_tls.resolved.32

arena_state.hot_tls.ready.31:                     ; preds = %arena_state.hot_tls.fast.29
  br label %arena_state.hot_tls.resolved.32

arena_state.hot_tls.resolved.32:                  ; preds = %arena_state.hot_tls.ready.31, %arena_state.hot_tls.slow.30
  %.184 = phi ptr addrspace(1) [ %rs4gc.s6, %arena_state.hot_tls.ready.31 ], [ %rs4gc.s6.relocated, %arena_state.hot_tls.slow.30 ]
  %.279 = phi ptr addrspace(1) [ %.077, %arena_state.hot_tls.ready.31 ], [ %r31.0.relocated22, %arena_state.hot_tls.slow.30 ]
  %.2 = phi ptr addrspace(1) [ %.075, %arena_state.hot_tls.ready.31 ], [ %r31.0.base.relocated21, %arena_state.hot_tls.slow.30 ]
  %r74.2 = phi ptr [ %r87, %arena_state.hot_tls.ready.31 ], [ %r9020, %arena_state.hot_tls.slow.30 ]
  %r91 = phi ptr [ %r87, %arena_state.hot_tls.ready.31 ], [ %r9020, %arena_state.hot_tls.slow.30 ]
  br label %arena_state.ready.27

alloc.fast.33:                                    ; preds = %arena_state.ready.27
  store i64 %r95, ptr %r93, align 8
  %r99 = load ptr, ptr %r92, align 8
  %r100 = getelementptr i8, ptr %r99, i64 %r94
  br label %alloc.merge.35

alloc.slow.34:                                    ; preds = %arena_state.ready.27
  %statepoint_token23 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr (ptr, i64, i64)) @js_inline_arena_slow_alloc, i32 3, i32 0, ptr %r92, i64 40, i64 8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.176, ptr addrspace(1) %.178, ptr addrspace(1) %.083) ]
  %r10124 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token23)
  %r31.0.base.relocated25 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token23, i32 0, i32 0) ; (%.176, %.176)
  %r31.0.relocated26 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token23, i32 0, i32 1) ; (%.176, %.178)
  %rs4gc.s6.relocated27 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token23, i32 2, i32 2) ; (%.083, %.083)
  br label %alloc.merge.35

alloc.merge.35:                                   ; preds = %alloc.slow.34, %alloc.fast.33
  %.285 = phi ptr addrspace(1) [ %.083, %alloc.fast.33 ], [ %rs4gc.s6.relocated27, %alloc.slow.34 ]
  %.380 = phi ptr addrspace(1) [ %.178, %alloc.fast.33 ], [ %r31.0.relocated26, %alloc.slow.34 ]
  %.3 = phi ptr addrspace(1) [ %.176, %alloc.fast.33 ], [ %r31.0.base.relocated25, %alloc.slow.34 ]
  %r102 = phi ptr [ %r100, %alloc.fast.33 ], [ %r10124, %alloc.slow.34 ]
  store <2 x i64> %r104, ptr %r102, align 8
  %r106 = getelementptr i8, ptr %r102, i64 16
  store i64 0, ptr %r106, align 8
  %r107 = getelementptr i8, ptr %r102, i64 24
  store i64 9222246136947933185, ptr %r107, align 8
  %r108 = getelementptr i8, ptr %r102, i64 32
  store i64 9222246136947933185, ptr %r108, align 8
  %r109 = getelementptr i8, ptr %r102, i64 8
  %r110 = ptrtoint ptr %r109 to i64
  %r111 = load atomic i32, ptr @PERRY_PER_OBJECT_LAYOUTS_ANY monotonic, align 4
  %r112 = icmp ne i32 %r111, 0
  br i1 %r112, label %layout_forget.young.36, label %layout_forget.done.39

layout_forget.young.36:                           ; preds = %alloc.merge.35
  %r113 = load atomic i32, ptr @PERRY_YOUNG_LAYOUT_RECORDS monotonic, align 4
  %r114 = icmp ne i32 %r113, 0
  br i1 %r114, label %layout_forget.sketch.37, label %layout_forget.done.39

layout_forget.sketch.37:                          ; preds = %layout_forget.young.36
  %r115 = mul i64 %r110, -7046029254386353131
  %r116 = lshr i64 %r115, 52
  %r117 = lshr i64 %r116, 6
  %r118 = and i64 %r116, 63
  %r119 = shl nuw i64 1, %r118
  %r120 = getelementptr i64, ptr @PERRY_LAYOUT_ADDR_FILTER, i64 %r117
  %r121 = load atomic i64, ptr %r120 monotonic, align 8
  %r122 = and i64 %r121, %r119
  %r123 = icmp ne i64 %r122, 0
  br i1 %r123, label %layout_forget.armed.38, label %layout_forget.done.39

layout_forget.armed.38:                           ; preds = %layout_forget.sketch.37
  call void @js_gc_forget_object_layout(i64 %r110) #9
  br label %layout_forget.done.39

layout_forget.done.39:                            ; preds = %layout_forget.armed.38, %layout_forget.sketch.37, %layout_forget.young.36, %alloc.merge.35
  %rs4gc.s7 = inttoptr i64 %r110 to ptr addrspace(1)
  %r125.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7 to i64
  %r125 = call i64 asm "", "=r,0"(i64 %r125.rs4i) #9
  %r126 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r127 = icmp ne i32 %r126, 0
  br i1 %r127, label %shadow.root.barrier.40, label %shadow.root.barrier.done.41

shadow.root.barrier.40:                           ; preds = %layout_forget.done.39
  call void @js_write_barrier_root_nanbox(i64 %r125) #9
  br label %shadow.root.barrier.done.41

shadow.root.barrier.done.41:                      ; preds = %shadow.root.barrier.40, %layout_forget.done.39
  %r128 = or i64 %r110, 9222527611924643840
  %r129 = bitcast i64 %r128 to double
  %r130.rs4i = ptrtoint ptr addrspace(1) %.285 to i64
  %r130 = call i64 asm "", "=r,0"(i64 %r130.rs4i) #9
  %r131 = bitcast i64 %r130 to double
  %r132 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r133 = icmp eq i8 %r132, 0
  %r134 = bitcast double %r40.0 to i64
  %r135 = and i64 %r134, 9218868437227405312
  %r136 = icmp ne i64 %r135, 9218868437227405312
  %r137 = and i1 %r133, %r136
  br i1 %r137, label %ctor_prologue.fast.42, label %ctor_prologue.slow.43

ctor_prologue.fast.42:                            ; preds = %shadow.root.barrier.done.41
  %r138 = inttoptr i64 %r110 to ptr
  %r139 = getelementptr i8, ptr %r138, i64 16
  %r140 = bitcast double %r129 to i64
  %r141 = getelementptr double, ptr %r139, i64 0
  store double %r40.0, ptr %r141, align 8
  %r142 = ptrtoint ptr %r141 to i64
  %r143 = bitcast double %r40.0 to i64
  %r144 = getelementptr double, ptr %r139, i64 1
  store double %r131, ptr %r144, align 8
  %r145 = ptrtoint ptr %r144 to i64
  %r146 = bitcast double %r131 to i64
  %r147 = lshr i64 %r146, 48
  %r148 = icmp eq i64 %r147, 0
  %r149 = icmp uge i64 %r146, 4096
  %r150 = and i1 %r148, %r149
  %r151 = icmp eq i64 %r147, 32765
  %r152 = icmp eq i64 %r147, 32767
  %r153 = icmp eq i64 %r147, 32762
  %r154 = or i1 %r151, %r152
  %r155 = or i1 %r154, %r153
  %r156 = or i1 %r155, %r150
  br i1 %r156, label %ctor_prologue.barrier.maybe.45, label %ctor_prologue.barrier.done.47

ctor_prologue.slow.43:                            ; preds = %shadow.root.barrier.done.41
  %statepoint_token28 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, double)) @test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c_constructor, i32 3, i32 0, double %r129, double %r40.0, double %r131, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3, ptr addrspace(1) %.380, ptr addrspace(1) %rs4gc.s7) ]
  %r16529 = call double @llvm.experimental.gc.result.f64(token %statepoint_token28)
  %r31.0.base.relocated30 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token28, i32 0, i32 0) ; (%.3, %.3)
  %r31.0.relocated31 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token28, i32 0, i32 1) ; (%.3, %.380)
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token28, i32 2, i32 2) ; (%rs4gc.s7, %rs4gc.s7)
  br label %ctor_prologue.merge.44

ctor_prologue.merge.44:                           ; preds = %ctor_prologue.barrier.done.47, %ctor_prologue.slow.43
  %.086 = phi ptr addrspace(1) [ %rs4gc.s7, %ctor_prologue.barrier.done.47 ], [ %rs4gc.s7.relocated, %ctor_prologue.slow.43 ]
  %.481 = phi ptr addrspace(1) [ %.380, %ctor_prologue.barrier.done.47 ], [ %r31.0.relocated31, %ctor_prologue.slow.43 ]
  %.4 = phi ptr addrspace(1) [ %.3, %ctor_prologue.barrier.done.47 ], [ %r31.0.base.relocated30, %ctor_prologue.slow.43 ]
  %r166 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.47 ], [ %r16529, %ctor_prologue.slow.43 ]
  %r167.rs4i = ptrtoint ptr addrspace(1) %.086 to i64
  %r167 = call i64 asm "", "=r,0"(i64 %r167.rs4i) #9
  %r168 = or i64 %r167, 9222527611924643840
  %r169 = bitcast i64 %r168 to double
  %r170 = bitcast double %r166 to i64
  %r171 = icmp eq i64 %r170, 9222246136947933185
  br i1 %r171, label %ctor_ret.merge.49, label %ctor_ret.override.48

ctor_prologue.barrier.maybe.45:                   ; preds = %ctor_prologue.fast.42
  %r157 = sub i64 %r110, 7
  %r158 = inttoptr i64 %r157 to ptr
  %r159 = load i8, ptr %r158, align 1
  %r160 = and i8 %r159, 32
  %r161 = icmp ne i8 %r160, 0
  %r162 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r163 = icmp ne i32 %r162, 0
  %r164 = or i1 %r161, %r163
  br i1 %r164, label %ctor_prologue.barrier.46, label %ctor_prologue.barrier.done.47

ctor_prologue.barrier.46:                         ; preds = %ctor_prologue.barrier.maybe.45
  call void @js_write_barrier_slot_validated_parent(i64 %r110, i64 %r145, i64 %r146) #9
  br label %ctor_prologue.barrier.done.47

ctor_prologue.barrier.done.47:                    ; preds = %ctor_prologue.barrier.46, %ctor_prologue.barrier.maybe.45, %ctor_prologue.fast.42
  br label %ctor_prologue.merge.44

ctor_ret.override.48:                             ; preds = %ctor_prologue.merge.44
  %statepoint_token32 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r169, double %r166, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4, ptr addrspace(1) %.481) ]
  %r17233 = call double @llvm.experimental.gc.result.f64(token %statepoint_token32)
  %r31.0.base.relocated34 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token32, i32 0, i32 0) ; (%.4, %.4)
  %r31.0.relocated35 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token32, i32 0, i32 1) ; (%.4, %.481)
  br label %ctor_ret.merge.49

ctor_ret.merge.49:                                ; preds = %ctor_ret.override.48, %ctor_prologue.merge.44
  %.582 = phi ptr addrspace(1) [ %.481, %ctor_prologue.merge.44 ], [ %r31.0.relocated35, %ctor_ret.override.48 ]
  %.5 = phi ptr addrspace(1) [ %.4, %ctor_prologue.merge.44 ], [ %r31.0.base.relocated34, %ctor_ret.override.48 ]
  %r173 = phi double [ %r169, %ctor_prologue.merge.44 ], [ %r17233, %ctor_ret.override.48 ]
  %r174 = bitcast double %r173 to i64
  %r175.rs4i = ptrtoint ptr addrspace(1) %.582 to i64
  %r175.rs4o = call i64 asm "", "=r,0"(i64 %r175.rs4i) #9
  %r175 = bitcast i64 %r175.rs4o to double
  %r176 = bitcast double %r175 to i64
  %r177 = and i64 %r176, 281474976710655
  %r178 = sub nsw i64 %r177, 8
  %r179 = inttoptr i64 %r178 to ptr
  %r180 = load i8, ptr %r179, align 1
  %r181 = icmp ne i8 %r180, 1
  %r182 = sub nsw i64 %r177, 7
  %r183 = inttoptr i64 %r182 to ptr
  %r184 = load i8, ptr %r183, align 1
  %r185 = and i8 %r184, -128
  %r186 = icmp ne i8 %r185, 0
  %r187 = or i1 %r181, %r186
  br i1 %r186, label %apush.fwd.50, label %apush.elements.51

apush.fwd.50:                                     ; preds = %apush.elements.check.52, %ctor_ret.merge.49
  %statepoint_token36 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r177, double %r173, i32 0, i32 0)
  %r21437 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token36)
  %r215 = or i64 %r21437, 9222527611924643840
  %r216 = bitcast i64 %r215 to double
  %rs4gc.b8 = bitcast double %r216 to i64
  %rs4gc.s8 = inttoptr i64 %rs4gc.b8 to ptr addrspace(1)
  br label %apush.merge.56

apush.elements.51:                                ; preds = %ctor_ret.merge.49
  %r189 = add nuw nsw i64 %r177, 8
  %r190 = inttoptr i64 %r189 to ptr
  %r191 = load i64, ptr %r190, align 8
  %r192 = icmp ne i64 %r191, 0
  %r193 = icmp eq i8 %r180, 2
  %r194 = and i1 %r193, %r192
  %r195 = select i1 %r194, i64 %r191, i64 %r177
  %r196 = inttoptr i64 %r195 to ptr
  %r197 = getelementptr i64, ptr %r196, i64 12
  %r198 = load i64, ptr %r197, align 8
  %r199 = icmp ne i64 %r198, 0
  %r200 = and i1 %r194, %r199
  %r201 = select i1 %r200, i64 %r198, i64 %r177
  %r188 = icmp eq i8 %r180, 1
  br i1 %r188, label %apush.nofwd.53, label %apush.elements.check.52

apush.elements.check.52:                          ; preds = %apush.elements.51
  %r202 = icmp ne i64 %r201, 0
  %r203 = sub i64 %r201, 8
  %r204 = inttoptr i64 %r203 to ptr
  %r205 = load i8, ptr %r204, align 1
  %r206 = icmp eq i8 %r205, 1
  %r207 = sub i64 %r201, 7
  %r208 = inttoptr i64 %r207 to ptr
  %r209 = load i8, ptr %r208, align 1
  %r210 = and i8 %r209, -128
  %r211 = icmp eq i8 %r210, 0
  %r212 = and i1 %r202, %r206
  %r213 = and i1 %r212, %r211
  br i1 %r213, label %apush.nofwd.53, label %apush.fwd.50

apush.nofwd.53:                                   ; preds = %apush.elements.check.52, %apush.elements.51
  %r217 = phi i64 [ %r177, %apush.elements.51 ], [ %r201, %apush.elements.check.52 ]
  %r218 = sub i64 %r217, 6
  %r219 = inttoptr i64 %r218 to ptr
  %r220 = load i16, ptr %r219, align 2
  %r221 = and i16 %r220, -2937
  %r222 = icmp eq i16 %r221, -24576
  %r223 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r224 = icmp eq i8 %r223, 0
  %r225 = and i1 %r222, %r224
  %r226 = icmp ult i64 %r217, 4096
  %r227 = inttoptr i64 %r217 to ptr
  %r228 = select i1 %r226, ptr @perry_null_guard_zero_test_json_string_emitters_ts, ptr %r227
  %r229 = load i32, ptr %r228, align 4
  %r230 = add i64 %r217, 4
  %r231 = inttoptr i64 %r230 to ptr
  %r232 = load i32, ptr %r231, align 4
  %r233 = icmp ult i32 %r229, %r232
  %r234 = and i1 %r233, %r225
  br i1 %r234, label %apush.inbounds.54, label %apush.realloc.55

apush.inbounds.54:                                ; preds = %apush.nofwd.53
  %r235 = icmp ult i64 %r217, 4096
  %r236 = inttoptr i64 %r217 to ptr
  %r237 = select i1 %r235, ptr @perry_null_guard_zero_test_json_string_emitters_ts, ptr %r236
  %r238 = load i32, ptr %r237, align 4
  %r239 = zext i32 %r238 to i64
  %r240 = shl nuw nsw i64 %r239, 3
  %r241 = add nuw nsw i64 %r240, 8
  %r242 = add i64 %r217, %r241
  %r243 = inttoptr i64 %r242 to ptr
  store double %r173, ptr %r243, align 8
  call void @js_string_addref_if_heap_string(double %r173) #9
  %r244 = bitcast double %r173 to i64
  %r245 = sub i64 %r217, 7
  %r246 = inttoptr i64 %r245 to ptr
  %r247 = load i8, ptr %r246, align 1
  %r248 = and i8 %r247, 32
  %r249 = icmp ne i8 %r248, 0
  %r250 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r251 = icmp ne i32 %r250, 0
  %r252 = or i1 %r249, %r251
  br i1 %r252, label %apush.barrier.57, label %apush.barrier.done.58

apush.realloc.55:                                 ; preds = %apush.nofwd.53
  %statepoint_token38 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r177, double %r173, i32 0, i32 0)
  %r25539 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token38)
  %r256 = or i64 %r25539, 9222527611924643840
  %r257 = bitcast i64 %r256 to double
  %rs4gc.b9 = bitcast double %r257 to i64
  %rs4gc.s9 = inttoptr i64 %rs4gc.b9 to ptr addrspace(1)
  br label %apush.merge.56

apush.merge.56:                                   ; preds = %apush.barrier.done.58, %apush.realloc.55, %apush.fwd.50
  %r31.1.base = phi ptr addrspace(1) [ %rs4gc.s8, %apush.fwd.50 ], [ %.5, %apush.barrier.done.58 ], [ %rs4gc.s9, %apush.realloc.55 ], !is_base_value !0
  %r31.1 = phi ptr addrspace(1) [ %rs4gc.s8, %apush.fwd.50 ], [ %.582, %apush.barrier.done.58 ], [ %rs4gc.s9, %apush.realloc.55 ]
  %r258 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r259 = icmp ne i32 %r258, 0
  br i1 %r259, label %gcpoll.59, label %gcpoll.done.60

apush.barrier.57:                                 ; preds = %apush.inbounds.54
  call void @js_write_barrier_slot_validated_parent(i64 %r217, i64 %r242, i64 %r244) #9
  br label %apush.barrier.done.58

apush.barrier.done.58:                            ; preds = %apush.barrier.57, %apush.inbounds.54
  %r253 = add i32 %r238, 1
  %r254 = inttoptr i64 %r217 to ptr
  store i32 %r253, ptr %r254, align 4
  br label %apush.merge.56

gcpoll.59:                                        ; preds = %apush.merge.56
  %statepoint_token40 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r31.1.base, ptr addrspace(1) %r31.1) ]
  %r31.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token40, i32 0, i32 0) ; (%r31.1.base, %r31.1.base)
  %r31.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token40, i32 0, i32 1) ; (%r31.1.base, %r31.1)
  br label %gcpoll.done.60

gcpoll.done.60:                                   ; preds = %gcpoll.59, %apush.merge.56
  %.088 = phi ptr addrspace(1) [ %r31.1.relocated, %gcpoll.59 ], [ %r31.1, %apush.merge.56 ]
  %.087 = phi ptr addrspace(1) [ %r31.1.base.relocated, %gcpoll.59 ], [ %r31.1.base, %apush.merge.56 ]
  br label %for.update.17

arr.fast.61:                                      ; preds = %arr.guard.range.67
  %r329 = add i64 %r285, 384
  %r330 = inttoptr i64 %r329 to ptr
  %r331 = load double, ptr %r330, align 8
  %r332 = bitcast double %r331 to i64
  %r333 = icmp eq i64 %r332, 9222246136947933200
  %r335 = select i1 %r333, double 0x7FFC000000000001, double %r331
  br label %arr.merge.64

arr.fallback.62:                                  ; preds = %arr.guard.live.66, %arr.guard.deref.65, %for.exit.18
  %statepoint_token41 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 6553530643794362369, double %r264, double 4.700000e+01, i32 0, i32 0)
  %r32542 = call double @llvm.experimental.gc.result.f64(token %statepoint_token41)
  br label %arr.merge.64

arr.guard.oob.63:                                 ; preds = %arr.guard.range.67
  br label %arr.merge.64

arr.merge.64:                                     ; preds = %arr.guard.oob.63, %arr.fallback.62, %arr.fast.61
  %r336 = phi double [ %r335, %arr.fast.61 ], [ %r32542, %arr.fallback.62 ], [ 0x7FFC000000000001, %arr.guard.oob.63 ]
  %r337 = bitcast double %r336 to i64
  %r338 = and i64 %r337, 281474976710655
  %r339 = lshr i64 %r337, 48
  %r340 = and i64 %r339, 65533
  %r341 = icmp eq i64 %r340, 32765
  br i1 %r341, label %pget.recv_ok.69, label %pget.recv_other.73

arr.guard.deref.65:                               ; preds = %for.exit.18
  %r271 = bitcast double %r264 to i64
  %r272 = and i64 %r271, 281474976710655
  %r273 = sub nsw i64 %r272, 8
  %r274 = inttoptr i64 %r273 to ptr
  %r275 = load i8, ptr %r274, align 1
  %r276 = icmp eq i8 %r275, 1
  %r277 = sub nsw i64 %r272, 7
  %r278 = inttoptr i64 %r277 to ptr
  %r279 = load i8, ptr %r278, align 1
  %r280 = and i8 %r279, -128
  %r281 = icmp ne i8 %r280, 0
  %r282 = inttoptr i64 %r272 to ptr
  %r283 = load i64, ptr %r282, align 8
  %r284 = and i1 %r276, %r281
  %r285 = select i1 %r284, i64 %r283, i64 %r272
  %r286 = lshr i64 %r285, 48
  %r287 = icmp eq i64 %r286, 0
  %r288 = icmp ugt i64 %r285, 1048575
  %r289 = and i1 %r287, %r288
  br i1 %r289, label %arr.guard.live.66, label %arr.fallback.62

arr.guard.live.66:                                ; preds = %arr.guard.deref.65
  %r290 = sub nuw i64 %r285, 8
  %r291 = inttoptr i64 %r290 to ptr
  %r292 = load i8, ptr %r291, align 1
  %r293 = icmp eq i8 %r292, 1
  %r294 = sub nuw i64 %r285, 7
  %r295 = inttoptr i64 %r294 to ptr
  %r296 = load i8, ptr %r295, align 1
  %r297 = and i8 %r296, -128
  %r298 = icmp eq i8 %r297, 0
  %r299 = sub nuw i64 %r285, 6
  %r300 = inttoptr i64 %r299 to ptr
  %r301 = load i16, ptr %r300, align 2
  %r302 = and i16 %r301, 1024
  %r303 = icmp eq i16 %r302, 0
  %r304 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r305 = icmp eq i8 %r304, 0
  %r306 = inttoptr i64 %r285 to ptr
  %r307 = load i32, ptr %r306, align 4
  %r308 = getelementptr i8, ptr %r306, i64 4
  %r309 = load i32, ptr %r308, align 4
  %r313 = icmp ule i32 %r307, 16000000
  %r314 = icmp ule i32 %r309, 16000000
  %r315 = icmp ule i32 %r307, %r309
  %r316 = and i1 %r293, %r298
  %r317 = and i1 %r316, %r303
  %r318 = and i1 %r317, %r305
  %r320 = and i1 %r318, %r313
  %r321 = and i1 %r320, %r314
  %r322 = and i1 %r321, %r315
  br i1 %r322, label %arr.guard.range.67, label %arr.fallback.62

arr.guard.range.67:                               ; preds = %arr.guard.live.66
  %r312 = icmp ult i32 47, %r307
  br i1 %r312, label %arr.fast.61, label %arr.guard.oob.63

pget.recv_sso.68:                                 ; preds = %pget.recv_other.73
  %r479 = load double, ptr @test_json_string_emitters_ts_.str.3.handle, align 8
  %r480 = bitcast double %r479 to i64
  %r481 = and i64 %r480, 281474976710655
  %statepoint_token43 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r337, i64 %r481, i32 0, i32 0)
  %r48244 = call double @llvm.experimental.gc.result.f64(token %statepoint_token43)
  br label %pget.recv_merge.72

pget.recv_ok.69:                                  ; preds = %arr.merge.64
  %r348 = icmp ugt i64 %r338, 1048575
  br i1 %r348, label %pic.recv_hdr.90, label %pic.miss.cold.87

pget.recv_bad.70:                                 ; preds = %pget.check_class_ref.74
  %r471 = icmp eq i64 %r337, 9222246136947933185
  %r472 = icmp eq i64 %r337, 9222246136947933186
  %r473 = or i1 %r471, %r472
  br i1 %r473, label %pget.throw_nullish.97, label %pget.recv_undef_return.98

pget.recv_class_ref.71:                           ; preds = %pget.check_class_ref.74
  %r344 = load double, ptr @test_json_string_emitters_ts_.str.3.handle, align 8
  %r345 = bitcast double %r344 to i64
  %r346 = and i64 %r345, 281474976710655
  %statepoint_token45 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6553530643794362370, i64 %r337, i64 %r346, i32 0, i32 0)
  %r34746 = call double @llvm.experimental.gc.result.f64(token %statepoint_token45)
  br label %pget.recv_merge.72

pget.recv_merge.72:                               ; preds = %pget.recv_undef_return.98, %pic.merge.89, %pget.recv_class_ref.71, %pget.recv_sso.68
  %r483 = phi double [ %r470, %pic.merge.89 ], [ %r47859, %pget.recv_undef_return.98 ], [ %r48244, %pget.recv_sso.68 ], [ %r34746, %pget.recv_class_ref.71 ]
  %r484 = load double, ptr @test_json_string_emitters_ts_.str.4.handle, align 8
  %r485 = load double, ptr @test_json_string_emitters_ts_.str.2.handle, align 8
  %r487 = getelementptr double, ptr %r486, i64 0
  store double %r485, ptr %r487, align 8
  %r488 = getelementptr double, ptr %r486, i64 1
  store double %r483, ptr %r488, align 8
  %r489 = getelementptr double, ptr %r486, i64 2
  store double %r484, ptr %r489, align 8
  %r490 = ptrtoint ptr %r486 to i64
  %statepoint_token47 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r490, i32 3, i32 0, i32 0)
  %r49148 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token47)
  %r492 = or i64 %r49148, 9223090561878065152
  %r493 = bitcast i64 %r492 to double
  %statepoint_token49 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r493, i32 0, i32 0)
  %r49450 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token49)
  %statepoint_token51 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r49450, i32 0, i32 0)
  %r49552 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token51)
  %r496 = bitcast i64 %r49552 to double
  %rs4gc.b10 = bitcast double %r496 to i64
  %rs4gc.s10 = inttoptr i64 %rs4gc.b10 to ptr addrspace(1)
  %r497.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r497 = call i64 asm "", "=r,0"(i64 %r497.rs4i) #9
  %r498 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r499 = icmp ne i32 %r498, 0
  br i1 %r499, label %shadow.root.barrier.99, label %shadow.root.barrier.done.100

pget.recv_other.73:                               ; preds = %arr.merge.64
  %r342 = icmp eq i64 %r339, 32761
  br i1 %r342, label %pget.recv_sso.68, label %pget.check_class_ref.74

pget.check_class_ref.74:                          ; preds = %pget.recv_other.73
  %r343 = icmp eq i64 %r339, 32766
  br i1 %r343, label %pget.recv_class_ref.71, label %pget.recv_bad.70

pic.hit.75:                                       ; preds = %pic.token.91
  %r373 = getelementptr i64, ptr %r358, i64 1
  %r374 = load i64, ptr %r373, align 8
  %r375 = and i64 %r374, 1073741824
  %r376 = icmp ne i64 %r375, 0
  br i1 %r376, label %pic.hit.overflow.92, label %pic.hit.inline.93

pic.hit.live.76:                                  ; preds = %pic.hit.inline.93
  br label %pic.merge.89

pic.prefix.guard.77:                              ; preds = %pic.token.91
  %r389 = getelementptr i64, ptr %r358, i64 2
  %r390 = load i64, ptr %r389, align 8
  %r391 = icmp ne i64 %r390, 0
  br i1 %r391, label %pic.prefix.meta.78, label %pic.miss.86

pic.prefix.meta.78:                               ; preds = %pic.prefix.guard.77
  %r392 = add nuw nsw i64 %r338, 8
  %r393 = inttoptr i64 %r392 to ptr
  %r394 = load i64, ptr %r393, align 8
  %r395 = icmp ne i64 %r394, 0
  br i1 %r395, label %pic.prefix.token.79, label %pic.miss.86

pic.prefix.token.79:                              ; preds = %pic.prefix.meta.78
  %r396 = inttoptr i64 %r394 to ptr
  %r397 = getelementptr i64, ptr %r396, i64 6
  %r398 = load i64, ptr %r397, align 8
  %r399 = icmp eq i64 %r398, %r390
  br i1 %r399, label %pic.prefix.hit.80, label %pic.miss.86

pic.prefix.hit.80:                                ; preds = %pic.prefix.token.79
  %r400 = getelementptr i64, ptr %r358, i64 1
  %r401 = load i64, ptr %r400, align 8
  %r402 = shl i64 %r401, 3
  %r403 = add nuw nsw i64 %r338, 16
  %r404 = add i64 %r403, %r402
  %r405 = inttoptr i64 %r404 to ptr
  %r406 = load double, ptr %r405, align 8
  br label %pic.merge.89

pic.desc.classify.81:                             ; preds = %pic.recv_hdr.90
  %r362 = and i1 %r352, %r359
  br i1 %r362, label %pic.desc.prefix.guard.82, label %pic.miss.cold.87

pic.desc.prefix.guard.82:                         ; preds = %pic.desc.classify.81
  %r407 = getelementptr i64, ptr %r358, i64 2
  %r408 = load i64, ptr %r407, align 8
  %r409 = icmp ne i64 %r408, 0
  br i1 %r409, label %pic.desc.prefix.meta.83, label %pic.miss.cold.87

pic.desc.prefix.meta.83:                          ; preds = %pic.desc.prefix.guard.82
  %r410 = add nuw nsw i64 %r338, 8
  %r411 = inttoptr i64 %r410 to ptr
  %r412 = load i64, ptr %r411, align 8
  %r413 = icmp ne i64 %r412, 0
  br i1 %r413, label %pic.desc.prefix.token.84, label %pic.miss.cold.87

pic.desc.prefix.token.84:                         ; preds = %pic.desc.prefix.meta.83
  %r414 = inttoptr i64 %r412 to ptr
  %r415 = getelementptr i64, ptr %r414, i64 6
  %r416 = load i64, ptr %r415, align 8
  %r417 = icmp eq i64 %r416, %r408
  br i1 %r417, label %pic.desc.prefix.hit.85, label %pic.miss.cold.87

pic.desc.prefix.hit.85:                           ; preds = %pic.desc.prefix.token.84
  %r418 = getelementptr i64, ptr %r358, i64 1
  %r419 = load i64, ptr %r418, align 8
  %r420 = shl i64 %r419, 3
  %r421 = add nuw nsw i64 %r338, 16
  %r422 = add i64 %r421, %r420
  %r423 = inttoptr i64 %r422 to ptr
  %r424 = load double, ptr %r423, align 8
  br label %pic.merge.89

pic.miss.86:                                      ; preds = %pic.hit.inline.93, %pic.prefix.token.79, %pic.prefix.meta.78, %pic.prefix.guard.77
  %r425 = getelementptr i64, ptr %r358, i64 3
  %r426 = load i64, ptr %r425, align 8
  %r427 = icmp sgt i64 %r426, 0
  br i1 %r427, label %pic.ways.94, label %pic.miss.call.88

pic.miss.cold.87:                                 ; preds = %pic.desc.prefix.token.84, %pic.desc.prefix.meta.83, %pic.desc.prefix.guard.82, %pic.desc.classify.81, %pget.recv_ok.69
  br label %pic.miss.call.88

pic.miss.call.88:                                 ; preds = %pic.way.load.95, %pic.ways.94, %pic.miss.cold.87, %pic.miss.86
  %r466 = load double, ptr @test_json_string_emitters_ts_.str.3.handle, align 8
  %r467 = bitcast double %r466 to i64
  %r468 = and i64 %r467, 281474976710655
  %statepoint_token53 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r338, i64 %r468, ptr @perry_ic_test_json_string_emitters_ts__3, i32 0, i32 0)
  %r46954 = call double @llvm.experimental.gc.result.f64(token %statepoint_token53)
  br label %pic.merge.89

pic.merge.89:                                     ; preds = %pic.way.live.96, %pic.hit.overflow.92, %pic.miss.call.88, %pic.desc.prefix.hit.85, %pic.prefix.hit.80, %pic.hit.live.76
  %r470 = phi double [ %r386, %pic.hit.live.76 ], [ %r38156, %pic.hit.overflow.92 ], [ %r406, %pic.prefix.hit.80 ], [ %r424, %pic.desc.prefix.hit.85 ], [ %r463, %pic.way.live.96 ], [ %r46954, %pic.miss.call.88 ]
  br label %pget.recv_merge.72

pic.recv_hdr.90:                                  ; preds = %pget.recv_ok.69
  %r349 = sub nuw nsw i64 %r338, 8
  %r350 = inttoptr i64 %r349 to ptr
  %r351 = load i8, ptr %r350, align 1
  %r352 = icmp eq i8 %r351, 2
  %r353 = sub nuw nsw i64 %r338, 6
  %r354 = inttoptr i64 %r353 to ptr
  %r355 = load i16, ptr %r354, align 2
  %r356 = and i16 %r355, 2048
  %r357 = icmp eq i16 %r356, 0
  %r358 = load ptr, ptr @perry_ic_test_json_string_emitters_ts__3, align 8
  %r359 = icmp ne ptr %r358, null
  %r360 = and i1 %r352, %r357
  %r361 = and i1 %r360, %r359
  br i1 %r361, label %pic.token.91, label %pic.desc.classify.81

pic.token.91:                                     ; preds = %pic.recv_hdr.90
  %r363 = add nuw nsw i64 %r338, 4
  %r364 = inttoptr i64 %r363 to ptr
  %r365 = load i32, ptr %r364, align 4
  %r366 = zext i32 %r365 to i64
  %r367 = or i64 %r366, 4611686018427387904
  %r368 = icmp ne i32 %r365, 0
  %r369 = getelementptr i64, ptr %r358, i64 0
  %r370 = load i64, ptr %r369, align 8
  %r371 = icmp eq i64 %r367, %r370
  %r372 = and i1 %r371, %r368
  br i1 %r372, label %pic.hit.75, label %pic.prefix.guard.77

pic.hit.overflow.92:                              ; preds = %pic.hit.75
  %r377 = load double, ptr @test_json_string_emitters_ts_.str.3.handle, align 8
  %r378 = bitcast double %r377 to i64
  %r379 = and i64 %r378, 281474976710655
  %r380 = trunc i64 %r374 to i32
  %statepoint_token55 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r338, i64 %r379, i32 %r380, ptr @perry_ic_test_json_string_emitters_ts__3, i32 0, i32 0)
  %r38156 = call double @llvm.experimental.gc.result.f64(token %statepoint_token55)
  br label %pic.merge.89

pic.hit.inline.93:                                ; preds = %pic.hit.75
  %r382 = shl i64 %r374, 3
  %r383 = add nuw nsw i64 %r338, 16
  %r384 = add i64 %r383, %r382
  %r385 = inttoptr i64 %r384 to ptr
  %r386 = load double, ptr %r385, align 8
  %r387 = bitcast double %r386 to i64
  %r388 = icmp eq i64 %r387, 9222246136947933200
  br i1 %r388, label %pic.miss.86, label %pic.hit.live.76

pic.ways.94:                                      ; preds = %pic.miss.86
  %r428 = getelementptr i64, ptr %r358, i64 4
  %r429 = load i64, ptr %r428, align 8
  %r430 = icmp eq i64 %r429, %r367
  %r431 = getelementptr i64, ptr %r358, i64 5
  %r432 = load i64, ptr %r431, align 8
  %r433 = select i1 %r430, i64 %r432, i64 0
  %r434 = getelementptr i64, ptr %r358, i64 6
  %r435 = load i64, ptr %r434, align 8
  %r436 = icmp eq i64 %r435, %r367
  %r437 = getelementptr i64, ptr %r358, i64 7
  %r438 = load i64, ptr %r437, align 8
  %r439 = select i1 %r436, i64 %r438, i64 0
  %r440 = getelementptr i64, ptr %r358, i64 8
  %r441 = load i64, ptr %r440, align 8
  %r442 = icmp eq i64 %r441, %r367
  %r443 = getelementptr i64, ptr %r358, i64 9
  %r444 = load i64, ptr %r443, align 8
  %r445 = select i1 %r442, i64 %r444, i64 0
  %r446 = getelementptr i64, ptr %r358, i64 10
  %r447 = load i64, ptr %r446, align 8
  %r448 = icmp eq i64 %r447, %r367
  %r449 = getelementptr i64, ptr %r358, i64 11
  %r450 = load i64, ptr %r449, align 8
  %r451 = select i1 %r448, i64 %r450, i64 0
  %r452 = or i1 %r430, %r436
  %r453 = select i1 %r430, i64 %r433, i64 %r439
  %r454 = or i1 %r442, %r448
  %r455 = select i1 %r442, i64 %r445, i64 %r451
  %r456 = or i1 %r452, %r454
  %r457 = select i1 %r452, i64 %r453, i64 %r455
  %r458 = and i1 %r368, %r456
  br i1 %r458, label %pic.way.load.95, label %pic.miss.call.88

pic.way.load.95:                                  ; preds = %pic.ways.94
  %r459 = shl i64 %r457, 3
  %r460 = add nuw nsw i64 %r338, 16
  %r461 = add i64 %r460, %r459
  %r462 = inttoptr i64 %r461 to ptr
  %r463 = load double, ptr %r462, align 8
  %r464 = bitcast double %r463 to i64
  %r465 = icmp eq i64 %r464, 9222246136947933200
  br i1 %r465, label %pic.miss.call.88, label %pic.way.live.96

pic.way.live.96:                                  ; preds = %pic.way.load.95
  br label %pic.merge.89

pget.throw_nullish.97:                            ; preds = %pget.recv_bad.70
  %r474 = zext i1 %r472 to i32
  %statepoint_token57 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r474, ptr @test_json_string_emitters_ts_.str.3.bytes, i64 2, i32 0, i32 0)
  unreachable

pget.recv_undef_return.98:                        ; preds = %pget.recv_bad.70
  %r475 = load double, ptr @test_json_string_emitters_ts_.str.3.handle, align 8
  %r476 = bitcast double %r475 to i64
  %r477 = and i64 %r476, 281474976710655
  %statepoint_token58 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r337, i64 %r477, i32 0, i32 0)
  %r47859 = call double @llvm.experimental.gc.result.f64(token %statepoint_token58)
  br label %pget.recv_merge.72

shadow.root.barrier.99:                           ; preds = %pget.recv_merge.72
  call void @js_write_barrier_root_nanbox(i64 %r497) #9
  br label %shadow.root.barrier.done.100

shadow.root.barrier.done.100:                     ; preds = %shadow.root.barrier.99, %pget.recv_merge.72
  %r500.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r500.rs4o = call i64 asm "", "=r,0"(i64 %r500.rs4i) #9
  %r500 = bitcast i64 %r500.rs4o to double
  %r501 = bitcast double %r500 to i64
  %r502 = and i64 %r501, 281474976710655
  %r503 = lshr i64 %r501, 48
  %r504 = and i64 %r503, 65533
  %r505 = icmp eq i64 %r504, 32765
  br i1 %r505, label %pget.recv_ok.102, label %pget.recv_other.106

pget.recv_sso.101:                                ; preds = %pget.recv_other.106
  %r643 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r644 = bitcast double %r643 to i64
  %r645 = and i64 %r644, 281474976710655
  %statepoint_token60 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r501, i64 %r645, i32 0, i32 0)
  %r64661 = call double @llvm.experimental.gc.result.f64(token %statepoint_token60)
  br label %pget.recv_merge.105

pget.recv_ok.102:                                 ; preds = %shadow.root.barrier.done.100
  %r512 = icmp ugt i64 %r502, 1048575
  br i1 %r512, label %pic.recv_hdr.123, label %pic.miss.cold.120

pget.recv_bad.103:                                ; preds = %pget.check_class_ref.107
  %r635 = icmp eq i64 %r501, 9222246136947933185
  %r636 = icmp eq i64 %r501, 9222246136947933186
  %r637 = or i1 %r635, %r636
  br i1 %r637, label %pget.throw_nullish.130, label %pget.recv_undef_return.131

pget.recv_class_ref.104:                          ; preds = %pget.check_class_ref.107
  %r508 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r509 = bitcast double %r508 to i64
  %r510 = and i64 %r509, 281474976710655
  %statepoint_token62 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6553530643794362372, i64 %r501, i64 %r510, i32 0, i32 0)
  %r51163 = call double @llvm.experimental.gc.result.f64(token %statepoint_token62)
  br label %pget.recv_merge.105

pget.recv_merge.105:                              ; preds = %pget.recv_undef_return.131, %pic.merge.122, %pget.recv_class_ref.104, %pget.recv_sso.101
  %r647 = phi double [ %r634, %pic.merge.122 ], [ %r64270, %pget.recv_undef_return.131 ], [ %r64661, %pget.recv_sso.101 ], [ %r51163, %pget.recv_class_ref.104 ]
  ret double %r647

pget.recv_other.106:                              ; preds = %shadow.root.barrier.done.100
  %r506 = icmp eq i64 %r503, 32761
  br i1 %r506, label %pget.recv_sso.101, label %pget.check_class_ref.107

pget.check_class_ref.107:                         ; preds = %pget.recv_other.106
  %r507 = icmp eq i64 %r503, 32766
  br i1 %r507, label %pget.recv_class_ref.104, label %pget.recv_bad.103

pic.hit.108:                                      ; preds = %pic.token.124
  %r537 = getelementptr i64, ptr %r522, i64 1
  %r538 = load i64, ptr %r537, align 8
  %r539 = and i64 %r538, 1073741824
  %r540 = icmp ne i64 %r539, 0
  br i1 %r540, label %pic.hit.overflow.125, label %pic.hit.inline.126

pic.hit.live.109:                                 ; preds = %pic.hit.inline.126
  br label %pic.merge.122

pic.prefix.guard.110:                             ; preds = %pic.token.124
  %r553 = getelementptr i64, ptr %r522, i64 2
  %r554 = load i64, ptr %r553, align 8
  %r555 = icmp ne i64 %r554, 0
  br i1 %r555, label %pic.prefix.meta.111, label %pic.miss.119

pic.prefix.meta.111:                              ; preds = %pic.prefix.guard.110
  %r556 = add nuw nsw i64 %r502, 8
  %r557 = inttoptr i64 %r556 to ptr
  %r558 = load i64, ptr %r557, align 8
  %r559 = icmp ne i64 %r558, 0
  br i1 %r559, label %pic.prefix.token.112, label %pic.miss.119

pic.prefix.token.112:                             ; preds = %pic.prefix.meta.111
  %r560 = inttoptr i64 %r558 to ptr
  %r561 = getelementptr i64, ptr %r560, i64 6
  %r562 = load i64, ptr %r561, align 8
  %r563 = icmp eq i64 %r562, %r554
  br i1 %r563, label %pic.prefix.hit.113, label %pic.miss.119

pic.prefix.hit.113:                               ; preds = %pic.prefix.token.112
  %r564 = getelementptr i64, ptr %r522, i64 1
  %r565 = load i64, ptr %r564, align 8
  %r566 = shl i64 %r565, 3
  %r567 = add nuw nsw i64 %r502, 16
  %r568 = add i64 %r567, %r566
  %r569 = inttoptr i64 %r568 to ptr
  %r570 = load double, ptr %r569, align 8
  br label %pic.merge.122

pic.desc.classify.114:                            ; preds = %pic.recv_hdr.123
  %r526 = and i1 %r516, %r523
  br i1 %r526, label %pic.desc.prefix.guard.115, label %pic.miss.cold.120

pic.desc.prefix.guard.115:                        ; preds = %pic.desc.classify.114
  %r571 = getelementptr i64, ptr %r522, i64 2
  %r572 = load i64, ptr %r571, align 8
  %r573 = icmp ne i64 %r572, 0
  br i1 %r573, label %pic.desc.prefix.meta.116, label %pic.miss.cold.120

pic.desc.prefix.meta.116:                         ; preds = %pic.desc.prefix.guard.115
  %r574 = add nuw nsw i64 %r502, 8
  %r575 = inttoptr i64 %r574 to ptr
  %r576 = load i64, ptr %r575, align 8
  %r577 = icmp ne i64 %r576, 0
  br i1 %r577, label %pic.desc.prefix.token.117, label %pic.miss.cold.120

pic.desc.prefix.token.117:                        ; preds = %pic.desc.prefix.meta.116
  %r578 = inttoptr i64 %r576 to ptr
  %r579 = getelementptr i64, ptr %r578, i64 6
  %r580 = load i64, ptr %r579, align 8
  %r581 = icmp eq i64 %r580, %r572
  br i1 %r581, label %pic.desc.prefix.hit.118, label %pic.miss.cold.120

pic.desc.prefix.hit.118:                          ; preds = %pic.desc.prefix.token.117
  %r582 = getelementptr i64, ptr %r522, i64 1
  %r583 = load i64, ptr %r582, align 8
  %r584 = shl i64 %r583, 3
  %r585 = add nuw nsw i64 %r502, 16
  %r586 = add i64 %r585, %r584
  %r587 = inttoptr i64 %r586 to ptr
  %r588 = load double, ptr %r587, align 8
  br label %pic.merge.122

pic.miss.119:                                     ; preds = %pic.hit.inline.126, %pic.prefix.token.112, %pic.prefix.meta.111, %pic.prefix.guard.110
  %r589 = getelementptr i64, ptr %r522, i64 3
  %r590 = load i64, ptr %r589, align 8
  %r591 = icmp sgt i64 %r590, 0
  br i1 %r591, label %pic.ways.127, label %pic.miss.call.121

pic.miss.cold.120:                                ; preds = %pic.desc.prefix.token.117, %pic.desc.prefix.meta.116, %pic.desc.prefix.guard.115, %pic.desc.classify.114, %pget.recv_ok.102
  br label %pic.miss.call.121

pic.miss.call.121:                                ; preds = %pic.way.load.128, %pic.ways.127, %pic.miss.cold.120, %pic.miss.119
  %r630 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r631 = bitcast double %r630 to i64
  %r632 = and i64 %r631, 281474976710655
  %statepoint_token64 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r502, i64 %r632, ptr @perry_ic_test_json_string_emitters_ts__5, i32 0, i32 0)
  %r63365 = call double @llvm.experimental.gc.result.f64(token %statepoint_token64)
  br label %pic.merge.122

pic.merge.122:                                    ; preds = %pic.way.live.129, %pic.hit.overflow.125, %pic.miss.call.121, %pic.desc.prefix.hit.118, %pic.prefix.hit.113, %pic.hit.live.109
  %r634 = phi double [ %r550, %pic.hit.live.109 ], [ %r54567, %pic.hit.overflow.125 ], [ %r570, %pic.prefix.hit.113 ], [ %r588, %pic.desc.prefix.hit.118 ], [ %r627, %pic.way.live.129 ], [ %r63365, %pic.miss.call.121 ]
  br label %pget.recv_merge.105

pic.recv_hdr.123:                                 ; preds = %pget.recv_ok.102
  %r513 = sub nuw nsw i64 %r502, 8
  %r514 = inttoptr i64 %r513 to ptr
  %r515 = load i8, ptr %r514, align 1
  %r516 = icmp eq i8 %r515, 2
  %r517 = sub nuw nsw i64 %r502, 6
  %r518 = inttoptr i64 %r517 to ptr
  %r519 = load i16, ptr %r518, align 2
  %r520 = and i16 %r519, 2048
  %r521 = icmp eq i16 %r520, 0
  %r522 = load ptr, ptr @perry_ic_test_json_string_emitters_ts__5, align 8
  %r523 = icmp ne ptr %r522, null
  %r524 = and i1 %r516, %r521
  %r525 = and i1 %r524, %r523
  br i1 %r525, label %pic.token.124, label %pic.desc.classify.114

pic.token.124:                                    ; preds = %pic.recv_hdr.123
  %r527 = add nuw nsw i64 %r502, 4
  %r528 = inttoptr i64 %r527 to ptr
  %r529 = load i32, ptr %r528, align 4
  %r530 = zext i32 %r529 to i64
  %r531 = or i64 %r530, 4611686018427387904
  %r532 = icmp ne i32 %r529, 0
  %r533 = getelementptr i64, ptr %r522, i64 0
  %r534 = load i64, ptr %r533, align 8
  %r535 = icmp eq i64 %r531, %r534
  %r536 = and i1 %r535, %r532
  br i1 %r536, label %pic.hit.108, label %pic.prefix.guard.110

pic.hit.overflow.125:                             ; preds = %pic.hit.108
  %r541 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r542 = bitcast double %r541 to i64
  %r543 = and i64 %r542, 281474976710655
  %r544 = trunc i64 %r538 to i32
  %statepoint_token66 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r502, i64 %r543, i32 %r544, ptr @perry_ic_test_json_string_emitters_ts__5, i32 0, i32 0)
  %r54567 = call double @llvm.experimental.gc.result.f64(token %statepoint_token66)
  br label %pic.merge.122

pic.hit.inline.126:                               ; preds = %pic.hit.108
  %r546 = shl i64 %r538, 3
  %r547 = add nuw nsw i64 %r502, 16
  %r548 = add i64 %r547, %r546
  %r549 = inttoptr i64 %r548 to ptr
  %r550 = load double, ptr %r549, align 8
  %r551 = bitcast double %r550 to i64
  %r552 = icmp eq i64 %r551, 9222246136947933200
  br i1 %r552, label %pic.miss.119, label %pic.hit.live.109

pic.ways.127:                                     ; preds = %pic.miss.119
  %r592 = getelementptr i64, ptr %r522, i64 4
  %r593 = load i64, ptr %r592, align 8
  %r594 = icmp eq i64 %r593, %r531
  %r595 = getelementptr i64, ptr %r522, i64 5
  %r596 = load i64, ptr %r595, align 8
  %r597 = select i1 %r594, i64 %r596, i64 0
  %r598 = getelementptr i64, ptr %r522, i64 6
  %r599 = load i64, ptr %r598, align 8
  %r600 = icmp eq i64 %r599, %r531
  %r601 = getelementptr i64, ptr %r522, i64 7
  %r602 = load i64, ptr %r601, align 8
  %r603 = select i1 %r600, i64 %r602, i64 0
  %r604 = getelementptr i64, ptr %r522, i64 8
  %r605 = load i64, ptr %r604, align 8
  %r606 = icmp eq i64 %r605, %r531
  %r607 = getelementptr i64, ptr %r522, i64 9
  %r608 = load i64, ptr %r607, align 8
  %r609 = select i1 %r606, i64 %r608, i64 0
  %r610 = getelementptr i64, ptr %r522, i64 10
  %r611 = load i64, ptr %r610, align 8
  %r612 = icmp eq i64 %r611, %r531
  %r613 = getelementptr i64, ptr %r522, i64 11
  %r614 = load i64, ptr %r613, align 8
  %r615 = select i1 %r612, i64 %r614, i64 0
  %r616 = or i1 %r594, %r600
  %r617 = select i1 %r594, i64 %r597, i64 %r603
  %r618 = or i1 %r606, %r612
  %r619 = select i1 %r606, i64 %r609, i64 %r615
  %r620 = or i1 %r616, %r618
  %r621 = select i1 %r616, i64 %r617, i64 %r619
  %r622 = and i1 %r532, %r620
  br i1 %r622, label %pic.way.load.128, label %pic.miss.call.121

pic.way.load.128:                                 ; preds = %pic.ways.127
  %r623 = shl i64 %r621, 3
  %r624 = add nuw nsw i64 %r502, 16
  %r625 = add i64 %r624, %r623
  %r626 = inttoptr i64 %r625 to ptr
  %r627 = load double, ptr %r626, align 8
  %r628 = bitcast double %r627 to i64
  %r629 = icmp eq i64 %r628, 9222246136947933200
  br i1 %r629, label %pic.miss.call.121, label %pic.way.live.129

pic.way.live.129:                                 ; preds = %pic.way.load.128
  br label %pic.merge.122

pget.throw_nullish.130:                           ; preds = %pget.recv_bad.103
  %r638 = zext i1 %r636 to i32
  %statepoint_token68 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r638, ptr @test_json_string_emitters_ts_.str.0.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.131:                       ; preds = %pget.recv_bad.103
  %r639 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r640 = bitcast double %r639 to i64
  %r641 = and i64 %r640, 281474976710655
  %statepoint_token69 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r501, i64 %r641, i32 0, i32 0)
  %r64270 = call double @llvm.experimental.gc.result.f64(token %statepoint_token69)
  br label %pget.recv_merge.105

streqlit.sso.132:                                 ; preds = %if.merge.12
  %r653 = icmp eq i64 %r650, 9221407709712050291
  br i1 %r653, label %streqlit.true.138, label %streqlit.tag.133

streqlit.tag.133:                                 ; preds = %streqlit.sso.132
  %r654 = lshr i64 %r650, 48
  %r655 = icmp eq i64 %r654, 32767
  %r656 = and i64 %r650, 281474976710655
  %r657 = icmp ugt i64 %r656, 4095
  %r658 = and i1 %r655, %r657
  br i1 %r658, label %streqlit.len.134, label %streqlit.false.139

streqlit.len.134:                                 ; preds = %streqlit.tag.133
  %r659 = inttoptr i64 %r656 to ptr
  %r660 = getelementptr inbounds nuw i8, ptr %r659, i64 4
  %r661 = load i32, ptr %r660, align 4
  %r662 = icmp eq i32 %r661, 5
  br i1 %r662, label %streqlit.b0.135, label %streqlit.false.139

streqlit.b0.135:                                  ; preds = %streqlit.len.134
  %r663 = getelementptr inbounds nuw i8, ptr %r659, i64 20
  %r664 = load i8, ptr %r663, align 1
  %r665 = icmp eq i8 %r664, 115
  br i1 %r665, label %streqlit.bl.136, label %streqlit.false.139

streqlit.bl.136:                                  ; preds = %streqlit.b0.135
  %r666 = getelementptr inbounds nuw i8, ptr %r659, i64 24
  %r667 = load i8, ptr %r666, align 1
  %r668 = icmp eq i8 %r667, 116
  br i1 %r668, label %streqlit.slow.137, label %streqlit.false.139

streqlit.slow.137:                                ; preds = %streqlit.bl.136
  %r669 = and i64 %r651, 281474976710655
  %statepoint_token71 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r656, i64 %r669, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0) ]
  %r67072 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token71)
  %rs4gc.s4.relocated73 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token71, i32 0, i32 0) ; (%.0, %.0)
  %r671 = icmp ne i32 %r67072, 0
  br label %streqlit.merge.140

streqlit.true.138:                                ; preds = %streqlit.sso.132, %if.merge.12
  br label %streqlit.merge.140

streqlit.false.139:                               ; preds = %streqlit.bl.136, %streqlit.b0.135, %streqlit.len.134, %streqlit.tag.133
  br label %streqlit.merge.140

streqlit.merge.140:                               ; preds = %streqlit.false.139, %streqlit.true.138, %streqlit.slow.137
  %.1 = phi ptr addrspace(1) [ %.0, %streqlit.true.138 ], [ %rs4gc.s4.relocated73, %streqlit.slow.137 ], [ %.0, %streqlit.false.139 ]
  %r672 = phi i1 [ true, %streqlit.true.138 ], [ false, %streqlit.false.139 ], [ %r671, %streqlit.slow.137 ]
  %r673 = select i1 %r672, i64 9222246136947933188, i64 9222246136947933187
  %r674 = bitcast i64 %r673 to double
  %r675 = icmp eq i64 %r673, 9222246136947933188
  br i1 %r675, label %if.then.141, label %if.else.142

if.then.141:                                      ; preds = %streqlit.merge.140
  %r676 = load double, ptr @test_json_string_emitters_ts_.str.6.handle, align 8
  ret double %r676

if.else.142:                                      ; preds = %streqlit.merge.140
  br label %if.merge.143

if.merge.143:                                     ; preds = %if.else.142
  %r677.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r677.rs4o = call i64 asm "", "=r,0"(i64 %r677.rs4i) #9
  %r677 = bitcast i64 %r677.rs4o to double
  ret double %r677
}

; Function Attrs: inlinehint optsize
define internal double @"perry_fn_test_json_string_emitters_ts__identity$generic"(double %arg3, double %arg4) #7 gc "statepoint-example" {
entry.0:
  %rs4gc.b1 = bitcast double %arg3 to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg4 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %r3.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r3.rs4o = call i64 asm "", "=r,0"(i64 %r3.rs4i) #9
  %r3 = bitcast i64 %r3.rs4o to double
  ret double %r3
}

; Function Attrs: noinline optsize
define double @perry_fn_test_json_string_emitters_ts__identity(double %arg3, double %arg4) #8 {
entry.0:
  %r1 = call i32 @js_typed_string_arg_guard(double %arg3)
  %r2 = icmp ne i32 %r1, 0
  br i1 %r2, label %spec_public.fast.1, label %spec_public.fallback.2

spec_public.fast.1:                               ; preds = %entry.0
  %r3 = call double @"perry_fn_test_json_string_emitters_ts__identity$spec_b_b"(double %arg3, double %arg4)
  ret double %r3

spec_public.fallback.2:                           ; preds = %entry.0
  %r4 = call double @"perry_fn_test_json_string_emitters_ts__identity$generic"(double %arg3, double %arg4)
  ret double %r4
}

; Function Attrs: optsize
define internal double @"perry_fn_test_json_string_emitters_ts__allocateString$generic"(double %arg8, double %arg9) #6 gc "statepoint-example" {
entry.0:
  %r104 = load <2 x i64>, ptr @perry_class_header_image_test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c, align 16
  %r486 = alloca [32 x double], align 8
  %rs4gc.b3 = bitcast double %arg8 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %rs4gc.b4 = bitcast double %arg9 to i64
  %rs4gc.s4 = inttoptr i64 %rs4gc.b4 to ptr addrspace(1)
  %r3.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3 to i64
  %r3.rs4o = call i64 asm "", "=r,0"(i64 %r3.rs4i) #9
  %r3 = bitcast i64 %r3.rs4o to double
  %r4 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r5 = bitcast double %r3 to i64
  %r6 = bitcast double %r4 to i64
  %r7 = icmp eq i64 %r5, %r6
  br i1 %r7, label %streqlit.true.7, label %streqlit.sso.1

streqlit.sso.1:                                   ; preds = %entry.0
  %r8 = icmp eq i64 %r5, 9221406112018359668
  br i1 %r8, label %streqlit.true.7, label %streqlit.tag.2

streqlit.tag.2:                                   ; preds = %streqlit.sso.1
  %r9 = lshr i64 %r5, 48
  %r10 = icmp eq i64 %r9, 32767
  %r11 = and i64 %r5, 281474976710655
  %r12 = icmp ugt i64 %r11, 4095
  %r13 = and i1 %r10, %r12
  br i1 %r13, label %streqlit.len.3, label %streqlit.false.8

streqlit.len.3:                                   ; preds = %streqlit.tag.2
  %r14 = inttoptr i64 %r11 to ptr
  %r15 = getelementptr inbounds nuw i8, ptr %r14, i64 4
  %r16 = load i32, ptr %r15, align 4
  %r17 = icmp eq i32 %r16, 4
  br i1 %r17, label %streqlit.b0.4, label %streqlit.false.8

streqlit.b0.4:                                    ; preds = %streqlit.len.3
  %r18 = getelementptr inbounds nuw i8, ptr %r14, i64 20
  %r19 = load i8, ptr %r18, align 1
  %r20 = icmp eq i8 %r19, 116
  br i1 %r20, label %streqlit.bl.5, label %streqlit.false.8

streqlit.bl.5:                                    ; preds = %streqlit.b0.4
  %r21 = getelementptr inbounds nuw i8, ptr %r14, i64 23
  %r22 = load i8, ptr %r21, align 1
  %r23 = icmp eq i8 %r22, 116
  br i1 %r23, label %streqlit.slow.6, label %streqlit.false.8

streqlit.slow.6:                                  ; preds = %streqlit.bl.5
  %r24 = and i64 %r6, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r11, i64 %r24, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4, ptr addrspace(1) %rs4gc.s3) ]
  %r2510 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token)
  %rs4gc.s4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s4, %rs4gc.s4)
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%rs4gc.s3, %rs4gc.s3)
  %r26 = icmp ne i32 %r2510, 0
  br label %streqlit.merge.9

streqlit.true.7:                                  ; preds = %streqlit.sso.1, %entry.0
  br label %streqlit.merge.9

streqlit.false.8:                                 ; preds = %streqlit.bl.5, %streqlit.b0.4, %streqlit.len.3, %streqlit.tag.2
  br label %streqlit.merge.9

streqlit.merge.9:                                 ; preds = %streqlit.false.8, %streqlit.true.7, %streqlit.slow.6
  %.074 = phi ptr addrspace(1) [ %rs4gc.s3, %streqlit.true.7 ], [ %rs4gc.s3.relocated, %streqlit.slow.6 ], [ %rs4gc.s3, %streqlit.false.8 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s4, %streqlit.true.7 ], [ %rs4gc.s4.relocated, %streqlit.slow.6 ], [ %rs4gc.s4, %streqlit.false.8 ]
  %r27 = phi i1 [ true, %streqlit.true.7 ], [ false, %streqlit.false.8 ], [ %r26, %streqlit.slow.6 ]
  %r28 = select i1 %r27, i64 9222246136947933188, i64 9222246136947933187
  %r29 = bitcast i64 %r28 to double
  %r30 = icmp eq i64 %r28, 9222246136947933188
  br i1 %r30, label %if.then.10, label %if.else.11

if.then.10:                                       ; preds = %streqlit.merge.9
  %statepoint_token11 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0)
  %r3212 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token11)
  %r33 = or i64 %r3212, 9222527611924643840
  %r34 = bitcast i64 %r33 to double
  %rs4gc.b5 = bitcast double %r34 to i64
  %rs4gc.s5 = inttoptr i64 %rs4gc.b5 to ptr addrspace(1)
  %r35.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s5 to i64
  %r35 = call i64 asm "", "=r,0"(i64 %r35.rs4i) #9
  %r36 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r37 = icmp ne i32 %r36, 0
  br i1 %r37, label %shadow.root.barrier.13, label %shadow.root.barrier.done.14

if.else.11:                                       ; preds = %streqlit.merge.9
  br label %if.merge.12

if.merge.12:                                      ; preds = %if.else.11
  %r648.rs4i = ptrtoint ptr addrspace(1) %.074 to i64
  %r648.rs4o = call i64 asm "", "=r,0"(i64 %r648.rs4i) #9
  %r648 = bitcast i64 %r648.rs4o to double
  %r649 = load double, ptr @test_json_string_emitters_ts_.str.5.handle, align 8
  %r650 = bitcast double %r648 to i64
  %r651 = bitcast double %r649 to i64
  %r652 = icmp eq i64 %r650, %r651
  br i1 %r652, label %streqlit.true.138, label %streqlit.sso.132

shadow.root.barrier.13:                           ; preds = %if.then.10
  call void @js_write_barrier_root_nanbox(i64 %r35) #9
  br label %shadow.root.barrier.done.14

shadow.root.barrier.done.14:                      ; preds = %shadow.root.barrier.13, %if.then.10
  %r38 = bitcast double %r34 to i64
  %r39 = and i64 %r38, 281474976710655
  call void @js_array_declare_all_pointer_elements(i64 %r39) #9
  br label %for.cond.15

for.cond.15:                                      ; preds = %for.update.17, %shadow.root.barrier.done.14
  %r74.0 = phi ptr [ null, %shadow.root.barrier.done.14 ], [ %r74.1, %for.update.17 ]
  %r40.0 = phi double [ 0.000000e+00, %shadow.root.barrier.done.14 ], [ %r261, %for.update.17 ]
  %r31.0.base = phi ptr addrspace(1) [ %rs4gc.s5, %shadow.root.barrier.done.14 ], [ %.087, %for.update.17 ], !is_base_value !0
  %r31.0 = phi ptr addrspace(1) [ %rs4gc.s5, %shadow.root.barrier.done.14 ], [ %.088, %for.update.17 ]
  %r42 = fcmp olt double %r40.0, 4.800000e+01
  %r43 = select i1 %r42, i64 9222246136947933188, i64 9222246136947933187
  %r44 = bitcast i64 %r43 to double
  %r45 = icmp eq i64 %r43, 9222246136947933188
  br i1 %r45, label %for.body.16, label %for.exit.18

for.body.16:                                      ; preds = %for.cond.15
  %r47 = load double, ptr @test_json_string_emitters_ts_.str.1.handle, align 8
  %r49 = fcmp oge double %r40.0, 0.000000e+00
  %r50 = fcmp olt double %r40.0, 3.200000e+01
  %r51 = and i1 %r49, %r50
  br i1 %r51, label %csite.chk.19, label %csite.plain.22

for.update.17:                                    ; preds = %gcpoll.done.60
  %r261 = fadd double %r40.0, 1.000000e+00
  br label %for.cond.15

for.exit.18:                                      ; preds = %for.cond.15
  %r263 = load double, ptr @test_json_string_emitters_ts_.str.2.handle, align 8
  %r264.rs4i = ptrtoint ptr addrspace(1) %r31.0 to i64
  %r264.rs4o = call i64 asm "", "=r,0"(i64 %r264.rs4i) #9
  %r264 = bitcast i64 %r264.rs4o to double
  %r265 = bitcast double %r264 to i64
  %r266 = and i64 %r265, 281474976710655
  %r267 = lshr i64 %r265, 48
  %r268 = icmp eq i64 %r267, 32765
  %r269 = icmp ugt i64 %r266, 1048575
  %r270 = and i1 %r268, %r269
  br i1 %r270, label %arr.guard.deref.65, label %arr.fallback.62

csite.chk.19:                                     ; preds = %for.body.16
  %r52 = fptosi double %r40.0 to i32
  %r53 = sitofp i32 %r52 to double
  %r54 = fcmp oeq double %r53, %r40.0
  %r55 = sext i32 %r52 to i64
  %r56 = getelementptr [32 x i64], ptr @perry_concat_site_test_json_string_emitters_ts__6, i64 0, i64 %r55
  %r57 = load i64, ptr %r56, align 8
  %r58 = icmp ne i64 %r57, 0
  %r59 = and i1 %r54, %r58
  br i1 %r59, label %csite.hit.20, label %csite.fill.21

csite.hit.20:                                     ; preds = %csite.chk.19
  %r60 = bitcast i64 %r57 to double
  br label %csite.merge.23

csite.fill.21:                                    ; preds = %csite.chk.19
  %r61 = bitcast double %r47 to i64
  %r62 = and i64 %r61, 281474976710655
  %statepoint_token13 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, double)) @js_string_concat_site_value, i32 3, i32 0, i64 ptrtoint (ptr @perry_concat_site_test_json_string_emitters_ts__6 to i64), i64 %r62, double %r40.0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r31.0.base, ptr addrspace(1) %r31.0) ]
  %r6414 = call double @llvm.experimental.gc.result.f64(token %statepoint_token13)
  %r31.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token13, i32 0, i32 0) ; (%r31.0.base, %r31.0.base)
  %r31.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token13, i32 0, i32 1) ; (%r31.0.base, %r31.0)
  br label %csite.merge.23

csite.plain.22:                                   ; preds = %for.body.16
  %r65 = bitcast double %r47 to i64
  %r66 = and i64 %r65, 281474976710655
  %statepoint_token15 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r66, double %r40.0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r31.0.base, ptr addrspace(1) %r31.0) ]
  %r6716 = call double @llvm.experimental.gc.result.f64(token %statepoint_token15)
  %r31.0.base.relocated17 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token15, i32 0, i32 0) ; (%r31.0.base, %r31.0.base)
  %r31.0.relocated18 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token15, i32 0, i32 1) ; (%r31.0.base, %r31.0)
  br label %csite.merge.23

csite.merge.23:                                   ; preds = %csite.plain.22, %csite.fill.21, %csite.hit.20
  %.077 = phi ptr addrspace(1) [ %r31.0, %csite.hit.20 ], [ %r31.0.relocated, %csite.fill.21 ], [ %r31.0.relocated18, %csite.plain.22 ]
  %.075 = phi ptr addrspace(1) [ %r31.0.base, %csite.hit.20 ], [ %r31.0.base.relocated, %csite.fill.21 ], [ %r31.0.base.relocated17, %csite.plain.22 ]
  %r68 = phi double [ %r60, %csite.hit.20 ], [ %r6414, %csite.fill.21 ], [ %r6716, %csite.plain.22 ]
  %r69 = bitcast double %r68 to i64
  %rs4gc.s6 = inttoptr i64 %r69 to ptr addrspace(1)
  %r71.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r71 = call i64 asm "", "=r,0"(i64 %r71.rs4i) #9
  %r72 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r73 = icmp ne i32 %r72, 0
  br i1 %r73, label %shadow.root.barrier.24, label %shadow.root.barrier.done.25

shadow.root.barrier.24:                           ; preds = %csite.merge.23
  call void @js_write_barrier_root_nanbox(i64 %r71) #9
  br label %shadow.root.barrier.done.25

shadow.root.barrier.done.25:                      ; preds = %shadow.root.barrier.24, %csite.merge.23
  %r76 = icmp eq ptr %r74.0, null
  br i1 %r76, label %arena_state.init.26, label %arena_state.ready.27

arena_state.init.26:                              ; preds = %shadow.root.barrier.done.25
  %r77 = load atomic i64, ptr @PERRY_HOT_TSD_KEY monotonic, align 8
  %r78 = icmp ne i64 %r77, -1
  br i1 %r78, label %arena_state.hot_tls.tsd.28, label %arena_state.hot_tls.slow.30

arena_state.ready.27:                             ; preds = %arena_state.hot_tls.resolved.32, %shadow.root.barrier.done.25
  %.083 = phi ptr addrspace(1) [ %.184, %arena_state.hot_tls.resolved.32 ], [ %rs4gc.s6, %shadow.root.barrier.done.25 ]
  %.178 = phi ptr addrspace(1) [ %.279, %arena_state.hot_tls.resolved.32 ], [ %.077, %shadow.root.barrier.done.25 ]
  %.176 = phi ptr addrspace(1) [ %.2, %arena_state.hot_tls.resolved.32 ], [ %.075, %shadow.root.barrier.done.25 ]
  %r74.1 = phi ptr [ %r74.2, %arena_state.hot_tls.resolved.32 ], [ %r74.0, %shadow.root.barrier.done.25 ]
  %r92 = phi ptr [ %r74.0, %shadow.root.barrier.done.25 ], [ %r91, %arena_state.hot_tls.resolved.32 ]
  %r93 = getelementptr i8, ptr %r92, i64 8
  %r94 = load i64, ptr %r93, align 8
  %r95 = add i64 %r94, 40
  %r96 = getelementptr i8, ptr %r92, i64 16
  %r97 = load i64, ptr %r96, align 8
  %r98 = icmp ule i64 %r95, %r97
  br i1 %r98, label %alloc.fast.33, label %alloc.slow.34

arena_state.hot_tls.tsd.28:                       ; preds = %arena_state.init.26
  %r79 = call i64 asm sideeffect "mrs $0, tpidrro_el0", "=r"() #9
  %r80 = and i64 %r79, -8
  %r81 = shl i64 %r77, 3
  %r82 = add i64 %r80, %r81
  %r83 = inttoptr i64 %r82 to ptr
  %r84 = load ptr, ptr %r83, align 8
  %r85 = icmp ne ptr %r84, null
  br i1 %r85, label %arena_state.hot_tls.fast.29, label %arena_state.hot_tls.slow.30

arena_state.hot_tls.fast.29:                      ; preds = %arena_state.hot_tls.tsd.28
  %r86 = getelementptr i8, ptr %r84, i64 8
  %r87 = load ptr, ptr %r86, align 8
  %r88 = load ptr, ptr %r87, align 8
  %r89 = icmp ne ptr %r88, null
  br i1 %r89, label %arena_state.hot_tls.ready.31, label %arena_state.hot_tls.slow.30

arena_state.hot_tls.slow.30:                      ; preds = %arena_state.hot_tls.fast.29, %arena_state.hot_tls.tsd.28, %arena_state.init.26
  %statepoint_token19 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr ()) @js_inline_arena_state, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.075, ptr addrspace(1) %.077, ptr addrspace(1) %rs4gc.s6) ]
  %r9020 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token19)
  %r31.0.base.relocated21 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 0, i32 0) ; (%.075, %.075)
  %r31.0.relocated22 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 0, i32 1) ; (%.075, %.077)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 2, i32 2) ; (%rs4gc.s6, %rs4gc.s6)
  br label %arena_state.hot_tls.resolved.32

arena_state.hot_tls.ready.31:                     ; preds = %arena_state.hot_tls.fast.29
  br label %arena_state.hot_tls.resolved.32

arena_state.hot_tls.resolved.32:                  ; preds = %arena_state.hot_tls.ready.31, %arena_state.hot_tls.slow.30
  %.184 = phi ptr addrspace(1) [ %rs4gc.s6, %arena_state.hot_tls.ready.31 ], [ %rs4gc.s6.relocated, %arena_state.hot_tls.slow.30 ]
  %.279 = phi ptr addrspace(1) [ %.077, %arena_state.hot_tls.ready.31 ], [ %r31.0.relocated22, %arena_state.hot_tls.slow.30 ]
  %.2 = phi ptr addrspace(1) [ %.075, %arena_state.hot_tls.ready.31 ], [ %r31.0.base.relocated21, %arena_state.hot_tls.slow.30 ]
  %r74.2 = phi ptr [ %r87, %arena_state.hot_tls.ready.31 ], [ %r9020, %arena_state.hot_tls.slow.30 ]
  %r91 = phi ptr [ %r87, %arena_state.hot_tls.ready.31 ], [ %r9020, %arena_state.hot_tls.slow.30 ]
  br label %arena_state.ready.27

alloc.fast.33:                                    ; preds = %arena_state.ready.27
  store i64 %r95, ptr %r93, align 8
  %r99 = load ptr, ptr %r92, align 8
  %r100 = getelementptr i8, ptr %r99, i64 %r94
  br label %alloc.merge.35

alloc.slow.34:                                    ; preds = %arena_state.ready.27
  %statepoint_token23 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr (ptr, i64, i64)) @js_inline_arena_slow_alloc, i32 3, i32 0, ptr %r92, i64 40, i64 8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.176, ptr addrspace(1) %.178, ptr addrspace(1) %.083) ]
  %r10124 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token23)
  %r31.0.base.relocated25 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token23, i32 0, i32 0) ; (%.176, %.176)
  %r31.0.relocated26 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token23, i32 0, i32 1) ; (%.176, %.178)
  %rs4gc.s6.relocated27 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token23, i32 2, i32 2) ; (%.083, %.083)
  br label %alloc.merge.35

alloc.merge.35:                                   ; preds = %alloc.slow.34, %alloc.fast.33
  %.285 = phi ptr addrspace(1) [ %.083, %alloc.fast.33 ], [ %rs4gc.s6.relocated27, %alloc.slow.34 ]
  %.380 = phi ptr addrspace(1) [ %.178, %alloc.fast.33 ], [ %r31.0.relocated26, %alloc.slow.34 ]
  %.3 = phi ptr addrspace(1) [ %.176, %alloc.fast.33 ], [ %r31.0.base.relocated25, %alloc.slow.34 ]
  %r102 = phi ptr [ %r100, %alloc.fast.33 ], [ %r10124, %alloc.slow.34 ]
  store <2 x i64> %r104, ptr %r102, align 8
  %r106 = getelementptr i8, ptr %r102, i64 16
  store i64 0, ptr %r106, align 8
  %r107 = getelementptr i8, ptr %r102, i64 24
  store i64 9222246136947933185, ptr %r107, align 8
  %r108 = getelementptr i8, ptr %r102, i64 32
  store i64 9222246136947933185, ptr %r108, align 8
  %r109 = getelementptr i8, ptr %r102, i64 8
  %r110 = ptrtoint ptr %r109 to i64
  %r111 = load atomic i32, ptr @PERRY_PER_OBJECT_LAYOUTS_ANY monotonic, align 4
  %r112 = icmp ne i32 %r111, 0
  br i1 %r112, label %layout_forget.young.36, label %layout_forget.done.39

layout_forget.young.36:                           ; preds = %alloc.merge.35
  %r113 = load atomic i32, ptr @PERRY_YOUNG_LAYOUT_RECORDS monotonic, align 4
  %r114 = icmp ne i32 %r113, 0
  br i1 %r114, label %layout_forget.sketch.37, label %layout_forget.done.39

layout_forget.sketch.37:                          ; preds = %layout_forget.young.36
  %r115 = mul i64 %r110, -7046029254386353131
  %r116 = lshr i64 %r115, 52
  %r117 = lshr i64 %r116, 6
  %r118 = and i64 %r116, 63
  %r119 = shl nuw i64 1, %r118
  %r120 = getelementptr i64, ptr @PERRY_LAYOUT_ADDR_FILTER, i64 %r117
  %r121 = load atomic i64, ptr %r120 monotonic, align 8
  %r122 = and i64 %r121, %r119
  %r123 = icmp ne i64 %r122, 0
  br i1 %r123, label %layout_forget.armed.38, label %layout_forget.done.39

layout_forget.armed.38:                           ; preds = %layout_forget.sketch.37
  call void @js_gc_forget_object_layout(i64 %r110) #9
  br label %layout_forget.done.39

layout_forget.done.39:                            ; preds = %layout_forget.armed.38, %layout_forget.sketch.37, %layout_forget.young.36, %alloc.merge.35
  %rs4gc.s7 = inttoptr i64 %r110 to ptr addrspace(1)
  %r125.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7 to i64
  %r125 = call i64 asm "", "=r,0"(i64 %r125.rs4i) #9
  %r126 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r127 = icmp ne i32 %r126, 0
  br i1 %r127, label %shadow.root.barrier.40, label %shadow.root.barrier.done.41

shadow.root.barrier.40:                           ; preds = %layout_forget.done.39
  call void @js_write_barrier_root_nanbox(i64 %r125) #9
  br label %shadow.root.barrier.done.41

shadow.root.barrier.done.41:                      ; preds = %shadow.root.barrier.40, %layout_forget.done.39
  %r128 = or i64 %r110, 9222527611924643840
  %r129 = bitcast i64 %r128 to double
  %r130.rs4i = ptrtoint ptr addrspace(1) %.285 to i64
  %r130 = call i64 asm "", "=r,0"(i64 %r130.rs4i) #9
  %r131 = bitcast i64 %r130 to double
  %r132 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r133 = icmp eq i8 %r132, 0
  %r134 = bitcast double %r40.0 to i64
  %r135 = and i64 %r134, 9218868437227405312
  %r136 = icmp ne i64 %r135, 9218868437227405312
  %r137 = and i1 %r133, %r136
  br i1 %r137, label %ctor_prologue.fast.42, label %ctor_prologue.slow.43

ctor_prologue.fast.42:                            ; preds = %shadow.root.barrier.done.41
  %r138 = inttoptr i64 %r110 to ptr
  %r139 = getelementptr i8, ptr %r138, i64 16
  %r140 = bitcast double %r129 to i64
  %r141 = getelementptr double, ptr %r139, i64 0
  store double %r40.0, ptr %r141, align 8
  %r142 = ptrtoint ptr %r141 to i64
  %r143 = bitcast double %r40.0 to i64
  %r144 = getelementptr double, ptr %r139, i64 1
  store double %r131, ptr %r144, align 8
  %r145 = ptrtoint ptr %r144 to i64
  %r146 = bitcast double %r131 to i64
  %r147 = lshr i64 %r146, 48
  %r148 = icmp eq i64 %r147, 0
  %r149 = icmp uge i64 %r146, 4096
  %r150 = and i1 %r148, %r149
  %r151 = icmp eq i64 %r147, 32765
  %r152 = icmp eq i64 %r147, 32767
  %r153 = icmp eq i64 %r147, 32762
  %r154 = or i1 %r151, %r152
  %r155 = or i1 %r154, %r153
  %r156 = or i1 %r155, %r150
  br i1 %r156, label %ctor_prologue.barrier.maybe.45, label %ctor_prologue.barrier.done.47

ctor_prologue.slow.43:                            ; preds = %shadow.root.barrier.done.41
  %statepoint_token28 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, double)) @test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c_constructor, i32 3, i32 0, double %r129, double %r40.0, double %r131, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3, ptr addrspace(1) %.380, ptr addrspace(1) %rs4gc.s7) ]
  %r16529 = call double @llvm.experimental.gc.result.f64(token %statepoint_token28)
  %r31.0.base.relocated30 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token28, i32 0, i32 0) ; (%.3, %.3)
  %r31.0.relocated31 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token28, i32 0, i32 1) ; (%.3, %.380)
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token28, i32 2, i32 2) ; (%rs4gc.s7, %rs4gc.s7)
  br label %ctor_prologue.merge.44

ctor_prologue.merge.44:                           ; preds = %ctor_prologue.barrier.done.47, %ctor_prologue.slow.43
  %.086 = phi ptr addrspace(1) [ %rs4gc.s7, %ctor_prologue.barrier.done.47 ], [ %rs4gc.s7.relocated, %ctor_prologue.slow.43 ]
  %.481 = phi ptr addrspace(1) [ %.380, %ctor_prologue.barrier.done.47 ], [ %r31.0.relocated31, %ctor_prologue.slow.43 ]
  %.4 = phi ptr addrspace(1) [ %.3, %ctor_prologue.barrier.done.47 ], [ %r31.0.base.relocated30, %ctor_prologue.slow.43 ]
  %r166 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.47 ], [ %r16529, %ctor_prologue.slow.43 ]
  %r167.rs4i = ptrtoint ptr addrspace(1) %.086 to i64
  %r167 = call i64 asm "", "=r,0"(i64 %r167.rs4i) #9
  %r168 = or i64 %r167, 9222527611924643840
  %r169 = bitcast i64 %r168 to double
  %r170 = bitcast double %r166 to i64
  %r171 = icmp eq i64 %r170, 9222246136947933185
  br i1 %r171, label %ctor_ret.merge.49, label %ctor_ret.override.48

ctor_prologue.barrier.maybe.45:                   ; preds = %ctor_prologue.fast.42
  %r157 = sub i64 %r110, 7
  %r158 = inttoptr i64 %r157 to ptr
  %r159 = load i8, ptr %r158, align 1
  %r160 = and i8 %r159, 32
  %r161 = icmp ne i8 %r160, 0
  %r162 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r163 = icmp ne i32 %r162, 0
  %r164 = or i1 %r161, %r163
  br i1 %r164, label %ctor_prologue.barrier.46, label %ctor_prologue.barrier.done.47

ctor_prologue.barrier.46:                         ; preds = %ctor_prologue.barrier.maybe.45
  call void @js_write_barrier_slot_validated_parent(i64 %r110, i64 %r145, i64 %r146) #9
  br label %ctor_prologue.barrier.done.47

ctor_prologue.barrier.done.47:                    ; preds = %ctor_prologue.barrier.46, %ctor_prologue.barrier.maybe.45, %ctor_prologue.fast.42
  br label %ctor_prologue.merge.44

ctor_ret.override.48:                             ; preds = %ctor_prologue.merge.44
  %statepoint_token32 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r169, double %r166, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4, ptr addrspace(1) %.481) ]
  %r17233 = call double @llvm.experimental.gc.result.f64(token %statepoint_token32)
  %r31.0.base.relocated34 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token32, i32 0, i32 0) ; (%.4, %.4)
  %r31.0.relocated35 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token32, i32 0, i32 1) ; (%.4, %.481)
  br label %ctor_ret.merge.49

ctor_ret.merge.49:                                ; preds = %ctor_ret.override.48, %ctor_prologue.merge.44
  %.582 = phi ptr addrspace(1) [ %.481, %ctor_prologue.merge.44 ], [ %r31.0.relocated35, %ctor_ret.override.48 ]
  %.5 = phi ptr addrspace(1) [ %.4, %ctor_prologue.merge.44 ], [ %r31.0.base.relocated34, %ctor_ret.override.48 ]
  %r173 = phi double [ %r169, %ctor_prologue.merge.44 ], [ %r17233, %ctor_ret.override.48 ]
  %r174 = bitcast double %r173 to i64
  %r175.rs4i = ptrtoint ptr addrspace(1) %.582 to i64
  %r175.rs4o = call i64 asm "", "=r,0"(i64 %r175.rs4i) #9
  %r175 = bitcast i64 %r175.rs4o to double
  %r176 = bitcast double %r175 to i64
  %r177 = and i64 %r176, 281474976710655
  %r178 = sub nsw i64 %r177, 8
  %r179 = inttoptr i64 %r178 to ptr
  %r180 = load i8, ptr %r179, align 1
  %r181 = icmp ne i8 %r180, 1
  %r182 = sub nsw i64 %r177, 7
  %r183 = inttoptr i64 %r182 to ptr
  %r184 = load i8, ptr %r183, align 1
  %r185 = and i8 %r184, -128
  %r186 = icmp ne i8 %r185, 0
  %r187 = or i1 %r181, %r186
  br i1 %r186, label %apush.fwd.50, label %apush.elements.51

apush.fwd.50:                                     ; preds = %apush.elements.check.52, %ctor_ret.merge.49
  %statepoint_token36 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r177, double %r173, i32 0, i32 0)
  %r21437 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token36)
  %r215 = or i64 %r21437, 9222527611924643840
  %r216 = bitcast i64 %r215 to double
  %rs4gc.b8 = bitcast double %r216 to i64
  %rs4gc.s8 = inttoptr i64 %rs4gc.b8 to ptr addrspace(1)
  br label %apush.merge.56

apush.elements.51:                                ; preds = %ctor_ret.merge.49
  %r189 = add nuw nsw i64 %r177, 8
  %r190 = inttoptr i64 %r189 to ptr
  %r191 = load i64, ptr %r190, align 8
  %r192 = icmp ne i64 %r191, 0
  %r193 = icmp eq i8 %r180, 2
  %r194 = and i1 %r193, %r192
  %r195 = select i1 %r194, i64 %r191, i64 %r177
  %r196 = inttoptr i64 %r195 to ptr
  %r197 = getelementptr i64, ptr %r196, i64 12
  %r198 = load i64, ptr %r197, align 8
  %r199 = icmp ne i64 %r198, 0
  %r200 = and i1 %r194, %r199
  %r201 = select i1 %r200, i64 %r198, i64 %r177
  %r188 = icmp eq i8 %r180, 1
  br i1 %r188, label %apush.nofwd.53, label %apush.elements.check.52

apush.elements.check.52:                          ; preds = %apush.elements.51
  %r202 = icmp ne i64 %r201, 0
  %r203 = sub i64 %r201, 8
  %r204 = inttoptr i64 %r203 to ptr
  %r205 = load i8, ptr %r204, align 1
  %r206 = icmp eq i8 %r205, 1
  %r207 = sub i64 %r201, 7
  %r208 = inttoptr i64 %r207 to ptr
  %r209 = load i8, ptr %r208, align 1
  %r210 = and i8 %r209, -128
  %r211 = icmp eq i8 %r210, 0
  %r212 = and i1 %r202, %r206
  %r213 = and i1 %r212, %r211
  br i1 %r213, label %apush.nofwd.53, label %apush.fwd.50

apush.nofwd.53:                                   ; preds = %apush.elements.check.52, %apush.elements.51
  %r217 = phi i64 [ %r177, %apush.elements.51 ], [ %r201, %apush.elements.check.52 ]
  %r218 = sub i64 %r217, 6
  %r219 = inttoptr i64 %r218 to ptr
  %r220 = load i16, ptr %r219, align 2
  %r221 = and i16 %r220, -2937
  %r222 = icmp eq i16 %r221, -24576
  %r223 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r224 = icmp eq i8 %r223, 0
  %r225 = and i1 %r222, %r224
  %r226 = icmp ult i64 %r217, 4096
  %r227 = inttoptr i64 %r217 to ptr
  %r228 = select i1 %r226, ptr @perry_null_guard_zero_test_json_string_emitters_ts, ptr %r227
  %r229 = load i32, ptr %r228, align 4
  %r230 = add i64 %r217, 4
  %r231 = inttoptr i64 %r230 to ptr
  %r232 = load i32, ptr %r231, align 4
  %r233 = icmp ult i32 %r229, %r232
  %r234 = and i1 %r233, %r225
  br i1 %r234, label %apush.inbounds.54, label %apush.realloc.55

apush.inbounds.54:                                ; preds = %apush.nofwd.53
  %r235 = icmp ult i64 %r217, 4096
  %r236 = inttoptr i64 %r217 to ptr
  %r237 = select i1 %r235, ptr @perry_null_guard_zero_test_json_string_emitters_ts, ptr %r236
  %r238 = load i32, ptr %r237, align 4
  %r239 = zext i32 %r238 to i64
  %r240 = shl nuw nsw i64 %r239, 3
  %r241 = add nuw nsw i64 %r240, 8
  %r242 = add i64 %r217, %r241
  %r243 = inttoptr i64 %r242 to ptr
  store double %r173, ptr %r243, align 8
  call void @js_string_addref_if_heap_string(double %r173) #9
  %r244 = bitcast double %r173 to i64
  %r245 = sub i64 %r217, 7
  %r246 = inttoptr i64 %r245 to ptr
  %r247 = load i8, ptr %r246, align 1
  %r248 = and i8 %r247, 32
  %r249 = icmp ne i8 %r248, 0
  %r250 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r251 = icmp ne i32 %r250, 0
  %r252 = or i1 %r249, %r251
  br i1 %r252, label %apush.barrier.57, label %apush.barrier.done.58

apush.realloc.55:                                 ; preds = %apush.nofwd.53
  %statepoint_token38 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r177, double %r173, i32 0, i32 0)
  %r25539 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token38)
  %r256 = or i64 %r25539, 9222527611924643840
  %r257 = bitcast i64 %r256 to double
  %rs4gc.b9 = bitcast double %r257 to i64
  %rs4gc.s9 = inttoptr i64 %rs4gc.b9 to ptr addrspace(1)
  br label %apush.merge.56

apush.merge.56:                                   ; preds = %apush.barrier.done.58, %apush.realloc.55, %apush.fwd.50
  %r31.1.base = phi ptr addrspace(1) [ %rs4gc.s8, %apush.fwd.50 ], [ %.5, %apush.barrier.done.58 ], [ %rs4gc.s9, %apush.realloc.55 ], !is_base_value !0
  %r31.1 = phi ptr addrspace(1) [ %rs4gc.s8, %apush.fwd.50 ], [ %.582, %apush.barrier.done.58 ], [ %rs4gc.s9, %apush.realloc.55 ]
  %r258 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r259 = icmp ne i32 %r258, 0
  br i1 %r259, label %gcpoll.59, label %gcpoll.done.60

apush.barrier.57:                                 ; preds = %apush.inbounds.54
  call void @js_write_barrier_slot_validated_parent(i64 %r217, i64 %r242, i64 %r244) #9
  br label %apush.barrier.done.58

apush.barrier.done.58:                            ; preds = %apush.barrier.57, %apush.inbounds.54
  %r253 = add i32 %r238, 1
  %r254 = inttoptr i64 %r217 to ptr
  store i32 %r253, ptr %r254, align 4
  br label %apush.merge.56

gcpoll.59:                                        ; preds = %apush.merge.56
  %statepoint_token40 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r31.1.base, ptr addrspace(1) %r31.1) ]
  %r31.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token40, i32 0, i32 0) ; (%r31.1.base, %r31.1.base)
  %r31.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token40, i32 0, i32 1) ; (%r31.1.base, %r31.1)
  br label %gcpoll.done.60

gcpoll.done.60:                                   ; preds = %gcpoll.59, %apush.merge.56
  %.088 = phi ptr addrspace(1) [ %r31.1.relocated, %gcpoll.59 ], [ %r31.1, %apush.merge.56 ]
  %.087 = phi ptr addrspace(1) [ %r31.1.base.relocated, %gcpoll.59 ], [ %r31.1.base, %apush.merge.56 ]
  br label %for.update.17

arr.fast.61:                                      ; preds = %arr.guard.range.67
  %r329 = add i64 %r285, 384
  %r330 = inttoptr i64 %r329 to ptr
  %r331 = load double, ptr %r330, align 8
  %r332 = bitcast double %r331 to i64
  %r333 = icmp eq i64 %r332, 9222246136947933200
  %r335 = select i1 %r333, double 0x7FFC000000000001, double %r331
  br label %arr.merge.64

arr.fallback.62:                                  ; preds = %arr.guard.live.66, %arr.guard.deref.65, %for.exit.18
  %statepoint_token41 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 6553530643794362375, double %r264, double 4.700000e+01, i32 0, i32 0)
  %r32542 = call double @llvm.experimental.gc.result.f64(token %statepoint_token41)
  br label %arr.merge.64

arr.guard.oob.63:                                 ; preds = %arr.guard.range.67
  br label %arr.merge.64

arr.merge.64:                                     ; preds = %arr.guard.oob.63, %arr.fallback.62, %arr.fast.61
  %r336 = phi double [ %r335, %arr.fast.61 ], [ %r32542, %arr.fallback.62 ], [ 0x7FFC000000000001, %arr.guard.oob.63 ]
  %r337 = bitcast double %r336 to i64
  %r338 = and i64 %r337, 281474976710655
  %r339 = lshr i64 %r337, 48
  %r340 = and i64 %r339, 65533
  %r341 = icmp eq i64 %r340, 32765
  br i1 %r341, label %pget.recv_ok.69, label %pget.recv_other.73

arr.guard.deref.65:                               ; preds = %for.exit.18
  %r271 = bitcast double %r264 to i64
  %r272 = and i64 %r271, 281474976710655
  %r273 = sub nsw i64 %r272, 8
  %r274 = inttoptr i64 %r273 to ptr
  %r275 = load i8, ptr %r274, align 1
  %r276 = icmp eq i8 %r275, 1
  %r277 = sub nsw i64 %r272, 7
  %r278 = inttoptr i64 %r277 to ptr
  %r279 = load i8, ptr %r278, align 1
  %r280 = and i8 %r279, -128
  %r281 = icmp ne i8 %r280, 0
  %r282 = inttoptr i64 %r272 to ptr
  %r283 = load i64, ptr %r282, align 8
  %r284 = and i1 %r276, %r281
  %r285 = select i1 %r284, i64 %r283, i64 %r272
  %r286 = lshr i64 %r285, 48
  %r287 = icmp eq i64 %r286, 0
  %r288 = icmp ugt i64 %r285, 1048575
  %r289 = and i1 %r287, %r288
  br i1 %r289, label %arr.guard.live.66, label %arr.fallback.62

arr.guard.live.66:                                ; preds = %arr.guard.deref.65
  %r290 = sub nuw i64 %r285, 8
  %r291 = inttoptr i64 %r290 to ptr
  %r292 = load i8, ptr %r291, align 1
  %r293 = icmp eq i8 %r292, 1
  %r294 = sub nuw i64 %r285, 7
  %r295 = inttoptr i64 %r294 to ptr
  %r296 = load i8, ptr %r295, align 1
  %r297 = and i8 %r296, -128
  %r298 = icmp eq i8 %r297, 0
  %r299 = sub nuw i64 %r285, 6
  %r300 = inttoptr i64 %r299 to ptr
  %r301 = load i16, ptr %r300, align 2
  %r302 = and i16 %r301, 1024
  %r303 = icmp eq i16 %r302, 0
  %r304 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r305 = icmp eq i8 %r304, 0
  %r306 = inttoptr i64 %r285 to ptr
  %r307 = load i32, ptr %r306, align 4
  %r308 = getelementptr i8, ptr %r306, i64 4
  %r309 = load i32, ptr %r308, align 4
  %r313 = icmp ule i32 %r307, 16000000
  %r314 = icmp ule i32 %r309, 16000000
  %r315 = icmp ule i32 %r307, %r309
  %r316 = and i1 %r293, %r298
  %r317 = and i1 %r316, %r303
  %r318 = and i1 %r317, %r305
  %r320 = and i1 %r318, %r313
  %r321 = and i1 %r320, %r314
  %r322 = and i1 %r321, %r315
  br i1 %r322, label %arr.guard.range.67, label %arr.fallback.62

arr.guard.range.67:                               ; preds = %arr.guard.live.66
  %r312 = icmp ult i32 47, %r307
  br i1 %r312, label %arr.fast.61, label %arr.guard.oob.63

pget.recv_sso.68:                                 ; preds = %pget.recv_other.73
  %r479 = load double, ptr @test_json_string_emitters_ts_.str.3.handle, align 8
  %r480 = bitcast double %r479 to i64
  %r481 = and i64 %r480, 281474976710655
  %statepoint_token43 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r337, i64 %r481, i32 0, i32 0)
  %r48244 = call double @llvm.experimental.gc.result.f64(token %statepoint_token43)
  br label %pget.recv_merge.72

pget.recv_ok.69:                                  ; preds = %arr.merge.64
  %r348 = icmp ugt i64 %r338, 1048575
  br i1 %r348, label %pic.recv_hdr.90, label %pic.miss.cold.87

pget.recv_bad.70:                                 ; preds = %pget.check_class_ref.74
  %r471 = icmp eq i64 %r337, 9222246136947933185
  %r472 = icmp eq i64 %r337, 9222246136947933186
  %r473 = or i1 %r471, %r472
  br i1 %r473, label %pget.throw_nullish.97, label %pget.recv_undef_return.98

pget.recv_class_ref.71:                           ; preds = %pget.check_class_ref.74
  %r344 = load double, ptr @test_json_string_emitters_ts_.str.3.handle, align 8
  %r345 = bitcast double %r344 to i64
  %r346 = and i64 %r345, 281474976710655
  %statepoint_token45 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6553530643794362376, i64 %r337, i64 %r346, i32 0, i32 0)
  %r34746 = call double @llvm.experimental.gc.result.f64(token %statepoint_token45)
  br label %pget.recv_merge.72

pget.recv_merge.72:                               ; preds = %pget.recv_undef_return.98, %pic.merge.89, %pget.recv_class_ref.71, %pget.recv_sso.68
  %r483 = phi double [ %r470, %pic.merge.89 ], [ %r47859, %pget.recv_undef_return.98 ], [ %r48244, %pget.recv_sso.68 ], [ %r34746, %pget.recv_class_ref.71 ]
  %r484 = load double, ptr @test_json_string_emitters_ts_.str.4.handle, align 8
  %r485 = load double, ptr @test_json_string_emitters_ts_.str.2.handle, align 8
  %r487 = getelementptr double, ptr %r486, i64 0
  store double %r485, ptr %r487, align 8
  %r488 = getelementptr double, ptr %r486, i64 1
  store double %r483, ptr %r488, align 8
  %r489 = getelementptr double, ptr %r486, i64 2
  store double %r484, ptr %r489, align 8
  %r490 = ptrtoint ptr %r486 to i64
  %statepoint_token47 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r490, i32 3, i32 0, i32 0)
  %r49148 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token47)
  %r492 = or i64 %r49148, 9223090561878065152
  %r493 = bitcast i64 %r492 to double
  %statepoint_token49 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r493, i32 0, i32 0)
  %r49450 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token49)
  %statepoint_token51 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r49450, i32 0, i32 0)
  %r49552 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token51)
  %r496 = bitcast i64 %r49552 to double
  %rs4gc.b10 = bitcast double %r496 to i64
  %rs4gc.s10 = inttoptr i64 %rs4gc.b10 to ptr addrspace(1)
  %r497.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r497 = call i64 asm "", "=r,0"(i64 %r497.rs4i) #9
  %r498 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r499 = icmp ne i32 %r498, 0
  br i1 %r499, label %shadow.root.barrier.99, label %shadow.root.barrier.done.100

pget.recv_other.73:                               ; preds = %arr.merge.64
  %r342 = icmp eq i64 %r339, 32761
  br i1 %r342, label %pget.recv_sso.68, label %pget.check_class_ref.74

pget.check_class_ref.74:                          ; preds = %pget.recv_other.73
  %r343 = icmp eq i64 %r339, 32766
  br i1 %r343, label %pget.recv_class_ref.71, label %pget.recv_bad.70

pic.hit.75:                                       ; preds = %pic.token.91
  %r373 = getelementptr i64, ptr %r358, i64 1
  %r374 = load i64, ptr %r373, align 8
  %r375 = and i64 %r374, 1073741824
  %r376 = icmp ne i64 %r375, 0
  br i1 %r376, label %pic.hit.overflow.92, label %pic.hit.inline.93

pic.hit.live.76:                                  ; preds = %pic.hit.inline.93
  br label %pic.merge.89

pic.prefix.guard.77:                              ; preds = %pic.token.91
  %r389 = getelementptr i64, ptr %r358, i64 2
  %r390 = load i64, ptr %r389, align 8
  %r391 = icmp ne i64 %r390, 0
  br i1 %r391, label %pic.prefix.meta.78, label %pic.miss.86

pic.prefix.meta.78:                               ; preds = %pic.prefix.guard.77
  %r392 = add nuw nsw i64 %r338, 8
  %r393 = inttoptr i64 %r392 to ptr
  %r394 = load i64, ptr %r393, align 8
  %r395 = icmp ne i64 %r394, 0
  br i1 %r395, label %pic.prefix.token.79, label %pic.miss.86

pic.prefix.token.79:                              ; preds = %pic.prefix.meta.78
  %r396 = inttoptr i64 %r394 to ptr
  %r397 = getelementptr i64, ptr %r396, i64 6
  %r398 = load i64, ptr %r397, align 8
  %r399 = icmp eq i64 %r398, %r390
  br i1 %r399, label %pic.prefix.hit.80, label %pic.miss.86

pic.prefix.hit.80:                                ; preds = %pic.prefix.token.79
  %r400 = getelementptr i64, ptr %r358, i64 1
  %r401 = load i64, ptr %r400, align 8
  %r402 = shl i64 %r401, 3
  %r403 = add nuw nsw i64 %r338, 16
  %r404 = add i64 %r403, %r402
  %r405 = inttoptr i64 %r404 to ptr
  %r406 = load double, ptr %r405, align 8
  br label %pic.merge.89

pic.desc.classify.81:                             ; preds = %pic.recv_hdr.90
  %r362 = and i1 %r352, %r359
  br i1 %r362, label %pic.desc.prefix.guard.82, label %pic.miss.cold.87

pic.desc.prefix.guard.82:                         ; preds = %pic.desc.classify.81
  %r407 = getelementptr i64, ptr %r358, i64 2
  %r408 = load i64, ptr %r407, align 8
  %r409 = icmp ne i64 %r408, 0
  br i1 %r409, label %pic.desc.prefix.meta.83, label %pic.miss.cold.87

pic.desc.prefix.meta.83:                          ; preds = %pic.desc.prefix.guard.82
  %r410 = add nuw nsw i64 %r338, 8
  %r411 = inttoptr i64 %r410 to ptr
  %r412 = load i64, ptr %r411, align 8
  %r413 = icmp ne i64 %r412, 0
  br i1 %r413, label %pic.desc.prefix.token.84, label %pic.miss.cold.87

pic.desc.prefix.token.84:                         ; preds = %pic.desc.prefix.meta.83
  %r414 = inttoptr i64 %r412 to ptr
  %r415 = getelementptr i64, ptr %r414, i64 6
  %r416 = load i64, ptr %r415, align 8
  %r417 = icmp eq i64 %r416, %r408
  br i1 %r417, label %pic.desc.prefix.hit.85, label %pic.miss.cold.87

pic.desc.prefix.hit.85:                           ; preds = %pic.desc.prefix.token.84
  %r418 = getelementptr i64, ptr %r358, i64 1
  %r419 = load i64, ptr %r418, align 8
  %r420 = shl i64 %r419, 3
  %r421 = add nuw nsw i64 %r338, 16
  %r422 = add i64 %r421, %r420
  %r423 = inttoptr i64 %r422 to ptr
  %r424 = load double, ptr %r423, align 8
  br label %pic.merge.89

pic.miss.86:                                      ; preds = %pic.hit.inline.93, %pic.prefix.token.79, %pic.prefix.meta.78, %pic.prefix.guard.77
  %r425 = getelementptr i64, ptr %r358, i64 3
  %r426 = load i64, ptr %r425, align 8
  %r427 = icmp sgt i64 %r426, 0
  br i1 %r427, label %pic.ways.94, label %pic.miss.call.88

pic.miss.cold.87:                                 ; preds = %pic.desc.prefix.token.84, %pic.desc.prefix.meta.83, %pic.desc.prefix.guard.82, %pic.desc.classify.81, %pget.recv_ok.69
  br label %pic.miss.call.88

pic.miss.call.88:                                 ; preds = %pic.way.load.95, %pic.ways.94, %pic.miss.cold.87, %pic.miss.86
  %r466 = load double, ptr @test_json_string_emitters_ts_.str.3.handle, align 8
  %r467 = bitcast double %r466 to i64
  %r468 = and i64 %r467, 281474976710655
  %statepoint_token53 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r338, i64 %r468, ptr @perry_ic_test_json_string_emitters_ts__9, i32 0, i32 0)
  %r46954 = call double @llvm.experimental.gc.result.f64(token %statepoint_token53)
  br label %pic.merge.89

pic.merge.89:                                     ; preds = %pic.way.live.96, %pic.hit.overflow.92, %pic.miss.call.88, %pic.desc.prefix.hit.85, %pic.prefix.hit.80, %pic.hit.live.76
  %r470 = phi double [ %r386, %pic.hit.live.76 ], [ %r38156, %pic.hit.overflow.92 ], [ %r406, %pic.prefix.hit.80 ], [ %r424, %pic.desc.prefix.hit.85 ], [ %r463, %pic.way.live.96 ], [ %r46954, %pic.miss.call.88 ]
  br label %pget.recv_merge.72

pic.recv_hdr.90:                                  ; preds = %pget.recv_ok.69
  %r349 = sub nuw nsw i64 %r338, 8
  %r350 = inttoptr i64 %r349 to ptr
  %r351 = load i8, ptr %r350, align 1
  %r352 = icmp eq i8 %r351, 2
  %r353 = sub nuw nsw i64 %r338, 6
  %r354 = inttoptr i64 %r353 to ptr
  %r355 = load i16, ptr %r354, align 2
  %r356 = and i16 %r355, 2048
  %r357 = icmp eq i16 %r356, 0
  %r358 = load ptr, ptr @perry_ic_test_json_string_emitters_ts__9, align 8
  %r359 = icmp ne ptr %r358, null
  %r360 = and i1 %r352, %r357
  %r361 = and i1 %r360, %r359
  br i1 %r361, label %pic.token.91, label %pic.desc.classify.81

pic.token.91:                                     ; preds = %pic.recv_hdr.90
  %r363 = add nuw nsw i64 %r338, 4
  %r364 = inttoptr i64 %r363 to ptr
  %r365 = load i32, ptr %r364, align 4
  %r366 = zext i32 %r365 to i64
  %r367 = or i64 %r366, 4611686018427387904
  %r368 = icmp ne i32 %r365, 0
  %r369 = getelementptr i64, ptr %r358, i64 0
  %r370 = load i64, ptr %r369, align 8
  %r371 = icmp eq i64 %r367, %r370
  %r372 = and i1 %r371, %r368
  br i1 %r372, label %pic.hit.75, label %pic.prefix.guard.77

pic.hit.overflow.92:                              ; preds = %pic.hit.75
  %r377 = load double, ptr @test_json_string_emitters_ts_.str.3.handle, align 8
  %r378 = bitcast double %r377 to i64
  %r379 = and i64 %r378, 281474976710655
  %r380 = trunc i64 %r374 to i32
  %statepoint_token55 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r338, i64 %r379, i32 %r380, ptr @perry_ic_test_json_string_emitters_ts__9, i32 0, i32 0)
  %r38156 = call double @llvm.experimental.gc.result.f64(token %statepoint_token55)
  br label %pic.merge.89

pic.hit.inline.93:                                ; preds = %pic.hit.75
  %r382 = shl i64 %r374, 3
  %r383 = add nuw nsw i64 %r338, 16
  %r384 = add i64 %r383, %r382
  %r385 = inttoptr i64 %r384 to ptr
  %r386 = load double, ptr %r385, align 8
  %r387 = bitcast double %r386 to i64
  %r388 = icmp eq i64 %r387, 9222246136947933200
  br i1 %r388, label %pic.miss.86, label %pic.hit.live.76

pic.ways.94:                                      ; preds = %pic.miss.86
  %r428 = getelementptr i64, ptr %r358, i64 4
  %r429 = load i64, ptr %r428, align 8
  %r430 = icmp eq i64 %r429, %r367
  %r431 = getelementptr i64, ptr %r358, i64 5
  %r432 = load i64, ptr %r431, align 8
  %r433 = select i1 %r430, i64 %r432, i64 0
  %r434 = getelementptr i64, ptr %r358, i64 6
  %r435 = load i64, ptr %r434, align 8
  %r436 = icmp eq i64 %r435, %r367
  %r437 = getelementptr i64, ptr %r358, i64 7
  %r438 = load i64, ptr %r437, align 8
  %r439 = select i1 %r436, i64 %r438, i64 0
  %r440 = getelementptr i64, ptr %r358, i64 8
  %r441 = load i64, ptr %r440, align 8
  %r442 = icmp eq i64 %r441, %r367
  %r443 = getelementptr i64, ptr %r358, i64 9
  %r444 = load i64, ptr %r443, align 8
  %r445 = select i1 %r442, i64 %r444, i64 0
  %r446 = getelementptr i64, ptr %r358, i64 10
  %r447 = load i64, ptr %r446, align 8
  %r448 = icmp eq i64 %r447, %r367
  %r449 = getelementptr i64, ptr %r358, i64 11
  %r450 = load i64, ptr %r449, align 8
  %r451 = select i1 %r448, i64 %r450, i64 0
  %r452 = or i1 %r430, %r436
  %r453 = select i1 %r430, i64 %r433, i64 %r439
  %r454 = or i1 %r442, %r448
  %r455 = select i1 %r442, i64 %r445, i64 %r451
  %r456 = or i1 %r452, %r454
  %r457 = select i1 %r452, i64 %r453, i64 %r455
  %r458 = and i1 %r368, %r456
  br i1 %r458, label %pic.way.load.95, label %pic.miss.call.88

pic.way.load.95:                                  ; preds = %pic.ways.94
  %r459 = shl i64 %r457, 3
  %r460 = add nuw nsw i64 %r338, 16
  %r461 = add i64 %r460, %r459
  %r462 = inttoptr i64 %r461 to ptr
  %r463 = load double, ptr %r462, align 8
  %r464 = bitcast double %r463 to i64
  %r465 = icmp eq i64 %r464, 9222246136947933200
  br i1 %r465, label %pic.miss.call.88, label %pic.way.live.96

pic.way.live.96:                                  ; preds = %pic.way.load.95
  br label %pic.merge.89

pget.throw_nullish.97:                            ; preds = %pget.recv_bad.70
  %r474 = zext i1 %r472 to i32
  %statepoint_token57 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r474, ptr @test_json_string_emitters_ts_.str.3.bytes, i64 2, i32 0, i32 0)
  unreachable

pget.recv_undef_return.98:                        ; preds = %pget.recv_bad.70
  %r475 = load double, ptr @test_json_string_emitters_ts_.str.3.handle, align 8
  %r476 = bitcast double %r475 to i64
  %r477 = and i64 %r476, 281474976710655
  %statepoint_token58 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r337, i64 %r477, i32 0, i32 0)
  %r47859 = call double @llvm.experimental.gc.result.f64(token %statepoint_token58)
  br label %pget.recv_merge.72

shadow.root.barrier.99:                           ; preds = %pget.recv_merge.72
  call void @js_write_barrier_root_nanbox(i64 %r497) #9
  br label %shadow.root.barrier.done.100

shadow.root.barrier.done.100:                     ; preds = %shadow.root.barrier.99, %pget.recv_merge.72
  %r500.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r500.rs4o = call i64 asm "", "=r,0"(i64 %r500.rs4i) #9
  %r500 = bitcast i64 %r500.rs4o to double
  %r501 = bitcast double %r500 to i64
  %r502 = and i64 %r501, 281474976710655
  %r503 = lshr i64 %r501, 48
  %r504 = and i64 %r503, 65533
  %r505 = icmp eq i64 %r504, 32765
  br i1 %r505, label %pget.recv_ok.102, label %pget.recv_other.106

pget.recv_sso.101:                                ; preds = %pget.recv_other.106
  %r643 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r644 = bitcast double %r643 to i64
  %r645 = and i64 %r644, 281474976710655
  %statepoint_token60 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r501, i64 %r645, i32 0, i32 0)
  %r64661 = call double @llvm.experimental.gc.result.f64(token %statepoint_token60)
  br label %pget.recv_merge.105

pget.recv_ok.102:                                 ; preds = %shadow.root.barrier.done.100
  %r512 = icmp ugt i64 %r502, 1048575
  br i1 %r512, label %pic.recv_hdr.123, label %pic.miss.cold.120

pget.recv_bad.103:                                ; preds = %pget.check_class_ref.107
  %r635 = icmp eq i64 %r501, 9222246136947933185
  %r636 = icmp eq i64 %r501, 9222246136947933186
  %r637 = or i1 %r635, %r636
  br i1 %r637, label %pget.throw_nullish.130, label %pget.recv_undef_return.131

pget.recv_class_ref.104:                          ; preds = %pget.check_class_ref.107
  %r508 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r509 = bitcast double %r508 to i64
  %r510 = and i64 %r509, 281474976710655
  %statepoint_token62 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6553530643794362378, i64 %r501, i64 %r510, i32 0, i32 0)
  %r51163 = call double @llvm.experimental.gc.result.f64(token %statepoint_token62)
  br label %pget.recv_merge.105

pget.recv_merge.105:                              ; preds = %pget.recv_undef_return.131, %pic.merge.122, %pget.recv_class_ref.104, %pget.recv_sso.101
  %r647 = phi double [ %r634, %pic.merge.122 ], [ %r64270, %pget.recv_undef_return.131 ], [ %r64661, %pget.recv_sso.101 ], [ %r51163, %pget.recv_class_ref.104 ]
  ret double %r647

pget.recv_other.106:                              ; preds = %shadow.root.barrier.done.100
  %r506 = icmp eq i64 %r503, 32761
  br i1 %r506, label %pget.recv_sso.101, label %pget.check_class_ref.107

pget.check_class_ref.107:                         ; preds = %pget.recv_other.106
  %r507 = icmp eq i64 %r503, 32766
  br i1 %r507, label %pget.recv_class_ref.104, label %pget.recv_bad.103

pic.hit.108:                                      ; preds = %pic.token.124
  %r537 = getelementptr i64, ptr %r522, i64 1
  %r538 = load i64, ptr %r537, align 8
  %r539 = and i64 %r538, 1073741824
  %r540 = icmp ne i64 %r539, 0
  br i1 %r540, label %pic.hit.overflow.125, label %pic.hit.inline.126

pic.hit.live.109:                                 ; preds = %pic.hit.inline.126
  br label %pic.merge.122

pic.prefix.guard.110:                             ; preds = %pic.token.124
  %r553 = getelementptr i64, ptr %r522, i64 2
  %r554 = load i64, ptr %r553, align 8
  %r555 = icmp ne i64 %r554, 0
  br i1 %r555, label %pic.prefix.meta.111, label %pic.miss.119

pic.prefix.meta.111:                              ; preds = %pic.prefix.guard.110
  %r556 = add nuw nsw i64 %r502, 8
  %r557 = inttoptr i64 %r556 to ptr
  %r558 = load i64, ptr %r557, align 8
  %r559 = icmp ne i64 %r558, 0
  br i1 %r559, label %pic.prefix.token.112, label %pic.miss.119

pic.prefix.token.112:                             ; preds = %pic.prefix.meta.111
  %r560 = inttoptr i64 %r558 to ptr
  %r561 = getelementptr i64, ptr %r560, i64 6
  %r562 = load i64, ptr %r561, align 8
  %r563 = icmp eq i64 %r562, %r554
  br i1 %r563, label %pic.prefix.hit.113, label %pic.miss.119

pic.prefix.hit.113:                               ; preds = %pic.prefix.token.112
  %r564 = getelementptr i64, ptr %r522, i64 1
  %r565 = load i64, ptr %r564, align 8
  %r566 = shl i64 %r565, 3
  %r567 = add nuw nsw i64 %r502, 16
  %r568 = add i64 %r567, %r566
  %r569 = inttoptr i64 %r568 to ptr
  %r570 = load double, ptr %r569, align 8
  br label %pic.merge.122

pic.desc.classify.114:                            ; preds = %pic.recv_hdr.123
  %r526 = and i1 %r516, %r523
  br i1 %r526, label %pic.desc.prefix.guard.115, label %pic.miss.cold.120

pic.desc.prefix.guard.115:                        ; preds = %pic.desc.classify.114
  %r571 = getelementptr i64, ptr %r522, i64 2
  %r572 = load i64, ptr %r571, align 8
  %r573 = icmp ne i64 %r572, 0
  br i1 %r573, label %pic.desc.prefix.meta.116, label %pic.miss.cold.120

pic.desc.prefix.meta.116:                         ; preds = %pic.desc.prefix.guard.115
  %r574 = add nuw nsw i64 %r502, 8
  %r575 = inttoptr i64 %r574 to ptr
  %r576 = load i64, ptr %r575, align 8
  %r577 = icmp ne i64 %r576, 0
  br i1 %r577, label %pic.desc.prefix.token.117, label %pic.miss.cold.120

pic.desc.prefix.token.117:                        ; preds = %pic.desc.prefix.meta.116
  %r578 = inttoptr i64 %r576 to ptr
  %r579 = getelementptr i64, ptr %r578, i64 6
  %r580 = load i64, ptr %r579, align 8
  %r581 = icmp eq i64 %r580, %r572
  br i1 %r581, label %pic.desc.prefix.hit.118, label %pic.miss.cold.120

pic.desc.prefix.hit.118:                          ; preds = %pic.desc.prefix.token.117
  %r582 = getelementptr i64, ptr %r522, i64 1
  %r583 = load i64, ptr %r582, align 8
  %r584 = shl i64 %r583, 3
  %r585 = add nuw nsw i64 %r502, 16
  %r586 = add i64 %r585, %r584
  %r587 = inttoptr i64 %r586 to ptr
  %r588 = load double, ptr %r587, align 8
  br label %pic.merge.122

pic.miss.119:                                     ; preds = %pic.hit.inline.126, %pic.prefix.token.112, %pic.prefix.meta.111, %pic.prefix.guard.110
  %r589 = getelementptr i64, ptr %r522, i64 3
  %r590 = load i64, ptr %r589, align 8
  %r591 = icmp sgt i64 %r590, 0
  br i1 %r591, label %pic.ways.127, label %pic.miss.call.121

pic.miss.cold.120:                                ; preds = %pic.desc.prefix.token.117, %pic.desc.prefix.meta.116, %pic.desc.prefix.guard.115, %pic.desc.classify.114, %pget.recv_ok.102
  br label %pic.miss.call.121

pic.miss.call.121:                                ; preds = %pic.way.load.128, %pic.ways.127, %pic.miss.cold.120, %pic.miss.119
  %r630 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r631 = bitcast double %r630 to i64
  %r632 = and i64 %r631, 281474976710655
  %statepoint_token64 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r502, i64 %r632, ptr @perry_ic_test_json_string_emitters_ts__11, i32 0, i32 0)
  %r63365 = call double @llvm.experimental.gc.result.f64(token %statepoint_token64)
  br label %pic.merge.122

pic.merge.122:                                    ; preds = %pic.way.live.129, %pic.hit.overflow.125, %pic.miss.call.121, %pic.desc.prefix.hit.118, %pic.prefix.hit.113, %pic.hit.live.109
  %r634 = phi double [ %r550, %pic.hit.live.109 ], [ %r54567, %pic.hit.overflow.125 ], [ %r570, %pic.prefix.hit.113 ], [ %r588, %pic.desc.prefix.hit.118 ], [ %r627, %pic.way.live.129 ], [ %r63365, %pic.miss.call.121 ]
  br label %pget.recv_merge.105

pic.recv_hdr.123:                                 ; preds = %pget.recv_ok.102
  %r513 = sub nuw nsw i64 %r502, 8
  %r514 = inttoptr i64 %r513 to ptr
  %r515 = load i8, ptr %r514, align 1
  %r516 = icmp eq i8 %r515, 2
  %r517 = sub nuw nsw i64 %r502, 6
  %r518 = inttoptr i64 %r517 to ptr
  %r519 = load i16, ptr %r518, align 2
  %r520 = and i16 %r519, 2048
  %r521 = icmp eq i16 %r520, 0
  %r522 = load ptr, ptr @perry_ic_test_json_string_emitters_ts__11, align 8
  %r523 = icmp ne ptr %r522, null
  %r524 = and i1 %r516, %r521
  %r525 = and i1 %r524, %r523
  br i1 %r525, label %pic.token.124, label %pic.desc.classify.114

pic.token.124:                                    ; preds = %pic.recv_hdr.123
  %r527 = add nuw nsw i64 %r502, 4
  %r528 = inttoptr i64 %r527 to ptr
  %r529 = load i32, ptr %r528, align 4
  %r530 = zext i32 %r529 to i64
  %r531 = or i64 %r530, 4611686018427387904
  %r532 = icmp ne i32 %r529, 0
  %r533 = getelementptr i64, ptr %r522, i64 0
  %r534 = load i64, ptr %r533, align 8
  %r535 = icmp eq i64 %r531, %r534
  %r536 = and i1 %r535, %r532
  br i1 %r536, label %pic.hit.108, label %pic.prefix.guard.110

pic.hit.overflow.125:                             ; preds = %pic.hit.108
  %r541 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r542 = bitcast double %r541 to i64
  %r543 = and i64 %r542, 281474976710655
  %r544 = trunc i64 %r538 to i32
  %statepoint_token66 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r502, i64 %r543, i32 %r544, ptr @perry_ic_test_json_string_emitters_ts__11, i32 0, i32 0)
  %r54567 = call double @llvm.experimental.gc.result.f64(token %statepoint_token66)
  br label %pic.merge.122

pic.hit.inline.126:                               ; preds = %pic.hit.108
  %r546 = shl i64 %r538, 3
  %r547 = add nuw nsw i64 %r502, 16
  %r548 = add i64 %r547, %r546
  %r549 = inttoptr i64 %r548 to ptr
  %r550 = load double, ptr %r549, align 8
  %r551 = bitcast double %r550 to i64
  %r552 = icmp eq i64 %r551, 9222246136947933200
  br i1 %r552, label %pic.miss.119, label %pic.hit.live.109

pic.ways.127:                                     ; preds = %pic.miss.119
  %r592 = getelementptr i64, ptr %r522, i64 4
  %r593 = load i64, ptr %r592, align 8
  %r594 = icmp eq i64 %r593, %r531
  %r595 = getelementptr i64, ptr %r522, i64 5
  %r596 = load i64, ptr %r595, align 8
  %r597 = select i1 %r594, i64 %r596, i64 0
  %r598 = getelementptr i64, ptr %r522, i64 6
  %r599 = load i64, ptr %r598, align 8
  %r600 = icmp eq i64 %r599, %r531
  %r601 = getelementptr i64, ptr %r522, i64 7
  %r602 = load i64, ptr %r601, align 8
  %r603 = select i1 %r600, i64 %r602, i64 0
  %r604 = getelementptr i64, ptr %r522, i64 8
  %r605 = load i64, ptr %r604, align 8
  %r606 = icmp eq i64 %r605, %r531
  %r607 = getelementptr i64, ptr %r522, i64 9
  %r608 = load i64, ptr %r607, align 8
  %r609 = select i1 %r606, i64 %r608, i64 0
  %r610 = getelementptr i64, ptr %r522, i64 10
  %r611 = load i64, ptr %r610, align 8
  %r612 = icmp eq i64 %r611, %r531
  %r613 = getelementptr i64, ptr %r522, i64 11
  %r614 = load i64, ptr %r613, align 8
  %r615 = select i1 %r612, i64 %r614, i64 0
  %r616 = or i1 %r594, %r600
  %r617 = select i1 %r594, i64 %r597, i64 %r603
  %r618 = or i1 %r606, %r612
  %r619 = select i1 %r606, i64 %r609, i64 %r615
  %r620 = or i1 %r616, %r618
  %r621 = select i1 %r616, i64 %r617, i64 %r619
  %r622 = and i1 %r532, %r620
  br i1 %r622, label %pic.way.load.128, label %pic.miss.call.121

pic.way.load.128:                                 ; preds = %pic.ways.127
  %r623 = shl i64 %r621, 3
  %r624 = add nuw nsw i64 %r502, 16
  %r625 = add i64 %r624, %r623
  %r626 = inttoptr i64 %r625 to ptr
  %r627 = load double, ptr %r626, align 8
  %r628 = bitcast double %r627 to i64
  %r629 = icmp eq i64 %r628, 9222246136947933200
  br i1 %r629, label %pic.miss.call.121, label %pic.way.live.129

pic.way.live.129:                                 ; preds = %pic.way.load.128
  br label %pic.merge.122

pget.throw_nullish.130:                           ; preds = %pget.recv_bad.103
  %r638 = zext i1 %r636 to i32
  %statepoint_token68 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r638, ptr @test_json_string_emitters_ts_.str.0.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.131:                       ; preds = %pget.recv_bad.103
  %r639 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r640 = bitcast double %r639 to i64
  %r641 = and i64 %r640, 281474976710655
  %statepoint_token69 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r501, i64 %r641, i32 0, i32 0)
  %r64270 = call double @llvm.experimental.gc.result.f64(token %statepoint_token69)
  br label %pget.recv_merge.105

streqlit.sso.132:                                 ; preds = %if.merge.12
  %r653 = icmp eq i64 %r650, 9221407709712050291
  br i1 %r653, label %streqlit.true.138, label %streqlit.tag.133

streqlit.tag.133:                                 ; preds = %streqlit.sso.132
  %r654 = lshr i64 %r650, 48
  %r655 = icmp eq i64 %r654, 32767
  %r656 = and i64 %r650, 281474976710655
  %r657 = icmp ugt i64 %r656, 4095
  %r658 = and i1 %r655, %r657
  br i1 %r658, label %streqlit.len.134, label %streqlit.false.139

streqlit.len.134:                                 ; preds = %streqlit.tag.133
  %r659 = inttoptr i64 %r656 to ptr
  %r660 = getelementptr inbounds nuw i8, ptr %r659, i64 4
  %r661 = load i32, ptr %r660, align 4
  %r662 = icmp eq i32 %r661, 5
  br i1 %r662, label %streqlit.b0.135, label %streqlit.false.139

streqlit.b0.135:                                  ; preds = %streqlit.len.134
  %r663 = getelementptr inbounds nuw i8, ptr %r659, i64 20
  %r664 = load i8, ptr %r663, align 1
  %r665 = icmp eq i8 %r664, 115
  br i1 %r665, label %streqlit.bl.136, label %streqlit.false.139

streqlit.bl.136:                                  ; preds = %streqlit.b0.135
  %r666 = getelementptr inbounds nuw i8, ptr %r659, i64 24
  %r667 = load i8, ptr %r666, align 1
  %r668 = icmp eq i8 %r667, 116
  br i1 %r668, label %streqlit.slow.137, label %streqlit.false.139

streqlit.slow.137:                                ; preds = %streqlit.bl.136
  %r669 = and i64 %r651, 281474976710655
  %statepoint_token71 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r656, i64 %r669, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0) ]
  %r67072 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token71)
  %rs4gc.s4.relocated73 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token71, i32 0, i32 0) ; (%.0, %.0)
  %r671 = icmp ne i32 %r67072, 0
  br label %streqlit.merge.140

streqlit.true.138:                                ; preds = %streqlit.sso.132, %if.merge.12
  br label %streqlit.merge.140

streqlit.false.139:                               ; preds = %streqlit.bl.136, %streqlit.b0.135, %streqlit.len.134, %streqlit.tag.133
  br label %streqlit.merge.140

streqlit.merge.140:                               ; preds = %streqlit.false.139, %streqlit.true.138, %streqlit.slow.137
  %.1 = phi ptr addrspace(1) [ %.0, %streqlit.true.138 ], [ %rs4gc.s4.relocated73, %streqlit.slow.137 ], [ %.0, %streqlit.false.139 ]
  %r672 = phi i1 [ true, %streqlit.true.138 ], [ false, %streqlit.false.139 ], [ %r671, %streqlit.slow.137 ]
  %r673 = select i1 %r672, i64 9222246136947933188, i64 9222246136947933187
  %r674 = bitcast i64 %r673 to double
  %r675 = icmp eq i64 %r673, 9222246136947933188
  br i1 %r675, label %if.then.141, label %if.else.142

if.then.141:                                      ; preds = %streqlit.merge.140
  %r676 = load double, ptr @test_json_string_emitters_ts_.str.6.handle, align 8
  ret double %r676

if.else.142:                                      ; preds = %streqlit.merge.140
  br label %if.merge.143

if.merge.143:                                     ; preds = %if.else.142
  %r677.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r677.rs4o = call i64 asm "", "=r,0"(i64 %r677.rs4i) #9
  %r677 = bitcast i64 %r677.rs4o to double
  ret double %r677
}

; Function Attrs: noinline optsize
define double @perry_fn_test_json_string_emitters_ts__allocateString(double %arg8, double %arg9) #8 {
entry.0:
  %r1 = call i32 @js_typed_string_arg_guard(double %arg8)
  %r2 = icmp ne i32 %r1, 0
  br i1 %r2, label %spec_public.fast.1, label %spec_public.fallback.2

spec_public.fast.1:                               ; preds = %entry.0
  %r3 = call double @"perry_fn_test_json_string_emitters_ts__allocateString$spec_b_b"(double %arg8, double %arg9)
  ret double %r3

spec_public.fallback.2:                           ; preds = %entry.0
  %r4 = call double @"perry_fn_test_json_string_emitters_ts__allocateString$generic"(double %arg8, double %arg9)
  ret double %r4
}

; Function Attrs: optsize
define double @test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c_constructor(double %this_arg, double %arg12, double %arg13) #6 gc "statepoint-example" {
entry.0:
  %r8 = load i32, ptr @perry_class_shape_id_test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c, align 4
  %rs4gc.b1 = bitcast double %this_arg to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg12 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %rs4gc.b3 = bitcast double %arg13 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r5.rs4o = call i64 asm "", "=r,0"(i64 %r5.rs4i) #9
  %r5 = bitcast i64 %r5.rs4o to double
  %r6.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r6.rs4o = call i64 asm "", "=r,0"(i64 %r6.rs4i) #9
  %r6 = bitcast i64 %r6.rs4o to double
  %r10 = bitcast double %r5 to i64
  %r11 = and i64 %r10, 281474976710655
  %r12 = load double, ptr @test_json_string_emitters_ts_.str.3.handle, align 8
  %r13 = bitcast double %r12 to i64
  %r14 = and i64 %r13, 281474976710655
  %r15 = bitcast double %r6 to i64
  %r16 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r17 = icmp eq i8 %r16, 0
  %r18 = lshr i64 %r10, 48
  %r19 = icmp eq i64 %r18, 32765
  %r20 = icmp ugt i64 %r11, 1048575
  %r21 = and i1 %r19, %r20
  %r22 = and i1 %r21, %r17
  br i1 %r22, label %class_field_inline.deref.5, label %class_field_inline.guardcall.6

standalone.ctor.return.after.1:                   ; preds = %class_field_set.merge.9
  ret double 0x7FFC000000000001

class_field_set.fast.2:                           ; preds = %class_field_inline.guardcall.6, %class_field_inline.deref.5
  %r187.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r187.rs4o = call i64 asm "", "=r,0"(i64 %r187.rs4i) #9
  %r187 = bitcast i64 %r187.rs4o to double
  %r188 = bitcast double %r187 to i64
  %r189 = and i64 %r188, 281474976710655
  %r59 = inttoptr i64 %r189 to ptr
  %r183.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r183.rs4o = call i64 asm "", "=r,0"(i64 %r183.rs4i) #9
  %r183 = bitcast i64 %r183.rs4o to double
  %r184 = bitcast double %r183 to i64
  %r185 = and i64 %r184, 281474976710655
  %r186 = inttoptr i64 %r185 to ptr
  %r60 = getelementptr i8, ptr %r186, i64 16
  %r61 = getelementptr double, ptr %r60, i64 0
  %r182.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r182.rs4o = call i64 asm "", "=r,0"(i64 %r182.rs4i) #9
  %r182 = bitcast i64 %r182.rs4o to double
  %r62 = call double @js_array_numeric_value_to_raw_f64(double %r182) #9
  store double %r62, ptr %r61, align 8
  br label %class_field_set.merge.4

class_field_set.fallback.3:                       ; preds = %class_field_inline.guardcall.6
  %r176.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r176.rs4o = call i64 asm "", "=r,0"(i64 %r176.rs4i) #9
  %r176 = bitcast i64 %r176.rs4o to double
  %r177 = bitcast double %r176 to i64
  %r178.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r178.rs4o = call i64 asm "", "=r,0"(i64 %r178.rs4i) #9
  %r178 = bitcast i64 %r178.rs4o to double
  %r179 = load double, ptr @test_json_string_emitters_ts_.str.3.handle, align 8
  %r180 = bitcast double %r179 to i64
  %r181 = and i64 %r180, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6553530643794362380, i64 %r177, i64 %r181, double %r178, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3, ptr addrspace(1) %rs4gc.s1) ]
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s3, %rs4gc.s3)
  %rs4gc.s1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%rs4gc.s1, %rs4gc.s1)
  br label %class_field_set.merge.4

class_field_set.merge.4:                          ; preds = %class_field_set.fallback.3, %class_field_set.fast.2
  %.02 = phi ptr addrspace(1) [ %rs4gc.s1, %class_field_set.fast.2 ], [ %rs4gc.s1.relocated, %class_field_set.fallback.3 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s3, %class_field_set.fast.2 ], [ %rs4gc.s3.relocated, %class_field_set.fallback.3 ]
  %r63.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r63.rs4o = call i64 asm "", "=r,0"(i64 %r63.rs4i) #9
  %r63 = bitcast i64 %r63.rs4o to double
  %r64.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r64.rs4o = call i64 asm "", "=r,0"(i64 %r64.rs4i) #9
  %r64 = bitcast i64 %r64.rs4o to double
  %r66 = bitcast double %r63 to i64
  %r67 = and i64 %r66, 281474976710655
  %r68 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r69 = bitcast double %r68 to i64
  %r70 = and i64 %r69, 281474976710655
  %r71 = bitcast double %r64 to i64
  %r72 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r73 = icmp eq i8 %r72, 0
  %r74 = lshr i64 %r66, 48
  %r75 = icmp eq i64 %r74, 32765
  %r76 = icmp ugt i64 %r67, 1048575
  %r77 = and i1 %r75, %r76
  %r78 = and i1 %r77, %r73
  br i1 %r78, label %class_field_inline.deref.10, label %class_field_inline.guardcall.11

class_field_inline.deref.5:                       ; preds = %entry.0
  %r23 = inttoptr i64 %r11 to ptr
  %r24 = getelementptr i8, ptr %r23, i64 -8
  %r25 = load i8, ptr %r24, align 1
  %r26 = icmp eq i8 %r25, 2
  %r27 = getelementptr i8, ptr %r23, i64 -7
  %r28 = load i8, ptr %r27, align 1
  %r29 = and i8 %r28, -128
  %r30 = icmp eq i8 %r29, 0
  %r31 = getelementptr i8, ptr %r23, i64 -6
  %r32 = load i16, ptr %r31, align 2
  %r33 = getelementptr i8, ptr %r23, i64 0
  %r34 = load i32, ptr %r33, align 4
  %r35 = icmp eq i32 %r34, 1
  %r36 = getelementptr i8, ptr %r23, i64 4
  %r37 = load i32, ptr %r36, align 4
  %r38 = icmp eq i32 %r37, %r8
  %r39 = and i1 %r26, %r30
  %r40 = and i1 %r39, %r35
  %r41 = and i1 %r40, %r38
  %r42 = and i16 %r32, 3072
  %r43 = icmp eq i16 %r42, 0
  %r44 = and i1 %r41, %r43
  %r45 = and i16 %r32, 4096
  %r46 = icmp ne i16 %r45, 0
  %r47 = and i1 %r44, %r46
  %r48 = and i16 %r32, 1
  %r49 = icmp eq i16 %r48, 0
  %r50 = and i1 %r47, %r49
  %r51 = and i16 %r32, 128
  %r52 = icmp eq i16 %r51, 0
  %r53 = and i1 %r50, %r52
  %r54 = and i64 %r15, 9218868437227405312
  %r55 = icmp ne i64 %r54, 9218868437227405312
  %r56 = and i1 %r53, %r55
  br i1 %r56, label %class_field_set.fast.2, label %class_field_inline.guardcall.6

class_field_inline.guardcall.6:                   ; preds = %class_field_inline.deref.5, %entry.0
  %r57 = call i32 @js_typed_feedback_class_field_set_guard(i64 6553530643794362380, double %r5, i32 1, i32 %r8, i64 %r14, i32 0, double %r6, i32 1) #9
  %r58 = icmp ne i32 %r57, 0
  br i1 %r58, label %class_field_set.fast.2, label %class_field_set.fallback.3

class_field_set.fast.7:                           ; preds = %class_field_inline.guardcall.11, %class_field_inline.deref.10
  %r173.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r173.rs4o = call i64 asm "", "=r,0"(i64 %r173.rs4i) #9
  %r173 = bitcast i64 %r173.rs4o to double
  %r174 = bitcast double %r173 to i64
  %r175 = and i64 %r174, 281474976710655
  %r109 = inttoptr i64 %r175 to ptr
  %r169.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r169.rs4o = call i64 asm "", "=r,0"(i64 %r169.rs4i) #9
  %r169 = bitcast i64 %r169.rs4o to double
  %r170 = bitcast double %r169 to i64
  %r171 = and i64 %r170, 281474976710655
  %r172 = inttoptr i64 %r171 to ptr
  %r110 = getelementptr i8, ptr %r172, i64 16
  %r111 = getelementptr double, ptr %r110, i64 1
  %r112 = ptrtoint ptr %r111 to i64
  %r168.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r168.rs4o = call i64 asm "", "=r,0"(i64 %r168.rs4i) #9
  %r168 = bitcast i64 %r168.rs4o to double
  store double %r168, ptr %r111, align 8
  %r167.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r167.rs4o = call i64 asm "", "=r,0"(i64 %r167.rs4i) #9
  %r167 = bitcast i64 %r167.rs4o to double
  %r113 = bitcast double %r167 to i64
  %r165.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r165.rs4o = call i64 asm "", "=r,0"(i64 %r165.rs4i) #9
  %r165 = bitcast i64 %r165.rs4o to double
  %r166 = bitcast double %r165 to i64
  %r114 = lshr i64 %r166, 48
  %r115 = icmp eq i64 %r114, 0
  %r163.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r163.rs4o = call i64 asm "", "=r,0"(i64 %r163.rs4i) #9
  %r163 = bitcast i64 %r163.rs4o to double
  %r164 = bitcast double %r163 to i64
  %r116 = icmp uge i64 %r164, 4096
  %r117 = and i1 %r115, %r116
  %r118 = icmp eq i64 %r114, 32765
  %r119 = icmp eq i64 %r114, 32767
  %r120 = icmp eq i64 %r114, 32762
  %r121 = or i1 %r118, %r119
  %r122 = or i1 %r121, %r120
  %r123 = or i1 %r122, %r117
  br i1 %r123, label %class_field_set.gc_bookkeeping.12, label %class_field_set.gc_bookkeeping.done.13

class_field_set.fallback.8:                       ; preds = %class_field_inline.guardcall.11
  %r157.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r157.rs4o = call i64 asm "", "=r,0"(i64 %r157.rs4i) #9
  %r157 = bitcast i64 %r157.rs4o to double
  %r158 = bitcast double %r157 to i64
  %r159.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r159.rs4o = call i64 asm "", "=r,0"(i64 %r159.rs4i) #9
  %r159 = bitcast i64 %r159.rs4o to double
  %r160 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r161 = bitcast double %r160 to i64
  %r162 = and i64 %r161, 281474976710655
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6553530643794362381, i64 %r158, i64 %r162, double %r159, i32 0, i32 0)
  br label %class_field_set.merge.9

class_field_set.merge.9:                          ; preds = %class_field_set.gc_bookkeeping.done.13, %class_field_set.fallback.8
  br label %standalone.ctor.return.after.1

class_field_inline.deref.10:                      ; preds = %class_field_set.merge.4
  %r79 = inttoptr i64 %r67 to ptr
  %r80 = getelementptr i8, ptr %r79, i64 -8
  %r81 = load i8, ptr %r80, align 1
  %r82 = icmp eq i8 %r81, 2
  %r83 = getelementptr i8, ptr %r79, i64 -7
  %r84 = load i8, ptr %r83, align 1
  %r85 = and i8 %r84, -128
  %r86 = icmp eq i8 %r85, 0
  %r87 = getelementptr i8, ptr %r79, i64 -6
  %r88 = load i16, ptr %r87, align 2
  %r89 = getelementptr i8, ptr %r79, i64 0
  %r90 = load i32, ptr %r89, align 4
  %r91 = icmp eq i32 %r90, 1
  %r92 = getelementptr i8, ptr %r79, i64 4
  %r93 = load i32, ptr %r92, align 4
  %r94 = icmp eq i32 %r93, %r8
  %r95 = and i1 %r82, %r86
  %r96 = and i1 %r95, %r91
  %r97 = and i1 %r96, %r94
  %r98 = and i16 %r88, 3072
  %r99 = icmp eq i16 %r98, 0
  %r100 = and i1 %r97, %r99
  %r101 = and i16 %r88, 1
  %r102 = icmp eq i16 %r101, 0
  %r103 = and i1 %r100, %r102
  %r104 = and i16 %r88, 128
  %r105 = icmp eq i16 %r104, 0
  %r106 = and i1 %r103, %r105
  br i1 %r106, label %class_field_set.fast.7, label %class_field_inline.guardcall.11

class_field_inline.guardcall.11:                  ; preds = %class_field_inline.deref.10, %class_field_set.merge.4
  %r107 = call i32 @js_typed_feedback_class_field_set_guard(i64 6553530643794362381, double %r63, i32 1, i32 %r8, i64 %r70, i32 1, double %r64, i32 0) #9
  %r108 = icmp ne i32 %r107, 0
  br i1 %r108, label %class_field_set.fast.7, label %class_field_set.fallback.8

class_field_set.gc_bookkeeping.12:                ; preds = %class_field_set.fast.7
  %r156.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r156.rs4o = call i64 asm "", "=r,0"(i64 %r156.rs4i) #9
  %r156 = bitcast i64 %r156.rs4o to double
  call void @js_string_addref_if_heap_string(double %r156) #9
  %r153.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r153.rs4o = call i64 asm "", "=r,0"(i64 %r153.rs4i) #9
  %r153 = bitcast i64 %r153.rs4o to double
  %r154 = bitcast double %r153 to i64
  %r155 = and i64 %r154, 281474976710655
  %r124 = inttoptr i64 %r155 to ptr
  %r149.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r149.rs4o = call i64 asm "", "=r,0"(i64 %r149.rs4i) #9
  %r149 = bitcast i64 %r149.rs4o to double
  %r150 = bitcast double %r149 to i64
  %r151 = and i64 %r150, 281474976710655
  %r152 = inttoptr i64 %r151 to ptr
  %r125 = getelementptr i8, ptr %r152, i64 -6
  %r126 = load i16, ptr %r125, align 2
  %r127 = and i16 %r126, -12288
  %r128 = icmp eq i16 %r127, -28672
  br i1 %r128, label %class_field_set.layout_note.done.15, label %class_field_set.layout_note.14

class_field_set.gc_bookkeeping.done.13:           ; preds = %class_field_set.barrier.16, %class_field_set.layout_note.done.15, %class_field_set.fast.7
  br label %class_field_set.merge.9

class_field_set.layout_note.14:                   ; preds = %class_field_set.gc_bookkeeping.12
  %r144.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r144.rs4o = call i64 asm "", "=r,0"(i64 %r144.rs4i) #9
  %r144 = bitcast i64 %r144.rs4o to double
  %r145 = bitcast double %r144 to i64
  %r146 = and i64 %r145, 281474976710655
  %r147.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r147.rs4o = call i64 asm "", "=r,0"(i64 %r147.rs4i) #9
  %r147 = bitcast i64 %r147.rs4o to double
  %r148 = bitcast double %r147 to i64
  call void @js_gc_note_slot_layout(i64 %r146, i32 1, i64 %r148) #9
  br label %class_field_set.layout_note.done.15

class_field_set.layout_note.done.15:              ; preds = %class_field_set.layout_note.14, %class_field_set.gc_bookkeeping.12
  %r141.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r141.rs4o = call i64 asm "", "=r,0"(i64 %r141.rs4i) #9
  %r141 = bitcast i64 %r141.rs4o to double
  %r142 = bitcast double %r141 to i64
  %r143 = and i64 %r142, 281474976710655
  %r129 = sub nsw i64 %r143, 7
  %r130 = inttoptr i64 %r129 to ptr
  %r131 = load i8, ptr %r130, align 1
  %r132 = and i8 %r131, 32
  %r133 = icmp ne i8 %r132, 0
  %r134 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r135 = icmp ne i32 %r134, 0
  %r136 = or i1 %r133, %r135
  br i1 %r136, label %class_field_set.barrier.16, label %class_field_set.gc_bookkeeping.done.13

class_field_set.barrier.16:                       ; preds = %class_field_set.layout_note.done.15
  %r137.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r137.rs4o = call i64 asm "", "=r,0"(i64 %r137.rs4i) #9
  %r137 = bitcast i64 %r137.rs4o to double
  %r138 = bitcast double %r137 to i64
  %r139.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r139.rs4o = call i64 asm "", "=r,0"(i64 %r139.rs4i) #9
  %r139 = bitcast i64 %r139.rs4o to double
  %r140 = bitcast double %r139 to i64
  call void @js_write_barrier_slot(i64 %r138, i64 %r112, i64 %r140) #9
  br label %class_field_set.gc_bookkeeping.done.13
}

; Function Attrs: optsize
define double @__perry_wrap_perry_fn_test_json_string_emitters_ts__identity(i64 %this_closure, double %a0, double %a1) #6 {
entry.0:
  %r1 = call double @perry_fn_test_json_string_emitters_ts__identity(double %a0, double %a1)
  ret double %r1
}

; Function Attrs: optsize
define double @__perry_wrap_perry_fn_test_json_string_emitters_ts__allocateString(i64 %this_closure, double %a0, double %a1) #6 {
entry.0:
  %r1 = call double @perry_fn_test_json_string_emitters_ts__allocateString(double %a0, double %a1)
  ret double %r1
}

; Function Attrs: optsize
define internal double @__perry_wrap_perry_unknown_func_test_json_string_emitters_ts(i64 %this_closure, double %a0, double %a1, double %a2, double %a3, double %a4) #6 {
entry.0:
  ret double 0x7FFC000000000001
}

; Function Attrs: optsize
define void @test_json_string_emitters_ts__init() #6 {
entry.0:
  ret void
}

; Function Attrs: optsize
define i32 @main() #6 gc "statepoint-example" {
entry.0:
  %r288 = alloca [32 x double], align 8
  %r1155 = alloca [32 x double], align 8
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (ptr, i32)) @js_set_process_entry_path, i32 2, i32 0, ptr @test_json_string_emitters_ts_.str.0, i32 87, i32 0, i32 0)
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_init, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token2 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32)) @js_gc_write_barriers_emitted, i32 1, i32 0, i32 1, i32 0, i32 0)
  %statepoint_token3 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @perry_macos_bundle_chdir, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token4 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @__perry_init_strings_test_json_string_emitters_ts, i32 0, i32 0, i32 0, i32 0)
  %r543 = call ptr @perry_transition_cache_base() #9
  %r2 = load double, ptr @test_json_string_emitters_ts_.str.7.handle, align 8
  %r3 = load double, ptr @test_json_string_emitters_ts_.str.8.handle, align 8
  %r4 = load double, ptr @test_json_string_emitters_ts_.str.6.handle, align 8
  %r5 = load double, ptr @test_json_string_emitters_ts_.str.9.handle, align 8
  %r6 = load double, ptr @test_json_string_emitters_ts_.str.10.handle, align 8
  %r7 = load double, ptr @test_json_string_emitters_ts_.str.11.handle, align 8
  %r8 = load double, ptr @test_json_string_emitters_ts_.str.12.handle, align 8
  %r9 = load double, ptr @test_json_string_emitters_ts_.str.13.handle, align 8
  %r10 = load double, ptr @test_json_string_emitters_ts_.str.14.handle, align 8
  %r11 = bitcast double %r10 to i64
  %rs4gc.s9 = inttoptr i64 %r11 to ptr addrspace(1)
  %r13.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9 to i64
  %r13 = call i64 asm "", "=r,0"(i64 %r13.rs4i) #9
  %r14 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r15 = icmp ne i32 %r14, 0
  br i1 %r15, label %shadow.root.barrier.1, label %shadow.root.barrier.done.2

shadow.root.barrier.1:                            ; preds = %entry.0
  call void @js_write_barrier_root_nanbox(i64 %r13) #9
  br label %shadow.root.barrier.done.2

shadow.root.barrier.done.2:                       ; preds = %shadow.root.barrier.1, %entry.0
  %r16 = load double, ptr @test_json_string_emitters_ts_.str.15.handle, align 8
  %r17 = load double, ptr @test_json_string_emitters_ts_.str.16.handle, align 8
  %r18 = load double, ptr @test_json_string_emitters_ts_.str.7.handle, align 8
  %r19 = load double, ptr @test_json_string_emitters_ts_.str.8.handle, align 8
  %r20 = load double, ptr @test_json_string_emitters_ts_.str.6.handle, align 8
  %r21 = load double, ptr @test_json_string_emitters_ts_.str.9.handle, align 8
  %r22 = load double, ptr @test_json_string_emitters_ts_.str.10.handle, align 8
  %r23 = load double, ptr @test_json_string_emitters_ts_.str.11.handle, align 8
  %r24 = load double, ptr @test_json_string_emitters_ts_.str.12.handle, align 8
  %r25 = load double, ptr @test_json_string_emitters_ts_.str.13.handle, align 8
  %r26.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9 to i64
  %r26 = call i64 asm "", "=r,0"(i64 %r26.rs4i) #9
  %r27 = bitcast i64 %r26 to double
  br label %arena_state.init.3

arena_state.init.3:                               ; preds = %shadow.root.barrier.done.2
  %r31 = load atomic i64, ptr @PERRY_HOT_TSD_KEY monotonic, align 8
  %r32 = icmp ne i64 %r31, -1
  br i1 %r32, label %arena_state.hot_tls.tsd.5, label %arena_state.hot_tls.slow.7

arena_state.ready.4:                              ; preds = %arena_state.hot_tls.resolved.9
  %r47 = getelementptr i8, ptr %r45, i64 8
  %r48 = load i64, ptr %r47, align 8
  %r49 = add i64 %r48, 104
  %r50 = getelementptr i8, ptr %r45, i64 16
  %r51 = load i64, ptr %r50, align 8
  %r52 = icmp ule i64 %r49, %r51
  br i1 %r52, label %arrlit.fast.10, label %arrlit.slow.11

arena_state.hot_tls.tsd.5:                        ; preds = %arena_state.init.3
  %r33 = call i64 asm sideeffect "mrs $0, tpidrro_el0", "=r"() #9
  %r34 = and i64 %r33, -8
  %r35 = shl i64 %r31, 3
  %r36 = add i64 %r34, %r35
  %r37 = inttoptr i64 %r36 to ptr
  %r38 = load ptr, ptr %r37, align 8
  %r39 = icmp ne ptr %r38, null
  br i1 %r39, label %arena_state.hot_tls.fast.6, label %arena_state.hot_tls.slow.7

arena_state.hot_tls.fast.6:                       ; preds = %arena_state.hot_tls.tsd.5
  %r40 = getelementptr i8, ptr %r38, i64 8
  %r41 = load ptr, ptr %r40, align 8
  %r42 = load ptr, ptr %r41, align 8
  %r43 = icmp ne ptr %r42, null
  br i1 %r43, label %arena_state.hot_tls.ready.8, label %arena_state.hot_tls.slow.7

arena_state.hot_tls.slow.7:                       ; preds = %arena_state.hot_tls.fast.6, %arena_state.hot_tls.tsd.5, %arena_state.init.3
  %statepoint_token5 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr ()) @js_inline_arena_state, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s9) ]
  %r4410 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token5)
  %rs4gc.s9.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token5, i32 0, i32 0) ; (%rs4gc.s9, %rs4gc.s9)
  br label %arena_state.hot_tls.resolved.9

arena_state.hot_tls.ready.8:                      ; preds = %arena_state.hot_tls.fast.6
  br label %arena_state.hot_tls.resolved.9

arena_state.hot_tls.resolved.9:                   ; preds = %arena_state.hot_tls.ready.8, %arena_state.hot_tls.slow.7
  %.0 = phi ptr addrspace(1) [ %rs4gc.s9, %arena_state.hot_tls.ready.8 ], [ %rs4gc.s9.relocated, %arena_state.hot_tls.slow.7 ]
  %r45 = phi ptr [ %r41, %arena_state.hot_tls.ready.8 ], [ %r4410, %arena_state.hot_tls.slow.7 ]
  br label %arena_state.ready.4

arrlit.fast.10:                                   ; preds = %arena_state.ready.4
  store i64 %r49, ptr %r47, align 8
  %r53 = load ptr, ptr %r45, align 8
  %r54 = getelementptr i8, ptr %r53, i64 %r48
  br label %arrlit.merge.12

arrlit.slow.11:                                   ; preds = %arena_state.ready.4
  %statepoint_token11 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr (ptr, i64, i64)) @js_inline_arena_slow_alloc, i32 3, i32 0, ptr %r45, i64 104, i64 8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0) ]
  %r5512 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token11)
  %rs4gc.s9.relocated13 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token11, i32 0, i32 0) ; (%.0, %.0)
  br label %arrlit.merge.12

arrlit.merge.12:                                  ; preds = %arrlit.slow.11, %arrlit.fast.10
  %.1 = phi ptr addrspace(1) [ %.0, %arrlit.fast.10 ], [ %rs4gc.s9.relocated13, %arrlit.slow.11 ]
  %r56 = phi ptr [ %r54, %arrlit.fast.10 ], [ %r5512, %arrlit.slow.11 ]
  store i64 447750341121, ptr %r56, align 8
  %r57 = getelementptr i8, ptr %r56, i64 8
  store i64 47244640267, ptr %r57, align 8
  %r58 = getelementptr i8, ptr %r56, i64 8
  %r59 = ptrtoint ptr %r58 to i64
  %r60 = getelementptr inbounds nuw i8, ptr %r56, i64 16
  %r2776 = load double, ptr @test_json_string_emitters_ts_.str.7.handle, align 8
  store double %r2776, ptr %r60, align 8
  %r2775 = load double, ptr @test_json_string_emitters_ts_.str.7.handle, align 8
  call void @js_string_addref_if_heap_string(double %r2775) #9
  %r2774 = load double, ptr @test_json_string_emitters_ts_.str.7.handle, align 8
  %r61 = bitcast double %r2774 to i64
  %r2772 = load double, ptr @test_json_string_emitters_ts_.str.7.handle, align 8
  %r2773 = bitcast double %r2772 to i64
  call void @js_gc_note_slot_layout(i64 %r59, i32 0, i64 %r2773) #9
  %r62 = getelementptr inbounds nuw i8, ptr %r56, i64 24
  %r2771 = load double, ptr @test_json_string_emitters_ts_.str.8.handle, align 8
  store double %r2771, ptr %r62, align 8
  %r2770 = load double, ptr @test_json_string_emitters_ts_.str.8.handle, align 8
  call void @js_string_addref_if_heap_string(double %r2770) #9
  %r2769 = load double, ptr @test_json_string_emitters_ts_.str.8.handle, align 8
  %r63 = bitcast double %r2769 to i64
  %r2767 = load double, ptr @test_json_string_emitters_ts_.str.8.handle, align 8
  %r2768 = bitcast double %r2767 to i64
  call void @js_gc_note_slot_layout(i64 %r59, i32 1, i64 %r2768) #9
  %r64 = getelementptr inbounds nuw i8, ptr %r56, i64 32
  %r2766 = load double, ptr @test_json_string_emitters_ts_.str.6.handle, align 8
  store double %r2766, ptr %r64, align 8
  %r2765 = load double, ptr @test_json_string_emitters_ts_.str.6.handle, align 8
  call void @js_string_addref_if_heap_string(double %r2765) #9
  %r2764 = load double, ptr @test_json_string_emitters_ts_.str.6.handle, align 8
  %r65 = bitcast double %r2764 to i64
  %r2762 = load double, ptr @test_json_string_emitters_ts_.str.6.handle, align 8
  %r2763 = bitcast double %r2762 to i64
  call void @js_gc_note_slot_layout(i64 %r59, i32 2, i64 %r2763) #9
  %r66 = getelementptr inbounds nuw i8, ptr %r56, i64 40
  %r2761 = load double, ptr @test_json_string_emitters_ts_.str.9.handle, align 8
  store double %r2761, ptr %r66, align 8
  %r2760 = load double, ptr @test_json_string_emitters_ts_.str.9.handle, align 8
  call void @js_string_addref_if_heap_string(double %r2760) #9
  %r2759 = load double, ptr @test_json_string_emitters_ts_.str.9.handle, align 8
  %r67 = bitcast double %r2759 to i64
  %r2757 = load double, ptr @test_json_string_emitters_ts_.str.9.handle, align 8
  %r2758 = bitcast double %r2757 to i64
  call void @js_gc_note_slot_layout(i64 %r59, i32 3, i64 %r2758) #9
  %r68 = getelementptr inbounds nuw i8, ptr %r56, i64 48
  %r2756 = load double, ptr @test_json_string_emitters_ts_.str.10.handle, align 8
  store double %r2756, ptr %r68, align 8
  %r2755 = load double, ptr @test_json_string_emitters_ts_.str.10.handle, align 8
  call void @js_string_addref_if_heap_string(double %r2755) #9
  %r2754 = load double, ptr @test_json_string_emitters_ts_.str.10.handle, align 8
  %r69 = bitcast double %r2754 to i64
  %r2752 = load double, ptr @test_json_string_emitters_ts_.str.10.handle, align 8
  %r2753 = bitcast double %r2752 to i64
  call void @js_gc_note_slot_layout(i64 %r59, i32 4, i64 %r2753) #9
  %r70 = getelementptr inbounds nuw i8, ptr %r56, i64 56
  %r2751 = load double, ptr @test_json_string_emitters_ts_.str.11.handle, align 8
  store double %r2751, ptr %r70, align 8
  %r2750 = load double, ptr @test_json_string_emitters_ts_.str.11.handle, align 8
  call void @js_string_addref_if_heap_string(double %r2750) #9
  %r2749 = load double, ptr @test_json_string_emitters_ts_.str.11.handle, align 8
  %r71 = bitcast double %r2749 to i64
  %r2747 = load double, ptr @test_json_string_emitters_ts_.str.11.handle, align 8
  %r2748 = bitcast double %r2747 to i64
  call void @js_gc_note_slot_layout(i64 %r59, i32 5, i64 %r2748) #9
  %r72 = getelementptr inbounds nuw i8, ptr %r56, i64 64
  %r2746 = load double, ptr @test_json_string_emitters_ts_.str.12.handle, align 8
  store double %r2746, ptr %r72, align 8
  %r2745 = load double, ptr @test_json_string_emitters_ts_.str.12.handle, align 8
  call void @js_string_addref_if_heap_string(double %r2745) #9
  %r2744 = load double, ptr @test_json_string_emitters_ts_.str.12.handle, align 8
  %r73 = bitcast double %r2744 to i64
  %r2742 = load double, ptr @test_json_string_emitters_ts_.str.12.handle, align 8
  %r2743 = bitcast double %r2742 to i64
  call void @js_gc_note_slot_layout(i64 %r59, i32 6, i64 %r2743) #9
  %r74 = getelementptr inbounds nuw i8, ptr %r56, i64 72
  %r2741 = load double, ptr @test_json_string_emitters_ts_.str.13.handle, align 8
  store double %r2741, ptr %r74, align 8
  %r2740 = load double, ptr @test_json_string_emitters_ts_.str.13.handle, align 8
  call void @js_string_addref_if_heap_string(double %r2740) #9
  %r2739 = load double, ptr @test_json_string_emitters_ts_.str.13.handle, align 8
  %r75 = bitcast double %r2739 to i64
  %r2737 = load double, ptr @test_json_string_emitters_ts_.str.13.handle, align 8
  %r2738 = bitcast double %r2737 to i64
  call void @js_gc_note_slot_layout(i64 %r59, i32 7, i64 %r2738) #9
  %r76 = getelementptr inbounds nuw i8, ptr %r56, i64 80
  %r2735.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r2735 = call i64 asm "", "=r,0"(i64 %r2735.rs4i) #9
  %r2736 = bitcast i64 %r2735 to double
  store double %r2736, ptr %r76, align 8
  %r2733.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r2733 = call i64 asm "", "=r,0"(i64 %r2733.rs4i) #9
  %r2734 = bitcast i64 %r2733 to double
  call void @js_string_addref_if_heap_string(double %r2734) #9
  %r2731.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r2731 = call i64 asm "", "=r,0"(i64 %r2731.rs4i) #9
  %r2732 = bitcast i64 %r2731 to double
  %r77 = bitcast double %r2732 to i64
  %r2728.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r2728 = call i64 asm "", "=r,0"(i64 %r2728.rs4i) #9
  %r2729 = bitcast i64 %r2728 to double
  %r2730 = bitcast double %r2729 to i64
  call void @js_gc_note_slot_layout(i64 %r59, i32 8, i64 %r2730) #9
  %r78 = getelementptr inbounds nuw i8, ptr %r56, i64 88
  %r2727 = load double, ptr @test_json_string_emitters_ts_.str.15.handle, align 8
  store double %r2727, ptr %r78, align 8
  %r2726 = load double, ptr @test_json_string_emitters_ts_.str.15.handle, align 8
  call void @js_string_addref_if_heap_string(double %r2726) #9
  %r2725 = load double, ptr @test_json_string_emitters_ts_.str.15.handle, align 8
  %r79 = bitcast double %r2725 to i64
  %r2723 = load double, ptr @test_json_string_emitters_ts_.str.15.handle, align 8
  %r2724 = bitcast double %r2723 to i64
  call void @js_gc_note_slot_layout(i64 %r59, i32 9, i64 %r2724) #9
  %r80 = getelementptr inbounds nuw i8, ptr %r56, i64 96
  %r2722 = load double, ptr @test_json_string_emitters_ts_.str.16.handle, align 8
  store double %r2722, ptr %r80, align 8
  %r2721 = load double, ptr @test_json_string_emitters_ts_.str.16.handle, align 8
  call void @js_string_addref_if_heap_string(double %r2721) #9
  %r2720 = load double, ptr @test_json_string_emitters_ts_.str.16.handle, align 8
  %r81 = bitcast double %r2720 to i64
  %r2718 = load double, ptr @test_json_string_emitters_ts_.str.16.handle, align 8
  %r2719 = bitcast double %r2718 to i64
  call void @js_gc_note_slot_layout(i64 %r59, i32 10, i64 %r2719) #9
  %r82 = or i64 %r59, 9222527611924643840
  %r83 = bitcast i64 %r82 to double
  %rs4gc.b10 = bitcast double %r83 to i64
  %rs4gc.s10 = inttoptr i64 %rs4gc.b10 to ptr addrspace(1)
  %r84.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r84 = call i64 asm "", "=r,0"(i64 %r84.rs4i) #9
  %r85 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r86 = icmp ne i32 %r85, 0
  br i1 %r86, label %shadow.root.barrier.13, label %shadow.root.barrier.done.14

shadow.root.barrier.13:                           ; preds = %arrlit.merge.12
  call void @js_write_barrier_root_nanbox(i64 %r84) #9
  br label %shadow.root.barrier.done.14

shadow.root.barrier.done.14:                      ; preds = %shadow.root.barrier.13, %arrlit.merge.12
  br label %for.cond.15

for.cond.15:                                      ; preds = %for.update.17, %shadow.root.barrier.done.14
  %.0521 = phi ptr addrspace(1) [ %rs4gc.s10, %shadow.root.barrier.done.14 ], [ %.11, %for.update.17 ]
  %r87.0 = phi i32 [ 0, %shadow.root.barrier.done.14 ], [ %r1132, %for.update.17 ]
  %r89 = sitofp i32 %r87.0 to double
  %r90.rs4i = ptrtoint ptr addrspace(1) %.0521 to i64
  %r90.rs4o = call i64 asm "", "=r,0"(i64 %r90.rs4i) #9
  %r90 = bitcast i64 %r90.rs4o to double
  %r91 = bitcast double %r90 to i64
  %r92 = and i64 %r91, 281474976710655
  %r93 = lshr i64 %r91, 48
  %r94 = and i64 %r93, 65533
  %r95 = icmp eq i64 %r94, 32765
  %r96 = icmp ugt i64 %r92, 1048575
  %r97 = and i1 %r95, %r96
  br i1 %r97, label %plen.check_gc.19, label %plen.slow.21

for.body.16:                                      ; preds = %gcpoll.done.41
  %r204.rs4i = ptrtoint ptr addrspace(1) %.3 to i64
  %r204.rs4o = call i64 asm "", "=r,0"(i64 %r204.rs4i) #9
  %r204 = bitcast i64 %r204.rs4o to double
  %r206 = bitcast double %r204 to i64
  %r207 = and i64 %r206, 281474976710655
  %r208 = lshr i64 %r206, 48
  %r209 = icmp eq i64 %r208, 32765
  %r210 = icmp ugt i64 %r207, 1048575
  %r211 = and i1 %r209, %r210
  br i1 %r211, label %arr.guard.deref.46, label %arr.fallback.43

for.update.17:                                    ; preds = %gcpoll.done.196
  %r1132 = add i32 %r87.0, 1
  %r1133 = sitofp i32 %r87.0 to double
  %r1134 = sitofp i32 %r1132 to double
  br label %for.cond.15

for.exit.18:                                      ; preds = %gcpoll.done.41
  %statepoint_token14 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0)
  %r113615 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token14)
  %r1137 = or i64 %r113615, 9222527611924643840
  %r1138 = bitcast i64 %r1137 to double
  %rs4gc.b11 = bitcast double %r1138 to i64
  %rs4gc.s11 = inttoptr i64 %rs4gc.b11 to ptr addrspace(1)
  %r1139.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s11 to i64
  %r1139 = call i64 asm "", "=r,0"(i64 %r1139.rs4i) #9
  %r1140 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1141 = icmp ne i32 %r1140, 0
  br i1 %r1141, label %shadow.root.barrier.197, label %shadow.root.barrier.done.198

plen.check_gc.19:                                 ; preds = %for.cond.15
  %r98 = sub nuw nsw i64 %r92, 8
  %r99 = inttoptr i64 %r98 to ptr
  %r100 = load i8, ptr %r99, align 1
  %r101 = icmp eq i8 %r100, 1
  %r102 = icmp eq i8 %r100, 3
  %r103 = or i1 %r101, %r102
  %r104 = sub nuw nsw i64 %r92, 7
  %r105 = inttoptr i64 %r104 to ptr
  %r106 = load i8, ptr %r105, align 1
  %r107 = and i8 %r106, -128
  %r108 = icmp eq i8 %r107, 0
  %r109 = and i1 %r103, %r108
  br i1 %r109, label %plen.fast.20, label %plen.slow.21

plen.fast.20:                                     ; preds = %plen.check_gc.19
  %r111 = inttoptr i64 %r92 to ptr
  %r112 = select i1 false, ptr @perry_null_guard_zero_test_json_string_emitters_ts, ptr %r111
  %r113 = load i32, ptr %r112, align 4
  %r114 = uitofp i32 %r113 to double
  br label %plen.merge.22

plen.slow.21:                                     ; preds = %plen.check_gc.19, %for.cond.15
  %r115 = lshr i64 %r91, 48
  %r116 = icmp eq i64 %r115, 32765
  %r117 = icmp uge i64 %r92, 2199023255552
  %r118 = icmp ult i64 %r92, 140737488355328
  %r119 = and i1 %r116, %r117
  %r120 = and i1 %r119, %r118
  %r121 = load ptr, ptr @perry_ic_test_json_string_emitters_ts__14, align 8
  br i1 %r120, label %plen.ic.header.23, label %plen.ic.miss.35

plen.merge.22:                                    ; preds = %plen.ic.merge.36, %plen.fast.20
  %.1522 = phi ptr addrspace(1) [ %.0521, %plen.fast.20 ], [ %.2, %plen.ic.merge.36 ]
  %r196 = phi double [ %r114, %plen.fast.20 ], [ %r195, %plen.ic.merge.36 ]
  %r197 = fcmp olt double %r89, %r196
  %r198 = select i1 %r197, i64 9222246136947933188, i64 9222246136947933187
  %r199 = bitcast i64 %r198 to double
  %r201 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r202 = icmp ne i32 %r201, 0
  br i1 %r202, label %gcpoll.40, label %gcpoll.done.41

plen.ic.header.23:                                ; preds = %plen.slow.21
  %r123 = sub nuw nsw i64 %r92, 8
  %r124 = inttoptr i64 %r123 to ptr
  %r125 = load i8, ptr %r124, align 1
  %r126 = icmp eq i8 %r125, 2
  %r127 = sub nuw nsw i64 %r92, 7
  %r128 = inttoptr i64 %r127 to ptr
  %r129 = load i8, ptr %r128, align 1
  %r130 = and i8 %r129, -128
  %r131 = icmp eq i8 %r130, 0
  %r132 = and i1 %r126, %r131
  br i1 %r132, label %plen.elem.meta.37, label %plen.ic.miss.35

plen.ic.shape.24:                                 ; preds = %plen.elem.store.38, %plen.elem.meta.37
  %r122 = icmp ne ptr %r121, null
  br i1 %r122, label %plen.ic.shape.probe.25, label %plen.ic.miss.35

plen.ic.shape.probe.25:                           ; preds = %plen.ic.shape.24
  %r144 = inttoptr i64 %r92 to ptr
  %r145 = load i32, ptr %r144, align 4
  %r146 = add nuw nsw i64 %r92, 4
  %r147 = inttoptr i64 %r146 to ptr
  %r148 = load i32, ptr %r147, align 4
  %r149 = zext i32 %r145 to i64
  %r150 = zext i32 %r148 to i64
  %r151 = shl nuw i64 %r149, 32
  %r152 = or i64 %r151, %r150
  %r153 = getelementptr i64, ptr %r121, i64 0
  %r154 = load i64, ptr %r153, align 8
  %r155 = icmp ne i64 %r154, 0
  br i1 %r155, label %plen.ic.identity.26, label %plen.ic.miss.35

plen.ic.identity.26:                              ; preds = %plen.ic.shape.probe.25
  %r156 = and i64 %r154, -9223372036854775808
  %0 = icmp slt i64 %r154, 0
  br i1 %0, label %plen.ic.family_meta.28, label %plen.ic.exact.27

plen.ic.exact.27:                                 ; preds = %plen.ic.identity.26
  %r158 = icmp eq i64 %r152, %r154
  br i1 %r158, label %plen.ic.slot.30, label %plen.ic.miss.35

plen.ic.family_meta.28:                           ; preds = %plen.ic.identity.26
  %r159 = add nuw nsw i64 %r92, 8
  %r160 = inttoptr i64 %r159 to ptr
  %r161 = load i64, ptr %r160, align 8
  %r162 = icmp ne i64 %r161, 0
  br i1 %r162, label %plen.ic.family_token.29, label %plen.ic.miss.35

plen.ic.family_token.29:                          ; preds = %plen.ic.family_meta.28
  %r163 = inttoptr i64 %r161 to ptr
  %r164 = getelementptr i64, ptr %r163, i64 6
  %r165 = load i64, ptr %r164, align 8
  %r166 = icmp eq i64 %r165, %r154
  br i1 %r166, label %plen.ic.slot.30, label %plen.ic.miss.35

plen.ic.slot.30:                                  ; preds = %plen.ic.family_token.29, %plen.ic.exact.27
  %r167 = getelementptr i64, ptr %r121, i64 1
  %r168 = load i64, ptr %r167, align 8
  %r169 = getelementptr i64, ptr %r121, i64 2
  %r170 = load i64, ptr %r169, align 8
  %r171 = icmp ult i64 %r168, %r170
  br i1 %r171, label %plen.ic.inline.31, label %plen.ic.spill_meta.32

plen.ic.inline.31:                                ; preds = %plen.ic.slot.30
  %r172 = shl i64 %r168, 3
  %r173 = add i64 %r172, 16
  %r174 = add i64 %r92, %r173
  %r175 = inttoptr i64 %r174 to ptr
  %r176 = load double, ptr %r175, align 8
  br label %plen.ic.merge.36

plen.ic.spill_meta.32:                            ; preds = %plen.ic.slot.30
  %r177 = add nuw nsw i64 %r92, 8
  %r178 = inttoptr i64 %r177 to ptr
  %r179 = load i64, ptr %r178, align 8
  %r180 = icmp ne i64 %r179, 0
  br i1 %r180, label %plen.ic.spill_ptr.33, label %plen.ic.miss.35

plen.ic.spill_ptr.33:                             ; preds = %plen.ic.spill_meta.32
  %r181 = inttoptr i64 %r179 to ptr
  %r182 = getelementptr i64, ptr %r181, i64 4
  %r183 = load i64, ptr %r182, align 8
  %r184 = icmp ne i64 %r183, 0
  %r185 = select i1 %r184, i64 %r183, i64 %r179
  %r186 = inttoptr i64 %r185 to ptr
  %r187 = load i32, ptr %r186, align 4
  %r188 = zext i32 %r187 to i64
  %r189 = icmp ult i64 %r168, %r188
  %r190 = and i1 %r184, %r189
  br i1 %r190, label %plen.ic.spill_load.34, label %plen.ic.miss.35

plen.ic.spill_load.34:                            ; preds = %plen.ic.spill_ptr.33
  %r191 = add nuw nsw i64 %r168, 1
  %r192 = getelementptr inbounds nuw i64, ptr %r186, i64 %r191
  %r193 = load double, ptr %r192, align 8
  br label %plen.ic.merge.36

plen.ic.miss.35:                                  ; preds = %plen.ic.spill_ptr.33, %plen.ic.spill_meta.32, %plen.ic.family_token.29, %plen.ic.family_meta.28, %plen.ic.exact.27, %plen.ic.shape.probe.25, %plen.ic.shape.24, %plen.ic.header.23, %plen.slow.21
  %statepoint_token16 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r90, ptr @perry_ic_test_json_string_emitters_ts__14, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0521) ]
  %r19417 = call double @llvm.experimental.gc.result.f64(token %statepoint_token16)
  %rs4gc.s10.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token16, i32 0, i32 0) ; (%.0521, %.0521)
  br label %plen.ic.merge.36

plen.ic.merge.36:                                 ; preds = %plen.elem.length.39, %plen.ic.miss.35, %plen.ic.spill_load.34, %plen.ic.inline.31
  %.2 = phi ptr addrspace(1) [ %.0521, %plen.elem.length.39 ], [ %.0521, %plen.ic.inline.31 ], [ %.0521, %plen.ic.spill_load.34 ], [ %rs4gc.s10.relocated, %plen.ic.miss.35 ]
  %r195 = phi double [ %r143, %plen.elem.length.39 ], [ %r176, %plen.ic.inline.31 ], [ %r193, %plen.ic.spill_load.34 ], [ %r19417, %plen.ic.miss.35 ]
  br label %plen.merge.22

plen.elem.meta.37:                                ; preds = %plen.ic.header.23
  %r133 = add nuw nsw i64 %r92, 8
  %r134 = inttoptr i64 %r133 to ptr
  %r135 = load i64, ptr %r134, align 8
  %r136 = icmp ne i64 %r135, 0
  br i1 %r136, label %plen.elem.store.38, label %plen.ic.shape.24

plen.elem.store.38:                               ; preds = %plen.elem.meta.37
  %r137 = inttoptr i64 %r135 to ptr
  %r138 = getelementptr i64, ptr %r137, i64 12
  %r139 = load i64, ptr %r138, align 8
  %r140 = icmp ne i64 %r139, 0
  br i1 %r140, label %plen.elem.length.39, label %plen.ic.shape.24

plen.elem.length.39:                              ; preds = %plen.elem.store.38
  %r141 = inttoptr i64 %r139 to ptr
  %r142 = load i32, ptr %r141, align 4
  %r143 = uitofp i32 %r142 to double
  br label %plen.ic.merge.36

gcpoll.40:                                        ; preds = %plen.merge.22
  %statepoint_token18 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1522) ]
  %rs4gc.s10.relocated19 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token18, i32 0, i32 0) ; (%.1522, %.1522)
  br label %gcpoll.done.41

gcpoll.done.41:                                   ; preds = %gcpoll.40, %plen.merge.22
  %.3 = phi ptr addrspace(1) [ %rs4gc.s10.relocated19, %gcpoll.40 ], [ %.1522, %plen.merge.22 ]
  %r200 = icmp eq i64 %r198, 9222246136947933188
  br i1 %r200, label %for.body.16, label %for.exit.18

arr.fast.42:                                      ; preds = %arr.guard.range.48
  %r267 = zext i32 %r87.0 to i64
  %r268 = shl nuw nsw i64 %r267, 3
  %r269 = add nuw nsw i64 %r268, 8
  %r270 = add i64 %r226, %r269
  %r271 = inttoptr i64 %r270 to ptr
  %r272 = load double, ptr %r271, align 8
  %r273 = bitcast double %r272 to i64
  %r274 = icmp eq i64 %r273, 9222246136947933200
  %r276 = select i1 %r274, double 0x7FFC000000000001, double %r272
  br label %arr.merge.45

arr.fallback.43:                                  ; preds = %arr.guard.live.47, %arr.guard.deref.46, %for.body.16
  %r265 = sitofp i32 %r87.0 to double
  %statepoint_token20 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 6553530643794362383, double %r204, double %r265, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3) ]
  %r26621 = call double @llvm.experimental.gc.result.f64(token %statepoint_token20)
  %rs4gc.s10.relocated22 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token20, i32 0, i32 0) ; (%.3, %.3)
  br label %arr.merge.45

arr.guard.oob.44:                                 ; preds = %arr.guard.range.48
  br label %arr.merge.45

arr.merge.45:                                     ; preds = %arr.guard.oob.44, %arr.fallback.43, %arr.fast.42
  %.4 = phi ptr addrspace(1) [ %.3, %arr.fast.42 ], [ %.3, %arr.guard.oob.44 ], [ %rs4gc.s10.relocated22, %arr.fallback.43 ]
  %r277 = phi double [ %r276, %arr.fast.42 ], [ %r26621, %arr.fallback.43 ], [ 0x7FFC000000000001, %arr.guard.oob.44 ]
  %rs4gc.b12 = bitcast double %r277 to i64
  %rs4gc.s12 = inttoptr i64 %rs4gc.b12 to ptr addrspace(1)
  %r278 = bitcast double %r277 to i64
  %r279 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r280 = icmp ne i32 %r279, 0
  br i1 %r280, label %shadow.root.barrier.49, label %shadow.root.barrier.done.50

arr.guard.deref.46:                               ; preds = %for.body.16
  %r212 = bitcast double %r204 to i64
  %r213 = and i64 %r212, 281474976710655
  %r214 = sub nsw i64 %r213, 8
  %r215 = inttoptr i64 %r214 to ptr
  %r216 = load i8, ptr %r215, align 1
  %r217 = icmp eq i8 %r216, 1
  %r218 = sub nsw i64 %r213, 7
  %r219 = inttoptr i64 %r218 to ptr
  %r220 = load i8, ptr %r219, align 1
  %r221 = and i8 %r220, -128
  %r222 = icmp ne i8 %r221, 0
  %r223 = inttoptr i64 %r213 to ptr
  %r224 = load i64, ptr %r223, align 8
  %r225 = and i1 %r217, %r222
  %r226 = select i1 %r225, i64 %r224, i64 %r213
  %r227 = lshr i64 %r226, 48
  %r228 = icmp eq i64 %r227, 0
  %r229 = icmp ugt i64 %r226, 1048575
  %r230 = and i1 %r228, %r229
  br i1 %r230, label %arr.guard.live.47, label %arr.fallback.43

arr.guard.live.47:                                ; preds = %arr.guard.deref.46
  %r231 = sub nuw i64 %r226, 8
  %r232 = inttoptr i64 %r231 to ptr
  %r233 = load i8, ptr %r232, align 1
  %r234 = icmp eq i8 %r233, 1
  %r235 = sub nuw i64 %r226, 7
  %r236 = inttoptr i64 %r235 to ptr
  %r237 = load i8, ptr %r236, align 1
  %r238 = and i8 %r237, -128
  %r239 = icmp eq i8 %r238, 0
  %r240 = sub nuw i64 %r226, 6
  %r241 = inttoptr i64 %r240 to ptr
  %r242 = load i16, ptr %r241, align 2
  %r243 = and i16 %r242, 1024
  %r244 = icmp eq i16 %r243, 0
  %r245 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r246 = icmp eq i8 %r245, 0
  %r247 = inttoptr i64 %r226 to ptr
  %r248 = load i32, ptr %r247, align 4
  %r249 = getelementptr i8, ptr %r247, i64 4
  %r250 = load i32, ptr %r249, align 4
  %r251 = icmp slt i32 %r87.0, 0
  %r252 = icmp eq i1 %r251, false
  %r254 = icmp ule i32 %r248, 16000000
  %r255 = icmp ule i32 %r250, 16000000
  %r256 = icmp ule i32 %r248, %r250
  %r257 = and i1 %r234, %r239
  %r258 = and i1 %r257, %r244
  %r259 = and i1 %r258, %r246
  %r260 = and i1 %r259, %r252
  %r261 = and i1 %r260, %r254
  %r262 = and i1 %r261, %r255
  %r263 = and i1 %r262, %r256
  br i1 %r263, label %arr.guard.range.48, label %arr.fallback.43

arr.guard.range.48:                               ; preds = %arr.guard.live.47
  %r253 = icmp ult i32 %r87.0, %r248
  br i1 %r253, label %arr.fast.42, label %arr.guard.oob.44

shadow.root.barrier.49:                           ; preds = %arr.merge.45
  call void @js_write_barrier_root_nanbox(i64 %r278) #9
  br label %shadow.root.barrier.done.50

shadow.root.barrier.done.50:                      ; preds = %shadow.root.barrier.49, %arr.merge.45
  %r282 = load double, ptr @test_json_string_emitters_ts_.str.17.handle, align 8
  %r283.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12 to i64
  %r283.rs4o = call i64 asm "", "=r,0"(i64 %r283.rs4i) #9
  %r283 = bitcast i64 %r283.rs4o to double
  %statepoint_token23 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r283, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4) ]
  %r28424 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token23)
  %rs4gc.s10.relocated25 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token23, i32 0, i32 0) ; (%.4, %.4)
  %r285 = bitcast i64 %r28424 to double
  %r286 = load double, ptr @test_json_string_emitters_ts_.str.18.handle, align 8
  %r287 = load double, ptr @test_json_string_emitters_ts_.str.17.handle, align 8
  %r289 = getelementptr double, ptr %r288, i64 0
  store double %r287, ptr %r289, align 8
  %r290 = getelementptr double, ptr %r288, i64 1
  store double %r285, ptr %r290, align 8
  %r291 = getelementptr double, ptr %r288, i64 2
  store double %r286, ptr %r291, align 8
  %r292 = ptrtoint ptr %r288 to i64
  %statepoint_token26 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r292, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s10.relocated25) ]
  %r29327 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token26)
  %rs4gc.s10.relocated28 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token26, i32 0, i32 0) ; (%rs4gc.s10.relocated25, %rs4gc.s10.relocated25)
  %r294 = or i64 %r29327, 9223090561878065152
  %r295 = bitcast i64 %r294 to double
  %statepoint_token29 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r295, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s10.relocated28) ]
  %r29630 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token29)
  %rs4gc.s10.relocated31 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token29, i32 0, i32 0) ; (%rs4gc.s10.relocated28, %rs4gc.s10.relocated28)
  %statepoint_token32 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r29630, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s10.relocated31) ]
  %r29733 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token32)
  %rs4gc.s10.relocated34 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token32, i32 0, i32 0) ; (%rs4gc.s10.relocated31, %rs4gc.s10.relocated31)
  %r298 = bitcast i64 %r29733 to double
  %rs4gc.b13 = bitcast double %r298 to i64
  %rs4gc.s13 = inttoptr i64 %rs4gc.b13 to ptr addrspace(1)
  %r299.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13 to i64
  %r299 = call i64 asm "", "=r,0"(i64 %r299.rs4i) #9
  %r300 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r301 = icmp ne i32 %r300, 0
  br i1 %r301, label %shadow.root.barrier.51, label %shadow.root.barrier.done.52

shadow.root.barrier.51:                           ; preds = %shadow.root.barrier.done.50
  call void @js_write_barrier_root_nanbox(i64 %r299) #9
  br label %shadow.root.barrier.done.52

shadow.root.barrier.done.52:                      ; preds = %shadow.root.barrier.51, %shadow.root.barrier.done.50
  %statepoint_token35 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13, ptr addrspace(1) %rs4gc.s10.relocated34) ]
  %r30236 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token35)
  %rs4gc.s13.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token35, i32 0, i32 0) ; (%rs4gc.s13, %rs4gc.s13)
  %rs4gc.s10.relocated37 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token35, i32 1, i32 1) ; (%rs4gc.s10.relocated34, %rs4gc.s10.relocated34)
  %rs4gc.s14 = inttoptr i64 %r30236 to ptr addrspace(1)
  %r303.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r303 = call i64 asm "", "=r,0"(i64 %r303.rs4i) #9
  %r304 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r305 = icmp ne i32 %r304, 0
  br i1 %r305, label %shadow.root.barrier.53, label %shadow.root.barrier.done.54

shadow.root.barrier.53:                           ; preds = %shadow.root.barrier.done.52
  call void @js_write_barrier_root_nanbox(i64 %r303) #9
  br label %shadow.root.barrier.done.54

shadow.root.barrier.done.54:                      ; preds = %shadow.root.barrier.53, %shadow.root.barrier.done.52
  %r306 = load double, ptr @test_json_string_emitters_ts_.str.19.handle, align 8
  %r307.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r307 = call i64 asm "", "=r,0"(i64 %r307.rs4i) #9
  %statepoint_token38 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r307, double %r306, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated, ptr addrspace(1) %rs4gc.s10.relocated37) ]
  %r30839 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token38)
  %rs4gc.s13.relocated40 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token38, i32 0, i32 0) ; (%rs4gc.s13.relocated, %rs4gc.s13.relocated)
  %rs4gc.s10.relocated41 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token38, i32 1, i32 1) ; (%rs4gc.s10.relocated37, %rs4gc.s10.relocated37)
  %rs4gc.s15 = inttoptr i64 %r30839 to ptr addrspace(1)
  %r309.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15 to i64
  %r309 = call i64 asm "", "=r,0"(i64 %r309.rs4i) #9
  %r310 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r311 = icmp ne i32 %r310, 0
  br i1 %r311, label %shadow.root.barrier.55, label %shadow.root.barrier.done.56

shadow.root.barrier.55:                           ; preds = %shadow.root.barrier.done.54
  call void @js_write_barrier_root_nanbox(i64 %r309) #9
  br label %shadow.root.barrier.done.56

shadow.root.barrier.done.56:                      ; preds = %shadow.root.barrier.55, %shadow.root.barrier.done.54
  %r313 = sitofp i32 %r87.0 to double
  %r314.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15 to i64
  %r314 = call i64 asm "", "=r,0"(i64 %r314.rs4i) #9
  %statepoint_token42 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r314, double %r313, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated40, ptr addrspace(1) %rs4gc.s10.relocated41) ]
  %r31543 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token42)
  %rs4gc.s13.relocated44 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token42, i32 0, i32 0) ; (%rs4gc.s13.relocated40, %rs4gc.s13.relocated40)
  %rs4gc.s10.relocated45 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token42, i32 1, i32 1) ; (%rs4gc.s10.relocated41, %rs4gc.s10.relocated41)
  %rs4gc.s16 = inttoptr i64 %r31543 to ptr addrspace(1)
  %r316.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16 to i64
  %r316 = call i64 asm "", "=r,0"(i64 %r316.rs4i) #9
  %r317 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r318 = icmp ne i32 %r317, 0
  br i1 %r318, label %shadow.root.barrier.57, label %shadow.root.barrier.done.58

shadow.root.barrier.57:                           ; preds = %shadow.root.barrier.done.56
  call void @js_write_barrier_root_nanbox(i64 %r316) #9
  br label %shadow.root.barrier.done.58

shadow.root.barrier.done.58:                      ; preds = %shadow.root.barrier.57, %shadow.root.barrier.done.56
  %r319.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated44 to i64
  %r319.rs4o = call i64 asm "", "=r,0"(i64 %r319.rs4i) #9
  %r319 = bitcast i64 %r319.rs4o to double
  %statepoint_token46 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r319, double 0x7FFC000000000002, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated44, ptr addrspace(1) %rs4gc.s10.relocated45, ptr addrspace(1) %rs4gc.s16) ]
  %r32047 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token46)
  %rs4gc.s13.relocated48 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token46, i32 0, i32 0) ; (%rs4gc.s13.relocated44, %rs4gc.s13.relocated44)
  %rs4gc.s10.relocated49 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token46, i32 1, i32 1) ; (%rs4gc.s10.relocated45, %rs4gc.s10.relocated45)
  %rs4gc.s16.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token46, i32 2, i32 2) ; (%rs4gc.s16, %rs4gc.s16)
  %r321 = bitcast i64 %r32047 to double
  %r322.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16.relocated to i64
  %r322 = call i64 asm "", "=r,0"(i64 %r322.rs4i) #9
  %statepoint_token50 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r322, double %r321, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated48, ptr addrspace(1) %rs4gc.s10.relocated49) ]
  %r32351 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token50)
  %rs4gc.s13.relocated52 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token50, i32 0, i32 0) ; (%rs4gc.s13.relocated48, %rs4gc.s13.relocated48)
  %rs4gc.s10.relocated53 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token50, i32 1, i32 1) ; (%rs4gc.s10.relocated49, %rs4gc.s10.relocated49)
  %rs4gc.s17 = inttoptr i64 %r32351 to ptr addrspace(1)
  %r324.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17 to i64
  %r324 = call i64 asm "", "=r,0"(i64 %r324.rs4i) #9
  %r325 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r326 = icmp ne i32 %r325, 0
  br i1 %r326, label %shadow.root.barrier.59, label %shadow.root.barrier.done.60

shadow.root.barrier.59:                           ; preds = %shadow.root.barrier.done.58
  call void @js_write_barrier_root_nanbox(i64 %r324) #9
  br label %shadow.root.barrier.done.60

shadow.root.barrier.done.60:                      ; preds = %shadow.root.barrier.59, %shadow.root.barrier.done.58
  %r327.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17 to i64
  %r327 = call i64 asm "", "=r,0"(i64 %r327.rs4i) #9
  %statepoint_token54 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r327, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated52, ptr addrspace(1) %rs4gc.s10.relocated53) ]
  %rs4gc.s13.relocated55 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token54, i32 0, i32 0) ; (%rs4gc.s13.relocated52, %rs4gc.s13.relocated52)
  %rs4gc.s10.relocated56 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token54, i32 1, i32 1) ; (%rs4gc.s10.relocated53, %rs4gc.s10.relocated53)
  %statepoint_token57 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated55, ptr addrspace(1) %rs4gc.s10.relocated56) ]
  %r32858 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token57)
  %rs4gc.s13.relocated59 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token57, i32 0, i32 0) ; (%rs4gc.s13.relocated55, %rs4gc.s13.relocated55)
  %rs4gc.s10.relocated60 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token57, i32 1, i32 1) ; (%rs4gc.s10.relocated56, %rs4gc.s10.relocated56)
  %rs4gc.s18 = inttoptr i64 %r32858 to ptr addrspace(1)
  %r329.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r329 = call i64 asm "", "=r,0"(i64 %r329.rs4i) #9
  %r330 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r331 = icmp ne i32 %r330, 0
  br i1 %r331, label %shadow.root.barrier.61, label %shadow.root.barrier.done.62

shadow.root.barrier.61:                           ; preds = %shadow.root.barrier.done.60
  call void @js_write_barrier_root_nanbox(i64 %r329) #9
  br label %shadow.root.barrier.done.62

shadow.root.barrier.done.62:                      ; preds = %shadow.root.barrier.61, %shadow.root.barrier.done.60
  %r332 = load double, ptr @test_json_string_emitters_ts_.str.20.handle, align 8
  %r333.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r333 = call i64 asm "", "=r,0"(i64 %r333.rs4i) #9
  %statepoint_token61 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r333, double %r332, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated59, ptr addrspace(1) %rs4gc.s10.relocated60) ]
  %r33462 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token61)
  %rs4gc.s13.relocated63 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token61, i32 0, i32 0) ; (%rs4gc.s13.relocated59, %rs4gc.s13.relocated59)
  %rs4gc.s10.relocated64 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token61, i32 1, i32 1) ; (%rs4gc.s10.relocated60, %rs4gc.s10.relocated60)
  %rs4gc.s19 = inttoptr i64 %r33462 to ptr addrspace(1)
  %r335.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19 to i64
  %r335 = call i64 asm "", "=r,0"(i64 %r335.rs4i) #9
  %r336 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r337 = icmp ne i32 %r336, 0
  br i1 %r337, label %shadow.root.barrier.63, label %shadow.root.barrier.done.64

shadow.root.barrier.63:                           ; preds = %shadow.root.barrier.done.62
  call void @js_write_barrier_root_nanbox(i64 %r335) #9
  br label %shadow.root.barrier.done.64

shadow.root.barrier.done.64:                      ; preds = %shadow.root.barrier.63, %shadow.root.barrier.done.62
  %r339 = sitofp i32 %r87.0 to double
  %r340.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19 to i64
  %r340 = call i64 asm "", "=r,0"(i64 %r340.rs4i) #9
  %statepoint_token65 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r340, double %r339, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated63, ptr addrspace(1) %rs4gc.s10.relocated64) ]
  %r34166 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token65)
  %rs4gc.s13.relocated67 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token65, i32 0, i32 0) ; (%rs4gc.s13.relocated63, %rs4gc.s13.relocated63)
  %rs4gc.s10.relocated68 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token65, i32 1, i32 1) ; (%rs4gc.s10.relocated64, %rs4gc.s10.relocated64)
  %rs4gc.s20 = inttoptr i64 %r34166 to ptr addrspace(1)
  %r342.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20 to i64
  %r342 = call i64 asm "", "=r,0"(i64 %r342.rs4i) #9
  %r343 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r344 = icmp ne i32 %r343, 0
  br i1 %r344, label %shadow.root.barrier.65, label %shadow.root.barrier.done.66

shadow.root.barrier.65:                           ; preds = %shadow.root.barrier.done.64
  call void @js_write_barrier_root_nanbox(i64 %r342) #9
  br label %shadow.root.barrier.done.66

shadow.root.barrier.done.66:                      ; preds = %shadow.root.barrier.65, %shadow.root.barrier.done.64
  %r345.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated67 to i64
  %r345.rs4o = call i64 asm "", "=r,0"(i64 %r345.rs4i) #9
  %r345 = bitcast i64 %r345.rs4o to double
  %statepoint_token69 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (ptr)) @js_closure_alloc_singleton, i32 1, i32 0, ptr @__perry_wrap_perry_fn_test_json_string_emitters_ts__identity, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated67, ptr addrspace(1) %rs4gc.s10.relocated68, ptr addrspace(1) %rs4gc.s20) ]
  %r34670 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token69)
  %rs4gc.s13.relocated71 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token69, i32 0, i32 0) ; (%rs4gc.s13.relocated67, %rs4gc.s13.relocated67)
  %rs4gc.s10.relocated72 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token69, i32 1, i32 1) ; (%rs4gc.s10.relocated68, %rs4gc.s10.relocated68)
  %rs4gc.s20.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token69, i32 2, i32 2) ; (%rs4gc.s20, %rs4gc.s20)
  %r347 = or i64 %r34670, 9222527611924643840
  %r348 = bitcast i64 %r347 to double
  %r2717.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated71 to i64
  %r2717.rs4o = call i64 asm "", "=r,0"(i64 %r2717.rs4i) #9
  %r2717 = bitcast i64 %r2717.rs4o to double
  %statepoint_token73 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r2717, double %r348, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated71, ptr addrspace(1) %rs4gc.s10.relocated72, ptr addrspace(1) %rs4gc.s20.relocated) ]
  %r34974 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token73)
  %rs4gc.s13.relocated75 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token73, i32 0, i32 0) ; (%rs4gc.s13.relocated71, %rs4gc.s13.relocated71)
  %rs4gc.s10.relocated76 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token73, i32 1, i32 1) ; (%rs4gc.s10.relocated72, %rs4gc.s10.relocated72)
  %rs4gc.s20.relocated77 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token73, i32 2, i32 2) ; (%rs4gc.s20.relocated, %rs4gc.s20.relocated)
  %r350 = bitcast i64 %r34974 to double
  %r351.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20.relocated77 to i64
  %r351 = call i64 asm "", "=r,0"(i64 %r351.rs4i) #9
  %statepoint_token78 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r351, double %r350, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated75, ptr addrspace(1) %rs4gc.s10.relocated76) ]
  %r35279 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token78)
  %rs4gc.s13.relocated80 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token78, i32 0, i32 0) ; (%rs4gc.s13.relocated75, %rs4gc.s13.relocated75)
  %rs4gc.s10.relocated81 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token78, i32 1, i32 1) ; (%rs4gc.s10.relocated76, %rs4gc.s10.relocated76)
  %rs4gc.s21 = inttoptr i64 %r35279 to ptr addrspace(1)
  %r353.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r353 = call i64 asm "", "=r,0"(i64 %r353.rs4i) #9
  %r354 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r355 = icmp ne i32 %r354, 0
  br i1 %r355, label %shadow.root.barrier.67, label %shadow.root.barrier.done.68

shadow.root.barrier.67:                           ; preds = %shadow.root.barrier.done.66
  call void @js_write_barrier_root_nanbox(i64 %r353) #9
  br label %shadow.root.barrier.done.68

shadow.root.barrier.done.68:                      ; preds = %shadow.root.barrier.67, %shadow.root.barrier.done.66
  %r356.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r356 = call i64 asm "", "=r,0"(i64 %r356.rs4i) #9
  %statepoint_token82 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r356, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated80, ptr addrspace(1) %rs4gc.s10.relocated81) ]
  %rs4gc.s13.relocated83 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token82, i32 0, i32 0) ; (%rs4gc.s13.relocated80, %rs4gc.s13.relocated80)
  %rs4gc.s10.relocated84 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token82, i32 1, i32 1) ; (%rs4gc.s10.relocated81, %rs4gc.s10.relocated81)
  %statepoint_token85 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated83, ptr addrspace(1) %rs4gc.s10.relocated84) ]
  %r35786 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token85)
  %rs4gc.s13.relocated87 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token85, i32 0, i32 0) ; (%rs4gc.s13.relocated83, %rs4gc.s13.relocated83)
  %rs4gc.s10.relocated88 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token85, i32 1, i32 1) ; (%rs4gc.s10.relocated84, %rs4gc.s10.relocated84)
  %rs4gc.s22 = inttoptr i64 %r35786 to ptr addrspace(1)
  %r358.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s22 to i64
  %r358 = call i64 asm "", "=r,0"(i64 %r358.rs4i) #9
  %r359 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r360 = icmp ne i32 %r359, 0
  br i1 %r360, label %shadow.root.barrier.69, label %shadow.root.barrier.done.70

shadow.root.barrier.69:                           ; preds = %shadow.root.barrier.done.68
  call void @js_write_barrier_root_nanbox(i64 %r358) #9
  br label %shadow.root.barrier.done.70

shadow.root.barrier.done.70:                      ; preds = %shadow.root.barrier.69, %shadow.root.barrier.done.68
  %r361 = load double, ptr @test_json_string_emitters_ts_.str.21.handle, align 8
  %r362.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s22 to i64
  %r362 = call i64 asm "", "=r,0"(i64 %r362.rs4i) #9
  %statepoint_token89 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r362, double %r361, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated87, ptr addrspace(1) %rs4gc.s10.relocated88) ]
  %r36390 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token89)
  %rs4gc.s13.relocated91 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token89, i32 0, i32 0) ; (%rs4gc.s13.relocated87, %rs4gc.s13.relocated87)
  %rs4gc.s10.relocated92 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token89, i32 1, i32 1) ; (%rs4gc.s10.relocated88, %rs4gc.s10.relocated88)
  %rs4gc.s23 = inttoptr i64 %r36390 to ptr addrspace(1)
  %r364.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s23 to i64
  %r364 = call i64 asm "", "=r,0"(i64 %r364.rs4i) #9
  %r365 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r366 = icmp ne i32 %r365, 0
  br i1 %r366, label %shadow.root.barrier.71, label %shadow.root.barrier.done.72

shadow.root.barrier.71:                           ; preds = %shadow.root.barrier.done.70
  call void @js_write_barrier_root_nanbox(i64 %r364) #9
  br label %shadow.root.barrier.done.72

shadow.root.barrier.done.72:                      ; preds = %shadow.root.barrier.71, %shadow.root.barrier.done.70
  %r368 = sitofp i32 %r87.0 to double
  %r369.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s23 to i64
  %r369 = call i64 asm "", "=r,0"(i64 %r369.rs4i) #9
  %statepoint_token93 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r369, double %r368, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated91, ptr addrspace(1) %rs4gc.s10.relocated92) ]
  %r37094 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token93)
  %rs4gc.s13.relocated95 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token93, i32 0, i32 0) ; (%rs4gc.s13.relocated91, %rs4gc.s13.relocated91)
  %rs4gc.s10.relocated96 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token93, i32 1, i32 1) ; (%rs4gc.s10.relocated92, %rs4gc.s10.relocated92)
  %rs4gc.s24 = inttoptr i64 %r37094 to ptr addrspace(1)
  %r371.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24 to i64
  %r371 = call i64 asm "", "=r,0"(i64 %r371.rs4i) #9
  %r372 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r373 = icmp ne i32 %r372, 0
  br i1 %r373, label %shadow.root.barrier.73, label %shadow.root.barrier.done.74

shadow.root.barrier.73:                           ; preds = %shadow.root.barrier.done.72
  call void @js_write_barrier_root_nanbox(i64 %r371) #9
  br label %shadow.root.barrier.done.74

shadow.root.barrier.done.74:                      ; preds = %shadow.root.barrier.73, %shadow.root.barrier.done.72
  %r374.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated95 to i64
  %r374.rs4o = call i64 asm "", "=r,0"(i64 %r374.rs4i) #9
  %r374 = bitcast i64 %r374.rs4o to double
  %statepoint_token97 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (ptr)) @js_closure_alloc_singleton, i32 1, i32 0, ptr @__perry_wrap_perry_fn_test_json_string_emitters_ts__identity, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated95, ptr addrspace(1) %rs4gc.s10.relocated96, ptr addrspace(1) %rs4gc.s24) ]
  %r37598 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token97)
  %rs4gc.s13.relocated99 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token97, i32 0, i32 0) ; (%rs4gc.s13.relocated95, %rs4gc.s13.relocated95)
  %rs4gc.s10.relocated100 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token97, i32 1, i32 1) ; (%rs4gc.s10.relocated96, %rs4gc.s10.relocated96)
  %rs4gc.s24.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token97, i32 2, i32 2) ; (%rs4gc.s24, %rs4gc.s24)
  %r376 = or i64 %r37598, 9222527611924643840
  %r377 = bitcast i64 %r376 to double
  %r2716.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated99 to i64
  %r2716.rs4o = call i64 asm "", "=r,0"(i64 %r2716.rs4i) #9
  %r2716 = bitcast i64 %r2716.rs4o to double
  %statepoint_token101 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r2716, double %r377, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated99, ptr addrspace(1) %rs4gc.s10.relocated100, ptr addrspace(1) %rs4gc.s24.relocated) ]
  %r378102 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token101)
  %rs4gc.s13.relocated103 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token101, i32 0, i32 0) ; (%rs4gc.s13.relocated99, %rs4gc.s13.relocated99)
  %rs4gc.s10.relocated104 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token101, i32 1, i32 1) ; (%rs4gc.s10.relocated100, %rs4gc.s10.relocated100)
  %rs4gc.s24.relocated105 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token101, i32 2, i32 2) ; (%rs4gc.s24.relocated, %rs4gc.s24.relocated)
  %r379 = bitcast i64 %r378102 to double
  %r380.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24.relocated105 to i64
  %r380 = call i64 asm "", "=r,0"(i64 %r380.rs4i) #9
  %statepoint_token106 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r380, double %r379, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated103, ptr addrspace(1) %rs4gc.s10.relocated104) ]
  %r381107 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token106)
  %rs4gc.s13.relocated108 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token106, i32 0, i32 0) ; (%rs4gc.s13.relocated103, %rs4gc.s13.relocated103)
  %rs4gc.s10.relocated109 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token106, i32 1, i32 1) ; (%rs4gc.s10.relocated104, %rs4gc.s10.relocated104)
  %rs4gc.s25 = inttoptr i64 %r381107 to ptr addrspace(1)
  %r382.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s25 to i64
  %r382 = call i64 asm "", "=r,0"(i64 %r382.rs4i) #9
  %r383 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r384 = icmp ne i32 %r383, 0
  br i1 %r384, label %shadow.root.barrier.75, label %shadow.root.barrier.done.76

shadow.root.barrier.75:                           ; preds = %shadow.root.barrier.done.74
  call void @js_write_barrier_root_nanbox(i64 %r382) #9
  br label %shadow.root.barrier.done.76

shadow.root.barrier.done.76:                      ; preds = %shadow.root.barrier.75, %shadow.root.barrier.done.74
  %r385.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s25 to i64
  %r385 = call i64 asm "", "=r,0"(i64 %r385.rs4i) #9
  %statepoint_token110 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r385, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated108, ptr addrspace(1) %rs4gc.s10.relocated109) ]
  %rs4gc.s13.relocated111 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token110, i32 0, i32 0) ; (%rs4gc.s13.relocated108, %rs4gc.s13.relocated108)
  %rs4gc.s10.relocated112 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token110, i32 1, i32 1) ; (%rs4gc.s10.relocated109, %rs4gc.s10.relocated109)
  %r386 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r387.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated111 to i64
  %r387.rs4o = call i64 asm "", "=r,0"(i64 %r387.rs4i) #9
  %r387 = bitcast i64 %r387.rs4o to double
  %r388 = bitcast double %r387 to i64
  %r389 = and i64 %r388, 281474976710655
  %r390 = lshr i64 %r388, 48
  %r391 = and i64 %r390, 65533
  %r392 = icmp eq i64 %r391, 32765
  br i1 %r392, label %pget.recv_ok.78, label %pget.recv_other.82

pget.recv_sso.77:                                 ; preds = %pget.recv_other.82
  %r530 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r531 = bitcast double %r530 to i64
  %r532 = and i64 %r531, 281474976710655
  %statepoint_token113 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r388, i64 %r532, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated111, ptr addrspace(1) %rs4gc.s10.relocated112) ]
  %r533114 = call double @llvm.experimental.gc.result.f64(token %statepoint_token113)
  %rs4gc.s13.relocated115 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token113, i32 0, i32 0) ; (%rs4gc.s13.relocated111, %rs4gc.s13.relocated111)
  %rs4gc.s10.relocated116 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token113, i32 1, i32 1) ; (%rs4gc.s10.relocated112, %rs4gc.s10.relocated112)
  br label %pget.recv_merge.81

pget.recv_ok.78:                                  ; preds = %shadow.root.barrier.done.76
  %r399 = icmp ugt i64 %r389, 1048575
  br i1 %r399, label %pic.recv_hdr.99, label %pic.miss.cold.96

pget.recv_bad.79:                                 ; preds = %pget.check_class_ref.83
  %r522 = icmp eq i64 %r388, 9222246136947933185
  %r523 = icmp eq i64 %r388, 9222246136947933186
  %r524 = or i1 %r522, %r523
  br i1 %r524, label %pget.throw_nullish.106, label %pget.recv_undef_return.107

pget.recv_class_ref.80:                           ; preds = %pget.check_class_ref.83
  %r395 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r396 = bitcast double %r395 to i64
  %r397 = and i64 %r396, 281474976710655
  %statepoint_token117 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6553530643794362384, i64 %r388, i64 %r397, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated111, ptr addrspace(1) %rs4gc.s10.relocated112) ]
  %r398118 = call double @llvm.experimental.gc.result.f64(token %statepoint_token117)
  %rs4gc.s13.relocated119 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token117, i32 0, i32 0) ; (%rs4gc.s13.relocated111, %rs4gc.s13.relocated111)
  %rs4gc.s10.relocated120 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token117, i32 1, i32 1) ; (%rs4gc.s10.relocated112, %rs4gc.s10.relocated112)
  br label %pget.recv_merge.81

pget.recv_merge.81:                               ; preds = %pget.recv_undef_return.107, %pic.merge.98, %pget.recv_class_ref.80, %pget.recv_sso.77
  %.0523 = phi ptr addrspace(1) [ %.1524, %pic.merge.98 ], [ %rs4gc.s13.relocated115, %pget.recv_sso.77 ], [ %rs4gc.s13.relocated119, %pget.recv_class_ref.80 ], [ %rs4gc.s13.relocated136, %pget.recv_undef_return.107 ]
  %.5 = phi ptr addrspace(1) [ %.6, %pic.merge.98 ], [ %rs4gc.s10.relocated116, %pget.recv_sso.77 ], [ %rs4gc.s10.relocated120, %pget.recv_class_ref.80 ], [ %rs4gc.s10.relocated137, %pget.recv_undef_return.107 ]
  %r534 = phi double [ %r521, %pic.merge.98 ], [ %r529135, %pget.recv_undef_return.107 ], [ %r533114, %pget.recv_sso.77 ], [ %r398118, %pget.recv_class_ref.80 ]
  %r535 = load double, ptr @test_json_string_emitters_ts_.str.22.handle, align 8
  %statepoint_token121 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r534, double %r535, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0523, ptr addrspace(1) %.5) ]
  %r536122 = call double @llvm.experimental.gc.result.f64(token %statepoint_token121)
  %rs4gc.s13.relocated123 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token121, i32 0, i32 0) ; (%.0523, %.0523)
  %rs4gc.s10.relocated124 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token121, i32 1, i32 1) ; (%.5, %.5)
  %r537 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r538.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated123 to i64
  %r538.rs4o = call i64 asm "", "=r,0"(i64 %r538.rs4i) #9
  %r538 = bitcast i64 %r538.rs4o to double
  %r539 = load ptr, ptr @perry_ic_test_json_string_emitters_ts__18, align 8
  %r540 = icmp ne ptr %r539, null
  %r541 = select i1 %r540, ptr %r539, ptr @perry_ic_test_json_string_emitters_ts__18
  %r544 = bitcast double %r537 to i64
  %r545 = bitcast double %r536122 to i64
  %r546 = bitcast double %r538 to i64
  %r547 = and i64 %r546, 281474976710655
  %r548 = lshr i64 %r546, 48
  %r549 = icmp eq i64 %r548, 32765
  %r550 = icmp ugt i64 %r547, 1048575
  %r551 = lshr i64 %r545, 48
  %r552 = icmp ne i64 %r551, 32765
  %r553 = icmp ne i64 %r551, 32767
  %r554 = icmp ne i64 %r551, 32762
  %r555 = and i1 %r552, %r553
  %r556 = and i1 %r555, %r554
  %r557 = icmp ne i64 %r544, 0
  %r558 = and i1 %r549, %r550
  %r559 = and i1 %r558, %r557
  br i1 %r559, label %put.dynic.guard.108, label %put.dynic.slow.126

pget.recv_other.82:                               ; preds = %shadow.root.barrier.done.76
  %r393 = icmp eq i64 %r390, 32761
  br i1 %r393, label %pget.recv_sso.77, label %pget.check_class_ref.83

pget.check_class_ref.83:                          ; preds = %pget.recv_other.82
  %r394 = icmp eq i64 %r390, 32766
  br i1 %r394, label %pget.recv_class_ref.80, label %pget.recv_bad.79

pic.hit.84:                                       ; preds = %pic.token.100
  %r424 = getelementptr i64, ptr %r409, i64 1
  %r425 = load i64, ptr %r424, align 8
  %r426 = and i64 %r425, 1073741824
  %r427 = icmp ne i64 %r426, 0
  br i1 %r427, label %pic.hit.overflow.101, label %pic.hit.inline.102

pic.hit.live.85:                                  ; preds = %pic.hit.inline.102
  br label %pic.merge.98

pic.prefix.guard.86:                              ; preds = %pic.token.100
  %r440 = getelementptr i64, ptr %r409, i64 2
  %r441 = load i64, ptr %r440, align 8
  %r442 = icmp ne i64 %r441, 0
  br i1 %r442, label %pic.prefix.meta.87, label %pic.miss.95

pic.prefix.meta.87:                               ; preds = %pic.prefix.guard.86
  %r443 = add nuw nsw i64 %r389, 8
  %r444 = inttoptr i64 %r443 to ptr
  %r445 = load i64, ptr %r444, align 8
  %r446 = icmp ne i64 %r445, 0
  br i1 %r446, label %pic.prefix.token.88, label %pic.miss.95

pic.prefix.token.88:                              ; preds = %pic.prefix.meta.87
  %r447 = inttoptr i64 %r445 to ptr
  %r448 = getelementptr i64, ptr %r447, i64 6
  %r449 = load i64, ptr %r448, align 8
  %r450 = icmp eq i64 %r449, %r441
  br i1 %r450, label %pic.prefix.hit.89, label %pic.miss.95

pic.prefix.hit.89:                                ; preds = %pic.prefix.token.88
  %r451 = getelementptr i64, ptr %r409, i64 1
  %r452 = load i64, ptr %r451, align 8
  %r453 = shl i64 %r452, 3
  %r454 = add nuw nsw i64 %r389, 16
  %r455 = add i64 %r454, %r453
  %r456 = inttoptr i64 %r455 to ptr
  %r457 = load double, ptr %r456, align 8
  br label %pic.merge.98

pic.desc.classify.90:                             ; preds = %pic.recv_hdr.99
  %r413 = and i1 %r403, %r410
  br i1 %r413, label %pic.desc.prefix.guard.91, label %pic.miss.cold.96

pic.desc.prefix.guard.91:                         ; preds = %pic.desc.classify.90
  %r458 = getelementptr i64, ptr %r409, i64 2
  %r459 = load i64, ptr %r458, align 8
  %r460 = icmp ne i64 %r459, 0
  br i1 %r460, label %pic.desc.prefix.meta.92, label %pic.miss.cold.96

pic.desc.prefix.meta.92:                          ; preds = %pic.desc.prefix.guard.91
  %r461 = add nuw nsw i64 %r389, 8
  %r462 = inttoptr i64 %r461 to ptr
  %r463 = load i64, ptr %r462, align 8
  %r464 = icmp ne i64 %r463, 0
  br i1 %r464, label %pic.desc.prefix.token.93, label %pic.miss.cold.96

pic.desc.prefix.token.93:                         ; preds = %pic.desc.prefix.meta.92
  %r465 = inttoptr i64 %r463 to ptr
  %r466 = getelementptr i64, ptr %r465, i64 6
  %r467 = load i64, ptr %r466, align 8
  %r468 = icmp eq i64 %r467, %r459
  br i1 %r468, label %pic.desc.prefix.hit.94, label %pic.miss.cold.96

pic.desc.prefix.hit.94:                           ; preds = %pic.desc.prefix.token.93
  %r469 = getelementptr i64, ptr %r409, i64 1
  %r470 = load i64, ptr %r469, align 8
  %r471 = shl i64 %r470, 3
  %r472 = add nuw nsw i64 %r389, 16
  %r473 = add i64 %r472, %r471
  %r474 = inttoptr i64 %r473 to ptr
  %r475 = load double, ptr %r474, align 8
  br label %pic.merge.98

pic.miss.95:                                      ; preds = %pic.hit.inline.102, %pic.prefix.token.88, %pic.prefix.meta.87, %pic.prefix.guard.86
  %r476 = getelementptr i64, ptr %r409, i64 3
  %r477 = load i64, ptr %r476, align 8
  %r478 = icmp sgt i64 %r477, 0
  br i1 %r478, label %pic.ways.103, label %pic.miss.call.97

pic.miss.cold.96:                                 ; preds = %pic.desc.prefix.token.93, %pic.desc.prefix.meta.92, %pic.desc.prefix.guard.91, %pic.desc.classify.90, %pget.recv_ok.78
  br label %pic.miss.call.97

pic.miss.call.97:                                 ; preds = %pic.way.load.104, %pic.ways.103, %pic.miss.cold.96, %pic.miss.95
  %r517 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r518 = bitcast double %r517 to i64
  %r519 = and i64 %r518, 281474976710655
  %statepoint_token125 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r389, i64 %r519, ptr @perry_ic_test_json_string_emitters_ts__17, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated111, ptr addrspace(1) %rs4gc.s10.relocated112) ]
  %r520126 = call double @llvm.experimental.gc.result.f64(token %statepoint_token125)
  %rs4gc.s13.relocated127 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token125, i32 0, i32 0) ; (%rs4gc.s13.relocated111, %rs4gc.s13.relocated111)
  %rs4gc.s10.relocated128 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token125, i32 1, i32 1) ; (%rs4gc.s10.relocated112, %rs4gc.s10.relocated112)
  br label %pic.merge.98

pic.merge.98:                                     ; preds = %pic.way.live.105, %pic.hit.overflow.101, %pic.miss.call.97, %pic.desc.prefix.hit.94, %pic.prefix.hit.89, %pic.hit.live.85
  %.1524 = phi ptr addrspace(1) [ %rs4gc.s13.relocated131, %pic.hit.overflow.101 ], [ %rs4gc.s13.relocated127, %pic.miss.call.97 ], [ %rs4gc.s13.relocated111, %pic.way.live.105 ], [ %rs4gc.s13.relocated111, %pic.hit.live.85 ], [ %rs4gc.s13.relocated111, %pic.prefix.hit.89 ], [ %rs4gc.s13.relocated111, %pic.desc.prefix.hit.94 ]
  %.6 = phi ptr addrspace(1) [ %rs4gc.s10.relocated132, %pic.hit.overflow.101 ], [ %rs4gc.s10.relocated128, %pic.miss.call.97 ], [ %rs4gc.s10.relocated112, %pic.way.live.105 ], [ %rs4gc.s10.relocated112, %pic.hit.live.85 ], [ %rs4gc.s10.relocated112, %pic.prefix.hit.89 ], [ %rs4gc.s10.relocated112, %pic.desc.prefix.hit.94 ]
  %r521 = phi double [ %r437, %pic.hit.live.85 ], [ %r432130, %pic.hit.overflow.101 ], [ %r457, %pic.prefix.hit.89 ], [ %r475, %pic.desc.prefix.hit.94 ], [ %r514, %pic.way.live.105 ], [ %r520126, %pic.miss.call.97 ]
  br label %pget.recv_merge.81

pic.recv_hdr.99:                                  ; preds = %pget.recv_ok.78
  %r400 = sub nuw nsw i64 %r389, 8
  %r401 = inttoptr i64 %r400 to ptr
  %r402 = load i8, ptr %r401, align 1
  %r403 = icmp eq i8 %r402, 2
  %r404 = sub nuw nsw i64 %r389, 6
  %r405 = inttoptr i64 %r404 to ptr
  %r406 = load i16, ptr %r405, align 2
  %r407 = and i16 %r406, 2048
  %r408 = icmp eq i16 %r407, 0
  %r409 = load ptr, ptr @perry_ic_test_json_string_emitters_ts__17, align 8
  %r410 = icmp ne ptr %r409, null
  %r411 = and i1 %r403, %r408
  %r412 = and i1 %r411, %r410
  br i1 %r412, label %pic.token.100, label %pic.desc.classify.90

pic.token.100:                                    ; preds = %pic.recv_hdr.99
  %r414 = add nuw nsw i64 %r389, 4
  %r415 = inttoptr i64 %r414 to ptr
  %r416 = load i32, ptr %r415, align 4
  %r417 = zext i32 %r416 to i64
  %r418 = or i64 %r417, 4611686018427387904
  %r419 = icmp ne i32 %r416, 0
  %r420 = getelementptr i64, ptr %r409, i64 0
  %r421 = load i64, ptr %r420, align 8
  %r422 = icmp eq i64 %r418, %r421
  %r423 = and i1 %r422, %r419
  br i1 %r423, label %pic.hit.84, label %pic.prefix.guard.86

pic.hit.overflow.101:                             ; preds = %pic.hit.84
  %r428 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r429 = bitcast double %r428 to i64
  %r430 = and i64 %r429, 281474976710655
  %r431 = trunc i64 %r425 to i32
  %statepoint_token129 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r389, i64 %r430, i32 %r431, ptr @perry_ic_test_json_string_emitters_ts__17, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated111, ptr addrspace(1) %rs4gc.s10.relocated112) ]
  %r432130 = call double @llvm.experimental.gc.result.f64(token %statepoint_token129)
  %rs4gc.s13.relocated131 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token129, i32 0, i32 0) ; (%rs4gc.s13.relocated111, %rs4gc.s13.relocated111)
  %rs4gc.s10.relocated132 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token129, i32 1, i32 1) ; (%rs4gc.s10.relocated112, %rs4gc.s10.relocated112)
  br label %pic.merge.98

pic.hit.inline.102:                               ; preds = %pic.hit.84
  %r433 = shl i64 %r425, 3
  %r434 = add nuw nsw i64 %r389, 16
  %r435 = add i64 %r434, %r433
  %r436 = inttoptr i64 %r435 to ptr
  %r437 = load double, ptr %r436, align 8
  %r438 = bitcast double %r437 to i64
  %r439 = icmp eq i64 %r438, 9222246136947933200
  br i1 %r439, label %pic.miss.95, label %pic.hit.live.85

pic.ways.103:                                     ; preds = %pic.miss.95
  %r479 = getelementptr i64, ptr %r409, i64 4
  %r480 = load i64, ptr %r479, align 8
  %r481 = icmp eq i64 %r480, %r418
  %r482 = getelementptr i64, ptr %r409, i64 5
  %r483 = load i64, ptr %r482, align 8
  %r484 = select i1 %r481, i64 %r483, i64 0
  %r485 = getelementptr i64, ptr %r409, i64 6
  %r486 = load i64, ptr %r485, align 8
  %r487 = icmp eq i64 %r486, %r418
  %r488 = getelementptr i64, ptr %r409, i64 7
  %r489 = load i64, ptr %r488, align 8
  %r490 = select i1 %r487, i64 %r489, i64 0
  %r491 = getelementptr i64, ptr %r409, i64 8
  %r492 = load i64, ptr %r491, align 8
  %r493 = icmp eq i64 %r492, %r418
  %r494 = getelementptr i64, ptr %r409, i64 9
  %r495 = load i64, ptr %r494, align 8
  %r496 = select i1 %r493, i64 %r495, i64 0
  %r497 = getelementptr i64, ptr %r409, i64 10
  %r498 = load i64, ptr %r497, align 8
  %r499 = icmp eq i64 %r498, %r418
  %r500 = getelementptr i64, ptr %r409, i64 11
  %r501 = load i64, ptr %r500, align 8
  %r502 = select i1 %r499, i64 %r501, i64 0
  %r503 = or i1 %r481, %r487
  %r504 = select i1 %r481, i64 %r484, i64 %r490
  %r505 = or i1 %r493, %r499
  %r506 = select i1 %r493, i64 %r496, i64 %r502
  %r507 = or i1 %r503, %r505
  %r508 = select i1 %r503, i64 %r504, i64 %r506
  %r509 = and i1 %r419, %r507
  br i1 %r509, label %pic.way.load.104, label %pic.miss.call.97

pic.way.load.104:                                 ; preds = %pic.ways.103
  %r510 = shl i64 %r508, 3
  %r511 = add nuw nsw i64 %r389, 16
  %r512 = add i64 %r511, %r510
  %r513 = inttoptr i64 %r512 to ptr
  %r514 = load double, ptr %r513, align 8
  %r515 = bitcast double %r514 to i64
  %r516 = icmp eq i64 %r515, 9222246136947933200
  br i1 %r516, label %pic.miss.call.97, label %pic.way.live.105

pic.way.live.105:                                 ; preds = %pic.way.load.104
  br label %pic.merge.98

pget.throw_nullish.106:                           ; preds = %pget.recv_bad.79
  %r525 = zext i1 %r523 to i32
  %statepoint_token133 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r525, ptr @test_json_string_emitters_ts_.str.0.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.107:                       ; preds = %pget.recv_bad.79
  %r526 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r527 = bitcast double %r526 to i64
  %r528 = and i64 %r527, 281474976710655
  %statepoint_token134 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r388, i64 %r528, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated111, ptr addrspace(1) %rs4gc.s10.relocated112) ]
  %r529135 = call double @llvm.experimental.gc.result.f64(token %statepoint_token134)
  %rs4gc.s13.relocated136 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token134, i32 0, i32 0) ; (%rs4gc.s13.relocated111, %rs4gc.s13.relocated111)
  %rs4gc.s10.relocated137 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token134, i32 1, i32 1) ; (%rs4gc.s10.relocated112, %rs4gc.s10.relocated112)
  br label %pget.recv_merge.81

put.dynic.guard.108:                              ; preds = %pget.recv_merge.81
  %r560 = sub nuw nsw i64 %r547, 8
  %r561 = inttoptr i64 %r560 to ptr
  %r562 = load i8, ptr %r561, align 1
  %r563 = icmp eq i8 %r562, 2
  %r564 = sub nuw nsw i64 %r547, 7
  %r565 = inttoptr i64 %r564 to ptr
  %r566 = load i8, ptr %r565, align 1
  %r567 = and i8 %r566, -128
  %r568 = icmp eq i8 %r567, 0
  %r569 = sub nuw nsw i64 %r547, 6
  %r570 = inttoptr i64 %r569 to ptr
  %r571 = load i16, ptr %r570, align 2
  %r572 = and i16 %r571, 6535
  %r573 = icmp eq i16 %r572, 0
  %r574 = add nuw nsw i64 %r547, 0
  %r575 = inttoptr i64 %r574 to ptr
  %r576 = load i32, ptr %r575, align 4
  %r577 = icmp ne i32 %r576, 0
  %r578 = icmp ne i32 %r576, -2
  %r579 = and i16 %r571, 512
  %r580 = icmp ne i16 %r579, 0
  %r581 = or i1 %r577, %r580
  %r582 = add nuw nsw i64 %r547, 4
  %r583 = inttoptr i64 %r582 to ptr
  %r584 = load i32, ptr %r583, align 4
  %r585 = add i32 %r584, -2147483648
  %r586 = icmp ult i32 %r585, 1073741824
  %r587 = zext i32 %r584 to i64
  %r588 = or i64 %r587, 4611686018427387904
  %r589 = select i1 %r586, i64 %r588, i64 0
  %r590 = getelementptr i64, ptr %r541, i64 0
  %r591 = load i64, ptr %r590, align 8
  %r592 = icmp eq i64 %r589, %r591
  %r593 = icmp ne i64 %r589, 0
  %r594 = and i1 %r563, %r568
  %r595 = and i1 %r594, %r573
  %r596 = and i1 %r595, %r581
  %r597 = and i1 %r596, %r578
  %r598 = and i1 %r592, %r593
  %r599 = and i1 %r597, %r598
  br i1 %r599, label %put.dynic.ways.109, label %put.dynic.trans.gate.117

put.dynic.ways.109:                               ; preds = %put.dynic.guard.108
  %r601 = getelementptr i64, ptr %r539, i64 1
  %r602 = load i64, ptr %r601, align 8
  %r603 = getelementptr i64, ptr %r539, i64 2
  %r604 = load i64, ptr %r603, align 8
  %r605 = icmp eq i64 %r544, %r602
  br i1 %r605, label %put.dynic.store.112, label %put.dynic.way1.110

put.dynic.way1.110:                               ; preds = %put.dynic.ways.109
  %r606 = getelementptr i64, ptr %r539, i64 3
  %r607 = load i64, ptr %r606, align 8
  %r608 = getelementptr i64, ptr %r539, i64 4
  %r609 = load i64, ptr %r608, align 8
  %r610 = icmp eq i64 %r544, %r607
  br i1 %r610, label %put.dynic.store.112, label %put.dynic.way2.111

put.dynic.way2.111:                               ; preds = %put.dynic.way1.110
  %r611 = getelementptr i64, ptr %r539, i64 5
  %r612 = load i64, ptr %r611, align 8
  %r613 = getelementptr i64, ptr %r539, i64 6
  %r614 = load i64, ptr %r613, align 8
  %r615 = icmp eq i64 %r544, %r612
  br i1 %r615, label %put.dynic.store.112, label %put.dynic.trans.probe.118

put.dynic.store.112:                              ; preds = %put.dynic.way2.111, %put.dynic.way1.110, %put.dynic.ways.109
  %r616 = phi i64 [ %r604, %put.dynic.ways.109 ], [ %r609, %put.dynic.way1.110 ], [ %r614, %put.dynic.way2.111 ]
  %r617 = shl i64 %r616, 3
  %r618 = add i64 %r617, 16
  %r619 = inttoptr i64 %r547 to ptr
  %r620 = getelementptr inbounds i8, ptr %r619, i64 %r618
  %r621 = and i16 %r571, 1024
  %r622 = icmp ne i16 %r621, 0
  br i1 %r622, label %put.dynic.store.validate.113, label %put.dynic.store.dispatch.114

put.dynic.store.validate.113:                     ; preds = %put.dynic.store.112
  %r623 = load double, ptr %r620, align 8
  %r624 = bitcast double %r623 to i64
  %r625 = icmp eq i64 %r624, 9222246136947933200
  br i1 %r625, label %put.dynic.slow.126, label %put.dynic.store.dispatch.114

put.dynic.store.dispatch.114:                     ; preds = %put.dynic.store.validate.113, %put.dynic.store.112
  br i1 %r556, label %put.dynic.store.scalar.115, label %put.dynic.store.ref.116

put.dynic.store.scalar.115:                       ; preds = %put.dynic.store.dispatch.114
  store double %r536122, ptr %r620, align 8
  br label %put.dynic.merge.127

put.dynic.store.ref.116:                          ; preds = %put.dynic.store.dispatch.114
  %r626 = trunc i64 %r616 to i32
  %r627 = shl i64 %r616, 3
  %r628 = add nuw nsw i64 %r547, 16
  %r629 = add i64 %r628, %r627
  %r630 = load double, ptr %r620, align 8
  %r631 = bitcast double %r630 to i64
  store double %r536122, ptr %r620, align 8
  call void @js_string_addref_if_heap_string(double %r536122) #9
  %r632 = bitcast double %r536122 to i64
  %r2713.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated123 to i64
  %r2713.rs4o = call i64 asm "", "=r,0"(i64 %r2713.rs4i) #9
  %r2713 = bitcast i64 %r2713.rs4o to double
  %r2714 = bitcast double %r2713 to i64
  %r2715 = and i64 %r2714, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r2715, i32 %r626, i64 %r632, i64 %r631) #9
  %r2711.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated123 to i64
  %r2711.rs4o = call i64 asm "", "=r,0"(i64 %r2711.rs4i) #9
  %r2711 = bitcast i64 %r2711.rs4o to double
  %r2712 = bitcast double %r2711 to i64
  call void @js_write_barrier_slot(i64 %r2712, i64 %r629, i64 %r632) #9
  br label %put.dynic.merge.127

put.dynic.trans.gate.117:                         ; preds = %put.dynic.guard.108
  %r600 = and i1 %r597, %r593
  br i1 %r600, label %put.dynic.trans.probe.118, label %put.dynic.slow.126

put.dynic.trans.probe.118:                        ; preds = %put.dynic.trans.gate.117, %put.dynic.way2.111
  %r633 = lshr i64 %r544, 48
  %r634 = icmp eq i64 %r633, 32767
  %r635 = and i64 %r544, 281474976710655
  %r636 = icmp ugt i64 %r635, 1048575
  %r637 = and i16 %r571, -16384
  %r638 = icmp eq i16 %r637, 0
  %r639 = and i8 %r566, 32
  %r640 = icmp eq i8 %r639, 0
  %r641 = and i1 %r634, %r636
  %r642 = and i1 %r641, %r638
  %r643 = and i1 %r642, %r640
  br i1 %r643, label %put.dynic.trans.key.119, label %put.dynic.slow.126

put.dynic.trans.key.119:                          ; preds = %put.dynic.trans.probe.118
  %r644 = and i64 %r544, 281474976710655
  %r645 = add nuw nsw i64 %r644, 4
  %r646 = inttoptr i64 %r645 to ptr
  %r647 = load i32, ptr %r646, align 4
  %r648 = icmp uge i32 %r647, 6
  %r649 = icmp ule i32 %r647, 8
  %r650 = add nuw nsw i64 %r644, 20
  %r651 = inttoptr i64 %r650 to ptr
  %r652 = load i8, ptr %r651, align 1
  %r653 = sub i8 %r652, 48
  %r654 = icmp ult i8 %r653, 10
  %r655 = icmp eq i1 %r654, false
  %r656 = and i1 %r648, %r649
  %r657 = and i1 %r656, %r655
  br i1 %r657, label %put.dynic.trans.entry.120, label %put.dynic.slow.126

put.dynic.trans.entry.120:                        ; preds = %put.dynic.trans.key.119
  %r658 = add nuw nsw i64 %r644, 20
  %r659 = inttoptr i64 %r658 to ptr
  %r660 = load i64, ptr %r659, align 8
  %r661 = zext nneg i32 %r647 to i64
  %r662 = sub nuw nsw i64 8, %r661
  %r663 = shl nuw nsw i64 %r662, 3
  %r664 = lshr i64 -1, %r663
  %r665 = and i64 %r660, %r664
  %r667 = ptrtoint ptr %r543 to i64
  %r668 = zext i32 %r584 to i64
  %r669 = mul i64 %r668, -7046029254386353131
  %r670 = lshr i64 %r665, 3
  %r671 = mul i64 %r670, -4126379630918253789
  %r672 = xor i64 %r669, %r671
  %r673 = and i64 %r672, 16383
  %r674 = shl nuw nsw i64 %r673, 5
  %r675 = add i64 %r667, %r674
  %r676 = inttoptr i64 %r675 to ptr
  %r677 = load i64, ptr %r676, align 8
  %r678 = add i64 %r675, 8
  %r679 = inttoptr i64 %r678 to ptr
  %r680 = load i64, ptr %r679, align 8
  %r681 = add i64 %r675, 16
  %r682 = inttoptr i64 %r681 to ptr
  %r683 = load i32, ptr %r682, align 4
  %r684 = add i64 %r675, 20
  %r685 = inttoptr i64 %r684 to ptr
  %r686 = load i32, ptr %r685, align 4
  %r687 = add i64 %r675, 24
  %r688 = inttoptr i64 %r687 to ptr
  %r689 = load i32, ptr %r688, align 4
  %r690 = lshr i32 %r689, 24
  %r691 = and i32 %r689, 16777215
  %r692 = add i64 %r675, 28
  %r693 = inttoptr i64 %r692 to ptr
  %r694 = load i32, ptr %r693, align 4
  %r695 = icmp eq i64 %r677, %r665
  %r696 = icmp eq i32 %r690, %r647
  %r697 = icmp eq i32 %r683, %r584
  %r698 = icmp ne i64 %r680, 0
  %r699 = add nuw nsw i32 %r691, 1
  %r700 = icmp eq i32 %r694, %r699
  %r701 = zext nneg i32 %r691 to i64
  %r702 = and i64 %r545, 281474976710655
  %r703 = icmp eq i64 %r551, 32765
  %r704 = icmp eq i64 %r702, 0
  %r705 = and i1 %r703, %r704
  %r706 = select i1 %r705, i64 9222246136947933185, i64 %r545
  %r707 = bitcast i64 %r706 to double
  %r708 = and i1 %r695, %r696
  %r709 = and i1 %r708, %r697
  %r710 = and i1 %r709, %r698
  %r711 = and i1 %r710, %r700
  br i1 %r711, label %put.dynic.trans.nk.121, label %put.dynic.slow.126

put.dynic.trans.nk.121:                           ; preds = %put.dynic.trans.entry.120
  %r712 = inttoptr i64 %r680 to ptr
  %r713 = load i32, ptr %r712, align 4
  %r714 = icmp eq i32 %r713, %r699
  br i1 %r714, label %put.dynic.trans.dispatch.122, label %put.dynic.slow.126

put.dynic.trans.dispatch.122:                     ; preds = %put.dynic.trans.nk.121
  %r715 = icmp ult i64 %r701, 2
  br i1 %r715, label %put.dynic.trans.inline_ref.123, label %put.dynic.trans.ovf.124

put.dynic.trans.inline_ref.123:                   ; preds = %put.dynic.trans.dispatch.122
  %r716 = shl nuw nsw i64 %r701, 3
  %r717 = add nuw nsw i64 %r716, 16
  %r718 = add nuw nsw i64 %r547, %r717
  %r719 = inttoptr i64 %r718 to ptr
  %r720 = trunc nuw nsw i64 %r701 to i32
  %r721 = load double, ptr %r719, align 8
  %r722 = bitcast double %r721 to i64
  store double %r707, ptr %r719, align 8
  call void @js_string_addref_if_heap_string(double %r707) #9
  %r723 = bitcast double %r707 to i64
  %r2708.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated123 to i64
  %r2708.rs4o = call i64 asm "", "=r,0"(i64 %r2708.rs4i) #9
  %r2708 = bitcast i64 %r2708.rs4o to double
  %r2709 = bitcast double %r2708 to i64
  %r2710 = and i64 %r2709, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r2710, i32 %r720, i64 %r723, i64 %r722) #9
  %r2706.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated123 to i64
  %r2706.rs4o = call i64 asm "", "=r,0"(i64 %r2706.rs4i) #9
  %r2706 = bitcast i64 %r2706.rs4o to double
  %r2707 = bitcast double %r2706 to i64
  call void @js_write_barrier_slot(i64 %r2707, i64 %r718, i64 %r723) #9
  br label %put.dynic.trans.stamp.125

put.dynic.trans.ovf.124:                          ; preds = %put.dynic.trans.dispatch.122
  %r724 = trunc nuw nsw i64 %r701 to i32
  %r725 = call i32 @js_transition_ic_spill_append(double %r538, i64 %r589, i32 %r724, double %r707) #9
  %r726 = icmp ne i32 %r725, 0
  br i1 %r726, label %put.dynic.trans.stamp.125, label %put.dynic.slow.126

put.dynic.trans.stamp.125:                        ; preds = %put.dynic.trans.ovf.124, %put.dynic.trans.inline_ref.123
  %r2703.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated123 to i64
  %r2703.rs4o = call i64 asm "", "=r,0"(i64 %r2703.rs4i) #9
  %r2703 = bitcast i64 %r2703.rs4o to double
  %r2704 = bitcast double %r2703 to i64
  %r2705 = and i64 %r2704, 281474976710655
  %r727 = add nuw nsw i64 %r2705, 4
  %r728 = inttoptr i64 %r727 to ptr
  store i32 %r686, ptr %r728, align 4
  br label %put.dynic.merge.127

put.dynic.slow.126:                               ; preds = %put.dynic.trans.ovf.124, %put.dynic.trans.nk.121, %put.dynic.trans.entry.120, %put.dynic.trans.key.119, %put.dynic.trans.probe.118, %put.dynic.trans.gate.117, %put.dynic.store.validate.113, %pget.recv_merge.81
  %statepoint_token138 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, double, double, i32)) @js_put_value_set_dyn_ic, i32 5, i32 0, ptr @perry_ic_test_json_string_emitters_ts__18, double %r538, double %r537, double %r536122, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated123, ptr addrspace(1) %rs4gc.s10.relocated124) ]
  %r729139 = call double @llvm.experimental.gc.result.f64(token %statepoint_token138)
  %rs4gc.s13.relocated140 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token138, i32 0, i32 0) ; (%rs4gc.s13.relocated123, %rs4gc.s13.relocated123)
  %rs4gc.s10.relocated141 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token138, i32 1, i32 1) ; (%rs4gc.s10.relocated124, %rs4gc.s10.relocated124)
  br label %put.dynic.merge.127

put.dynic.merge.127:                              ; preds = %put.dynic.slow.126, %put.dynic.trans.stamp.125, %put.dynic.store.ref.116, %put.dynic.store.scalar.115
  %.2525 = phi ptr addrspace(1) [ %rs4gc.s13.relocated140, %put.dynic.slow.126 ], [ %rs4gc.s13.relocated123, %put.dynic.store.scalar.115 ], [ %rs4gc.s13.relocated123, %put.dynic.store.ref.116 ], [ %rs4gc.s13.relocated123, %put.dynic.trans.stamp.125 ]
  %.7 = phi ptr addrspace(1) [ %rs4gc.s10.relocated141, %put.dynic.slow.126 ], [ %rs4gc.s10.relocated124, %put.dynic.store.scalar.115 ], [ %rs4gc.s10.relocated124, %put.dynic.store.ref.116 ], [ %rs4gc.s10.relocated124, %put.dynic.trans.stamp.125 ]
  %r730 = phi double [ %r536122, %put.dynic.store.scalar.115 ], [ %r536122, %put.dynic.store.ref.116 ], [ %r707, %put.dynic.trans.stamp.125 ], [ %r729139, %put.dynic.slow.126 ]
  %r731 = load double, ptr @test_json_string_emitters_ts_.str.5.handle, align 8
  %r732.rs4i = ptrtoint ptr addrspace(1) %.2525 to i64
  %r732.rs4o = call i64 asm "", "=r,0"(i64 %r732.rs4i) #9
  %r732 = bitcast i64 %r732.rs4o to double
  %r733 = bitcast double %r732 to i64
  %r734 = and i64 %r733, 281474976710655
  %r735 = lshr i64 %r733, 48
  %r736 = and i64 %r735, 65533
  %r737 = icmp eq i64 %r736, 32765
  br i1 %r737, label %pget.recv_ok.129, label %pget.recv_other.133

pget.recv_sso.128:                                ; preds = %pget.recv_other.133
  %r875 = load double, ptr @test_json_string_emitters_ts_.str.5.handle, align 8
  %r876 = bitcast double %r875 to i64
  %r877 = and i64 %r876, 281474976710655
  %statepoint_token142 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r733, i64 %r877, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2525, ptr addrspace(1) %.7) ]
  %r878143 = call double @llvm.experimental.gc.result.f64(token %statepoint_token142)
  %rs4gc.s13.relocated144 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token142, i32 0, i32 0) ; (%.2525, %.2525)
  %rs4gc.s10.relocated145 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token142, i32 1, i32 1) ; (%.7, %.7)
  br label %pget.recv_merge.132

pget.recv_ok.129:                                 ; preds = %put.dynic.merge.127
  %r744 = icmp ugt i64 %r734, 1048575
  br i1 %r744, label %pic.recv_hdr.150, label %pic.miss.cold.147

pget.recv_bad.130:                                ; preds = %pget.check_class_ref.134
  %r867 = icmp eq i64 %r733, 9222246136947933185
  %r868 = icmp eq i64 %r733, 9222246136947933186
  %r869 = or i1 %r867, %r868
  br i1 %r869, label %pget.throw_nullish.157, label %pget.recv_undef_return.158

pget.recv_class_ref.131:                          ; preds = %pget.check_class_ref.134
  %r740 = load double, ptr @test_json_string_emitters_ts_.str.5.handle, align 8
  %r741 = bitcast double %r740 to i64
  %r742 = and i64 %r741, 281474976710655
  %statepoint_token146 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6553530643794362387, i64 %r733, i64 %r742, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2525, ptr addrspace(1) %.7) ]
  %r743147 = call double @llvm.experimental.gc.result.f64(token %statepoint_token146)
  %rs4gc.s13.relocated148 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token146, i32 0, i32 0) ; (%.2525, %.2525)
  %rs4gc.s10.relocated149 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token146, i32 1, i32 1) ; (%.7, %.7)
  br label %pget.recv_merge.132

pget.recv_merge.132:                              ; preds = %pget.recv_undef_return.158, %pic.merge.149, %pget.recv_class_ref.131, %pget.recv_sso.128
  %.3526 = phi ptr addrspace(1) [ %.4527, %pic.merge.149 ], [ %rs4gc.s13.relocated144, %pget.recv_sso.128 ], [ %rs4gc.s13.relocated148, %pget.recv_class_ref.131 ], [ %rs4gc.s13.relocated165, %pget.recv_undef_return.158 ]
  %.8 = phi ptr addrspace(1) [ %.9, %pic.merge.149 ], [ %rs4gc.s10.relocated145, %pget.recv_sso.128 ], [ %rs4gc.s10.relocated149, %pget.recv_class_ref.131 ], [ %rs4gc.s10.relocated166, %pget.recv_undef_return.158 ]
  %r879 = phi double [ %r866, %pic.merge.149 ], [ %r874164, %pget.recv_undef_return.158 ], [ %r878143, %pget.recv_sso.128 ], [ %r743147, %pget.recv_class_ref.131 ]
  %r880 = load double, ptr @test_json_string_emitters_ts_.str.23.handle, align 8
  %statepoint_token150 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r879, double %r880, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3526, ptr addrspace(1) %.8) ]
  %r881151 = call double @llvm.experimental.gc.result.f64(token %statepoint_token150)
  %rs4gc.s13.relocated152 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token150, i32 0, i32 0) ; (%.3526, %.3526)
  %rs4gc.s10.relocated153 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token150, i32 1, i32 1) ; (%.8, %.8)
  %r882 = load double, ptr @test_json_string_emitters_ts_.str.5.handle, align 8
  %r883.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated152 to i64
  %r883.rs4o = call i64 asm "", "=r,0"(i64 %r883.rs4i) #9
  %r883 = bitcast i64 %r883.rs4o to double
  %r884 = load ptr, ptr @perry_ic_test_json_string_emitters_ts__21, align 8
  %r885 = icmp ne ptr %r884, null
  %r886 = select i1 %r885, ptr %r884, ptr @perry_ic_test_json_string_emitters_ts__21
  %r887 = bitcast double %r882 to i64
  %r888 = bitcast double %r881151 to i64
  %r889 = bitcast double %r883 to i64
  %r890 = and i64 %r889, 281474976710655
  %r891 = lshr i64 %r889, 48
  %r892 = icmp eq i64 %r891, 32765
  %r893 = icmp ugt i64 %r890, 1048575
  %r894 = lshr i64 %r888, 48
  %r895 = icmp ne i64 %r894, 32765
  %r896 = icmp ne i64 %r894, 32767
  %r897 = icmp ne i64 %r894, 32762
  %r898 = and i1 %r895, %r896
  %r899 = and i1 %r898, %r897
  %r900 = icmp ne i64 %r887, 0
  %r901 = and i1 %r892, %r893
  %r902 = and i1 %r901, %r900
  br i1 %r902, label %put.dynic.guard.159, label %put.dynic.slow.177

pget.recv_other.133:                              ; preds = %put.dynic.merge.127
  %r738 = icmp eq i64 %r735, 32761
  br i1 %r738, label %pget.recv_sso.128, label %pget.check_class_ref.134

pget.check_class_ref.134:                         ; preds = %pget.recv_other.133
  %r739 = icmp eq i64 %r735, 32766
  br i1 %r739, label %pget.recv_class_ref.131, label %pget.recv_bad.130

pic.hit.135:                                      ; preds = %pic.token.151
  %r769 = getelementptr i64, ptr %r754, i64 1
  %r770 = load i64, ptr %r769, align 8
  %r771 = and i64 %r770, 1073741824
  %r772 = icmp ne i64 %r771, 0
  br i1 %r772, label %pic.hit.overflow.152, label %pic.hit.inline.153

pic.hit.live.136:                                 ; preds = %pic.hit.inline.153
  br label %pic.merge.149

pic.prefix.guard.137:                             ; preds = %pic.token.151
  %r785 = getelementptr i64, ptr %r754, i64 2
  %r786 = load i64, ptr %r785, align 8
  %r787 = icmp ne i64 %r786, 0
  br i1 %r787, label %pic.prefix.meta.138, label %pic.miss.146

pic.prefix.meta.138:                              ; preds = %pic.prefix.guard.137
  %r788 = add nuw nsw i64 %r734, 8
  %r789 = inttoptr i64 %r788 to ptr
  %r790 = load i64, ptr %r789, align 8
  %r791 = icmp ne i64 %r790, 0
  br i1 %r791, label %pic.prefix.token.139, label %pic.miss.146

pic.prefix.token.139:                             ; preds = %pic.prefix.meta.138
  %r792 = inttoptr i64 %r790 to ptr
  %r793 = getelementptr i64, ptr %r792, i64 6
  %r794 = load i64, ptr %r793, align 8
  %r795 = icmp eq i64 %r794, %r786
  br i1 %r795, label %pic.prefix.hit.140, label %pic.miss.146

pic.prefix.hit.140:                               ; preds = %pic.prefix.token.139
  %r796 = getelementptr i64, ptr %r754, i64 1
  %r797 = load i64, ptr %r796, align 8
  %r798 = shl i64 %r797, 3
  %r799 = add nuw nsw i64 %r734, 16
  %r800 = add i64 %r799, %r798
  %r801 = inttoptr i64 %r800 to ptr
  %r802 = load double, ptr %r801, align 8
  br label %pic.merge.149

pic.desc.classify.141:                            ; preds = %pic.recv_hdr.150
  %r758 = and i1 %r748, %r755
  br i1 %r758, label %pic.desc.prefix.guard.142, label %pic.miss.cold.147

pic.desc.prefix.guard.142:                        ; preds = %pic.desc.classify.141
  %r803 = getelementptr i64, ptr %r754, i64 2
  %r804 = load i64, ptr %r803, align 8
  %r805 = icmp ne i64 %r804, 0
  br i1 %r805, label %pic.desc.prefix.meta.143, label %pic.miss.cold.147

pic.desc.prefix.meta.143:                         ; preds = %pic.desc.prefix.guard.142
  %r806 = add nuw nsw i64 %r734, 8
  %r807 = inttoptr i64 %r806 to ptr
  %r808 = load i64, ptr %r807, align 8
  %r809 = icmp ne i64 %r808, 0
  br i1 %r809, label %pic.desc.prefix.token.144, label %pic.miss.cold.147

pic.desc.prefix.token.144:                        ; preds = %pic.desc.prefix.meta.143
  %r810 = inttoptr i64 %r808 to ptr
  %r811 = getelementptr i64, ptr %r810, i64 6
  %r812 = load i64, ptr %r811, align 8
  %r813 = icmp eq i64 %r812, %r804
  br i1 %r813, label %pic.desc.prefix.hit.145, label %pic.miss.cold.147

pic.desc.prefix.hit.145:                          ; preds = %pic.desc.prefix.token.144
  %r814 = getelementptr i64, ptr %r754, i64 1
  %r815 = load i64, ptr %r814, align 8
  %r816 = shl i64 %r815, 3
  %r817 = add nuw nsw i64 %r734, 16
  %r818 = add i64 %r817, %r816
  %r819 = inttoptr i64 %r818 to ptr
  %r820 = load double, ptr %r819, align 8
  br label %pic.merge.149

pic.miss.146:                                     ; preds = %pic.hit.inline.153, %pic.prefix.token.139, %pic.prefix.meta.138, %pic.prefix.guard.137
  %r821 = getelementptr i64, ptr %r754, i64 3
  %r822 = load i64, ptr %r821, align 8
  %r823 = icmp sgt i64 %r822, 0
  br i1 %r823, label %pic.ways.154, label %pic.miss.call.148

pic.miss.cold.147:                                ; preds = %pic.desc.prefix.token.144, %pic.desc.prefix.meta.143, %pic.desc.prefix.guard.142, %pic.desc.classify.141, %pget.recv_ok.129
  br label %pic.miss.call.148

pic.miss.call.148:                                ; preds = %pic.way.load.155, %pic.ways.154, %pic.miss.cold.147, %pic.miss.146
  %r862 = load double, ptr @test_json_string_emitters_ts_.str.5.handle, align 8
  %r863 = bitcast double %r862 to i64
  %r864 = and i64 %r863, 281474976710655
  %statepoint_token154 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r734, i64 %r864, ptr @perry_ic_test_json_string_emitters_ts__20, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2525, ptr addrspace(1) %.7) ]
  %r865155 = call double @llvm.experimental.gc.result.f64(token %statepoint_token154)
  %rs4gc.s13.relocated156 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token154, i32 0, i32 0) ; (%.2525, %.2525)
  %rs4gc.s10.relocated157 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token154, i32 1, i32 1) ; (%.7, %.7)
  br label %pic.merge.149

pic.merge.149:                                    ; preds = %pic.way.live.156, %pic.hit.overflow.152, %pic.miss.call.148, %pic.desc.prefix.hit.145, %pic.prefix.hit.140, %pic.hit.live.136
  %.4527 = phi ptr addrspace(1) [ %rs4gc.s13.relocated160, %pic.hit.overflow.152 ], [ %rs4gc.s13.relocated156, %pic.miss.call.148 ], [ %.2525, %pic.way.live.156 ], [ %.2525, %pic.hit.live.136 ], [ %.2525, %pic.prefix.hit.140 ], [ %.2525, %pic.desc.prefix.hit.145 ]
  %.9 = phi ptr addrspace(1) [ %rs4gc.s10.relocated161, %pic.hit.overflow.152 ], [ %rs4gc.s10.relocated157, %pic.miss.call.148 ], [ %.7, %pic.way.live.156 ], [ %.7, %pic.hit.live.136 ], [ %.7, %pic.prefix.hit.140 ], [ %.7, %pic.desc.prefix.hit.145 ]
  %r866 = phi double [ %r782, %pic.hit.live.136 ], [ %r777159, %pic.hit.overflow.152 ], [ %r802, %pic.prefix.hit.140 ], [ %r820, %pic.desc.prefix.hit.145 ], [ %r859, %pic.way.live.156 ], [ %r865155, %pic.miss.call.148 ]
  br label %pget.recv_merge.132

pic.recv_hdr.150:                                 ; preds = %pget.recv_ok.129
  %r745 = sub nuw nsw i64 %r734, 8
  %r746 = inttoptr i64 %r745 to ptr
  %r747 = load i8, ptr %r746, align 1
  %r748 = icmp eq i8 %r747, 2
  %r749 = sub nuw nsw i64 %r734, 6
  %r750 = inttoptr i64 %r749 to ptr
  %r751 = load i16, ptr %r750, align 2
  %r752 = and i16 %r751, 2048
  %r753 = icmp eq i16 %r752, 0
  %r754 = load ptr, ptr @perry_ic_test_json_string_emitters_ts__20, align 8
  %r755 = icmp ne ptr %r754, null
  %r756 = and i1 %r748, %r753
  %r757 = and i1 %r756, %r755
  br i1 %r757, label %pic.token.151, label %pic.desc.classify.141

pic.token.151:                                    ; preds = %pic.recv_hdr.150
  %r759 = add nuw nsw i64 %r734, 4
  %r760 = inttoptr i64 %r759 to ptr
  %r761 = load i32, ptr %r760, align 4
  %r762 = zext i32 %r761 to i64
  %r763 = or i64 %r762, 4611686018427387904
  %r764 = icmp ne i32 %r761, 0
  %r765 = getelementptr i64, ptr %r754, i64 0
  %r766 = load i64, ptr %r765, align 8
  %r767 = icmp eq i64 %r763, %r766
  %r768 = and i1 %r767, %r764
  br i1 %r768, label %pic.hit.135, label %pic.prefix.guard.137

pic.hit.overflow.152:                             ; preds = %pic.hit.135
  %r773 = load double, ptr @test_json_string_emitters_ts_.str.5.handle, align 8
  %r774 = bitcast double %r773 to i64
  %r775 = and i64 %r774, 281474976710655
  %r776 = trunc i64 %r770 to i32
  %statepoint_token158 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r734, i64 %r775, i32 %r776, ptr @perry_ic_test_json_string_emitters_ts__20, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2525, ptr addrspace(1) %.7) ]
  %r777159 = call double @llvm.experimental.gc.result.f64(token %statepoint_token158)
  %rs4gc.s13.relocated160 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token158, i32 0, i32 0) ; (%.2525, %.2525)
  %rs4gc.s10.relocated161 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token158, i32 1, i32 1) ; (%.7, %.7)
  br label %pic.merge.149

pic.hit.inline.153:                               ; preds = %pic.hit.135
  %r778 = shl i64 %r770, 3
  %r779 = add nuw nsw i64 %r734, 16
  %r780 = add i64 %r779, %r778
  %r781 = inttoptr i64 %r780 to ptr
  %r782 = load double, ptr %r781, align 8
  %r783 = bitcast double %r782 to i64
  %r784 = icmp eq i64 %r783, 9222246136947933200
  br i1 %r784, label %pic.miss.146, label %pic.hit.live.136

pic.ways.154:                                     ; preds = %pic.miss.146
  %r824 = getelementptr i64, ptr %r754, i64 4
  %r825 = load i64, ptr %r824, align 8
  %r826 = icmp eq i64 %r825, %r763
  %r827 = getelementptr i64, ptr %r754, i64 5
  %r828 = load i64, ptr %r827, align 8
  %r829 = select i1 %r826, i64 %r828, i64 0
  %r830 = getelementptr i64, ptr %r754, i64 6
  %r831 = load i64, ptr %r830, align 8
  %r832 = icmp eq i64 %r831, %r763
  %r833 = getelementptr i64, ptr %r754, i64 7
  %r834 = load i64, ptr %r833, align 8
  %r835 = select i1 %r832, i64 %r834, i64 0
  %r836 = getelementptr i64, ptr %r754, i64 8
  %r837 = load i64, ptr %r836, align 8
  %r838 = icmp eq i64 %r837, %r763
  %r839 = getelementptr i64, ptr %r754, i64 9
  %r840 = load i64, ptr %r839, align 8
  %r841 = select i1 %r838, i64 %r840, i64 0
  %r842 = getelementptr i64, ptr %r754, i64 10
  %r843 = load i64, ptr %r842, align 8
  %r844 = icmp eq i64 %r843, %r763
  %r845 = getelementptr i64, ptr %r754, i64 11
  %r846 = load i64, ptr %r845, align 8
  %r847 = select i1 %r844, i64 %r846, i64 0
  %r848 = or i1 %r826, %r832
  %r849 = select i1 %r826, i64 %r829, i64 %r835
  %r850 = or i1 %r838, %r844
  %r851 = select i1 %r838, i64 %r841, i64 %r847
  %r852 = or i1 %r848, %r850
  %r853 = select i1 %r848, i64 %r849, i64 %r851
  %r854 = and i1 %r764, %r852
  br i1 %r854, label %pic.way.load.155, label %pic.miss.call.148

pic.way.load.155:                                 ; preds = %pic.ways.154
  %r855 = shl i64 %r853, 3
  %r856 = add nuw nsw i64 %r734, 16
  %r857 = add i64 %r856, %r855
  %r858 = inttoptr i64 %r857 to ptr
  %r859 = load double, ptr %r858, align 8
  %r860 = bitcast double %r859 to i64
  %r861 = icmp eq i64 %r860, 9222246136947933200
  br i1 %r861, label %pic.miss.call.148, label %pic.way.live.156

pic.way.live.156:                                 ; preds = %pic.way.load.155
  br label %pic.merge.149

pget.throw_nullish.157:                           ; preds = %pget.recv_bad.130
  %r870 = zext i1 %r868 to i32
  %statepoint_token162 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r870, ptr @test_json_string_emitters_ts_.str.5.bytes, i64 5, i32 0, i32 0)
  unreachable

pget.recv_undef_return.158:                       ; preds = %pget.recv_bad.130
  %r871 = load double, ptr @test_json_string_emitters_ts_.str.5.handle, align 8
  %r872 = bitcast double %r871 to i64
  %r873 = and i64 %r872, 281474976710655
  %statepoint_token163 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r733, i64 %r873, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2525, ptr addrspace(1) %.7) ]
  %r874164 = call double @llvm.experimental.gc.result.f64(token %statepoint_token163)
  %rs4gc.s13.relocated165 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token163, i32 0, i32 0) ; (%.2525, %.2525)
  %rs4gc.s10.relocated166 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token163, i32 1, i32 1) ; (%.7, %.7)
  br label %pget.recv_merge.132

put.dynic.guard.159:                              ; preds = %pget.recv_merge.132
  %r903 = sub nuw nsw i64 %r890, 8
  %r904 = inttoptr i64 %r903 to ptr
  %r905 = load i8, ptr %r904, align 1
  %r906 = icmp eq i8 %r905, 2
  %r907 = sub nuw nsw i64 %r890, 7
  %r908 = inttoptr i64 %r907 to ptr
  %r909 = load i8, ptr %r908, align 1
  %r910 = and i8 %r909, -128
  %r911 = icmp eq i8 %r910, 0
  %r912 = sub nuw nsw i64 %r890, 6
  %r913 = inttoptr i64 %r912 to ptr
  %r914 = load i16, ptr %r913, align 2
  %r915 = and i16 %r914, 6535
  %r916 = icmp eq i16 %r915, 0
  %r917 = add nuw nsw i64 %r890, 0
  %r918 = inttoptr i64 %r917 to ptr
  %r919 = load i32, ptr %r918, align 4
  %r920 = icmp ne i32 %r919, 0
  %r921 = icmp ne i32 %r919, -2
  %r922 = and i16 %r914, 512
  %r923 = icmp ne i16 %r922, 0
  %r924 = or i1 %r920, %r923
  %r925 = add nuw nsw i64 %r890, 4
  %r926 = inttoptr i64 %r925 to ptr
  %r927 = load i32, ptr %r926, align 4
  %r928 = add i32 %r927, -2147483648
  %r929 = icmp ult i32 %r928, 1073741824
  %r930 = zext i32 %r927 to i64
  %r931 = or i64 %r930, 4611686018427387904
  %r932 = select i1 %r929, i64 %r931, i64 0
  %r933 = getelementptr i64, ptr %r886, i64 0
  %r934 = load i64, ptr %r933, align 8
  %r935 = icmp eq i64 %r932, %r934
  %r936 = icmp ne i64 %r932, 0
  %r937 = and i1 %r906, %r911
  %r938 = and i1 %r937, %r916
  %r939 = and i1 %r938, %r924
  %r940 = and i1 %r939, %r921
  %r941 = and i1 %r935, %r936
  %r942 = and i1 %r940, %r941
  br i1 %r942, label %put.dynic.ways.160, label %put.dynic.trans.gate.168

put.dynic.ways.160:                               ; preds = %put.dynic.guard.159
  %r944 = getelementptr i64, ptr %r884, i64 1
  %r945 = load i64, ptr %r944, align 8
  %r946 = getelementptr i64, ptr %r884, i64 2
  %r947 = load i64, ptr %r946, align 8
  %r948 = icmp eq i64 %r887, %r945
  br i1 %r948, label %put.dynic.store.163, label %put.dynic.way1.161

put.dynic.way1.161:                               ; preds = %put.dynic.ways.160
  %r949 = getelementptr i64, ptr %r884, i64 3
  %r950 = load i64, ptr %r949, align 8
  %r951 = getelementptr i64, ptr %r884, i64 4
  %r952 = load i64, ptr %r951, align 8
  %r953 = icmp eq i64 %r887, %r950
  br i1 %r953, label %put.dynic.store.163, label %put.dynic.way2.162

put.dynic.way2.162:                               ; preds = %put.dynic.way1.161
  %r954 = getelementptr i64, ptr %r884, i64 5
  %r955 = load i64, ptr %r954, align 8
  %r956 = getelementptr i64, ptr %r884, i64 6
  %r957 = load i64, ptr %r956, align 8
  %r958 = icmp eq i64 %r887, %r955
  br i1 %r958, label %put.dynic.store.163, label %put.dynic.trans.probe.169

put.dynic.store.163:                              ; preds = %put.dynic.way2.162, %put.dynic.way1.161, %put.dynic.ways.160
  %r959 = phi i64 [ %r947, %put.dynic.ways.160 ], [ %r952, %put.dynic.way1.161 ], [ %r957, %put.dynic.way2.162 ]
  %r960 = shl i64 %r959, 3
  %r961 = add i64 %r960, 16
  %r962 = inttoptr i64 %r890 to ptr
  %r963 = getelementptr inbounds i8, ptr %r962, i64 %r961
  %r964 = and i16 %r914, 1024
  %r965 = icmp ne i16 %r964, 0
  br i1 %r965, label %put.dynic.store.validate.164, label %put.dynic.store.dispatch.165

put.dynic.store.validate.164:                     ; preds = %put.dynic.store.163
  %r966 = load double, ptr %r963, align 8
  %r967 = bitcast double %r966 to i64
  %r968 = icmp eq i64 %r967, 9222246136947933200
  br i1 %r968, label %put.dynic.slow.177, label %put.dynic.store.dispatch.165

put.dynic.store.dispatch.165:                     ; preds = %put.dynic.store.validate.164, %put.dynic.store.163
  br i1 %r899, label %put.dynic.store.scalar.166, label %put.dynic.store.ref.167

put.dynic.store.scalar.166:                       ; preds = %put.dynic.store.dispatch.165
  store double %r881151, ptr %r963, align 8
  br label %put.dynic.merge.178

put.dynic.store.ref.167:                          ; preds = %put.dynic.store.dispatch.165
  %r969 = trunc i64 %r959 to i32
  %r970 = shl i64 %r959, 3
  %r971 = add nuw nsw i64 %r890, 16
  %r972 = add i64 %r971, %r970
  %r973 = load double, ptr %r963, align 8
  %r974 = bitcast double %r973 to i64
  store double %r881151, ptr %r963, align 8
  call void @js_string_addref_if_heap_string(double %r881151) #9
  %r975 = bitcast double %r881151 to i64
  %r2700.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated152 to i64
  %r2700.rs4o = call i64 asm "", "=r,0"(i64 %r2700.rs4i) #9
  %r2700 = bitcast i64 %r2700.rs4o to double
  %r2701 = bitcast double %r2700 to i64
  %r2702 = and i64 %r2701, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r2702, i32 %r969, i64 %r975, i64 %r974) #9
  %r2698.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated152 to i64
  %r2698.rs4o = call i64 asm "", "=r,0"(i64 %r2698.rs4i) #9
  %r2698 = bitcast i64 %r2698.rs4o to double
  %r2699 = bitcast double %r2698 to i64
  call void @js_write_barrier_slot(i64 %r2699, i64 %r972, i64 %r975) #9
  br label %put.dynic.merge.178

put.dynic.trans.gate.168:                         ; preds = %put.dynic.guard.159
  %r943 = and i1 %r940, %r936
  br i1 %r943, label %put.dynic.trans.probe.169, label %put.dynic.slow.177

put.dynic.trans.probe.169:                        ; preds = %put.dynic.trans.gate.168, %put.dynic.way2.162
  %r976 = lshr i64 %r887, 48
  %r977 = icmp eq i64 %r976, 32767
  %r978 = and i64 %r887, 281474976710655
  %r979 = icmp ugt i64 %r978, 1048575
  %r980 = and i16 %r914, -16384
  %r981 = icmp eq i16 %r980, 0
  %r982 = and i8 %r909, 32
  %r983 = icmp eq i8 %r982, 0
  %r984 = and i1 %r977, %r979
  %r985 = and i1 %r984, %r981
  %r986 = and i1 %r985, %r983
  br i1 %r986, label %put.dynic.trans.key.170, label %put.dynic.slow.177

put.dynic.trans.key.170:                          ; preds = %put.dynic.trans.probe.169
  %r987 = and i64 %r887, 281474976710655
  %r988 = add nuw nsw i64 %r987, 4
  %r989 = inttoptr i64 %r988 to ptr
  %r990 = load i32, ptr %r989, align 4
  %r991 = icmp uge i32 %r990, 6
  %r992 = icmp ule i32 %r990, 8
  %r993 = add nuw nsw i64 %r987, 20
  %r994 = inttoptr i64 %r993 to ptr
  %r995 = load i8, ptr %r994, align 1
  %r996 = sub i8 %r995, 48
  %r997 = icmp ult i8 %r996, 10
  %r998 = icmp eq i1 %r997, false
  %r999 = and i1 %r991, %r992
  %r1000 = and i1 %r999, %r998
  br i1 %r1000, label %put.dynic.trans.entry.171, label %put.dynic.slow.177

put.dynic.trans.entry.171:                        ; preds = %put.dynic.trans.key.170
  %r1001 = add nuw nsw i64 %r987, 20
  %r1002 = inttoptr i64 %r1001 to ptr
  %r1003 = load i64, ptr %r1002, align 8
  %r1004 = zext nneg i32 %r990 to i64
  %r1005 = sub nuw nsw i64 8, %r1004
  %r1006 = shl nuw nsw i64 %r1005, 3
  %r1007 = lshr i64 -1, %r1006
  %r1008 = and i64 %r1003, %r1007
  %r1010 = ptrtoint ptr %r543 to i64
  %r1011 = zext i32 %r927 to i64
  %r1012 = mul i64 %r1011, -7046029254386353131
  %r1013 = lshr i64 %r1008, 3
  %r1014 = mul i64 %r1013, -4126379630918253789
  %r1015 = xor i64 %r1012, %r1014
  %r1016 = and i64 %r1015, 16383
  %r1017 = shl nuw nsw i64 %r1016, 5
  %r1018 = add i64 %r1010, %r1017
  %r1019 = inttoptr i64 %r1018 to ptr
  %r1020 = load i64, ptr %r1019, align 8
  %r1021 = add i64 %r1018, 8
  %r1022 = inttoptr i64 %r1021 to ptr
  %r1023 = load i64, ptr %r1022, align 8
  %r1024 = add i64 %r1018, 16
  %r1025 = inttoptr i64 %r1024 to ptr
  %r1026 = load i32, ptr %r1025, align 4
  %r1027 = add i64 %r1018, 20
  %r1028 = inttoptr i64 %r1027 to ptr
  %r1029 = load i32, ptr %r1028, align 4
  %r1030 = add i64 %r1018, 24
  %r1031 = inttoptr i64 %r1030 to ptr
  %r1032 = load i32, ptr %r1031, align 4
  %r1033 = lshr i32 %r1032, 24
  %r1034 = and i32 %r1032, 16777215
  %r1035 = add i64 %r1018, 28
  %r1036 = inttoptr i64 %r1035 to ptr
  %r1037 = load i32, ptr %r1036, align 4
  %r1038 = icmp eq i64 %r1020, %r1008
  %r1039 = icmp eq i32 %r1033, %r990
  %r1040 = icmp eq i32 %r1026, %r927
  %r1041 = icmp ne i64 %r1023, 0
  %r1042 = add nuw nsw i32 %r1034, 1
  %r1043 = icmp eq i32 %r1037, %r1042
  %r1044 = zext nneg i32 %r1034 to i64
  %r1045 = and i64 %r888, 281474976710655
  %r1046 = icmp eq i64 %r894, 32765
  %r1047 = icmp eq i64 %r1045, 0
  %r1048 = and i1 %r1046, %r1047
  %r1049 = select i1 %r1048, i64 9222246136947933185, i64 %r888
  %r1050 = bitcast i64 %r1049 to double
  %r1051 = and i1 %r1038, %r1039
  %r1052 = and i1 %r1051, %r1040
  %r1053 = and i1 %r1052, %r1041
  %r1054 = and i1 %r1053, %r1043
  br i1 %r1054, label %put.dynic.trans.nk.172, label %put.dynic.slow.177

put.dynic.trans.nk.172:                           ; preds = %put.dynic.trans.entry.171
  %r1055 = inttoptr i64 %r1023 to ptr
  %r1056 = load i32, ptr %r1055, align 4
  %r1057 = icmp eq i32 %r1056, %r1042
  br i1 %r1057, label %put.dynic.trans.dispatch.173, label %put.dynic.slow.177

put.dynic.trans.dispatch.173:                     ; preds = %put.dynic.trans.nk.172
  %r1058 = icmp ult i64 %r1044, 2
  br i1 %r1058, label %put.dynic.trans.inline_ref.174, label %put.dynic.trans.ovf.175

put.dynic.trans.inline_ref.174:                   ; preds = %put.dynic.trans.dispatch.173
  %r1059 = shl nuw nsw i64 %r1044, 3
  %r1060 = add nuw nsw i64 %r1059, 16
  %r1061 = add nuw nsw i64 %r890, %r1060
  %r1062 = inttoptr i64 %r1061 to ptr
  %r1063 = trunc nuw nsw i64 %r1044 to i32
  %r1064 = load double, ptr %r1062, align 8
  %r1065 = bitcast double %r1064 to i64
  store double %r1050, ptr %r1062, align 8
  call void @js_string_addref_if_heap_string(double %r1050) #9
  %r1066 = bitcast double %r1050 to i64
  %r2695.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated152 to i64
  %r2695.rs4o = call i64 asm "", "=r,0"(i64 %r2695.rs4i) #9
  %r2695 = bitcast i64 %r2695.rs4o to double
  %r2696 = bitcast double %r2695 to i64
  %r2697 = and i64 %r2696, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r2697, i32 %r1063, i64 %r1066, i64 %r1065) #9
  %r2693.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated152 to i64
  %r2693.rs4o = call i64 asm "", "=r,0"(i64 %r2693.rs4i) #9
  %r2693 = bitcast i64 %r2693.rs4o to double
  %r2694 = bitcast double %r2693 to i64
  call void @js_write_barrier_slot(i64 %r2694, i64 %r1061, i64 %r1066) #9
  br label %put.dynic.trans.stamp.176

put.dynic.trans.ovf.175:                          ; preds = %put.dynic.trans.dispatch.173
  %r1067 = trunc nuw nsw i64 %r1044 to i32
  %r1068 = call i32 @js_transition_ic_spill_append(double %r883, i64 %r932, i32 %r1067, double %r1050) #9
  %r1069 = icmp ne i32 %r1068, 0
  br i1 %r1069, label %put.dynic.trans.stamp.176, label %put.dynic.slow.177

put.dynic.trans.stamp.176:                        ; preds = %put.dynic.trans.ovf.175, %put.dynic.trans.inline_ref.174
  %r2690.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated152 to i64
  %r2690.rs4o = call i64 asm "", "=r,0"(i64 %r2690.rs4i) #9
  %r2690 = bitcast i64 %r2690.rs4o to double
  %r2691 = bitcast double %r2690 to i64
  %r2692 = and i64 %r2691, 281474976710655
  %r1070 = add nuw nsw i64 %r2692, 4
  %r1071 = inttoptr i64 %r1070 to ptr
  store i32 %r1029, ptr %r1071, align 4
  br label %put.dynic.merge.178

put.dynic.slow.177:                               ; preds = %put.dynic.trans.ovf.175, %put.dynic.trans.nk.172, %put.dynic.trans.entry.171, %put.dynic.trans.key.170, %put.dynic.trans.probe.169, %put.dynic.trans.gate.168, %put.dynic.store.validate.164, %pget.recv_merge.132
  %statepoint_token167 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, double, double, i32)) @js_put_value_set_dyn_ic, i32 5, i32 0, ptr @perry_ic_test_json_string_emitters_ts__21, double %r883, double %r882, double %r881151, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated152, ptr addrspace(1) %rs4gc.s10.relocated153) ]
  %r1072168 = call double @llvm.experimental.gc.result.f64(token %statepoint_token167)
  %rs4gc.s13.relocated169 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token167, i32 0, i32 0) ; (%rs4gc.s13.relocated152, %rs4gc.s13.relocated152)
  %rs4gc.s10.relocated170 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token167, i32 1, i32 1) ; (%rs4gc.s10.relocated153, %rs4gc.s10.relocated153)
  br label %put.dynic.merge.178

put.dynic.merge.178:                              ; preds = %put.dynic.slow.177, %put.dynic.trans.stamp.176, %put.dynic.store.ref.167, %put.dynic.store.scalar.166
  %.5528 = phi ptr addrspace(1) [ %rs4gc.s13.relocated169, %put.dynic.slow.177 ], [ %rs4gc.s13.relocated152, %put.dynic.store.scalar.166 ], [ %rs4gc.s13.relocated152, %put.dynic.store.ref.167 ], [ %rs4gc.s13.relocated152, %put.dynic.trans.stamp.176 ]
  %.10 = phi ptr addrspace(1) [ %rs4gc.s10.relocated170, %put.dynic.slow.177 ], [ %rs4gc.s10.relocated153, %put.dynic.store.scalar.166 ], [ %rs4gc.s10.relocated153, %put.dynic.store.ref.167 ], [ %rs4gc.s10.relocated153, %put.dynic.trans.stamp.176 ]
  %r1073 = phi double [ %r881151, %put.dynic.store.scalar.166 ], [ %r881151, %put.dynic.store.ref.167 ], [ %r1050, %put.dynic.trans.stamp.176 ], [ %r1072168, %put.dynic.slow.177 ]
  %statepoint_token171 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5528, ptr addrspace(1) %.10) ]
  %r1074172 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token171)
  %rs4gc.s13.relocated173 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 0, i32 0) ; (%.5528, %.5528)
  %rs4gc.s10.relocated174 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 1, i32 1) ; (%.10, %.10)
  %rs4gc.s26 = inttoptr i64 %r1074172 to ptr addrspace(1)
  %r1075.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s26 to i64
  %r1075 = call i64 asm "", "=r,0"(i64 %r1075.rs4i) #9
  %r1076 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1077 = icmp ne i32 %r1076, 0
  br i1 %r1077, label %shadow.root.barrier.179, label %shadow.root.barrier.done.180

shadow.root.barrier.179:                          ; preds = %put.dynic.merge.178
  call void @js_write_barrier_root_nanbox(i64 %r1075) #9
  br label %shadow.root.barrier.done.180

shadow.root.barrier.done.180:                     ; preds = %shadow.root.barrier.179, %put.dynic.merge.178
  %r1078 = load double, ptr @test_json_string_emitters_ts_.str.24.handle, align 8
  %r1079.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s26 to i64
  %r1079 = call i64 asm "", "=r,0"(i64 %r1079.rs4i) #9
  %statepoint_token175 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1079, double %r1078, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated173, ptr addrspace(1) %rs4gc.s10.relocated174) ]
  %r1080176 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token175)
  %rs4gc.s13.relocated177 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token175, i32 0, i32 0) ; (%rs4gc.s13.relocated173, %rs4gc.s13.relocated173)
  %rs4gc.s10.relocated178 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token175, i32 1, i32 1) ; (%rs4gc.s10.relocated174, %rs4gc.s10.relocated174)
  %rs4gc.s27 = inttoptr i64 %r1080176 to ptr addrspace(1)
  %r1081.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s27 to i64
  %r1081 = call i64 asm "", "=r,0"(i64 %r1081.rs4i) #9
  %r1082 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1083 = icmp ne i32 %r1082, 0
  br i1 %r1083, label %shadow.root.barrier.181, label %shadow.root.barrier.done.182

shadow.root.barrier.181:                          ; preds = %shadow.root.barrier.done.180
  call void @js_write_barrier_root_nanbox(i64 %r1081) #9
  br label %shadow.root.barrier.done.182

shadow.root.barrier.done.182:                     ; preds = %shadow.root.barrier.181, %shadow.root.barrier.done.180
  %r1085 = sitofp i32 %r87.0 to double
  %r1086.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s27 to i64
  %r1086 = call i64 asm "", "=r,0"(i64 %r1086.rs4i) #9
  %statepoint_token179 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1086, double %r1085, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated177, ptr addrspace(1) %rs4gc.s10.relocated178) ]
  %r1087180 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token179)
  %rs4gc.s13.relocated181 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token179, i32 0, i32 0) ; (%rs4gc.s13.relocated177, %rs4gc.s13.relocated177)
  %rs4gc.s10.relocated182 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token179, i32 1, i32 1) ; (%rs4gc.s10.relocated178, %rs4gc.s10.relocated178)
  %rs4gc.s28 = inttoptr i64 %r1087180 to ptr addrspace(1)
  %r1088.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s28 to i64
  %r1088 = call i64 asm "", "=r,0"(i64 %r1088.rs4i) #9
  %r1089 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1090 = icmp ne i32 %r1089, 0
  br i1 %r1090, label %shadow.root.barrier.183, label %shadow.root.barrier.done.184

shadow.root.barrier.183:                          ; preds = %shadow.root.barrier.done.182
  call void @js_write_barrier_root_nanbox(i64 %r1088) #9
  br label %shadow.root.barrier.done.184

shadow.root.barrier.done.184:                     ; preds = %shadow.root.barrier.183, %shadow.root.barrier.done.182
  %r1091.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated181 to i64
  %r1091.rs4o = call i64 asm "", "=r,0"(i64 %r1091.rs4i) #9
  %r1091 = bitcast i64 %r1091.rs4o to double
  %statepoint_token183 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r1091, double 0x7FFC000000000002, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated181, ptr addrspace(1) %rs4gc.s10.relocated182, ptr addrspace(1) %rs4gc.s28) ]
  %r1092184 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token183)
  %rs4gc.s13.relocated185 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token183, i32 0, i32 0) ; (%rs4gc.s13.relocated181, %rs4gc.s13.relocated181)
  %rs4gc.s10.relocated186 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token183, i32 1, i32 1) ; (%rs4gc.s10.relocated182, %rs4gc.s10.relocated182)
  %rs4gc.s28.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token183, i32 2, i32 2) ; (%rs4gc.s28, %rs4gc.s28)
  %r1093 = bitcast i64 %r1092184 to double
  %r1094.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s28.relocated to i64
  %r1094 = call i64 asm "", "=r,0"(i64 %r1094.rs4i) #9
  %statepoint_token187 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1094, double %r1093, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated185, ptr addrspace(1) %rs4gc.s10.relocated186) ]
  %r1095188 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token187)
  %rs4gc.s13.relocated189 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token187, i32 0, i32 0) ; (%rs4gc.s13.relocated185, %rs4gc.s13.relocated185)
  %rs4gc.s10.relocated190 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token187, i32 1, i32 1) ; (%rs4gc.s10.relocated186, %rs4gc.s10.relocated186)
  %rs4gc.s29 = inttoptr i64 %r1095188 to ptr addrspace(1)
  %r1096.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s29 to i64
  %r1096 = call i64 asm "", "=r,0"(i64 %r1096.rs4i) #9
  %r1097 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1098 = icmp ne i32 %r1097, 0
  br i1 %r1098, label %shadow.root.barrier.185, label %shadow.root.barrier.done.186

shadow.root.barrier.185:                          ; preds = %shadow.root.barrier.done.184
  call void @js_write_barrier_root_nanbox(i64 %r1096) #9
  br label %shadow.root.barrier.done.186

shadow.root.barrier.done.186:                     ; preds = %shadow.root.barrier.185, %shadow.root.barrier.done.184
  %r1099.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s29 to i64
  %r1099 = call i64 asm "", "=r,0"(i64 %r1099.rs4i) #9
  %statepoint_token191 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r1099, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated189, ptr addrspace(1) %rs4gc.s10.relocated190) ]
  %rs4gc.s13.relocated192 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token191, i32 0, i32 0) ; (%rs4gc.s13.relocated189, %rs4gc.s13.relocated189)
  %rs4gc.s10.relocated193 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token191, i32 1, i32 1) ; (%rs4gc.s10.relocated190, %rs4gc.s10.relocated190)
  %statepoint_token194 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated192, ptr addrspace(1) %rs4gc.s10.relocated193) ]
  %r1100195 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token194)
  %rs4gc.s13.relocated196 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token194, i32 0, i32 0) ; (%rs4gc.s13.relocated192, %rs4gc.s13.relocated192)
  %rs4gc.s10.relocated197 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token194, i32 1, i32 1) ; (%rs4gc.s10.relocated193, %rs4gc.s10.relocated193)
  %rs4gc.s30 = inttoptr i64 %r1100195 to ptr addrspace(1)
  %r1101.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s30 to i64
  %r1101 = call i64 asm "", "=r,0"(i64 %r1101.rs4i) #9
  %r1102 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1103 = icmp ne i32 %r1102, 0
  br i1 %r1103, label %shadow.root.barrier.187, label %shadow.root.barrier.done.188

shadow.root.barrier.187:                          ; preds = %shadow.root.barrier.done.186
  call void @js_write_barrier_root_nanbox(i64 %r1101) #9
  br label %shadow.root.barrier.done.188

shadow.root.barrier.done.188:                     ; preds = %shadow.root.barrier.187, %shadow.root.barrier.done.186
  %r1104 = load double, ptr @test_json_string_emitters_ts_.str.25.handle, align 8
  %r1105.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s30 to i64
  %r1105 = call i64 asm "", "=r,0"(i64 %r1105.rs4i) #9
  %statepoint_token198 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1105, double %r1104, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated196, ptr addrspace(1) %rs4gc.s10.relocated197) ]
  %r1106199 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token198)
  %rs4gc.s13.relocated200 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token198, i32 0, i32 0) ; (%rs4gc.s13.relocated196, %rs4gc.s13.relocated196)
  %rs4gc.s10.relocated201 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token198, i32 1, i32 1) ; (%rs4gc.s10.relocated197, %rs4gc.s10.relocated197)
  %rs4gc.s31 = inttoptr i64 %r1106199 to ptr addrspace(1)
  %r1107.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31 to i64
  %r1107 = call i64 asm "", "=r,0"(i64 %r1107.rs4i) #9
  %r1108 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1109 = icmp ne i32 %r1108, 0
  br i1 %r1109, label %shadow.root.barrier.189, label %shadow.root.barrier.done.190

shadow.root.barrier.189:                          ; preds = %shadow.root.barrier.done.188
  call void @js_write_barrier_root_nanbox(i64 %r1107) #9
  br label %shadow.root.barrier.done.190

shadow.root.barrier.done.190:                     ; preds = %shadow.root.barrier.189, %shadow.root.barrier.done.188
  %r1111 = sitofp i32 %r87.0 to double
  %r1112.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31 to i64
  %r1112 = call i64 asm "", "=r,0"(i64 %r1112.rs4i) #9
  %statepoint_token202 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1112, double %r1111, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s10.relocated201, ptr addrspace(1) %rs4gc.s13.relocated200) ]
  %r1113203 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token202)
  %rs4gc.s10.relocated204 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token202, i32 0, i32 0) ; (%rs4gc.s10.relocated201, %rs4gc.s10.relocated201)
  %rs4gc.s13.relocated205 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token202, i32 1, i32 1) ; (%rs4gc.s13.relocated200, %rs4gc.s13.relocated200)
  %rs4gc.s32 = inttoptr i64 %r1113203 to ptr addrspace(1)
  %r1114.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s32 to i64
  %r1114 = call i64 asm "", "=r,0"(i64 %r1114.rs4i) #9
  %r1115 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1116 = icmp ne i32 %r1115, 0
  br i1 %r1116, label %shadow.root.barrier.191, label %shadow.root.barrier.done.192

shadow.root.barrier.191:                          ; preds = %shadow.root.barrier.done.190
  call void @js_write_barrier_root_nanbox(i64 %r1114) #9
  br label %shadow.root.barrier.done.192

shadow.root.barrier.done.192:                     ; preds = %shadow.root.barrier.191, %shadow.root.barrier.done.190
  %r1117.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated205 to i64
  %r1117.rs4o = call i64 asm "", "=r,0"(i64 %r1117.rs4i) #9
  %r1117 = bitcast i64 %r1117.rs4o to double
  %statepoint_token206 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (ptr)) @js_closure_alloc_singleton, i32 1, i32 0, ptr @__perry_wrap_perry_fn_test_json_string_emitters_ts__identity, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s10.relocated204, ptr addrspace(1) %rs4gc.s32, ptr addrspace(1) %rs4gc.s13.relocated205) ]
  %r1118207 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token206)
  %rs4gc.s10.relocated208 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token206, i32 0, i32 0) ; (%rs4gc.s10.relocated204, %rs4gc.s10.relocated204)
  %rs4gc.s32.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token206, i32 1, i32 1) ; (%rs4gc.s32, %rs4gc.s32)
  %rs4gc.s13.relocated209 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token206, i32 2, i32 2) ; (%rs4gc.s13.relocated205, %rs4gc.s13.relocated205)
  %r1119 = or i64 %r1118207, 9222527611924643840
  %r1120 = bitcast i64 %r1119 to double
  %r2689.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated209 to i64
  %r2689.rs4o = call i64 asm "", "=r,0"(i64 %r2689.rs4i) #9
  %r2689 = bitcast i64 %r2689.rs4o to double
  %statepoint_token210 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r2689, double %r1120, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s10.relocated208, ptr addrspace(1) %rs4gc.s32.relocated) ]
  %r1121211 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token210)
  %rs4gc.s10.relocated212 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token210, i32 0, i32 0) ; (%rs4gc.s10.relocated208, %rs4gc.s10.relocated208)
  %rs4gc.s32.relocated213 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token210, i32 1, i32 1) ; (%rs4gc.s32.relocated, %rs4gc.s32.relocated)
  %r1122 = bitcast i64 %r1121211 to double
  %r1123.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s32.relocated213 to i64
  %r1123 = call i64 asm "", "=r,0"(i64 %r1123.rs4i) #9
  %statepoint_token214 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1123, double %r1122, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s10.relocated212) ]
  %r1124215 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token214)
  %rs4gc.s10.relocated216 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token214, i32 0, i32 0) ; (%rs4gc.s10.relocated212, %rs4gc.s10.relocated212)
  %rs4gc.s33 = inttoptr i64 %r1124215 to ptr addrspace(1)
  %r1125.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s33 to i64
  %r1125 = call i64 asm "", "=r,0"(i64 %r1125.rs4i) #9
  %r1126 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1127 = icmp ne i32 %r1126, 0
  br i1 %r1127, label %shadow.root.barrier.193, label %shadow.root.barrier.done.194

shadow.root.barrier.193:                          ; preds = %shadow.root.barrier.done.192
  call void @js_write_barrier_root_nanbox(i64 %r1125) #9
  br label %shadow.root.barrier.done.194

shadow.root.barrier.done.194:                     ; preds = %shadow.root.barrier.193, %shadow.root.barrier.done.192
  %r1128.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s33 to i64
  %r1128 = call i64 asm "", "=r,0"(i64 %r1128.rs4i) #9
  %statepoint_token217 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r1128, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s10.relocated216) ]
  %rs4gc.s10.relocated218 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token217, i32 0, i32 0) ; (%rs4gc.s10.relocated216, %rs4gc.s10.relocated216)
  %r1129 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1130 = icmp ne i32 %r1129, 0
  br i1 %r1130, label %gcpoll.195, label %gcpoll.done.196

gcpoll.195:                                       ; preds = %shadow.root.barrier.done.194
  %statepoint_token219 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s10.relocated218) ]
  %rs4gc.s10.relocated220 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token219, i32 0, i32 0) ; (%rs4gc.s10.relocated218, %rs4gc.s10.relocated218)
  br label %gcpoll.done.196

gcpoll.done.196:                                  ; preds = %gcpoll.195, %shadow.root.barrier.done.194
  %.11 = phi ptr addrspace(1) [ %rs4gc.s10.relocated220, %gcpoll.195 ], [ %rs4gc.s10.relocated218, %shadow.root.barrier.done.194 ]
  br label %for.update.17

shadow.root.barrier.197:                          ; preds = %for.exit.18
  call void @js_write_barrier_root_nanbox(i64 %r1139) #9
  br label %shadow.root.barrier.done.198

shadow.root.barrier.done.198:                     ; preds = %shadow.root.barrier.197, %for.exit.18
  br label %for.cond.199

for.cond.199:                                     ; preds = %for.update.201, %shadow.root.barrier.done.198
  %r1143.0 = phi i32 [ 0, %shadow.root.barrier.done.198 ], [ %r1463, %for.update.201 ]
  %r1142.0 = phi ptr addrspace(1) [ null, %shadow.root.barrier.done.198 ], [ %.0574, %for.update.201 ]
  %r1135.0.base = phi ptr addrspace(1) [ %rs4gc.s11, %shadow.root.barrier.done.198 ], [ %.3567, %for.update.201 ], !is_base_value !0
  %r1135.0 = phi ptr addrspace(1) [ %rs4gc.s11, %shadow.root.barrier.done.198 ], [ %.3573, %for.update.201 ]
  %r1145 = sitofp i32 %r1143.0 to double
  %r1146 = fcmp olt double %r1145, 6.400000e+01
  %r1147 = select i1 %r1146, i64 9222246136947933188, i64 9222246136947933187
  %r1148 = bitcast i64 %r1147 to double
  %r1149 = icmp eq i64 %r1147, 9222246136947933188
  br i1 %r1149, label %for.body.200, label %for.exit.202

for.body.200:                                     ; preds = %for.cond.199
  %r1151 = load double, ptr @test_json_string_emitters_ts_.str.26.handle, align 8
  %r1153 = sitofp i32 %r1143.0 to double
  %r1154 = load double, ptr @test_json_string_emitters_ts_.str.27.handle, align 8
  %r1156 = getelementptr double, ptr %r1155, i64 0
  store double %r1151, ptr %r1156, align 8
  %r1157 = getelementptr double, ptr %r1155, i64 1
  store double %r1153, ptr %r1157, align 8
  %r1158 = getelementptr double, ptr %r1155, i64 2
  store double %r1154, ptr %r1158, align 8
  %r1159 = ptrtoint ptr %r1155 to i64
  %statepoint_token221 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r1159, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1142.0, ptr addrspace(1) %r1135.0.base, ptr addrspace(1) %r1135.0) ]
  %r1160222 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token221)
  %r1142.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token221, i32 0, i32 0) ; (%r1142.0, %r1142.0)
  %r1135.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token221, i32 1, i32 1) ; (%r1135.0.base, %r1135.0.base)
  %r1135.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token221, i32 1, i32 2) ; (%r1135.0.base, %r1135.0)
  %r1161 = or i64 %r1160222, 9223090561878065152
  %r1162 = bitcast i64 %r1161 to double
  %statepoint_token223 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r1162, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1142.0.relocated, ptr addrspace(1) %r1135.0.base.relocated, ptr addrspace(1) %r1135.0.relocated) ]
  %r1163224 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token223)
  %r1142.0.relocated225 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token223, i32 0, i32 0) ; (%r1142.0.relocated, %r1142.0.relocated)
  %r1135.0.base.relocated226 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token223, i32 1, i32 1) ; (%r1135.0.base.relocated, %r1135.0.base.relocated)
  %r1135.0.relocated227 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token223, i32 1, i32 2) ; (%r1135.0.base.relocated, %r1135.0.relocated)
  %statepoint_token228 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r1163224, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1142.0.relocated225, ptr addrspace(1) %r1135.0.base.relocated226, ptr addrspace(1) %r1135.0.relocated227) ]
  %r1164229 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token228)
  %r1142.0.relocated230 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token228, i32 0, i32 0) ; (%r1142.0.relocated225, %r1142.0.relocated225)
  %r1135.0.base.relocated231 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token228, i32 1, i32 1) ; (%r1135.0.base.relocated226, %r1135.0.base.relocated226)
  %r1135.0.relocated232 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token228, i32 1, i32 2) ; (%r1135.0.base.relocated226, %r1135.0.relocated227)
  %r1165 = bitcast i64 %r1164229 to double
  %rs4gc.b35 = bitcast double %r1165 to i64
  %rs4gc.s35 = inttoptr i64 %rs4gc.b35 to ptr addrspace(1)
  %r1166.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35 to i64
  %r1166 = call i64 asm "", "=r,0"(i64 %r1166.rs4i) #9
  %r1167 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1168 = icmp ne i32 %r1167, 0
  br i1 %r1168, label %shadow.root.barrier.203, label %shadow.root.barrier.done.204

for.update.201:                                   ; preds = %gcpoll.done.262
  %r1463 = add i32 %r1143.0, 1
  %r1464 = sitofp i32 %r1143.0 to double
  %r1465 = sitofp i32 %r1463 to double
  br label %for.cond.199

for.exit.202:                                     ; preds = %for.cond.199
  br label %for.cond.263

shadow.root.barrier.203:                          ; preds = %for.body.200
  call void @js_write_barrier_root_nanbox(i64 %r1166) #9
  br label %shadow.root.barrier.done.204

shadow.root.barrier.done.204:                     ; preds = %shadow.root.barrier.203, %for.body.200
  %r1170.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35 to i64
  %r1170.rs4o = call i64 asm "", "=r,0"(i64 %r1170.rs4i) #9
  %r1170 = bitcast i64 %r1170.rs4o to double
  %statepoint_token233 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (ptr)) @js_closure_alloc_singleton, i32 1, i32 0, ptr @__perry_wrap_perry_fn_test_json_string_emitters_ts__allocateString, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1142.0.relocated230, ptr addrspace(1) %r1135.0.base.relocated231, ptr addrspace(1) %r1135.0.relocated232, ptr addrspace(1) %rs4gc.s35) ]
  %r1171234 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token233)
  %r1142.0.relocated235 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token233, i32 0, i32 0) ; (%r1142.0.relocated230, %r1142.0.relocated230)
  %r1135.0.base.relocated236 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token233, i32 1, i32 1) ; (%r1135.0.base.relocated231, %r1135.0.base.relocated231)
  %r1135.0.relocated237 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token233, i32 1, i32 2) ; (%r1135.0.base.relocated231, %r1135.0.relocated232)
  %rs4gc.s35.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token233, i32 3, i32 3) ; (%rs4gc.s35, %rs4gc.s35)
  %r1172 = or i64 %r1171234, 9222527611924643840
  %r1173 = bitcast i64 %r1172 to double
  %r1175 = sitofp i32 %r1143.0 to double
  %r1176 = fptosi double %r1175 to i64
  %r1178 = srem i64 %r1176, 2
  %r1179 = sitofp i64 %r1178 to double
  %r1180 = icmp eq i64 %r1178, 0
  %r1181 = fcmp olt double %r1175, 0.000000e+00
  %r1182 = and i1 %r1180, %r1181
  %r1183 = fneg double %r1179
  %r1184 = select i1 %r1182, double %r1183, double %r1179
  %r1185 = fcmp oeq double %r1184, 0.000000e+00
  %r1186 = select i1 %r1185, i64 9222246136947933188, i64 9222246136947933187
  %r1187 = bitcast i64 %r1186 to double
  %r1188 = icmp eq i64 %r1186, 9222246136947933188
  br i1 %r1188, label %ternary.then.205, label %ternary.else.206

ternary.then.205:                                 ; preds = %shadow.root.barrier.done.204
  br label %ternary.merge.207

ternary.else.206:                                 ; preds = %shadow.root.barrier.done.204
  br label %ternary.merge.207

ternary.merge.207:                                ; preds = %ternary.else.206, %ternary.then.205
  %r1189 = phi double [ 0.000000e+00, %ternary.then.205 ], [ 2.000000e+00, %ternary.else.206 ]
  %r2688.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated to i64
  %r2688.rs4o = call i64 asm "", "=r,0"(i64 %r2688.rs4i) #9
  %r2688 = bitcast i64 %r2688.rs4o to double
  %statepoint_token238 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r2688, double %r1173, double %r1189, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1142.0.relocated235, ptr addrspace(1) %r1135.0.base.relocated236, ptr addrspace(1) %r1135.0.relocated237) ]
  %r1190239 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token238)
  %r1142.0.relocated240 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token238, i32 0, i32 0) ; (%r1142.0.relocated235, %r1142.0.relocated235)
  %r1135.0.base.relocated241 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token238, i32 1, i32 1) ; (%r1135.0.base.relocated236, %r1135.0.base.relocated236)
  %r1135.0.relocated242 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token238, i32 1, i32 2) ; (%r1135.0.base.relocated236, %r1135.0.relocated237)
  %r1191 = bitcast i64 %r1190239 to double
  %rs4gc.b36 = bitcast double %r1191 to i64
  %rs4gc.s36 = inttoptr i64 %rs4gc.b36 to ptr addrspace(1)
  %r1192.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s36 to i64
  %r1192 = call i64 asm "", "=r,0"(i64 %r1192.rs4i) #9
  %r1193 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1194 = icmp ne i32 %r1193, 0
  br i1 %r1194, label %shadow.root.barrier.208, label %shadow.root.barrier.done.209

shadow.root.barrier.208:                          ; preds = %ternary.merge.207
  call void @js_write_barrier_root_nanbox(i64 %r1192) #9
  br label %shadow.root.barrier.done.209

shadow.root.barrier.done.209:                     ; preds = %shadow.root.barrier.208, %ternary.merge.207
  %r1195.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s36 to i64
  %r1195.rs4o = call i64 asm "", "=r,0"(i64 %r1195.rs4i) #9
  %r1195 = bitcast i64 %r1195.rs4o to double
  %r1196 = bitcast double %r1195 to i64
  %r1197.rs4i = ptrtoint ptr addrspace(1) %r1135.0.relocated242 to i64
  %r1197.rs4o = call i64 asm "", "=r,0"(i64 %r1197.rs4i) #9
  %r1197 = bitcast i64 %r1197.rs4o to double
  %r1198 = bitcast double %r1197 to i64
  %r1199 = and i64 %r1198, 281474976710655
  %r1200 = sub nsw i64 %r1199, 8
  %r1201 = inttoptr i64 %r1200 to ptr
  %r1202 = load i8, ptr %r1201, align 1
  %r1203 = icmp ne i8 %r1202, 1
  %r1204 = sub nsw i64 %r1199, 7
  %r1205 = inttoptr i64 %r1204 to ptr
  %r1206 = load i8, ptr %r1205, align 1
  %r1207 = and i8 %r1206, -128
  %r1208 = icmp ne i8 %r1207, 0
  %r1209 = or i1 %r1203, %r1208
  br i1 %r1208, label %apush.fwd.210, label %apush.elements.211

apush.fwd.210:                                    ; preds = %apush.elements.check.212, %shadow.root.barrier.done.209
  %statepoint_token243 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1199, double %r1195, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s36, ptr addrspace(1) %r1142.0.relocated240) ]
  %r1236244 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token243)
  %rs4gc.s36.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token243, i32 0, i32 0) ; (%rs4gc.s36, %rs4gc.s36)
  %r1142.0.relocated245 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token243, i32 1, i32 1) ; (%r1142.0.relocated240, %r1142.0.relocated240)
  %r1237 = or i64 %r1236244, 9222527611924643840
  %r1238 = bitcast i64 %r1237 to double
  %rs4gc.b37 = bitcast double %r1238 to i64
  %rs4gc.s37 = inttoptr i64 %rs4gc.b37 to ptr addrspace(1)
  br label %apush.merge.216

apush.elements.211:                               ; preds = %shadow.root.barrier.done.209
  %r1211 = add nuw nsw i64 %r1199, 8
  %r1212 = inttoptr i64 %r1211 to ptr
  %r1213 = load i64, ptr %r1212, align 8
  %r1214 = icmp ne i64 %r1213, 0
  %r1215 = icmp eq i8 %r1202, 2
  %r1216 = and i1 %r1215, %r1214
  %r1217 = select i1 %r1216, i64 %r1213, i64 %r1199
  %r1218 = inttoptr i64 %r1217 to ptr
  %r1219 = getelementptr i64, ptr %r1218, i64 12
  %r1220 = load i64, ptr %r1219, align 8
  %r1221 = icmp ne i64 %r1220, 0
  %r1222 = and i1 %r1216, %r1221
  %r1223 = select i1 %r1222, i64 %r1220, i64 %r1199
  %r1210 = icmp eq i8 %r1202, 1
  br i1 %r1210, label %apush.nofwd.213, label %apush.elements.check.212

apush.elements.check.212:                         ; preds = %apush.elements.211
  %r1224 = icmp ne i64 %r1223, 0
  %r1225 = sub i64 %r1223, 8
  %r1226 = inttoptr i64 %r1225 to ptr
  %r1227 = load i8, ptr %r1226, align 1
  %r1228 = icmp eq i8 %r1227, 1
  %r1229 = sub i64 %r1223, 7
  %r1230 = inttoptr i64 %r1229 to ptr
  %r1231 = load i8, ptr %r1230, align 1
  %r1232 = and i8 %r1231, -128
  %r1233 = icmp eq i8 %r1232, 0
  %r1234 = and i1 %r1224, %r1228
  %r1235 = and i1 %r1234, %r1233
  br i1 %r1235, label %apush.nofwd.213, label %apush.fwd.210

apush.nofwd.213:                                  ; preds = %apush.elements.check.212, %apush.elements.211
  %r1239 = phi i64 [ %r1199, %apush.elements.211 ], [ %r1223, %apush.elements.check.212 ]
  %r1240 = sub i64 %r1239, 6
  %r1241 = inttoptr i64 %r1240 to ptr
  %r1242 = load i16, ptr %r1241, align 2
  %r1243 = and i16 %r1242, 1031
  %r1244 = icmp eq i16 %r1243, 0
  %r1245 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1246 = icmp eq i8 %r1245, 0
  %r1247 = and i1 %r1244, %r1246
  %r1248 = icmp ult i64 %r1239, 4096
  %r1249 = inttoptr i64 %r1239 to ptr
  %r1250 = select i1 %r1248, ptr @perry_null_guard_zero_test_json_string_emitters_ts, ptr %r1249
  %r1251 = load i32, ptr %r1250, align 4
  %r1252 = add i64 %r1239, 4
  %r1253 = inttoptr i64 %r1252 to ptr
  %r1254 = load i32, ptr %r1253, align 4
  %r1255 = icmp ult i32 %r1251, %r1254
  %r1256 = and i1 %r1255, %r1247
  br i1 %r1256, label %apush.inbounds.214, label %apush.realloc.215

apush.inbounds.214:                               ; preds = %apush.nofwd.213
  %r1257 = icmp ult i64 %r1239, 4096
  %r1258 = inttoptr i64 %r1239 to ptr
  %r1259 = select i1 %r1257, ptr @perry_null_guard_zero_test_json_string_emitters_ts, ptr %r1258
  %r1260 = load i32, ptr %r1259, align 4
  %r1261 = zext i32 %r1260 to i64
  %r1262 = shl nuw nsw i64 %r1261, 3
  %r1263 = add nuw nsw i64 %r1262, 8
  %r1264 = add i64 %r1239, %r1263
  %r1265 = inttoptr i64 %r1264 to ptr
  store double %r1195, ptr %r1265, align 8
  %r1266 = lshr i64 %r1196, 48
  %r1267 = icmp eq i64 %r1266, 32765
  %r1268 = and i16 %r1242, -1920
  %r1269 = icmp eq i16 %r1268, -24576
  %r1270 = and i1 %r1267, %r1269
  br i1 %r1270, label %apush.pointer_layout.done.218, label %apush.pointer_layout.bookkeeping.217

apush.realloc.215:                                ; preds = %apush.nofwd.213
  %statepoint_token246 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1199, double %r1195, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s36, ptr addrspace(1) %r1142.0.relocated240) ]
  %r1281247 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token246)
  %rs4gc.s36.relocated248 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token246, i32 0, i32 0) ; (%rs4gc.s36, %rs4gc.s36)
  %r1142.0.relocated249 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token246, i32 1, i32 1) ; (%r1142.0.relocated240, %r1142.0.relocated240)
  %r1282 = or i64 %r1281247, 9222527611924643840
  %r1283 = bitcast i64 %r1282 to double
  %rs4gc.b38 = bitcast double %r1283 to i64
  %rs4gc.s38 = inttoptr i64 %rs4gc.b38 to ptr addrspace(1)
  br label %apush.merge.216

apush.merge.216:                                  ; preds = %apush.barrier.done.220, %apush.realloc.215, %apush.fwd.210
  %.0563 = phi ptr addrspace(1) [ %rs4gc.s36.relocated, %apush.fwd.210 ], [ %rs4gc.s36, %apush.barrier.done.220 ], [ %rs4gc.s36.relocated248, %apush.realloc.215 ]
  %.0529 = phi ptr addrspace(1) [ %r1142.0.relocated245, %apush.fwd.210 ], [ %r1142.0.relocated240, %apush.barrier.done.220 ], [ %r1142.0.relocated249, %apush.realloc.215 ]
  %r1135.1.base = phi ptr addrspace(1) [ %rs4gc.s37, %apush.fwd.210 ], [ %r1135.0.base.relocated241, %apush.barrier.done.220 ], [ %rs4gc.s38, %apush.realloc.215 ], !is_base_value !0
  %r1135.1 = phi ptr addrspace(1) [ %rs4gc.s37, %apush.fwd.210 ], [ %r1135.0.relocated242, %apush.barrier.done.220 ], [ %rs4gc.s38, %apush.realloc.215 ]
  %r1284.rs4i = ptrtoint ptr addrspace(1) %.0529 to i64
  %r1284.rs4o = call i64 asm "", "=r,0"(i64 %r1284.rs4i) #9
  %r1284 = bitcast i64 %r1284.rs4o to double
  %r1285 = bitcast double %r1284 to i64
  %rs4gc.s39 = inttoptr i64 %r1285 to ptr addrspace(1)
  %r1286.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s39 to i64
  %r1286 = call i64 asm "", "=r,0"(i64 %r1286.rs4i) #9
  %r1287 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1288 = icmp ne i32 %r1287, 0
  br i1 %r1288, label %shadow.root.barrier.221, label %shadow.root.barrier.done.222

apush.pointer_layout.bookkeeping.217:             ; preds = %apush.inbounds.214
  call void @js_string_addref_if_heap_string(double %r1195) #9
  %r2686.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s36 to i64
  %r2686.rs4o = call i64 asm "", "=r,0"(i64 %r2686.rs4i) #9
  %r2686 = bitcast i64 %r2686.rs4o to double
  %r2687 = bitcast double %r2686 to i64
  call void @js_gc_note_slot_layout(i64 %r1239, i32 %r1260, i64 %r2687) #9
  %r2684.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s36 to i64
  %r2684.rs4o = call i64 asm "", "=r,0"(i64 %r2684.rs4i) #9
  %r2684 = bitcast i64 %r2684.rs4o to double
  %r2685 = bitcast double %r2684 to i64
  call void @js_array_note_numeric_write(i64 %r1239, i64 %r2685) #9
  br label %apush.pointer_layout.done.218

apush.pointer_layout.done.218:                    ; preds = %apush.pointer_layout.bookkeeping.217, %apush.inbounds.214
  %r1271 = sub i64 %r1239, 7
  %r1272 = inttoptr i64 %r1271 to ptr
  %r1273 = load i8, ptr %r1272, align 1
  %r1274 = and i8 %r1273, 32
  %r1275 = icmp ne i8 %r1274, 0
  %r1276 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1277 = icmp ne i32 %r1276, 0
  %r1278 = or i1 %r1275, %r1277
  br i1 %r1278, label %apush.barrier.219, label %apush.barrier.done.220

apush.barrier.219:                                ; preds = %apush.pointer_layout.done.218
  %r2682.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s36 to i64
  %r2682.rs4o = call i64 asm "", "=r,0"(i64 %r2682.rs4i) #9
  %r2682 = bitcast i64 %r2682.rs4o to double
  %r2683 = bitcast double %r2682 to i64
  call void @js_write_barrier_slot_validated_parent(i64 %r1239, i64 %r1264, i64 %r2683) #9
  br label %apush.barrier.done.220

apush.barrier.done.220:                           ; preds = %apush.barrier.219, %apush.pointer_layout.done.218
  %r1279 = add i32 %r1260, 1
  %r1280 = inttoptr i64 %r1239 to ptr
  store i32 %r1279, ptr %r1280, align 4
  br label %apush.merge.216

shadow.root.barrier.221:                          ; preds = %apush.merge.216
  call void @js_write_barrier_root_nanbox(i64 %r1286) #9
  br label %shadow.root.barrier.done.222

shadow.root.barrier.done.222:                     ; preds = %shadow.root.barrier.221, %apush.merge.216
  %r1289.rs4i = ptrtoint ptr addrspace(1) %.0563 to i64
  %r1289.rs4o = call i64 asm "", "=r,0"(i64 %r1289.rs4i) #9
  %r1289 = bitcast i64 %r1289.rs4o to double
  %r1290 = bitcast double %r1289 to i64
  %r1291 = and i64 %r1290, 281474976710655
  %r1292 = lshr i64 %r1290, 48
  %r1293 = and i64 %r1292, 65533
  %r1294 = icmp eq i64 %r1293, 32765
  br i1 %r1294, label %pget.recv_ok.224, label %pget.recv_other.229

pget.recv_sso.223:                                ; preds = %pget.recv_other.229
  %r1433 = lshr i64 %r1290, 40
  %r1434 = and i64 %r1433, 255
  %r1435 = uitofp nneg i64 %r1434 to double
  br label %pget.recv_merge.227

pget.recv_ok.224:                                 ; preds = %shadow.root.barrier.done.222
  %r1301 = icmp eq i64 %r1292, 32767
  br i1 %r1301, label %pget.strlen_heap.228, label %pget.recv_obj.231

pget.recv_bad.225:                                ; preds = %pget.check_class_ref.230
  %r1425 = icmp eq i64 %r1290, 9222246136947933185
  %r1426 = icmp eq i64 %r1290, 9222246136947933186
  %r1427 = or i1 %r1425, %r1426
  br i1 %r1427, label %pget.throw_nullish.254, label %pget.recv_undef_return.255

pget.recv_class_ref.226:                          ; preds = %pget.check_class_ref.230
  %r1297 = load double, ptr @test_json_string_emitters_ts_.str.28.handle, align 8
  %r1298 = bitcast double %r1297 to i64
  %r1299 = and i64 %r1298, 281474976710655
  %statepoint_token250 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6553530643794362390, i64 %r1290, i64 %r1299, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1135.1.base, ptr addrspace(1) %rs4gc.s39, ptr addrspace(1) %r1135.1) ]
  %r1300251 = call double @llvm.experimental.gc.result.f64(token %statepoint_token250)
  %r1135.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token250, i32 0, i32 0) ; (%r1135.1.base, %r1135.1.base)
  %rs4gc.s39.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token250, i32 1, i32 1) ; (%rs4gc.s39, %rs4gc.s39)
  %r1135.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token250, i32 0, i32 2) ; (%r1135.1.base, %r1135.1)
  br label %pget.recv_merge.227

pget.recv_merge.227:                              ; preds = %pget.recv_undef_return.255, %pic.merge.246, %pget.strlen_heap.228, %pget.recv_class_ref.226, %pget.recv_sso.223
  %.0570 = phi ptr addrspace(1) [ %r1135.1, %pget.strlen_heap.228 ], [ %.1571, %pic.merge.246 ], [ %r1135.1, %pget.recv_sso.223 ], [ %r1135.1.relocated, %pget.recv_class_ref.226 ], [ %r1135.1.relocated267, %pget.recv_undef_return.255 ]
  %.0568 = phi ptr addrspace(1) [ %rs4gc.s39, %pget.strlen_heap.228 ], [ %.1569, %pic.merge.246 ], [ %rs4gc.s39, %pget.recv_sso.223 ], [ %rs4gc.s39.relocated, %pget.recv_class_ref.226 ], [ %rs4gc.s39.relocated266, %pget.recv_undef_return.255 ]
  %.0564 = phi ptr addrspace(1) [ %r1135.1.base, %pget.strlen_heap.228 ], [ %.1565, %pic.merge.246 ], [ %r1135.1.base, %pget.recv_sso.223 ], [ %r1135.1.base.relocated, %pget.recv_class_ref.226 ], [ %r1135.1.base.relocated265, %pget.recv_undef_return.255 ]
  %r1441 = phi double [ %r1424, %pic.merge.246 ], [ %r1432264, %pget.recv_undef_return.255 ], [ %r1435, %pget.recv_sso.223 ], [ %r1300251, %pget.recv_class_ref.226 ], [ %r1440, %pget.strlen_heap.228 ]
  %r1442.rs4i = ptrtoint ptr addrspace(1) %.0568 to i64
  %r1442 = call i64 asm "", "=r,0"(i64 %r1442.rs4i) #9
  %r1443 = bitcast i64 %r1442 to double
  %r1444 = and i64 %r1442, -281474976710656
  %r1445 = icmp ult i64 %r1444, 9221401712017801216
  %r1446 = icmp ugt i64 %r1444, 9223090561878065152
  %r1447 = or i1 %r1445, %r1446
  %r1448 = bitcast double %r1441 to i64
  %r1449 = and i64 %r1448, -281474976710656
  %r1450 = icmp ult i64 %r1449, 9221401712017801216
  %r1451 = icmp ugt i64 %r1449, 9223090561878065152
  %r1452 = or i1 %r1450, %r1451
  %r1453 = and i1 %r1447, %r1452
  br i1 %r1453, label %guarded_add.numeric.256, label %guarded_add.dynamic.257

pget.strlen_heap.228:                             ; preds = %pget.recv_ok.224
  %r1436 = icmp ult i64 %r1291, 4096
  %r1437 = inttoptr i64 %r1291 to ptr
  %r1438 = select i1 %r1436, ptr @perry_null_guard_zero_test_json_string_emitters_ts, ptr %r1437
  %r1439 = load i32, ptr %r1438, align 4
  %r1440 = uitofp i32 %r1439 to double
  br label %pget.recv_merge.227

pget.recv_other.229:                              ; preds = %shadow.root.barrier.done.222
  %r1295 = icmp eq i64 %r1292, 32761
  br i1 %r1295, label %pget.recv_sso.223, label %pget.check_class_ref.230

pget.check_class_ref.230:                         ; preds = %pget.recv_other.229
  %r1296 = icmp eq i64 %r1292, 32766
  br i1 %r1296, label %pget.recv_class_ref.226, label %pget.recv_bad.225

pget.recv_obj.231:                                ; preds = %pget.recv_ok.224
  %r1302 = icmp ugt i64 %r1291, 1048575
  br i1 %r1302, label %pic.recv_hdr.247, label %pic.miss.cold.244

pic.hit.232:                                      ; preds = %pic.token.248
  %r1327 = getelementptr i64, ptr %r1312, i64 1
  %r1328 = load i64, ptr %r1327, align 8
  %r1329 = and i64 %r1328, 1073741824
  %r1330 = icmp ne i64 %r1329, 0
  br i1 %r1330, label %pic.hit.overflow.249, label %pic.hit.inline.250

pic.hit.live.233:                                 ; preds = %pic.hit.inline.250
  br label %pic.merge.246

pic.prefix.guard.234:                             ; preds = %pic.token.248
  %r1343 = getelementptr i64, ptr %r1312, i64 2
  %r1344 = load i64, ptr %r1343, align 8
  %r1345 = icmp ne i64 %r1344, 0
  br i1 %r1345, label %pic.prefix.meta.235, label %pic.miss.243

pic.prefix.meta.235:                              ; preds = %pic.prefix.guard.234
  %r1346 = add nuw nsw i64 %r1291, 8
  %r1347 = inttoptr i64 %r1346 to ptr
  %r1348 = load i64, ptr %r1347, align 8
  %r1349 = icmp ne i64 %r1348, 0
  br i1 %r1349, label %pic.prefix.token.236, label %pic.miss.243

pic.prefix.token.236:                             ; preds = %pic.prefix.meta.235
  %r1350 = inttoptr i64 %r1348 to ptr
  %r1351 = getelementptr i64, ptr %r1350, i64 6
  %r1352 = load i64, ptr %r1351, align 8
  %r1353 = icmp eq i64 %r1352, %r1344
  br i1 %r1353, label %pic.prefix.hit.237, label %pic.miss.243

pic.prefix.hit.237:                               ; preds = %pic.prefix.token.236
  %r1354 = getelementptr i64, ptr %r1312, i64 1
  %r1355 = load i64, ptr %r1354, align 8
  %r1356 = shl i64 %r1355, 3
  %r1357 = add nuw nsw i64 %r1291, 16
  %r1358 = add i64 %r1357, %r1356
  %r1359 = inttoptr i64 %r1358 to ptr
  %r1360 = load double, ptr %r1359, align 8
  br label %pic.merge.246

pic.desc.classify.238:                            ; preds = %pic.recv_hdr.247
  %r1316 = and i1 %r1306, %r1313
  br i1 %r1316, label %pic.desc.prefix.guard.239, label %pic.miss.cold.244

pic.desc.prefix.guard.239:                        ; preds = %pic.desc.classify.238
  %r1361 = getelementptr i64, ptr %r1312, i64 2
  %r1362 = load i64, ptr %r1361, align 8
  %r1363 = icmp ne i64 %r1362, 0
  br i1 %r1363, label %pic.desc.prefix.meta.240, label %pic.miss.cold.244

pic.desc.prefix.meta.240:                         ; preds = %pic.desc.prefix.guard.239
  %r1364 = add nuw nsw i64 %r1291, 8
  %r1365 = inttoptr i64 %r1364 to ptr
  %r1366 = load i64, ptr %r1365, align 8
  %r1367 = icmp ne i64 %r1366, 0
  br i1 %r1367, label %pic.desc.prefix.token.241, label %pic.miss.cold.244

pic.desc.prefix.token.241:                        ; preds = %pic.desc.prefix.meta.240
  %r1368 = inttoptr i64 %r1366 to ptr
  %r1369 = getelementptr i64, ptr %r1368, i64 6
  %r1370 = load i64, ptr %r1369, align 8
  %r1371 = icmp eq i64 %r1370, %r1362
  br i1 %r1371, label %pic.desc.prefix.hit.242, label %pic.miss.cold.244

pic.desc.prefix.hit.242:                          ; preds = %pic.desc.prefix.token.241
  %r1372 = getelementptr i64, ptr %r1312, i64 1
  %r1373 = load i64, ptr %r1372, align 8
  %r1374 = shl i64 %r1373, 3
  %r1375 = add nuw nsw i64 %r1291, 16
  %r1376 = add i64 %r1375, %r1374
  %r1377 = inttoptr i64 %r1376 to ptr
  %r1378 = load double, ptr %r1377, align 8
  br label %pic.merge.246

pic.miss.243:                                     ; preds = %pic.hit.inline.250, %pic.prefix.token.236, %pic.prefix.meta.235, %pic.prefix.guard.234
  %r1379 = getelementptr i64, ptr %r1312, i64 3
  %r1380 = load i64, ptr %r1379, align 8
  %r1381 = icmp sgt i64 %r1380, 0
  br i1 %r1381, label %pic.ways.251, label %pic.miss.call.245

pic.miss.cold.244:                                ; preds = %pic.desc.prefix.token.241, %pic.desc.prefix.meta.240, %pic.desc.prefix.guard.239, %pic.desc.classify.238, %pget.recv_obj.231
  br label %pic.miss.call.245

pic.miss.call.245:                                ; preds = %pic.way.load.252, %pic.ways.251, %pic.miss.cold.244, %pic.miss.243
  %r1420 = load double, ptr @test_json_string_emitters_ts_.str.28.handle, align 8
  %r1421 = bitcast double %r1420 to i64
  %r1422 = and i64 %r1421, 281474976710655
  %statepoint_token252 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1291, i64 %r1422, ptr @perry_ic_test_json_string_emitters_ts__23, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1135.1.base, ptr addrspace(1) %rs4gc.s39, ptr addrspace(1) %r1135.1) ]
  %r1423253 = call double @llvm.experimental.gc.result.f64(token %statepoint_token252)
  %r1135.1.base.relocated254 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 0, i32 0) ; (%r1135.1.base, %r1135.1.base)
  %rs4gc.s39.relocated255 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 1, i32 1) ; (%rs4gc.s39, %rs4gc.s39)
  %r1135.1.relocated256 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 0, i32 2) ; (%r1135.1.base, %r1135.1)
  br label %pic.merge.246

pic.merge.246:                                    ; preds = %pic.way.live.253, %pic.hit.overflow.249, %pic.miss.call.245, %pic.desc.prefix.hit.242, %pic.prefix.hit.237, %pic.hit.live.233
  %.1571 = phi ptr addrspace(1) [ %r1135.1.relocated261, %pic.hit.overflow.249 ], [ %r1135.1.relocated256, %pic.miss.call.245 ], [ %r1135.1, %pic.way.live.253 ], [ %r1135.1, %pic.hit.live.233 ], [ %r1135.1, %pic.prefix.hit.237 ], [ %r1135.1, %pic.desc.prefix.hit.242 ]
  %.1569 = phi ptr addrspace(1) [ %rs4gc.s39.relocated260, %pic.hit.overflow.249 ], [ %rs4gc.s39.relocated255, %pic.miss.call.245 ], [ %rs4gc.s39, %pic.way.live.253 ], [ %rs4gc.s39, %pic.hit.live.233 ], [ %rs4gc.s39, %pic.prefix.hit.237 ], [ %rs4gc.s39, %pic.desc.prefix.hit.242 ]
  %.1565 = phi ptr addrspace(1) [ %r1135.1.base.relocated259, %pic.hit.overflow.249 ], [ %r1135.1.base.relocated254, %pic.miss.call.245 ], [ %r1135.1.base, %pic.way.live.253 ], [ %r1135.1.base, %pic.hit.live.233 ], [ %r1135.1.base, %pic.prefix.hit.237 ], [ %r1135.1.base, %pic.desc.prefix.hit.242 ]
  %r1424 = phi double [ %r1340, %pic.hit.live.233 ], [ %r1335258, %pic.hit.overflow.249 ], [ %r1360, %pic.prefix.hit.237 ], [ %r1378, %pic.desc.prefix.hit.242 ], [ %r1417, %pic.way.live.253 ], [ %r1423253, %pic.miss.call.245 ]
  br label %pget.recv_merge.227

pic.recv_hdr.247:                                 ; preds = %pget.recv_obj.231
  %r1303 = sub nuw nsw i64 %r1291, 8
  %r1304 = inttoptr i64 %r1303 to ptr
  %r1305 = load i8, ptr %r1304, align 1
  %r1306 = icmp eq i8 %r1305, 2
  %r1307 = sub nuw nsw i64 %r1291, 6
  %r1308 = inttoptr i64 %r1307 to ptr
  %r1309 = load i16, ptr %r1308, align 2
  %r1310 = and i16 %r1309, 2048
  %r1311 = icmp eq i16 %r1310, 0
  %r1312 = load ptr, ptr @perry_ic_test_json_string_emitters_ts__23, align 8
  %r1313 = icmp ne ptr %r1312, null
  %r1314 = and i1 %r1306, %r1311
  %r1315 = and i1 %r1314, %r1313
  br i1 %r1315, label %pic.token.248, label %pic.desc.classify.238

pic.token.248:                                    ; preds = %pic.recv_hdr.247
  %r1317 = add nuw nsw i64 %r1291, 4
  %r1318 = inttoptr i64 %r1317 to ptr
  %r1319 = load i32, ptr %r1318, align 4
  %r1320 = zext i32 %r1319 to i64
  %r1321 = or i64 %r1320, 4611686018427387904
  %r1322 = icmp ne i32 %r1319, 0
  %r1323 = getelementptr i64, ptr %r1312, i64 0
  %r1324 = load i64, ptr %r1323, align 8
  %r1325 = icmp eq i64 %r1321, %r1324
  %r1326 = and i1 %r1325, %r1322
  br i1 %r1326, label %pic.hit.232, label %pic.prefix.guard.234

pic.hit.overflow.249:                             ; preds = %pic.hit.232
  %r1331 = load double, ptr @test_json_string_emitters_ts_.str.28.handle, align 8
  %r1332 = bitcast double %r1331 to i64
  %r1333 = and i64 %r1332, 281474976710655
  %r1334 = trunc i64 %r1328 to i32
  %statepoint_token257 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1291, i64 %r1333, i32 %r1334, ptr @perry_ic_test_json_string_emitters_ts__23, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1135.1.base, ptr addrspace(1) %rs4gc.s39, ptr addrspace(1) %r1135.1) ]
  %r1335258 = call double @llvm.experimental.gc.result.f64(token %statepoint_token257)
  %r1135.1.base.relocated259 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token257, i32 0, i32 0) ; (%r1135.1.base, %r1135.1.base)
  %rs4gc.s39.relocated260 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token257, i32 1, i32 1) ; (%rs4gc.s39, %rs4gc.s39)
  %r1135.1.relocated261 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token257, i32 0, i32 2) ; (%r1135.1.base, %r1135.1)
  br label %pic.merge.246

pic.hit.inline.250:                               ; preds = %pic.hit.232
  %r1336 = shl i64 %r1328, 3
  %r1337 = add nuw nsw i64 %r1291, 16
  %r1338 = add i64 %r1337, %r1336
  %r1339 = inttoptr i64 %r1338 to ptr
  %r1340 = load double, ptr %r1339, align 8
  %r1341 = bitcast double %r1340 to i64
  %r1342 = icmp eq i64 %r1341, 9222246136947933200
  br i1 %r1342, label %pic.miss.243, label %pic.hit.live.233

pic.ways.251:                                     ; preds = %pic.miss.243
  %r1382 = getelementptr i64, ptr %r1312, i64 4
  %r1383 = load i64, ptr %r1382, align 8
  %r1384 = icmp eq i64 %r1383, %r1321
  %r1385 = getelementptr i64, ptr %r1312, i64 5
  %r1386 = load i64, ptr %r1385, align 8
  %r1387 = select i1 %r1384, i64 %r1386, i64 0
  %r1388 = getelementptr i64, ptr %r1312, i64 6
  %r1389 = load i64, ptr %r1388, align 8
  %r1390 = icmp eq i64 %r1389, %r1321
  %r1391 = getelementptr i64, ptr %r1312, i64 7
  %r1392 = load i64, ptr %r1391, align 8
  %r1393 = select i1 %r1390, i64 %r1392, i64 0
  %r1394 = getelementptr i64, ptr %r1312, i64 8
  %r1395 = load i64, ptr %r1394, align 8
  %r1396 = icmp eq i64 %r1395, %r1321
  %r1397 = getelementptr i64, ptr %r1312, i64 9
  %r1398 = load i64, ptr %r1397, align 8
  %r1399 = select i1 %r1396, i64 %r1398, i64 0
  %r1400 = getelementptr i64, ptr %r1312, i64 10
  %r1401 = load i64, ptr %r1400, align 8
  %r1402 = icmp eq i64 %r1401, %r1321
  %r1403 = getelementptr i64, ptr %r1312, i64 11
  %r1404 = load i64, ptr %r1403, align 8
  %r1405 = select i1 %r1402, i64 %r1404, i64 0
  %r1406 = or i1 %r1384, %r1390
  %r1407 = select i1 %r1384, i64 %r1387, i64 %r1393
  %r1408 = or i1 %r1396, %r1402
  %r1409 = select i1 %r1396, i64 %r1399, i64 %r1405
  %r1410 = or i1 %r1406, %r1408
  %r1411 = select i1 %r1406, i64 %r1407, i64 %r1409
  %r1412 = and i1 %r1322, %r1410
  br i1 %r1412, label %pic.way.load.252, label %pic.miss.call.245

pic.way.load.252:                                 ; preds = %pic.ways.251
  %r1413 = shl i64 %r1411, 3
  %r1414 = add nuw nsw i64 %r1291, 16
  %r1415 = add i64 %r1414, %r1413
  %r1416 = inttoptr i64 %r1415 to ptr
  %r1417 = load double, ptr %r1416, align 8
  %r1418 = bitcast double %r1417 to i64
  %r1419 = icmp eq i64 %r1418, 9222246136947933200
  br i1 %r1419, label %pic.miss.call.245, label %pic.way.live.253

pic.way.live.253:                                 ; preds = %pic.way.load.252
  br label %pic.merge.246

pget.throw_nullish.254:                           ; preds = %pget.recv_bad.225
  %r1428 = zext i1 %r1426 to i32
  %statepoint_token262 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1428, ptr @test_json_string_emitters_ts_.str.28.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.255:                       ; preds = %pget.recv_bad.225
  %r1429 = load double, ptr @test_json_string_emitters_ts_.str.28.handle, align 8
  %r1430 = bitcast double %r1429 to i64
  %r1431 = and i64 %r1430, 281474976710655
  %statepoint_token263 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1290, i64 %r1431, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1135.1.base, ptr addrspace(1) %rs4gc.s39, ptr addrspace(1) %r1135.1) ]
  %r1432264 = call double @llvm.experimental.gc.result.f64(token %statepoint_token263)
  %r1135.1.base.relocated265 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token263, i32 0, i32 0) ; (%r1135.1.base, %r1135.1.base)
  %rs4gc.s39.relocated266 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token263, i32 1, i32 1) ; (%rs4gc.s39, %rs4gc.s39)
  %r1135.1.relocated267 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token263, i32 0, i32 2) ; (%r1135.1.base, %r1135.1)
  br label %pget.recv_merge.227

guarded_add.numeric.256:                          ; preds = %pget.recv_merge.227
  %r1454 = fadd double %r1443, %r1441
  br label %guarded_add.merge.258

guarded_add.dynamic.257:                          ; preds = %pget.recv_merge.227
  %statepoint_token268 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r1443, double %r1441, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0564, ptr addrspace(1) %.0570) ]
  %r1455269 = call double @llvm.experimental.gc.result.f64(token %statepoint_token268)
  %r1135.1.base.relocated270 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token268, i32 0, i32 0) ; (%.0564, %.0564)
  %r1135.1.relocated271 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token268, i32 0, i32 1) ; (%.0564, %.0570)
  br label %guarded_add.merge.258

guarded_add.merge.258:                            ; preds = %guarded_add.dynamic.257, %guarded_add.numeric.256
  %.2572 = phi ptr addrspace(1) [ %.0570, %guarded_add.numeric.256 ], [ %r1135.1.relocated271, %guarded_add.dynamic.257 ]
  %.2566 = phi ptr addrspace(1) [ %.0564, %guarded_add.numeric.256 ], [ %r1135.1.base.relocated270, %guarded_add.dynamic.257 ]
  %r1456 = phi double [ %r1454, %guarded_add.numeric.256 ], [ %r1455269, %guarded_add.dynamic.257 ]
  %rs4gc.b40 = bitcast double %r1456 to i64
  %rs4gc.s40 = inttoptr i64 %rs4gc.b40 to ptr addrspace(1)
  %r1457.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s40 to i64
  %r1457 = call i64 asm "", "=r,0"(i64 %r1457.rs4i) #9
  %r1458 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1459 = icmp ne i32 %r1458, 0
  br i1 %r1459, label %shadow.root.barrier.259, label %shadow.root.barrier.done.260

shadow.root.barrier.259:                          ; preds = %guarded_add.merge.258
  call void @js_write_barrier_root_nanbox(i64 %r1457) #9
  br label %shadow.root.barrier.done.260

shadow.root.barrier.done.260:                     ; preds = %shadow.root.barrier.259, %guarded_add.merge.258
  %r1460 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1461 = icmp ne i32 %r1460, 0
  br i1 %r1461, label %gcpoll.261, label %gcpoll.done.262

gcpoll.261:                                       ; preds = %shadow.root.barrier.done.260
  %statepoint_token272 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s40, ptr addrspace(1) %.2566, ptr addrspace(1) %.2572) ]
  %rs4gc.s40.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token272, i32 0, i32 0) ; (%rs4gc.s40, %rs4gc.s40)
  %r1135.1.base.relocated273 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token272, i32 1, i32 1) ; (%.2566, %.2566)
  %r1135.1.relocated274 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token272, i32 1, i32 2) ; (%.2566, %.2572)
  br label %gcpoll.done.262

gcpoll.done.262:                                  ; preds = %gcpoll.261, %shadow.root.barrier.done.260
  %.0574 = phi ptr addrspace(1) [ %rs4gc.s40.relocated, %gcpoll.261 ], [ %rs4gc.s40, %shadow.root.barrier.done.260 ]
  %.3573 = phi ptr addrspace(1) [ %r1135.1.relocated274, %gcpoll.261 ], [ %.2572, %shadow.root.barrier.done.260 ]
  %.3567 = phi ptr addrspace(1) [ %r1135.1.base.relocated273, %gcpoll.261 ], [ %.2566, %shadow.root.barrier.done.260 ]
  br label %for.update.201

for.cond.263:                                     ; preds = %for.update.265, %for.exit.202
  %.0542 = phi ptr addrspace(1) [ %r1135.0, %for.exit.202 ], [ %.20562, %for.update.265 ]
  %.0530 = phi ptr addrspace(1) [ %r1135.0.base, %for.exit.202 ], [ %.20, %for.update.265 ]
  %r1466.0 = phi i32 [ 0, %for.exit.202 ], [ %r2514, %for.update.265 ]
  %r1142.1 = phi ptr addrspace(1) [ %r1142.0, %for.exit.202 ], [ %.0605, %for.update.265 ]
  %r1468 = sitofp i32 %r1466.0 to double
  %r1469.rs4i = ptrtoint ptr addrspace(1) %.0542 to i64
  %r1469.rs4o = call i64 asm "", "=r,0"(i64 %r1469.rs4i) #9
  %r1469 = bitcast i64 %r1469.rs4o to double
  %r1470 = bitcast double %r1469 to i64
  %r1471 = and i64 %r1470, 281474976710655
  %r1472 = lshr i64 %r1470, 48
  %r1473 = and i64 %r1472, 65533
  %r1474 = icmp eq i64 %r1473, 32765
  %r1475 = icmp ugt i64 %r1471, 1048575
  %r1476 = and i1 %r1474, %r1475
  br i1 %r1476, label %plen.check_gc.267, label %plen.slow.269

for.body.264:                                     ; preds = %gcpoll.done.289
  %r1583.rs4i = ptrtoint ptr addrspace(1) %.3545 to i64
  %r1583.rs4o = call i64 asm "", "=r,0"(i64 %r1583.rs4i) #9
  %r1583 = bitcast i64 %r1583.rs4o to double
  %r1585 = bitcast double %r1583 to i64
  %r1586 = and i64 %r1585, 281474976710655
  %r1587 = lshr i64 %r1585, 48
  %r1588 = icmp eq i64 %r1587, 32765
  %r1589 = icmp ugt i64 %r1586, 1048575
  %r1590 = and i1 %r1588, %r1589
  br i1 %r1590, label %arr.guard.deref.294, label %arr.fallback.291

for.update.265:                                   ; preds = %gcpoll.done.488
  %r2514 = add i32 %r1466.0, 1
  %r2515 = sitofp i32 %r1466.0 to double
  %r2516 = sitofp i32 %r2514 to double
  br label %for.cond.263

for.exit.266:                                     ; preds = %gcpoll.done.289
  %statepoint_token275 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2577, ptr addrspace(1) %.3545, ptr addrspace(1) %.3533) ]
  %r2517276 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token275)
  %r1142.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token275, i32 0, i32 0) ; (%.2577, %.2577)
  %r1135.0.relocated277 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token275, i32 2, i32 1) ; (%.3533, %.3545)
  %r1135.0.base.relocated278 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token275, i32 2, i32 2) ; (%.3533, %.3533)
  %rs4gc.s41 = inttoptr i64 %r2517276 to ptr addrspace(1)
  %r2518.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s41 to i64
  %r2518 = call i64 asm "", "=r,0"(i64 %r2518.rs4i) #9
  %r2519 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2520 = icmp ne i32 %r2519, 0
  br i1 %r2520, label %shadow.root.barrier.489, label %shadow.root.barrier.done.490

plen.check_gc.267:                                ; preds = %for.cond.263
  %r1477 = sub nuw nsw i64 %r1471, 8
  %r1478 = inttoptr i64 %r1477 to ptr
  %r1479 = load i8, ptr %r1478, align 1
  %r1480 = icmp eq i8 %r1479, 1
  %r1481 = icmp eq i8 %r1479, 3
  %r1482 = or i1 %r1480, %r1481
  %r1483 = sub nuw nsw i64 %r1471, 7
  %r1484 = inttoptr i64 %r1483 to ptr
  %r1485 = load i8, ptr %r1484, align 1
  %r1486 = and i8 %r1485, -128
  %r1487 = icmp eq i8 %r1486, 0
  %r1488 = and i1 %r1482, %r1487
  br i1 %r1488, label %plen.fast.268, label %plen.slow.269

plen.fast.268:                                    ; preds = %plen.check_gc.267
  %r1490 = inttoptr i64 %r1471 to ptr
  %r1491 = select i1 false, ptr @perry_null_guard_zero_test_json_string_emitters_ts, ptr %r1490
  %r1492 = load i32, ptr %r1491, align 4
  %r1493 = uitofp i32 %r1492 to double
  br label %plen.merge.270

plen.slow.269:                                    ; preds = %plen.check_gc.267, %for.cond.263
  %r1494 = lshr i64 %r1470, 48
  %r1495 = icmp eq i64 %r1494, 32765
  %r1496 = icmp uge i64 %r1471, 2199023255552
  %r1497 = icmp ult i64 %r1471, 140737488355328
  %r1498 = and i1 %r1495, %r1496
  %r1499 = and i1 %r1498, %r1497
  %r1500 = load ptr, ptr @perry_ic_test_json_string_emitters_ts__24, align 8
  br i1 %r1499, label %plen.ic.header.271, label %plen.ic.miss.283

plen.merge.270:                                   ; preds = %plen.ic.merge.284, %plen.fast.268
  %.0575 = phi ptr addrspace(1) [ %r1142.1, %plen.fast.268 ], [ %.1576, %plen.ic.merge.284 ]
  %.1543 = phi ptr addrspace(1) [ %.0542, %plen.fast.268 ], [ %.2544, %plen.ic.merge.284 ]
  %.1531 = phi ptr addrspace(1) [ %.0530, %plen.fast.268 ], [ %.2532, %plen.ic.merge.284 ]
  %r1575 = phi double [ %r1493, %plen.fast.268 ], [ %r1574, %plen.ic.merge.284 ]
  %r1576 = fcmp olt double %r1468, %r1575
  %r1577 = select i1 %r1576, i64 9222246136947933188, i64 9222246136947933187
  %r1578 = bitcast i64 %r1577 to double
  %r1580 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1581 = icmp ne i32 %r1580, 0
  br i1 %r1581, label %gcpoll.288, label %gcpoll.done.289

plen.ic.header.271:                               ; preds = %plen.slow.269
  %r1502 = sub nuw nsw i64 %r1471, 8
  %r1503 = inttoptr i64 %r1502 to ptr
  %r1504 = load i8, ptr %r1503, align 1
  %r1505 = icmp eq i8 %r1504, 2
  %r1506 = sub nuw nsw i64 %r1471, 7
  %r1507 = inttoptr i64 %r1506 to ptr
  %r1508 = load i8, ptr %r1507, align 1
  %r1509 = and i8 %r1508, -128
  %r1510 = icmp eq i8 %r1509, 0
  %r1511 = and i1 %r1505, %r1510
  br i1 %r1511, label %plen.elem.meta.285, label %plen.ic.miss.283

plen.ic.shape.272:                                ; preds = %plen.elem.store.286, %plen.elem.meta.285
  %r1501 = icmp ne ptr %r1500, null
  br i1 %r1501, label %plen.ic.shape.probe.273, label %plen.ic.miss.283

plen.ic.shape.probe.273:                          ; preds = %plen.ic.shape.272
  %r1523 = inttoptr i64 %r1471 to ptr
  %r1524 = load i32, ptr %r1523, align 4
  %r1525 = add nuw nsw i64 %r1471, 4
  %r1526 = inttoptr i64 %r1525 to ptr
  %r1527 = load i32, ptr %r1526, align 4
  %r1528 = zext i32 %r1524 to i64
  %r1529 = zext i32 %r1527 to i64
  %r1530 = shl nuw i64 %r1528, 32
  %r1531 = or i64 %r1530, %r1529
  %r1532 = getelementptr i64, ptr %r1500, i64 0
  %r1533 = load i64, ptr %r1532, align 8
  %r1534 = icmp ne i64 %r1533, 0
  br i1 %r1534, label %plen.ic.identity.274, label %plen.ic.miss.283

plen.ic.identity.274:                             ; preds = %plen.ic.shape.probe.273
  %r1535 = and i64 %r1533, -9223372036854775808
  %1 = icmp slt i64 %r1533, 0
  br i1 %1, label %plen.ic.family_meta.276, label %plen.ic.exact.275

plen.ic.exact.275:                                ; preds = %plen.ic.identity.274
  %r1537 = icmp eq i64 %r1531, %r1533
  br i1 %r1537, label %plen.ic.slot.278, label %plen.ic.miss.283

plen.ic.family_meta.276:                          ; preds = %plen.ic.identity.274
  %r1538 = add nuw nsw i64 %r1471, 8
  %r1539 = inttoptr i64 %r1538 to ptr
  %r1540 = load i64, ptr %r1539, align 8
  %r1541 = icmp ne i64 %r1540, 0
  br i1 %r1541, label %plen.ic.family_token.277, label %plen.ic.miss.283

plen.ic.family_token.277:                         ; preds = %plen.ic.family_meta.276
  %r1542 = inttoptr i64 %r1540 to ptr
  %r1543 = getelementptr i64, ptr %r1542, i64 6
  %r1544 = load i64, ptr %r1543, align 8
  %r1545 = icmp eq i64 %r1544, %r1533
  br i1 %r1545, label %plen.ic.slot.278, label %plen.ic.miss.283

plen.ic.slot.278:                                 ; preds = %plen.ic.family_token.277, %plen.ic.exact.275
  %r1546 = getelementptr i64, ptr %r1500, i64 1
  %r1547 = load i64, ptr %r1546, align 8
  %r1548 = getelementptr i64, ptr %r1500, i64 2
  %r1549 = load i64, ptr %r1548, align 8
  %r1550 = icmp ult i64 %r1547, %r1549
  br i1 %r1550, label %plen.ic.inline.279, label %plen.ic.spill_meta.280

plen.ic.inline.279:                               ; preds = %plen.ic.slot.278
  %r1551 = shl i64 %r1547, 3
  %r1552 = add i64 %r1551, 16
  %r1553 = add i64 %r1471, %r1552
  %r1554 = inttoptr i64 %r1553 to ptr
  %r1555 = load double, ptr %r1554, align 8
  br label %plen.ic.merge.284

plen.ic.spill_meta.280:                           ; preds = %plen.ic.slot.278
  %r1556 = add nuw nsw i64 %r1471, 8
  %r1557 = inttoptr i64 %r1556 to ptr
  %r1558 = load i64, ptr %r1557, align 8
  %r1559 = icmp ne i64 %r1558, 0
  br i1 %r1559, label %plen.ic.spill_ptr.281, label %plen.ic.miss.283

plen.ic.spill_ptr.281:                            ; preds = %plen.ic.spill_meta.280
  %r1560 = inttoptr i64 %r1558 to ptr
  %r1561 = getelementptr i64, ptr %r1560, i64 4
  %r1562 = load i64, ptr %r1561, align 8
  %r1563 = icmp ne i64 %r1562, 0
  %r1564 = select i1 %r1563, i64 %r1562, i64 %r1558
  %r1565 = inttoptr i64 %r1564 to ptr
  %r1566 = load i32, ptr %r1565, align 4
  %r1567 = zext i32 %r1566 to i64
  %r1568 = icmp ult i64 %r1547, %r1567
  %r1569 = and i1 %r1563, %r1568
  br i1 %r1569, label %plen.ic.spill_load.282, label %plen.ic.miss.283

plen.ic.spill_load.282:                           ; preds = %plen.ic.spill_ptr.281
  %r1570 = add nuw nsw i64 %r1547, 1
  %r1571 = getelementptr inbounds nuw i64, ptr %r1565, i64 %r1570
  %r1572 = load double, ptr %r1571, align 8
  br label %plen.ic.merge.284

plen.ic.miss.283:                                 ; preds = %plen.ic.spill_ptr.281, %plen.ic.spill_meta.280, %plen.ic.family_token.277, %plen.ic.family_meta.276, %plen.ic.exact.275, %plen.ic.shape.probe.273, %plen.ic.shape.272, %plen.ic.header.271, %plen.slow.269
  %statepoint_token279 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r1469, ptr @perry_ic_test_json_string_emitters_ts__24, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1142.1, ptr addrspace(1) %.0530, ptr addrspace(1) %.0542) ]
  %r1573280 = call double @llvm.experimental.gc.result.f64(token %statepoint_token279)
  %r1142.1.relocated281 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token279, i32 0, i32 0) ; (%r1142.1, %r1142.1)
  %r1135.0.base.relocated282 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token279, i32 1, i32 1) ; (%.0530, %.0530)
  %r1135.0.relocated283 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token279, i32 1, i32 2) ; (%.0530, %.0542)
  br label %plen.ic.merge.284

plen.ic.merge.284:                                ; preds = %plen.elem.length.287, %plen.ic.miss.283, %plen.ic.spill_load.282, %plen.ic.inline.279
  %.1576 = phi ptr addrspace(1) [ %r1142.1, %plen.elem.length.287 ], [ %r1142.1, %plen.ic.inline.279 ], [ %r1142.1, %plen.ic.spill_load.282 ], [ %r1142.1.relocated281, %plen.ic.miss.283 ]
  %.2544 = phi ptr addrspace(1) [ %.0542, %plen.elem.length.287 ], [ %.0542, %plen.ic.inline.279 ], [ %.0542, %plen.ic.spill_load.282 ], [ %r1135.0.relocated283, %plen.ic.miss.283 ]
  %.2532 = phi ptr addrspace(1) [ %.0530, %plen.elem.length.287 ], [ %.0530, %plen.ic.inline.279 ], [ %.0530, %plen.ic.spill_load.282 ], [ %r1135.0.base.relocated282, %plen.ic.miss.283 ]
  %r1574 = phi double [ %r1522, %plen.elem.length.287 ], [ %r1555, %plen.ic.inline.279 ], [ %r1572, %plen.ic.spill_load.282 ], [ %r1573280, %plen.ic.miss.283 ]
  br label %plen.merge.270

plen.elem.meta.285:                               ; preds = %plen.ic.header.271
  %r1512 = add nuw nsw i64 %r1471, 8
  %r1513 = inttoptr i64 %r1512 to ptr
  %r1514 = load i64, ptr %r1513, align 8
  %r1515 = icmp ne i64 %r1514, 0
  br i1 %r1515, label %plen.elem.store.286, label %plen.ic.shape.272

plen.elem.store.286:                              ; preds = %plen.elem.meta.285
  %r1516 = inttoptr i64 %r1514 to ptr
  %r1517 = getelementptr i64, ptr %r1516, i64 12
  %r1518 = load i64, ptr %r1517, align 8
  %r1519 = icmp ne i64 %r1518, 0
  br i1 %r1519, label %plen.elem.length.287, label %plen.ic.shape.272

plen.elem.length.287:                             ; preds = %plen.elem.store.286
  %r1520 = inttoptr i64 %r1518 to ptr
  %r1521 = load i32, ptr %r1520, align 4
  %r1522 = uitofp i32 %r1521 to double
  br label %plen.ic.merge.284

gcpoll.288:                                       ; preds = %plen.merge.270
  %statepoint_token284 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0575, ptr addrspace(1) %.1531, ptr addrspace(1) %.1543) ]
  %r1142.1.relocated285 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 0, i32 0) ; (%.0575, %.0575)
  %r1135.0.base.relocated286 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 1, i32 1) ; (%.1531, %.1531)
  %r1135.0.relocated287 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 1, i32 2) ; (%.1531, %.1543)
  br label %gcpoll.done.289

gcpoll.done.289:                                  ; preds = %gcpoll.288, %plen.merge.270
  %.2577 = phi ptr addrspace(1) [ %r1142.1.relocated285, %gcpoll.288 ], [ %.0575, %plen.merge.270 ]
  %.3545 = phi ptr addrspace(1) [ %r1135.0.relocated287, %gcpoll.288 ], [ %.1543, %plen.merge.270 ]
  %.3533 = phi ptr addrspace(1) [ %r1135.0.base.relocated286, %gcpoll.288 ], [ %.1531, %plen.merge.270 ]
  %r1579 = icmp eq i64 %r1577, 9222246136947933188
  br i1 %r1579, label %for.body.264, label %for.exit.266

arr.fast.290:                                     ; preds = %arr.guard.range.296
  %r1646 = zext i32 %r1466.0 to i64
  %r1647 = shl nuw nsw i64 %r1646, 3
  %r1648 = add nuw nsw i64 %r1647, 8
  %r1649 = add i64 %r1605, %r1648
  %r1650 = inttoptr i64 %r1649 to ptr
  %r1651 = load double, ptr %r1650, align 8
  %r1652 = bitcast double %r1651 to i64
  %r1653 = icmp eq i64 %r1652, 9222246136947933200
  %r1655 = select i1 %r1653, double 0x7FFC000000000001, double %r1651
  br label %arr.merge.293

arr.fallback.291:                                 ; preds = %arr.guard.live.295, %arr.guard.deref.294, %for.body.264
  %r1644 = sitofp i32 %r1466.0 to double
  %statepoint_token288 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 6553530643794362393, double %r1583, double %r1644, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2577, ptr addrspace(1) %.3533, ptr addrspace(1) %.3545) ]
  %r1645289 = call double @llvm.experimental.gc.result.f64(token %statepoint_token288)
  %r1142.1.relocated290 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token288, i32 0, i32 0) ; (%.2577, %.2577)
  %r1135.0.base.relocated291 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token288, i32 1, i32 1) ; (%.3533, %.3533)
  %r1135.0.relocated292 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token288, i32 1, i32 2) ; (%.3533, %.3545)
  br label %arr.merge.293

arr.guard.oob.292:                                ; preds = %arr.guard.range.296
  br label %arr.merge.293

arr.merge.293:                                    ; preds = %arr.guard.oob.292, %arr.fallback.291, %arr.fast.290
  %.3578 = phi ptr addrspace(1) [ %.2577, %arr.fast.290 ], [ %.2577, %arr.guard.oob.292 ], [ %r1142.1.relocated290, %arr.fallback.291 ]
  %.4546 = phi ptr addrspace(1) [ %.3545, %arr.fast.290 ], [ %.3545, %arr.guard.oob.292 ], [ %r1135.0.relocated292, %arr.fallback.291 ]
  %.4534 = phi ptr addrspace(1) [ %.3533, %arr.fast.290 ], [ %.3533, %arr.guard.oob.292 ], [ %r1135.0.base.relocated291, %arr.fallback.291 ]
  %r1656 = phi double [ %r1655, %arr.fast.290 ], [ %r1645289, %arr.fallback.291 ], [ 0x7FFC000000000001, %arr.guard.oob.292 ]
  %statepoint_token293 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r1656, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4534, ptr addrspace(1) %.3578, ptr addrspace(1) %.4546) ]
  %r1657294 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token293)
  %r1135.0.base.relocated295 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token293, i32 0, i32 0) ; (%.4534, %.4534)
  %r1142.1.relocated296 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token293, i32 1, i32 1) ; (%.3578, %.3578)
  %r1135.0.relocated297 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token293, i32 0, i32 2) ; (%.4534, %.4546)
  %statepoint_token298 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r1657294, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1135.0.base.relocated295, ptr addrspace(1) %r1142.1.relocated296, ptr addrspace(1) %r1135.0.relocated297) ]
  %r1658299 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token298)
  %r1135.0.base.relocated300 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token298, i32 0, i32 0) ; (%r1135.0.base.relocated295, %r1135.0.base.relocated295)
  %r1142.1.relocated301 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token298, i32 1, i32 1) ; (%r1142.1.relocated296, %r1142.1.relocated296)
  %r1135.0.relocated302 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token298, i32 0, i32 2) ; (%r1135.0.base.relocated295, %r1135.0.relocated297)
  %r1659 = bitcast i64 %r1658299 to double
  %rs4gc.b42 = bitcast double %r1659 to i64
  %rs4gc.s42 = inttoptr i64 %rs4gc.b42 to ptr addrspace(1)
  %r1660.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s42 to i64
  %r1660 = call i64 asm "", "=r,0"(i64 %r1660.rs4i) #9
  %r1661 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1662 = icmp ne i32 %r1661, 0
  br i1 %r1662, label %shadow.root.barrier.297, label %shadow.root.barrier.done.298

arr.guard.deref.294:                              ; preds = %for.body.264
  %r1591 = bitcast double %r1583 to i64
  %r1592 = and i64 %r1591, 281474976710655
  %r1593 = sub nsw i64 %r1592, 8
  %r1594 = inttoptr i64 %r1593 to ptr
  %r1595 = load i8, ptr %r1594, align 1
  %r1596 = icmp eq i8 %r1595, 1
  %r1597 = sub nsw i64 %r1592, 7
  %r1598 = inttoptr i64 %r1597 to ptr
  %r1599 = load i8, ptr %r1598, align 1
  %r1600 = and i8 %r1599, -128
  %r1601 = icmp ne i8 %r1600, 0
  %r1602 = inttoptr i64 %r1592 to ptr
  %r1603 = load i64, ptr %r1602, align 8
  %r1604 = and i1 %r1596, %r1601
  %r1605 = select i1 %r1604, i64 %r1603, i64 %r1592
  %r1606 = lshr i64 %r1605, 48
  %r1607 = icmp eq i64 %r1606, 0
  %r1608 = icmp ugt i64 %r1605, 1048575
  %r1609 = and i1 %r1607, %r1608
  br i1 %r1609, label %arr.guard.live.295, label %arr.fallback.291

arr.guard.live.295:                               ; preds = %arr.guard.deref.294
  %r1610 = sub nuw i64 %r1605, 8
  %r1611 = inttoptr i64 %r1610 to ptr
  %r1612 = load i8, ptr %r1611, align 1
  %r1613 = icmp eq i8 %r1612, 1
  %r1614 = sub nuw i64 %r1605, 7
  %r1615 = inttoptr i64 %r1614 to ptr
  %r1616 = load i8, ptr %r1615, align 1
  %r1617 = and i8 %r1616, -128
  %r1618 = icmp eq i8 %r1617, 0
  %r1619 = sub nuw i64 %r1605, 6
  %r1620 = inttoptr i64 %r1619 to ptr
  %r1621 = load i16, ptr %r1620, align 2
  %r1622 = and i16 %r1621, 1024
  %r1623 = icmp eq i16 %r1622, 0
  %r1624 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1625 = icmp eq i8 %r1624, 0
  %r1626 = inttoptr i64 %r1605 to ptr
  %r1627 = load i32, ptr %r1626, align 4
  %r1628 = getelementptr i8, ptr %r1626, i64 4
  %r1629 = load i32, ptr %r1628, align 4
  %r1630 = icmp slt i32 %r1466.0, 0
  %r1631 = icmp eq i1 %r1630, false
  %r1633 = icmp ule i32 %r1627, 16000000
  %r1634 = icmp ule i32 %r1629, 16000000
  %r1635 = icmp ule i32 %r1627, %r1629
  %r1636 = and i1 %r1613, %r1618
  %r1637 = and i1 %r1636, %r1623
  %r1638 = and i1 %r1637, %r1625
  %r1639 = and i1 %r1638, %r1631
  %r1640 = and i1 %r1639, %r1633
  %r1641 = and i1 %r1640, %r1634
  %r1642 = and i1 %r1641, %r1635
  br i1 %r1642, label %arr.guard.range.296, label %arr.fallback.291

arr.guard.range.296:                              ; preds = %arr.guard.live.295
  %r1632 = icmp ult i32 %r1466.0, %r1627
  br i1 %r1632, label %arr.fast.290, label %arr.guard.oob.292

shadow.root.barrier.297:                          ; preds = %arr.merge.293
  call void @js_write_barrier_root_nanbox(i64 %r1660) #9
  br label %shadow.root.barrier.done.298

shadow.root.barrier.done.298:                     ; preds = %shadow.root.barrier.297, %arr.merge.293
  %r1663.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s42 to i64
  %r1663.rs4o = call i64 asm "", "=r,0"(i64 %r1663.rs4i) #9
  %r1663 = bitcast i64 %r1663.rs4o to double
  %r1664 = bitcast double %r1663 to i64
  %r1665 = and i64 %r1664, 281474976710655
  %r1666 = lshr i64 %r1664, 48
  %r1667 = and i64 %r1666, 65533
  %r1668 = icmp eq i64 %r1667, 32765
  br i1 %r1668, label %pget.recv_ok.300, label %pget.recv_other.304

pget.recv_sso.299:                                ; preds = %pget.recv_other.304
  %r1806 = load double, ptr @test_json_string_emitters_ts_.str.3.handle, align 8
  %r1807 = bitcast double %r1806 to i64
  %r1808 = and i64 %r1807, 281474976710655
  %statepoint_token303 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1664, i64 %r1808, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1135.0.base.relocated300, ptr addrspace(1) %rs4gc.s42, ptr addrspace(1) %r1142.1.relocated301, ptr addrspace(1) %r1135.0.relocated302) ]
  %r1809304 = call double @llvm.experimental.gc.result.f64(token %statepoint_token303)
  %r1135.0.base.relocated305 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token303, i32 0, i32 0) ; (%r1135.0.base.relocated300, %r1135.0.base.relocated300)
  %rs4gc.s42.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token303, i32 1, i32 1) ; (%rs4gc.s42, %rs4gc.s42)
  %r1142.1.relocated306 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token303, i32 2, i32 2) ; (%r1142.1.relocated301, %r1142.1.relocated301)
  %r1135.0.relocated307 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token303, i32 0, i32 3) ; (%r1135.0.base.relocated300, %r1135.0.relocated302)
  br label %pget.recv_merge.303

pget.recv_ok.300:                                 ; preds = %shadow.root.barrier.done.298
  %r1675 = icmp ugt i64 %r1665, 1048575
  br i1 %r1675, label %pic.recv_hdr.321, label %pic.miss.cold.318

pget.recv_bad.301:                                ; preds = %pget.check_class_ref.305
  %r1798 = icmp eq i64 %r1664, 9222246136947933185
  %r1799 = icmp eq i64 %r1664, 9222246136947933186
  %r1800 = or i1 %r1798, %r1799
  br i1 %r1800, label %pget.throw_nullish.328, label %pget.recv_undef_return.329

pget.recv_class_ref.302:                          ; preds = %pget.check_class_ref.305
  %r1671 = load double, ptr @test_json_string_emitters_ts_.str.3.handle, align 8
  %r1672 = bitcast double %r1671 to i64
  %r1673 = and i64 %r1672, 281474976710655
  %statepoint_token308 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6553530643794362394, i64 %r1664, i64 %r1673, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1135.0.base.relocated300, ptr addrspace(1) %rs4gc.s42, ptr addrspace(1) %r1142.1.relocated301, ptr addrspace(1) %r1135.0.relocated302) ]
  %r1674309 = call double @llvm.experimental.gc.result.f64(token %statepoint_token308)
  %r1135.0.base.relocated310 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token308, i32 0, i32 0) ; (%r1135.0.base.relocated300, %r1135.0.base.relocated300)
  %rs4gc.s42.relocated311 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token308, i32 1, i32 1) ; (%rs4gc.s42, %rs4gc.s42)
  %r1142.1.relocated312 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token308, i32 2, i32 2) ; (%r1142.1.relocated301, %r1142.1.relocated301)
  %r1135.0.relocated313 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token308, i32 0, i32 3) ; (%r1135.0.base.relocated300, %r1135.0.relocated302)
  br label %pget.recv_merge.303

pget.recv_merge.303:                              ; preds = %pget.recv_undef_return.329, %pic.merge.320, %pget.recv_class_ref.302, %pget.recv_sso.299
  %.0591 = phi ptr addrspace(1) [ %.1592, %pic.merge.320 ], [ %rs4gc.s42.relocated, %pget.recv_sso.299 ], [ %rs4gc.s42.relocated311, %pget.recv_class_ref.302 ], [ %rs4gc.s42.relocated330, %pget.recv_undef_return.329 ]
  %.4579 = phi ptr addrspace(1) [ %.5580, %pic.merge.320 ], [ %r1142.1.relocated306, %pget.recv_sso.299 ], [ %r1142.1.relocated312, %pget.recv_class_ref.302 ], [ %r1142.1.relocated331, %pget.recv_undef_return.329 ]
  %.5547 = phi ptr addrspace(1) [ %.6548, %pic.merge.320 ], [ %r1135.0.relocated307, %pget.recv_sso.299 ], [ %r1135.0.relocated313, %pget.recv_class_ref.302 ], [ %r1135.0.relocated332, %pget.recv_undef_return.329 ]
  %.5535 = phi ptr addrspace(1) [ %.6536, %pic.merge.320 ], [ %r1135.0.base.relocated305, %pget.recv_sso.299 ], [ %r1135.0.base.relocated310, %pget.recv_class_ref.302 ], [ %r1135.0.base.relocated329, %pget.recv_undef_return.329 ]
  %r1810 = phi double [ %r1797, %pic.merge.320 ], [ %r1805328, %pget.recv_undef_return.329 ], [ %r1809304, %pget.recv_sso.299 ], [ %r1674309, %pget.recv_class_ref.302 ]
  %r1812 = sitofp i32 %r1466.0 to double
  %r1813 = bitcast double %r1810 to i64
  %r1814 = lshr i64 %r1813, 48
  %r1815 = icmp eq i64 %r1814, 32766
  %r1816 = trunc i64 %r1813 to i32
  %r1817 = sitofp i32 %r1816 to double
  %r1818 = select i1 %r1815, double %r1817, double %r1810
  %r1819 = bitcast double %r1812 to i64
  %r1820 = lshr i64 %r1819, 48
  %r1821 = icmp eq i64 %r1820, 32766
  %r1822 = trunc i64 %r1819 to i32
  %r1823 = sitofp i32 %r1822 to double
  %r1824 = select i1 %r1821, double %r1823, double %r1812
  %r1825 = fcmp une double %r1818, %r1824
  %r1826 = select i1 %r1825, i64 9222246136947933188, i64 9222246136947933187
  %r1827 = bitcast i64 %r1826 to double
  %r1828 = icmp eq i64 %r1826, 9222246136947933188
  br i1 %r1828, label %logical.merge.331, label %logical.then.330

pget.recv_other.304:                              ; preds = %shadow.root.barrier.done.298
  %r1669 = icmp eq i64 %r1666, 32761
  br i1 %r1669, label %pget.recv_sso.299, label %pget.check_class_ref.305

pget.check_class_ref.305:                         ; preds = %pget.recv_other.304
  %r1670 = icmp eq i64 %r1666, 32766
  br i1 %r1670, label %pget.recv_class_ref.302, label %pget.recv_bad.301

pic.hit.306:                                      ; preds = %pic.token.322
  %r1700 = getelementptr i64, ptr %r1685, i64 1
  %r1701 = load i64, ptr %r1700, align 8
  %r1702 = and i64 %r1701, 1073741824
  %r1703 = icmp ne i64 %r1702, 0
  br i1 %r1703, label %pic.hit.overflow.323, label %pic.hit.inline.324

pic.hit.live.307:                                 ; preds = %pic.hit.inline.324
  br label %pic.merge.320

pic.prefix.guard.308:                             ; preds = %pic.token.322
  %r1716 = getelementptr i64, ptr %r1685, i64 2
  %r1717 = load i64, ptr %r1716, align 8
  %r1718 = icmp ne i64 %r1717, 0
  br i1 %r1718, label %pic.prefix.meta.309, label %pic.miss.317

pic.prefix.meta.309:                              ; preds = %pic.prefix.guard.308
  %r1719 = add nuw nsw i64 %r1665, 8
  %r1720 = inttoptr i64 %r1719 to ptr
  %r1721 = load i64, ptr %r1720, align 8
  %r1722 = icmp ne i64 %r1721, 0
  br i1 %r1722, label %pic.prefix.token.310, label %pic.miss.317

pic.prefix.token.310:                             ; preds = %pic.prefix.meta.309
  %r1723 = inttoptr i64 %r1721 to ptr
  %r1724 = getelementptr i64, ptr %r1723, i64 6
  %r1725 = load i64, ptr %r1724, align 8
  %r1726 = icmp eq i64 %r1725, %r1717
  br i1 %r1726, label %pic.prefix.hit.311, label %pic.miss.317

pic.prefix.hit.311:                               ; preds = %pic.prefix.token.310
  %r1727 = getelementptr i64, ptr %r1685, i64 1
  %r1728 = load i64, ptr %r1727, align 8
  %r1729 = shl i64 %r1728, 3
  %r1730 = add nuw nsw i64 %r1665, 16
  %r1731 = add i64 %r1730, %r1729
  %r1732 = inttoptr i64 %r1731 to ptr
  %r1733 = load double, ptr %r1732, align 8
  br label %pic.merge.320

pic.desc.classify.312:                            ; preds = %pic.recv_hdr.321
  %r1689 = and i1 %r1679, %r1686
  br i1 %r1689, label %pic.desc.prefix.guard.313, label %pic.miss.cold.318

pic.desc.prefix.guard.313:                        ; preds = %pic.desc.classify.312
  %r1734 = getelementptr i64, ptr %r1685, i64 2
  %r1735 = load i64, ptr %r1734, align 8
  %r1736 = icmp ne i64 %r1735, 0
  br i1 %r1736, label %pic.desc.prefix.meta.314, label %pic.miss.cold.318

pic.desc.prefix.meta.314:                         ; preds = %pic.desc.prefix.guard.313
  %r1737 = add nuw nsw i64 %r1665, 8
  %r1738 = inttoptr i64 %r1737 to ptr
  %r1739 = load i64, ptr %r1738, align 8
  %r1740 = icmp ne i64 %r1739, 0
  br i1 %r1740, label %pic.desc.prefix.token.315, label %pic.miss.cold.318

pic.desc.prefix.token.315:                        ; preds = %pic.desc.prefix.meta.314
  %r1741 = inttoptr i64 %r1739 to ptr
  %r1742 = getelementptr i64, ptr %r1741, i64 6
  %r1743 = load i64, ptr %r1742, align 8
  %r1744 = icmp eq i64 %r1743, %r1735
  br i1 %r1744, label %pic.desc.prefix.hit.316, label %pic.miss.cold.318

pic.desc.prefix.hit.316:                          ; preds = %pic.desc.prefix.token.315
  %r1745 = getelementptr i64, ptr %r1685, i64 1
  %r1746 = load i64, ptr %r1745, align 8
  %r1747 = shl i64 %r1746, 3
  %r1748 = add nuw nsw i64 %r1665, 16
  %r1749 = add i64 %r1748, %r1747
  %r1750 = inttoptr i64 %r1749 to ptr
  %r1751 = load double, ptr %r1750, align 8
  br label %pic.merge.320

pic.miss.317:                                     ; preds = %pic.hit.inline.324, %pic.prefix.token.310, %pic.prefix.meta.309, %pic.prefix.guard.308
  %r1752 = getelementptr i64, ptr %r1685, i64 3
  %r1753 = load i64, ptr %r1752, align 8
  %r1754 = icmp sgt i64 %r1753, 0
  br i1 %r1754, label %pic.ways.325, label %pic.miss.call.319

pic.miss.cold.318:                                ; preds = %pic.desc.prefix.token.315, %pic.desc.prefix.meta.314, %pic.desc.prefix.guard.313, %pic.desc.classify.312, %pget.recv_ok.300
  br label %pic.miss.call.319

pic.miss.call.319:                                ; preds = %pic.way.load.326, %pic.ways.325, %pic.miss.cold.318, %pic.miss.317
  %r1793 = load double, ptr @test_json_string_emitters_ts_.str.3.handle, align 8
  %r1794 = bitcast double %r1793 to i64
  %r1795 = and i64 %r1794, 281474976710655
  %statepoint_token314 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1665, i64 %r1795, ptr @perry_ic_test_json_string_emitters_ts__27, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1135.0.base.relocated300, ptr addrspace(1) %rs4gc.s42, ptr addrspace(1) %r1142.1.relocated301, ptr addrspace(1) %r1135.0.relocated302) ]
  %r1796315 = call double @llvm.experimental.gc.result.f64(token %statepoint_token314)
  %r1135.0.base.relocated316 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 0, i32 0) ; (%r1135.0.base.relocated300, %r1135.0.base.relocated300)
  %rs4gc.s42.relocated317 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 1, i32 1) ; (%rs4gc.s42, %rs4gc.s42)
  %r1142.1.relocated318 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 2, i32 2) ; (%r1142.1.relocated301, %r1142.1.relocated301)
  %r1135.0.relocated319 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 0, i32 3) ; (%r1135.0.base.relocated300, %r1135.0.relocated302)
  br label %pic.merge.320

pic.merge.320:                                    ; preds = %pic.way.live.327, %pic.hit.overflow.323, %pic.miss.call.319, %pic.desc.prefix.hit.316, %pic.prefix.hit.311, %pic.hit.live.307
  %.1592 = phi ptr addrspace(1) [ %rs4gc.s42.relocated323, %pic.hit.overflow.323 ], [ %rs4gc.s42.relocated317, %pic.miss.call.319 ], [ %rs4gc.s42, %pic.way.live.327 ], [ %rs4gc.s42, %pic.hit.live.307 ], [ %rs4gc.s42, %pic.prefix.hit.311 ], [ %rs4gc.s42, %pic.desc.prefix.hit.316 ]
  %.5580 = phi ptr addrspace(1) [ %r1142.1.relocated324, %pic.hit.overflow.323 ], [ %r1142.1.relocated318, %pic.miss.call.319 ], [ %r1142.1.relocated301, %pic.way.live.327 ], [ %r1142.1.relocated301, %pic.hit.live.307 ], [ %r1142.1.relocated301, %pic.prefix.hit.311 ], [ %r1142.1.relocated301, %pic.desc.prefix.hit.316 ]
  %.6548 = phi ptr addrspace(1) [ %r1135.0.relocated325, %pic.hit.overflow.323 ], [ %r1135.0.relocated319, %pic.miss.call.319 ], [ %r1135.0.relocated302, %pic.way.live.327 ], [ %r1135.0.relocated302, %pic.hit.live.307 ], [ %r1135.0.relocated302, %pic.prefix.hit.311 ], [ %r1135.0.relocated302, %pic.desc.prefix.hit.316 ]
  %.6536 = phi ptr addrspace(1) [ %r1135.0.base.relocated322, %pic.hit.overflow.323 ], [ %r1135.0.base.relocated316, %pic.miss.call.319 ], [ %r1135.0.base.relocated300, %pic.way.live.327 ], [ %r1135.0.base.relocated300, %pic.hit.live.307 ], [ %r1135.0.base.relocated300, %pic.prefix.hit.311 ], [ %r1135.0.base.relocated300, %pic.desc.prefix.hit.316 ]
  %r1797 = phi double [ %r1713, %pic.hit.live.307 ], [ %r1708321, %pic.hit.overflow.323 ], [ %r1733, %pic.prefix.hit.311 ], [ %r1751, %pic.desc.prefix.hit.316 ], [ %r1790, %pic.way.live.327 ], [ %r1796315, %pic.miss.call.319 ]
  br label %pget.recv_merge.303

pic.recv_hdr.321:                                 ; preds = %pget.recv_ok.300
  %r1676 = sub nuw nsw i64 %r1665, 8
  %r1677 = inttoptr i64 %r1676 to ptr
  %r1678 = load i8, ptr %r1677, align 1
  %r1679 = icmp eq i8 %r1678, 2
  %r1680 = sub nuw nsw i64 %r1665, 6
  %r1681 = inttoptr i64 %r1680 to ptr
  %r1682 = load i16, ptr %r1681, align 2
  %r1683 = and i16 %r1682, 2048
  %r1684 = icmp eq i16 %r1683, 0
  %r1685 = load ptr, ptr @perry_ic_test_json_string_emitters_ts__27, align 8
  %r1686 = icmp ne ptr %r1685, null
  %r1687 = and i1 %r1679, %r1684
  %r1688 = and i1 %r1687, %r1686
  br i1 %r1688, label %pic.token.322, label %pic.desc.classify.312

pic.token.322:                                    ; preds = %pic.recv_hdr.321
  %r1690 = add nuw nsw i64 %r1665, 4
  %r1691 = inttoptr i64 %r1690 to ptr
  %r1692 = load i32, ptr %r1691, align 4
  %r1693 = zext i32 %r1692 to i64
  %r1694 = or i64 %r1693, 4611686018427387904
  %r1695 = icmp ne i32 %r1692, 0
  %r1696 = getelementptr i64, ptr %r1685, i64 0
  %r1697 = load i64, ptr %r1696, align 8
  %r1698 = icmp eq i64 %r1694, %r1697
  %r1699 = and i1 %r1698, %r1695
  br i1 %r1699, label %pic.hit.306, label %pic.prefix.guard.308

pic.hit.overflow.323:                             ; preds = %pic.hit.306
  %r1704 = load double, ptr @test_json_string_emitters_ts_.str.3.handle, align 8
  %r1705 = bitcast double %r1704 to i64
  %r1706 = and i64 %r1705, 281474976710655
  %r1707 = trunc i64 %r1701 to i32
  %statepoint_token320 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1665, i64 %r1706, i32 %r1707, ptr @perry_ic_test_json_string_emitters_ts__27, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1135.0.base.relocated300, ptr addrspace(1) %rs4gc.s42, ptr addrspace(1) %r1142.1.relocated301, ptr addrspace(1) %r1135.0.relocated302) ]
  %r1708321 = call double @llvm.experimental.gc.result.f64(token %statepoint_token320)
  %r1135.0.base.relocated322 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token320, i32 0, i32 0) ; (%r1135.0.base.relocated300, %r1135.0.base.relocated300)
  %rs4gc.s42.relocated323 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token320, i32 1, i32 1) ; (%rs4gc.s42, %rs4gc.s42)
  %r1142.1.relocated324 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token320, i32 2, i32 2) ; (%r1142.1.relocated301, %r1142.1.relocated301)
  %r1135.0.relocated325 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token320, i32 0, i32 3) ; (%r1135.0.base.relocated300, %r1135.0.relocated302)
  br label %pic.merge.320

pic.hit.inline.324:                               ; preds = %pic.hit.306
  %r1709 = shl i64 %r1701, 3
  %r1710 = add nuw nsw i64 %r1665, 16
  %r1711 = add i64 %r1710, %r1709
  %r1712 = inttoptr i64 %r1711 to ptr
  %r1713 = load double, ptr %r1712, align 8
  %r1714 = bitcast double %r1713 to i64
  %r1715 = icmp eq i64 %r1714, 9222246136947933200
  br i1 %r1715, label %pic.miss.317, label %pic.hit.live.307

pic.ways.325:                                     ; preds = %pic.miss.317
  %r1755 = getelementptr i64, ptr %r1685, i64 4
  %r1756 = load i64, ptr %r1755, align 8
  %r1757 = icmp eq i64 %r1756, %r1694
  %r1758 = getelementptr i64, ptr %r1685, i64 5
  %r1759 = load i64, ptr %r1758, align 8
  %r1760 = select i1 %r1757, i64 %r1759, i64 0
  %r1761 = getelementptr i64, ptr %r1685, i64 6
  %r1762 = load i64, ptr %r1761, align 8
  %r1763 = icmp eq i64 %r1762, %r1694
  %r1764 = getelementptr i64, ptr %r1685, i64 7
  %r1765 = load i64, ptr %r1764, align 8
  %r1766 = select i1 %r1763, i64 %r1765, i64 0
  %r1767 = getelementptr i64, ptr %r1685, i64 8
  %r1768 = load i64, ptr %r1767, align 8
  %r1769 = icmp eq i64 %r1768, %r1694
  %r1770 = getelementptr i64, ptr %r1685, i64 9
  %r1771 = load i64, ptr %r1770, align 8
  %r1772 = select i1 %r1769, i64 %r1771, i64 0
  %r1773 = getelementptr i64, ptr %r1685, i64 10
  %r1774 = load i64, ptr %r1773, align 8
  %r1775 = icmp eq i64 %r1774, %r1694
  %r1776 = getelementptr i64, ptr %r1685, i64 11
  %r1777 = load i64, ptr %r1776, align 8
  %r1778 = select i1 %r1775, i64 %r1777, i64 0
  %r1779 = or i1 %r1757, %r1763
  %r1780 = select i1 %r1757, i64 %r1760, i64 %r1766
  %r1781 = or i1 %r1769, %r1775
  %r1782 = select i1 %r1769, i64 %r1772, i64 %r1778
  %r1783 = or i1 %r1779, %r1781
  %r1784 = select i1 %r1779, i64 %r1780, i64 %r1782
  %r1785 = and i1 %r1695, %r1783
  br i1 %r1785, label %pic.way.load.326, label %pic.miss.call.319

pic.way.load.326:                                 ; preds = %pic.ways.325
  %r1786 = shl i64 %r1784, 3
  %r1787 = add nuw nsw i64 %r1665, 16
  %r1788 = add i64 %r1787, %r1786
  %r1789 = inttoptr i64 %r1788 to ptr
  %r1790 = load double, ptr %r1789, align 8
  %r1791 = bitcast double %r1790 to i64
  %r1792 = icmp eq i64 %r1791, 9222246136947933200
  br i1 %r1792, label %pic.miss.call.319, label %pic.way.live.327

pic.way.live.327:                                 ; preds = %pic.way.load.326
  br label %pic.merge.320

pget.throw_nullish.328:                           ; preds = %pget.recv_bad.301
  %r1801 = zext i1 %r1799 to i32
  %statepoint_token326 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1801, ptr @test_json_string_emitters_ts_.str.3.bytes, i64 2, i32 0, i32 0)
  unreachable

pget.recv_undef_return.329:                       ; preds = %pget.recv_bad.301
  %r1802 = load double, ptr @test_json_string_emitters_ts_.str.3.handle, align 8
  %r1803 = bitcast double %r1802 to i64
  %r1804 = and i64 %r1803, 281474976710655
  %statepoint_token327 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1664, i64 %r1804, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1135.0.base.relocated300, ptr addrspace(1) %rs4gc.s42, ptr addrspace(1) %r1142.1.relocated301, ptr addrspace(1) %r1135.0.relocated302) ]
  %r1805328 = call double @llvm.experimental.gc.result.f64(token %statepoint_token327)
  %r1135.0.base.relocated329 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token327, i32 0, i32 0) ; (%r1135.0.base.relocated300, %r1135.0.base.relocated300)
  %rs4gc.s42.relocated330 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token327, i32 1, i32 1) ; (%rs4gc.s42, %rs4gc.s42)
  %r1142.1.relocated331 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token327, i32 2, i32 2) ; (%r1142.1.relocated301, %r1142.1.relocated301)
  %r1135.0.relocated332 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token327, i32 0, i32 3) ; (%r1135.0.base.relocated300, %r1135.0.relocated302)
  br label %pget.recv_merge.303

logical.then.330:                                 ; preds = %pget.recv_merge.303
  %r1829.rs4i = ptrtoint ptr addrspace(1) %.0591 to i64
  %r1829.rs4o = call i64 asm "", "=r,0"(i64 %r1829.rs4i) #9
  %r1829 = bitcast i64 %r1829.rs4o to double
  %r1830 = bitcast double %r1829 to i64
  %r1831 = and i64 %r1830, 281474976710655
  %r1832 = lshr i64 %r1830, 48
  %r1833 = and i64 %r1832, 65533
  %r1834 = icmp eq i64 %r1833, 32765
  br i1 %r1834, label %pget.recv_ok.333, label %pget.recv_other.337

logical.merge.331:                                ; preds = %streqlit.merge.370, %pget.recv_merge.303
  %.2593 = phi ptr addrspace(1) [ %.0591, %pget.recv_merge.303 ], [ %.3594, %streqlit.merge.370 ]
  %.6581 = phi ptr addrspace(1) [ %.4579, %pget.recv_merge.303 ], [ %.7582, %streqlit.merge.370 ]
  %.7549 = phi ptr addrspace(1) [ %.5547, %pget.recv_merge.303 ], [ %.8550, %streqlit.merge.370 ]
  %.7537 = phi ptr addrspace(1) [ %.5535, %pget.recv_merge.303 ], [ %.8538, %streqlit.merge.370 ]
  %r2004 = phi double [ %r1827, %pget.recv_merge.303 ], [ %r2002, %streqlit.merge.370 ]
  %r2005 = phi i1 [ true, %pget.recv_merge.303 ], [ %r2003, %streqlit.merge.370 ]
  br i1 %r2005, label %logical.merge.372, label %logical.then.371

pget.recv_sso.332:                                ; preds = %pget.recv_other.337
  %r1972 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r1973 = bitcast double %r1972 to i64
  %r1974 = and i64 %r1973, 281474976710655
  %statepoint_token333 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1830, i64 %r1974, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5535, ptr addrspace(1) %.0591, ptr addrspace(1) %.4579, ptr addrspace(1) %.5547) ]
  %r1975334 = call double @llvm.experimental.gc.result.f64(token %statepoint_token333)
  %r1135.0.base.relocated335 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token333, i32 0, i32 0) ; (%.5535, %.5535)
  %rs4gc.s42.relocated336 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token333, i32 1, i32 1) ; (%.0591, %.0591)
  %r1142.1.relocated337 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token333, i32 2, i32 2) ; (%.4579, %.4579)
  %r1135.0.relocated338 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token333, i32 0, i32 3) ; (%.5535, %.5547)
  br label %pget.recv_merge.336

pget.recv_ok.333:                                 ; preds = %logical.then.330
  %r1841 = icmp ugt i64 %r1831, 1048575
  br i1 %r1841, label %pic.recv_hdr.354, label %pic.miss.cold.351

pget.recv_bad.334:                                ; preds = %pget.check_class_ref.338
  %r1964 = icmp eq i64 %r1830, 9222246136947933185
  %r1965 = icmp eq i64 %r1830, 9222246136947933186
  %r1966 = or i1 %r1964, %r1965
  br i1 %r1966, label %pget.throw_nullish.361, label %pget.recv_undef_return.362

pget.recv_class_ref.335:                          ; preds = %pget.check_class_ref.338
  %r1837 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r1838 = bitcast double %r1837 to i64
  %r1839 = and i64 %r1838, 281474976710655
  %statepoint_token339 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6553530643794362396, i64 %r1830, i64 %r1839, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5535, ptr addrspace(1) %.0591, ptr addrspace(1) %.4579, ptr addrspace(1) %.5547) ]
  %r1840340 = call double @llvm.experimental.gc.result.f64(token %statepoint_token339)
  %r1135.0.base.relocated341 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token339, i32 0, i32 0) ; (%.5535, %.5535)
  %rs4gc.s42.relocated342 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token339, i32 1, i32 1) ; (%.0591, %.0591)
  %r1142.1.relocated343 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token339, i32 2, i32 2) ; (%.4579, %.4579)
  %r1135.0.relocated344 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token339, i32 0, i32 3) ; (%.5535, %.5547)
  br label %pget.recv_merge.336

pget.recv_merge.336:                              ; preds = %pget.recv_undef_return.362, %pic.merge.353, %pget.recv_class_ref.335, %pget.recv_sso.332
  %.5596 = phi ptr addrspace(1) [ %.6597, %pic.merge.353 ], [ %rs4gc.s42.relocated336, %pget.recv_sso.332 ], [ %rs4gc.s42.relocated342, %pget.recv_class_ref.335 ], [ %rs4gc.s42.relocated361, %pget.recv_undef_return.362 ]
  %.9584 = phi ptr addrspace(1) [ %.10585, %pic.merge.353 ], [ %r1142.1.relocated337, %pget.recv_sso.332 ], [ %r1142.1.relocated343, %pget.recv_class_ref.335 ], [ %r1142.1.relocated362, %pget.recv_undef_return.362 ]
  %.10552 = phi ptr addrspace(1) [ %.11553, %pic.merge.353 ], [ %r1135.0.relocated338, %pget.recv_sso.332 ], [ %r1135.0.relocated344, %pget.recv_class_ref.335 ], [ %r1135.0.relocated363, %pget.recv_undef_return.362 ]
  %.10540 = phi ptr addrspace(1) [ %.11541, %pic.merge.353 ], [ %r1135.0.base.relocated335, %pget.recv_sso.332 ], [ %r1135.0.base.relocated341, %pget.recv_class_ref.335 ], [ %r1135.0.base.relocated360, %pget.recv_undef_return.362 ]
  %r1976 = phi double [ %r1963, %pic.merge.353 ], [ %r1971359, %pget.recv_undef_return.362 ], [ %r1975334, %pget.recv_sso.332 ], [ %r1840340, %pget.recv_class_ref.335 ]
  %r1977 = load double, ptr @test_json_string_emitters_ts_.str.29.handle, align 8
  %r1978 = bitcast double %r1976 to i64
  %r1979 = bitcast double %r1977 to i64
  %r1980 = icmp eq i64 %r1978, %r1979
  br i1 %r1980, label %streqlit.true.368, label %streqlit.tag.363

pget.recv_other.337:                              ; preds = %logical.then.330
  %r1835 = icmp eq i64 %r1832, 32761
  br i1 %r1835, label %pget.recv_sso.332, label %pget.check_class_ref.338

pget.check_class_ref.338:                         ; preds = %pget.recv_other.337
  %r1836 = icmp eq i64 %r1832, 32766
  br i1 %r1836, label %pget.recv_class_ref.335, label %pget.recv_bad.334

pic.hit.339:                                      ; preds = %pic.token.355
  %r1866 = getelementptr i64, ptr %r1851, i64 1
  %r1867 = load i64, ptr %r1866, align 8
  %r1868 = and i64 %r1867, 1073741824
  %r1869 = icmp ne i64 %r1868, 0
  br i1 %r1869, label %pic.hit.overflow.356, label %pic.hit.inline.357

pic.hit.live.340:                                 ; preds = %pic.hit.inline.357
  br label %pic.merge.353

pic.prefix.guard.341:                             ; preds = %pic.token.355
  %r1882 = getelementptr i64, ptr %r1851, i64 2
  %r1883 = load i64, ptr %r1882, align 8
  %r1884 = icmp ne i64 %r1883, 0
  br i1 %r1884, label %pic.prefix.meta.342, label %pic.miss.350

pic.prefix.meta.342:                              ; preds = %pic.prefix.guard.341
  %r1885 = add nuw nsw i64 %r1831, 8
  %r1886 = inttoptr i64 %r1885 to ptr
  %r1887 = load i64, ptr %r1886, align 8
  %r1888 = icmp ne i64 %r1887, 0
  br i1 %r1888, label %pic.prefix.token.343, label %pic.miss.350

pic.prefix.token.343:                             ; preds = %pic.prefix.meta.342
  %r1889 = inttoptr i64 %r1887 to ptr
  %r1890 = getelementptr i64, ptr %r1889, i64 6
  %r1891 = load i64, ptr %r1890, align 8
  %r1892 = icmp eq i64 %r1891, %r1883
  br i1 %r1892, label %pic.prefix.hit.344, label %pic.miss.350

pic.prefix.hit.344:                               ; preds = %pic.prefix.token.343
  %r1893 = getelementptr i64, ptr %r1851, i64 1
  %r1894 = load i64, ptr %r1893, align 8
  %r1895 = shl i64 %r1894, 3
  %r1896 = add nuw nsw i64 %r1831, 16
  %r1897 = add i64 %r1896, %r1895
  %r1898 = inttoptr i64 %r1897 to ptr
  %r1899 = load double, ptr %r1898, align 8
  br label %pic.merge.353

pic.desc.classify.345:                            ; preds = %pic.recv_hdr.354
  %r1855 = and i1 %r1845, %r1852
  br i1 %r1855, label %pic.desc.prefix.guard.346, label %pic.miss.cold.351

pic.desc.prefix.guard.346:                        ; preds = %pic.desc.classify.345
  %r1900 = getelementptr i64, ptr %r1851, i64 2
  %r1901 = load i64, ptr %r1900, align 8
  %r1902 = icmp ne i64 %r1901, 0
  br i1 %r1902, label %pic.desc.prefix.meta.347, label %pic.miss.cold.351

pic.desc.prefix.meta.347:                         ; preds = %pic.desc.prefix.guard.346
  %r1903 = add nuw nsw i64 %r1831, 8
  %r1904 = inttoptr i64 %r1903 to ptr
  %r1905 = load i64, ptr %r1904, align 8
  %r1906 = icmp ne i64 %r1905, 0
  br i1 %r1906, label %pic.desc.prefix.token.348, label %pic.miss.cold.351

pic.desc.prefix.token.348:                        ; preds = %pic.desc.prefix.meta.347
  %r1907 = inttoptr i64 %r1905 to ptr
  %r1908 = getelementptr i64, ptr %r1907, i64 6
  %r1909 = load i64, ptr %r1908, align 8
  %r1910 = icmp eq i64 %r1909, %r1901
  br i1 %r1910, label %pic.desc.prefix.hit.349, label %pic.miss.cold.351

pic.desc.prefix.hit.349:                          ; preds = %pic.desc.prefix.token.348
  %r1911 = getelementptr i64, ptr %r1851, i64 1
  %r1912 = load i64, ptr %r1911, align 8
  %r1913 = shl i64 %r1912, 3
  %r1914 = add nuw nsw i64 %r1831, 16
  %r1915 = add i64 %r1914, %r1913
  %r1916 = inttoptr i64 %r1915 to ptr
  %r1917 = load double, ptr %r1916, align 8
  br label %pic.merge.353

pic.miss.350:                                     ; preds = %pic.hit.inline.357, %pic.prefix.token.343, %pic.prefix.meta.342, %pic.prefix.guard.341
  %r1918 = getelementptr i64, ptr %r1851, i64 3
  %r1919 = load i64, ptr %r1918, align 8
  %r1920 = icmp sgt i64 %r1919, 0
  br i1 %r1920, label %pic.ways.358, label %pic.miss.call.352

pic.miss.cold.351:                                ; preds = %pic.desc.prefix.token.348, %pic.desc.prefix.meta.347, %pic.desc.prefix.guard.346, %pic.desc.classify.345, %pget.recv_ok.333
  br label %pic.miss.call.352

pic.miss.call.352:                                ; preds = %pic.way.load.359, %pic.ways.358, %pic.miss.cold.351, %pic.miss.350
  %r1959 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r1960 = bitcast double %r1959 to i64
  %r1961 = and i64 %r1960, 281474976710655
  %statepoint_token345 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1831, i64 %r1961, ptr @perry_ic_test_json_string_emitters_ts__29, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5535, ptr addrspace(1) %.0591, ptr addrspace(1) %.4579, ptr addrspace(1) %.5547) ]
  %r1962346 = call double @llvm.experimental.gc.result.f64(token %statepoint_token345)
  %r1135.0.base.relocated347 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token345, i32 0, i32 0) ; (%.5535, %.5535)
  %rs4gc.s42.relocated348 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token345, i32 1, i32 1) ; (%.0591, %.0591)
  %r1142.1.relocated349 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token345, i32 2, i32 2) ; (%.4579, %.4579)
  %r1135.0.relocated350 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token345, i32 0, i32 3) ; (%.5535, %.5547)
  br label %pic.merge.353

pic.merge.353:                                    ; preds = %pic.way.live.360, %pic.hit.overflow.356, %pic.miss.call.352, %pic.desc.prefix.hit.349, %pic.prefix.hit.344, %pic.hit.live.340
  %.6597 = phi ptr addrspace(1) [ %rs4gc.s42.relocated354, %pic.hit.overflow.356 ], [ %rs4gc.s42.relocated348, %pic.miss.call.352 ], [ %.0591, %pic.way.live.360 ], [ %.0591, %pic.hit.live.340 ], [ %.0591, %pic.prefix.hit.344 ], [ %.0591, %pic.desc.prefix.hit.349 ]
  %.10585 = phi ptr addrspace(1) [ %r1142.1.relocated355, %pic.hit.overflow.356 ], [ %r1142.1.relocated349, %pic.miss.call.352 ], [ %.4579, %pic.way.live.360 ], [ %.4579, %pic.hit.live.340 ], [ %.4579, %pic.prefix.hit.344 ], [ %.4579, %pic.desc.prefix.hit.349 ]
  %.11553 = phi ptr addrspace(1) [ %r1135.0.relocated356, %pic.hit.overflow.356 ], [ %r1135.0.relocated350, %pic.miss.call.352 ], [ %.5547, %pic.way.live.360 ], [ %.5547, %pic.hit.live.340 ], [ %.5547, %pic.prefix.hit.344 ], [ %.5547, %pic.desc.prefix.hit.349 ]
  %.11541 = phi ptr addrspace(1) [ %r1135.0.base.relocated353, %pic.hit.overflow.356 ], [ %r1135.0.base.relocated347, %pic.miss.call.352 ], [ %.5535, %pic.way.live.360 ], [ %.5535, %pic.hit.live.340 ], [ %.5535, %pic.prefix.hit.344 ], [ %.5535, %pic.desc.prefix.hit.349 ]
  %r1963 = phi double [ %r1879, %pic.hit.live.340 ], [ %r1874352, %pic.hit.overflow.356 ], [ %r1899, %pic.prefix.hit.344 ], [ %r1917, %pic.desc.prefix.hit.349 ], [ %r1956, %pic.way.live.360 ], [ %r1962346, %pic.miss.call.352 ]
  br label %pget.recv_merge.336

pic.recv_hdr.354:                                 ; preds = %pget.recv_ok.333
  %r1842 = sub nuw nsw i64 %r1831, 8
  %r1843 = inttoptr i64 %r1842 to ptr
  %r1844 = load i8, ptr %r1843, align 1
  %r1845 = icmp eq i8 %r1844, 2
  %r1846 = sub nuw nsw i64 %r1831, 6
  %r1847 = inttoptr i64 %r1846 to ptr
  %r1848 = load i16, ptr %r1847, align 2
  %r1849 = and i16 %r1848, 2048
  %r1850 = icmp eq i16 %r1849, 0
  %r1851 = load ptr, ptr @perry_ic_test_json_string_emitters_ts__29, align 8
  %r1852 = icmp ne ptr %r1851, null
  %r1853 = and i1 %r1845, %r1850
  %r1854 = and i1 %r1853, %r1852
  br i1 %r1854, label %pic.token.355, label %pic.desc.classify.345

pic.token.355:                                    ; preds = %pic.recv_hdr.354
  %r1856 = add nuw nsw i64 %r1831, 4
  %r1857 = inttoptr i64 %r1856 to ptr
  %r1858 = load i32, ptr %r1857, align 4
  %r1859 = zext i32 %r1858 to i64
  %r1860 = or i64 %r1859, 4611686018427387904
  %r1861 = icmp ne i32 %r1858, 0
  %r1862 = getelementptr i64, ptr %r1851, i64 0
  %r1863 = load i64, ptr %r1862, align 8
  %r1864 = icmp eq i64 %r1860, %r1863
  %r1865 = and i1 %r1864, %r1861
  br i1 %r1865, label %pic.hit.339, label %pic.prefix.guard.341

pic.hit.overflow.356:                             ; preds = %pic.hit.339
  %r1870 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r1871 = bitcast double %r1870 to i64
  %r1872 = and i64 %r1871, 281474976710655
  %r1873 = trunc i64 %r1867 to i32
  %statepoint_token351 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1831, i64 %r1872, i32 %r1873, ptr @perry_ic_test_json_string_emitters_ts__29, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5535, ptr addrspace(1) %.0591, ptr addrspace(1) %.4579, ptr addrspace(1) %.5547) ]
  %r1874352 = call double @llvm.experimental.gc.result.f64(token %statepoint_token351)
  %r1135.0.base.relocated353 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token351, i32 0, i32 0) ; (%.5535, %.5535)
  %rs4gc.s42.relocated354 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token351, i32 1, i32 1) ; (%.0591, %.0591)
  %r1142.1.relocated355 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token351, i32 2, i32 2) ; (%.4579, %.4579)
  %r1135.0.relocated356 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token351, i32 0, i32 3) ; (%.5535, %.5547)
  br label %pic.merge.353

pic.hit.inline.357:                               ; preds = %pic.hit.339
  %r1875 = shl i64 %r1867, 3
  %r1876 = add nuw nsw i64 %r1831, 16
  %r1877 = add i64 %r1876, %r1875
  %r1878 = inttoptr i64 %r1877 to ptr
  %r1879 = load double, ptr %r1878, align 8
  %r1880 = bitcast double %r1879 to i64
  %r1881 = icmp eq i64 %r1880, 9222246136947933200
  br i1 %r1881, label %pic.miss.350, label %pic.hit.live.340

pic.ways.358:                                     ; preds = %pic.miss.350
  %r1921 = getelementptr i64, ptr %r1851, i64 4
  %r1922 = load i64, ptr %r1921, align 8
  %r1923 = icmp eq i64 %r1922, %r1860
  %r1924 = getelementptr i64, ptr %r1851, i64 5
  %r1925 = load i64, ptr %r1924, align 8
  %r1926 = select i1 %r1923, i64 %r1925, i64 0
  %r1927 = getelementptr i64, ptr %r1851, i64 6
  %r1928 = load i64, ptr %r1927, align 8
  %r1929 = icmp eq i64 %r1928, %r1860
  %r1930 = getelementptr i64, ptr %r1851, i64 7
  %r1931 = load i64, ptr %r1930, align 8
  %r1932 = select i1 %r1929, i64 %r1931, i64 0
  %r1933 = getelementptr i64, ptr %r1851, i64 8
  %r1934 = load i64, ptr %r1933, align 8
  %r1935 = icmp eq i64 %r1934, %r1860
  %r1936 = getelementptr i64, ptr %r1851, i64 9
  %r1937 = load i64, ptr %r1936, align 8
  %r1938 = select i1 %r1935, i64 %r1937, i64 0
  %r1939 = getelementptr i64, ptr %r1851, i64 10
  %r1940 = load i64, ptr %r1939, align 8
  %r1941 = icmp eq i64 %r1940, %r1860
  %r1942 = getelementptr i64, ptr %r1851, i64 11
  %r1943 = load i64, ptr %r1942, align 8
  %r1944 = select i1 %r1941, i64 %r1943, i64 0
  %r1945 = or i1 %r1923, %r1929
  %r1946 = select i1 %r1923, i64 %r1926, i64 %r1932
  %r1947 = or i1 %r1935, %r1941
  %r1948 = select i1 %r1935, i64 %r1938, i64 %r1944
  %r1949 = or i1 %r1945, %r1947
  %r1950 = select i1 %r1945, i64 %r1946, i64 %r1948
  %r1951 = and i1 %r1861, %r1949
  br i1 %r1951, label %pic.way.load.359, label %pic.miss.call.352

pic.way.load.359:                                 ; preds = %pic.ways.358
  %r1952 = shl i64 %r1950, 3
  %r1953 = add nuw nsw i64 %r1831, 16
  %r1954 = add i64 %r1953, %r1952
  %r1955 = inttoptr i64 %r1954 to ptr
  %r1956 = load double, ptr %r1955, align 8
  %r1957 = bitcast double %r1956 to i64
  %r1958 = icmp eq i64 %r1957, 9222246136947933200
  br i1 %r1958, label %pic.miss.call.352, label %pic.way.live.360

pic.way.live.360:                                 ; preds = %pic.way.load.359
  br label %pic.merge.353

pget.throw_nullish.361:                           ; preds = %pget.recv_bad.334
  %r1967 = zext i1 %r1965 to i32
  %statepoint_token357 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1967, ptr @test_json_string_emitters_ts_.str.0.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.362:                       ; preds = %pget.recv_bad.334
  %r1968 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r1969 = bitcast double %r1968 to i64
  %r1970 = and i64 %r1969, 281474976710655
  %statepoint_token358 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1830, i64 %r1970, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5535, ptr addrspace(1) %.0591, ptr addrspace(1) %.4579, ptr addrspace(1) %.5547) ]
  %r1971359 = call double @llvm.experimental.gc.result.f64(token %statepoint_token358)
  %r1135.0.base.relocated360 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token358, i32 0, i32 0) ; (%.5535, %.5535)
  %rs4gc.s42.relocated361 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token358, i32 1, i32 1) ; (%.0591, %.0591)
  %r1142.1.relocated362 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token358, i32 2, i32 2) ; (%.4579, %.4579)
  %r1135.0.relocated363 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token358, i32 0, i32 3) ; (%.5535, %.5547)
  br label %pget.recv_merge.336

streqlit.tag.363:                                 ; preds = %pget.recv_merge.336
  %r1981 = lshr i64 %r1978, 48
  %r1982 = icmp eq i64 %r1981, 32767
  %r1983 = and i64 %r1978, 281474976710655
  %r1984 = icmp ugt i64 %r1983, 4095
  %r1985 = and i1 %r1982, %r1984
  br i1 %r1985, label %streqlit.len.364, label %streqlit.false.369

streqlit.len.364:                                 ; preds = %streqlit.tag.363
  %r1986 = inttoptr i64 %r1983 to ptr
  %r1987 = getelementptr inbounds nuw i8, ptr %r1986, i64 4
  %r1988 = load i32, ptr %r1987, align 4
  %r1989 = icmp eq i32 %r1988, 18
  br i1 %r1989, label %streqlit.b0.365, label %streqlit.false.369

streqlit.b0.365:                                  ; preds = %streqlit.len.364
  %r1990 = getelementptr inbounds nuw i8, ptr %r1986, i64 20
  %r1991 = load i8, ptr %r1990, align 1
  %r1992 = icmp eq i8 %r1991, 99
  br i1 %r1992, label %streqlit.bl.366, label %streqlit.false.369

streqlit.bl.366:                                  ; preds = %streqlit.b0.365
  %r1993 = getelementptr inbounds nuw i8, ptr %r1986, i64 37
  %r1994 = load i8, ptr %r1993, align 1
  %r1995 = icmp eq i8 %r1994, 55
  br i1 %r1995, label %streqlit.slow.367, label %streqlit.false.369

streqlit.slow.367:                                ; preds = %streqlit.bl.366
  %r1996 = and i64 %r1979, 281474976710655
  %statepoint_token364 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r1983, i64 %r1996, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10540, ptr addrspace(1) %.5596, ptr addrspace(1) %.9584, ptr addrspace(1) %.10552) ]
  %r1997365 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token364)
  %r1135.0.base.relocated366 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token364, i32 0, i32 0) ; (%.10540, %.10540)
  %rs4gc.s42.relocated367 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token364, i32 1, i32 1) ; (%.5596, %.5596)
  %r1142.1.relocated368 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token364, i32 2, i32 2) ; (%.9584, %.9584)
  %r1135.0.relocated369 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token364, i32 0, i32 3) ; (%.10540, %.10552)
  %r1998 = icmp ne i32 %r1997365, 0
  br label %streqlit.merge.370

streqlit.true.368:                                ; preds = %pget.recv_merge.336
  br label %streqlit.merge.370

streqlit.false.369:                               ; preds = %streqlit.bl.366, %streqlit.b0.365, %streqlit.len.364, %streqlit.tag.363
  br label %streqlit.merge.370

streqlit.merge.370:                               ; preds = %streqlit.false.369, %streqlit.true.368, %streqlit.slow.367
  %.3594 = phi ptr addrspace(1) [ %.5596, %streqlit.true.368 ], [ %rs4gc.s42.relocated367, %streqlit.slow.367 ], [ %.5596, %streqlit.false.369 ]
  %.7582 = phi ptr addrspace(1) [ %.9584, %streqlit.true.368 ], [ %r1142.1.relocated368, %streqlit.slow.367 ], [ %.9584, %streqlit.false.369 ]
  %.8550 = phi ptr addrspace(1) [ %.10552, %streqlit.true.368 ], [ %r1135.0.relocated369, %streqlit.slow.367 ], [ %.10552, %streqlit.false.369 ]
  %.8538 = phi ptr addrspace(1) [ %.10540, %streqlit.true.368 ], [ %r1135.0.base.relocated366, %streqlit.slow.367 ], [ %.10540, %streqlit.false.369 ]
  %r1999 = phi i1 [ true, %streqlit.true.368 ], [ false, %streqlit.false.369 ], [ %r1998, %streqlit.slow.367 ]
  %r2000 = xor i1 %r1999, true
  %r2001 = select i1 %r2000, i64 9222246136947933188, i64 9222246136947933187
  %r2002 = bitcast i64 %r2001 to double
  %r2003 = icmp eq i64 %r2001, 9222246136947933188
  br label %logical.merge.331

logical.then.371:                                 ; preds = %logical.merge.331
  %r2006.rs4i = ptrtoint ptr addrspace(1) %.2593 to i64
  %r2006.rs4o = call i64 asm "", "=r,0"(i64 %r2006.rs4i) #9
  %r2006 = bitcast i64 %r2006.rs4o to double
  %r2007 = bitcast double %r2006 to i64
  %r2008 = and i64 %r2007, 281474976710655
  %r2009 = lshr i64 %r2007, 48
  %r2010 = and i64 %r2009, 65533
  %r2011 = icmp eq i64 %r2010, 32765
  br i1 %r2011, label %pget.recv_ok.374, label %pget.recv_other.378

logical.merge.372:                                ; preds = %streqlit.merge.412, %logical.merge.331
  %.4595 = phi ptr addrspace(1) [ %.2593, %logical.merge.331 ], [ %.7598, %streqlit.merge.412 ]
  %.8583 = phi ptr addrspace(1) [ %.6581, %logical.merge.331 ], [ %.11586, %streqlit.merge.412 ]
  %.9551 = phi ptr addrspace(1) [ %.7549, %logical.merge.331 ], [ %.12554, %streqlit.merge.412 ]
  %.9539 = phi ptr addrspace(1) [ %.7537, %logical.merge.331 ], [ %.12, %streqlit.merge.412 ]
  %r2182 = phi double [ %r2004, %logical.merge.331 ], [ %r2180, %streqlit.merge.412 ]
  %r2183 = phi i1 [ true, %logical.merge.331 ], [ %r2181, %streqlit.merge.412 ]
  br i1 %r2183, label %if.then.413, label %if.else.414

pget.recv_sso.373:                                ; preds = %pget.recv_other.378
  %r2149 = load double, ptr @test_json_string_emitters_ts_.str.5.handle, align 8
  %r2150 = bitcast double %r2149 to i64
  %r2151 = and i64 %r2150, 281474976710655
  %statepoint_token370 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2007, i64 %r2151, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.7537, ptr addrspace(1) %.2593, ptr addrspace(1) %.6581, ptr addrspace(1) %.7549) ]
  %r2152371 = call double @llvm.experimental.gc.result.f64(token %statepoint_token370)
  %r1135.0.base.relocated372 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token370, i32 0, i32 0) ; (%.7537, %.7537)
  %rs4gc.s42.relocated373 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token370, i32 1, i32 1) ; (%.2593, %.2593)
  %r1142.1.relocated374 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token370, i32 2, i32 2) ; (%.6581, %.6581)
  %r1135.0.relocated375 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token370, i32 0, i32 3) ; (%.7537, %.7549)
  br label %pget.recv_merge.377

pget.recv_ok.374:                                 ; preds = %logical.then.371
  %r2018 = icmp ugt i64 %r2008, 1048575
  br i1 %r2018, label %pic.recv_hdr.395, label %pic.miss.cold.392

pget.recv_bad.375:                                ; preds = %pget.check_class_ref.379
  %r2141 = icmp eq i64 %r2007, 9222246136947933185
  %r2142 = icmp eq i64 %r2007, 9222246136947933186
  %r2143 = or i1 %r2141, %r2142
  br i1 %r2143, label %pget.throw_nullish.402, label %pget.recv_undef_return.403

pget.recv_class_ref.376:                          ; preds = %pget.check_class_ref.379
  %r2014 = load double, ptr @test_json_string_emitters_ts_.str.5.handle, align 8
  %r2015 = bitcast double %r2014 to i64
  %r2016 = and i64 %r2015, 281474976710655
  %statepoint_token376 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6553530643794362398, i64 %r2007, i64 %r2016, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.7537, ptr addrspace(1) %.2593, ptr addrspace(1) %.6581, ptr addrspace(1) %.7549) ]
  %r2017377 = call double @llvm.experimental.gc.result.f64(token %statepoint_token376)
  %r1135.0.base.relocated378 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token376, i32 0, i32 0) ; (%.7537, %.7537)
  %rs4gc.s42.relocated379 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token376, i32 1, i32 1) ; (%.2593, %.2593)
  %r1142.1.relocated380 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token376, i32 2, i32 2) ; (%.6581, %.6581)
  %r1135.0.relocated381 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token376, i32 0, i32 3) ; (%.7537, %.7549)
  br label %pget.recv_merge.377

pget.recv_merge.377:                              ; preds = %pget.recv_undef_return.403, %pic.merge.394, %pget.recv_class_ref.376, %pget.recv_sso.373
  %.8599 = phi ptr addrspace(1) [ %.9600, %pic.merge.394 ], [ %rs4gc.s42.relocated373, %pget.recv_sso.373 ], [ %rs4gc.s42.relocated379, %pget.recv_class_ref.376 ], [ %rs4gc.s42.relocated398, %pget.recv_undef_return.403 ]
  %.12587 = phi ptr addrspace(1) [ %.13588, %pic.merge.394 ], [ %r1142.1.relocated374, %pget.recv_sso.373 ], [ %r1142.1.relocated380, %pget.recv_class_ref.376 ], [ %r1142.1.relocated399, %pget.recv_undef_return.403 ]
  %.13555 = phi ptr addrspace(1) [ %.14556, %pic.merge.394 ], [ %r1135.0.relocated375, %pget.recv_sso.373 ], [ %r1135.0.relocated381, %pget.recv_class_ref.376 ], [ %r1135.0.relocated400, %pget.recv_undef_return.403 ]
  %.13 = phi ptr addrspace(1) [ %.14, %pic.merge.394 ], [ %r1135.0.base.relocated372, %pget.recv_sso.373 ], [ %r1135.0.base.relocated378, %pget.recv_class_ref.376 ], [ %r1135.0.base.relocated397, %pget.recv_undef_return.403 ]
  %r2153 = phi double [ %r2140, %pic.merge.394 ], [ %r2148396, %pget.recv_undef_return.403 ], [ %r2152371, %pget.recv_sso.373 ], [ %r2017377, %pget.recv_class_ref.376 ]
  %r2154 = load double, ptr @test_json_string_emitters_ts_.str.6.handle, align 8
  %r2155 = bitcast double %r2153 to i64
  %r2156 = bitcast double %r2154 to i64
  %r2157 = icmp eq i64 %r2155, %r2156
  br i1 %r2157, label %streqlit.true.410, label %streqlit.sso.404

pget.recv_other.378:                              ; preds = %logical.then.371
  %r2012 = icmp eq i64 %r2009, 32761
  br i1 %r2012, label %pget.recv_sso.373, label %pget.check_class_ref.379

pget.check_class_ref.379:                         ; preds = %pget.recv_other.378
  %r2013 = icmp eq i64 %r2009, 32766
  br i1 %r2013, label %pget.recv_class_ref.376, label %pget.recv_bad.375

pic.hit.380:                                      ; preds = %pic.token.396
  %r2043 = getelementptr i64, ptr %r2028, i64 1
  %r2044 = load i64, ptr %r2043, align 8
  %r2045 = and i64 %r2044, 1073741824
  %r2046 = icmp ne i64 %r2045, 0
  br i1 %r2046, label %pic.hit.overflow.397, label %pic.hit.inline.398

pic.hit.live.381:                                 ; preds = %pic.hit.inline.398
  br label %pic.merge.394

pic.prefix.guard.382:                             ; preds = %pic.token.396
  %r2059 = getelementptr i64, ptr %r2028, i64 2
  %r2060 = load i64, ptr %r2059, align 8
  %r2061 = icmp ne i64 %r2060, 0
  br i1 %r2061, label %pic.prefix.meta.383, label %pic.miss.391

pic.prefix.meta.383:                              ; preds = %pic.prefix.guard.382
  %r2062 = add nuw nsw i64 %r2008, 8
  %r2063 = inttoptr i64 %r2062 to ptr
  %r2064 = load i64, ptr %r2063, align 8
  %r2065 = icmp ne i64 %r2064, 0
  br i1 %r2065, label %pic.prefix.token.384, label %pic.miss.391

pic.prefix.token.384:                             ; preds = %pic.prefix.meta.383
  %r2066 = inttoptr i64 %r2064 to ptr
  %r2067 = getelementptr i64, ptr %r2066, i64 6
  %r2068 = load i64, ptr %r2067, align 8
  %r2069 = icmp eq i64 %r2068, %r2060
  br i1 %r2069, label %pic.prefix.hit.385, label %pic.miss.391

pic.prefix.hit.385:                               ; preds = %pic.prefix.token.384
  %r2070 = getelementptr i64, ptr %r2028, i64 1
  %r2071 = load i64, ptr %r2070, align 8
  %r2072 = shl i64 %r2071, 3
  %r2073 = add nuw nsw i64 %r2008, 16
  %r2074 = add i64 %r2073, %r2072
  %r2075 = inttoptr i64 %r2074 to ptr
  %r2076 = load double, ptr %r2075, align 8
  br label %pic.merge.394

pic.desc.classify.386:                            ; preds = %pic.recv_hdr.395
  %r2032 = and i1 %r2022, %r2029
  br i1 %r2032, label %pic.desc.prefix.guard.387, label %pic.miss.cold.392

pic.desc.prefix.guard.387:                        ; preds = %pic.desc.classify.386
  %r2077 = getelementptr i64, ptr %r2028, i64 2
  %r2078 = load i64, ptr %r2077, align 8
  %r2079 = icmp ne i64 %r2078, 0
  br i1 %r2079, label %pic.desc.prefix.meta.388, label %pic.miss.cold.392

pic.desc.prefix.meta.388:                         ; preds = %pic.desc.prefix.guard.387
  %r2080 = add nuw nsw i64 %r2008, 8
  %r2081 = inttoptr i64 %r2080 to ptr
  %r2082 = load i64, ptr %r2081, align 8
  %r2083 = icmp ne i64 %r2082, 0
  br i1 %r2083, label %pic.desc.prefix.token.389, label %pic.miss.cold.392

pic.desc.prefix.token.389:                        ; preds = %pic.desc.prefix.meta.388
  %r2084 = inttoptr i64 %r2082 to ptr
  %r2085 = getelementptr i64, ptr %r2084, i64 6
  %r2086 = load i64, ptr %r2085, align 8
  %r2087 = icmp eq i64 %r2086, %r2078
  br i1 %r2087, label %pic.desc.prefix.hit.390, label %pic.miss.cold.392

pic.desc.prefix.hit.390:                          ; preds = %pic.desc.prefix.token.389
  %r2088 = getelementptr i64, ptr %r2028, i64 1
  %r2089 = load i64, ptr %r2088, align 8
  %r2090 = shl i64 %r2089, 3
  %r2091 = add nuw nsw i64 %r2008, 16
  %r2092 = add i64 %r2091, %r2090
  %r2093 = inttoptr i64 %r2092 to ptr
  %r2094 = load double, ptr %r2093, align 8
  br label %pic.merge.394

pic.miss.391:                                     ; preds = %pic.hit.inline.398, %pic.prefix.token.384, %pic.prefix.meta.383, %pic.prefix.guard.382
  %r2095 = getelementptr i64, ptr %r2028, i64 3
  %r2096 = load i64, ptr %r2095, align 8
  %r2097 = icmp sgt i64 %r2096, 0
  br i1 %r2097, label %pic.ways.399, label %pic.miss.call.393

pic.miss.cold.392:                                ; preds = %pic.desc.prefix.token.389, %pic.desc.prefix.meta.388, %pic.desc.prefix.guard.387, %pic.desc.classify.386, %pget.recv_ok.374
  br label %pic.miss.call.393

pic.miss.call.393:                                ; preds = %pic.way.load.400, %pic.ways.399, %pic.miss.cold.392, %pic.miss.391
  %r2136 = load double, ptr @test_json_string_emitters_ts_.str.5.handle, align 8
  %r2137 = bitcast double %r2136 to i64
  %r2138 = and i64 %r2137, 281474976710655
  %statepoint_token382 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r2008, i64 %r2138, ptr @perry_ic_test_json_string_emitters_ts__31, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.7537, ptr addrspace(1) %.2593, ptr addrspace(1) %.6581, ptr addrspace(1) %.7549) ]
  %r2139383 = call double @llvm.experimental.gc.result.f64(token %statepoint_token382)
  %r1135.0.base.relocated384 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token382, i32 0, i32 0) ; (%.7537, %.7537)
  %rs4gc.s42.relocated385 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token382, i32 1, i32 1) ; (%.2593, %.2593)
  %r1142.1.relocated386 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token382, i32 2, i32 2) ; (%.6581, %.6581)
  %r1135.0.relocated387 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token382, i32 0, i32 3) ; (%.7537, %.7549)
  br label %pic.merge.394

pic.merge.394:                                    ; preds = %pic.way.live.401, %pic.hit.overflow.397, %pic.miss.call.393, %pic.desc.prefix.hit.390, %pic.prefix.hit.385, %pic.hit.live.381
  %.9600 = phi ptr addrspace(1) [ %rs4gc.s42.relocated391, %pic.hit.overflow.397 ], [ %rs4gc.s42.relocated385, %pic.miss.call.393 ], [ %.2593, %pic.way.live.401 ], [ %.2593, %pic.hit.live.381 ], [ %.2593, %pic.prefix.hit.385 ], [ %.2593, %pic.desc.prefix.hit.390 ]
  %.13588 = phi ptr addrspace(1) [ %r1142.1.relocated392, %pic.hit.overflow.397 ], [ %r1142.1.relocated386, %pic.miss.call.393 ], [ %.6581, %pic.way.live.401 ], [ %.6581, %pic.hit.live.381 ], [ %.6581, %pic.prefix.hit.385 ], [ %.6581, %pic.desc.prefix.hit.390 ]
  %.14556 = phi ptr addrspace(1) [ %r1135.0.relocated393, %pic.hit.overflow.397 ], [ %r1135.0.relocated387, %pic.miss.call.393 ], [ %.7549, %pic.way.live.401 ], [ %.7549, %pic.hit.live.381 ], [ %.7549, %pic.prefix.hit.385 ], [ %.7549, %pic.desc.prefix.hit.390 ]
  %.14 = phi ptr addrspace(1) [ %r1135.0.base.relocated390, %pic.hit.overflow.397 ], [ %r1135.0.base.relocated384, %pic.miss.call.393 ], [ %.7537, %pic.way.live.401 ], [ %.7537, %pic.hit.live.381 ], [ %.7537, %pic.prefix.hit.385 ], [ %.7537, %pic.desc.prefix.hit.390 ]
  %r2140 = phi double [ %r2056, %pic.hit.live.381 ], [ %r2051389, %pic.hit.overflow.397 ], [ %r2076, %pic.prefix.hit.385 ], [ %r2094, %pic.desc.prefix.hit.390 ], [ %r2133, %pic.way.live.401 ], [ %r2139383, %pic.miss.call.393 ]
  br label %pget.recv_merge.377

pic.recv_hdr.395:                                 ; preds = %pget.recv_ok.374
  %r2019 = sub nuw nsw i64 %r2008, 8
  %r2020 = inttoptr i64 %r2019 to ptr
  %r2021 = load i8, ptr %r2020, align 1
  %r2022 = icmp eq i8 %r2021, 2
  %r2023 = sub nuw nsw i64 %r2008, 6
  %r2024 = inttoptr i64 %r2023 to ptr
  %r2025 = load i16, ptr %r2024, align 2
  %r2026 = and i16 %r2025, 2048
  %r2027 = icmp eq i16 %r2026, 0
  %r2028 = load ptr, ptr @perry_ic_test_json_string_emitters_ts__31, align 8
  %r2029 = icmp ne ptr %r2028, null
  %r2030 = and i1 %r2022, %r2027
  %r2031 = and i1 %r2030, %r2029
  br i1 %r2031, label %pic.token.396, label %pic.desc.classify.386

pic.token.396:                                    ; preds = %pic.recv_hdr.395
  %r2033 = add nuw nsw i64 %r2008, 4
  %r2034 = inttoptr i64 %r2033 to ptr
  %r2035 = load i32, ptr %r2034, align 4
  %r2036 = zext i32 %r2035 to i64
  %r2037 = or i64 %r2036, 4611686018427387904
  %r2038 = icmp ne i32 %r2035, 0
  %r2039 = getelementptr i64, ptr %r2028, i64 0
  %r2040 = load i64, ptr %r2039, align 8
  %r2041 = icmp eq i64 %r2037, %r2040
  %r2042 = and i1 %r2041, %r2038
  br i1 %r2042, label %pic.hit.380, label %pic.prefix.guard.382

pic.hit.overflow.397:                             ; preds = %pic.hit.380
  %r2047 = load double, ptr @test_json_string_emitters_ts_.str.5.handle, align 8
  %r2048 = bitcast double %r2047 to i64
  %r2049 = and i64 %r2048, 281474976710655
  %r2050 = trunc i64 %r2044 to i32
  %statepoint_token388 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r2008, i64 %r2049, i32 %r2050, ptr @perry_ic_test_json_string_emitters_ts__31, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.7537, ptr addrspace(1) %.2593, ptr addrspace(1) %.6581, ptr addrspace(1) %.7549) ]
  %r2051389 = call double @llvm.experimental.gc.result.f64(token %statepoint_token388)
  %r1135.0.base.relocated390 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token388, i32 0, i32 0) ; (%.7537, %.7537)
  %rs4gc.s42.relocated391 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token388, i32 1, i32 1) ; (%.2593, %.2593)
  %r1142.1.relocated392 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token388, i32 2, i32 2) ; (%.6581, %.6581)
  %r1135.0.relocated393 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token388, i32 0, i32 3) ; (%.7537, %.7549)
  br label %pic.merge.394

pic.hit.inline.398:                               ; preds = %pic.hit.380
  %r2052 = shl i64 %r2044, 3
  %r2053 = add nuw nsw i64 %r2008, 16
  %r2054 = add i64 %r2053, %r2052
  %r2055 = inttoptr i64 %r2054 to ptr
  %r2056 = load double, ptr %r2055, align 8
  %r2057 = bitcast double %r2056 to i64
  %r2058 = icmp eq i64 %r2057, 9222246136947933200
  br i1 %r2058, label %pic.miss.391, label %pic.hit.live.381

pic.ways.399:                                     ; preds = %pic.miss.391
  %r2098 = getelementptr i64, ptr %r2028, i64 4
  %r2099 = load i64, ptr %r2098, align 8
  %r2100 = icmp eq i64 %r2099, %r2037
  %r2101 = getelementptr i64, ptr %r2028, i64 5
  %r2102 = load i64, ptr %r2101, align 8
  %r2103 = select i1 %r2100, i64 %r2102, i64 0
  %r2104 = getelementptr i64, ptr %r2028, i64 6
  %r2105 = load i64, ptr %r2104, align 8
  %r2106 = icmp eq i64 %r2105, %r2037
  %r2107 = getelementptr i64, ptr %r2028, i64 7
  %r2108 = load i64, ptr %r2107, align 8
  %r2109 = select i1 %r2106, i64 %r2108, i64 0
  %r2110 = getelementptr i64, ptr %r2028, i64 8
  %r2111 = load i64, ptr %r2110, align 8
  %r2112 = icmp eq i64 %r2111, %r2037
  %r2113 = getelementptr i64, ptr %r2028, i64 9
  %r2114 = load i64, ptr %r2113, align 8
  %r2115 = select i1 %r2112, i64 %r2114, i64 0
  %r2116 = getelementptr i64, ptr %r2028, i64 10
  %r2117 = load i64, ptr %r2116, align 8
  %r2118 = icmp eq i64 %r2117, %r2037
  %r2119 = getelementptr i64, ptr %r2028, i64 11
  %r2120 = load i64, ptr %r2119, align 8
  %r2121 = select i1 %r2118, i64 %r2120, i64 0
  %r2122 = or i1 %r2100, %r2106
  %r2123 = select i1 %r2100, i64 %r2103, i64 %r2109
  %r2124 = or i1 %r2112, %r2118
  %r2125 = select i1 %r2112, i64 %r2115, i64 %r2121
  %r2126 = or i1 %r2122, %r2124
  %r2127 = select i1 %r2122, i64 %r2123, i64 %r2125
  %r2128 = and i1 %r2038, %r2126
  br i1 %r2128, label %pic.way.load.400, label %pic.miss.call.393

pic.way.load.400:                                 ; preds = %pic.ways.399
  %r2129 = shl i64 %r2127, 3
  %r2130 = add nuw nsw i64 %r2008, 16
  %r2131 = add i64 %r2130, %r2129
  %r2132 = inttoptr i64 %r2131 to ptr
  %r2133 = load double, ptr %r2132, align 8
  %r2134 = bitcast double %r2133 to i64
  %r2135 = icmp eq i64 %r2134, 9222246136947933200
  br i1 %r2135, label %pic.miss.call.393, label %pic.way.live.401

pic.way.live.401:                                 ; preds = %pic.way.load.400
  br label %pic.merge.394

pget.throw_nullish.402:                           ; preds = %pget.recv_bad.375
  %r2144 = zext i1 %r2142 to i32
  %statepoint_token394 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2144, ptr @test_json_string_emitters_ts_.str.5.bytes, i64 5, i32 0, i32 0)
  unreachable

pget.recv_undef_return.403:                       ; preds = %pget.recv_bad.375
  %r2145 = load double, ptr @test_json_string_emitters_ts_.str.5.handle, align 8
  %r2146 = bitcast double %r2145 to i64
  %r2147 = and i64 %r2146, 281474976710655
  %statepoint_token395 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2007, i64 %r2147, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.7537, ptr addrspace(1) %.2593, ptr addrspace(1) %.6581, ptr addrspace(1) %.7549) ]
  %r2148396 = call double @llvm.experimental.gc.result.f64(token %statepoint_token395)
  %r1135.0.base.relocated397 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token395, i32 0, i32 0) ; (%.7537, %.7537)
  %rs4gc.s42.relocated398 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token395, i32 1, i32 1) ; (%.2593, %.2593)
  %r1142.1.relocated399 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token395, i32 2, i32 2) ; (%.6581, %.6581)
  %r1135.0.relocated400 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token395, i32 0, i32 3) ; (%.7537, %.7549)
  br label %pget.recv_merge.377

streqlit.sso.404:                                 ; preds = %pget.recv_merge.377
  %r2158 = icmp eq i64 %r2155, 9221406111748547169
  br i1 %r2158, label %streqlit.true.410, label %streqlit.tag.405

streqlit.tag.405:                                 ; preds = %streqlit.sso.404
  %r2159 = lshr i64 %r2155, 48
  %r2160 = icmp eq i64 %r2159, 32767
  %r2161 = and i64 %r2155, 281474976710655
  %r2162 = icmp ugt i64 %r2161, 4095
  %r2163 = and i1 %r2160, %r2162
  br i1 %r2163, label %streqlit.len.406, label %streqlit.false.411

streqlit.len.406:                                 ; preds = %streqlit.tag.405
  %r2164 = inttoptr i64 %r2161 to ptr
  %r2165 = getelementptr inbounds nuw i8, ptr %r2164, i64 4
  %r2166 = load i32, ptr %r2165, align 4
  %r2167 = icmp eq i32 %r2166, 4
  br i1 %r2167, label %streqlit.b0.407, label %streqlit.false.411

streqlit.b0.407:                                  ; preds = %streqlit.len.406
  %r2168 = getelementptr inbounds nuw i8, ptr %r2164, i64 20
  %r2169 = load i8, ptr %r2168, align 1
  %r2170 = icmp eq i8 %r2169, 97
  br i1 %r2170, label %streqlit.bl.408, label %streqlit.false.411

streqlit.bl.408:                                  ; preds = %streqlit.b0.407
  %r2171 = getelementptr inbounds nuw i8, ptr %r2164, i64 23
  %r2172 = load i8, ptr %r2171, align 1
  %r2173 = icmp eq i8 %r2172, 100
  br i1 %r2173, label %streqlit.slow.409, label %streqlit.false.411

streqlit.slow.409:                                ; preds = %streqlit.bl.408
  %r2174 = and i64 %r2156, 281474976710655
  %statepoint_token401 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r2161, i64 %r2174, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.13, ptr addrspace(1) %.8599, ptr addrspace(1) %.12587, ptr addrspace(1) %.13555) ]
  %r2175402 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token401)
  %r1135.0.base.relocated403 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token401, i32 0, i32 0) ; (%.13, %.13)
  %rs4gc.s42.relocated404 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token401, i32 1, i32 1) ; (%.8599, %.8599)
  %r1142.1.relocated405 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token401, i32 2, i32 2) ; (%.12587, %.12587)
  %r1135.0.relocated406 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token401, i32 0, i32 3) ; (%.13, %.13555)
  %r2176 = icmp ne i32 %r2175402, 0
  br label %streqlit.merge.412

streqlit.true.410:                                ; preds = %streqlit.sso.404, %pget.recv_merge.377
  br label %streqlit.merge.412

streqlit.false.411:                               ; preds = %streqlit.bl.408, %streqlit.b0.407, %streqlit.len.406, %streqlit.tag.405
  br label %streqlit.merge.412

streqlit.merge.412:                               ; preds = %streqlit.false.411, %streqlit.true.410, %streqlit.slow.409
  %.7598 = phi ptr addrspace(1) [ %.8599, %streqlit.true.410 ], [ %rs4gc.s42.relocated404, %streqlit.slow.409 ], [ %.8599, %streqlit.false.411 ]
  %.11586 = phi ptr addrspace(1) [ %.12587, %streqlit.true.410 ], [ %r1142.1.relocated405, %streqlit.slow.409 ], [ %.12587, %streqlit.false.411 ]
  %.12554 = phi ptr addrspace(1) [ %.13555, %streqlit.true.410 ], [ %r1135.0.relocated406, %streqlit.slow.409 ], [ %.13555, %streqlit.false.411 ]
  %.12 = phi ptr addrspace(1) [ %.13, %streqlit.true.410 ], [ %r1135.0.base.relocated403, %streqlit.slow.409 ], [ %.13, %streqlit.false.411 ]
  %r2177 = phi i1 [ true, %streqlit.true.410 ], [ false, %streqlit.false.411 ], [ %r2176, %streqlit.slow.409 ]
  %r2178 = xor i1 %r2177, true
  %r2179 = select i1 %r2178, i64 9222246136947933188, i64 9222246136947933187
  %r2180 = bitcast i64 %r2179 to double
  %r2181 = icmp eq i64 %r2179, 9222246136947933188
  br label %logical.merge.372

if.then.413:                                      ; preds = %logical.merge.372
  %r2184 = load double, ptr @test_json_string_emitters_ts_.str.30.handle, align 8
  %statepoint_token407 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_error_new_from_value, i32 1, i32 0, double %r2184, i32 0, i32 0)
  %r2185408 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token407)
  %r2186 = or i64 %r2185408, 9222527611924643840
  %r2187 = bitcast i64 %r2186 to double
  %statepoint_token409 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r2187, i32 0, i32 0)
  unreachable

if.else.414:                                      ; preds = %logical.merge.372
  br label %if.merge.415

if.merge.415:                                     ; preds = %if.else.414
  %r2188.rs4i = ptrtoint ptr addrspace(1) %.8583 to i64
  %r2188.rs4o = call i64 asm "", "=r,0"(i64 %r2188.rs4i) #9
  %r2188 = bitcast i64 %r2188.rs4o to double
  %r2189 = bitcast double %r2188 to i64
  %rs4gc.s43 = inttoptr i64 %r2189 to ptr addrspace(1)
  %r2190.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s43 to i64
  %r2190 = call i64 asm "", "=r,0"(i64 %r2190.rs4i) #9
  %r2191 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2192 = icmp ne i32 %r2191, 0
  br i1 %r2192, label %shadow.root.barrier.416, label %shadow.root.barrier.done.417

shadow.root.barrier.416:                          ; preds = %if.merge.415
  call void @js_write_barrier_root_nanbox(i64 %r2190) #9
  br label %shadow.root.barrier.done.417

shadow.root.barrier.done.417:                     ; preds = %shadow.root.barrier.416, %if.merge.415
  %r2193.rs4i = ptrtoint ptr addrspace(1) %.4595 to i64
  %r2193.rs4o = call i64 asm "", "=r,0"(i64 %r2193.rs4i) #9
  %r2193 = bitcast i64 %r2193.rs4o to double
  %r2194 = bitcast double %r2193 to i64
  %r2195 = and i64 %r2194, 281474976710655
  %r2196 = lshr i64 %r2194, 48
  %r2197 = and i64 %r2196, 65533
  %r2198 = icmp eq i64 %r2197, 32765
  br i1 %r2198, label %pget.recv_ok.419, label %pget.recv_other.423

pget.recv_sso.418:                                ; preds = %pget.recv_other.423
  %r2336 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r2337 = bitcast double %r2336 to i64
  %r2338 = and i64 %r2337, 281474976710655
  %statepoint_token410 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2194, i64 %r2338, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s43, ptr addrspace(1) %.9539, ptr addrspace(1) %.9551) ]
  %r2339411 = call double @llvm.experimental.gc.result.f64(token %statepoint_token410)
  %rs4gc.s43.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token410, i32 0, i32 0) ; (%rs4gc.s43, %rs4gc.s43)
  %r1135.0.base.relocated412 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token410, i32 1, i32 1) ; (%.9539, %.9539)
  %r1135.0.relocated413 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token410, i32 1, i32 2) ; (%.9539, %.9551)
  br label %pget.recv_merge.422

pget.recv_ok.419:                                 ; preds = %shadow.root.barrier.done.417
  %r2205 = icmp ugt i64 %r2195, 1048575
  br i1 %r2205, label %pic.recv_hdr.440, label %pic.miss.cold.437

pget.recv_bad.420:                                ; preds = %pget.check_class_ref.424
  %r2328 = icmp eq i64 %r2194, 9222246136947933185
  %r2329 = icmp eq i64 %r2194, 9222246136947933186
  %r2330 = or i1 %r2328, %r2329
  br i1 %r2330, label %pget.throw_nullish.447, label %pget.recv_undef_return.448

pget.recv_class_ref.421:                          ; preds = %pget.check_class_ref.424
  %r2201 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r2202 = bitcast double %r2201 to i64
  %r2203 = and i64 %r2202, 281474976710655
  %statepoint_token414 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6553530643794362400, i64 %r2194, i64 %r2203, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s43, ptr addrspace(1) %.9539, ptr addrspace(1) %.9551) ]
  %r2204415 = call double @llvm.experimental.gc.result.f64(token %statepoint_token414)
  %rs4gc.s43.relocated416 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token414, i32 0, i32 0) ; (%rs4gc.s43, %rs4gc.s43)
  %r1135.0.base.relocated417 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token414, i32 1, i32 1) ; (%.9539, %.9539)
  %r1135.0.relocated418 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token414, i32 1, i32 2) ; (%.9539, %.9551)
  br label %pget.recv_merge.422

pget.recv_merge.422:                              ; preds = %pget.recv_undef_return.448, %pic.merge.439, %pget.recv_class_ref.421, %pget.recv_sso.418
  %.0601 = phi ptr addrspace(1) [ %.1602, %pic.merge.439 ], [ %rs4gc.s43.relocated, %pget.recv_sso.418 ], [ %rs4gc.s43.relocated416, %pget.recv_class_ref.421 ], [ %rs4gc.s43.relocated432, %pget.recv_undef_return.448 ]
  %.15557 = phi ptr addrspace(1) [ %.16558, %pic.merge.439 ], [ %r1135.0.relocated413, %pget.recv_sso.418 ], [ %r1135.0.relocated418, %pget.recv_class_ref.421 ], [ %r1135.0.relocated434, %pget.recv_undef_return.448 ]
  %.15 = phi ptr addrspace(1) [ %.16, %pic.merge.439 ], [ %r1135.0.base.relocated412, %pget.recv_sso.418 ], [ %r1135.0.base.relocated417, %pget.recv_class_ref.421 ], [ %r1135.0.base.relocated433, %pget.recv_undef_return.448 ]
  %r2340 = phi double [ %r2327, %pic.merge.439 ], [ %r2335431, %pget.recv_undef_return.448 ], [ %r2339411, %pget.recv_sso.418 ], [ %r2204415, %pget.recv_class_ref.421 ]
  %r2341 = bitcast double %r2340 to i64
  %r2342 = and i64 %r2341, 281474976710655
  %r2343 = lshr i64 %r2341, 48
  %r2344 = and i64 %r2343, 65533
  %r2345 = icmp eq i64 %r2344, 32765
  br i1 %r2345, label %pget.recv_ok.450, label %pget.recv_other.455

pget.recv_other.423:                              ; preds = %shadow.root.barrier.done.417
  %r2199 = icmp eq i64 %r2196, 32761
  br i1 %r2199, label %pget.recv_sso.418, label %pget.check_class_ref.424

pget.check_class_ref.424:                         ; preds = %pget.recv_other.423
  %r2200 = icmp eq i64 %r2196, 32766
  br i1 %r2200, label %pget.recv_class_ref.421, label %pget.recv_bad.420

pic.hit.425:                                      ; preds = %pic.token.441
  %r2230 = getelementptr i64, ptr %r2215, i64 1
  %r2231 = load i64, ptr %r2230, align 8
  %r2232 = and i64 %r2231, 1073741824
  %r2233 = icmp ne i64 %r2232, 0
  br i1 %r2233, label %pic.hit.overflow.442, label %pic.hit.inline.443

pic.hit.live.426:                                 ; preds = %pic.hit.inline.443
  br label %pic.merge.439

pic.prefix.guard.427:                             ; preds = %pic.token.441
  %r2246 = getelementptr i64, ptr %r2215, i64 2
  %r2247 = load i64, ptr %r2246, align 8
  %r2248 = icmp ne i64 %r2247, 0
  br i1 %r2248, label %pic.prefix.meta.428, label %pic.miss.436

pic.prefix.meta.428:                              ; preds = %pic.prefix.guard.427
  %r2249 = add nuw nsw i64 %r2195, 8
  %r2250 = inttoptr i64 %r2249 to ptr
  %r2251 = load i64, ptr %r2250, align 8
  %r2252 = icmp ne i64 %r2251, 0
  br i1 %r2252, label %pic.prefix.token.429, label %pic.miss.436

pic.prefix.token.429:                             ; preds = %pic.prefix.meta.428
  %r2253 = inttoptr i64 %r2251 to ptr
  %r2254 = getelementptr i64, ptr %r2253, i64 6
  %r2255 = load i64, ptr %r2254, align 8
  %r2256 = icmp eq i64 %r2255, %r2247
  br i1 %r2256, label %pic.prefix.hit.430, label %pic.miss.436

pic.prefix.hit.430:                               ; preds = %pic.prefix.token.429
  %r2257 = getelementptr i64, ptr %r2215, i64 1
  %r2258 = load i64, ptr %r2257, align 8
  %r2259 = shl i64 %r2258, 3
  %r2260 = add nuw nsw i64 %r2195, 16
  %r2261 = add i64 %r2260, %r2259
  %r2262 = inttoptr i64 %r2261 to ptr
  %r2263 = load double, ptr %r2262, align 8
  br label %pic.merge.439

pic.desc.classify.431:                            ; preds = %pic.recv_hdr.440
  %r2219 = and i1 %r2209, %r2216
  br i1 %r2219, label %pic.desc.prefix.guard.432, label %pic.miss.cold.437

pic.desc.prefix.guard.432:                        ; preds = %pic.desc.classify.431
  %r2264 = getelementptr i64, ptr %r2215, i64 2
  %r2265 = load i64, ptr %r2264, align 8
  %r2266 = icmp ne i64 %r2265, 0
  br i1 %r2266, label %pic.desc.prefix.meta.433, label %pic.miss.cold.437

pic.desc.prefix.meta.433:                         ; preds = %pic.desc.prefix.guard.432
  %r2267 = add nuw nsw i64 %r2195, 8
  %r2268 = inttoptr i64 %r2267 to ptr
  %r2269 = load i64, ptr %r2268, align 8
  %r2270 = icmp ne i64 %r2269, 0
  br i1 %r2270, label %pic.desc.prefix.token.434, label %pic.miss.cold.437

pic.desc.prefix.token.434:                        ; preds = %pic.desc.prefix.meta.433
  %r2271 = inttoptr i64 %r2269 to ptr
  %r2272 = getelementptr i64, ptr %r2271, i64 6
  %r2273 = load i64, ptr %r2272, align 8
  %r2274 = icmp eq i64 %r2273, %r2265
  br i1 %r2274, label %pic.desc.prefix.hit.435, label %pic.miss.cold.437

pic.desc.prefix.hit.435:                          ; preds = %pic.desc.prefix.token.434
  %r2275 = getelementptr i64, ptr %r2215, i64 1
  %r2276 = load i64, ptr %r2275, align 8
  %r2277 = shl i64 %r2276, 3
  %r2278 = add nuw nsw i64 %r2195, 16
  %r2279 = add i64 %r2278, %r2277
  %r2280 = inttoptr i64 %r2279 to ptr
  %r2281 = load double, ptr %r2280, align 8
  br label %pic.merge.439

pic.miss.436:                                     ; preds = %pic.hit.inline.443, %pic.prefix.token.429, %pic.prefix.meta.428, %pic.prefix.guard.427
  %r2282 = getelementptr i64, ptr %r2215, i64 3
  %r2283 = load i64, ptr %r2282, align 8
  %r2284 = icmp sgt i64 %r2283, 0
  br i1 %r2284, label %pic.ways.444, label %pic.miss.call.438

pic.miss.cold.437:                                ; preds = %pic.desc.prefix.token.434, %pic.desc.prefix.meta.433, %pic.desc.prefix.guard.432, %pic.desc.classify.431, %pget.recv_ok.419
  br label %pic.miss.call.438

pic.miss.call.438:                                ; preds = %pic.way.load.445, %pic.ways.444, %pic.miss.cold.437, %pic.miss.436
  %r2323 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r2324 = bitcast double %r2323 to i64
  %r2325 = and i64 %r2324, 281474976710655
  %statepoint_token419 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r2195, i64 %r2325, ptr @perry_ic_test_json_string_emitters_ts__33, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s43, ptr addrspace(1) %.9539, ptr addrspace(1) %.9551) ]
  %r2326420 = call double @llvm.experimental.gc.result.f64(token %statepoint_token419)
  %rs4gc.s43.relocated421 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token419, i32 0, i32 0) ; (%rs4gc.s43, %rs4gc.s43)
  %r1135.0.base.relocated422 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token419, i32 1, i32 1) ; (%.9539, %.9539)
  %r1135.0.relocated423 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token419, i32 1, i32 2) ; (%.9539, %.9551)
  br label %pic.merge.439

pic.merge.439:                                    ; preds = %pic.way.live.446, %pic.hit.overflow.442, %pic.miss.call.438, %pic.desc.prefix.hit.435, %pic.prefix.hit.430, %pic.hit.live.426
  %.1602 = phi ptr addrspace(1) [ %rs4gc.s43.relocated426, %pic.hit.overflow.442 ], [ %rs4gc.s43.relocated421, %pic.miss.call.438 ], [ %rs4gc.s43, %pic.way.live.446 ], [ %rs4gc.s43, %pic.hit.live.426 ], [ %rs4gc.s43, %pic.prefix.hit.430 ], [ %rs4gc.s43, %pic.desc.prefix.hit.435 ]
  %.16558 = phi ptr addrspace(1) [ %r1135.0.relocated428, %pic.hit.overflow.442 ], [ %r1135.0.relocated423, %pic.miss.call.438 ], [ %.9551, %pic.way.live.446 ], [ %.9551, %pic.hit.live.426 ], [ %.9551, %pic.prefix.hit.430 ], [ %.9551, %pic.desc.prefix.hit.435 ]
  %.16 = phi ptr addrspace(1) [ %r1135.0.base.relocated427, %pic.hit.overflow.442 ], [ %r1135.0.base.relocated422, %pic.miss.call.438 ], [ %.9539, %pic.way.live.446 ], [ %.9539, %pic.hit.live.426 ], [ %.9539, %pic.prefix.hit.430 ], [ %.9539, %pic.desc.prefix.hit.435 ]
  %r2327 = phi double [ %r2243, %pic.hit.live.426 ], [ %r2238425, %pic.hit.overflow.442 ], [ %r2263, %pic.prefix.hit.430 ], [ %r2281, %pic.desc.prefix.hit.435 ], [ %r2320, %pic.way.live.446 ], [ %r2326420, %pic.miss.call.438 ]
  br label %pget.recv_merge.422

pic.recv_hdr.440:                                 ; preds = %pget.recv_ok.419
  %r2206 = sub nuw nsw i64 %r2195, 8
  %r2207 = inttoptr i64 %r2206 to ptr
  %r2208 = load i8, ptr %r2207, align 1
  %r2209 = icmp eq i8 %r2208, 2
  %r2210 = sub nuw nsw i64 %r2195, 6
  %r2211 = inttoptr i64 %r2210 to ptr
  %r2212 = load i16, ptr %r2211, align 2
  %r2213 = and i16 %r2212, 2048
  %r2214 = icmp eq i16 %r2213, 0
  %r2215 = load ptr, ptr @perry_ic_test_json_string_emitters_ts__33, align 8
  %r2216 = icmp ne ptr %r2215, null
  %r2217 = and i1 %r2209, %r2214
  %r2218 = and i1 %r2217, %r2216
  br i1 %r2218, label %pic.token.441, label %pic.desc.classify.431

pic.token.441:                                    ; preds = %pic.recv_hdr.440
  %r2220 = add nuw nsw i64 %r2195, 4
  %r2221 = inttoptr i64 %r2220 to ptr
  %r2222 = load i32, ptr %r2221, align 4
  %r2223 = zext i32 %r2222 to i64
  %r2224 = or i64 %r2223, 4611686018427387904
  %r2225 = icmp ne i32 %r2222, 0
  %r2226 = getelementptr i64, ptr %r2215, i64 0
  %r2227 = load i64, ptr %r2226, align 8
  %r2228 = icmp eq i64 %r2224, %r2227
  %r2229 = and i1 %r2228, %r2225
  br i1 %r2229, label %pic.hit.425, label %pic.prefix.guard.427

pic.hit.overflow.442:                             ; preds = %pic.hit.425
  %r2234 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r2235 = bitcast double %r2234 to i64
  %r2236 = and i64 %r2235, 281474976710655
  %r2237 = trunc i64 %r2231 to i32
  %statepoint_token424 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r2195, i64 %r2236, i32 %r2237, ptr @perry_ic_test_json_string_emitters_ts__33, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s43, ptr addrspace(1) %.9539, ptr addrspace(1) %.9551) ]
  %r2238425 = call double @llvm.experimental.gc.result.f64(token %statepoint_token424)
  %rs4gc.s43.relocated426 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token424, i32 0, i32 0) ; (%rs4gc.s43, %rs4gc.s43)
  %r1135.0.base.relocated427 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token424, i32 1, i32 1) ; (%.9539, %.9539)
  %r1135.0.relocated428 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token424, i32 1, i32 2) ; (%.9539, %.9551)
  br label %pic.merge.439

pic.hit.inline.443:                               ; preds = %pic.hit.425
  %r2239 = shl i64 %r2231, 3
  %r2240 = add nuw nsw i64 %r2195, 16
  %r2241 = add i64 %r2240, %r2239
  %r2242 = inttoptr i64 %r2241 to ptr
  %r2243 = load double, ptr %r2242, align 8
  %r2244 = bitcast double %r2243 to i64
  %r2245 = icmp eq i64 %r2244, 9222246136947933200
  br i1 %r2245, label %pic.miss.436, label %pic.hit.live.426

pic.ways.444:                                     ; preds = %pic.miss.436
  %r2285 = getelementptr i64, ptr %r2215, i64 4
  %r2286 = load i64, ptr %r2285, align 8
  %r2287 = icmp eq i64 %r2286, %r2224
  %r2288 = getelementptr i64, ptr %r2215, i64 5
  %r2289 = load i64, ptr %r2288, align 8
  %r2290 = select i1 %r2287, i64 %r2289, i64 0
  %r2291 = getelementptr i64, ptr %r2215, i64 6
  %r2292 = load i64, ptr %r2291, align 8
  %r2293 = icmp eq i64 %r2292, %r2224
  %r2294 = getelementptr i64, ptr %r2215, i64 7
  %r2295 = load i64, ptr %r2294, align 8
  %r2296 = select i1 %r2293, i64 %r2295, i64 0
  %r2297 = getelementptr i64, ptr %r2215, i64 8
  %r2298 = load i64, ptr %r2297, align 8
  %r2299 = icmp eq i64 %r2298, %r2224
  %r2300 = getelementptr i64, ptr %r2215, i64 9
  %r2301 = load i64, ptr %r2300, align 8
  %r2302 = select i1 %r2299, i64 %r2301, i64 0
  %r2303 = getelementptr i64, ptr %r2215, i64 10
  %r2304 = load i64, ptr %r2303, align 8
  %r2305 = icmp eq i64 %r2304, %r2224
  %r2306 = getelementptr i64, ptr %r2215, i64 11
  %r2307 = load i64, ptr %r2306, align 8
  %r2308 = select i1 %r2305, i64 %r2307, i64 0
  %r2309 = or i1 %r2287, %r2293
  %r2310 = select i1 %r2287, i64 %r2290, i64 %r2296
  %r2311 = or i1 %r2299, %r2305
  %r2312 = select i1 %r2299, i64 %r2302, i64 %r2308
  %r2313 = or i1 %r2309, %r2311
  %r2314 = select i1 %r2309, i64 %r2310, i64 %r2312
  %r2315 = and i1 %r2225, %r2313
  br i1 %r2315, label %pic.way.load.445, label %pic.miss.call.438

pic.way.load.445:                                 ; preds = %pic.ways.444
  %r2316 = shl i64 %r2314, 3
  %r2317 = add nuw nsw i64 %r2195, 16
  %r2318 = add i64 %r2317, %r2316
  %r2319 = inttoptr i64 %r2318 to ptr
  %r2320 = load double, ptr %r2319, align 8
  %r2321 = bitcast double %r2320 to i64
  %r2322 = icmp eq i64 %r2321, 9222246136947933200
  br i1 %r2322, label %pic.miss.call.438, label %pic.way.live.446

pic.way.live.446:                                 ; preds = %pic.way.load.445
  br label %pic.merge.439

pget.throw_nullish.447:                           ; preds = %pget.recv_bad.420
  %r2331 = zext i1 %r2329 to i32
  %statepoint_token429 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2331, ptr @test_json_string_emitters_ts_.str.0.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.448:                       ; preds = %pget.recv_bad.420
  %r2332 = load double, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  %r2333 = bitcast double %r2332 to i64
  %r2334 = and i64 %r2333, 281474976710655
  %statepoint_token430 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2194, i64 %r2334, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s43, ptr addrspace(1) %.9539, ptr addrspace(1) %.9551) ]
  %r2335431 = call double @llvm.experimental.gc.result.f64(token %statepoint_token430)
  %rs4gc.s43.relocated432 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token430, i32 0, i32 0) ; (%rs4gc.s43, %rs4gc.s43)
  %r1135.0.base.relocated433 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token430, i32 1, i32 1) ; (%.9539, %.9539)
  %r1135.0.relocated434 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token430, i32 1, i32 2) ; (%.9539, %.9551)
  br label %pget.recv_merge.422

pget.recv_sso.449:                                ; preds = %pget.recv_other.455
  %r2484 = lshr i64 %r2341, 40
  %r2485 = and i64 %r2484, 255
  %r2486 = uitofp nneg i64 %r2485 to double
  br label %pget.recv_merge.453

pget.recv_ok.450:                                 ; preds = %pget.recv_merge.422
  %r2352 = icmp eq i64 %r2343, 32767
  br i1 %r2352, label %pget.strlen_heap.454, label %pget.recv_obj.457

pget.recv_bad.451:                                ; preds = %pget.check_class_ref.456
  %r2476 = icmp eq i64 %r2341, 9222246136947933185
  %r2477 = icmp eq i64 %r2341, 9222246136947933186
  %r2478 = or i1 %r2476, %r2477
  br i1 %r2478, label %pget.throw_nullish.480, label %pget.recv_undef_return.481

pget.recv_class_ref.452:                          ; preds = %pget.check_class_ref.456
  %r2348 = load double, ptr @test_json_string_emitters_ts_.str.28.handle, align 8
  %r2349 = bitcast double %r2348 to i64
  %r2350 = and i64 %r2349, 281474976710655
  %statepoint_token435 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6553530643794362402, i64 %r2341, i64 %r2350, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.15, ptr addrspace(1) %.0601, ptr addrspace(1) %.15557) ]
  %r2351436 = call double @llvm.experimental.gc.result.f64(token %statepoint_token435)
  %r1135.0.base.relocated437 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token435, i32 0, i32 0) ; (%.15, %.15)
  %rs4gc.s43.relocated438 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token435, i32 1, i32 1) ; (%.0601, %.0601)
  %r1135.0.relocated439 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token435, i32 0, i32 2) ; (%.15, %.15557)
  br label %pget.recv_merge.453

pget.recv_merge.453:                              ; preds = %pget.recv_undef_return.481, %pic.merge.472, %pget.strlen_heap.454, %pget.recv_class_ref.452, %pget.recv_sso.449
  %.2603 = phi ptr addrspace(1) [ %.0601, %pget.strlen_heap.454 ], [ %.3604, %pic.merge.472 ], [ %.0601, %pget.recv_sso.449 ], [ %rs4gc.s43.relocated438, %pget.recv_class_ref.452 ], [ %rs4gc.s43.relocated454, %pget.recv_undef_return.481 ]
  %.17559 = phi ptr addrspace(1) [ %.15557, %pget.strlen_heap.454 ], [ %.18560, %pic.merge.472 ], [ %.15557, %pget.recv_sso.449 ], [ %r1135.0.relocated439, %pget.recv_class_ref.452 ], [ %r1135.0.relocated455, %pget.recv_undef_return.481 ]
  %.17 = phi ptr addrspace(1) [ %.15, %pget.strlen_heap.454 ], [ %.18, %pic.merge.472 ], [ %.15, %pget.recv_sso.449 ], [ %r1135.0.base.relocated437, %pget.recv_class_ref.452 ], [ %r1135.0.base.relocated453, %pget.recv_undef_return.481 ]
  %r2492 = phi double [ %r2475, %pic.merge.472 ], [ %r2483452, %pget.recv_undef_return.481 ], [ %r2486, %pget.recv_sso.449 ], [ %r2351436, %pget.recv_class_ref.452 ], [ %r2491, %pget.strlen_heap.454 ]
  %r2493.rs4i = ptrtoint ptr addrspace(1) %.2603 to i64
  %r2493 = call i64 asm "", "=r,0"(i64 %r2493.rs4i) #9
  %r2494 = bitcast i64 %r2493 to double
  %r2495 = and i64 %r2493, -281474976710656
  %r2496 = icmp ult i64 %r2495, 9221401712017801216
  %r2497 = icmp ugt i64 %r2495, 9223090561878065152
  %r2498 = or i1 %r2496, %r2497
  %r2499 = bitcast double %r2492 to i64
  %r2500 = and i64 %r2499, -281474976710656
  %r2501 = icmp ult i64 %r2500, 9221401712017801216
  %r2502 = icmp ugt i64 %r2500, 9223090561878065152
  %r2503 = or i1 %r2501, %r2502
  %r2504 = and i1 %r2498, %r2503
  br i1 %r2504, label %guarded_add.numeric.482, label %guarded_add.dynamic.483

pget.strlen_heap.454:                             ; preds = %pget.recv_ok.450
  %r2487 = icmp ult i64 %r2342, 4096
  %r2488 = inttoptr i64 %r2342 to ptr
  %r2489 = select i1 %r2487, ptr @perry_null_guard_zero_test_json_string_emitters_ts, ptr %r2488
  %r2490 = load i32, ptr %r2489, align 4
  %r2491 = uitofp i32 %r2490 to double
  br label %pget.recv_merge.453

pget.recv_other.455:                              ; preds = %pget.recv_merge.422
  %r2346 = icmp eq i64 %r2343, 32761
  br i1 %r2346, label %pget.recv_sso.449, label %pget.check_class_ref.456

pget.check_class_ref.456:                         ; preds = %pget.recv_other.455
  %r2347 = icmp eq i64 %r2343, 32766
  br i1 %r2347, label %pget.recv_class_ref.452, label %pget.recv_bad.451

pget.recv_obj.457:                                ; preds = %pget.recv_ok.450
  %r2353 = icmp ugt i64 %r2342, 1048575
  br i1 %r2353, label %pic.recv_hdr.473, label %pic.miss.cold.470

pic.hit.458:                                      ; preds = %pic.token.474
  %r2378 = getelementptr i64, ptr %r2363, i64 1
  %r2379 = load i64, ptr %r2378, align 8
  %r2380 = and i64 %r2379, 1073741824
  %r2381 = icmp ne i64 %r2380, 0
  br i1 %r2381, label %pic.hit.overflow.475, label %pic.hit.inline.476

pic.hit.live.459:                                 ; preds = %pic.hit.inline.476
  br label %pic.merge.472

pic.prefix.guard.460:                             ; preds = %pic.token.474
  %r2394 = getelementptr i64, ptr %r2363, i64 2
  %r2395 = load i64, ptr %r2394, align 8
  %r2396 = icmp ne i64 %r2395, 0
  br i1 %r2396, label %pic.prefix.meta.461, label %pic.miss.469

pic.prefix.meta.461:                              ; preds = %pic.prefix.guard.460
  %r2397 = add nuw nsw i64 %r2342, 8
  %r2398 = inttoptr i64 %r2397 to ptr
  %r2399 = load i64, ptr %r2398, align 8
  %r2400 = icmp ne i64 %r2399, 0
  br i1 %r2400, label %pic.prefix.token.462, label %pic.miss.469

pic.prefix.token.462:                             ; preds = %pic.prefix.meta.461
  %r2401 = inttoptr i64 %r2399 to ptr
  %r2402 = getelementptr i64, ptr %r2401, i64 6
  %r2403 = load i64, ptr %r2402, align 8
  %r2404 = icmp eq i64 %r2403, %r2395
  br i1 %r2404, label %pic.prefix.hit.463, label %pic.miss.469

pic.prefix.hit.463:                               ; preds = %pic.prefix.token.462
  %r2405 = getelementptr i64, ptr %r2363, i64 1
  %r2406 = load i64, ptr %r2405, align 8
  %r2407 = shl i64 %r2406, 3
  %r2408 = add nuw nsw i64 %r2342, 16
  %r2409 = add i64 %r2408, %r2407
  %r2410 = inttoptr i64 %r2409 to ptr
  %r2411 = load double, ptr %r2410, align 8
  br label %pic.merge.472

pic.desc.classify.464:                            ; preds = %pic.recv_hdr.473
  %r2367 = and i1 %r2357, %r2364
  br i1 %r2367, label %pic.desc.prefix.guard.465, label %pic.miss.cold.470

pic.desc.prefix.guard.465:                        ; preds = %pic.desc.classify.464
  %r2412 = getelementptr i64, ptr %r2363, i64 2
  %r2413 = load i64, ptr %r2412, align 8
  %r2414 = icmp ne i64 %r2413, 0
  br i1 %r2414, label %pic.desc.prefix.meta.466, label %pic.miss.cold.470

pic.desc.prefix.meta.466:                         ; preds = %pic.desc.prefix.guard.465
  %r2415 = add nuw nsw i64 %r2342, 8
  %r2416 = inttoptr i64 %r2415 to ptr
  %r2417 = load i64, ptr %r2416, align 8
  %r2418 = icmp ne i64 %r2417, 0
  br i1 %r2418, label %pic.desc.prefix.token.467, label %pic.miss.cold.470

pic.desc.prefix.token.467:                        ; preds = %pic.desc.prefix.meta.466
  %r2419 = inttoptr i64 %r2417 to ptr
  %r2420 = getelementptr i64, ptr %r2419, i64 6
  %r2421 = load i64, ptr %r2420, align 8
  %r2422 = icmp eq i64 %r2421, %r2413
  br i1 %r2422, label %pic.desc.prefix.hit.468, label %pic.miss.cold.470

pic.desc.prefix.hit.468:                          ; preds = %pic.desc.prefix.token.467
  %r2423 = getelementptr i64, ptr %r2363, i64 1
  %r2424 = load i64, ptr %r2423, align 8
  %r2425 = shl i64 %r2424, 3
  %r2426 = add nuw nsw i64 %r2342, 16
  %r2427 = add i64 %r2426, %r2425
  %r2428 = inttoptr i64 %r2427 to ptr
  %r2429 = load double, ptr %r2428, align 8
  br label %pic.merge.472

pic.miss.469:                                     ; preds = %pic.hit.inline.476, %pic.prefix.token.462, %pic.prefix.meta.461, %pic.prefix.guard.460
  %r2430 = getelementptr i64, ptr %r2363, i64 3
  %r2431 = load i64, ptr %r2430, align 8
  %r2432 = icmp sgt i64 %r2431, 0
  br i1 %r2432, label %pic.ways.477, label %pic.miss.call.471

pic.miss.cold.470:                                ; preds = %pic.desc.prefix.token.467, %pic.desc.prefix.meta.466, %pic.desc.prefix.guard.465, %pic.desc.classify.464, %pget.recv_obj.457
  br label %pic.miss.call.471

pic.miss.call.471:                                ; preds = %pic.way.load.478, %pic.ways.477, %pic.miss.cold.470, %pic.miss.469
  %r2471 = load double, ptr @test_json_string_emitters_ts_.str.28.handle, align 8
  %r2472 = bitcast double %r2471 to i64
  %r2473 = and i64 %r2472, 281474976710655
  %statepoint_token440 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r2342, i64 %r2473, ptr @perry_ic_test_json_string_emitters_ts__35, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.15, ptr addrspace(1) %.0601, ptr addrspace(1) %.15557) ]
  %r2474441 = call double @llvm.experimental.gc.result.f64(token %statepoint_token440)
  %r1135.0.base.relocated442 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token440, i32 0, i32 0) ; (%.15, %.15)
  %rs4gc.s43.relocated443 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token440, i32 1, i32 1) ; (%.0601, %.0601)
  %r1135.0.relocated444 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token440, i32 0, i32 2) ; (%.15, %.15557)
  br label %pic.merge.472

pic.merge.472:                                    ; preds = %pic.way.live.479, %pic.hit.overflow.475, %pic.miss.call.471, %pic.desc.prefix.hit.468, %pic.prefix.hit.463, %pic.hit.live.459
  %.3604 = phi ptr addrspace(1) [ %rs4gc.s43.relocated448, %pic.hit.overflow.475 ], [ %rs4gc.s43.relocated443, %pic.miss.call.471 ], [ %.0601, %pic.way.live.479 ], [ %.0601, %pic.hit.live.459 ], [ %.0601, %pic.prefix.hit.463 ], [ %.0601, %pic.desc.prefix.hit.468 ]
  %.18560 = phi ptr addrspace(1) [ %r1135.0.relocated449, %pic.hit.overflow.475 ], [ %r1135.0.relocated444, %pic.miss.call.471 ], [ %.15557, %pic.way.live.479 ], [ %.15557, %pic.hit.live.459 ], [ %.15557, %pic.prefix.hit.463 ], [ %.15557, %pic.desc.prefix.hit.468 ]
  %.18 = phi ptr addrspace(1) [ %r1135.0.base.relocated447, %pic.hit.overflow.475 ], [ %r1135.0.base.relocated442, %pic.miss.call.471 ], [ %.15, %pic.way.live.479 ], [ %.15, %pic.hit.live.459 ], [ %.15, %pic.prefix.hit.463 ], [ %.15, %pic.desc.prefix.hit.468 ]
  %r2475 = phi double [ %r2391, %pic.hit.live.459 ], [ %r2386446, %pic.hit.overflow.475 ], [ %r2411, %pic.prefix.hit.463 ], [ %r2429, %pic.desc.prefix.hit.468 ], [ %r2468, %pic.way.live.479 ], [ %r2474441, %pic.miss.call.471 ]
  br label %pget.recv_merge.453

pic.recv_hdr.473:                                 ; preds = %pget.recv_obj.457
  %r2354 = sub nuw nsw i64 %r2342, 8
  %r2355 = inttoptr i64 %r2354 to ptr
  %r2356 = load i8, ptr %r2355, align 1
  %r2357 = icmp eq i8 %r2356, 2
  %r2358 = sub nuw nsw i64 %r2342, 6
  %r2359 = inttoptr i64 %r2358 to ptr
  %r2360 = load i16, ptr %r2359, align 2
  %r2361 = and i16 %r2360, 2048
  %r2362 = icmp eq i16 %r2361, 0
  %r2363 = load ptr, ptr @perry_ic_test_json_string_emitters_ts__35, align 8
  %r2364 = icmp ne ptr %r2363, null
  %r2365 = and i1 %r2357, %r2362
  %r2366 = and i1 %r2365, %r2364
  br i1 %r2366, label %pic.token.474, label %pic.desc.classify.464

pic.token.474:                                    ; preds = %pic.recv_hdr.473
  %r2368 = add nuw nsw i64 %r2342, 4
  %r2369 = inttoptr i64 %r2368 to ptr
  %r2370 = load i32, ptr %r2369, align 4
  %r2371 = zext i32 %r2370 to i64
  %r2372 = or i64 %r2371, 4611686018427387904
  %r2373 = icmp ne i32 %r2370, 0
  %r2374 = getelementptr i64, ptr %r2363, i64 0
  %r2375 = load i64, ptr %r2374, align 8
  %r2376 = icmp eq i64 %r2372, %r2375
  %r2377 = and i1 %r2376, %r2373
  br i1 %r2377, label %pic.hit.458, label %pic.prefix.guard.460

pic.hit.overflow.475:                             ; preds = %pic.hit.458
  %r2382 = load double, ptr @test_json_string_emitters_ts_.str.28.handle, align 8
  %r2383 = bitcast double %r2382 to i64
  %r2384 = and i64 %r2383, 281474976710655
  %r2385 = trunc i64 %r2379 to i32
  %statepoint_token445 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r2342, i64 %r2384, i32 %r2385, ptr @perry_ic_test_json_string_emitters_ts__35, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.15, ptr addrspace(1) %.0601, ptr addrspace(1) %.15557) ]
  %r2386446 = call double @llvm.experimental.gc.result.f64(token %statepoint_token445)
  %r1135.0.base.relocated447 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token445, i32 0, i32 0) ; (%.15, %.15)
  %rs4gc.s43.relocated448 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token445, i32 1, i32 1) ; (%.0601, %.0601)
  %r1135.0.relocated449 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token445, i32 0, i32 2) ; (%.15, %.15557)
  br label %pic.merge.472

pic.hit.inline.476:                               ; preds = %pic.hit.458
  %r2387 = shl i64 %r2379, 3
  %r2388 = add nuw nsw i64 %r2342, 16
  %r2389 = add i64 %r2388, %r2387
  %r2390 = inttoptr i64 %r2389 to ptr
  %r2391 = load double, ptr %r2390, align 8
  %r2392 = bitcast double %r2391 to i64
  %r2393 = icmp eq i64 %r2392, 9222246136947933200
  br i1 %r2393, label %pic.miss.469, label %pic.hit.live.459

pic.ways.477:                                     ; preds = %pic.miss.469
  %r2433 = getelementptr i64, ptr %r2363, i64 4
  %r2434 = load i64, ptr %r2433, align 8
  %r2435 = icmp eq i64 %r2434, %r2372
  %r2436 = getelementptr i64, ptr %r2363, i64 5
  %r2437 = load i64, ptr %r2436, align 8
  %r2438 = select i1 %r2435, i64 %r2437, i64 0
  %r2439 = getelementptr i64, ptr %r2363, i64 6
  %r2440 = load i64, ptr %r2439, align 8
  %r2441 = icmp eq i64 %r2440, %r2372
  %r2442 = getelementptr i64, ptr %r2363, i64 7
  %r2443 = load i64, ptr %r2442, align 8
  %r2444 = select i1 %r2441, i64 %r2443, i64 0
  %r2445 = getelementptr i64, ptr %r2363, i64 8
  %r2446 = load i64, ptr %r2445, align 8
  %r2447 = icmp eq i64 %r2446, %r2372
  %r2448 = getelementptr i64, ptr %r2363, i64 9
  %r2449 = load i64, ptr %r2448, align 8
  %r2450 = select i1 %r2447, i64 %r2449, i64 0
  %r2451 = getelementptr i64, ptr %r2363, i64 10
  %r2452 = load i64, ptr %r2451, align 8
  %r2453 = icmp eq i64 %r2452, %r2372
  %r2454 = getelementptr i64, ptr %r2363, i64 11
  %r2455 = load i64, ptr %r2454, align 8
  %r2456 = select i1 %r2453, i64 %r2455, i64 0
  %r2457 = or i1 %r2435, %r2441
  %r2458 = select i1 %r2435, i64 %r2438, i64 %r2444
  %r2459 = or i1 %r2447, %r2453
  %r2460 = select i1 %r2447, i64 %r2450, i64 %r2456
  %r2461 = or i1 %r2457, %r2459
  %r2462 = select i1 %r2457, i64 %r2458, i64 %r2460
  %r2463 = and i1 %r2373, %r2461
  br i1 %r2463, label %pic.way.load.478, label %pic.miss.call.471

pic.way.load.478:                                 ; preds = %pic.ways.477
  %r2464 = shl i64 %r2462, 3
  %r2465 = add nuw nsw i64 %r2342, 16
  %r2466 = add i64 %r2465, %r2464
  %r2467 = inttoptr i64 %r2466 to ptr
  %r2468 = load double, ptr %r2467, align 8
  %r2469 = bitcast double %r2468 to i64
  %r2470 = icmp eq i64 %r2469, 9222246136947933200
  br i1 %r2470, label %pic.miss.call.471, label %pic.way.live.479

pic.way.live.479:                                 ; preds = %pic.way.load.478
  br label %pic.merge.472

pget.throw_nullish.480:                           ; preds = %pget.recv_bad.451
  %r2479 = zext i1 %r2477 to i32
  %statepoint_token450 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2479, ptr @test_json_string_emitters_ts_.str.28.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.481:                       ; preds = %pget.recv_bad.451
  %r2480 = load double, ptr @test_json_string_emitters_ts_.str.28.handle, align 8
  %r2481 = bitcast double %r2480 to i64
  %r2482 = and i64 %r2481, 281474976710655
  %statepoint_token451 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2341, i64 %r2482, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.15, ptr addrspace(1) %.0601, ptr addrspace(1) %.15557) ]
  %r2483452 = call double @llvm.experimental.gc.result.f64(token %statepoint_token451)
  %r1135.0.base.relocated453 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token451, i32 0, i32 0) ; (%.15, %.15)
  %rs4gc.s43.relocated454 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token451, i32 1, i32 1) ; (%.0601, %.0601)
  %r1135.0.relocated455 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token451, i32 0, i32 2) ; (%.15, %.15557)
  br label %pget.recv_merge.453

guarded_add.numeric.482:                          ; preds = %pget.recv_merge.453
  %r2505 = fadd double %r2494, %r2492
  br label %guarded_add.merge.484

guarded_add.dynamic.483:                          ; preds = %pget.recv_merge.453
  %statepoint_token456 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r2494, double %r2492, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.17, ptr addrspace(1) %.17559) ]
  %r2506457 = call double @llvm.experimental.gc.result.f64(token %statepoint_token456)
  %r1135.0.base.relocated458 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token456, i32 0, i32 0) ; (%.17, %.17)
  %r1135.0.relocated459 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token456, i32 0, i32 1) ; (%.17, %.17559)
  br label %guarded_add.merge.484

guarded_add.merge.484:                            ; preds = %guarded_add.dynamic.483, %guarded_add.numeric.482
  %.19561 = phi ptr addrspace(1) [ %.17559, %guarded_add.numeric.482 ], [ %r1135.0.relocated459, %guarded_add.dynamic.483 ]
  %.19 = phi ptr addrspace(1) [ %.17, %guarded_add.numeric.482 ], [ %r1135.0.base.relocated458, %guarded_add.dynamic.483 ]
  %r2507 = phi double [ %r2505, %guarded_add.numeric.482 ], [ %r2506457, %guarded_add.dynamic.483 ]
  %rs4gc.b44 = bitcast double %r2507 to i64
  %rs4gc.s44 = inttoptr i64 %rs4gc.b44 to ptr addrspace(1)
  %r2508.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s44 to i64
  %r2508 = call i64 asm "", "=r,0"(i64 %r2508.rs4i) #9
  %r2509 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2510 = icmp ne i32 %r2509, 0
  br i1 %r2510, label %shadow.root.barrier.485, label %shadow.root.barrier.done.486

shadow.root.barrier.485:                          ; preds = %guarded_add.merge.484
  call void @js_write_barrier_root_nanbox(i64 %r2508) #9
  br label %shadow.root.barrier.done.486

shadow.root.barrier.done.486:                     ; preds = %shadow.root.barrier.485, %guarded_add.merge.484
  %r2511 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r2512 = icmp ne i32 %r2511, 0
  br i1 %r2512, label %gcpoll.487, label %gcpoll.done.488

gcpoll.487:                                       ; preds = %shadow.root.barrier.done.486
  %statepoint_token460 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s44, ptr addrspace(1) %.19, ptr addrspace(1) %.19561) ]
  %rs4gc.s44.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token460, i32 0, i32 0) ; (%rs4gc.s44, %rs4gc.s44)
  %r1135.0.base.relocated461 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token460, i32 1, i32 1) ; (%.19, %.19)
  %r1135.0.relocated462 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token460, i32 1, i32 2) ; (%.19, %.19561)
  br label %gcpoll.done.488

gcpoll.done.488:                                  ; preds = %gcpoll.487, %shadow.root.barrier.done.486
  %.0605 = phi ptr addrspace(1) [ %rs4gc.s44.relocated, %gcpoll.487 ], [ %rs4gc.s44, %shadow.root.barrier.done.486 ]
  %.20562 = phi ptr addrspace(1) [ %r1135.0.relocated462, %gcpoll.487 ], [ %.19561, %shadow.root.barrier.done.486 ]
  %.20 = phi ptr addrspace(1) [ %r1135.0.base.relocated461, %gcpoll.487 ], [ %.19, %shadow.root.barrier.done.486 ]
  br label %for.update.265

shadow.root.barrier.489:                          ; preds = %for.exit.266
  call void @js_write_barrier_root_nanbox(i64 %r2518) #9
  br label %shadow.root.barrier.done.490

shadow.root.barrier.done.490:                     ; preds = %shadow.root.barrier.489, %for.exit.266
  %r2521 = load double, ptr @test_json_string_emitters_ts_.str.31.handle, align 8
  %r2522.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s41 to i64
  %r2522 = call i64 asm "", "=r,0"(i64 %r2522.rs4i) #9
  %statepoint_token463 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r2522, double %r2521, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1142.1.relocated, ptr addrspace(1) %r1135.0.relocated277, ptr addrspace(1) %r1135.0.base.relocated278) ]
  %r2523464 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token463)
  %r1142.1.relocated465 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token463, i32 0, i32 0) ; (%r1142.1.relocated, %r1142.1.relocated)
  %r1135.0.relocated466 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token463, i32 2, i32 1) ; (%r1135.0.base.relocated278, %r1135.0.relocated277)
  %r1135.0.base.relocated467 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token463, i32 2, i32 2) ; (%r1135.0.base.relocated278, %r1135.0.base.relocated278)
  %rs4gc.s45 = inttoptr i64 %r2523464 to ptr addrspace(1)
  %r2524.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s45 to i64
  %r2524 = call i64 asm "", "=r,0"(i64 %r2524.rs4i) #9
  %r2525 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2526 = icmp ne i32 %r2525, 0
  br i1 %r2526, label %shadow.root.barrier.491, label %shadow.root.barrier.done.492

shadow.root.barrier.491:                          ; preds = %shadow.root.barrier.done.490
  call void @js_write_barrier_root_nanbox(i64 %r2524) #9
  br label %shadow.root.barrier.done.492

shadow.root.barrier.done.492:                     ; preds = %shadow.root.barrier.491, %shadow.root.barrier.done.490
  %r2527.rs4i = ptrtoint ptr addrspace(1) %r1135.0.relocated466 to i64
  %r2527.rs4o = call i64 asm "", "=r,0"(i64 %r2527.rs4i) #9
  %r2527 = bitcast i64 %r2527.rs4o to double
  %r2528 = bitcast double %r2527 to i64
  %r2529 = and i64 %r2528, 281474976710655
  %r2530 = lshr i64 %r2528, 48
  %r2531 = and i64 %r2530, 65533
  %r2532 = icmp eq i64 %r2531, 32765
  %r2533 = icmp ugt i64 %r2529, 1048575
  %r2534 = and i1 %r2532, %r2533
  br i1 %r2534, label %plen.check_gc.493, label %plen.slow.495

plen.check_gc.493:                                ; preds = %shadow.root.barrier.done.492
  %r2535 = sub nuw nsw i64 %r2529, 8
  %r2536 = inttoptr i64 %r2535 to ptr
  %r2537 = load i8, ptr %r2536, align 1
  %r2538 = icmp eq i8 %r2537, 1
  %r2539 = icmp eq i8 %r2537, 3
  %r2540 = or i1 %r2538, %r2539
  %r2541 = sub nuw nsw i64 %r2529, 7
  %r2542 = inttoptr i64 %r2541 to ptr
  %r2543 = load i8, ptr %r2542, align 1
  %r2544 = and i8 %r2543, -128
  %r2545 = icmp eq i8 %r2544, 0
  %r2546 = and i1 %r2540, %r2545
  br i1 %r2546, label %plen.fast.494, label %plen.slow.495

plen.fast.494:                                    ; preds = %plen.check_gc.493
  %r2548 = inttoptr i64 %r2529 to ptr
  %r2549 = select i1 false, ptr @perry_null_guard_zero_test_json_string_emitters_ts, ptr %r2548
  %r2550 = load i32, ptr %r2549, align 4
  %r2551 = uitofp i32 %r2550 to double
  br label %plen.merge.496

plen.slow.495:                                    ; preds = %plen.check_gc.493, %shadow.root.barrier.done.492
  %r2552 = lshr i64 %r2528, 48
  %r2553 = icmp eq i64 %r2552, 32765
  %r2554 = icmp uge i64 %r2529, 2199023255552
  %r2555 = icmp ult i64 %r2529, 140737488355328
  %r2556 = and i1 %r2553, %r2554
  %r2557 = and i1 %r2556, %r2555
  %r2558 = load ptr, ptr @perry_ic_test_json_string_emitters_ts__36, align 8
  br i1 %r2557, label %plen.ic.header.497, label %plen.ic.miss.509

plen.merge.496:                                   ; preds = %plen.ic.merge.510, %plen.fast.494
  %.0606 = phi ptr addrspace(1) [ %rs4gc.s45, %plen.fast.494 ], [ %.1607, %plen.ic.merge.510 ]
  %.14589 = phi ptr addrspace(1) [ %r1142.1.relocated465, %plen.fast.494 ], [ %.15590, %plen.ic.merge.510 ]
  %r2633 = phi double [ %r2551, %plen.fast.494 ], [ %r2632, %plen.ic.merge.510 ]
  %r2634.rs4i = ptrtoint ptr addrspace(1) %.0606 to i64
  %r2634 = call i64 asm "", "=r,0"(i64 %r2634.rs4i) #9
  %statepoint_token468 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r2634, double %r2633, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.14589) ]
  %r2635469 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token468)
  %r1142.1.relocated470 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token468, i32 0, i32 0) ; (%.14589, %.14589)
  %rs4gc.s46 = inttoptr i64 %r2635469 to ptr addrspace(1)
  %r2636.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s46 to i64
  %r2636 = call i64 asm "", "=r,0"(i64 %r2636.rs4i) #9
  %r2637 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2638 = icmp ne i32 %r2637, 0
  br i1 %r2638, label %shadow.root.barrier.514, label %shadow.root.barrier.done.515

plen.ic.header.497:                               ; preds = %plen.slow.495
  %r2560 = sub nuw nsw i64 %r2529, 8
  %r2561 = inttoptr i64 %r2560 to ptr
  %r2562 = load i8, ptr %r2561, align 1
  %r2563 = icmp eq i8 %r2562, 2
  %r2564 = sub nuw nsw i64 %r2529, 7
  %r2565 = inttoptr i64 %r2564 to ptr
  %r2566 = load i8, ptr %r2565, align 1
  %r2567 = and i8 %r2566, -128
  %r2568 = icmp eq i8 %r2567, 0
  %r2569 = and i1 %r2563, %r2568
  br i1 %r2569, label %plen.elem.meta.511, label %plen.ic.miss.509

plen.ic.shape.498:                                ; preds = %plen.elem.store.512, %plen.elem.meta.511
  %r2559 = icmp ne ptr %r2558, null
  br i1 %r2559, label %plen.ic.shape.probe.499, label %plen.ic.miss.509

plen.ic.shape.probe.499:                          ; preds = %plen.ic.shape.498
  %r2581 = inttoptr i64 %r2529 to ptr
  %r2582 = load i32, ptr %r2581, align 4
  %r2583 = add nuw nsw i64 %r2529, 4
  %r2584 = inttoptr i64 %r2583 to ptr
  %r2585 = load i32, ptr %r2584, align 4
  %r2586 = zext i32 %r2582 to i64
  %r2587 = zext i32 %r2585 to i64
  %r2588 = shl nuw i64 %r2586, 32
  %r2589 = or i64 %r2588, %r2587
  %r2590 = getelementptr i64, ptr %r2558, i64 0
  %r2591 = load i64, ptr %r2590, align 8
  %r2592 = icmp ne i64 %r2591, 0
  br i1 %r2592, label %plen.ic.identity.500, label %plen.ic.miss.509

plen.ic.identity.500:                             ; preds = %plen.ic.shape.probe.499
  %r2593 = and i64 %r2591, -9223372036854775808
  %2 = icmp slt i64 %r2591, 0
  br i1 %2, label %plen.ic.family_meta.502, label %plen.ic.exact.501

plen.ic.exact.501:                                ; preds = %plen.ic.identity.500
  %r2595 = icmp eq i64 %r2589, %r2591
  br i1 %r2595, label %plen.ic.slot.504, label %plen.ic.miss.509

plen.ic.family_meta.502:                          ; preds = %plen.ic.identity.500
  %r2596 = add nuw nsw i64 %r2529, 8
  %r2597 = inttoptr i64 %r2596 to ptr
  %r2598 = load i64, ptr %r2597, align 8
  %r2599 = icmp ne i64 %r2598, 0
  br i1 %r2599, label %plen.ic.family_token.503, label %plen.ic.miss.509

plen.ic.family_token.503:                         ; preds = %plen.ic.family_meta.502
  %r2600 = inttoptr i64 %r2598 to ptr
  %r2601 = getelementptr i64, ptr %r2600, i64 6
  %r2602 = load i64, ptr %r2601, align 8
  %r2603 = icmp eq i64 %r2602, %r2591
  br i1 %r2603, label %plen.ic.slot.504, label %plen.ic.miss.509

plen.ic.slot.504:                                 ; preds = %plen.ic.family_token.503, %plen.ic.exact.501
  %r2604 = getelementptr i64, ptr %r2558, i64 1
  %r2605 = load i64, ptr %r2604, align 8
  %r2606 = getelementptr i64, ptr %r2558, i64 2
  %r2607 = load i64, ptr %r2606, align 8
  %r2608 = icmp ult i64 %r2605, %r2607
  br i1 %r2608, label %plen.ic.inline.505, label %plen.ic.spill_meta.506

plen.ic.inline.505:                               ; preds = %plen.ic.slot.504
  %r2609 = shl i64 %r2605, 3
  %r2610 = add i64 %r2609, 16
  %r2611 = add i64 %r2529, %r2610
  %r2612 = inttoptr i64 %r2611 to ptr
  %r2613 = load double, ptr %r2612, align 8
  br label %plen.ic.merge.510

plen.ic.spill_meta.506:                           ; preds = %plen.ic.slot.504
  %r2614 = add nuw nsw i64 %r2529, 8
  %r2615 = inttoptr i64 %r2614 to ptr
  %r2616 = load i64, ptr %r2615, align 8
  %r2617 = icmp ne i64 %r2616, 0
  br i1 %r2617, label %plen.ic.spill_ptr.507, label %plen.ic.miss.509

plen.ic.spill_ptr.507:                            ; preds = %plen.ic.spill_meta.506
  %r2618 = inttoptr i64 %r2616 to ptr
  %r2619 = getelementptr i64, ptr %r2618, i64 4
  %r2620 = load i64, ptr %r2619, align 8
  %r2621 = icmp ne i64 %r2620, 0
  %r2622 = select i1 %r2621, i64 %r2620, i64 %r2616
  %r2623 = inttoptr i64 %r2622 to ptr
  %r2624 = load i32, ptr %r2623, align 4
  %r2625 = zext i32 %r2624 to i64
  %r2626 = icmp ult i64 %r2605, %r2625
  %r2627 = and i1 %r2621, %r2626
  br i1 %r2627, label %plen.ic.spill_load.508, label %plen.ic.miss.509

plen.ic.spill_load.508:                           ; preds = %plen.ic.spill_ptr.507
  %r2628 = add nuw nsw i64 %r2605, 1
  %r2629 = getelementptr inbounds nuw i64, ptr %r2623, i64 %r2628
  %r2630 = load double, ptr %r2629, align 8
  br label %plen.ic.merge.510

plen.ic.miss.509:                                 ; preds = %plen.ic.spill_ptr.507, %plen.ic.spill_meta.506, %plen.ic.family_token.503, %plen.ic.family_meta.502, %plen.ic.exact.501, %plen.ic.shape.probe.499, %plen.ic.shape.498, %plen.ic.header.497, %plen.slow.495
  %statepoint_token471 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r2527, ptr @perry_ic_test_json_string_emitters_ts__36, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1142.1.relocated465, ptr addrspace(1) %rs4gc.s45) ]
  %r2631472 = call double @llvm.experimental.gc.result.f64(token %statepoint_token471)
  %r1142.1.relocated473 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token471, i32 0, i32 0) ; (%r1142.1.relocated465, %r1142.1.relocated465)
  %rs4gc.s45.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token471, i32 1, i32 1) ; (%rs4gc.s45, %rs4gc.s45)
  br label %plen.ic.merge.510

plen.ic.merge.510:                                ; preds = %plen.elem.length.513, %plen.ic.miss.509, %plen.ic.spill_load.508, %plen.ic.inline.505
  %.1607 = phi ptr addrspace(1) [ %rs4gc.s45, %plen.elem.length.513 ], [ %rs4gc.s45, %plen.ic.inline.505 ], [ %rs4gc.s45, %plen.ic.spill_load.508 ], [ %rs4gc.s45.relocated, %plen.ic.miss.509 ]
  %.15590 = phi ptr addrspace(1) [ %r1142.1.relocated465, %plen.elem.length.513 ], [ %r1142.1.relocated465, %plen.ic.inline.505 ], [ %r1142.1.relocated465, %plen.ic.spill_load.508 ], [ %r1142.1.relocated473, %plen.ic.miss.509 ]
  %r2632 = phi double [ %r2580, %plen.elem.length.513 ], [ %r2613, %plen.ic.inline.505 ], [ %r2630, %plen.ic.spill_load.508 ], [ %r2631472, %plen.ic.miss.509 ]
  br label %plen.merge.496

plen.elem.meta.511:                               ; preds = %plen.ic.header.497
  %r2570 = add nuw nsw i64 %r2529, 8
  %r2571 = inttoptr i64 %r2570 to ptr
  %r2572 = load i64, ptr %r2571, align 8
  %r2573 = icmp ne i64 %r2572, 0
  br i1 %r2573, label %plen.elem.store.512, label %plen.ic.shape.498

plen.elem.store.512:                              ; preds = %plen.elem.meta.511
  %r2574 = inttoptr i64 %r2572 to ptr
  %r2575 = getelementptr i64, ptr %r2574, i64 12
  %r2576 = load i64, ptr %r2575, align 8
  %r2577 = icmp ne i64 %r2576, 0
  br i1 %r2577, label %plen.elem.length.513, label %plen.ic.shape.498

plen.elem.length.513:                             ; preds = %plen.elem.store.512
  %r2578 = inttoptr i64 %r2576 to ptr
  %r2579 = load i32, ptr %r2578, align 4
  %r2580 = uitofp i32 %r2579 to double
  br label %plen.ic.merge.510

shadow.root.barrier.514:                          ; preds = %plen.merge.496
  call void @js_write_barrier_root_nanbox(i64 %r2636) #9
  br label %shadow.root.barrier.done.515

shadow.root.barrier.done.515:                     ; preds = %shadow.root.barrier.514, %plen.merge.496
  %r2639.rs4i = ptrtoint ptr addrspace(1) %r1142.1.relocated470 to i64
  %r2639.rs4o = call i64 asm "", "=r,0"(i64 %r2639.rs4i) #9
  %r2639 = bitcast i64 %r2639.rs4o to double
  %r2640.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s46 to i64
  %r2640 = call i64 asm "", "=r,0"(i64 %r2640.rs4i) #9
  %statepoint_token474 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r2640, double %r2639, i32 0, i32 0)
  %r2641475 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token474)
  %rs4gc.s47 = inttoptr i64 %r2641475 to ptr addrspace(1)
  %r2642.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s47 to i64
  %r2642 = call i64 asm "", "=r,0"(i64 %r2642.rs4i) #9
  %r2643 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2644 = icmp ne i32 %r2643, 0
  br i1 %r2644, label %shadow.root.barrier.516, label %shadow.root.barrier.done.517

shadow.root.barrier.516:                          ; preds = %shadow.root.barrier.done.515
  call void @js_write_barrier_root_nanbox(i64 %r2642) #9
  br label %shadow.root.barrier.done.517

shadow.root.barrier.done.517:                     ; preds = %shadow.root.barrier.516, %shadow.root.barrier.done.515
  %r2645.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s47 to i64
  %r2645 = call i64 asm "", "=r,0"(i64 %r2645.rs4i) #9
  %statepoint_token476 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r2645, i32 0, i32 0)
  %statepoint_token477 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token478 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token479 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token480 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token481 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.518

event_loop.header.518:                            ; preds = %event_loop.body_wait.523, %event_loop.body_check.522, %shadow.root.barrier.done.517
  %statepoint_token482 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_event_loop_host_driven, i32 0, i32 0, i32 0, i32 0)
  %r2650483 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token482)
  %r2651 = icmp ne i32 %r2650483, 0
  br i1 %r2651, label %event_loop.host_return.520, label %event_loop.check_pending.519

event_loop.check_pending.519:                     ; preds = %event_loop.header.518
  %statepoint_token484 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r2652485 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token484)
  %statepoint_token486 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r2653487 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token486)
  %statepoint_token488 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r2654489 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token488)
  %statepoint_token490 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r2655491 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token490)
  %statepoint_token492 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r2656493 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token492)
  %statepoint_token494 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r2657495 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token494)
  %r2658 = or i32 %r2652485, %r2653487
  %r2659 = or i32 %r2654489, %r2655491
  %r2660 = or i32 %r2659, %r2656493
  %r2661 = or i32 %r2658, %r2660
  %r2662 = or i32 %r2661, 0
  %r2663 = or i32 %r2662, %r2657495
  %r2664 = icmp ne i32 %r2663, 0
  br i1 %r2664, label %event_loop.body.521, label %event_loop.exit.524

event_loop.host_return.520:                       ; preds = %event_loop.header.518
  call void @js_typed_feedback_maybe_dump_trace() #9
  ret i32 0

event_loop.body.521:                              ; preds = %event_loop.check_pending.519
  %statepoint_token496 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token497 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.body_check.522

event_loop.body_check.522:                        ; preds = %event_loop.body.521
  %statepoint_token498 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r2666499 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token498)
  %statepoint_token500 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r2667501 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token500)
  %statepoint_token502 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r2668503 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token502)
  %statepoint_token504 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r2669505 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token504)
  %statepoint_token506 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r2670507 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token506)
  %statepoint_token508 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r2671509 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token508)
  %r2672 = or i32 %r2666499, %r2667501
  %r2673 = or i32 %r2668503, %r2669505
  %r2674 = or i32 %r2673, %r2670507
  %r2675 = or i32 %r2672, %r2674
  %r2676 = or i32 %r2675, 0
  %r2677 = or i32 %r2676, %r2671509
  %r2678 = icmp ne i32 %r2677, 0
  br i1 %r2678, label %event_loop.body_wait.523, label %event_loop.header.518

event_loop.body_wait.523:                         ; preds = %event_loop.body_check.522
  %statepoint_token510 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_wait_for_event, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.518

event_loop.exit.524:                              ; preds = %event_loop.check_pending.519
  %statepoint_token511 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_emit_before_exit_pending, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token512 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token513 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_exit_sequence, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token514 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_finalization_exit, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token515 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_promise_jobs, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token516 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_trace_events_flush_output, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token517 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_promise_report_unhandled_rejections, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token518 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_release_current_thread_collection_side_allocations, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token519 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_process_pending_exit_code, i32 0, i32 0, i32 0, i32 0)
  %r2681520 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token519)
  call void @js_typed_feedback_maybe_dump_trace() #9
  ret i32 %r2681520
}

; Function Attrs: optsize
define void @__perry_init_strings_test_json_string_emitters_ts_chunk0() #6 {
entry.0:
  %r1 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.0.bytes, i32 4)
  %r2 = call double @js_nanbox_string(i64 %r1)
  store double %r2, ptr @test_json_string_emitters_ts_.str.0.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.0.handle to i64))
  %r4 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.1.bytes, i32 18)
  %r5 = call double @js_nanbox_string(i64 %r4)
  store double %r5, ptr @test_json_string_emitters_ts_.str.1.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.1.handle to i64))
  %r7 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.2.bytes, i32 25)
  %r8 = call double @js_nanbox_string(i64 %r7)
  store double %r8, ptr @test_json_string_emitters_ts_.str.2.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.2.handle to i64))
  %r10 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.3.bytes, i32 2)
  %r11 = call double @js_nanbox_string(i64 %r10)
  store double %r11, ptr @test_json_string_emitters_ts_.str.3.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.3.handle to i64))
  %r13 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.4.bytes, i32 2)
  %r14 = call double @js_nanbox_string(i64 %r13)
  store double %r14, ptr @test_json_string_emitters_ts_.str.4.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.4.handle to i64))
  %r16 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.5.bytes, i32 5)
  %r17 = call double @js_nanbox_string(i64 %r16)
  store double %r17, ptr @test_json_string_emitters_ts_.str.5.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.5.handle to i64))
  %r19 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.6.bytes, i32 4)
  %r20 = call double @js_nanbox_string(i64 %r19)
  store double %r20, ptr @test_json_string_emitters_ts_.str.6.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.6.handle to i64))
  %r22 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.7.bytes, i32 0)
  %r23 = call double @js_nanbox_string(i64 %r22)
  store double %r23, ptr @test_json_string_emitters_ts_.str.7.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.7.handle to i64))
  %r25 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.8.bytes, i32 1)
  %r26 = call double @js_nanbox_string(i64 %r25)
  store double %r26, ptr @test_json_string_emitters_ts_.str.8.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.8.handle to i64))
  %r28 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.9.bytes, i32 5)
  %r29 = call double @js_nanbox_string(i64 %r28)
  store double %r29, ptr @test_json_string_emitters_ts_.str.9.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.9.handle to i64))
  %r31 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.10.bytes, i32 6)
  %r32 = call double @js_nanbox_string(i64 %r31)
  store double %r32, ptr @test_json_string_emitters_ts_.str.10.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.10.handle to i64))
  %r34 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.11.bytes, i32 15)
  %r35 = call double @js_nanbox_string(i64 %r34)
  store double %r35, ptr @test_json_string_emitters_ts_.str.11.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.11.handle to i64))
  %r37 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.12.bytes, i32 12)
  %r38 = call double @js_nanbox_string(i64 %r37)
  store double %r38, ptr @test_json_string_emitters_ts_.str.12.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.12.handle to i64))
  %r40 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.13.bytes, i32 12)
  %r41 = call double @js_nanbox_string(i64 %r40)
  store double %r41, ptr @test_json_string_emitters_ts_.str.13.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.13.handle to i64))
  %r43 = call i64 @js_string_from_wtf8_bytes(ptr @test_json_string_emitters_ts_.str.14.bytes, i32 3)
  %r44 = call double @js_nanbox_string(i64 %r43)
  store double %r44, ptr @test_json_string_emitters_ts_.str.14.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.14.handle to i64))
  %r46 = call i64 @js_string_from_wtf8_bytes(ptr @test_json_string_emitters_ts_.str.15.bytes, i32 3)
  %r47 = call double @js_nanbox_string(i64 %r46)
  store double %r47, ptr @test_json_string_emitters_ts_.str.15.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.15.handle to i64))
  %r49 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.16.bytes, i32 4)
  %r50 = call double @js_nanbox_string(i64 %r49)
  store double %r50, ptr @test_json_string_emitters_ts_.str.16.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.16.handle to i64))
  %r52 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.17.bytes, i32 8)
  %r53 = call double @js_nanbox_string(i64 %r52)
  store double %r53, ptr @test_json_string_emitters_ts_.str.17.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.17.handle to i64))
  %r55 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.18.bytes, i32 16)
  %r56 = call double @js_nanbox_string(i64 %r55)
  store double %r56, ptr @test_json_string_emitters_ts_.str.18.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.18.handle to i64))
  %r58 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.19.bytes, i32 6)
  %r59 = call double @js_nanbox_string(i64 %r58)
  store double %r59, ptr @test_json_string_emitters_ts_.str.19.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.19.handle to i64))
  %r61 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.20.bytes, i32 8)
  %r62 = call double @js_nanbox_string(i64 %r61)
  store double %r62, ptr @test_json_string_emitters_ts_.str.20.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.20.handle to i64))
  %r64 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.21.bytes, i32 15)
  %r65 = call double @js_nanbox_string(i64 %r64)
  store double %r65, ptr @test_json_string_emitters_ts_.str.21.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.21.handle to i64))
  %r67 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.22.bytes, i32 2)
  %r68 = call double @js_nanbox_string(i64 %r67)
  store double %r68, ptr @test_json_string_emitters_ts_.str.22.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.22.handle to i64))
  %r70 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.23.bytes, i32 1)
  %r71 = call double @js_nanbox_string(i64 %r70)
  store double %r71, ptr @test_json_string_emitters_ts_.str.23.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.23.handle to i64))
  %r73 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.24.bytes, i32 14)
  %r74 = call double @js_nanbox_string(i64 %r73)
  store double %r74, ptr @test_json_string_emitters_ts_.str.24.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.24.handle to i64))
  %r76 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.25.bytes, i32 16)
  %r77 = call double @js_nanbox_string(i64 %r76)
  store double %r77, ptr @test_json_string_emitters_ts_.str.25.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.25.handle to i64))
  %r79 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.26.bytes, i32 6)
  %r80 = call double @js_nanbox_string(i64 %r79)
  store double %r80, ptr @test_json_string_emitters_ts_.str.26.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.26.handle to i64))
  %r82 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.27.bytes, i32 39)
  %r83 = call double @js_nanbox_string(i64 %r82)
  store double %r83, ptr @test_json_string_emitters_ts_.str.27.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.27.handle to i64))
  %r85 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.28.bytes, i32 6)
  %r86 = call double @js_nanbox_string(i64 %r85)
  store double %r86, ptr @test_json_string_emitters_ts_.str.28.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.28.handle to i64))
  %r88 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.29.bytes, i32 18)
  %r89 = call double @js_nanbox_string(i64 %r88)
  store double %r89, ptr @test_json_string_emitters_ts_.str.29.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.29.handle to i64))
  %r91 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.30.bytes, i32 32)
  %r92 = call double @js_nanbox_string(i64 %r91)
  store double %r92, ptr @test_json_string_emitters_ts_.str.30.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.30.handle to i64))
  %r94 = call i64 @js_string_from_bytes(ptr @test_json_string_emitters_ts_.str.31.bytes, i32 8)
  %r95 = call double @js_nanbox_string(i64 %r94)
  store double %r95, ptr @test_json_string_emitters_ts_.str.31.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_string_emitters_ts_.str.31.handle to i64))
  call void @js_register_function_name_static(ptr @__perry_wrap_perry_fn_test_json_string_emitters_ts__identity, ptr @test_json_string_emitters_ts_.str.1, i32 8)
  call void @js_register_function_name_static(ptr @__perry_wrap_perry_fn_test_json_string_emitters_ts__allocateString, ptr @test_json_string_emitters_ts_.str.2, i32 14)
  call void @js_register_function_name_static(ptr @perry_fn_test_json_string_emitters_ts__identity, ptr @test_json_string_emitters_ts_.str.1, i32 8)
  call void @js_register_function_name_static(ptr @perry_fn_test_json_string_emitters_ts__allocateString, ptr @test_json_string_emitters_ts_.str.2, i32 14)
  call void @js_register_function_name_static(ptr @test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c_constructor, ptr @test_json_string_emitters_ts_.str.3, i32 32)
  call void @js_register_function_source_static(ptr @__perry_wrap_perry_fn_test_json_string_emitters_ts__identity, ptr @test_json_string_emitters_ts_.str.4, i32 65, i32 0)
  call void @js_register_function_source_static(ptr @__perry_wrap_perry_fn_test_json_string_emitters_ts__allocateString, ptr @test_json_string_emitters_ts_.str.5, i32 394, i32 0)
  %r97 = call i64 @js_build_class_keys_array(i32 1, i32 2, ptr @perry_class_keys_packed_test_json_string_emitters_ts__0, i32 8)
  store i64 %r97, ptr @perry_class_keys_test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c, align 8
  call void @js_write_barrier_root_heap_word(i64 %r97)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_class_keys_test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c to i64))
  %r99 = call i32 @js_gc_typed_shape_id_for_keys(i32 1, i64 %r97, i32 2, ptr @perry_typed_shape_raw_f64_mask_test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c, i32 1, ptr @perry_typed_shape_mask_test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c, i32 1)
  store i32 %r99, ptr @perry_class_shape_id_test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c, align 4
  %r100 = zext i32 %r99 to i64
  %r101 = shl nuw i64 %r100, 32
  %r102 = or i64 %r101, 1
  %r103 = insertelement <2 x i64> <i64 174214611458, i64 0>, i64 %r102, i32 1
  store <2 x i64> %r103, ptr @perry_class_header_image_test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c, align 8
  call void @js_register_class_constructor(i64 1, i64 ptrtoint (ptr @test_json_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c_constructor to i64), i64 2, i64 0)
  call void @js_register_class_id(i32 1)
  call void @js_register_anon_shape_class_id(i32 1)
  call void @js_register_class_length(i32 1, i32 2)
  call void @js_register_closure_arity(ptr @__perry_wrap_perry_fn_test_json_string_emitters_ts__allocateString, i32 2)
  call void @js_register_closure_arity(ptr @__perry_wrap_perry_fn_test_json_string_emitters_ts__identity, i32 2)
  call void @js_register_closure_length(ptr @__perry_wrap_perry_fn_test_json_string_emitters_ts__allocateString, i32 2)
  call void @js_register_closure_length(ptr @__perry_wrap_perry_fn_test_json_string_emitters_ts__identity, i32 2)
  call void @js_register_closure_strict_function(ptr @__perry_wrap_perry_fn_test_json_string_emitters_ts__allocateString)
  call void @js_register_closure_strict_function(ptr @__perry_wrap_perry_fn_test_json_string_emitters_ts__identity)
  ret void
}

; Function Attrs: optsize
define void @__perry_init_strings_test_json_string_emitters_ts() #6 {
entry.0:
  call void @__perry_init_strings_test_json_string_emitters_ts_chunk0()
  ret void
}

declare void @__tmp_use(...)

attributes #0 = { nounwind willreturn }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { optsize "frame-pointer"="non-leaf" }
attributes #7 = { inlinehint optsize "frame-pointer"="non-leaf" }
attributes #8 = { noinline optsize "frame-pointer"="non-leaf" }
attributes #9 = { "gc-leaf-function" }

!0 = !{}
