
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/lazy-cached-read-r22/candidate-access-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007bcc90 <_js_array_get_f64>:
1007bcc90:     	sub	sp, sp, #0x70
1007bcc94:     	stp	x26, x25, [sp, #0x20]
1007bcc98:     	stp	x24, x23, [sp, #0x30]
1007bcc9c:     	stp	x22, x21, [sp, #0x40]
1007bcca0:     	stp	x20, x19, [sp, #0x50]
1007bcca4:     	stp	x29, x30, [sp, #0x60]
1007bcca8:     	add	x29, sp, #0x60
1007bccac:     	mov	x19, x1
1007bccb0:     	mov	x22, x0
1007bccb4:     	lsr	x25, x0, #51
1007bccb8:     	mov	x20, x0
1007bccbc:     	cmp	x25, #0xfff
1007bccc0:     	b.lo	0x1007bccdc <_js_array_get_f64+0x4c>
1007bccc4:     	mov	w8, #0x7ffc             ; =32764
1007bccc8:     	cmp	x8, x22, lsr #48
1007bcccc:     	b.ne	0x1007bccd8 <_js_array_get_f64+0x48>
1007bccd0:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007bccd4:     	b	0x1007bd3d4 <_js_array_get_f64+0x744>
1007bccd8:     	and	x20, x22, #0xffffffffffff
1007bccdc:     	lsr	x8, x20, #3
1007bcce0:     	cmp	x8, #0x200
1007bcce4:     	b.ls	0x1007bcd24 <_js_array_get_f64+0x94>
1007bcce8:     	ldurb	w8, [x20, #-0x8]
1007bccec:     	cmp	w8, #0x9
1007bccf0:     	b.ne	0x1007bcd24 <_js_array_get_f64+0x94>
1007bccf4:     	ldr	w8, [x20, #0x4]
1007bccf8:     	mov	w9, #0x5841             ; =22593
1007bccfc:     	movk	w9, #0x4c5a, lsl #16
1007bcd00:     	cmp	w8, w9
1007bcd04:     	b.ne	0x1007bcd24 <_js_array_get_f64+0x94>
1007bcd08:     	ldr	x8, [x20, #0x20]
1007bcd0c:     	cbz	x8, 0x1007bcf78 <_js_array_get_f64+0x2e8>
1007bcd10:     	mov	x0, x20
1007bcd14:     	mov	x1, x19
1007bcd18:     	bl	0x10037451c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted>
1007bcd1c:     	fmov	d0, x0
1007bcd20:     	b	0x1007bd3d8 <_js_array_get_f64+0x748>
1007bcd24:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bcd28:     	b.lo	0x1007bcdd8 <_js_array_get_f64+0x148>
1007bcd2c:     	tst	x20, #0xffff800000000000
1007bcd30:     	mov	w8, #0x1000             ; =4096
1007bcd34:     	ccmp	x20, x8, #0x0, eq
1007bcd38:     	b.lo	0x1007bcdd8 <_js_array_get_f64+0x148>
1007bcd3c:     	ldurb	w24, [x20, #-0x8]
1007bcd40:     	ldurh	w23, [x20, #-0x6]
1007bcd44:     	cmp	w24, #0xa
1007bcd48:     	b.gt	0x1007bcef0 <_js_array_get_f64+0x260>
1007bcd4c:     	cmp	w24, #0x2
1007bcd50:     	b.eq	0x1007bcfb0 <_js_array_get_f64+0x320>
1007bcd54:     	cmp	w24, #0x8
1007bcd58:     	b.ne	0x1007bcde0 <_js_array_get_f64+0x150>
1007bcd5c:     	mov	x0, x20
1007bcd60:     	bl	0x100304068 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007bcd64:     	cbz	w0, 0x1007bd04c <_js_array_get_f64+0x3bc>
1007bcd68:     	mov	x22, #0x1               ; =1
1007bcd6c:     	movk	x22, #0x7ffc, lsl #48
1007bcd70:     	lsr	x8, x20, #51
1007bcd74:     	cmp	x8, #0xfff
1007bcd78:     	b.lo	0x1007bcd8c <_js_array_get_f64+0xfc>
1007bcd7c:     	mov	w8, #0x7ffc             ; =32764
1007bcd80:     	cmp	x8, x20, lsr #48
1007bcd84:     	b.eq	0x1007bd3d4 <_js_array_get_f64+0x744>
1007bcd88:     	and	x20, x20, #0xffffffffffff
1007bcd8c:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bcd90:     	b.lo	0x1007bcdb0 <_js_array_get_f64+0x120>
1007bcd94:     	tst	x20, #0xffff800000000000
1007bcd98:     	mov	w8, #0x1000             ; =4096
1007bcd9c:     	ccmp	x20, x8, #0x0, eq
1007bcda0:     	b.lo	0x1007bcdb0 <_js_array_get_f64+0x120>
1007bcda4:     	ldurb	w8, [x20, #-0x8]
1007bcda8:     	cmp	w8, #0x2
1007bcdac:     	b.eq	0x1007bd6c0 <_js_array_get_f64+0xa30>
1007bcdb0:     	cbz	x20, 0x1007bd3d4 <_js_array_get_f64+0x744>
1007bcdb4:     	mov	x0, x20
1007bcdb8:     	mov	x1, x19
1007bcdbc:     	bl	0x100304218 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007bcdc0:     	cmp	w0, #0x1
1007bcdc4:     	b.ne	0x1007bd3d4 <_js_array_get_f64+0x744>
1007bcdc8:     	ldr	x8, [x20, #0x8]
1007bcdcc:     	ubfiz	x9, x1, #4, #32
1007bcdd0:     	ldr	x22, [x8, x9]
1007bcdd4:     	b	0x1007bd3d4 <_js_array_get_f64+0x744>
1007bcdd8:     	mov	w23, #0x0               ; =0
1007bcddc:     	mov	w24, #0x0               ; =0
1007bcde0:     	mov	x21, x22
1007bcde4:     	cmp	x25, #0xfff
1007bcde8:     	b.lo	0x1007bce00 <_js_array_get_f64+0x170>
1007bcdec:     	mov	w8, #0x7ffc             ; =32764
1007bcdf0:     	cmp	x8, x22, lsr #48
1007bcdf4:     	b.eq	0x1007bd3c0 <_js_array_get_f64+0x730>
1007bcdf8:     	ands	x21, x22, #0xffffffffffff
1007bcdfc:     	b.eq	0x1007bd3c0 <_js_array_get_f64+0x730>
1007bce00:     	and	x8, x21, #0xfffffffffff00000
1007bce04:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007bce08:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007bce0c:     	cmp	x9, x10
1007bce10:     	ccmp	x8, #0x0, #0x4, lo
1007bce14:     	b.eq	0x1007bd3c0 <_js_array_get_f64+0x730>
1007bce18:     	tst	x21, #0x3
1007bce1c:     	ccmp	x21, #0x7, #0x0, eq
1007bce20:     	b.ls	0x1007bd114 <_js_array_get_f64+0x484>
1007bce24:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bce28:     	ldr	x8, [x8, #0x30]
1007bce2c:     	cmn	x8, #0x1
1007bce30:     	b.eq	0x1007bd064 <_js_array_get_f64+0x3d4>
1007bce34:     	mrs	x9, TPIDRRO_EL0
1007bce38:     	and	x9, x9, #0xfffffffffffffff8
1007bce3c:     	ldr	x0, [x9, x8, lsl #3]
1007bce40:     	cbz	x0, 0x1007bd064 <_js_array_get_f64+0x3d4>
1007bce44:     	lsr	x1, x21, #20
1007bce48:     	ldr	x8, [x0, #0x10]
1007bce4c:     	ldrb	w9, [x8]
1007bce50:     	cmp	w9, #0x2
1007bce54:     	b.ne	0x1007bd07c <_js_array_get_f64+0x3ec>
1007bce58:     	ldrb	w9, [x8, #0x88]
1007bce5c:     	tbz	w9, #0x0, 0x1007bce7c <_js_array_get_f64+0x1ec>
1007bce60:     	ldr	x9, [x8, #0x80]
1007bce64:     	cmp	x9, x1
1007bce68:     	b.ne	0x1007bce7c <_js_array_get_f64+0x1ec>
1007bce6c:     	ldp	x9, x10, [x8, #0x60]
1007bce70:     	cmp	x9, x21
1007bce74:     	ccmp	x10, x21, #0x0, ls
1007bce78:     	b.hi	0x1007bd05c <_js_array_get_f64+0x3cc>
1007bce7c:     	ldrb	w9, [x8, #0xb8]
1007bce80:     	cbz	w9, 0x1007bcea0 <_js_array_get_f64+0x210>
1007bce84:     	ldr	x9, [x8, #0xb0]
1007bce88:     	cmp	x9, x1
1007bce8c:     	b.ne	0x1007bcea0 <_js_array_get_f64+0x210>
1007bce90:     	ldp	x9, x10, [x8, #0x90]
1007bce94:     	cmp	x9, x21
1007bce98:     	ccmp	x10, x21, #0x0, ls
1007bce9c:     	b.hi	0x1007bd524 <_js_array_get_f64+0x894>
1007bcea0:     	ldrb	w9, [x8, #0xe8]
1007bcea4:     	cbz	w9, 0x1007bcec4 <_js_array_get_f64+0x234>
1007bcea8:     	ldr	x9, [x8, #0xe0]
1007bceac:     	cmp	x9, x1
1007bceb0:     	b.ne	0x1007bcec4 <_js_array_get_f64+0x234>
1007bceb4:     	ldp	x9, x10, [x8, #0xc0]
1007bceb8:     	cmp	x9, x21
1007bcebc:     	ccmp	x10, x21, #0x0, ls
1007bcec0:     	b.hi	0x1007bd60c <_js_array_get_f64+0x97c>
1007bcec4:     	ldrb	w9, [x8, #0x118]
1007bcec8:     	cbz	w9, 0x1007bd0dc <_js_array_get_f64+0x44c>
1007bcecc:     	ldr	x9, [x8, #0x110]
1007bced0:     	cmp	x9, x1
1007bced4:     	b.ne	0x1007bd0dc <_js_array_get_f64+0x44c>
1007bced8:     	ldp	x9, x10, [x8, #0xf0]
1007bcedc:     	cmp	x9, x21
1007bcee0:     	ccmp	x10, x21, #0x0, ls
1007bcee4:     	b.ls	0x1007bd0dc <_js_array_get_f64+0x44c>
1007bcee8:     	add	x9, x8, #0xf0
1007bceec:     	b	0x1007bd610 <_js_array_get_f64+0x980>
1007bcef0:     	cmp	w24, #0xb
1007bcef4:     	b.eq	0x1007bcfc8 <_js_array_get_f64+0x338>
1007bcef8:     	cmp	w24, #0xc
1007bcefc:     	b.ne	0x1007bcde0 <_js_array_get_f64+0x150>
1007bcf00:     	mov	x0, x20
1007bcf04:     	bl	0x100309df8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007bcf08:     	cbz	w0, 0x1007bd054 <_js_array_get_f64+0x3c4>
1007bcf0c:     	mov	x22, #0x1               ; =1
1007bcf10:     	movk	x22, #0x7ffc, lsl #48
1007bcf14:     	lsr	x8, x20, #51
1007bcf18:     	cmp	x8, #0xfff
1007bcf1c:     	b.lo	0x1007bcf30 <_js_array_get_f64+0x2a0>
1007bcf20:     	mov	w8, #0x7ffc             ; =32764
1007bcf24:     	cmp	x8, x20, lsr #48
1007bcf28:     	b.eq	0x1007bd3d4 <_js_array_get_f64+0x744>
1007bcf2c:     	and	x20, x20, #0xffffffffffff
1007bcf30:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bcf34:     	b.lo	0x1007bcf54 <_js_array_get_f64+0x2c4>
1007bcf38:     	tst	x20, #0xffff800000000000
1007bcf3c:     	mov	w8, #0x1000             ; =4096
1007bcf40:     	ccmp	x20, x8, #0x0, eq
1007bcf44:     	b.lo	0x1007bcf54 <_js_array_get_f64+0x2c4>
1007bcf48:     	ldurb	w8, [x20, #-0x8]
1007bcf4c:     	cmp	w8, #0x2
1007bcf50:     	b.eq	0x1007bd6d8 <_js_array_get_f64+0xa48>
1007bcf54:     	cbz	x20, 0x1007bd3d4 <_js_array_get_f64+0x744>
1007bcf58:     	mov	x0, x20
1007bcf5c:     	mov	x1, x19
1007bcf60:     	bl	0x10030ba70 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007bcf64:     	cmp	w0, #0x1
1007bcf68:     	b.ne	0x1007bd3d4 <_js_array_get_f64+0x744>
1007bcf6c:     	ldr	x8, [x20, #0x8]
1007bcf70:     	ldr	x22, [x8, w1, uxtw #3]
1007bcf74:     	b	0x1007bd3d4 <_js_array_get_f64+0x744>
1007bcf78:     	ldr	w8, [x20]
1007bcf7c:     	cmp	w19, w8
1007bcf80:     	b.hs	0x1007bd040 <_js_array_get_f64+0x3b0>
1007bcf84:     	ldr	x9, [x20, #0x30]
1007bcf88:     	cbz	x9, 0x1007bcd10 <_js_array_get_f64+0x80>
1007bcf8c:     	ldr	x8, [x20, #0x28]
1007bcf90:     	cbz	x8, 0x1007bcd10 <_js_array_get_f64+0x80>
1007bcf94:     	mov	w10, w19
1007bcf98:     	lsr	x11, x10, #6
1007bcf9c:     	ldr	x9, [x9, x11, lsl #3]
1007bcfa0:     	lsr	x9, x9, x19
1007bcfa4:     	tbz	w9, #0x0, 0x1007bcd10 <_js_array_get_f64+0x80>
1007bcfa8:     	ldr	x22, [x8, x10, lsl #3]
1007bcfac:     	b	0x1007bd3d4 <_js_array_get_f64+0x744>
1007bcfb0:     	mov	x0, x22
1007bcfb4:     	mov	x1, x19
1007bcfb8:     	bl	0x1005474cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007bcfbc:     	tbnz	w0, #0x0, 0x1007bd3d0 <_js_array_get_f64+0x740>
1007bcfc0:     	mov	w24, #0x2               ; =2
1007bcfc4:     	b	0x1007bcde0 <_js_array_get_f64+0x150>
1007bcfc8:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bcfcc:     	add	x8, x8, #0xe80
1007bcfd0:     	ldaprb	w8, [x8]
1007bcfd4:     	cbz	w8, 0x1007bd038 <_js_array_get_f64+0x3a8>
1007bcfd8:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bcfdc:     	add	x8, x8, #0x40
1007bcfe0:     	ldapr	x8, [x8]
1007bcfe4:     	cmp	x20, x8
1007bcfe8:     	b.lo	0x1007bd038 <_js_array_get_f64+0x3a8>
1007bcfec:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bcff0:     	add	x8, x8, #0x48
1007bcff4:     	ldapr	x8, [x8]
1007bcff8:     	cmp	x20, x8
1007bcffc:     	b.hi	0x1007bd038 <_js_array_get_f64+0x3a8>
1007bd000:     	mov	x0, x20
1007bd004:     	bl	0x1002a3b38 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd008:     	tbz	w0, #0x0, 0x1007bd038 <_js_array_get_f64+0x3a8>
1007bd00c:     	add	x0, sp, #0x8
1007bd010:     	mov	x1, x20
1007bd014:     	bl	0x1002a396c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007bd018:     	ldr	x8, [sp, #0x8]
1007bd01c:     	cbz	x8, 0x1007bd650 <_js_array_get_f64+0x9c0>
1007bd020:     	cmp	x8, #0x1
1007bd024:     	b.ne	0x1007bd694 <_js_array_get_f64+0xa04>
1007bd028:     	ldr	d0, [sp, #0x10]
1007bd02c:     	scvtf	d1, w19
1007bd030:     	bl	0x10081b274 <_js_dyn_index_get>
1007bd034:     	b	0x1007bd3d0 <_js_array_get_f64+0x740>
1007bd038:     	mov	w24, #0xb               ; =11
1007bd03c:     	b	0x1007bcde0 <_js_array_get_f64+0x150>
1007bd040:     	mov	x22, #0x1               ; =1
1007bd044:     	movk	x22, #0x7ffc, lsl #48
1007bd048:     	b	0x1007bd3d4 <_js_array_get_f64+0x744>
1007bd04c:     	mov	w24, #0x8               ; =8
1007bd050:     	b	0x1007bcde0 <_js_array_get_f64+0x150>
1007bd054:     	mov	w24, #0xc               ; =12
1007bd058:     	b	0x1007bcde0 <_js_array_get_f64+0x150>
1007bd05c:     	add	x9, x8, #0x60
1007bd060:     	b	0x1007bd610 <_js_array_get_f64+0x980>
1007bd064:     	bl	0x100b3defc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007bd068:     	lsr	x1, x21, #20
1007bd06c:     	ldr	x8, [x0, #0x10]
1007bd070:     	ldrb	w9, [x8]
1007bd074:     	cmp	w9, #0x2
1007bd078:     	b.eq	0x1007bce58 <_js_array_get_f64+0x1c8>
1007bd07c:     	ldr	x9, [x8, #0x8]
1007bd080:     	ldr	x10, [x8, #0x28]
1007bd084:     	sub	x9, x1, x9
1007bd088:     	cmp	x9, x10
1007bd08c:     	b.hs	0x1007bd0d0 <_js_array_get_f64+0x440>
1007bd090:     	ldr	x10, [x8, #0x20]
1007bd094:     	mov	w11, #0x28              ; =40
1007bd098:     	madd	x9, x9, x11, x10
1007bd09c:     	ldr	x10, [x9]
1007bd0a0:     	ldr	x11, [x8, #0x10]
1007bd0a4:     	cmp	x10, x11
1007bd0a8:     	b.ne	0x1007bd0dc <_js_array_get_f64+0x44c>
1007bd0ac:     	ldp	x10, x11, [x9, #0x8]
1007bd0b0:     	cmp	x10, x21
1007bd0b4:     	ccmp	x11, x21, #0x0, ls
1007bd0b8:     	b.ls	0x1007bd0dc <_js_array_get_f64+0x44c>
1007bd0bc:     	ldr	x10, [x8, #0x30]
1007bd0c0:     	add	x10, x10, #0x1
1007bd0c4:     	str	x10, [x8, #0x30]
1007bd0c8:     	add	x8, x9, #0x21
1007bd0cc:     	b	0x1007bd620 <_js_array_get_f64+0x990>
1007bd0d0:     	ldr	x9, [x8, #0x58]
1007bd0d4:     	add	x9, x9, #0x1
1007bd0d8:     	str	x9, [x8, #0x58]
1007bd0dc:     	ldr	x9, [x8, #0x38]
1007bd0e0:     	add	x9, x9, #0x1
1007bd0e4:     	str	x9, [x8, #0x38]
1007bd0e8:     	mov	x0, x21
1007bd0ec:     	bl	0x10051d208 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007bd0f0:     	and	w8, w0, #0xff
1007bd0f4:     	cbz	w8, 0x1007bd114 <_js_array_get_f64+0x484>
1007bd0f8:     	ldurb	w8, [x21, #-0x8]
1007bd0fc:     	ldurb	w9, [x21, #-0x7]
1007bd100:     	mov	w10, #0x82              ; =130
1007bd104:     	and	w9, w9, w10
1007bd108:     	cmp	w9, #0x2
1007bd10c:     	ccmp	w8, #0x1, #0x0, eq
1007bd110:     	b.eq	0x1007bd1e4 <_js_array_get_f64+0x554>
1007bd114:     	mov	x0, x21
1007bd118:     	bl	0x100579880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007bd11c:     	cbz	x0, 0x1007bd144 <_js_array_get_f64+0x4b4>
1007bd120:     	ldrb	w9, [x0]
1007bd124:     	cmp	w9, #0x1
1007bd128:     	b.ne	0x1007bd160 <_js_array_get_f64+0x4d0>
1007bd12c:     	ldrsb	w8, [x0, #0x1]
1007bd130:     	tbnz	w8, #0x1f, 0x1007bd20c <_js_array_get_f64+0x57c>
1007bd134:     	ldp	w10, w9, [x21]
1007bd138:     	cmp	w10, w9
1007bd13c:     	b.hi	0x1007bd298 <_js_array_get_f64+0x608>
1007bd140:     	b	0x1007bd2b0 <_js_array_get_f64+0x620>
1007bd144:     	mov	x25, x0
1007bd148:     	mov	x0, x21
1007bd14c:     	bl	0x1005880b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bd150:     	tbz	w0, #0x0, 0x1007bd19c <_js_array_get_f64+0x50c>
1007bd154:     	mov	x0, #0x0                ; =0
1007bd158:     	mov	x8, x25
1007bd15c:     	b	0x1007bd288 <_js_array_get_f64+0x5f8>
1007bd160:     	mov	x8, x0
1007bd164:     	cmp	w9, #0x1
1007bd168:     	b.eq	0x1007bd288 <_js_array_get_f64+0x5f8>
1007bd16c:     	cmp	w9, #0x9
1007bd170:     	b.ne	0x1007bd3c0 <_js_array_get_f64+0x730>
1007bd174:     	ldr	w8, [x21, #0x4]
1007bd178:     	mov	w9, #0x5841             ; =22593
1007bd17c:     	movk	w9, #0x4c5a, lsl #16
1007bd180:     	cmp	w8, w9
1007bd184:     	b.ne	0x1007bd3c0 <_js_array_get_f64+0x730>
1007bd188:     	mov	x0, x21
1007bd18c:     	bl	0x100374d0c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007bd190:     	cbz	x0, 0x1007bd3c0 <_js_array_get_f64+0x730>
1007bd194:     	mov	x21, x0
1007bd198:     	b	0x1007bd2cc <_js_array_get_f64+0x63c>
1007bd19c:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bd1a0:     	add	x8, x8, #0xe80
1007bd1a4:     	ldaprb	w8, [x8]
1007bd1a8:     	cbz	w8, 0x1007bd3c0 <_js_array_get_f64+0x730>
1007bd1ac:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd1b0:     	add	x8, x8, #0x40
1007bd1b4:     	ldapr	x8, [x8]
1007bd1b8:     	cmp	x8, x21
1007bd1bc:     	b.hi	0x1007bd3c0 <_js_array_get_f64+0x730>
1007bd1c0:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd1c4:     	add	x8, x8, #0x48
1007bd1c8:     	ldapr	x8, [x8]
1007bd1cc:     	cmp	x8, x21
1007bd1d0:     	b.lo	0x1007bd3c0 <_js_array_get_f64+0x730>
1007bd1d4:     	mov	x0, x21
1007bd1d8:     	bl	0x1002a3b38 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd1dc:     	tbnz	w0, #0x0, 0x1007bd154 <_js_array_get_f64+0x4c4>
1007bd1e0:     	b	0x1007bd3c0 <_js_array_get_f64+0x730>
1007bd1e4:     	ldr	w8, [x21]
1007bd1e8:     	mov	w9, #0xe100             ; =57600
1007bd1ec:     	movk	w9, #0x5f5, lsl #16
1007bd1f0:     	orr	w9, w9, #0x1
1007bd1f4:     	cmp	w8, w9
1007bd1f8:     	b.hs	0x1007bd114 <_js_array_get_f64+0x484>
1007bd1fc:     	ldr	w9, [x21, #0x4]
1007bd200:     	cmp	w8, w9
1007bd204:     	b.ls	0x1007bd2cc <_js_array_get_f64+0x63c>
1007bd208:     	b	0x1007bd114 <_js_array_get_f64+0x484>
1007bd20c:     	mov	x25, x0
1007bd210:     	ldr	x21, [x0, #0x8]
1007bd214:     	mov	x0, x21
1007bd218:     	bl	0x100579880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007bd21c:     	cbz	x0, 0x1007bd3c0 <_js_array_get_f64+0x730>
1007bd220:     	ldrb	w8, [x0]
1007bd224:     	cmp	w8, #0x1
1007bd228:     	b.ne	0x1007bd3c0 <_js_array_get_f64+0x730>
1007bd22c:     	ldrsb	w8, [x0, #0x1]
1007bd230:     	tbz	w8, #0x1f, 0x1007bd134 <_js_array_get_f64+0x4a4>
1007bd234:     	mov	w26, #0x1               ; =1
1007bd238:     	ldr	x21, [x0, #0x8]
1007bd23c:     	mov	x0, x21
1007bd240:     	bl	0x100579880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007bd244:     	cbz	x0, 0x1007bd3c0 <_js_array_get_f64+0x730>
1007bd248:     	ldrb	w8, [x0]
1007bd24c:     	cmp	w8, #0x1
1007bd250:     	b.ne	0x1007bd3c0 <_js_array_get_f64+0x730>
1007bd254:     	cmp	w26, #0x3f
1007bd258:     	b.hi	0x1007bd3c0 <_js_array_get_f64+0x730>
1007bd25c:     	add	w26, w26, #0x1
1007bd260:     	ldrsb	w8, [x0, #0x1]
1007bd264:     	tbnz	w8, #0x1f, 0x1007bd238 <_js_array_get_f64+0x5a8>
1007bd268:     	str	x21, [x25, #0x8]
1007bd26c:     	ldrb	w8, [x25, #0x1]
1007bd270:     	orr	w9, w8, #0x80
1007bd274:     	mov	x8, x25
1007bd278:     	strb	w9, [x25, #0x1]
1007bd27c:     	ldrb	w9, [x0]
1007bd280:     	cmp	w9, #0x1
1007bd284:     	b.ne	0x1007bd16c <_js_array_get_f64+0x4dc>
1007bd288:     	ldp	w10, w9, [x21]
1007bd28c:     	cmp	w10, w9
1007bd290:     	b.ls	0x1007bd2b0 <_js_array_get_f64+0x620>
1007bd294:     	cbz	x8, 0x1007bd2c0 <_js_array_get_f64+0x630>
1007bd298:     	ldr	w8, [x0, #0x4]
1007bd29c:     	ubfiz	x9, x9, #3, #32
1007bd2a0:     	add	x9, x9, #0x10
1007bd2a4:     	cmp	x9, x8
1007bd2a8:     	b.eq	0x1007bd2cc <_js_array_get_f64+0x63c>
1007bd2ac:     	b	0x1007bd2c0 <_js_array_get_f64+0x630>
1007bd2b0:     	mov	w8, #0xe100             ; =57600
1007bd2b4:     	movk	w8, #0x5f5, lsl #16
1007bd2b8:     	cmp	w10, w8
1007bd2bc:     	b.ls	0x1007bd2cc <_js_array_get_f64+0x63c>
1007bd2c0:     	mov	x0, x21
1007bd2c4:     	bl	0x1005880b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bd2c8:     	tbz	w0, #0x0, 0x1007bd37c <_js_array_get_f64+0x6ec>
1007bd2cc:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bd2d0:     	add	x8, x8, #0xe80
1007bd2d4:     	ldaprb	w8, [x8]
1007bd2d8:     	cbz	w8, 0x1007bd320 <_js_array_get_f64+0x690>
1007bd2dc:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd2e0:     	add	x8, x8, #0x40
1007bd2e4:     	ldapr	x8, [x8]
1007bd2e8:     	cmp	x21, x8
1007bd2ec:     	b.lo	0x1007bd320 <_js_array_get_f64+0x690>
1007bd2f0:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd2f4:     	add	x8, x8, #0x48
1007bd2f8:     	ldapr	x8, [x8]
1007bd2fc:     	cmp	x21, x8
1007bd300:     	b.hi	0x1007bd320 <_js_array_get_f64+0x690>
1007bd304:     	mov	x0, x21
1007bd308:     	bl	0x1002a3b38 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd30c:     	tbz	w0, #0x0, 0x1007bd320 <_js_array_get_f64+0x690>
1007bd310:     	mov	x0, x21
1007bd314:     	mov	x1, x19
1007bd318:     	bl	0x1008fafc8 <_js_typed_array_get>
1007bd31c:     	b	0x1007bd3d0 <_js_array_get_f64+0x740>
1007bd320:     	mov	x0, x21
1007bd324:     	bl	0x1005880b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bd328:     	tbz	w0, #0x0, 0x1007bd350 <_js_array_get_f64+0x6c0>
1007bd32c:     	mov	x0, x21
1007bd330:     	mov	x1, x19
1007bd334:     	bl	0x1005853dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007bd338:     	and	w8, w1, #0xff
1007bd33c:     	ucvtf	d0, w8
1007bd340:     	fmov	x8, d0
1007bd344:     	tst	w0, #0x1
1007bd348:     	csel	x22, x8, xzr, ne
1007bd34c:     	b	0x1007bd3d4 <_js_array_get_f64+0x744>
1007bd350:     	cmp	x21, x20
1007bd354:     	b.eq	0x1007bd3fc <_js_array_get_f64+0x76c>
1007bd358:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007bd35c:     	b.lo	0x1007bd3f4 <_js_array_get_f64+0x764>
1007bd360:     	tst	x21, #0xffff800000000000
1007bd364:     	mov	w8, #0x1000             ; =4096
1007bd368:     	ccmp	x21, x8, #0x0, eq
1007bd36c:     	b.lo	0x1007bd3f4 <_js_array_get_f64+0x764>
1007bd370:     	ldurb	w24, [x21, #-0x8]
1007bd374:     	ldurh	w23, [x21, #-0x6]
1007bd378:     	b	0x1007bd3fc <_js_array_get_f64+0x76c>
1007bd37c:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bd380:     	add	x8, x8, #0xe80
1007bd384:     	ldaprb	w8, [x8]
1007bd388:     	cbz	w8, 0x1007bd3c0 <_js_array_get_f64+0x730>
1007bd38c:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd390:     	add	x8, x8, #0x40
1007bd394:     	ldapr	x8, [x8]
1007bd398:     	cmp	x21, x8
1007bd39c:     	b.lo	0x1007bd3c0 <_js_array_get_f64+0x730>
1007bd3a0:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd3a4:     	add	x8, x8, #0x48
1007bd3a8:     	ldapr	x8, [x8]
1007bd3ac:     	cmp	x21, x8
1007bd3b0:     	b.hi	0x1007bd3c0 <_js_array_get_f64+0x730>
1007bd3b4:     	mov	x0, x21
1007bd3b8:     	bl	0x1002a3b38 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd3bc:     	tbnz	w0, #0x0, 0x1007bd2cc <_js_array_get_f64+0x63c>
1007bd3c0:     	mov	x0, x22
1007bd3c4:     	mov	x1, x19
1007bd3c8:     	bl	0x1005474cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007bd3cc:     	tbz	w0, #0x0, 0x1007bd6a4 <_js_array_get_f64+0xa14>
1007bd3d0:     	fmov	x22, d0
1007bd3d4:     	fmov	d0, x22
1007bd3d8:     	ldp	x29, x30, [sp, #0x60]
1007bd3dc:     	ldp	x20, x19, [sp, #0x50]
1007bd3e0:     	ldp	x22, x21, [sp, #0x40]
1007bd3e4:     	ldp	x24, x23, [sp, #0x30]
1007bd3e8:     	ldp	x26, x25, [sp, #0x20]
1007bd3ec:     	add	sp, sp, #0x70
1007bd3f0:     	ret
1007bd3f4:     	mov	w23, #0x0               ; =0
1007bd3f8:     	mov	w24, #0x0               ; =0
1007bd3fc:     	cmp	w24, #0x1
1007bd400:     	b.ne	0x1007bd5b4 <_js_array_get_f64+0x924>
1007bd404:     	tbz	w23, #0xa, 0x1007bd5b4 <_js_array_get_f64+0x924>
1007bd408:     	adrp	x8, 0x100b63000 <__RNvNtNtNtCsjgY6bXVaRmE_4core7unicode12unicode_data1n7OFFSETS+0xa6>
1007bd40c:     	add	x8, x8, #0x90c
1007bd410:     	cmp	w19, #0x3e8
1007bd414:     	b.lo	0x1007bd48c <_js_array_get_f64+0x7fc>
1007bd418:     	mov	x9, #0x0                ; =0
1007bd41c:     	mov	w11, #0x1759            ; =5977
1007bd420:     	movk	w11, #0xd1b7, lsl #16
1007bd424:     	mov	w12, #0x2710            ; =10000
1007bd428:     	mov	w13, #0x147b            ; =5243
1007bd42c:     	mov	w14, #0x64              ; =100
1007bd430:     	add	x15, sp, #0x8
1007bd434:     	mov	w16, #0x967f            ; =38527
1007bd438:     	movk	w16, #0x98, lsl #16
1007bd43c:     	mov	x10, x19
1007bd440:     	mov	x17, x10
1007bd444:     	umull	x10, w10, w11
1007bd448:     	lsr	x10, x10, #45
1007bd44c:     	msub	w0, w10, w12, w17
1007bd450:     	ubfx	w1, w0, #2, #14
1007bd454:     	mul	w1, w1, w13
1007bd458:     	lsr	w1, w1, #17
1007bd45c:     	msub	w0, w1, w14, w0
1007bd460:     	add	x2, x15, x9
1007bd464:     	ldrh	w1, [x8, w1, uxtw #1]
1007bd468:     	strh	w1, [x2, #0x6]
1007bd46c:     	and	x0, x0, #0xffff
1007bd470:     	ldrh	w0, [x8, x0, lsl #1]
1007bd474:     	strh	w0, [x2, #0x8]
1007bd478:     	sub	x9, x9, #0x4
1007bd47c:     	cmp	w17, w16
1007bd480:     	b.hi	0x1007bd440 <_js_array_get_f64+0x7b0>
1007bd484:     	add	x9, x9, #0xa
1007bd488:     	b	0x1007bd494 <_js_array_get_f64+0x804>
1007bd48c:     	mov	w9, #0xa                ; =10
1007bd490:     	mov	x10, x19
1007bd494:     	cmp	w10, #0x9
1007bd498:     	b.ls	0x1007bd4cc <_js_array_get_f64+0x83c>
1007bd49c:     	sub	x9, x9, #0x2
1007bd4a0:     	ubfx	w11, w10, #2, #14
1007bd4a4:     	mov	w12, #0x147b            ; =5243
1007bd4a8:     	mul	w11, w11, w12
1007bd4ac:     	lsr	w11, w11, #17
1007bd4b0:     	mov	w12, #0x64              ; =100
1007bd4b4:     	msub	w10, w11, w12, w10
1007bd4b8:     	and	x10, x10, #0xffff
1007bd4bc:     	ldrh	w10, [x8, x10, lsl #1]
1007bd4c0:     	add	x12, sp, #0x8
1007bd4c4:     	strh	w10, [x12, x9]
1007bd4c8:     	mov	x10, x11
1007bd4cc:     	cbz	w19, 0x1007bd504 <_js_array_get_f64+0x874>
1007bd4d0:     	cbnz	w10, 0x1007bd504 <_js_array_get_f64+0x874>
1007bd4d4:     	cmp	x9, #0xa
1007bd4d8:     	b.ne	0x1007bd52c <_js_array_get_f64+0x89c>
1007bd4dc:     	mov	w23, #0x1               ; =1
1007bd4e0:     	add	x0, sp, #0x8
1007bd4e4:     	mov	x1, x21
1007bd4e8:     	mov	w2, #0x1                ; =1
1007bd4ec:     	mov	x3, #0x0                ; =0
1007bd4f0:     	bl	0x1005b17bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007bd4f4:     	ldr	x8, [sp, #0x8]
1007bd4f8:     	mov	w20, #0x1               ; =1
1007bd4fc:     	cbnz	x8, 0x1007bd57c <_js_array_get_f64+0x8ec>
1007bd500:     	b	0x1007bd5b4 <_js_array_get_f64+0x924>
1007bd504:     	sub	x23, x9, #0x1
1007bd508:     	ubfiz	w10, w10, #1, #4
1007bd50c:     	add	x8, x8, x10
1007bd510:     	ldrb	w8, [x8, #0x1]
1007bd514:     	add	x10, sp, #0x8
1007bd518:     	strb	w8, [x10, x23]
1007bd51c:     	mov	w8, #0xb                ; =11
1007bd520:     	b	0x1007bd534 <_js_array_get_f64+0x8a4>
1007bd524:     	add	x9, x8, #0x90
1007bd528:     	b	0x1007bd610 <_js_array_get_f64+0x980>
1007bd52c:     	mov	w8, #0xa                ; =10
1007bd530:     	mov	x23, x9
1007bd534:     	sub	x22, x8, x9
1007bd538:     	mov	x0, x22
1007bd53c:     	mov	w1, #0x1                ; =1
1007bd540:     	bl	0x100b5dd48 <_mi_malloc_aligned>
1007bd544:     	cbz	x0, 0x1007bd6f0 <_js_array_get_f64+0xa60>
1007bd548:     	mov	x20, x0
1007bd54c:     	add	x8, sp, #0x8
1007bd550:     	add	x1, x8, x23
1007bd554:     	mov	x2, x22
1007bd558:     	bl	0x100b6096c <_writev+0x100b6096c>
1007bd55c:     	add	x0, sp, #0x8
1007bd560:     	mov	x1, x21
1007bd564:     	mov	x2, x20
1007bd568:     	mov	x3, x22
1007bd56c:     	bl	0x1005b17bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007bd570:     	ldr	w8, [sp, #0x8]
1007bd574:     	tbz	w8, #0x0, 0x1007bd5ac <_js_array_get_f64+0x91c>
1007bd578:     	mov	w23, #0x0               ; =0
1007bd57c:     	mov	x22, #0x1               ; =1
1007bd580:     	movk	x22, #0x7ffc, lsl #48
1007bd584:     	ldr	x0, [sp, #0x10]
1007bd588:     	cbz	x0, 0x1007bd640 <_js_array_get_f64+0x9b0>
1007bd58c:     	cbz	x21, 0x1007bd630 <_js_array_get_f64+0x9a0>
1007bd590:     	lsr	x8, x21, #52
1007bd594:     	cmp	x8, #0x7fe
1007bd598:     	b.hi	0x1007bd634 <_js_array_get_f64+0x9a4>
1007bd59c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007bd5a0:     	bfxil	x8, x21, #0, #48
1007bd5a4:     	mov	x21, x8
1007bd5a8:     	b	0x1007bd634 <_js_array_get_f64+0x9a4>
1007bd5ac:     	mov	x0, x20
1007bd5b0:     	bl	0x100b5dac0 <_mi_free>
1007bd5b4:     	ldr	w8, [x21]
1007bd5b8:     	cmp	w19, w8
1007bd5bc:     	b.hs	0x1007bd5fc <_js_array_get_f64+0x96c>
1007bd5c0:     	ldr	w8, [x21, #0x4]
1007bd5c4:     	cmp	w19, w8
1007bd5c8:     	b.hs	0x1007bd5ec <_js_array_get_f64+0x95c>
1007bd5cc:     	add	x8, x21, w19, uxtw #3
1007bd5d0:     	ldr	x22, [x8, #0x8]
1007bd5d4:     	mov	x8, #0x1                ; =1
1007bd5d8:     	movk	x8, #0x7ffc, lsl #48
1007bd5dc:     	add	x8, x8, #0xf
1007bd5e0:     	cmp	x22, x8
1007bd5e4:     	b.ne	0x1007bd3d4 <_js_array_get_f64+0x744>
1007bd5e8:     	b	0x1007bd5fc <_js_array_get_f64+0x96c>
1007bd5ec:     	mov	x0, x21
1007bd5f0:     	mov	x1, x19
1007bd5f4:     	bl	0x1005298c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007bd5f8:     	tbnz	w0, #0x0, 0x1007bd3d0 <_js_array_get_f64+0x740>
1007bd5fc:     	mov	x0, x21
1007bd600:     	mov	x1, x19
1007bd604:     	bl	0x1006c60d8 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007bd608:     	b	0x1007bd3d0 <_js_array_get_f64+0x740>
1007bd60c:     	add	x9, x8, #0xc0
1007bd610:     	ldr	x10, [x8, #0x30]
1007bd614:     	add	x10, x10, #0x1
1007bd618:     	str	x10, [x8, #0x30]
1007bd61c:     	add	x8, x9, #0x19
1007bd620:     	ldrb	w8, [x8]
1007bd624:     	cmp	w8, #0xff
1007bd628:     	b.ne	0x1007bd0f4 <_js_array_get_f64+0x464>
1007bd62c:     	b	0x1007bd0e8 <_js_array_get_f64+0x458>
1007bd630:     	add	x21, x22, #0x1
1007bd634:     	fmov	d0, x21
1007bd638:     	bl	0x1006fbefc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007bd63c:     	mov	x22, x0
1007bd640:     	tbnz	w23, #0x0, 0x1007bd3d4 <_js_array_get_f64+0x744>
1007bd644:     	mov	x0, x20
1007bd648:     	bl	0x100b5dac0 <_mi_free>
1007bd64c:     	b	0x1007bd3d4 <_js_array_get_f64+0x744>
1007bd650:     	ldr	x20, [sp, #0x10]
1007bd654:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bd658:     	ldr	x8, [x8, #0xe98]
1007bd65c:     	cbz	x8, 0x1007bd674 <_js_array_get_f64+0x9e4>
1007bd660:     	mov	x0, x20
1007bd664:     	bl	0x10013bbc0 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007bd668:     	tbz	w0, #0x0, 0x1007bd674 <_js_array_get_f64+0x9e4>
1007bd66c:     	mov	x0, x20
1007bd670:     	bl	0x1002bdd40 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007bd674:     	tbnz	w19, #0x1f, 0x1007bd694 <_js_array_get_f64+0xa04>
1007bd678:     	ldr	w8, [x20]
1007bd67c:     	cmp	w19, w8
1007bd680:     	b.hs	0x1007bd694 <_js_array_get_f64+0xa04>
1007bd684:     	mov	w1, w19
1007bd688:     	mov	x0, x20
1007bd68c:     	bl	0x1002a3fcc <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007bd690:     	b	0x1007bd3d0 <_js_array_get_f64+0x740>
1007bd694:     	mov	x8, #0x1                ; =1
1007bd698:     	movk	x8, #0x7ffc, lsl #48
1007bd69c:     	mov	x22, x8
1007bd6a0:     	b	0x1007bd3d4 <_js_array_get_f64+0x744>
1007bd6a4:     	mov	x0, x22
1007bd6a8:     	bl	0x100b46430 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007bd6ac:     	cmp	x0, #0x1
1007bd6b0:     	b.ne	0x1007bccd0 <_js_array_get_f64+0x40>
1007bd6b4:     	mov	x0, x19
1007bd6b8:     	bl	0x100b46450 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007bd6bc:     	b	0x1007bd3d0 <_js_array_get_f64+0x740>
1007bd6c0:     	mov	x0, x20
1007bd6c4:     	mov	w1, #0x0                ; =0
1007bd6c8:     	bl	0x100b489c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bd6cc:     	mov	x20, x0
1007bd6d0:     	cbnz	x0, 0x1007bcdb4 <_js_array_get_f64+0x124>
1007bd6d4:     	b	0x1007bd3d4 <_js_array_get_f64+0x744>
1007bd6d8:     	mov	x0, x20
1007bd6dc:     	mov	w1, #0x1                ; =1
1007bd6e0:     	bl	0x100b489c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bd6e4:     	mov	x20, x0
1007bd6e8:     	cbnz	x0, 0x1007bcf58 <_js_array_get_f64+0x2c8>
1007bd6ec:     	b	0x1007bd3d4 <_js_array_get_f64+0x744>
1007bd6f0:     	mov	w0, #0x1                ; =1
1007bd6f4:     	mov	x1, x22
1007bd6f8:     	bl	0x100b10e80 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1007bd6fc:     	udf	#0x0
