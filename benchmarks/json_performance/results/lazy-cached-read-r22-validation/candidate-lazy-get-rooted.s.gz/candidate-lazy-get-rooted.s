
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/lazy-cached-read-r22/candidate-access-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010037451c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted>:
10037451c:     	sub	sp, sp, #0xc0
100374520:     	stp	x28, x27, [sp, #0x60]
100374524:     	stp	x26, x25, [sp, #0x70]
100374528:     	stp	x24, x23, [sp, #0x80]
10037452c:     	stp	x22, x21, [sp, #0x90]
100374530:     	stp	x20, x19, [sp, #0xa0]
100374534:     	stp	x29, x30, [sp, #0xb0]
100374538:     	add	x29, sp, #0xb0
10037453c:     	mov	x20, #0x1               ; =1
100374540:     	movk	x20, #0x7ffc, lsl #48
100374544:     	cbz	x0, 0x100374974 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x458>
100374548:     	mov	x19, x1
10037454c:     	mov	x21, x0
100374550:     	bl	0x10028a2d8 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
100374554:     	str	x0, [sp, #0x10]
100374558:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10037455c:     	stp	x21, x8, [sp, #0x28]
100374560:     	mov	w8, #0x1                ; =1
100374564:     	str	x8, [sp, #0x20]
100374568:     	add	x0, sp, #0x20
10037456c:     	bl	0x10028a3e0 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
100374570:     	mov	x21, x0
100374574:     	str	x0, [sp, #0x18]
100374578:     	adrp	x24, 0x100f7c000 <_perry_global_access_worker_ts__1>
10037457c:     	ldr	x8, [x24, #0x30]
100374580:     	cmn	x8, #0x1
100374584:     	b.eq	0x1003745ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0xd0>
100374588:     	mrs	x9, TPIDRRO_EL0
10037458c:     	and	x9, x9, #0xfffffffffffffff8
100374590:     	ldr	x8, [x9, x8, lsl #3]
100374594:     	cbz	x8, 0x1003745ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0xd0>
100374598:     	ldr	x8, [x8, #0x19e8]
10037459c:     	cbz	x8, 0x1003745ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0xd0>
1003745a0:     	ldr	x9, [x8]
1003745a4:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1003745a8:     	cmp	x9, x10
1003745ac:     	b.hs	0x100374998 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x47c>
1003745b0:     	add	x10, x9, #0x1
1003745b4:     	str	x10, [x8]
1003745b8:     	ldr	x10, [x8, #0x18]
1003745bc:     	cmp	x21, x10
1003745c0:     	b.hs	0x1003749a4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x488>
1003745c4:     	ldr	x10, [x8, #0x10]
1003745c8:     	mov	w11, #0x18              ; =24
1003745cc:     	madd	x10, x21, x11, x10
1003745d0:     	ldr	x11, [x10]
1003745d4:     	cmp	x11, #0x1
1003745d8:     	b.ne	0x1003749a8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x48c>
1003745dc:     	ldr	x22, [x10, #0x8]
1003745e0:     	str	x9, [x8]
1003745e4:     	cbnz	x22, 0x1003745fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0xe0>
1003745e8:     	b	0x10037496c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x450>
1003745ec:     	mov	x0, x21
1003745f0:     	bl	0x10013b118 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
1003745f4:     	mov	x22, x0
1003745f8:     	cbz	x0, 0x10037496c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x450>
1003745fc:     	mov	x0, x22
100374600:     	bl	0x10068711c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100374604:     	cbz	x0, 0x100374618 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0xfc>
100374608:     	mov	x1, x19
10037460c:     	bl	0x1007bcc90 <_js_array_get_f64>
100374610:     	fmov	x20, d0
100374614:     	b	0x10037496c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x450>
100374618:     	ldr	w23, [x22]
10037461c:     	cmp	w19, w23
100374620:     	b.hs	0x10037496c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x450>
100374624:     	ldr	x9, [x22, #0x30]
100374628:     	cbz	x9, 0x100374650 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x134>
10037462c:     	ldr	x8, [x22, #0x28]
100374630:     	cbz	x8, 0x100374650 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x134>
100374634:     	mov	w10, w19
100374638:     	lsr	x11, x10, #6
10037463c:     	ldr	x9, [x9, x11, lsl #3]
100374640:     	lsr	x9, x9, x10
100374644:     	tbz	w9, #0x0, 0x100374650 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x134>
100374648:     	ldr	x20, [x8, x10, lsl #3]
10037464c:     	b	0x10037496c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x450>
100374650:     	stp	xzr, x21, [sp, #0x20]
100374654:     	ldr	w25, [x22, #0x8]
100374658:     	ldr	x8, [x24, #0x30]
10037465c:     	cmn	x8, #0x1
100374660:     	b.eq	0x1003746c4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x1a8>
100374664:     	mrs	x9, TPIDRRO_EL0
100374668:     	and	x9, x9, #0xfffffffffffffff8
10037466c:     	ldr	x8, [x9, x8, lsl #3]
100374670:     	cbz	x8, 0x1003746c4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x1a8>
100374674:     	ldr	x8, [x8, #0x19e8]
100374678:     	cbz	x8, 0x1003746c4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x1a8>
10037467c:     	ldr	x9, [x8]
100374680:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100374684:     	cmp	x9, x10
100374688:     	b.hs	0x100374998 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x47c>
10037468c:     	add	x10, x9, #0x1
100374690:     	str	x10, [x8]
100374694:     	ldr	x10, [x8, #0x18]
100374698:     	cmp	x21, x10
10037469c:     	b.hs	0x1003749a4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x488>
1003746a0:     	ldr	x10, [x8, #0x10]
1003746a4:     	mov	w11, #0x18              ; =24
1003746a8:     	madd	x10, x21, x11, x10
1003746ac:     	ldr	x11, [x10]
1003746b0:     	cmp	x11, #0x1
1003746b4:     	b.ne	0x1003749a8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x48c>
1003746b8:     	ldr	x0, [x10, #0x8]
1003746bc:     	str	x9, [x8]
1003746c0:     	b	0x1003746cc <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x1b0>
1003746c4:     	mov	x0, x21
1003746c8:     	bl	0x10013b118 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
1003746cc:     	cbz	x0, 0x10037496c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x450>
1003746d0:     	ldr	w8, [x0, #0xc]
1003746d4:     	cmp	w25, w8
1003746d8:     	b.hs	0x10037496c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x450>
1003746dc:     	ldr	x8, [x0, #0x10]
1003746e0:     	cbz	x8, 0x10037496c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x450>
1003746e4:     	mov	w9, #0xc                ; =12
1003746e8:     	umaddl	x8, w25, w9, x8
1003746ec:     	ldrb	w9, [x8, #0x8]
1003746f0:     	cmp	w9, #0x3
1003746f4:     	b.ne	0x10037496c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x450>
1003746f8:     	ldr	w28, [x8, #0x4]
1003746fc:     	ldr	w26, [x22, #0x38]
100374700:     	cmn	w26, #0x1
100374704:     	b.eq	0x10037471c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x200>
100374708:     	cmp	w19, w26
10037470c:     	b.lo	0x10037471c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x200>
100374710:     	ldr	w25, [x22, #0x3c]
100374714:     	mov	x9, x26
100374718:     	b	0x100374724 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x208>
10037471c:     	mov	w9, #0x0                ; =0
100374720:     	add	x25, x25, #0x1
100374724:     	str	x25, [sp, #0x40]
100374728:     	cmp	x25, x28
10037472c:     	cset	w8, lo
100374730:     	str	w9, [sp, #0xc]
100374734:     	b.hs	0x10037480c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x2f0>
100374738:     	cmp	w19, w9
10037473c:     	b.ls	0x10037480c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x2f0>
100374740:     	add	w27, w9, #0x1
100374744:     	ldr	x8, [x24, #0x30]
100374748:     	cmn	x8, #0x1
10037474c:     	b.eq	0x1003747b0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x294>
100374750:     	mrs	x9, TPIDRRO_EL0
100374754:     	and	x9, x9, #0xfffffffffffffff8
100374758:     	ldr	x8, [x9, x8, lsl #3]
10037475c:     	cbz	x8, 0x1003747b0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x294>
100374760:     	ldr	x8, [x8, #0x19e8]
100374764:     	cbz	x8, 0x1003747b0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x294>
100374768:     	ldr	x9, [x8]
10037476c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100374770:     	cmp	x9, x10
100374774:     	b.hs	0x100374998 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x47c>
100374778:     	add	x10, x9, #0x1
10037477c:     	str	x10, [x8]
100374780:     	ldr	x10, [x8, #0x18]
100374784:     	cmp	x21, x10
100374788:     	b.hs	0x1003749a4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x488>
10037478c:     	ldr	x10, [x8, #0x10]
100374790:     	mov	w11, #0x18              ; =24
100374794:     	madd	x10, x21, x11, x10
100374798:     	ldr	x11, [x10]
10037479c:     	cmp	x11, #0x1
1003747a0:     	b.ne	0x1003749a8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x48c>
1003747a4:     	ldr	x0, [x10, #0x8]
1003747a8:     	str	x9, [x8]
1003747ac:     	b	0x1003747b8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x29c>
1003747b0:     	mov	x0, x21
1003747b4:     	bl	0x10013b118 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
1003747b8:     	cbz	x0, 0x10037496c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x450>
1003747bc:     	ldr	w8, [x0, #0xc]
1003747c0:     	cmp	x25, x8
1003747c4:     	b.hs	0x10037496c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x450>
1003747c8:     	ldr	x8, [x0, #0x10]
1003747cc:     	cbz	x8, 0x10037496c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x450>
1003747d0:     	mov	w9, #0xc                ; =12
1003747d4:     	madd	x8, x25, x9, x8
1003747d8:     	ldrb	w9, [x8, #0x8]
1003747dc:     	orr	w9, w9, #0x2
1003747e0:     	cmp	w9, #0x3
1003747e4:     	b.ne	0x1003747ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x2d0>
1003747e8:     	ldr	w25, [x8, #0x4]
1003747ec:     	add	x25, x25, #0x1
1003747f0:     	str	x25, [sp, #0x40]
1003747f4:     	cmp	x25, x28
1003747f8:     	cset	w8, lo
1003747fc:     	b.hs	0x10037480c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x2f0>
100374800:     	cmp	w27, w19
100374804:     	add	w27, w27, #0x1
100374808:     	b.lo	0x100374744 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x228>
10037480c:     	tbz	w8, #0x0, 0x10037496c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x450>
100374810:     	ldr	w8, [sp, #0xc]
100374814:     	sub	w8, w19, w8
100374818:     	add	w9, w26, #0x1
10037481c:     	cmp	w19, w9
100374820:     	ccmn	w26, #0x1, #0x4, eq
100374824:     	b.eq	0x100374838 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x31c>
100374828:     	ldr	w9, [x22, #0x48]
10037482c:     	adds	w9, w9, #0x1
100374830:     	csinv	w21, w9, wzr, lo
100374834:     	b	0x10037483c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x320>
100374838:     	mov	w21, #0x1               ; =1
10037483c:     	str	w21, [x22, #0x48]
100374840:     	stp	w19, w25, [x22, #0x38]
100374844:     	ldr	x9, [x22, #0x40]
100374848:     	adds	x8, x9, x8
10037484c:     	csinv	x8, x8, xzr, lo
100374850:     	str	x8, [x22, #0x40]
100374854:     	add	x8, sp, #0x20
100374858:     	add	x9, sp, #0x10
10037485c:     	stp	x8, x9, [sp, #0x48]
100374860:     	add	x8, sp, #0x40
100374864:     	str	x8, [sp, #0x58]
100374868:     	cmp	w21, #0x1
10037486c:     	b.ls	0x10037488c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x370>
100374870:     	add	x0, sp, #0x48
100374874:     	bl	0x100215184 <__RNCNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted0B5_>
100374878:     	mov	x8, x0
10037487c:     	tbz	w8, #0x0, 0x100374888 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x36c>
100374880:     	mov	x0, x1
100374884:     	b	0x10037489c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x380>
100374888:     	ldr	x25, [sp, #0x40]
10037488c:     	str	x25, [sp, #0x48]
100374890:     	add	x0, sp, #0x20
100374894:     	add	x1, sp, #0x48
100374898:     	bl	0x10037713c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24materialize_value_source>
10037489c:     	stp	xzr, x0, [sp, #0x48]
1003748a0:     	add	x0, sp, #0x48
1003748a4:     	bl	0x10028a3e0 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
1003748a8:     	str	x0, [sp, #0x48]
1003748ac:     	add	x0, sp, #0x18
1003748b0:     	bl	0x10013f958 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle10across_mutNtNtBc_9json_tape15LazyArrayHeaderuNCNvB1D_19reparse_materializes_0EBc_>
1003748b4:     	ldr	x22, [x0, #0x30]
1003748b8:     	cbz	x22, 0x100374904 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x3e8>
1003748bc:     	ldr	x24, [x0, #0x28]
1003748c0:     	cbz	x24, 0x100374904 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x3e8>
1003748c4:     	mov	x20, x0
1003748c8:     	add	x0, sp, #0x48
1003748cc:     	bl	0x100266b2c <__RNvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB5_13RuntimeHandle14get_nanbox_u64>
1003748d0:     	mov	x2, x0
1003748d4:     	mov	w25, w19
1003748d8:     	add	x1, x24, w19, uxtw #3
1003748dc:     	str	x0, [x1]
1003748e0:     	mov	x0, x20
1003748e4:     	bl	0x100374c8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape20note_lazy_cache_slot>
1003748e8:     	mov	w8, #0x1                ; =1
1003748ec:     	lsl	x8, x8, x25
1003748f0:     	lsr	x9, x25, #3
1003748f4:     	and	x9, x9, #0x1ffffff8
1003748f8:     	ldr	x10, [x22, x9]
1003748fc:     	orr	x8, x10, x8
100374900:     	str	x8, [x22, x9]
100374904:     	add	x0, sp, #0x18
100374908:     	bl	0x10013f958 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle10across_mutNtNtBc_9json_tape15LazyArrayHeaderuNCNvB1D_19reparse_materializes_0EBc_>
10037490c:     	lsr	w8, w23, #6
100374910:     	mov	w9, #0x40               ; =64
100374914:     	cmp	w8, #0x40
100374918:     	csel	w8, w8, w9, hi
10037491c:     	cmp	w21, w8
100374920:     	b.hs	0x100374934 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x418>
100374924:     	ldr	x8, [x0, #0x40]
100374928:     	cmp	x8, x23, lsl #1
10037492c:     	b.hi	0x10037495c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x440>
100374930:     	b	0x100374960 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x444>
100374934:     	mov	x19, x0
100374938:     	bl	0x1003749b8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape17lazy_cached_count>
10037493c:     	mov	x8, x0
100374940:     	mov	x0, x19
100374944:     	ldr	x9, [x19, #0x40]
100374948:     	cmp	x9, x23, lsl #1
10037494c:     	b.hi	0x10037495c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x440>
100374950:     	lsl	x8, x8, #1
100374954:     	cmp	x8, x23
100374958:     	b.hs	0x100374960 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted+0x444>
10037495c:     	bl	0x100374d0c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
100374960:     	add	x0, sp, #0x48
100374964:     	bl	0x100266b2c <__RNvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB5_13RuntimeHandle14get_nanbox_u64>
100374968:     	mov	x20, x0
10037496c:     	add	x0, sp, #0x10
100374970:     	bl	0x100165cfc <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100374974:     	mov	x0, x20
100374978:     	ldp	x29, x30, [sp, #0xb0]
10037497c:     	ldp	x20, x19, [sp, #0xa0]
100374980:     	ldp	x22, x21, [sp, #0x90]
100374984:     	ldp	x24, x23, [sp, #0x80]
100374988:     	ldp	x26, x25, [sp, #0x70]
10037498c:     	ldp	x28, x27, [sp, #0x60]
100374990:     	add	sp, sp, #0xc0
100374994:     	ret
100374998:     	adrp	x0, 0x100ef3000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
10037499c:     	add	x0, x0, #0xd70
1003749a0:     	bl	0x100b1125c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1003749a4:     	bl	0x100b4a454 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
1003749a8:     	adrp	x0, 0x100c40000 <_anon.3a0f55142d697dd4d6c50f8035b0d3d6.3+0x5440>
1003749ac:     	add	x0, x0, #0xce7
1003749b0:     	mov	w1, #0xb                ; =11
1003749b4:     	bl	0x100b4a41c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
