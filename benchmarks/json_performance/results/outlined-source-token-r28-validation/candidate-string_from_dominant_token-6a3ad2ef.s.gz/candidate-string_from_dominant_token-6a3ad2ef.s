
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/outlined-source-token-r28/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001006c65d0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token>:
1006c65d0:     	stp	x24, x23, [sp, #-0x40]!
1006c65d4:     	stp	x22, x21, [sp, #0x10]
1006c65d8:     	stp	x20, x19, [sp, #0x20]
1006c65dc:     	stp	x29, x30, [sp, #0x30]
1006c65e0:     	add	x29, sp, #0x30
1006c65e4:     	mov	x19, x6
1006c65e8:     	mov	x20, x5
1006c65ec:     	mov	x21, x0
1006c65f0:     	mov	x0, x1
1006c65f4:     	mov	x1, x2
1006c65f8:     	mov	x2, x3
1006c65fc:     	mov	x3, x4
1006c6600:     	mov	x4, x6
1006c6604:     	bl	0x1006c6490 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len>
1006c6608:     	cmp	w0, #0x1
1006c660c:     	b.ne	0x1006c66ac <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0xdc>
1006c6610:     	mov	x22, x1
1006c6614:     	lsr	w8, w19, #19
1006c6618:     	cbz	w8, 0x1006c66cc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0xfc>
1006c661c:     	mov	w23, w19
1006c6620:     	add	x0, x23, #0x14
1006c6624:     	mov	w1, #0x3                ; =3
1006c6628:     	bl	0x1004583c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
1006c662c:     	mov	x21, x0
1006c6630:     	stp	w22, w19, [x0]
1006c6634:     	str	w19, [x0, #0x8]
1006c6638:     	mov	x8, #0x200000000        ; =8589934592
1006c663c:     	stur	x8, [x0, #0xc]
1006c6640:     	add	x0, x0, #0x14
1006c6644:     	mov	x1, x20
1006c6648:     	mov	x2, x19
1006c664c:     	bl	0x100b622ec <_writev+0x100b622ec>
1006c6650:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
1006c6654:     	ldr	w19, [x8, #0x590]
1006c6658:     	cmp	w19, #0x300
1006c665c:     	b.hs	0x1006c67b0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0x1e0>
1006c6660:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1006c6664:     	ldr	x8, [x8, #0x48]
1006c6668:     	cmn	x8, #0x1
1006c666c:     	b.eq	0x1006c67a0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0x1d0>
1006c6670:     	mrs	x9, TPIDRRO_EL0
1006c6674:     	and	x9, x9, #0xfffffffffffffff8
1006c6678:     	ldr	x0, [x9, x8, lsl #3]
1006c667c:     	cbz	x0, 0x1006c67a0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0x1d0>
1006c6680:     	add	x8, x0, x19, lsl #3
1006c6684:     	ldr	x0, [x8, #0x1e8]
1006c6688:     	cbz	x0, 0x1006c67b0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0x1e0>
1006c668c:     	ldr	x8, [x0]
1006c6690:     	adds	x8, x8, x23
1006c6694:     	csinv	x8, x8, xzr, lo
1006c6698:     	str	x8, [x0]
1006c669c:     	lsr	x8, x8, #25
1006c66a0:     	cbz	x8, 0x1006c6740 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0x170>
1006c66a4:     	bl	0x10045f2f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
1006c66a8:     	b	0x1006c6740 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0x170>
1006c66ac:     	mov	x0, x21
1006c66b0:     	mov	x1, x20
1006c66b4:     	mov	x2, x19
1006c66b8:     	ldp	x29, x30, [sp, #0x30]
1006c66bc:     	ldp	x20, x19, [sp, #0x20]
1006c66c0:     	ldp	x22, x21, [sp, #0x10]
1006c66c4:     	ldp	x24, x23, [sp], #0x40
1006c66c8:     	b	0x1005eaf44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>
1006c66cc:     	ldr	x8, [x21]
1006c66d0:     	cbz	x8, 0x1006c6714 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0x144>
1006c66d4:     	add	x8, x19, #0x23
1006c66d8:     	and	x8, x8, #0x7ffffffffffffff8
1006c66dc:     	and	x8, x8, #0xffffffff000fffff
1006c66e0:     	cmp	x8, #0x4, lsl #12       ; =0x4000
1006c66e4:     	b.hi	0x1006c6714 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0x144>
1006c66e8:     	ldr	x9, [x21, #0x10]
1006c66ec:     	ldrb	w9, [x9]
1006c66f0:     	tbnz	w9, #0x0, 0x1006c6714 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0x144>
1006c66f4:     	ldr	x10, [x21, #0x8]
1006c66f8:     	ldp	x9, x12, [x10, #0x8]
1006c66fc:     	add	x9, x9, #0x7
1006c6700:     	and	x11, x9, #0xfffffffffffffff8
1006c6704:     	subs	x9, x12, x11
1006c6708:     	csel	x9, xzr, x9, lo
1006c670c:     	cmp	x8, x9
1006c6710:     	b.ls	0x1006c6758 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0x188>
1006c6714:     	mov	x0, x19
1006c6718:     	bl	0x10034b1ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
1006c671c:     	mov	x21, x0
1006c6720:     	mov	x0, x1
1006c6724:     	stp	w22, w19, [x21]
1006c6728:     	str	w19, [x21, #0x8]
1006c672c:     	mov	x8, #0x200000000        ; =8589934592
1006c6730:     	stur	x8, [x21, #0xc]
1006c6734:     	mov	x1, x20
1006c6738:     	mov	x2, x19
1006c673c:     	bl	0x100b622ec <_writev+0x100b622ec>
1006c6740:     	mov	x0, x21
1006c6744:     	ldp	x29, x30, [sp, #0x30]
1006c6748:     	ldp	x20, x19, [sp, #0x20]
1006c674c:     	ldp	x22, x21, [sp, #0x10]
1006c6750:     	ldp	x24, x23, [sp], #0x40
1006c6754:     	ret
1006c6758:     	add	x9, x19, #0x14
1006c675c:     	ldr	x12, [x10]
1006c6760:     	add	x23, x12, x11
1006c6764:     	add	x11, x11, x8
1006c6768:     	str	x11, [x10, #0x8]
1006c676c:     	mov	w10, #0x203             ; =515
1006c6770:     	stp	w10, w8, [x23]
1006c6774:     	add	x21, x23, #0x8
1006c6778:     	subs	x8, x8, #0x8
1006c677c:     	csel	x8, xzr, x8, lo
1006c6780:     	subs	x10, x8, x9
1006c6784:     	csel	x1, xzr, x10, lo
1006c6788:     	b.ls	0x1006c67e0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0x210>
1006c678c:     	cmp	x1, #0x9
1006c6790:     	b.hs	0x1006c67d8 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0x208>
1006c6794:     	add	x8, x21, x8
1006c6798:     	stur	xzr, [x8, #-0x8]
1006c679c:     	b	0x1006c67e0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0x210>
1006c67a0:     	bl	0x100b3f87c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1006c67a4:     	add	x8, x0, x19, lsl #3
1006c67a8:     	ldr	x0, [x8, #0x1e8]
1006c67ac:     	cbnz	x0, 0x1006c668c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0xbc>
1006c67b0:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1006c67b4:     	add	x0, x0, #0x78
1006c67b8:     	bl	0x100b3d09c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1006c67bc:     	ldr	x8, [x0]
1006c67c0:     	adds	x8, x8, x23
1006c67c4:     	csinv	x8, x8, xzr, lo
1006c67c8:     	str	x8, [x0]
1006c67cc:     	lsr	x8, x8, #25
1006c67d0:     	cbnz	x8, 0x1006c66a4 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0xd4>
1006c67d4:     	b	0x1006c6740 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0x170>
1006c67d8:     	add	x0, x21, x9
1006c67dc:     	bl	0x100b61e24 <_writev+0x100b61e24>
1006c67e0:     	stp	w22, w19, [x23, #0x8]
1006c67e4:     	str	w19, [x23, #0x10]
1006c67e8:     	mov	x8, #0x200000000        ; =8589934592
1006c67ec:     	stur	x8, [x23, #0x14]
1006c67f0:     	add	x0, x23, #0x1c
1006c67f4:     	b	0x1006c6734 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token+0x164>
