
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/outlined-source-token-r28/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100844b54 <_js_json_parse>:
100844b54:     	stp	x29, x30, [sp, #-0x10]!
100844b58:     	mov	x29, sp
100844b5c:     	cbz	x0, 0x100844bb4 <_js_json_parse+0x60>
100844b60:     	ldr	w1, [x0, #0x4]
100844b64:     	cmp	w1, #0x2
100844b68:     	b.eq	0x100844b78 <_js_json_parse+0x24>
100844b6c:     	cbz	w1, 0x100844bb4 <_js_json_parse+0x60>
100844b70:     	ldrb	w8, [x0, #0x14]
100844b74:     	b	0x100844b98 <_js_json_parse+0x44>
100844b78:     	ldrb	w8, [x0, #0x14]
100844b7c:     	cmp	w8, #0x7b
100844b80:     	b.ne	0x100844b98 <_js_json_parse+0x44>
100844b84:     	ldrb	w8, [x0, #0x15]
100844b88:     	cmp	w8, #0x7d
100844b8c:     	b.ne	0x100844ba4 <_js_json_parse+0x50>
100844b90:     	ldp	x29, x30, [sp], #0x10
100844b94:     	b	0x1004ec940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100844b98:     	orr	w8, w8, #0x20
100844b9c:     	cmp	w8, #0x7b
100844ba0:     	b.ne	0x100844bac <_js_json_parse+0x58>
100844ba4:     	ldp	x29, x30, [sp], #0x10
100844ba8:     	b	0x100505db8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
100844bac:     	ldp	x29, x30, [sp], #0x10
100844bb0:     	b	0x100508434 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
100844bb4:     	adrp	x0, 0x100c75000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x6a5c>
100844bb8:     	add	x0, x0, #0xa81
100844bbc:     	mov	w1, #0x1c               ; =28
100844bc0:     	bl	0x100508868 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
