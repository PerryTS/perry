
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/outlined-source-token-r28/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100245dc8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value>:
100245dc8:     	sub	sp, sp, #0x60
100245dcc:     	stp	x24, x23, [sp, #0x20]
100245dd0:     	stp	x22, x21, [sp, #0x30]
100245dd4:     	stp	x20, x19, [sp, #0x40]
100245dd8:     	stp	x29, x30, [sp, #0x50]
100245ddc:     	add	x29, sp, #0x50
100245de0:     	mov	x22, x0
100245de4:     	ldr	x21, [x0, #0x70]
100245de8:     	ldp	x8, x9, [x0]
100245dec:     	cmp	x8, #0x0
100245df0:     	ccmp	x9, x21, #0x0, ne
100245df4:     	b.eq	0x100245e20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x58>
100245df8:     	add	x0, sp, #0x8
100245dfc:     	mov	x1, x22
100245e00:     	bl	0x100245978 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes>
100245e04:     	ldr	x23, [sp, #0x8]
100245e08:     	cmn	x23, #0x2
100245e0c:     	b.ne	0x100245e48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x80>
100245e10:     	strb	wzr, [x22, #0xd4]
100245e14:     	mov	x0, #0x2                ; =2
100245e18:     	movk	x0, #0x7ffc, lsl #48
100245e1c:     	b	0x100245e30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100245e20:     	ldp	x8, x9, [x22, #0x10]
100245e24:     	str	x8, [x22, #0x70]
100245e28:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100245e2c:     	bfxil	x0, x9, #0, #48
100245e30:     	ldp	x29, x30, [sp, #0x50]
100245e34:     	ldp	x20, x19, [sp, #0x40]
100245e38:     	ldp	x22, x21, [sp, #0x30]
100245e3c:     	ldp	x24, x23, [sp, #0x20]
100245e40:     	add	sp, sp, #0x60
100245e44:     	ret
100245e48:     	ldp	x20, x19, [sp, #0x10]
100245e4c:     	cmp	x19, #0x6
100245e50:     	b.hs	0x100245ee0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x118>
100245e54:     	subs	x8, x19, #0x3
100245e58:     	b.lo	0x100245f0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100245e5c:     	ldrb	w9, [x20]
100245e60:     	cmp	w9, #0xed
100245e64:     	b.ne	0x100245e84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xbc>
100245e68:     	ldrb	w9, [x20, #0x1]
100245e6c:     	and	w9, w9, #0xe0
100245e70:     	cmp	w9, #0xa0
100245e74:     	b.ne	0x100245e84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xbc>
100245e78:     	ldrsb	w9, [x20, #0x2]
100245e7c:     	cmn	w9, #0x40
100245e80:     	b.lt	0x100245ee0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x118>
100245e84:     	cbz	x8, 0x100245f0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100245e88:     	ldrb	w9, [x20, #0x1]
100245e8c:     	cmp	w9, #0xed
100245e90:     	b.ne	0x100245eb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xe8>
100245e94:     	ldrb	w9, [x20, #0x2]
100245e98:     	and	w9, w9, #0xe0
100245e9c:     	cmp	w9, #0xa0
100245ea0:     	b.ne	0x100245eb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xe8>
100245ea4:     	ldrsb	w9, [x20, #0x3]
100245ea8:     	cmn	w9, #0x40
100245eac:     	b.lt	0x100245ee0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x118>
100245eb0:     	cmp	x8, #0x1
100245eb4:     	b.eq	0x100245f0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100245eb8:     	ldrb	w8, [x20, #0x2]
100245ebc:     	cmp	w8, #0xed
100245ec0:     	b.ne	0x100245f0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100245ec4:     	ldrb	w8, [x20, #0x3]
100245ec8:     	and	w8, w8, #0xe0
100245ecc:     	cmp	w8, #0xa0
100245ed0:     	b.ne	0x100245f0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100245ed4:     	ldrsb	w8, [x20, #0x4]
100245ed8:     	cmn	w8, #0x40
100245edc:     	b.ge	0x100245f0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100245ee0:     	cmn	x23, #0x1
100245ee4:     	b.eq	0x100245f28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x160>
100245ee8:     	mov	x0, x20
100245eec:     	mov	x1, x19
100245ef0:     	bl	0x10034b830 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
100245ef4:     	mov	x8, x0
100245ef8:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100245efc:     	bfxil	x0, x8, #0, #48
100245f00:     	cmp	x23, #0x1
100245f04:     	b.ge	0x100246034 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x26c>
100245f08:     	b	0x100245e30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100245f0c:     	cbz	x19, 0x100245f68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x1a0>
100245f10:     	cmp	x19, #0x4
100245f14:     	b.hs	0x100245f70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x1a8>
100245f18:     	mov	x10, #0x0               ; =0
100245f1c:     	mov	x9, #0x0                ; =0
100245f20:     	mov	x8, x20
100245f24:     	b	0x100246000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x238>
100245f28:     	ldr	x23, [x22, #0x68]
100245f2c:     	sub	x8, x23, x19
100245f30:     	cmp	x8, #0x101
100245f34:     	mov	w8, #0xff               ; =255
100245f38:     	ccmp	x19, x8, #0x0, lo
100245f3c:     	b.ls	0x100246048 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x280>
100245f40:     	ldr	x1, [x22, #0x60]
100245f44:     	ldr	x24, [x22, #0xc8]
100245f48:     	add	x0, x22, #0x20
100245f4c:     	mov	x2, x23
100245f50:     	mov	x3, x24
100245f54:     	mov	x4, x21
100245f58:     	mov	x5, x20
100245f5c:     	mov	x6, x19
100245f60:     	bl	0x1006c65d0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token>
100245f64:     	b	0x10024605c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x294>
100245f68:     	mov	x10, #0x0               ; =0
100245f6c:     	b	0x100246020 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x258>
100245f70:     	and	x9, x19, #0x4
100245f74:     	add	x8, x20, x9
100245f78:     	adrp	x10, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x49b0>
100245f7c:     	ldr	q0, [x10, #0xec0]
100245f80:     	adrp	x10, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x331ba>
100245f84:     	ldr	q2, [x10, #0xdc0]
100245f88:     	movi.2d	v1, #0000000000000000
100245f8c:     	movi.2d	v3, #0x000000000000ff
100245f90:     	mov	w10, #0x4               ; =4
100245f94:     	dup.2d	v4, x10
100245f98:     	mov	x10, x20
100245f9c:     	and	x11, x19, #0x4
100245fa0:     	movi.2d	v5, #0000000000000000
100245fa4:     	ldr	s6, [x10], #0x4
100245fa8:     	ushll.8h	v6, v6, #0x0
100245fac:     	ushll.4s	v6, v6, #0x0
100245fb0:     	ushll2.2d	v7, v6, #0x0
100245fb4:     	and.16b	v7, v7, v3
100245fb8:     	ushll.2d	v6, v6, #0x0
100245fbc:     	and.16b	v6, v6, v3
100245fc0:     	shl.2d	v16, v0, #0x3
100245fc4:     	shl.2d	v17, v2, #0x3
100245fc8:     	ushl.2d	v6, v6, v17
100245fcc:     	ushl.2d	v7, v7, v16
100245fd0:     	orr.16b	v1, v7, v1
100245fd4:     	orr.16b	v5, v6, v5
100245fd8:     	add.2d	v0, v0, v4
100245fdc:     	add.2d	v2, v2, v4
100245fe0:     	subs	x11, x11, #0x4
100245fe4:     	b.ne	0x100245fa4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x1dc>
100245fe8:     	orr.16b	v0, v5, v1
100245fec:     	mov	d1, v0[1]
100245ff0:     	orr.8b	v0, v0, v1
100245ff4:     	fmov	x10, d0
100245ff8:     	cmp	x19, x9
100245ffc:     	b.eq	0x100246020 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x258>
100246000:     	add	x11, x20, x19
100246004:     	lsl	x9, x9, #3
100246008:     	ldrb	w12, [x8], #0x1
10024600c:     	lsl	x12, x12, x9
100246010:     	orr	x10, x12, x10
100246014:     	add	x9, x9, #0x8
100246018:     	cmp	x8, x11
10024601c:     	b.ne	0x100246008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x240>
100246020:     	orr	x8, x10, x19, lsl #40
100246024:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100246028:     	orr	x0, x8, x9
10024602c:     	cmp	x23, #0x1
100246030:     	b.lt	0x100245e30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100246034:     	mov	x19, x0
100246038:     	mov	x0, x20
10024603c:     	bl	0x100b5f440 <_mi_free>
100246040:     	mov	x0, x19
100246044:     	b	0x100245e30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100246048:     	add	x0, x22, #0x20
10024604c:     	mov	x1, x20
100246050:     	mov	x2, x19
100246054:     	bl	0x1005eaf44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>
100246058:     	ldr	x24, [x22, #0xc8]
10024605c:     	cmp	x23, #0x200, lsl #12    ; =0x200000
100246060:     	b.hi	0x100246168 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3a0>
100246064:     	cmp	x19, #0x100
100246068:     	b.lo	0x100246168 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3a0>
10024606c:     	cbz	x0, 0x100246168 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3a0>
100246070:     	cbz	x24, 0x100246168 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3a0>
100246074:     	ldr	x20, [x22, #0x70]
100246078:     	sub	x8, x23, x23, lsr #1
10024607c:     	cmp	x19, x8
100246080:     	orr	x8, x20, x21
100246084:     	and	x8, x8, #0xffffffff00000000
100246088:     	ccmp	x8, #0x0, #0x0, hs
10024608c:     	b.ne	0x100246168 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3a0>
100246090:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
100246094:     	ldr	w19, [x8, #0x560]
100246098:     	cmp	w19, #0x300
10024609c:     	b.hs	0x100246194 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3cc>
1002460a0:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1002460a4:     	ldr	x8, [x8, #0x48]
1002460a8:     	cmn	x8, #0x1
1002460ac:     	b.eq	0x100246178 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3b0>
1002460b0:     	mrs	x9, TPIDRRO_EL0
1002460b4:     	and	x9, x9, #0xfffffffffffffff8
1002460b8:     	ldr	x8, [x9, x8, lsl #3]
1002460bc:     	cbz	x8, 0x100246178 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3b0>
1002460c0:     	add	x8, x8, x19, lsl #3
1002460c4:     	ldr	x19, [x8, #0x1e8]
1002460c8:     	cbz	x19, 0x100246194 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3cc>
1002460cc:     	ldr	x8, [x19]
1002460d0:     	cbnz	x8, 0x1002461b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3f0>
1002460d4:     	mov	x8, #-0x1               ; =-1
1002460d8:     	str	x8, [x19]
1002460dc:     	ldrb	w8, [x19, #0x24]
1002460e0:     	cmp	w8, #0x2
1002460e4:     	b.eq	0x100246108 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x340>
1002460e8:     	ldr	x8, [x19, #0x8]
1002460ec:     	cmp	x8, x24
1002460f0:     	b.ne	0x100246108 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x340>
1002460f4:     	ldr	w8, [x19, #0x18]
1002460f8:     	cmp	w8, w23
1002460fc:     	b.ne	0x100246108 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x340>
100246100:     	mov	x8, #0x0                ; =0
100246104:     	b	0x100246164 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x39c>
100246108:     	stp	x24, x0, [x19, #0x8]
10024610c:     	stp	w23, w21, [x19, #0x18]
100246110:     	str	w20, [x19, #0x20]
100246114:     	strb	wzr, [x19, #0x24]
100246118:     	adrp	x20, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10024611c:     	ldr	w8, [x20, #0x864]
100246120:     	cbz	w8, 0x10024613c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x374>
100246124:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100246128:     	bfxil	x8, x24, #0, #48
10024612c:     	mov	x21, x0
100246130:     	mov	x0, x8
100246134:     	bl	0x100476770 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
100246138:     	mov	x0, x21
10024613c:     	ldr	w8, [x20, #0x864]
100246140:     	cbz	w8, 0x10024615c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x394>
100246144:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100246148:     	bfxil	x8, x0, #0, #48
10024614c:     	mov	x20, x0
100246150:     	mov	x0, x8
100246154:     	bl	0x100476770 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
100246158:     	mov	x0, x20
10024615c:     	ldr	x8, [x19]
100246160:     	add	x8, x8, #0x1
100246164:     	str	x8, [x19]
100246168:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
10024616c:     	bfxil	x8, x0, #0, #48
100246170:     	mov	x0, x8
100246174:     	b	0x100245e30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100246178:     	mov	x22, x0
10024617c:     	bl	0x100b3f87c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100246180:     	mov	x8, x0
100246184:     	mov	x0, x22
100246188:     	add	x8, x8, x19, lsl #3
10024618c:     	ldr	x19, [x8, #0x1e8]
100246190:     	cbnz	x19, 0x1002460cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x304>
100246194:     	adrp	x8, 0x100f0f000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
100246198:     	add	x8, x8, #0xfa0
10024619c:     	mov	x22, x0
1002461a0:     	mov	x0, x8
1002461a4:     	bl	0x100b3d09c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1002461a8:     	mov	x19, x0
1002461ac:     	mov	x0, x22
1002461b0:     	ldr	x8, [x19]
1002461b4:     	cbz	x8, 0x1002460d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x30c>
1002461b8:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1002461bc:     	add	x0, x0, #0xce0
1002461c0:     	bl	0x100b12bac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
		...
