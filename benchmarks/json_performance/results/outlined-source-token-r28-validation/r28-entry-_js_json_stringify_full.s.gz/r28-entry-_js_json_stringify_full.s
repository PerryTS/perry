
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/outlined-source-token-r28/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100845fc0 <_js_json_stringify_full>:
100845fc0:     	sub	sp, sp, #0x120
100845fc4:     	stp	d9, d8, [sp, #0xb0]
100845fc8:     	stp	x28, x27, [sp, #0xc0]
100845fcc:     	stp	x26, x25, [sp, #0xd0]
100845fd0:     	stp	x24, x23, [sp, #0xe0]
100845fd4:     	stp	x22, x21, [sp, #0xf0]
100845fd8:     	stp	x20, x19, [sp, #0x100]
100845fdc:     	stp	x29, x30, [sp, #0x110]
100845fe0:     	add	x29, sp, #0x110
100845fe4:     	mov.16b	v9, v2
100845fe8:     	mov.16b	v8, v0
100845fec:     	fmov	x19, d8
100845ff0:     	fmov	x21, d1
100845ff4:     	fmov	x23, d9
100845ff8:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100845ffc:     	add	x27, x21, x8
100846000:     	add	x24, x23, x8
100846004:     	fcmp	d2, #0.0
100846008:     	ccmp	x24, #0x2, #0x0, ne
10084600c:     	b.hi	0x10084601c <_js_json_stringify_full+0x5c>
100846010:     	cmp	x27, #0x2
100846014:     	b.lo	0x10084602c <_js_json_stringify_full+0x6c>
100846018:     	b	0x100846598 <_js_json_stringify_full+0x5d8>
10084601c:     	mov	x8, #0x7ffe000000000000 ; =9222809086901354496
100846020:     	cmp	x23, x8
100846024:     	ccmp	x27, #0x2, #0x2, eq
100846028:     	b.hs	0x100846598 <_js_json_stringify_full+0x5d8>
10084602c:     	mov	x8, #-0x2               ; =-2
100846030:     	movk	x8, #0x8003, lsl #48
100846034:     	add	x8, x19, x8
100846038:     	cmp	x8, #0x3
10084603c:     	b.hs	0x100846050 <_js_json_stringify_full+0x90>
100846040:     	adrp	x9, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x49b0>
100846044:     	add	x9, x9, #0xbd8
100846048:     	ldr	x20, [x9, x8, lsl #3]
10084604c:     	b	0x100847468 <_js_json_stringify_full+0x14a8>
100846050:     	strb	wzr, [sp, #0x4c]
100846054:     	str	wzr, [sp, #0x48]
100846058:     	and	x8, x19, #0xffff000000000000
10084605c:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100846060:     	cmp	x8, x9
100846064:     	b.eq	0x1008460d8 <_js_json_stringify_full+0x118>
100846068:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084606c:     	cmp	x8, x9
100846070:     	b.ne	0x1008464d4 <_js_json_stringify_full+0x514>
100846074:     	ubfx	x10, x19, #40, #8
100846078:     	cbz	x10, 0x1008460c8 <_js_json_stringify_full+0x108>
10084607c:     	strb	w19, [sp, #0x48]
100846080:     	cmp	x10, #0x1
100846084:     	b.eq	0x1008460c8 <_js_json_stringify_full+0x108>
100846088:     	lsr	x9, x19, #8
10084608c:     	strb	w9, [sp, #0x49]
100846090:     	cmp	x10, #0x2
100846094:     	b.eq	0x1008460c8 <_js_json_stringify_full+0x108>
100846098:     	lsr	x9, x19, #16
10084609c:     	strb	w9, [sp, #0x4a]
1008460a0:     	cmp	x10, #0x3
1008460a4:     	b.eq	0x1008460c8 <_js_json_stringify_full+0x108>
1008460a8:     	lsr	x9, x19, #24
1008460ac:     	strb	w9, [sp, #0x4b]
1008460b0:     	cmp	x10, #0x4
1008460b4:     	b.eq	0x1008460c8 <_js_json_stringify_full+0x108>
1008460b8:     	lsr	x9, x19, #32
1008460bc:     	strb	w9, [sp, #0x4c]
1008460c0:     	cmp	x10, #0x5
1008460c4:     	b.ne	0x100847c3c <_js_json_stringify_full+0x1c7c>
1008460c8:     	add	x11, sp, #0x48
1008460cc:     	cmp	w10, #0x3
1008460d0:     	b.ls	0x1008460f0 <_js_json_stringify_full+0x130>
1008460d4:     	b	0x1008464d4 <_js_json_stringify_full+0x514>
1008460d8:     	ands	x9, x19, #0xffffffffffff
1008460dc:     	b.eq	0x100846598 <_js_json_stringify_full+0x5d8>
1008460e0:     	add	x11, x9, #0x14
1008460e4:     	ldr	w10, [x9, #0x4]
1008460e8:     	cmp	w10, #0x3
1008460ec:     	b.hi	0x1008464d4 <_js_json_stringify_full+0x514>
1008460f0:     	stur	wzr, [sp, #0x81]
1008460f4:     	mov	w9, #0x22               ; =34
1008460f8:     	strb	w9, [sp, #0x80]
1008460fc:     	cbz	w10, 0x100846134 <_js_json_stringify_full+0x174>
100846100:     	add	x12, sp, #0x80
100846104:     	ldrb	w13, [x11]
100846108:     	sxtb	w15, w13
10084610c:     	cmp	w13, #0xb
100846110:     	b.le	0x10084613c <_js_json_stringify_full+0x17c>
100846114:     	cmp	w13, #0x21
100846118:     	b.gt	0x10084615c <_js_json_stringify_full+0x19c>
10084611c:     	cmp	w13, #0xc
100846120:     	b.eq	0x100846190 <_js_json_stringify_full+0x1d0>
100846124:     	cmp	w13, #0xd
100846128:     	b.ne	0x10084616c <_js_json_stringify_full+0x1ac>
10084612c:     	mov	w15, #0x72              ; =114
100846130:     	b	0x10084619c <_js_json_stringify_full+0x1dc>
100846134:     	mov	w12, #0x1               ; =1
100846138:     	b	0x1008461c4 <_js_json_stringify_full+0x204>
10084613c:     	cmp	w13, #0x8
100846140:     	b.eq	0x100846188 <_js_json_stringify_full+0x1c8>
100846144:     	cmp	w13, #0x9
100846148:     	b.eq	0x100846198 <_js_json_stringify_full+0x1d8>
10084614c:     	cmp	w13, #0xa
100846150:     	b.ne	0x10084616c <_js_json_stringify_full+0x1ac>
100846154:     	mov	w15, #0x6e              ; =110
100846158:     	b	0x10084619c <_js_json_stringify_full+0x1dc>
10084615c:     	cmp	w13, #0x22
100846160:     	b.eq	0x10084619c <_js_json_stringify_full+0x1dc>
100846164:     	cmp	w13, #0x5c
100846168:     	b.eq	0x10084619c <_js_json_stringify_full+0x1dc>
10084616c:     	cmp	w15, #0x20
100846170:     	b.lt	0x1008464d4 <_js_json_stringify_full+0x514>
100846174:     	mov	w14, #0x0               ; =0
100846178:     	add	x13, x12, #0x2
10084617c:     	mov	w12, #0x2               ; =2
100846180:     	mov	w16, #0x1               ; =1
100846184:     	b	0x1008461b4 <_js_json_stringify_full+0x1f4>
100846188:     	mov	w15, #0x62              ; =98
10084618c:     	b	0x10084619c <_js_json_stringify_full+0x1dc>
100846190:     	mov	w15, #0x66              ; =102
100846194:     	b	0x10084619c <_js_json_stringify_full+0x1dc>
100846198:     	mov	w15, #0x74              ; =116
10084619c:     	add	x13, x12, #0x3
1008461a0:     	mov	w12, #0x5c              ; =92
1008461a4:     	strb	w12, [sp, #0x81]
1008461a8:     	mov	w14, #0x1               ; =1
1008461ac:     	mov	w12, #0x3               ; =3
1008461b0:     	mov	w16, #0x2               ; =2
1008461b4:     	add	x17, sp, #0x80
1008461b8:     	strb	w15, [x17, x16]
1008461bc:     	cmp	w10, #0x1
1008461c0:     	b.ne	0x1008461fc <_js_json_stringify_full+0x23c>
1008461c4:     	add	x10, sp, #0x80
1008461c8:     	strb	w9, [x10, x12]
1008461cc:     	add	x8, x12, #0x1
1008461d0:     	cmp	x12, #0x3
1008461d4:     	b.hs	0x1008461e8 <_js_json_stringify_full+0x228>
1008461d8:     	mov	x13, #0x0               ; =0
1008461dc:     	mov	x11, #0x0               ; =0
1008461e0:     	add	x9, sp, #0x80
1008461e4:     	b	0x100846444 <_js_json_stringify_full+0x484>
1008461e8:     	cmp	x12, #0xf
1008461ec:     	b.hs	0x10084622c <_js_json_stringify_full+0x26c>
1008461f0:     	mov	x11, #0x0               ; =0
1008461f4:     	mov	x13, #0x0               ; =0
1008461f8:     	b	0x1008463a0 <_js_json_stringify_full+0x3e0>
1008461fc:     	ldrb	w16, [x11, #0x1]
100846200:     	sxtb	w15, w16
100846204:     	cmp	w16, #0xb
100846208:     	b.le	0x100846474 <_js_json_stringify_full+0x4b4>
10084620c:     	cmp	w16, #0x21
100846210:     	b.gt	0x100846494 <_js_json_stringify_full+0x4d4>
100846214:     	cmp	w16, #0xc
100846218:     	b.eq	0x1008464c4 <_js_json_stringify_full+0x504>
10084621c:     	cmp	w16, #0xd
100846220:     	b.ne	0x1008464a4 <_js_json_stringify_full+0x4e4>
100846224:     	mov	w15, #0x72              ; =114
100846228:     	b	0x1008464d0 <_js_json_stringify_full+0x510>
10084622c:     	and	x12, x8, #0xc
100846230:     	and	x11, x8, #0x10
100846234:     	add	x13, sp, #0x80
100846238:     	add	x9, x13, x11
10084623c:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x59b0>
100846240:     	ldr	q0, [x14, #0xd50]
100846244:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x59b0>
100846248:     	ldr	q1, [x14, #0xd60]
10084624c:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x59b0>
100846250:     	ldr	q2, [x14, #0xd70]
100846254:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x59b0>
100846258:     	ldr	q3, [x14, #0xd80]
10084625c:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x59b0>
100846260:     	ldr	q4, [x14, #0xd90]
100846264:     	movi.2d	v5, #0000000000000000
100846268:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x59b0>
10084626c:     	ldr	q6, [x14, #0xda0]
100846270:     	adrp	x14, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x49b0>
100846274:     	ldr	q7, [x14, #0xec0]
100846278:     	mov	w14, #0x10              ; =16
10084627c:     	movi.2d	v16, #0000000000000000
100846280:     	dup.2d	v17, x14
100846284:     	adrp	x14, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x331ba>
100846288:     	ldr	q19, [x14, #0xdc0]
10084628c:     	and	x14, x8, #0x10
100846290:     	movi.2d	v20, #0000000000000000
100846294:     	movi.2d	v18, #0000000000000000
100846298:     	movi.2d	v23, #0000000000000000
10084629c:     	movi.2d	v21, #0000000000000000
1008462a0:     	movi.2d	v24, #0000000000000000
1008462a4:     	movi.2d	v22, #0000000000000000
1008462a8:     	ldr	q25, [x13], #0x10
1008462ac:     	ushll.8h	v26, v25, #0x0
1008462b0:     	ushll2.4s	v27, v26, #0x0
1008462b4:     	ushll2.2d	v28, v27, #0x0
1008462b8:     	ushll2.8h	v25, v25, #0x0
1008462bc:     	ushll.4s	v29, v25, #0x0
1008462c0:     	ushll2.2d	v30, v29, #0x0
1008462c4:     	ushll.2d	v29, v29, #0x0
1008462c8:     	ushll.2d	v27, v27, #0x0
1008462cc:     	ushll.4s	v26, v26, #0x0
1008462d0:     	ushll2.2d	v31, v26, #0x0
1008462d4:     	ushll2.4s	v25, v25, #0x0
1008462d8:     	ushll.2d	v8, v25, #0x0
1008462dc:     	ushll.2d	v26, v26, #0x0
1008462e0:     	ushll2.2d	v25, v25, #0x0
1008462e4:     	shl.2d	v9, v0, #0x3
1008462e8:     	ushl.2d	v25, v25, v9
1008462ec:     	shl.2d	v9, v19, #0x3
1008462f0:     	ushl.2d	v26, v26, v9
1008462f4:     	shl.2d	v9, v1, #0x3
1008462f8:     	ushl.2d	v8, v8, v9
1008462fc:     	shl.2d	v9, v7, #0x3
100846300:     	ushl.2d	v31, v31, v9
100846304:     	shl.2d	v9, v6, #0x3
100846308:     	ushl.2d	v27, v27, v9
10084630c:     	shl.2d	v9, v3, #0x3
100846310:     	ushl.2d	v29, v29, v9
100846314:     	shl.2d	v9, v2, #0x3
100846318:     	ushl.2d	v30, v30, v9
10084631c:     	shl.2d	v9, v4, #0x3
100846320:     	ushl.2d	v28, v28, v9
100846324:     	orr.16b	v18, v28, v18
100846328:     	orr.16b	v21, v30, v21
10084632c:     	orr.16b	v23, v29, v23
100846330:     	orr.16b	v20, v27, v20
100846334:     	orr.16b	v5, v31, v5
100846338:     	orr.16b	v24, v8, v24
10084633c:     	orr.16b	v16, v26, v16
100846340:     	orr.16b	v22, v25, v22
100846344:     	add.2d	v6, v6, v17
100846348:     	add.2d	v7, v7, v17
10084634c:     	add.2d	v19, v19, v17
100846350:     	add.2d	v4, v4, v17
100846354:     	add.2d	v3, v3, v17
100846358:     	add.2d	v2, v2, v17
10084635c:     	add.2d	v1, v1, v17
100846360:     	add.2d	v0, v0, v17
100846364:     	subs	x14, x14, #0x10
100846368:     	b.ne	0x1008462a8 <_js_json_stringify_full+0x2e8>
10084636c:     	orr.16b	v0, v16, v23
100846370:     	orr.16b	v1, v20, v24
100846374:     	orr.16b	v0, v0, v1
100846378:     	orr.16b	v1, v5, v21
10084637c:     	orr.16b	v2, v18, v22
100846380:     	orr.16b	v1, v1, v2
100846384:     	orr.16b	v0, v0, v1
100846388:     	mov	d1, v0[1]
10084638c:     	orr.8b	v0, v0, v1
100846390:     	fmov	x13, d0
100846394:     	cmp	x8, x11
100846398:     	b.eq	0x100846464 <_js_json_stringify_full+0x4a4>
10084639c:     	cbz	x12, 0x100846444 <_js_json_stringify_full+0x484>
1008463a0:     	mov	x14, x11
1008463a4:     	and	x11, x8, #0x1c
1008463a8:     	add	x15, sp, #0x80
1008463ac:     	add	x9, x15, x11
1008463b0:     	fmov	d0, x13
1008463b4:     	movi.2d	v1, #0000000000000000
1008463b8:     	dup.2d	v3, x14
1008463bc:     	adrp	x12, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x49b0>
1008463c0:     	ldr	q2, [x12, #0xec0]
1008463c4:     	orr.16b	v2, v3, v2
1008463c8:     	adrp	x12, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x331ba>
1008463cc:     	ldr	q4, [x12, #0xdc0]
1008463d0:     	orr.16b	v3, v3, v4
1008463d4:     	sub	x12, x14, x11
1008463d8:     	add	x13, x15, x14
1008463dc:     	movi.2d	v4, #0x000000000000ff
1008463e0:     	mov	w14, #0x4               ; =4
1008463e4:     	dup.2d	v5, x14
1008463e8:     	ldr	s6, [x13], #0x4
1008463ec:     	ushll.8h	v6, v6, #0x0
1008463f0:     	ushll.4s	v6, v6, #0x0
1008463f4:     	ushll2.2d	v7, v6, #0x0
1008463f8:     	and.16b	v7, v7, v4
1008463fc:     	ushll.2d	v6, v6, #0x0
100846400:     	and.16b	v6, v6, v4
100846404:     	shl.2d	v16, v2, #0x3
100846408:     	shl.2d	v17, v3, #0x3
10084640c:     	ushl.2d	v6, v6, v17
100846410:     	ushl.2d	v7, v7, v16
100846414:     	orr.16b	v1, v7, v1
100846418:     	orr.16b	v0, v6, v0
10084641c:     	add.2d	v2, v2, v5
100846420:     	add.2d	v3, v3, v5
100846424:     	adds	x12, x12, #0x4
100846428:     	b.ne	0x1008463e8 <_js_json_stringify_full+0x428>
10084642c:     	orr.16b	v0, v0, v1
100846430:     	mov	d1, v0[1]
100846434:     	orr.8b	v0, v0, v1
100846438:     	fmov	x13, d0
10084643c:     	cmp	x8, x11
100846440:     	b.eq	0x100846464 <_js_json_stringify_full+0x4a4>
100846444:     	add	x10, x10, x8
100846448:     	lsl	x11, x11, #3
10084644c:     	ldrb	w12, [x9], #0x1
100846450:     	lsl	x12, x12, x11
100846454:     	orr	x13, x12, x13
100846458:     	add	x11, x11, #0x8
10084645c:     	cmp	x9, x10
100846460:     	b.ne	0x10084644c <_js_json_stringify_full+0x48c>
100846464:     	orr	x8, x13, x8, lsl #40
100846468:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084646c:     	orr	x20, x8, x9
100846470:     	b	0x100847468 <_js_json_stringify_full+0x14a8>
100846474:     	cmp	w16, #0x8
100846478:     	b.eq	0x1008464bc <_js_json_stringify_full+0x4fc>
10084647c:     	cmp	w16, #0x9
100846480:     	b.eq	0x1008464cc <_js_json_stringify_full+0x50c>
100846484:     	cmp	w16, #0xa
100846488:     	b.ne	0x1008464a4 <_js_json_stringify_full+0x4e4>
10084648c:     	mov	w15, #0x6e              ; =110
100846490:     	b	0x1008464d0 <_js_json_stringify_full+0x510>
100846494:     	cmp	w16, #0x22
100846498:     	b.eq	0x1008464d0 <_js_json_stringify_full+0x510>
10084649c:     	cmp	w16, #0x5c
1008464a0:     	b.eq	0x1008464d0 <_js_json_stringify_full+0x510>
1008464a4:     	cmp	w15, #0x20
1008464a8:     	b.lt	0x1008464d4 <_js_json_stringify_full+0x514>
1008464ac:     	add	x13, sp, #0x80
1008464b0:     	strb	w15, [x13, x12]
1008464b4:     	add	x12, x12, #0x1
1008464b8:     	b	0x100846a5c <_js_json_stringify_full+0xa9c>
1008464bc:     	mov	w15, #0x62              ; =98
1008464c0:     	b	0x1008464d0 <_js_json_stringify_full+0x510>
1008464c4:     	mov	w15, #0x66              ; =102
1008464c8:     	b	0x1008464d0 <_js_json_stringify_full+0x510>
1008464cc:     	mov	w15, #0x74              ; =116
1008464d0:     	tbz	w14, #0x0, 0x100846a48 <_js_json_stringify_full+0xa88>
1008464d4:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
1008464d8:     	cmp	x8, x9
1008464dc:     	b.eq	0x100846524 <_js_json_stringify_full+0x564>
1008464e0:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
1008464e4:     	cmp	x8, x9
1008464e8:     	b.ne	0x100846598 <_js_json_stringify_full+0x5d8>
1008464ec:     	and	x8, x19, #0xffffffffffff
1008464f0:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
1008464f4:     	mov	x10, #0x7fffffffffff    ; =140737488355327
1008464f8:     	movk	x10, #0xffef, lsl #16
1008464fc:     	cmp	x9, x10
100846500:     	b.hi	0x100846598 <_js_json_stringify_full+0x5d8>
100846504:     	ldr	w8, [x8, #0x4]
100846508:     	cmp	w8, #0x40
10084650c:     	b.lo	0x100846598 <_js_json_stringify_full+0x5d8>
100846510:     	and	x0, x19, #0xffffffffffff
100846514:     	bl	0x1004f2ce8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100846518:     	cmp	x0, #0x1
10084651c:     	b.ne	0x100846598 <_js_json_stringify_full+0x5d8>
100846520:     	b	0x1008466e4 <_js_json_stringify_full+0x724>
100846524:     	and	x25, x19, #0xffffffffffff
100846528:     	and	x0, x19, #0xffffffffffff
10084652c:     	bl	0x10057aa00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100846530:     	cbz	x0, 0x100846564 <_js_json_stringify_full+0x5a4>
100846534:     	ldrb	w8, [x0]
100846538:     	cmp	w8, #0x2
10084653c:     	b.ne	0x100846564 <_js_json_stringify_full+0x5a4>
100846540:     	ldrsb	w8, [x0, #0x1]
100846544:     	tbnz	w8, #0x1f, 0x100846564 <_js_json_stringify_full+0x5a4>
100846548:     	ldrh	w8, [x0, #0x2]
10084654c:     	tbnz	w8, #0xb, 0x100846564 <_js_json_stringify_full+0x5a4>
100846550:     	ldr	w8, [x0, #0x4]
100846554:     	cmp	w8, #0x18
100846558:     	b.lo	0x100846564 <_js_json_stringify_full+0x5a4>
10084655c:     	ldr	w8, [x25]
100846560:     	cbz	w8, 0x1008475bc <_js_json_stringify_full+0x15fc>
100846564:     	and	x0, x19, #0xffffffffffff
100846568:     	bl	0x10057aa00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084656c:     	cbz	x0, 0x100846598 <_js_json_stringify_full+0x5d8>
100846570:     	ldrb	w8, [x0]
100846574:     	cmp	w8, #0x2
100846578:     	b.ne	0x100846598 <_js_json_stringify_full+0x5d8>
10084657c:     	ldrh	w8, [x0, #0x2]
100846580:     	tbnz	w8, #0xb, 0x100846598 <_js_json_stringify_full+0x5d8>
100846584:     	ldr	w8, [x0, #0x4]
100846588:     	cmp	w8, #0x18
10084658c:     	b.lo	0x100846598 <_js_json_stringify_full+0x5d8>
100846590:     	ldr	w8, [x25]
100846594:     	cbz	w8, 0x100847560 <_js_json_stringify_full+0x15a0>
100846598:     	mov	x20, #0x1               ; =1
10084659c:     	movk	x20, #0x7ffc, lsl #48
1008465a0:     	cmp	x19, x20
1008465a4:     	b.eq	0x100847468 <_js_json_stringify_full+0x14a8>
1008465a8:     	and	x22, x19, #0xffff000000000000
1008465ac:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008465b0:     	cmp	x22, x8
1008465b4:     	b.ne	0x1008465ec <_js_json_stringify_full+0x62c>
1008465b8:     	and	x8, x19, #0xffffffffffff
1008465bc:     	cmp	x8, #0x100, lsl #12     ; =0x100000
1008465c0:     	b.lo	0x1008465d8 <_js_json_stringify_full+0x618>
1008465c4:     	ldr	w8, [x8, #0xc]
1008465c8:     	mov	w9, #0x4f53             ; =20307
1008465cc:     	movk	w9, #0x434c, lsl #16
1008465d0:     	cmp	w8, w9
1008465d4:     	b.eq	0x100847468 <_js_json_stringify_full+0x14a8>
1008465d8:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008465dc:     	cmp	x22, x8
1008465e0:     	b.ne	0x100846618 <_js_json_stringify_full+0x658>
1008465e4:     	and	x0, x19, #0xffffffffffff
1008465e8:     	b	0x100846640 <_js_json_stringify_full+0x680>
1008465ec:     	lsr	x8, x19, #52
1008465f0:     	cbnz	x8, 0x1008466c8 <_js_json_stringify_full+0x708>
1008465f4:     	and	x8, x19, #0x7
1008465f8:     	cbz	x19, 0x100846624 <_js_json_stringify_full+0x664>
1008465fc:     	cbnz	x8, 0x100846624 <_js_json_stringify_full+0x664>
100846600:     	mov	x0, x19
100846604:     	bl	0x10050f178 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846608:     	mov	x8, x19
10084660c:     	tbnz	w0, #0x0, 0x1008465bc <_js_json_stringify_full+0x5fc>
100846610:     	mov	x8, #0x0                ; =0
100846614:     	b	0x100846624 <_js_json_stringify_full+0x664>
100846618:     	lsr	x8, x19, #52
10084661c:     	cbnz	x8, 0x1008466c8 <_js_json_stringify_full+0x708>
100846620:     	and	x8, x19, #0x7
100846624:     	cbz	x19, 0x1008466c8 <_js_json_stringify_full+0x708>
100846628:     	cbnz	x8, 0x1008466c8 <_js_json_stringify_full+0x708>
10084662c:     	mov	x0, x19
100846630:     	bl	0x10050f178 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846634:     	mov	x8, x0
100846638:     	mov	x0, x19
10084663c:     	tbz	w8, #0x0, 0x1008466c8 <_js_json_stringify_full+0x708>
100846640:     	cmp	x0, #0x100, lsl #12     ; =0x100000
100846644:     	b.lo	0x1008466c8 <_js_json_stringify_full+0x708>
100846648:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084664c:     	add	x8, x8, #0xfb0
100846650:     	ldaprb	w8, [x8]
100846654:     	cbz	w8, 0x1008466c8 <_js_json_stringify_full+0x708>
100846658:     	lsr	x8, x0, #3
10084665c:     	mov	x9, #0x7c15             ; =31765
100846660:     	movk	x9, #0x7f4a, lsl #16
100846664:     	movk	x9, #0x79b9, lsl #32
100846668:     	movk	x9, #0x9e37, lsl #48
10084666c:     	mul	x8, x8, x9
100846670:     	lsr	x10, x8, #54
100846674:     	lsr	x11, x8, #60
100846678:     	adrp	x9, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084667c:     	add	x9, x9, #0xf30
100846680:     	add	x11, x9, x11, lsl #3
100846684:     	ldapr	x11, [x11]
100846688:     	lsr	x10, x11, x10
10084668c:     	tbz	w10, #0x0, 0x1008466c8 <_js_json_stringify_full+0x708>
100846690:     	lsr	x10, x8, #44
100846694:     	ubfx	x11, x8, #50, #4
100846698:     	add	x11, x9, x11, lsl #3
10084669c:     	ldapr	x11, [x11]
1008466a0:     	lsr	x10, x11, x10
1008466a4:     	tbz	w10, #0x0, 0x1008466c8 <_js_json_stringify_full+0x708>
1008466a8:     	lsr	x10, x8, #34
1008466ac:     	ubfx	x8, x8, #40, #4
1008466b0:     	add	x8, x9, x8, lsl #3
1008466b4:     	ldapr	x8, [x8]
1008466b8:     	lsr	x8, x8, x10
1008466bc:     	tbz	w8, #0x0, 0x1008466c8 <_js_json_stringify_full+0x708>
1008466c0:     	bl	0x10034ca6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
1008466c4:     	tbnz	w0, #0x0, 0x100847468 <_js_json_stringify_full+0x14a8>
1008466c8:     	cmp	x24, #0x3
1008466cc:     	ccmp	x27, #0x2, #0x2, lo
1008466d0:     	b.hs	0x1008466f0 <_js_json_stringify_full+0x730>
1008466d4:     	mov.16b	v0, v8
1008466d8:     	bl	0x1004eddbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
1008466dc:     	cmp	x0, #0x1
1008466e0:     	b.ne	0x1008466f0 <_js_json_stringify_full+0x730>
1008466e4:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
1008466e8:     	bfxil	x20, x1, #0, #48
1008466ec:     	b	0x100847468 <_js_json_stringify_full+0x14a8>
1008466f0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008466f4:     	cmp	x22, x8
1008466f8:     	b.ne	0x100846748 <_js_json_stringify_full+0x788>
1008466fc:     	ands	x22, x19, #0xffffffffffff
100846700:     	b.eq	0x100846748 <_js_json_stringify_full+0x788>
100846704:     	mov	x0, x22
100846708:     	bl	0x10050f178 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084670c:     	cbz	w0, 0x100846748 <_js_json_stringify_full+0x788>
100846710:     	ldurb	w8, [x22, #-0x8]
100846714:     	cmp	w8, #0x9
100846718:     	b.ne	0x100846748 <_js_json_stringify_full+0x788>
10084671c:     	ldr	w8, [x22, #0x4]
100846720:     	mov	w9, #0x5841             ; =22593
100846724:     	movk	w9, #0x4c5a, lsl #16
100846728:     	cmp	w8, w9
10084672c:     	b.ne	0x100846748 <_js_json_stringify_full+0x788>
100846730:     	mov	x0, x22
100846734:     	bl	0x1006883a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100846738:     	cbz	x0, 0x100846748 <_js_json_stringify_full+0x788>
10084673c:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
100846740:     	bfxil	x19, x0, #0, #48
100846744:     	fmov	d8, x19
100846748:     	mov	w8, #0x7ffd             ; =32765
10084674c:     	cmp	x8, x23, lsr #48
100846750:     	b.ne	0x100846764 <_js_json_stringify_full+0x7a4>
100846754:     	and	x1, x23, #0xffffffffffff
100846758:     	cmp	x1, #0x100, lsl #12     ; =0x100000
10084675c:     	b.hs	0x100846778 <_js_json_stringify_full+0x7b8>
100846760:     	b	0x1008467cc <_js_json_stringify_full+0x80c>
100846764:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
100846768:     	mov	x9, #0xfffffff00000     ; =281474975662080
10084676c:     	mov	x1, x23
100846770:     	cmp	x8, x9
100846774:     	b.hs	0x1008467cc <_js_json_stringify_full+0x80c>
100846778:     	lsr	x8, x1, #47
10084677c:     	cbnz	x8, 0x1008467cc <_js_json_stringify_full+0x80c>
100846780:     	add	x0, sp, #0x80
100846784:     	bl	0x10076e52c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
100846788:     	ldr	w8, [sp, #0x80]
10084678c:     	tbz	w8, #0x0, 0x1008467cc <_js_json_stringify_full+0x80c>
100846790:     	ldr	w8, [sp, #0x88]
100846794:     	mov	w9, #-0xff30            ; =-65328
100846798:     	cmp	w8, w9
10084679c:     	b.eq	0x1008467c0 <_js_json_stringify_full+0x800>
1008467a0:     	mov	w9, #-0xff2f            ; =-65327
1008467a4:     	cmp	w8, w9
1008467a8:     	b.ne	0x1008467cc <_js_json_stringify_full+0x80c>
1008467ac:     	mov.16b	v0, v9
1008467b0:     	bl	0x10084887c <_js_jsvalue_to_string>
1008467b4:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
1008467b8:     	bfxil	x23, x0, #0, #48
1008467bc:     	b	0x1008467cc <_js_json_stringify_full+0x80c>
1008467c0:     	mov.16b	v0, v9
1008467c4:     	bl	0x10086fe20 <_js_number_coerce>
1008467c8:     	fmov	x23, d0
1008467cc:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
1008467d0:     	add	x8, x23, x8
1008467d4:     	cmp	x8, #0x3
1008467d8:     	b.hs	0x1008467f0 <_js_json_stringify_full+0x830>
1008467dc:     	mov	x22, #0x0               ; =0
1008467e0:     	mov	w8, #0x1                ; =1
1008467e4:     	stp	xzr, x8, [sp, #0x10]
1008467e8:     	str	xzr, [sp, #0x20]
1008467ec:     	b	0x100846aa4 <_js_json_stringify_full+0xae4>
1008467f0:     	and	x8, x23, #0xffff000000000000
1008467f4:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1008467f8:     	cmp	x8, x9
1008467fc:     	b.eq	0x100846820 <_js_json_stringify_full+0x860>
100846800:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100846804:     	cmp	x8, x9
100846808:     	b.ne	0x1008468ac <_js_json_stringify_full+0x8ec>
10084680c:     	and	x8, x23, #0xffffffffffff
100846810:     	cmp	x8, #0x1, lsl #12       ; =0x1000
100846814:     	b.hs	0x1008468f4 <_js_json_stringify_full+0x934>
100846818:     	mov	x9, #0x0                ; =0
10084681c:     	b	0x1008468fc <_js_json_stringify_full+0x93c>
100846820:     	strb	wzr, [sp, #0x4c]
100846824:     	str	wzr, [sp, #0x48]
100846828:     	ubfx	x1, x23, #40, #8
10084682c:     	cbz	x1, 0x10084687c <_js_json_stringify_full+0x8bc>
100846830:     	strb	w23, [sp, #0x48]
100846834:     	cmp	x1, #0x1
100846838:     	b.eq	0x10084687c <_js_json_stringify_full+0x8bc>
10084683c:     	lsr	x8, x23, #8
100846840:     	strb	w8, [sp, #0x49]
100846844:     	cmp	x1, #0x2
100846848:     	b.eq	0x10084687c <_js_json_stringify_full+0x8bc>
10084684c:     	lsr	x8, x23, #16
100846850:     	strb	w8, [sp, #0x4a]
100846854:     	cmp	x1, #0x3
100846858:     	b.eq	0x10084687c <_js_json_stringify_full+0x8bc>
10084685c:     	lsr	x8, x23, #24
100846860:     	strb	w8, [sp, #0x4b]
100846864:     	cmp	x1, #0x4
100846868:     	b.eq	0x10084687c <_js_json_stringify_full+0x8bc>
10084686c:     	lsr	x8, x23, #32
100846870:     	strb	w8, [sp, #0x4c]
100846874:     	cmp	x1, #0x5
100846878:     	b.ne	0x100847c3c <_js_json_stringify_full+0x1c7c>
10084687c:     	add	x8, sp, #0x80
100846880:     	add	x0, sp, #0x48
100846884:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100846888:     	ldr	w8, [sp, #0x80]
10084688c:     	ldp	x9, x22, [sp, #0x88]
100846890:     	cmp	w8, #0x0
100846894:     	csinc	x23, x9, xzr, eq
100846898:     	csel	x25, xzr, x22, ne
10084689c:     	tbz	x25, #0x3f, 0x1008469dc <_js_json_stringify_full+0xa1c>
1008468a0:     	mov	x0, #0x0                ; =0
1008468a4:     	mov	x1, x22
1008468a8:     	bl	0x100b12800 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1008468ac:     	add	x8, x20, #0x3
1008468b0:     	cmp	x23, x8
1008468b4:     	b.eq	0x1008467dc <_js_json_stringify_full+0x81c>
1008468b8:     	fmov	d0, x23
1008468bc:     	fcvtzu	x8, d0
1008468c0:     	mov	w9, #0xa                ; =10
1008468c4:     	cmp	x8, #0xa
1008468c8:     	csel	x3, x8, x9, lo
1008468cc:     	adrp	x1, 0x100c43000 <_PERRY_EMPTY_STRING+0x15f4>
1008468d0:     	add	x1, x1, #0xb9c
1008468d4:     	add	x0, sp, #0x80
1008468d8:     	mov	w2, #0x1                ; =1
1008468dc:     	bl	0x1002305f4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
1008468e0:     	ldr	x22, [sp, #0x90]
1008468e4:     	str	x22, [sp, #0x20]
1008468e8:     	ldr	q0, [sp, #0x80]
1008468ec:     	str	q0, [sp, #0x10]
1008468f0:     	b	0x100846aa4 <_js_json_stringify_full+0xae4>
1008468f4:     	ldr	w22, [x8, #0x4]
1008468f8:     	add	x9, x8, #0x14
1008468fc:     	mov	x14, #0x0               ; =0
100846900:     	mov	x8, #0x0                ; =0
100846904:     	cmp	x9, #0x0
100846908:     	csel	x24, xzr, x22, eq
10084690c:     	csinc	x23, x9, xzr, ne
100846910:     	add	x9, x23, x24
100846914:     	mov	w10, #0x1               ; =1
100846918:     	mov	x11, x23
10084691c:     	b	0x10084694c <_js_json_stringify_full+0x98c>
100846920:     	add	x12, x11, #0x2
100846924:     	bfi	w15, w13, #6, #5
100846928:     	mov	x13, x15
10084692c:     	sub	x11, x25, x11
100846930:     	add	x14, x11, x12
100846934:     	cmp	w13, #0x10, lsl #12     ; =0x10000
100846938:     	cinc	x11, x10, hs
10084693c:     	add	x8, x11, x8
100846940:     	mov	x11, x12
100846944:     	cmp	x8, #0xa
100846948:     	b.hi	0x100846a04 <_js_json_stringify_full+0xa44>
10084694c:     	cmp	x11, x9
100846950:     	b.eq	0x1008469b4 <_js_json_stringify_full+0x9f4>
100846954:     	mov	x25, x14
100846958:     	mov	x12, x11
10084695c:     	ldrsb	w14, [x12], #0x1
100846960:     	and	w13, w14, #0xff
100846964:     	tbz	w14, #0x1f, 0x10084692c <_js_json_stringify_full+0x96c>
100846968:     	ldrb	w12, [x11, #0x1]
10084696c:     	and	w15, w12, #0x3f
100846970:     	cmp	w13, #0xe0
100846974:     	b.lo	0x100846920 <_js_json_stringify_full+0x960>
100846978:     	and	w14, w13, #0x1f
10084697c:     	ldrb	w12, [x11, #0x2]
100846980:     	and	w12, w12, #0x3f
100846984:     	orr	w15, w12, w15, lsl #6
100846988:     	cmp	w13, #0xf0
10084698c:     	b.lo	0x1008469a8 <_js_json_stringify_full+0x9e8>
100846990:     	add	x12, x11, #0x4
100846994:     	ldrb	w13, [x11, #0x3]
100846998:     	and	w13, w13, #0x3f
10084699c:     	orr	w13, w13, w15, lsl #6
1008469a0:     	bfi	w13, w14, #18, #3
1008469a4:     	b	0x10084692c <_js_json_stringify_full+0x96c>
1008469a8:     	add	x12, x11, #0x3
1008469ac:     	orr	w13, w15, w14, lsl #12
1008469b0:     	b	0x10084692c <_js_json_stringify_full+0x96c>
1008469b4:     	cbz	x24, 0x100846a38 <_js_json_stringify_full+0xa78>
1008469b8:     	mov	x0, x24
1008469bc:     	mov	w1, #0x1                ; =1
1008469c0:     	bl	0x100b5f6c8 <_mi_malloc_aligned>
1008469c4:     	cbz	x0, 0x100847c24 <_js_json_stringify_full+0x1c64>
1008469c8:     	mov	x26, x0
1008469cc:     	mov	x1, x23
1008469d0:     	mov	x2, x24
1008469d4:     	bl	0x100b622ec <_writev+0x100b622ec>
1008469d8:     	b	0x100846a40 <_js_json_stringify_full+0xa80>
1008469dc:     	cbz	x25, 0x100846a94 <_js_json_stringify_full+0xad4>
1008469e0:     	mov	x0, x25
1008469e4:     	mov	w1, #0x1                ; =1
1008469e8:     	bl	0x100b5f6c8 <_mi_malloc_aligned>
1008469ec:     	cbz	x0, 0x100847c30 <_js_json_stringify_full+0x1c70>
1008469f0:     	mov	x24, x0
1008469f4:     	mov	x1, x23
1008469f8:     	mov	x2, x25
1008469fc:     	bl	0x100b622ec <_writev+0x100b622ec>
100846a00:     	b	0x100846a9c <_js_json_stringify_full+0xadc>
100846a04:     	cbz	x25, 0x100846a38 <_js_json_stringify_full+0xa78>
100846a08:     	cmp	x25, x24
100846a0c:     	b.hs	0x1008474b4 <_js_json_stringify_full+0x14f4>
100846a10:     	ldrsb	w8, [x23, x25]
100846a14:     	cmn	w8, #0x40
100846a18:     	b.ge	0x1008474b8 <_js_json_stringify_full+0x14f8>
100846a1c:     	adrp	x4, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100846a20:     	add	x4, x4, #0x270
100846a24:     	mov	x0, x23
100846a28:     	mov	x1, x24
100846a2c:     	mov	x2, #0x0                ; =0
100846a30:     	mov	x3, x25
100846a34:     	bl	0x100b12b78 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
100846a38:     	mov	x22, #0x0               ; =0
100846a3c:     	mov	w26, #0x1               ; =1
100846a40:     	stp	x22, x26, [sp, #0x10]
100846a44:     	b	0x100846aa0 <_js_json_stringify_full+0xae0>
100846a48:     	add	x14, sp, #0x80
100846a4c:     	mov	w16, #0x5c              ; =92
100846a50:     	strb	w16, [x14, x12]
100846a54:     	add	x12, x12, #0x2
100846a58:     	strb	w15, [x13, #0x1]
100846a5c:     	cmp	w10, #0x2
100846a60:     	b.eq	0x1008461c4 <_js_json_stringify_full+0x204>
100846a64:     	ldrb	w11, [x11, #0x2]
100846a68:     	sxtb	w10, w11
100846a6c:     	cmp	w11, #0xb
100846a70:     	b.le	0x100847540 <_js_json_stringify_full+0x1580>
100846a74:     	cmp	w11, #0x21
100846a78:     	b.gt	0x10084758c <_js_json_stringify_full+0x15cc>
100846a7c:     	cmp	w11, #0xc
100846a80:     	b.eq	0x100847618 <_js_json_stringify_full+0x1658>
100846a84:     	cmp	w11, #0xd
100846a88:     	b.ne	0x10084759c <_js_json_stringify_full+0x15dc>
100846a8c:     	mov	w10, #0x72              ; =114
100846a90:     	b	0x100847624 <_js_json_stringify_full+0x1664>
100846a94:     	mov	x22, #0x0               ; =0
100846a98:     	mov	w24, #0x1               ; =1
100846a9c:     	stp	x22, x24, [sp, #0x10]
100846aa0:     	str	x22, [sp, #0x20]
100846aa4:     	cmp	x27, #0x2
100846aa8:     	b.lo	0x100846be8 <_js_json_stringify_full+0xc28>
100846aac:     	and	x25, x21, #0xffff000000000000
100846ab0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846ab4:     	cmp	x25, x8
100846ab8:     	b.ne	0x100846bc4 <_js_json_stringify_full+0xc04>
100846abc:     	and	x23, x21, #0xffffffffffff
100846ac0:     	cmp	x23, #0x100, lsl #12    ; =0x100000
100846ac4:     	b.lo	0x100846be8 <_js_json_stringify_full+0xc28>
100846ac8:     	mov	x0, x23
100846acc:     	bl	0x10050a680 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
100846ad0:     	tbnz	w0, #0x0, 0x100846be8 <_js_json_stringify_full+0xc28>
100846ad4:     	lsr	x8, x23, #51
100846ad8:     	cmp	x8, #0xfff
100846adc:     	b.lo	0x100846af4 <_js_json_stringify_full+0xb34>
100846ae0:     	mov	w8, #0x7ffc             ; =32764
100846ae4:     	cmp	x8, x23, lsr #48
100846ae8:     	b.eq	0x100846be8 <_js_json_stringify_full+0xc28>
100846aec:     	ands	x23, x23, #0xffffffffffff
100846af0:     	b.eq	0x100846be8 <_js_json_stringify_full+0xc28>
100846af4:     	and	x8, x23, #0xfffffffffff00000
100846af8:     	lsr	x9, x23, #47
100846afc:     	cmp	x9, #0x0
100846b00:     	ccmp	x8, #0x0, #0x4, eq
100846b04:     	b.eq	0x100846be8 <_js_json_stringify_full+0xc28>
100846b08:     	tst	x23, #0x3
100846b0c:     	ccmp	x23, #0x7, #0x0, eq
100846b10:     	b.ls	0x100847854 <_js_json_stringify_full+0x1894>
100846b14:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100846b18:     	ldr	x8, [x8, #0x48]
100846b1c:     	cmn	x8, #0x1
100846b20:     	b.eq	0x1008477a4 <_js_json_stringify_full+0x17e4>
100846b24:     	mrs	x9, TPIDRRO_EL0
100846b28:     	and	x9, x9, #0xfffffffffffffff8
100846b2c:     	ldr	x0, [x9, x8, lsl #3]
100846b30:     	cbz	x0, 0x1008477a4 <_js_json_stringify_full+0x17e4>
100846b34:     	lsr	x1, x23, #20
100846b38:     	ldr	x8, [x0, #0x10]
100846b3c:     	ldrb	w9, [x8]
100846b40:     	cmp	w9, #0x2
100846b44:     	b.ne	0x1008477bc <_js_json_stringify_full+0x17fc>
100846b48:     	ldrb	w9, [x8, #0x88]
100846b4c:     	tbz	w9, #0x0, 0x100846b6c <_js_json_stringify_full+0xbac>
100846b50:     	ldr	x9, [x8, #0x80]
100846b54:     	cmp	x9, x1
100846b58:     	b.ne	0x100846b6c <_js_json_stringify_full+0xbac>
100846b5c:     	ldp	x9, x10, [x8, #0x60]
100846b60:     	cmp	x9, x23
100846b64:     	ccmp	x10, x23, #0x0, ls
100846b68:     	b.hi	0x10084779c <_js_json_stringify_full+0x17dc>
100846b6c:     	ldrb	w9, [x8, #0xb8]
100846b70:     	cbz	w9, 0x100846b90 <_js_json_stringify_full+0xbd0>
100846b74:     	ldr	x9, [x8, #0xb0]
100846b78:     	cmp	x9, x1
100846b7c:     	b.ne	0x100846b90 <_js_json_stringify_full+0xbd0>
100846b80:     	ldp	x9, x10, [x8, #0x90]
100846b84:     	cmp	x9, x23
100846b88:     	ccmp	x10, x23, #0x0, ls
100846b8c:     	b.hi	0x100847a24 <_js_json_stringify_full+0x1a64>
100846b90:     	ldrb	w9, [x8, #0xe8]
100846b94:     	cbz	w9, 0x1008475dc <_js_json_stringify_full+0x161c>
100846b98:     	ldr	x9, [x8, #0xe0]
100846b9c:     	cmp	x9, x1
100846ba0:     	b.ne	0x1008475dc <_js_json_stringify_full+0x161c>
100846ba4:     	ldr	x9, [x8, #0xc0]
100846ba8:     	cmp	x9, x23
100846bac:     	b.hi	0x1008475dc <_js_json_stringify_full+0x161c>
100846bb0:     	ldr	x9, [x8, #0xc8]
100846bb4:     	cmp	x9, x23
100846bb8:     	b.ls	0x1008475dc <_js_json_stringify_full+0x161c>
100846bbc:     	add	x9, x8, #0xc0
100846bc0:     	b	0x100847a28 <_js_json_stringify_full+0x1a68>
100846bc4:     	lsr	x8, x21, #52
100846bc8:     	cbnz	x8, 0x100846be8 <_js_json_stringify_full+0xc28>
100846bcc:     	cbz	x21, 0x100846be8 <_js_json_stringify_full+0xc28>
100846bd0:     	and	x8, x21, #0x7
100846bd4:     	cbnz	x8, 0x100846be8 <_js_json_stringify_full+0xc28>
100846bd8:     	mov	x0, x21
100846bdc:     	bl	0x10050f178 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846be0:     	mov	x23, x21
100846be4:     	cbnz	w0, 0x100846ac0 <_js_json_stringify_full+0xb00>
100846be8:     	mov	x25, #-0x1              ; =-1
100846bec:     	str	x25, [sp, #0x30]
100846bf0:     	mov	w24, #0x1               ; =1
100846bf4:     	cmp	x27, #0x1
100846bf8:     	cset	w8, hi
100846bfc:     	tst	w8, w24
100846c00:     	b.eq	0x100846c74 <_js_json_stringify_full+0xcb4>
100846c04:     	and	x23, x21, #0xffff000000000000
100846c08:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846c0c:     	cmp	x23, x8
100846c10:     	b.ne	0x100846c4c <_js_json_stringify_full+0xc8c>
100846c14:     	and	x8, x21, #0xffffffffffff
100846c18:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100846c1c:     	b.lo	0x100846c74 <_js_json_stringify_full+0xcb4>
100846c20:     	ldr	w8, [x8, #0xc]
100846c24:     	mov	w9, #0x4f53             ; =20307
100846c28:     	movk	w9, #0x434c, lsl #16
100846c2c:     	cmp	w8, w9
100846c30:     	b.ne	0x100846c74 <_js_json_stringify_full+0xcb4>
100846c34:     	and	x8, x21, #0xffffffffffff
100846c38:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100846c3c:     	cmp	x23, x9
100846c40:     	csel	x28, x8, x21, eq
100846c44:     	mov	w27, #0x1               ; =1
100846c48:     	b	0x100846c78 <_js_json_stringify_full+0xcb8>
100846c4c:     	lsr	x8, x21, #52
100846c50:     	cbnz	x8, 0x100846c74 <_js_json_stringify_full+0xcb4>
100846c54:     	mov	w27, #0x0               ; =0
100846c58:     	cbz	x21, 0x100846c78 <_js_json_stringify_full+0xcb8>
100846c5c:     	and	x8, x21, #0x7
100846c60:     	cbnz	x8, 0x100846c78 <_js_json_stringify_full+0xcb8>
100846c64:     	mov	x0, x21
100846c68:     	bl	0x10050f178 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846c6c:     	mov	x8, x21
100846c70:     	tbnz	w0, #0x0, 0x100846c18 <_js_json_stringify_full+0xc58>
100846c74:     	mov	w27, #0x0               ; =0
100846c78:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846c7c:     	add	x0, x0, #0xd78
100846c80:     	ldr	x8, [x0]
100846c84:     	blr	x8
100846c88:     	mov	x21, x0
100846c8c:     	ldr	w26, [x0]
100846c90:     	add	w8, w26, #0x1
100846c94:     	str	w8, [x0]
100846c98:     	cbz	w26, 0x100846d08 <_js_json_stringify_full+0xd48>
100846c9c:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846ca0:     	add	x0, x0, #0xd00
100846ca4:     	ldr	x8, [x0]
100846ca8:     	blr	x8
100846cac:     	ldrb	w8, [x0, #0x20]
100846cb0:     	cmp	w8, #0x1
100846cb4:     	b.ne	0x100847a94 <_js_json_stringify_full+0x1ad4>
100846cb8:     	ldr	x8, [x0]
100846cbc:     	cbnz	x8, 0x100847aa0 <_js_json_stringify_full+0x1ae0>
100846cc0:     	mov	x8, #-0x1               ; =-1
100846cc4:     	str	x8, [x0]
100846cc8:     	ldr	x23, [x0, #0x18]
100846ccc:     	ldr	x8, [x0, #0x8]
100846cd0:     	cmp	x23, x8
100846cd4:     	b.eq	0x100847490 <_js_json_stringify_full+0x14d0>
100846cd8:     	ldr	x8, [x0, #0x10]
100846cdc:     	mov	w9, #0x18               ; =24
100846ce0:     	madd	x8, x23, x9, x8
100846ce4:     	mov	w9, #0x8                ; =8
100846ce8:     	stp	xzr, x9, [x8]
100846cec:     	str	xzr, [x8, #0x10]
100846cf0:     	add	x8, x23, #0x1
100846cf4:     	str	x8, [x0, #0x18]
100846cf8:     	ldr	x8, [x0]
100846cfc:     	add	x8, x8, #0x1
100846d00:     	str	x8, [x0]
100846d04:     	b	0x100846d70 <_js_json_stringify_full+0xdb0>
100846d08:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846d0c:     	add	x0, x0, #0xdc0
100846d10:     	ldr	x8, [x0]
100846d14:     	blr	x8
100846d18:     	strb	wzr, [x0]
100846d1c:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846d20:     	add	x0, x0, #0xdf0
100846d24:     	ldr	x8, [x0]
100846d28:     	blr	x8
100846d2c:     	strb	wzr, [x0]
100846d30:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
100846d34:     	ldr	w23, [x8, #0x5a8]
100846d38:     	cmp	w23, #0x300
100846d3c:     	b.hs	0x1008474d8 <_js_json_stringify_full+0x1518>
100846d40:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100846d44:     	ldr	x8, [x8, #0x48]
100846d48:     	cmn	x8, #0x1
100846d4c:     	b.eq	0x1008474c8 <_js_json_stringify_full+0x1508>
100846d50:     	mrs	x9, TPIDRRO_EL0
100846d54:     	and	x9, x9, #0xfffffffffffffff8
100846d58:     	ldr	x0, [x9, x8, lsl #3]
100846d5c:     	cbz	x0, 0x1008474c8 <_js_json_stringify_full+0x1508>
100846d60:     	add	x8, x0, x23, lsl #3
100846d64:     	ldr	x0, [x8, #0x1e8]
100846d68:     	cbz	x0, 0x1008474d8 <_js_json_stringify_full+0x1518>
100846d6c:     	str	xzr, [x0]
100846d70:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846d74:     	add	x0, x0, #0xd30
100846d78:     	ldr	x8, [x0]
100846d7c:     	blr	x8
100846d80:     	mov	x23, x0
100846d84:     	ldrb	w8, [x0, #0x18]
100846d88:     	cmp	w8, #0x1
100846d8c:     	b.ne	0x100847a48 <_js_json_stringify_full+0x1a88>
100846d90:     	ldr	x8, [x0]
100846d94:     	mov	x9, #-0x1               ; =-1
100846d98:     	str	x9, [x0]
100846d9c:     	cmn	x8, #0x2
100846da0:     	b.eq	0x100847bd0 <_js_json_stringify_full+0x1c10>
100846da4:     	cmn	x8, #0x1
100846da8:     	b.eq	0x100846e7c <_js_json_stringify_full+0xebc>
100846dac:     	add	x9, sp, #0x48
100846db0:     	ldur	q0, [x0, #0x8]
100846db4:     	stur	q0, [x9, #0x8]
100846db8:     	str	x8, [sp, #0x48]
100846dbc:     	tbz	w24, #0x0, 0x100846e90 <_js_json_stringify_full+0xed0>
100846dc0:     	tbz	w27, #0x0, 0x100846f78 <_js_json_stringify_full+0xfb8>
100846dc4:     	bl	0x10028b458 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
100846dc8:     	str	x0, [sp, #0x60]
100846dcc:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846dd0:     	stp	x28, x8, [sp, #0x88]
100846dd4:     	mov	w8, #0x1                ; =1
100846dd8:     	str	x8, [sp, #0x80]
100846ddc:     	add	x0, sp, #0x80
100846de0:     	bl	0x10028b560 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
100846de4:     	mov	x22, x0
100846de8:     	str	x0, [sp, #0x68]
100846dec:     	mov	w0, #0x0                ; =0
100846df0:     	bl	0x10034b1ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100846df4:     	stp	xzr, xzr, [x0]
100846df8:     	str	wzr, [x0, #0x10]
100846dfc:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846e00:     	bfxil	x8, x0, #0, #48
100846e04:     	fmov	d0, x8
100846e08:     	bl	0x10020b124 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
100846e0c:     	mov	x19, x0
100846e10:     	adrp	x24, 0x100f80000 <_perry_global_worker_ts__1>
100846e14:     	ldr	x8, [x24, #0x48]
100846e18:     	cmn	x8, #0x1
100846e1c:     	b.eq	0x100846fdc <_js_json_stringify_full+0x101c>
100846e20:     	mrs	x9, TPIDRRO_EL0
100846e24:     	and	x9, x9, #0xfffffffffffffff8
100846e28:     	ldr	x8, [x9, x8, lsl #3]
100846e2c:     	cbz	x8, 0x100846fdc <_js_json_stringify_full+0x101c>
100846e30:     	ldr	x8, [x8, #0x19e8]
100846e34:     	cbz	x8, 0x100846fdc <_js_json_stringify_full+0x101c>
100846e38:     	ldr	x9, [x8]
100846e3c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846e40:     	cmp	x9, x10
100846e44:     	b.hs	0x100847b1c <_js_json_stringify_full+0x1b5c>
100846e48:     	add	x10, x9, #0x1
100846e4c:     	str	x10, [x8]
100846e50:     	ldr	x10, [x8, #0x18]
100846e54:     	cmp	x19, x10
100846e58:     	b.hs	0x100847b28 <_js_json_stringify_full+0x1b68>
100846e5c:     	ldr	x10, [x8, #0x10]
100846e60:     	mov	w11, #0x18              ; =24
100846e64:     	madd	x10, x19, x11, x10
100846e68:     	ldr	x11, [x10]
100846e6c:     	cbnz	x11, 0x100847b88 <_js_json_stringify_full+0x1bc8>
100846e70:     	ldr	x0, [x10, #0x8]
100846e74:     	str	x9, [x8]
100846e78:     	b	0x100846fe4 <_js_json_stringify_full+0x1024>
100846e7c:     	mov	x8, #0x0                ; =0
100846e80:     	mov	w9, #0x1                ; =1
100846e84:     	stp	x9, xzr, [sp, #0x50]
100846e88:     	str	x8, [sp, #0x48]
100846e8c:     	tbnz	w24, #0x0, 0x100846dc0 <_js_json_stringify_full+0xe00>
100846e90:     	cmp	x22, #0x0
100846e94:     	cset	w6, ne
100846e98:     	ldp	x0, x1, [sp, #0x38]
100846e9c:     	ldp	x3, x4, [sp, #0x18]
100846ea0:     	add	x2, sp, #0x48
100846ea4:     	mov.16b	v0, v8
100846ea8:     	mov	x5, #0x0                ; =0
100846eac:     	bl	0x100502ec0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
100846eb0:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846eb4:     	add	x0, x0, #0xd90
100846eb8:     	ldr	x8, [x0]
100846ebc:     	blr	x8
100846ec0:     	ldrb	w8, [x0, #0x20]
100846ec4:     	cbnz	w8, 0x100847aac <_js_json_stringify_full+0x1aec>
100846ec8:     	ldr	x8, [x0]
100846ecc:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100846ed0:     	cmp	x8, x9
100846ed4:     	b.hs	0x100847adc <_js_json_stringify_full+0x1b1c>
100846ed8:     	ldr	x9, [x0, #0x18]
100846edc:     	cbz	x9, 0x100846ee8 <_js_json_stringify_full+0xf28>
100846ee0:     	cbnz	x8, 0x100847ae8 <_js_json_stringify_full+0x1b28>
100846ee4:     	str	xzr, [x0, #0x18]
100846ee8:     	ldp	x0, x1, [sp, #0x50]
100846eec:     	cmp	x1, #0x5
100846ef0:     	b.hi	0x100846f58 <_js_json_stringify_full+0xf98>
100846ef4:     	cbz	x1, 0x100847168 <_js_json_stringify_full+0x11a8>
100846ef8:     	ldrsb	w8, [x0]
100846efc:     	tbnz	w8, #0x1f, 0x100846f58 <_js_json_stringify_full+0xf98>
100846f00:     	cmp	x1, #0x1
100846f04:     	b.eq	0x100846f40 <_js_json_stringify_full+0xf80>
100846f08:     	ldrsb	w8, [x0, #0x1]
100846f0c:     	tbnz	w8, #0x1f, 0x100846f58 <_js_json_stringify_full+0xf98>
100846f10:     	cmp	x1, #0x2
100846f14:     	b.eq	0x100846f40 <_js_json_stringify_full+0xf80>
100846f18:     	ldrsb	w8, [x0, #0x2]
100846f1c:     	tbnz	w8, #0x1f, 0x100846f58 <_js_json_stringify_full+0xf98>
100846f20:     	cmp	x1, #0x3
100846f24:     	b.eq	0x100846f40 <_js_json_stringify_full+0xf80>
100846f28:     	ldrsb	w8, [x0, #0x3]
100846f2c:     	tbnz	w8, #0x1f, 0x100846f58 <_js_json_stringify_full+0xf98>
100846f30:     	cmp	x1, #0x4
100846f34:     	b.eq	0x100846f40 <_js_json_stringify_full+0xf80>
100846f38:     	ldrsb	w8, [x0, #0x4]
100846f3c:     	tbnz	w8, #0x1f, 0x100846f58 <_js_json_stringify_full+0xf98>
100846f40:     	cmp	x1, #0x4
100846f44:     	b.hs	0x1008472a8 <_js_json_stringify_full+0x12e8>
100846f48:     	mov	x10, #0x0               ; =0
100846f4c:     	mov	x9, #0x0                ; =0
100846f50:     	mov	x8, x0
100846f54:     	b	0x100847338 <_js_json_stringify_full+0x1378>
100846f58:     	bl	0x100329ec8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
100846f5c:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
100846f60:     	bfxil	x20, x0, #0, #48
100846f64:     	ldp	x22, x0, [sp, #0x48]
100846f68:     	ldrb	w8, [x23, #0x18]
100846f6c:     	cmp	w8, #0x1
100846f70:     	b.eq	0x100847374 <_js_json_stringify_full+0x13b4>
100846f74:     	b	0x100847a78 <_js_json_stringify_full+0x1ab8>
100846f78:     	mov	w0, #0x0                ; =0
100846f7c:     	bl	0x10034b1ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100846f80:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846f84:     	bfxil	x8, x0, #0, #48
100846f88:     	fmov	d1, x8
100846f8c:     	stp	xzr, xzr, [x0]
100846f90:     	str	wzr, [x0, #0x10]
100846f94:     	mov.16b	v0, v8
100846f98:     	bl	0x1004ff93c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100846f9c:     	mov.16b	v8, v0
100846fa0:     	fmov	x24, d8
100846fa4:     	cmp	x24, x20
100846fa8:     	b.eq	0x1008471f0 <_js_json_stringify_full+0x1230>
100846fac:     	mov	w8, #0x7ffd             ; =32765
100846fb0:     	cmp	x8, x24, lsr #48
100846fb4:     	b.ne	0x1008471c0 <_js_json_stringify_full+0x1200>
100846fb8:     	and	x8, x24, #0xffffffffffff
100846fbc:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100846fc0:     	b.lo	0x1008471e4 <_js_json_stringify_full+0x1224>
100846fc4:     	ldr	w8, [x8, #0xc]
100846fc8:     	mov	w9, #0x4f53             ; =20307
100846fcc:     	movk	w9, #0x434c, lsl #16
100846fd0:     	cmp	w8, w9
100846fd4:     	b.ne	0x1008471e4 <_js_json_stringify_full+0x1224>
100846fd8:     	b	0x1008471f0 <_js_json_stringify_full+0x1230>
100846fdc:     	mov	x0, x19
100846fe0:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100846fe4:     	fmov	d1, x0
100846fe8:     	mov.16b	v0, v8
100846fec:     	bl	0x1004ff93c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100846ff0:     	mov.16b	v8, v0
100846ff4:     	ldr	x8, [x24, #0x48]
100846ff8:     	cmn	x8, #0x1
100846ffc:     	b.eq	0x100847060 <_js_json_stringify_full+0x10a0>
100847000:     	mrs	x9, TPIDRRO_EL0
100847004:     	and	x9, x9, #0xfffffffffffffff8
100847008:     	ldr	x8, [x9, x8, lsl #3]
10084700c:     	cbz	x8, 0x100847060 <_js_json_stringify_full+0x10a0>
100847010:     	ldr	x8, [x8, #0x19e8]
100847014:     	cbz	x8, 0x100847060 <_js_json_stringify_full+0x10a0>
100847018:     	ldr	x9, [x8]
10084701c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100847020:     	cmp	x9, x10
100847024:     	b.hs	0x100847b1c <_js_json_stringify_full+0x1b5c>
100847028:     	add	x10, x9, #0x1
10084702c:     	str	x10, [x8]
100847030:     	ldr	x10, [x8, #0x18]
100847034:     	cmp	x22, x10
100847038:     	b.hs	0x100847b28 <_js_json_stringify_full+0x1b68>
10084703c:     	ldr	x10, [x8, #0x10]
100847040:     	mov	w11, #0x18              ; =24
100847044:     	madd	x10, x22, x11, x10
100847048:     	ldr	x11, [x10]
10084704c:     	cmp	x11, #0x1
100847050:     	b.ne	0x100847be8 <_js_json_stringify_full+0x1c28>
100847054:     	ldr	x22, [x10, #0x8]
100847058:     	str	x9, [x8]
10084705c:     	b	0x10084706c <_js_json_stringify_full+0x10ac>
100847060:     	mov	x0, x22
100847064:     	bl	0x10013c298 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
100847068:     	mov	x22, x0
10084706c:     	ldr	x8, [x24, #0x48]
100847070:     	cmn	x8, #0x1
100847074:     	b.eq	0x1008470d4 <_js_json_stringify_full+0x1114>
100847078:     	mrs	x9, TPIDRRO_EL0
10084707c:     	and	x9, x9, #0xfffffffffffffff8
100847080:     	ldr	x8, [x9, x8, lsl #3]
100847084:     	cbz	x8, 0x1008470d4 <_js_json_stringify_full+0x1114>
100847088:     	ldr	x8, [x8, #0x19e8]
10084708c:     	cbz	x8, 0x1008470d4 <_js_json_stringify_full+0x1114>
100847090:     	ldr	x9, [x8]
100847094:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100847098:     	cmp	x9, x10
10084709c:     	b.hs	0x100847b1c <_js_json_stringify_full+0x1b5c>
1008470a0:     	add	x10, x9, #0x1
1008470a4:     	str	x10, [x8]
1008470a8:     	ldr	x10, [x8, #0x18]
1008470ac:     	cmp	x19, x10
1008470b0:     	b.hs	0x100847b28 <_js_json_stringify_full+0x1b68>
1008470b4:     	ldr	x10, [x8, #0x10]
1008470b8:     	mov	w11, #0x18              ; =24
1008470bc:     	madd	x10, x19, x11, x10
1008470c0:     	ldr	x11, [x10]
1008470c4:     	cbnz	x11, 0x100847b88 <_js_json_stringify_full+0x1bc8>
1008470c8:     	ldr	x0, [x10, #0x8]
1008470cc:     	str	x9, [x8]
1008470d0:     	b	0x1008470dc <_js_json_stringify_full+0x111c>
1008470d4:     	mov	x0, x19
1008470d8:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
1008470dc:     	fmov	d9, x0
1008470e0:     	mov.16b	v0, v8
1008470e4:     	bl	0x1004ff474 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
1008470e8:     	mov.16b	v2, v0
1008470ec:     	mov	x0, x22
1008470f0:     	mov.16b	v0, v9
1008470f4:     	mov.16b	v1, v8
1008470f8:     	bl	0x1004ff754 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
1008470fc:     	str	d0, [sp, #0x70]
100847100:     	fmov	x19, d0
100847104:     	cmp	x19, x20
100847108:     	b.ne	0x100847170 <_js_json_stringify_full+0x11b0>
10084710c:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100847110:     	add	x0, x0, #0xd90
100847114:     	ldr	x8, [x0]
100847118:     	blr	x8
10084711c:     	ldrb	w8, [x0, #0x20]
100847120:     	cbnz	w8, 0x100847bc8 <_js_json_stringify_full+0x1c08>
100847124:     	ldr	x8, [x0]
100847128:     	cbnz	x8, 0x100847c18 <_js_json_stringify_full+0x1c58>
10084712c:     	str	xzr, [x0, #0x18]
100847130:     	ldp	x22, x19, [sp, #0x48]
100847134:     	ldrb	w8, [x23, #0x18]
100847138:     	cmp	w8, #0x1
10084713c:     	b.ne	0x100847b60 <_js_json_stringify_full+0x1ba0>
100847140:     	ldp	x8, x0, [x23]
100847144:     	stp	x22, x19, [x23]
100847148:     	str	xzr, [x23, #0x10]
10084714c:     	sub	x8, x8, #0x1
100847150:     	cmn	x8, #0x2
100847154:     	b.hs	0x10084715c <_js_json_stringify_full+0x119c>
100847158:     	bl	0x100b5f440 <_mi_free>
10084715c:     	cbz	w26, 0x1008473fc <_js_json_stringify_full+0x143c>
100847160:     	bl	0x100328128 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100847164:     	b	0x100847400 <_js_json_stringify_full+0x1440>
100847168:     	mov	x10, #0x0               ; =0
10084716c:     	b	0x100847358 <_js_json_stringify_full+0x1398>
100847170:     	add	x0, sp, #0x48
100847174:     	bl	0x1005004b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
100847178:     	tbnz	w0, #0x0, 0x1008471b4 <_js_json_stringify_full+0x11f4>
10084717c:     	mov	x0, x19
100847180:     	bl	0x100327e2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
100847184:     	cmp	x0, #0x1
100847188:     	b.ne	0x100847bdc <_js_json_stringify_full+0x1c1c>
10084718c:     	add	x8, sp, #0x78
100847190:     	add	x9, sp, #0x70
100847194:     	stp	x1, x8, [sp, #0x78]
100847198:     	str	x9, [sp, #0x88]
10084719c:     	add	x8, sp, #0x48
1008471a0:     	add	x9, sp, #0x10
1008471a4:     	stp	x8, x9, [sp, #0x90]
1008471a8:     	add	x0, sp, #0x68
1008471ac:     	add	x1, sp, #0x80
1008471b0:     	bl	0x100143d90 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
1008471b4:     	add	x0, sp, #0x60
1008471b8:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
1008471bc:     	b	0x100846eb0 <_js_json_stringify_full+0xef0>
1008471c0:     	lsr	x8, x24, #52
1008471c4:     	cbnz	x8, 0x1008471e4 <_js_json_stringify_full+0x1224>
1008471c8:     	cbz	x24, 0x1008471e4 <_js_json_stringify_full+0x1224>
1008471cc:     	and	x8, x24, #0x7
1008471d0:     	cbnz	x8, 0x1008471e4 <_js_json_stringify_full+0x1224>
1008471d4:     	mov	x0, x24
1008471d8:     	bl	0x10050f178 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008471dc:     	mov	x8, x24
1008471e0:     	tbnz	w0, #0x0, 0x100846fbc <_js_json_stringify_full+0xffc>
1008471e4:     	mov	x0, x24
1008471e8:     	bl	0x1005094d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
1008471ec:     	tbz	w0, #0x0, 0x10084727c <_js_json_stringify_full+0x12bc>
1008471f0:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1008471f4:     	add	x0, x0, #0xd90
1008471f8:     	ldr	x8, [x0]
1008471fc:     	blr	x8
100847200:     	ldrb	w8, [x0, #0x20]
100847204:     	cbnz	w8, 0x100847b2c <_js_json_stringify_full+0x1b6c>
100847208:     	ldr	x8, [x0]
10084720c:     	cbnz	x8, 0x100847b54 <_js_json_stringify_full+0x1b94>
100847210:     	str	xzr, [x0, #0x18]
100847214:     	ldp	x22, x19, [sp, #0x48]
100847218:     	ldrb	w8, [x23, #0x18]
10084721c:     	cmp	w8, #0x1
100847220:     	b.ne	0x100847b08 <_js_json_stringify_full+0x1b48>
100847224:     	ldp	x8, x0, [x23]
100847228:     	stp	x22, x19, [x23]
10084722c:     	str	xzr, [x23, #0x10]
100847230:     	sub	x8, x8, #0x1
100847234:     	cmn	x8, #0x2
100847238:     	b.hs	0x100847240 <_js_json_stringify_full+0x1280>
10084723c:     	bl	0x100b5f440 <_mi_free>
100847240:     	cbz	w26, 0x100847260 <_js_json_stringify_full+0x12a0>
100847244:     	bl	0x100328128 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100847248:     	ldr	w8, [x21]
10084724c:     	sub	w8, w8, #0x1
100847250:     	str	w8, [x21]
100847254:     	cmn	x25, #0x1
100847258:     	b.ne	0x10084741c <_js_json_stringify_full+0x145c>
10084725c:     	b	0x100847458 <_js_json_stringify_full+0x1498>
100847260:     	bl	0x100327f58 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100847264:     	ldr	w8, [x21]
100847268:     	sub	w8, w8, #0x1
10084726c:     	str	w8, [x21]
100847270:     	cmn	x25, #0x1
100847274:     	b.ne	0x10084741c <_js_json_stringify_full+0x145c>
100847278:     	b	0x100847458 <_js_json_stringify_full+0x1498>
10084727c:     	cmp	x19, x24
100847280:     	b.eq	0x10084728c <_js_json_stringify_full+0x12cc>
100847284:     	mov.16b	v0, v8
100847288:     	bl	0x10050e8ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
10084728c:     	cbz	x22, 0x1008474e8 <_js_json_stringify_full+0x1528>
100847290:     	ldp	x1, x2, [sp, #0x18]
100847294:     	add	x0, sp, #0x48
100847298:     	mov.16b	v0, v8
10084729c:     	mov	x3, #0x0                ; =0
1008472a0:     	bl	0x100500fa0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
1008472a4:     	b	0x1008474f8 <_js_json_stringify_full+0x1538>
1008472a8:     	and	x9, x1, #0x4
1008472ac:     	add	x8, x0, x9
1008472b0:     	adrp	x10, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x49b0>
1008472b4:     	ldr	q0, [x10, #0xec0]
1008472b8:     	adrp	x10, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x331ba>
1008472bc:     	ldr	q2, [x10, #0xdc0]
1008472c0:     	movi.2d	v1, #0000000000000000
1008472c4:     	movi.2d	v3, #0x000000000000ff
1008472c8:     	mov	w10, #0x4               ; =4
1008472cc:     	dup.2d	v4, x10
1008472d0:     	mov	x10, x0
1008472d4:     	and	x11, x1, #0x4
1008472d8:     	movi.2d	v5, #0000000000000000
1008472dc:     	ldr	s6, [x10], #0x4
1008472e0:     	ushll.8h	v6, v6, #0x0
1008472e4:     	ushll.4s	v6, v6, #0x0
1008472e8:     	ushll2.2d	v7, v6, #0x0
1008472ec:     	and.16b	v7, v7, v3
1008472f0:     	ushll.2d	v6, v6, #0x0
1008472f4:     	and.16b	v6, v6, v3
1008472f8:     	shl.2d	v16, v0, #0x3
1008472fc:     	shl.2d	v17, v2, #0x3
100847300:     	ushl.2d	v6, v6, v17
100847304:     	ushl.2d	v7, v7, v16
100847308:     	orr.16b	v1, v7, v1
10084730c:     	orr.16b	v5, v6, v5
100847310:     	add.2d	v0, v0, v4
100847314:     	add.2d	v2, v2, v4
100847318:     	subs	x11, x11, #0x4
10084731c:     	b.ne	0x1008472dc <_js_json_stringify_full+0x131c>
100847320:     	orr.16b	v0, v5, v1
100847324:     	mov	d1, v0[1]
100847328:     	orr.8b	v0, v0, v1
10084732c:     	fmov	x10, d0
100847330:     	cmp	x1, x9
100847334:     	b.eq	0x100847358 <_js_json_stringify_full+0x1398>
100847338:     	add	x11, x0, x1
10084733c:     	lsl	x9, x9, #3
100847340:     	ldrb	w12, [x8], #0x1
100847344:     	lsl	x12, x12, x9
100847348:     	orr	x10, x12, x10
10084734c:     	add	x9, x9, #0x8
100847350:     	cmp	x8, x11
100847354:     	b.ne	0x100847340 <_js_json_stringify_full+0x1380>
100847358:     	orr	x8, x10, x1, lsl #40
10084735c:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100847360:     	orr	x20, x8, x9
100847364:     	ldr	x22, [sp, #0x48]
100847368:     	ldrb	w8, [x23, #0x18]
10084736c:     	cmp	w8, #0x1
100847370:     	b.ne	0x100847a78 <_js_json_stringify_full+0x1ab8>
100847374:     	ldp	x9, x8, [x23]
100847378:     	stp	x22, x0, [x23]
10084737c:     	str	xzr, [x23, #0x10]
100847380:     	sub	x9, x9, #0x1
100847384:     	cmn	x9, #0x2
100847388:     	b.hs	0x100847394 <_js_json_stringify_full+0x13d4>
10084738c:     	mov	x0, x8
100847390:     	bl	0x100b5f440 <_mi_free>
100847394:     	cbz	w26, 0x1008473b4 <_js_json_stringify_full+0x13f4>
100847398:     	bl	0x100328128 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084739c:     	ldr	w8, [x21]
1008473a0:     	sub	w8, w8, #0x1
1008473a4:     	str	w8, [x21]
1008473a8:     	cmn	x25, #0x1
1008473ac:     	b.ne	0x1008473cc <_js_json_stringify_full+0x140c>
1008473b0:     	b	0x100847458 <_js_json_stringify_full+0x1498>
1008473b4:     	bl	0x100327f58 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
1008473b8:     	ldr	w8, [x21]
1008473bc:     	sub	w8, w8, #0x1
1008473c0:     	str	w8, [x21]
1008473c4:     	cmn	x25, #0x1
1008473c8:     	b.eq	0x100847458 <_js_json_stringify_full+0x1498>
1008473cc:     	ldp	x19, x21, [sp, #0x38]
1008473d0:     	cbz	x21, 0x10084744c <_js_json_stringify_full+0x148c>
1008473d4:     	add	x22, x19, #0x8
1008473d8:     	b	0x1008473e8 <_js_json_stringify_full+0x1428>
1008473dc:     	add	x22, x22, #0x18
1008473e0:     	subs	x21, x21, #0x1
1008473e4:     	b.eq	0x10084744c <_js_json_stringify_full+0x148c>
1008473e8:     	ldur	x8, [x22, #-0x8]
1008473ec:     	cbz	x8, 0x1008473dc <_js_json_stringify_full+0x141c>
1008473f0:     	ldr	x0, [x22]
1008473f4:     	bl	0x100b5f440 <_mi_free>
1008473f8:     	b	0x1008473dc <_js_json_stringify_full+0x141c>
1008473fc:     	bl	0x100327f58 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100847400:     	ldr	w8, [x21]
100847404:     	sub	w8, w8, #0x1
100847408:     	str	w8, [x21]
10084740c:     	add	x0, sp, #0x60
100847410:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100847414:     	cmn	x25, #0x1
100847418:     	b.eq	0x100847458 <_js_json_stringify_full+0x1498>
10084741c:     	ldp	x19, x21, [sp, #0x38]
100847420:     	cbz	x21, 0x10084744c <_js_json_stringify_full+0x148c>
100847424:     	add	x22, x19, #0x8
100847428:     	b	0x100847438 <_js_json_stringify_full+0x1478>
10084742c:     	add	x22, x22, #0x18
100847430:     	subs	x21, x21, #0x1
100847434:     	b.eq	0x10084744c <_js_json_stringify_full+0x148c>
100847438:     	ldur	x8, [x22, #-0x8]
10084743c:     	cbz	x8, 0x10084742c <_js_json_stringify_full+0x146c>
100847440:     	ldr	x0, [x22]
100847444:     	bl	0x100b5f440 <_mi_free>
100847448:     	b	0x10084742c <_js_json_stringify_full+0x146c>
10084744c:     	cbz	x25, 0x100847458 <_js_json_stringify_full+0x1498>
100847450:     	mov	x0, x19
100847454:     	bl	0x100b5f440 <_mi_free>
100847458:     	ldr	x8, [sp, #0x10]
10084745c:     	cbz	x8, 0x100847468 <_js_json_stringify_full+0x14a8>
100847460:     	ldr	x0, [sp, #0x18]
100847464:     	bl	0x100b5f440 <_mi_free>
100847468:     	mov	x0, x20
10084746c:     	ldp	x29, x30, [sp, #0x110]
100847470:     	ldp	x20, x19, [sp, #0x100]
100847474:     	ldp	x22, x21, [sp, #0xf0]
100847478:     	ldp	x24, x23, [sp, #0xe0]
10084747c:     	ldp	x26, x25, [sp, #0xd0]
100847480:     	ldp	x28, x27, [sp, #0xc0]
100847484:     	ldp	d9, d8, [sp, #0xb0]
100847488:     	add	sp, sp, #0x120
10084748c:     	ret
100847490:     	str	x22, [sp, #0x8]
100847494:     	mov	x22, x28
100847498:     	mov	x28, x0
10084749c:     	add	x0, x0, #0x8
1008474a0:     	bl	0x100b3c1d0 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1008474a4:     	mov	x0, x28
1008474a8:     	mov	x28, x22
1008474ac:     	ldr	x22, [sp, #0x8]
1008474b0:     	b	0x100846cd8 <_js_json_stringify_full+0xd18>
1008474b4:     	b.ne	0x100846a1c <_js_json_stringify_full+0xa5c>
1008474b8:     	tbz	x25, #0x3f, 0x100847510 <_js_json_stringify_full+0x1550>
1008474bc:     	mov	x0, #0x0                ; =0
1008474c0:     	mov	x1, x25
1008474c4:     	bl	0x100b12800 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1008474c8:     	bl	0x100b3f87c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1008474cc:     	add	x8, x0, x23, lsl #3
1008474d0:     	ldr	x0, [x8, #0x1e8]
1008474d4:     	cbnz	x0, 0x100846d6c <_js_json_stringify_full+0xdac>
1008474d8:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1008474dc:     	add	x0, x0, #0x138
1008474e0:     	bl	0x100b3d09c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1008474e4:     	b	0x100846d6c <_js_json_stringify_full+0xdac>
1008474e8:     	add	x1, sp, #0x48
1008474ec:     	mov.16b	v0, v8
1008474f0:     	mov	w0, #0x0                ; =0
1008474f4:     	bl	0x1005095ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
1008474f8:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1008474fc:     	add	x0, x0, #0xdc0
100847500:     	ldr	x8, [x0]
100847504:     	blr	x8
100847508:     	strb	wzr, [x0]
10084750c:     	b	0x100846eb0 <_js_json_stringify_full+0xef0>
100847510:     	mov	x0, x25
100847514:     	mov	w1, #0x1                ; =1
100847518:     	bl	0x100b5f6c8 <_mi_malloc_aligned>
10084751c:     	mov	x26, x0
100847520:     	mov	w0, #0x1                ; =1
100847524:     	cbz	x26, 0x1008474c0 <_js_json_stringify_full+0x1500>
100847528:     	mov	x0, x26
10084752c:     	mov	x1, x23
100847530:     	mov	x2, x25
100847534:     	bl	0x100b622ec <_writev+0x100b622ec>
100847538:     	mov	x22, x25
10084753c:     	b	0x100846a40 <_js_json_stringify_full+0xa80>
100847540:     	cmp	w11, #0x8
100847544:     	b.eq	0x100847610 <_js_json_stringify_full+0x1650>
100847548:     	cmp	w11, #0x9
10084754c:     	b.eq	0x100847620 <_js_json_stringify_full+0x1660>
100847550:     	cmp	w11, #0xa
100847554:     	b.ne	0x10084759c <_js_json_stringify_full+0x15dc>
100847558:     	mov	w10, #0x6e              ; =110
10084755c:     	b	0x100847624 <_js_json_stringify_full+0x1664>
100847560:     	mov	x22, x0
100847564:     	and	x0, x19, #0xffffffffffff
100847568:     	bl	0x100347c80 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
10084756c:     	cbz	x0, 0x100847648 <_js_json_stringify_full+0x1688>
100847570:     	ldr	w20, [x0]
100847574:     	cmp	w20, #0x4
100847578:     	b.hi	0x100846598 <_js_json_stringify_full+0x5d8>
10084757c:     	ldr	w8, [x0, #0x4]
100847580:     	cmp	w20, w8
100847584:     	b.hi	0x100846598 <_js_json_stringify_full+0x5d8>
100847588:     	b	0x10084764c <_js_json_stringify_full+0x168c>
10084758c:     	cmp	w11, #0x22
100847590:     	b.eq	0x100847624 <_js_json_stringify_full+0x1664>
100847594:     	cmp	w11, #0x5c
100847598:     	b.eq	0x100847624 <_js_json_stringify_full+0x1664>
10084759c:     	cmp	x12, #0x3
1008475a0:     	mov	w11, #0x20              ; =32
1008475a4:     	ccmp	w10, w11, #0x8, ls
1008475a8:     	b.lt	0x1008464d4 <_js_json_stringify_full+0x514>
1008475ac:     	add	x8, sp, #0x80
1008475b0:     	strb	w10, [x8, x12]
1008475b4:     	add	x12, x12, #0x1
1008475b8:     	b	0x1008461c4 <_js_json_stringify_full+0x204>
1008475bc:     	mov	x1, x0
1008475c0:     	and	x0, x19, #0xffffffffffff
1008475c4:     	mov	x22, x1
1008475c8:     	bl	0x1004f8e40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
1008475cc:     	cmp	x0, #0x1
1008475d0:     	b.ne	0x1008476f4 <_js_json_stringify_full+0x1734>
1008475d4:     	mov	x20, x1
1008475d8:     	b	0x100847468 <_js_json_stringify_full+0x14a8>
1008475dc:     	ldrb	w9, [x8, #0x118]
1008475e0:     	cbz	w9, 0x10084781c <_js_json_stringify_full+0x185c>
1008475e4:     	ldr	x9, [x8, #0x110]
1008475e8:     	cmp	x9, x1
1008475ec:     	b.ne	0x10084781c <_js_json_stringify_full+0x185c>
1008475f0:     	ldr	x9, [x8, #0xf0]
1008475f4:     	cmp	x9, x23
1008475f8:     	b.hi	0x10084781c <_js_json_stringify_full+0x185c>
1008475fc:     	ldr	x9, [x8, #0xf8]
100847600:     	cmp	x9, x23
100847604:     	b.ls	0x10084781c <_js_json_stringify_full+0x185c>
100847608:     	add	x9, x8, #0xf0
10084760c:     	b	0x100847a28 <_js_json_stringify_full+0x1a68>
100847610:     	mov	w10, #0x62              ; =98
100847614:     	b	0x100847624 <_js_json_stringify_full+0x1664>
100847618:     	mov	w10, #0x66              ; =102
10084761c:     	b	0x100847624 <_js_json_stringify_full+0x1664>
100847620:     	mov	w10, #0x74              ; =116
100847624:     	cmp	x12, #0x2
100847628:     	b.hi	0x1008464d4 <_js_json_stringify_full+0x514>
10084762c:     	add	x8, sp, #0x80
100847630:     	add	x8, x8, x12
100847634:     	add	x12, x12, #0x2
100847638:     	mov	w11, #0x5c              ; =92
10084763c:     	strb	w11, [x8]
100847640:     	strb	w10, [x8, #0x1]
100847644:     	b	0x1008461c4 <_js_json_stringify_full+0x204>
100847648:     	mov	x20, #0x0               ; =0
10084764c:     	ldr	w8, [x22, #0x4]
100847650:     	lsl	x9, x20, #3
100847654:     	add	x9, x9, #0x18
100847658:     	cmp	x9, x8
10084765c:     	b.hi	0x100846598 <_js_json_stringify_full+0x5d8>
100847660:     	ldr	w8, [x25, #0x4]
100847664:     	mov	w9, #-0x40000000        ; =-1073741824
100847668:     	cmp	w8, w9
10084766c:     	csel	w8, w8, wzr, lt
100847670:     	mov	x22, x0
100847674:     	mov	x0, x8
100847678:     	bl	0x1005e5724 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084767c:     	mov	w9, #0x2                ; =2
100847680:     	cmp	w1, #0x2
100847684:     	csel	w10, w1, w9, hi
100847688:     	tst	w0, #0x1
10084768c:     	csel	x8, x10, x9, ne
100847690:     	cmp	x20, x8
100847694:     	b.hi	0x100846598 <_js_json_stringify_full+0x5d8>
100847698:     	cbz	x20, 0x100847a58 <_js_json_stringify_full+0x1a98>
10084769c:     	mov	x0, x22
1008476a0:     	mov	x1, x20
1008476a4:     	bl	0x1004efe00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
1008476a8:     	tbz	w0, #0x0, 0x100846598 <_js_json_stringify_full+0x5d8>
1008476ac:     	cmp	x20, #0x1
1008476b0:     	b.eq	0x100847af4 <_js_json_stringify_full+0x1b34>
1008476b4:     	cmp	x20, #0x2
1008476b8:     	b.ne	0x100847bb0 <_js_json_stringify_full+0x1bf0>
1008476bc:     	mov	x22, #0x0               ; =0
1008476c0:     	add	x25, x25, #0x10
1008476c4:     	mov	w8, #0x1                ; =1
1008476c8:     	mov	x26, x8
1008476cc:     	ldr	x1, [x25, x22, lsl #3]
1008476d0:     	add	x0, sp, #0x80
1008476d4:     	bl	0x1004efe54 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
1008476d8:     	ldr	w8, [sp, #0x80]
1008476dc:     	cmn	w8, #0x1
1008476e0:     	b.ne	0x100847b98 <_js_json_stringify_full+0x1bd8>
1008476e4:     	mov	w8, #0x0                ; =0
1008476e8:     	mov	w22, #0x1               ; =1
1008476ec:     	tbnz	w26, #0x0, 0x1008476c8 <_js_json_stringify_full+0x1708>
1008476f0:     	b	0x100847bb0 <_js_json_stringify_full+0x1bf0>
1008476f4:     	and	x0, x19, #0xffffffffffff
1008476f8:     	bl	0x100347c80 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
1008476fc:     	cbz	x0, 0x100847788 <_js_json_stringify_full+0x17c8>
100847700:     	ldr	w20, [x0]
100847704:     	cbz	w20, 0x100847788 <_js_json_stringify_full+0x17c8>
100847708:     	cmp	w20, #0x8
10084770c:     	b.hi	0x100846564 <_js_json_stringify_full+0x5a4>
100847710:     	ldr	w8, [x0, #0x4]
100847714:     	cmp	w20, w8
100847718:     	b.hi	0x100846564 <_js_json_stringify_full+0x5a4>
10084771c:     	ldr	w8, [x22, #0x4]
100847720:     	lsl	x9, x20, #3
100847724:     	add	x9, x9, #0x18
100847728:     	cmp	x9, x8
10084772c:     	b.hi	0x100846564 <_js_json_stringify_full+0x5a4>
100847730:     	ldr	w8, [x25, #0x4]
100847734:     	mov	w9, #-0x40000000        ; =-1073741824
100847738:     	cmp	w8, w9
10084773c:     	csel	w8, w8, wzr, lt
100847740:     	mov	x22, x0
100847744:     	mov	x0, x8
100847748:     	bl	0x1005e5724 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084774c:     	mov	w9, #0x2                ; =2
100847750:     	cmp	w1, #0x2
100847754:     	csel	w10, w1, w9, hi
100847758:     	tst	w0, #0x1
10084775c:     	csel	w8, w10, w9, ne
100847760:     	cmp	w20, w8
100847764:     	b.hi	0x100846564 <_js_json_stringify_full+0x5a4>
100847768:     	mov	x0, x22
10084776c:     	mov	x1, x20
100847770:     	bl	0x1004efe00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
100847774:     	cbz	w0, 0x100846564 <_js_json_stringify_full+0x5a4>
100847778:     	and	x0, x19, #0xffffffffffff
10084777c:     	mov	x1, x20
100847780:     	bl	0x1004f7f80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
100847784:     	b	0x100847790 <_js_json_stringify_full+0x17d0>
100847788:     	and	x0, x19, #0xffffffffffff
10084778c:     	bl	0x1004f8d00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
100847790:     	mov	x20, x1
100847794:     	tbz	w0, #0x0, 0x100846564 <_js_json_stringify_full+0x5a4>
100847798:     	b	0x100847468 <_js_json_stringify_full+0x14a8>
10084779c:     	add	x9, x8, #0x60
1008477a0:     	b	0x100847a28 <_js_json_stringify_full+0x1a68>
1008477a4:     	bl	0x100b3f87c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1008477a8:     	lsr	x1, x23, #20
1008477ac:     	ldr	x8, [x0, #0x10]
1008477b0:     	ldrb	w9, [x8]
1008477b4:     	cmp	w9, #0x2
1008477b8:     	b.eq	0x100846b48 <_js_json_stringify_full+0xb88>
1008477bc:     	ldr	x9, [x8, #0x8]
1008477c0:     	ldr	x10, [x8, #0x28]
1008477c4:     	sub	x9, x1, x9
1008477c8:     	cmp	x9, x10
1008477cc:     	b.hs	0x100847810 <_js_json_stringify_full+0x1850>
1008477d0:     	ldr	x10, [x8, #0x20]
1008477d4:     	mov	w11, #0x28              ; =40
1008477d8:     	madd	x9, x9, x11, x10
1008477dc:     	ldr	x10, [x9]
1008477e0:     	ldr	x11, [x8, #0x10]
1008477e4:     	cmp	x10, x11
1008477e8:     	b.ne	0x10084781c <_js_json_stringify_full+0x185c>
1008477ec:     	ldp	x10, x11, [x9, #0x8]
1008477f0:     	cmp	x10, x23
1008477f4:     	ccmp	x11, x23, #0x0, ls
1008477f8:     	b.ls	0x10084781c <_js_json_stringify_full+0x185c>
1008477fc:     	ldr	x10, [x8, #0x30]
100847800:     	add	x10, x10, #0x1
100847804:     	str	x10, [x8, #0x30]
100847808:     	add	x8, x9, #0x21
10084780c:     	b	0x100847a38 <_js_json_stringify_full+0x1a78>
100847810:     	ldr	x9, [x8, #0x58]
100847814:     	add	x9, x9, #0x1
100847818:     	str	x9, [x8, #0x58]
10084781c:     	ldr	x9, [x8, #0x38]
100847820:     	add	x9, x9, #0x1
100847824:     	str	x9, [x8, #0x38]
100847828:     	mov	x0, x23
10084782c:     	bl	0x10051e388 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
100847830:     	and	w8, w0, #0xff
100847834:     	cbz	w8, 0x100847854 <_js_json_stringify_full+0x1894>
100847838:     	ldurb	w8, [x23, #-0x8]
10084783c:     	ldurb	w9, [x23, #-0x7]
100847840:     	mov	w10, #0x82              ; =130
100847844:     	and	w9, w9, w10
100847848:     	cmp	w9, #0x2
10084784c:     	ccmp	w8, #0x1, #0x0, eq
100847850:     	b.eq	0x1008478e8 <_js_json_stringify_full+0x1928>
100847854:     	mov	x0, x23
100847858:     	bl	0x10057aa00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084785c:     	mov	x24, x0
100847860:     	cbz	x0, 0x10084788c <_js_json_stringify_full+0x18cc>
100847864:     	ldrb	w8, [x24]
100847868:     	cmp	w8, #0x1
10084786c:     	b.ne	0x1008478ac <_js_json_stringify_full+0x18ec>
100847870:     	ldrsb	w8, [x24, #0x1]
100847874:     	tbnz	w8, #0x1f, 0x100847910 <_js_json_stringify_full+0x1950>
100847878:     	mov	x0, x24
10084787c:     	ldp	w9, w8, [x23]
100847880:     	cmp	w9, w8
100847884:     	b.hi	0x100847994 <_js_json_stringify_full+0x19d4>
100847888:     	b	0x1008479ac <_js_json_stringify_full+0x19ec>
10084788c:     	mov	x0, x23
100847890:     	bl	0x100589234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100847894:     	tbnz	w0, #0x0, 0x1008478a4 <_js_json_stringify_full+0x18e4>
100847898:     	mov	x0, x23
10084789c:     	bl	0x1002a3f88 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
1008478a0:     	tbz	w0, #0x0, 0x100846be8 <_js_json_stringify_full+0xc28>
1008478a4:     	mov	x0, #0x0                ; =0
1008478a8:     	b	0x100847984 <_js_json_stringify_full+0x19c4>
1008478ac:     	mov	x0, x24
1008478b0:     	cmp	w8, #0x1
1008478b4:     	b.eq	0x100847984 <_js_json_stringify_full+0x19c4>
1008478b8:     	cmp	w8, #0x9
1008478bc:     	b.ne	0x100846be8 <_js_json_stringify_full+0xc28>
1008478c0:     	ldr	w8, [x23, #0x4]
1008478c4:     	mov	w9, #0x5841             ; =22593
1008478c8:     	movk	w9, #0x4c5a, lsl #16
1008478cc:     	cmp	w8, w9
1008478d0:     	b.ne	0x100846be8 <_js_json_stringify_full+0xc28>
1008478d4:     	mov	x0, x23
1008478d8:     	bl	0x100375e90 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1008478dc:     	mov	x23, x0
1008478e0:     	cbnz	x0, 0x1008479d4 <_js_json_stringify_full+0x1a14>
1008478e4:     	b	0x100846be8 <_js_json_stringify_full+0xc28>
1008478e8:     	ldr	w8, [x23]
1008478ec:     	mov	w9, #0xe100             ; =57600
1008478f0:     	movk	w9, #0x5f5, lsl #16
1008478f4:     	orr	w9, w9, #0x1
1008478f8:     	cmp	w8, w9
1008478fc:     	b.hs	0x100847854 <_js_json_stringify_full+0x1894>
100847900:     	ldr	w9, [x23, #0x4]
100847904:     	cmp	w8, w9
100847908:     	b.ls	0x1008479d4 <_js_json_stringify_full+0x1a14>
10084790c:     	b	0x100847854 <_js_json_stringify_full+0x1894>
100847910:     	ldr	x23, [x24, #0x8]
100847914:     	mov	x0, x23
100847918:     	bl	0x10057aa00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084791c:     	cbz	x0, 0x100846be8 <_js_json_stringify_full+0xc28>
100847920:     	ldrb	w8, [x0]
100847924:     	cmp	w8, #0x1
100847928:     	b.ne	0x100846be8 <_js_json_stringify_full+0xc28>
10084792c:     	ldrsb	w8, [x0, #0x1]
100847930:     	tbz	w8, #0x1f, 0x10084787c <_js_json_stringify_full+0x18bc>
100847934:     	mov	w26, #0x1               ; =1
100847938:     	ldr	x23, [x0, #0x8]
10084793c:     	mov	x0, x23
100847940:     	bl	0x10057aa00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100847944:     	cbz	x0, 0x100846be8 <_js_json_stringify_full+0xc28>
100847948:     	ldrb	w8, [x0]
10084794c:     	cmp	w8, #0x1
100847950:     	b.ne	0x100846be8 <_js_json_stringify_full+0xc28>
100847954:     	cmp	w26, #0x3f
100847958:     	b.hi	0x100846be8 <_js_json_stringify_full+0xc28>
10084795c:     	add	w26, w26, #0x1
100847960:     	ldrsb	w8, [x0, #0x1]
100847964:     	tbnz	w8, #0x1f, 0x100847938 <_js_json_stringify_full+0x1978>
100847968:     	str	x23, [x24, #0x8]
10084796c:     	ldrb	w8, [x24, #0x1]
100847970:     	orr	w8, w8, #0x80
100847974:     	strb	w8, [x24, #0x1]
100847978:     	ldrb	w8, [x0]
10084797c:     	cmp	w8, #0x1
100847980:     	b.ne	0x1008478b8 <_js_json_stringify_full+0x18f8>
100847984:     	ldp	w9, w8, [x23]
100847988:     	cmp	w9, w8
10084798c:     	b.ls	0x1008479ac <_js_json_stringify_full+0x19ec>
100847990:     	cbz	x24, 0x1008479bc <_js_json_stringify_full+0x19fc>
100847994:     	ldr	w9, [x0, #0x4]
100847998:     	ubfiz	x8, x8, #3, #32
10084799c:     	add	x8, x8, #0x10
1008479a0:     	cmp	x8, x9
1008479a4:     	b.eq	0x1008479d4 <_js_json_stringify_full+0x1a14>
1008479a8:     	b	0x1008479bc <_js_json_stringify_full+0x19fc>
1008479ac:     	mov	w8, #0xe100             ; =57600
1008479b0:     	movk	w8, #0x5f5, lsl #16
1008479b4:     	cmp	w9, w8
1008479b8:     	b.ls	0x1008479d4 <_js_json_stringify_full+0x1a14>
1008479bc:     	mov	x0, x23
1008479c0:     	bl	0x100589234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1008479c4:     	tbnz	w0, #0x0, 0x1008479d4 <_js_json_stringify_full+0x1a14>
1008479c8:     	mov	x0, x23
1008479cc:     	bl	0x1002a3f88 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
1008479d0:     	tbz	w0, #0x0, 0x100846be8 <_js_json_stringify_full+0xc28>
1008479d4:     	ldp	w8, w9, [x23]
1008479d8:     	sub	w10, w9, #0x1
1008479dc:     	mov	w11, #0x270f            ; =9999
1008479e0:     	cmp	w10, w11
1008479e4:     	ccmp	w8, w9, #0x2, lo
1008479e8:     	b.hi	0x100846be8 <_js_json_stringify_full+0xc28>
1008479ec:     	and	x8, x21, #0xffffffffffff
1008479f0:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
1008479f4:     	cmp	x25, x9
1008479f8:     	csel	x1, x8, x21, eq
1008479fc:     	add	x0, sp, #0x30
100847a00:     	bl	0x1004ffcb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer20extract_string_array>
100847a04:     	ldr	x25, [sp, #0x30]
100847a08:     	cmn	x25, #0x1
100847a0c:     	cset	w24, eq
100847a10:     	cmp	x27, #0x1
100847a14:     	cset	w8, hi
100847a18:     	tst	w8, w24
100847a1c:     	b.ne	0x100846c04 <_js_json_stringify_full+0xc44>
100847a20:     	b	0x100846c74 <_js_json_stringify_full+0xcb4>
100847a24:     	add	x9, x8, #0x90
100847a28:     	ldr	x10, [x8, #0x30]
100847a2c:     	add	x10, x10, #0x1
100847a30:     	str	x10, [x8, #0x30]
100847a34:     	add	x8, x9, #0x19
100847a38:     	ldrb	w8, [x8]
100847a3c:     	cmp	w8, #0xff
100847a40:     	b.ne	0x100847834 <_js_json_stringify_full+0x1874>
100847a44:     	b	0x100847828 <_js_json_stringify_full+0x1868>
100847a48:     	mov	x0, x23
100847a4c:     	bl	0x100b1ea04 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847a50:     	cbnz	x0, 0x100846d90 <_js_json_stringify_full+0xdd0>
100847a54:     	b	0x100847bd0 <_js_json_stringify_full+0x1c10>
100847a58:     	and	x0, x19, #0xffffffffffff
100847a5c:     	bl	0x1004f7db0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
100847a60:     	mov	w0, w0
100847a64:     	mov	x20, #0x7d7b            ; =32123
100847a68:     	movk	x20, #0x200, lsl #32
100847a6c:     	movk	x20, #0x7ff9, lsl #48
100847a70:     	tbz	w0, #0x0, 0x100846598 <_js_json_stringify_full+0x5d8>
100847a74:     	b	0x100847468 <_js_json_stringify_full+0x14a8>
100847a78:     	mov	x19, x0
100847a7c:     	mov	x0, x23
100847a80:     	bl	0x100b1ea04 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847a84:     	mov	x23, x0
100847a88:     	mov	x0, x19
100847a8c:     	cbnz	x23, 0x100847374 <_js_json_stringify_full+0x13b4>
100847a90:     	b	0x100847b70 <_js_json_stringify_full+0x1bb0>
100847a94:     	bl	0x100b1eb64 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100847a98:     	cbnz	x0, 0x100846cb8 <_js_json_stringify_full+0xcf8>
100847a9c:     	b	0x100847bd0 <_js_json_stringify_full+0x1c10>
100847aa0:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100847aa4:     	add	x0, x0, #0x440
100847aa8:     	bl	0x100b12bac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847aac:     	cmp	w8, #0x1
100847ab0:     	b.ne	0x100847bd0 <_js_json_stringify_full+0x1c10>
100847ab4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100847ab8:     	add	x1, x1, #0x998
100847abc:     	mov	x19, x0
100847ac0:     	bl	0x100a208dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847ac4:     	mov	x0, x19
100847ac8:     	strb	wzr, [x19, #0x20]
100847acc:     	ldr	x8, [x19]
100847ad0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100847ad4:     	cmp	x8, x9
100847ad8:     	b.lo	0x100846ed8 <_js_json_stringify_full+0xf18>
100847adc:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847ae0:     	add	x0, x0, #0xea8
100847ae4:     	bl	0x100b12bdc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100847ae8:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847aec:     	add	x0, x0, #0xec0
100847af0:     	bl	0x100b12bac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847af4:     	and	x0, x19, #0xffffffffffff
100847af8:     	bl	0x1004efa00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
100847afc:     	mov	x20, x1
100847b00:     	tbz	w0, #0x0, 0x100846598 <_js_json_stringify_full+0x5d8>
100847b04:     	b	0x100847468 <_js_json_stringify_full+0x14a8>
100847b08:     	mov	x0, x23
100847b0c:     	bl	0x100b1ea04 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847b10:     	mov	x23, x0
100847b14:     	cbnz	x0, 0x100847224 <_js_json_stringify_full+0x1264>
100847b18:     	b	0x100847b70 <_js_json_stringify_full+0x1bb0>
100847b1c:     	adrp	x0, 0x100ef7000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
100847b20:     	add	x0, x0, #0xd70
100847b24:     	bl	0x100b12bdc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100847b28:     	bl	0x100b4bdd4 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
100847b2c:     	cmp	w8, #0x2
100847b30:     	b.eq	0x100847bd0 <_js_json_stringify_full+0x1c10>
100847b34:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100847b38:     	add	x1, x1, #0x998
100847b3c:     	mov	x19, x0
100847b40:     	bl	0x100a208dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847b44:     	mov	x0, x19
100847b48:     	strb	wzr, [x19, #0x20]
100847b4c:     	ldr	x8, [x19]
100847b50:     	cbz	x8, 0x100847210 <_js_json_stringify_full+0x1250>
100847b54:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847b58:     	add	x0, x0, #0xe90
100847b5c:     	bl	0x100b12bac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847b60:     	mov	x0, x23
100847b64:     	bl	0x100b1ea04 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847b68:     	mov	x23, x0
100847b6c:     	cbnz	x0, 0x100847140 <_js_json_stringify_full+0x1180>
100847b70:     	cbz	x22, 0x100847bd0 <_js_json_stringify_full+0x1c10>
100847b74:     	mov	x0, x19
100847b78:     	bl	0x100b5f440 <_mi_free>
100847b7c:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100847b80:     	add	x0, x0, #0xc18
100847b84:     	bl	0x100b58a9c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100847b88:     	adrp	x0, 0x100c42000 <_PERRY_EMPTY_STRING+0x5f4>
100847b8c:     	add	x0, x0, #0x930
100847b90:     	mov	w1, #0xf                ; =15
100847b94:     	bl	0x100b4bd9c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100847b98:     	and	x0, x19, #0xffffffffffff
100847b9c:     	add	x2, sp, #0x80
100847ba0:     	mov	x1, x22
100847ba4:     	bl	0x1004f0200 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
100847ba8:     	tbnz	w0, #0x0, 0x1008475d4 <_js_json_stringify_full+0x1614>
100847bac:     	mov	w20, #0x2               ; =2
100847bb0:     	and	x0, x19, #0xffffffffffff
100847bb4:     	mov	x1, x20
100847bb8:     	bl	0x1004ee880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
100847bbc:     	mov	x20, x1
100847bc0:     	tbz	w0, #0x0, 0x100846598 <_js_json_stringify_full+0x5d8>
100847bc4:     	b	0x100847468 <_js_json_stringify_full+0x14a8>
100847bc8:     	cmp	w8, #0x2
100847bcc:     	b.ne	0x100847bf8 <_js_json_stringify_full+0x1c38>
100847bd0:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100847bd4:     	add	x0, x0, #0xc18
100847bd8:     	bl	0x100b58a9c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100847bdc:     	adrp	x0, 0x100f2f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x1a8>
100847be0:     	add	x0, x0, #0x830
100847be4:     	bl	0x100b12c70 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100847be8:     	adrp	x0, 0x100c42000 <_PERRY_EMPTY_STRING+0x5f4>
100847bec:     	add	x0, x0, #0x667
100847bf0:     	mov	w1, #0xb                ; =11
100847bf4:     	bl	0x100b4bd9c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100847bf8:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100847bfc:     	add	x1, x1, #0x998
100847c00:     	mov	x19, x0
100847c04:     	bl	0x100a208dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847c08:     	mov	x0, x19
100847c0c:     	strb	wzr, [x19, #0x20]
100847c10:     	ldr	x8, [x19]
100847c14:     	cbz	x8, 0x10084712c <_js_json_stringify_full+0x116c>
100847c18:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847c1c:     	add	x0, x0, #0xe78
100847c20:     	bl	0x100b12bac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847c24:     	mov	w0, #0x1                ; =1
100847c28:     	mov	x1, x24
100847c2c:     	bl	0x100b12800 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847c30:     	mov	w0, #0x1                ; =1
100847c34:     	mov	x1, x22
100847c38:     	bl	0x100b12800 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847c3c:     	adrp	x2, 0x100ef8000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100847c40:     	add	x2, x2, #0x3c8
100847c44:     	mov	w0, #0x5                ; =5
100847c48:     	mov	w1, #0x5                ; =5
100847c4c:     	bl	0x100b12d0c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
