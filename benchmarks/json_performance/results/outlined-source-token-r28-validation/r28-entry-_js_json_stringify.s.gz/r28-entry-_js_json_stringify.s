
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/outlined-source-token-r28/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010084586c <_js_json_stringify>:
10084586c:     	sub	sp, sp, #0x80
100845870:     	stp	d9, d8, [sp, #0x20]
100845874:     	stp	x26, x25, [sp, #0x30]
100845878:     	stp	x24, x23, [sp, #0x40]
10084587c:     	stp	x22, x21, [sp, #0x50]
100845880:     	stp	x20, x19, [sp, #0x60]
100845884:     	stp	x29, x30, [sp, #0x70]
100845888:     	add	x29, sp, #0x70
10084588c:     	mov	x21, x0
100845890:     	mov.16b	v8, v0
100845894:     	fmov	x19, d8
100845898:     	and	x20, x19, #0xffff000000000000
10084589c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
1008458a0:     	cmp	x20, x8
1008458a4:     	b.ne	0x1008458cc <_js_json_stringify+0x60>
1008458a8:     	and	x0, x19, #0xffffffffffff
1008458ac:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
1008458b0:     	mov	x9, #0x7fffffffffff     ; =140737488355327
1008458b4:     	movk	x9, #0xffef, lsl #16
1008458b8:     	cmp	x8, x9
1008458bc:     	b.hi	0x1008458cc <_js_json_stringify+0x60>
1008458c0:     	ldr	w8, [x0, #0x4]
1008458c4:     	cmp	w8, #0x40
1008458c8:     	b.hs	0x10084593c <_js_json_stringify+0xd0>
1008458cc:     	mov.16b	v0, v8
1008458d0:     	bl	0x1004eddbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
1008458d4:     	tbz	w0, #0x0, 0x1008458e0 <_js_json_stringify+0x74>
1008458d8:     	mov	x23, x1
1008458dc:     	b	0x100845e50 <_js_json_stringify+0x5e4>
1008458e0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008458e4:     	cmp	x20, x8
1008458e8:     	b.ne	0x100845950 <_js_json_stringify+0xe4>
1008458ec:     	ands	x19, x19, #0xffffffffffff
1008458f0:     	b.eq	0x100845950 <_js_json_stringify+0xe4>
1008458f4:     	mov	x0, x19
1008458f8:     	bl	0x10050f178 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008458fc:     	cbz	w0, 0x100845950 <_js_json_stringify+0xe4>
100845900:     	ldurb	w8, [x19, #-0x8]
100845904:     	cmp	w8, #0x9
100845908:     	b.ne	0x100845950 <_js_json_stringify+0xe4>
10084590c:     	ldr	w8, [x19, #0x4]
100845910:     	mov	w9, #0x5841             ; =22593
100845914:     	movk	w9, #0x4c5a, lsl #16
100845918:     	cmp	w8, w9
10084591c:     	b.ne	0x100845950 <_js_json_stringify+0xe4>
100845920:     	mov	x0, x19
100845924:     	bl	0x1006883a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100845928:     	cbz	x0, 0x100845950 <_js_json_stringify+0xe4>
10084592c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100845930:     	bfxil	x8, x0, #0, #48
100845934:     	fmov	d8, x8
100845938:     	b	0x100845950 <_js_json_stringify+0xe4>
10084593c:     	bl	0x1004f2ce8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100845940:     	tbnz	w0, #0x0, 0x1008458d8 <_js_json_stringify+0x6c>
100845944:     	mov.16b	v0, v8
100845948:     	bl	0x1004eddbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084594c:     	tbnz	w0, #0x0, 0x1008458d8 <_js_json_stringify+0x6c>
100845950:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100845954:     	add	x0, x0, #0xd78
100845958:     	ldr	x8, [x0]
10084595c:     	blr	x8
100845960:     	mov	x19, x0
100845964:     	ldr	w26, [x0]
100845968:     	add	w8, w26, #0x1
10084596c:     	str	w8, [x0]
100845970:     	cbz	w26, 0x1008459e0 <_js_json_stringify+0x174>
100845974:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100845978:     	add	x0, x0, #0xd00
10084597c:     	ldr	x8, [x0]
100845980:     	blr	x8
100845984:     	ldrb	w8, [x0, #0x20]
100845988:     	cmp	w8, #0x1
10084598c:     	b.ne	0x100845f44 <_js_json_stringify+0x6d8>
100845990:     	ldr	x8, [x0]
100845994:     	cbnz	x8, 0x100845f50 <_js_json_stringify+0x6e4>
100845998:     	mov	x8, #-0x1               ; =-1
10084599c:     	str	x8, [x0]
1008459a0:     	ldr	x20, [x0, #0x18]
1008459a4:     	ldr	x8, [x0, #0x8]
1008459a8:     	cmp	x20, x8
1008459ac:     	b.eq	0x100845e74 <_js_json_stringify+0x608>
1008459b0:     	ldr	x8, [x0, #0x10]
1008459b4:     	mov	w9, #0x18               ; =24
1008459b8:     	madd	x8, x20, x9, x8
1008459bc:     	mov	w9, #0x8                ; =8
1008459c0:     	stp	xzr, x9, [x8]
1008459c4:     	str	xzr, [x8, #0x10]
1008459c8:     	add	x8, x20, #0x1
1008459cc:     	str	x8, [x0, #0x18]
1008459d0:     	ldr	x8, [x0]
1008459d4:     	add	x8, x8, #0x1
1008459d8:     	str	x8, [x0]
1008459dc:     	b	0x100845a6c <_js_json_stringify+0x200>
1008459e0:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1008459e4:     	add	x0, x0, #0xdc0
1008459e8:     	ldr	x8, [x0]
1008459ec:     	blr	x8
1008459f0:     	strb	wzr, [x0]
1008459f4:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1008459f8:     	add	x0, x0, #0xdf0
1008459fc:     	ldr	x8, [x0]
100845a00:     	blr	x8
100845a04:     	strb	wzr, [x0]
100845a08:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
100845a0c:     	ldr	w20, [x8, #0x5a8]
100845a10:     	cmp	w20, #0x300
100845a14:     	b.hs	0x100845ed0 <_js_json_stringify+0x664>
100845a18:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100845a1c:     	ldr	x8, [x8, #0x48]
100845a20:     	cmn	x8, #0x1
100845a24:     	b.eq	0x100845ec0 <_js_json_stringify+0x654>
100845a28:     	mrs	x9, TPIDRRO_EL0
100845a2c:     	and	x9, x9, #0xfffffffffffffff8
100845a30:     	ldr	x0, [x9, x8, lsl #3]
100845a34:     	cbz	x0, 0x100845ec0 <_js_json_stringify+0x654>
100845a38:     	add	x8, x0, x20, lsl #3
100845a3c:     	ldr	x0, [x8, #0x1e8]
100845a40:     	cbz	x0, 0x100845ed0 <_js_json_stringify+0x664>
100845a44:     	str	xzr, [x0]
100845a48:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100845a4c:     	add	x0, x0, #0xd90
100845a50:     	ldr	x8, [x0]
100845a54:     	blr	x8
100845a58:     	ldrb	w8, [x0, #0x20]
100845a5c:     	cbnz	w8, 0x100845f5c <_js_json_stringify+0x6f0>
100845a60:     	ldr	x8, [x0]
100845a64:     	cbnz	x8, 0x100845f84 <_js_json_stringify+0x718>
100845a68:     	str	xzr, [x0, #0x18]
100845a6c:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100845a70:     	add	x0, x0, #0xd30
100845a74:     	ldr	x8, [x0]
100845a78:     	blr	x8
100845a7c:     	mov	x20, x0
100845a80:     	ldrb	w8, [x0, #0x18]
100845a84:     	cmp	w8, #0x1
100845a88:     	b.ne	0x100845ee0 <_js_json_stringify+0x674>
100845a8c:     	ldr	x8, [x0]
100845a90:     	mov	x9, #-0x1               ; =-1
100845a94:     	str	x9, [x0]
100845a98:     	cmn	x8, #0x2
100845a9c:     	b.eq	0x100845f90 <_js_json_stringify+0x724>
100845aa0:     	cmn	x8, #0x1
100845aa4:     	b.eq	0x100845ab8 <_js_json_stringify+0x24c>
100845aa8:     	add	x9, sp, #0x8
100845aac:     	ldur	q0, [x0, #0x8]
100845ab0:     	stur	q0, [x9, #0x8]
100845ab4:     	b	0x100845ac4 <_js_json_stringify+0x258>
100845ab8:     	mov	x8, #0x0                ; =0
100845abc:     	mov	w9, #0x1                ; =1
100845ac0:     	stp	x9, xzr, [sp, #0x10]
100845ac4:     	str	x8, [sp, #0x8]
100845ac8:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100845acc:     	add	x0, x0, #0xd18
100845ad0:     	ldr	x8, [x0]
100845ad4:     	blr	x8
100845ad8:     	ldrb	w8, [x0, #0x20]
100845adc:     	cbnz	w8, 0x100845f10 <_js_json_stringify+0x6a4>
100845ae0:     	ldr	x8, [x0]
100845ae4:     	cbnz	x8, 0x100845f38 <_js_json_stringify+0x6cc>
100845ae8:     	str	xzr, [x0, #0x18]
100845aec:     	add	x1, sp, #0x8
100845af0:     	mov.16b	v0, v8
100845af4:     	mov	x0, x21
100845af8:     	bl	0x1005095ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
100845afc:     	ldp	x21, x22, [sp, #0x10]
100845b00:     	cmp	w22, #0x80, lsl #12     ; =0x80000
100845b04:     	b.hs	0x100845bc4 <_js_json_stringify+0x358>
100845b08:     	cmp	x22, #0x40
100845b0c:     	b.hs	0x100845c88 <_js_json_stringify+0x41c>
100845b10:     	ands	x9, x22, #0x38
100845b14:     	b.eq	0x100845b38 <_js_json_stringify+0x2cc>
100845b18:     	and	x8, x22, #0x38
100845b1c:     	neg	x8, x8
100845b20:     	mov	x10, x21
100845b24:     	ldr	x11, [x10], #0x8
100845b28:     	tst	x11, #0x8080808080808080
100845b2c:     	b.ne	0x100845bac <_js_json_stringify+0x340>
100845b30:     	adds	x8, x8, #0x8
100845b34:     	b.ne	0x100845b24 <_js_json_stringify+0x2b8>
100845b38:     	and	x8, x22, #0x7
100845b3c:     	cbz	x8, 0x100845d0c <_js_json_stringify+0x4a0>
100845b40:     	add	x9, x21, x9
100845b44:     	ldrsb	w10, [x9]
100845b48:     	tbnz	w10, #0x1f, 0x100845bac <_js_json_stringify+0x340>
100845b4c:     	cmp	x8, #0x1
100845b50:     	b.eq	0x100845d0c <_js_json_stringify+0x4a0>
100845b54:     	ldrsb	w10, [x9, #0x1]
100845b58:     	tbnz	w10, #0x1f, 0x100845bac <_js_json_stringify+0x340>
100845b5c:     	cmp	x8, #0x2
100845b60:     	b.eq	0x100845d0c <_js_json_stringify+0x4a0>
100845b64:     	ldrsb	w10, [x9, #0x2]
100845b68:     	tbnz	w10, #0x1f, 0x100845bac <_js_json_stringify+0x340>
100845b6c:     	cmp	x8, #0x3
100845b70:     	b.eq	0x100845d0c <_js_json_stringify+0x4a0>
100845b74:     	ldrsb	w10, [x9, #0x3]
100845b78:     	tbnz	w10, #0x1f, 0x100845bac <_js_json_stringify+0x340>
100845b7c:     	cmp	x8, #0x4
100845b80:     	b.eq	0x100845d0c <_js_json_stringify+0x4a0>
100845b84:     	ldrsb	w10, [x9, #0x4]
100845b88:     	tbnz	w10, #0x1f, 0x100845bac <_js_json_stringify+0x340>
100845b8c:     	cmp	x8, #0x5
100845b90:     	b.eq	0x100845d0c <_js_json_stringify+0x4a0>
100845b94:     	ldrsb	w10, [x9, #0x5]
100845b98:     	tbnz	w10, #0x1f, 0x100845bac <_js_json_stringify+0x340>
100845b9c:     	cmp	x8, #0x6
100845ba0:     	b.eq	0x100845d0c <_js_json_stringify+0x4a0>
100845ba4:     	ldrsb	w8, [x9, #0x6]
100845ba8:     	tbz	w8, #0x1f, 0x100845d0c <_js_json_stringify+0x4a0>
100845bac:     	mov	x0, x21
100845bb0:     	mov	x1, x22
100845bb4:     	mov	x2, x22
100845bb8:     	bl	0x1008dd240 <_js_string_from_bytes_with_capacity>
100845bbc:     	mov	x23, x0
100845bc0:     	b	0x100845e08 <_js_json_stringify+0x59c>
100845bc4:     	and	x8, x22, #0x7fffffffffffffc0
100845bc8:     	add	x8, x21, x8
100845bcc:     	mov	x9, x21
100845bd0:     	ldp	q0, q1, [x9]
100845bd4:     	ldp	q2, q3, [x9, #0x20]
100845bd8:     	orr.16b	v0, v1, v0
100845bdc:     	orr.16b	v1, v2, v3
100845be0:     	orr.16b	v0, v0, v1
100845be4:     	umaxv.16b	b0, v0
100845be8:     	fmov	w10, s0
100845bec:     	tbnz	w10, #0x7, 0x100845c4c <_js_json_stringify+0x3e0>
100845bf0:     	add	x9, x9, #0x40
100845bf4:     	cmp	x9, x8
100845bf8:     	b.ne	0x100845bd0 <_js_json_stringify+0x364>
100845bfc:     	ands	x9, x22, #0x30
100845c00:     	b.eq	0x100845c24 <_js_json_stringify+0x3b8>
100845c04:     	mov	x10, x9
100845c08:     	mov	x11, x8
100845c0c:     	ldr	q0, [x11], #0x10
100845c10:     	umaxv.16b	b0, v0
100845c14:     	fmov	w12, s0
100845c18:     	tbnz	w12, #0x7, 0x100845c4c <_js_json_stringify+0x3e0>
100845c1c:     	subs	x10, x10, #0x10
100845c20:     	b.ne	0x100845c0c <_js_json_stringify+0x3a0>
100845c24:     	and	x10, x22, #0xf
100845c28:     	cbz	x10, 0x100845c44 <_js_json_stringify+0x3d8>
100845c2c:     	add	x8, x8, x9
100845c30:     	ldrsb	w9, [x8]
100845c34:     	tbnz	w9, #0x1f, 0x100845c4c <_js_json_stringify+0x3e0>
100845c38:     	add	x8, x8, #0x1
100845c3c:     	subs	x10, x10, #0x1
100845c40:     	b.ne	0x100845c30 <_js_json_stringify+0x3c4>
100845c44:     	mov	w24, w22
100845c48:     	b	0x100845c80 <_js_json_stringify+0x414>
100845c4c:     	mov	w24, w22
100845c50:     	cbz	x24, 0x100845c80 <_js_json_stringify+0x414>
100845c54:     	mov	x8, x21
100845c58:     	ands	x9, x22, #0x3
100845c5c:     	b.eq	0x100845c78 <_js_json_stringify+0x40c>
100845c60:     	mov	x8, x21
100845c64:     	ldrsb	w10, [x8]
100845c68:     	tbnz	w10, #0x1f, 0x100845d70 <_js_json_stringify+0x504>
100845c6c:     	add	x8, x8, #0x1
100845c70:     	subs	x9, x9, #0x1
100845c74:     	b.ne	0x100845c64 <_js_json_stringify+0x3f8>
100845c78:     	cmp	x24, #0x4
100845c7c:     	b.hs	0x100845d3c <_js_json_stringify+0x4d0>
100845c80:     	mov	x25, x22
100845c84:     	b	0x100845d80 <_js_json_stringify+0x514>
100845c88:     	and	x8, x22, #0x7fffffffffffffc0
100845c8c:     	and	x8, x8, #0xffffffff0007ffff
100845c90:     	add	x8, x21, x8
100845c94:     	mov	x9, x21
100845c98:     	ldp	q0, q1, [x9]
100845c9c:     	ldp	q2, q3, [x9, #0x20]
100845ca0:     	orr.16b	v0, v1, v0
100845ca4:     	orr.16b	v1, v2, v3
100845ca8:     	orr.16b	v0, v0, v1
100845cac:     	umaxv.16b	b0, v0
100845cb0:     	fmov	w10, s0
100845cb4:     	tbnz	w10, #0x7, 0x100845bac <_js_json_stringify+0x340>
100845cb8:     	add	x9, x9, #0x40
100845cbc:     	cmp	x9, x8
100845cc0:     	b.ne	0x100845c98 <_js_json_stringify+0x42c>
100845cc4:     	ands	x9, x22, #0x30
100845cc8:     	b.eq	0x100845cec <_js_json_stringify+0x480>
100845ccc:     	mov	x10, x9
100845cd0:     	mov	x11, x8
100845cd4:     	ldr	q0, [x11], #0x10
100845cd8:     	umaxv.16b	b0, v0
100845cdc:     	fmov	w12, s0
100845ce0:     	tbnz	w12, #0x7, 0x100845bac <_js_json_stringify+0x340>
100845ce4:     	subs	x10, x10, #0x10
100845ce8:     	b.ne	0x100845cd4 <_js_json_stringify+0x468>
100845cec:     	and	x10, x22, #0xf
100845cf0:     	cbz	x10, 0x100845d0c <_js_json_stringify+0x4a0>
100845cf4:     	add	x8, x8, x9
100845cf8:     	ldrsb	w9, [x8]
100845cfc:     	tbnz	w9, #0x1f, 0x100845bac <_js_json_stringify+0x340>
100845d00:     	add	x8, x8, #0x1
100845d04:     	subs	x10, x10, #0x1
100845d08:     	b.ne	0x100845cf8 <_js_json_stringify+0x48c>
100845d0c:     	mov	x0, x22
100845d10:     	bl	0x10034b1ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100845d14:     	mov	x23, x0
100845d18:     	stp	w22, w22, [x0]
100845d1c:     	stp	wzr, wzr, [x0, #0xc]
100845d20:     	str	w22, [x0, #0x8]
100845d24:     	cbz	w22, 0x100845e08 <_js_json_stringify+0x59c>
100845d28:     	and	x2, x22, #0x7ffff
100845d2c:     	mov	x0, x1
100845d30:     	mov	x1, x21
100845d34:     	bl	0x100b622ec <_writev+0x100b622ec>
100845d38:     	b	0x100845e08 <_js_json_stringify+0x59c>
100845d3c:     	add	x9, x21, x24
100845d40:     	ldrsb	w10, [x8]
100845d44:     	tbnz	w10, #0x1f, 0x100845d70 <_js_json_stringify+0x504>
100845d48:     	ldrsb	w10, [x8, #0x1]
100845d4c:     	tbnz	w10, #0x1f, 0x100845d70 <_js_json_stringify+0x504>
100845d50:     	ldrsb	w10, [x8, #0x2]
100845d54:     	tbnz	w10, #0x1f, 0x100845d70 <_js_json_stringify+0x504>
100845d58:     	ldrsb	w10, [x8, #0x3]
100845d5c:     	tbnz	w10, #0x1f, 0x100845d70 <_js_json_stringify+0x504>
100845d60:     	add	x8, x8, #0x4
100845d64:     	cmp	x8, x9
100845d68:     	b.ne	0x100845d40 <_js_json_stringify+0x4d4>
100845d6c:     	b	0x100845c80 <_js_json_stringify+0x414>
100845d70:     	mov	w1, w22
100845d74:     	mov	x0, x21
100845d78:     	bl	0x1005ea960 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
100845d7c:     	mov	x25, x0
100845d80:     	bl	0x1004eff40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
100845d84:     	add	x0, x24, #0x14
100845d88:     	mov	w1, #0x3                ; =3
100845d8c:     	bl	0x1004583c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
100845d90:     	mov	x23, x0
100845d94:     	stp	w25, w22, [x0]
100845d98:     	stp	wzr, wzr, [x0, #0xc]
100845d9c:     	str	w22, [x0, #0x8]
100845da0:     	add	x0, x0, #0x14
100845da4:     	mov	x1, x21
100845da8:     	mov	x2, x24
100845dac:     	bl	0x100b622ec <_writev+0x100b622ec>
100845db0:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
100845db4:     	ldr	w21, [x8, #0x590]
100845db8:     	cmp	w21, #0x300
100845dbc:     	b.hs	0x100845e98 <_js_json_stringify+0x62c>
100845dc0:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100845dc4:     	ldr	x8, [x8, #0x48]
100845dc8:     	cmn	x8, #0x1
100845dcc:     	b.eq	0x100845e88 <_js_json_stringify+0x61c>
100845dd0:     	mrs	x9, TPIDRRO_EL0
100845dd4:     	and	x9, x9, #0xfffffffffffffff8
100845dd8:     	ldr	x0, [x9, x8, lsl #3]
100845ddc:     	cbz	x0, 0x100845e88 <_js_json_stringify+0x61c>
100845de0:     	add	x8, x0, x21, lsl #3
100845de4:     	ldr	x0, [x8, #0x1e8]
100845de8:     	cbz	x0, 0x100845e98 <_js_json_stringify+0x62c>
100845dec:     	ldr	x8, [x0]
100845df0:     	adds	x8, x8, x24
100845df4:     	csinv	x8, x8, xzr, lo
100845df8:     	str	x8, [x0]
100845dfc:     	lsr	x8, x8, #25
100845e00:     	cbz	x8, 0x100845e08 <_js_json_stringify+0x59c>
100845e04:     	bl	0x10045f2f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100845e08:     	ldp	x22, x21, [sp, #0x8]
100845e0c:     	ldrb	w8, [x20, #0x18]
100845e10:     	cmp	w8, #0x1
100845e14:     	b.ne	0x100845ef0 <_js_json_stringify+0x684>
100845e18:     	ldp	x8, x0, [x20]
100845e1c:     	stp	x22, x21, [x20]
100845e20:     	str	xzr, [x20, #0x10]
100845e24:     	sub	x8, x8, #0x1
100845e28:     	cmn	x8, #0x2
100845e2c:     	b.hs	0x100845e34 <_js_json_stringify+0x5c8>
100845e30:     	bl	0x100b5f440 <_mi_free>
100845e34:     	cbz	w26, 0x100845e40 <_js_json_stringify+0x5d4>
100845e38:     	bl	0x100328128 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100845e3c:     	b	0x100845e44 <_js_json_stringify+0x5d8>
100845e40:     	bl	0x100327f58 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100845e44:     	ldr	w8, [x19]
100845e48:     	sub	w8, w8, #0x1
100845e4c:     	str	w8, [x19]
100845e50:     	mov	x0, x23
100845e54:     	ldp	x29, x30, [sp, #0x70]
100845e58:     	ldp	x20, x19, [sp, #0x60]
100845e5c:     	ldp	x22, x21, [sp, #0x50]
100845e60:     	ldp	x24, x23, [sp, #0x40]
100845e64:     	ldp	x26, x25, [sp, #0x30]
100845e68:     	ldp	d9, d8, [sp, #0x20]
100845e6c:     	add	sp, sp, #0x80
100845e70:     	ret
100845e74:     	mov	x22, x0
100845e78:     	add	x0, x0, #0x8
100845e7c:     	bl	0x100b3c1d0 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100845e80:     	mov	x0, x22
100845e84:     	b	0x1008459b0 <_js_json_stringify+0x144>
100845e88:     	bl	0x100b3f87c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100845e8c:     	add	x8, x0, x21, lsl #3
100845e90:     	ldr	x0, [x8, #0x1e8]
100845e94:     	cbnz	x0, 0x100845dec <_js_json_stringify+0x580>
100845e98:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100845e9c:     	add	x0, x0, #0x78
100845ea0:     	bl	0x100b3d09c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100845ea4:     	ldr	x8, [x0]
100845ea8:     	adds	x8, x8, x24
100845eac:     	csinv	x8, x8, xzr, lo
100845eb0:     	str	x8, [x0]
100845eb4:     	lsr	x8, x8, #25
100845eb8:     	cbnz	x8, 0x100845e04 <_js_json_stringify+0x598>
100845ebc:     	b	0x100845e08 <_js_json_stringify+0x59c>
100845ec0:     	bl	0x100b3f87c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100845ec4:     	add	x8, x0, x20, lsl #3
100845ec8:     	ldr	x0, [x8, #0x1e8]
100845ecc:     	cbnz	x0, 0x100845a44 <_js_json_stringify+0x1d8>
100845ed0:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100845ed4:     	add	x0, x0, #0x138
100845ed8:     	bl	0x100b3d09c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100845edc:     	b	0x100845a44 <_js_json_stringify+0x1d8>
100845ee0:     	mov	x0, x20
100845ee4:     	bl	0x100b1ea04 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100845ee8:     	cbnz	x0, 0x100845a8c <_js_json_stringify+0x220>
100845eec:     	b	0x100845f90 <_js_json_stringify+0x724>
100845ef0:     	mov	x0, x20
100845ef4:     	bl	0x100b1ea04 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100845ef8:     	mov	x20, x0
100845efc:     	cbnz	x0, 0x100845e18 <_js_json_stringify+0x5ac>
100845f00:     	cbz	x22, 0x100845f90 <_js_json_stringify+0x724>
100845f04:     	mov	x0, x21
100845f08:     	bl	0x100b5f440 <_mi_free>
100845f0c:     	b	0x100845f90 <_js_json_stringify+0x724>
100845f10:     	cmp	w8, #0x2
100845f14:     	b.eq	0x100845f90 <_js_json_stringify+0x724>
100845f18:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100845f1c:     	add	x1, x1, #0xff8
100845f20:     	mov	x22, x0
100845f24:     	bl	0x100a208dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100845f28:     	mov	x0, x22
100845f2c:     	strb	wzr, [x22, #0x20]
100845f30:     	ldr	x8, [x22]
100845f34:     	cbz	x8, 0x100845ae8 <_js_json_stringify+0x27c>
100845f38:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100845f3c:     	add	x0, x0, #0xdb8
100845f40:     	bl	0x100b12bac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845f44:     	bl	0x100b1eb64 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100845f48:     	cbnz	x0, 0x100845990 <_js_json_stringify+0x124>
100845f4c:     	b	0x100845f90 <_js_json_stringify+0x724>
100845f50:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100845f54:     	add	x0, x0, #0x440
100845f58:     	bl	0x100b12bac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845f5c:     	cmp	w8, #0x1
100845f60:     	b.ne	0x100845f90 <_js_json_stringify+0x724>
100845f64:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100845f68:     	add	x1, x1, #0x998
100845f6c:     	mov	x20, x0
100845f70:     	bl	0x100a208dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100845f74:     	mov	x0, x20
100845f78:     	strb	wzr, [x20, #0x20]
100845f7c:     	ldr	x8, [x20]
100845f80:     	cbz	x8, 0x100845a68 <_js_json_stringify+0x1fc>
100845f84:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100845f88:     	add	x0, x0, #0xd88
100845f8c:     	bl	0x100b12bac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845f90:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100845f94:     	add	x0, x0, #0xc18
100845f98:     	bl	0x100b58a9c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
		...
