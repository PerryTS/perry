
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/outlined-source-token-r28/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001006c6490 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len>:
1006c6490:     	stp	x26, x25, [sp, #-0x50]!
1006c6494:     	stp	x24, x23, [sp, #0x10]
1006c6498:     	stp	x22, x21, [sp, #0x20]
1006c649c:     	stp	x20, x19, [sp, #0x30]
1006c64a0:     	stp	x29, x30, [sp, #0x40]
1006c64a4:     	add	x29, sp, #0x40
1006c64a8:     	subs	x21, x1, x4
1006c64ac:     	ccmp	x2, #0x0, #0x4, hs
1006c64b0:     	b.eq	0x1006c6508 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x78>
1006c64b4:     	cmp	x21, #0x100
1006c64b8:     	b.hi	0x1006c6508 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x78>
1006c64bc:     	adds	x8, x3, #0x1
1006c64c0:     	b.hs	0x1006c6508 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x78>
1006c64c4:     	add	x22, x8, x4
1006c64c8:     	subs	x20, x1, x22
1006c64cc:     	ccmp	x22, x8, #0x0, hi
1006c64d0:     	b.lo	0x1006c6508 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x78>
1006c64d4:     	cmp	x3, x1
1006c64d8:     	b.hs	0x1006c65b0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x120>
1006c64dc:     	ldrb	w9, [x0, x3]
1006c64e0:     	cmp	w9, #0x22
1006c64e4:     	b.ne	0x1006c6508 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x78>
1006c64e8:     	ldrb	w9, [x0, x22]
1006c64ec:     	cmp	w9, #0x22
1006c64f0:     	b.ne	0x1006c6508 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x78>
1006c64f4:     	ldr	w9, [x2, #0x4]
1006c64f8:     	add	x10, x2, #0x14
1006c64fc:     	cmp	x10, x0
1006c6500:     	ccmp	x1, x9, #0x0, eq
1006c6504:     	b.eq	0x1006c6524 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x94>
1006c6508:     	mov	w0, #0x0                ; =0
1006c650c:     	ldp	x29, x30, [sp, #0x40]
1006c6510:     	ldp	x20, x19, [sp, #0x30]
1006c6514:     	ldp	x22, x21, [sp, #0x20]
1006c6518:     	ldp	x24, x23, [sp, #0x10]
1006c651c:     	ldp	x26, x25, [sp], #0x50
1006c6520:     	ret
1006c6524:     	mov	x25, x4
1006c6528:     	mov	x26, x3
1006c652c:     	mov	x23, x2
1006c6530:     	mov	x19, x1
1006c6534:     	mov	x24, x0
1006c6538:     	mov	x1, x8
1006c653c:     	bl	0x10077fd58 <__RNvNvNtNtCsjgY6bXVaRmE_4core5slice5ascii8is_ascii7runtime>
1006c6540:     	cbz	w0, 0x1006c650c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x7c>
1006c6544:     	add	x0, x24, x22
1006c6548:     	mov	x1, x20
1006c654c:     	bl	0x10077fd58 <__RNvNvNtNtCsjgY6bXVaRmE_4core5slice5ascii8is_ascii7runtime>
1006c6550:     	cbz	w0, 0x1006c650c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x7c>
1006c6554:     	add	x0, x25, x26
1006c6558:     	cmp	x0, x19
1006c655c:     	b.hs	0x1006c65c0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x130>
1006c6560:     	ldrb	w9, [x24, x0]
1006c6564:     	cmp	w9, #0xbf
1006c6568:     	b.hi	0x1006c6508 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x78>
1006c656c:     	mov	x8, x19
1006c6570:     	sub	x0, x22, #0x2
1006c6574:     	cmp	x0, x19
1006c6578:     	b.hs	0x1006c65c0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x130>
1006c657c:     	ldrb	w9, [x24, x0]
1006c6580:     	cmp	w9, #0xdf
1006c6584:     	b.hi	0x1006c6508 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x78>
1006c6588:     	sub	x0, x22, #0x3
1006c658c:     	cmp	x0, x8
1006c6590:     	b.hs	0x1006c65c0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x130>
1006c6594:     	ldrb	w8, [x24, x0]
1006c6598:     	cmp	w8, #0xef
1006c659c:     	b.hi	0x1006c6508 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x78>
1006c65a0:     	ldr	w8, [x23]
1006c65a4:     	subs	w1, w8, w21
1006c65a8:     	cset	w0, hs
1006c65ac:     	b	0x1006c650c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length22source_token_utf16_len+0x7c>
1006c65b0:     	adrp	x2, 0x100f1c000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots10stack_maps17LAST_REWRITE_WALK+0x6470>
1006c65b4:     	add	x2, x2, #0x648
1006c65b8:     	mov	x0, x3
1006c65bc:     	bl	0x100b12d0c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
1006c65c0:     	adrp	x2, 0x100f1c000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots10stack_maps17LAST_REWRITE_WALK+0x6470>
1006c65c4:     	add	x2, x2, #0x660
1006c65c8:     	mov	x1, x19
1006c65cc:     	bl	0x100b12d0c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
