
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100244808 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_>:
100244808:     	stp	x29, x30, [sp, #-0x10]!
10024480c:     	mov	x29, sp
100244810:     	ldp	x2, x8, [x0, #0x68]
100244814:     	cmp	x8, x2
100244818:     	b.hs	0x100244850 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x48>
10024481c:     	ldr	x9, [x0, #0x60]
100244820:     	mov	x10, #0x2600            ; =9728
100244824:     	movk	x10, #0x1, lsl #32
100244828:     	ldrb	w11, [x9, x8]
10024482c:     	cmp	w11, #0x20
100244830:     	b.hi	0x100244850 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x48>
100244834:     	lsr	x11, x10, x11
100244838:     	tbz	w11, #0x0, 0x100244850 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x48>
10024483c:     	add	x8, x8, #0x1
100244840:     	str	x8, [x0, #0x70]
100244844:     	cmp	x2, x8
100244848:     	b.ne	0x100244828 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x20>
10024484c:     	b	0x100244994 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x18c>
100244850:     	cmp	x8, x2
100244854:     	b.hs	0x100244994 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x18c>
100244858:     	ldr	x9, [x0, #0x60]
10024485c:     	ldrb	w10, [x9, x8]
100244860:     	cmp	w10, #0x65
100244864:     	b.le	0x1002448b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0xb0>
100244868:     	cmp	w10, #0x73
10024486c:     	b.gt	0x1002448d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0xd0>
100244870:     	cmp	w10, #0x66
100244874:     	b.eq	0x10024490c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x104>
100244878:     	cmp	w10, #0x6e
10024487c:     	b.ne	0x1002448f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0xf0>
100244880:     	add	x1, x8, #0x4
100244884:     	cmp	x1, x2
100244888:     	b.hi	0x100244994 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x18c>
10024488c:     	cmn	x8, #0x5
100244890:     	b.hi	0x1002449cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x1c4>
100244894:     	ldr	w8, [x9, x8]
100244898:     	mov	w9, #0x756e             ; =30062
10024489c:     	movk	w9, #0x6c6c, lsl #16
1002448a0:     	cmp	w8, w9
1002448a4:     	b.ne	0x100244994 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x18c>
1002448a8:     	mov	x8, #0x2                ; =2
1002448ac:     	movk	x8, #0x7ffc, lsl #48
1002448b0:     	str	x1, [x0, #0x70]
1002448b4:     	b	0x1002449a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x198>
1002448b8:     	cmp	w10, #0x22
1002448bc:     	b.eq	0x1002448f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0xe8>
1002448c0:     	cmp	w10, #0x2d
1002448c4:     	b.eq	0x100244904 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0xfc>
1002448c8:     	cmp	w10, #0x5b
1002448cc:     	b.ne	0x1002448f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0xf0>
1002448d0:     	ldp	x29, x30, [sp], #0x10
1002448d4:     	b	0x1002446a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_arrayB9_>
1002448d8:     	cmp	w10, #0x74
1002448dc:     	b.eq	0x100244958 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x150>
1002448e0:     	cmp	w10, #0x7b
1002448e4:     	b.ne	0x1002448f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0xf0>
1002448e8:     	ldp	x29, x30, [sp], #0x10
1002448ec:     	b	0x100246104 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_>
1002448f0:     	ldp	x29, x30, [sp], #0x10
1002448f4:     	b	0x100245e78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_>
1002448f8:     	sub	w8, w10, #0x30
1002448fc:     	cmp	w8, #0x9
100244900:     	b.hi	0x100244994 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x18c>
100244904:     	ldp	x29, x30, [sp], #0x10
100244908:     	b	0x1002449dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E12parse_numberB9_>
10024490c:     	add	x1, x8, #0x5
100244910:     	cmp	x1, x2
100244914:     	b.hi	0x100244994 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x18c>
100244918:     	cmn	x8, #0x6
10024491c:     	b.hi	0x1002449ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x1a4>
100244920:     	add	x8, x9, x8
100244924:     	ldrb	w9, [x8, #0x4]
100244928:     	ldr	w8, [x8]
10024492c:     	orr	x8, x8, x9, lsl #32
100244930:     	mov	x9, #0x6166             ; =24934
100244934:     	movk	x9, #0x736c, lsl #16
100244938:     	movk	x9, #0x65, lsl #32
10024493c:     	cmp	x8, x9
100244940:     	b.ne	0x100244994 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x18c>
100244944:     	str	x1, [x0, #0x70]
100244948:     	mov	x8, #0x2                ; =2
10024494c:     	movk	x8, #0x7ffc, lsl #48
100244950:     	orr	x8, x8, #0x1
100244954:     	b	0x1002449a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x198>
100244958:     	add	x1, x8, #0x4
10024495c:     	cmp	x1, x2
100244960:     	b.hi	0x100244994 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x18c>
100244964:     	cmn	x8, #0x5
100244968:     	b.hi	0x1002449bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x1b4>
10024496c:     	ldr	w8, [x9, x8]
100244970:     	mov	w9, #0x7274             ; =29300
100244974:     	movk	w9, #0x6575, lsl #16
100244978:     	cmp	w8, w9
10024497c:     	b.ne	0x100244994 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x18c>
100244980:     	str	x1, [x0, #0x70]
100244984:     	mov	x8, #0x2                ; =2
100244988:     	movk	x8, #0x7ffc, lsl #48
10024498c:     	add	x8, x8, #0x2
100244990:     	b	0x1002449a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_+0x198>
100244994:     	mov	x8, #0x2                ; =2
100244998:     	movk	x8, #0x7ffc, lsl #48
10024499c:     	strb	wzr, [x0, #0xd4]
1002449a0:     	mov	x0, x8
1002449a4:     	ldp	x29, x30, [sp], #0x10
1002449a8:     	ret
1002449ac:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002449b0:     	add	x3, x3, #0x5c0
1002449b4:     	mov	x0, x8
1002449b8:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1002449bc:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002449c0:     	add	x3, x3, #0x5a8
1002449c4:     	mov	x0, x8
1002449c8:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1002449cc:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002449d0:     	add	x3, x3, #0x590
1002449d4:     	mov	x0, x8
1002449d8:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
