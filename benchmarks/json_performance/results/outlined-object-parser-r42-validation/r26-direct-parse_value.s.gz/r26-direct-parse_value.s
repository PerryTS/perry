
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/outlined-object-parser-r42/main-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001002448c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value>:
1002448c8:     	stp	x29, x30, [sp, #-0x10]!
1002448cc:     	mov	x29, sp
1002448d0:     	ldp	x2, x8, [x0, #0x68]
1002448d4:     	cmp	x8, x2
1002448d8:     	b.hs	0x100244910 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x48>
1002448dc:     	ldr	x9, [x0, #0x60]
1002448e0:     	mov	x10, #0x2600            ; =9728
1002448e4:     	movk	x10, #0x1, lsl #32
1002448e8:     	ldrb	w11, [x9, x8]
1002448ec:     	cmp	w11, #0x20
1002448f0:     	b.hi	0x100244910 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x48>
1002448f4:     	lsr	x11, x10, x11
1002448f8:     	tbz	w11, #0x0, 0x100244910 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x48>
1002448fc:     	add	x8, x8, #0x1
100244900:     	str	x8, [x0, #0x70]
100244904:     	cmp	x2, x8
100244908:     	b.ne	0x1002448e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x20>
10024490c:     	b	0x100244a54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x18c>
100244910:     	cmp	x8, x2
100244914:     	b.hs	0x100244a54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x18c>
100244918:     	ldr	x9, [x0, #0x60]
10024491c:     	ldrb	w10, [x9, x8]
100244920:     	cmp	w10, #0x65
100244924:     	b.le	0x100244978 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0xb0>
100244928:     	cmp	w10, #0x73
10024492c:     	b.gt	0x100244998 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0xd0>
100244930:     	cmp	w10, #0x66
100244934:     	b.eq	0x1002449cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x104>
100244938:     	cmp	w10, #0x6e
10024493c:     	b.ne	0x1002449b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0xf0>
100244940:     	add	x1, x8, #0x4
100244944:     	cmp	x1, x2
100244948:     	b.hi	0x100244a54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x18c>
10024494c:     	cmn	x8, #0x5
100244950:     	b.hi	0x100244a8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x1c4>
100244954:     	ldr	w8, [x9, x8]
100244958:     	mov	w9, #0x756e             ; =30062
10024495c:     	movk	w9, #0x6c6c, lsl #16
100244960:     	cmp	w8, w9
100244964:     	b.ne	0x100244a54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x18c>
100244968:     	mov	x8, #0x2                ; =2
10024496c:     	movk	x8, #0x7ffc, lsl #48
100244970:     	str	x1, [x0, #0x70]
100244974:     	b	0x100244a60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x198>
100244978:     	cmp	w10, #0x22
10024497c:     	b.eq	0x1002449b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0xe8>
100244980:     	cmp	w10, #0x2d
100244984:     	b.eq	0x1002449c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0xfc>
100244988:     	cmp	w10, #0x5b
10024498c:     	b.ne	0x1002449b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0xf0>
100244990:     	ldp	x29, x30, [sp], #0x10
100244994:     	b	0x100244768 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_array>
100244998:     	cmp	w10, #0x74
10024499c:     	b.eq	0x100244a18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x150>
1002449a0:     	cmp	w10, #0x7b
1002449a4:     	b.ne	0x1002449b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0xf0>
1002449a8:     	ldp	x29, x30, [sp], #0x10
1002449ac:     	b	0x100246198 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped>
1002449b0:     	ldp	x29, x30, [sp], #0x10
1002449b4:     	b	0x100245dc8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value>
1002449b8:     	sub	w8, w10, #0x30
1002449bc:     	cmp	w8, #0x9
1002449c0:     	b.hi	0x100244a54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x18c>
1002449c4:     	ldp	x29, x30, [sp], #0x10
1002449c8:     	b	0x100244a9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser12parse_number>
1002449cc:     	add	x1, x8, #0x5
1002449d0:     	cmp	x1, x2
1002449d4:     	b.hi	0x100244a54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x18c>
1002449d8:     	cmn	x8, #0x6
1002449dc:     	b.hi	0x100244a6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x1a4>
1002449e0:     	add	x8, x9, x8
1002449e4:     	ldrb	w9, [x8, #0x4]
1002449e8:     	ldr	w8, [x8]
1002449ec:     	orr	x8, x8, x9, lsl #32
1002449f0:     	mov	x9, #0x6166             ; =24934
1002449f4:     	movk	x9, #0x736c, lsl #16
1002449f8:     	movk	x9, #0x65, lsl #32
1002449fc:     	cmp	x8, x9
100244a00:     	b.ne	0x100244a54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x18c>
100244a04:     	str	x1, [x0, #0x70]
100244a08:     	mov	x8, #0x2                ; =2
100244a0c:     	movk	x8, #0x7ffc, lsl #48
100244a10:     	orr	x8, x8, #0x1
100244a14:     	b	0x100244a60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x198>
100244a18:     	add	x1, x8, #0x4
100244a1c:     	cmp	x1, x2
100244a20:     	b.hi	0x100244a54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x18c>
100244a24:     	cmn	x8, #0x5
100244a28:     	b.hi	0x100244a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x1b4>
100244a2c:     	ldr	w8, [x9, x8]
100244a30:     	mov	w9, #0x7274             ; =29300
100244a34:     	movk	w9, #0x6575, lsl #16
100244a38:     	cmp	w8, w9
100244a3c:     	b.ne	0x100244a54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x18c>
100244a40:     	str	x1, [x0, #0x70]
100244a44:     	mov	x8, #0x2                ; =2
100244a48:     	movk	x8, #0x7ffc, lsl #48
100244a4c:     	add	x8, x8, #0x2
100244a50:     	b	0x100244a60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value+0x198>
100244a54:     	mov	x8, #0x2                ; =2
100244a58:     	movk	x8, #0x7ffc, lsl #48
100244a5c:     	strb	wzr, [x0, #0xd4]
100244a60:     	mov	x0, x8
100244a64:     	ldp	x29, x30, [sp], #0x10
100244a68:     	ret
100244a6c:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100244a70:     	add	x3, x3, #0x5c0
100244a74:     	mov	x0, x8
100244a78:     	bl	0x100b129cc <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100244a7c:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100244a80:     	add	x3, x3, #0x5a8
100244a84:     	mov	x0, x8
100244a88:     	bl	0x100b129cc <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100244a8c:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100244a90:     	add	x3, x3, #0x590
100244a94:     	mov	x0, x8
100244a98:     	bl	0x100b129cc <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
