
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/outlined-object-parser-r42/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100246104 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_>:
100246104:     	stp	x28, x27, [sp, #-0x60]!
100246108:     	stp	x26, x25, [sp, #0x10]
10024610c:     	stp	x24, x23, [sp, #0x20]
100246110:     	stp	x22, x21, [sp, #0x30]
100246114:     	stp	x20, x19, [sp, #0x40]
100246118:     	stp	x29, x30, [sp, #0x50]
10024611c:     	add	x29, sp, #0x50
100246120:     	sub	sp, sp, #0x250
100246124:     	mov	x19, x0
100246128:     	ldp	x8, x9, [x0, #0x68]
10024612c:     	add	x9, x9, #0x1
100246130:     	str	x9, [x0, #0x70]
100246134:     	cmp	x9, x8
100246138:     	b.hs	0x10024616c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x68>
10024613c:     	ldr	x10, [x19, #0x60]
100246140:     	mov	x11, #0x2600            ; =9728
100246144:     	movk	x11, #0x1, lsl #32
100246148:     	ldrb	w12, [x10, x9]
10024614c:     	cmp	w12, #0x20
100246150:     	b.hi	0x10024616c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x68>
100246154:     	lsr	x12, x11, x12
100246158:     	tbz	w12, #0x0, 0x10024616c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x68>
10024615c:     	add	x9, x9, #0x1
100246160:     	str	x9, [x19, #0x70]
100246164:     	cmp	x8, x9
100246168:     	b.ne	0x100246148 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x44>
10024616c:     	ldrb	w8, [x19, #0xd5]
100246170:     	tbz	w8, #0x0, 0x10024619c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x98>
100246174:     	strb	wzr, [x19, #0xd5]
100246178:     	ldr	x22, [x19, #0x78]
10024617c:     	ldp	q0, q1, [x19, #0x80]
100246180:     	stur	q0, [sp, #0xb8]
100246184:     	stur	q1, [sp, #0xc8]
100246188:     	ldp	q0, q1, [x19, #0xa0]
10024618c:     	stur	q0, [sp, #0xd8]
100246190:     	stur	q1, [sp, #0xe8]
100246194:     	ldr	x21, [x19, #0xc0]
100246198:     	b	0x1002461cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc8>
10024619c:     	mov	w26, #0x0               ; =0
1002461a0:     	mov	x8, #0x0                ; =0
1002461a4:     	ldr	x22, [x19, #0x78]
1002461a8:     	cbz	x22, 0x100246ee4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xde0>
1002461ac:     	ldr	x21, [x19, #0xc0]
1002461b0:     	cbz	x21, 0x1002461e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe0>
1002461b4:     	ldp	q0, q1, [x19, #0x80]
1002461b8:     	stur	q0, [sp, #0xb8]
1002461bc:     	stur	q1, [sp, #0xc8]
1002461c0:     	ldp	q0, q1, [x19, #0xa0]
1002461c4:     	stur	q0, [sp, #0xd8]
1002461c8:     	stur	q1, [sp, #0xe8]
1002461cc:     	ldr	w8, [x19, #0xd0]
1002461d0:     	stp	x22, x21, [sp, #0xf8]
1002461d4:     	str	w8, [sp, #0x84]
1002461d8:     	str	w8, [sp, #0x108]
1002461dc:     	mov	w8, #0x1                ; =1
1002461e0:     	mov	w26, #0x1               ; =1
1002461e4:     	str	x8, [sp, #0xb0]
1002461e8:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
1002461ec:     	add	x0, x0, #0xce8
1002461f0:     	ldr	x8, [x0]
1002461f4:     	blr	x8
1002461f8:     	mov	x20, x0
1002461fc:     	ldrb	w8, [x0, #0x20]
100246200:     	cbnz	w8, 0x100247254 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1150>
100246204:     	ldr	x8, [x20]
100246208:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10024620c:     	cmp	x8, x9
100246210:     	b.hs	0x100247280 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x117c>
100246214:     	ldr	x27, [x20, #0x18]
100246218:     	ldp	x23, x28, [x19, #0x68]
10024621c:     	cmp	x28, x23
100246220:     	b.hs	0x100246254 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x150>
100246224:     	ldr	x8, [x19, #0x60]
100246228:     	ldrb	w8, [x8, x28]
10024622c:     	cmp	w8, #0x7d
100246230:     	b.ne	0x100246254 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x150>
100246234:     	add	x8, x28, #0x1
100246238:     	str	x8, [x19, #0x70]
10024623c:     	ldr	x8, [x19, #0x78]
100246240:     	cbnz	x8, 0x100246ee8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xde4>
100246244:     	ldr	x1, [x19, #0xc0]
100246248:     	cbz	x1, 0x100246ee8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xde4>
10024624c:     	ldr	w2, [x19, #0xd0]
100246250:     	b	0x100246f08 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe04>
100246254:     	movi.2d	v0, #0000000000000000
100246258:     	stp	q0, q0, [sp, #0x130]
10024625c:     	stp	q0, q0, [sp, #0x110]
100246260:     	adrp	x1, 0x100ca1000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6fb0>
100246264:     	add	x1, x1, #0xb40
100246268:     	add	x0, sp, #0x158
10024626c:     	mov	w2, #0x40               ; =64
100246270:     	bl	0x100b66c10 <_writev+0x100b66c10>
100246274:     	mov	x24, #0x0               ; =0
100246278:     	str	xzr, [sp, #0xa0]
10024627c:     	mov	x8, #-0x1               ; =-1
100246280:     	str	x8, [sp, #0x198]
100246284:     	add	x8, sp, #0xb0
100246288:     	add	x8, x8, #0x8
10024628c:     	stp	x8, xzr, [sp, #0x88]
100246290:     	mov	x25, #0x2600            ; =9728
100246294:     	movk	x25, #0x1, lsl #32
100246298:     	adrp	x8, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4fb0>
10024629c:     	ldr	q0, [x8, #0x8d0]
1002462a0:     	str	q0, [sp, #0x60]
1002462a4:     	adrp	x8, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4fb0>
1002462a8:     	ldr	q0, [x8, #0x8e0]
1002462ac:     	str	q0, [sp, #0x50]
1002462b0:     	mov	x11, x26
1002462b4:     	mov	x8, x26
1002462b8:     	str	x21, [sp, #0x78]
1002462bc:     	str	w26, [sp, #0x9c]
1002462c0:     	str	w8, [sp, #0x98]
1002462c4:     	cmp	x28, x23
1002462c8:     	b.hs	0x1002462f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1f4>
1002462cc:     	ldr	x8, [x19, #0x60]
1002462d0:     	ldrb	w9, [x8, x28]
1002462d4:     	cmp	w9, #0x20
1002462d8:     	b.hi	0x1002462f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1f4>
1002462dc:     	lsr	x9, x25, x9
1002462e0:     	tbz	w9, #0x0, 0x1002462f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1f4>
1002462e4:     	add	x28, x28, #0x1
1002462e8:     	str	x28, [x19, #0x70]
1002462ec:     	cmp	x23, x28
1002462f0:     	b.ne	0x1002462d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1cc>
1002462f4:     	mov	x28, x23
1002462f8:     	str	x24, [sp, #0xa8]
1002462fc:     	cbz	w26, 0x1002463b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b4>
100246300:     	cmp	x24, x22
100246304:     	cset	w8, lo
100246308:     	tst	w11, w8
10024630c:     	b.eq	0x1002463b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b4>
100246310:     	cmp	x24, #0x8
100246314:     	b.hs	0x100247328 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1224>
100246318:     	mov	x26, x11
10024631c:     	cmp	x28, x23
100246320:     	b.hs	0x1002463bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
100246324:     	ldr	x8, [sp, #0x88]
100246328:     	ldr	x9, [x8, x24, lsl #3]
10024632c:     	cbz	x9, 0x1002463bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
100246330:     	ldr	x10, [x19, #0x60]
100246334:     	ldrb	w8, [x10, x28]
100246338:     	cmp	w8, #0x22
10024633c:     	b.ne	0x1002463bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
100246340:     	add	x11, x28, #0x1
100246344:     	ldr	w14, [x9, #0x4]
100246348:     	add	x8, x11, x14
10024634c:     	cmp	x8, x23
100246350:     	ccmp	x8, x28, #0x0, lo
100246354:     	b.ls	0x1002463bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
100246358:     	ldrb	w12, [x10, x8]
10024635c:     	cmp	w12, #0x22
100246360:     	b.ne	0x1002463bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
100246364:     	add	x23, x10, x11
100246368:     	cbz	w14, 0x1002463a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2a0>
10024636c:     	add	x9, x9, #0x14
100246370:     	mov	x10, x14
100246374:     	mov	x11, x23
100246378:     	ldrb	w12, [x11], #0x1
10024637c:     	cmp	w12, #0x5c
100246380:     	b.eq	0x1002463bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
100246384:     	cmp	w12, #0x22
100246388:     	b.eq	0x1002463bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
10024638c:     	ldrb	w13, [x9], #0x1
100246390:     	cmp	w12, #0x20
100246394:     	ccmp	w12, w13, #0x0, hs
100246398:     	b.ne	0x1002463bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
10024639c:     	subs	x10, x10, #0x1
1002463a0:     	b.ne	0x100246378 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x274>
1002463a4:     	add	x8, x8, #0x1
1002463a8:     	str	x8, [x19, #0x70]
1002463ac:     	mov	w28, #0x1               ; =1
1002463b0:     	mov	x24, #-0x1              ; =-1
1002463b4:     	b	0x1002463dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2d8>
1002463b8:     	mov	x26, x11
1002463bc:     	sub	x0, x29, #0x80
1002463c0:     	mov	x1, x19
1002463c4:     	bl	0x1002458b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_bytesB9_>
1002463c8:     	ldur	x24, [x29, #-0x80]
1002463cc:     	cmn	x24, #0x2
1002463d0:     	b.eq	0x100246f50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe4c>
1002463d4:     	mov	w28, #0x0               ; =0
1002463d8:     	ldp	x23, x14, [x29, #-0x78]
1002463dc:     	ldp	x9, x8, [x19, #0x68]
1002463e0:     	cmp	x8, x9
1002463e4:     	b.hs	0x100246dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcbc>
1002463e8:     	ldr	x10, [x19, #0x60]
1002463ec:     	ldrb	w11, [x10, x8]
1002463f0:     	cmp	w11, #0x3a
1002463f4:     	b.hi	0x100246dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcbc>
1002463f8:     	lsr	x12, x25, x11
1002463fc:     	tbz	w12, #0x0, 0x100246414 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x310>
100246400:     	add	x8, x8, #0x1
100246404:     	str	x8, [x19, #0x70]
100246408:     	cmp	x9, x8
10024640c:     	b.ne	0x1002463ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2e8>
100246410:     	b	0x100246dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcbc>
100246414:     	cmp	x11, #0x3a
100246418:     	b.ne	0x100246dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcbc>
10024641c:     	str	x14, [sp, #0x48]
100246420:     	add	x8, x8, #0x1
100246424:     	str	x8, [x19, #0x70]
100246428:     	mov	x0, x19
10024642c:     	bl	0x100244808 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_>
100246430:     	ldrb	w8, [x19, #0xd4]
100246434:     	tbz	w8, #0x0, 0x100246dc4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcc0>
100246438:     	ldr	x9, [sp, #0x198]
10024643c:     	cmn	x9, #0x1
100246440:     	stp	x0, x23, [sp, #0x38]
100246444:     	ldr	x17, [sp, #0x48]
100246448:     	b.eq	0x10024650c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x408>
10024644c:     	ldr	x8, [sp, #0x1c8]
100246450:     	ldr	x28, [sp, #0x1a8]
100246454:     	cmn	x8, #0x1
100246458:     	b.eq	0x10024655c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x458>
10024645c:     	ldr	x11, [sp, #0x208]
100246460:     	ldr	x8, [sp, #0x200]
100246464:     	ldr	x10, [sp, #0x210]
100246468:     	ldr	x9, [sp, #0x218]
10024646c:     	eor	x11, x11, x17
100246470:     	mov	x13, #0x7f2d            ; =32557
100246474:     	movk	x13, #0x4c95, lsl #16
100246478:     	movk	x13, #0xf42d, lsl #32
10024647c:     	movk	x13, #0x5851, lsl #48
100246480:     	mul	x12, x11, x13
100246484:     	umulh	x11, x11, x13
100246488:     	eor	x11, x11, x12
10024648c:     	add	x11, x17, x11
100246490:     	mul	x11, x11, x13
100246494:     	cmp	x17, #0x8
100246498:     	str	x28, [sp, #0x28]
10024649c:     	b.ls	0x1002465b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x4ac>
1002464a0:     	cmp	x17, #0x10
1002464a4:     	b.ls	0x100246658 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x554>
1002464a8:     	add	x12, x23, x17
1002464ac:     	ldp	x12, x13, [x12, #-0x10]
1002464b0:     	eor	x12, x10, x12
1002464b4:     	eor	x13, x13, x9
1002464b8:     	mul	x14, x13, x12
1002464bc:     	umulh	x12, x13, x12
1002464c0:     	eor	x12, x12, x14
1002464c4:     	add	x11, x11, x8
1002464c8:     	eor	x11, x11, x12
1002464cc:     	ror	x11, x11, #0x29
1002464d0:     	mov	x13, x23
1002464d4:     	mov	x12, x17
1002464d8:     	ldp	x15, x14, [x13], #0x10
1002464dc:     	sub	x12, x12, #0x10
1002464e0:     	eor	x15, x10, x15
1002464e4:     	eor	x14, x14, x9
1002464e8:     	mul	x16, x14, x15
1002464ec:     	umulh	x14, x14, x15
1002464f0:     	eor	x14, x14, x16
1002464f4:     	add	x11, x11, x8
1002464f8:     	eor	x11, x11, x14
1002464fc:     	ror	x11, x11, #0x29
100246500:     	cmp	x12, #0x10
100246504:     	b.hi	0x1002464d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x3d4>
100246508:     	b	0x100246734 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x630>
10024650c:     	ldr	w8, [sp, #0x98]
100246510:     	tbz	w8, #0x0, 0x1002465d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x4cc>
100246514:     	ldr	w8, [sp, #0x9c]
100246518:     	tbz	w8, #0x0, 0x10024731c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1218>
10024651c:     	ldr	x8, [sp, #0xa8]
100246520:     	cmp	x8, x22
100246524:     	mov	x11, x26
100246528:     	ldr	w26, [sp, #0x9c]
10024652c:     	b.hs	0x100246870 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x76c>
100246530:     	tbz	w28, #0x0, 0x10024682c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x728>
100246534:     	ldr	x0, [sp, #0xa8]
100246538:     	cmp	x0, #0x7
10024653c:     	ldr	x9, [sp, #0x30]
100246540:     	b.hi	0x100247360 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x125c>
100246544:     	ldr	x8, [sp, #0x88]
100246548:     	ldr	x10, [x8, x0, lsl #3]
10024654c:     	add	x0, x0, #0x1
100246550:     	str	x0, [sp, #0xa8]
100246554:     	mov	w8, #0x1                ; =1
100246558:     	b	0x10024688c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x788>
10024655c:     	str	x9, [sp, #0x10]
100246560:     	ldr	x1, [sp, #0x1a0]
100246564:     	cmp	x28, #0x80
100246568:     	b.ne	0x1002465f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x4ec>
10024656c:     	mov	w8, #0x1                ; =1
100246570:     	strb	w8, [x19, #0xd6]
100246574:     	add	x8, sp, #0x198
100246578:     	add	x0, x8, #0x30
10024657c:     	mov	x21, x1
100246580:     	bl	0x10028b55c <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex9from_keys>
100246584:     	ldr	x17, [sp, #0x48]
100246588:     	ldr	x8, [sp, #0x1c8]
10024658c:     	cmn	x8, #0x1
100246590:     	b.ne	0x10024645c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x358>
100246594:     	mov	x0, x23
100246598:     	mov	x1, x17
10024659c:     	bl	0x10032abfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
1002465a0:     	mov	x23, x0
1002465a4:     	add	x13, x21, #0x400
1002465a8:     	mov	x10, x21
1002465ac:     	b	0x100246610 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x50c>
1002465b0:     	cmp	x17, #0x1
1002465b4:     	b.ls	0x100246668 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x564>
1002465b8:     	add	x13, x23, x17
1002465bc:     	cmp	x17, #0x3
1002465c0:     	b.ls	0x100246700 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x5fc>
1002465c4:     	ldr	w12, [x23]
1002465c8:     	ldur	w13, [x13, #-0x4]
1002465cc:     	b	0x100246714 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x610>
1002465d0:     	mov	x0, x23
1002465d4:     	mov	x1, x17
1002465d8:     	bl	0x10032abfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
1002465dc:     	mov	x10, x0
1002465e0:     	mov	w8, #0x0                ; =0
1002465e4:     	mov	x11, x26
1002465e8:     	ldr	w26, [sp, #0x9c]
1002465ec:     	b	0x100246888 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x784>
1002465f0:     	str	x1, [sp, #0x8]
1002465f4:     	mov	x0, x23
1002465f8:     	mov	x1, x17
1002465fc:     	bl	0x10032abfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100246600:     	mov	x23, x0
100246604:     	cbz	x28, 0x100246c54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb50>
100246608:     	ldr	x10, [sp, #0x8]
10024660c:     	add	x13, x10, x28, lsl #3
100246610:     	ldr	x8, [sp, #0xa8]
100246614:     	cmp	x8, #0x0
100246618:     	cset	w8, eq
10024661c:     	ldr	w9, [sp, #0x98]
100246620:     	orr	w8, w8, w9
100246624:     	tbz	w8, #0x0, 0x100246678 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x574>
100246628:     	mov	x0, #0x0                ; =0
10024662c:     	mov	x8, x10
100246630:     	mov	x11, x26
100246634:     	ldr	w26, [sp, #0x9c]
100246638:     	ldr	x9, [x8], #0x8
10024663c:     	cmp	x9, x23
100246640:     	b.eq	0x1002466e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x5e0>
100246644:     	add	x0, x0, #0x1
100246648:     	cmp	x8, x13
10024664c:     	b.ne	0x100246638 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x534>
100246650:     	ldr	x9, [sp, #0x30]
100246654:     	b	0x100246c78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb74>
100246658:     	ldr	x12, [x23]
10024665c:     	add	x13, x23, x17
100246660:     	ldur	x13, [x13, #-0x8]
100246664:     	b	0x100246714 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x610>
100246668:     	b.ne	0x10024670c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x608>
10024666c:     	ldrb	w12, [x23]
100246670:     	mov	x13, x12
100246674:     	b	0x100246714 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x610>
100246678:     	str	x28, [sp, #0x28]
10024667c:     	str	x27, [sp, #0x18]
100246680:     	mov	x28, #0x0               ; =0
100246684:     	str	x10, [sp, #0x8]
100246688:     	mov	x27, x10
10024668c:     	ldr	x2, [sp, #0x48]
100246690:     	b	0x1002466a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x59c>
100246694:     	sub	x28, x28, #0x1
100246698:     	cmp	x27, x13
10024669c:     	b.eq	0x100246c64 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb60>
1002466a0:     	ldr	x8, [x27], #0x8
1002466a4:     	cmp	x8, x23
1002466a8:     	b.eq	0x1002466d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x5d0>
1002466ac:     	ldr	w9, [x8, #0x4]
1002466b0:     	cmp	x2, x9
1002466b4:     	b.ne	0x100246694 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x590>
1002466b8:     	add	x0, x8, #0x14
1002466bc:     	ldr	x1, [sp, #0x40]
1002466c0:     	mov	x21, x13
1002466c4:     	bl	0x100b66be0 <_writev+0x100b66be0>
1002466c8:     	mov	x13, x21
1002466cc:     	ldr	x2, [sp, #0x48]
1002466d0:     	cbnz	w0, 0x100246694 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x590>
1002466d4:     	neg	x0, x28
1002466d8:     	ldr	x27, [sp, #0x18]
1002466dc:     	mov	x11, x26
1002466e0:     	ldr	w26, [sp, #0x9c]
1002466e4:     	ldr	x9, [sp, #0x30]
1002466e8:     	cmp	x0, x9
1002466ec:     	b.hs	0x100247350 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x124c>
1002466f0:     	ldr	x8, [sp, #0x20]
1002466f4:     	ldr	x10, [sp, #0x38]
1002466f8:     	str	x10, [x8, x0, lsl #3]
1002466fc:     	b	0x100246cb4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbb0>
100246700:     	ldrh	w12, [x23]
100246704:     	ldurb	w13, [x13, #-0x1]
100246708:     	b	0x100246714 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x610>
10024670c:     	mov	x12, #0x0               ; =0
100246710:     	mov	x13, #0x0               ; =0
100246714:     	eor	x10, x12, x10
100246718:     	eor	x9, x13, x9
10024671c:     	mul	x12, x9, x10
100246720:     	umulh	x9, x9, x10
100246724:     	eor	x9, x9, x12
100246728:     	add	x10, x11, x8
10024672c:     	eor	x9, x10, x9
100246730:     	ror	x11, x9, #0x29
100246734:     	mul	x9, x11, x8
100246738:     	umulh	x8, x11, x8
10024673c:     	eor	x8, x8, x9
100246740:     	neg	w9, w11
100246744:     	ror	x28, x8, x9
100246748:     	ldr	x4, [sp, #0x1a0]
10024674c:     	add	x8, sp, #0x198
100246750:     	add	x0, x8, #0x30
100246754:     	mov	x1, x28
100246758:     	mov	x2, x23
10024675c:     	mov	x3, x17
100246760:     	ldr	x5, [sp, #0x28]
100246764:     	bl	0x10028b18c <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11find_hashed>
100246768:     	tbz	w0, #0x0, 0x100246790 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x68c>
10024676c:     	ldr	x9, [sp, #0x30]
100246770:     	cmp	x1, x9
100246774:     	b.hs	0x10024733c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1238>
100246778:     	mov	x11, x26
10024677c:     	ldr	x8, [sp, #0x20]
100246780:     	ldr	x10, [sp, #0x38]
100246784:     	str	x10, [x8, x1, lsl #3]
100246788:     	ldr	w26, [sp, #0x9c]
10024678c:     	b	0x100246cb4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbb0>
100246790:     	str	x27, [sp, #0x18]
100246794:     	cmn	x24, #0x1
100246798:     	b.eq	0x1002467ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x6a8>
10024679c:     	mov	x0, x23
1002467a0:     	ldr	x1, [sp, #0x48]
1002467a4:     	bl	0x10034e1b0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
1002467a8:     	b	0x1002467bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x6b8>
1002467ac:     	add	x0, x19, #0x20
1002467b0:     	mov	x1, x23
1002467b4:     	ldr	x2, [sp, #0x48]
1002467b8:     	bl	0x1005eddc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>
1002467bc:     	mov	x27, x0
1002467c0:     	add	x8, sp, #0x198
1002467c4:     	add	x0, x8, #0x30
1002467c8:     	mov	x1, x28
1002467cc:     	ldr	x2, [sp, #0x28]
1002467d0:     	bl	0x10028b360 <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11insert_hash>
1002467d4:     	ldr	x23, [sp, #0x1a8]
1002467d8:     	ldr	x8, [sp, #0x198]
1002467dc:     	cmp	x23, x8
1002467e0:     	b.eq	0x100246d44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc40>
1002467e4:     	ldr	x8, [sp, #0x1a0]
1002467e8:     	ldr	x9, [sp, #0x1b0]
1002467ec:     	str	x27, [x8, x23, lsl #3]
1002467f0:     	add	x8, x23, #0x1
1002467f4:     	str	x8, [sp, #0x1a8]
1002467f8:     	ldr	x23, [sp, #0x1c0]
1002467fc:     	cmp	x23, x9
100246800:     	b.eq	0x100246d50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc4c>
100246804:     	ldr	x8, [sp, #0x1b8]
100246808:     	str	x8, [sp, #0x20]
10024680c:     	ldr	x9, [sp, #0x38]
100246810:     	str	x9, [x8, x23, lsl #3]
100246814:     	add	x9, x23, #0x1
100246818:     	str	x9, [sp, #0x1c0]
10024681c:     	ldr	x27, [sp, #0x18]
100246820:     	mov	x11, x26
100246824:     	ldr	w26, [sp, #0x9c]
100246828:     	b	0x100246cb4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbb0>
10024682c:     	ldr	x0, [sp, #0xa8]
100246830:     	cmp	x0, #0x8
100246834:     	b.hs	0x100247370 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x126c>
100246838:     	ldr	x8, [sp, #0x88]
10024683c:     	ldr	x9, [x8, x0, lsl #3]
100246840:     	ldr	w8, [x9, #0x4]
100246844:     	cmp	x17, x8
100246848:     	b.ne	0x100246870 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x76c>
10024684c:     	add	x0, x9, #0x14
100246850:     	mov	x1, x23
100246854:     	mov	x2, x17
100246858:     	mov	x23, x11
10024685c:     	mov	x28, x9
100246860:     	bl	0x100b66be0 <_writev+0x100b66be0>
100246864:     	mov	x11, x23
100246868:     	ldp	x23, x17, [sp, #0x40]
10024686c:     	cbz	w0, 0x100246d60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc5c>
100246870:     	mov	x0, x23
100246874:     	mov	x1, x17
100246878:     	bl	0x10032abfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
10024687c:     	mov	x10, x0
100246880:     	mov	w11, #0x0               ; =0
100246884:     	mov	w8, #0x0                ; =0
100246888:     	ldr	x9, [sp, #0x30]
10024688c:     	ldp	x1, x12, [sp, #0xa0]
100246890:     	cmp	x12, #0x0
100246894:     	str	w8, [sp, #0x98]
100246898:     	csinc	w28, w8, wzr, ne
10024689c:     	cmp	x1, #0x9
1002468a0:     	b.hs	0x1002472e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11dc>
1002468a4:     	ldr	x2, [sp, #0x48]
1002468a8:     	cbz	x1, 0x100246c20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
1002468ac:     	ldr	x8, [sp, #0x110]
1002468b0:     	cmp	x8, x10
1002468b4:     	b.eq	0x100246c44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb40>
1002468b8:     	tbnz	w28, #0x0, 0x1002468f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7ec>
1002468bc:     	ldr	w9, [x8, #0x4]
1002468c0:     	cmp	x2, x9
1002468c4:     	ldr	x9, [sp, #0x30]
1002468c8:     	b.ne	0x1002468f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7ec>
1002468cc:     	add	x0, x8, #0x14
1002468d0:     	mov	x1, x23
1002468d4:     	mov	x23, x11
1002468d8:     	str	x10, [sp, #0x28]
1002468dc:     	bl	0x100b66be0 <_writev+0x100b66be0>
1002468e0:     	ldp	x10, x9, [sp, #0x28]
1002468e4:     	mov	x11, x23
1002468e8:     	ldp	x23, x2, [sp, #0x40]
1002468ec:     	cbz	w0, 0x100246c44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb40>
1002468f0:     	ldr	x1, [sp, #0xa0]
1002468f4:     	cmp	x1, #0x1
1002468f8:     	b.eq	0x100246c20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
1002468fc:     	ldr	x9, [sp, #0x118]
100246900:     	add	x8, sp, #0x158
100246904:     	add	x8, x8, #0x8
100246908:     	cmp	x9, x10
10024690c:     	b.eq	0x100246c48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
100246910:     	tbnz	w28, #0x0, 0x10024694c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x848>
100246914:     	ldr	w8, [x9, #0x4]
100246918:     	cmp	x2, x8
10024691c:     	b.ne	0x10024694c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x848>
100246920:     	add	x0, x9, #0x14
100246924:     	mov	x1, x23
100246928:     	mov	x23, x11
10024692c:     	str	x10, [sp, #0x28]
100246930:     	bl	0x100b66be0 <_writev+0x100b66be0>
100246934:     	ldr	x10, [sp, #0x28]
100246938:     	mov	x11, x23
10024693c:     	ldp	x23, x2, [sp, #0x40]
100246940:     	add	x8, sp, #0x158
100246944:     	add	x8, x8, #0x8
100246948:     	cbz	w0, 0x100246c48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
10024694c:     	ldr	x1, [sp, #0xa0]
100246950:     	cmp	x1, #0x2
100246954:     	ldr	x9, [sp, #0x30]
100246958:     	b.eq	0x100246c20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
10024695c:     	ldr	x9, [sp, #0x120]
100246960:     	add	x8, sp, #0x158
100246964:     	add	x8, x8, #0x10
100246968:     	cmp	x9, x10
10024696c:     	b.eq	0x100246c48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
100246970:     	tbnz	w28, #0x0, 0x1002469ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x8a8>
100246974:     	ldr	w8, [x9, #0x4]
100246978:     	cmp	x2, x8
10024697c:     	b.ne	0x1002469ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x8a8>
100246980:     	add	x0, x9, #0x14
100246984:     	mov	x1, x23
100246988:     	mov	x23, x11
10024698c:     	str	x10, [sp, #0x28]
100246990:     	bl	0x100b66be0 <_writev+0x100b66be0>
100246994:     	ldr	x10, [sp, #0x28]
100246998:     	mov	x11, x23
10024699c:     	ldp	x23, x2, [sp, #0x40]
1002469a0:     	add	x8, sp, #0x158
1002469a4:     	add	x8, x8, #0x10
1002469a8:     	cbz	w0, 0x100246c48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
1002469ac:     	ldr	x1, [sp, #0xa0]
1002469b0:     	cmp	x1, #0x3
1002469b4:     	ldr	x9, [sp, #0x30]
1002469b8:     	b.eq	0x100246c20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
1002469bc:     	ldr	x9, [sp, #0x128]
1002469c0:     	add	x8, sp, #0x158
1002469c4:     	add	x8, x8, #0x18
1002469c8:     	cmp	x9, x10
1002469cc:     	b.eq	0x100246c48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
1002469d0:     	tbnz	w28, #0x0, 0x100246a0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x908>
1002469d4:     	ldr	w8, [x9, #0x4]
1002469d8:     	cmp	x2, x8
1002469dc:     	b.ne	0x100246a0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x908>
1002469e0:     	add	x0, x9, #0x14
1002469e4:     	mov	x1, x23
1002469e8:     	mov	x23, x11
1002469ec:     	str	x10, [sp, #0x28]
1002469f0:     	bl	0x100b66be0 <_writev+0x100b66be0>
1002469f4:     	ldr	x10, [sp, #0x28]
1002469f8:     	mov	x11, x23
1002469fc:     	ldp	x23, x2, [sp, #0x40]
100246a00:     	add	x8, sp, #0x158
100246a04:     	add	x8, x8, #0x18
100246a08:     	cbz	w0, 0x100246c48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
100246a0c:     	ldr	x1, [sp, #0xa0]
100246a10:     	cmp	x1, #0x4
100246a14:     	ldr	x9, [sp, #0x30]
100246a18:     	b.eq	0x100246c20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
100246a1c:     	ldr	x9, [sp, #0x130]
100246a20:     	add	x8, sp, #0x158
100246a24:     	add	x8, x8, #0x20
100246a28:     	cmp	x9, x10
100246a2c:     	b.eq	0x100246c48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
100246a30:     	tbnz	w28, #0x0, 0x100246a6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x968>
100246a34:     	ldr	w8, [x9, #0x4]
100246a38:     	cmp	x2, x8
100246a3c:     	b.ne	0x100246a6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x968>
100246a40:     	add	x0, x9, #0x14
100246a44:     	mov	x1, x23
100246a48:     	mov	x23, x11
100246a4c:     	str	x10, [sp, #0x28]
100246a50:     	bl	0x100b66be0 <_writev+0x100b66be0>
100246a54:     	ldr	x10, [sp, #0x28]
100246a58:     	mov	x11, x23
100246a5c:     	ldp	x23, x2, [sp, #0x40]
100246a60:     	add	x8, sp, #0x158
100246a64:     	add	x8, x8, #0x20
100246a68:     	cbz	w0, 0x100246c48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
100246a6c:     	ldr	x1, [sp, #0xa0]
100246a70:     	cmp	x1, #0x5
100246a74:     	ldr	x9, [sp, #0x30]
100246a78:     	b.eq	0x100246c20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
100246a7c:     	ldr	x9, [sp, #0x138]
100246a80:     	add	x8, sp, #0x158
100246a84:     	add	x8, x8, #0x28
100246a88:     	cmp	x9, x10
100246a8c:     	b.eq	0x100246c48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
100246a90:     	tbnz	w28, #0x0, 0x100246acc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x9c8>
100246a94:     	ldr	w8, [x9, #0x4]
100246a98:     	cmp	x2, x8
100246a9c:     	b.ne	0x100246acc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x9c8>
100246aa0:     	add	x0, x9, #0x14
100246aa4:     	mov	x1, x23
100246aa8:     	mov	x23, x11
100246aac:     	str	x10, [sp, #0x28]
100246ab0:     	bl	0x100b66be0 <_writev+0x100b66be0>
100246ab4:     	ldr	x10, [sp, #0x28]
100246ab8:     	mov	x11, x23
100246abc:     	ldp	x23, x2, [sp, #0x40]
100246ac0:     	add	x8, sp, #0x158
100246ac4:     	add	x8, x8, #0x28
100246ac8:     	cbz	w0, 0x100246c48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
100246acc:     	ldr	x1, [sp, #0xa0]
100246ad0:     	cmp	x1, #0x6
100246ad4:     	ldr	x9, [sp, #0x30]
100246ad8:     	b.eq	0x100246c20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
100246adc:     	ldr	x9, [sp, #0x140]
100246ae0:     	add	x8, sp, #0x158
100246ae4:     	add	x8, x8, #0x30
100246ae8:     	cmp	x9, x10
100246aec:     	b.eq	0x100246c48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
100246af0:     	tbnz	w28, #0x0, 0x100246b2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xa28>
100246af4:     	ldr	w8, [x9, #0x4]
100246af8:     	cmp	x2, x8
100246afc:     	b.ne	0x100246b2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xa28>
100246b00:     	add	x0, x9, #0x14
100246b04:     	mov	x1, x23
100246b08:     	mov	x23, x11
100246b0c:     	str	x10, [sp, #0x28]
100246b10:     	bl	0x100b66be0 <_writev+0x100b66be0>
100246b14:     	ldr	x10, [sp, #0x28]
100246b18:     	mov	x11, x23
100246b1c:     	ldp	x23, x2, [sp, #0x40]
100246b20:     	add	x8, sp, #0x158
100246b24:     	add	x8, x8, #0x30
100246b28:     	cbz	w0, 0x100246c48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
100246b2c:     	ldr	x1, [sp, #0xa0]
100246b30:     	cmp	x1, #0x7
100246b34:     	ldr	x9, [sp, #0x30]
100246b38:     	b.eq	0x100246c20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
100246b3c:     	ldr	x9, [sp, #0x148]
100246b40:     	add	x8, sp, #0x158
100246b44:     	add	x8, x8, #0x38
100246b48:     	cmp	x9, x10
100246b4c:     	b.eq	0x100246c48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
100246b50:     	tbnz	w28, #0x0, 0x100246b88 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xa84>
100246b54:     	ldr	w8, [x9, #0x4]
100246b58:     	cmp	x2, x8
100246b5c:     	b.ne	0x100246b88 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xa84>
100246b60:     	add	x0, x9, #0x14
100246b64:     	mov	x1, x23
100246b68:     	mov	x23, x11
100246b6c:     	mov	x28, x10
100246b70:     	bl	0x100b66be0 <_writev+0x100b66be0>
100246b74:     	mov	x10, x28
100246b78:     	mov	x11, x23
100246b7c:     	add	x8, sp, #0x158
100246b80:     	add	x8, x8, #0x38
100246b84:     	cbz	w0, 0x100246c48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
100246b88:     	ldr	x1, [sp, #0xa0]
100246b8c:     	cmp	x1, #0x8
100246b90:     	ldr	x9, [sp, #0x30]
100246b94:     	b.ne	0x100246c20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
100246b98:     	mov	x28, x10
100246b9c:     	mov	x26, x11
100246ba0:     	mov	w0, #0x80               ; =128
100246ba4:     	bl	0x100b63fc8 <_mi_malloc_aligned>
100246ba8:     	cbz	x0, 0x100247380 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x127c>
100246bac:     	mov	x23, x0
100246bb0:     	mov	w0, #0x80               ; =128
100246bb4:     	mov	w1, #0x8                ; =8
100246bb8:     	bl	0x100b63fc8 <_mi_malloc_aligned>
100246bbc:     	str	x0, [sp, #0x20]
100246bc0:     	cbz	x0, 0x100247380 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x127c>
100246bc4:     	ldp	q0, q1, [sp, #0x110]
100246bc8:     	stp	q0, q1, [x23]
100246bcc:     	ldp	q0, q1, [sp, #0x130]
100246bd0:     	stp	q0, q1, [x23, #0x20]
100246bd4:     	add	x9, sp, #0x158
100246bd8:     	ldp	q0, q1, [x9]
100246bdc:     	ldr	x10, [sp, #0x20]
100246be0:     	stp	q0, q1, [x10]
100246be4:     	ldp	q0, q1, [x9, #0x20]
100246be8:     	stp	q0, q1, [x10, #0x20]
100246bec:     	str	x28, [x23, #0x40]
100246bf0:     	ldr	x8, [sp, #0x38]
100246bf4:     	str	x8, [x10, #0x40]
100246bf8:     	mov	w8, #0x10               ; =16
100246bfc:     	stp	x8, x23, [sp, #0x198]
100246c00:     	ldp	q0, q1, [sp, #0x50]
100246c04:     	str	q1, [x9, #0x50]
100246c08:     	str	x10, [sp, #0x1b8]
100246c0c:     	mov	w8, #0x8                ; =8
100246c10:     	str	x8, [sp, #0xa0]
100246c14:     	stur	q0, [x9, #0x68]
100246c18:     	mov	w9, #0x9                ; =9
100246c1c:     	b	0x100246820 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x71c>
100246c20:     	add	x8, sp, #0x110
100246c24:     	str	x10, [x8, x1, lsl #3]
100246c28:     	add	x8, sp, #0x158
100246c2c:     	ldr	x10, [sp, #0x38]
100246c30:     	str	x10, [x8, x1, lsl #3]
100246c34:     	add	x8, x1, #0x1
100246c38:     	str	x8, [sp, #0x90]
100246c3c:     	str	x8, [sp, #0xa0]
100246c40:     	b	0x100246cb4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbb0>
100246c44:     	add	x8, sp, #0x158
100246c48:     	ldp	x9, x10, [sp, #0x30]
100246c4c:     	str	x10, [x8]
100246c50:     	b	0x100246cb4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbb0>
100246c54:     	mov	x11, x26
100246c58:     	ldr	w26, [sp, #0x9c]
100246c5c:     	ldr	x9, [sp, #0x30]
100246c60:     	b	0x100246c74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb70>
100246c64:     	ldr	x27, [sp, #0x18]
100246c68:     	mov	x11, x26
100246c6c:     	ldr	w26, [sp, #0x9c]
100246c70:     	ldp	x28, x9, [sp, #0x28]
100246c74:     	ldr	x10, [sp, #0x8]
100246c78:     	ldr	x8, [sp, #0x10]
100246c7c:     	cmp	x28, x8
100246c80:     	b.eq	0x100246d70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc6c>
100246c84:     	str	x23, [x10, x28, lsl #3]
100246c88:     	add	x8, x28, #0x1
100246c8c:     	str	x8, [sp, #0x1a8]
100246c90:     	ldr	x8, [sp, #0x1b0]
100246c94:     	cmp	x9, x8
100246c98:     	b.eq	0x100246da0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc9c>
100246c9c:     	ldr	x8, [sp, #0x1b8]
100246ca0:     	str	x8, [sp, #0x20]
100246ca4:     	ldr	x10, [sp, #0x38]
100246ca8:     	str	x10, [x8, x9, lsl #3]
100246cac:     	add	x9, x9, #0x1
100246cb0:     	str	x9, [sp, #0x1c0]
100246cb4:     	ldp	x23, x8, [x19, #0x68]
100246cb8:     	cmp	x8, x23
100246cbc:     	b.hs	0x100246cf4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbf0>
100246cc0:     	mov	x12, x9
100246cc4:     	ldr	x9, [x19, #0x60]
100246cc8:     	ldrb	w10, [x9, x8]
100246ccc:     	cmp	w10, #0x20
100246cd0:     	b.hi	0x100246cf0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbec>
100246cd4:     	lsr	x10, x25, x10
100246cd8:     	tbz	w10, #0x0, 0x100246cf0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbec>
100246cdc:     	add	x8, x8, #0x1
100246ce0:     	str	x8, [x19, #0x70]
100246ce4:     	cmp	x23, x8
100246ce8:     	b.ne	0x100246cc8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbc4>
100246cec:     	b	0x100246f40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe3c>
100246cf0:     	mov	x9, x12
100246cf4:     	cmp	x8, x23
100246cf8:     	b.hs	0x100246f40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe3c>
100246cfc:     	str	x9, [sp, #0x30]
100246d00:     	ldr	x9, [x19, #0x60]
100246d04:     	ldrb	w9, [x9, x8]
100246d08:     	cmp	w9, #0x2c
100246d0c:     	b.ne	0x100246f40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe3c>
100246d10:     	add	x28, x8, #0x1
100246d14:     	str	x28, [x19, #0x70]
100246d18:     	cmp	x24, #0x1
100246d1c:     	ldr	x24, [sp, #0xa8]
100246d20:     	ldr	w8, [sp, #0x98]
100246d24:     	b.lt	0x1002462c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1bc>
100246d28:     	ldr	x0, [sp, #0x40]
100246d2c:     	mov	x23, x11
100246d30:     	bl	0x100b63d40 <_mi_free>
100246d34:     	mov	x11, x23
100246d38:     	ldr	w8, [sp, #0x98]
100246d3c:     	ldp	x23, x28, [x19, #0x68]
100246d40:     	b	0x1002462c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1bc>
100246d44:     	add	x0, sp, #0x198
100246d48:     	bl	0x100b40a2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100246d4c:     	b	0x1002467e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x6e0>
100246d50:     	add	x8, sp, #0x198
100246d54:     	add	x0, x8, #0x18
100246d58:     	bl	0x100b40a2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100246d5c:     	b	0x100246804 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x700>
100246d60:     	mov	x10, x28
100246d64:     	ldr	x0, [sp, #0xa8]
100246d68:     	ldr	x9, [sp, #0x30]
100246d6c:     	b	0x10024654c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x448>
100246d70:     	add	x0, sp, #0x198
100246d74:     	str	w11, [sp, #0x48]
100246d78:     	bl	0x100b40a2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100246d7c:     	ldr	w11, [sp, #0x48]
100246d80:     	ldr	x10, [sp, #0x1a0]
100246d84:     	ldr	x9, [sp, #0x1c0]
100246d88:     	str	x23, [x10, x28, lsl #3]
100246d8c:     	add	x8, x28, #0x1
100246d90:     	str	x8, [sp, #0x1a8]
100246d94:     	ldr	x8, [sp, #0x1b0]
100246d98:     	cmp	x9, x8
100246d9c:     	b.ne	0x100246c9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb98>
100246da0:     	add	x8, sp, #0x198
100246da4:     	add	x0, x8, #0x18
100246da8:     	mov	x23, x11
100246dac:     	mov	x28, x9
100246db0:     	bl	0x100b40a2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100246db4:     	mov	x9, x28
100246db8:     	mov	x11, x23
100246dbc:     	b	0x100246c9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb98>
100246dc0:     	strb	wzr, [x19, #0xd4]
100246dc4:     	ldr	w26, [sp, #0x9c]
100246dc8:     	cmp	x24, #0x1
100246dcc:     	b.lt	0x100246dd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcd4>
100246dd0:     	mov	x0, x23
100246dd4:     	bl	0x100b63d40 <_mi_free>
100246dd8:     	ldr	x21, [sp, #0xa8]
100246ddc:     	ldp	x9, x8, [x19, #0x68]
100246de0:     	cmp	x8, x9
100246de4:     	b.hs	0x100246f64 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe60>
100246de8:     	ldr	x10, [x19, #0x60]
100246dec:     	mov	x11, #0x2600            ; =9728
100246df0:     	movk	x11, #0x1, lsl #32
100246df4:     	ldrb	w12, [x10, x8]
100246df8:     	cmp	w12, #0x20
100246dfc:     	b.hi	0x100246e1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xd18>
100246e00:     	lsr	x13, x11, x12
100246e04:     	tbz	w13, #0x0, 0x100246e1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xd18>
100246e08:     	add	x8, x8, #0x1
100246e0c:     	str	x8, [x19, #0x70]
100246e10:     	cmp	x9, x8
100246e14:     	b.ne	0x100246df4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcf0>
100246e18:     	b	0x100246f64 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe60>
100246e1c:     	cmp	w12, #0x7d
100246e20:     	b.ne	0x100246f64 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe60>
100246e24:     	add	x8, x8, #0x1
100246e28:     	str	x8, [x19, #0x70]
100246e2c:     	ldr	x8, [sp, #0x198]
100246e30:     	cmn	x8, #0x1
100246e34:     	b.ne	0x100246f74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe70>
100246e38:     	ldr	w8, [sp, #0x98]
100246e3c:     	and	w8, w26, w8
100246e40:     	tbz	w8, #0x0, 0x100246e74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xd70>
100246e44:     	ldr	x8, [sp, #0x90]
100246e48:     	cmp	x22, x8
100246e4c:     	b.ne	0x100246e74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xd70>
100246e50:     	cmp	x21, x22
100246e54:     	b.ne	0x100246e74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xd70>
100246e58:     	ldr	x22, [sp, #0xa0]
100246e5c:     	cmp	x22, #0x9
100246e60:     	ldr	w2, [sp, #0x84]
100246e64:     	ldr	x21, [sp, #0x78]
100246e68:     	b.hs	0x100246fe8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xee4>
100246e6c:     	add	x3, sp, #0x158
100246e70:     	b	0x10024701c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf18>
100246e74:     	ldr	x22, [sp, #0xa0]
100246e78:     	cmp	x22, #0x9
100246e7c:     	b.hs	0x1002472b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11b0>
100246e80:     	ldr	x8, [x19, #0x78]
100246e84:     	cmp	x22, x8
100246e88:     	b.ne	0x100246ea8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
100246e8c:     	ldr	x21, [x19, #0xc0]
100246e90:     	cbz	x21, 0x100246ea8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
100246e94:     	cbz	x22, 0x100247100 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
100246e98:     	ldr	x8, [x19, #0x80]
100246e9c:     	ldr	x9, [sp, #0x110]
100246ea0:     	cmp	x8, x9
100246ea4:     	b.eq	0x1002470f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xff4>
100246ea8:     	add	x0, sp, #0x110
100246eac:     	mov	x1, x22
100246eb0:     	bl	0x10032c2dc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100246eb4:     	mov	x21, x0
100246eb8:     	mov	x23, x1
100246ebc:     	str	x22, [x19, #0x78]
100246ec0:     	lsl	x2, x22, #3
100246ec4:     	add	x0, x19, #0x80
100246ec8:     	add	x1, sp, #0x110
100246ecc:     	bl	0x100b66bec <_writev+0x100b66bec>
100246ed0:     	mov	x2, x23
100246ed4:     	str	x21, [x19, #0xc0]
100246ed8:     	str	w23, [x19, #0xd0]
100246edc:     	add	x3, sp, #0x158
100246ee0:     	b	0x10024701c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf18>
100246ee4:     	b	0x1002461e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe0>
100246ee8:     	sub	x0, x29, #0x68
100246eec:     	mov	x1, #0x0                ; =0
100246ef0:     	bl	0x10032c2dc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100246ef4:     	mov	x2, x1
100246ef8:     	mov	x1, x0
100246efc:     	str	xzr, [x19, #0x78]
100246f00:     	str	x0, [x19, #0xc0]
100246f04:     	str	w2, [x19, #0xd0]
100246f08:     	add	x0, x19, #0x20
100246f0c:     	mov	w3, #0x8                ; =8
100246f10:     	mov	x4, #0x0                ; =0
100246f14:     	bl	0x1005bf688 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
100246f18:     	mov	x19, x0
100246f1c:     	ldrb	w8, [x20, #0x20]
100246f20:     	cbnz	w8, 0x1002472cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11c8>
100246f24:     	ldr	x8, [x20]
100246f28:     	cbnz	x8, 0x100247310 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x120c>
100246f2c:     	ldr	x8, [x20, #0x18]
100246f30:     	cmp	x27, x8
100246f34:     	b.hi	0x1002470b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfb4>
100246f38:     	str	x27, [x20, #0x18]
100246f3c:     	b	0x1002470b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfb4>
100246f40:     	ldr	x23, [sp, #0x40]
100246f44:     	cmp	x24, #0x1
100246f48:     	b.ge	0x100246dd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xccc>
100246f4c:     	b	0x100246dd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcd4>
100246f50:     	ldr	x21, [sp, #0xa8]
100246f54:     	ldr	w26, [sp, #0x9c]
100246f58:     	ldp	x9, x8, [x19, #0x68]
100246f5c:     	cmp	x8, x9
100246f60:     	b.lo	0x100246de8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xce4>
100246f64:     	strb	wzr, [x19, #0xd4]
100246f68:     	ldr	x8, [sp, #0x198]
100246f6c:     	cmn	x8, #0x1
100246f70:     	b.eq	0x100246e38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xd34>
100246f74:     	ldp	x0, x1, [sp, #0x1a0]
100246f78:     	cmp	x1, #0x9
100246f7c:     	b.hs	0x100247000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xefc>
100246f80:     	ldr	x8, [x19, #0x78]
100246f84:     	cmp	x1, x8
100246f88:     	ldr	x22, [sp, #0xa0]
100246f8c:     	b.ne	0x100246fac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
100246f90:     	ldr	x21, [x19, #0xc0]
100246f94:     	cbz	x21, 0x100246fac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
100246f98:     	cbz	x1, 0x1002470e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
100246f9c:     	ldr	x8, [x19, #0x80]
100246fa0:     	ldr	x9, [x0]
100246fa4:     	cmp	x8, x9
100246fa8:     	b.eq	0x1002470e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfdc>
100246fac:     	mov	x24, x0
100246fb0:     	mov	x25, x1
100246fb4:     	bl	0x10032c2dc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100246fb8:     	mov	x21, x0
100246fbc:     	mov	x23, x1
100246fc0:     	str	x25, [x19, #0x78]
100246fc4:     	lsl	x2, x25, #3
100246fc8:     	add	x0, x19, #0x80
100246fcc:     	mov	x1, x24
100246fd0:     	bl	0x100b66bec <_writev+0x100b66bec>
100246fd4:     	mov	x2, x23
100246fd8:     	str	x21, [x19, #0xc0]
100246fdc:     	str	w23, [x19, #0xd0]
100246fe0:     	cmp	x22, #0x9
100246fe4:     	b.lo	0x100247018 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf14>
100246fe8:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246fec:     	add	x3, x3, #0x710
100246ff0:     	mov	x0, #0x0                ; =0
100246ff4:     	mov	x1, x22
100246ff8:     	mov	w2, #0x8                ; =8
100246ffc:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100247000:     	bl	0x10032c2dc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100247004:     	mov	x21, x0
100247008:     	mov	x2, x1
10024700c:     	ldr	x22, [sp, #0xa0]
100247010:     	cmp	x22, #0x9
100247014:     	b.hs	0x100246fe8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xee4>
100247018:     	ldp	x3, x22, [sp, #0x1b8]
10024701c:     	add	x0, x19, #0x20
100247020:     	mov	x1, x21
100247024:     	mov	x4, x22
100247028:     	bl	0x1005bf688 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
10024702c:     	mov	x19, x0
100247030:     	ldrb	w8, [x20, #0x20]
100247034:     	cbnz	w8, 0x10024728c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1188>
100247038:     	ldr	x8, [x20]
10024703c:     	cbnz	x8, 0x100247310 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x120c>
100247040:     	ldr	x8, [x20, #0x18]
100247044:     	cmp	x27, x8
100247048:     	b.hi	0x100247050 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf4c>
10024704c:     	str	x27, [x20, #0x18]
100247050:     	ldr	x8, [sp, #0x198]
100247054:     	cmn	x8, #0x1
100247058:     	b.eq	0x1002470b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfb4>
10024705c:     	cbz	x8, 0x100247068 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf64>
100247060:     	ldr	x0, [sp, #0x1a0]
100247064:     	bl	0x100b63d40 <_mi_free>
100247068:     	ldr	x8, [sp, #0x1b0]
10024706c:     	cbz	x8, 0x100247078 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf74>
100247070:     	ldr	x0, [sp, #0x1b8]
100247074:     	bl	0x100b63d40 <_mi_free>
100247078:     	ldr	x20, [sp, #0x1c8]
10024707c:     	cmn	x20, #0x1
100247080:     	b.eq	0x1002470b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfb4>
100247084:     	ldr	x9, [sp, #0x1e8]
100247088:     	cbz	x9, 0x1002470ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfa8>
10024708c:     	lsl	x8, x9, #4
100247090:     	add	x9, x8, x9
100247094:     	cmn	x9, #0x19
100247098:     	b.eq	0x1002470ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfa8>
10024709c:     	ldr	x9, [sp, #0x1e0]
1002470a0:     	sub	x8, x9, x8
1002470a4:     	sub	x0, x8, #0x10
1002470a8:     	bl	0x100b63d40 <_mi_free>
1002470ac:     	cbz	x20, 0x1002470b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfb4>
1002470b0:     	ldr	x0, [sp, #0x1d0]
1002470b4:     	bl	0x100b63d40 <_mi_free>
1002470b8:     	mov	x0, #0x7ffd000000000000 ; =9222527611924643840
1002470bc:     	bfxil	x0, x19, #0, #48
1002470c0:     	add	sp, sp, #0x250
1002470c4:     	ldp	x29, x30, [sp, #0x50]
1002470c8:     	ldp	x20, x19, [sp, #0x40]
1002470cc:     	ldp	x22, x21, [sp, #0x30]
1002470d0:     	ldp	x24, x23, [sp, #0x20]
1002470d4:     	ldp	x26, x25, [sp, #0x10]
1002470d8:     	ldp	x28, x27, [sp], #0x60
1002470dc:     	ret
1002470e0:     	cmp	x1, #0x1
1002470e4:     	b.ne	0x10024710c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1008>
1002470e8:     	ldr	w2, [x19, #0xd0]
1002470ec:     	cmp	x22, #0x9
1002470f0:     	b.lo	0x100247018 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf14>
1002470f4:     	b	0x100246fe8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xee4>
1002470f8:     	cmp	x22, #0x1
1002470fc:     	b.ne	0x1002471b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x10ac>
100247100:     	ldr	w2, [x19, #0xd0]
100247104:     	add	x3, sp, #0x158
100247108:     	b	0x10024701c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf18>
10024710c:     	ldr	x8, [x19, #0x88]
100247110:     	ldr	x9, [x0, #0x8]
100247114:     	cmp	x8, x9
100247118:     	b.ne	0x100246fac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
10024711c:     	cmp	x1, #0x2
100247120:     	b.eq	0x1002470e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
100247124:     	ldr	x8, [x19, #0x90]
100247128:     	ldr	x9, [x0, #0x10]
10024712c:     	cmp	x8, x9
100247130:     	b.ne	0x100246fac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
100247134:     	cmp	x1, #0x3
100247138:     	b.eq	0x1002470e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
10024713c:     	ldr	x8, [x19, #0x98]
100247140:     	ldr	x9, [x0, #0x18]
100247144:     	cmp	x8, x9
100247148:     	b.ne	0x100246fac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
10024714c:     	cmp	x1, #0x4
100247150:     	b.eq	0x1002470e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
100247154:     	ldr	x8, [x19, #0xa0]
100247158:     	ldr	x9, [x0, #0x20]
10024715c:     	cmp	x8, x9
100247160:     	b.ne	0x100246fac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
100247164:     	cmp	x1, #0x5
100247168:     	b.eq	0x1002470e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
10024716c:     	ldr	x8, [x19, #0xa8]
100247170:     	ldr	x9, [x0, #0x28]
100247174:     	cmp	x8, x9
100247178:     	b.ne	0x100246fac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
10024717c:     	cmp	x1, #0x6
100247180:     	b.eq	0x1002470e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
100247184:     	ldr	x8, [x19, #0xb0]
100247188:     	ldr	x9, [x0, #0x30]
10024718c:     	cmp	x8, x9
100247190:     	b.ne	0x100246fac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
100247194:     	cmp	x1, #0x7
100247198:     	b.eq	0x1002470e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
10024719c:     	ldr	x8, [x19, #0xb8]
1002471a0:     	ldr	x9, [x0, #0x38]
1002471a4:     	cmp	x8, x9
1002471a8:     	b.ne	0x100246fac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
1002471ac:     	b	0x1002470e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
1002471b0:     	ldr	x8, [x19, #0x88]
1002471b4:     	ldr	x9, [sp, #0x118]
1002471b8:     	cmp	x8, x9
1002471bc:     	b.ne	0x100246ea8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
1002471c0:     	cmp	x22, #0x2
1002471c4:     	b.eq	0x100247100 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
1002471c8:     	ldr	x8, [x19, #0x90]
1002471cc:     	ldr	x9, [sp, #0x120]
1002471d0:     	cmp	x8, x9
1002471d4:     	b.ne	0x100246ea8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
1002471d8:     	cmp	x22, #0x3
1002471dc:     	b.eq	0x100247100 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
1002471e0:     	ldr	x8, [x19, #0x98]
1002471e4:     	ldr	x9, [sp, #0x128]
1002471e8:     	cmp	x8, x9
1002471ec:     	b.ne	0x100246ea8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
1002471f0:     	cmp	x22, #0x4
1002471f4:     	b.eq	0x100247100 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
1002471f8:     	ldr	x8, [x19, #0xa0]
1002471fc:     	ldr	x9, [sp, #0x130]
100247200:     	cmp	x8, x9
100247204:     	b.ne	0x100246ea8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
100247208:     	cmp	x22, #0x5
10024720c:     	b.eq	0x100247100 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
100247210:     	ldr	x8, [x19, #0xa8]
100247214:     	ldr	x9, [sp, #0x138]
100247218:     	cmp	x8, x9
10024721c:     	b.ne	0x100246ea8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
100247220:     	cmp	x22, #0x6
100247224:     	b.eq	0x100247100 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
100247228:     	ldr	x8, [x19, #0xb0]
10024722c:     	ldr	x9, [sp, #0x140]
100247230:     	cmp	x8, x9
100247234:     	b.ne	0x100246ea8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
100247238:     	cmp	x22, #0x7
10024723c:     	b.eq	0x100247100 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
100247240:     	ldr	x8, [x19, #0xb8]
100247244:     	ldr	x9, [sp, #0x148]
100247248:     	cmp	x8, x9
10024724c:     	b.ne	0x100246ea8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
100247250:     	b	0x100247100 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
100247254:     	cmp	w8, #0x1
100247258:     	b.ne	0x1002472d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11d0>
10024725c:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
100247260:     	add	x1, x1, #0x898
100247264:     	mov	x0, x20
100247268:     	bl	0x100a2519c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10024726c:     	strb	wzr, [x20, #0x20]
100247270:     	ldr	x8, [x20]
100247274:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100247278:     	cmp	x8, x9
10024727c:     	b.lo	0x100246214 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x110>
100247280:     	adrp	x0, 0x100efe000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100247284:     	add	x0, x0, #0x4a0
100247288:     	bl	0x100b1749c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
10024728c:     	cmp	w8, #0x2
100247290:     	b.eq	0x1002472d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11d0>
100247294:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
100247298:     	add	x1, x1, #0x898
10024729c:     	mov	x0, x20
1002472a0:     	bl	0x100a2519c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1002472a4:     	strb	wzr, [x20, #0x20]
1002472a8:     	ldr	x8, [x20]
1002472ac:     	cbz	x8, 0x100247040 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf3c>
1002472b0:     	b	0x100247310 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x120c>
1002472b4:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002472b8:     	add	x3, x3, #0x6f8
1002472bc:     	mov	x0, #0x0                ; =0
1002472c0:     	mov	x1, x22
1002472c4:     	mov	w2, #0x8                ; =8
1002472c8:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1002472cc:     	cmp	w8, #0x2
1002472d0:     	b.ne	0x1002472f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11f0>
1002472d4:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
1002472d8:     	add	x0, x0, #0xc18
1002472dc:     	bl	0x100b5d39c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
1002472e0:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002472e4:     	add	x3, x3, #0x6b0
1002472e8:     	mov	x0, #0x0                ; =0
1002472ec:     	mov	w2, #0x8                ; =8
1002472f0:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1002472f4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
1002472f8:     	add	x1, x1, #0x898
1002472fc:     	mov	x0, x20
100247300:     	bl	0x100a2519c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100247304:     	strb	wzr, [x20, #0x20]
100247308:     	ldr	x8, [x20]
10024730c:     	cbz	x8, 0x100246f2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe28>
100247310:     	adrp	x0, 0x100efe000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100247314:     	add	x0, x0, #0x488
100247318:     	bl	0x100b1746c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10024731c:     	adrp	x0, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100247320:     	add	x0, x0, #0x668
100247324:     	bl	0x100b17530 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100247328:     	adrp	x2, 0x100efc000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
10024732c:     	add	x2, x2, #0x800
100247330:     	mov	x0, x24
100247334:     	mov	w1, #0x8                ; =8
100247338:     	bl	0x100b175cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
10024733c:     	adrp	x2, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100247340:     	add	x2, x2, #0x6c8
100247344:     	mov	x0, x1
100247348:     	mov	x1, x9
10024734c:     	bl	0x100b175cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100247350:     	adrp	x2, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100247354:     	add	x2, x2, #0x6e0
100247358:     	mov	x1, x9
10024735c:     	bl	0x100b175cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100247360:     	adrp	x2, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100247364:     	add	x2, x2, #0x698
100247368:     	mov	w1, #0x8                ; =8
10024736c:     	bl	0x100b175cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100247370:     	adrp	x2, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100247374:     	add	x2, x2, #0x680
100247378:     	mov	w1, #0x8                ; =8
10024737c:     	bl	0x100b175cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100247380:     	mov	w0, #0x8                ; =8
100247384:     	mov	w1, #0x80               ; =128
100247388:     	bl	0x100b170c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
