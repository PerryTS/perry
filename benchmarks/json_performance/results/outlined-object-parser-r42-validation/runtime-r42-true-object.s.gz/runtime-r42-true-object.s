
benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.0hzsjplwwpevv88lz9s5mjuly.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.addr2line-cfa71d2872fc9749.addr2line.2f803ffa438d6abd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.adler2-4a012095652e66be.adler2.4472f1a4039cb8c5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ahash-9514a3e3390ca75c.ahash.2d29b14819ea2aa7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.aho_corasick-0465e7d1dc158f68.aho_corasick.d4e9aa874147907-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.alloc-f7cf0325b2c4fbea.alloc.91507a9d0c1147cb-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.allocator_api2-f4879b7f65d9dad6.allocator_api2.c20efd3e8c1c526a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.anyhow-b00ab8880ea60f5a.anyhow.dd2c21d3a09e2169-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.base64-32ce9211317f5731.base64.d7b02bb0c01b4c7f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.base64ct-dc4539cdef9387c1.base64ct.a13194e5b06d043e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.better_scoped_tls-5623aa5785b63992.better_scoped_tls.c4fc4593c97e81eb-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bit_set-1b43a885fb453b97.bit_set.e296561ef88d1b25-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bit_vec-8353e4eca9cb6885.bit_vec.2905b060439a1ee5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bitflags-a267cd1b6450301e.bitflags.9b23124bf16832ba-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bytecount-f903ae1df949a853.bytecount.d96a36eac4eddd2e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bytes-4d639afa28f500e9.bytes.4b80b056274f495a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bytes_str-9ed5b56fd3acead7.bytes_str.33b6ea97d807fd24-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.calendrical_calculations-d30e5fcb342f8309.calendrical_calculations.ff7d2d4d240655f4-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.cfg_if-11f50a868fc78507.cfg_if.b001c247f2cdfacc-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.cfg_if-65f3efe385514d24.cfg_if.f06090845af655d8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.chacha20-894520615b692380.chacha20.255207753dfba230-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.combine-c70df9144a05ac41.combine.c3909ca49e68f1f0-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.const_oid-7b92d750363681a1.const_oid.59ced0f90a34feb8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.core-1eb26884753bb7ec.core.e07e215301fbc6f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.core_maths-11146167d2fbcd32.core_maths.423ca64e8f23f19a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.cty-f1fa0ed128de58b9.cty.6b73d1db9cbf7b8b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.data_encoding-98155a5d48e5ec99.data_encoding.d70ce69399f262ca-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.debug_unreachable-9bb446589bc29b16.debug_unreachable.fe3a47d951b816d9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.der-9bb76198d0a38255.der.6bdd1208ba76c73b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.dirs-756cabb78e25a929.dirs.ffe05ade48c56831-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.dirs_sys-e3f5752242e2a022.dirs_sys.ee3c17565b1fea59-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.either-432e8663b5d638fc.either.94df2b7257068b13-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.errno-ea9565cc054c881d.errno.7569163361032131-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.fancy_regex-2c325c7f9e823393.fancy_regex.ca4df3e112cd6cb7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.fixed_decimal-7e6fe6d640091744.fixed_decimal.7d257809aa775ff2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.flagset-ac9650c267cc7e77.flagset.b1438c243c6ff671-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.form_urlencoded-c338c7e2455734e8.form_urlencoded.1ab2c7c11d3385cf-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_core-61582daa6c57b257.futures_core.e5c5ead29f2a5185-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_io-313f277a9d659f14.futures_io.2354b3f0d921f5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_sink-24e92a078488c232.futures_sink.477b530395196519-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_task-40d3c4f4c699450f.futures_task.a793339b5ba19ee-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_util-9ca40d38221ccdc3.futures_util.7622420df399cdfe-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.getrandom-888caac6f3a9d896.getrandom.7f8b53275961c005-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.getrandom-c7786f5309f7c1d1.getrandom.c00a3944440a318d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.gimli-1dc154aa9e77af93.gimli.5901559d024f6e07-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.gimli-4a08f02c6b3bfed9.gimli.adbe390e003e7ecb-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hashbrown-4d32db017aa9b7a5.hashbrown.8f7d8026e818751e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hashbrown-af4a3f18b4ae97c9.hashbrown.cb64e714776d3e07-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hickory_proto-5da21089dd651d86.hickory_proto.b3e58bdc73b32711-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hostname-1a758cf59ba97d19.hostname.9e06914bfa9458c0-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hstr-990b134b3f579b0d.hstr.7816630fc46099ef-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_calendar-41dd45c4986e5371.icu_calendar.525e0f6d835cb712-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_calendar_data-edd7996660c4190e.icu_calendar_data.f47bf9c505eeaff2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_collections-559b63245c10ac1b.icu_collections.377b7b7ce659b1b9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_datetime-034ad7cdc455dac0.icu_datetime.3f12d4db0ba0d033-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_datetime_data-618583f1e8f98068.icu_datetime_data.ae5f6f8bf868927e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_decimal-77beaba6d2163e9b.icu_decimal.fe46e9f4b123130a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_decimal_data-367997f4010d8153.icu_decimal_data.d6f512199a2a447f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale-b42b3e1360358fc5.icu_locale.b3f10ef03c9651a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale_core-849ff933c9f4951a.icu_locale_core.e916c9be12dd52d2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale_data-9e7081d145555538.icu_locale_data.c24e3b51aa8226f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale_fallback-a6e3f83d98e2a67b.icu_locale_fallback.56246df7a44619a1-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale_fallback_data-1291c99bd372729e.icu_locale_fallback_data.afad649127a1756e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_normalizer-bc7f251896dc40bd.icu_normalizer.ff2a905c7940b1f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_normalizer_data-268487fee32ac8f0.icu_normalizer_data.8ad43135a1ce7d1f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_pattern-d59a83eb0e463baf.icu_pattern.be117b667d76f6f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_plurals-3c9070f8fa2510af.icu_plurals.740da912aa775a52-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_plurals_data-bd8faf2099579a9d.icu_plurals_data.45ea6926f1b7622f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_properties-6d0d35008dd1dbf9.icu_properties.c9b54ac36f6ff15d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_properties_data-59005f70ef52dd72.icu_properties_data.2b4f163e924ba5b8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_provider-6781ca5b429f4aee.icu_provider.29b968015b290673-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_time-54550ac874f62853.icu_time.5b58251af801c00d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_time_data-4cd606d3217ab0c8.icu_time_data.e93588578a1fe390-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.idna-8d5c8377e58f6d08.idna.aba1e6179509c9b5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.idna_adapter-16f147720f57f9af.idna_adapter.f7fd92e26f89f8f1-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ipnet-16dcea07c26a0bdf.ipnet.a68501ef90183657-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.itoa-72113ee16b8d0ab6.itoa.6381431f0c25948c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ixdtf-da83a26e439607da.ixdtf.9e61fc26cbabd4cd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.jiff_tzdb-c9f0d309035f3bef.jiff_tzdb.8ad45a94b44687b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.lazy_static-7647d3e036babadd.lazy_static.f61d0a0c663b0e34-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.libc-6299013de1b57308.libc.89db0e620931259c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.libc-dadb5a82a633a7dc.libc.6bde7fa237754b8a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.libm-ac5dff0b52f67d03.libm.554bb06ed6d99dbd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.libmimalloc_sys-b1e23e8a6c5928c2.libmimalloc_sys.29accdad47f6ede0-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.litemap-2e12d9912a397309.litemap.571f336a3d6bbb56-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.lock_api-b480096f46123924.lock_api.874432d3f0bce2f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.log-169df25b841fb738.log.f3f704751685a618-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.mach2-6f42ba587ea54125.mach2.e7620912d05e5c3f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.memchr-1c6a1f6f6196cc2c.memchr.9afcaf06bb01edf2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.memchr-db6845a68ce0f188.memchr.9fcb083790588d2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.miette-85b477785fba33d9.miette.50b4b2d1c414b7ce-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.mimalloc-bcf0b21589b8fa53.mimalloc.95dbff8ab7587b05-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.miniz_oxide-2b20def31e1e0221.miniz_oxide.3e514f74919855b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.mio-f4b45263c6fb2e44.mio.430e10d80ebe3d9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.node_semver-359c30260c8449dc.node_semver.233ee6db2f2c4e46-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.nom-d7f48be26f93c2f7.nom.749d1dbb25d8ab32-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.num_bigint-aa73c29d2bd73516.num_bigint.9ee201b330206f6-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.num_integer-e318a12cf646126f.num_integer.9033146fac8f1134-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.num_traits-46d1dcb8872f2815.num_traits.d52ad62a33d7f1a9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.object-836e641a18d03406.object.f0cec6469c5dcf18-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.once_cell-01ae4f33c7a79bb7.once_cell.3768cf33248bb273-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.option_ext-8f1216324e4e6381.option_ext.92b51bce59292c52-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.panic_abort-905bfe97e1134923.panic_abort.cec6bdc4f2a8e72d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.parking_lot-4acf5fa50a52bd18.parking_lot.b59ab0d8f2549f8e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.parking_lot_core-0dcf47a90d11c4e4.parking_lot_core.502597fbe5df1389-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.pem_rfc7468-d976dcafab7c7e37.pem_rfc7468.757403f363ad557c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.percent_encoding-2e8ac337530122b2.percent_encoding.f83c908de861c15d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_diagnostics-fba70546dd9f3424.perry_diagnostics.cefa4a43ff59d614-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_dispatch-0bc0b01b9b7736fe.perry_dispatch.cd02373148e7c215-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_parser-b68fb40287dd2e20.perry_parser.6e33b45a5046bf8f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_runtime-9458b86ff25d0db1.perry_runtime.261c4ba5a81df8f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000155de4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_>:
  155de4:      	stp	x28, x27, [sp, #-0x60]!
  155de8:      	stp	x26, x25, [sp, #0x10]
  155dec:      	stp	x24, x23, [sp, #0x20]
  155df0:      	stp	x22, x21, [sp, #0x30]
  155df4:      	stp	x20, x19, [sp, #0x40]
  155df8:      	stp	x29, x30, [sp, #0x50]
  155dfc:      	add	x29, sp, #0x50
  155e00:      	sub	sp, sp, #0x240
  155e04:      	mov	x19, x0
  155e08:      	ldp	x8, x9, [x0, #0x68]
  155e0c:      	add	x9, x9, #0x1
  155e10:      	str	x9, [x0, #0x70]
  155e14:      	cmp	x9, x8
  155e18:      	b.hs	0x155e4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x68>
  155e1c:      	ldr	x10, [x19, #0x60]
  155e20:      	mov	x11, #0x2600            ; =9728
  155e24:      	movk	x11, #0x1, lsl #32
  155e28:      	ldrb	w12, [x10, x9]
  155e2c:      	cmp	w12, #0x20
  155e30:      	b.hi	0x155e4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x68>
  155e34:      	lsr	x12, x11, x12
  155e38:      	tbz	w12, #0x0, 0x155e4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x68>
  155e3c:      	add	x9, x9, #0x1
  155e40:      	str	x9, [x19, #0x70]
  155e44:      	cmp	x8, x9
  155e48:      	b.ne	0x155e28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x44>
  155e4c:      	ldrb	w8, [x19, #0xd5]
  155e50:      	tbz	w8, #0x0, 0x155e7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x98>
  155e54:      	strb	wzr, [x19, #0xd5]
  155e58:      	ldr	x22, [x19, #0x78]
  155e5c:      	ldp	q0, q1, [x19, #0x80]
  155e60:      	stur	q0, [sp, #0xa8]
  155e64:      	stur	q1, [sp, #0xb8]
  155e68:      	ldp	q0, q1, [x19, #0xa0]
  155e6c:      	stur	q0, [sp, #0xc8]
  155e70:      	stur	q1, [sp, #0xd8]
  155e74:      	ldr	x21, [x19, #0xc0]
  155e78:      	b	0x155eac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xc8>
  155e7c:      	mov	w26, #0x0               ; =0
  155e80:      	mov	x8, #0x0                ; =0
  155e84:      	ldr	x22, [x19, #0x78]
  155e88:      	cbz	x22, 0x156d10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf2c>
  155e8c:      	ldr	x21, [x19, #0xc0]
  155e90:      	cbz	x21, 0x155ec4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe0>
  155e94:      	ldp	q0, q1, [x19, #0x80]
  155e98:      	stur	q0, [sp, #0xa8]
  155e9c:      	stur	q1, [sp, #0xb8]
  155ea0:      	ldp	q0, q1, [x19, #0xa0]
  155ea4:      	stur	q0, [sp, #0xc8]
  155ea8:      	stur	q1, [sp, #0xd8]
  155eac:      	ldr	w8, [x19, #0xd0]
  155eb0:      	stp	x22, x21, [sp, #0xe8]
  155eb4:      	str	w8, [sp, #0x7c]
  155eb8:      	str	w8, [sp, #0xf8]
  155ebc:      	mov	w8, #0x1                ; =1
  155ec0:      	mov	w26, #0x1               ; =1
  155ec4:      	str	x8, [sp, #0xa0]
  155ec8:      	adrp	x0, 0x155000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f4>
  155ecc:      	ldr	x0, [x0]
  155ed0:      	ldr	x8, [x0]
  155ed4:      	blr	x8
  155ed8:      	mov	x20, x0
  155edc:      	ldrb	w8, [x0, #0x20]
  155ee0:      	cbnz	w8, 0x156f20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x113c>
  155ee4:      	ldr	x8, [x20]
  155ee8:      	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
  155eec:      	cmp	x8, x9
  155ef0:      	b.hs	0x156f4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1168>
  155ef4:      	ldr	x27, [x20, #0x18]
  155ef8:      	ldp	x24, x28, [x19, #0x68]
  155efc:      	cmp	x28, x24
  155f00:      	b.hs	0x155f34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x150>
  155f04:      	ldr	x8, [x19, #0x60]
  155f08:      	ldrb	w8, [x8, x28]
  155f0c:      	cmp	w8, #0x7d
  155f10:      	b.ne	0x155f34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x150>
  155f14:      	add	x8, x28, #0x1
  155f18:      	str	x8, [x19, #0x70]
  155f1c:      	ldr	x8, [x19, #0x78]
  155f20:      	cbnz	x8, 0x156d14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf30>
  155f24:      	ldr	x1, [x19, #0xc0]
  155f28:      	cbz	x1, 0x156d14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf30>
  155f2c:      	ldr	w2, [x19, #0xd0]
  155f30:      	b	0x156d34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf50>
  155f34:      	str	x21, [sp, #0x90]
  155f38:      	movi.2d	v0, #0000000000000000
  155f3c:      	stp	q0, q0, [sp, #0x120]
  155f40:      	stp	q0, q0, [sp, #0x100]
  155f44:      	adrp	x1, 0x155000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f4>
  155f48:      	add	x1, x1, #0x0
  155f4c:      	add	x0, sp, #0x148
  155f50:      	mov	w2, #0x40               ; =64
  155f54:      	bl	0x155f54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x170>
  155f58:      	mov	x23, #0x0               ; =0
  155f5c:      	mov	x21, #0x0               ; =0
  155f60:      	mov	x8, #-0x1               ; =-1
  155f64:      	str	x8, [sp, #0x188]
  155f68:      	add	x8, sp, #0xa0
  155f6c:      	add	x8, x8, #0x8
  155f70:      	stp	x8, xzr, [sp, #0x68]
  155f74:      	mov	x25, #0x2600            ; =9728
  155f78:      	movk	x25, #0x1, lsl #32
  155f7c:      	adrp	x8, 0x155000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f4>
  155f80:      	ldr	q0, [x8]
  155f84:      	str	q0, [sp, #0x50]
  155f88:      	adrp	x8, 0x155000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f4>
  155f8c:      	ldr	q0, [x8]
  155f90:      	str	q0, [sp, #0x40]
  155f94:      	mov	x11, x26
  155f98:      	stp	w26, w26, [sp, #0x98]
  155f9c:      	str	x22, [sp, #0x80]
  155fa0:      	cmp	x28, x24
  155fa4:      	b.hs	0x155fd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1f0>
  155fa8:      	ldr	x8, [x19, #0x60]
  155fac:      	ldrb	w9, [x8, x28]
  155fb0:      	cmp	w9, #0x20
  155fb4:      	b.hi	0x155fd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1f0>
  155fb8:      	lsr	x9, x25, x9
  155fbc:      	tbz	w9, #0x0, 0x155fd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1f0>
  155fc0:      	add	x28, x28, #0x1
  155fc4:      	str	x28, [x19, #0x70]
  155fc8:      	cmp	x24, x28
  155fcc:      	b.ne	0x155fac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1c8>
  155fd0:      	mov	x28, x24
  155fd4:      	str	x23, [sp, #0x88]
  155fd8:      	cbz	w26, 0x156094 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b0>
  155fdc:      	cmp	x23, x22
  155fe0:      	cset	w8, lo
  155fe4:      	tst	w11, w8
  155fe8:      	b.eq	0x156094 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b0>
  155fec:      	cmp	x23, #0x8
  155ff0:      	b.hs	0x156ff8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1214>
  155ff4:      	mov	x26, x11
  155ff8:      	cmp	x28, x24
  155ffc:      	b.hs	0x156098 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b4>
  156000:      	ldr	x8, [sp, #0x68]
  156004:      	ldr	x9, [x8, x23, lsl #3]
  156008:      	cbz	x9, 0x156098 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b4>
  15600c:      	ldr	x10, [x19, #0x60]
  156010:      	ldrb	w8, [x10, x28]
  156014:      	cmp	w8, #0x22
  156018:      	b.ne	0x156098 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b4>
  15601c:      	add	x11, x28, #0x1
  156020:      	ldr	w14, [x9, #0x4]
  156024:      	add	x8, x11, x14
  156028:      	cmp	x8, x24
  15602c:      	ccmp	x8, x28, #0x0, lo
  156030:      	b.ls	0x156098 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b4>
  156034:      	ldrb	w12, [x10, x8]
  156038:      	cmp	w12, #0x22
  15603c:      	b.ne	0x156098 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b4>
  156040:      	add	x1, x10, x11
  156044:      	cbz	w14, 0x156080 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x29c>
  156048:      	add	x9, x9, #0x14
  15604c:      	mov	x10, x14
  156050:      	mov	x11, x1
  156054:      	ldrb	w12, [x11], #0x1
  156058:      	cmp	w12, #0x5c
  15605c:      	b.eq	0x156098 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b4>
  156060:      	cmp	w12, #0x22
  156064:      	b.eq	0x156098 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b4>
  156068:      	ldrb	w13, [x9], #0x1
  15606c:      	cmp	w12, #0x20
  156070:      	ccmp	w12, w13, #0x0, hs
  156074:      	b.ne	0x156098 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b4>
  156078:      	subs	x10, x10, #0x1
  15607c:      	b.ne	0x156054 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x270>
  156080:      	add	x8, x8, #0x1
  156084:      	str	x8, [x19, #0x70]
  156088:      	mov	w24, #0x1               ; =1
  15608c:      	mov	x23, #-0x1              ; =-1
  156090:      	b	0x1560b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2d4>
  156094:      	mov	x26, x11
  156098:      	sub	x0, x29, #0x80
  15609c:      	mov	x1, x19
  1560a0:      	bl	0x1560a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2bc>
  1560a4:      	ldur	x23, [x29, #-0x80]
  1560a8:      	cmn	x23, #0x2
  1560ac:      	b.eq	0x156e3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1058>
  1560b0:      	mov	w24, #0x0               ; =0
  1560b4:      	ldp	x1, x14, [x29, #-0x78]
  1560b8:      	mov	x28, x21
  1560bc:      	ldp	x9, x8, [x19, #0x68]
  1560c0:      	cmp	x8, x9
  1560c4:      	b.hs	0x156a9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcb8>
  1560c8:      	ldr	x10, [x19, #0x60]
  1560cc:      	ldrb	w11, [x10, x8]
  1560d0:      	cmp	w11, #0x3a
  1560d4:      	b.hi	0x156a9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcb8>
  1560d8:      	lsr	x12, x25, x11
  1560dc:      	tbz	w12, #0x0, 0x1560f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x310>
  1560e0:      	add	x8, x8, #0x1
  1560e4:      	str	x8, [x19, #0x70]
  1560e8:      	cmp	x9, x8
  1560ec:      	b.ne	0x1560cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2e8>
  1560f0:      	b	0x156a9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcb8>
  1560f4:      	cmp	x11, #0x3a
  1560f8:      	b.ne	0x156a9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcb8>
  1560fc:      	stp	x14, x1, [sp, #0x30]
  156100:      	add	x8, x8, #0x1
  156104:      	str	x8, [x19, #0x70]
  156108:      	mov	x0, x19
  15610c:      	bl	0x15610c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x328>
  156110:      	ldrb	w8, [x19, #0xd4]
  156114:      	tbz	w8, #0x0, 0x156f08 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1124>
  156118:      	ldr	x9, [sp, #0x188]
  15611c:      	cmn	x9, #0x1
  156120:      	ldp	x3, x17, [sp, #0x30]
  156124:      	str	x0, [sp, #0x28]
  156128:      	b.eq	0x1561e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x3fc>
  15612c:      	ldr	x8, [sp, #0x1b8]
  156130:      	cmn	x8, #0x1
  156134:      	b.eq	0x156230 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x44c>
  156138:      	ldp	x8, x11, [sp, #0x1f0]
  15613c:      	ldr	x10, [sp, #0x200]
  156140:      	ldr	x9, [sp, #0x208]
  156144:      	eor	x11, x11, x3
  156148:      	mov	x13, #0x7f2d            ; =32557
  15614c:      	movk	x13, #0x4c95, lsl #16
  156150:      	movk	x13, #0xf42d, lsl #32
  156154:      	movk	x13, #0x5851, lsl #48
  156158:      	mul	x12, x11, x13
  15615c:      	umulh	x11, x11, x13
  156160:      	eor	x11, x11, x12
  156164:      	add	x11, x3, x11
  156168:      	mul	x11, x11, x13
  15616c:      	cmp	x3, #0x8
  156170:      	b.ls	0x156288 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x4a4>
  156174:      	cmp	x3, #0x10
  156178:      	b.ls	0x156338 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x554>
  15617c:      	add	x12, x17, x3
  156180:      	ldp	x12, x13, [x12, #-0x10]
  156184:      	eor	x12, x10, x12
  156188:      	eor	x13, x13, x9
  15618c:      	mul	x14, x13, x12
  156190:      	umulh	x12, x13, x12
  156194:      	eor	x12, x12, x14
  156198:      	add	x11, x11, x8
  15619c:      	eor	x11, x11, x12
  1561a0:      	ror	x11, x11, #0x29
  1561a4:      	mov	x13, x17
  1561a8:      	mov	x12, x3
  1561ac:      	ldp	x15, x14, [x13], #0x10
  1561b0:      	sub	x12, x12, #0x10
  1561b4:      	eor	x15, x10, x15
  1561b8:      	eor	x14, x14, x9
  1561bc:      	mul	x16, x14, x15
  1561c0:      	umulh	x14, x14, x15
  1561c4:      	eor	x14, x14, x16
  1561c8:      	add	x11, x11, x8
  1561cc:      	eor	x11, x11, x14
  1561d0:      	ror	x11, x11, #0x29
  1561d4:      	cmp	x12, #0x10
  1561d8:      	b.hi	0x1561ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x3c8>
  1561dc:      	b	0x156414 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x630>
  1561e0:      	ldr	w8, [sp, #0x9c]
  1561e4:      	tbz	w8, #0x0, 0x1562a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x4c4>
  1561e8:      	ldr	w8, [sp, #0x98]
  1561ec:      	tbz	w8, #0x0, 0x156fec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1208>
  1561f0:      	ldp	x9, x8, [sp, #0x80]
  1561f4:      	cmp	x8, x9
  1561f8:      	ldr	x21, [sp, #0x90]
  1561fc:      	mov	x11, x26
  156200:      	ldr	w26, [sp, #0x98]
  156204:      	b.hs	0x156554 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x770>
  156208:      	tbz	w24, #0x0, 0x156510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x72c>
  15620c:      	ldr	x0, [sp, #0x88]
  156210:      	cmp	x0, #0x7
  156214:      	b.hi	0x157030 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x124c>
  156218:      	ldr	x8, [sp, #0x68]
  15621c:      	ldr	x10, [x8, x0, lsl #3]
  156220:      	add	x0, x0, #0x1
  156224:      	str	x0, [sp, #0x88]
  156228:      	mov	w9, #0x1                ; =1
  15622c:      	b	0x15656c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x788>
  156230:      	str	x9, [sp, #0x10]
  156234:      	ldp	x1, x24, [sp, #0x190]
  156238:      	cmp	x24, #0x80
  15623c:      	b.ne	0x1562cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x4e8>
  156240:      	mov	w8, #0x1                ; =1
  156244:      	strb	w8, [x19, #0xd6]
  156248:      	add	x8, sp, #0x188
  15624c:      	add	x0, x8, #0x30
  156250:      	mov	x28, x1
  156254:      	bl	0x156254 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x470>
  156258:      	ldp	x3, x17, [sp, #0x30]
  15625c:      	ldr	x8, [sp, #0x1b8]
  156260:      	cmn	x8, #0x1
  156264:      	b.ne	0x156138 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x354>
  156268:      	mov	x0, x17
  15626c:      	mov	x1, x3
  156270:      	bl	0x156270 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x48c>
  156274:      	mov	x12, x0
  156278:      	add	x22, x28, #0x400
  15627c:      	ldr	w9, [sp, #0x9c]
  156280:      	mov	x10, x28
  156284:      	b	0x1562f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x50c>
  156288:      	cmp	x3, #0x1
  15628c:      	b.ls	0x156348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x564>
  156290:      	add	x13, x17, x3
  156294:      	cmp	x3, #0x3
  156298:      	b.ls	0x1563e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x5fc>
  15629c:      	ldr	w12, [x17]
  1562a0:      	ldur	w13, [x13, #-0x4]
  1562a4:      	b	0x1563f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x610>
  1562a8:      	mov	x0, x17
  1562ac:      	mov	x1, x3
  1562b0:      	bl	0x1562b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x4cc>
  1562b4:      	mov	x10, x0
  1562b8:      	mov	w9, #0x0                ; =0
  1562bc:      	ldr	x21, [sp, #0x90]
  1562c0:      	mov	x11, x26
  1562c4:      	ldr	w26, [sp, #0x98]
  1562c8:      	b	0x15656c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x788>
  1562cc:      	str	x1, [sp, #0x8]
  1562d0:      	mov	x0, x17
  1562d4:      	mov	x1, x3
  1562d8:      	bl	0x1562d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x4f4>
  1562dc:      	mov	x12, x0
  1562e0:      	ldr	w9, [sp, #0x9c]
  1562e4:      	cbz	x24, 0x156914 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb30>
  1562e8:      	ldr	x10, [sp, #0x8]
  1562ec:      	add	x22, x10, x24, lsl #3
  1562f0:      	ldr	x8, [sp, #0x88]
  1562f4:      	cmp	x8, #0x0
  1562f8:      	cset	w8, eq
  1562fc:      	orr	w8, w8, w9
  156300:      	tbz	w8, #0x0, 0x156358 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x574>
  156304:      	mov	x0, #0x0                ; =0
  156308:      	mov	x8, x10
  15630c:      	mov	x11, x26
  156310:      	ldr	w26, [sp, #0x98]
  156314:      	ldr	x1, [sp, #0x38]
  156318:      	ldr	x9, [x8], #0x8
  15631c:      	cmp	x9, x12
  156320:      	b.eq	0x1563bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x5d8>
  156324:      	add	x0, x0, #0x1
  156328:      	cmp	x8, x22
  15632c:      	b.ne	0x156318 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x534>
  156330:      	mov	x28, x21
  156334:      	b	0x15693c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb58>
  156338:      	ldr	x12, [x17]
  15633c:      	add	x13, x17, x3
  156340:      	ldur	x13, [x13, #-0x8]
  156344:      	b	0x1563f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x610>
  156348:      	b.ne	0x1563ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x608>
  15634c:      	ldrb	w12, [x17]
  156350:      	mov	x13, x12
  156354:      	b	0x1563f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x610>
  156358:      	stp	x24, x10, [sp]
  15635c:      	str	x27, [sp, #0x18]
  156360:      	mov	x24, #0x0               ; =0
  156364:      	mov	x27, x10
  156368:      	ldp	x2, x1, [sp, #0x30]
  15636c:      	b	0x15637c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x598>
  156370:      	sub	x24, x24, #0x1
  156374:      	cmp	x27, x22
  156378:      	b.eq	0x156924 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb40>
  15637c:      	ldr	x8, [x27], #0x8
  156380:      	cmp	x8, x12
  156384:      	b.eq	0x1563ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x5c8>
  156388:      	ldr	w9, [x8, #0x4]
  15638c:      	cmp	x2, x9
  156390:      	b.ne	0x156370 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x58c>
  156394:      	add	x0, x8, #0x14
  156398:      	mov	x28, x12
  15639c:      	bl	0x15639c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x5b8>
  1563a0:      	mov	x12, x28
  1563a4:      	ldp	x2, x1, [sp, #0x30]
  1563a8:      	cbnz	w0, 0x156370 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x58c>
  1563ac:      	neg	x0, x24
  1563b0:      	ldr	x27, [sp, #0x18]
  1563b4:      	mov	x11, x26
  1563b8:      	ldr	w26, [sp, #0x98]
  1563bc:      	ldr	x9, [sp, #0x20]
  1563c0:      	cmp	x0, x9
  1563c4:      	ldr	x8, [sp, #0x60]
  1563c8:      	b.hs	0x157020 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x123c>
  1563cc:      	mov	x28, x21
  1563d0:      	ldr	x10, [sp, #0x28]
  1563d4:      	str	x10, [x8, x0, lsl #3]
  1563d8:      	ldr	x21, [sp, #0x90]
  1563dc:      	b	0x156980 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb9c>
  1563e0:      	ldrh	w12, [x17]
  1563e4:      	ldurb	w13, [x13, #-0x1]
  1563e8:      	b	0x1563f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x610>
  1563ec:      	mov	x12, #0x0               ; =0
  1563f0:      	mov	x13, #0x0               ; =0
  1563f4:      	eor	x10, x12, x10
  1563f8:      	eor	x9, x13, x9
  1563fc:      	mul	x12, x9, x10
  156400:      	umulh	x9, x9, x10
  156404:      	eor	x9, x9, x12
  156408:      	add	x10, x11, x8
  15640c:      	eor	x9, x10, x9
  156410:      	ror	x11, x9, #0x29
  156414:      	mul	x9, x11, x8
  156418:      	umulh	x8, x11, x8
  15641c:      	eor	x8, x8, x9
  156420:      	neg	w9, w11
  156424:      	ror	x24, x8, x9
  156428:      	ldp	x4, x28, [sp, #0x190]
  15642c:      	add	x8, sp, #0x188
  156430:      	add	x0, x8, #0x30
  156434:      	mov	x1, x24
  156438:      	mov	x2, x17
  15643c:      	mov	x5, x28
  156440:      	bl	0x156440 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x65c>
  156444:      	tbz	w0, #0x0, 0x156470 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x68c>
  156448:      	ldr	x9, [sp, #0x20]
  15644c:      	cmp	x1, x9
  156450:      	b.hs	0x15700c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1228>
  156454:      	mov	x11, x26
  156458:      	ldr	x8, [sp, #0x60]
  15645c:      	ldr	x10, [sp, #0x28]
  156460:      	str	x10, [x8, x1, lsl #3]
  156464:      	mov	x28, x21
  156468:      	ldr	x21, [sp, #0x90]
  15646c:      	b	0x156504 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x720>
  156470:      	str	x27, [sp, #0x18]
  156474:      	cmn	x23, #0x1
  156478:      	b.eq	0x156488 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x6a4>
  15647c:      	ldp	x1, x0, [sp, #0x30]
  156480:      	bl	0x156480 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x69c>
  156484:      	b	0x156494 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x6b0>
  156488:      	add	x0, x19, #0x20
  15648c:      	ldp	x2, x1, [sp, #0x30]
  156490:      	bl	0x156490 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x6ac>
  156494:      	mov	x27, x0
  156498:      	add	x8, sp, #0x188
  15649c:      	add	x0, x8, #0x30
  1564a0:      	mov	x1, x24
  1564a4:      	mov	x2, x28
  1564a8:      	bl	0x1564a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x6c4>
  1564ac:      	ldr	x24, [sp, #0x198]
  1564b0:      	ldr	x8, [sp, #0x188]
  1564b4:      	cmp	x24, x8
  1564b8:      	b.eq	0x156a0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xc28>
  1564bc:      	ldr	x8, [sp, #0x190]
  1564c0:      	ldr	x9, [sp, #0x1a0]
  1564c4:      	str	x27, [x8, x24, lsl #3]
  1564c8:      	add	x8, x24, #0x1
  1564cc:      	str	x8, [sp, #0x198]
  1564d0:      	ldr	x24, [sp, #0x1b0]
  1564d4:      	cmp	x24, x9
  1564d8:      	mov	x28, x21
  1564dc:      	b.eq	0x156a18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xc34>
  1564e0:      	ldr	x8, [sp, #0x1a8]
  1564e4:      	str	x8, [sp, #0x60]
  1564e8:      	ldr	x9, [sp, #0x28]
  1564ec:      	str	x9, [x8, x24, lsl #3]
  1564f0:      	add	x9, x24, #0x1
  1564f4:      	str	x9, [sp, #0x1b0]
  1564f8:      	ldr	x27, [sp, #0x18]
  1564fc:      	ldr	x21, [sp, #0x90]
  156500:      	mov	x11, x26
  156504:      	ldr	w26, [sp, #0x98]
  156508:      	ldr	x1, [sp, #0x38]
  15650c:      	b	0x156980 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb9c>
  156510:      	ldr	x0, [sp, #0x88]
  156514:      	cmp	x0, #0x8
  156518:      	b.hs	0x157040 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x125c>
  15651c:      	ldr	x8, [sp, #0x68]
  156520:      	ldr	x9, [x8, x0, lsl #3]
  156524:      	ldr	w8, [x9, #0x4]
  156528:      	cmp	x3, x8
  15652c:      	b.ne	0x156554 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x770>
  156530:      	add	x0, x9, #0x14
  156534:      	mov	x1, x17
  156538:      	mov	x2, x3
  15653c:      	mov	x24, x11
  156540:      	str	x9, [sp, #0x18]
  156544:      	bl	0x156544 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x760>
  156548:      	ldr	x10, [sp, #0x18]
  15654c:      	ldp	x3, x17, [sp, #0x30]
  156550:      	cbz	w0, 0x156a28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xc44>
  156554:      	mov	x0, x17
  156558:      	mov	x1, x3
  15655c:      	bl	0x15655c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x778>
  156560:      	mov	x10, x0
  156564:      	mov	w11, #0x0               ; =0
  156568:      	mov	w9, #0x0                ; =0
  15656c:      	ldr	x8, [sp, #0x88]
  156570:      	cmp	x8, #0x0
  156574:      	str	w9, [sp, #0x9c]
  156578:      	csinc	w24, w9, wzr, ne
  15657c:      	cmp	x28, #0x9
  156580:      	b.hs	0x156fac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11c8>
  156584:      	ldp	x2, x1, [sp, #0x30]
  156588:      	ldr	x9, [sp, #0x20]
  15658c:      	cbz	x28, 0x1568e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb00>
  156590:      	ldr	x8, [sp, #0x100]
  156594:      	cmp	x8, x10
  156598:      	b.eq	0x156904 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb20>
  15659c:      	tbnz	w24, #0x0, 0x1565d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x7f0>
  1565a0:      	ldr	w9, [x8, #0x4]
  1565a4:      	cmp	x2, x9
  1565a8:      	ldr	x9, [sp, #0x20]
  1565ac:      	b.ne	0x1565d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x7f0>
  1565b0:      	add	x0, x8, #0x14
  1565b4:      	mov	x26, x11
  1565b8:      	str	x10, [sp, #0x18]
  1565bc:      	bl	0x1565bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x7d8>
  1565c0:      	ldp	x10, x9, [sp, #0x18]
  1565c4:      	ldp	x2, x1, [sp, #0x30]
  1565c8:      	mov	x11, x26
  1565cc:      	ldr	w26, [sp, #0x98]
  1565d0:      	cbz	w0, 0x156904 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb20>
  1565d4:      	cmp	x28, #0x1
  1565d8:      	b.eq	0x1568e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb00>
  1565dc:      	ldr	x9, [sp, #0x108]
  1565e0:      	add	x8, sp, #0x148
  1565e4:      	add	x8, x8, #0x8
  1565e8:      	cmp	x9, x10
  1565ec:      	b.eq	0x156908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
  1565f0:      	tbnz	w24, #0x0, 0x15662c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x848>
  1565f4:      	ldr	w8, [x9, #0x4]
  1565f8:      	cmp	x2, x8
  1565fc:      	b.ne	0x15662c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x848>
  156600:      	add	x0, x9, #0x14
  156604:      	mov	x26, x11
  156608:      	str	x10, [sp, #0x18]
  15660c:      	bl	0x15660c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x828>
  156610:      	ldr	x10, [sp, #0x18]
  156614:      	ldp	x2, x1, [sp, #0x30]
  156618:      	mov	x11, x26
  15661c:      	ldr	w26, [sp, #0x98]
  156620:      	add	x8, sp, #0x148
  156624:      	add	x8, x8, #0x8
  156628:      	cbz	w0, 0x156908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
  15662c:      	cmp	x28, #0x2
  156630:      	ldr	x9, [sp, #0x20]
  156634:      	b.eq	0x1568e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb00>
  156638:      	ldr	x9, [sp, #0x110]
  15663c:      	add	x8, sp, #0x148
  156640:      	add	x8, x8, #0x10
  156644:      	cmp	x9, x10
  156648:      	b.eq	0x156908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
  15664c:      	tbnz	w24, #0x0, 0x156688 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x8a4>
  156650:      	ldr	w8, [x9, #0x4]
  156654:      	cmp	x2, x8
  156658:      	b.ne	0x156688 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x8a4>
  15665c:      	add	x0, x9, #0x14
  156660:      	mov	x26, x11
  156664:      	str	x10, [sp, #0x18]
  156668:      	bl	0x156668 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x884>
  15666c:      	ldr	x10, [sp, #0x18]
  156670:      	ldp	x2, x1, [sp, #0x30]
  156674:      	mov	x11, x26
  156678:      	ldr	w26, [sp, #0x98]
  15667c:      	add	x8, sp, #0x148
  156680:      	add	x8, x8, #0x10
  156684:      	cbz	w0, 0x156908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
  156688:      	cmp	x28, #0x3
  15668c:      	ldr	x9, [sp, #0x20]
  156690:      	b.eq	0x1568e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb00>
  156694:      	ldr	x9, [sp, #0x118]
  156698:      	add	x8, sp, #0x148
  15669c:      	add	x8, x8, #0x18
  1566a0:      	cmp	x9, x10
  1566a4:      	b.eq	0x156908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
  1566a8:      	tbnz	w24, #0x0, 0x1566e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x900>
  1566ac:      	ldr	w8, [x9, #0x4]
  1566b0:      	cmp	x2, x8
  1566b4:      	b.ne	0x1566e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x900>
  1566b8:      	add	x0, x9, #0x14
  1566bc:      	mov	x26, x11
  1566c0:      	str	x10, [sp, #0x18]
  1566c4:      	bl	0x1566c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x8e0>
  1566c8:      	ldr	x10, [sp, #0x18]
  1566cc:      	ldp	x2, x1, [sp, #0x30]
  1566d0:      	mov	x11, x26
  1566d4:      	ldr	w26, [sp, #0x98]
  1566d8:      	add	x8, sp, #0x148
  1566dc:      	add	x8, x8, #0x18
  1566e0:      	cbz	w0, 0x156908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
  1566e4:      	cmp	x28, #0x4
  1566e8:      	ldr	x9, [sp, #0x20]
  1566ec:      	b.eq	0x1568e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb00>
  1566f0:      	ldr	x9, [sp, #0x120]
  1566f4:      	add	x8, sp, #0x148
  1566f8:      	add	x8, x8, #0x20
  1566fc:      	cmp	x9, x10
  156700:      	b.eq	0x156908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
  156704:      	tbnz	w24, #0x0, 0x156740 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x95c>
  156708:      	ldr	w8, [x9, #0x4]
  15670c:      	cmp	x2, x8
  156710:      	b.ne	0x156740 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x95c>
  156714:      	add	x0, x9, #0x14
  156718:      	mov	x26, x11
  15671c:      	str	x10, [sp, #0x18]
  156720:      	bl	0x156720 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x93c>
  156724:      	ldr	x10, [sp, #0x18]
  156728:      	ldp	x2, x1, [sp, #0x30]
  15672c:      	mov	x11, x26
  156730:      	ldr	w26, [sp, #0x98]
  156734:      	add	x8, sp, #0x148
  156738:      	add	x8, x8, #0x20
  15673c:      	cbz	w0, 0x156908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
  156740:      	cmp	x28, #0x5
  156744:      	ldr	x9, [sp, #0x20]
  156748:      	b.eq	0x1568e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb00>
  15674c:      	ldr	x9, [sp, #0x128]
  156750:      	add	x8, sp, #0x148
  156754:      	add	x8, x8, #0x28
  156758:      	cmp	x9, x10
  15675c:      	b.eq	0x156908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
  156760:      	tbnz	w24, #0x0, 0x15679c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x9b8>
  156764:      	ldr	w8, [x9, #0x4]
  156768:      	cmp	x2, x8
  15676c:      	b.ne	0x15679c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x9b8>
  156770:      	add	x0, x9, #0x14
  156774:      	mov	x26, x11
  156778:      	str	x10, [sp, #0x18]
  15677c:      	bl	0x15677c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x998>
  156780:      	ldr	x10, [sp, #0x18]
  156784:      	ldp	x2, x1, [sp, #0x30]
  156788:      	mov	x11, x26
  15678c:      	ldr	w26, [sp, #0x98]
  156790:      	add	x8, sp, #0x148
  156794:      	add	x8, x8, #0x28
  156798:      	cbz	w0, 0x156908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
  15679c:      	cmp	x28, #0x6
  1567a0:      	ldr	x9, [sp, #0x20]
  1567a4:      	b.eq	0x1568e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb00>
  1567a8:      	ldr	x9, [sp, #0x130]
  1567ac:      	add	x8, sp, #0x148
  1567b0:      	add	x8, x8, #0x30
  1567b4:      	cmp	x9, x10
  1567b8:      	b.eq	0x156908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
  1567bc:      	tbnz	w24, #0x0, 0x1567f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xa14>
  1567c0:      	ldr	w8, [x9, #0x4]
  1567c4:      	cmp	x2, x8
  1567c8:      	b.ne	0x1567f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xa14>
  1567cc:      	add	x0, x9, #0x14
  1567d0:      	mov	x26, x11
  1567d4:      	str	x10, [sp, #0x18]
  1567d8:      	bl	0x1567d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x9f4>
  1567dc:      	ldr	x10, [sp, #0x18]
  1567e0:      	ldp	x2, x1, [sp, #0x30]
  1567e4:      	mov	x11, x26
  1567e8:      	ldr	w26, [sp, #0x98]
  1567ec:      	add	x8, sp, #0x148
  1567f0:      	add	x8, x8, #0x30
  1567f4:      	cbz	w0, 0x156908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
  1567f8:      	cmp	x28, #0x7
  1567fc:      	ldr	x9, [sp, #0x20]
  156800:      	b.eq	0x1568e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb00>
  156804:      	ldr	x9, [sp, #0x138]
  156808:      	add	x8, sp, #0x148
  15680c:      	add	x8, x8, #0x38
  156810:      	cmp	x9, x10
  156814:      	b.eq	0x156908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
  156818:      	tbnz	w24, #0x0, 0x156850 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xa6c>
  15681c:      	ldr	w8, [x9, #0x4]
  156820:      	cmp	x2, x8
  156824:      	b.ne	0x156850 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xa6c>
  156828:      	add	x0, x9, #0x14
  15682c:      	str	w11, [sp, #0x30]
  156830:      	mov	x24, x10
  156834:      	bl	0x156834 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xa50>
  156838:      	mov	x10, x24
  15683c:      	ldr	x1, [sp, #0x38]
  156840:      	ldr	w11, [sp, #0x30]
  156844:      	add	x8, sp, #0x148
  156848:      	add	x8, x8, #0x38
  15684c:      	cbz	w0, 0x156908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
  156850:      	cmp	x28, #0x8
  156854:      	ldr	x9, [sp, #0x20]
  156858:      	b.ne	0x1568e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb00>
  15685c:      	mov	x21, x10
  156860:      	mov	x26, x11
  156864:      	mov	w0, #0x80               ; =128
  156868:      	mov	w1, #0x8                ; =8
  15686c:      	bl	0x15686c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xa88>
  156870:      	cbz	x0, 0x157050 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x126c>
  156874:      	mov	x24, x0
  156878:      	mov	w0, #0x80               ; =128
  15687c:      	mov	w1, #0x8                ; =8
  156880:      	bl	0x156880 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xa9c>
  156884:      	str	x0, [sp, #0x60]
  156888:      	cbz	x0, 0x157050 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x126c>
  15688c:      	ldp	q0, q1, [sp, #0x100]
  156890:      	stp	q0, q1, [x24]
  156894:      	ldp	q0, q1, [sp, #0x120]
  156898:      	stp	q0, q1, [x24, #0x20]
  15689c:      	add	x9, sp, #0x148
  1568a0:      	ldp	q0, q1, [x9]
  1568a4:      	ldr	x8, [sp, #0x60]
  1568a8:      	stp	q0, q1, [x8]
  1568ac:      	ldp	q0, q1, [x9, #0x20]
  1568b0:      	stp	q0, q1, [x8, #0x20]
  1568b4:      	str	x21, [x24, #0x40]
  1568b8:      	ldr	x10, [sp, #0x28]
  1568bc:      	str	x10, [x8, #0x40]
  1568c0:      	mov	w10, #0x10              ; =16
  1568c4:      	stp	x10, x24, [sp, #0x188]
  1568c8:      	ldp	q0, q1, [sp, #0x40]
  1568cc:      	str	q1, [x9, #0x50]
  1568d0:      	str	x8, [sp, #0x1a8]
  1568d4:      	mov	w28, #0x8               ; =8
  1568d8:      	stur	q0, [x9, #0x68]
  1568dc:      	mov	w9, #0x9                ; =9
  1568e0:      	b	0x1564fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x718>
  1568e4:      	add	x8, sp, #0x100
  1568e8:      	str	x10, [x8, x28, lsl #3]
  1568ec:      	add	x8, sp, #0x148
  1568f0:      	ldr	x10, [sp, #0x28]
  1568f4:      	str	x10, [x8, x28, lsl #3]
  1568f8:      	add	x28, x28, #0x1
  1568fc:      	str	x28, [sp, #0x70]
  156900:      	b	0x156980 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb9c>
  156904:      	add	x8, sp, #0x148
  156908:      	ldp	x9, x10, [sp, #0x20]
  15690c:      	str	x10, [x8]
  156910:      	b	0x156980 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb9c>
  156914:      	mov	x11, x26
  156918:      	ldr	w26, [sp, #0x98]
  15691c:      	ldr	x1, [sp, #0x38]
  156920:      	b	0x156938 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb54>
  156924:      	ldr	x27, [sp, #0x18]
  156928:      	mov	x28, x21
  15692c:      	mov	x11, x26
  156930:      	ldr	w26, [sp, #0x98]
  156934:      	ldr	x24, [sp]
  156938:      	ldr	x10, [sp, #0x8]
  15693c:      	ldr	x8, [sp, #0x10]
  156940:      	cmp	x24, x8
  156944:      	ldr	x21, [sp, #0x90]
  156948:      	ldr	x9, [sp, #0x20]
  15694c:      	b.eq	0x156a34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xc50>
  156950:      	str	x12, [x10, x24, lsl #3]
  156954:      	add	x8, x24, #0x1
  156958:      	str	x8, [sp, #0x198]
  15695c:      	ldr	x8, [sp, #0x1a0]
  156960:      	cmp	x9, x8
  156964:      	b.eq	0x156a78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xc94>
  156968:      	ldr	x8, [sp, #0x1a8]
  15696c:      	str	x8, [sp, #0x60]
  156970:      	ldr	x10, [sp, #0x28]
  156974:      	str	x10, [x8, x9, lsl #3]
  156978:      	add	x9, x9, #0x1
  15697c:      	str	x9, [sp, #0x1b0]
  156980:      	ldp	x24, x8, [x19, #0x68]
  156984:      	cmp	x8, x24
  156988:      	b.hs	0x1569c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xbdc>
  15698c:      	mov	x12, x9
  156990:      	ldr	x9, [x19, #0x60]
  156994:      	ldrb	w10, [x9, x8]
  156998:      	cmp	w10, #0x20
  15699c:      	b.hi	0x1569bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xbd8>
  1569a0:      	lsr	x10, x25, x10
  1569a4:      	tbz	w10, #0x0, 0x1569bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xbd8>
  1569a8:      	add	x8, x8, #0x1
  1569ac:      	str	x8, [x19, #0x70]
  1569b0:      	cmp	x24, x8
  1569b4:      	b.ne	0x156994 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xbb0>
  1569b8:      	b	0x156aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcc4>
  1569bc:      	mov	x9, x12
  1569c0:      	cmp	x8, x24
  1569c4:      	b.hs	0x156aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcc4>
  1569c8:      	str	x9, [sp, #0x20]
  1569cc:      	ldr	x9, [x19, #0x60]
  1569d0:      	ldrb	w9, [x9, x8]
  1569d4:      	cmp	w9, #0x2c
  1569d8:      	b.ne	0x156aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcc4>
  1569dc:      	mov	x21, x28
  1569e0:      	add	x28, x8, #0x1
  1569e4:      	str	x28, [x19, #0x70]
  1569e8:      	cmp	x23, #0x1
  1569ec:      	ldp	x22, x23, [sp, #0x80]
  1569f0:      	b.lt	0x155fa0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1bc>
  1569f4:      	mov	x0, x1
  1569f8:      	mov	x24, x11
  1569fc:      	bl	0x1569fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xc18>
  156a00:      	mov	x11, x24
  156a04:      	ldp	x24, x28, [x19, #0x68]
  156a08:      	b	0x155fa0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1bc>
  156a0c:      	add	x0, sp, #0x188
  156a10:      	bl	0x156a10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xc2c>
  156a14:      	b	0x1564bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x6d8>
  156a18:      	add	x8, sp, #0x188
  156a1c:      	add	x0, x8, #0x18
  156a20:      	bl	0x156a20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xc3c>
  156a24:      	b	0x1564e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x6fc>
  156a28:      	mov	x11, x24
  156a2c:      	ldr	x0, [sp, #0x88]
  156a30:      	b	0x156220 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x43c>
  156a34:      	add	x0, sp, #0x188
  156a38:      	str	x24, [sp]
  156a3c:      	mov	x24, x11
  156a40:      	str	x12, [sp, #0x60]
  156a44:      	bl	0x156a44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xc60>
  156a48:      	ldr	x12, [sp, #0x60]
  156a4c:      	ldr	x1, [sp, #0x38]
  156a50:      	mov	x11, x24
  156a54:      	ldr	x24, [sp]
  156a58:      	ldr	x10, [sp, #0x190]
  156a5c:      	ldr	x9, [sp, #0x1b0]
  156a60:      	str	x12, [x10, x24, lsl #3]
  156a64:      	add	x8, x24, #0x1
  156a68:      	str	x8, [sp, #0x198]
  156a6c:      	ldr	x8, [sp, #0x1a0]
  156a70:      	cmp	x9, x8
  156a74:      	b.ne	0x156968 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb84>
  156a78:      	add	x8, sp, #0x188
  156a7c:      	add	x0, x8, #0x18
  156a80:      	mov	x24, x11
  156a84:      	str	x9, [sp, #0x20]
  156a88:      	bl	0x156a88 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xca4>
  156a8c:      	ldr	x9, [sp, #0x20]
  156a90:      	ldr	x1, [sp, #0x38]
  156a94:      	mov	x11, x24
  156a98:      	b	0x156968 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb84>
  156a9c:      	strb	wzr, [x19, #0xd4]
  156aa0:      	ldr	x21, [sp, #0x90]
  156aa4:      	ldr	w26, [sp, #0x98]
  156aa8:      	cmp	x23, #0x1
  156aac:      	ldr	w24, [sp, #0x9c]
  156ab0:      	b.lt	0x156abc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcd8>
  156ab4:      	mov	x0, x1
  156ab8:      	bl	0x156ab8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcd4>
  156abc:      	ldp	x9, x8, [x19, #0x68]
  156ac0:      	cmp	x8, x9
  156ac4:      	b.hs	0x156bb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xdcc>
  156ac8:      	ldr	x10, [x19, #0x60]
  156acc:      	mov	x11, #0x2600            ; =9728
  156ad0:      	movk	x11, #0x1, lsl #32
  156ad4:      	ldrb	w12, [x10, x8]
  156ad8:      	cmp	w12, #0x20
  156adc:      	b.hi	0x156afc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd18>
  156ae0:      	lsr	x13, x11, x12
  156ae4:      	tbz	w13, #0x0, 0x156afc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd18>
  156ae8:      	add	x8, x8, #0x1
  156aec:      	str	x8, [x19, #0x70]
  156af0:      	cmp	x9, x8
  156af4:      	b.ne	0x156ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcf0>
  156af8:      	b	0x156bb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xdcc>
  156afc:      	cmp	w12, #0x7d
  156b00:      	b.ne	0x156bb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xdcc>
  156b04:      	add	x8, x8, #0x1
  156b08:      	str	x8, [x19, #0x70]
  156b0c:      	ldr	x23, [sp, #0x188]
  156b10:      	cmn	x23, #0x1
  156b14:      	b.ne	0x156bc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xddc>
  156b18:      	and	w8, w26, w24
  156b1c:      	ldr	w2, [sp, #0x7c]
  156b20:      	tbz	w8, #0x0, 0x156b40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd5c>
  156b24:      	ldr	x8, [sp, #0x70]
  156b28:      	ldr	x9, [sp, #0x80]
  156b2c:      	cmp	x9, x8
  156b30:      	b.ne	0x156b40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd5c>
  156b34:      	ldp	x9, x8, [sp, #0x80]
  156b38:      	cmp	x8, x9
  156b3c:      	b.eq	0x156c54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe70>
  156b40:      	cmp	x28, #0x9
  156b44:      	b.hs	0x156f80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x119c>
  156b48:      	ldr	x8, [x19, #0x78]
  156b4c:      	cmp	x28, x8
  156b50:      	b.ne	0x156b70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd8c>
  156b54:      	ldr	x21, [x19, #0xc0]
  156b58:      	cbz	x21, 0x156b70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd8c>
  156b5c:      	cbz	x28, 0x156e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
  156b60:      	ldr	x8, [x19, #0x80]
  156b64:      	ldr	x9, [sp, #0x100]
  156b68:      	cmp	x8, x9
  156b6c:      	b.eq	0x156e4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1068>
  156b70:      	add	x0, sp, #0x100
  156b74:      	mov	x1, x28
  156b78:      	bl	0x156b78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd94>
  156b7c:      	mov	x21, x0
  156b80:      	mov	x24, x1
  156b84:      	str	x28, [x19, #0x78]
  156b88:      	lsl	x2, x28, #3
  156b8c:      	add	x0, x19, #0x80
  156b90:      	add	x1, sp, #0x100
  156b94:      	bl	0x156b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xdb0>
  156b98:      	mov	x2, x24
  156b9c:      	str	x21, [x19, #0xc0]
  156ba0:      	str	w24, [x19, #0xd0]
  156ba4:      	cmp	x28, #0x9
  156ba8:      	b.lo	0x156c5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe78>
  156bac:      	b	0x156c30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe4c>
  156bb0:      	strb	wzr, [x19, #0xd4]
  156bb4:      	ldr	x23, [sp, #0x188]
  156bb8:      	cmn	x23, #0x1
  156bbc:      	b.eq	0x156b18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd34>
  156bc0:      	ldp	x0, x1, [sp, #0x190]
  156bc4:      	cmp	x1, #0x9
  156bc8:      	b.hs	0x156c48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe64>
  156bcc:      	ldr	x8, [x19, #0x78]
  156bd0:      	cmp	x1, x8
  156bd4:      	b.ne	0x156bf4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe10>
  156bd8:      	ldr	x21, [x19, #0xc0]
  156bdc:      	cbz	x21, 0x156bf4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe10>
  156be0:      	cbz	x1, 0x156e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
  156be4:      	ldr	x8, [x19, #0x80]
  156be8:      	ldr	x9, [x0]
  156bec:      	cmp	x8, x9
  156bf0:      	b.eq	0x156d90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xfac>
  156bf4:      	mov	x24, x0
  156bf8:      	mov	x25, x1
  156bfc:      	bl	0x156bfc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe18>
  156c00:      	mov	x21, x0
  156c04:      	mov	x26, x1
  156c08:      	str	x25, [x19, #0x78]
  156c0c:      	lsl	x2, x25, #3
  156c10:      	add	x0, x19, #0x80
  156c14:      	mov	x1, x24
  156c18:      	bl	0x156c18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe34>
  156c1c:      	mov	x2, x26
  156c20:      	str	x21, [x19, #0xc0]
  156c24:      	str	w26, [x19, #0xd0]
  156c28:      	cmp	x28, #0x9
  156c2c:      	b.lo	0x156c5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe78>
  156c30:      	adrp	x3, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x21c>
  156c34:      	add	x3, x3, #0x0
  156c38:      	mov	x0, #0x0                ; =0
  156c3c:      	mov	x1, x28
  156c40:      	mov	w2, #0x8                ; =8
  156c44:      	bl	0x156c44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe60>
  156c48:      	bl	0x156c48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe64>
  156c4c:      	mov	x21, x0
  156c50:      	mov	x2, x1
  156c54:      	cmp	x28, #0x9
  156c58:      	b.hs	0x156c30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe4c>
  156c5c:      	ldr	x8, [sp, #0x1b0]
  156c60:      	cmn	x23, #0x1
  156c64:      	add	x9, sp, #0x148
  156c68:      	ldr	x10, [sp, #0x60]
  156c6c:      	csel	x3, x9, x10, eq
  156c70:      	csel	x4, x28, x8, eq
  156c74:      	add	x0, x19, #0x20
  156c78:      	mov	x1, x21
  156c7c:      	bl	0x156c7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe98>
  156c80:      	mov	x19, x0
  156c84:      	ldrb	w8, [x20, #0x20]
  156c88:      	cbnz	w8, 0x156f58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1174>
  156c8c:      	ldr	x8, [x20]
  156c90:      	cbnz	x8, 0x156fe0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11fc>
  156c94:      	ldr	x8, [x20, #0x18]
  156c98:      	cmp	x27, x8
  156c9c:      	b.hi	0x156ca4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xec0>
  156ca0:      	str	x27, [x20, #0x18]
  156ca4:      	ldr	x8, [sp, #0x188]
  156ca8:      	cmn	x8, #0x1
  156cac:      	b.eq	0x156d68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf84>
  156cb0:      	cbz	x8, 0x156cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xed8>
  156cb4:      	ldr	x0, [sp, #0x190]
  156cb8:      	bl	0x156cb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xed4>
  156cbc:      	ldr	x8, [sp, #0x1a0]
  156cc0:      	cbz	x8, 0x156ccc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xee8>
  156cc4:      	ldr	x0, [sp, #0x1a8]
  156cc8:      	bl	0x156cc8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xee4>
  156ccc:      	ldr	x20, [sp, #0x1b8]
  156cd0:      	cmn	x20, #0x1
  156cd4:      	b.eq	0x156d68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf84>
  156cd8:      	ldr	x9, [sp, #0x1d8]
  156cdc:      	cbz	x9, 0x156d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf1c>
  156ce0:      	lsl	x8, x9, #4
  156ce4:      	add	x9, x8, x9
  156ce8:      	cmn	x9, #0x19
  156cec:      	b.eq	0x156d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf1c>
  156cf0:      	ldr	x9, [sp, #0x1d0]
  156cf4:      	sub	x8, x9, x8
  156cf8:      	sub	x0, x8, #0x10
  156cfc:      	bl	0x156cfc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf18>
  156d00:      	cbz	x20, 0x156d68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf84>
  156d04:      	ldr	x0, [sp, #0x1c0]
  156d08:      	bl	0x156d08 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf24>
  156d0c:      	b	0x156d68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf84>
  156d10:      	b	0x155ec4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe0>
  156d14:      	sub	x0, x29, #0x68
  156d18:      	mov	x1, #0x0                ; =0
  156d1c:      	bl	0x156d1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf38>
  156d20:      	mov	x2, x1
  156d24:      	mov	x1, x0
  156d28:      	str	xzr, [x19, #0x78]
  156d2c:      	str	x0, [x19, #0xc0]
  156d30:      	str	w2, [x19, #0xd0]
  156d34:      	add	x0, x19, #0x20
  156d38:      	mov	w3, #0x8                ; =8
  156d3c:      	mov	x4, #0x0                ; =0
  156d40:      	bl	0x156d40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf5c>
  156d44:      	mov	x19, x0
  156d48:      	ldrb	w8, [x20, #0x20]
  156d4c:      	cbnz	w8, 0x156f98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11b4>
  156d50:      	ldr	x8, [x20]
  156d54:      	cbnz	x8, 0x156fe0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11fc>
  156d58:      	ldr	x8, [x20, #0x18]
  156d5c:      	cmp	x27, x8
  156d60:      	b.hi	0x156d68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf84>
  156d64:      	str	x27, [x20, #0x18]
  156d68:      	mov	x0, #0x7ffd000000000000 ; =9222527611924643840
  156d6c:      	bfxil	x0, x19, #0, #48
  156d70:      	add	sp, sp, #0x240
  156d74:      	ldp	x29, x30, [sp, #0x50]
  156d78:      	ldp	x20, x19, [sp, #0x40]
  156d7c:      	ldp	x22, x21, [sp, #0x30]
  156d80:      	ldp	x24, x23, [sp, #0x20]
  156d84:      	ldp	x26, x25, [sp, #0x10]
  156d88:      	ldp	x28, x27, [sp], #0x60
  156d8c:      	ret
  156d90:      	cmp	x1, #0x1
  156d94:      	b.eq	0x156e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
  156d98:      	ldr	x8, [x19, #0x88]
  156d9c:      	ldr	x9, [x0, #0x8]
  156da0:      	cmp	x8, x9
  156da4:      	b.ne	0x156bf4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe10>
  156da8:      	cmp	x1, #0x2
  156dac:      	b.eq	0x156e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
  156db0:      	ldr	x8, [x19, #0x90]
  156db4:      	ldr	x9, [x0, #0x10]
  156db8:      	cmp	x8, x9
  156dbc:      	b.ne	0x156bf4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe10>
  156dc0:      	cmp	x1, #0x3
  156dc4:      	b.eq	0x156e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
  156dc8:      	ldr	x8, [x19, #0x98]
  156dcc:      	ldr	x9, [x0, #0x18]
  156dd0:      	cmp	x8, x9
  156dd4:      	b.ne	0x156bf4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe10>
  156dd8:      	cmp	x1, #0x4
  156ddc:      	b.eq	0x156e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
  156de0:      	ldr	x8, [x19, #0xa0]
  156de4:      	ldr	x9, [x0, #0x20]
  156de8:      	cmp	x8, x9
  156dec:      	b.ne	0x156bf4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe10>
  156df0:      	cmp	x1, #0x5
  156df4:      	b.eq	0x156e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
  156df8:      	ldr	x8, [x19, #0xa8]
  156dfc:      	ldr	x9, [x0, #0x28]
  156e00:      	cmp	x8, x9
  156e04:      	b.ne	0x156bf4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe10>
  156e08:      	cmp	x1, #0x6
  156e0c:      	b.eq	0x156e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
  156e10:      	ldr	x8, [x19, #0xb0]
  156e14:      	ldr	x9, [x0, #0x30]
  156e18:      	cmp	x8, x9
  156e1c:      	b.ne	0x156bf4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe10>
  156e20:      	cmp	x1, #0x7
  156e24:      	b.eq	0x156e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
  156e28:      	ldr	x8, [x19, #0xb8]
  156e2c:      	ldr	x9, [x0, #0x38]
  156e30:      	cmp	x8, x9
  156e34:      	b.ne	0x156bf4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe10>
  156e38:      	b	0x156e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
  156e3c:      	mov	x28, x21
  156e40:      	ldr	x21, [sp, #0x90]
  156e44:      	ldp	w26, w24, [sp, #0x98]
  156e48:      	b	0x156abc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcd8>
  156e4c:      	cmp	x28, #0x1
  156e50:      	b.ne	0x156e64 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1080>
  156e54:      	ldr	w2, [x19, #0xd0]
  156e58:      	cmp	x28, #0x9
  156e5c:      	b.lo	0x156c5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe78>
  156e60:      	b	0x156c30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe4c>
  156e64:      	ldr	x8, [x19, #0x88]
  156e68:      	ldr	x9, [sp, #0x108]
  156e6c:      	cmp	x8, x9
  156e70:      	b.ne	0x156b70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd8c>
  156e74:      	cmp	x28, #0x2
  156e78:      	b.eq	0x156e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
  156e7c:      	ldr	x8, [x19, #0x90]
  156e80:      	ldr	x9, [sp, #0x110]
  156e84:      	cmp	x8, x9
  156e88:      	b.ne	0x156b70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd8c>
  156e8c:      	cmp	x28, #0x3
  156e90:      	b.eq	0x156e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
  156e94:      	ldr	x8, [x19, #0x98]
  156e98:      	ldr	x9, [sp, #0x118]
  156e9c:      	cmp	x8, x9
  156ea0:      	b.ne	0x156b70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd8c>
  156ea4:      	cmp	x28, #0x4
  156ea8:      	b.eq	0x156e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
  156eac:      	ldr	x8, [x19, #0xa0]
  156eb0:      	ldr	x9, [sp, #0x120]
  156eb4:      	cmp	x8, x9
  156eb8:      	b.ne	0x156b70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd8c>
  156ebc:      	cmp	x28, #0x5
  156ec0:      	b.eq	0x156e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
  156ec4:      	ldr	x8, [x19, #0xa8]
  156ec8:      	ldr	x9, [sp, #0x128]
  156ecc:      	cmp	x8, x9
  156ed0:      	b.ne	0x156b70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd8c>
  156ed4:      	cmp	x28, #0x6
  156ed8:      	b.eq	0x156e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
  156edc:      	ldr	x8, [x19, #0xb0]
  156ee0:      	ldr	x9, [sp, #0x130]
  156ee4:      	cmp	x8, x9
  156ee8:      	b.ne	0x156b70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd8c>
  156eec:      	cmp	x28, #0x7
  156ef0:      	b.eq	0x156e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
  156ef4:      	ldr	x8, [x19, #0xb8]
  156ef8:      	ldr	x9, [sp, #0x138]
  156efc:      	cmp	x8, x9
  156f00:      	b.ne	0x156b70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd8c>
  156f04:      	b	0x156e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
  156f08:      	ldr	x21, [sp, #0x90]
  156f0c:      	ldp	w26, w24, [sp, #0x98]
  156f10:      	ldr	x1, [sp, #0x38]
  156f14:      	cmp	x23, #0x1
  156f18:      	b.ge	0x156ab4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcd0>
  156f1c:      	b	0x156abc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcd8>
  156f20:      	cmp	w8, #0x1
  156f24:      	b.ne	0x156fa0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11bc>
  156f28:      	adrp	x1, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x21c>
  156f2c:      	add	x1, x1, #0x0
  156f30:      	mov	x0, x20
  156f34:      	bl	0x156f34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1150>
  156f38:      	strb	wzr, [x20, #0x20]
  156f3c:      	ldr	x8, [x20]
  156f40:      	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
  156f44:      	cmp	x8, x9
  156f48:      	b.lo	0x155ef4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x110>
  156f4c:      	adrp	x0, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x21c>
  156f50:      	add	x0, x0, #0x0
  156f54:      	bl	0x156f54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1170>
  156f58:      	cmp	w8, #0x2
  156f5c:      	b.eq	0x156fa0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11bc>
  156f60:      	adrp	x1, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x21c>
  156f64:      	add	x1, x1, #0x0
  156f68:      	mov	x0, x20
  156f6c:      	bl	0x156f6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1188>
  156f70:      	strb	wzr, [x20, #0x20]
  156f74:      	ldr	x8, [x20]
  156f78:      	cbz	x8, 0x156c94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xeb0>
  156f7c:      	b	0x156fe0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11fc>
  156f80:      	adrp	x3, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x21c>
  156f84:      	add	x3, x3, #0x0
  156f88:      	mov	x0, #0x0                ; =0
  156f8c:      	mov	x1, x28
  156f90:      	mov	w2, #0x8                ; =8
  156f94:      	bl	0x156f94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11b0>
  156f98:      	cmp	w8, #0x2
  156f9c:      	b.ne	0x156fc4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11e0>
  156fa0:      	adrp	x0, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x21c>
  156fa4:      	add	x0, x0, #0x0
  156fa8:      	bl	0x156fa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11c4>
  156fac:      	adrp	x3, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x21c>
  156fb0:      	add	x3, x3, #0x0
  156fb4:      	mov	x0, #0x0                ; =0
  156fb8:      	mov	x1, x28
  156fbc:      	mov	w2, #0x8                ; =8
  156fc0:      	bl	0x156fc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11dc>
  156fc4:      	adrp	x1, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x21c>
  156fc8:      	add	x1, x1, #0x0
  156fcc:      	mov	x0, x20
  156fd0:      	bl	0x156fd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11ec>
  156fd4:      	strb	wzr, [x20, #0x20]
  156fd8:      	ldr	x8, [x20]
  156fdc:      	cbz	x8, 0x156d58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf74>
  156fe0:      	adrp	x0, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x21c>
  156fe4:      	add	x0, x0, #0x0
  156fe8:      	bl	0x156fe8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1204>
  156fec:      	adrp	x0, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x21c>
  156ff0:      	add	x0, x0, #0x0
  156ff4:      	bl	0x156ff4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1210>
  156ff8:      	adrp	x2, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x21c>
  156ffc:      	add	x2, x2, #0x0
  157000:      	mov	x0, x23
  157004:      	mov	w1, #0x8                ; =8
  157008:      	bl	0x157008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1224>
  15700c:      	adrp	x2, 0x157000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x121c>
  157010:      	add	x2, x2, #0x0
  157014:      	mov	x0, x1
  157018:      	mov	x1, x9
  15701c:      	bl	0x15701c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1238>
  157020:      	adrp	x2, 0x157000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x121c>
  157024:      	add	x2, x2, #0x0
  157028:      	mov	x1, x9
  15702c:      	bl	0x15702c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1248>
  157030:      	adrp	x2, 0x157000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x121c>
  157034:      	add	x2, x2, #0x0
  157038:      	mov	w1, #0x8                ; =8
  15703c:      	bl	0x15703c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1258>
  157040:      	adrp	x2, 0x157000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x121c>
  157044:      	add	x2, x2, #0x0
  157048:      	mov	w1, #0x8                ; =8
  15704c:      	bl	0x15704c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1268>
  157050:      	mov	w0, #0x8                ; =8
  157054:      	mov	w1, #0x80               ; =128
  157058:      	bl	0x157058 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1274>

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_runtime.51e3211f3b89fd3b-cgu.0.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.phf-fda76137c618ed94.phf.e4e92736a1df7d19-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.phf_shared-a99412ae5fa8df63.phf_shared.d4b5e8e0605a820e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.pin_project_lite-9112ff0b4ca4c5f5.pin_project_lite.9e3a833d7736b09d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.portable_atomic-ee537db1fe67f1f1.portable_atomic.3d3e8745d3fefd81-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.potential_utf-7290d80b7d4fd7a6.potential_utf.3d03ee8112fd1596-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.prefix_trie-40e0fdfa96a3a51b.prefix_trie.aa2676338b217d25-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.psm-9f3b8da3ad16e1fa.psm.78bcf4d21b57561-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rand-492323155da95b1d.rand.6529a7c3eb82dfd6-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rand_core-6bacf6ecfee8446a.rand_core.fec9fb7b016054b8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.regex-23a1744e34a6bdd8.regex.5fe00e4da3593f57-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.regex_automata-05498c6e8207064c.regex_automata.2113017827263087-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.regex_syntax-dc078710f3e283e5.regex_syntax.5d77536cdc21bec2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.regress-4af654b3baeba21a.regress.56c9efe3abfd7dd9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.resolv_conf-589bb5b300ae9b62.resolv_conf.ef8ce2570ae6b7ca-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_demangle-a0db1312f42a1e44.rustc_demangle.e8c1817fde257fa-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_demangle-a84069e27028b871.rustc_demangle.6e498b991fca6ce6-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_hash-6acac617e2694d16.rustc_hash.8dd8e3d9c15ad472-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_std_workspace_alloc-5b4356182ec17e27.rustc_std_workspace_alloc.95a6ecb1e2b64b16-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_std_workspace_core-91fae2e614e9d003.rustc_std_workspace_core.5c33cd8176fbdf03-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ryu-88f4114cfee0f920.ryu.e5b11607222e9f1-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ryu_js-8203fc1e86d8300b.ryu_js.38024f8f2b58d396-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.scoped_tls-bea296576cbd4055.scoped_tls.4868881ed73f4220-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.scopeguard-3f34b2f52778ed6d.scopeguard.39c46ee7c3ff5c3a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.serde-b1698c4db99cd0f6.serde.ace619f76592a163-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.serde_core-7feea810e2b7e669.serde_core.91e6c9d28410876e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.serde_json-5f6cce1ec0bc1f51.serde_json.1881800b546529cc-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.serde_spanned-786a63d1fb99443c.serde_spanned.ecff9bd5fc6ed1cd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.signal_hook_registry-73f406794e9b58b9.signal_hook_registry.a304ee316af8aaf-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.simdutf8-6eaa160c64d9f76b.simdutf8.5e602d216e3b60b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.siphasher-3f0a76aeabf470da.siphasher.5dc93b2dddb35ff3-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.siphasher-a84eeb1952cd7c96.siphasher.63b0bb3e10f5fb09-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.slab-ce3c7619cdf98849.slab.4197f6b653c95390-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.slotmap-20ea319e01e10a36.slotmap.7f53c3097a475db5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.smallvec-0e7d453b7999d6bf.smallvec.a3fac2ce2795659-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.smartstring-dc627c0149b34430.smartstring.daa138bdd471414-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.socket2-c0fc5e20d9815054.socket2.325daa4db95003be-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.spin-419ef0217c1a7e9d.spin.124ce9ff3747f4d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.spki-68668ef35563db08.spki.dcea16c81f3faeb7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.stable_deref_trait-d05f845ec581f3c3.stable_deref_trait.20e7280df43487a4-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.stacker-e8215abced14b595.stacker.a64d36231c9b54e8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.static_assertions-26a67eb00cbe4a19.static_assertions.d246fd1a619c5f56-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.std-36f377630a6d9041.std.6435e32e5249d112-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.std_detect-4733c791661234cb.std_detect.19bab4874ad71232-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_atoms-920e18ec1ca531dc.swc_atoms.6e099e31e61309c3-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_common-d6bd2bc4e58d990f.swc_common.8fdf2470d9cfdc5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_ecma_ast-84ea4ee5ba95db2e.swc_ecma_ast.3d8d12e8f84f649c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_ecma_parser-8ec30cfb0eaf253d.swc_ecma_parser.bc422679edde26a7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_ecma_visit-b63461394357b0d4.swc_ecma_visit.c99e8944d3846bc7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_visit-64ac6e1c9cb7923d.swc_visit.2ab765cb666f8899-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.taffy-fe5c9a8e7c25c5f0.taffy.d86dff334662a800-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.temporal_rs-0fb585091cfff93a.temporal_rs.615be7171f19ae8f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.thiserror-1959f5c5ef95f8e0.thiserror.66a9b0aa6ac5659c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.thiserror-819934ff4cff447d.thiserror.262fe98a9286a6f8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.timezone_provider-734aa3cb276ec3ef.timezone_provider.c5d1d9aad8d3988f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tinystr-7460fd70af50815a.tinystr.f12ac1933cb9ba2b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tinyvec-747e19215a97d544.tinyvec.c739c1e068ab99ed-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tinyvec_macros-03c0b3b0828d119a.tinyvec_macros.a5317fef04132c16-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tokio-c09ace7016a21111.tokio.10f85077cf846efc-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tokio_util-b3b32b3e68ae174b.tokio_util.c2188b63290972ae-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.toml-e1d9f60e2a93edf6.toml.69efb9df2f8e67b3-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.toml_datetime-da06043cbfd6a3ff.toml_datetime.eed1431b100c0ba5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.toml_parser-a8ea5ac599f8d731.toml_parser.4dda3eb99405abdd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.toml_writer-86392e121e73ea49.toml_writer.612da603a2a255c9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tracing-1e99833042e023d4.tracing.480a63e3c00ffe5d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tracing_core-a4ce5df32b216be5.tracing_core.551518ce0c3162f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.triomphe-1f26ad013b2edc2b.triomphe.df0393428d78f2d2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tzif-f601d4f6882f6c91.tzif.4b87cacab3be6a39-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_id_start-b1b648fdc7033911.unicode_id_start.b451d75f4870a19-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_normalization-74312452efd83ea5.unicode_normalization.a9dba2d72fcfb0e9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_segmentation-9d17b5f253060a33.unicode_segmentation.418ba6cb19b4b691-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_width-9091f55f45a06a5b.unicode_width.2046f0e93b598eee-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_width-eefe794da3ddc491.unicode_width.81acccf54ab200a6-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unsafe_libyaml-6fc9986bea6e83a2.unsafe_libyaml.498c10ddae7016fa-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unwind-b34336196694d849.unwind.84a5a803a0d3b8e5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.url-937de9168f16e023.url.1a3dafb8678c931d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.utf8_iter-495f179a61b481d6.utf8_iter.c6d05cdf24642122-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.winnow-19e99833af0373f3.winnow.82b0bb40063afce5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.writeable-590fc088fec40648.writeable.5b4332e450c8b833-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.x509_cert-23c04dad6503524d.x509_cert.a1cd03d282d34aa8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.xxhash_rust-aca16904554a0e24.xxhash_rust.80a8560132cdda1a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.yoke-344345244b6e4947.yoke.e19373a6f771978b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zerocopy-99f7f8d1743ab073.zerocopy.c4d7aea3b77dbe79-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zerofrom-316567aba73be1b3.zerofrom.895504131b58bc4e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zeroize-c6a7916c40321e93.zeroize.9524028ebbc3b95a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zerotrie-5524f4e315dcaf36.zerotrie.47410e50260eb1e0-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zerovec-8f5cd301f36e965a.zerovec.9ea12157016434b1-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zmij-8f9e3f41857f0483.zmij.180143115354781b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zstd-2da8f76fd714c069.zstd.f736b1e5325616ef-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zstd_safe-e368634d5a7f6151.zstd_safe.828b5cf371cee27e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zstd_sys-959dee5ed6b0497e.zstd_sys.67acef213add5ee5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f17b5a9852f781a4-perry_sjlj.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-debug.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-entropy_common.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-error_private.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-fse_decompress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-pool.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-threading.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-zstd_common.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-fse_compress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-hist.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-huf_compress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_compress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_compress_literals.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_compress_sequences.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_compress_superblock.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_double_fast.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_fast.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_lazy.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_ldm.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_opt.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_preSplit.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstdmt_compress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(88f362f13b0528ed-huf_decompress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(88f362f13b0528ed-zstd_ddict.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(88f362f13b0528ed-zstd_decompress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(88f362f13b0528ed-zstd_decompress_block.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(a6c81c75fc82913a-cover.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(a6c81c75fc82913a-divsufsort.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(a6c81c75fc82913a-fastcover.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(a6c81c75fc82913a-zdict.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v01.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v02.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v03.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v04.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v05.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v06.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v07.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(7faed3f8272f2313-huf_decompress_amd64.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(b85de32113adef8e-static.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(4f9a91766097c4c5-aarch_aapcs64.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.000.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.001.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.002.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.003.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.004.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.005.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.006.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.007.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.008.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.009.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.010.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.011.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.012.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.013.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.014.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.015.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.016.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.017.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.018.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.019.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.020.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.021.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.022.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.023.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.024.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.025.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.026.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.027.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.028.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.029.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.030.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.031.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.032.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.033.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.034.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.035.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.036.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.037.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.038.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.039.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.040.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.041.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.042.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.043.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.044.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.045.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.046.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.047.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.048.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.049.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.050.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.051.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.052.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.053.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.054.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.055.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.056.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.057.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.058.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.059.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.060.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.061.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.062.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.063.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.064.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.065.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.066.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.067.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.068.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.069.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.070.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.071.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.072.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.073.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.074.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.075.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.076.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.077.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.078.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.079.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.080.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.081.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.082.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.083.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.084.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.085.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.086.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.087.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.088.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.089.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.090.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.091.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.092.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.093.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.094.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.095.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.096.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.097.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.098.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.099.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.100.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.101.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.102.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.103.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.104.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.105.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.106.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.107.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.108.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.109.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.110.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.111.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.112.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.113.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.114.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.115.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.116.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.117.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.118.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.119.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.120.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.121.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.122.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.123.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.124.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.125.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.126.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.127.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.128.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.129.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.130.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.131.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.132.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.133.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.134.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.135.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.136.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.137.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.138.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.139.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.140.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.141.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.142.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.143.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.144.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.145.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.146.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.147.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.148.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.149.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.150.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.151.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.152.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.153.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.154.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.155.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.156.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.157.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.158.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.159.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.160.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.161.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.162.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.163.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.164.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.165.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.166.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.167.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.168.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.169.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.170.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.171.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.172.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.173.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.174.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.175.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.176.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.177.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.178.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.179.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.180.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.181.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.182.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.183.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.184.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.185.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.186.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.187.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.188.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.189.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.190.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.191.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.192.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.193.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.194.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.195.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.196.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.197.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.198.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.199.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.200.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.201.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.202.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.203.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.204.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.205.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.206.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.207.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.208.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.209.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.210.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.211.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.212.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.213.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.214.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.215.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.216.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.217.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.218.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.219.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.220.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.221.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.222.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.223.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.224.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.225.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.226.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.227.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.228.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas1_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas1_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas1_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas1_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas2_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas2_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas2_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas2_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas4_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas4_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas4_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas4_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas8_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas8_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas8_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas8_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas16_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas16_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas16_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas16_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp1_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp1_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp1_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp1_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp2_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp2_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp2_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp2_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp4_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp4_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp4_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp4_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp8_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp8_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp8_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp8_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd1_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd1_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd1_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd1_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd2_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd2_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd2_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd2_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd4_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd4_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd4_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd4_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd8_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd8_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd8_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd8_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr1_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr1_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr1_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr1_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr2_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr2_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr2_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr2_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr4_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr4_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr4_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr4_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr8_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr8_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr8_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr8_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor1_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor1_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor1_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor1_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor2_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor2_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor2_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor2_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor4_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor4_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor4_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor4_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor8_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor8_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor8_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor8_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset1_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset1_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset1_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset1_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset2_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset2_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset2_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset2_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset4_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset4_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset4_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset4_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset8_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset8_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset8_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset8_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(ad3ac4dcdcbf93cb-aarch64.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-absvdi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-absvsi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-absvti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-addvdi3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-addvsi3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-addvti3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-cmpdi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-cmpti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-divdc3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-divsc3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-fp_mode.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-ffsti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-int_util.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-muldc3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-mulsc3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-multc3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-mulvdi3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-mulvsi3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-mulvti3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negdf2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negdi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negsf2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negvdi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negvsi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negvti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-paritydi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-paritysi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-parityti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-popcountdi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-popcountsi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-popcountti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-subvdi3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-subvsi3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-subvti3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-ucmpdi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-ucmpti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_flag_clear.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_flag_clear_explicit.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_flag_test_and_set.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_flag_test_and_set_explicit.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_signal_fence.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_thread_fence.o):	file format mach-o arm64
