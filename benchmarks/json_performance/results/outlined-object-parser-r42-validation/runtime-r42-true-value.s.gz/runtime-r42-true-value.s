
benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.0hzsjplwwpevv88lz9s5mjuly.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.addr2line-cfa71d2872fc9749.addr2line.2f803ffa438d6abd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.adler2-4a012095652e66be.adler2.4472f1a4039cb8c5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ahash-9514a3e3390ca75c.ahash.2d29b14819ea2aa7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.aho_corasick-0465e7d1dc158f68.aho_corasick.d4e9aa874147907-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.alloc-f7cf0325b2c4fbea.alloc.91507a9d0c1147cb-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.allocator_api2-f4879b7f65d9dad6.allocator_api2.c20efd3e8c1c526a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.anyhow-b00ab8880ea60f5a.anyhow.dd2c21d3a09e2169-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.base64-32ce9211317f5731.base64.d7b02bb0c01b4c7f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.base64ct-dc4539cdef9387c1.base64ct.a13194e5b06d043e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.better_scoped_tls-5623aa5785b63992.better_scoped_tls.c4fc4593c97e81eb-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bit_set-1b43a885fb453b97.bit_set.e296561ef88d1b25-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bit_vec-8353e4eca9cb6885.bit_vec.2905b060439a1ee5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bitflags-a267cd1b6450301e.bitflags.9b23124bf16832ba-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bytecount-f903ae1df949a853.bytecount.d96a36eac4eddd2e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bytes-4d639afa28f500e9.bytes.4b80b056274f495a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bytes_str-9ed5b56fd3acead7.bytes_str.33b6ea97d807fd24-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.calendrical_calculations-d30e5fcb342f8309.calendrical_calculations.ff7d2d4d240655f4-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.cfg_if-11f50a868fc78507.cfg_if.b001c247f2cdfacc-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.cfg_if-65f3efe385514d24.cfg_if.f06090845af655d8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.chacha20-894520615b692380.chacha20.255207753dfba230-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.combine-c70df9144a05ac41.combine.c3909ca49e68f1f0-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.const_oid-7b92d750363681a1.const_oid.59ced0f90a34feb8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.core-1eb26884753bb7ec.core.e07e215301fbc6f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.core_maths-11146167d2fbcd32.core_maths.423ca64e8f23f19a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.cty-f1fa0ed128de58b9.cty.6b73d1db9cbf7b8b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.data_encoding-98155a5d48e5ec99.data_encoding.d70ce69399f262ca-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.debug_unreachable-9bb446589bc29b16.debug_unreachable.fe3a47d951b816d9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.der-9bb76198d0a38255.der.6bdd1208ba76c73b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.dirs-756cabb78e25a929.dirs.ffe05ade48c56831-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.dirs_sys-e3f5752242e2a022.dirs_sys.ee3c17565b1fea59-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.either-432e8663b5d638fc.either.94df2b7257068b13-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.errno-ea9565cc054c881d.errno.7569163361032131-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.fancy_regex-2c325c7f9e823393.fancy_regex.ca4df3e112cd6cb7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.fixed_decimal-7e6fe6d640091744.fixed_decimal.7d257809aa775ff2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.flagset-ac9650c267cc7e77.flagset.b1438c243c6ff671-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.form_urlencoded-c338c7e2455734e8.form_urlencoded.1ab2c7c11d3385cf-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_core-61582daa6c57b257.futures_core.e5c5ead29f2a5185-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_io-313f277a9d659f14.futures_io.2354b3f0d921f5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_sink-24e92a078488c232.futures_sink.477b530395196519-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_task-40d3c4f4c699450f.futures_task.a793339b5ba19ee-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_util-9ca40d38221ccdc3.futures_util.7622420df399cdfe-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.getrandom-888caac6f3a9d896.getrandom.7f8b53275961c005-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.getrandom-c7786f5309f7c1d1.getrandom.c00a3944440a318d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.gimli-1dc154aa9e77af93.gimli.5901559d024f6e07-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.gimli-4a08f02c6b3bfed9.gimli.adbe390e003e7ecb-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hashbrown-4d32db017aa9b7a5.hashbrown.8f7d8026e818751e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hashbrown-af4a3f18b4ae97c9.hashbrown.cb64e714776d3e07-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hickory_proto-5da21089dd651d86.hickory_proto.b3e58bdc73b32711-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hostname-1a758cf59ba97d19.hostname.9e06914bfa9458c0-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hstr-990b134b3f579b0d.hstr.7816630fc46099ef-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_calendar-41dd45c4986e5371.icu_calendar.525e0f6d835cb712-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_calendar_data-edd7996660c4190e.icu_calendar_data.f47bf9c505eeaff2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_collections-559b63245c10ac1b.icu_collections.377b7b7ce659b1b9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_datetime-034ad7cdc455dac0.icu_datetime.3f12d4db0ba0d033-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_datetime_data-618583f1e8f98068.icu_datetime_data.ae5f6f8bf868927e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_decimal-77beaba6d2163e9b.icu_decimal.fe46e9f4b123130a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_decimal_data-367997f4010d8153.icu_decimal_data.d6f512199a2a447f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale-b42b3e1360358fc5.icu_locale.b3f10ef03c9651a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale_core-849ff933c9f4951a.icu_locale_core.e916c9be12dd52d2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale_data-9e7081d145555538.icu_locale_data.c24e3b51aa8226f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale_fallback-a6e3f83d98e2a67b.icu_locale_fallback.56246df7a44619a1-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale_fallback_data-1291c99bd372729e.icu_locale_fallback_data.afad649127a1756e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_normalizer-bc7f251896dc40bd.icu_normalizer.ff2a905c7940b1f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_normalizer_data-268487fee32ac8f0.icu_normalizer_data.8ad43135a1ce7d1f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_pattern-d59a83eb0e463baf.icu_pattern.be117b667d76f6f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_plurals-3c9070f8fa2510af.icu_plurals.740da912aa775a52-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_plurals_data-bd8faf2099579a9d.icu_plurals_data.45ea6926f1b7622f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_properties-6d0d35008dd1dbf9.icu_properties.c9b54ac36f6ff15d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_properties_data-59005f70ef52dd72.icu_properties_data.2b4f163e924ba5b8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_provider-6781ca5b429f4aee.icu_provider.29b968015b290673-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_time-54550ac874f62853.icu_time.5b58251af801c00d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_time_data-4cd606d3217ab0c8.icu_time_data.e93588578a1fe390-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.idna-8d5c8377e58f6d08.idna.aba1e6179509c9b5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.idna_adapter-16f147720f57f9af.idna_adapter.f7fd92e26f89f8f1-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ipnet-16dcea07c26a0bdf.ipnet.a68501ef90183657-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.itoa-72113ee16b8d0ab6.itoa.6381431f0c25948c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ixdtf-da83a26e439607da.ixdtf.9e61fc26cbabd4cd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.jiff_tzdb-c9f0d309035f3bef.jiff_tzdb.8ad45a94b44687b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.lazy_static-7647d3e036babadd.lazy_static.f61d0a0c663b0e34-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.libc-6299013de1b57308.libc.89db0e620931259c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.libc-dadb5a82a633a7dc.libc.6bde7fa237754b8a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.libm-ac5dff0b52f67d03.libm.554bb06ed6d99dbd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.libmimalloc_sys-b1e23e8a6c5928c2.libmimalloc_sys.29accdad47f6ede0-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.litemap-2e12d9912a397309.litemap.571f336a3d6bbb56-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.lock_api-b480096f46123924.lock_api.874432d3f0bce2f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.log-169df25b841fb738.log.f3f704751685a618-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.mach2-6f42ba587ea54125.mach2.e7620912d05e5c3f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.memchr-1c6a1f6f6196cc2c.memchr.9afcaf06bb01edf2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.memchr-db6845a68ce0f188.memchr.9fcb083790588d2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.miette-85b477785fba33d9.miette.50b4b2d1c414b7ce-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.mimalloc-bcf0b21589b8fa53.mimalloc.95dbff8ab7587b05-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.miniz_oxide-2b20def31e1e0221.miniz_oxide.3e514f74919855b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.mio-f4b45263c6fb2e44.mio.430e10d80ebe3d9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.node_semver-359c30260c8449dc.node_semver.233ee6db2f2c4e46-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.nom-d7f48be26f93c2f7.nom.749d1dbb25d8ab32-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.num_bigint-aa73c29d2bd73516.num_bigint.9ee201b330206f6-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.num_integer-e318a12cf646126f.num_integer.9033146fac8f1134-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.num_traits-46d1dcb8872f2815.num_traits.d52ad62a33d7f1a9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.object-836e641a18d03406.object.f0cec6469c5dcf18-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.once_cell-01ae4f33c7a79bb7.once_cell.3768cf33248bb273-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.option_ext-8f1216324e4e6381.option_ext.92b51bce59292c52-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.panic_abort-905bfe97e1134923.panic_abort.cec6bdc4f2a8e72d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.parking_lot-4acf5fa50a52bd18.parking_lot.b59ab0d8f2549f8e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.parking_lot_core-0dcf47a90d11c4e4.parking_lot_core.502597fbe5df1389-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.pem_rfc7468-d976dcafab7c7e37.pem_rfc7468.757403f363ad557c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.percent_encoding-2e8ac337530122b2.percent_encoding.f83c908de861c15d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_diagnostics-fba70546dd9f3424.perry_diagnostics.cefa4a43ff59d614-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_dispatch-0bc0b01b9b7736fe.perry_dispatch.cd02373148e7c215-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_parser-b68fb40287dd2e20.perry_parser.6e33b45a5046bf8f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_runtime-9458b86ff25d0db1.perry_runtime.261c4ba5a81df8f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000015490c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_>:
  15490c:      	sub	sp, sp, #0x60
  154910:      	stp	x24, x23, [sp, #0x20]
  154914:      	stp	x22, x21, [sp, #0x30]
  154918:      	stp	x20, x19, [sp, #0x40]
  15491c:      	stp	x29, x30, [sp, #0x50]
  154920:      	add	x29, sp, #0x50
  154924:      	ldp	x2, x19, [x0, #0x68]
  154928:      	cmp	x19, x2
  15492c:      	b.hs	0x154964 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x58>
  154930:      	ldr	x8, [x0, #0x60]
  154934:      	mov	x9, #0x2600             ; =9728
  154938:      	movk	x9, #0x1, lsl #32
  15493c:      	ldrb	w10, [x8, x19]
  154940:      	cmp	w10, #0x20
  154944:      	b.hi	0x154964 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x58>
  154948:      	lsr	x10, x9, x10
  15494c:      	tbz	w10, #0x0, 0x154964 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x58>
  154950:      	add	x19, x19, #0x1
  154954:      	str	x19, [x0, #0x70]
  154958:      	cmp	x2, x19
  15495c:      	b.ne	0x15493c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x30>
  154960:      	b	0x15505c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
  154964:      	cmp	x19, x2
  154968:      	b.hs	0x15505c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
  15496c:      	ldr	x12, [x0, #0x60]
  154970:      	add	x9, x12, x19
  154974:      	ldrb	w8, [x9]
  154978:      	cmp	w8, #0x65
  15497c:      	b.le	0x1549d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc4>
  154980:      	cmp	w8, #0x73
  154984:      	b.gt	0x154acc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1c0>
  154988:      	cmp	w8, #0x66
  15498c:      	b.eq	0x154b38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x22c>
  154990:      	cmp	w8, #0x6e
  154994:      	b.ne	0x154b20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x214>
  154998:      	add	x1, x19, #0x4
  15499c:      	cmp	x1, x2
  1549a0:      	b.hi	0x15505c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
  1549a4:      	cmn	x19, #0x5
  1549a8:      	b.hi	0x1551a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x89c>
  1549ac:      	ldr	w8, [x9]
  1549b0:      	mov	w9, #0x756e             ; =30062
  1549b4:      	movk	w9, #0x6c6c, lsl #16
  1549b8:      	cmp	w8, w9
  1549bc:      	b.ne	0x15505c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
  1549c0:      	mov	x19, #0x2               ; =2
  1549c4:      	movk	x19, #0x7ffc, lsl #48
  1549c8:      	str	x1, [x0, #0x70]
  1549cc:      	b	0x155068 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
  1549d0:      	cmp	w8, #0x22
  1549d4:      	b.eq	0x154af4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1e8>
  1549d8:      	cmp	w8, #0x2d
  1549dc:      	b.eq	0x154bbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x2b0>
  1549e0:      	cmp	w8, #0x5b
  1549e4:      	b.ne	0x154b20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x214>
  1549e8:      	add	x8, x19, #0x1
  1549ec:      	str	x8, [x0, #0x70]
  1549f0:      	cmp	x8, x2
  1549f4:      	b.hs	0x154a24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x118>
  1549f8:      	mov	x9, #0x2600             ; =9728
  1549fc:      	movk	x9, #0x1, lsl #32
  154a00:      	ldrb	w10, [x12, x8]
  154a04:      	cmp	w10, #0x20
  154a08:      	b.hi	0x154a24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x118>
  154a0c:      	lsr	x10, x9, x10
  154a10:      	tbz	w10, #0x0, 0x154a24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x118>
  154a14:      	add	x8, x8, #0x1
  154a18:      	str	x8, [x0, #0x70]
  154a1c:      	cmp	x2, x8
  154a20:      	b.ne	0x154a00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xf4>
  154a24:      	mov	x20, x0
  154a28:      	adrp	x0, 0x154000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x46c>
  154a2c:      	ldr	x0, [x0]
  154a30:      	ldr	x8, [x0]
  154a34:      	blr	x8
  154a38:      	mov	x19, x0
  154a3c:      	ldrb	w8, [x0, #0x20]
  154a40:      	cbnz	w8, 0x155150 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x844>
  154a44:      	ldr	x8, [x19]
  154a48:      	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
  154a4c:      	cmp	x8, x9
  154a50:      	b.hs	0x15517c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x870>
  154a54:      	mov	x0, x20
  154a58:      	ldr	x1, [x19, #0x18]
  154a5c:      	ldp	x8, x9, [x20, #0x68]
  154a60:      	subs	x8, x8, x9
  154a64:      	b.ls	0x154c24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x318>
  154a68:      	ldr	x10, [x0, #0x60]
  154a6c:      	ldrb	w9, [x10, x9]
  154a70:      	cmp	w9, #0x7b
  154a74:      	b.ne	0x154c24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x318>
  154a78:      	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
  154a7c:      	movk	x9, #0xaaab
  154a80:      	umulh	x8, x8, x9
  154a84:      	lsr	x8, x8, #6
  154a88:      	mov	w9, #0x10               ; =16
  154a8c:      	cmp	x8, #0x10
  154a90:      	csel	x8, x8, x9, hi
  154a94:      	mov	w9, #0x4000             ; =16384
  154a98:      	cmp	x8, #0x4, lsl #12       ; =0x4000
  154a9c:      	csel	x2, x8, x9, lo
  154aa0:      	mov	x19, x0
  154aa4:      	add	x0, sp, #0x8
  154aa8:      	mov	x20, x1
  154aac:      	add	x1, x19, #0x20
  154ab0:      	bl	0x154ab0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a4>
  154ab4:      	add	x1, sp, #0x8
  154ab8:      	mov	x0, x19
  154abc:      	mov	x2, x20
  154ac0:      	bl	0x154ac0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b4>
  154ac4:      	mov	x19, x0
  154ac8:      	b	0x155068 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
  154acc:      	cmp	w8, #0x74
  154ad0:      	b.eq	0x154b80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x274>
  154ad4:      	cmp	w8, #0x7b
  154ad8:      	b.ne	0x154b20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x214>
  154adc:      	ldp	x29, x30, [sp, #0x50]
  154ae0:      	ldp	x20, x19, [sp, #0x40]
  154ae4:      	ldp	x22, x21, [sp, #0x30]
  154ae8:      	ldp	x24, x23, [sp, #0x20]
  154aec:      	add	sp, sp, #0x60
  154af0:      	b	0x154af0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1e4>
  154af4:      	ldr	x8, [x0]
  154af8:      	cmp	x8, #0x1
  154afc:      	b.ne	0x154c3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x330>
  154b00:      	ldr	x8, [x0, #0x8]
  154b04:      	cmp	x8, x19
  154b08:      	b.ne	0x154c3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x330>
  154b0c:      	ldp	x9, x8, [x0, #0x10]
  154b10:      	str	x9, [x0, #0x70]
  154b14:      	mov	x19, #0x7fff000000000000 ; =9223090561878065152
  154b18:      	bfxil	x19, x8, #0, #48
  154b1c:      	b	0x155068 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
  154b20:      	sub	w8, w8, #0x30
  154b24:      	cmp	w8, #0x9
  154b28:      	b.hi	0x15505c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
  154b2c:      	mov	w13, #0x0               ; =0
  154b30:      	mov	x10, x19
  154b34:      	b	0x154bc8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x2bc>
  154b38:      	add	x1, x19, #0x5
  154b3c:      	cmp	x1, x2
  154b40:      	b.hi	0x15505c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
  154b44:      	cmn	x19, #0x6
  154b48:      	b.hi	0x155188 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x87c>
  154b4c:      	ldrb	w8, [x9, #0x4]
  154b50:      	ldr	w9, [x9]
  154b54:      	orr	x8, x9, x8, lsl #32
  154b58:      	mov	x9, #0x6166             ; =24934
  154b5c:      	movk	x9, #0x736c, lsl #16
  154b60:      	movk	x9, #0x65, lsl #32
  154b64:      	cmp	x8, x9
  154b68:      	b.ne	0x15505c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
  154b6c:      	str	x1, [x0, #0x70]
  154b70:      	mov	x8, #0x2                ; =2
  154b74:      	movk	x8, #0x7ffc, lsl #48
  154b78:      	orr	x19, x8, #0x1
  154b7c:      	b	0x155068 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
  154b80:      	add	x1, x19, #0x4
  154b84:      	cmp	x1, x2
  154b88:      	b.hi	0x15505c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
  154b8c:      	cmn	x19, #0x5
  154b90:      	b.hi	0x155198 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x88c>
  154b94:      	ldr	w8, [x9]
  154b98:      	mov	w9, #0x7274             ; =29300
  154b9c:      	movk	w9, #0x6575, lsl #16
  154ba0:      	cmp	w8, w9
  154ba4:      	b.ne	0x15505c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
  154ba8:      	str	x1, [x0, #0x70]
  154bac:      	mov	x8, #0x2                ; =2
  154bb0:      	movk	x8, #0x7ffc, lsl #48
  154bb4:      	add	x19, x8, #0x2
  154bb8:      	b	0x155068 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
  154bbc:      	add	x10, x19, #0x1
  154bc0:      	str	x10, [x0, #0x70]
  154bc4:      	mov	w13, #0x1               ; =1
  154bc8:      	cmp	x10, x2
  154bcc:      	b.hs	0x15505c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
  154bd0:      	add	x14, x12, x10
  154bd4:      	ldrb	w8, [x14]
  154bd8:      	cmp	w8, #0x30
  154bdc:      	b.ne	0x154c68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x35c>
  154be0:      	add	x1, x10, #0x1
  154be4:      	str	x1, [x0, #0x70]
  154be8:      	cmp	x1, x2
  154bec:      	b.hs	0x154ca0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x394>
  154bf0:      	ldrb	w8, [x12, x1]
  154bf4:      	sub	w8, w8, #0x30
  154bf8:      	cmp	w8, #0x9
  154bfc:      	b.hi	0x154ca0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x394>
  154c00:      	ldrb	w8, [x12, x1]
  154c04:      	sub	w8, w8, #0x30
  154c08:      	cmp	w8, #0xa
  154c0c:      	b.hs	0x15505c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
  154c10:      	add	x1, x1, #0x1
  154c14:      	str	x1, [x0, #0x70]
  154c18:      	cmp	x2, x1
  154c1c:      	b.ne	0x154c00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x2f4>
  154c20:      	b	0x15505c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
  154c24:      	ldp	x29, x30, [sp, #0x50]
  154c28:      	ldp	x20, x19, [sp, #0x40]
  154c2c:      	ldp	x22, x21, [sp, #0x30]
  154c30:      	ldp	x24, x23, [sp, #0x20]
  154c34:      	add	sp, sp, #0x60
  154c38:      	b	0x154c38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x32c>
  154c3c:      	mov	x1, x0
  154c40:      	add	x0, sp, #0x8
  154c44:      	mov	x24, x1
  154c48:      	bl	0x154c48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x33c>
  154c4c:      	ldr	x22, [sp, #0x8]
  154c50:      	cmn	x22, #0x2
  154c54:      	b.ne	0x154d1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x410>
  154c58:      	mov	x19, #0x2               ; =2
  154c5c:      	movk	x19, #0x7ffc, lsl #48
  154c60:      	strb	wzr, [x24, #0xd4]
  154c64:      	b	0x155068 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
  154c68:      	sub	w8, w8, #0x31
  154c6c:      	cmp	w8, #0x8
  154c70:      	b.hi	0x15505c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
  154c74:      	mov	x1, x10
  154c78:      	ldrb	w8, [x12, x1]
  154c7c:      	sub	w8, w8, #0x30
  154c80:      	cmp	w8, #0x9
  154c84:      	b.hi	0x154ca0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x394>
  154c88:      	add	x1, x1, #0x1
  154c8c:      	str	x1, [x0, #0x70]
  154c90:      	cmp	x2, x1
  154c94:      	b.ne	0x154c78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x36c>
  154c98:      	mov	x1, x2
  154c9c:      	b	0x154cc8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x3bc>
  154ca0:      	subs	x8, x1, x2
  154ca4:      	b.hs	0x154cc8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x3bc>
  154ca8:      	ldrb	w11, [x12, x1]
  154cac:      	cmp	w11, #0x2e
  154cb0:      	b.eq	0x154ef4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x5e8>
  154cb4:      	cmp	w11, #0x45
  154cb8:      	b.eq	0x154dd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4c8>
  154cbc:      	mov	x8, x1
  154cc0:      	cmp	w11, #0x65
  154cc4:      	b.eq	0x154dd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4cc>
  154cc8:      	subs	x8, x1, x10
  154ccc:      	ccmp	x8, #0x13, #0x2, ne
  154cd0:      	b.hs	0x154dd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4c8>
  154cd4:      	cmp	x1, x10
  154cd8:      	b.lo	0x1551d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8cc>
  154cdc:      	cmp	x1, x2
  154ce0:      	b.hi	0x1551d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8cc>
  154ce4:      	mov	x9, #0x0                ; =0
  154ce8:      	mov	w10, #0xa               ; =10
  154cec:      	ldrb	w11, [x14], #0x1
  154cf0:      	mul	x9, x9, x10
  154cf4:      	sub	w11, w11, #0x30
  154cf8:      	add	x9, x9, w11, uxtb
  154cfc:      	subs	x8, x8, #0x1
  154d00:      	b.ne	0x154cec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x3e0>
  154d04:      	ucvtf	d0, x9
  154d08:      	fneg	d1, d0
  154d0c:      	cmp	w13, #0x0
  154d10:      	fcsel	d0, d1, d0, ne
  154d14:      	fmov	x19, d0
  154d18:      	b	0x155068 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
  154d1c:      	ldp	x21, x20, [sp, #0x10]
  154d20:      	cmp	x20, #0x6
  154d24:      	b.hs	0x154db4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4a8>
  154d28:      	subs	x8, x20, #0x3
  154d2c:      	b.lo	0x154e8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x580>
  154d30:      	ldrb	w9, [x21]
  154d34:      	cmp	w9, #0xed
  154d38:      	b.ne	0x154d58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x44c>
  154d3c:      	ldrb	w9, [x21, #0x1]
  154d40:      	and	w9, w9, #0xe0
  154d44:      	cmp	w9, #0xa0
  154d48:      	b.ne	0x154d58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x44c>
  154d4c:      	ldrsb	w9, [x21, #0x2]
  154d50:      	cmn	w9, #0x40
  154d54:      	b.lt	0x154db4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4a8>
  154d58:      	cbz	x8, 0x154e8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x580>
  154d5c:      	ldrb	w9, [x21, #0x1]
  154d60:      	cmp	w9, #0xed
  154d64:      	b.ne	0x154d84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x478>
  154d68:      	ldrb	w9, [x21, #0x2]
  154d6c:      	and	w9, w9, #0xe0
  154d70:      	cmp	w9, #0xa0
  154d74:      	b.ne	0x154d84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x478>
  154d78:      	ldrsb	w9, [x21, #0x3]
  154d7c:      	cmn	w9, #0x40
  154d80:      	b.lt	0x154db4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4a8>
  154d84:      	cmp	x8, #0x1
  154d88:      	b.eq	0x154e8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x580>
  154d8c:      	ldrb	w8, [x21, #0x2]
  154d90:      	cmp	w8, #0xed
  154d94:      	b.ne	0x154e8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x580>
  154d98:      	ldrb	w8, [x21, #0x3]
  154d9c:      	and	w8, w8, #0xe0
  154da0:      	cmp	w8, #0xa0
  154da4:      	b.ne	0x154e8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x580>
  154da8:      	ldrsb	w8, [x21, #0x4]
  154dac:      	cmn	w8, #0x40
  154db0:      	b.ge	0x154e8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x580>
  154db4:      	cmn	x22, #0x1
  154db8:      	b.eq	0x154eb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x5a4>
  154dbc:      	mov	x0, x21
  154dc0:      	mov	x1, x20
  154dc4:      	bl	0x154dc4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4b8>
  154dc8:      	mov	x19, #0x7fff000000000000 ; =9223090561878065152
  154dcc:      	bfxil	x19, x0, #0, #48
  154dd0:      	b	0x155004 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f8>
  154dd4:      	mov	x8, x1
  154dd8:      	cmp	x8, x2
  154ddc:      	b.hs	0x154e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x548>
  154de0:      	ldrb	w10, [x12, x8]
  154de4:      	orr	w10, w10, #0x20
  154de8:      	cmp	w10, #0x65
  154dec:      	b.ne	0x154e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x548>
  154df0:      	add	x10, x8, #0x1
  154df4:      	str	x10, [x0, #0x70]
  154df8:      	cmp	x10, x2
  154dfc:      	b.hs	0x154e1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x510>
  154e00:      	ldrb	w11, [x12, x10]
  154e04:      	cmp	w11, #0x2d
  154e08:      	b.eq	0x154e14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x508>
  154e0c:      	cmp	w11, #0x2b
  154e10:      	b.ne	0x154e1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x510>
  154e14:      	add	x10, x8, #0x2
  154e18:      	str	x10, [x0, #0x70]
  154e1c:      	cmp	x10, x2
  154e20:      	b.hs	0x15505c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
  154e24:      	mov	x8, x10
  154e28:      	ldrb	w11, [x12, x8]
  154e2c:      	sub	w11, w11, #0x30
  154e30:      	cmp	w11, #0x9
  154e34:      	b.hi	0x154e4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x540>
  154e38:      	add	x8, x8, #0x1
  154e3c:      	str	x8, [x0, #0x70]
  154e40:      	cmp	x2, x8
  154e44:      	b.ne	0x154e28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x51c>
  154e48:      	mov	x8, x2
  154e4c:      	cmp	x8, x10
  154e50:      	b.eq	0x15505c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
  154e54:      	subs	x1, x8, x19
  154e58:      	b.lo	0x1551b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8ac>
  154e5c:      	cmp	x8, x2
  154e60:      	b.hi	0x1551b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8ac>
  154e64:      	mov	x20, x0
  154e68:      	add	x8, sp, #0x8
  154e6c:      	mov	x0, x9
  154e70:      	bl	0x154e70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x564>
  154e74:      	ldrb	w8, [sp, #0x8]
  154e78:      	tbz	w8, #0x0, 0x154ea8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x59c>
  154e7c:      	mov	x19, #0x2               ; =2
  154e80:      	movk	x19, #0x7ffc, lsl #48
  154e84:      	strb	wzr, [x20, #0xd4]
  154e88:      	b	0x155068 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
  154e8c:      	cbz	x20, 0x154f40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x634>
  154e90:      	cmp	x20, #0x4
  154e94:      	b.hs	0x154f48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x63c>
  154e98:      	mov	x10, #0x0               ; =0
  154e9c:      	mov	x9, #0x0                ; =0
  154ea0:      	mov	x8, x21
  154ea4:      	b	0x154fd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6cc>
  154ea8:      	ldr	x19, [sp, #0x10]
  154eac:      	b	0x155068 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
  154eb0:      	ldr	x22, [x24, #0x68]
  154eb4:      	sub	x9, x22, x20
  154eb8:      	cmp	x9, #0x101
  154ebc:      	mov	w9, #0xff               ; =255
  154ec0:      	ccmp	x20, x9, #0x0, lo
  154ec4:      	b.ls	0x155018 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x70c>
  154ec8:      	ldr	x1, [x24, #0x60]
  154ecc:      	ldr	x23, [x24, #0xc8]
  154ed0:      	add	x0, x24, #0x20
  154ed4:      	mov	x2, x22
  154ed8:      	mov	x3, x23
  154edc:      	mov	x4, x19
  154ee0:      	mov	x5, x21
  154ee4:      	mov	x6, x20
  154ee8:      	bl	0x154ee8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x5dc>
  154eec:      	mov	x21, x0
  154ef0:      	b	0x155030 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x724>
  154ef4:      	add	x11, x1, #0x1
  154ef8:      	cmp	x11, x2
  154efc:      	b.hs	0x155058 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x74c>
  154f00:      	add	x16, x12, #0x1
  154f04:      	mov	x15, #-0x1              ; =-1
  154f08:      	ldrb	w17, [x16, x1]
  154f0c:      	sub	w3, w17, #0x30
  154f10:      	cmp	w3, #0x9
  154f14:      	b.hi	0x155084 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
  154f18:      	add	x16, x16, #0x1
  154f1c:      	sub	x15, x15, #0x1
  154f20:      	cmp	x8, x15
  154f24:      	b.ne	0x154f08 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x5fc>
  154f28:      	str	x2, [x0, #0x70]
  154f2c:      	mov	x8, x2
  154f30:      	subs	x16, x1, x10
  154f34:      	b.eq	0x154e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x548>
  154f38:      	mov	x8, x2
  154f3c:      	b	0x1550b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x7ac>
  154f40:      	mov	x10, #0x0               ; =0
  154f44:      	b	0x154ff8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6ec>
  154f48:      	and	x9, x20, #0x4
  154f4c:      	add	x8, x21, x9
  154f50:      	adrp	x10, 0x154000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x46c>
  154f54:      	ldr	q0, [x10]
  154f58:      	adrp	x10, 0x154000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x46c>
  154f5c:      	ldr	q2, [x10]
  154f60:      	movi.2d	v1, #0000000000000000
  154f64:      	movi.2d	v3, #0x000000000000ff
  154f68:      	mov	w10, #0x4               ; =4
  154f6c:      	dup.2d	v4, x10
  154f70:      	mov	x10, x21
  154f74:      	and	x11, x20, #0x4
  154f78:      	movi.2d	v5, #0000000000000000
  154f7c:      	ldr	s6, [x10], #0x4
  154f80:      	ushll.8h	v6, v6, #0x0
  154f84:      	ushll.4s	v6, v6, #0x0
  154f88:      	ushll2.2d	v7, v6, #0x0
  154f8c:      	and.16b	v7, v7, v3
  154f90:      	ushll.2d	v6, v6, #0x0
  154f94:      	and.16b	v6, v6, v3
  154f98:      	shl.2d	v16, v0, #0x3
  154f9c:      	shl.2d	v17, v2, #0x3
  154fa0:      	ushl.2d	v6, v6, v17
  154fa4:      	ushl.2d	v7, v7, v16
  154fa8:      	orr.16b	v1, v7, v1
  154fac:      	orr.16b	v5, v6, v5
  154fb0:      	add.2d	v0, v0, v4
  154fb4:      	add.2d	v2, v2, v4
  154fb8:      	subs	x11, x11, #0x4
  154fbc:      	b.ne	0x154f7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x670>
  154fc0:      	orr.16b	v0, v5, v1
  154fc4:      	mov	d1, v0[1]
  154fc8:      	orr.8b	v0, v0, v1
  154fcc:      	fmov	x10, d0
  154fd0:      	cmp	x20, x9
  154fd4:      	b.eq	0x154ff8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6ec>
  154fd8:      	add	x11, x21, x20
  154fdc:      	lsl	x9, x9, #3
  154fe0:      	ldrb	w12, [x8], #0x1
  154fe4:      	lsl	x12, x12, x9
  154fe8:      	orr	x10, x12, x10
  154fec:      	add	x9, x9, #0x8
  154ff0:      	cmp	x8, x11
  154ff4:      	b.ne	0x154fe0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6d4>
  154ff8:      	orr	x8, x10, x20, lsl #40
  154ffc:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
  155000:      	orr	x19, x8, x9
  155004:      	cmp	x22, #0x1
  155008:      	b.lt	0x155068 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
  15500c:      	mov	x0, x21
  155010:      	bl	0x155010 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x704>
  155014:      	b	0x155068 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
  155018:      	add	x0, x24, #0x20
  15501c:      	mov	x1, x21
  155020:      	mov	x2, x20
  155024:      	bl	0x155024 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x718>
  155028:      	mov	x21, x0
  15502c:      	ldr	x23, [x24, #0xc8]
  155030:      	ldr	x3, [x24, #0x70]
  155034:      	mov	x0, x23
  155038:      	mov	x1, x22
  15503c:      	mov	x2, x19
  155040:      	mov	x4, x21
  155044:      	mov	x5, x20
  155048:      	bl	0x155048 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x73c>
  15504c:      	mov	x19, #0x7fff000000000000 ; =9223090561878065152
  155050:      	bfxil	x19, x21, #0, #48
  155054:      	b	0x155068 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
  155058:      	str	x11, [x0, #0x70]
  15505c:      	mov	x19, #0x2               ; =2
  155060:      	movk	x19, #0x7ffc, lsl #48
  155064:      	strb	wzr, [x0, #0xd4]
  155068:      	mov	x0, x19
  15506c:      	ldp	x29, x30, [sp, #0x50]
  155070:      	ldp	x20, x19, [sp, #0x40]
  155074:      	ldp	x22, x21, [sp, #0x30]
  155078:      	ldp	x24, x23, [sp, #0x20]
  15507c:      	add	sp, sp, #0x60
  155080:      	ret
  155084:      	sub	x8, x1, x15
  155088:      	str	x8, [x0, #0x70]
  15508c:      	cmp	w17, #0x65
  155090:      	b.ne	0x1550a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x794>
  155094:      	cmn	x15, #0x1
  155098:      	b.ne	0x154dd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4cc>
  15509c:      	b	0x15505c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
  1550a0:      	cmn	x15, #0x1
  1550a4:      	b.eq	0x15505c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
  1550a8:      	subs	x16, x1, x10
  1550ac:      	b.eq	0x154dd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4cc>
  1550b0:      	cmp	w17, #0x45
  1550b4:      	b.eq	0x154dd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4cc>
  1550b8:      	sub	x15, x8, x11
  1550bc:      	cmp	x15, #0x9
  1550c0:      	b.hi	0x154dd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4cc>
  1550c4:      	add	x17, x16, x15
  1550c8:      	cmp	x17, #0x11
  1550cc:      	b.hi	0x154dd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4cc>
  1550d0:      	cmp	x1, x10
  1550d4:      	b.lo	0x1551e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8dc>
  1550d8:      	mov	x10, #0x0               ; =0
  1550dc:      	b.eq	0x1550fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x7f0>
  1550e0:      	mov	w17, #0xa               ; =10
  1550e4:      	ldrb	w3, [x14], #0x1
  1550e8:      	mul	x10, x10, x17
  1550ec:      	sub	w3, w3, #0x30
  1550f0:      	add	x10, x10, w3, uxtb
  1550f4:      	subs	x16, x16, #0x1
  1550f8:      	b.ne	0x1550e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x7d8>
  1550fc:      	cmp	x8, x1
  155100:      	b.ls	0x1551f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8ec>
  155104:      	cmp	x8, x2
  155108:      	b.hi	0x1551f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8ec>
  15510c:      	mov	w14, #0xa               ; =10
  155110:      	ldrb	w16, [x12, x11]
  155114:      	mul	x10, x10, x14
  155118:      	sub	w16, w16, #0x30
  15511c:      	add	x10, x10, w16, uxtb
  155120:      	add	x11, x11, #0x1
  155124:      	cmp	x8, x11
  155128:      	b.ne	0x155110 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x804>
  15512c:      	mov	x11, #0x20000000000000  ; =9007199254740992
  155130:      	cmp	x10, x11
  155134:      	b.hi	0x154dd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4cc>
  155138:      	ucvtf	d0, x10
  15513c:      	adrp	x8, 0x155000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f4>
  155140:      	add	x8, x8, #0x0
  155144:      	ldr	d1, [x8, x15, lsl #3]
  155148:      	fdiv	d0, d0, d1
  15514c:      	b	0x154d08 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x3fc>
  155150:      	cmp	w8, #0x1
  155154:      	b.ne	0x1551cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8c0>
  155158:      	adrp	x1, 0x155000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f4>
  15515c:      	add	x1, x1, #0x0
  155160:      	mov	x0, x19
  155164:      	bl	0x155164 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x858>
  155168:      	strb	wzr, [x19, #0x20]
  15516c:      	ldr	x8, [x19]
  155170:      	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
  155174:      	cmp	x8, x9
  155178:      	b.lo	0x154a54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x148>
  15517c:      	adrp	x0, 0x155000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f4>
  155180:      	add	x0, x0, #0x0
  155184:      	bl	0x155184 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x878>
  155188:      	adrp	x3, 0x155000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f4>
  15518c:      	add	x3, x3, #0x0
  155190:      	mov	x0, x19
  155194:      	bl	0x155194 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x888>
  155198:      	adrp	x3, 0x155000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f4>
  15519c:      	add	x3, x3, #0x0
  1551a0:      	mov	x0, x19
  1551a4:      	bl	0x1551a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x898>
  1551a8:      	adrp	x3, 0x155000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f4>
  1551ac:      	add	x3, x3, #0x0
  1551b0:      	mov	x0, x19
  1551b4:      	bl	0x1551b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8a8>
  1551b8:      	adrp	x3, 0x155000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f4>
  1551bc:      	add	x3, x3, #0x0
  1551c0:      	mov	x0, x19
  1551c4:      	mov	x1, x8
  1551c8:      	bl	0x1551c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8bc>
  1551cc:      	adrp	x0, 0x155000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f4>
  1551d0:      	add	x0, x0, #0x0
  1551d4:      	bl	0x1551d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8c8>
  1551d8:      	adrp	x3, 0x155000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f4>
  1551dc:      	add	x3, x3, #0x0
  1551e0:      	mov	x0, x10
  1551e4:      	bl	0x1551e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8d8>
  1551e8:      	adrp	x3, 0x155000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f4>
  1551ec:      	add	x3, x3, #0x0
  1551f0:      	mov	x0, x10
  1551f4:      	bl	0x1551f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8e8>
  1551f8:      	adrp	x3, 0x155000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f4>
  1551fc:      	add	x3, x3, #0x0
  155200:      	mov	x0, x11
  155204:      	mov	x1, x8
  155208:      	bl	0x155208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8fc>

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_runtime.51e3211f3b89fd3b-cgu.0.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.phf-fda76137c618ed94.phf.e4e92736a1df7d19-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.phf_shared-a99412ae5fa8df63.phf_shared.d4b5e8e0605a820e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.pin_project_lite-9112ff0b4ca4c5f5.pin_project_lite.9e3a833d7736b09d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.portable_atomic-ee537db1fe67f1f1.portable_atomic.3d3e8745d3fefd81-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.potential_utf-7290d80b7d4fd7a6.potential_utf.3d03ee8112fd1596-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.prefix_trie-40e0fdfa96a3a51b.prefix_trie.aa2676338b217d25-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.psm-9f3b8da3ad16e1fa.psm.78bcf4d21b57561-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rand-492323155da95b1d.rand.6529a7c3eb82dfd6-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rand_core-6bacf6ecfee8446a.rand_core.fec9fb7b016054b8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.regex-23a1744e34a6bdd8.regex.5fe00e4da3593f57-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.regex_automata-05498c6e8207064c.regex_automata.2113017827263087-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.regex_syntax-dc078710f3e283e5.regex_syntax.5d77536cdc21bec2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.regress-4af654b3baeba21a.regress.56c9efe3abfd7dd9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.resolv_conf-589bb5b300ae9b62.resolv_conf.ef8ce2570ae6b7ca-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_demangle-a0db1312f42a1e44.rustc_demangle.e8c1817fde257fa-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_demangle-a84069e27028b871.rustc_demangle.6e498b991fca6ce6-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_hash-6acac617e2694d16.rustc_hash.8dd8e3d9c15ad472-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_std_workspace_alloc-5b4356182ec17e27.rustc_std_workspace_alloc.95a6ecb1e2b64b16-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_std_workspace_core-91fae2e614e9d003.rustc_std_workspace_core.5c33cd8176fbdf03-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ryu-88f4114cfee0f920.ryu.e5b11607222e9f1-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ryu_js-8203fc1e86d8300b.ryu_js.38024f8f2b58d396-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.scoped_tls-bea296576cbd4055.scoped_tls.4868881ed73f4220-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.scopeguard-3f34b2f52778ed6d.scopeguard.39c46ee7c3ff5c3a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.serde-b1698c4db99cd0f6.serde.ace619f76592a163-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.serde_core-7feea810e2b7e669.serde_core.91e6c9d28410876e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.serde_json-5f6cce1ec0bc1f51.serde_json.1881800b546529cc-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.serde_spanned-786a63d1fb99443c.serde_spanned.ecff9bd5fc6ed1cd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.signal_hook_registry-73f406794e9b58b9.signal_hook_registry.a304ee316af8aaf-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.simdutf8-6eaa160c64d9f76b.simdutf8.5e602d216e3b60b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.siphasher-3f0a76aeabf470da.siphasher.5dc93b2dddb35ff3-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.siphasher-a84eeb1952cd7c96.siphasher.63b0bb3e10f5fb09-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.slab-ce3c7619cdf98849.slab.4197f6b653c95390-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.slotmap-20ea319e01e10a36.slotmap.7f53c3097a475db5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.smallvec-0e7d453b7999d6bf.smallvec.a3fac2ce2795659-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.smartstring-dc627c0149b34430.smartstring.daa138bdd471414-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.socket2-c0fc5e20d9815054.socket2.325daa4db95003be-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.spin-419ef0217c1a7e9d.spin.124ce9ff3747f4d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.spki-68668ef35563db08.spki.dcea16c81f3faeb7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.stable_deref_trait-d05f845ec581f3c3.stable_deref_trait.20e7280df43487a4-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.stacker-e8215abced14b595.stacker.a64d36231c9b54e8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.static_assertions-26a67eb00cbe4a19.static_assertions.d246fd1a619c5f56-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.std-36f377630a6d9041.std.6435e32e5249d112-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.std_detect-4733c791661234cb.std_detect.19bab4874ad71232-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_atoms-920e18ec1ca531dc.swc_atoms.6e099e31e61309c3-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_common-d6bd2bc4e58d990f.swc_common.8fdf2470d9cfdc5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_ecma_ast-84ea4ee5ba95db2e.swc_ecma_ast.3d8d12e8f84f649c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_ecma_parser-8ec30cfb0eaf253d.swc_ecma_parser.bc422679edde26a7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_ecma_visit-b63461394357b0d4.swc_ecma_visit.c99e8944d3846bc7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_visit-64ac6e1c9cb7923d.swc_visit.2ab765cb666f8899-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.taffy-fe5c9a8e7c25c5f0.taffy.d86dff334662a800-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.temporal_rs-0fb585091cfff93a.temporal_rs.615be7171f19ae8f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.thiserror-1959f5c5ef95f8e0.thiserror.66a9b0aa6ac5659c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.thiserror-819934ff4cff447d.thiserror.262fe98a9286a6f8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.timezone_provider-734aa3cb276ec3ef.timezone_provider.c5d1d9aad8d3988f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tinystr-7460fd70af50815a.tinystr.f12ac1933cb9ba2b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tinyvec-747e19215a97d544.tinyvec.c739c1e068ab99ed-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tinyvec_macros-03c0b3b0828d119a.tinyvec_macros.a5317fef04132c16-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tokio-c09ace7016a21111.tokio.10f85077cf846efc-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tokio_util-b3b32b3e68ae174b.tokio_util.c2188b63290972ae-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.toml-e1d9f60e2a93edf6.toml.69efb9df2f8e67b3-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.toml_datetime-da06043cbfd6a3ff.toml_datetime.eed1431b100c0ba5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.toml_parser-a8ea5ac599f8d731.toml_parser.4dda3eb99405abdd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.toml_writer-86392e121e73ea49.toml_writer.612da603a2a255c9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tracing-1e99833042e023d4.tracing.480a63e3c00ffe5d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tracing_core-a4ce5df32b216be5.tracing_core.551518ce0c3162f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.triomphe-1f26ad013b2edc2b.triomphe.df0393428d78f2d2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tzif-f601d4f6882f6c91.tzif.4b87cacab3be6a39-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_id_start-b1b648fdc7033911.unicode_id_start.b451d75f4870a19-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_normalization-74312452efd83ea5.unicode_normalization.a9dba2d72fcfb0e9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_segmentation-9d17b5f253060a33.unicode_segmentation.418ba6cb19b4b691-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_width-9091f55f45a06a5b.unicode_width.2046f0e93b598eee-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_width-eefe794da3ddc491.unicode_width.81acccf54ab200a6-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unsafe_libyaml-6fc9986bea6e83a2.unsafe_libyaml.498c10ddae7016fa-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unwind-b34336196694d849.unwind.84a5a803a0d3b8e5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.url-937de9168f16e023.url.1a3dafb8678c931d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.utf8_iter-495f179a61b481d6.utf8_iter.c6d05cdf24642122-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.winnow-19e99833af0373f3.winnow.82b0bb40063afce5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.writeable-590fc088fec40648.writeable.5b4332e450c8b833-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.x509_cert-23c04dad6503524d.x509_cert.a1cd03d282d34aa8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.xxhash_rust-aca16904554a0e24.xxhash_rust.80a8560132cdda1a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.yoke-344345244b6e4947.yoke.e19373a6f771978b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zerocopy-99f7f8d1743ab073.zerocopy.c4d7aea3b77dbe79-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zerofrom-316567aba73be1b3.zerofrom.895504131b58bc4e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zeroize-c6a7916c40321e93.zeroize.9524028ebbc3b95a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zerotrie-5524f4e315dcaf36.zerotrie.47410e50260eb1e0-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zerovec-8f5cd301f36e965a.zerovec.9ea12157016434b1-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zmij-8f9e3f41857f0483.zmij.180143115354781b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zstd-2da8f76fd714c069.zstd.f736b1e5325616ef-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zstd_safe-e368634d5a7f6151.zstd_safe.828b5cf371cee27e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zstd_sys-959dee5ed6b0497e.zstd_sys.67acef213add5ee5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f17b5a9852f781a4-perry_sjlj.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-debug.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-entropy_common.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-error_private.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-fse_decompress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-pool.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-threading.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-zstd_common.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-fse_compress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-hist.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-huf_compress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_compress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_compress_literals.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_compress_sequences.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_compress_superblock.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_double_fast.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_fast.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_lazy.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_ldm.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_opt.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_preSplit.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstdmt_compress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(88f362f13b0528ed-huf_decompress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(88f362f13b0528ed-zstd_ddict.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(88f362f13b0528ed-zstd_decompress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(88f362f13b0528ed-zstd_decompress_block.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(a6c81c75fc82913a-cover.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(a6c81c75fc82913a-divsufsort.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(a6c81c75fc82913a-fastcover.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(a6c81c75fc82913a-zdict.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v01.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v02.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v03.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v04.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v05.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v06.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v07.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(7faed3f8272f2313-huf_decompress_amd64.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(b85de32113adef8e-static.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(4f9a91766097c4c5-aarch_aapcs64.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.000.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.001.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.002.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.003.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.004.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.005.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.006.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.007.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.008.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.009.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.010.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.011.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.012.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.013.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.014.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.015.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.016.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.017.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.018.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.019.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.020.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.021.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.022.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.023.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.024.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.025.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.026.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.027.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.028.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.029.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.030.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.031.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.032.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.033.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.034.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.035.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.036.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.037.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.038.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.039.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.040.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.041.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.042.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.043.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.044.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.045.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.046.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.047.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.048.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.049.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.050.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.051.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.052.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.053.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.054.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.055.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.056.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.057.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.058.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.059.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.060.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.061.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.062.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.063.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.064.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.065.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.066.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.067.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.068.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.069.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.070.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.071.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.072.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.073.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.074.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.075.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.076.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.077.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.078.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.079.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.080.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.081.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.082.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.083.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.084.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.085.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.086.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.087.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.088.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.089.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.090.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.091.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.092.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.093.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.094.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.095.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.096.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.097.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.098.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.099.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.100.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.101.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.102.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.103.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.104.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.105.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.106.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.107.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.108.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.109.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.110.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.111.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.112.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.113.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.114.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.115.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.116.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.117.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.118.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.119.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.120.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.121.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.122.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.123.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.124.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.125.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.126.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.127.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.128.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.129.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.130.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.131.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.132.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.133.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.134.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.135.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.136.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.137.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.138.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.139.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.140.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.141.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.142.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.143.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.144.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.145.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.146.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.147.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.148.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.149.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.150.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.151.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.152.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.153.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.154.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.155.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.156.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.157.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.158.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.159.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.160.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.161.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.162.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.163.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.164.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.165.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.166.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.167.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.168.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.169.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.170.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.171.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.172.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.173.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.174.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.175.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.176.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.177.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.178.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.179.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.180.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.181.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.182.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.183.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.184.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.185.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.186.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.187.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.188.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.189.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.190.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.191.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.192.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.193.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.194.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.195.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.196.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.197.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.198.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.199.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.200.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.201.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.202.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.203.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.204.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.205.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.206.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.207.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.208.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.209.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.210.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.211.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.212.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.213.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.214.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.215.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.216.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.217.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.218.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.219.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.220.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.221.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.222.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.223.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.224.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.225.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.226.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.227.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.228.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas1_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas1_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas1_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas1_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas2_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas2_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas2_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas2_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas4_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas4_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas4_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas4_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas8_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas8_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas8_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas8_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas16_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas16_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas16_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas16_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp1_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp1_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp1_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp1_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp2_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp2_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp2_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp2_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp4_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp4_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp4_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp4_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp8_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp8_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp8_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp8_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd1_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd1_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd1_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd1_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd2_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd2_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd2_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd2_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd4_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd4_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd4_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd4_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd8_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd8_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd8_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd8_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr1_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr1_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr1_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr1_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr2_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr2_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr2_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr2_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr4_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr4_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr4_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr4_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr8_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr8_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr8_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr8_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor1_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor1_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor1_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor1_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor2_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor2_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor2_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor2_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor4_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor4_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor4_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor4_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor8_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor8_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor8_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor8_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset1_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset1_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset1_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset1_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset2_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset2_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset2_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset2_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset4_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset4_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset4_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset4_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset8_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset8_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset8_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset8_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(ad3ac4dcdcbf93cb-aarch64.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-absvdi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-absvsi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-absvti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-addvdi3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-addvsi3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-addvti3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-cmpdi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-cmpti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-divdc3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-divsc3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-fp_mode.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-ffsti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-int_util.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-muldc3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-mulsc3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-multc3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-mulvdi3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-mulvsi3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-mulvti3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negdf2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negdi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negsf2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negvdi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negvsi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negvti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-paritydi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-paritysi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-parityti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-popcountdi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-popcountsi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-popcountti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-subvdi3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-subvsi3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-subvti3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-ucmpdi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-ucmpti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_flag_clear.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_flag_clear_explicit.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_flag_test_and_set.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_flag_test_and_set_explicit.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_signal_fence.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_thread_fence.o):	file format mach-o arm64
