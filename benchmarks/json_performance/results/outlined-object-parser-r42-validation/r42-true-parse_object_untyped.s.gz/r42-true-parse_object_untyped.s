
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/outlined-object-parser-r42/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001002496e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_>:
1002496e4:     	stp	x28, x27, [sp, #-0x60]!
1002496e8:     	stp	x26, x25, [sp, #0x10]
1002496ec:     	stp	x24, x23, [sp, #0x20]
1002496f0:     	stp	x22, x21, [sp, #0x30]
1002496f4:     	stp	x20, x19, [sp, #0x40]
1002496f8:     	stp	x29, x30, [sp, #0x50]
1002496fc:     	add	x29, sp, #0x50
100249700:     	sub	sp, sp, #0x240
100249704:     	mov	x19, x0
100249708:     	ldp	x8, x9, [x0, #0x68]
10024970c:     	add	x9, x9, #0x1
100249710:     	str	x9, [x0, #0x70]
100249714:     	cmp	x9, x8
100249718:     	b.hs	0x10024974c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x68>
10024971c:     	ldr	x10, [x19, #0x60]
100249720:     	mov	x11, #0x2600            ; =9728
100249724:     	movk	x11, #0x1, lsl #32
100249728:     	ldrb	w12, [x10, x9]
10024972c:     	cmp	w12, #0x20
100249730:     	b.hi	0x10024974c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x68>
100249734:     	lsr	x12, x11, x12
100249738:     	tbz	w12, #0x0, 0x10024974c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x68>
10024973c:     	add	x9, x9, #0x1
100249740:     	str	x9, [x19, #0x70]
100249744:     	cmp	x8, x9
100249748:     	b.ne	0x100249728 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x44>
10024974c:     	ldrb	w8, [x19, #0xd5]
100249750:     	tbz	w8, #0x0, 0x10024977c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x98>
100249754:     	strb	wzr, [x19, #0xd5]
100249758:     	ldr	x22, [x19, #0x78]
10024975c:     	ldp	q0, q1, [x19, #0x80]
100249760:     	stur	q0, [sp, #0xa8]
100249764:     	stur	q1, [sp, #0xb8]
100249768:     	ldp	q0, q1, [x19, #0xa0]
10024976c:     	stur	q0, [sp, #0xc8]
100249770:     	stur	q1, [sp, #0xd8]
100249774:     	ldr	x21, [x19, #0xc0]
100249778:     	b	0x1002497ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xc8>
10024977c:     	mov	w26, #0x0               ; =0
100249780:     	mov	x8, #0x0                ; =0
100249784:     	ldr	x22, [x19, #0x78]
100249788:     	cbz	x22, 0x10024a610 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf2c>
10024978c:     	ldr	x21, [x19, #0xc0]
100249790:     	cbz	x21, 0x1002497c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe0>
100249794:     	ldp	q0, q1, [x19, #0x80]
100249798:     	stur	q0, [sp, #0xa8]
10024979c:     	stur	q1, [sp, #0xb8]
1002497a0:     	ldp	q0, q1, [x19, #0xa0]
1002497a4:     	stur	q0, [sp, #0xc8]
1002497a8:     	stur	q1, [sp, #0xd8]
1002497ac:     	ldr	w8, [x19, #0xd0]
1002497b0:     	stp	x22, x21, [sp, #0xe8]
1002497b4:     	str	w8, [sp, #0x7c]
1002497b8:     	str	w8, [sp, #0xf8]
1002497bc:     	mov	w8, #0x1                ; =1
1002497c0:     	mov	w26, #0x1               ; =1
1002497c4:     	str	x8, [sp, #0xa0]
1002497c8:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
1002497cc:     	add	x0, x0, #0xce8
1002497d0:     	ldr	x8, [x0]
1002497d4:     	blr	x8
1002497d8:     	mov	x20, x0
1002497dc:     	ldrb	w8, [x0, #0x20]
1002497e0:     	cbnz	w8, 0x10024a820 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x113c>
1002497e4:     	ldr	x8, [x20]
1002497e8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1002497ec:     	cmp	x8, x9
1002497f0:     	b.hs	0x10024a84c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1168>
1002497f4:     	ldr	x27, [x20, #0x18]
1002497f8:     	ldp	x24, x28, [x19, #0x68]
1002497fc:     	cmp	x28, x24
100249800:     	b.hs	0x100249834 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x150>
100249804:     	ldr	x8, [x19, #0x60]
100249808:     	ldrb	w8, [x8, x28]
10024980c:     	cmp	w8, #0x7d
100249810:     	b.ne	0x100249834 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x150>
100249814:     	add	x8, x28, #0x1
100249818:     	str	x8, [x19, #0x70]
10024981c:     	ldr	x8, [x19, #0x78]
100249820:     	cbnz	x8, 0x10024a614 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf30>
100249824:     	ldr	x1, [x19, #0xc0]
100249828:     	cbz	x1, 0x10024a614 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf30>
10024982c:     	ldr	w2, [x19, #0xd0]
100249830:     	b	0x10024a634 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf50>
100249834:     	str	x21, [sp, #0x90]
100249838:     	movi.2d	v0, #0000000000000000
10024983c:     	stp	q0, q0, [sp, #0x120]
100249840:     	stp	q0, q0, [sp, #0x100]
100249844:     	adrp	x1, 0x100ca1000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6fb0>
100249848:     	add	x1, x1, #0xb40
10024984c:     	add	x0, sp, #0x148
100249850:     	mov	w2, #0x40               ; =64
100249854:     	bl	0x100b66c10 <_writev+0x100b66c10>
100249858:     	mov	x23, #0x0               ; =0
10024985c:     	mov	x21, #0x0               ; =0
100249860:     	mov	x8, #-0x1               ; =-1
100249864:     	str	x8, [sp, #0x188]
100249868:     	add	x8, sp, #0xa0
10024986c:     	add	x8, x8, #0x8
100249870:     	stp	x8, xzr, [sp, #0x68]
100249874:     	mov	x25, #0x2600            ; =9728
100249878:     	movk	x25, #0x1, lsl #32
10024987c:     	adrp	x8, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4fb0>
100249880:     	ldr	q0, [x8, #0x8d0]
100249884:     	str	q0, [sp, #0x50]
100249888:     	adrp	x8, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4fb0>
10024988c:     	ldr	q0, [x8, #0x8e0]
100249890:     	str	q0, [sp, #0x40]
100249894:     	mov	x11, x26
100249898:     	stp	w26, w26, [sp, #0x98]
10024989c:     	str	x22, [sp, #0x80]
1002498a0:     	cmp	x28, x24
1002498a4:     	b.hs	0x1002498d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1f0>
1002498a8:     	ldr	x8, [x19, #0x60]
1002498ac:     	ldrb	w9, [x8, x28]
1002498b0:     	cmp	w9, #0x20
1002498b4:     	b.hi	0x1002498d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1f0>
1002498b8:     	lsr	x9, x25, x9
1002498bc:     	tbz	w9, #0x0, 0x1002498d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1f0>
1002498c0:     	add	x28, x28, #0x1
1002498c4:     	str	x28, [x19, #0x70]
1002498c8:     	cmp	x24, x28
1002498cc:     	b.ne	0x1002498ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1c8>
1002498d0:     	mov	x28, x24
1002498d4:     	str	x23, [sp, #0x88]
1002498d8:     	cbz	w26, 0x100249994 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b0>
1002498dc:     	cmp	x23, x22
1002498e0:     	cset	w8, lo
1002498e4:     	tst	w11, w8
1002498e8:     	b.eq	0x100249994 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b0>
1002498ec:     	cmp	x23, #0x8
1002498f0:     	b.hs	0x10024a8f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1214>
1002498f4:     	mov	x26, x11
1002498f8:     	cmp	x28, x24
1002498fc:     	b.hs	0x100249998 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b4>
100249900:     	ldr	x8, [sp, #0x68]
100249904:     	ldr	x9, [x8, x23, lsl #3]
100249908:     	cbz	x9, 0x100249998 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b4>
10024990c:     	ldr	x10, [x19, #0x60]
100249910:     	ldrb	w8, [x10, x28]
100249914:     	cmp	w8, #0x22
100249918:     	b.ne	0x100249998 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b4>
10024991c:     	add	x11, x28, #0x1
100249920:     	ldr	w14, [x9, #0x4]
100249924:     	add	x8, x11, x14
100249928:     	cmp	x8, x24
10024992c:     	ccmp	x8, x28, #0x0, lo
100249930:     	b.ls	0x100249998 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b4>
100249934:     	ldrb	w12, [x10, x8]
100249938:     	cmp	w12, #0x22
10024993c:     	b.ne	0x100249998 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b4>
100249940:     	add	x1, x10, x11
100249944:     	cbz	w14, 0x100249980 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x29c>
100249948:     	add	x9, x9, #0x14
10024994c:     	mov	x10, x14
100249950:     	mov	x11, x1
100249954:     	ldrb	w12, [x11], #0x1
100249958:     	cmp	w12, #0x5c
10024995c:     	b.eq	0x100249998 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b4>
100249960:     	cmp	w12, #0x22
100249964:     	b.eq	0x100249998 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b4>
100249968:     	ldrb	w13, [x9], #0x1
10024996c:     	cmp	w12, #0x20
100249970:     	ccmp	w12, w13, #0x0, hs
100249974:     	b.ne	0x100249998 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2b4>
100249978:     	subs	x10, x10, #0x1
10024997c:     	b.ne	0x100249954 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x270>
100249980:     	add	x8, x8, #0x1
100249984:     	str	x8, [x19, #0x70]
100249988:     	mov	w24, #0x1               ; =1
10024998c:     	mov	x23, #-0x1              ; =-1
100249990:     	b	0x1002499b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2d4>
100249994:     	mov	x26, x11
100249998:     	sub	x0, x29, #0x80
10024999c:     	mov	x1, x19
1002499a0:     	bl	0x1002458b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_bytesB9_>
1002499a4:     	ldur	x23, [x29, #-0x80]
1002499a8:     	cmn	x23, #0x2
1002499ac:     	b.eq	0x10024a73c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1058>
1002499b0:     	mov	w24, #0x0               ; =0
1002499b4:     	ldp	x1, x14, [x29, #-0x78]
1002499b8:     	mov	x28, x21
1002499bc:     	ldp	x9, x8, [x19, #0x68]
1002499c0:     	cmp	x8, x9
1002499c4:     	b.hs	0x10024a39c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcb8>
1002499c8:     	ldr	x10, [x19, #0x60]
1002499cc:     	ldrb	w11, [x10, x8]
1002499d0:     	cmp	w11, #0x3a
1002499d4:     	b.hi	0x10024a39c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcb8>
1002499d8:     	lsr	x12, x25, x11
1002499dc:     	tbz	w12, #0x0, 0x1002499f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x310>
1002499e0:     	add	x8, x8, #0x1
1002499e4:     	str	x8, [x19, #0x70]
1002499e8:     	cmp	x9, x8
1002499ec:     	b.ne	0x1002499cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x2e8>
1002499f0:     	b	0x10024a39c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcb8>
1002499f4:     	cmp	x11, #0x3a
1002499f8:     	b.ne	0x10024a39c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcb8>
1002499fc:     	stp	x14, x1, [sp, #0x30]
100249a00:     	add	x8, x8, #0x1
100249a04:     	str	x8, [x19, #0x70]
100249a08:     	mov	x0, x19
100249a0c:     	bl	0x10024820c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_>
100249a10:     	ldrb	w8, [x19, #0xd4]
100249a14:     	tbz	w8, #0x0, 0x10024a808 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1124>
100249a18:     	ldr	x9, [sp, #0x188]
100249a1c:     	cmn	x9, #0x1
100249a20:     	ldp	x3, x17, [sp, #0x30]
100249a24:     	str	x0, [sp, #0x28]
100249a28:     	b.eq	0x100249ae0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x3fc>
100249a2c:     	ldr	x8, [sp, #0x1b8]
100249a30:     	cmn	x8, #0x1
100249a34:     	b.eq	0x100249b30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x44c>
100249a38:     	ldp	x8, x11, [sp, #0x1f0]
100249a3c:     	ldr	x10, [sp, #0x200]
100249a40:     	ldr	x9, [sp, #0x208]
100249a44:     	eor	x11, x11, x3
100249a48:     	mov	x13, #0x7f2d            ; =32557
100249a4c:     	movk	x13, #0x4c95, lsl #16
100249a50:     	movk	x13, #0xf42d, lsl #32
100249a54:     	movk	x13, #0x5851, lsl #48
100249a58:     	mul	x12, x11, x13
100249a5c:     	umulh	x11, x11, x13
100249a60:     	eor	x11, x11, x12
100249a64:     	add	x11, x3, x11
100249a68:     	mul	x11, x11, x13
100249a6c:     	cmp	x3, #0x8
100249a70:     	b.ls	0x100249b88 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x4a4>
100249a74:     	cmp	x3, #0x10
100249a78:     	b.ls	0x100249c38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x554>
100249a7c:     	add	x12, x17, x3
100249a80:     	ldp	x12, x13, [x12, #-0x10]
100249a84:     	eor	x12, x10, x12
100249a88:     	eor	x13, x13, x9
100249a8c:     	mul	x14, x13, x12
100249a90:     	umulh	x12, x13, x12
100249a94:     	eor	x12, x12, x14
100249a98:     	add	x11, x11, x8
100249a9c:     	eor	x11, x11, x12
100249aa0:     	ror	x11, x11, #0x29
100249aa4:     	mov	x13, x17
100249aa8:     	mov	x12, x3
100249aac:     	ldp	x15, x14, [x13], #0x10
100249ab0:     	sub	x12, x12, #0x10
100249ab4:     	eor	x15, x10, x15
100249ab8:     	eor	x14, x14, x9
100249abc:     	mul	x16, x14, x15
100249ac0:     	umulh	x14, x14, x15
100249ac4:     	eor	x14, x14, x16
100249ac8:     	add	x11, x11, x8
100249acc:     	eor	x11, x11, x14
100249ad0:     	ror	x11, x11, #0x29
100249ad4:     	cmp	x12, #0x10
100249ad8:     	b.hi	0x100249aac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x3c8>
100249adc:     	b	0x100249d14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x630>
100249ae0:     	ldr	w8, [sp, #0x9c]
100249ae4:     	tbz	w8, #0x0, 0x100249ba8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x4c4>
100249ae8:     	ldr	w8, [sp, #0x98]
100249aec:     	tbz	w8, #0x0, 0x10024a8ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1208>
100249af0:     	ldp	x9, x8, [sp, #0x80]
100249af4:     	cmp	x8, x9
100249af8:     	ldr	x21, [sp, #0x90]
100249afc:     	mov	x11, x26
100249b00:     	ldr	w26, [sp, #0x98]
100249b04:     	b.hs	0x100249e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x770>
100249b08:     	tbz	w24, #0x0, 0x100249e10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x72c>
100249b0c:     	ldr	x0, [sp, #0x88]
100249b10:     	cmp	x0, #0x7
100249b14:     	b.hi	0x10024a930 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x124c>
100249b18:     	ldr	x8, [sp, #0x68]
100249b1c:     	ldr	x10, [x8, x0, lsl #3]
100249b20:     	add	x0, x0, #0x1
100249b24:     	str	x0, [sp, #0x88]
100249b28:     	mov	w9, #0x1                ; =1
100249b2c:     	b	0x100249e6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x788>
100249b30:     	str	x9, [sp, #0x10]
100249b34:     	ldp	x1, x24, [sp, #0x190]
100249b38:     	cmp	x24, #0x80
100249b3c:     	b.ne	0x100249bcc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x4e8>
100249b40:     	mov	w8, #0x1                ; =1
100249b44:     	strb	w8, [x19, #0xd6]
100249b48:     	add	x8, sp, #0x188
100249b4c:     	add	x0, x8, #0x30
100249b50:     	mov	x28, x1
100249b54:     	bl	0x10028b55c <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex9from_keys>
100249b58:     	ldp	x3, x17, [sp, #0x30]
100249b5c:     	ldr	x8, [sp, #0x1b8]
100249b60:     	cmn	x8, #0x1
100249b64:     	b.ne	0x100249a38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x354>
100249b68:     	mov	x0, x17
100249b6c:     	mov	x1, x3
100249b70:     	bl	0x10032abfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100249b74:     	mov	x12, x0
100249b78:     	add	x22, x28, #0x400
100249b7c:     	ldr	w9, [sp, #0x9c]
100249b80:     	mov	x10, x28
100249b84:     	b	0x100249bf0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x50c>
100249b88:     	cmp	x3, #0x1
100249b8c:     	b.ls	0x100249c48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x564>
100249b90:     	add	x13, x17, x3
100249b94:     	cmp	x3, #0x3
100249b98:     	b.ls	0x100249ce0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x5fc>
100249b9c:     	ldr	w12, [x17]
100249ba0:     	ldur	w13, [x13, #-0x4]
100249ba4:     	b	0x100249cf4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x610>
100249ba8:     	mov	x0, x17
100249bac:     	mov	x1, x3
100249bb0:     	bl	0x10032abfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100249bb4:     	mov	x10, x0
100249bb8:     	mov	w9, #0x0                ; =0
100249bbc:     	ldr	x21, [sp, #0x90]
100249bc0:     	mov	x11, x26
100249bc4:     	ldr	w26, [sp, #0x98]
100249bc8:     	b	0x100249e6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x788>
100249bcc:     	str	x1, [sp, #0x8]
100249bd0:     	mov	x0, x17
100249bd4:     	mov	x1, x3
100249bd8:     	bl	0x10032abfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100249bdc:     	mov	x12, x0
100249be0:     	ldr	w9, [sp, #0x9c]
100249be4:     	cbz	x24, 0x10024a214 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb30>
100249be8:     	ldr	x10, [sp, #0x8]
100249bec:     	add	x22, x10, x24, lsl #3
100249bf0:     	ldr	x8, [sp, #0x88]
100249bf4:     	cmp	x8, #0x0
100249bf8:     	cset	w8, eq
100249bfc:     	orr	w8, w8, w9
100249c00:     	tbz	w8, #0x0, 0x100249c58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x574>
100249c04:     	mov	x0, #0x0                ; =0
100249c08:     	mov	x8, x10
100249c0c:     	mov	x11, x26
100249c10:     	ldr	w26, [sp, #0x98]
100249c14:     	ldr	x1, [sp, #0x38]
100249c18:     	ldr	x9, [x8], #0x8
100249c1c:     	cmp	x9, x12
100249c20:     	b.eq	0x100249cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x5d8>
100249c24:     	add	x0, x0, #0x1
100249c28:     	cmp	x8, x22
100249c2c:     	b.ne	0x100249c18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x534>
100249c30:     	mov	x28, x21
100249c34:     	b	0x10024a23c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb58>
100249c38:     	ldr	x12, [x17]
100249c3c:     	add	x13, x17, x3
100249c40:     	ldur	x13, [x13, #-0x8]
100249c44:     	b	0x100249cf4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x610>
100249c48:     	b.ne	0x100249cec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x608>
100249c4c:     	ldrb	w12, [x17]
100249c50:     	mov	x13, x12
100249c54:     	b	0x100249cf4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x610>
100249c58:     	stp	x24, x10, [sp]
100249c5c:     	str	x27, [sp, #0x18]
100249c60:     	mov	x24, #0x0               ; =0
100249c64:     	mov	x27, x10
100249c68:     	ldp	x2, x1, [sp, #0x30]
100249c6c:     	b	0x100249c7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x598>
100249c70:     	sub	x24, x24, #0x1
100249c74:     	cmp	x27, x22
100249c78:     	b.eq	0x10024a224 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb40>
100249c7c:     	ldr	x8, [x27], #0x8
100249c80:     	cmp	x8, x12
100249c84:     	b.eq	0x100249cac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x5c8>
100249c88:     	ldr	w9, [x8, #0x4]
100249c8c:     	cmp	x2, x9
100249c90:     	b.ne	0x100249c70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x58c>
100249c94:     	add	x0, x8, #0x14
100249c98:     	mov	x28, x12
100249c9c:     	bl	0x100b66be0 <_writev+0x100b66be0>
100249ca0:     	mov	x12, x28
100249ca4:     	ldp	x2, x1, [sp, #0x30]
100249ca8:     	cbnz	w0, 0x100249c70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x58c>
100249cac:     	neg	x0, x24
100249cb0:     	ldr	x27, [sp, #0x18]
100249cb4:     	mov	x11, x26
100249cb8:     	ldr	w26, [sp, #0x98]
100249cbc:     	ldr	x9, [sp, #0x20]
100249cc0:     	cmp	x0, x9
100249cc4:     	ldr	x8, [sp, #0x60]
100249cc8:     	b.hs	0x10024a920 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x123c>
100249ccc:     	mov	x28, x21
100249cd0:     	ldr	x10, [sp, #0x28]
100249cd4:     	str	x10, [x8, x0, lsl #3]
100249cd8:     	ldr	x21, [sp, #0x90]
100249cdc:     	b	0x10024a280 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb9c>
100249ce0:     	ldrh	w12, [x17]
100249ce4:     	ldurb	w13, [x13, #-0x1]
100249ce8:     	b	0x100249cf4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x610>
100249cec:     	mov	x12, #0x0               ; =0
100249cf0:     	mov	x13, #0x0               ; =0
100249cf4:     	eor	x10, x12, x10
100249cf8:     	eor	x9, x13, x9
100249cfc:     	mul	x12, x9, x10
100249d00:     	umulh	x9, x9, x10
100249d04:     	eor	x9, x9, x12
100249d08:     	add	x10, x11, x8
100249d0c:     	eor	x9, x10, x9
100249d10:     	ror	x11, x9, #0x29
100249d14:     	mul	x9, x11, x8
100249d18:     	umulh	x8, x11, x8
100249d1c:     	eor	x8, x8, x9
100249d20:     	neg	w9, w11
100249d24:     	ror	x24, x8, x9
100249d28:     	ldp	x4, x28, [sp, #0x190]
100249d2c:     	add	x8, sp, #0x188
100249d30:     	add	x0, x8, #0x30
100249d34:     	mov	x1, x24
100249d38:     	mov	x2, x17
100249d3c:     	mov	x5, x28
100249d40:     	bl	0x10028b18c <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11find_hashed>
100249d44:     	tbz	w0, #0x0, 0x100249d70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x68c>
100249d48:     	ldr	x9, [sp, #0x20]
100249d4c:     	cmp	x1, x9
100249d50:     	b.hs	0x10024a90c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1228>
100249d54:     	mov	x11, x26
100249d58:     	ldr	x8, [sp, #0x60]
100249d5c:     	ldr	x10, [sp, #0x28]
100249d60:     	str	x10, [x8, x1, lsl #3]
100249d64:     	mov	x28, x21
100249d68:     	ldr	x21, [sp, #0x90]
100249d6c:     	b	0x100249e04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x720>
100249d70:     	str	x27, [sp, #0x18]
100249d74:     	cmn	x23, #0x1
100249d78:     	b.eq	0x100249d88 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x6a4>
100249d7c:     	ldp	x1, x0, [sp, #0x30]
100249d80:     	bl	0x10034e1b0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
100249d84:     	b	0x100249d94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x6b0>
100249d88:     	add	x0, x19, #0x20
100249d8c:     	ldp	x2, x1, [sp, #0x30]
100249d90:     	bl	0x1005eddc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>
100249d94:     	mov	x27, x0
100249d98:     	add	x8, sp, #0x188
100249d9c:     	add	x0, x8, #0x30
100249da0:     	mov	x1, x24
100249da4:     	mov	x2, x28
100249da8:     	bl	0x10028b360 <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11insert_hash>
100249dac:     	ldr	x24, [sp, #0x198]
100249db0:     	ldr	x8, [sp, #0x188]
100249db4:     	cmp	x24, x8
100249db8:     	b.eq	0x10024a30c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xc28>
100249dbc:     	ldr	x8, [sp, #0x190]
100249dc0:     	ldr	x9, [sp, #0x1a0]
100249dc4:     	str	x27, [x8, x24, lsl #3]
100249dc8:     	add	x8, x24, #0x1
100249dcc:     	str	x8, [sp, #0x198]
100249dd0:     	ldr	x24, [sp, #0x1b0]
100249dd4:     	cmp	x24, x9
100249dd8:     	mov	x28, x21
100249ddc:     	b.eq	0x10024a318 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xc34>
100249de0:     	ldr	x8, [sp, #0x1a8]
100249de4:     	str	x8, [sp, #0x60]
100249de8:     	ldr	x9, [sp, #0x28]
100249dec:     	str	x9, [x8, x24, lsl #3]
100249df0:     	add	x9, x24, #0x1
100249df4:     	str	x9, [sp, #0x1b0]
100249df8:     	ldr	x27, [sp, #0x18]
100249dfc:     	ldr	x21, [sp, #0x90]
100249e00:     	mov	x11, x26
100249e04:     	ldr	w26, [sp, #0x98]
100249e08:     	ldr	x1, [sp, #0x38]
100249e0c:     	b	0x10024a280 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb9c>
100249e10:     	ldr	x0, [sp, #0x88]
100249e14:     	cmp	x0, #0x8
100249e18:     	b.hs	0x10024a940 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x125c>
100249e1c:     	ldr	x8, [sp, #0x68]
100249e20:     	ldr	x9, [x8, x0, lsl #3]
100249e24:     	ldr	w8, [x9, #0x4]
100249e28:     	cmp	x3, x8
100249e2c:     	b.ne	0x100249e54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x770>
100249e30:     	add	x0, x9, #0x14
100249e34:     	mov	x1, x17
100249e38:     	mov	x2, x3
100249e3c:     	mov	x24, x11
100249e40:     	str	x9, [sp, #0x18]
100249e44:     	bl	0x100b66be0 <_writev+0x100b66be0>
100249e48:     	ldr	x10, [sp, #0x18]
100249e4c:     	ldp	x3, x17, [sp, #0x30]
100249e50:     	cbz	w0, 0x10024a328 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xc44>
100249e54:     	mov	x0, x17
100249e58:     	mov	x1, x3
100249e5c:     	bl	0x10032abfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100249e60:     	mov	x10, x0
100249e64:     	mov	w11, #0x0               ; =0
100249e68:     	mov	w9, #0x0                ; =0
100249e6c:     	ldr	x8, [sp, #0x88]
100249e70:     	cmp	x8, #0x0
100249e74:     	str	w9, [sp, #0x9c]
100249e78:     	csinc	w24, w9, wzr, ne
100249e7c:     	cmp	x28, #0x9
100249e80:     	b.hs	0x10024a8ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11c8>
100249e84:     	ldp	x2, x1, [sp, #0x30]
100249e88:     	ldr	x9, [sp, #0x20]
100249e8c:     	cbz	x28, 0x10024a1e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb00>
100249e90:     	ldr	x8, [sp, #0x100]
100249e94:     	cmp	x8, x10
100249e98:     	b.eq	0x10024a204 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb20>
100249e9c:     	tbnz	w24, #0x0, 0x100249ed4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x7f0>
100249ea0:     	ldr	w9, [x8, #0x4]
100249ea4:     	cmp	x2, x9
100249ea8:     	ldr	x9, [sp, #0x20]
100249eac:     	b.ne	0x100249ed4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x7f0>
100249eb0:     	add	x0, x8, #0x14
100249eb4:     	mov	x26, x11
100249eb8:     	str	x10, [sp, #0x18]
100249ebc:     	bl	0x100b66be0 <_writev+0x100b66be0>
100249ec0:     	ldp	x10, x9, [sp, #0x18]
100249ec4:     	ldp	x2, x1, [sp, #0x30]
100249ec8:     	mov	x11, x26
100249ecc:     	ldr	w26, [sp, #0x98]
100249ed0:     	cbz	w0, 0x10024a204 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb20>
100249ed4:     	cmp	x28, #0x1
100249ed8:     	b.eq	0x10024a1e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb00>
100249edc:     	ldr	x9, [sp, #0x108]
100249ee0:     	add	x8, sp, #0x148
100249ee4:     	add	x8, x8, #0x8
100249ee8:     	cmp	x9, x10
100249eec:     	b.eq	0x10024a208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
100249ef0:     	tbnz	w24, #0x0, 0x100249f2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x848>
100249ef4:     	ldr	w8, [x9, #0x4]
100249ef8:     	cmp	x2, x8
100249efc:     	b.ne	0x100249f2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x848>
100249f00:     	add	x0, x9, #0x14
100249f04:     	mov	x26, x11
100249f08:     	str	x10, [sp, #0x18]
100249f0c:     	bl	0x100b66be0 <_writev+0x100b66be0>
100249f10:     	ldr	x10, [sp, #0x18]
100249f14:     	ldp	x2, x1, [sp, #0x30]
100249f18:     	mov	x11, x26
100249f1c:     	ldr	w26, [sp, #0x98]
100249f20:     	add	x8, sp, #0x148
100249f24:     	add	x8, x8, #0x8
100249f28:     	cbz	w0, 0x10024a208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
100249f2c:     	cmp	x28, #0x2
100249f30:     	ldr	x9, [sp, #0x20]
100249f34:     	b.eq	0x10024a1e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb00>
100249f38:     	ldr	x9, [sp, #0x110]
100249f3c:     	add	x8, sp, #0x148
100249f40:     	add	x8, x8, #0x10
100249f44:     	cmp	x9, x10
100249f48:     	b.eq	0x10024a208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
100249f4c:     	tbnz	w24, #0x0, 0x100249f88 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x8a4>
100249f50:     	ldr	w8, [x9, #0x4]
100249f54:     	cmp	x2, x8
100249f58:     	b.ne	0x100249f88 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x8a4>
100249f5c:     	add	x0, x9, #0x14
100249f60:     	mov	x26, x11
100249f64:     	str	x10, [sp, #0x18]
100249f68:     	bl	0x100b66be0 <_writev+0x100b66be0>
100249f6c:     	ldr	x10, [sp, #0x18]
100249f70:     	ldp	x2, x1, [sp, #0x30]
100249f74:     	mov	x11, x26
100249f78:     	ldr	w26, [sp, #0x98]
100249f7c:     	add	x8, sp, #0x148
100249f80:     	add	x8, x8, #0x10
100249f84:     	cbz	w0, 0x10024a208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
100249f88:     	cmp	x28, #0x3
100249f8c:     	ldr	x9, [sp, #0x20]
100249f90:     	b.eq	0x10024a1e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb00>
100249f94:     	ldr	x9, [sp, #0x118]
100249f98:     	add	x8, sp, #0x148
100249f9c:     	add	x8, x8, #0x18
100249fa0:     	cmp	x9, x10
100249fa4:     	b.eq	0x10024a208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
100249fa8:     	tbnz	w24, #0x0, 0x100249fe4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x900>
100249fac:     	ldr	w8, [x9, #0x4]
100249fb0:     	cmp	x2, x8
100249fb4:     	b.ne	0x100249fe4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x900>
100249fb8:     	add	x0, x9, #0x14
100249fbc:     	mov	x26, x11
100249fc0:     	str	x10, [sp, #0x18]
100249fc4:     	bl	0x100b66be0 <_writev+0x100b66be0>
100249fc8:     	ldr	x10, [sp, #0x18]
100249fcc:     	ldp	x2, x1, [sp, #0x30]
100249fd0:     	mov	x11, x26
100249fd4:     	ldr	w26, [sp, #0x98]
100249fd8:     	add	x8, sp, #0x148
100249fdc:     	add	x8, x8, #0x18
100249fe0:     	cbz	w0, 0x10024a208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
100249fe4:     	cmp	x28, #0x4
100249fe8:     	ldr	x9, [sp, #0x20]
100249fec:     	b.eq	0x10024a1e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb00>
100249ff0:     	ldr	x9, [sp, #0x120]
100249ff4:     	add	x8, sp, #0x148
100249ff8:     	add	x8, x8, #0x20
100249ffc:     	cmp	x9, x10
10024a000:     	b.eq	0x10024a208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
10024a004:     	tbnz	w24, #0x0, 0x10024a040 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x95c>
10024a008:     	ldr	w8, [x9, #0x4]
10024a00c:     	cmp	x2, x8
10024a010:     	b.ne	0x10024a040 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x95c>
10024a014:     	add	x0, x9, #0x14
10024a018:     	mov	x26, x11
10024a01c:     	str	x10, [sp, #0x18]
10024a020:     	bl	0x100b66be0 <_writev+0x100b66be0>
10024a024:     	ldr	x10, [sp, #0x18]
10024a028:     	ldp	x2, x1, [sp, #0x30]
10024a02c:     	mov	x11, x26
10024a030:     	ldr	w26, [sp, #0x98]
10024a034:     	add	x8, sp, #0x148
10024a038:     	add	x8, x8, #0x20
10024a03c:     	cbz	w0, 0x10024a208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
10024a040:     	cmp	x28, #0x5
10024a044:     	ldr	x9, [sp, #0x20]
10024a048:     	b.eq	0x10024a1e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb00>
10024a04c:     	ldr	x9, [sp, #0x128]
10024a050:     	add	x8, sp, #0x148
10024a054:     	add	x8, x8, #0x28
10024a058:     	cmp	x9, x10
10024a05c:     	b.eq	0x10024a208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
10024a060:     	tbnz	w24, #0x0, 0x10024a09c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x9b8>
10024a064:     	ldr	w8, [x9, #0x4]
10024a068:     	cmp	x2, x8
10024a06c:     	b.ne	0x10024a09c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x9b8>
10024a070:     	add	x0, x9, #0x14
10024a074:     	mov	x26, x11
10024a078:     	str	x10, [sp, #0x18]
10024a07c:     	bl	0x100b66be0 <_writev+0x100b66be0>
10024a080:     	ldr	x10, [sp, #0x18]
10024a084:     	ldp	x2, x1, [sp, #0x30]
10024a088:     	mov	x11, x26
10024a08c:     	ldr	w26, [sp, #0x98]
10024a090:     	add	x8, sp, #0x148
10024a094:     	add	x8, x8, #0x28
10024a098:     	cbz	w0, 0x10024a208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
10024a09c:     	cmp	x28, #0x6
10024a0a0:     	ldr	x9, [sp, #0x20]
10024a0a4:     	b.eq	0x10024a1e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb00>
10024a0a8:     	ldr	x9, [sp, #0x130]
10024a0ac:     	add	x8, sp, #0x148
10024a0b0:     	add	x8, x8, #0x30
10024a0b4:     	cmp	x9, x10
10024a0b8:     	b.eq	0x10024a208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
10024a0bc:     	tbnz	w24, #0x0, 0x10024a0f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xa14>
10024a0c0:     	ldr	w8, [x9, #0x4]
10024a0c4:     	cmp	x2, x8
10024a0c8:     	b.ne	0x10024a0f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xa14>
10024a0cc:     	add	x0, x9, #0x14
10024a0d0:     	mov	x26, x11
10024a0d4:     	str	x10, [sp, #0x18]
10024a0d8:     	bl	0x100b66be0 <_writev+0x100b66be0>
10024a0dc:     	ldr	x10, [sp, #0x18]
10024a0e0:     	ldp	x2, x1, [sp, #0x30]
10024a0e4:     	mov	x11, x26
10024a0e8:     	ldr	w26, [sp, #0x98]
10024a0ec:     	add	x8, sp, #0x148
10024a0f0:     	add	x8, x8, #0x30
10024a0f4:     	cbz	w0, 0x10024a208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
10024a0f8:     	cmp	x28, #0x7
10024a0fc:     	ldr	x9, [sp, #0x20]
10024a100:     	b.eq	0x10024a1e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb00>
10024a104:     	ldr	x9, [sp, #0x138]
10024a108:     	add	x8, sp, #0x148
10024a10c:     	add	x8, x8, #0x38
10024a110:     	cmp	x9, x10
10024a114:     	b.eq	0x10024a208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
10024a118:     	tbnz	w24, #0x0, 0x10024a150 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xa6c>
10024a11c:     	ldr	w8, [x9, #0x4]
10024a120:     	cmp	x2, x8
10024a124:     	b.ne	0x10024a150 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xa6c>
10024a128:     	add	x0, x9, #0x14
10024a12c:     	str	w11, [sp, #0x30]
10024a130:     	mov	x24, x10
10024a134:     	bl	0x100b66be0 <_writev+0x100b66be0>
10024a138:     	mov	x10, x24
10024a13c:     	ldr	x1, [sp, #0x38]
10024a140:     	ldr	w11, [sp, #0x30]
10024a144:     	add	x8, sp, #0x148
10024a148:     	add	x8, x8, #0x38
10024a14c:     	cbz	w0, 0x10024a208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb24>
10024a150:     	cmp	x28, #0x8
10024a154:     	ldr	x9, [sp, #0x20]
10024a158:     	b.ne	0x10024a1e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb00>
10024a15c:     	mov	x21, x10
10024a160:     	mov	x26, x11
10024a164:     	mov	w0, #0x80               ; =128
10024a168:     	mov	w1, #0x8                ; =8
10024a16c:     	bl	0x100b63fc8 <_mi_malloc_aligned>
10024a170:     	cbz	x0, 0x10024a950 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x126c>
10024a174:     	mov	x24, x0
10024a178:     	mov	w0, #0x80               ; =128
10024a17c:     	mov	w1, #0x8                ; =8
10024a180:     	bl	0x100b63fc8 <_mi_malloc_aligned>
10024a184:     	str	x0, [sp, #0x60]
10024a188:     	cbz	x0, 0x10024a950 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x126c>
10024a18c:     	ldp	q0, q1, [sp, #0x100]
10024a190:     	stp	q0, q1, [x24]
10024a194:     	ldp	q0, q1, [sp, #0x120]
10024a198:     	stp	q0, q1, [x24, #0x20]
10024a19c:     	add	x9, sp, #0x148
10024a1a0:     	ldp	q0, q1, [x9]
10024a1a4:     	ldr	x8, [sp, #0x60]
10024a1a8:     	stp	q0, q1, [x8]
10024a1ac:     	ldp	q0, q1, [x9, #0x20]
10024a1b0:     	stp	q0, q1, [x8, #0x20]
10024a1b4:     	str	x21, [x24, #0x40]
10024a1b8:     	ldr	x10, [sp, #0x28]
10024a1bc:     	str	x10, [x8, #0x40]
10024a1c0:     	mov	w10, #0x10              ; =16
10024a1c4:     	stp	x10, x24, [sp, #0x188]
10024a1c8:     	ldp	q0, q1, [sp, #0x40]
10024a1cc:     	str	q1, [x9, #0x50]
10024a1d0:     	str	x8, [sp, #0x1a8]
10024a1d4:     	mov	w28, #0x8               ; =8
10024a1d8:     	stur	q0, [x9, #0x68]
10024a1dc:     	mov	w9, #0x9                ; =9
10024a1e0:     	b	0x100249dfc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x718>
10024a1e4:     	add	x8, sp, #0x100
10024a1e8:     	str	x10, [x8, x28, lsl #3]
10024a1ec:     	add	x8, sp, #0x148
10024a1f0:     	ldr	x10, [sp, #0x28]
10024a1f4:     	str	x10, [x8, x28, lsl #3]
10024a1f8:     	add	x28, x28, #0x1
10024a1fc:     	str	x28, [sp, #0x70]
10024a200:     	b	0x10024a280 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb9c>
10024a204:     	add	x8, sp, #0x148
10024a208:     	ldp	x9, x10, [sp, #0x20]
10024a20c:     	str	x10, [x8]
10024a210:     	b	0x10024a280 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb9c>
10024a214:     	mov	x11, x26
10024a218:     	ldr	w26, [sp, #0x98]
10024a21c:     	ldr	x1, [sp, #0x38]
10024a220:     	b	0x10024a238 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb54>
10024a224:     	ldr	x27, [sp, #0x18]
10024a228:     	mov	x28, x21
10024a22c:     	mov	x11, x26
10024a230:     	ldr	w26, [sp, #0x98]
10024a234:     	ldr	x24, [sp]
10024a238:     	ldr	x10, [sp, #0x8]
10024a23c:     	ldr	x8, [sp, #0x10]
10024a240:     	cmp	x24, x8
10024a244:     	ldr	x21, [sp, #0x90]
10024a248:     	ldr	x9, [sp, #0x20]
10024a24c:     	b.eq	0x10024a334 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xc50>
10024a250:     	str	x12, [x10, x24, lsl #3]
10024a254:     	add	x8, x24, #0x1
10024a258:     	str	x8, [sp, #0x198]
10024a25c:     	ldr	x8, [sp, #0x1a0]
10024a260:     	cmp	x9, x8
10024a264:     	b.eq	0x10024a378 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xc94>
10024a268:     	ldr	x8, [sp, #0x1a8]
10024a26c:     	str	x8, [sp, #0x60]
10024a270:     	ldr	x10, [sp, #0x28]
10024a274:     	str	x10, [x8, x9, lsl #3]
10024a278:     	add	x9, x9, #0x1
10024a27c:     	str	x9, [sp, #0x1b0]
10024a280:     	ldp	x24, x8, [x19, #0x68]
10024a284:     	cmp	x8, x24
10024a288:     	b.hs	0x10024a2c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xbdc>
10024a28c:     	mov	x12, x9
10024a290:     	ldr	x9, [x19, #0x60]
10024a294:     	ldrb	w10, [x9, x8]
10024a298:     	cmp	w10, #0x20
10024a29c:     	b.hi	0x10024a2bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xbd8>
10024a2a0:     	lsr	x10, x25, x10
10024a2a4:     	tbz	w10, #0x0, 0x10024a2bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xbd8>
10024a2a8:     	add	x8, x8, #0x1
10024a2ac:     	str	x8, [x19, #0x70]
10024a2b0:     	cmp	x24, x8
10024a2b4:     	b.ne	0x10024a294 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xbb0>
10024a2b8:     	b	0x10024a3a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcc4>
10024a2bc:     	mov	x9, x12
10024a2c0:     	cmp	x8, x24
10024a2c4:     	b.hs	0x10024a3a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcc4>
10024a2c8:     	str	x9, [sp, #0x20]
10024a2cc:     	ldr	x9, [x19, #0x60]
10024a2d0:     	ldrb	w9, [x9, x8]
10024a2d4:     	cmp	w9, #0x2c
10024a2d8:     	b.ne	0x10024a3a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcc4>
10024a2dc:     	mov	x21, x28
10024a2e0:     	add	x28, x8, #0x1
10024a2e4:     	str	x28, [x19, #0x70]
10024a2e8:     	cmp	x23, #0x1
10024a2ec:     	ldp	x22, x23, [sp, #0x80]
10024a2f0:     	b.lt	0x1002498a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1bc>
10024a2f4:     	mov	x0, x1
10024a2f8:     	mov	x24, x11
10024a2fc:     	bl	0x100b63d40 <_mi_free>
10024a300:     	mov	x11, x24
10024a304:     	ldp	x24, x28, [x19, #0x68]
10024a308:     	b	0x1002498a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1bc>
10024a30c:     	add	x0, sp, #0x188
10024a310:     	bl	0x100b40a2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10024a314:     	b	0x100249dbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x6d8>
10024a318:     	add	x8, sp, #0x188
10024a31c:     	add	x0, x8, #0x18
10024a320:     	bl	0x100b40a2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10024a324:     	b	0x100249de0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x6fc>
10024a328:     	mov	x11, x24
10024a32c:     	ldr	x0, [sp, #0x88]
10024a330:     	b	0x100249b20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x43c>
10024a334:     	add	x0, sp, #0x188
10024a338:     	str	x24, [sp]
10024a33c:     	mov	x24, x11
10024a340:     	str	x12, [sp, #0x60]
10024a344:     	bl	0x100b40a2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10024a348:     	ldr	x12, [sp, #0x60]
10024a34c:     	ldr	x1, [sp, #0x38]
10024a350:     	mov	x11, x24
10024a354:     	ldr	x24, [sp]
10024a358:     	ldr	x10, [sp, #0x190]
10024a35c:     	ldr	x9, [sp, #0x1b0]
10024a360:     	str	x12, [x10, x24, lsl #3]
10024a364:     	add	x8, x24, #0x1
10024a368:     	str	x8, [sp, #0x198]
10024a36c:     	ldr	x8, [sp, #0x1a0]
10024a370:     	cmp	x9, x8
10024a374:     	b.ne	0x10024a268 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb84>
10024a378:     	add	x8, sp, #0x188
10024a37c:     	add	x0, x8, #0x18
10024a380:     	mov	x24, x11
10024a384:     	str	x9, [sp, #0x20]
10024a388:     	bl	0x100b40a2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10024a38c:     	ldr	x9, [sp, #0x20]
10024a390:     	ldr	x1, [sp, #0x38]
10024a394:     	mov	x11, x24
10024a398:     	b	0x10024a268 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xb84>
10024a39c:     	strb	wzr, [x19, #0xd4]
10024a3a0:     	ldr	x21, [sp, #0x90]
10024a3a4:     	ldr	w26, [sp, #0x98]
10024a3a8:     	cmp	x23, #0x1
10024a3ac:     	ldr	w24, [sp, #0x9c]
10024a3b0:     	b.lt	0x10024a3bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcd8>
10024a3b4:     	mov	x0, x1
10024a3b8:     	bl	0x100b63d40 <_mi_free>
10024a3bc:     	ldp	x9, x8, [x19, #0x68]
10024a3c0:     	cmp	x8, x9
10024a3c4:     	b.hs	0x10024a4b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xdcc>
10024a3c8:     	ldr	x10, [x19, #0x60]
10024a3cc:     	mov	x11, #0x2600            ; =9728
10024a3d0:     	movk	x11, #0x1, lsl #32
10024a3d4:     	ldrb	w12, [x10, x8]
10024a3d8:     	cmp	w12, #0x20
10024a3dc:     	b.hi	0x10024a3fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd18>
10024a3e0:     	lsr	x13, x11, x12
10024a3e4:     	tbz	w13, #0x0, 0x10024a3fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd18>
10024a3e8:     	add	x8, x8, #0x1
10024a3ec:     	str	x8, [x19, #0x70]
10024a3f0:     	cmp	x9, x8
10024a3f4:     	b.ne	0x10024a3d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcf0>
10024a3f8:     	b	0x10024a4b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xdcc>
10024a3fc:     	cmp	w12, #0x7d
10024a400:     	b.ne	0x10024a4b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xdcc>
10024a404:     	add	x8, x8, #0x1
10024a408:     	str	x8, [x19, #0x70]
10024a40c:     	ldr	x23, [sp, #0x188]
10024a410:     	cmn	x23, #0x1
10024a414:     	b.ne	0x10024a4c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xddc>
10024a418:     	and	w8, w26, w24
10024a41c:     	ldr	w2, [sp, #0x7c]
10024a420:     	tbz	w8, #0x0, 0x10024a440 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd5c>
10024a424:     	ldr	x8, [sp, #0x70]
10024a428:     	ldr	x9, [sp, #0x80]
10024a42c:     	cmp	x9, x8
10024a430:     	b.ne	0x10024a440 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd5c>
10024a434:     	ldp	x9, x8, [sp, #0x80]
10024a438:     	cmp	x8, x9
10024a43c:     	b.eq	0x10024a554 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe70>
10024a440:     	cmp	x28, #0x9
10024a444:     	b.hs	0x10024a880 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x119c>
10024a448:     	ldr	x8, [x19, #0x78]
10024a44c:     	cmp	x28, x8
10024a450:     	b.ne	0x10024a470 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd8c>
10024a454:     	ldr	x21, [x19, #0xc0]
10024a458:     	cbz	x21, 0x10024a470 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd8c>
10024a45c:     	cbz	x28, 0x10024a754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
10024a460:     	ldr	x8, [x19, #0x80]
10024a464:     	ldr	x9, [sp, #0x100]
10024a468:     	cmp	x8, x9
10024a46c:     	b.eq	0x10024a74c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1068>
10024a470:     	add	x0, sp, #0x100
10024a474:     	mov	x1, x28
10024a478:     	bl	0x10032c2dc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
10024a47c:     	mov	x21, x0
10024a480:     	mov	x24, x1
10024a484:     	str	x28, [x19, #0x78]
10024a488:     	lsl	x2, x28, #3
10024a48c:     	add	x0, x19, #0x80
10024a490:     	add	x1, sp, #0x100
10024a494:     	bl	0x100b66bec <_writev+0x100b66bec>
10024a498:     	mov	x2, x24
10024a49c:     	str	x21, [x19, #0xc0]
10024a4a0:     	str	w24, [x19, #0xd0]
10024a4a4:     	cmp	x28, #0x9
10024a4a8:     	b.lo	0x10024a55c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe78>
10024a4ac:     	b	0x10024a530 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe4c>
10024a4b0:     	strb	wzr, [x19, #0xd4]
10024a4b4:     	ldr	x23, [sp, #0x188]
10024a4b8:     	cmn	x23, #0x1
10024a4bc:     	b.eq	0x10024a418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd34>
10024a4c0:     	ldp	x0, x1, [sp, #0x190]
10024a4c4:     	cmp	x1, #0x9
10024a4c8:     	b.hs	0x10024a548 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe64>
10024a4cc:     	ldr	x8, [x19, #0x78]
10024a4d0:     	cmp	x1, x8
10024a4d4:     	b.ne	0x10024a4f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe10>
10024a4d8:     	ldr	x21, [x19, #0xc0]
10024a4dc:     	cbz	x21, 0x10024a4f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe10>
10024a4e0:     	cbz	x1, 0x10024a754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
10024a4e4:     	ldr	x8, [x19, #0x80]
10024a4e8:     	ldr	x9, [x0]
10024a4ec:     	cmp	x8, x9
10024a4f0:     	b.eq	0x10024a690 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xfac>
10024a4f4:     	mov	x24, x0
10024a4f8:     	mov	x25, x1
10024a4fc:     	bl	0x10032c2dc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
10024a500:     	mov	x21, x0
10024a504:     	mov	x26, x1
10024a508:     	str	x25, [x19, #0x78]
10024a50c:     	lsl	x2, x25, #3
10024a510:     	add	x0, x19, #0x80
10024a514:     	mov	x1, x24
10024a518:     	bl	0x100b66bec <_writev+0x100b66bec>
10024a51c:     	mov	x2, x26
10024a520:     	str	x21, [x19, #0xc0]
10024a524:     	str	w26, [x19, #0xd0]
10024a528:     	cmp	x28, #0x9
10024a52c:     	b.lo	0x10024a55c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe78>
10024a530:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
10024a534:     	add	x3, x3, #0x710
10024a538:     	mov	x0, #0x0                ; =0
10024a53c:     	mov	x1, x28
10024a540:     	mov	w2, #0x8                ; =8
10024a544:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
10024a548:     	bl	0x10032c2dc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
10024a54c:     	mov	x21, x0
10024a550:     	mov	x2, x1
10024a554:     	cmp	x28, #0x9
10024a558:     	b.hs	0x10024a530 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe4c>
10024a55c:     	ldr	x8, [sp, #0x1b0]
10024a560:     	cmn	x23, #0x1
10024a564:     	add	x9, sp, #0x148
10024a568:     	ldr	x10, [sp, #0x60]
10024a56c:     	csel	x3, x9, x10, eq
10024a570:     	csel	x4, x28, x8, eq
10024a574:     	add	x0, x19, #0x20
10024a578:     	mov	x1, x21
10024a57c:     	bl	0x1005bf688 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
10024a580:     	mov	x19, x0
10024a584:     	ldrb	w8, [x20, #0x20]
10024a588:     	cbnz	w8, 0x10024a858 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1174>
10024a58c:     	ldr	x8, [x20]
10024a590:     	cbnz	x8, 0x10024a8e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11fc>
10024a594:     	ldr	x8, [x20, #0x18]
10024a598:     	cmp	x27, x8
10024a59c:     	b.hi	0x10024a5a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xec0>
10024a5a0:     	str	x27, [x20, #0x18]
10024a5a4:     	ldr	x8, [sp, #0x188]
10024a5a8:     	cmn	x8, #0x1
10024a5ac:     	b.eq	0x10024a668 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf84>
10024a5b0:     	cbz	x8, 0x10024a5bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xed8>
10024a5b4:     	ldr	x0, [sp, #0x190]
10024a5b8:     	bl	0x100b63d40 <_mi_free>
10024a5bc:     	ldr	x8, [sp, #0x1a0]
10024a5c0:     	cbz	x8, 0x10024a5cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xee8>
10024a5c4:     	ldr	x0, [sp, #0x1a8]
10024a5c8:     	bl	0x100b63d40 <_mi_free>
10024a5cc:     	ldr	x20, [sp, #0x1b8]
10024a5d0:     	cmn	x20, #0x1
10024a5d4:     	b.eq	0x10024a668 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf84>
10024a5d8:     	ldr	x9, [sp, #0x1d8]
10024a5dc:     	cbz	x9, 0x10024a600 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf1c>
10024a5e0:     	lsl	x8, x9, #4
10024a5e4:     	add	x9, x8, x9
10024a5e8:     	cmn	x9, #0x19
10024a5ec:     	b.eq	0x10024a600 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf1c>
10024a5f0:     	ldr	x9, [sp, #0x1d0]
10024a5f4:     	sub	x8, x9, x8
10024a5f8:     	sub	x0, x8, #0x10
10024a5fc:     	bl	0x100b63d40 <_mi_free>
10024a600:     	cbz	x20, 0x10024a668 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf84>
10024a604:     	ldr	x0, [sp, #0x1c0]
10024a608:     	bl	0x100b63d40 <_mi_free>
10024a60c:     	b	0x10024a668 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf84>
10024a610:     	b	0x1002497c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe0>
10024a614:     	sub	x0, x29, #0x68
10024a618:     	mov	x1, #0x0                ; =0
10024a61c:     	bl	0x10032c2dc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
10024a620:     	mov	x2, x1
10024a624:     	mov	x1, x0
10024a628:     	str	xzr, [x19, #0x78]
10024a62c:     	str	x0, [x19, #0xc0]
10024a630:     	str	w2, [x19, #0xd0]
10024a634:     	add	x0, x19, #0x20
10024a638:     	mov	w3, #0x8                ; =8
10024a63c:     	mov	x4, #0x0                ; =0
10024a640:     	bl	0x1005bf688 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
10024a644:     	mov	x19, x0
10024a648:     	ldrb	w8, [x20, #0x20]
10024a64c:     	cbnz	w8, 0x10024a898 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11b4>
10024a650:     	ldr	x8, [x20]
10024a654:     	cbnz	x8, 0x10024a8e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11fc>
10024a658:     	ldr	x8, [x20, #0x18]
10024a65c:     	cmp	x27, x8
10024a660:     	b.hi	0x10024a668 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf84>
10024a664:     	str	x27, [x20, #0x18]
10024a668:     	mov	x0, #0x7ffd000000000000 ; =9222527611924643840
10024a66c:     	bfxil	x0, x19, #0, #48
10024a670:     	add	sp, sp, #0x240
10024a674:     	ldp	x29, x30, [sp, #0x50]
10024a678:     	ldp	x20, x19, [sp, #0x40]
10024a67c:     	ldp	x22, x21, [sp, #0x30]
10024a680:     	ldp	x24, x23, [sp, #0x20]
10024a684:     	ldp	x26, x25, [sp, #0x10]
10024a688:     	ldp	x28, x27, [sp], #0x60
10024a68c:     	ret
10024a690:     	cmp	x1, #0x1
10024a694:     	b.eq	0x10024a754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
10024a698:     	ldr	x8, [x19, #0x88]
10024a69c:     	ldr	x9, [x0, #0x8]
10024a6a0:     	cmp	x8, x9
10024a6a4:     	b.ne	0x10024a4f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe10>
10024a6a8:     	cmp	x1, #0x2
10024a6ac:     	b.eq	0x10024a754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
10024a6b0:     	ldr	x8, [x19, #0x90]
10024a6b4:     	ldr	x9, [x0, #0x10]
10024a6b8:     	cmp	x8, x9
10024a6bc:     	b.ne	0x10024a4f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe10>
10024a6c0:     	cmp	x1, #0x3
10024a6c4:     	b.eq	0x10024a754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
10024a6c8:     	ldr	x8, [x19, #0x98]
10024a6cc:     	ldr	x9, [x0, #0x18]
10024a6d0:     	cmp	x8, x9
10024a6d4:     	b.ne	0x10024a4f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe10>
10024a6d8:     	cmp	x1, #0x4
10024a6dc:     	b.eq	0x10024a754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
10024a6e0:     	ldr	x8, [x19, #0xa0]
10024a6e4:     	ldr	x9, [x0, #0x20]
10024a6e8:     	cmp	x8, x9
10024a6ec:     	b.ne	0x10024a4f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe10>
10024a6f0:     	cmp	x1, #0x5
10024a6f4:     	b.eq	0x10024a754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
10024a6f8:     	ldr	x8, [x19, #0xa8]
10024a6fc:     	ldr	x9, [x0, #0x28]
10024a700:     	cmp	x8, x9
10024a704:     	b.ne	0x10024a4f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe10>
10024a708:     	cmp	x1, #0x6
10024a70c:     	b.eq	0x10024a754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
10024a710:     	ldr	x8, [x19, #0xb0]
10024a714:     	ldr	x9, [x0, #0x30]
10024a718:     	cmp	x8, x9
10024a71c:     	b.ne	0x10024a4f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe10>
10024a720:     	cmp	x1, #0x7
10024a724:     	b.eq	0x10024a754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
10024a728:     	ldr	x8, [x19, #0xb8]
10024a72c:     	ldr	x9, [x0, #0x38]
10024a730:     	cmp	x8, x9
10024a734:     	b.ne	0x10024a4f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe10>
10024a738:     	b	0x10024a754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
10024a73c:     	mov	x28, x21
10024a740:     	ldr	x21, [sp, #0x90]
10024a744:     	ldp	w26, w24, [sp, #0x98]
10024a748:     	b	0x10024a3bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcd8>
10024a74c:     	cmp	x28, #0x1
10024a750:     	b.ne	0x10024a764 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1080>
10024a754:     	ldr	w2, [x19, #0xd0]
10024a758:     	cmp	x28, #0x9
10024a75c:     	b.lo	0x10024a55c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe78>
10024a760:     	b	0x10024a530 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xe4c>
10024a764:     	ldr	x8, [x19, #0x88]
10024a768:     	ldr	x9, [sp, #0x108]
10024a76c:     	cmp	x8, x9
10024a770:     	b.ne	0x10024a470 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd8c>
10024a774:     	cmp	x28, #0x2
10024a778:     	b.eq	0x10024a754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
10024a77c:     	ldr	x8, [x19, #0x90]
10024a780:     	ldr	x9, [sp, #0x110]
10024a784:     	cmp	x8, x9
10024a788:     	b.ne	0x10024a470 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd8c>
10024a78c:     	cmp	x28, #0x3
10024a790:     	b.eq	0x10024a754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
10024a794:     	ldr	x8, [x19, #0x98]
10024a798:     	ldr	x9, [sp, #0x118]
10024a79c:     	cmp	x8, x9
10024a7a0:     	b.ne	0x10024a470 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd8c>
10024a7a4:     	cmp	x28, #0x4
10024a7a8:     	b.eq	0x10024a754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
10024a7ac:     	ldr	x8, [x19, #0xa0]
10024a7b0:     	ldr	x9, [sp, #0x120]
10024a7b4:     	cmp	x8, x9
10024a7b8:     	b.ne	0x10024a470 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd8c>
10024a7bc:     	cmp	x28, #0x5
10024a7c0:     	b.eq	0x10024a754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
10024a7c4:     	ldr	x8, [x19, #0xa8]
10024a7c8:     	ldr	x9, [sp, #0x128]
10024a7cc:     	cmp	x8, x9
10024a7d0:     	b.ne	0x10024a470 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd8c>
10024a7d4:     	cmp	x28, #0x6
10024a7d8:     	b.eq	0x10024a754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
10024a7dc:     	ldr	x8, [x19, #0xb0]
10024a7e0:     	ldr	x9, [sp, #0x130]
10024a7e4:     	cmp	x8, x9
10024a7e8:     	b.ne	0x10024a470 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd8c>
10024a7ec:     	cmp	x28, #0x7
10024a7f0:     	b.eq	0x10024a754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
10024a7f4:     	ldr	x8, [x19, #0xb8]
10024a7f8:     	ldr	x9, [sp, #0x138]
10024a7fc:     	cmp	x8, x9
10024a800:     	b.ne	0x10024a470 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xd8c>
10024a804:     	b	0x10024a754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x1070>
10024a808:     	ldr	x21, [sp, #0x90]
10024a80c:     	ldp	w26, w24, [sp, #0x98]
10024a810:     	ldr	x1, [sp, #0x38]
10024a814:     	cmp	x23, #0x1
10024a818:     	b.ge	0x10024a3b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcd0>
10024a81c:     	b	0x10024a3bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xcd8>
10024a820:     	cmp	w8, #0x1
10024a824:     	b.ne	0x10024a8a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11bc>
10024a828:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10024a82c:     	add	x1, x1, #0x898
10024a830:     	mov	x0, x20
10024a834:     	bl	0x100a2519c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10024a838:     	strb	wzr, [x20, #0x20]
10024a83c:     	ldr	x8, [x20]
10024a840:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10024a844:     	cmp	x8, x9
10024a848:     	b.lo	0x1002497f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x110>
10024a84c:     	adrp	x0, 0x100efe000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
10024a850:     	add	x0, x0, #0x4a0
10024a854:     	bl	0x100b1749c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
10024a858:     	cmp	w8, #0x2
10024a85c:     	b.eq	0x10024a8a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11bc>
10024a860:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10024a864:     	add	x1, x1, #0x898
10024a868:     	mov	x0, x20
10024a86c:     	bl	0x100a2519c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10024a870:     	strb	wzr, [x20, #0x20]
10024a874:     	ldr	x8, [x20]
10024a878:     	cbz	x8, 0x10024a594 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xeb0>
10024a87c:     	b	0x10024a8e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11fc>
10024a880:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
10024a884:     	add	x3, x3, #0x6f8
10024a888:     	mov	x0, #0x0                ; =0
10024a88c:     	mov	x1, x28
10024a890:     	mov	w2, #0x8                ; =8
10024a894:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
10024a898:     	cmp	w8, #0x2
10024a89c:     	b.ne	0x10024a8c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0x11e0>
10024a8a0:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
10024a8a4:     	add	x0, x0, #0xc18
10024a8a8:     	bl	0x100b5d39c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
10024a8ac:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
10024a8b0:     	add	x3, x3, #0x6b0
10024a8b4:     	mov	x0, #0x0                ; =0
10024a8b8:     	mov	x1, x28
10024a8bc:     	mov	w2, #0x8                ; =8
10024a8c0:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
10024a8c4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10024a8c8:     	add	x1, x1, #0x898
10024a8cc:     	mov	x0, x20
10024a8d0:     	bl	0x100a2519c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10024a8d4:     	strb	wzr, [x20, #0x20]
10024a8d8:     	ldr	x8, [x20]
10024a8dc:     	cbz	x8, 0x10024a658 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_+0xf74>
10024a8e0:     	adrp	x0, 0x100efe000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
10024a8e4:     	add	x0, x0, #0x488
10024a8e8:     	bl	0x100b1746c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10024a8ec:     	adrp	x0, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
10024a8f0:     	add	x0, x0, #0x668
10024a8f4:     	bl	0x100b17530 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
10024a8f8:     	adrp	x2, 0x100efc000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
10024a8fc:     	add	x2, x2, #0x800
10024a900:     	mov	x0, x23
10024a904:     	mov	w1, #0x8                ; =8
10024a908:     	bl	0x100b175cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
10024a90c:     	adrp	x2, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
10024a910:     	add	x2, x2, #0x6c8
10024a914:     	mov	x0, x1
10024a918:     	mov	x1, x9
10024a91c:     	bl	0x100b175cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
10024a920:     	adrp	x2, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
10024a924:     	add	x2, x2, #0x6e0
10024a928:     	mov	x1, x9
10024a92c:     	bl	0x100b175cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
10024a930:     	adrp	x2, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
10024a934:     	add	x2, x2, #0x698
10024a938:     	mov	w1, #0x8                ; =8
10024a93c:     	bl	0x100b175cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
10024a940:     	adrp	x2, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
10024a944:     	add	x2, x2, #0x680
10024a948:     	mov	w1, #0x8                ; =8
10024a94c:     	bl	0x100b175cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
10024a950:     	mov	w0, #0x8                ; =8
10024a954:     	mov	w1, #0x80               ; =128
10024a958:     	bl	0x100b170c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
