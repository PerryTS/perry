
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/isolated-json-scan-chunks-r36/main-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010024541c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow>:
10024541c:     	sub	sp, sp, #0x90
100245420:     	stp	x28, x27, [sp, #0x30]
100245424:     	stp	x26, x25, [sp, #0x40]
100245428:     	stp	x24, x23, [sp, #0x50]
10024542c:     	stp	x22, x21, [sp, #0x60]
100245430:     	stp	x20, x19, [sp, #0x70]
100245434:     	stp	x29, x30, [sp, #0x80]
100245438:     	add	x29, sp, #0x80
10024543c:     	ldp	x20, x22, [x1, #0x68]
100245440:     	subs	x23, x22, x2
100245444:     	b.lo	0x100246080 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc64>
100245448:     	cmp	x22, x20
10024544c:     	b.hi	0x100246080 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc64>
100245450:     	tbz	x23, #0x3f, 0x100245464 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x48>
100245454:     	mov	x24, #0x0               ; =0
100245458:     	mov	x0, x24
10024545c:     	mov	x1, x23
100245460:     	bl	0x100b10140 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100245464:     	mov	x21, x1
100245468:     	ldr	x25, [x1, #0x60]
10024546c:     	cmp	x22, x2
100245470:     	str	x0, [sp, #0x8]
100245474:     	b.ne	0x100245488 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x6c>
100245478:     	mov	w8, #0x1                ; =1
10024547c:     	stp	x23, x8, [sp, #0x10]
100245480:     	str	xzr, [sp, #0x20]
100245484:     	b	0x1002454b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x98>
100245488:     	mov	x19, x2
10024548c:     	mov	w24, #0x1               ; =1
100245490:     	mov	x0, x23
100245494:     	mov	w1, #0x1                ; =1
100245498:     	bl	0x100b5d008 <_mi_malloc_aligned>
10024549c:     	cbz	x0, 0x100245458 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3c>
1002454a0:     	stp	x23, x0, [sp, #0x10]
1002454a4:     	add	x1, x25, x19
1002454a8:     	mov	x2, x23
1002454ac:     	bl	0x100b5fc2c <_writev+0x100b5fc2c>
1002454b0:     	str	x23, [sp, #0x20]
1002454b4:     	adds	x8, x22, #0x40
1002454b8:     	csinv	x8, x8, xzr, lo
1002454bc:     	cmp	x8, x20
1002454c0:     	csel	x28, x8, x20, lo
1002454c4:     	mov	w8, #0xdc00             ; =56320
1002454c8:     	movk	w8, #0x370, lsl #16
1002454cc:     	sub	w8, w8, #0x100, lsl #12 ; =0x100000
1002454d0:     	str	w8, [sp, #0x4]
1002454d4:     	b	0x1002454e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xcc>
1002454d8:     	ldr	x8, [sp, #0x18]
1002454dc:     	strb	w19, [x8, x23]
1002454e0:     	add	x8, x23, #0x1
1002454e4:     	str	x8, [sp, #0x20]
1002454e8:     	cmp	x22, x28
1002454ec:     	b.lo	0x100245ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x6bc>
1002454f0:     	sub	x8, x20, x22
1002454f4:     	cmp	x8, #0x40
1002454f8:     	b.lo	0x100245ac0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x6a4>
1002454fc:     	ldp	x28, x24, [sp, #0x18]
100245500:     	ldr	x8, [sp, #0x10]
100245504:     	sub	x8, x8, x24
100245508:     	cmp	x8, #0x3f
10024550c:     	b.ls	0x100245ac0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x6a4>
100245510:     	cmn	x22, #0x35
100245514:     	b.hi	0x100245aa4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x688>
100245518:     	mov	x26, #0x0               ; =0
10024551c:     	add	x27, x28, x24
100245520:     	add	x19, x22, #0x34
100245524:     	mov	x8, x22
100245528:     	add	x9, x25, x8
10024552c:     	ldrb	w10, [x9]
100245530:     	add	x22, x8, #0x1
100245534:     	cmp	w10, #0x5c
100245538:     	b.eq	0x100245564 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x148>
10024553c:     	cmp	w10, #0x22
100245540:     	b.eq	0x100246030 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc14>
100245544:     	cmp	w10, #0x20
100245548:     	b.lo	0x100246008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbec>
10024554c:     	strb	w10, [x27, x26]
100245550:     	add	x26, x26, #0x1
100245554:     	mov	x8, x22
100245558:     	cmp	x22, x19
10024555c:     	b.lo	0x100245528 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
100245560:     	b	0x100245aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
100245564:     	ldrb	w10, [x25, x22]
100245568:     	add	x22, x8, #0x2
10024556c:     	cmp	w10, #0x65
100245570:     	b.le	0x1002455ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x1d0>
100245574:     	cmp	w10, #0x71
100245578:     	b.le	0x10024564c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x230>
10024557c:     	cmp	w10, #0x72
100245580:     	b.eq	0x1002456cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2b0>
100245584:     	cmp	w10, #0x74
100245588:     	b.eq	0x100245678 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x25c>
10024558c:     	cmp	w10, #0x75
100245590:     	b.ne	0x100246008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbec>
100245594:     	add	x11, x25, x22
100245598:     	ldrb	w12, [x11]
10024559c:     	sub	w10, w12, #0x30
1002455a0:     	cmp	w10, #0xa
1002455a4:     	b.lo	0x1002455b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x19c>
1002455a8:     	sub	w10, w12, #0x61
1002455ac:     	cmp	w10, #0x6
1002455b0:     	b.hs	0x100245704 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2e8>
1002455b4:     	sub	w10, w12, #0x57
1002455b8:     	ldrb	w13, [x11, #0x1]
1002455bc:     	sub	w12, w13, #0x30
1002455c0:     	cmp	w12, #0xa
1002455c4:     	b.hs	0x100245724 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x308>
1002455c8:     	ldrb	w14, [x11, #0x2]
1002455cc:     	sub	w13, w14, #0x30
1002455d0:     	cmp	w13, #0xa
1002455d4:     	b.hs	0x100245744 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x328>
1002455d8:     	ldrb	w11, [x11, #0x3]
1002455dc:     	sub	w14, w11, #0x30
1002455e0:     	cmp	w14, #0xa
1002455e4:     	b.lo	0x1002457d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3b4>
1002455e8:     	b	0x1002457ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x390>
1002455ec:     	cmp	w10, #0x5b
1002455f0:     	b.gt	0x100245620 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x204>
1002455f4:     	cmp	w10, #0x22
1002455f8:     	b.eq	0x100245694 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x278>
1002455fc:     	cmp	w10, #0x2f
100245600:     	b.ne	0x100246008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbec>
100245604:     	mov	w8, #0x2f               ; =47
100245608:     	strb	w8, [x27, x26]
10024560c:     	add	x26, x26, #0x1
100245610:     	mov	x8, x22
100245614:     	cmp	x22, x19
100245618:     	b.lo	0x100245528 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
10024561c:     	b	0x100245aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
100245620:     	cmp	w10, #0x5c
100245624:     	b.eq	0x1002456b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x294>
100245628:     	cmp	w10, #0x62
10024562c:     	b.ne	0x100246008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbec>
100245630:     	mov	w8, #0x8                ; =8
100245634:     	strb	w8, [x27, x26]
100245638:     	add	x26, x26, #0x1
10024563c:     	mov	x8, x22
100245640:     	cmp	x22, x19
100245644:     	b.lo	0x100245528 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
100245648:     	b	0x100245aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
10024564c:     	cmp	w10, #0x66
100245650:     	b.eq	0x1002456e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2cc>
100245654:     	cmp	w10, #0x6e
100245658:     	b.ne	0x100246008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbec>
10024565c:     	mov	w8, #0xa                ; =10
100245660:     	strb	w8, [x27, x26]
100245664:     	add	x26, x26, #0x1
100245668:     	mov	x8, x22
10024566c:     	cmp	x22, x19
100245670:     	b.lo	0x100245528 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
100245674:     	b	0x100245aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
100245678:     	mov	w8, #0x9                ; =9
10024567c:     	strb	w8, [x27, x26]
100245680:     	add	x26, x26, #0x1
100245684:     	mov	x8, x22
100245688:     	cmp	x22, x19
10024568c:     	b.lo	0x100245528 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
100245690:     	b	0x100245aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
100245694:     	mov	w8, #0x22               ; =34
100245698:     	strb	w8, [x27, x26]
10024569c:     	add	x26, x26, #0x1
1002456a0:     	mov	x8, x22
1002456a4:     	cmp	x22, x19
1002456a8:     	b.lo	0x100245528 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
1002456ac:     	b	0x100245aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
1002456b0:     	mov	w8, #0x5c               ; =92
1002456b4:     	strb	w8, [x27, x26]
1002456b8:     	add	x26, x26, #0x1
1002456bc:     	mov	x8, x22
1002456c0:     	cmp	x22, x19
1002456c4:     	b.lo	0x100245528 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
1002456c8:     	b	0x100245aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
1002456cc:     	mov	w8, #0xd                ; =13
1002456d0:     	strb	w8, [x27, x26]
1002456d4:     	add	x26, x26, #0x1
1002456d8:     	mov	x8, x22
1002456dc:     	cmp	x22, x19
1002456e0:     	b.lo	0x100245528 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
1002456e4:     	b	0x100245aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
1002456e8:     	mov	w8, #0xc                ; =12
1002456ec:     	strb	w8, [x27, x26]
1002456f0:     	add	x26, x26, #0x1
1002456f4:     	mov	x8, x22
1002456f8:     	cmp	x22, x19
1002456fc:     	b.lo	0x100245528 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
100245700:     	b	0x100245aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
100245704:     	sub	w10, w12, #0x41
100245708:     	cmp	w10, #0x6
10024570c:     	b.hs	0x100246008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbec>
100245710:     	sub	w10, w12, #0x37
100245714:     	ldrb	w13, [x11, #0x1]
100245718:     	sub	w12, w13, #0x30
10024571c:     	cmp	w12, #0xa
100245720:     	b.lo	0x1002455c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x1ac>
100245724:     	sub	w12, w13, #0x61
100245728:     	cmp	w12, #0x6
10024572c:     	b.hs	0x100245768 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x34c>
100245730:     	sub	w12, w13, #0x57
100245734:     	ldrb	w14, [x11, #0x2]
100245738:     	sub	w13, w14, #0x30
10024573c:     	cmp	w13, #0xa
100245740:     	b.lo	0x1002455d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x1bc>
100245744:     	sub	w13, w14, #0x61
100245748:     	cmp	w13, #0x6
10024574c:     	b.hs	0x10024578c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x370>
100245750:     	sub	w13, w14, #0x57
100245754:     	ldrb	w11, [x11, #0x3]
100245758:     	sub	w14, w11, #0x30
10024575c:     	cmp	w14, #0xa
100245760:     	b.hs	0x1002457ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x390>
100245764:     	b	0x1002457d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3b4>
100245768:     	sub	w12, w13, #0x41
10024576c:     	cmp	w12, #0x5
100245770:     	b.hi	0x100246008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbec>
100245774:     	sub	w12, w13, #0x37
100245778:     	ldrb	w14, [x11, #0x2]
10024577c:     	sub	w13, w14, #0x30
100245780:     	cmp	w13, #0xa
100245784:     	b.hs	0x100245744 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x328>
100245788:     	b	0x1002455d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x1bc>
10024578c:     	sub	w13, w14, #0x41
100245790:     	cmp	w13, #0x5
100245794:     	b.hi	0x100246008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbec>
100245798:     	sub	w13, w14, #0x37
10024579c:     	ldrb	w11, [x11, #0x3]
1002457a0:     	sub	w14, w11, #0x30
1002457a4:     	cmp	w14, #0xa
1002457a8:     	b.lo	0x1002457d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3b4>
1002457ac:     	sub	w14, w11, #0x61
1002457b0:     	cmp	w14, #0x6
1002457b4:     	b.hs	0x1002457c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3a4>
1002457b8:     	sub	w14, w11, #0x57
1002457bc:     	b	0x1002457d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3b4>
1002457c0:     	sub	w14, w11, #0x41
1002457c4:     	cmp	w14, #0x5
1002457c8:     	b.hi	0x100246008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbec>
1002457cc:     	sub	w14, w11, #0x37
1002457d0:     	add	x22, x8, #0x6
1002457d4:     	and	w10, w10, #0xff
1002457d8:     	and	w11, w12, #0xff
1002457dc:     	lsl	w11, w11, #4
1002457e0:     	orr	w11, w11, w10, lsl #8
1002457e4:     	and	w10, w13, #0xff
1002457e8:     	orr	w12, w11, w10
1002457ec:     	lsl	w13, w12, #4
1002457f0:     	and	w10, w14, #0xff
1002457f4:     	orr	w10, w13, w10
1002457f8:     	cmp	w11, #0xd80
1002457fc:     	b.hs	0x100245838 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x41c>
100245800:     	str	wzr, [sp, #0x2c]
100245804:     	and	w8, w13, #0xffff
100245808:     	mov	w9, #0xd800             ; =55296
10024580c:     	movk	w9, #0xffef, lsl #16
100245810:     	eor	w8, w8, w9
100245814:     	mov	w9, #0x800              ; =2048
100245818:     	movk	w9, #0xffef, lsl #16
10024581c:     	cmp	w8, w9
100245820:     	b.lo	0x100246098 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc7c>
100245824:     	cmp	w12, #0x8
100245828:     	b.hs	0x100245890 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x474>
10024582c:     	strb	w10, [sp, #0x2c]
100245830:     	mov	w23, #0x1               ; =1
100245834:     	b	0x100245a58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x63c>
100245838:     	cmp	w12, #0xdbf
10024583c:     	b.hi	0x1002458b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x49c>
100245840:     	cmp	x22, x20
100245844:     	b.hs	0x10024610c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xcf0>
100245848:     	ldrb	w12, [x25, x22]
10024584c:     	cmp	w12, #0x5c
100245850:     	b.ne	0x100245a2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x610>
100245854:     	add	x0, x8, #0x7
100245858:     	cmp	x0, x20
10024585c:     	b.hs	0x100246120 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xd04>
100245860:     	ldrb	w12, [x25, x0]
100245864:     	cmp	w12, #0x75
100245868:     	b.ne	0x100245a2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x610>
10024586c:     	ldrb	w13, [x9, #0x8]
100245870:     	sub	w12, w13, #0x30
100245874:     	cmp	w12, #0xa
100245878:     	b.lo	0x1002458f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x4d8>
10024587c:     	sub	w12, w13, #0x61
100245880:     	cmp	w12, #0x6
100245884:     	b.hs	0x1002458e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x4c8>
100245888:     	sub	w12, w13, #0x57
10024588c:     	b	0x1002458f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x4d8>
100245890:     	mov	w8, #-0x80              ; =-128
100245894:     	bfxil	w8, w10, #0, #6
100245898:     	cmp	w11, #0x80
10024589c:     	b.hs	0x1002458c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x4ac>
1002458a0:     	lsr	w9, w10, #6
1002458a4:     	orr	w9, w9, #0xc0
1002458a8:     	strb	w9, [sp, #0x2c]
1002458ac:     	strb	w8, [sp, #0x2d]
1002458b0:     	mov	w23, #0x2               ; =2
1002458b4:     	b	0x100245a58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x63c>
1002458b8:     	str	wzr, [sp, #0x2c]
1002458bc:     	cmp	w11, #0xe00
1002458c0:     	b.hs	0x100245804 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3e8>
1002458c4:     	b	0x100245a30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x614>
1002458c8:     	lsr	w9, w11, #8
1002458cc:     	mov	w11, #0x80              ; =128
1002458d0:     	orr	w9, w9, #0xe0
1002458d4:     	strb	w9, [sp, #0x2c]
1002458d8:     	bfxil	w11, w10, #6, #6
1002458dc:     	strb	w11, [sp, #0x2d]
1002458e0:     	b	0x100245a50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x634>
1002458e4:     	sub	w12, w13, #0x41
1002458e8:     	cmp	w12, #0x6
1002458ec:     	b.hs	0x100245a2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x610>
1002458f0:     	sub	w12, w13, #0x37
1002458f4:     	ldrb	w14, [x9, #0x9]
1002458f8:     	sub	w13, w14, #0x30
1002458fc:     	cmp	w13, #0xa
100245900:     	b.lo	0x100245928 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x50c>
100245904:     	sub	w13, w14, #0x61
100245908:     	cmp	w13, #0x6
10024590c:     	b.hs	0x100245918 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x4fc>
100245910:     	sub	w13, w14, #0x57
100245914:     	b	0x100245928 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x50c>
100245918:     	sub	w13, w14, #0x41
10024591c:     	cmp	w13, #0x5
100245920:     	b.hi	0x100245a2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x610>
100245924:     	sub	w13, w14, #0x37
100245928:     	ldrb	w15, [x9, #0xa]
10024592c:     	sub	w14, w15, #0x30
100245930:     	cmp	w14, #0xa
100245934:     	b.lo	0x10024595c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x540>
100245938:     	sub	w14, w15, #0x61
10024593c:     	cmp	w14, #0x6
100245940:     	b.hs	0x10024594c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x530>
100245944:     	sub	w14, w15, #0x57
100245948:     	b	0x10024595c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x540>
10024594c:     	sub	w14, w15, #0x41
100245950:     	cmp	w14, #0x5
100245954:     	b.hi	0x100245a2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x610>
100245958:     	sub	w14, w15, #0x37
10024595c:     	ldrb	w15, [x9, #0xb]
100245960:     	sub	w9, w15, #0x30
100245964:     	cmp	w9, #0xa
100245968:     	b.lo	0x100245990 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x574>
10024596c:     	sub	w9, w15, #0x61
100245970:     	cmp	w9, #0x6
100245974:     	b.hs	0x100245980 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x564>
100245978:     	sub	w9, w15, #0x57
10024597c:     	b	0x100245990 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x574>
100245980:     	sub	w9, w15, #0x41
100245984:     	cmp	w9, #0x5
100245988:     	b.hi	0x100245a2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x610>
10024598c:     	sub	w9, w15, #0x37
100245990:     	and	w12, w12, #0xff
100245994:     	and	w13, w13, #0xff
100245998:     	lsl	w13, w13, #4
10024599c:     	orr	w12, w13, w12, lsl #8
1002459a0:     	and	w13, w14, #0xff
1002459a4:     	orr	w12, w12, w13
1002459a8:     	and	w13, w12, #0xfc0
1002459ac:     	str	wzr, [sp, #0x2c]
1002459b0:     	cmp	w13, #0xdc0
1002459b4:     	b.ne	0x100245a30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x614>
1002459b8:     	and	w9, w9, #0xff
1002459bc:     	orr	w11, w9, w12, lsl #4
1002459c0:     	and	w9, w10, #0xffff
1002459c4:     	lsl	w9, w9, #10
1002459c8:     	add	w12, w9, w11, uxth
1002459cc:     	mov	w9, #0x2400             ; =9216
1002459d0:     	movk	w9, #0xfca0, lsl #16
1002459d4:     	add	w9, w12, w9
1002459d8:     	mov	w10, #0xd800            ; =55296
1002459dc:     	eor	w10, w9, w10
1002459e0:     	mov	w13, #0x800             ; =2048
1002459e4:     	movk	w13, #0xffef, lsl #16
1002459e8:     	add	w10, w10, w13
1002459ec:     	sub	w10, w10, #0x800
1002459f0:     	cmp	w10, w13
1002459f4:     	b.lo	0x1002460d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xcb8>
1002459f8:     	add	x22, x8, #0xc
1002459fc:     	mov	w8, #-0x80              ; =-128
100245a00:     	bfxil	w8, w11, #0, #6
100245a04:     	mov	w10, #-0x80             ; =-128
100245a08:     	bfxil	w10, w9, #6, #6
100245a0c:     	ldr	w11, [sp, #0x4]
100245a10:     	cmp	w12, w11
100245a14:     	b.hs	0x100245a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x660>
100245a18:     	lsr	w9, w9, #12
100245a1c:     	orr	w9, w9, #0xe0
100245a20:     	strb	w9, [sp, #0x2c]
100245a24:     	strb	w10, [sp, #0x2d]
100245a28:     	b	0x100245a50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x634>
100245a2c:     	str	wzr, [sp, #0x2c]
100245a30:     	lsr	w8, w11, #8
100245a34:     	orr	w8, w8, #0xe0
100245a38:     	strb	w8, [sp, #0x2c]
100245a3c:     	mov	w8, #0x80               ; =128
100245a40:     	bfxil	w8, w10, #6, #6
100245a44:     	strb	w8, [sp, #0x2d]
100245a48:     	mov	w8, #0x80               ; =128
100245a4c:     	bfxil	w8, w10, #0, #6
100245a50:     	strb	w8, [sp, #0x2e]
100245a54:     	mov	w23, #0x3               ; =3
100245a58:     	add	x0, x27, x26
100245a5c:     	add	x1, sp, #0x2c
100245a60:     	mov	x2, x23
100245a64:     	bl	0x100b5fc2c <_writev+0x100b5fc2c>
100245a68:     	add	x26, x23, x26
100245a6c:     	mov	x8, x22
100245a70:     	cmp	x22, x19
100245a74:     	b.lo	0x100245528 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
100245a78:     	b	0x100245aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
100245a7c:     	lsr	w11, w9, #18
100245a80:     	orr	w11, w11, #0xf0
100245a84:     	mov	w12, #0x80              ; =128
100245a88:     	strb	w11, [sp, #0x2c]
100245a8c:     	bfxil	w12, w9, #12, #6
100245a90:     	strb	w12, [sp, #0x2d]
100245a94:     	strb	w10, [sp, #0x2e]
100245a98:     	strb	w8, [sp, #0x2f]
100245a9c:     	mov	w23, #0x4               ; =4
100245aa0:     	b	0x100245a58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x63c>
100245aa4:     	mov	x26, #0x0               ; =0
100245aa8:     	str	x22, [x21, #0x70]
100245aac:     	add	x24, x26, x24
100245ab0:     	str	x24, [sp, #0x20]
100245ab4:     	sub	x8, x20, x22
100245ab8:     	cmp	x8, #0x40
100245abc:     	b.hs	0x100245500 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xe4>
100245ac0:     	adds	x8, x22, #0x40
100245ac4:     	csinv	x8, x8, xzr, lo
100245ac8:     	cmp	x8, x20
100245acc:     	csel	x28, x8, x20, lo
100245ad0:     	cmp	x22, x20
100245ad4:     	b.hs	0x10024600c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
100245ad8:     	mov	x8, x22
100245adc:     	ldrb	w19, [x25, x22]
100245ae0:     	add	x22, x22, #0x1
100245ae4:     	str	x22, [x21, #0x70]
100245ae8:     	cmp	w19, #0x5c
100245aec:     	b.eq	0x100245b1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x700>
100245af0:     	cmp	w19, #0x22
100245af4:     	b.eq	0x10024606c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc50>
100245af8:     	cmp	w19, #0x20
100245afc:     	b.lo	0x10024600c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
100245b00:     	ldr	x23, [sp, #0x20]
100245b04:     	ldr	x8, [sp, #0x10]
100245b08:     	cmp	x23, x8
100245b0c:     	b.ne	0x1002454d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbc>
100245b10:     	add	x0, sp, #0x10
100245b14:     	bl	0x100b10028 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100245b18:     	b	0x1002454d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbc>
100245b1c:     	cmp	x22, x20
100245b20:     	b.hs	0x10024600c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
100245b24:     	ldrb	w9, [x25, x22]
100245b28:     	add	x22, x8, #0x2
100245b2c:     	str	x22, [x21, #0x70]
100245b30:     	cmp	w9, #0x65
100245b34:     	b.le	0x100245b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x778>
100245b38:     	cmp	w9, #0x71
100245b3c:     	b.le	0x100245c04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x7e8>
100245b40:     	cmp	w9, #0x72
100245b44:     	b.eq	0x100245ca4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x888>
100245b48:     	cmp	w9, #0x74
100245b4c:     	b.eq	0x100245c38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x81c>
100245b50:     	cmp	w9, #0x75
100245b54:     	b.ne	0x10024600c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
100245b58:     	add	x23, x8, #0x6
100245b5c:     	cmp	x23, x20
100245b60:     	b.hi	0x10024600c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
100245b64:     	cmp	x23, x22
100245b68:     	b.lo	0x1002460a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc88>
100245b6c:     	add	x10, x25, x22
100245b70:     	ldrb	w11, [x10]
100245b74:     	sub	w9, w11, #0x30
100245b78:     	cmp	w9, #0xa
100245b7c:     	b.lo	0x100245d08 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8ec>
100245b80:     	sub	w9, w11, #0x61
100245b84:     	cmp	w9, #0x6
100245b88:     	b.hs	0x100245cf8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8dc>
100245b8c:     	sub	w9, w11, #0x57
100245b90:     	b	0x100245d08 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8ec>
100245b94:     	cmp	w9, #0x5b
100245b98:     	b.gt	0x100245bd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x7b4>
100245b9c:     	cmp	w9, #0x22
100245ba0:     	b.eq	0x100245c5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x840>
100245ba4:     	cmp	w9, #0x2f
100245ba8:     	b.ne	0x10024600c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
100245bac:     	ldr	x19, [sp, #0x20]
100245bb0:     	ldr	x8, [sp, #0x10]
100245bb4:     	cmp	x19, x8
100245bb8:     	b.ne	0x100245bc4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x7a8>
100245bbc:     	add	x0, sp, #0x10
100245bc0:     	bl	0x100b10028 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100245bc4:     	ldr	x8, [sp, #0x18]
100245bc8:     	mov	w9, #0x2f               ; =47
100245bcc:     	b	0x100245ce8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8cc>
100245bd0:     	cmp	w9, #0x5c
100245bd4:     	b.eq	0x100245c80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x864>
100245bd8:     	cmp	w9, #0x62
100245bdc:     	b.ne	0x10024600c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
100245be0:     	ldr	x19, [sp, #0x20]
100245be4:     	ldr	x8, [sp, #0x10]
100245be8:     	cmp	x19, x8
100245bec:     	b.ne	0x100245bf8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x7dc>
100245bf0:     	add	x0, sp, #0x10
100245bf4:     	bl	0x100b10028 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100245bf8:     	ldr	x8, [sp, #0x18]
100245bfc:     	mov	w9, #0x8                ; =8
100245c00:     	b	0x100245ce8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8cc>
100245c04:     	cmp	w9, #0x66
100245c08:     	b.eq	0x100245cc8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8ac>
100245c0c:     	cmp	w9, #0x6e
100245c10:     	b.ne	0x10024600c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
100245c14:     	ldr	x19, [sp, #0x20]
100245c18:     	ldr	x8, [sp, #0x10]
100245c1c:     	cmp	x19, x8
100245c20:     	b.ne	0x100245c2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x810>
100245c24:     	add	x0, sp, #0x10
100245c28:     	bl	0x100b10028 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100245c2c:     	ldr	x8, [sp, #0x18]
100245c30:     	mov	w9, #0xa                ; =10
100245c34:     	b	0x100245ce8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8cc>
100245c38:     	ldr	x19, [sp, #0x20]
100245c3c:     	ldr	x8, [sp, #0x10]
100245c40:     	cmp	x19, x8
100245c44:     	b.ne	0x100245c50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x834>
100245c48:     	add	x0, sp, #0x10
100245c4c:     	bl	0x100b10028 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100245c50:     	ldr	x8, [sp, #0x18]
100245c54:     	mov	w9, #0x9                ; =9
100245c58:     	b	0x100245ce8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8cc>
100245c5c:     	ldr	x19, [sp, #0x20]
100245c60:     	ldr	x8, [sp, #0x10]
100245c64:     	cmp	x19, x8
100245c68:     	b.ne	0x100245c74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x858>
100245c6c:     	add	x0, sp, #0x10
100245c70:     	bl	0x100b10028 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100245c74:     	ldr	x8, [sp, #0x18]
100245c78:     	mov	w9, #0x22               ; =34
100245c7c:     	b	0x100245ce8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8cc>
100245c80:     	ldr	x19, [sp, #0x20]
100245c84:     	ldr	x8, [sp, #0x10]
100245c88:     	cmp	x19, x8
100245c8c:     	b.ne	0x100245c98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x87c>
100245c90:     	add	x0, sp, #0x10
100245c94:     	bl	0x100b10028 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100245c98:     	ldr	x8, [sp, #0x18]
100245c9c:     	mov	w9, #0x5c               ; =92
100245ca0:     	b	0x100245ce8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8cc>
100245ca4:     	ldr	x19, [sp, #0x20]
100245ca8:     	ldr	x8, [sp, #0x10]
100245cac:     	cmp	x19, x8
100245cb0:     	b.ne	0x100245cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8a0>
100245cb4:     	add	x0, sp, #0x10
100245cb8:     	bl	0x100b10028 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100245cbc:     	ldr	x8, [sp, #0x18]
100245cc0:     	mov	w9, #0xd                ; =13
100245cc4:     	b	0x100245ce8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8cc>
100245cc8:     	ldr	x19, [sp, #0x20]
100245ccc:     	ldr	x8, [sp, #0x10]
100245cd0:     	cmp	x19, x8
100245cd4:     	b.ne	0x100245ce0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8c4>
100245cd8:     	add	x0, sp, #0x10
100245cdc:     	bl	0x100b10028 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100245ce0:     	ldr	x8, [sp, #0x18]
100245ce4:     	mov	w9, #0xc                ; =12
100245ce8:     	strb	w9, [x8, x19]
100245cec:     	add	x8, x19, #0x1
100245cf0:     	str	x8, [sp, #0x20]
100245cf4:     	b	0x1002454e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xcc>
100245cf8:     	sub	w9, w11, #0x41
100245cfc:     	cmp	w9, #0x6
100245d00:     	b.hs	0x10024600c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
100245d04:     	sub	w9, w11, #0x37
100245d08:     	ldrb	w12, [x10, #0x1]
100245d0c:     	sub	w11, w12, #0x30
100245d10:     	cmp	w11, #0xa
100245d14:     	b.lo	0x100245d3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x920>
100245d18:     	sub	w11, w12, #0x61
100245d1c:     	cmp	w11, #0x6
100245d20:     	b.hs	0x100245d2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x910>
100245d24:     	sub	w11, w12, #0x57
100245d28:     	b	0x100245d3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x920>
100245d2c:     	sub	w11, w12, #0x41
100245d30:     	cmp	w11, #0x5
100245d34:     	b.hi	0x10024600c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
100245d38:     	sub	w11, w12, #0x37
100245d3c:     	ldrb	w13, [x10, #0x2]
100245d40:     	sub	w12, w13, #0x30
100245d44:     	cmp	w12, #0xa
100245d48:     	b.lo	0x100245d70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x954>
100245d4c:     	sub	w12, w13, #0x61
100245d50:     	cmp	w12, #0x6
100245d54:     	b.hs	0x100245d60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x944>
100245d58:     	sub	w12, w13, #0x57
100245d5c:     	b	0x100245d70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x954>
100245d60:     	sub	w12, w13, #0x41
100245d64:     	cmp	w12, #0x5
100245d68:     	b.hi	0x10024600c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
100245d6c:     	sub	w12, w13, #0x37
100245d70:     	ldrb	w13, [x10, #0x3]
100245d74:     	sub	w10, w13, #0x30
100245d78:     	cmp	w10, #0xa
100245d7c:     	b.lo	0x100245da4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x988>
100245d80:     	sub	w10, w13, #0x61
100245d84:     	cmp	w10, #0x6
100245d88:     	b.hs	0x100245d94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x978>
100245d8c:     	sub	w10, w13, #0x57
100245d90:     	b	0x100245da4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x988>
100245d94:     	sub	w10, w13, #0x41
100245d98:     	cmp	w10, #0x5
100245d9c:     	b.hi	0x10024600c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
100245da0:     	sub	w10, w13, #0x37
100245da4:     	and	w9, w9, #0xff
100245da8:     	and	w11, w11, #0xff
100245dac:     	lsl	w11, w11, #4
100245db0:     	orr	w24, w11, w9, lsl #8
100245db4:     	and	w9, w12, #0xff
100245db8:     	orr	w26, w24, w9
100245dbc:     	lsl	w27, w26, #4
100245dc0:     	and	w9, w10, #0xff
100245dc4:     	orr	w19, w27, w9
100245dc8:     	str	x23, [x21, #0x70]
100245dcc:     	cmp	w24, #0xd80
100245dd0:     	b.lo	0x100245ea0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xa84>
100245dd4:     	cmp	w26, #0xdbf
100245dd8:     	b.hi	0x100245ea0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xa84>
100245ddc:     	add	x22, x8, #0xc
100245de0:     	cmp	x22, x20
100245de4:     	b.hi	0x100245ea0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xa84>
100245de8:     	cmp	x23, x20
100245dec:     	b.hs	0x100246130 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xd14>
100245df0:     	ldrb	w9, [x25, x23]
100245df4:     	cmp	w9, #0x5c
100245df8:     	b.ne	0x100245ea0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xa84>
100245dfc:     	add	x0, x8, #0x7
100245e00:     	cmp	x0, x20
100245e04:     	b.hs	0x100246144 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xd28>
100245e08:     	ldrb	w9, [x25, x0]
100245e0c:     	cmp	w9, #0x75
100245e10:     	b.ne	0x100245ea0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xa84>
100245e14:     	add	x0, x8, #0x8
100245e18:     	cmp	x22, x0
100245e1c:     	b.lo	0x1002460e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xcc4>
100245e20:     	add	x0, x25, x0
100245e24:     	bl	0x1004fa278 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser14decode_hex_u16>
100245e28:     	ubfx	w8, w1, #10, #6
100245e2c:     	cmp	w8, #0x37
100245e30:     	cset	w8, eq
100245e34:     	and	w8, w0, w8
100245e38:     	tbz	w8, #0x0, 0x100245ea0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xa84>
100245e3c:     	str	x22, [x21, #0x70]
100245e40:     	and	w8, w19, #0xffff
100245e44:     	lsl	w8, w8, #10
100245e48:     	add	w8, w8, w1, uxth
100245e4c:     	mov	w9, #0x2400             ; =9216
100245e50:     	movk	w9, #0xfca0, lsl #16
100245e54:     	add	w0, w8, w9
100245e58:     	mov	w8, #0xd800             ; =55296
100245e5c:     	eor	w8, w0, w8
100245e60:     	mov	w9, #0x800              ; =2048
100245e64:     	movk	w9, #0xffef, lsl #16
100245e68:     	add	w8, w8, w9
100245e6c:     	sub	w8, w8, #0x800
100245e70:     	cmp	w8, w9
100245e74:     	b.lo	0x1002460f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xcd8>
100245e78:     	str	wzr, [sp, #0x2c]
100245e7c:     	add	x1, sp, #0x2c
100245e80:     	bl	0x100688a50 <__RNvNtNtCsjgY6bXVaRmE_4core4char7methods15encode_utf8_raw>
100245e84:     	mov	x2, x0
100245e88:     	mov	x3, x1
100245e8c:     	add	x0, sp, #0x10
100245e90:     	mov	x1, x2
100245e94:     	mov	x2, x3
100245e98:     	bl	0x100282c50 <__RNvMs_NtCsctvjasLqLe9_5alloc3vecINtB4_3VechE15append_elementsCs3gRpqoBkMHm_13perry_runtime>
100245e9c:     	b	0x1002454e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xcc>
100245ea0:     	and	w8, w24, #0xf80
100245ea4:     	cmp	w8, #0xd80
100245ea8:     	b.ne	0x100245f30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xb14>
100245eac:     	ldr	x22, [sp, #0x20]
100245eb0:     	ldr	x8, [sp, #0x10]
100245eb4:     	cmp	x22, x8
100245eb8:     	b.ne	0x100245ec4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xaa8>
100245ebc:     	add	x0, sp, #0x10
100245ec0:     	bl	0x100b10028 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100245ec4:     	ldr	x8, [sp, #0x18]
100245ec8:     	mov	w9, #0xed               ; =237
100245ecc:     	strb	w9, [x8, x22]
100245ed0:     	add	x24, x22, #0x1
100245ed4:     	str	x24, [sp, #0x20]
100245ed8:     	ldr	x8, [sp, #0x10]
100245edc:     	cmp	x24, x8
100245ee0:     	b.ne	0x100245eec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xad0>
100245ee4:     	add	x0, sp, #0x10
100245ee8:     	bl	0x100b10028 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100245eec:     	mov	w8, #-0x80              ; =-128
100245ef0:     	bfxil	w8, w19, #6, #6
100245ef4:     	ldr	x9, [sp, #0x18]
100245ef8:     	strb	w8, [x9, x24]
100245efc:     	add	x24, x22, #0x2
100245f00:     	str	x24, [sp, #0x20]
100245f04:     	ldr	x8, [sp, #0x10]
100245f08:     	cmp	x24, x8
100245f0c:     	b.ne	0x100245f18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xafc>
100245f10:     	add	x0, sp, #0x10
100245f14:     	bl	0x100b10028 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100245f18:     	mov	w8, #-0x80              ; =-128
100245f1c:     	bfxil	w8, w19, #0, #6
100245f20:     	ldr	x9, [sp, #0x18]
100245f24:     	strb	w8, [x9, x24]
100245f28:     	add	x8, x22, #0x3
100245f2c:     	b	0x100245fdc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbc0>
100245f30:     	and	w8, w27, #0xffff
100245f34:     	mov	w9, #0xd800             ; =55296
100245f38:     	movk	w9, #0xffef, lsl #16
100245f3c:     	eor	w8, w8, w9
100245f40:     	mov	w9, #0x800              ; =2048
100245f44:     	movk	w9, #0xffef, lsl #16
100245f48:     	cmp	w8, w9
100245f4c:     	b.lo	0x1002460bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xca0>
100245f50:     	str	wzr, [sp, #0x2c]
100245f54:     	cmp	w26, #0x8
100245f58:     	b.hs	0x100245f68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xb4c>
100245f5c:     	strb	w19, [sp, #0x2c]
100245f60:     	mov	w22, #0x1               ; =1
100245f64:     	b	0x100245fb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xb94>
100245f68:     	mov	w8, #-0x80              ; =-128
100245f6c:     	bfxil	w8, w19, #0, #6
100245f70:     	cmp	w24, #0x80
100245f74:     	b.hs	0x100245f90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xb74>
100245f78:     	lsr	w9, w19, #6
100245f7c:     	orr	w9, w9, #0xc0
100245f80:     	strb	w9, [sp, #0x2c]
100245f84:     	strb	w8, [sp, #0x2d]
100245f88:     	mov	w22, #0x2               ; =2
100245f8c:     	b	0x100245fb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xb94>
100245f90:     	lsr	w9, w24, #8
100245f94:     	mov	w10, #0x80              ; =128
100245f98:     	orr	w9, w9, #0xe0
100245f9c:     	strb	w9, [sp, #0x2c]
100245fa0:     	bfxil	w10, w19, #6, #6
100245fa4:     	strb	w10, [sp, #0x2d]
100245fa8:     	strb	w8, [sp, #0x2e]
100245fac:     	mov	w22, #0x3               ; =3
100245fb0:     	ldr	x24, [sp, #0x20]
100245fb4:     	ldr	x8, [sp, #0x10]
100245fb8:     	sub	x8, x8, x24
100245fbc:     	cmp	x22, x8
100245fc0:     	b.hi	0x100245fe8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbcc>
100245fc4:     	ldr	x8, [sp, #0x18]
100245fc8:     	add	x0, x8, x24
100245fcc:     	add	x1, sp, #0x2c
100245fd0:     	mov	x2, x22
100245fd4:     	bl	0x100b5fc2c <_writev+0x100b5fc2c>
100245fd8:     	add	x8, x24, x22
100245fdc:     	str	x8, [sp, #0x20]
100245fe0:     	mov	x22, x23
100245fe4:     	b	0x1002454e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xcc>
100245fe8:     	add	x0, sp, #0x10
100245fec:     	mov	x1, x24
100245ff0:     	mov	x2, x22
100245ff4:     	mov	w3, #0x1                ; =1
100245ff8:     	mov	w4, #0x1                ; =1
100245ffc:     	bl	0x100b37250 <__RINvNvMs2_NtCsctvjasLqLe9_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs3gRpqoBkMHm_13perry_runtime>
100246000:     	ldr	x24, [sp, #0x20]
100246004:     	b	0x100245fc4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xba8>
100246008:     	str	x22, [x21, #0x70]
10024600c:     	strb	wzr, [x21, #0xd4]
100246010:     	mov	x8, #-0x2               ; =-2
100246014:     	ldr	x9, [sp, #0x8]
100246018:     	str	x8, [x9]
10024601c:     	ldr	x8, [sp, #0x10]
100246020:     	cbz	x8, 0x10024604c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc30>
100246024:     	ldr	x0, [sp, #0x18]
100246028:     	bl	0x100b5cd80 <_mi_free>
10024602c:     	b	0x10024604c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc30>
100246030:     	str	x22, [x21, #0x70]
100246034:     	add	x8, x26, x24
100246038:     	str	x8, [sp, #0x20]
10024603c:     	ldr	q0, [sp, #0x10]
100246040:     	ldr	x9, [sp, #0x8]
100246044:     	str	q0, [x9]
100246048:     	str	x8, [x9, #0x10]
10024604c:     	ldp	x29, x30, [sp, #0x80]
100246050:     	ldp	x20, x19, [sp, #0x70]
100246054:     	ldp	x22, x21, [sp, #0x60]
100246058:     	ldp	x24, x23, [sp, #0x50]
10024605c:     	ldp	x26, x25, [sp, #0x40]
100246060:     	ldp	x28, x27, [sp, #0x30]
100246064:     	add	sp, sp, #0x90
100246068:     	ret
10024606c:     	ldr	q0, [sp, #0x10]
100246070:     	ldr	x9, [sp, #0x8]
100246074:     	str	q0, [x9]
100246078:     	ldr	x8, [sp, #0x20]
10024607c:     	b	0x100246048 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc2c>
100246080:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246084:     	add	x3, x3, #0x7a0
100246088:     	mov	x0, x2
10024608c:     	mov	x1, x22
100246090:     	mov	x2, x20
100246094:     	bl	0x100b1080c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100246098:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
10024609c:     	add	x0, x0, #0x348
1002460a0:     	bl	0x100b105b0 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
1002460a4:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002460a8:     	add	x3, x3, #0x788
1002460ac:     	mov	x0, x22
1002460b0:     	mov	x1, x23
1002460b4:     	mov	x2, x20
1002460b8:     	bl	0x100b1080c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1002460bc:     	adrp	x0, 0x100c73000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x711c>
1002460c0:     	add	x0, x0, #0x355
1002460c4:     	adrp	x2, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1002460c8:     	add	x2, x2, #0x258
1002460cc:     	mov	w1, #0x2d               ; =45
1002460d0:     	bl	0x100b10580 <__RNvNtCsjgY6bXVaRmE_4core6option13expect_failed>
1002460d4:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002460d8:     	add	x0, x0, #0x330
1002460dc:     	bl	0x100b105b0 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
1002460e0:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002460e4:     	add	x3, x3, #0x770
1002460e8:     	mov	x1, x22
1002460ec:     	mov	x2, x20
1002460f0:     	bl	0x100b1080c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1002460f4:     	adrp	x0, 0x100c44000 <_PERRY_EMPTY_STRING+0x4cb4>
1002460f8:     	add	x0, x0, #0x278
1002460fc:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246100:     	add	x2, x2, #0x758
100246104:     	mov	w1, #0x22               ; =34
100246108:     	bl	0x100b10580 <__RNvNtCsjgY6bXVaRmE_4core6option13expect_failed>
10024610c:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246110:     	add	x2, x2, #0x300
100246114:     	mov	x0, x22
100246118:     	mov	x1, x20
10024611c:     	bl	0x100b1064c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100246120:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246124:     	add	x2, x2, #0x318
100246128:     	mov	x1, x20
10024612c:     	bl	0x100b1064c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100246130:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246134:     	add	x2, x2, #0x728
100246138:     	mov	x0, x23
10024613c:     	mov	x1, x20
100246140:     	bl	0x100b1064c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100246144:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246148:     	add	x2, x2, #0x740
10024614c:     	mov	x1, x20
100246150:     	bl	0x100b1064c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
