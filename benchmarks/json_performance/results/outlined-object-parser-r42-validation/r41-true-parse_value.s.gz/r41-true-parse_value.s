
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010024820c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_>:
10024820c:     	stp	x28, x27, [sp, #-0x60]!
100248210:     	stp	x26, x25, [sp, #0x10]
100248214:     	stp	x24, x23, [sp, #0x20]
100248218:     	stp	x22, x21, [sp, #0x30]
10024821c:     	stp	x20, x19, [sp, #0x40]
100248220:     	stp	x29, x30, [sp, #0x50]
100248224:     	add	x29, sp, #0x50
100248228:     	sub	sp, sp, #0x240
10024822c:     	ldp	x2, x19, [x0, #0x68]
100248230:     	cmp	x19, x2
100248234:     	b.hs	0x10024826c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x60>
100248238:     	ldr	x8, [x0, #0x60]
10024823c:     	mov	x9, #0x2600             ; =9728
100248240:     	movk	x9, #0x1, lsl #32
100248244:     	ldrb	w10, [x8, x19]
100248248:     	cmp	w10, #0x20
10024824c:     	b.hi	0x10024826c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x60>
100248250:     	lsr	x10, x9, x10
100248254:     	tbz	w10, #0x0, 0x10024826c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x60>
100248258:     	add	x19, x19, #0x1
10024825c:     	str	x19, [x0, #0x70]
100248260:     	cmp	x2, x19
100248264:     	b.ne	0x100248244 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x38>
100248268:     	b	0x1002499d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
10024826c:     	cmp	x19, x2
100248270:     	b.hs	0x1002499d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100248274:     	ldr	x12, [x0, #0x60]
100248278:     	add	x9, x12, x19
10024827c:     	ldrb	w8, [x9]
100248280:     	cmp	w8, #0x65
100248284:     	b.le	0x1002482d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xcc>
100248288:     	cmp	w8, #0x73
10024828c:     	b.gt	0x1002483d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1c8>
100248290:     	cmp	w8, #0x66
100248294:     	b.eq	0x100248494 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x288>
100248298:     	cmp	w8, #0x6e
10024829c:     	b.ne	0x10024847c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x270>
1002482a0:     	add	x1, x19, #0x4
1002482a4:     	cmp	x1, x2
1002482a8:     	b.hi	0x1002499d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
1002482ac:     	cmn	x19, #0x5
1002482b0:     	b.hi	0x100249c18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a0c>
1002482b4:     	ldr	w8, [x9]
1002482b8:     	mov	w9, #0x756e             ; =30062
1002482bc:     	movk	w9, #0x6c6c, lsl #16
1002482c0:     	cmp	w8, w9
1002482c4:     	b.ne	0x1002499d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
1002482c8:     	mov	x19, #0x2               ; =2
1002482cc:     	movk	x19, #0x7ffc, lsl #48
1002482d0:     	str	x1, [x0, #0x70]
1002482d4:     	b	0x1002499dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
1002482d8:     	cmp	w8, #0x22
1002482dc:     	b.eq	0x100248450 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x244>
1002482e0:     	cmp	w8, #0x2d
1002482e4:     	b.eq	0x100248518 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x30c>
1002482e8:     	cmp	w8, #0x5b
1002482ec:     	b.ne	0x10024847c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x270>
1002482f0:     	add	x8, x19, #0x1
1002482f4:     	str	x8, [x0, #0x70]
1002482f8:     	cmp	x8, x2
1002482fc:     	b.hs	0x10024832c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x120>
100248300:     	mov	x9, #0x2600             ; =9728
100248304:     	movk	x9, #0x1, lsl #32
100248308:     	ldrb	w10, [x12, x8]
10024830c:     	cmp	w10, #0x20
100248310:     	b.hi	0x10024832c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x120>
100248314:     	lsr	x10, x9, x10
100248318:     	tbz	w10, #0x0, 0x10024832c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x120>
10024831c:     	add	x8, x8, #0x1
100248320:     	str	x8, [x0, #0x70]
100248324:     	cmp	x2, x8
100248328:     	b.ne	0x100248308 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xfc>
10024832c:     	mov	x20, x0
100248330:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100248334:     	add	x0, x0, #0xce8
100248338:     	ldr	x8, [x0]
10024833c:     	blr	x8
100248340:     	mov	x19, x0
100248344:     	ldrb	w8, [x0, #0x20]
100248348:     	cbnz	w8, 0x100249b90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1984>
10024834c:     	ldr	x8, [x19]
100248350:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100248354:     	cmp	x8, x9
100248358:     	b.hs	0x100249bec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19e0>
10024835c:     	mov	x0, x20
100248360:     	ldr	x1, [x19, #0x18]
100248364:     	ldp	x8, x9, [x20, #0x68]
100248368:     	subs	x8, x8, x9
10024836c:     	b.ls	0x100248580 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x374>
100248370:     	ldr	x10, [x0, #0x60]
100248374:     	ldrb	w9, [x10, x9]
100248378:     	cmp	w9, #0x7b
10024837c:     	b.ne	0x100248580 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x374>
100248380:     	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
100248384:     	movk	x9, #0xaaab
100248388:     	umulh	x8, x8, x9
10024838c:     	lsr	x8, x8, #6
100248390:     	mov	w9, #0x10               ; =16
100248394:     	cmp	x8, #0x10
100248398:     	csel	x8, x8, x9, hi
10024839c:     	mov	w9, #0x4000             ; =16384
1002483a0:     	cmp	x8, #0x4, lsl #12       ; =0x4000
1002483a4:     	csel	x2, x8, x9, lo
1002483a8:     	mov	x19, x0
1002483ac:     	add	x0, sp, #0x188
1002483b0:     	mov	x20, x1
1002483b4:     	add	x1, x19, #0x20
1002483b8:     	bl	0x1002359d0 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray3new>
1002483bc:     	add	x1, sp, #0x188
1002483c0:     	mov	x0, x19
1002483c4:     	mov	x2, x20
1002483c8:     	bl	0x100249d8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E16parse_array_tailB9_>
1002483cc:     	mov	x19, x0
1002483d0:     	b	0x1002499dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
1002483d4:     	cmp	w8, #0x74
1002483d8:     	b.eq	0x1002484dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x2d0>
1002483dc:     	cmp	w8, #0x7b
1002483e0:     	b.ne	0x10024847c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x270>
1002483e4:     	add	x8, x19, #0x1
1002483e8:     	str	x8, [x0, #0x70]
1002483ec:     	cmp	x8, x2
1002483f0:     	b.hs	0x100248420 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x214>
1002483f4:     	mov	x9, #0x2600             ; =9728
1002483f8:     	movk	x9, #0x1, lsl #32
1002483fc:     	ldrb	w10, [x12, x8]
100248400:     	cmp	w10, #0x20
100248404:     	b.hi	0x100248420 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x214>
100248408:     	lsr	x10, x9, x10
10024840c:     	tbz	w10, #0x0, 0x100248420 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x214>
100248410:     	add	x8, x8, #0x1
100248414:     	str	x8, [x0, #0x70]
100248418:     	cmp	x2, x8
10024841c:     	b.ne	0x1002483fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1f0>
100248420:     	ldrb	w8, [x0, #0xd5]
100248424:     	tbz	w8, #0x0, 0x1002485cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x3c0>
100248428:     	strb	wzr, [x0, #0xd5]
10024842c:     	ldr	x22, [x0, #0x78]
100248430:     	ldp	q0, q1, [x0, #0x80]
100248434:     	stur	q0, [sp, #0xa8]
100248438:     	stur	q1, [sp, #0xb8]
10024843c:     	ldp	q0, q1, [x0, #0xa0]
100248440:     	stur	q0, [sp, #0xc8]
100248444:     	stur	q1, [sp, #0xd8]
100248448:     	ldr	x9, [x0, #0xc0]
10024844c:     	b	0x100248774 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x568>
100248450:     	ldr	x8, [x0]
100248454:     	cmp	x8, #0x1
100248458:     	b.ne	0x1002485a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x394>
10024845c:     	ldr	x8, [x0, #0x8]
100248460:     	cmp	x8, x19
100248464:     	b.ne	0x1002485a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x394>
100248468:     	ldp	x9, x8, [x0, #0x10]
10024846c:     	str	x9, [x0, #0x70]
100248470:     	mov	x19, #0x7fff000000000000 ; =9223090561878065152
100248474:     	bfxil	x19, x8, #0, #48
100248478:     	b	0x1002499dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
10024847c:     	sub	w8, w8, #0x30
100248480:     	cmp	w8, #0x9
100248484:     	b.hi	0x1002499d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100248488:     	mov	w13, #0x0               ; =0
10024848c:     	mov	x10, x19
100248490:     	b	0x100248524 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x318>
100248494:     	add	x1, x19, #0x5
100248498:     	cmp	x1, x2
10024849c:     	b.hi	0x1002499d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
1002484a0:     	cmn	x19, #0x6
1002484a4:     	b.hi	0x100249bf8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19ec>
1002484a8:     	ldrb	w8, [x9, #0x4]
1002484ac:     	ldr	w9, [x9]
1002484b0:     	orr	x8, x9, x8, lsl #32
1002484b4:     	mov	x9, #0x6166             ; =24934
1002484b8:     	movk	x9, #0x736c, lsl #16
1002484bc:     	movk	x9, #0x65, lsl #32
1002484c0:     	cmp	x8, x9
1002484c4:     	b.ne	0x1002499d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
1002484c8:     	str	x1, [x0, #0x70]
1002484cc:     	mov	x8, #0x2                ; =2
1002484d0:     	movk	x8, #0x7ffc, lsl #48
1002484d4:     	orr	x19, x8, #0x1
1002484d8:     	b	0x1002499dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
1002484dc:     	add	x1, x19, #0x4
1002484e0:     	cmp	x1, x2
1002484e4:     	b.hi	0x1002499d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
1002484e8:     	cmn	x19, #0x5
1002484ec:     	b.hi	0x100249c08 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19fc>
1002484f0:     	ldr	w8, [x9]
1002484f4:     	mov	w9, #0x7274             ; =29300
1002484f8:     	movk	w9, #0x6575, lsl #16
1002484fc:     	cmp	w8, w9
100248500:     	b.ne	0x1002499d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100248504:     	str	x1, [x0, #0x70]
100248508:     	mov	x8, #0x2                ; =2
10024850c:     	movk	x8, #0x7ffc, lsl #48
100248510:     	add	x19, x8, #0x2
100248514:     	b	0x1002499dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
100248518:     	add	x10, x19, #0x1
10024851c:     	str	x10, [x0, #0x70]
100248520:     	mov	w13, #0x1               ; =1
100248524:     	cmp	x10, x2
100248528:     	b.hs	0x1002499d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
10024852c:     	add	x14, x12, x10
100248530:     	ldrb	w8, [x14]
100248534:     	cmp	w8, #0x30
100248538:     	b.ne	0x1002485f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x3e4>
10024853c:     	add	x1, x10, #0x1
100248540:     	str	x1, [x0, #0x70]
100248544:     	cmp	x1, x2
100248548:     	b.hs	0x100248628 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x41c>
10024854c:     	ldrb	w8, [x12, x1]
100248550:     	sub	w8, w8, #0x30
100248554:     	cmp	w8, #0x9
100248558:     	b.hi	0x100248628 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x41c>
10024855c:     	ldrb	w8, [x12, x1]
100248560:     	sub	w8, w8, #0x30
100248564:     	cmp	w8, #0xa
100248568:     	b.hs	0x1002499d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
10024856c:     	add	x1, x1, #0x1
100248570:     	str	x1, [x0, #0x70]
100248574:     	cmp	x2, x1
100248578:     	b.ne	0x10024855c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x350>
10024857c:     	b	0x1002499d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100248580:     	add	sp, sp, #0x240
100248584:     	ldp	x29, x30, [sp, #0x50]
100248588:     	ldp	x20, x19, [sp, #0x40]
10024858c:     	ldp	x22, x21, [sp, #0x30]
100248590:     	ldp	x24, x23, [sp, #0x20]
100248594:     	ldp	x26, x25, [sp, #0x10]
100248598:     	ldp	x28, x27, [sp], #0x60
10024859c:     	b	0x10024a20c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E18parse_array_prefixB9_>
1002485a0:     	mov	x1, x0
1002485a4:     	add	x0, sp, #0x188
1002485a8:     	mov	x24, x1
1002485ac:     	bl	0x1002458b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_bytesB9_>
1002485b0:     	ldr	x22, [sp, #0x188]
1002485b4:     	cmn	x22, #0x2
1002485b8:     	b.ne	0x1002486a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x498>
1002485bc:     	mov	x19, #0x2               ; =2
1002485c0:     	movk	x19, #0x7ffc, lsl #48
1002485c4:     	strb	wzr, [x24, #0xd4]
1002485c8:     	b	0x1002499dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
1002485cc:     	ldr	x22, [x0, #0x78]
1002485d0:     	ldr	x9, [x0, #0xc0]
1002485d4:     	cmp	x22, #0x0
1002485d8:     	ccmp	x9, #0x0, #0x4, ne
1002485dc:     	b.ne	0x10024875c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x550>
1002485e0:     	mov	x21, x0
1002485e4:     	mov	x8, #0x0                ; =0
1002485e8:     	mov	w27, #0x0               ; =0
1002485ec:     	b	0x100248794 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x588>
1002485f0:     	sub	w8, w8, #0x31
1002485f4:     	cmp	w8, #0x8
1002485f8:     	b.hi	0x1002499d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
1002485fc:     	mov	x1, x10
100248600:     	ldrb	w8, [x12, x1]
100248604:     	sub	w8, w8, #0x30
100248608:     	cmp	w8, #0x9
10024860c:     	b.hi	0x100248628 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x41c>
100248610:     	add	x1, x1, #0x1
100248614:     	str	x1, [x0, #0x70]
100248618:     	cmp	x2, x1
10024861c:     	b.ne	0x100248600 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x3f4>
100248620:     	mov	x1, x2
100248624:     	b	0x100248650 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x444>
100248628:     	subs	x8, x1, x2
10024862c:     	b.hs	0x100248650 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x444>
100248630:     	ldrb	w11, [x12, x1]
100248634:     	cmp	w11, #0x2e
100248638:     	b.eq	0x1002495b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x13a4>
10024863c:     	cmp	w11, #0x45
100248640:     	b.eq	0x100249418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x120c>
100248644:     	mov	x8, x1
100248648:     	cmp	w11, #0x65
10024864c:     	b.eq	0x10024941c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
100248650:     	subs	x8, x1, x10
100248654:     	ccmp	x8, #0x13, #0x2, ne
100248658:     	b.hs	0x100249418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x120c>
10024865c:     	cmp	x1, x10
100248660:     	b.lo	0x100249c84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a78>
100248664:     	cmp	x1, x2
100248668:     	b.hi	0x100249c84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a78>
10024866c:     	mov	x9, #0x0                ; =0
100248670:     	mov	w10, #0xa               ; =10
100248674:     	ldrb	w11, [x14], #0x1
100248678:     	mul	x9, x9, x10
10024867c:     	sub	w11, w11, #0x30
100248680:     	add	x9, x9, w11, uxtb
100248684:     	subs	x8, x8, #0x1
100248688:     	b.ne	0x100248674 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x468>
10024868c:     	ucvtf	d0, x9
100248690:     	fneg	d1, d0
100248694:     	cmp	w13, #0x0
100248698:     	fcsel	d0, d1, d0, ne
10024869c:     	fmov	x19, d0
1002486a0:     	b	0x1002499dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
1002486a4:     	ldp	x21, x20, [sp, #0x190]
1002486a8:     	cmp	x20, #0x6
1002486ac:     	b.hs	0x10024873c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x530>
1002486b0:     	subs	x8, x20, #0x3
1002486b4:     	b.lo	0x100249540 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1334>
1002486b8:     	ldrb	w9, [x21]
1002486bc:     	cmp	w9, #0xed
1002486c0:     	b.ne	0x1002486e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4d4>
1002486c4:     	ldrb	w9, [x21, #0x1]
1002486c8:     	and	w9, w9, #0xe0
1002486cc:     	cmp	w9, #0xa0
1002486d0:     	b.ne	0x1002486e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4d4>
1002486d4:     	ldrsb	w9, [x21, #0x2]
1002486d8:     	cmn	w9, #0x40
1002486dc:     	b.lt	0x10024873c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x530>
1002486e0:     	cbz	x8, 0x100249540 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1334>
1002486e4:     	ldrb	w9, [x21, #0x1]
1002486e8:     	cmp	w9, #0xed
1002486ec:     	b.ne	0x10024870c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x500>
1002486f0:     	ldrb	w9, [x21, #0x2]
1002486f4:     	and	w9, w9, #0xe0
1002486f8:     	cmp	w9, #0xa0
1002486fc:     	b.ne	0x10024870c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x500>
100248700:     	ldrsb	w9, [x21, #0x3]
100248704:     	cmn	w9, #0x40
100248708:     	b.lt	0x10024873c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x530>
10024870c:     	cmp	x8, #0x1
100248710:     	b.eq	0x100249540 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1334>
100248714:     	ldrb	w8, [x21, #0x2]
100248718:     	cmp	w8, #0xed
10024871c:     	b.ne	0x100249540 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1334>
100248720:     	ldrb	w8, [x21, #0x3]
100248724:     	and	w8, w8, #0xe0
100248728:     	cmp	w8, #0xa0
10024872c:     	b.ne	0x100249540 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1334>
100248730:     	ldrsb	w8, [x21, #0x4]
100248734:     	cmn	w8, #0x40
100248738:     	b.ge	0x100249540 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1334>
10024873c:     	cmn	x22, #0x1
100248740:     	b.eq	0x10024956c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1360>
100248744:     	mov	x0, x21
100248748:     	mov	x1, x20
10024874c:     	bl	0x10034e1b0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
100248750:     	mov	x19, #0x7fff000000000000 ; =9223090561878065152
100248754:     	bfxil	x19, x0, #0, #48
100248758:     	b	0x1002496c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x14b4>
10024875c:     	ldp	q0, q1, [x0, #0x80]
100248760:     	stur	q0, [sp, #0xa8]
100248764:     	stur	q1, [sp, #0xb8]
100248768:     	ldp	q0, q1, [x0, #0xa0]
10024876c:     	stur	q0, [sp, #0xc8]
100248770:     	stur	q1, [sp, #0xd8]
100248774:     	mov	x21, x0
100248778:     	ldr	w8, [x0, #0xd0]
10024877c:     	stp	x22, x9, [sp, #0xe8]
100248780:     	str	x9, [sp, #0x90]
100248784:     	str	w8, [sp, #0x7c]
100248788:     	str	w8, [sp, #0xf8]
10024878c:     	mov	w8, #0x1                ; =1
100248790:     	mov	w27, #0x1               ; =1
100248794:     	str	x8, [sp, #0xa0]
100248798:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10024879c:     	add	x0, x0, #0xce8
1002487a0:     	ldr	x8, [x0]
1002487a4:     	blr	x8
1002487a8:     	mov	x19, x0
1002487ac:     	ldrb	w8, [x0, #0x20]
1002487b0:     	cbnz	w8, 0x100249bc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19b4>
1002487b4:     	ldr	x8, [x19]
1002487b8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1002487bc:     	cmp	x8, x9
1002487c0:     	b.hs	0x100249bec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19e0>
1002487c4:     	ldr	x23, [x19, #0x18]
1002487c8:     	ldp	x24, x28, [x21, #0x68]
1002487cc:     	cmp	x28, x24
1002487d0:     	b.hs	0x100248804 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x5f8>
1002487d4:     	ldr	x8, [x21, #0x60]
1002487d8:     	ldrb	w8, [x8, x28]
1002487dc:     	cmp	w8, #0x7d
1002487e0:     	b.ne	0x100248804 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x5f8>
1002487e4:     	add	x8, x28, #0x1
1002487e8:     	str	x8, [x21, #0x70]
1002487ec:     	ldr	x8, [x21, #0x78]
1002487f0:     	cbnz	x8, 0x1002494e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x12d8>
1002487f4:     	ldr	x1, [x21, #0xc0]
1002487f8:     	cbz	x1, 0x1002494e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x12d8>
1002487fc:     	ldr	w2, [x21, #0xd0]
100248800:     	b	0x100249504 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x12f8>
100248804:     	movi.2d	v0, #0000000000000000
100248808:     	stp	q0, q0, [sp, #0x120]
10024880c:     	stp	q0, q0, [sp, #0x100]
100248810:     	adrp	x1, 0x100ca1000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6fb0>
100248814:     	add	x1, x1, #0xb40
100248818:     	add	x0, sp, #0x148
10024881c:     	mov	w2, #0x40               ; =64
100248820:     	bl	0x100b66c10 <_writev+0x100b66c10>
100248824:     	mov	x8, x21
100248828:     	mov	x12, #0x0               ; =0
10024882c:     	str	xzr, [sp, #0x98]
100248830:     	mov	x9, #-0x1               ; =-1
100248834:     	str	x9, [sp, #0x188]
100248838:     	add	x9, sp, #0xa0
10024883c:     	add	x9, x9, #0x8
100248840:     	stp	x9, xzr, [sp, #0x68]
100248844:     	mov	x25, #0x2600            ; =9728
100248848:     	movk	x25, #0x1, lsl #32
10024884c:     	adrp	x9, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4fb0>
100248850:     	ldr	q0, [x9, #0x8d0]
100248854:     	str	q0, [sp, #0x50]
100248858:     	adrp	x9, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4fb0>
10024885c:     	ldr	q0, [x9, #0x8e0]
100248860:     	str	q0, [sp, #0x40]
100248864:     	mov	x26, x27
100248868:     	mov	x9, x27
10024886c:     	str	w27, [sp, #0x88]
100248870:     	str	x22, [sp, #0x80]
100248874:     	str	w9, [sp, #0x8c]
100248878:     	cmp	x28, x24
10024887c:     	b.hs	0x1002488ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6a0>
100248880:     	ldr	x9, [x8, #0x60]
100248884:     	ldrb	w10, [x9, x28]
100248888:     	cmp	w10, #0x20
10024888c:     	b.hi	0x1002488ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6a0>
100248890:     	lsr	x10, x25, x10
100248894:     	tbz	w10, #0x0, 0x1002488ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6a0>
100248898:     	add	x28, x28, #0x1
10024889c:     	str	x28, [x8, #0x70]
1002488a0:     	cmp	x24, x28
1002488a4:     	b.ne	0x100248884 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x678>
1002488a8:     	mov	x28, x24
1002488ac:     	cbz	w27, 0x100248970 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x764>
1002488b0:     	cmp	x12, x22
1002488b4:     	cset	w9, lo
1002488b8:     	tst	w26, w9
1002488bc:     	b.eq	0x100248970 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x764>
1002488c0:     	mov	x20, x26
1002488c4:     	mov	x26, x12
1002488c8:     	cmp	x12, #0x8
1002488cc:     	b.hs	0x100249d20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b14>
1002488d0:     	cmp	x28, x24
1002488d4:     	b.hs	0x100248984 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
1002488d8:     	ldr	x8, [sp, #0x68]
1002488dc:     	ldr	x9, [x8, x26, lsl #3]
1002488e0:     	cbz	x9, 0x100248984 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
1002488e4:     	ldr	x10, [x21, #0x60]
1002488e8:     	ldrb	w8, [x10, x28]
1002488ec:     	cmp	w8, #0x22
1002488f0:     	b.ne	0x100248984 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
1002488f4:     	add	x11, x28, #0x1
1002488f8:     	ldr	w14, [x9, #0x4]
1002488fc:     	add	x8, x11, x14
100248900:     	cmp	x8, x24
100248904:     	ccmp	x8, x28, #0x0, lo
100248908:     	b.ls	0x100248984 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
10024890c:     	ldrb	w12, [x10, x8]
100248910:     	cmp	w12, #0x22
100248914:     	b.ne	0x100248984 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
100248918:     	add	x1, x10, x11
10024891c:     	cbz	w14, 0x100248958 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x74c>
100248920:     	add	x9, x9, #0x14
100248924:     	mov	x10, x14
100248928:     	mov	x11, x1
10024892c:     	ldrb	w12, [x11], #0x1
100248930:     	cmp	w12, #0x5c
100248934:     	b.eq	0x100248984 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
100248938:     	cmp	w12, #0x22
10024893c:     	b.eq	0x100248984 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
100248940:     	ldrb	w13, [x9], #0x1
100248944:     	cmp	w12, #0x20
100248948:     	ccmp	w12, w13, #0x0, hs
10024894c:     	b.ne	0x100248984 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
100248950:     	subs	x10, x10, #0x1
100248954:     	b.ne	0x10024892c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x720>
100248958:     	add	x9, x8, #0x1
10024895c:     	mov	x8, x21
100248960:     	str	x9, [x21, #0x70]
100248964:     	mov	w24, #0x1               ; =1
100248968:     	mov	x27, #-0x1              ; =-1
10024896c:     	b	0x1002489a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x79c>
100248970:     	mov	x20, x26
100248974:     	mov	x26, x12
100248978:     	mov	x1, x8
10024897c:     	sub	x0, x29, #0x80
100248980:     	b	0x10024898c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x780>
100248984:     	sub	x0, x29, #0x80
100248988:     	mov	x1, x21
10024898c:     	bl	0x1002458b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_bytesB9_>
100248990:     	ldur	x27, [x29, #-0x80]
100248994:     	cmn	x27, #0x2
100248998:     	b.eq	0x100249714 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1508>
10024899c:     	mov	w24, #0x0               ; =0
1002489a0:     	ldp	x1, x14, [x29, #-0x78]
1002489a4:     	mov	x8, x21
1002489a8:     	ldr	x28, [sp, #0x98]
1002489ac:     	ldp	x10, x9, [x8, #0x68]
1002489b0:     	cmp	x9, x10
1002489b4:     	b.hs	0x1002493bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11b0>
1002489b8:     	ldr	x11, [x8, #0x60]
1002489bc:     	ldrb	w12, [x11, x9]
1002489c0:     	cmp	w12, #0x3a
1002489c4:     	b.hi	0x1002493bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11b0>
1002489c8:     	lsr	x13, x25, x12
1002489cc:     	tbz	w13, #0x0, 0x1002489e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x7d8>
1002489d0:     	add	x9, x9, #0x1
1002489d4:     	str	x9, [x8, #0x70]
1002489d8:     	cmp	x10, x9
1002489dc:     	b.ne	0x1002489bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x7b0>
1002489e0:     	b	0x1002493bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11b0>
1002489e4:     	cmp	x12, #0x3a
1002489e8:     	b.ne	0x1002493bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11b0>
1002489ec:     	stp	x14, x1, [sp, #0x30]
1002489f0:     	add	x9, x9, #0x1
1002489f4:     	str	x9, [x8, #0x70]
1002489f8:     	mov	x0, x21
1002489fc:     	bl	0x10024820c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_>
100248a00:     	mov	x8, x21
100248a04:     	ldrb	w9, [x21, #0xd4]
100248a08:     	tbz	w9, #0x0, 0x100249b70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1964>
100248a0c:     	ldr	x10, [sp, #0x188]
100248a10:     	cmn	x10, #0x1
100248a14:     	ldp	x3, x17, [sp, #0x30]
100248a18:     	str	x0, [sp, #0x28]
100248a1c:     	b.eq	0x100248ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8c8>
100248a20:     	ldr	x9, [sp, #0x1b8]
100248a24:     	cmn	x9, #0x1
100248a28:     	b.eq	0x100248b18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x90c>
100248a2c:     	ldp	x8, x11, [sp, #0x1f0]
100248a30:     	ldr	x10, [sp, #0x200]
100248a34:     	ldr	x9, [sp, #0x208]
100248a38:     	eor	x11, x11, x3
100248a3c:     	mov	x13, #0x7f2d            ; =32557
100248a40:     	movk	x13, #0x4c95, lsl #16
100248a44:     	movk	x13, #0xf42d, lsl #32
100248a48:     	movk	x13, #0x5851, lsl #48
100248a4c:     	mul	x12, x11, x13
100248a50:     	umulh	x11, x11, x13
100248a54:     	eor	x11, x11, x12
100248a58:     	add	x11, x3, x11
100248a5c:     	mul	x11, x11, x13
100248a60:     	cmp	x3, #0x8
100248a64:     	b.ls	0x100248b6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x960>
100248a68:     	cmp	x3, #0x10
100248a6c:     	b.ls	0x100248c20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa14>
100248a70:     	add	x12, x17, x3
100248a74:     	ldp	x12, x13, [x12, #-0x10]
100248a78:     	eor	x12, x10, x12
100248a7c:     	eor	x13, x13, x9
100248a80:     	mul	x14, x13, x12
100248a84:     	umulh	x12, x13, x12
100248a88:     	eor	x12, x12, x14
100248a8c:     	add	x11, x11, x8
100248a90:     	eor	x11, x11, x12
100248a94:     	ror	x11, x11, #0x29
100248a98:     	mov	x13, x17
100248a9c:     	mov	x12, x3
100248aa0:     	ldp	x15, x14, [x13], #0x10
100248aa4:     	sub	x12, x12, #0x10
100248aa8:     	eor	x15, x10, x15
100248aac:     	eor	x14, x14, x9
100248ab0:     	mul	x16, x14, x15
100248ab4:     	umulh	x14, x14, x15
100248ab8:     	eor	x14, x14, x16
100248abc:     	add	x11, x11, x8
100248ac0:     	eor	x11, x11, x14
100248ac4:     	ror	x11, x11, #0x29
100248ac8:     	cmp	x12, #0x10
100248acc:     	b.hi	0x100248aa0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x894>
100248ad0:     	b	0x100248d0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xb00>
100248ad4:     	ldr	w9, [sp, #0x8c]
100248ad8:     	tbz	w9, #0x0, 0x100248b8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x980>
100248adc:     	ldr	w9, [sp, #0x88]
100248ae0:     	tbz	w9, #0x0, 0x100249cf0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ae4>
100248ae4:     	mov	x12, x26
100248ae8:     	ldr	x9, [sp, #0x80]
100248aec:     	cmp	x26, x9
100248af0:     	b.hs	0x100248e4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc40>
100248af4:     	mov	x26, x20
100248af8:     	tbz	w24, #0x0, 0x100248e0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc00>
100248afc:     	cmp	x12, #0x7
100248b00:     	b.hi	0x100249d58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b4c>
100248b04:     	ldr	x9, [sp, #0x68]
100248b08:     	ldr	x11, [x9, x12, lsl #3]
100248b0c:     	add	x12, x12, #0x1
100248b10:     	mov	w9, #0x1                ; =1
100248b14:     	b	0x100248e70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc64>
100248b18:     	str	x10, [sp, #0x10]
100248b1c:     	ldp	x1, x24, [sp, #0x190]
100248b20:     	cmp	x24, #0x80
100248b24:     	b.ne	0x100248bb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x9a4>
100248b28:     	mov	w9, #0x1                ; =1
100248b2c:     	strb	w9, [x8, #0xd6]
100248b30:     	add	x8, sp, #0x188
100248b34:     	add	x0, x8, #0x30
100248b38:     	mov	x28, x1
100248b3c:     	bl	0x10028b55c <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex9from_keys>
100248b40:     	ldp	x3, x17, [sp, #0x30]
100248b44:     	ldr	x8, [sp, #0x1b8]
100248b48:     	cmn	x8, #0x1
100248b4c:     	b.ne	0x100248a2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x820>
100248b50:     	mov	x0, x17
100248b54:     	mov	x1, x3
100248b58:     	bl	0x10032abfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100248b5c:     	mov	x13, x0
100248b60:     	add	x22, x28, #0x400
100248b64:     	mov	x11, x28
100248b68:     	b	0x100248bd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x9c4>
100248b6c:     	cmp	x3, #0x1
100248b70:     	b.ls	0x100248c30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa24>
100248b74:     	add	x13, x17, x3
100248b78:     	cmp	x3, #0x3
100248b7c:     	b.ls	0x100248cd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xacc>
100248b80:     	ldr	w12, [x17]
100248b84:     	ldur	w13, [x13, #-0x4]
100248b88:     	b	0x100248cec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xae0>
100248b8c:     	mov	x0, x17
100248b90:     	mov	x1, x3
100248b94:     	bl	0x10032abfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100248b98:     	mov	x11, x0
100248b9c:     	mov	x8, x21
100248ba0:     	mov	w9, #0x0                ; =0
100248ba4:     	mov	x12, x26
100248ba8:     	mov	x26, x20
100248bac:     	b	0x100248e70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc64>
100248bb0:     	str	x1, [sp, #0x8]
100248bb4:     	mov	x0, x17
100248bb8:     	mov	x1, x3
100248bbc:     	bl	0x10032abfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100248bc0:     	mov	x13, x0
100248bc4:     	cbz	x24, 0x100249238 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x102c>
100248bc8:     	ldr	x11, [sp, #0x8]
100248bcc:     	add	x22, x11, x24, lsl #3
100248bd0:     	mov	x12, x26
100248bd4:     	cmp	x26, #0x0
100248bd8:     	cset	w8, eq
100248bdc:     	ldr	w9, [sp, #0x8c]
100248be0:     	orr	w8, w8, w9
100248be4:     	tbz	w8, #0x0, 0x100248c40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa34>
100248be8:     	mov	x0, #0x0                ; =0
100248bec:     	mov	x9, x11
100248bf0:     	mov	x8, x21
100248bf4:     	mov	x26, x20
100248bf8:     	ldr	x1, [sp, #0x38]
100248bfc:     	ldr	x20, [sp, #0x20]
100248c00:     	ldr	x10, [x9], #0x8
100248c04:     	cmp	x10, x13
100248c08:     	b.eq	0x100248cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xab0>
100248c0c:     	add	x0, x0, #0x1
100248c10:     	cmp	x9, x22
100248c14:     	b.ne	0x100248c00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x9f4>
100248c18:     	ldr	x28, [sp, #0x98]
100248c1c:     	b	0x100249264 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1058>
100248c20:     	ldr	x12, [x17]
100248c24:     	add	x13, x17, x3
100248c28:     	ldur	x13, [x13, #-0x8]
100248c2c:     	b	0x100248cec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xae0>
100248c30:     	b.ne	0x100248ce4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xad8>
100248c34:     	ldrb	w12, [x17]
100248c38:     	mov	x13, x12
100248c3c:     	b	0x100248cec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xae0>
100248c40:     	stp	x24, x11, [sp]
100248c44:     	str	x23, [sp, #0x18]
100248c48:     	mov	x24, #0x0               ; =0
100248c4c:     	mov	x23, x11
100248c50:     	mov	x26, x20
100248c54:     	ldp	x2, x1, [sp, #0x30]
100248c58:     	ldr	x20, [sp, #0x20]
100248c5c:     	b	0x100248c6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa60>
100248c60:     	sub	x24, x24, #0x1
100248c64:     	cmp	x23, x22
100248c68:     	b.eq	0x100249250 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1044>
100248c6c:     	ldr	x8, [x23], #0x8
100248c70:     	cmp	x8, x13
100248c74:     	b.eq	0x100248cb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xaa4>
100248c78:     	ldr	w9, [x8, #0x4]
100248c7c:     	cmp	x2, x9
100248c80:     	b.ne	0x100248c60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa54>
100248c84:     	add	x0, x8, #0x14
100248c88:     	mov	x20, x26
100248c8c:     	mov	x26, x12
100248c90:     	mov	x28, x13
100248c94:     	bl	0x100b66be0 <_writev+0x100b66be0>
100248c98:     	mov	x13, x28
100248c9c:     	ldp	x2, x1, [sp, #0x30]
100248ca0:     	mov	x12, x26
100248ca4:     	mov	x26, x20
100248ca8:     	ldr	x20, [sp, #0x20]
100248cac:     	cbnz	w0, 0x100248c60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa54>
100248cb0:     	neg	x0, x24
100248cb4:     	mov	x8, x21
100248cb8:     	ldr	x23, [sp, #0x18]
100248cbc:     	cmp	x0, x20
100248cc0:     	ldr	x28, [sp, #0x98]
100248cc4:     	ldr	x9, [sp, #0x60]
100248cc8:     	b.hs	0x100249d48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b3c>
100248ccc:     	ldr	x10, [sp, #0x28]
100248cd0:     	str	x10, [x9, x0, lsl #3]
100248cd4:     	b	0x1002492a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1098>
100248cd8:     	ldrh	w12, [x17]
100248cdc:     	ldurb	w13, [x13, #-0x1]
100248ce0:     	b	0x100248cec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xae0>
100248ce4:     	mov	x12, #0x0               ; =0
100248ce8:     	mov	x13, #0x0               ; =0
100248cec:     	eor	x10, x12, x10
100248cf0:     	eor	x9, x13, x9
100248cf4:     	mul	x12, x9, x10
100248cf8:     	umulh	x9, x9, x10
100248cfc:     	eor	x9, x9, x12
100248d00:     	add	x10, x11, x8
100248d04:     	eor	x9, x10, x9
100248d08:     	ror	x11, x9, #0x29
100248d0c:     	mul	x9, x11, x8
100248d10:     	umulh	x8, x11, x8
100248d14:     	eor	x8, x8, x9
100248d18:     	neg	w9, w11
100248d1c:     	ror	x24, x8, x9
100248d20:     	ldp	x4, x28, [sp, #0x190]
100248d24:     	add	x8, sp, #0x188
100248d28:     	add	x0, x8, #0x30
100248d2c:     	mov	x1, x24
100248d30:     	mov	x2, x17
100248d34:     	mov	x5, x28
100248d38:     	bl	0x10028b18c <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11find_hashed>
100248d3c:     	tbz	w0, #0x0, 0x100248d68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xb5c>
100248d40:     	ldr	x8, [sp, #0x20]
100248d44:     	cmp	x1, x8
100248d48:     	b.hs	0x100249d34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b28>
100248d4c:     	mov	x8, x21
100248d50:     	mov	x12, x26
100248d54:     	ldr	x9, [sp, #0x60]
100248d58:     	ldr	x10, [sp, #0x28]
100248d5c:     	str	x10, [x9, x1, lsl #3]
100248d60:     	ldr	x28, [sp, #0x98]
100248d64:     	b	0x100248e00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xbf4>
100248d68:     	cmn	x27, #0x1
100248d6c:     	str	x23, [sp, #0x18]
100248d70:     	b.eq	0x100248d80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xb74>
100248d74:     	ldp	x1, x0, [sp, #0x30]
100248d78:     	bl	0x10034e1b0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
100248d7c:     	b	0x100248d8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xb80>
100248d80:     	add	x0, x21, #0x20
100248d84:     	ldp	x2, x1, [sp, #0x30]
100248d88:     	bl	0x1005eddc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>
100248d8c:     	mov	x22, x0
100248d90:     	add	x8, sp, #0x188
100248d94:     	add	x0, x8, #0x30
100248d98:     	mov	x1, x24
100248d9c:     	mov	x2, x28
100248da0:     	bl	0x10028b360 <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11insert_hash>
100248da4:     	ldr	x23, [sp, #0x198]
100248da8:     	ldr	x8, [sp, #0x188]
100248dac:     	cmp	x23, x8
100248db0:     	b.eq	0x100249330 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1124>
100248db4:     	ldr	x8, [sp, #0x190]
100248db8:     	str	x22, [x8, x23, lsl #3]
100248dbc:     	add	x8, x23, #0x1
100248dc0:     	str	x8, [sp, #0x198]
100248dc4:     	ldr	x23, [sp, #0x1b0]
100248dc8:     	ldr	x8, [sp, #0x1a0]
100248dcc:     	cmp	x23, x8
100248dd0:     	ldr	x28, [sp, #0x98]
100248dd4:     	b.eq	0x10024933c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1130>
100248dd8:     	ldr	x8, [sp, #0x1a8]
100248ddc:     	str	x8, [sp, #0x60]
100248de0:     	ldr	x9, [sp, #0x28]
100248de4:     	str	x9, [x8, x23, lsl #3]
100248de8:     	add	x8, x23, #0x1
100248dec:     	str	x8, [sp, #0x20]
100248df0:     	str	x8, [sp, #0x1b0]
100248df4:     	mov	x8, x21
100248df8:     	ldr	x23, [sp, #0x18]
100248dfc:     	mov	x12, x26
100248e00:     	mov	x26, x20
100248e04:     	ldr	x1, [sp, #0x38]
100248e08:     	b	0x1002492a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1098>
100248e0c:     	cmp	x12, #0x8
100248e10:     	b.hs	0x100249d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b60>
100248e14:     	ldr	x8, [sp, #0x68]
100248e18:     	ldr	x9, [x8, x12, lsl #3]
100248e1c:     	ldr	w8, [x9, #0x4]
100248e20:     	cmp	x3, x8
100248e24:     	b.ne	0x100248e4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc40>
100248e28:     	add	x0, x9, #0x14
100248e2c:     	mov	x1, x17
100248e30:     	mov	x2, x3
100248e34:     	mov	x24, x12
100248e38:     	mov	x20, x9
100248e3c:     	bl	0x100b66be0 <_writev+0x100b66be0>
100248e40:     	ldp	x3, x17, [sp, #0x30]
100248e44:     	mov	x12, x24
100248e48:     	cbz	w0, 0x10024934c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1140>
100248e4c:     	mov	x0, x17
100248e50:     	mov	x1, x3
100248e54:     	mov	x24, x12
100248e58:     	bl	0x10032abfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100248e5c:     	mov	x12, x24
100248e60:     	mov	x11, x0
100248e64:     	mov	x8, x21
100248e68:     	mov	w26, #0x0               ; =0
100248e6c:     	mov	w9, #0x0                ; =0
100248e70:     	cmp	x12, #0x0
100248e74:     	str	w9, [sp, #0x8c]
100248e78:     	csinc	w24, w9, wzr, ne
100248e7c:     	cmp	x28, #0x9
100248e80:     	b.hs	0x100249ca8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a9c>
100248e84:     	ldp	x2, x1, [sp, #0x30]
100248e88:     	cbz	x28, 0x100249208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
100248e8c:     	ldr	x9, [sp, #0x100]
100248e90:     	cmp	x9, x11
100248e94:     	b.eq	0x100249228 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x101c>
100248e98:     	tbnz	w24, #0x0, 0x100248ed4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xcc8>
100248e9c:     	ldr	w10, [x9, #0x4]
100248ea0:     	cmp	x2, x10
100248ea4:     	b.ne	0x100248ed4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xcc8>
100248ea8:     	add	x0, x9, #0x14
100248eac:     	mov	x20, x26
100248eb0:     	mov	x26, x12
100248eb4:     	str	x11, [sp, #0x98]
100248eb8:     	bl	0x100b66be0 <_writev+0x100b66be0>
100248ebc:     	ldr	x11, [sp, #0x98]
100248ec0:     	ldp	x2, x1, [sp, #0x30]
100248ec4:     	mov	x12, x26
100248ec8:     	mov	x26, x20
100248ecc:     	mov	x8, x21
100248ed0:     	cbz	w0, 0x100249228 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x101c>
100248ed4:     	cmp	x28, #0x1
100248ed8:     	b.eq	0x100249208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
100248edc:     	ldr	x10, [sp, #0x108]
100248ee0:     	add	x9, sp, #0x148
100248ee4:     	add	x9, x9, #0x8
100248ee8:     	cmp	x10, x11
100248eec:     	b.eq	0x10024922c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100248ef0:     	tbnz	w24, #0x0, 0x100248f34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xd28>
100248ef4:     	ldr	w9, [x10, #0x4]
100248ef8:     	cmp	x2, x9
100248efc:     	b.ne	0x100248f34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xd28>
100248f00:     	add	x0, x10, #0x14
100248f04:     	mov	x20, x26
100248f08:     	mov	x26, x12
100248f0c:     	str	x11, [sp, #0x98]
100248f10:     	bl	0x100b66be0 <_writev+0x100b66be0>
100248f14:     	ldr	x11, [sp, #0x98]
100248f18:     	ldp	x2, x1, [sp, #0x30]
100248f1c:     	mov	x12, x26
100248f20:     	mov	x26, x20
100248f24:     	mov	x8, x21
100248f28:     	add	x9, sp, #0x148
100248f2c:     	add	x9, x9, #0x8
100248f30:     	cbz	w0, 0x10024922c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100248f34:     	cmp	x28, #0x2
100248f38:     	b.eq	0x100249208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
100248f3c:     	ldr	x10, [sp, #0x110]
100248f40:     	add	x9, sp, #0x148
100248f44:     	add	x9, x9, #0x10
100248f48:     	cmp	x10, x11
100248f4c:     	b.eq	0x10024922c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100248f50:     	tbnz	w24, #0x0, 0x100248f94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xd88>
100248f54:     	ldr	w9, [x10, #0x4]
100248f58:     	cmp	x2, x9
100248f5c:     	b.ne	0x100248f94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xd88>
100248f60:     	add	x0, x10, #0x14
100248f64:     	mov	x20, x26
100248f68:     	mov	x26, x12
100248f6c:     	str	x11, [sp, #0x98]
100248f70:     	bl	0x100b66be0 <_writev+0x100b66be0>
100248f74:     	ldr	x11, [sp, #0x98]
100248f78:     	ldp	x2, x1, [sp, #0x30]
100248f7c:     	mov	x12, x26
100248f80:     	mov	x26, x20
100248f84:     	mov	x8, x21
100248f88:     	add	x9, sp, #0x148
100248f8c:     	add	x9, x9, #0x10
100248f90:     	cbz	w0, 0x10024922c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100248f94:     	cmp	x28, #0x3
100248f98:     	b.eq	0x100249208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
100248f9c:     	ldr	x10, [sp, #0x118]
100248fa0:     	add	x9, sp, #0x148
100248fa4:     	add	x9, x9, #0x18
100248fa8:     	cmp	x10, x11
100248fac:     	b.eq	0x10024922c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100248fb0:     	tbnz	w24, #0x0, 0x100248ff4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xde8>
100248fb4:     	ldr	w9, [x10, #0x4]
100248fb8:     	cmp	x2, x9
100248fbc:     	b.ne	0x100248ff4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xde8>
100248fc0:     	add	x0, x10, #0x14
100248fc4:     	mov	x20, x26
100248fc8:     	mov	x26, x12
100248fcc:     	str	x11, [sp, #0x98]
100248fd0:     	bl	0x100b66be0 <_writev+0x100b66be0>
100248fd4:     	ldr	x11, [sp, #0x98]
100248fd8:     	ldp	x2, x1, [sp, #0x30]
100248fdc:     	mov	x12, x26
100248fe0:     	mov	x26, x20
100248fe4:     	mov	x8, x21
100248fe8:     	add	x9, sp, #0x148
100248fec:     	add	x9, x9, #0x18
100248ff0:     	cbz	w0, 0x10024922c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100248ff4:     	cmp	x28, #0x4
100248ff8:     	b.eq	0x100249208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
100248ffc:     	ldr	x10, [sp, #0x120]
100249000:     	add	x9, sp, #0x148
100249004:     	add	x9, x9, #0x20
100249008:     	cmp	x10, x11
10024900c:     	b.eq	0x10024922c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100249010:     	tbnz	w24, #0x0, 0x100249054 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xe48>
100249014:     	ldr	w9, [x10, #0x4]
100249018:     	cmp	x2, x9
10024901c:     	b.ne	0x100249054 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xe48>
100249020:     	add	x0, x10, #0x14
100249024:     	mov	x20, x26
100249028:     	mov	x26, x12
10024902c:     	str	x11, [sp, #0x98]
100249030:     	bl	0x100b66be0 <_writev+0x100b66be0>
100249034:     	ldr	x11, [sp, #0x98]
100249038:     	ldp	x2, x1, [sp, #0x30]
10024903c:     	mov	x12, x26
100249040:     	mov	x26, x20
100249044:     	mov	x8, x21
100249048:     	add	x9, sp, #0x148
10024904c:     	add	x9, x9, #0x20
100249050:     	cbz	w0, 0x10024922c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100249054:     	cmp	x28, #0x5
100249058:     	b.eq	0x100249208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
10024905c:     	ldr	x10, [sp, #0x128]
100249060:     	add	x9, sp, #0x148
100249064:     	add	x9, x9, #0x28
100249068:     	cmp	x10, x11
10024906c:     	b.eq	0x10024922c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100249070:     	tbnz	w24, #0x0, 0x1002490b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xea8>
100249074:     	ldr	w9, [x10, #0x4]
100249078:     	cmp	x2, x9
10024907c:     	b.ne	0x1002490b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xea8>
100249080:     	add	x0, x10, #0x14
100249084:     	mov	x20, x26
100249088:     	mov	x26, x12
10024908c:     	str	x11, [sp, #0x98]
100249090:     	bl	0x100b66be0 <_writev+0x100b66be0>
100249094:     	ldr	x11, [sp, #0x98]
100249098:     	ldp	x2, x1, [sp, #0x30]
10024909c:     	mov	x12, x26
1002490a0:     	mov	x26, x20
1002490a4:     	mov	x8, x21
1002490a8:     	add	x9, sp, #0x148
1002490ac:     	add	x9, x9, #0x28
1002490b0:     	cbz	w0, 0x10024922c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
1002490b4:     	cmp	x28, #0x6
1002490b8:     	b.eq	0x100249208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
1002490bc:     	ldr	x10, [sp, #0x130]
1002490c0:     	add	x9, sp, #0x148
1002490c4:     	add	x9, x9, #0x30
1002490c8:     	cmp	x10, x11
1002490cc:     	b.eq	0x10024922c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
1002490d0:     	tbnz	w24, #0x0, 0x100249114 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xf08>
1002490d4:     	ldr	w9, [x10, #0x4]
1002490d8:     	cmp	x2, x9
1002490dc:     	b.ne	0x100249114 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xf08>
1002490e0:     	add	x0, x10, #0x14
1002490e4:     	mov	x20, x26
1002490e8:     	mov	x26, x12
1002490ec:     	str	x11, [sp, #0x98]
1002490f0:     	bl	0x100b66be0 <_writev+0x100b66be0>
1002490f4:     	ldr	x11, [sp, #0x98]
1002490f8:     	ldp	x2, x1, [sp, #0x30]
1002490fc:     	mov	x12, x26
100249100:     	mov	x26, x20
100249104:     	mov	x8, x21
100249108:     	add	x9, sp, #0x148
10024910c:     	add	x9, x9, #0x30
100249110:     	cbz	w0, 0x10024922c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100249114:     	cmp	x28, #0x7
100249118:     	b.eq	0x100249208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
10024911c:     	ldr	x10, [sp, #0x138]
100249120:     	add	x9, sp, #0x148
100249124:     	add	x9, x9, #0x38
100249128:     	cmp	x10, x11
10024912c:     	b.eq	0x10024922c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100249130:     	tbnz	w24, #0x0, 0x10024916c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xf60>
100249134:     	ldr	w9, [x10, #0x4]
100249138:     	cmp	x2, x9
10024913c:     	b.ne	0x10024916c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xf60>
100249140:     	add	x0, x10, #0x14
100249144:     	mov	x24, x12
100249148:     	mov	x20, x11
10024914c:     	bl	0x100b66be0 <_writev+0x100b66be0>
100249150:     	mov	x11, x20
100249154:     	ldr	x1, [sp, #0x38]
100249158:     	mov	x12, x24
10024915c:     	mov	x8, x21
100249160:     	add	x9, sp, #0x148
100249164:     	add	x9, x9, #0x38
100249168:     	cbz	w0, 0x10024922c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
10024916c:     	cmp	x28, #0x8
100249170:     	b.ne	0x100249208 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
100249174:     	mov	x28, x11
100249178:     	mov	x20, x26
10024917c:     	mov	x26, x12
100249180:     	mov	w0, #0x80               ; =128
100249184:     	mov	w1, #0x8                ; =8
100249188:     	bl	0x100b63fc8 <_mi_malloc_aligned>
10024918c:     	cbz	x0, 0x100249d80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b74>
100249190:     	mov	x24, x0
100249194:     	mov	w0, #0x80               ; =128
100249198:     	mov	w1, #0x8                ; =8
10024919c:     	bl	0x100b63fc8 <_mi_malloc_aligned>
1002491a0:     	str	x0, [sp, #0x60]
1002491a4:     	cbz	x0, 0x100249d80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b74>
1002491a8:     	ldp	q0, q1, [sp, #0x100]
1002491ac:     	stp	q0, q1, [x24]
1002491b0:     	ldp	q0, q1, [sp, #0x120]
1002491b4:     	stp	q0, q1, [x24, #0x20]
1002491b8:     	add	x9, sp, #0x148
1002491bc:     	ldp	q0, q1, [x9]
1002491c0:     	ldr	x8, [sp, #0x60]
1002491c4:     	stp	q0, q1, [x8]
1002491c8:     	ldp	q0, q1, [x9, #0x20]
1002491cc:     	stp	q0, q1, [x8, #0x20]
1002491d0:     	str	x28, [x24, #0x40]
1002491d4:     	ldr	x10, [sp, #0x28]
1002491d8:     	str	x10, [x8, #0x40]
1002491dc:     	mov	w10, #0x10              ; =16
1002491e0:     	stp	x10, x24, [sp, #0x188]
1002491e4:     	ldp	q0, q1, [sp, #0x40]
1002491e8:     	str	q1, [x9, #0x50]
1002491ec:     	str	x8, [sp, #0x1a8]
1002491f0:     	mov	w8, #0x9                ; =9
1002491f4:     	str	x8, [sp, #0x20]
1002491f8:     	mov	w28, #0x8               ; =8
1002491fc:     	stur	q0, [x9, #0x68]
100249200:     	mov	x8, x21
100249204:     	b	0x100248dfc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xbf0>
100249208:     	add	x9, sp, #0x100
10024920c:     	str	x11, [x9, x28, lsl #3]
100249210:     	add	x9, sp, #0x148
100249214:     	ldr	x10, [sp, #0x28]
100249218:     	str	x10, [x9, x28, lsl #3]
10024921c:     	add	x28, x28, #0x1
100249220:     	str	x28, [sp, #0x70]
100249224:     	b	0x1002492a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1098>
100249228:     	add	x9, sp, #0x148
10024922c:     	ldr	x10, [sp, #0x28]
100249230:     	str	x10, [x9]
100249234:     	b	0x1002492a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1098>
100249238:     	mov	x8, x21
10024923c:     	mov	x12, x26
100249240:     	mov	x26, x20
100249244:     	ldr	x1, [sp, #0x38]
100249248:     	ldr	x20, [sp, #0x20]
10024924c:     	b	0x100249260 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1054>
100249250:     	mov	x8, x21
100249254:     	ldr	x23, [sp, #0x18]
100249258:     	ldr	x28, [sp, #0x98]
10024925c:     	ldr	x24, [sp]
100249260:     	ldr	x11, [sp, #0x8]
100249264:     	ldr	x9, [sp, #0x10]
100249268:     	cmp	x24, x9
10024926c:     	b.eq	0x100249358 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x114c>
100249270:     	str	x13, [x11, x24, lsl #3]
100249274:     	add	x9, x24, #0x1
100249278:     	str	x9, [sp, #0x198]
10024927c:     	ldr	x9, [sp, #0x1a0]
100249280:     	cmp	x20, x9
100249284:     	b.eq	0x10024939c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1190>
100249288:     	ldr	x9, [sp, #0x1a8]
10024928c:     	str	x9, [sp, #0x60]
100249290:     	ldr	x10, [sp, #0x28]
100249294:     	str	x10, [x9, x20, lsl #3]
100249298:     	add	x20, x20, #0x1
10024929c:     	str	x20, [sp, #0x20]
1002492a0:     	str	x20, [sp, #0x1b0]
1002492a4:     	ldp	x24, x9, [x8, #0x68]
1002492a8:     	cmp	x9, x24
1002492ac:     	b.hs	0x1002492dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x10d0>
1002492b0:     	ldr	x10, [x8, #0x60]
1002492b4:     	ldrb	w11, [x10, x9]
1002492b8:     	cmp	w11, #0x20
1002492bc:     	b.hi	0x1002492dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x10d0>
1002492c0:     	lsr	x11, x25, x11
1002492c4:     	tbz	w11, #0x0, 0x1002492dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x10d0>
1002492c8:     	add	x9, x9, #0x1
1002492cc:     	str	x9, [x8, #0x70]
1002492d0:     	cmp	x24, x9
1002492d4:     	b.ne	0x1002492b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x10a8>
1002492d8:     	b	0x100249564 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1358>
1002492dc:     	cmp	x9, x24
1002492e0:     	b.hs	0x100249564 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1358>
1002492e4:     	ldr	x10, [x8, #0x60]
1002492e8:     	ldrb	w10, [x10, x9]
1002492ec:     	cmp	w10, #0x2c
1002492f0:     	b.ne	0x100249564 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1358>
1002492f4:     	str	x28, [sp, #0x98]
1002492f8:     	add	x28, x9, #0x1
1002492fc:     	str	x28, [x8, #0x70]
100249300:     	cmp	x27, #0x1
100249304:     	ldr	x22, [sp, #0x80]
100249308:     	ldp	w27, w9, [sp, #0x88]
10024930c:     	b.lt	0x100248874 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x668>
100249310:     	mov	x0, x1
100249314:     	mov	x24, x12
100249318:     	bl	0x100b63d40 <_mi_free>
10024931c:     	ldr	w9, [sp, #0x8c]
100249320:     	mov	x12, x24
100249324:     	mov	x8, x21
100249328:     	ldp	x24, x28, [x21, #0x68]
10024932c:     	b	0x100248874 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x668>
100249330:     	add	x0, sp, #0x188
100249334:     	bl	0x100b40a2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100249338:     	b	0x100248db4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xba8>
10024933c:     	add	x8, sp, #0x188
100249340:     	add	x0, x8, #0x18
100249344:     	bl	0x100b40a2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100249348:     	b	0x100248dd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xbcc>
10024934c:     	mov	x11, x20
100249350:     	mov	x8, x21
100249354:     	b	0x100248b0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x900>
100249358:     	add	x0, sp, #0x188
10024935c:     	mov	x20, x24
100249360:     	mov	x24, x12
100249364:     	mov	x22, x13
100249368:     	bl	0x100b40a2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10024936c:     	ldr	x1, [sp, #0x38]
100249370:     	mov	x12, x24
100249374:     	mov	x24, x20
100249378:     	mov	x8, x21
10024937c:     	ldr	x11, [sp, #0x190]
100249380:     	ldr	x20, [sp, #0x1b0]
100249384:     	str	x22, [x11, x24, lsl #3]
100249388:     	add	x9, x24, #0x1
10024938c:     	str	x9, [sp, #0x198]
100249390:     	ldr	x9, [sp, #0x1a0]
100249394:     	cmp	x20, x9
100249398:     	b.ne	0x100249288 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x107c>
10024939c:     	add	x8, sp, #0x188
1002493a0:     	add	x0, x8, #0x18
1002493a4:     	mov	x24, x12
1002493a8:     	bl	0x100b40a2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1002493ac:     	ldr	x1, [sp, #0x38]
1002493b0:     	mov	x12, x24
1002493b4:     	mov	x8, x21
1002493b8:     	b	0x100249288 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x107c>
1002493bc:     	strb	wzr, [x8, #0xd4]
1002493c0:     	cmp	x27, #0x1
1002493c4:     	b.lt	0x1002493d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11c8>
1002493c8:     	mov	x0, x1
1002493cc:     	bl	0x100b63d40 <_mi_free>
1002493d0:     	mov	x8, x21
1002493d4:     	ldr	x20, [sp, #0x90]
1002493d8:     	ldp	x10, x9, [x8, #0x68]
1002493dc:     	cmp	x9, x10
1002493e0:     	b.hs	0x100249728 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x151c>
1002493e4:     	ldr	x11, [x8, #0x60]
1002493e8:     	mov	x12, #0x2600            ; =9728
1002493ec:     	movk	x12, #0x1, lsl #32
1002493f0:     	ldrb	w13, [x11, x9]
1002493f4:     	cmp	w13, #0x20
1002493f8:     	b.hi	0x1002494d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x12c4>
1002493fc:     	lsr	x14, x12, x13
100249400:     	tbz	w14, #0x0, 0x1002494d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x12c4>
100249404:     	add	x9, x9, #0x1
100249408:     	str	x9, [x8, #0x70]
10024940c:     	cmp	x10, x9
100249410:     	b.ne	0x1002493f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11e4>
100249414:     	b	0x100249728 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x151c>
100249418:     	mov	x8, x1
10024941c:     	cmp	x8, x2
100249420:     	b.hs	0x100249498 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x128c>
100249424:     	ldrb	w10, [x12, x8]
100249428:     	orr	w10, w10, #0x20
10024942c:     	cmp	w10, #0x65
100249430:     	b.ne	0x100249498 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x128c>
100249434:     	add	x10, x8, #0x1
100249438:     	str	x10, [x0, #0x70]
10024943c:     	cmp	x10, x2
100249440:     	b.hs	0x100249460 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1254>
100249444:     	ldrb	w11, [x12, x10]
100249448:     	cmp	w11, #0x2d
10024944c:     	b.eq	0x100249458 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x124c>
100249450:     	cmp	w11, #0x2b
100249454:     	b.ne	0x100249460 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1254>
100249458:     	add	x10, x8, #0x2
10024945c:     	str	x10, [x0, #0x70]
100249460:     	cmp	x10, x2
100249464:     	b.hs	0x1002499d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100249468:     	mov	x8, x10
10024946c:     	ldrb	w11, [x12, x8]
100249470:     	sub	w11, w11, #0x30
100249474:     	cmp	w11, #0x9
100249478:     	b.hi	0x100249490 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1284>
10024947c:     	add	x8, x8, #0x1
100249480:     	str	x8, [x0, #0x70]
100249484:     	cmp	x2, x8
100249488:     	b.ne	0x10024946c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1260>
10024948c:     	mov	x8, x2
100249490:     	cmp	x8, x10
100249494:     	b.eq	0x1002499d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100249498:     	subs	x1, x8, x19
10024949c:     	b.lo	0x100249c70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a64>
1002494a0:     	cmp	x8, x2
1002494a4:     	b.hi	0x100249c70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a64>
1002494a8:     	mov	x20, x0
1002494ac:     	add	x8, sp, #0x188
1002494b0:     	mov	x0, x9
1002494b4:     	bl	0x1000334ac <__RNvXs2_NtNtCsjgY6bXVaRmE_4core3num11float_parsedNtNtNtB9_3str6traits7FromStr8from_str>
1002494b8:     	ldrb	w8, [sp, #0x188]
1002494bc:     	tbz	w8, #0x0, 0x10024955c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1350>
1002494c0:     	mov	x19, #0x2               ; =2
1002494c4:     	movk	x19, #0x7ffc, lsl #48
1002494c8:     	strb	wzr, [x20, #0xd4]
1002494cc:     	b	0x1002499dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
1002494d0:     	cmp	w13, #0x7d
1002494d4:     	b.ne	0x100249728 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x151c>
1002494d8:     	add	x9, x9, #0x1
1002494dc:     	str	x9, [x8, #0x70]
1002494e0:     	b	0x10024972c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1520>
1002494e4:     	sub	x0, x29, #0x68
1002494e8:     	mov	x1, #0x0                ; =0
1002494ec:     	bl	0x10032c2dc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
1002494f0:     	mov	x2, x1
1002494f4:     	mov	x1, x0
1002494f8:     	str	xzr, [x21, #0x78]
1002494fc:     	str	x0, [x21, #0xc0]
100249500:     	str	w2, [x21, #0xd0]
100249504:     	add	x0, x21, #0x20
100249508:     	mov	w3, #0x8                ; =8
10024950c:     	mov	x4, #0x0                ; =0
100249510:     	bl	0x1005bf688 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
100249514:     	ldrb	w8, [x19, #0x20]
100249518:     	cbnz	w8, 0x100249c94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a88>
10024951c:     	ldr	x8, [x19]
100249520:     	cbnz	x8, 0x100249ce4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ad8>
100249524:     	ldr	x8, [x19, #0x18]
100249528:     	cmp	x23, x8
10024952c:     	b.hi	0x100249534 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1328>
100249530:     	str	x23, [x19, #0x18]
100249534:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
100249538:     	bfxil	x19, x0, #0, #48
10024953c:     	b	0x1002499dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
100249540:     	cbz	x20, 0x1002495fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x13f0>
100249544:     	cmp	x20, #0x4
100249548:     	b.hs	0x100249604 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x13f8>
10024954c:     	mov	x10, #0x0               ; =0
100249550:     	mov	x9, #0x0                ; =0
100249554:     	mov	x8, x21
100249558:     	b	0x100249694 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1488>
10024955c:     	ldr	x19, [sp, #0x190]
100249560:     	b	0x1002499dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
100249564:     	mov	x26, x12
100249568:     	b	0x1002493c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11b4>
10024956c:     	ldr	x22, [x24, #0x68]
100249570:     	sub	x9, x22, x20
100249574:     	cmp	x9, #0x101
100249578:     	mov	w9, #0xff               ; =255
10024957c:     	ccmp	x20, x9, #0x0, lo
100249580:     	b.ls	0x1002496d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x14c8>
100249584:     	ldr	x1, [x24, #0x60]
100249588:     	ldr	x23, [x24, #0xc8]
10024958c:     	add	x0, x24, #0x20
100249590:     	mov	x2, x22
100249594:     	mov	x3, x23
100249598:     	mov	x4, x19
10024959c:     	mov	x5, x21
1002495a0:     	mov	x6, x20
1002495a4:     	bl	0x1006ca50c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token>
1002495a8:     	mov	x21, x0
1002495ac:     	b	0x1002496ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x14e0>
1002495b0:     	add	x11, x1, #0x1
1002495b4:     	cmp	x11, x2
1002495b8:     	b.hs	0x1002499cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c0>
1002495bc:     	add	x16, x12, #0x1
1002495c0:     	mov	x15, #-0x1              ; =-1
1002495c4:     	ldrb	w17, [x16, x1]
1002495c8:     	sub	w3, w17, #0x30
1002495cc:     	cmp	w3, #0x9
1002495d0:     	b.hi	0x100249aa4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1898>
1002495d4:     	add	x16, x16, #0x1
1002495d8:     	sub	x15, x15, #0x1
1002495dc:     	cmp	x8, x15
1002495e0:     	b.ne	0x1002495c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x13b8>
1002495e4:     	str	x2, [x0, #0x70]
1002495e8:     	mov	x8, x2
1002495ec:     	subs	x16, x1, x10
1002495f0:     	b.eq	0x100249498 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x128c>
1002495f4:     	mov	x8, x2
1002495f8:     	b	0x100249ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x18cc>
1002495fc:     	mov	x10, #0x0               ; =0
100249600:     	b	0x1002496b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x14a8>
100249604:     	and	x9, x20, #0x4
100249608:     	add	x8, x21, x9
10024960c:     	adrp	x10, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4fb0>
100249610:     	ldr	q0, [x10, #0x8c0]
100249614:     	adrp	x10, 0x100c3e000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x338ba>
100249618:     	ldr	q2, [x10, #0x6c0]
10024961c:     	movi.2d	v1, #0000000000000000
100249620:     	movi.2d	v3, #0x000000000000ff
100249624:     	mov	w10, #0x4               ; =4
100249628:     	dup.2d	v4, x10
10024962c:     	mov	x10, x21
100249630:     	and	x11, x20, #0x4
100249634:     	movi.2d	v5, #0000000000000000
100249638:     	ldr	s6, [x10], #0x4
10024963c:     	ushll.8h	v6, v6, #0x0
100249640:     	ushll.4s	v6, v6, #0x0
100249644:     	ushll2.2d	v7, v6, #0x0
100249648:     	and.16b	v7, v7, v3
10024964c:     	ushll.2d	v6, v6, #0x0
100249650:     	and.16b	v6, v6, v3
100249654:     	shl.2d	v16, v0, #0x3
100249658:     	shl.2d	v17, v2, #0x3
10024965c:     	ushl.2d	v6, v6, v17
100249660:     	ushl.2d	v7, v7, v16
100249664:     	orr.16b	v1, v7, v1
100249668:     	orr.16b	v5, v6, v5
10024966c:     	add.2d	v0, v0, v4
100249670:     	add.2d	v2, v2, v4
100249674:     	subs	x11, x11, #0x4
100249678:     	b.ne	0x100249638 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x142c>
10024967c:     	orr.16b	v0, v5, v1
100249680:     	mov	d1, v0[1]
100249684:     	orr.8b	v0, v0, v1
100249688:     	fmov	x10, d0
10024968c:     	cmp	x20, x9
100249690:     	b.eq	0x1002496b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x14a8>
100249694:     	add	x11, x21, x20
100249698:     	lsl	x9, x9, #3
10024969c:     	ldrb	w12, [x8], #0x1
1002496a0:     	lsl	x12, x12, x9
1002496a4:     	orr	x10, x12, x10
1002496a8:     	add	x9, x9, #0x8
1002496ac:     	cmp	x8, x11
1002496b0:     	b.ne	0x10024969c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1490>
1002496b4:     	orr	x8, x10, x20, lsl #40
1002496b8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1002496bc:     	orr	x19, x8, x9
1002496c0:     	cmp	x22, #0x1
1002496c4:     	b.lt	0x1002499dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
1002496c8:     	mov	x0, x21
1002496cc:     	bl	0x100b63d40 <_mi_free>
1002496d0:     	b	0x1002499dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
1002496d4:     	add	x0, x24, #0x20
1002496d8:     	mov	x1, x21
1002496dc:     	mov	x2, x20
1002496e0:     	bl	0x1005ee804 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction30string_from_scanned_json_bytes>
1002496e4:     	mov	x21, x0
1002496e8:     	ldr	x23, [x24, #0xc8]
1002496ec:     	ldr	x3, [x24, #0x70]
1002496f0:     	mov	x0, x23
1002496f4:     	mov	x1, x22
1002496f8:     	mov	x2, x19
1002496fc:     	mov	x4, x21
100249700:     	mov	x5, x20
100249704:     	bl	0x1004efaec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21remember_parse_string>
100249708:     	mov	x19, #0x7fff000000000000 ; =9223090561878065152
10024970c:     	bfxil	x19, x21, #0, #48
100249710:     	b	0x1002499dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
100249714:     	mov	x8, x21
100249718:     	ldp	x20, x28, [sp, #0x90]
10024971c:     	ldp	x10, x9, [x21, #0x68]
100249720:     	cmp	x9, x10
100249724:     	b.lo	0x1002493e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11d8>
100249728:     	strb	wzr, [x8, #0xd4]
10024972c:     	ldr	x27, [sp, #0x188]
100249730:     	cmn	x27, #0x1
100249734:     	b.eq	0x1002497a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x159c>
100249738:     	ldp	x0, x1, [sp, #0x190]
10024973c:     	cmp	x1, #0x9
100249740:     	b.hs	0x100249840 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1634>
100249744:     	ldr	x9, [x8, #0x78]
100249748:     	cmp	x1, x9
10024974c:     	b.ne	0x10024976c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
100249750:     	ldr	x20, [x8, #0xc0]
100249754:     	cbz	x20, 0x10024976c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
100249758:     	cbz	x1, 0x100249908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
10024975c:     	ldr	x9, [x8, #0x80]
100249760:     	ldr	x10, [x0]
100249764:     	cmp	x9, x10
100249768:     	b.eq	0x100249854 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1648>
10024976c:     	mov	x24, x0
100249770:     	mov	x25, x1
100249774:     	bl	0x10032c2dc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100249778:     	mov	x20, x0
10024977c:     	mov	x26, x1
100249780:     	str	x25, [x21, #0x78]
100249784:     	lsl	x2, x25, #3
100249788:     	add	x0, x21, #0x80
10024978c:     	mov	x1, x24
100249790:     	bl	0x100b66bec <_writev+0x100b66bec>
100249794:     	mov	x2, x26
100249798:     	mov	x8, x21
10024979c:     	str	x20, [x21, #0xc0]
1002497a0:     	str	w26, [x21, #0xd0]
1002497a4:     	b	0x10024990c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1700>
1002497a8:     	ldp	w9, w10, [sp, #0x88]
1002497ac:     	and	w9, w9, w10
1002497b0:     	ldr	w2, [sp, #0x7c]
1002497b4:     	tbz	w9, #0x0, 0x1002497d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15c8>
1002497b8:     	ldr	x9, [sp, #0x70]
1002497bc:     	ldr	x10, [sp, #0x80]
1002497c0:     	cmp	x10, x9
1002497c4:     	b.ne	0x1002497d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15c8>
1002497c8:     	ldr	x9, [sp, #0x80]
1002497cc:     	cmp	x26, x9
1002497d0:     	b.eq	0x10024990c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1700>
1002497d4:     	cmp	x28, #0x9
1002497d8:     	b.hs	0x100249c58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a4c>
1002497dc:     	ldr	x9, [x8, #0x78]
1002497e0:     	cmp	x28, x9
1002497e4:     	b.ne	0x100249804 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
1002497e8:     	ldr	x20, [x8, #0xc0]
1002497ec:     	cbz	x20, 0x100249804 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
1002497f0:     	cbz	x28, 0x100249908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
1002497f4:     	ldr	x9, [x8, #0x80]
1002497f8:     	ldr	x10, [sp, #0x100]
1002497fc:     	cmp	x9, x10
100249800:     	b.eq	0x100249900 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
100249804:     	add	x0, sp, #0x100
100249808:     	mov	x1, x28
10024980c:     	bl	0x10032c2dc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100249810:     	mov	x20, x0
100249814:     	mov	x24, x1
100249818:     	str	x28, [x21, #0x78]
10024981c:     	lsl	x2, x28, #3
100249820:     	add	x0, x21, #0x80
100249824:     	add	x1, sp, #0x100
100249828:     	bl	0x100b66bec <_writev+0x100b66bec>
10024982c:     	mov	x2, x24
100249830:     	mov	x8, x21
100249834:     	str	x20, [x21, #0xc0]
100249838:     	str	w24, [x21, #0xd0]
10024983c:     	b	0x10024990c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1700>
100249840:     	bl	0x10032c2dc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100249844:     	mov	x20, x0
100249848:     	mov	x8, x21
10024984c:     	mov	x2, x1
100249850:     	b	0x10024990c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1700>
100249854:     	cmp	x1, #0x1
100249858:     	b.eq	0x100249908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
10024985c:     	ldr	x9, [x8, #0x88]
100249860:     	ldr	x10, [x0, #0x8]
100249864:     	cmp	x9, x10
100249868:     	b.ne	0x10024976c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
10024986c:     	cmp	x1, #0x2
100249870:     	b.eq	0x100249908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
100249874:     	ldr	x9, [x8, #0x90]
100249878:     	ldr	x10, [x0, #0x10]
10024987c:     	cmp	x9, x10
100249880:     	b.ne	0x10024976c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
100249884:     	cmp	x1, #0x3
100249888:     	b.eq	0x100249908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
10024988c:     	ldr	x9, [x8, #0x98]
100249890:     	ldr	x10, [x0, #0x18]
100249894:     	cmp	x9, x10
100249898:     	b.ne	0x10024976c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
10024989c:     	cmp	x1, #0x4
1002498a0:     	b.eq	0x100249908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
1002498a4:     	ldr	x9, [x8, #0xa0]
1002498a8:     	ldr	x10, [x0, #0x20]
1002498ac:     	cmp	x9, x10
1002498b0:     	b.ne	0x10024976c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
1002498b4:     	cmp	x1, #0x5
1002498b8:     	b.eq	0x100249908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
1002498bc:     	ldr	x9, [x8, #0xa8]
1002498c0:     	ldr	x10, [x0, #0x28]
1002498c4:     	cmp	x9, x10
1002498c8:     	b.ne	0x10024976c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
1002498cc:     	cmp	x1, #0x6
1002498d0:     	b.eq	0x100249908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
1002498d4:     	ldr	x9, [x8, #0xb0]
1002498d8:     	ldr	x10, [x0, #0x30]
1002498dc:     	cmp	x9, x10
1002498e0:     	b.ne	0x10024976c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
1002498e4:     	cmp	x1, #0x7
1002498e8:     	b.eq	0x100249908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
1002498ec:     	ldr	x9, [x8, #0xb8]
1002498f0:     	ldr	x10, [x0, #0x38]
1002498f4:     	cmp	x9, x10
1002498f8:     	b.ne	0x10024976c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
1002498fc:     	b	0x100249908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
100249900:     	cmp	x28, #0x1
100249904:     	b.ne	0x100249a00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17f4>
100249908:     	ldr	w2, [x8, #0xd0]
10024990c:     	cmp	x28, #0x9
100249910:     	b.hs	0x100249b78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x196c>
100249914:     	ldr	x9, [sp, #0x1b0]
100249918:     	cmn	x27, #0x1
10024991c:     	add	x10, sp, #0x148
100249920:     	ldr	x11, [sp, #0x60]
100249924:     	csel	x3, x10, x11, eq
100249928:     	csel	x4, x28, x9, eq
10024992c:     	add	x0, x8, #0x20
100249930:     	mov	x1, x20
100249934:     	bl	0x1005bf688 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
100249938:     	ldrb	w8, [x19, #0x20]
10024993c:     	cbnz	w8, 0x100249c28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a1c>
100249940:     	ldr	x8, [x19]
100249944:     	cbnz	x8, 0x100249ce4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ad8>
100249948:     	ldr	x8, [x19, #0x18]
10024994c:     	cmp	x23, x8
100249950:     	b.hi	0x100249958 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x174c>
100249954:     	str	x23, [x19, #0x18]
100249958:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
10024995c:     	bfxil	x19, x0, #0, #48
100249960:     	ldr	x8, [sp, #0x188]
100249964:     	cmn	x8, #0x1
100249968:     	b.eq	0x1002499dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
10024996c:     	cbz	x8, 0x100249978 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x176c>
100249970:     	ldr	x0, [sp, #0x190]
100249974:     	bl	0x100b63d40 <_mi_free>
100249978:     	ldr	x8, [sp, #0x1a0]
10024997c:     	cbz	x8, 0x100249988 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x177c>
100249980:     	ldr	x0, [sp, #0x1a8]
100249984:     	bl	0x100b63d40 <_mi_free>
100249988:     	ldr	x20, [sp, #0x1b8]
10024998c:     	cmn	x20, #0x1
100249990:     	b.eq	0x1002499dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
100249994:     	ldr	x9, [sp, #0x1d8]
100249998:     	cbz	x9, 0x1002499bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17b0>
10024999c:     	lsl	x8, x9, #4
1002499a0:     	add	x9, x8, x9
1002499a4:     	cmn	x9, #0x19
1002499a8:     	b.eq	0x1002499bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17b0>
1002499ac:     	ldr	x9, [sp, #0x1d0]
1002499b0:     	sub	x8, x9, x8
1002499b4:     	sub	x0, x8, #0x10
1002499b8:     	bl	0x100b63d40 <_mi_free>
1002499bc:     	cbz	x20, 0x1002499dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
1002499c0:     	ldr	x0, [sp, #0x1c0]
1002499c4:     	bl	0x100b63d40 <_mi_free>
1002499c8:     	b	0x1002499dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
1002499cc:     	str	x11, [x0, #0x70]
1002499d0:     	mov	x19, #0x2               ; =2
1002499d4:     	movk	x19, #0x7ffc, lsl #48
1002499d8:     	strb	wzr, [x0, #0xd4]
1002499dc:     	mov	x0, x19
1002499e0:     	add	sp, sp, #0x240
1002499e4:     	ldp	x29, x30, [sp, #0x50]
1002499e8:     	ldp	x20, x19, [sp, #0x40]
1002499ec:     	ldp	x22, x21, [sp, #0x30]
1002499f0:     	ldp	x24, x23, [sp, #0x20]
1002499f4:     	ldp	x26, x25, [sp, #0x10]
1002499f8:     	ldp	x28, x27, [sp], #0x60
1002499fc:     	ret
100249a00:     	ldr	x9, [x8, #0x88]
100249a04:     	ldr	x10, [sp, #0x108]
100249a08:     	cmp	x9, x10
100249a0c:     	b.ne	0x100249804 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
100249a10:     	cmp	x28, #0x2
100249a14:     	b.eq	0x100249908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
100249a18:     	ldr	x9, [x8, #0x90]
100249a1c:     	ldr	x10, [sp, #0x110]
100249a20:     	cmp	x9, x10
100249a24:     	b.ne	0x100249804 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
100249a28:     	cmp	x28, #0x3
100249a2c:     	b.eq	0x100249908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
100249a30:     	ldr	x9, [x8, #0x98]
100249a34:     	ldr	x10, [sp, #0x118]
100249a38:     	cmp	x9, x10
100249a3c:     	b.ne	0x100249804 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
100249a40:     	cmp	x28, #0x4
100249a44:     	b.eq	0x100249908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
100249a48:     	ldr	x9, [x8, #0xa0]
100249a4c:     	ldr	x10, [sp, #0x120]
100249a50:     	cmp	x9, x10
100249a54:     	b.ne	0x100249804 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
100249a58:     	cmp	x28, #0x5
100249a5c:     	b.eq	0x100249908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
100249a60:     	ldr	x9, [x8, #0xa8]
100249a64:     	ldr	x10, [sp, #0x128]
100249a68:     	cmp	x9, x10
100249a6c:     	b.ne	0x100249804 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
100249a70:     	cmp	x28, #0x6
100249a74:     	b.eq	0x100249908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
100249a78:     	ldr	x9, [x8, #0xb0]
100249a7c:     	ldr	x10, [sp, #0x130]
100249a80:     	cmp	x9, x10
100249a84:     	b.ne	0x100249804 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
100249a88:     	cmp	x28, #0x7
100249a8c:     	b.eq	0x100249908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
100249a90:     	ldr	x9, [x8, #0xb8]
100249a94:     	ldr	x10, [sp, #0x138]
100249a98:     	cmp	x9, x10
100249a9c:     	b.ne	0x100249804 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
100249aa0:     	b	0x100249908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
100249aa4:     	sub	x8, x1, x15
100249aa8:     	str	x8, [x0, #0x70]
100249aac:     	cmp	w17, #0x65
100249ab0:     	b.ne	0x100249ac0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x18b4>
100249ab4:     	cmn	x15, #0x1
100249ab8:     	b.ne	0x10024941c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
100249abc:     	b	0x1002499d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100249ac0:     	cmn	x15, #0x1
100249ac4:     	b.eq	0x1002499d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100249ac8:     	subs	x16, x1, x10
100249acc:     	b.eq	0x10024941c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
100249ad0:     	cmp	w17, #0x45
100249ad4:     	b.eq	0x10024941c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
100249ad8:     	sub	x15, x8, x11
100249adc:     	cmp	x15, #0x9
100249ae0:     	b.hi	0x10024941c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
100249ae4:     	add	x17, x16, x15
100249ae8:     	cmp	x17, #0x11
100249aec:     	b.hi	0x10024941c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
100249af0:     	cmp	x1, x10
100249af4:     	b.lo	0x100249cfc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1af0>
100249af8:     	mov	x10, #0x0               ; =0
100249afc:     	b.eq	0x100249b1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1910>
100249b00:     	mov	w17, #0xa               ; =10
100249b04:     	ldrb	w3, [x14], #0x1
100249b08:     	mul	x10, x10, x17
100249b0c:     	sub	w3, w3, #0x30
100249b10:     	add	x10, x10, w3, uxtb
100249b14:     	subs	x16, x16, #0x1
100249b18:     	b.ne	0x100249b04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x18f8>
100249b1c:     	cmp	x8, x1
100249b20:     	b.ls	0x100249d0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b00>
100249b24:     	cmp	x8, x2
100249b28:     	b.hi	0x100249d0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b00>
100249b2c:     	mov	w14, #0xa               ; =10
100249b30:     	ldrb	w16, [x12, x11]
100249b34:     	mul	x10, x10, x14
100249b38:     	sub	w16, w16, #0x30
100249b3c:     	add	x10, x10, w16, uxtb
100249b40:     	add	x11, x11, #0x1
100249b44:     	cmp	x8, x11
100249b48:     	b.ne	0x100249b30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1924>
100249b4c:     	mov	x11, #0x20000000000000  ; =9007199254740992
100249b50:     	cmp	x10, x11
100249b54:     	b.hi	0x10024941c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
100249b58:     	ucvtf	d0, x10
100249b5c:     	adrp	x8, 0x100c4b000 <_PERRY_EMPTY_STRING+0x4cf4>
100249b60:     	add	x8, x8, #0x230
100249b64:     	ldr	d1, [x8, x15, lsl #3]
100249b68:     	fdiv	d0, d0, d1
100249b6c:     	b	0x100248690 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x484>
100249b70:     	ldr	x1, [sp, #0x38]
100249b74:     	b	0x1002493c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11b4>
100249b78:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100249b7c:     	add	x3, x3, #0x710
100249b80:     	mov	x0, #0x0                ; =0
100249b84:     	mov	x1, x28
100249b88:     	mov	w2, #0x8                ; =8
100249b8c:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100249b90:     	cmp	w8, #0x2
100249b94:     	b.eq	0x100249c9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a90>
100249b98:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
100249b9c:     	add	x1, x1, #0x898
100249ba0:     	mov	x0, x19
100249ba4:     	bl	0x100a2519c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100249ba8:     	strb	wzr, [x19, #0x20]
100249bac:     	ldr	x8, [x19]
100249bb0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100249bb4:     	cmp	x8, x9
100249bb8:     	b.lo	0x10024835c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x150>
100249bbc:     	b	0x100249bec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19e0>
100249bc0:     	cmp	w8, #0x1
100249bc4:     	b.ne	0x100249c9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a90>
100249bc8:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
100249bcc:     	add	x1, x1, #0x898
100249bd0:     	mov	x0, x19
100249bd4:     	bl	0x100a2519c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100249bd8:     	strb	wzr, [x19, #0x20]
100249bdc:     	ldr	x8, [x19]
100249be0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100249be4:     	cmp	x8, x9
100249be8:     	b.lo	0x1002487c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x5b8>
100249bec:     	adrp	x0, 0x100efe000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100249bf0:     	add	x0, x0, #0x4a0
100249bf4:     	bl	0x100b1749c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100249bf8:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100249bfc:     	add	x3, x3, #0x5c0
100249c00:     	mov	x0, x19
100249c04:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100249c08:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100249c0c:     	add	x3, x3, #0x5a8
100249c10:     	mov	x0, x19
100249c14:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100249c18:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100249c1c:     	add	x3, x3, #0x590
100249c20:     	mov	x0, x19
100249c24:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100249c28:     	cmp	w8, #0x2
100249c2c:     	b.eq	0x100249c9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a90>
100249c30:     	mov	x20, x0
100249c34:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
100249c38:     	add	x1, x1, #0x898
100249c3c:     	mov	x0, x19
100249c40:     	bl	0x100a2519c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100249c44:     	strb	wzr, [x19, #0x20]
100249c48:     	mov	x0, x20
100249c4c:     	ldr	x8, [x19]
100249c50:     	cbz	x8, 0x100249948 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x173c>
100249c54:     	b	0x100249ce4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ad8>
100249c58:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100249c5c:     	add	x3, x3, #0x6f8
100249c60:     	mov	x0, #0x0                ; =0
100249c64:     	mov	x1, x28
100249c68:     	mov	w2, #0x8                ; =8
100249c6c:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100249c70:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100249c74:     	add	x3, x3, #0x620
100249c78:     	mov	x0, x19
100249c7c:     	mov	x1, x8
100249c80:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100249c84:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100249c88:     	add	x3, x3, #0x5d8
100249c8c:     	mov	x0, x10
100249c90:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100249c94:     	cmp	w8, #0x2
100249c98:     	b.ne	0x100249cc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ab4>
100249c9c:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100249ca0:     	add	x0, x0, #0xc18
100249ca4:     	bl	0x100b5d39c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100249ca8:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100249cac:     	add	x3, x3, #0x6b0
100249cb0:     	mov	x0, #0x0                ; =0
100249cb4:     	mov	x1, x28
100249cb8:     	mov	w2, #0x8                ; =8
100249cbc:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100249cc0:     	mov	x20, x0
100249cc4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
100249cc8:     	add	x1, x1, #0x898
100249ccc:     	mov	x0, x19
100249cd0:     	bl	0x100a2519c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100249cd4:     	strb	wzr, [x19, #0x20]
100249cd8:     	mov	x0, x20
100249cdc:     	ldr	x8, [x19]
100249ce0:     	cbz	x8, 0x100249524 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1318>
100249ce4:     	adrp	x0, 0x100efe000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100249ce8:     	add	x0, x0, #0x488
100249cec:     	bl	0x100b1746c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100249cf0:     	adrp	x0, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100249cf4:     	add	x0, x0, #0x668
100249cf8:     	bl	0x100b17530 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100249cfc:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100249d00:     	add	x3, x3, #0x608
100249d04:     	mov	x0, x10
100249d08:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100249d0c:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100249d10:     	add	x3, x3, #0x5f0
100249d14:     	mov	x0, x11
100249d18:     	mov	x1, x8
100249d1c:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100249d20:     	adrp	x2, 0x100efc000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100249d24:     	add	x2, x2, #0x800
100249d28:     	mov	x0, x26
100249d2c:     	mov	w1, #0x8                ; =8
100249d30:     	bl	0x100b175cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100249d34:     	adrp	x2, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100249d38:     	add	x2, x2, #0x6c8
100249d3c:     	mov	x0, x1
100249d40:     	ldr	x1, [sp, #0x20]
100249d44:     	bl	0x100b175cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100249d48:     	adrp	x2, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100249d4c:     	add	x2, x2, #0x6e0
100249d50:     	ldr	x1, [sp, #0x20]
100249d54:     	bl	0x100b175cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100249d58:     	adrp	x2, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100249d5c:     	add	x2, x2, #0x698
100249d60:     	mov	x0, x12
100249d64:     	mov	w1, #0x8                ; =8
100249d68:     	bl	0x100b175cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100249d6c:     	adrp	x2, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100249d70:     	add	x2, x2, #0x680
100249d74:     	mov	x0, x12
100249d78:     	mov	w1, #0x8                ; =8
100249d7c:     	bl	0x100b175cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100249d80:     	mov	w0, #0x8                ; =8
100249d84:     	mov	w1, #0x80               ; =128
100249d88:     	bl	0x100b170c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
