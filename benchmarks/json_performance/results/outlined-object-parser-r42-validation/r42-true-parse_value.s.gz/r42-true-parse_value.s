
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/outlined-object-parser-r42/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010024820c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_>:
10024820c:     	sub	sp, sp, #0x60
100248210:     	stp	x24, x23, [sp, #0x20]
100248214:     	stp	x22, x21, [sp, #0x30]
100248218:     	stp	x20, x19, [sp, #0x40]
10024821c:     	stp	x29, x30, [sp, #0x50]
100248220:     	add	x29, sp, #0x50
100248224:     	ldp	x2, x19, [x0, #0x68]
100248228:     	cmp	x19, x2
10024822c:     	b.hs	0x100248264 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x58>
100248230:     	ldr	x8, [x0, #0x60]
100248234:     	mov	x9, #0x2600             ; =9728
100248238:     	movk	x9, #0x1, lsl #32
10024823c:     	ldrb	w10, [x8, x19]
100248240:     	cmp	w10, #0x20
100248244:     	b.hi	0x100248264 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x58>
100248248:     	lsr	x10, x9, x10
10024824c:     	tbz	w10, #0x0, 0x100248264 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x58>
100248250:     	add	x19, x19, #0x1
100248254:     	str	x19, [x0, #0x70]
100248258:     	cmp	x2, x19
10024825c:     	b.ne	0x10024823c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x30>
100248260:     	b	0x10024895c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
100248264:     	cmp	x19, x2
100248268:     	b.hs	0x10024895c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
10024826c:     	ldr	x12, [x0, #0x60]
100248270:     	add	x9, x12, x19
100248274:     	ldrb	w8, [x9]
100248278:     	cmp	w8, #0x65
10024827c:     	b.le	0x1002482d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc4>
100248280:     	cmp	w8, #0x73
100248284:     	b.gt	0x1002483cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1c0>
100248288:     	cmp	w8, #0x66
10024828c:     	b.eq	0x100248438 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x22c>
100248290:     	cmp	w8, #0x6e
100248294:     	b.ne	0x100248420 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x214>
100248298:     	add	x1, x19, #0x4
10024829c:     	cmp	x1, x2
1002482a0:     	b.hi	0x10024895c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
1002482a4:     	cmn	x19, #0x5
1002482a8:     	b.hi	0x100248aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x89c>
1002482ac:     	ldr	w8, [x9]
1002482b0:     	mov	w9, #0x756e             ; =30062
1002482b4:     	movk	w9, #0x6c6c, lsl #16
1002482b8:     	cmp	w8, w9
1002482bc:     	b.ne	0x10024895c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
1002482c0:     	mov	x19, #0x2               ; =2
1002482c4:     	movk	x19, #0x7ffc, lsl #48
1002482c8:     	str	x1, [x0, #0x70]
1002482cc:     	b	0x100248968 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
1002482d0:     	cmp	w8, #0x22
1002482d4:     	b.eq	0x1002483f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1e8>
1002482d8:     	cmp	w8, #0x2d
1002482dc:     	b.eq	0x1002484bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x2b0>
1002482e0:     	cmp	w8, #0x5b
1002482e4:     	b.ne	0x100248420 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x214>
1002482e8:     	add	x8, x19, #0x1
1002482ec:     	str	x8, [x0, #0x70]
1002482f0:     	cmp	x8, x2
1002482f4:     	b.hs	0x100248324 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x118>
1002482f8:     	mov	x9, #0x2600             ; =9728
1002482fc:     	movk	x9, #0x1, lsl #32
100248300:     	ldrb	w10, [x12, x8]
100248304:     	cmp	w10, #0x20
100248308:     	b.hi	0x100248324 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x118>
10024830c:     	lsr	x10, x9, x10
100248310:     	tbz	w10, #0x0, 0x100248324 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x118>
100248314:     	add	x8, x8, #0x1
100248318:     	str	x8, [x0, #0x70]
10024831c:     	cmp	x2, x8
100248320:     	b.ne	0x100248300 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xf4>
100248324:     	mov	x20, x0
100248328:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10024832c:     	add	x0, x0, #0xce8
100248330:     	ldr	x8, [x0]
100248334:     	blr	x8
100248338:     	mov	x19, x0
10024833c:     	ldrb	w8, [x0, #0x20]
100248340:     	cbnz	w8, 0x100248a50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x844>
100248344:     	ldr	x8, [x19]
100248348:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10024834c:     	cmp	x8, x9
100248350:     	b.hs	0x100248a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x870>
100248354:     	mov	x0, x20
100248358:     	ldr	x1, [x19, #0x18]
10024835c:     	ldp	x8, x9, [x20, #0x68]
100248360:     	subs	x8, x8, x9
100248364:     	b.ls	0x100248524 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x318>
100248368:     	ldr	x10, [x0, #0x60]
10024836c:     	ldrb	w9, [x10, x9]
100248370:     	cmp	w9, #0x7b
100248374:     	b.ne	0x100248524 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x318>
100248378:     	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
10024837c:     	movk	x9, #0xaaab
100248380:     	umulh	x8, x8, x9
100248384:     	lsr	x8, x8, #6
100248388:     	mov	w9, #0x10               ; =16
10024838c:     	cmp	x8, #0x10
100248390:     	csel	x8, x8, x9, hi
100248394:     	mov	w9, #0x4000             ; =16384
100248398:     	cmp	x8, #0x4, lsl #12       ; =0x4000
10024839c:     	csel	x2, x8, x9, lo
1002483a0:     	mov	x19, x0
1002483a4:     	add	x0, sp, #0x8
1002483a8:     	mov	x20, x1
1002483ac:     	add	x1, x19, #0x20
1002483b0:     	bl	0x1002359d0 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray3new>
1002483b4:     	add	x1, sp, #0x8
1002483b8:     	mov	x0, x19
1002483bc:     	mov	x2, x20
1002483c0:     	bl	0x100248b0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E16parse_array_tailB9_>
1002483c4:     	mov	x19, x0
1002483c8:     	b	0x100248968 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
1002483cc:     	cmp	w8, #0x74
1002483d0:     	b.eq	0x100248480 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x274>
1002483d4:     	cmp	w8, #0x7b
1002483d8:     	b.ne	0x100248420 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x214>
1002483dc:     	ldp	x29, x30, [sp, #0x50]
1002483e0:     	ldp	x20, x19, [sp, #0x40]
1002483e4:     	ldp	x22, x21, [sp, #0x30]
1002483e8:     	ldp	x24, x23, [sp, #0x20]
1002483ec:     	add	sp, sp, #0x60
1002483f0:     	b	0x1002496e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E20parse_object_untypedB9_>
1002483f4:     	ldr	x8, [x0]
1002483f8:     	cmp	x8, #0x1
1002483fc:     	b.ne	0x10024853c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x330>
100248400:     	ldr	x8, [x0, #0x8]
100248404:     	cmp	x8, x19
100248408:     	b.ne	0x10024853c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x330>
10024840c:     	ldp	x9, x8, [x0, #0x10]
100248410:     	str	x9, [x0, #0x70]
100248414:     	mov	x19, #0x7fff000000000000 ; =9223090561878065152
100248418:     	bfxil	x19, x8, #0, #48
10024841c:     	b	0x100248968 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
100248420:     	sub	w8, w8, #0x30
100248424:     	cmp	w8, #0x9
100248428:     	b.hi	0x10024895c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
10024842c:     	mov	w13, #0x0               ; =0
100248430:     	mov	x10, x19
100248434:     	b	0x1002484c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x2bc>
100248438:     	add	x1, x19, #0x5
10024843c:     	cmp	x1, x2
100248440:     	b.hi	0x10024895c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
100248444:     	cmn	x19, #0x6
100248448:     	b.hi	0x100248a88 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x87c>
10024844c:     	ldrb	w8, [x9, #0x4]
100248450:     	ldr	w9, [x9]
100248454:     	orr	x8, x9, x8, lsl #32
100248458:     	mov	x9, #0x6166             ; =24934
10024845c:     	movk	x9, #0x736c, lsl #16
100248460:     	movk	x9, #0x65, lsl #32
100248464:     	cmp	x8, x9
100248468:     	b.ne	0x10024895c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
10024846c:     	str	x1, [x0, #0x70]
100248470:     	mov	x8, #0x2                ; =2
100248474:     	movk	x8, #0x7ffc, lsl #48
100248478:     	orr	x19, x8, #0x1
10024847c:     	b	0x100248968 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
100248480:     	add	x1, x19, #0x4
100248484:     	cmp	x1, x2
100248488:     	b.hi	0x10024895c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
10024848c:     	cmn	x19, #0x5
100248490:     	b.hi	0x100248a98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x88c>
100248494:     	ldr	w8, [x9]
100248498:     	mov	w9, #0x7274             ; =29300
10024849c:     	movk	w9, #0x6575, lsl #16
1002484a0:     	cmp	w8, w9
1002484a4:     	b.ne	0x10024895c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
1002484a8:     	str	x1, [x0, #0x70]
1002484ac:     	mov	x8, #0x2                ; =2
1002484b0:     	movk	x8, #0x7ffc, lsl #48
1002484b4:     	add	x19, x8, #0x2
1002484b8:     	b	0x100248968 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
1002484bc:     	add	x10, x19, #0x1
1002484c0:     	str	x10, [x0, #0x70]
1002484c4:     	mov	w13, #0x1               ; =1
1002484c8:     	cmp	x10, x2
1002484cc:     	b.hs	0x10024895c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
1002484d0:     	add	x14, x12, x10
1002484d4:     	ldrb	w8, [x14]
1002484d8:     	cmp	w8, #0x30
1002484dc:     	b.ne	0x100248568 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x35c>
1002484e0:     	add	x1, x10, #0x1
1002484e4:     	str	x1, [x0, #0x70]
1002484e8:     	cmp	x1, x2
1002484ec:     	b.hs	0x1002485a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x394>
1002484f0:     	ldrb	w8, [x12, x1]
1002484f4:     	sub	w8, w8, #0x30
1002484f8:     	cmp	w8, #0x9
1002484fc:     	b.hi	0x1002485a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x394>
100248500:     	ldrb	w8, [x12, x1]
100248504:     	sub	w8, w8, #0x30
100248508:     	cmp	w8, #0xa
10024850c:     	b.hs	0x10024895c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
100248510:     	add	x1, x1, #0x1
100248514:     	str	x1, [x0, #0x70]
100248518:     	cmp	x2, x1
10024851c:     	b.ne	0x100248500 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x2f4>
100248520:     	b	0x10024895c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
100248524:     	ldp	x29, x30, [sp, #0x50]
100248528:     	ldp	x20, x19, [sp, #0x40]
10024852c:     	ldp	x22, x21, [sp, #0x30]
100248530:     	ldp	x24, x23, [sp, #0x20]
100248534:     	add	sp, sp, #0x60
100248538:     	b	0x100248f8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E18parse_array_prefixB9_>
10024853c:     	mov	x1, x0
100248540:     	add	x0, sp, #0x8
100248544:     	mov	x24, x1
100248548:     	bl	0x1002458b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_bytesB9_>
10024854c:     	ldr	x22, [sp, #0x8]
100248550:     	cmn	x22, #0x2
100248554:     	b.ne	0x10024861c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x410>
100248558:     	mov	x19, #0x2               ; =2
10024855c:     	movk	x19, #0x7ffc, lsl #48
100248560:     	strb	wzr, [x24, #0xd4]
100248564:     	b	0x100248968 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
100248568:     	sub	w8, w8, #0x31
10024856c:     	cmp	w8, #0x8
100248570:     	b.hi	0x10024895c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
100248574:     	mov	x1, x10
100248578:     	ldrb	w8, [x12, x1]
10024857c:     	sub	w8, w8, #0x30
100248580:     	cmp	w8, #0x9
100248584:     	b.hi	0x1002485a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x394>
100248588:     	add	x1, x1, #0x1
10024858c:     	str	x1, [x0, #0x70]
100248590:     	cmp	x2, x1
100248594:     	b.ne	0x100248578 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x36c>
100248598:     	mov	x1, x2
10024859c:     	b	0x1002485c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x3bc>
1002485a0:     	subs	x8, x1, x2
1002485a4:     	b.hs	0x1002485c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x3bc>
1002485a8:     	ldrb	w11, [x12, x1]
1002485ac:     	cmp	w11, #0x2e
1002485b0:     	b.eq	0x1002487f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x5e8>
1002485b4:     	cmp	w11, #0x45
1002485b8:     	b.eq	0x1002486d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4c8>
1002485bc:     	mov	x8, x1
1002485c0:     	cmp	w11, #0x65
1002485c4:     	b.eq	0x1002486d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4cc>
1002485c8:     	subs	x8, x1, x10
1002485cc:     	ccmp	x8, #0x13, #0x2, ne
1002485d0:     	b.hs	0x1002486d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4c8>
1002485d4:     	cmp	x1, x10
1002485d8:     	b.lo	0x100248ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8cc>
1002485dc:     	cmp	x1, x2
1002485e0:     	b.hi	0x100248ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8cc>
1002485e4:     	mov	x9, #0x0                ; =0
1002485e8:     	mov	w10, #0xa               ; =10
1002485ec:     	ldrb	w11, [x14], #0x1
1002485f0:     	mul	x9, x9, x10
1002485f4:     	sub	w11, w11, #0x30
1002485f8:     	add	x9, x9, w11, uxtb
1002485fc:     	subs	x8, x8, #0x1
100248600:     	b.ne	0x1002485ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x3e0>
100248604:     	ucvtf	d0, x9
100248608:     	fneg	d1, d0
10024860c:     	cmp	w13, #0x0
100248610:     	fcsel	d0, d1, d0, ne
100248614:     	fmov	x19, d0
100248618:     	b	0x100248968 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
10024861c:     	ldp	x21, x20, [sp, #0x10]
100248620:     	cmp	x20, #0x6
100248624:     	b.hs	0x1002486b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4a8>
100248628:     	subs	x8, x20, #0x3
10024862c:     	b.lo	0x10024878c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x580>
100248630:     	ldrb	w9, [x21]
100248634:     	cmp	w9, #0xed
100248638:     	b.ne	0x100248658 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x44c>
10024863c:     	ldrb	w9, [x21, #0x1]
100248640:     	and	w9, w9, #0xe0
100248644:     	cmp	w9, #0xa0
100248648:     	b.ne	0x100248658 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x44c>
10024864c:     	ldrsb	w9, [x21, #0x2]
100248650:     	cmn	w9, #0x40
100248654:     	b.lt	0x1002486b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4a8>
100248658:     	cbz	x8, 0x10024878c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x580>
10024865c:     	ldrb	w9, [x21, #0x1]
100248660:     	cmp	w9, #0xed
100248664:     	b.ne	0x100248684 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x478>
100248668:     	ldrb	w9, [x21, #0x2]
10024866c:     	and	w9, w9, #0xe0
100248670:     	cmp	w9, #0xa0
100248674:     	b.ne	0x100248684 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x478>
100248678:     	ldrsb	w9, [x21, #0x3]
10024867c:     	cmn	w9, #0x40
100248680:     	b.lt	0x1002486b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4a8>
100248684:     	cmp	x8, #0x1
100248688:     	b.eq	0x10024878c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x580>
10024868c:     	ldrb	w8, [x21, #0x2]
100248690:     	cmp	w8, #0xed
100248694:     	b.ne	0x10024878c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x580>
100248698:     	ldrb	w8, [x21, #0x3]
10024869c:     	and	w8, w8, #0xe0
1002486a0:     	cmp	w8, #0xa0
1002486a4:     	b.ne	0x10024878c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x580>
1002486a8:     	ldrsb	w8, [x21, #0x4]
1002486ac:     	cmn	w8, #0x40
1002486b0:     	b.ge	0x10024878c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x580>
1002486b4:     	cmn	x22, #0x1
1002486b8:     	b.eq	0x1002487b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x5a4>
1002486bc:     	mov	x0, x21
1002486c0:     	mov	x1, x20
1002486c4:     	bl	0x10034e1b0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
1002486c8:     	mov	x19, #0x7fff000000000000 ; =9223090561878065152
1002486cc:     	bfxil	x19, x0, #0, #48
1002486d0:     	b	0x100248904 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f8>
1002486d4:     	mov	x8, x1
1002486d8:     	cmp	x8, x2
1002486dc:     	b.hs	0x100248754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x548>
1002486e0:     	ldrb	w10, [x12, x8]
1002486e4:     	orr	w10, w10, #0x20
1002486e8:     	cmp	w10, #0x65
1002486ec:     	b.ne	0x100248754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x548>
1002486f0:     	add	x10, x8, #0x1
1002486f4:     	str	x10, [x0, #0x70]
1002486f8:     	cmp	x10, x2
1002486fc:     	b.hs	0x10024871c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x510>
100248700:     	ldrb	w11, [x12, x10]
100248704:     	cmp	w11, #0x2d
100248708:     	b.eq	0x100248714 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x508>
10024870c:     	cmp	w11, #0x2b
100248710:     	b.ne	0x10024871c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x510>
100248714:     	add	x10, x8, #0x2
100248718:     	str	x10, [x0, #0x70]
10024871c:     	cmp	x10, x2
100248720:     	b.hs	0x10024895c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
100248724:     	mov	x8, x10
100248728:     	ldrb	w11, [x12, x8]
10024872c:     	sub	w11, w11, #0x30
100248730:     	cmp	w11, #0x9
100248734:     	b.hi	0x10024874c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x540>
100248738:     	add	x8, x8, #0x1
10024873c:     	str	x8, [x0, #0x70]
100248740:     	cmp	x2, x8
100248744:     	b.ne	0x100248728 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x51c>
100248748:     	mov	x8, x2
10024874c:     	cmp	x8, x10
100248750:     	b.eq	0x10024895c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
100248754:     	subs	x1, x8, x19
100248758:     	b.lo	0x100248ab8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8ac>
10024875c:     	cmp	x8, x2
100248760:     	b.hi	0x100248ab8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8ac>
100248764:     	mov	x20, x0
100248768:     	add	x8, sp, #0x8
10024876c:     	mov	x0, x9
100248770:     	bl	0x1000334ac <__RNvXs2_NtNtCsjgY6bXVaRmE_4core3num11float_parsedNtNtNtB9_3str6traits7FromStr8from_str>
100248774:     	ldrb	w8, [sp, #0x8]
100248778:     	tbz	w8, #0x0, 0x1002487a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x59c>
10024877c:     	mov	x19, #0x2               ; =2
100248780:     	movk	x19, #0x7ffc, lsl #48
100248784:     	strb	wzr, [x20, #0xd4]
100248788:     	b	0x100248968 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
10024878c:     	cbz	x20, 0x100248840 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x634>
100248790:     	cmp	x20, #0x4
100248794:     	b.hs	0x100248848 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x63c>
100248798:     	mov	x10, #0x0               ; =0
10024879c:     	mov	x9, #0x0                ; =0
1002487a0:     	mov	x8, x21
1002487a4:     	b	0x1002488d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6cc>
1002487a8:     	ldr	x19, [sp, #0x10]
1002487ac:     	b	0x100248968 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
1002487b0:     	ldr	x22, [x24, #0x68]
1002487b4:     	sub	x9, x22, x20
1002487b8:     	cmp	x9, #0x101
1002487bc:     	mov	w9, #0xff               ; =255
1002487c0:     	ccmp	x20, x9, #0x0, lo
1002487c4:     	b.ls	0x100248918 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x70c>
1002487c8:     	ldr	x1, [x24, #0x60]
1002487cc:     	ldr	x23, [x24, #0xc8]
1002487d0:     	add	x0, x24, #0x20
1002487d4:     	mov	x2, x22
1002487d8:     	mov	x3, x23
1002487dc:     	mov	x4, x19
1002487e0:     	mov	x5, x21
1002487e4:     	mov	x6, x20
1002487e8:     	bl	0x1006ca50c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token>
1002487ec:     	mov	x21, x0
1002487f0:     	b	0x100248930 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x724>
1002487f4:     	add	x11, x1, #0x1
1002487f8:     	cmp	x11, x2
1002487fc:     	b.hs	0x100248958 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x74c>
100248800:     	add	x16, x12, #0x1
100248804:     	mov	x15, #-0x1              ; =-1
100248808:     	ldrb	w17, [x16, x1]
10024880c:     	sub	w3, w17, #0x30
100248810:     	cmp	w3, #0x9
100248814:     	b.hi	0x100248984 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
100248818:     	add	x16, x16, #0x1
10024881c:     	sub	x15, x15, #0x1
100248820:     	cmp	x8, x15
100248824:     	b.ne	0x100248808 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x5fc>
100248828:     	str	x2, [x0, #0x70]
10024882c:     	mov	x8, x2
100248830:     	subs	x16, x1, x10
100248834:     	b.eq	0x100248754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x548>
100248838:     	mov	x8, x2
10024883c:     	b	0x1002489b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x7ac>
100248840:     	mov	x10, #0x0               ; =0
100248844:     	b	0x1002488f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6ec>
100248848:     	and	x9, x20, #0x4
10024884c:     	add	x8, x21, x9
100248850:     	adrp	x10, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4fb0>
100248854:     	ldr	q0, [x10, #0x8c0]
100248858:     	adrp	x10, 0x100c3e000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x338ba>
10024885c:     	ldr	q2, [x10, #0x6c0]
100248860:     	movi.2d	v1, #0000000000000000
100248864:     	movi.2d	v3, #0x000000000000ff
100248868:     	mov	w10, #0x4               ; =4
10024886c:     	dup.2d	v4, x10
100248870:     	mov	x10, x21
100248874:     	and	x11, x20, #0x4
100248878:     	movi.2d	v5, #0000000000000000
10024887c:     	ldr	s6, [x10], #0x4
100248880:     	ushll.8h	v6, v6, #0x0
100248884:     	ushll.4s	v6, v6, #0x0
100248888:     	ushll2.2d	v7, v6, #0x0
10024888c:     	and.16b	v7, v7, v3
100248890:     	ushll.2d	v6, v6, #0x0
100248894:     	and.16b	v6, v6, v3
100248898:     	shl.2d	v16, v0, #0x3
10024889c:     	shl.2d	v17, v2, #0x3
1002488a0:     	ushl.2d	v6, v6, v17
1002488a4:     	ushl.2d	v7, v7, v16
1002488a8:     	orr.16b	v1, v7, v1
1002488ac:     	orr.16b	v5, v6, v5
1002488b0:     	add.2d	v0, v0, v4
1002488b4:     	add.2d	v2, v2, v4
1002488b8:     	subs	x11, x11, #0x4
1002488bc:     	b.ne	0x10024887c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x670>
1002488c0:     	orr.16b	v0, v5, v1
1002488c4:     	mov	d1, v0[1]
1002488c8:     	orr.8b	v0, v0, v1
1002488cc:     	fmov	x10, d0
1002488d0:     	cmp	x20, x9
1002488d4:     	b.eq	0x1002488f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6ec>
1002488d8:     	add	x11, x21, x20
1002488dc:     	lsl	x9, x9, #3
1002488e0:     	ldrb	w12, [x8], #0x1
1002488e4:     	lsl	x12, x12, x9
1002488e8:     	orr	x10, x12, x10
1002488ec:     	add	x9, x9, #0x8
1002488f0:     	cmp	x8, x11
1002488f4:     	b.ne	0x1002488e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6d4>
1002488f8:     	orr	x8, x10, x20, lsl #40
1002488fc:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100248900:     	orr	x19, x8, x9
100248904:     	cmp	x22, #0x1
100248908:     	b.lt	0x100248968 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
10024890c:     	mov	x0, x21
100248910:     	bl	0x100b63d40 <_mi_free>
100248914:     	b	0x100248968 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
100248918:     	add	x0, x24, #0x20
10024891c:     	mov	x1, x21
100248920:     	mov	x2, x20
100248924:     	bl	0x1005ee804 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction30string_from_scanned_json_bytes>
100248928:     	mov	x21, x0
10024892c:     	ldr	x23, [x24, #0xc8]
100248930:     	ldr	x3, [x24, #0x70]
100248934:     	mov	x0, x23
100248938:     	mov	x1, x22
10024893c:     	mov	x2, x19
100248940:     	mov	x4, x21
100248944:     	mov	x5, x20
100248948:     	bl	0x1004efaec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21remember_parse_string>
10024894c:     	mov	x19, #0x7fff000000000000 ; =9223090561878065152
100248950:     	bfxil	x19, x21, #0, #48
100248954:     	b	0x100248968 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x75c>
100248958:     	str	x11, [x0, #0x70]
10024895c:     	mov	x19, #0x2               ; =2
100248960:     	movk	x19, #0x7ffc, lsl #48
100248964:     	strb	wzr, [x0, #0xd4]
100248968:     	mov	x0, x19
10024896c:     	ldp	x29, x30, [sp, #0x50]
100248970:     	ldp	x20, x19, [sp, #0x40]
100248974:     	ldp	x22, x21, [sp, #0x30]
100248978:     	ldp	x24, x23, [sp, #0x20]
10024897c:     	add	sp, sp, #0x60
100248980:     	ret
100248984:     	sub	x8, x1, x15
100248988:     	str	x8, [x0, #0x70]
10024898c:     	cmp	w17, #0x65
100248990:     	b.ne	0x1002489a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x794>
100248994:     	cmn	x15, #0x1
100248998:     	b.ne	0x1002486d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4cc>
10024899c:     	b	0x10024895c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
1002489a0:     	cmn	x15, #0x1
1002489a4:     	b.eq	0x10024895c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x750>
1002489a8:     	subs	x16, x1, x10
1002489ac:     	b.eq	0x1002486d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4cc>
1002489b0:     	cmp	w17, #0x45
1002489b4:     	b.eq	0x1002486d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4cc>
1002489b8:     	sub	x15, x8, x11
1002489bc:     	cmp	x15, #0x9
1002489c0:     	b.hi	0x1002486d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4cc>
1002489c4:     	add	x17, x16, x15
1002489c8:     	cmp	x17, #0x11
1002489cc:     	b.hi	0x1002486d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4cc>
1002489d0:     	cmp	x1, x10
1002489d4:     	b.lo	0x100248ae8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8dc>
1002489d8:     	mov	x10, #0x0               ; =0
1002489dc:     	b.eq	0x1002489fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x7f0>
1002489e0:     	mov	w17, #0xa               ; =10
1002489e4:     	ldrb	w3, [x14], #0x1
1002489e8:     	mul	x10, x10, x17
1002489ec:     	sub	w3, w3, #0x30
1002489f0:     	add	x10, x10, w3, uxtb
1002489f4:     	subs	x16, x16, #0x1
1002489f8:     	b.ne	0x1002489e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x7d8>
1002489fc:     	cmp	x8, x1
100248a00:     	b.ls	0x100248af8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8ec>
100248a04:     	cmp	x8, x2
100248a08:     	b.hi	0x100248af8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8ec>
100248a0c:     	mov	w14, #0xa               ; =10
100248a10:     	ldrb	w16, [x12, x11]
100248a14:     	mul	x10, x10, x14
100248a18:     	sub	w16, w16, #0x30
100248a1c:     	add	x10, x10, w16, uxtb
100248a20:     	add	x11, x11, #0x1
100248a24:     	cmp	x8, x11
100248a28:     	b.ne	0x100248a10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x804>
100248a2c:     	mov	x11, #0x20000000000000  ; =9007199254740992
100248a30:     	cmp	x10, x11
100248a34:     	b.hi	0x1002486d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4cc>
100248a38:     	ucvtf	d0, x10
100248a3c:     	adrp	x8, 0x100c4b000 <_PERRY_EMPTY_STRING+0x4cf4>
100248a40:     	add	x8, x8, #0x230
100248a44:     	ldr	d1, [x8, x15, lsl #3]
100248a48:     	fdiv	d0, d0, d1
100248a4c:     	b	0x100248608 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x3fc>
100248a50:     	cmp	w8, #0x1
100248a54:     	b.ne	0x100248acc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8c0>
100248a58:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
100248a5c:     	add	x1, x1, #0x898
100248a60:     	mov	x0, x19
100248a64:     	bl	0x100a2519c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100248a68:     	strb	wzr, [x19, #0x20]
100248a6c:     	ldr	x8, [x19]
100248a70:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100248a74:     	cmp	x8, x9
100248a78:     	b.lo	0x100248354 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x148>
100248a7c:     	adrp	x0, 0x100efe000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100248a80:     	add	x0, x0, #0x4a0
100248a84:     	bl	0x100b1749c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100248a88:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100248a8c:     	add	x3, x3, #0x5c0
100248a90:     	mov	x0, x19
100248a94:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100248a98:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100248a9c:     	add	x3, x3, #0x5a8
100248aa0:     	mov	x0, x19
100248aa4:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100248aa8:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100248aac:     	add	x3, x3, #0x590
100248ab0:     	mov	x0, x19
100248ab4:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100248ab8:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100248abc:     	add	x3, x3, #0x620
100248ac0:     	mov	x0, x19
100248ac4:     	mov	x1, x8
100248ac8:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100248acc:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100248ad0:     	add	x0, x0, #0xc18
100248ad4:     	bl	0x100b5d39c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100248ad8:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100248adc:     	add	x3, x3, #0x5d8
100248ae0:     	mov	x0, x10
100248ae4:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100248ae8:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100248aec:     	add	x3, x3, #0x608
100248af0:     	mov	x0, x10
100248af4:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100248af8:     	adrp	x3, 0x100f09000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100248afc:     	add	x3, x3, #0x5f0
100248b00:     	mov	x0, x11
100248b04:     	mov	x1, x8
100248b08:     	bl	0x100b1778c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
