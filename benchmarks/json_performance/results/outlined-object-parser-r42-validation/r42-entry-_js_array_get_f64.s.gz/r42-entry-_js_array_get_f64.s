
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/outlined-object-parser-r42/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007c26d0 <_js_array_get_f64>:
1007c26d0:     	sub	sp, sp, #0x70
1007c26d4:     	stp	x26, x25, [sp, #0x20]
1007c26d8:     	stp	x24, x23, [sp, #0x30]
1007c26dc:     	stp	x22, x21, [sp, #0x40]
1007c26e0:     	stp	x20, x19, [sp, #0x50]
1007c26e4:     	stp	x29, x30, [sp, #0x60]
1007c26e8:     	add	x29, sp, #0x60
1007c26ec:     	mov	x19, x1
1007c26f0:     	mov	x22, x0
1007c26f4:     	lsr	x25, x0, #51
1007c26f8:     	mov	x20, x0
1007c26fc:     	cmp	x25, #0xfff
1007c2700:     	b.lo	0x1007c271c <_js_array_get_f64+0x4c>
1007c2704:     	mov	w8, #0x7ffc             ; =32764
1007c2708:     	cmp	x8, x22, lsr #48
1007c270c:     	b.ne	0x1007c2718 <_js_array_get_f64+0x48>
1007c2710:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007c2714:     	b	0x1007c2dc8 <_js_array_get_f64+0x6f8>
1007c2718:     	and	x20, x22, #0xffffffffffff
1007c271c:     	lsr	x8, x20, #3
1007c2720:     	cmp	x8, #0x200
1007c2724:     	b.ls	0x1007c275c <_js_array_get_f64+0x8c>
1007c2728:     	ldurb	w8, [x20, #-0x8]
1007c272c:     	cmp	w8, #0x9
1007c2730:     	b.ne	0x1007c275c <_js_array_get_f64+0x8c>
1007c2734:     	ldr	w8, [x20, #0x4]
1007c2738:     	mov	w9, #0x5841             ; =22593
1007c273c:     	movk	w9, #0x4c5a, lsl #16
1007c2740:     	cmp	w8, w9
1007c2744:     	b.ne	0x1007c275c <_js_array_get_f64+0x8c>
1007c2748:     	mov	x0, x20
1007c274c:     	mov	x1, x19
1007c2750:     	bl	0x10068b804 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get>
1007c2754:     	fmov	d0, x0
1007c2758:     	b	0x1007c2dcc <_js_array_get_f64+0x6fc>
1007c275c:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007c2760:     	b.lo	0x1007c2810 <_js_array_get_f64+0x140>
1007c2764:     	tst	x20, #0xffff800000000000
1007c2768:     	mov	w8, #0x1000             ; =4096
1007c276c:     	ccmp	x20, x8, #0x0, eq
1007c2770:     	b.lo	0x1007c2810 <_js_array_get_f64+0x140>
1007c2774:     	ldurb	w24, [x20, #-0x8]
1007c2778:     	ldurh	w23, [x20, #-0x6]
1007c277c:     	cmp	w24, #0xa
1007c2780:     	b.gt	0x1007c2928 <_js_array_get_f64+0x258>
1007c2784:     	cmp	w24, #0x2
1007c2788:     	b.eq	0x1007c29b0 <_js_array_get_f64+0x2e0>
1007c278c:     	cmp	w24, #0x8
1007c2790:     	b.ne	0x1007c2818 <_js_array_get_f64+0x148>
1007c2794:     	mov	x0, x20
1007c2798:     	bl	0x100307b68 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007c279c:     	cbz	w0, 0x1007c2a40 <_js_array_get_f64+0x370>
1007c27a0:     	mov	x22, #0x1               ; =1
1007c27a4:     	movk	x22, #0x7ffc, lsl #48
1007c27a8:     	lsr	x8, x20, #51
1007c27ac:     	cmp	x8, #0xfff
1007c27b0:     	b.lo	0x1007c27c4 <_js_array_get_f64+0xf4>
1007c27b4:     	mov	w8, #0x7ffc             ; =32764
1007c27b8:     	cmp	x8, x20, lsr #48
1007c27bc:     	b.eq	0x1007c2dc8 <_js_array_get_f64+0x6f8>
1007c27c0:     	and	x20, x20, #0xffffffffffff
1007c27c4:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007c27c8:     	b.lo	0x1007c27e8 <_js_array_get_f64+0x118>
1007c27cc:     	tst	x20, #0xffff800000000000
1007c27d0:     	mov	w8, #0x1000             ; =4096
1007c27d4:     	ccmp	x20, x8, #0x0, eq
1007c27d8:     	b.lo	0x1007c27e8 <_js_array_get_f64+0x118>
1007c27dc:     	ldurb	w8, [x20, #-0x8]
1007c27e0:     	cmp	w8, #0x2
1007c27e4:     	b.eq	0x1007c30b4 <_js_array_get_f64+0x9e4>
1007c27e8:     	cbz	x20, 0x1007c2dc8 <_js_array_get_f64+0x6f8>
1007c27ec:     	mov	x0, x20
1007c27f0:     	mov	x1, x19
1007c27f4:     	bl	0x100307d18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007c27f8:     	cmp	w0, #0x1
1007c27fc:     	b.ne	0x1007c2dc8 <_js_array_get_f64+0x6f8>
1007c2800:     	ldr	x8, [x20, #0x8]
1007c2804:     	ubfiz	x9, x1, #4, #32
1007c2808:     	ldr	x22, [x8, x9]
1007c280c:     	b	0x1007c2dc8 <_js_array_get_f64+0x6f8>
1007c2810:     	mov	w23, #0x0               ; =0
1007c2814:     	mov	w24, #0x0               ; =0
1007c2818:     	mov	x21, x22
1007c281c:     	cmp	x25, #0xfff
1007c2820:     	b.lo	0x1007c2838 <_js_array_get_f64+0x168>
1007c2824:     	mov	w8, #0x7ffc             ; =32764
1007c2828:     	cmp	x8, x22, lsr #48
1007c282c:     	b.eq	0x1007c2db4 <_js_array_get_f64+0x6e4>
1007c2830:     	ands	x21, x22, #0xffffffffffff
1007c2834:     	b.eq	0x1007c2db4 <_js_array_get_f64+0x6e4>
1007c2838:     	and	x8, x21, #0xfffffffffff00000
1007c283c:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007c2840:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007c2844:     	cmp	x9, x10
1007c2848:     	ccmp	x8, #0x0, #0x4, lo
1007c284c:     	b.eq	0x1007c2db4 <_js_array_get_f64+0x6e4>
1007c2850:     	tst	x21, #0x3
1007c2854:     	ccmp	x21, #0x7, #0x0, eq
1007c2858:     	b.ls	0x1007c2b08 <_js_array_get_f64+0x438>
1007c285c:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2860:     	ldr	x8, [x8, #0x48]
1007c2864:     	cmn	x8, #0x1
1007c2868:     	b.eq	0x1007c2a58 <_js_array_get_f64+0x388>
1007c286c:     	mrs	x9, TPIDRRO_EL0
1007c2870:     	and	x9, x9, #0xfffffffffffffff8
1007c2874:     	ldr	x0, [x9, x8, lsl #3]
1007c2878:     	cbz	x0, 0x1007c2a58 <_js_array_get_f64+0x388>
1007c287c:     	lsr	x1, x21, #20
1007c2880:     	ldr	x8, [x0, #0x10]
1007c2884:     	ldrb	w9, [x8]
1007c2888:     	cmp	w9, #0x2
1007c288c:     	b.ne	0x1007c2a70 <_js_array_get_f64+0x3a0>
1007c2890:     	ldrb	w9, [x8, #0x88]
1007c2894:     	tbz	w9, #0x0, 0x1007c28b4 <_js_array_get_f64+0x1e4>
1007c2898:     	ldr	x9, [x8, #0x80]
1007c289c:     	cmp	x9, x1
1007c28a0:     	b.ne	0x1007c28b4 <_js_array_get_f64+0x1e4>
1007c28a4:     	ldp	x9, x10, [x8, #0x60]
1007c28a8:     	cmp	x9, x21
1007c28ac:     	ccmp	x10, x21, #0x0, ls
1007c28b0:     	b.hi	0x1007c2a50 <_js_array_get_f64+0x380>
1007c28b4:     	ldrb	w9, [x8, #0xb8]
1007c28b8:     	cbz	w9, 0x1007c28d8 <_js_array_get_f64+0x208>
1007c28bc:     	ldr	x9, [x8, #0xb0]
1007c28c0:     	cmp	x9, x1
1007c28c4:     	b.ne	0x1007c28d8 <_js_array_get_f64+0x208>
1007c28c8:     	ldp	x9, x10, [x8, #0x90]
1007c28cc:     	cmp	x9, x21
1007c28d0:     	ccmp	x10, x21, #0x0, ls
1007c28d4:     	b.hi	0x1007c2f18 <_js_array_get_f64+0x848>
1007c28d8:     	ldrb	w9, [x8, #0xe8]
1007c28dc:     	cbz	w9, 0x1007c28fc <_js_array_get_f64+0x22c>
1007c28e0:     	ldr	x9, [x8, #0xe0]
1007c28e4:     	cmp	x9, x1
1007c28e8:     	b.ne	0x1007c28fc <_js_array_get_f64+0x22c>
1007c28ec:     	ldp	x9, x10, [x8, #0xc0]
1007c28f0:     	cmp	x9, x21
1007c28f4:     	ccmp	x10, x21, #0x0, ls
1007c28f8:     	b.hi	0x1007c3000 <_js_array_get_f64+0x930>
1007c28fc:     	ldrb	w9, [x8, #0x118]
1007c2900:     	cbz	w9, 0x1007c2ad0 <_js_array_get_f64+0x400>
1007c2904:     	ldr	x9, [x8, #0x110]
1007c2908:     	cmp	x9, x1
1007c290c:     	b.ne	0x1007c2ad0 <_js_array_get_f64+0x400>
1007c2910:     	ldp	x9, x10, [x8, #0xf0]
1007c2914:     	cmp	x9, x21
1007c2918:     	ccmp	x10, x21, #0x0, ls
1007c291c:     	b.ls	0x1007c2ad0 <_js_array_get_f64+0x400>
1007c2920:     	add	x9, x8, #0xf0
1007c2924:     	b	0x1007c3004 <_js_array_get_f64+0x934>
1007c2928:     	cmp	w24, #0xb
1007c292c:     	b.eq	0x1007c29c8 <_js_array_get_f64+0x2f8>
1007c2930:     	cmp	w24, #0xc
1007c2934:     	b.ne	0x1007c2818 <_js_array_get_f64+0x148>
1007c2938:     	mov	x0, x20
1007c293c:     	bl	0x10030d8f8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007c2940:     	cbz	w0, 0x1007c2a48 <_js_array_get_f64+0x378>
1007c2944:     	mov	x22, #0x1               ; =1
1007c2948:     	movk	x22, #0x7ffc, lsl #48
1007c294c:     	lsr	x8, x20, #51
1007c2950:     	cmp	x8, #0xfff
1007c2954:     	b.lo	0x1007c2968 <_js_array_get_f64+0x298>
1007c2958:     	mov	w8, #0x7ffc             ; =32764
1007c295c:     	cmp	x8, x20, lsr #48
1007c2960:     	b.eq	0x1007c2dc8 <_js_array_get_f64+0x6f8>
1007c2964:     	and	x20, x20, #0xffffffffffff
1007c2968:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007c296c:     	b.lo	0x1007c298c <_js_array_get_f64+0x2bc>
1007c2970:     	tst	x20, #0xffff800000000000
1007c2974:     	mov	w8, #0x1000             ; =4096
1007c2978:     	ccmp	x20, x8, #0x0, eq
1007c297c:     	b.lo	0x1007c298c <_js_array_get_f64+0x2bc>
1007c2980:     	ldurb	w8, [x20, #-0x8]
1007c2984:     	cmp	w8, #0x2
1007c2988:     	b.eq	0x1007c30cc <_js_array_get_f64+0x9fc>
1007c298c:     	cbz	x20, 0x1007c2dc8 <_js_array_get_f64+0x6f8>
1007c2990:     	mov	x0, x20
1007c2994:     	mov	x1, x19
1007c2998:     	bl	0x10030f570 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007c299c:     	cmp	w0, #0x1
1007c29a0:     	b.ne	0x1007c2dc8 <_js_array_get_f64+0x6f8>
1007c29a4:     	ldr	x8, [x20, #0x8]
1007c29a8:     	ldr	x22, [x8, w1, uxtw #3]
1007c29ac:     	b	0x1007c2dc8 <_js_array_get_f64+0x6f8>
1007c29b0:     	mov	x0, x22
1007c29b4:     	mov	x1, x19
1007c29b8:     	bl	0x10054b4cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007c29bc:     	tbnz	w0, #0x0, 0x1007c2dc4 <_js_array_get_f64+0x6f4>
1007c29c0:     	mov	w24, #0x2               ; =2
1007c29c4:     	b	0x1007c2818 <_js_array_get_f64+0x148>
1007c29c8:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c29cc:     	add	x8, x8, #0xec0
1007c29d0:     	ldaprb	w8, [x8]
1007c29d4:     	cbz	w8, 0x1007c2a38 <_js_array_get_f64+0x368>
1007c29d8:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c29dc:     	add	x8, x8, #0x58
1007c29e0:     	ldapr	x8, [x8]
1007c29e4:     	cmp	x20, x8
1007c29e8:     	b.lo	0x1007c2a38 <_js_array_get_f64+0x368>
1007c29ec:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c29f0:     	add	x8, x8, #0x60
1007c29f4:     	ldapr	x8, [x8]
1007c29f8:     	cmp	x20, x8
1007c29fc:     	b.hi	0x1007c2a38 <_js_array_get_f64+0x368>
1007c2a00:     	mov	x0, x20
1007c2a04:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2a08:     	tbz	w0, #0x0, 0x1007c2a38 <_js_array_get_f64+0x368>
1007c2a0c:     	add	x0, sp, #0x8
1007c2a10:     	mov	x1, x20
1007c2a14:     	bl	0x1002a746c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007c2a18:     	ldr	x8, [sp, #0x8]
1007c2a1c:     	cbz	x8, 0x1007c3044 <_js_array_get_f64+0x974>
1007c2a20:     	cmp	x8, #0x1
1007c2a24:     	b.ne	0x1007c3088 <_js_array_get_f64+0x9b8>
1007c2a28:     	ldr	d0, [sp, #0x10]
1007c2a2c:     	scvtf	d1, w19
1007c2a30:     	bl	0x100820c74 <_js_dyn_index_get>
1007c2a34:     	b	0x1007c2dc4 <_js_array_get_f64+0x6f4>
1007c2a38:     	mov	w24, #0xb               ; =11
1007c2a3c:     	b	0x1007c2818 <_js_array_get_f64+0x148>
1007c2a40:     	mov	w24, #0x8               ; =8
1007c2a44:     	b	0x1007c2818 <_js_array_get_f64+0x148>
1007c2a48:     	mov	w24, #0xc               ; =12
1007c2a4c:     	b	0x1007c2818 <_js_array_get_f64+0x148>
1007c2a50:     	add	x9, x8, #0x60
1007c2a54:     	b	0x1007c3004 <_js_array_get_f64+0x934>
1007c2a58:     	bl	0x100b4413c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007c2a5c:     	lsr	x1, x21, #20
1007c2a60:     	ldr	x8, [x0, #0x10]
1007c2a64:     	ldrb	w9, [x8]
1007c2a68:     	cmp	w9, #0x2
1007c2a6c:     	b.eq	0x1007c2890 <_js_array_get_f64+0x1c0>
1007c2a70:     	ldr	x9, [x8, #0x8]
1007c2a74:     	ldr	x10, [x8, #0x28]
1007c2a78:     	sub	x9, x1, x9
1007c2a7c:     	cmp	x9, x10
1007c2a80:     	b.hs	0x1007c2ac4 <_js_array_get_f64+0x3f4>
1007c2a84:     	ldr	x10, [x8, #0x20]
1007c2a88:     	mov	w11, #0x28              ; =40
1007c2a8c:     	madd	x9, x9, x11, x10
1007c2a90:     	ldr	x10, [x9]
1007c2a94:     	ldr	x11, [x8, #0x10]
1007c2a98:     	cmp	x10, x11
1007c2a9c:     	b.ne	0x1007c2ad0 <_js_array_get_f64+0x400>
1007c2aa0:     	ldp	x10, x11, [x9, #0x8]
1007c2aa4:     	cmp	x10, x21
1007c2aa8:     	ccmp	x11, x21, #0x0, ls
1007c2aac:     	b.ls	0x1007c2ad0 <_js_array_get_f64+0x400>
1007c2ab0:     	ldr	x10, [x8, #0x30]
1007c2ab4:     	add	x10, x10, #0x1
1007c2ab8:     	str	x10, [x8, #0x30]
1007c2abc:     	add	x8, x9, #0x21
1007c2ac0:     	b	0x1007c3014 <_js_array_get_f64+0x944>
1007c2ac4:     	ldr	x9, [x8, #0x58]
1007c2ac8:     	add	x9, x9, #0x1
1007c2acc:     	str	x9, [x8, #0x58]
1007c2ad0:     	ldr	x9, [x8, #0x38]
1007c2ad4:     	add	x9, x9, #0x1
1007c2ad8:     	str	x9, [x8, #0x38]
1007c2adc:     	mov	x0, x21
1007c2ae0:     	bl	0x100521208 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007c2ae4:     	and	w8, w0, #0xff
1007c2ae8:     	cbz	w8, 0x1007c2b08 <_js_array_get_f64+0x438>
1007c2aec:     	ldurb	w8, [x21, #-0x8]
1007c2af0:     	ldurb	w9, [x21, #-0x7]
1007c2af4:     	mov	w10, #0x82              ; =130
1007c2af8:     	and	w9, w9, w10
1007c2afc:     	cmp	w9, #0x2
1007c2b00:     	ccmp	w8, #0x1, #0x0, eq
1007c2b04:     	b.eq	0x1007c2bd8 <_js_array_get_f64+0x508>
1007c2b08:     	mov	x0, x21
1007c2b0c:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007c2b10:     	cbz	x0, 0x1007c2b38 <_js_array_get_f64+0x468>
1007c2b14:     	ldrb	w9, [x0]
1007c2b18:     	cmp	w9, #0x1
1007c2b1c:     	b.ne	0x1007c2b54 <_js_array_get_f64+0x484>
1007c2b20:     	ldrsb	w8, [x0, #0x1]
1007c2b24:     	tbnz	w8, #0x1f, 0x1007c2c00 <_js_array_get_f64+0x530>
1007c2b28:     	ldp	w10, w9, [x21]
1007c2b2c:     	cmp	w10, w9
1007c2b30:     	b.hi	0x1007c2c8c <_js_array_get_f64+0x5bc>
1007c2b34:     	b	0x1007c2ca4 <_js_array_get_f64+0x5d4>
1007c2b38:     	mov	x25, x0
1007c2b3c:     	mov	x0, x21
1007c2b40:     	bl	0x10058c0b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007c2b44:     	tbz	w0, #0x0, 0x1007c2b90 <_js_array_get_f64+0x4c0>
1007c2b48:     	mov	x0, #0x0                ; =0
1007c2b4c:     	mov	x8, x25
1007c2b50:     	b	0x1007c2c7c <_js_array_get_f64+0x5ac>
1007c2b54:     	mov	x8, x0
1007c2b58:     	cmp	w9, #0x1
1007c2b5c:     	b.eq	0x1007c2c7c <_js_array_get_f64+0x5ac>
1007c2b60:     	cmp	w9, #0x9
1007c2b64:     	b.ne	0x1007c2db4 <_js_array_get_f64+0x6e4>
1007c2b68:     	ldr	w8, [x21, #0x4]
1007c2b6c:     	mov	w9, #0x5841             ; =22593
1007c2b70:     	movk	w9, #0x4c5a, lsl #16
1007c2b74:     	cmp	w8, w9
1007c2b78:     	b.ne	0x1007c2db4 <_js_array_get_f64+0x6e4>
1007c2b7c:     	mov	x0, x21
1007c2b80:     	bl	0x100378910 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007c2b84:     	cbz	x0, 0x1007c2db4 <_js_array_get_f64+0x6e4>
1007c2b88:     	mov	x21, x0
1007c2b8c:     	b	0x1007c2cc0 <_js_array_get_f64+0x5f0>
1007c2b90:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2b94:     	add	x8, x8, #0xec0
1007c2b98:     	ldaprb	w8, [x8]
1007c2b9c:     	cbz	w8, 0x1007c2db4 <_js_array_get_f64+0x6e4>
1007c2ba0:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2ba4:     	add	x8, x8, #0x58
1007c2ba8:     	ldapr	x8, [x8]
1007c2bac:     	cmp	x8, x21
1007c2bb0:     	b.hi	0x1007c2db4 <_js_array_get_f64+0x6e4>
1007c2bb4:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2bb8:     	add	x8, x8, #0x60
1007c2bbc:     	ldapr	x8, [x8]
1007c2bc0:     	cmp	x8, x21
1007c2bc4:     	b.lo	0x1007c2db4 <_js_array_get_f64+0x6e4>
1007c2bc8:     	mov	x0, x21
1007c2bcc:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2bd0:     	tbnz	w0, #0x0, 0x1007c2b48 <_js_array_get_f64+0x478>
1007c2bd4:     	b	0x1007c2db4 <_js_array_get_f64+0x6e4>
1007c2bd8:     	ldr	w8, [x21]
1007c2bdc:     	mov	w9, #0xe100             ; =57600
1007c2be0:     	movk	w9, #0x5f5, lsl #16
1007c2be4:     	orr	w9, w9, #0x1
1007c2be8:     	cmp	w8, w9
1007c2bec:     	b.hs	0x1007c2b08 <_js_array_get_f64+0x438>
1007c2bf0:     	ldr	w9, [x21, #0x4]
1007c2bf4:     	cmp	w8, w9
1007c2bf8:     	b.ls	0x1007c2cc0 <_js_array_get_f64+0x5f0>
1007c2bfc:     	b	0x1007c2b08 <_js_array_get_f64+0x438>
1007c2c00:     	mov	x25, x0
1007c2c04:     	ldr	x21, [x0, #0x8]
1007c2c08:     	mov	x0, x21
1007c2c0c:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007c2c10:     	cbz	x0, 0x1007c2db4 <_js_array_get_f64+0x6e4>
1007c2c14:     	ldrb	w8, [x0]
1007c2c18:     	cmp	w8, #0x1
1007c2c1c:     	b.ne	0x1007c2db4 <_js_array_get_f64+0x6e4>
1007c2c20:     	ldrsb	w8, [x0, #0x1]
1007c2c24:     	tbz	w8, #0x1f, 0x1007c2b28 <_js_array_get_f64+0x458>
1007c2c28:     	mov	w26, #0x1               ; =1
1007c2c2c:     	ldr	x21, [x0, #0x8]
1007c2c30:     	mov	x0, x21
1007c2c34:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007c2c38:     	cbz	x0, 0x1007c2db4 <_js_array_get_f64+0x6e4>
1007c2c3c:     	ldrb	w8, [x0]
1007c2c40:     	cmp	w8, #0x1
1007c2c44:     	b.ne	0x1007c2db4 <_js_array_get_f64+0x6e4>
1007c2c48:     	cmp	w26, #0x3f
1007c2c4c:     	b.hi	0x1007c2db4 <_js_array_get_f64+0x6e4>
1007c2c50:     	add	w26, w26, #0x1
1007c2c54:     	ldrsb	w8, [x0, #0x1]
1007c2c58:     	tbnz	w8, #0x1f, 0x1007c2c2c <_js_array_get_f64+0x55c>
1007c2c5c:     	str	x21, [x25, #0x8]
1007c2c60:     	ldrb	w8, [x25, #0x1]
1007c2c64:     	orr	w9, w8, #0x80
1007c2c68:     	mov	x8, x25
1007c2c6c:     	strb	w9, [x25, #0x1]
1007c2c70:     	ldrb	w9, [x0]
1007c2c74:     	cmp	w9, #0x1
1007c2c78:     	b.ne	0x1007c2b60 <_js_array_get_f64+0x490>
1007c2c7c:     	ldp	w10, w9, [x21]
1007c2c80:     	cmp	w10, w9
1007c2c84:     	b.ls	0x1007c2ca4 <_js_array_get_f64+0x5d4>
1007c2c88:     	cbz	x8, 0x1007c2cb4 <_js_array_get_f64+0x5e4>
1007c2c8c:     	ldr	w8, [x0, #0x4]
1007c2c90:     	ubfiz	x9, x9, #3, #32
1007c2c94:     	add	x9, x9, #0x10
1007c2c98:     	cmp	x9, x8
1007c2c9c:     	b.eq	0x1007c2cc0 <_js_array_get_f64+0x5f0>
1007c2ca0:     	b	0x1007c2cb4 <_js_array_get_f64+0x5e4>
1007c2ca4:     	mov	w8, #0xe100             ; =57600
1007c2ca8:     	movk	w8, #0x5f5, lsl #16
1007c2cac:     	cmp	w10, w8
1007c2cb0:     	b.ls	0x1007c2cc0 <_js_array_get_f64+0x5f0>
1007c2cb4:     	mov	x0, x21
1007c2cb8:     	bl	0x10058c0b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007c2cbc:     	tbz	w0, #0x0, 0x1007c2d70 <_js_array_get_f64+0x6a0>
1007c2cc0:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2cc4:     	add	x8, x8, #0xec0
1007c2cc8:     	ldaprb	w8, [x8]
1007c2ccc:     	cbz	w8, 0x1007c2d14 <_js_array_get_f64+0x644>
1007c2cd0:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2cd4:     	add	x8, x8, #0x58
1007c2cd8:     	ldapr	x8, [x8]
1007c2cdc:     	cmp	x21, x8
1007c2ce0:     	b.lo	0x1007c2d14 <_js_array_get_f64+0x644>
1007c2ce4:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2ce8:     	add	x8, x8, #0x60
1007c2cec:     	ldapr	x8, [x8]
1007c2cf0:     	cmp	x21, x8
1007c2cf4:     	b.hi	0x1007c2d14 <_js_array_get_f64+0x644>
1007c2cf8:     	mov	x0, x21
1007c2cfc:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2d00:     	tbz	w0, #0x0, 0x1007c2d14 <_js_array_get_f64+0x644>
1007c2d04:     	mov	x0, x21
1007c2d08:     	mov	x1, x19
1007c2d0c:     	bl	0x100900988 <_js_typed_array_get>
1007c2d10:     	b	0x1007c2dc4 <_js_array_get_f64+0x6f4>
1007c2d14:     	mov	x0, x21
1007c2d18:     	bl	0x10058c0b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007c2d1c:     	tbz	w0, #0x0, 0x1007c2d44 <_js_array_get_f64+0x674>
1007c2d20:     	mov	x0, x21
1007c2d24:     	mov	x1, x19
1007c2d28:     	bl	0x1005893dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007c2d2c:     	and	w8, w1, #0xff
1007c2d30:     	ucvtf	d0, w8
1007c2d34:     	fmov	x8, d0
1007c2d38:     	tst	w0, #0x1
1007c2d3c:     	csel	x22, x8, xzr, ne
1007c2d40:     	b	0x1007c2dc8 <_js_array_get_f64+0x6f8>
1007c2d44:     	cmp	x21, x20
1007c2d48:     	b.eq	0x1007c2df0 <_js_array_get_f64+0x720>
1007c2d4c:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007c2d50:     	b.lo	0x1007c2de8 <_js_array_get_f64+0x718>
1007c2d54:     	tst	x21, #0xffff800000000000
1007c2d58:     	mov	w8, #0x1000             ; =4096
1007c2d5c:     	ccmp	x21, x8, #0x0, eq
1007c2d60:     	b.lo	0x1007c2de8 <_js_array_get_f64+0x718>
1007c2d64:     	ldurb	w24, [x21, #-0x8]
1007c2d68:     	ldurh	w23, [x21, #-0x6]
1007c2d6c:     	b	0x1007c2df0 <_js_array_get_f64+0x720>
1007c2d70:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2d74:     	add	x8, x8, #0xec0
1007c2d78:     	ldaprb	w8, [x8]
1007c2d7c:     	cbz	w8, 0x1007c2db4 <_js_array_get_f64+0x6e4>
1007c2d80:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2d84:     	add	x8, x8, #0x58
1007c2d88:     	ldapr	x8, [x8]
1007c2d8c:     	cmp	x21, x8
1007c2d90:     	b.lo	0x1007c2db4 <_js_array_get_f64+0x6e4>
1007c2d94:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2d98:     	add	x8, x8, #0x60
1007c2d9c:     	ldapr	x8, [x8]
1007c2da0:     	cmp	x21, x8
1007c2da4:     	b.hi	0x1007c2db4 <_js_array_get_f64+0x6e4>
1007c2da8:     	mov	x0, x21
1007c2dac:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2db0:     	tbnz	w0, #0x0, 0x1007c2cc0 <_js_array_get_f64+0x5f0>
1007c2db4:     	mov	x0, x22
1007c2db8:     	mov	x1, x19
1007c2dbc:     	bl	0x10054b4cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007c2dc0:     	tbz	w0, #0x0, 0x1007c3098 <_js_array_get_f64+0x9c8>
1007c2dc4:     	fmov	x22, d0
1007c2dc8:     	fmov	d0, x22
1007c2dcc:     	ldp	x29, x30, [sp, #0x60]
1007c2dd0:     	ldp	x20, x19, [sp, #0x50]
1007c2dd4:     	ldp	x22, x21, [sp, #0x40]
1007c2dd8:     	ldp	x24, x23, [sp, #0x30]
1007c2ddc:     	ldp	x26, x25, [sp, #0x20]
1007c2de0:     	add	sp, sp, #0x70
1007c2de4:     	ret
1007c2de8:     	mov	w23, #0x0               ; =0
1007c2dec:     	mov	w24, #0x0               ; =0
1007c2df0:     	cmp	w24, #0x1
1007c2df4:     	b.ne	0x1007c2fa8 <_js_array_get_f64+0x8d8>
1007c2df8:     	tbz	w23, #0xa, 0x1007c2fa8 <_js_array_get_f64+0x8d8>
1007c2dfc:     	adrp	x8, 0x100b69000 <__RNvNtNtNtCsjgY6bXVaRmE_4core7unicode12unicode_data15grapheme_extend7OFFSETS+0x125>
1007c2e00:     	add	x8, x8, #0xb8c
1007c2e04:     	cmp	w19, #0x3e8
1007c2e08:     	b.lo	0x1007c2e80 <_js_array_get_f64+0x7b0>
1007c2e0c:     	mov	x9, #0x0                ; =0
1007c2e10:     	mov	w11, #0x1759            ; =5977
1007c2e14:     	movk	w11, #0xd1b7, lsl #16
1007c2e18:     	mov	w12, #0x2710            ; =10000
1007c2e1c:     	mov	w13, #0x147b            ; =5243
1007c2e20:     	mov	w14, #0x64              ; =100
1007c2e24:     	add	x15, sp, #0x8
1007c2e28:     	mov	w16, #0x967f            ; =38527
1007c2e2c:     	movk	w16, #0x98, lsl #16
1007c2e30:     	mov	x10, x19
1007c2e34:     	mov	x17, x10
1007c2e38:     	umull	x10, w10, w11
1007c2e3c:     	lsr	x10, x10, #45
1007c2e40:     	msub	w0, w10, w12, w17
1007c2e44:     	ubfx	w1, w0, #2, #14
1007c2e48:     	mul	w1, w1, w13
1007c2e4c:     	lsr	w1, w1, #17
1007c2e50:     	msub	w0, w1, w14, w0
1007c2e54:     	add	x2, x15, x9
1007c2e58:     	ldrh	w1, [x8, w1, uxtw #1]
1007c2e5c:     	strh	w1, [x2, #0x6]
1007c2e60:     	and	x0, x0, #0xffff
1007c2e64:     	ldrh	w0, [x8, x0, lsl #1]
1007c2e68:     	strh	w0, [x2, #0x8]
1007c2e6c:     	sub	x9, x9, #0x4
1007c2e70:     	cmp	w17, w16
1007c2e74:     	b.hi	0x1007c2e34 <_js_array_get_f64+0x764>
1007c2e78:     	add	x9, x9, #0xa
1007c2e7c:     	b	0x1007c2e88 <_js_array_get_f64+0x7b8>
1007c2e80:     	mov	w9, #0xa                ; =10
1007c2e84:     	mov	x10, x19
1007c2e88:     	cmp	w10, #0x9
1007c2e8c:     	b.ls	0x1007c2ec0 <_js_array_get_f64+0x7f0>
1007c2e90:     	sub	x9, x9, #0x2
1007c2e94:     	ubfx	w11, w10, #2, #14
1007c2e98:     	mov	w12, #0x147b            ; =5243
1007c2e9c:     	mul	w11, w11, w12
1007c2ea0:     	lsr	w11, w11, #17
1007c2ea4:     	mov	w12, #0x64              ; =100
1007c2ea8:     	msub	w10, w11, w12, w10
1007c2eac:     	and	x10, x10, #0xffff
1007c2eb0:     	ldrh	w10, [x8, x10, lsl #1]
1007c2eb4:     	add	x12, sp, #0x8
1007c2eb8:     	strh	w10, [x12, x9]
1007c2ebc:     	mov	x10, x11
1007c2ec0:     	cbz	w19, 0x1007c2ef8 <_js_array_get_f64+0x828>
1007c2ec4:     	cbnz	w10, 0x1007c2ef8 <_js_array_get_f64+0x828>
1007c2ec8:     	cmp	x9, #0xa
1007c2ecc:     	b.ne	0x1007c2f20 <_js_array_get_f64+0x850>
1007c2ed0:     	mov	w23, #0x1               ; =1
1007c2ed4:     	add	x0, sp, #0x8
1007c2ed8:     	mov	x1, x21
1007c2edc:     	mov	w2, #0x1                ; =1
1007c2ee0:     	mov	x3, #0x0                ; =0
1007c2ee4:     	bl	0x1005b57bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007c2ee8:     	ldr	x8, [sp, #0x8]
1007c2eec:     	mov	w20, #0x1               ; =1
1007c2ef0:     	cbnz	x8, 0x1007c2f70 <_js_array_get_f64+0x8a0>
1007c2ef4:     	b	0x1007c2fa8 <_js_array_get_f64+0x8d8>
1007c2ef8:     	sub	x23, x9, #0x1
1007c2efc:     	ubfiz	w10, w10, #1, #4
1007c2f00:     	add	x8, x8, x10
1007c2f04:     	ldrb	w8, [x8, #0x1]
1007c2f08:     	add	x10, sp, #0x8
1007c2f0c:     	strb	w8, [x10, x23]
1007c2f10:     	mov	w8, #0xb                ; =11
1007c2f14:     	b	0x1007c2f28 <_js_array_get_f64+0x858>
1007c2f18:     	add	x9, x8, #0x90
1007c2f1c:     	b	0x1007c3004 <_js_array_get_f64+0x934>
1007c2f20:     	mov	w8, #0xa                ; =10
1007c2f24:     	mov	x23, x9
1007c2f28:     	sub	x22, x8, x9
1007c2f2c:     	mov	x0, x22
1007c2f30:     	mov	w1, #0x1                ; =1
1007c2f34:     	bl	0x100b63fc8 <_mi_malloc_aligned>
1007c2f38:     	cbz	x0, 0x1007c30e4 <_js_array_get_f64+0xa14>
1007c2f3c:     	mov	x20, x0
1007c2f40:     	add	x8, sp, #0x8
1007c2f44:     	add	x1, x8, x23
1007c2f48:     	mov	x2, x22
1007c2f4c:     	bl	0x100b66bec <_writev+0x100b66bec>
1007c2f50:     	add	x0, sp, #0x8
1007c2f54:     	mov	x1, x21
1007c2f58:     	mov	x2, x20
1007c2f5c:     	mov	x3, x22
1007c2f60:     	bl	0x1005b57bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007c2f64:     	ldr	w8, [sp, #0x8]
1007c2f68:     	tbz	w8, #0x0, 0x1007c2fa0 <_js_array_get_f64+0x8d0>
1007c2f6c:     	mov	w23, #0x0               ; =0
1007c2f70:     	mov	x22, #0x1               ; =1
1007c2f74:     	movk	x22, #0x7ffc, lsl #48
1007c2f78:     	ldr	x0, [sp, #0x10]
1007c2f7c:     	cbz	x0, 0x1007c3034 <_js_array_get_f64+0x964>
1007c2f80:     	cbz	x21, 0x1007c3024 <_js_array_get_f64+0x954>
1007c2f84:     	lsr	x8, x21, #52
1007c2f88:     	cmp	x8, #0x7fe
1007c2f8c:     	b.hi	0x1007c3028 <_js_array_get_f64+0x958>
1007c2f90:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007c2f94:     	bfxil	x8, x21, #0, #48
1007c2f98:     	mov	x21, x8
1007c2f9c:     	b	0x1007c3028 <_js_array_get_f64+0x958>
1007c2fa0:     	mov	x0, x20
1007c2fa4:     	bl	0x100b63d40 <_mi_free>
1007c2fa8:     	ldr	w8, [x21]
1007c2fac:     	cmp	w19, w8
1007c2fb0:     	b.hs	0x1007c2ff0 <_js_array_get_f64+0x920>
1007c2fb4:     	ldr	w8, [x21, #0x4]
1007c2fb8:     	cmp	w19, w8
1007c2fbc:     	b.hs	0x1007c2fe0 <_js_array_get_f64+0x910>
1007c2fc0:     	add	x8, x21, w19, uxtw #3
1007c2fc4:     	ldr	x22, [x8, #0x8]
1007c2fc8:     	mov	x8, #0x1                ; =1
1007c2fcc:     	movk	x8, #0x7ffc, lsl #48
1007c2fd0:     	add	x8, x8, #0xf
1007c2fd4:     	cmp	x22, x8
1007c2fd8:     	b.ne	0x1007c2dc8 <_js_array_get_f64+0x6f8>
1007c2fdc:     	b	0x1007c2ff0 <_js_array_get_f64+0x920>
1007c2fe0:     	mov	x0, x21
1007c2fe4:     	mov	x1, x19
1007c2fe8:     	bl	0x10052d8c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007c2fec:     	tbnz	w0, #0x0, 0x1007c2dc4 <_js_array_get_f64+0x6f4>
1007c2ff0:     	mov	x0, x21
1007c2ff4:     	mov	x1, x19
1007c2ff8:     	bl	0x1006cb9b8 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007c2ffc:     	b	0x1007c2dc4 <_js_array_get_f64+0x6f4>
1007c3000:     	add	x9, x8, #0xc0
1007c3004:     	ldr	x10, [x8, #0x30]
1007c3008:     	add	x10, x10, #0x1
1007c300c:     	str	x10, [x8, #0x30]
1007c3010:     	add	x8, x9, #0x19
1007c3014:     	ldrb	w8, [x8]
1007c3018:     	cmp	w8, #0xff
1007c301c:     	b.ne	0x1007c2ae8 <_js_array_get_f64+0x418>
1007c3020:     	b	0x1007c2adc <_js_array_get_f64+0x40c>
1007c3024:     	add	x21, x22, #0x1
1007c3028:     	fmov	d0, x21
1007c302c:     	bl	0x1007017fc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007c3030:     	mov	x22, x0
1007c3034:     	tbnz	w23, #0x0, 0x1007c2dc8 <_js_array_get_f64+0x6f8>
1007c3038:     	mov	x0, x20
1007c303c:     	bl	0x100b63d40 <_mi_free>
1007c3040:     	b	0x1007c2dc8 <_js_array_get_f64+0x6f8>
1007c3044:     	ldr	x20, [sp, #0x10]
1007c3048:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c304c:     	ldr	x8, [x8, #0xed8]
1007c3050:     	cbz	x8, 0x1007c3068 <_js_array_get_f64+0x998>
1007c3054:     	mov	x0, x20
1007c3058:     	bl	0x10013cc40 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007c305c:     	tbz	w0, #0x0, 0x1007c3068 <_js_array_get_f64+0x998>
1007c3060:     	mov	x0, x20
1007c3064:     	bl	0x1002c1840 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007c3068:     	tbnz	w19, #0x1f, 0x1007c3088 <_js_array_get_f64+0x9b8>
1007c306c:     	ldr	w8, [x20]
1007c3070:     	cmp	w19, w8
1007c3074:     	b.hs	0x1007c3088 <_js_array_get_f64+0x9b8>
1007c3078:     	mov	w1, w19
1007c307c:     	mov	x0, x20
1007c3080:     	bl	0x1002a7acc <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007c3084:     	b	0x1007c2dc4 <_js_array_get_f64+0x6f4>
1007c3088:     	mov	x8, #0x1                ; =1
1007c308c:     	movk	x8, #0x7ffc, lsl #48
1007c3090:     	mov	x22, x8
1007c3094:     	b	0x1007c2dc8 <_js_array_get_f64+0x6f8>
1007c3098:     	mov	x0, x22
1007c309c:     	bl	0x100b4c6b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007c30a0:     	cmp	x0, #0x1
1007c30a4:     	b.ne	0x1007c2710 <_js_array_get_f64+0x40>
1007c30a8:     	mov	x0, x19
1007c30ac:     	bl	0x100b4c6d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007c30b0:     	b	0x1007c2dc4 <_js_array_get_f64+0x6f4>
1007c30b4:     	mov	x0, x20
1007c30b8:     	mov	w1, #0x0                ; =0
1007c30bc:     	bl	0x100b4ec40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007c30c0:     	mov	x20, x0
1007c30c4:     	cbnz	x0, 0x1007c27ec <_js_array_get_f64+0x11c>
1007c30c8:     	b	0x1007c2dc8 <_js_array_get_f64+0x6f8>
1007c30cc:     	mov	x0, x20
1007c30d0:     	mov	w1, #0x1                ; =1
1007c30d4:     	bl	0x100b4ec40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007c30d8:     	mov	x20, x0
1007c30dc:     	cbnz	x0, 0x1007c2990 <_js_array_get_f64+0x2c0>
1007c30e0:     	b	0x1007c2dc8 <_js_array_get_f64+0x6f8>
1007c30e4:     	mov	w0, #0x1                ; =1
1007c30e8:     	mov	x1, x22
1007c30ec:     	bl	0x100b170c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
