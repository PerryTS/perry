
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.0hzsjplwwpevv88lz9s5mjuly.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.addr2line-cfa71d2872fc9749.addr2line.2f803ffa438d6abd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.adler2-4a012095652e66be.adler2.4472f1a4039cb8c5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ahash-9514a3e3390ca75c.ahash.2d29b14819ea2aa7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.aho_corasick-0465e7d1dc158f68.aho_corasick.d4e9aa874147907-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.alloc-f7cf0325b2c4fbea.alloc.91507a9d0c1147cb-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.allocator_api2-f4879b7f65d9dad6.allocator_api2.c20efd3e8c1c526a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.anyhow-b00ab8880ea60f5a.anyhow.dd2c21d3a09e2169-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.base64-32ce9211317f5731.base64.d7b02bb0c01b4c7f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.base64ct-dc4539cdef9387c1.base64ct.a13194e5b06d043e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.better_scoped_tls-5623aa5785b63992.better_scoped_tls.c4fc4593c97e81eb-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bit_set-1b43a885fb453b97.bit_set.e296561ef88d1b25-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bit_vec-8353e4eca9cb6885.bit_vec.2905b060439a1ee5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bitflags-a267cd1b6450301e.bitflags.9b23124bf16832ba-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bytecount-f903ae1df949a853.bytecount.d96a36eac4eddd2e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bytes-4d639afa28f500e9.bytes.4b80b056274f495a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bytes_str-9ed5b56fd3acead7.bytes_str.33b6ea97d807fd24-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.calendrical_calculations-d30e5fcb342f8309.calendrical_calculations.ff7d2d4d240655f4-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.cfg_if-11f50a868fc78507.cfg_if.b001c247f2cdfacc-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.cfg_if-65f3efe385514d24.cfg_if.f06090845af655d8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.chacha20-894520615b692380.chacha20.255207753dfba230-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.combine-c70df9144a05ac41.combine.c3909ca49e68f1f0-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.const_oid-7b92d750363681a1.const_oid.59ced0f90a34feb8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.core-1eb26884753bb7ec.core.e07e215301fbc6f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.core_maths-11146167d2fbcd32.core_maths.423ca64e8f23f19a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.cty-f1fa0ed128de58b9.cty.6b73d1db9cbf7b8b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.data_encoding-98155a5d48e5ec99.data_encoding.d70ce69399f262ca-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.debug_unreachable-9bb446589bc29b16.debug_unreachable.fe3a47d951b816d9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.der-9bb76198d0a38255.der.6bdd1208ba76c73b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.dirs-756cabb78e25a929.dirs.ffe05ade48c56831-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.dirs_sys-e3f5752242e2a022.dirs_sys.ee3c17565b1fea59-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.either-432e8663b5d638fc.either.94df2b7257068b13-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.errno-ea9565cc054c881d.errno.7569163361032131-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.fancy_regex-2c325c7f9e823393.fancy_regex.ca4df3e112cd6cb7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.fixed_decimal-7e6fe6d640091744.fixed_decimal.7d257809aa775ff2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.flagset-ac9650c267cc7e77.flagset.b1438c243c6ff671-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.form_urlencoded-c338c7e2455734e8.form_urlencoded.1ab2c7c11d3385cf-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_core-61582daa6c57b257.futures_core.e5c5ead29f2a5185-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_io-313f277a9d659f14.futures_io.2354b3f0d921f5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_sink-24e92a078488c232.futures_sink.477b530395196519-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_task-40d3c4f4c699450f.futures_task.a793339b5ba19ee-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_util-9ca40d38221ccdc3.futures_util.7622420df399cdfe-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.getrandom-888caac6f3a9d896.getrandom.7f8b53275961c005-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.getrandom-c7786f5309f7c1d1.getrandom.c00a3944440a318d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.gimli-1dc154aa9e77af93.gimli.5901559d024f6e07-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.gimli-4a08f02c6b3bfed9.gimli.adbe390e003e7ecb-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hashbrown-4d32db017aa9b7a5.hashbrown.8f7d8026e818751e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hashbrown-af4a3f18b4ae97c9.hashbrown.cb64e714776d3e07-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hickory_proto-5da21089dd651d86.hickory_proto.b3e58bdc73b32711-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hostname-1a758cf59ba97d19.hostname.9e06914bfa9458c0-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hstr-990b134b3f579b0d.hstr.7816630fc46099ef-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_calendar-41dd45c4986e5371.icu_calendar.525e0f6d835cb712-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_calendar_data-edd7996660c4190e.icu_calendar_data.f47bf9c505eeaff2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_collections-559b63245c10ac1b.icu_collections.377b7b7ce659b1b9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_datetime-034ad7cdc455dac0.icu_datetime.3f12d4db0ba0d033-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_datetime_data-618583f1e8f98068.icu_datetime_data.ae5f6f8bf868927e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_decimal-77beaba6d2163e9b.icu_decimal.fe46e9f4b123130a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_decimal_data-367997f4010d8153.icu_decimal_data.d6f512199a2a447f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale-b42b3e1360358fc5.icu_locale.b3f10ef03c9651a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale_core-849ff933c9f4951a.icu_locale_core.e916c9be12dd52d2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale_data-9e7081d145555538.icu_locale_data.c24e3b51aa8226f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale_fallback-a6e3f83d98e2a67b.icu_locale_fallback.56246df7a44619a1-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale_fallback_data-1291c99bd372729e.icu_locale_fallback_data.afad649127a1756e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_normalizer-bc7f251896dc40bd.icu_normalizer.ff2a905c7940b1f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_normalizer_data-268487fee32ac8f0.icu_normalizer_data.8ad43135a1ce7d1f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_pattern-d59a83eb0e463baf.icu_pattern.be117b667d76f6f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_plurals-3c9070f8fa2510af.icu_plurals.740da912aa775a52-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_plurals_data-bd8faf2099579a9d.icu_plurals_data.45ea6926f1b7622f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_properties-6d0d35008dd1dbf9.icu_properties.c9b54ac36f6ff15d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_properties_data-59005f70ef52dd72.icu_properties_data.2b4f163e924ba5b8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_provider-6781ca5b429f4aee.icu_provider.29b968015b290673-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_time-54550ac874f62853.icu_time.5b58251af801c00d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_time_data-4cd606d3217ab0c8.icu_time_data.e93588578a1fe390-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.idna-8d5c8377e58f6d08.idna.aba1e6179509c9b5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.idna_adapter-16f147720f57f9af.idna_adapter.f7fd92e26f89f8f1-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ipnet-16dcea07c26a0bdf.ipnet.a68501ef90183657-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.itoa-72113ee16b8d0ab6.itoa.6381431f0c25948c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ixdtf-da83a26e439607da.ixdtf.9e61fc26cbabd4cd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.jiff_tzdb-c9f0d309035f3bef.jiff_tzdb.8ad45a94b44687b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.lazy_static-7647d3e036babadd.lazy_static.f61d0a0c663b0e34-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.libc-6299013de1b57308.libc.89db0e620931259c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.libc-dadb5a82a633a7dc.libc.6bde7fa237754b8a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.libm-ac5dff0b52f67d03.libm.554bb06ed6d99dbd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.libmimalloc_sys-b1e23e8a6c5928c2.libmimalloc_sys.29accdad47f6ede0-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.litemap-2e12d9912a397309.litemap.571f336a3d6bbb56-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.lock_api-b480096f46123924.lock_api.874432d3f0bce2f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.log-169df25b841fb738.log.f3f704751685a618-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.mach2-6f42ba587ea54125.mach2.e7620912d05e5c3f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.memchr-1c6a1f6f6196cc2c.memchr.9afcaf06bb01edf2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.memchr-db6845a68ce0f188.memchr.9fcb083790588d2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.miette-85b477785fba33d9.miette.50b4b2d1c414b7ce-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.mimalloc-bcf0b21589b8fa53.mimalloc.95dbff8ab7587b05-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.miniz_oxide-2b20def31e1e0221.miniz_oxide.3e514f74919855b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.mio-f4b45263c6fb2e44.mio.430e10d80ebe3d9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.node_semver-359c30260c8449dc.node_semver.233ee6db2f2c4e46-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.nom-d7f48be26f93c2f7.nom.749d1dbb25d8ab32-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.num_bigint-aa73c29d2bd73516.num_bigint.9ee201b330206f6-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.num_integer-e318a12cf646126f.num_integer.9033146fac8f1134-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.num_traits-46d1dcb8872f2815.num_traits.d52ad62a33d7f1a9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.object-836e641a18d03406.object.f0cec6469c5dcf18-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.once_cell-01ae4f33c7a79bb7.once_cell.3768cf33248bb273-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.option_ext-8f1216324e4e6381.option_ext.92b51bce59292c52-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.panic_abort-905bfe97e1134923.panic_abort.cec6bdc4f2a8e72d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.parking_lot-4acf5fa50a52bd18.parking_lot.b59ab0d8f2549f8e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.parking_lot_core-0dcf47a90d11c4e4.parking_lot_core.502597fbe5df1389-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.pem_rfc7468-d976dcafab7c7e37.pem_rfc7468.757403f363ad557c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.percent_encoding-2e8ac337530122b2.percent_encoding.f83c908de861c15d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_diagnostics-fba70546dd9f3424.perry_diagnostics.cefa4a43ff59d614-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_dispatch-0bc0b01b9b7736fe.perry_dispatch.cd02373148e7c215-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_parser-b68fb40287dd2e20.perry_parser.6e33b45a5046bf8f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_runtime-9458b86ff25d0db1.perry_runtime.261c4ba5a81df8f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000000015490c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_>:
  15490c:      	stp	x28, x27, [sp, #-0x60]!
  154910:      	stp	x26, x25, [sp, #0x10]
  154914:      	stp	x24, x23, [sp, #0x20]
  154918:      	stp	x22, x21, [sp, #0x30]
  15491c:      	stp	x20, x19, [sp, #0x40]
  154920:      	stp	x29, x30, [sp, #0x50]
  154924:      	add	x29, sp, #0x50
  154928:      	sub	sp, sp, #0x240
  15492c:      	ldp	x2, x19, [x0, #0x68]
  154930:      	cmp	x19, x2
  154934:      	b.hs	0x15496c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x60>
  154938:      	ldr	x8, [x0, #0x60]
  15493c:      	mov	x9, #0x2600             ; =9728
  154940:      	movk	x9, #0x1, lsl #32
  154944:      	ldrb	w10, [x8, x19]
  154948:      	cmp	w10, #0x20
  15494c:      	b.hi	0x15496c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x60>
  154950:      	lsr	x10, x9, x10
  154954:      	tbz	w10, #0x0, 0x15496c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x60>
  154958:      	add	x19, x19, #0x1
  15495c:      	str	x19, [x0, #0x70]
  154960:      	cmp	x2, x19
  154964:      	b.ne	0x154944 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x38>
  154968:      	b	0x1560d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
  15496c:      	cmp	x19, x2
  154970:      	b.hs	0x1560d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
  154974:      	ldr	x12, [x0, #0x60]
  154978:      	add	x9, x12, x19
  15497c:      	ldrb	w8, [x9]
  154980:      	cmp	w8, #0x65
  154984:      	b.le	0x1549d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xcc>
  154988:      	cmp	w8, #0x73
  15498c:      	b.gt	0x154ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1c8>
  154990:      	cmp	w8, #0x66
  154994:      	b.eq	0x154b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x288>
  154998:      	cmp	w8, #0x6e
  15499c:      	b.ne	0x154b7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x270>
  1549a0:      	add	x1, x19, #0x4
  1549a4:      	cmp	x1, x2
  1549a8:      	b.hi	0x1560d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
  1549ac:      	cmn	x19, #0x5
  1549b0:      	b.hi	0x156318 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a0c>
  1549b4:      	ldr	w8, [x9]
  1549b8:      	mov	w9, #0x756e             ; =30062
  1549bc:      	movk	w9, #0x6c6c, lsl #16
  1549c0:      	cmp	w8, w9
  1549c4:      	b.ne	0x1560d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
  1549c8:      	mov	x19, #0x2               ; =2
  1549cc:      	movk	x19, #0x7ffc, lsl #48
  1549d0:      	str	x1, [x0, #0x70]
  1549d4:      	b	0x1560dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
  1549d8:      	cmp	w8, #0x22
  1549dc:      	b.eq	0x154b50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x244>
  1549e0:      	cmp	w8, #0x2d
  1549e4:      	b.eq	0x154c18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x30c>
  1549e8:      	cmp	w8, #0x5b
  1549ec:      	b.ne	0x154b7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x270>
  1549f0:      	add	x8, x19, #0x1
  1549f4:      	str	x8, [x0, #0x70]
  1549f8:      	cmp	x8, x2
  1549fc:      	b.hs	0x154a2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x120>
  154a00:      	mov	x9, #0x2600             ; =9728
  154a04:      	movk	x9, #0x1, lsl #32
  154a08:      	ldrb	w10, [x12, x8]
  154a0c:      	cmp	w10, #0x20
  154a10:      	b.hi	0x154a2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x120>
  154a14:      	lsr	x10, x9, x10
  154a18:      	tbz	w10, #0x0, 0x154a2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x120>
  154a1c:      	add	x8, x8, #0x1
  154a20:      	str	x8, [x0, #0x70]
  154a24:      	cmp	x2, x8
  154a28:      	b.ne	0x154a08 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xfc>
  154a2c:      	mov	x20, x0
  154a30:      	adrp	x0, 0x154000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x46c>
  154a34:      	ldr	x0, [x0]
  154a38:      	ldr	x8, [x0]
  154a3c:      	blr	x8
  154a40:      	mov	x19, x0
  154a44:      	ldrb	w8, [x0, #0x20]
  154a48:      	cbnz	w8, 0x156290 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1984>
  154a4c:      	ldr	x8, [x19]
  154a50:      	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
  154a54:      	cmp	x8, x9
  154a58:      	b.hs	0x1562ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19e0>
  154a5c:      	mov	x0, x20
  154a60:      	ldr	x1, [x19, #0x18]
  154a64:      	ldp	x8, x9, [x20, #0x68]
  154a68:      	subs	x8, x8, x9
  154a6c:      	b.ls	0x154c80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x374>
  154a70:      	ldr	x10, [x0, #0x60]
  154a74:      	ldrb	w9, [x10, x9]
  154a78:      	cmp	w9, #0x7b
  154a7c:      	b.ne	0x154c80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x374>
  154a80:      	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
  154a84:      	movk	x9, #0xaaab
  154a88:      	umulh	x8, x8, x9
  154a8c:      	lsr	x8, x8, #6
  154a90:      	mov	w9, #0x10               ; =16
  154a94:      	cmp	x8, #0x10
  154a98:      	csel	x8, x8, x9, hi
  154a9c:      	mov	w9, #0x4000             ; =16384
  154aa0:      	cmp	x8, #0x4, lsl #12       ; =0x4000
  154aa4:      	csel	x2, x8, x9, lo
  154aa8:      	mov	x19, x0
  154aac:      	add	x0, sp, #0x188
  154ab0:      	mov	x20, x1
  154ab4:      	add	x1, x19, #0x20
  154ab8:      	bl	0x154ab8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ac>
  154abc:      	add	x1, sp, #0x188
  154ac0:      	mov	x0, x19
  154ac4:      	mov	x2, x20
  154ac8:      	bl	0x154ac8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1bc>
  154acc:      	mov	x19, x0
  154ad0:      	b	0x1560dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
  154ad4:      	cmp	w8, #0x74
  154ad8:      	b.eq	0x154bdc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x2d0>
  154adc:      	cmp	w8, #0x7b
  154ae0:      	b.ne	0x154b7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x270>
  154ae4:      	add	x8, x19, #0x1
  154ae8:      	str	x8, [x0, #0x70]
  154aec:      	cmp	x8, x2
  154af0:      	b.hs	0x154b20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x214>
  154af4:      	mov	x9, #0x2600             ; =9728
  154af8:      	movk	x9, #0x1, lsl #32
  154afc:      	ldrb	w10, [x12, x8]
  154b00:      	cmp	w10, #0x20
  154b04:      	b.hi	0x154b20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x214>
  154b08:      	lsr	x10, x9, x10
  154b0c:      	tbz	w10, #0x0, 0x154b20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x214>
  154b10:      	add	x8, x8, #0x1
  154b14:      	str	x8, [x0, #0x70]
  154b18:      	cmp	x2, x8
  154b1c:      	b.ne	0x154afc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1f0>
  154b20:      	ldrb	w8, [x0, #0xd5]
  154b24:      	tbz	w8, #0x0, 0x154ccc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x3c0>
  154b28:      	strb	wzr, [x0, #0xd5]
  154b2c:      	ldr	x22, [x0, #0x78]
  154b30:      	ldp	q0, q1, [x0, #0x80]
  154b34:      	stur	q0, [sp, #0xa8]
  154b38:      	stur	q1, [sp, #0xb8]
  154b3c:      	ldp	q0, q1, [x0, #0xa0]
  154b40:      	stur	q0, [sp, #0xc8]
  154b44:      	stur	q1, [sp, #0xd8]
  154b48:      	ldr	x9, [x0, #0xc0]
  154b4c:      	b	0x154e74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x568>
  154b50:      	ldr	x8, [x0]
  154b54:      	cmp	x8, #0x1
  154b58:      	b.ne	0x154ca0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x394>
  154b5c:      	ldr	x8, [x0, #0x8]
  154b60:      	cmp	x8, x19
  154b64:      	b.ne	0x154ca0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x394>
  154b68:      	ldp	x9, x8, [x0, #0x10]
  154b6c:      	str	x9, [x0, #0x70]
  154b70:      	mov	x19, #0x7fff000000000000 ; =9223090561878065152
  154b74:      	bfxil	x19, x8, #0, #48
  154b78:      	b	0x1560dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
  154b7c:      	sub	w8, w8, #0x30
  154b80:      	cmp	w8, #0x9
  154b84:      	b.hi	0x1560d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
  154b88:      	mov	w13, #0x0               ; =0
  154b8c:      	mov	x10, x19
  154b90:      	b	0x154c24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x318>
  154b94:      	add	x1, x19, #0x5
  154b98:      	cmp	x1, x2
  154b9c:      	b.hi	0x1560d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
  154ba0:      	cmn	x19, #0x6
  154ba4:      	b.hi	0x1562f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19ec>
  154ba8:      	ldrb	w8, [x9, #0x4]
  154bac:      	ldr	w9, [x9]
  154bb0:      	orr	x8, x9, x8, lsl #32
  154bb4:      	mov	x9, #0x6166             ; =24934
  154bb8:      	movk	x9, #0x736c, lsl #16
  154bbc:      	movk	x9, #0x65, lsl #32
  154bc0:      	cmp	x8, x9
  154bc4:      	b.ne	0x1560d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
  154bc8:      	str	x1, [x0, #0x70]
  154bcc:      	mov	x8, #0x2                ; =2
  154bd0:      	movk	x8, #0x7ffc, lsl #48
  154bd4:      	orr	x19, x8, #0x1
  154bd8:      	b	0x1560dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
  154bdc:      	add	x1, x19, #0x4
  154be0:      	cmp	x1, x2
  154be4:      	b.hi	0x1560d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
  154be8:      	cmn	x19, #0x5
  154bec:      	b.hi	0x156308 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19fc>
  154bf0:      	ldr	w8, [x9]
  154bf4:      	mov	w9, #0x7274             ; =29300
  154bf8:      	movk	w9, #0x6575, lsl #16
  154bfc:      	cmp	w8, w9
  154c00:      	b.ne	0x1560d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
  154c04:      	str	x1, [x0, #0x70]
  154c08:      	mov	x8, #0x2                ; =2
  154c0c:      	movk	x8, #0x7ffc, lsl #48
  154c10:      	add	x19, x8, #0x2
  154c14:      	b	0x1560dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
  154c18:      	add	x10, x19, #0x1
  154c1c:      	str	x10, [x0, #0x70]
  154c20:      	mov	w13, #0x1               ; =1
  154c24:      	cmp	x10, x2
  154c28:      	b.hs	0x1560d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
  154c2c:      	add	x14, x12, x10
  154c30:      	ldrb	w8, [x14]
  154c34:      	cmp	w8, #0x30
  154c38:      	b.ne	0x154cf0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x3e4>
  154c3c:      	add	x1, x10, #0x1
  154c40:      	str	x1, [x0, #0x70]
  154c44:      	cmp	x1, x2
  154c48:      	b.hs	0x154d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x41c>
  154c4c:      	ldrb	w8, [x12, x1]
  154c50:      	sub	w8, w8, #0x30
  154c54:      	cmp	w8, #0x9
  154c58:      	b.hi	0x154d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x41c>
  154c5c:      	ldrb	w8, [x12, x1]
  154c60:      	sub	w8, w8, #0x30
  154c64:      	cmp	w8, #0xa
  154c68:      	b.hs	0x1560d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
  154c6c:      	add	x1, x1, #0x1
  154c70:      	str	x1, [x0, #0x70]
  154c74:      	cmp	x2, x1
  154c78:      	b.ne	0x154c5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x350>
  154c7c:      	b	0x1560d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
  154c80:      	add	sp, sp, #0x240
  154c84:      	ldp	x29, x30, [sp, #0x50]
  154c88:      	ldp	x20, x19, [sp, #0x40]
  154c8c:      	ldp	x22, x21, [sp, #0x30]
  154c90:      	ldp	x24, x23, [sp, #0x20]
  154c94:      	ldp	x26, x25, [sp, #0x10]
  154c98:      	ldp	x28, x27, [sp], #0x60
  154c9c:      	b	0x154c9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x390>
  154ca0:      	mov	x1, x0
  154ca4:      	add	x0, sp, #0x188
  154ca8:      	mov	x24, x1
  154cac:      	bl	0x154cac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x3a0>
  154cb0:      	ldr	x22, [sp, #0x188]
  154cb4:      	cmn	x22, #0x2
  154cb8:      	b.ne	0x154da4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x498>
  154cbc:      	mov	x19, #0x2               ; =2
  154cc0:      	movk	x19, #0x7ffc, lsl #48
  154cc4:      	strb	wzr, [x24, #0xd4]
  154cc8:      	b	0x1560dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
  154ccc:      	ldr	x22, [x0, #0x78]
  154cd0:      	ldr	x9, [x0, #0xc0]
  154cd4:      	cmp	x22, #0x0
  154cd8:      	ccmp	x9, #0x0, #0x4, ne
  154cdc:      	b.ne	0x154e5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x550>
  154ce0:      	mov	x21, x0
  154ce4:      	mov	x8, #0x0                ; =0
  154ce8:      	mov	w27, #0x0               ; =0
  154cec:      	b	0x154e94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x588>
  154cf0:      	sub	w8, w8, #0x31
  154cf4:      	cmp	w8, #0x8
  154cf8:      	b.hi	0x1560d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
  154cfc:      	mov	x1, x10
  154d00:      	ldrb	w8, [x12, x1]
  154d04:      	sub	w8, w8, #0x30
  154d08:      	cmp	w8, #0x9
  154d0c:      	b.hi	0x154d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x41c>
  154d10:      	add	x1, x1, #0x1
  154d14:      	str	x1, [x0, #0x70]
  154d18:      	cmp	x2, x1
  154d1c:      	b.ne	0x154d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x3f4>
  154d20:      	mov	x1, x2
  154d24:      	b	0x154d50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x444>
  154d28:      	subs	x8, x1, x2
  154d2c:      	b.hs	0x154d50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x444>
  154d30:      	ldrb	w11, [x12, x1]
  154d34:      	cmp	w11, #0x2e
  154d38:      	b.eq	0x155cb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x13a4>
  154d3c:      	cmp	w11, #0x45
  154d40:      	b.eq	0x155b18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x120c>
  154d44:      	mov	x8, x1
  154d48:      	cmp	w11, #0x65
  154d4c:      	b.eq	0x155b1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
  154d50:      	subs	x8, x1, x10
  154d54:      	ccmp	x8, #0x13, #0x2, ne
  154d58:      	b.hs	0x155b18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x120c>
  154d5c:      	cmp	x1, x10
  154d60:      	b.lo	0x156384 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a78>
  154d64:      	cmp	x1, x2
  154d68:      	b.hi	0x156384 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a78>
  154d6c:      	mov	x9, #0x0                ; =0
  154d70:      	mov	w10, #0xa               ; =10
  154d74:      	ldrb	w11, [x14], #0x1
  154d78:      	mul	x9, x9, x10
  154d7c:      	sub	w11, w11, #0x30
  154d80:      	add	x9, x9, w11, uxtb
  154d84:      	subs	x8, x8, #0x1
  154d88:      	b.ne	0x154d74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x468>
  154d8c:      	ucvtf	d0, x9
  154d90:      	fneg	d1, d0
  154d94:      	cmp	w13, #0x0
  154d98:      	fcsel	d0, d1, d0, ne
  154d9c:      	fmov	x19, d0
  154da0:      	b	0x1560dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
  154da4:      	ldp	x21, x20, [sp, #0x190]
  154da8:      	cmp	x20, #0x6
  154dac:      	b.hs	0x154e3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x530>
  154db0:      	subs	x8, x20, #0x3
  154db4:      	b.lo	0x155c40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1334>
  154db8:      	ldrb	w9, [x21]
  154dbc:      	cmp	w9, #0xed
  154dc0:      	b.ne	0x154de0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4d4>
  154dc4:      	ldrb	w9, [x21, #0x1]
  154dc8:      	and	w9, w9, #0xe0
  154dcc:      	cmp	w9, #0xa0
  154dd0:      	b.ne	0x154de0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4d4>
  154dd4:      	ldrsb	w9, [x21, #0x2]
  154dd8:      	cmn	w9, #0x40
  154ddc:      	b.lt	0x154e3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x530>
  154de0:      	cbz	x8, 0x155c40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1334>
  154de4:      	ldrb	w9, [x21, #0x1]
  154de8:      	cmp	w9, #0xed
  154dec:      	b.ne	0x154e0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x500>
  154df0:      	ldrb	w9, [x21, #0x2]
  154df4:      	and	w9, w9, #0xe0
  154df8:      	cmp	w9, #0xa0
  154dfc:      	b.ne	0x154e0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x500>
  154e00:      	ldrsb	w9, [x21, #0x3]
  154e04:      	cmn	w9, #0x40
  154e08:      	b.lt	0x154e3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x530>
  154e0c:      	cmp	x8, #0x1
  154e10:      	b.eq	0x155c40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1334>
  154e14:      	ldrb	w8, [x21, #0x2]
  154e18:      	cmp	w8, #0xed
  154e1c:      	b.ne	0x155c40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1334>
  154e20:      	ldrb	w8, [x21, #0x3]
  154e24:      	and	w8, w8, #0xe0
  154e28:      	cmp	w8, #0xa0
  154e2c:      	b.ne	0x155c40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1334>
  154e30:      	ldrsb	w8, [x21, #0x4]
  154e34:      	cmn	w8, #0x40
  154e38:      	b.ge	0x155c40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1334>
  154e3c:      	cmn	x22, #0x1
  154e40:      	b.eq	0x155c6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1360>
  154e44:      	mov	x0, x21
  154e48:      	mov	x1, x20
  154e4c:      	bl	0x154e4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x540>
  154e50:      	mov	x19, #0x7fff000000000000 ; =9223090561878065152
  154e54:      	bfxil	x19, x0, #0, #48
  154e58:      	b	0x155dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x14b4>
  154e5c:      	ldp	q0, q1, [x0, #0x80]
  154e60:      	stur	q0, [sp, #0xa8]
  154e64:      	stur	q1, [sp, #0xb8]
  154e68:      	ldp	q0, q1, [x0, #0xa0]
  154e6c:      	stur	q0, [sp, #0xc8]
  154e70:      	stur	q1, [sp, #0xd8]
  154e74:      	mov	x21, x0
  154e78:      	ldr	w8, [x0, #0xd0]
  154e7c:      	stp	x22, x9, [sp, #0xe8]
  154e80:      	str	x9, [sp, #0x90]
  154e84:      	str	w8, [sp, #0x7c]
  154e88:      	str	w8, [sp, #0xf8]
  154e8c:      	mov	w8, #0x1                ; =1
  154e90:      	mov	w27, #0x1               ; =1
  154e94:      	str	x8, [sp, #0xa0]
  154e98:      	adrp	x0, 0x154000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x46c>
  154e9c:      	ldr	x0, [x0]
  154ea0:      	ldr	x8, [x0]
  154ea4:      	blr	x8
  154ea8:      	mov	x19, x0
  154eac:      	ldrb	w8, [x0, #0x20]
  154eb0:      	cbnz	w8, 0x1562c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19b4>
  154eb4:      	ldr	x8, [x19]
  154eb8:      	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
  154ebc:      	cmp	x8, x9
  154ec0:      	b.hs	0x1562ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19e0>
  154ec4:      	ldr	x23, [x19, #0x18]
  154ec8:      	ldp	x24, x28, [x21, #0x68]
  154ecc:      	cmp	x28, x24
  154ed0:      	b.hs	0x154f04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x5f8>
  154ed4:      	ldr	x8, [x21, #0x60]
  154ed8:      	ldrb	w8, [x8, x28]
  154edc:      	cmp	w8, #0x7d
  154ee0:      	b.ne	0x154f04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x5f8>
  154ee4:      	add	x8, x28, #0x1
  154ee8:      	str	x8, [x21, #0x70]
  154eec:      	ldr	x8, [x21, #0x78]
  154ef0:      	cbnz	x8, 0x155be4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x12d8>
  154ef4:      	ldr	x1, [x21, #0xc0]
  154ef8:      	cbz	x1, 0x155be4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x12d8>
  154efc:      	ldr	w2, [x21, #0xd0]
  154f00:      	b	0x155c04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x12f8>
  154f04:      	movi.2d	v0, #0000000000000000
  154f08:      	stp	q0, q0, [sp, #0x120]
  154f0c:      	stp	q0, q0, [sp, #0x100]
  154f10:      	adrp	x1, 0x154000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x46c>
  154f14:      	add	x1, x1, #0x0
  154f18:      	add	x0, sp, #0x148
  154f1c:      	mov	w2, #0x40               ; =64
  154f20:      	bl	0x154f20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x614>
  154f24:      	mov	x8, x21
  154f28:      	mov	x12, #0x0               ; =0
  154f2c:      	str	xzr, [sp, #0x98]
  154f30:      	mov	x9, #-0x1               ; =-1
  154f34:      	str	x9, [sp, #0x188]
  154f38:      	add	x9, sp, #0xa0
  154f3c:      	add	x9, x9, #0x8
  154f40:      	stp	x9, xzr, [sp, #0x68]
  154f44:      	mov	x25, #0x2600            ; =9728
  154f48:      	movk	x25, #0x1, lsl #32
  154f4c:      	adrp	x9, 0x154000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x46c>
  154f50:      	ldr	q0, [x9]
  154f54:      	str	q0, [sp, #0x50]
  154f58:      	adrp	x9, 0x154000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x46c>
  154f5c:      	ldr	q0, [x9]
  154f60:      	str	q0, [sp, #0x40]
  154f64:      	mov	x26, x27
  154f68:      	mov	x9, x27
  154f6c:      	str	w27, [sp, #0x88]
  154f70:      	str	x22, [sp, #0x80]
  154f74:      	str	w9, [sp, #0x8c]
  154f78:      	cmp	x28, x24
  154f7c:      	b.hs	0x154fac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6a0>
  154f80:      	ldr	x9, [x8, #0x60]
  154f84:      	ldrb	w10, [x9, x28]
  154f88:      	cmp	w10, #0x20
  154f8c:      	b.hi	0x154fac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6a0>
  154f90:      	lsr	x10, x25, x10
  154f94:      	tbz	w10, #0x0, 0x154fac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6a0>
  154f98:      	add	x28, x28, #0x1
  154f9c:      	str	x28, [x8, #0x70]
  154fa0:      	cmp	x24, x28
  154fa4:      	b.ne	0x154f84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x678>
  154fa8:      	mov	x28, x24
  154fac:      	cbz	w27, 0x155070 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x764>
  154fb0:      	cmp	x12, x22
  154fb4:      	cset	w9, lo
  154fb8:      	tst	w26, w9
  154fbc:      	b.eq	0x155070 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x764>
  154fc0:      	mov	x20, x26
  154fc4:      	mov	x26, x12
  154fc8:      	cmp	x12, #0x8
  154fcc:      	b.hs	0x156420 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b14>
  154fd0:      	cmp	x28, x24
  154fd4:      	b.hs	0x155084 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
  154fd8:      	ldr	x8, [sp, #0x68]
  154fdc:      	ldr	x9, [x8, x26, lsl #3]
  154fe0:      	cbz	x9, 0x155084 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
  154fe4:      	ldr	x10, [x21, #0x60]
  154fe8:      	ldrb	w8, [x10, x28]
  154fec:      	cmp	w8, #0x22
  154ff0:      	b.ne	0x155084 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
  154ff4:      	add	x11, x28, #0x1
  154ff8:      	ldr	w14, [x9, #0x4]
  154ffc:      	add	x8, x11, x14
  155000:      	cmp	x8, x24
  155004:      	ccmp	x8, x28, #0x0, lo
  155008:      	b.ls	0x155084 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
  15500c:      	ldrb	w12, [x10, x8]
  155010:      	cmp	w12, #0x22
  155014:      	b.ne	0x155084 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
  155018:      	add	x1, x10, x11
  15501c:      	cbz	w14, 0x155058 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x74c>
  155020:      	add	x9, x9, #0x14
  155024:      	mov	x10, x14
  155028:      	mov	x11, x1
  15502c:      	ldrb	w12, [x11], #0x1
  155030:      	cmp	w12, #0x5c
  155034:      	b.eq	0x155084 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
  155038:      	cmp	w12, #0x22
  15503c:      	b.eq	0x155084 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
  155040:      	ldrb	w13, [x9], #0x1
  155044:      	cmp	w12, #0x20
  155048:      	ccmp	w12, w13, #0x0, hs
  15504c:      	b.ne	0x155084 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
  155050:      	subs	x10, x10, #0x1
  155054:      	b.ne	0x15502c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x720>
  155058:      	add	x9, x8, #0x1
  15505c:      	mov	x8, x21
  155060:      	str	x9, [x21, #0x70]
  155064:      	mov	w24, #0x1               ; =1
  155068:      	mov	x27, #-0x1              ; =-1
  15506c:      	b	0x1550a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x79c>
  155070:      	mov	x20, x26
  155074:      	mov	x26, x12
  155078:      	mov	x1, x8
  15507c:      	sub	x0, x29, #0x80
  155080:      	b	0x15508c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x780>
  155084:      	sub	x0, x29, #0x80
  155088:      	mov	x1, x21
  15508c:      	bl	0x15508c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x780>
  155090:      	ldur	x27, [x29, #-0x80]
  155094:      	cmn	x27, #0x2
  155098:      	b.eq	0x155e14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1508>
  15509c:      	mov	w24, #0x0               ; =0
  1550a0:      	ldp	x1, x14, [x29, #-0x78]
  1550a4:      	mov	x8, x21
  1550a8:      	ldr	x28, [sp, #0x98]
  1550ac:      	ldp	x10, x9, [x8, #0x68]
  1550b0:      	cmp	x9, x10
  1550b4:      	b.hs	0x155abc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11b0>
  1550b8:      	ldr	x11, [x8, #0x60]
  1550bc:      	ldrb	w12, [x11, x9]
  1550c0:      	cmp	w12, #0x3a
  1550c4:      	b.hi	0x155abc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11b0>
  1550c8:      	lsr	x13, x25, x12
  1550cc:      	tbz	w13, #0x0, 0x1550e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x7d8>
  1550d0:      	add	x9, x9, #0x1
  1550d4:      	str	x9, [x8, #0x70]
  1550d8:      	cmp	x10, x9
  1550dc:      	b.ne	0x1550bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x7b0>
  1550e0:      	b	0x155abc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11b0>
  1550e4:      	cmp	x12, #0x3a
  1550e8:      	b.ne	0x155abc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11b0>
  1550ec:      	stp	x14, x1, [sp, #0x30]
  1550f0:      	add	x9, x9, #0x1
  1550f4:      	str	x9, [x8, #0x70]
  1550f8:      	mov	x0, x21
  1550fc:      	bl	0x15490c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_>
  155100:      	mov	x8, x21
  155104:      	ldrb	w9, [x21, #0xd4]
  155108:      	tbz	w9, #0x0, 0x156270 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1964>
  15510c:      	ldr	x10, [sp, #0x188]
  155110:      	cmn	x10, #0x1
  155114:      	ldp	x3, x17, [sp, #0x30]
  155118:      	str	x0, [sp, #0x28]
  15511c:      	b.eq	0x1551d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8c8>
  155120:      	ldr	x9, [sp, #0x1b8]
  155124:      	cmn	x9, #0x1
  155128:      	b.eq	0x155218 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x90c>
  15512c:      	ldp	x8, x11, [sp, #0x1f0]
  155130:      	ldr	x10, [sp, #0x200]
  155134:      	ldr	x9, [sp, #0x208]
  155138:      	eor	x11, x11, x3
  15513c:      	mov	x13, #0x7f2d            ; =32557
  155140:      	movk	x13, #0x4c95, lsl #16
  155144:      	movk	x13, #0xf42d, lsl #32
  155148:      	movk	x13, #0x5851, lsl #48
  15514c:      	mul	x12, x11, x13
  155150:      	umulh	x11, x11, x13
  155154:      	eor	x11, x11, x12
  155158:      	add	x11, x3, x11
  15515c:      	mul	x11, x11, x13
  155160:      	cmp	x3, #0x8
  155164:      	b.ls	0x15526c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x960>
  155168:      	cmp	x3, #0x10
  15516c:      	b.ls	0x155320 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa14>
  155170:      	add	x12, x17, x3
  155174:      	ldp	x12, x13, [x12, #-0x10]
  155178:      	eor	x12, x10, x12
  15517c:      	eor	x13, x13, x9
  155180:      	mul	x14, x13, x12
  155184:      	umulh	x12, x13, x12
  155188:      	eor	x12, x12, x14
  15518c:      	add	x11, x11, x8
  155190:      	eor	x11, x11, x12
  155194:      	ror	x11, x11, #0x29
  155198:      	mov	x13, x17
  15519c:      	mov	x12, x3
  1551a0:      	ldp	x15, x14, [x13], #0x10
  1551a4:      	sub	x12, x12, #0x10
  1551a8:      	eor	x15, x10, x15
  1551ac:      	eor	x14, x14, x9
  1551b0:      	mul	x16, x14, x15
  1551b4:      	umulh	x14, x14, x15
  1551b8:      	eor	x14, x14, x16
  1551bc:      	add	x11, x11, x8
  1551c0:      	eor	x11, x11, x14
  1551c4:      	ror	x11, x11, #0x29
  1551c8:      	cmp	x12, #0x10
  1551cc:      	b.hi	0x1551a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x894>
  1551d0:      	b	0x15540c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xb00>
  1551d4:      	ldr	w9, [sp, #0x8c]
  1551d8:      	tbz	w9, #0x0, 0x15528c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x980>
  1551dc:      	ldr	w9, [sp, #0x88]
  1551e0:      	tbz	w9, #0x0, 0x1563f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ae4>
  1551e4:      	mov	x12, x26
  1551e8:      	ldr	x9, [sp, #0x80]
  1551ec:      	cmp	x26, x9
  1551f0:      	b.hs	0x15554c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc40>
  1551f4:      	mov	x26, x20
  1551f8:      	tbz	w24, #0x0, 0x15550c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc00>
  1551fc:      	cmp	x12, #0x7
  155200:      	b.hi	0x156458 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b4c>
  155204:      	ldr	x9, [sp, #0x68]
  155208:      	ldr	x11, [x9, x12, lsl #3]
  15520c:      	add	x12, x12, #0x1
  155210:      	mov	w9, #0x1                ; =1
  155214:      	b	0x155570 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc64>
  155218:      	str	x10, [sp, #0x10]
  15521c:      	ldp	x1, x24, [sp, #0x190]
  155220:      	cmp	x24, #0x80
  155224:      	b.ne	0x1552b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x9a4>
  155228:      	mov	w9, #0x1                ; =1
  15522c:      	strb	w9, [x8, #0xd6]
  155230:      	add	x8, sp, #0x188
  155234:      	add	x0, x8, #0x30
  155238:      	mov	x28, x1
  15523c:      	bl	0x15523c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x930>
  155240:      	ldp	x3, x17, [sp, #0x30]
  155244:      	ldr	x8, [sp, #0x1b8]
  155248:      	cmn	x8, #0x1
  15524c:      	b.ne	0x15512c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x820>
  155250:      	mov	x0, x17
  155254:      	mov	x1, x3
  155258:      	bl	0x155258 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x94c>
  15525c:      	mov	x13, x0
  155260:      	add	x22, x28, #0x400
  155264:      	mov	x11, x28
  155268:      	b	0x1552d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x9c4>
  15526c:      	cmp	x3, #0x1
  155270:      	b.ls	0x155330 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa24>
  155274:      	add	x13, x17, x3
  155278:      	cmp	x3, #0x3
  15527c:      	b.ls	0x1553d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xacc>
  155280:      	ldr	w12, [x17]
  155284:      	ldur	w13, [x13, #-0x4]
  155288:      	b	0x1553ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xae0>
  15528c:      	mov	x0, x17
  155290:      	mov	x1, x3
  155294:      	bl	0x155294 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x988>
  155298:      	mov	x11, x0
  15529c:      	mov	x8, x21
  1552a0:      	mov	w9, #0x0                ; =0
  1552a4:      	mov	x12, x26
  1552a8:      	mov	x26, x20
  1552ac:      	b	0x155570 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc64>
  1552b0:      	str	x1, [sp, #0x8]
  1552b4:      	mov	x0, x17
  1552b8:      	mov	x1, x3
  1552bc:      	bl	0x1552bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x9b0>
  1552c0:      	mov	x13, x0
  1552c4:      	cbz	x24, 0x155938 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x102c>
  1552c8:      	ldr	x11, [sp, #0x8]
  1552cc:      	add	x22, x11, x24, lsl #3
  1552d0:      	mov	x12, x26
  1552d4:      	cmp	x26, #0x0
  1552d8:      	cset	w8, eq
  1552dc:      	ldr	w9, [sp, #0x8c]
  1552e0:      	orr	w8, w8, w9
  1552e4:      	tbz	w8, #0x0, 0x155340 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa34>
  1552e8:      	mov	x0, #0x0                ; =0
  1552ec:      	mov	x9, x11
  1552f0:      	mov	x8, x21
  1552f4:      	mov	x26, x20
  1552f8:      	ldr	x1, [sp, #0x38]
  1552fc:      	ldr	x20, [sp, #0x20]
  155300:      	ldr	x10, [x9], #0x8
  155304:      	cmp	x10, x13
  155308:      	b.eq	0x1553bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xab0>
  15530c:      	add	x0, x0, #0x1
  155310:      	cmp	x9, x22
  155314:      	b.ne	0x155300 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x9f4>
  155318:      	ldr	x28, [sp, #0x98]
  15531c:      	b	0x155964 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1058>
  155320:      	ldr	x12, [x17]
  155324:      	add	x13, x17, x3
  155328:      	ldur	x13, [x13, #-0x8]
  15532c:      	b	0x1553ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xae0>
  155330:      	b.ne	0x1553e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xad8>
  155334:      	ldrb	w12, [x17]
  155338:      	mov	x13, x12
  15533c:      	b	0x1553ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xae0>
  155340:      	stp	x24, x11, [sp]
  155344:      	str	x23, [sp, #0x18]
  155348:      	mov	x24, #0x0               ; =0
  15534c:      	mov	x23, x11
  155350:      	mov	x26, x20
  155354:      	ldp	x2, x1, [sp, #0x30]
  155358:      	ldr	x20, [sp, #0x20]
  15535c:      	b	0x15536c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa60>
  155360:      	sub	x24, x24, #0x1
  155364:      	cmp	x23, x22
  155368:      	b.eq	0x155950 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1044>
  15536c:      	ldr	x8, [x23], #0x8
  155370:      	cmp	x8, x13
  155374:      	b.eq	0x1553b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xaa4>
  155378:      	ldr	w9, [x8, #0x4]
  15537c:      	cmp	x2, x9
  155380:      	b.ne	0x155360 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa54>
  155384:      	add	x0, x8, #0x14
  155388:      	mov	x20, x26
  15538c:      	mov	x26, x12
  155390:      	mov	x28, x13
  155394:      	bl	0x155394 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa88>
  155398:      	mov	x13, x28
  15539c:      	ldp	x2, x1, [sp, #0x30]
  1553a0:      	mov	x12, x26
  1553a4:      	mov	x26, x20
  1553a8:      	ldr	x20, [sp, #0x20]
  1553ac:      	cbnz	w0, 0x155360 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa54>
  1553b0:      	neg	x0, x24
  1553b4:      	mov	x8, x21
  1553b8:      	ldr	x23, [sp, #0x18]
  1553bc:      	cmp	x0, x20
  1553c0:      	ldr	x28, [sp, #0x98]
  1553c4:      	ldr	x9, [sp, #0x60]
  1553c8:      	b.hs	0x156448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b3c>
  1553cc:      	ldr	x10, [sp, #0x28]
  1553d0:      	str	x10, [x9, x0, lsl #3]
  1553d4:      	b	0x1559a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1098>
  1553d8:      	ldrh	w12, [x17]
  1553dc:      	ldurb	w13, [x13, #-0x1]
  1553e0:      	b	0x1553ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xae0>
  1553e4:      	mov	x12, #0x0               ; =0
  1553e8:      	mov	x13, #0x0               ; =0
  1553ec:      	eor	x10, x12, x10
  1553f0:      	eor	x9, x13, x9
  1553f4:      	mul	x12, x9, x10
  1553f8:      	umulh	x9, x9, x10
  1553fc:      	eor	x9, x9, x12
  155400:      	add	x10, x11, x8
  155404:      	eor	x9, x10, x9
  155408:      	ror	x11, x9, #0x29
  15540c:      	mul	x9, x11, x8
  155410:      	umulh	x8, x11, x8
  155414:      	eor	x8, x8, x9
  155418:      	neg	w9, w11
  15541c:      	ror	x24, x8, x9
  155420:      	ldp	x4, x28, [sp, #0x190]
  155424:      	add	x8, sp, #0x188
  155428:      	add	x0, x8, #0x30
  15542c:      	mov	x1, x24
  155430:      	mov	x2, x17
  155434:      	mov	x5, x28
  155438:      	bl	0x155438 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xb2c>
  15543c:      	tbz	w0, #0x0, 0x155468 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xb5c>
  155440:      	ldr	x8, [sp, #0x20]
  155444:      	cmp	x1, x8
  155448:      	b.hs	0x156434 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b28>
  15544c:      	mov	x8, x21
  155450:      	mov	x12, x26
  155454:      	ldr	x9, [sp, #0x60]
  155458:      	ldr	x10, [sp, #0x28]
  15545c:      	str	x10, [x9, x1, lsl #3]
  155460:      	ldr	x28, [sp, #0x98]
  155464:      	b	0x155500 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xbf4>
  155468:      	cmn	x27, #0x1
  15546c:      	str	x23, [sp, #0x18]
  155470:      	b.eq	0x155480 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xb74>
  155474:      	ldp	x1, x0, [sp, #0x30]
  155478:      	bl	0x155478 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xb6c>
  15547c:      	b	0x15548c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xb80>
  155480:      	add	x0, x21, #0x20
  155484:      	ldp	x2, x1, [sp, #0x30]
  155488:      	bl	0x155488 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xb7c>
  15548c:      	mov	x22, x0
  155490:      	add	x8, sp, #0x188
  155494:      	add	x0, x8, #0x30
  155498:      	mov	x1, x24
  15549c:      	mov	x2, x28
  1554a0:      	bl	0x1554a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xb94>
  1554a4:      	ldr	x23, [sp, #0x198]
  1554a8:      	ldr	x8, [sp, #0x188]
  1554ac:      	cmp	x23, x8
  1554b0:      	b.eq	0x155a30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1124>
  1554b4:      	ldr	x8, [sp, #0x190]
  1554b8:      	str	x22, [x8, x23, lsl #3]
  1554bc:      	add	x8, x23, #0x1
  1554c0:      	str	x8, [sp, #0x198]
  1554c4:      	ldr	x23, [sp, #0x1b0]
  1554c8:      	ldr	x8, [sp, #0x1a0]
  1554cc:      	cmp	x23, x8
  1554d0:      	ldr	x28, [sp, #0x98]
  1554d4:      	b.eq	0x155a3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1130>
  1554d8:      	ldr	x8, [sp, #0x1a8]
  1554dc:      	str	x8, [sp, #0x60]
  1554e0:      	ldr	x9, [sp, #0x28]
  1554e4:      	str	x9, [x8, x23, lsl #3]
  1554e8:      	add	x8, x23, #0x1
  1554ec:      	str	x8, [sp, #0x20]
  1554f0:      	str	x8, [sp, #0x1b0]
  1554f4:      	mov	x8, x21
  1554f8:      	ldr	x23, [sp, #0x18]
  1554fc:      	mov	x12, x26
  155500:      	mov	x26, x20
  155504:      	ldr	x1, [sp, #0x38]
  155508:      	b	0x1559a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1098>
  15550c:      	cmp	x12, #0x8
  155510:      	b.hs	0x15646c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b60>
  155514:      	ldr	x8, [sp, #0x68]
  155518:      	ldr	x9, [x8, x12, lsl #3]
  15551c:      	ldr	w8, [x9, #0x4]
  155520:      	cmp	x3, x8
  155524:      	b.ne	0x15554c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc40>
  155528:      	add	x0, x9, #0x14
  15552c:      	mov	x1, x17
  155530:      	mov	x2, x3
  155534:      	mov	x24, x12
  155538:      	mov	x20, x9
  15553c:      	bl	0x15553c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc30>
  155540:      	ldp	x3, x17, [sp, #0x30]
  155544:      	mov	x12, x24
  155548:      	cbz	w0, 0x155a4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1140>
  15554c:      	mov	x0, x17
  155550:      	mov	x1, x3
  155554:      	mov	x24, x12
  155558:      	bl	0x155558 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc4c>
  15555c:      	mov	x12, x24
  155560:      	mov	x11, x0
  155564:      	mov	x8, x21
  155568:      	mov	w26, #0x0               ; =0
  15556c:      	mov	w9, #0x0                ; =0
  155570:      	cmp	x12, #0x0
  155574:      	str	w9, [sp, #0x8c]
  155578:      	csinc	w24, w9, wzr, ne
  15557c:      	cmp	x28, #0x9
  155580:      	b.hs	0x1563a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a9c>
  155584:      	ldp	x2, x1, [sp, #0x30]
  155588:      	cbz	x28, 0x155908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
  15558c:      	ldr	x9, [sp, #0x100]
  155590:      	cmp	x9, x11
  155594:      	b.eq	0x155928 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x101c>
  155598:      	tbnz	w24, #0x0, 0x1555d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xcc8>
  15559c:      	ldr	w10, [x9, #0x4]
  1555a0:      	cmp	x2, x10
  1555a4:      	b.ne	0x1555d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xcc8>
  1555a8:      	add	x0, x9, #0x14
  1555ac:      	mov	x20, x26
  1555b0:      	mov	x26, x12
  1555b4:      	str	x11, [sp, #0x98]
  1555b8:      	bl	0x1555b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xcac>
  1555bc:      	ldr	x11, [sp, #0x98]
  1555c0:      	ldp	x2, x1, [sp, #0x30]
  1555c4:      	mov	x12, x26
  1555c8:      	mov	x26, x20
  1555cc:      	mov	x8, x21
  1555d0:      	cbz	w0, 0x155928 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x101c>
  1555d4:      	cmp	x28, #0x1
  1555d8:      	b.eq	0x155908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
  1555dc:      	ldr	x10, [sp, #0x108]
  1555e0:      	add	x9, sp, #0x148
  1555e4:      	add	x9, x9, #0x8
  1555e8:      	cmp	x10, x11
  1555ec:      	b.eq	0x15592c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
  1555f0:      	tbnz	w24, #0x0, 0x155634 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xd28>
  1555f4:      	ldr	w9, [x10, #0x4]
  1555f8:      	cmp	x2, x9
  1555fc:      	b.ne	0x155634 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xd28>
  155600:      	add	x0, x10, #0x14
  155604:      	mov	x20, x26
  155608:      	mov	x26, x12
  15560c:      	str	x11, [sp, #0x98]
  155610:      	bl	0x155610 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xd04>
  155614:      	ldr	x11, [sp, #0x98]
  155618:      	ldp	x2, x1, [sp, #0x30]
  15561c:      	mov	x12, x26
  155620:      	mov	x26, x20
  155624:      	mov	x8, x21
  155628:      	add	x9, sp, #0x148
  15562c:      	add	x9, x9, #0x8
  155630:      	cbz	w0, 0x15592c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
  155634:      	cmp	x28, #0x2
  155638:      	b.eq	0x155908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
  15563c:      	ldr	x10, [sp, #0x110]
  155640:      	add	x9, sp, #0x148
  155644:      	add	x9, x9, #0x10
  155648:      	cmp	x10, x11
  15564c:      	b.eq	0x15592c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
  155650:      	tbnz	w24, #0x0, 0x155694 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xd88>
  155654:      	ldr	w9, [x10, #0x4]
  155658:      	cmp	x2, x9
  15565c:      	b.ne	0x155694 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xd88>
  155660:      	add	x0, x10, #0x14
  155664:      	mov	x20, x26
  155668:      	mov	x26, x12
  15566c:      	str	x11, [sp, #0x98]
  155670:      	bl	0x155670 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xd64>
  155674:      	ldr	x11, [sp, #0x98]
  155678:      	ldp	x2, x1, [sp, #0x30]
  15567c:      	mov	x12, x26
  155680:      	mov	x26, x20
  155684:      	mov	x8, x21
  155688:      	add	x9, sp, #0x148
  15568c:      	add	x9, x9, #0x10
  155690:      	cbz	w0, 0x15592c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
  155694:      	cmp	x28, #0x3
  155698:      	b.eq	0x155908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
  15569c:      	ldr	x10, [sp, #0x118]
  1556a0:      	add	x9, sp, #0x148
  1556a4:      	add	x9, x9, #0x18
  1556a8:      	cmp	x10, x11
  1556ac:      	b.eq	0x15592c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
  1556b0:      	tbnz	w24, #0x0, 0x1556f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xde8>
  1556b4:      	ldr	w9, [x10, #0x4]
  1556b8:      	cmp	x2, x9
  1556bc:      	b.ne	0x1556f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xde8>
  1556c0:      	add	x0, x10, #0x14
  1556c4:      	mov	x20, x26
  1556c8:      	mov	x26, x12
  1556cc:      	str	x11, [sp, #0x98]
  1556d0:      	bl	0x1556d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xdc4>
  1556d4:      	ldr	x11, [sp, #0x98]
  1556d8:      	ldp	x2, x1, [sp, #0x30]
  1556dc:      	mov	x12, x26
  1556e0:      	mov	x26, x20
  1556e4:      	mov	x8, x21
  1556e8:      	add	x9, sp, #0x148
  1556ec:      	add	x9, x9, #0x18
  1556f0:      	cbz	w0, 0x15592c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
  1556f4:      	cmp	x28, #0x4
  1556f8:      	b.eq	0x155908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
  1556fc:      	ldr	x10, [sp, #0x120]
  155700:      	add	x9, sp, #0x148
  155704:      	add	x9, x9, #0x20
  155708:      	cmp	x10, x11
  15570c:      	b.eq	0x15592c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
  155710:      	tbnz	w24, #0x0, 0x155754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xe48>
  155714:      	ldr	w9, [x10, #0x4]
  155718:      	cmp	x2, x9
  15571c:      	b.ne	0x155754 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xe48>
  155720:      	add	x0, x10, #0x14
  155724:      	mov	x20, x26
  155728:      	mov	x26, x12
  15572c:      	str	x11, [sp, #0x98]
  155730:      	bl	0x155730 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xe24>
  155734:      	ldr	x11, [sp, #0x98]
  155738:      	ldp	x2, x1, [sp, #0x30]
  15573c:      	mov	x12, x26
  155740:      	mov	x26, x20
  155744:      	mov	x8, x21
  155748:      	add	x9, sp, #0x148
  15574c:      	add	x9, x9, #0x20
  155750:      	cbz	w0, 0x15592c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
  155754:      	cmp	x28, #0x5
  155758:      	b.eq	0x155908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
  15575c:      	ldr	x10, [sp, #0x128]
  155760:      	add	x9, sp, #0x148
  155764:      	add	x9, x9, #0x28
  155768:      	cmp	x10, x11
  15576c:      	b.eq	0x15592c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
  155770:      	tbnz	w24, #0x0, 0x1557b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xea8>
  155774:      	ldr	w9, [x10, #0x4]
  155778:      	cmp	x2, x9
  15577c:      	b.ne	0x1557b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xea8>
  155780:      	add	x0, x10, #0x14
  155784:      	mov	x20, x26
  155788:      	mov	x26, x12
  15578c:      	str	x11, [sp, #0x98]
  155790:      	bl	0x155790 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xe84>
  155794:      	ldr	x11, [sp, #0x98]
  155798:      	ldp	x2, x1, [sp, #0x30]
  15579c:      	mov	x12, x26
  1557a0:      	mov	x26, x20
  1557a4:      	mov	x8, x21
  1557a8:      	add	x9, sp, #0x148
  1557ac:      	add	x9, x9, #0x28
  1557b0:      	cbz	w0, 0x15592c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
  1557b4:      	cmp	x28, #0x6
  1557b8:      	b.eq	0x155908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
  1557bc:      	ldr	x10, [sp, #0x130]
  1557c0:      	add	x9, sp, #0x148
  1557c4:      	add	x9, x9, #0x30
  1557c8:      	cmp	x10, x11
  1557cc:      	b.eq	0x15592c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
  1557d0:      	tbnz	w24, #0x0, 0x155814 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xf08>
  1557d4:      	ldr	w9, [x10, #0x4]
  1557d8:      	cmp	x2, x9
  1557dc:      	b.ne	0x155814 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xf08>
  1557e0:      	add	x0, x10, #0x14
  1557e4:      	mov	x20, x26
  1557e8:      	mov	x26, x12
  1557ec:      	str	x11, [sp, #0x98]
  1557f0:      	bl	0x1557f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xee4>
  1557f4:      	ldr	x11, [sp, #0x98]
  1557f8:      	ldp	x2, x1, [sp, #0x30]
  1557fc:      	mov	x12, x26
  155800:      	mov	x26, x20
  155804:      	mov	x8, x21
  155808:      	add	x9, sp, #0x148
  15580c:      	add	x9, x9, #0x30
  155810:      	cbz	w0, 0x15592c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
  155814:      	cmp	x28, #0x7
  155818:      	b.eq	0x155908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
  15581c:      	ldr	x10, [sp, #0x138]
  155820:      	add	x9, sp, #0x148
  155824:      	add	x9, x9, #0x38
  155828:      	cmp	x10, x11
  15582c:      	b.eq	0x15592c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
  155830:      	tbnz	w24, #0x0, 0x15586c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xf60>
  155834:      	ldr	w9, [x10, #0x4]
  155838:      	cmp	x2, x9
  15583c:      	b.ne	0x15586c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xf60>
  155840:      	add	x0, x10, #0x14
  155844:      	mov	x24, x12
  155848:      	mov	x20, x11
  15584c:      	bl	0x15584c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xf40>
  155850:      	mov	x11, x20
  155854:      	ldr	x1, [sp, #0x38]
  155858:      	mov	x12, x24
  15585c:      	mov	x8, x21
  155860:      	add	x9, sp, #0x148
  155864:      	add	x9, x9, #0x38
  155868:      	cbz	w0, 0x15592c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
  15586c:      	cmp	x28, #0x8
  155870:      	b.ne	0x155908 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
  155874:      	mov	x28, x11
  155878:      	mov	x20, x26
  15587c:      	mov	x26, x12
  155880:      	mov	w0, #0x80               ; =128
  155884:      	mov	w1, #0x8                ; =8
  155888:      	bl	0x155888 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xf7c>
  15588c:      	cbz	x0, 0x156480 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b74>
  155890:      	mov	x24, x0
  155894:      	mov	w0, #0x80               ; =128
  155898:      	mov	w1, #0x8                ; =8
  15589c:      	bl	0x15589c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xf90>
  1558a0:      	str	x0, [sp, #0x60]
  1558a4:      	cbz	x0, 0x156480 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b74>
  1558a8:      	ldp	q0, q1, [sp, #0x100]
  1558ac:      	stp	q0, q1, [x24]
  1558b0:      	ldp	q0, q1, [sp, #0x120]
  1558b4:      	stp	q0, q1, [x24, #0x20]
  1558b8:      	add	x9, sp, #0x148
  1558bc:      	ldp	q0, q1, [x9]
  1558c0:      	ldr	x8, [sp, #0x60]
  1558c4:      	stp	q0, q1, [x8]
  1558c8:      	ldp	q0, q1, [x9, #0x20]
  1558cc:      	stp	q0, q1, [x8, #0x20]
  1558d0:      	str	x28, [x24, #0x40]
  1558d4:      	ldr	x10, [sp, #0x28]
  1558d8:      	str	x10, [x8, #0x40]
  1558dc:      	mov	w10, #0x10              ; =16
  1558e0:      	stp	x10, x24, [sp, #0x188]
  1558e4:      	ldp	q0, q1, [sp, #0x40]
  1558e8:      	str	q1, [x9, #0x50]
  1558ec:      	str	x8, [sp, #0x1a8]
  1558f0:      	mov	w8, #0x9                ; =9
  1558f4:      	str	x8, [sp, #0x20]
  1558f8:      	mov	w28, #0x8               ; =8
  1558fc:      	stur	q0, [x9, #0x68]
  155900:      	mov	x8, x21
  155904:      	b	0x1554fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xbf0>
  155908:      	add	x9, sp, #0x100
  15590c:      	str	x11, [x9, x28, lsl #3]
  155910:      	add	x9, sp, #0x148
  155914:      	ldr	x10, [sp, #0x28]
  155918:      	str	x10, [x9, x28, lsl #3]
  15591c:      	add	x28, x28, #0x1
  155920:      	str	x28, [sp, #0x70]
  155924:      	b	0x1559a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1098>
  155928:      	add	x9, sp, #0x148
  15592c:      	ldr	x10, [sp, #0x28]
  155930:      	str	x10, [x9]
  155934:      	b	0x1559a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1098>
  155938:      	mov	x8, x21
  15593c:      	mov	x12, x26
  155940:      	mov	x26, x20
  155944:      	ldr	x1, [sp, #0x38]
  155948:      	ldr	x20, [sp, #0x20]
  15594c:      	b	0x155960 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1054>
  155950:      	mov	x8, x21
  155954:      	ldr	x23, [sp, #0x18]
  155958:      	ldr	x28, [sp, #0x98]
  15595c:      	ldr	x24, [sp]
  155960:      	ldr	x11, [sp, #0x8]
  155964:      	ldr	x9, [sp, #0x10]
  155968:      	cmp	x24, x9
  15596c:      	b.eq	0x155a58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x114c>
  155970:      	str	x13, [x11, x24, lsl #3]
  155974:      	add	x9, x24, #0x1
  155978:      	str	x9, [sp, #0x198]
  15597c:      	ldr	x9, [sp, #0x1a0]
  155980:      	cmp	x20, x9
  155984:      	b.eq	0x155a9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1190>
  155988:      	ldr	x9, [sp, #0x1a8]
  15598c:      	str	x9, [sp, #0x60]
  155990:      	ldr	x10, [sp, #0x28]
  155994:      	str	x10, [x9, x20, lsl #3]
  155998:      	add	x20, x20, #0x1
  15599c:      	str	x20, [sp, #0x20]
  1559a0:      	str	x20, [sp, #0x1b0]
  1559a4:      	ldp	x24, x9, [x8, #0x68]
  1559a8:      	cmp	x9, x24
  1559ac:      	b.hs	0x1559dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x10d0>
  1559b0:      	ldr	x10, [x8, #0x60]
  1559b4:      	ldrb	w11, [x10, x9]
  1559b8:      	cmp	w11, #0x20
  1559bc:      	b.hi	0x1559dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x10d0>
  1559c0:      	lsr	x11, x25, x11
  1559c4:      	tbz	w11, #0x0, 0x1559dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x10d0>
  1559c8:      	add	x9, x9, #0x1
  1559cc:      	str	x9, [x8, #0x70]
  1559d0:      	cmp	x24, x9
  1559d4:      	b.ne	0x1559b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x10a8>
  1559d8:      	b	0x155c64 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1358>
  1559dc:      	cmp	x9, x24
  1559e0:      	b.hs	0x155c64 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1358>
  1559e4:      	ldr	x10, [x8, #0x60]
  1559e8:      	ldrb	w10, [x10, x9]
  1559ec:      	cmp	w10, #0x2c
  1559f0:      	b.ne	0x155c64 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1358>
  1559f4:      	str	x28, [sp, #0x98]
  1559f8:      	add	x28, x9, #0x1
  1559fc:      	str	x28, [x8, #0x70]
  155a00:      	cmp	x27, #0x1
  155a04:      	ldr	x22, [sp, #0x80]
  155a08:      	ldp	w27, w9, [sp, #0x88]
  155a0c:      	b.lt	0x154f74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x668>
  155a10:      	mov	x0, x1
  155a14:      	mov	x24, x12
  155a18:      	bl	0x155a18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x110c>
  155a1c:      	ldr	w9, [sp, #0x8c]
  155a20:      	mov	x12, x24
  155a24:      	mov	x8, x21
  155a28:      	ldp	x24, x28, [x21, #0x68]
  155a2c:      	b	0x154f74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x668>
  155a30:      	add	x0, sp, #0x188
  155a34:      	bl	0x155a34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1128>
  155a38:      	b	0x1554b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xba8>
  155a3c:      	add	x8, sp, #0x188
  155a40:      	add	x0, x8, #0x18
  155a44:      	bl	0x155a44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1138>
  155a48:      	b	0x1554d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xbcc>
  155a4c:      	mov	x11, x20
  155a50:      	mov	x8, x21
  155a54:      	b	0x15520c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x900>
  155a58:      	add	x0, sp, #0x188
  155a5c:      	mov	x20, x24
  155a60:      	mov	x24, x12
  155a64:      	mov	x22, x13
  155a68:      	bl	0x155a68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x115c>
  155a6c:      	ldr	x1, [sp, #0x38]
  155a70:      	mov	x12, x24
  155a74:      	mov	x24, x20
  155a78:      	mov	x8, x21
  155a7c:      	ldr	x11, [sp, #0x190]
  155a80:      	ldr	x20, [sp, #0x1b0]
  155a84:      	str	x22, [x11, x24, lsl #3]
  155a88:      	add	x9, x24, #0x1
  155a8c:      	str	x9, [sp, #0x198]
  155a90:      	ldr	x9, [sp, #0x1a0]
  155a94:      	cmp	x20, x9
  155a98:      	b.ne	0x155988 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x107c>
  155a9c:      	add	x8, sp, #0x188
  155aa0:      	add	x0, x8, #0x18
  155aa4:      	mov	x24, x12
  155aa8:      	bl	0x155aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x119c>
  155aac:      	ldr	x1, [sp, #0x38]
  155ab0:      	mov	x12, x24
  155ab4:      	mov	x8, x21
  155ab8:      	b	0x155988 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x107c>
  155abc:      	strb	wzr, [x8, #0xd4]
  155ac0:      	cmp	x27, #0x1
  155ac4:      	b.lt	0x155ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11c8>
  155ac8:      	mov	x0, x1
  155acc:      	bl	0x155acc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11c0>
  155ad0:      	mov	x8, x21
  155ad4:      	ldr	x20, [sp, #0x90]
  155ad8:      	ldp	x10, x9, [x8, #0x68]
  155adc:      	cmp	x9, x10
  155ae0:      	b.hs	0x155e28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x151c>
  155ae4:      	ldr	x11, [x8, #0x60]
  155ae8:      	mov	x12, #0x2600            ; =9728
  155aec:      	movk	x12, #0x1, lsl #32
  155af0:      	ldrb	w13, [x11, x9]
  155af4:      	cmp	w13, #0x20
  155af8:      	b.hi	0x155bd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x12c4>
  155afc:      	lsr	x14, x12, x13
  155b00:      	tbz	w14, #0x0, 0x155bd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x12c4>
  155b04:      	add	x9, x9, #0x1
  155b08:      	str	x9, [x8, #0x70]
  155b0c:      	cmp	x10, x9
  155b10:      	b.ne	0x155af0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11e4>
  155b14:      	b	0x155e28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x151c>
  155b18:      	mov	x8, x1
  155b1c:      	cmp	x8, x2
  155b20:      	b.hs	0x155b98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x128c>
  155b24:      	ldrb	w10, [x12, x8]
  155b28:      	orr	w10, w10, #0x20
  155b2c:      	cmp	w10, #0x65
  155b30:      	b.ne	0x155b98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x128c>
  155b34:      	add	x10, x8, #0x1
  155b38:      	str	x10, [x0, #0x70]
  155b3c:      	cmp	x10, x2
  155b40:      	b.hs	0x155b60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1254>
  155b44:      	ldrb	w11, [x12, x10]
  155b48:      	cmp	w11, #0x2d
  155b4c:      	b.eq	0x155b58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x124c>
  155b50:      	cmp	w11, #0x2b
  155b54:      	b.ne	0x155b60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1254>
  155b58:      	add	x10, x8, #0x2
  155b5c:      	str	x10, [x0, #0x70]
  155b60:      	cmp	x10, x2
  155b64:      	b.hs	0x1560d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
  155b68:      	mov	x8, x10
  155b6c:      	ldrb	w11, [x12, x8]
  155b70:      	sub	w11, w11, #0x30
  155b74:      	cmp	w11, #0x9
  155b78:      	b.hi	0x155b90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1284>
  155b7c:      	add	x8, x8, #0x1
  155b80:      	str	x8, [x0, #0x70]
  155b84:      	cmp	x2, x8
  155b88:      	b.ne	0x155b6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1260>
  155b8c:      	mov	x8, x2
  155b90:      	cmp	x8, x10
  155b94:      	b.eq	0x1560d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
  155b98:      	subs	x1, x8, x19
  155b9c:      	b.lo	0x156370 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a64>
  155ba0:      	cmp	x8, x2
  155ba4:      	b.hi	0x156370 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a64>
  155ba8:      	mov	x20, x0
  155bac:      	add	x8, sp, #0x188
  155bb0:      	mov	x0, x9
  155bb4:      	bl	0x155bb4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x12a8>
  155bb8:      	ldrb	w8, [sp, #0x188]
  155bbc:      	tbz	w8, #0x0, 0x155c5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1350>
  155bc0:      	mov	x19, #0x2               ; =2
  155bc4:      	movk	x19, #0x7ffc, lsl #48
  155bc8:      	strb	wzr, [x20, #0xd4]
  155bcc:      	b	0x1560dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
  155bd0:      	cmp	w13, #0x7d
  155bd4:      	b.ne	0x155e28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x151c>
  155bd8:      	add	x9, x9, #0x1
  155bdc:      	str	x9, [x8, #0x70]
  155be0:      	b	0x155e2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1520>
  155be4:      	sub	x0, x29, #0x68
  155be8:      	mov	x1, #0x0                ; =0
  155bec:      	bl	0x155bec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x12e0>
  155bf0:      	mov	x2, x1
  155bf4:      	mov	x1, x0
  155bf8:      	str	xzr, [x21, #0x78]
  155bfc:      	str	x0, [x21, #0xc0]
  155c00:      	str	w2, [x21, #0xd0]
  155c04:      	add	x0, x21, #0x20
  155c08:      	mov	w3, #0x8                ; =8
  155c0c:      	mov	x4, #0x0                ; =0
  155c10:      	bl	0x155c10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1304>
  155c14:      	ldrb	w8, [x19, #0x20]
  155c18:      	cbnz	w8, 0x156394 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a88>
  155c1c:      	ldr	x8, [x19]
  155c20:      	cbnz	x8, 0x1563e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ad8>
  155c24:      	ldr	x8, [x19, #0x18]
  155c28:      	cmp	x23, x8
  155c2c:      	b.hi	0x155c34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1328>
  155c30:      	str	x23, [x19, #0x18]
  155c34:      	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
  155c38:      	bfxil	x19, x0, #0, #48
  155c3c:      	b	0x1560dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
  155c40:      	cbz	x20, 0x155cfc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x13f0>
  155c44:      	cmp	x20, #0x4
  155c48:      	b.hs	0x155d04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x13f8>
  155c4c:      	mov	x10, #0x0               ; =0
  155c50:      	mov	x9, #0x0                ; =0
  155c54:      	mov	x8, x21
  155c58:      	b	0x155d94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1488>
  155c5c:      	ldr	x19, [sp, #0x190]
  155c60:      	b	0x1560dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
  155c64:      	mov	x26, x12
  155c68:      	b	0x155ac0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11b4>
  155c6c:      	ldr	x22, [x24, #0x68]
  155c70:      	sub	x9, x22, x20
  155c74:      	cmp	x9, #0x101
  155c78:      	mov	w9, #0xff               ; =255
  155c7c:      	ccmp	x20, x9, #0x0, lo
  155c80:      	b.ls	0x155dd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x14c8>
  155c84:      	ldr	x1, [x24, #0x60]
  155c88:      	ldr	x23, [x24, #0xc8]
  155c8c:      	add	x0, x24, #0x20
  155c90:      	mov	x2, x22
  155c94:      	mov	x3, x23
  155c98:      	mov	x4, x19
  155c9c:      	mov	x5, x21
  155ca0:      	mov	x6, x20
  155ca4:      	bl	0x155ca4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1398>
  155ca8:      	mov	x21, x0
  155cac:      	b	0x155dec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x14e0>
  155cb0:      	add	x11, x1, #0x1
  155cb4:      	cmp	x11, x2
  155cb8:      	b.hs	0x1560cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c0>
  155cbc:      	add	x16, x12, #0x1
  155cc0:      	mov	x15, #-0x1              ; =-1
  155cc4:      	ldrb	w17, [x16, x1]
  155cc8:      	sub	w3, w17, #0x30
  155ccc:      	cmp	w3, #0x9
  155cd0:      	b.hi	0x1561a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1898>
  155cd4:      	add	x16, x16, #0x1
  155cd8:      	sub	x15, x15, #0x1
  155cdc:      	cmp	x8, x15
  155ce0:      	b.ne	0x155cc4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x13b8>
  155ce4:      	str	x2, [x0, #0x70]
  155ce8:      	mov	x8, x2
  155cec:      	subs	x16, x1, x10
  155cf0:      	b.eq	0x155b98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x128c>
  155cf4:      	mov	x8, x2
  155cf8:      	b	0x1561d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x18cc>
  155cfc:      	mov	x10, #0x0               ; =0
  155d00:      	b	0x155db4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x14a8>
  155d04:      	and	x9, x20, #0x4
  155d08:      	add	x8, x21, x9
  155d0c:      	adrp	x10, 0x155000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f4>
  155d10:      	ldr	q0, [x10]
  155d14:      	adrp	x10, 0x155000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6f4>
  155d18:      	ldr	q2, [x10]
  155d1c:      	movi.2d	v1, #0000000000000000
  155d20:      	movi.2d	v3, #0x000000000000ff
  155d24:      	mov	w10, #0x4               ; =4
  155d28:      	dup.2d	v4, x10
  155d2c:      	mov	x10, x21
  155d30:      	and	x11, x20, #0x4
  155d34:      	movi.2d	v5, #0000000000000000
  155d38:      	ldr	s6, [x10], #0x4
  155d3c:      	ushll.8h	v6, v6, #0x0
  155d40:      	ushll.4s	v6, v6, #0x0
  155d44:      	ushll2.2d	v7, v6, #0x0
  155d48:      	and.16b	v7, v7, v3
  155d4c:      	ushll.2d	v6, v6, #0x0
  155d50:      	and.16b	v6, v6, v3
  155d54:      	shl.2d	v16, v0, #0x3
  155d58:      	shl.2d	v17, v2, #0x3
  155d5c:      	ushl.2d	v6, v6, v17
  155d60:      	ushl.2d	v7, v7, v16
  155d64:      	orr.16b	v1, v7, v1
  155d68:      	orr.16b	v5, v6, v5
  155d6c:      	add.2d	v0, v0, v4
  155d70:      	add.2d	v2, v2, v4
  155d74:      	subs	x11, x11, #0x4
  155d78:      	b.ne	0x155d38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x142c>
  155d7c:      	orr.16b	v0, v5, v1
  155d80:      	mov	d1, v0[1]
  155d84:      	orr.8b	v0, v0, v1
  155d88:      	fmov	x10, d0
  155d8c:      	cmp	x20, x9
  155d90:      	b.eq	0x155db4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x14a8>
  155d94:      	add	x11, x21, x20
  155d98:      	lsl	x9, x9, #3
  155d9c:      	ldrb	w12, [x8], #0x1
  155da0:      	lsl	x12, x12, x9
  155da4:      	orr	x10, x12, x10
  155da8:      	add	x9, x9, #0x8
  155dac:      	cmp	x8, x11
  155db0:      	b.ne	0x155d9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1490>
  155db4:      	orr	x8, x10, x20, lsl #40
  155db8:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
  155dbc:      	orr	x19, x8, x9
  155dc0:      	cmp	x22, #0x1
  155dc4:      	b.lt	0x1560dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
  155dc8:      	mov	x0, x21
  155dcc:      	bl	0x155dcc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x14c0>
  155dd0:      	b	0x1560dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
  155dd4:      	add	x0, x24, #0x20
  155dd8:      	mov	x1, x21
  155ddc:      	mov	x2, x20
  155de0:      	bl	0x155de0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x14d4>
  155de4:      	mov	x21, x0
  155de8:      	ldr	x23, [x24, #0xc8]
  155dec:      	ldr	x3, [x24, #0x70]
  155df0:      	mov	x0, x23
  155df4:      	mov	x1, x22
  155df8:      	mov	x2, x19
  155dfc:      	mov	x4, x21
  155e00:      	mov	x5, x20
  155e04:      	bl	0x155e04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x14f8>
  155e08:      	mov	x19, #0x7fff000000000000 ; =9223090561878065152
  155e0c:      	bfxil	x19, x21, #0, #48
  155e10:      	b	0x1560dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
  155e14:      	mov	x8, x21
  155e18:      	ldp	x20, x28, [sp, #0x90]
  155e1c:      	ldp	x10, x9, [x21, #0x68]
  155e20:      	cmp	x9, x10
  155e24:      	b.lo	0x155ae4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11d8>
  155e28:      	strb	wzr, [x8, #0xd4]
  155e2c:      	ldr	x27, [sp, #0x188]
  155e30:      	cmn	x27, #0x1
  155e34:      	b.eq	0x155ea8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x159c>
  155e38:      	ldp	x0, x1, [sp, #0x190]
  155e3c:      	cmp	x1, #0x9
  155e40:      	b.hs	0x155f40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1634>
  155e44:      	ldr	x9, [x8, #0x78]
  155e48:      	cmp	x1, x9
  155e4c:      	b.ne	0x155e6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
  155e50:      	ldr	x20, [x8, #0xc0]
  155e54:      	cbz	x20, 0x155e6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
  155e58:      	cbz	x1, 0x156008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
  155e5c:      	ldr	x9, [x8, #0x80]
  155e60:      	ldr	x10, [x0]
  155e64:      	cmp	x9, x10
  155e68:      	b.eq	0x155f54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1648>
  155e6c:      	mov	x24, x0
  155e70:      	mov	x25, x1
  155e74:      	bl	0x155e74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1568>
  155e78:      	mov	x20, x0
  155e7c:      	mov	x26, x1
  155e80:      	str	x25, [x21, #0x78]
  155e84:      	lsl	x2, x25, #3
  155e88:      	add	x0, x21, #0x80
  155e8c:      	mov	x1, x24
  155e90:      	bl	0x155e90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1584>
  155e94:      	mov	x2, x26
  155e98:      	mov	x8, x21
  155e9c:      	str	x20, [x21, #0xc0]
  155ea0:      	str	w26, [x21, #0xd0]
  155ea4:      	b	0x15600c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1700>
  155ea8:      	ldp	w9, w10, [sp, #0x88]
  155eac:      	and	w9, w9, w10
  155eb0:      	ldr	w2, [sp, #0x7c]
  155eb4:      	tbz	w9, #0x0, 0x155ed4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15c8>
  155eb8:      	ldr	x9, [sp, #0x70]
  155ebc:      	ldr	x10, [sp, #0x80]
  155ec0:      	cmp	x10, x9
  155ec4:      	b.ne	0x155ed4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15c8>
  155ec8:      	ldr	x9, [sp, #0x80]
  155ecc:      	cmp	x26, x9
  155ed0:      	b.eq	0x15600c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1700>
  155ed4:      	cmp	x28, #0x9
  155ed8:      	b.hs	0x156358 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a4c>
  155edc:      	ldr	x9, [x8, #0x78]
  155ee0:      	cmp	x28, x9
  155ee4:      	b.ne	0x155f04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
  155ee8:      	ldr	x20, [x8, #0xc0]
  155eec:      	cbz	x20, 0x155f04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
  155ef0:      	cbz	x28, 0x156008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
  155ef4:      	ldr	x9, [x8, #0x80]
  155ef8:      	ldr	x10, [sp, #0x100]
  155efc:      	cmp	x9, x10
  155f00:      	b.eq	0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  155f04:      	add	x0, sp, #0x100
  155f08:      	mov	x1, x28
  155f0c:      	bl	0x155f0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1600>
  155f10:      	mov	x20, x0
  155f14:      	mov	x24, x1
  155f18:      	str	x28, [x21, #0x78]
  155f1c:      	lsl	x2, x28, #3
  155f20:      	add	x0, x21, #0x80
  155f24:      	add	x1, sp, #0x100
  155f28:      	bl	0x155f28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x161c>
  155f2c:      	mov	x2, x24
  155f30:      	mov	x8, x21
  155f34:      	str	x20, [x21, #0xc0]
  155f38:      	str	w24, [x21, #0xd0]
  155f3c:      	b	0x15600c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1700>
  155f40:      	bl	0x155f40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1634>
  155f44:      	mov	x20, x0
  155f48:      	mov	x8, x21
  155f4c:      	mov	x2, x1
  155f50:      	b	0x15600c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1700>
  155f54:      	cmp	x1, #0x1
  155f58:      	b.eq	0x156008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
  155f5c:      	ldr	x9, [x8, #0x88]
  155f60:      	ldr	x10, [x0, #0x8]
  155f64:      	cmp	x9, x10
  155f68:      	b.ne	0x155e6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
  155f6c:      	cmp	x1, #0x2
  155f70:      	b.eq	0x156008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
  155f74:      	ldr	x9, [x8, #0x90]
  155f78:      	ldr	x10, [x0, #0x10]
  155f7c:      	cmp	x9, x10
  155f80:      	b.ne	0x155e6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
  155f84:      	cmp	x1, #0x3
  155f88:      	b.eq	0x156008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
  155f8c:      	ldr	x9, [x8, #0x98]
  155f90:      	ldr	x10, [x0, #0x18]
  155f94:      	cmp	x9, x10
  155f98:      	b.ne	0x155e6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
  155f9c:      	cmp	x1, #0x4
  155fa0:      	b.eq	0x156008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
  155fa4:      	ldr	x9, [x8, #0xa0]
  155fa8:      	ldr	x10, [x0, #0x20]
  155fac:      	cmp	x9, x10
  155fb0:      	b.ne	0x155e6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
  155fb4:      	cmp	x1, #0x5
  155fb8:      	b.eq	0x156008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
  155fbc:      	ldr	x9, [x8, #0xa8]
  155fc0:      	ldr	x10, [x0, #0x28]
  155fc4:      	cmp	x9, x10
  155fc8:      	b.ne	0x155e6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
  155fcc:      	cmp	x1, #0x6
  155fd0:      	b.eq	0x156008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
  155fd4:      	ldr	x9, [x8, #0xb0]
  155fd8:      	ldr	x10, [x0, #0x30]
  155fdc:      	cmp	x9, x10
  155fe0:      	b.ne	0x155e6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
  155fe4:      	cmp	x1, #0x7
  155fe8:      	b.eq	0x156008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
  155fec:      	ldr	x9, [x8, #0xb8]
  155ff0:      	ldr	x10, [x0, #0x38]
  155ff4:      	cmp	x9, x10
  155ff8:      	b.ne	0x155e6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
  155ffc:      	b	0x156008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
  156000:      	cmp	x28, #0x1
  156004:      	b.ne	0x156100 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17f4>
  156008:      	ldr	w2, [x8, #0xd0]
  15600c:      	cmp	x28, #0x9
  156010:      	b.hs	0x156278 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x196c>
  156014:      	ldr	x9, [sp, #0x1b0]
  156018:      	cmn	x27, #0x1
  15601c:      	add	x10, sp, #0x148
  156020:      	ldr	x11, [sp, #0x60]
  156024:      	csel	x3, x10, x11, eq
  156028:      	csel	x4, x28, x9, eq
  15602c:      	add	x0, x8, #0x20
  156030:      	mov	x1, x20
  156034:      	bl	0x156034 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1728>
  156038:      	ldrb	w8, [x19, #0x20]
  15603c:      	cbnz	w8, 0x156328 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a1c>
  156040:      	ldr	x8, [x19]
  156044:      	cbnz	x8, 0x1563e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ad8>
  156048:      	ldr	x8, [x19, #0x18]
  15604c:      	cmp	x23, x8
  156050:      	b.hi	0x156058 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x174c>
  156054:      	str	x23, [x19, #0x18]
  156058:      	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
  15605c:      	bfxil	x19, x0, #0, #48
  156060:      	ldr	x8, [sp, #0x188]
  156064:      	cmn	x8, #0x1
  156068:      	b.eq	0x1560dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
  15606c:      	cbz	x8, 0x156078 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x176c>
  156070:      	ldr	x0, [sp, #0x190]
  156074:      	bl	0x156074 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1768>
  156078:      	ldr	x8, [sp, #0x1a0]
  15607c:      	cbz	x8, 0x156088 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x177c>
  156080:      	ldr	x0, [sp, #0x1a8]
  156084:      	bl	0x156084 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1778>
  156088:      	ldr	x20, [sp, #0x1b8]
  15608c:      	cmn	x20, #0x1
  156090:      	b.eq	0x1560dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
  156094:      	ldr	x9, [sp, #0x1d8]
  156098:      	cbz	x9, 0x1560bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17b0>
  15609c:      	lsl	x8, x9, #4
  1560a0:      	add	x9, x8, x9
  1560a4:      	cmn	x9, #0x19
  1560a8:      	b.eq	0x1560bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17b0>
  1560ac:      	ldr	x9, [sp, #0x1d0]
  1560b0:      	sub	x8, x9, x8
  1560b4:      	sub	x0, x8, #0x10
  1560b8:      	bl	0x1560b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17ac>
  1560bc:      	cbz	x20, 0x1560dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
  1560c0:      	ldr	x0, [sp, #0x1c0]
  1560c4:      	bl	0x1560c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17b8>
  1560c8:      	b	0x1560dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
  1560cc:      	str	x11, [x0, #0x70]
  1560d0:      	mov	x19, #0x2               ; =2
  1560d4:      	movk	x19, #0x7ffc, lsl #48
  1560d8:      	strb	wzr, [x0, #0xd4]
  1560dc:      	mov	x0, x19
  1560e0:      	add	sp, sp, #0x240
  1560e4:      	ldp	x29, x30, [sp, #0x50]
  1560e8:      	ldp	x20, x19, [sp, #0x40]
  1560ec:      	ldp	x22, x21, [sp, #0x30]
  1560f0:      	ldp	x24, x23, [sp, #0x20]
  1560f4:      	ldp	x26, x25, [sp, #0x10]
  1560f8:      	ldp	x28, x27, [sp], #0x60
  1560fc:      	ret
  156100:      	ldr	x9, [x8, #0x88]
  156104:      	ldr	x10, [sp, #0x108]
  156108:      	cmp	x9, x10
  15610c:      	b.ne	0x155f04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
  156110:      	cmp	x28, #0x2
  156114:      	b.eq	0x156008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
  156118:      	ldr	x9, [x8, #0x90]
  15611c:      	ldr	x10, [sp, #0x110]
  156120:      	cmp	x9, x10
  156124:      	b.ne	0x155f04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
  156128:      	cmp	x28, #0x3
  15612c:      	b.eq	0x156008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
  156130:      	ldr	x9, [x8, #0x98]
  156134:      	ldr	x10, [sp, #0x118]
  156138:      	cmp	x9, x10
  15613c:      	b.ne	0x155f04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
  156140:      	cmp	x28, #0x4
  156144:      	b.eq	0x156008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
  156148:      	ldr	x9, [x8, #0xa0]
  15614c:      	ldr	x10, [sp, #0x120]
  156150:      	cmp	x9, x10
  156154:      	b.ne	0x155f04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
  156158:      	cmp	x28, #0x5
  15615c:      	b.eq	0x156008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
  156160:      	ldr	x9, [x8, #0xa8]
  156164:      	ldr	x10, [sp, #0x128]
  156168:      	cmp	x9, x10
  15616c:      	b.ne	0x155f04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
  156170:      	cmp	x28, #0x6
  156174:      	b.eq	0x156008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
  156178:      	ldr	x9, [x8, #0xb0]
  15617c:      	ldr	x10, [sp, #0x130]
  156180:      	cmp	x9, x10
  156184:      	b.ne	0x155f04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
  156188:      	cmp	x28, #0x7
  15618c:      	b.eq	0x156008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
  156190:      	ldr	x9, [x8, #0xb8]
  156194:      	ldr	x10, [sp, #0x138]
  156198:      	cmp	x9, x10
  15619c:      	b.ne	0x155f04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
  1561a0:      	b	0x156008 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
  1561a4:      	sub	x8, x1, x15
  1561a8:      	str	x8, [x0, #0x70]
  1561ac:      	cmp	w17, #0x65
  1561b0:      	b.ne	0x1561c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x18b4>
  1561b4:      	cmn	x15, #0x1
  1561b8:      	b.ne	0x155b1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
  1561bc:      	b	0x1560d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
  1561c0:      	cmn	x15, #0x1
  1561c4:      	b.eq	0x1560d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
  1561c8:      	subs	x16, x1, x10
  1561cc:      	b.eq	0x155b1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
  1561d0:      	cmp	w17, #0x45
  1561d4:      	b.eq	0x155b1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
  1561d8:      	sub	x15, x8, x11
  1561dc:      	cmp	x15, #0x9
  1561e0:      	b.hi	0x155b1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
  1561e4:      	add	x17, x16, x15
  1561e8:      	cmp	x17, #0x11
  1561ec:      	b.hi	0x155b1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
  1561f0:      	cmp	x1, x10
  1561f4:      	b.lo	0x1563fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1af0>
  1561f8:      	mov	x10, #0x0               ; =0
  1561fc:      	b.eq	0x15621c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1910>
  156200:      	mov	w17, #0xa               ; =10
  156204:      	ldrb	w3, [x14], #0x1
  156208:      	mul	x10, x10, x17
  15620c:      	sub	w3, w3, #0x30
  156210:      	add	x10, x10, w3, uxtb
  156214:      	subs	x16, x16, #0x1
  156218:      	b.ne	0x156204 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x18f8>
  15621c:      	cmp	x8, x1
  156220:      	b.ls	0x15640c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b00>
  156224:      	cmp	x8, x2
  156228:      	b.hi	0x15640c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b00>
  15622c:      	mov	w14, #0xa               ; =10
  156230:      	ldrb	w16, [x12, x11]
  156234:      	mul	x10, x10, x14
  156238:      	sub	w16, w16, #0x30
  15623c:      	add	x10, x10, w16, uxtb
  156240:      	add	x11, x11, #0x1
  156244:      	cmp	x8, x11
  156248:      	b.ne	0x156230 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1924>
  15624c:      	mov	x11, #0x20000000000000  ; =9007199254740992
  156250:      	cmp	x10, x11
  156254:      	b.hi	0x155b1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
  156258:      	ucvtf	d0, x10
  15625c:      	adrp	x8, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  156260:      	add	x8, x8, #0x0
  156264:      	ldr	d1, [x8, x15, lsl #3]
  156268:      	fdiv	d0, d0, d1
  15626c:      	b	0x154d90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x484>
  156270:      	ldr	x1, [sp, #0x38]
  156274:      	b	0x155ac0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11b4>
  156278:      	adrp	x3, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  15627c:      	add	x3, x3, #0x0
  156280:      	mov	x0, #0x0                ; =0
  156284:      	mov	x1, x28
  156288:      	mov	w2, #0x8                ; =8
  15628c:      	bl	0x15628c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1980>
  156290:      	cmp	w8, #0x2
  156294:      	b.eq	0x15639c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a90>
  156298:      	adrp	x1, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  15629c:      	add	x1, x1, #0x0
  1562a0:      	mov	x0, x19
  1562a4:      	bl	0x1562a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1998>
  1562a8:      	strb	wzr, [x19, #0x20]
  1562ac:      	ldr	x8, [x19]
  1562b0:      	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
  1562b4:      	cmp	x8, x9
  1562b8:      	b.lo	0x154a5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x150>
  1562bc:      	b	0x1562ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19e0>
  1562c0:      	cmp	w8, #0x1
  1562c4:      	b.ne	0x15639c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a90>
  1562c8:      	adrp	x1, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  1562cc:      	add	x1, x1, #0x0
  1562d0:      	mov	x0, x19
  1562d4:      	bl	0x1562d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19c8>
  1562d8:      	strb	wzr, [x19, #0x20]
  1562dc:      	ldr	x8, [x19]
  1562e0:      	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
  1562e4:      	cmp	x8, x9
  1562e8:      	b.lo	0x154ec4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x5b8>
  1562ec:      	adrp	x0, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  1562f0:      	add	x0, x0, #0x0
  1562f4:      	bl	0x1562f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19e8>
  1562f8:      	adrp	x3, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  1562fc:      	add	x3, x3, #0x0
  156300:      	mov	x0, x19
  156304:      	bl	0x156304 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19f8>
  156308:      	adrp	x3, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  15630c:      	add	x3, x3, #0x0
  156310:      	mov	x0, x19
  156314:      	bl	0x156314 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a08>
  156318:      	adrp	x3, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  15631c:      	add	x3, x3, #0x0
  156320:      	mov	x0, x19
  156324:      	bl	0x156324 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a18>
  156328:      	cmp	w8, #0x2
  15632c:      	b.eq	0x15639c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a90>
  156330:      	mov	x20, x0
  156334:      	adrp	x1, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  156338:      	add	x1, x1, #0x0
  15633c:      	mov	x0, x19
  156340:      	bl	0x156340 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a34>
  156344:      	strb	wzr, [x19, #0x20]
  156348:      	mov	x0, x20
  15634c:      	ldr	x8, [x19]
  156350:      	cbz	x8, 0x156048 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x173c>
  156354:      	b	0x1563e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ad8>
  156358:      	adrp	x3, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  15635c:      	add	x3, x3, #0x0
  156360:      	mov	x0, #0x0                ; =0
  156364:      	mov	x1, x28
  156368:      	mov	w2, #0x8                ; =8
  15636c:      	bl	0x15636c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a60>
  156370:      	adrp	x3, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  156374:      	add	x3, x3, #0x0
  156378:      	mov	x0, x19
  15637c:      	mov	x1, x8
  156380:      	bl	0x156380 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a74>
  156384:      	adrp	x3, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  156388:      	add	x3, x3, #0x0
  15638c:      	mov	x0, x10
  156390:      	bl	0x156390 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a84>
  156394:      	cmp	w8, #0x2
  156398:      	b.ne	0x1563c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ab4>
  15639c:      	adrp	x0, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  1563a0:      	add	x0, x0, #0x0
  1563a4:      	bl	0x1563a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a98>
  1563a8:      	adrp	x3, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  1563ac:      	add	x3, x3, #0x0
  1563b0:      	mov	x0, #0x0                ; =0
  1563b4:      	mov	x1, x28
  1563b8:      	mov	w2, #0x8                ; =8
  1563bc:      	bl	0x1563bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ab0>
  1563c0:      	mov	x20, x0
  1563c4:      	adrp	x1, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  1563c8:      	add	x1, x1, #0x0
  1563cc:      	mov	x0, x19
  1563d0:      	bl	0x1563d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ac4>
  1563d4:      	strb	wzr, [x19, #0x20]
  1563d8:      	mov	x0, x20
  1563dc:      	ldr	x8, [x19]
  1563e0:      	cbz	x8, 0x155c24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1318>
  1563e4:      	adrp	x0, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  1563e8:      	add	x0, x0, #0x0
  1563ec:      	bl	0x1563ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ae0>
  1563f0:      	adrp	x0, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  1563f4:      	add	x0, x0, #0x0
  1563f8:      	bl	0x1563f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1aec>
  1563fc:      	adrp	x3, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  156400:      	add	x3, x3, #0x0
  156404:      	mov	x0, x10
  156408:      	bl	0x156408 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1afc>
  15640c:      	adrp	x3, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  156410:      	add	x3, x3, #0x0
  156414:      	mov	x0, x11
  156418:      	mov	x1, x8
  15641c:      	bl	0x15641c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b10>
  156420:      	adrp	x2, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  156424:      	add	x2, x2, #0x0
  156428:      	mov	x0, x26
  15642c:      	mov	w1, #0x8                ; =8
  156430:      	bl	0x156430 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b24>
  156434:      	adrp	x2, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  156438:      	add	x2, x2, #0x0
  15643c:      	mov	x0, x1
  156440:      	ldr	x1, [sp, #0x20]
  156444:      	bl	0x156444 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b38>
  156448:      	adrp	x2, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  15644c:      	add	x2, x2, #0x0
  156450:      	ldr	x1, [sp, #0x20]
  156454:      	bl	0x156454 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b48>
  156458:      	adrp	x2, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  15645c:      	add	x2, x2, #0x0
  156460:      	mov	x0, x12
  156464:      	mov	w1, #0x8                ; =8
  156468:      	bl	0x156468 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b5c>
  15646c:      	adrp	x2, 0x156000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
  156470:      	add	x2, x2, #0x0
  156474:      	mov	x0, x12
  156478:      	mov	w1, #0x8                ; =8
  15647c:      	bl	0x15647c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b70>
  156480:      	mov	w0, #0x8                ; =8
  156484:      	mov	w1, #0x80               ; =128
  156488:      	bl	0x156488 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b7c>

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_runtime.51e3211f3b89fd3b-cgu.0.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.phf-fda76137c618ed94.phf.e4e92736a1df7d19-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.phf_shared-a99412ae5fa8df63.phf_shared.d4b5e8e0605a820e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.pin_project_lite-9112ff0b4ca4c5f5.pin_project_lite.9e3a833d7736b09d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.portable_atomic-ee537db1fe67f1f1.portable_atomic.3d3e8745d3fefd81-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.potential_utf-7290d80b7d4fd7a6.potential_utf.3d03ee8112fd1596-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.prefix_trie-40e0fdfa96a3a51b.prefix_trie.aa2676338b217d25-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.psm-9f3b8da3ad16e1fa.psm.78bcf4d21b57561-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rand-492323155da95b1d.rand.6529a7c3eb82dfd6-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rand_core-6bacf6ecfee8446a.rand_core.fec9fb7b016054b8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.regex-23a1744e34a6bdd8.regex.5fe00e4da3593f57-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.regex_automata-05498c6e8207064c.regex_automata.2113017827263087-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.regex_syntax-dc078710f3e283e5.regex_syntax.5d77536cdc21bec2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.regress-4af654b3baeba21a.regress.56c9efe3abfd7dd9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.resolv_conf-589bb5b300ae9b62.resolv_conf.ef8ce2570ae6b7ca-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_demangle-a0db1312f42a1e44.rustc_demangle.e8c1817fde257fa-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_demangle-a84069e27028b871.rustc_demangle.6e498b991fca6ce6-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_hash-6acac617e2694d16.rustc_hash.8dd8e3d9c15ad472-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_std_workspace_alloc-5b4356182ec17e27.rustc_std_workspace_alloc.95a6ecb1e2b64b16-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_std_workspace_core-91fae2e614e9d003.rustc_std_workspace_core.5c33cd8176fbdf03-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ryu-88f4114cfee0f920.ryu.e5b11607222e9f1-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ryu_js-8203fc1e86d8300b.ryu_js.38024f8f2b58d396-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.scoped_tls-bea296576cbd4055.scoped_tls.4868881ed73f4220-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.scopeguard-3f34b2f52778ed6d.scopeguard.39c46ee7c3ff5c3a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.serde-b1698c4db99cd0f6.serde.ace619f76592a163-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.serde_core-7feea810e2b7e669.serde_core.91e6c9d28410876e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.serde_json-5f6cce1ec0bc1f51.serde_json.1881800b546529cc-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.serde_spanned-786a63d1fb99443c.serde_spanned.ecff9bd5fc6ed1cd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.signal_hook_registry-73f406794e9b58b9.signal_hook_registry.a304ee316af8aaf-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.simdutf8-6eaa160c64d9f76b.simdutf8.5e602d216e3b60b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.siphasher-3f0a76aeabf470da.siphasher.5dc93b2dddb35ff3-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.siphasher-a84eeb1952cd7c96.siphasher.63b0bb3e10f5fb09-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.slab-ce3c7619cdf98849.slab.4197f6b653c95390-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.slotmap-20ea319e01e10a36.slotmap.7f53c3097a475db5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.smallvec-0e7d453b7999d6bf.smallvec.a3fac2ce2795659-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.smartstring-dc627c0149b34430.smartstring.daa138bdd471414-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.socket2-c0fc5e20d9815054.socket2.325daa4db95003be-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.spin-419ef0217c1a7e9d.spin.124ce9ff3747f4d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.spki-68668ef35563db08.spki.dcea16c81f3faeb7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.stable_deref_trait-d05f845ec581f3c3.stable_deref_trait.20e7280df43487a4-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.stacker-e8215abced14b595.stacker.a64d36231c9b54e8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.static_assertions-26a67eb00cbe4a19.static_assertions.d246fd1a619c5f56-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.std-36f377630a6d9041.std.6435e32e5249d112-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.std_detect-4733c791661234cb.std_detect.19bab4874ad71232-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_atoms-920e18ec1ca531dc.swc_atoms.6e099e31e61309c3-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_common-d6bd2bc4e58d990f.swc_common.8fdf2470d9cfdc5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_ecma_ast-84ea4ee5ba95db2e.swc_ecma_ast.3d8d12e8f84f649c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_ecma_parser-8ec30cfb0eaf253d.swc_ecma_parser.bc422679edde26a7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_ecma_visit-b63461394357b0d4.swc_ecma_visit.c99e8944d3846bc7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_visit-64ac6e1c9cb7923d.swc_visit.2ab765cb666f8899-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.taffy-fe5c9a8e7c25c5f0.taffy.d86dff334662a800-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.temporal_rs-0fb585091cfff93a.temporal_rs.615be7171f19ae8f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.thiserror-1959f5c5ef95f8e0.thiserror.66a9b0aa6ac5659c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.thiserror-819934ff4cff447d.thiserror.262fe98a9286a6f8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.timezone_provider-734aa3cb276ec3ef.timezone_provider.c5d1d9aad8d3988f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tinystr-7460fd70af50815a.tinystr.f12ac1933cb9ba2b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tinyvec-747e19215a97d544.tinyvec.c739c1e068ab99ed-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tinyvec_macros-03c0b3b0828d119a.tinyvec_macros.a5317fef04132c16-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tokio-c09ace7016a21111.tokio.10f85077cf846efc-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tokio_util-b3b32b3e68ae174b.tokio_util.c2188b63290972ae-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.toml-e1d9f60e2a93edf6.toml.69efb9df2f8e67b3-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.toml_datetime-da06043cbfd6a3ff.toml_datetime.eed1431b100c0ba5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.toml_parser-a8ea5ac599f8d731.toml_parser.4dda3eb99405abdd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.toml_writer-86392e121e73ea49.toml_writer.612da603a2a255c9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tracing-1e99833042e023d4.tracing.480a63e3c00ffe5d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tracing_core-a4ce5df32b216be5.tracing_core.551518ce0c3162f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.triomphe-1f26ad013b2edc2b.triomphe.df0393428d78f2d2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tzif-f601d4f6882f6c91.tzif.4b87cacab3be6a39-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_id_start-b1b648fdc7033911.unicode_id_start.b451d75f4870a19-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_normalization-74312452efd83ea5.unicode_normalization.a9dba2d72fcfb0e9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_segmentation-9d17b5f253060a33.unicode_segmentation.418ba6cb19b4b691-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_width-9091f55f45a06a5b.unicode_width.2046f0e93b598eee-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_width-eefe794da3ddc491.unicode_width.81acccf54ab200a6-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unsafe_libyaml-6fc9986bea6e83a2.unsafe_libyaml.498c10ddae7016fa-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unwind-b34336196694d849.unwind.84a5a803a0d3b8e5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.url-937de9168f16e023.url.1a3dafb8678c931d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.utf8_iter-495f179a61b481d6.utf8_iter.c6d05cdf24642122-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.winnow-19e99833af0373f3.winnow.82b0bb40063afce5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.writeable-590fc088fec40648.writeable.5b4332e450c8b833-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.x509_cert-23c04dad6503524d.x509_cert.a1cd03d282d34aa8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.xxhash_rust-aca16904554a0e24.xxhash_rust.80a8560132cdda1a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.yoke-344345244b6e4947.yoke.e19373a6f771978b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zerocopy-99f7f8d1743ab073.zerocopy.c4d7aea3b77dbe79-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zerofrom-316567aba73be1b3.zerofrom.895504131b58bc4e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zeroize-c6a7916c40321e93.zeroize.9524028ebbc3b95a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zerotrie-5524f4e315dcaf36.zerotrie.47410e50260eb1e0-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zerovec-8f5cd301f36e965a.zerovec.9ea12157016434b1-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zmij-8f9e3f41857f0483.zmij.180143115354781b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zstd-2da8f76fd714c069.zstd.f736b1e5325616ef-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zstd_safe-e368634d5a7f6151.zstd_safe.828b5cf371cee27e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zstd_sys-959dee5ed6b0497e.zstd_sys.67acef213add5ee5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f17b5a9852f781a4-perry_sjlj.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-debug.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-entropy_common.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-error_private.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-fse_decompress.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-pool.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-threading.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-zstd_common.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-fse_compress.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-hist.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-huf_compress.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_compress.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_compress_literals.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_compress_sequences.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_compress_superblock.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_double_fast.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_fast.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_lazy.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_ldm.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_opt.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_preSplit.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstdmt_compress.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(88f362f13b0528ed-huf_decompress.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(88f362f13b0528ed-zstd_ddict.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(88f362f13b0528ed-zstd_decompress.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(88f362f13b0528ed-zstd_decompress_block.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(a6c81c75fc82913a-cover.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(a6c81c75fc82913a-divsufsort.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(a6c81c75fc82913a-fastcover.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(a6c81c75fc82913a-zdict.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v01.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v02.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v03.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v04.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v05.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v06.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v07.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(7faed3f8272f2313-huf_decompress_amd64.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(b85de32113adef8e-static.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(4f9a91766097c4c5-aarch_aapcs64.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.000.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.001.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.002.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.003.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.004.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.005.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.006.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.007.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.008.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.009.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.010.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.011.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.012.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.013.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.014.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.015.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.016.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.017.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.018.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.019.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.020.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.021.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.022.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.023.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.024.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.025.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.026.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.027.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.028.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.029.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.030.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.031.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.032.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.033.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.034.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.035.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.036.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.037.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.038.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.039.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.040.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.041.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.042.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.043.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.044.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.045.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.046.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.047.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.048.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.049.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.050.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.051.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.052.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.053.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.054.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.055.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.056.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.057.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.058.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.059.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.060.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.061.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.062.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.063.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.064.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.065.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.066.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.067.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.068.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.069.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.070.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.071.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.072.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.073.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.074.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.075.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.076.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.077.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.078.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.079.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.080.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.081.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.082.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.083.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.084.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.085.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.086.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.087.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.088.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.089.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.090.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.091.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.092.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.093.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.094.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.095.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.096.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.097.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.098.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.099.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.100.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.101.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.102.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.103.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.104.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.105.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.106.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.107.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.108.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.109.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.110.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.111.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.112.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.113.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.114.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.115.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.116.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.117.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.118.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.119.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.120.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.121.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.122.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.123.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.124.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.125.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.126.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.127.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.128.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.129.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.130.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.131.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.132.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.133.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.134.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.135.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.136.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.137.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.138.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.139.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.140.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.141.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.142.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.143.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.144.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.145.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.146.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.147.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.148.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.149.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.150.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.151.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.152.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.153.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.154.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.155.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.156.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.157.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.158.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.159.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.160.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.161.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.162.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.163.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.164.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.165.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.166.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.167.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.168.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.169.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.170.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.171.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.172.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.173.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.174.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.175.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.176.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.177.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.178.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.179.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.180.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.181.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.182.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.183.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.184.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.185.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.186.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.187.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.188.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.189.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.190.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.191.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.192.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.193.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.194.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.195.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.196.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.197.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.198.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.199.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.200.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.201.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.202.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.203.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.204.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.205.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.206.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.207.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.208.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.209.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.210.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.211.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.212.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.213.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.214.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.215.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.216.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.217.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.218.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.219.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.220.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.221.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.222.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.223.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.224.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.225.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.226.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.227.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.228.rcgu.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas1_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas1_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas1_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas1_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas2_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas2_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas2_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas2_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas4_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas4_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas4_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas4_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas8_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas8_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas8_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas8_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas16_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas16_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas16_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas16_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp1_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp1_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp1_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp1_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp2_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp2_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp2_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp2_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp4_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp4_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp4_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp4_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp8_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp8_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp8_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp8_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd1_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd1_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd1_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd1_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd2_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd2_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd2_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd2_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd4_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd4_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd4_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd4_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd8_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd8_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd8_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd8_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr1_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr1_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr1_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr1_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr2_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr2_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr2_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr2_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr4_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr4_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr4_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr4_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr8_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr8_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr8_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr8_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor1_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor1_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor1_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor1_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor2_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor2_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor2_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor2_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor4_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor4_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor4_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor4_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor8_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor8_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor8_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor8_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset1_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset1_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset1_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset1_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset2_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset2_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset2_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset2_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset4_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset4_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset4_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset4_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset8_relax.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset8_acq.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset8_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset8_acq_rel.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(ad3ac4dcdcbf93cb-aarch64.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-absvdi2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-absvsi2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-absvti2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-addvdi3.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-addvsi3.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-addvti3.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-cmpdi2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-cmpti2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-divdc3.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-divsc3.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-fp_mode.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-ffsti2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-int_util.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-muldc3.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-mulsc3.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-multc3.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-mulvdi3.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-mulvsi3.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-mulvti3.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negdf2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negdi2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negsf2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negti2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negvdi2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negvsi2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negvti2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-paritydi2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-paritysi2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-parityti2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-popcountdi2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-popcountsi2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-popcountti2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-subvdi3.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-subvsi3.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-subvti3.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-ucmpdi2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-ucmpti2.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_flag_clear.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_flag_clear_explicit.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_flag_test_and_set.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_flag_test_and_set_explicit.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_signal_fence.o):	file format mach-o arm64

/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_thread_fence.o):	file format mach-o arm64
