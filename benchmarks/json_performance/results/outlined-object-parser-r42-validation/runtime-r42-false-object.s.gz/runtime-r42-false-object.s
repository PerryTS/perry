
benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.0hzsjplwwpevv88lz9s5mjuly.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.addr2line-cfa71d2872fc9749.addr2line.2f803ffa438d6abd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.adler2-4a012095652e66be.adler2.4472f1a4039cb8c5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ahash-9514a3e3390ca75c.ahash.2d29b14819ea2aa7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.aho_corasick-0465e7d1dc158f68.aho_corasick.d4e9aa874147907-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.alloc-f7cf0325b2c4fbea.alloc.91507a9d0c1147cb-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.allocator_api2-f4879b7f65d9dad6.allocator_api2.c20efd3e8c1c526a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.anyhow-b00ab8880ea60f5a.anyhow.dd2c21d3a09e2169-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.base64-32ce9211317f5731.base64.d7b02bb0c01b4c7f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.base64ct-dc4539cdef9387c1.base64ct.a13194e5b06d043e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.better_scoped_tls-5623aa5785b63992.better_scoped_tls.c4fc4593c97e81eb-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bit_set-1b43a885fb453b97.bit_set.e296561ef88d1b25-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bit_vec-8353e4eca9cb6885.bit_vec.2905b060439a1ee5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bitflags-a267cd1b6450301e.bitflags.9b23124bf16832ba-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bytecount-f903ae1df949a853.bytecount.d96a36eac4eddd2e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bytes-4d639afa28f500e9.bytes.4b80b056274f495a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.bytes_str-9ed5b56fd3acead7.bytes_str.33b6ea97d807fd24-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.calendrical_calculations-d30e5fcb342f8309.calendrical_calculations.ff7d2d4d240655f4-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.cfg_if-11f50a868fc78507.cfg_if.b001c247f2cdfacc-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.cfg_if-65f3efe385514d24.cfg_if.f06090845af655d8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.chacha20-894520615b692380.chacha20.255207753dfba230-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.combine-c70df9144a05ac41.combine.c3909ca49e68f1f0-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.const_oid-7b92d750363681a1.const_oid.59ced0f90a34feb8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.core-1eb26884753bb7ec.core.e07e215301fbc6f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.core_maths-11146167d2fbcd32.core_maths.423ca64e8f23f19a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.cty-f1fa0ed128de58b9.cty.6b73d1db9cbf7b8b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.data_encoding-98155a5d48e5ec99.data_encoding.d70ce69399f262ca-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.debug_unreachable-9bb446589bc29b16.debug_unreachable.fe3a47d951b816d9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.der-9bb76198d0a38255.der.6bdd1208ba76c73b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.dirs-756cabb78e25a929.dirs.ffe05ade48c56831-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.dirs_sys-e3f5752242e2a022.dirs_sys.ee3c17565b1fea59-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.either-432e8663b5d638fc.either.94df2b7257068b13-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.errno-ea9565cc054c881d.errno.7569163361032131-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.fancy_regex-2c325c7f9e823393.fancy_regex.ca4df3e112cd6cb7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.fixed_decimal-7e6fe6d640091744.fixed_decimal.7d257809aa775ff2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.flagset-ac9650c267cc7e77.flagset.b1438c243c6ff671-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.form_urlencoded-c338c7e2455734e8.form_urlencoded.1ab2c7c11d3385cf-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_core-61582daa6c57b257.futures_core.e5c5ead29f2a5185-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_io-313f277a9d659f14.futures_io.2354b3f0d921f5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_sink-24e92a078488c232.futures_sink.477b530395196519-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_task-40d3c4f4c699450f.futures_task.a793339b5ba19ee-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.futures_util-9ca40d38221ccdc3.futures_util.7622420df399cdfe-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.getrandom-888caac6f3a9d896.getrandom.7f8b53275961c005-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.getrandom-c7786f5309f7c1d1.getrandom.c00a3944440a318d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.gimli-1dc154aa9e77af93.gimli.5901559d024f6e07-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.gimli-4a08f02c6b3bfed9.gimli.adbe390e003e7ecb-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hashbrown-4d32db017aa9b7a5.hashbrown.8f7d8026e818751e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hashbrown-af4a3f18b4ae97c9.hashbrown.cb64e714776d3e07-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hickory_proto-5da21089dd651d86.hickory_proto.b3e58bdc73b32711-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hostname-1a758cf59ba97d19.hostname.9e06914bfa9458c0-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.hstr-990b134b3f579b0d.hstr.7816630fc46099ef-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_calendar-41dd45c4986e5371.icu_calendar.525e0f6d835cb712-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_calendar_data-edd7996660c4190e.icu_calendar_data.f47bf9c505eeaff2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_collections-559b63245c10ac1b.icu_collections.377b7b7ce659b1b9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_datetime-034ad7cdc455dac0.icu_datetime.3f12d4db0ba0d033-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_datetime_data-618583f1e8f98068.icu_datetime_data.ae5f6f8bf868927e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_decimal-77beaba6d2163e9b.icu_decimal.fe46e9f4b123130a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_decimal_data-367997f4010d8153.icu_decimal_data.d6f512199a2a447f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale-b42b3e1360358fc5.icu_locale.b3f10ef03c9651a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale_core-849ff933c9f4951a.icu_locale_core.e916c9be12dd52d2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale_data-9e7081d145555538.icu_locale_data.c24e3b51aa8226f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale_fallback-a6e3f83d98e2a67b.icu_locale_fallback.56246df7a44619a1-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_locale_fallback_data-1291c99bd372729e.icu_locale_fallback_data.afad649127a1756e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_normalizer-bc7f251896dc40bd.icu_normalizer.ff2a905c7940b1f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_normalizer_data-268487fee32ac8f0.icu_normalizer_data.8ad43135a1ce7d1f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_pattern-d59a83eb0e463baf.icu_pattern.be117b667d76f6f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_plurals-3c9070f8fa2510af.icu_plurals.740da912aa775a52-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_plurals_data-bd8faf2099579a9d.icu_plurals_data.45ea6926f1b7622f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_properties-6d0d35008dd1dbf9.icu_properties.c9b54ac36f6ff15d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_properties_data-59005f70ef52dd72.icu_properties_data.2b4f163e924ba5b8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_provider-6781ca5b429f4aee.icu_provider.29b968015b290673-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_time-54550ac874f62853.icu_time.5b58251af801c00d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.icu_time_data-4cd606d3217ab0c8.icu_time_data.e93588578a1fe390-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.idna-8d5c8377e58f6d08.idna.aba1e6179509c9b5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.idna_adapter-16f147720f57f9af.idna_adapter.f7fd92e26f89f8f1-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ipnet-16dcea07c26a0bdf.ipnet.a68501ef90183657-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.itoa-72113ee16b8d0ab6.itoa.6381431f0c25948c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ixdtf-da83a26e439607da.ixdtf.9e61fc26cbabd4cd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.jiff_tzdb-c9f0d309035f3bef.jiff_tzdb.8ad45a94b44687b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.lazy_static-7647d3e036babadd.lazy_static.f61d0a0c663b0e34-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.libc-6299013de1b57308.libc.89db0e620931259c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.libc-dadb5a82a633a7dc.libc.6bde7fa237754b8a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.libm-ac5dff0b52f67d03.libm.554bb06ed6d99dbd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.libmimalloc_sys-b1e23e8a6c5928c2.libmimalloc_sys.29accdad47f6ede0-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.litemap-2e12d9912a397309.litemap.571f336a3d6bbb56-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.lock_api-b480096f46123924.lock_api.874432d3f0bce2f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.log-169df25b841fb738.log.f3f704751685a618-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.mach2-6f42ba587ea54125.mach2.e7620912d05e5c3f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.memchr-1c6a1f6f6196cc2c.memchr.9afcaf06bb01edf2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.memchr-db6845a68ce0f188.memchr.9fcb083790588d2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.miette-85b477785fba33d9.miette.50b4b2d1c414b7ce-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.mimalloc-bcf0b21589b8fa53.mimalloc.95dbff8ab7587b05-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.miniz_oxide-2b20def31e1e0221.miniz_oxide.3e514f74919855b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.mio-f4b45263c6fb2e44.mio.430e10d80ebe3d9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.node_semver-359c30260c8449dc.node_semver.233ee6db2f2c4e46-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.nom-d7f48be26f93c2f7.nom.749d1dbb25d8ab32-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.num_bigint-aa73c29d2bd73516.num_bigint.9ee201b330206f6-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.num_integer-e318a12cf646126f.num_integer.9033146fac8f1134-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.num_traits-46d1dcb8872f2815.num_traits.d52ad62a33d7f1a9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.object-836e641a18d03406.object.f0cec6469c5dcf18-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.once_cell-01ae4f33c7a79bb7.once_cell.3768cf33248bb273-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.option_ext-8f1216324e4e6381.option_ext.92b51bce59292c52-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.panic_abort-905bfe97e1134923.panic_abort.cec6bdc4f2a8e72d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.parking_lot-4acf5fa50a52bd18.parking_lot.b59ab0d8f2549f8e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.parking_lot_core-0dcf47a90d11c4e4.parking_lot_core.502597fbe5df1389-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.pem_rfc7468-d976dcafab7c7e37.pem_rfc7468.757403f363ad557c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.percent_encoding-2e8ac337530122b2.percent_encoding.f83c908de861c15d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_diagnostics-fba70546dd9f3424.perry_diagnostics.cefa4a43ff59d614-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_dispatch-0bc0b01b9b7736fe.perry_dispatch.cd02373148e7c215-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_parser-b68fb40287dd2e20.perry_parser.6e33b45a5046bf8f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_runtime-9458b86ff25d0db1.perry_runtime.261c4ba5a81df8f2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000152804 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_>:
  152804:      	stp	x28, x27, [sp, #-0x60]!
  152808:      	stp	x26, x25, [sp, #0x10]
  15280c:      	stp	x24, x23, [sp, #0x20]
  152810:      	stp	x22, x21, [sp, #0x30]
  152814:      	stp	x20, x19, [sp, #0x40]
  152818:      	stp	x29, x30, [sp, #0x50]
  15281c:      	add	x29, sp, #0x50
  152820:      	sub	sp, sp, #0x250
  152824:      	mov	x19, x0
  152828:      	ldp	x8, x9, [x0, #0x68]
  15282c:      	add	x9, x9, #0x1
  152830:      	str	x9, [x0, #0x70]
  152834:      	cmp	x9, x8
  152838:      	b.hs	0x15286c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x68>
  15283c:      	ldr	x10, [x19, #0x60]
  152840:      	mov	x11, #0x2600            ; =9728
  152844:      	movk	x11, #0x1, lsl #32
  152848:      	ldrb	w12, [x10, x9]
  15284c:      	cmp	w12, #0x20
  152850:      	b.hi	0x15286c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x68>
  152854:      	lsr	x12, x11, x12
  152858:      	tbz	w12, #0x0, 0x15286c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x68>
  15285c:      	add	x9, x9, #0x1
  152860:      	str	x9, [x19, #0x70]
  152864:      	cmp	x8, x9
  152868:      	b.ne	0x152848 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x44>
  15286c:      	ldrb	w8, [x19, #0xd5]
  152870:      	tbz	w8, #0x0, 0x15289c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x98>
  152874:      	strb	wzr, [x19, #0xd5]
  152878:      	ldr	x22, [x19, #0x78]
  15287c:      	ldp	q0, q1, [x19, #0x80]
  152880:      	stur	q0, [sp, #0xb8]
  152884:      	stur	q1, [sp, #0xc8]
  152888:      	ldp	q0, q1, [x19, #0xa0]
  15288c:      	stur	q0, [sp, #0xd8]
  152890:      	stur	q1, [sp, #0xe8]
  152894:      	ldr	x21, [x19, #0xc0]
  152898:      	b	0x1528cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc8>
  15289c:      	mov	w26, #0x0               ; =0
  1528a0:      	mov	x8, #0x0                ; =0
  1528a4:      	ldr	x22, [x19, #0x78]
  1528a8:      	cbz	x22, 0x1535e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xde0>
  1528ac:      	ldr	x21, [x19, #0xc0]
  1528b0:      	cbz	x21, 0x1528e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe0>
  1528b4:      	ldp	q0, q1, [x19, #0x80]
  1528b8:      	stur	q0, [sp, #0xb8]
  1528bc:      	stur	q1, [sp, #0xc8]
  1528c0:      	ldp	q0, q1, [x19, #0xa0]
  1528c4:      	stur	q0, [sp, #0xd8]
  1528c8:      	stur	q1, [sp, #0xe8]
  1528cc:      	ldr	w8, [x19, #0xd0]
  1528d0:      	stp	x22, x21, [sp, #0xf8]
  1528d4:      	str	w8, [sp, #0x84]
  1528d8:      	str	w8, [sp, #0x108]
  1528dc:      	mov	w8, #0x1                ; =1
  1528e0:      	mov	w26, #0x1               ; =1
  1528e4:      	str	x8, [sp, #0xb0]
  1528e8:      	adrp	x0, 0x152000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_bytesB9_+0x208>
  1528ec:      	ldr	x0, [x0]
  1528f0:      	ldr	x8, [x0]
  1528f4:      	blr	x8
  1528f8:      	mov	x20, x0
  1528fc:      	ldrb	w8, [x0, #0x20]
  152900:      	cbnz	w8, 0x153954 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1150>
  152904:      	ldr	x8, [x20]
  152908:      	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
  15290c:      	cmp	x8, x9
  152910:      	b.hs	0x153980 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x117c>
  152914:      	ldr	x27, [x20, #0x18]
  152918:      	ldp	x23, x28, [x19, #0x68]
  15291c:      	cmp	x28, x23
  152920:      	b.hs	0x152954 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x150>
  152924:      	ldr	x8, [x19, #0x60]
  152928:      	ldrb	w8, [x8, x28]
  15292c:      	cmp	w8, #0x7d
  152930:      	b.ne	0x152954 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x150>
  152934:      	add	x8, x28, #0x1
  152938:      	str	x8, [x19, #0x70]
  15293c:      	ldr	x8, [x19, #0x78]
  152940:      	cbnz	x8, 0x1535e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xde4>
  152944:      	ldr	x1, [x19, #0xc0]
  152948:      	cbz	x1, 0x1535e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xde4>
  15294c:      	ldr	w2, [x19, #0xd0]
  152950:      	b	0x153608 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe04>
  152954:      	movi.2d	v0, #0000000000000000
  152958:      	stp	q0, q0, [sp, #0x130]
  15295c:      	stp	q0, q0, [sp, #0x110]
  152960:      	adrp	x1, 0x152000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_bytesB9_+0x208>
  152964:      	add	x1, x1, #0x0
  152968:      	add	x0, sp, #0x158
  15296c:      	mov	w2, #0x40               ; =64
  152970:      	bl	0x152970 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x16c>
  152974:      	mov	x24, #0x0               ; =0
  152978:      	str	xzr, [sp, #0xa0]
  15297c:      	mov	x8, #-0x1               ; =-1
  152980:      	str	x8, [sp, #0x198]
  152984:      	add	x8, sp, #0xb0
  152988:      	add	x8, x8, #0x8
  15298c:      	stp	x8, xzr, [sp, #0x88]
  152990:      	mov	x25, #0x2600            ; =9728
  152994:      	movk	x25, #0x1, lsl #32
  152998:      	adrp	x8, 0x152000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_bytesB9_+0x208>
  15299c:      	ldr	q0, [x8]
  1529a0:      	str	q0, [sp, #0x60]
  1529a4:      	adrp	x8, 0x152000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_bytesB9_+0x208>
  1529a8:      	ldr	q0, [x8]
  1529ac:      	str	q0, [sp, #0x50]
  1529b0:      	mov	x11, x26
  1529b4:      	mov	x8, x26
  1529b8:      	str	x21, [sp, #0x78]
  1529bc:      	str	w26, [sp, #0x9c]
  1529c0:      	str	w8, [sp, #0x98]
  1529c4:      	cmp	x28, x23
  1529c8:      	b.hs	0x1529f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1f4>
  1529cc:      	ldr	x8, [x19, #0x60]
  1529d0:      	ldrb	w9, [x8, x28]
  1529d4:      	cmp	w9, #0x20
  1529d8:      	b.hi	0x1529f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1f4>
  1529dc:      	lsr	x9, x25, x9
  1529e0:      	tbz	w9, #0x0, 0x1529f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1f4>
  1529e4:      	add	x28, x28, #0x1
  1529e8:      	str	x28, [x19, #0x70]
  1529ec:      	cmp	x23, x28
  1529f0:      	b.ne	0x1529d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1cc>
  1529f4:      	mov	x28, x23
  1529f8:      	str	x24, [sp, #0xa8]
  1529fc:      	cbz	w26, 0x152ab8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b4>
  152a00:      	cmp	x24, x22
  152a04:      	cset	w8, lo
  152a08:      	tst	w11, w8
  152a0c:      	b.eq	0x152ab8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b4>
  152a10:      	cmp	x24, #0x8
  152a14:      	b.hs	0x153a28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1224>
  152a18:      	mov	x26, x11
  152a1c:      	cmp	x28, x23
  152a20:      	b.hs	0x152abc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
  152a24:      	ldr	x8, [sp, #0x88]
  152a28:      	ldr	x9, [x8, x24, lsl #3]
  152a2c:      	cbz	x9, 0x152abc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
  152a30:      	ldr	x10, [x19, #0x60]
  152a34:      	ldrb	w8, [x10, x28]
  152a38:      	cmp	w8, #0x22
  152a3c:      	b.ne	0x152abc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
  152a40:      	add	x11, x28, #0x1
  152a44:      	ldr	w14, [x9, #0x4]
  152a48:      	add	x8, x11, x14
  152a4c:      	cmp	x8, x23
  152a50:      	ccmp	x8, x28, #0x0, lo
  152a54:      	b.ls	0x152abc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
  152a58:      	ldrb	w12, [x10, x8]
  152a5c:      	cmp	w12, #0x22
  152a60:      	b.ne	0x152abc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
  152a64:      	add	x23, x10, x11
  152a68:      	cbz	w14, 0x152aa4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2a0>
  152a6c:      	add	x9, x9, #0x14
  152a70:      	mov	x10, x14
  152a74:      	mov	x11, x23
  152a78:      	ldrb	w12, [x11], #0x1
  152a7c:      	cmp	w12, #0x5c
  152a80:      	b.eq	0x152abc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
  152a84:      	cmp	w12, #0x22
  152a88:      	b.eq	0x152abc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
  152a8c:      	ldrb	w13, [x9], #0x1
  152a90:      	cmp	w12, #0x20
  152a94:      	ccmp	w12, w13, #0x0, hs
  152a98:      	b.ne	0x152abc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
  152a9c:      	subs	x10, x10, #0x1
  152aa0:      	b.ne	0x152a78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x274>
  152aa4:      	add	x8, x8, #0x1
  152aa8:      	str	x8, [x19, #0x70]
  152aac:      	mov	w28, #0x1               ; =1
  152ab0:      	mov	x24, #-0x1              ; =-1
  152ab4:      	b	0x152adc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2d8>
  152ab8:      	mov	x26, x11
  152abc:      	sub	x0, x29, #0x80
  152ac0:      	mov	x1, x19
  152ac4:      	bl	0x152ac4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2c0>
  152ac8:      	ldur	x24, [x29, #-0x80]
  152acc:      	cmn	x24, #0x2
  152ad0:      	b.eq	0x153650 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe4c>
  152ad4:      	mov	w28, #0x0               ; =0
  152ad8:      	ldp	x23, x14, [x29, #-0x78]
  152adc:      	ldp	x9, x8, [x19, #0x68]
  152ae0:      	cmp	x8, x9
  152ae4:      	b.hs	0x1534c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcbc>
  152ae8:      	ldr	x10, [x19, #0x60]
  152aec:      	ldrb	w11, [x10, x8]
  152af0:      	cmp	w11, #0x3a
  152af4:      	b.hi	0x1534c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcbc>
  152af8:      	lsr	x12, x25, x11
  152afc:      	tbz	w12, #0x0, 0x152b14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x310>
  152b00:      	add	x8, x8, #0x1
  152b04:      	str	x8, [x19, #0x70]
  152b08:      	cmp	x9, x8
  152b0c:      	b.ne	0x152aec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2e8>
  152b10:      	b	0x1534c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcbc>
  152b14:      	cmp	x11, #0x3a
  152b18:      	b.ne	0x1534c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcbc>
  152b1c:      	str	x14, [sp, #0x48]
  152b20:      	add	x8, x8, #0x1
  152b24:      	str	x8, [x19, #0x70]
  152b28:      	mov	x0, x19
  152b2c:      	bl	0x152b2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x328>
  152b30:      	ldrb	w8, [x19, #0xd4]
  152b34:      	tbz	w8, #0x0, 0x1534c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcc0>
  152b38:      	ldr	x9, [sp, #0x198]
  152b3c:      	cmn	x9, #0x1
  152b40:      	stp	x0, x23, [sp, #0x38]
  152b44:      	ldr	x17, [sp, #0x48]
  152b48:      	b.eq	0x152c0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x408>
  152b4c:      	ldr	x8, [sp, #0x1c8]
  152b50:      	ldr	x28, [sp, #0x1a8]
  152b54:      	cmn	x8, #0x1
  152b58:      	b.eq	0x152c5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x458>
  152b5c:      	ldr	x11, [sp, #0x208]
  152b60:      	ldr	x8, [sp, #0x200]
  152b64:      	ldr	x10, [sp, #0x210]
  152b68:      	ldr	x9, [sp, #0x218]
  152b6c:      	eor	x11, x11, x17
  152b70:      	mov	x13, #0x7f2d            ; =32557
  152b74:      	movk	x13, #0x4c95, lsl #16
  152b78:      	movk	x13, #0xf42d, lsl #32
  152b7c:      	movk	x13, #0x5851, lsl #48
  152b80:      	mul	x12, x11, x13
  152b84:      	umulh	x11, x11, x13
  152b88:      	eor	x11, x11, x12
  152b8c:      	add	x11, x17, x11
  152b90:      	mul	x11, x11, x13
  152b94:      	cmp	x17, #0x8
  152b98:      	str	x28, [sp, #0x28]
  152b9c:      	b.ls	0x152cb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x4ac>
  152ba0:      	cmp	x17, #0x10
  152ba4:      	b.ls	0x152d58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x554>
  152ba8:      	add	x12, x23, x17
  152bac:      	ldp	x12, x13, [x12, #-0x10]
  152bb0:      	eor	x12, x10, x12
  152bb4:      	eor	x13, x13, x9
  152bb8:      	mul	x14, x13, x12
  152bbc:      	umulh	x12, x13, x12
  152bc0:      	eor	x12, x12, x14
  152bc4:      	add	x11, x11, x8
  152bc8:      	eor	x11, x11, x12
  152bcc:      	ror	x11, x11, #0x29
  152bd0:      	mov	x13, x23
  152bd4:      	mov	x12, x17
  152bd8:      	ldp	x15, x14, [x13], #0x10
  152bdc:      	sub	x12, x12, #0x10
  152be0:      	eor	x15, x10, x15
  152be4:      	eor	x14, x14, x9
  152be8:      	mul	x16, x14, x15
  152bec:      	umulh	x14, x14, x15
  152bf0:      	eor	x14, x14, x16
  152bf4:      	add	x11, x11, x8
  152bf8:      	eor	x11, x11, x14
  152bfc:      	ror	x11, x11, #0x29
  152c00:      	cmp	x12, #0x10
  152c04:      	b.hi	0x152bd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x3d4>
  152c08:      	b	0x152e34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x630>
  152c0c:      	ldr	w8, [sp, #0x98]
  152c10:      	tbz	w8, #0x0, 0x152cd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x4cc>
  152c14:      	ldr	w8, [sp, #0x9c]
  152c18:      	tbz	w8, #0x0, 0x153a1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1218>
  152c1c:      	ldr	x8, [sp, #0xa8]
  152c20:      	cmp	x8, x22
  152c24:      	mov	x11, x26
  152c28:      	ldr	w26, [sp, #0x9c]
  152c2c:      	b.hs	0x152f70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x76c>
  152c30:      	tbz	w28, #0x0, 0x152f2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x728>
  152c34:      	ldr	x0, [sp, #0xa8]
  152c38:      	cmp	x0, #0x7
  152c3c:      	ldr	x9, [sp, #0x30]
  152c40:      	b.hi	0x153a60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x125c>
  152c44:      	ldr	x8, [sp, #0x88]
  152c48:      	ldr	x10, [x8, x0, lsl #3]
  152c4c:      	add	x0, x0, #0x1
  152c50:      	str	x0, [sp, #0xa8]
  152c54:      	mov	w8, #0x1                ; =1
  152c58:      	b	0x152f8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x788>
  152c5c:      	str	x9, [sp, #0x10]
  152c60:      	ldr	x1, [sp, #0x1a0]
  152c64:      	cmp	x28, #0x80
  152c68:      	b.ne	0x152cf0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x4ec>
  152c6c:      	mov	w8, #0x1                ; =1
  152c70:      	strb	w8, [x19, #0xd6]
  152c74:      	add	x8, sp, #0x198
  152c78:      	add	x0, x8, #0x30
  152c7c:      	mov	x21, x1
  152c80:      	bl	0x152c80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x47c>
  152c84:      	ldr	x17, [sp, #0x48]
  152c88:      	ldr	x8, [sp, #0x1c8]
  152c8c:      	cmn	x8, #0x1
  152c90:      	b.ne	0x152b5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x358>
  152c94:      	mov	x0, x23
  152c98:      	mov	x1, x17
  152c9c:      	bl	0x152c9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x498>
  152ca0:      	mov	x23, x0
  152ca4:      	add	x13, x21, #0x400
  152ca8:      	mov	x10, x21
  152cac:      	b	0x152d10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x50c>
  152cb0:      	cmp	x17, #0x1
  152cb4:      	b.ls	0x152d68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x564>
  152cb8:      	add	x13, x23, x17
  152cbc:      	cmp	x17, #0x3
  152cc0:      	b.ls	0x152e00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x5fc>
  152cc4:      	ldr	w12, [x23]
  152cc8:      	ldur	w13, [x13, #-0x4]
  152ccc:      	b	0x152e14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x610>
  152cd0:      	mov	x0, x23
  152cd4:      	mov	x1, x17
  152cd8:      	bl	0x152cd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x4d4>
  152cdc:      	mov	x10, x0
  152ce0:      	mov	w8, #0x0                ; =0
  152ce4:      	mov	x11, x26
  152ce8:      	ldr	w26, [sp, #0x9c]
  152cec:      	b	0x152f88 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x784>
  152cf0:      	str	x1, [sp, #0x8]
  152cf4:      	mov	x0, x23
  152cf8:      	mov	x1, x17
  152cfc:      	bl	0x152cfc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x4f8>
  152d00:      	mov	x23, x0
  152d04:      	cbz	x28, 0x153354 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb50>
  152d08:      	ldr	x10, [sp, #0x8]
  152d0c:      	add	x13, x10, x28, lsl #3
  152d10:      	ldr	x8, [sp, #0xa8]
  152d14:      	cmp	x8, #0x0
  152d18:      	cset	w8, eq
  152d1c:      	ldr	w9, [sp, #0x98]
  152d20:      	orr	w8, w8, w9
  152d24:      	tbz	w8, #0x0, 0x152d78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x574>
  152d28:      	mov	x0, #0x0                ; =0
  152d2c:      	mov	x8, x10
  152d30:      	mov	x11, x26
  152d34:      	ldr	w26, [sp, #0x9c]
  152d38:      	ldr	x9, [x8], #0x8
  152d3c:      	cmp	x9, x23
  152d40:      	b.eq	0x152de4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x5e0>
  152d44:      	add	x0, x0, #0x1
  152d48:      	cmp	x8, x13
  152d4c:      	b.ne	0x152d38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x534>
  152d50:      	ldr	x9, [sp, #0x30]
  152d54:      	b	0x153378 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb74>
  152d58:      	ldr	x12, [x23]
  152d5c:      	add	x13, x23, x17
  152d60:      	ldur	x13, [x13, #-0x8]
  152d64:      	b	0x152e14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x610>
  152d68:      	b.ne	0x152e0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x608>
  152d6c:      	ldrb	w12, [x23]
  152d70:      	mov	x13, x12
  152d74:      	b	0x152e14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x610>
  152d78:      	str	x28, [sp, #0x28]
  152d7c:      	str	x27, [sp, #0x18]
  152d80:      	mov	x28, #0x0               ; =0
  152d84:      	str	x10, [sp, #0x8]
  152d88:      	mov	x27, x10
  152d8c:      	ldr	x2, [sp, #0x48]
  152d90:      	b	0x152da0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x59c>
  152d94:      	sub	x28, x28, #0x1
  152d98:      	cmp	x27, x13
  152d9c:      	b.eq	0x153364 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb60>
  152da0:      	ldr	x8, [x27], #0x8
  152da4:      	cmp	x8, x23
  152da8:      	b.eq	0x152dd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x5d0>
  152dac:      	ldr	w9, [x8, #0x4]
  152db0:      	cmp	x2, x9
  152db4:      	b.ne	0x152d94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x590>
  152db8:      	add	x0, x8, #0x14
  152dbc:      	ldr	x1, [sp, #0x40]
  152dc0:      	mov	x21, x13
  152dc4:      	bl	0x152dc4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x5c0>
  152dc8:      	mov	x13, x21
  152dcc:      	ldr	x2, [sp, #0x48]
  152dd0:      	cbnz	w0, 0x152d94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x590>
  152dd4:      	neg	x0, x28
  152dd8:      	ldr	x27, [sp, #0x18]
  152ddc:      	mov	x11, x26
  152de0:      	ldr	w26, [sp, #0x9c]
  152de4:      	ldr	x9, [sp, #0x30]
  152de8:      	cmp	x0, x9
  152dec:      	b.hs	0x153a50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x124c>
  152df0:      	ldr	x8, [sp, #0x20]
  152df4:      	ldr	x10, [sp, #0x38]
  152df8:      	str	x10, [x8, x0, lsl #3]
  152dfc:      	b	0x1533b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbb0>
  152e00:      	ldrh	w12, [x23]
  152e04:      	ldurb	w13, [x13, #-0x1]
  152e08:      	b	0x152e14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x610>
  152e0c:      	mov	x12, #0x0               ; =0
  152e10:      	mov	x13, #0x0               ; =0
  152e14:      	eor	x10, x12, x10
  152e18:      	eor	x9, x13, x9
  152e1c:      	mul	x12, x9, x10
  152e20:      	umulh	x9, x9, x10
  152e24:      	eor	x9, x9, x12
  152e28:      	add	x10, x11, x8
  152e2c:      	eor	x9, x10, x9
  152e30:      	ror	x11, x9, #0x29
  152e34:      	mul	x9, x11, x8
  152e38:      	umulh	x8, x11, x8
  152e3c:      	eor	x8, x8, x9
  152e40:      	neg	w9, w11
  152e44:      	ror	x28, x8, x9
  152e48:      	ldr	x4, [sp, #0x1a0]
  152e4c:      	add	x8, sp, #0x198
  152e50:      	add	x0, x8, #0x30
  152e54:      	mov	x1, x28
  152e58:      	mov	x2, x23
  152e5c:      	mov	x3, x17
  152e60:      	ldr	x5, [sp, #0x28]
  152e64:      	bl	0x152e64 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x660>
  152e68:      	tbz	w0, #0x0, 0x152e90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x68c>
  152e6c:      	ldr	x9, [sp, #0x30]
  152e70:      	cmp	x1, x9
  152e74:      	b.hs	0x153a3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1238>
  152e78:      	mov	x11, x26
  152e7c:      	ldr	x8, [sp, #0x20]
  152e80:      	ldr	x10, [sp, #0x38]
  152e84:      	str	x10, [x8, x1, lsl #3]
  152e88:      	ldr	w26, [sp, #0x9c]
  152e8c:      	b	0x1533b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbb0>
  152e90:      	str	x27, [sp, #0x18]
  152e94:      	cmn	x24, #0x1
  152e98:      	b.eq	0x152eac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x6a8>
  152e9c:      	mov	x0, x23
  152ea0:      	ldr	x1, [sp, #0x48]
  152ea4:      	bl	0x152ea4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x6a0>
  152ea8:      	b	0x152ebc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x6b8>
  152eac:      	add	x0, x19, #0x20
  152eb0:      	mov	x1, x23
  152eb4:      	ldr	x2, [sp, #0x48]
  152eb8:      	bl	0x152eb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x6b4>
  152ebc:      	mov	x27, x0
  152ec0:      	add	x8, sp, #0x198
  152ec4:      	add	x0, x8, #0x30
  152ec8:      	mov	x1, x28
  152ecc:      	ldr	x2, [sp, #0x28]
  152ed0:      	bl	0x152ed0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x6cc>
  152ed4:      	ldr	x23, [sp, #0x1a8]
  152ed8:      	ldr	x8, [sp, #0x198]
  152edc:      	cmp	x23, x8
  152ee0:      	b.eq	0x153444 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc40>
  152ee4:      	ldr	x8, [sp, #0x1a0]
  152ee8:      	ldr	x9, [sp, #0x1b0]
  152eec:      	str	x27, [x8, x23, lsl #3]
  152ef0:      	add	x8, x23, #0x1
  152ef4:      	str	x8, [sp, #0x1a8]
  152ef8:      	ldr	x23, [sp, #0x1c0]
  152efc:      	cmp	x23, x9
  152f00:      	b.eq	0x153450 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc4c>
  152f04:      	ldr	x8, [sp, #0x1b8]
  152f08:      	str	x8, [sp, #0x20]
  152f0c:      	ldr	x9, [sp, #0x38]
  152f10:      	str	x9, [x8, x23, lsl #3]
  152f14:      	add	x9, x23, #0x1
  152f18:      	str	x9, [sp, #0x1c0]
  152f1c:      	ldr	x27, [sp, #0x18]
  152f20:      	mov	x11, x26
  152f24:      	ldr	w26, [sp, #0x9c]
  152f28:      	b	0x1533b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbb0>
  152f2c:      	ldr	x0, [sp, #0xa8]
  152f30:      	cmp	x0, #0x8
  152f34:      	b.hs	0x153a70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x126c>
  152f38:      	ldr	x8, [sp, #0x88]
  152f3c:      	ldr	x9, [x8, x0, lsl #3]
  152f40:      	ldr	w8, [x9, #0x4]
  152f44:      	cmp	x17, x8
  152f48:      	b.ne	0x152f70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x76c>
  152f4c:      	add	x0, x9, #0x14
  152f50:      	mov	x1, x23
  152f54:      	mov	x2, x17
  152f58:      	mov	x23, x11
  152f5c:      	mov	x28, x9
  152f60:      	bl	0x152f60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x75c>
  152f64:      	mov	x11, x23
  152f68:      	ldp	x23, x17, [sp, #0x40]
  152f6c:      	cbz	w0, 0x153460 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc5c>
  152f70:      	mov	x0, x23
  152f74:      	mov	x1, x17
  152f78:      	bl	0x152f78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x774>
  152f7c:      	mov	x10, x0
  152f80:      	mov	w11, #0x0               ; =0
  152f84:      	mov	w8, #0x0                ; =0
  152f88:      	ldr	x9, [sp, #0x30]
  152f8c:      	ldp	x1, x12, [sp, #0xa0]
  152f90:      	cmp	x12, #0x0
  152f94:      	str	w8, [sp, #0x98]
  152f98:      	csinc	w28, w8, wzr, ne
  152f9c:      	cmp	x1, #0x9
  152fa0:      	b.hs	0x1539e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11dc>
  152fa4:      	ldr	x2, [sp, #0x48]
  152fa8:      	cbz	x1, 0x153320 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
  152fac:      	ldr	x8, [sp, #0x110]
  152fb0:      	cmp	x8, x10
  152fb4:      	b.eq	0x153344 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb40>
  152fb8:      	tbnz	w28, #0x0, 0x152ff0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7ec>
  152fbc:      	ldr	w9, [x8, #0x4]
  152fc0:      	cmp	x2, x9
  152fc4:      	ldr	x9, [sp, #0x30]
  152fc8:      	b.ne	0x152ff0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7ec>
  152fcc:      	add	x0, x8, #0x14
  152fd0:      	mov	x1, x23
  152fd4:      	mov	x23, x11
  152fd8:      	str	x10, [sp, #0x28]
  152fdc:      	bl	0x152fdc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7d8>
  152fe0:      	ldp	x10, x9, [sp, #0x28]
  152fe4:      	mov	x11, x23
  152fe8:      	ldp	x23, x2, [sp, #0x40]
  152fec:      	cbz	w0, 0x153344 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb40>
  152ff0:      	ldr	x1, [sp, #0xa0]
  152ff4:      	cmp	x1, #0x1
  152ff8:      	b.eq	0x153320 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
  152ffc:      	ldr	x9, [sp, #0x118]
  153000:      	add	x8, sp, #0x158
  153004:      	add	x8, x8, #0x8
  153008:      	cmp	x9, x10
  15300c:      	b.eq	0x153348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
  153010:      	tbnz	w28, #0x0, 0x15304c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x848>
  153014:      	ldr	w8, [x9, #0x4]
  153018:      	cmp	x2, x8
  15301c:      	b.ne	0x15304c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x848>
  153020:      	add	x0, x9, #0x14
  153024:      	mov	x1, x23
  153028:      	mov	x23, x11
  15302c:      	str	x10, [sp, #0x28]
  153030:      	bl	0x153030 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x82c>
  153034:      	ldr	x10, [sp, #0x28]
  153038:      	mov	x11, x23
  15303c:      	ldp	x23, x2, [sp, #0x40]
  153040:      	add	x8, sp, #0x158
  153044:      	add	x8, x8, #0x8
  153048:      	cbz	w0, 0x153348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
  15304c:      	ldr	x1, [sp, #0xa0]
  153050:      	cmp	x1, #0x2
  153054:      	ldr	x9, [sp, #0x30]
  153058:      	b.eq	0x153320 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
  15305c:      	ldr	x9, [sp, #0x120]
  153060:      	add	x8, sp, #0x158
  153064:      	add	x8, x8, #0x10
  153068:      	cmp	x9, x10
  15306c:      	b.eq	0x153348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
  153070:      	tbnz	w28, #0x0, 0x1530ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x8a8>
  153074:      	ldr	w8, [x9, #0x4]
  153078:      	cmp	x2, x8
  15307c:      	b.ne	0x1530ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x8a8>
  153080:      	add	x0, x9, #0x14
  153084:      	mov	x1, x23
  153088:      	mov	x23, x11
  15308c:      	str	x10, [sp, #0x28]
  153090:      	bl	0x153090 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x88c>
  153094:      	ldr	x10, [sp, #0x28]
  153098:      	mov	x11, x23
  15309c:      	ldp	x23, x2, [sp, #0x40]
  1530a0:      	add	x8, sp, #0x158
  1530a4:      	add	x8, x8, #0x10
  1530a8:      	cbz	w0, 0x153348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
  1530ac:      	ldr	x1, [sp, #0xa0]
  1530b0:      	cmp	x1, #0x3
  1530b4:      	ldr	x9, [sp, #0x30]
  1530b8:      	b.eq	0x153320 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
  1530bc:      	ldr	x9, [sp, #0x128]
  1530c0:      	add	x8, sp, #0x158
  1530c4:      	add	x8, x8, #0x18
  1530c8:      	cmp	x9, x10
  1530cc:      	b.eq	0x153348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
  1530d0:      	tbnz	w28, #0x0, 0x15310c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x908>
  1530d4:      	ldr	w8, [x9, #0x4]
  1530d8:      	cmp	x2, x8
  1530dc:      	b.ne	0x15310c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x908>
  1530e0:      	add	x0, x9, #0x14
  1530e4:      	mov	x1, x23
  1530e8:      	mov	x23, x11
  1530ec:      	str	x10, [sp, #0x28]
  1530f0:      	bl	0x1530f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x8ec>
  1530f4:      	ldr	x10, [sp, #0x28]
  1530f8:      	mov	x11, x23
  1530fc:      	ldp	x23, x2, [sp, #0x40]
  153100:      	add	x8, sp, #0x158
  153104:      	add	x8, x8, #0x18
  153108:      	cbz	w0, 0x153348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
  15310c:      	ldr	x1, [sp, #0xa0]
  153110:      	cmp	x1, #0x4
  153114:      	ldr	x9, [sp, #0x30]
  153118:      	b.eq	0x153320 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
  15311c:      	ldr	x9, [sp, #0x130]
  153120:      	add	x8, sp, #0x158
  153124:      	add	x8, x8, #0x20
  153128:      	cmp	x9, x10
  15312c:      	b.eq	0x153348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
  153130:      	tbnz	w28, #0x0, 0x15316c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x968>
  153134:      	ldr	w8, [x9, #0x4]
  153138:      	cmp	x2, x8
  15313c:      	b.ne	0x15316c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x968>
  153140:      	add	x0, x9, #0x14
  153144:      	mov	x1, x23
  153148:      	mov	x23, x11
  15314c:      	str	x10, [sp, #0x28]
  153150:      	bl	0x153150 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x94c>
  153154:      	ldr	x10, [sp, #0x28]
  153158:      	mov	x11, x23
  15315c:      	ldp	x23, x2, [sp, #0x40]
  153160:      	add	x8, sp, #0x158
  153164:      	add	x8, x8, #0x20
  153168:      	cbz	w0, 0x153348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
  15316c:      	ldr	x1, [sp, #0xa0]
  153170:      	cmp	x1, #0x5
  153174:      	ldr	x9, [sp, #0x30]
  153178:      	b.eq	0x153320 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
  15317c:      	ldr	x9, [sp, #0x138]
  153180:      	add	x8, sp, #0x158
  153184:      	add	x8, x8, #0x28
  153188:      	cmp	x9, x10
  15318c:      	b.eq	0x153348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
  153190:      	tbnz	w28, #0x0, 0x1531cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x9c8>
  153194:      	ldr	w8, [x9, #0x4]
  153198:      	cmp	x2, x8
  15319c:      	b.ne	0x1531cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x9c8>
  1531a0:      	add	x0, x9, #0x14
  1531a4:      	mov	x1, x23
  1531a8:      	mov	x23, x11
  1531ac:      	str	x10, [sp, #0x28]
  1531b0:      	bl	0x1531b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x9ac>
  1531b4:      	ldr	x10, [sp, #0x28]
  1531b8:      	mov	x11, x23
  1531bc:      	ldp	x23, x2, [sp, #0x40]
  1531c0:      	add	x8, sp, #0x158
  1531c4:      	add	x8, x8, #0x28
  1531c8:      	cbz	w0, 0x153348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
  1531cc:      	ldr	x1, [sp, #0xa0]
  1531d0:      	cmp	x1, #0x6
  1531d4:      	ldr	x9, [sp, #0x30]
  1531d8:      	b.eq	0x153320 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
  1531dc:      	ldr	x9, [sp, #0x140]
  1531e0:      	add	x8, sp, #0x158
  1531e4:      	add	x8, x8, #0x30
  1531e8:      	cmp	x9, x10
  1531ec:      	b.eq	0x153348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
  1531f0:      	tbnz	w28, #0x0, 0x15322c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xa28>
  1531f4:      	ldr	w8, [x9, #0x4]
  1531f8:      	cmp	x2, x8
  1531fc:      	b.ne	0x15322c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xa28>
  153200:      	add	x0, x9, #0x14
  153204:      	mov	x1, x23
  153208:      	mov	x23, x11
  15320c:      	str	x10, [sp, #0x28]
  153210:      	bl	0x153210 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xa0c>
  153214:      	ldr	x10, [sp, #0x28]
  153218:      	mov	x11, x23
  15321c:      	ldp	x23, x2, [sp, #0x40]
  153220:      	add	x8, sp, #0x158
  153224:      	add	x8, x8, #0x30
  153228:      	cbz	w0, 0x153348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
  15322c:      	ldr	x1, [sp, #0xa0]
  153230:      	cmp	x1, #0x7
  153234:      	ldr	x9, [sp, #0x30]
  153238:      	b.eq	0x153320 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
  15323c:      	ldr	x9, [sp, #0x148]
  153240:      	add	x8, sp, #0x158
  153244:      	add	x8, x8, #0x38
  153248:      	cmp	x9, x10
  15324c:      	b.eq	0x153348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
  153250:      	tbnz	w28, #0x0, 0x153288 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xa84>
  153254:      	ldr	w8, [x9, #0x4]
  153258:      	cmp	x2, x8
  15325c:      	b.ne	0x153288 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xa84>
  153260:      	add	x0, x9, #0x14
  153264:      	mov	x1, x23
  153268:      	mov	x23, x11
  15326c:      	mov	x28, x10
  153270:      	bl	0x153270 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xa6c>
  153274:      	mov	x10, x28
  153278:      	mov	x11, x23
  15327c:      	add	x8, sp, #0x158
  153280:      	add	x8, x8, #0x38
  153284:      	cbz	w0, 0x153348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
  153288:      	ldr	x1, [sp, #0xa0]
  15328c:      	cmp	x1, #0x8
  153290:      	ldr	x9, [sp, #0x30]
  153294:      	b.ne	0x153320 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
  153298:      	mov	x28, x10
  15329c:      	mov	x26, x11
  1532a0:      	mov	w0, #0x80               ; =128
  1532a4:      	bl	0x1532a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xaa0>
  1532a8:      	cbz	x0, 0x153a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x127c>
  1532ac:      	mov	x23, x0
  1532b0:      	mov	w0, #0x80               ; =128
  1532b4:      	mov	w1, #0x8                ; =8
  1532b8:      	bl	0x1532b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xab4>
  1532bc:      	str	x0, [sp, #0x20]
  1532c0:      	cbz	x0, 0x153a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x127c>
  1532c4:      	ldp	q0, q1, [sp, #0x110]
  1532c8:      	stp	q0, q1, [x23]
  1532cc:      	ldp	q0, q1, [sp, #0x130]
  1532d0:      	stp	q0, q1, [x23, #0x20]
  1532d4:      	add	x9, sp, #0x158
  1532d8:      	ldp	q0, q1, [x9]
  1532dc:      	ldr	x10, [sp, #0x20]
  1532e0:      	stp	q0, q1, [x10]
  1532e4:      	ldp	q0, q1, [x9, #0x20]
  1532e8:      	stp	q0, q1, [x10, #0x20]
  1532ec:      	str	x28, [x23, #0x40]
  1532f0:      	ldr	x8, [sp, #0x38]
  1532f4:      	str	x8, [x10, #0x40]
  1532f8:      	mov	w8, #0x10               ; =16
  1532fc:      	stp	x8, x23, [sp, #0x198]
  153300:      	ldp	q0, q1, [sp, #0x50]
  153304:      	str	q1, [x9, #0x50]
  153308:      	str	x10, [sp, #0x1b8]
  15330c:      	mov	w8, #0x8                ; =8
  153310:      	str	x8, [sp, #0xa0]
  153314:      	stur	q0, [x9, #0x68]
  153318:      	mov	w9, #0x9                ; =9
  15331c:      	b	0x152f20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x71c>
  153320:      	add	x8, sp, #0x110
  153324:      	str	x10, [x8, x1, lsl #3]
  153328:      	add	x8, sp, #0x158
  15332c:      	ldr	x10, [sp, #0x38]
  153330:      	str	x10, [x8, x1, lsl #3]
  153334:      	add	x8, x1, #0x1
  153338:      	str	x8, [sp, #0x90]
  15333c:      	str	x8, [sp, #0xa0]
  153340:      	b	0x1533b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbb0>
  153344:      	add	x8, sp, #0x158
  153348:      	ldp	x9, x10, [sp, #0x30]
  15334c:      	str	x10, [x8]
  153350:      	b	0x1533b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbb0>
  153354:      	mov	x11, x26
  153358:      	ldr	w26, [sp, #0x9c]
  15335c:      	ldr	x9, [sp, #0x30]
  153360:      	b	0x153374 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb70>
  153364:      	ldr	x27, [sp, #0x18]
  153368:      	mov	x11, x26
  15336c:      	ldr	w26, [sp, #0x9c]
  153370:      	ldp	x28, x9, [sp, #0x28]
  153374:      	ldr	x10, [sp, #0x8]
  153378:      	ldr	x8, [sp, #0x10]
  15337c:      	cmp	x28, x8
  153380:      	b.eq	0x153470 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc6c>
  153384:      	str	x23, [x10, x28, lsl #3]
  153388:      	add	x8, x28, #0x1
  15338c:      	str	x8, [sp, #0x1a8]
  153390:      	ldr	x8, [sp, #0x1b0]
  153394:      	cmp	x9, x8
  153398:      	b.eq	0x1534a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc9c>
  15339c:      	ldr	x8, [sp, #0x1b8]
  1533a0:      	str	x8, [sp, #0x20]
  1533a4:      	ldr	x10, [sp, #0x38]
  1533a8:      	str	x10, [x8, x9, lsl #3]
  1533ac:      	add	x9, x9, #0x1
  1533b0:      	str	x9, [sp, #0x1c0]
  1533b4:      	ldp	x23, x8, [x19, #0x68]
  1533b8:      	cmp	x8, x23
  1533bc:      	b.hs	0x1533f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbf0>
  1533c0:      	mov	x12, x9
  1533c4:      	ldr	x9, [x19, #0x60]
  1533c8:      	ldrb	w10, [x9, x8]
  1533cc:      	cmp	w10, #0x20
  1533d0:      	b.hi	0x1533f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbec>
  1533d4:      	lsr	x10, x25, x10
  1533d8:      	tbz	w10, #0x0, 0x1533f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbec>
  1533dc:      	add	x8, x8, #0x1
  1533e0:      	str	x8, [x19, #0x70]
  1533e4:      	cmp	x23, x8
  1533e8:      	b.ne	0x1533c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbc4>
  1533ec:      	b	0x153640 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe3c>
  1533f0:      	mov	x9, x12
  1533f4:      	cmp	x8, x23
  1533f8:      	b.hs	0x153640 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe3c>
  1533fc:      	str	x9, [sp, #0x30]
  153400:      	ldr	x9, [x19, #0x60]
  153404:      	ldrb	w9, [x9, x8]
  153408:      	cmp	w9, #0x2c
  15340c:      	b.ne	0x153640 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe3c>
  153410:      	add	x28, x8, #0x1
  153414:      	str	x28, [x19, #0x70]
  153418:      	cmp	x24, #0x1
  15341c:      	ldr	x24, [sp, #0xa8]
  153420:      	ldr	w8, [sp, #0x98]
  153424:      	b.lt	0x1529c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1bc>
  153428:      	ldr	x0, [sp, #0x40]
  15342c:      	mov	x23, x11
  153430:      	bl	0x153430 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc2c>
  153434:      	mov	x11, x23
  153438:      	ldr	w8, [sp, #0x98]
  15343c:      	ldp	x23, x28, [x19, #0x68]
  153440:      	b	0x1529c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1bc>
  153444:      	add	x0, sp, #0x198
  153448:      	bl	0x153448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc44>
  15344c:      	b	0x152ee4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x6e0>
  153450:      	add	x8, sp, #0x198
  153454:      	add	x0, x8, #0x18
  153458:      	bl	0x153458 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc54>
  15345c:      	b	0x152f04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x700>
  153460:      	mov	x10, x28
  153464:      	ldr	x0, [sp, #0xa8]
  153468:      	ldr	x9, [sp, #0x30]
  15346c:      	b	0x152c4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x448>
  153470:      	add	x0, sp, #0x198
  153474:      	str	w11, [sp, #0x48]
  153478:      	bl	0x153478 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc74>
  15347c:      	ldr	w11, [sp, #0x48]
  153480:      	ldr	x10, [sp, #0x1a0]
  153484:      	ldr	x9, [sp, #0x1c0]
  153488:      	str	x23, [x10, x28, lsl #3]
  15348c:      	add	x8, x28, #0x1
  153490:      	str	x8, [sp, #0x1a8]
  153494:      	ldr	x8, [sp, #0x1b0]
  153498:      	cmp	x9, x8
  15349c:      	b.ne	0x15339c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb98>
  1534a0:      	add	x8, sp, #0x198
  1534a4:      	add	x0, x8, #0x18
  1534a8:      	mov	x23, x11
  1534ac:      	mov	x28, x9
  1534b0:      	bl	0x1534b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcac>
  1534b4:      	mov	x9, x28
  1534b8:      	mov	x11, x23
  1534bc:      	b	0x15339c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb98>
  1534c0:      	strb	wzr, [x19, #0xd4]
  1534c4:      	ldr	w26, [sp, #0x9c]
  1534c8:      	cmp	x24, #0x1
  1534cc:      	b.lt	0x1534d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcd4>
  1534d0:      	mov	x0, x23
  1534d4:      	bl	0x1534d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcd0>
  1534d8:      	ldr	x21, [sp, #0xa8]
  1534dc:      	ldp	x9, x8, [x19, #0x68]
  1534e0:      	cmp	x8, x9
  1534e4:      	b.hs	0x153664 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe60>
  1534e8:      	ldr	x10, [x19, #0x60]
  1534ec:      	mov	x11, #0x2600            ; =9728
  1534f0:      	movk	x11, #0x1, lsl #32
  1534f4:      	ldrb	w12, [x10, x8]
  1534f8:      	cmp	w12, #0x20
  1534fc:      	b.hi	0x15351c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xd18>
  153500:      	lsr	x13, x11, x12
  153504:      	tbz	w13, #0x0, 0x15351c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xd18>
  153508:      	add	x8, x8, #0x1
  15350c:      	str	x8, [x19, #0x70]
  153510:      	cmp	x9, x8
  153514:      	b.ne	0x1534f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcf0>
  153518:      	b	0x153664 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe60>
  15351c:      	cmp	w12, #0x7d
  153520:      	b.ne	0x153664 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe60>
  153524:      	add	x8, x8, #0x1
  153528:      	str	x8, [x19, #0x70]
  15352c:      	ldr	x8, [sp, #0x198]
  153530:      	cmn	x8, #0x1
  153534:      	b.ne	0x153674 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe70>
  153538:      	ldr	w8, [sp, #0x98]
  15353c:      	and	w8, w26, w8
  153540:      	tbz	w8, #0x0, 0x153574 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xd70>
  153544:      	ldr	x8, [sp, #0x90]
  153548:      	cmp	x22, x8
  15354c:      	b.ne	0x153574 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xd70>
  153550:      	cmp	x21, x22
  153554:      	b.ne	0x153574 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xd70>
  153558:      	ldr	x22, [sp, #0xa0]
  15355c:      	cmp	x22, #0x9
  153560:      	ldr	w2, [sp, #0x84]
  153564:      	ldr	x21, [sp, #0x78]
  153568:      	b.hs	0x1536e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xee4>
  15356c:      	add	x3, sp, #0x158
  153570:      	b	0x15371c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf18>
  153574:      	ldr	x22, [sp, #0xa0]
  153578:      	cmp	x22, #0x9
  15357c:      	b.hs	0x1539b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11b0>
  153580:      	ldr	x8, [x19, #0x78]
  153584:      	cmp	x22, x8
  153588:      	b.ne	0x1535a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
  15358c:      	ldr	x21, [x19, #0xc0]
  153590:      	cbz	x21, 0x1535a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
  153594:      	cbz	x22, 0x153800 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
  153598:      	ldr	x8, [x19, #0x80]
  15359c:      	ldr	x9, [sp, #0x110]
  1535a0:      	cmp	x8, x9
  1535a4:      	b.eq	0x1537f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xff4>
  1535a8:      	add	x0, sp, #0x110
  1535ac:      	mov	x1, x22
  1535b0:      	bl	0x1535b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xdac>
  1535b4:      	mov	x21, x0
  1535b8:      	mov	x23, x1
  1535bc:      	str	x22, [x19, #0x78]
  1535c0:      	lsl	x2, x22, #3
  1535c4:      	add	x0, x19, #0x80
  1535c8:      	add	x1, sp, #0x110
  1535cc:      	bl	0x1535cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xdc8>
  1535d0:      	mov	x2, x23
  1535d4:      	str	x21, [x19, #0xc0]
  1535d8:      	str	w23, [x19, #0xd0]
  1535dc:      	add	x3, sp, #0x158
  1535e0:      	b	0x15371c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf18>
  1535e4:      	b	0x1528e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe0>
  1535e8:      	sub	x0, x29, #0x68
  1535ec:      	mov	x1, #0x0                ; =0
  1535f0:      	bl	0x1535f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xdec>
  1535f4:      	mov	x2, x1
  1535f8:      	mov	x1, x0
  1535fc:      	str	xzr, [x19, #0x78]
  153600:      	str	x0, [x19, #0xc0]
  153604:      	str	w2, [x19, #0xd0]
  153608:      	add	x0, x19, #0x20
  15360c:      	mov	w3, #0x8                ; =8
  153610:      	mov	x4, #0x0                ; =0
  153614:      	bl	0x153614 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe10>
  153618:      	mov	x19, x0
  15361c:      	ldrb	w8, [x20, #0x20]
  153620:      	cbnz	w8, 0x1539cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11c8>
  153624:      	ldr	x8, [x20]
  153628:      	cbnz	x8, 0x153a10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x120c>
  15362c:      	ldr	x8, [x20, #0x18]
  153630:      	cmp	x27, x8
  153634:      	b.hi	0x1537b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfb4>
  153638:      	str	x27, [x20, #0x18]
  15363c:      	b	0x1537b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfb4>
  153640:      	ldr	x23, [sp, #0x40]
  153644:      	cmp	x24, #0x1
  153648:      	b.ge	0x1534d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xccc>
  15364c:      	b	0x1534d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcd4>
  153650:      	ldr	x21, [sp, #0xa8]
  153654:      	ldr	w26, [sp, #0x9c]
  153658:      	ldp	x9, x8, [x19, #0x68]
  15365c:      	cmp	x8, x9
  153660:      	b.lo	0x1534e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xce4>
  153664:      	strb	wzr, [x19, #0xd4]
  153668:      	ldr	x8, [sp, #0x198]
  15366c:      	cmn	x8, #0x1
  153670:      	b.eq	0x153538 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xd34>
  153674:      	ldp	x0, x1, [sp, #0x1a0]
  153678:      	cmp	x1, #0x9
  15367c:      	b.hs	0x153700 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xefc>
  153680:      	ldr	x8, [x19, #0x78]
  153684:      	cmp	x1, x8
  153688:      	ldr	x22, [sp, #0xa0]
  15368c:      	b.ne	0x1536ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
  153690:      	ldr	x21, [x19, #0xc0]
  153694:      	cbz	x21, 0x1536ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
  153698:      	cbz	x1, 0x1537e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
  15369c:      	ldr	x8, [x19, #0x80]
  1536a0:      	ldr	x9, [x0]
  1536a4:      	cmp	x8, x9
  1536a8:      	b.eq	0x1537e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfdc>
  1536ac:      	mov	x24, x0
  1536b0:      	mov	x25, x1
  1536b4:      	bl	0x1536b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xeb0>
  1536b8:      	mov	x21, x0
  1536bc:      	mov	x23, x1
  1536c0:      	str	x25, [x19, #0x78]
  1536c4:      	lsl	x2, x25, #3
  1536c8:      	add	x0, x19, #0x80
  1536cc:      	mov	x1, x24
  1536d0:      	bl	0x1536d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xecc>
  1536d4:      	mov	x2, x23
  1536d8:      	str	x21, [x19, #0xc0]
  1536dc:      	str	w23, [x19, #0xd0]
  1536e0:      	cmp	x22, #0x9
  1536e4:      	b.lo	0x153718 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf14>
  1536e8:      	adrp	x3, 0x153000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7fc>
  1536ec:      	add	x3, x3, #0x0
  1536f0:      	mov	x0, #0x0                ; =0
  1536f4:      	mov	x1, x22
  1536f8:      	mov	w2, #0x8                ; =8
  1536fc:      	bl	0x1536fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xef8>
  153700:      	bl	0x153700 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xefc>
  153704:      	mov	x21, x0
  153708:      	mov	x2, x1
  15370c:      	ldr	x22, [sp, #0xa0]
  153710:      	cmp	x22, #0x9
  153714:      	b.hs	0x1536e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xee4>
  153718:      	ldp	x3, x22, [sp, #0x1b8]
  15371c:      	add	x0, x19, #0x20
  153720:      	mov	x1, x21
  153724:      	mov	x4, x22
  153728:      	bl	0x153728 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf24>
  15372c:      	mov	x19, x0
  153730:      	ldrb	w8, [x20, #0x20]
  153734:      	cbnz	w8, 0x15398c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1188>
  153738:      	ldr	x8, [x20]
  15373c:      	cbnz	x8, 0x153a10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x120c>
  153740:      	ldr	x8, [x20, #0x18]
  153744:      	cmp	x27, x8
  153748:      	b.hi	0x153750 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf4c>
  15374c:      	str	x27, [x20, #0x18]
  153750:      	ldr	x8, [sp, #0x198]
  153754:      	cmn	x8, #0x1
  153758:      	b.eq	0x1537b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfb4>
  15375c:      	cbz	x8, 0x153768 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf64>
  153760:      	ldr	x0, [sp, #0x1a0]
  153764:      	bl	0x153764 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf60>
  153768:      	ldr	x8, [sp, #0x1b0]
  15376c:      	cbz	x8, 0x153778 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf74>
  153770:      	ldr	x0, [sp, #0x1b8]
  153774:      	bl	0x153774 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf70>
  153778:      	ldr	x20, [sp, #0x1c8]
  15377c:      	cmn	x20, #0x1
  153780:      	b.eq	0x1537b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfb4>
  153784:      	ldr	x9, [sp, #0x1e8]
  153788:      	cbz	x9, 0x1537ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfa8>
  15378c:      	lsl	x8, x9, #4
  153790:      	add	x9, x8, x9
  153794:      	cmn	x9, #0x19
  153798:      	b.eq	0x1537ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfa8>
  15379c:      	ldr	x9, [sp, #0x1e0]
  1537a0:      	sub	x8, x9, x8
  1537a4:      	sub	x0, x8, #0x10
  1537a8:      	bl	0x1537a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfa4>
  1537ac:      	cbz	x20, 0x1537b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfb4>
  1537b0:      	ldr	x0, [sp, #0x1d0]
  1537b4:      	bl	0x1537b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfb0>
  1537b8:      	mov	x0, #0x7ffd000000000000 ; =9222527611924643840
  1537bc:      	bfxil	x0, x19, #0, #48
  1537c0:      	add	sp, sp, #0x250
  1537c4:      	ldp	x29, x30, [sp, #0x50]
  1537c8:      	ldp	x20, x19, [sp, #0x40]
  1537cc:      	ldp	x22, x21, [sp, #0x30]
  1537d0:      	ldp	x24, x23, [sp, #0x20]
  1537d4:      	ldp	x26, x25, [sp, #0x10]
  1537d8:      	ldp	x28, x27, [sp], #0x60
  1537dc:      	ret
  1537e0:      	cmp	x1, #0x1
  1537e4:      	b.ne	0x15380c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1008>
  1537e8:      	ldr	w2, [x19, #0xd0]
  1537ec:      	cmp	x22, #0x9
  1537f0:      	b.lo	0x153718 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf14>
  1537f4:      	b	0x1536e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xee4>
  1537f8:      	cmp	x22, #0x1
  1537fc:      	b.ne	0x1538b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x10ac>
  153800:      	ldr	w2, [x19, #0xd0]
  153804:      	add	x3, sp, #0x158
  153808:      	b	0x15371c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf18>
  15380c:      	ldr	x8, [x19, #0x88]
  153810:      	ldr	x9, [x0, #0x8]
  153814:      	cmp	x8, x9
  153818:      	b.ne	0x1536ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
  15381c:      	cmp	x1, #0x2
  153820:      	b.eq	0x1537e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
  153824:      	ldr	x8, [x19, #0x90]
  153828:      	ldr	x9, [x0, #0x10]
  15382c:      	cmp	x8, x9
  153830:      	b.ne	0x1536ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
  153834:      	cmp	x1, #0x3
  153838:      	b.eq	0x1537e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
  15383c:      	ldr	x8, [x19, #0x98]
  153840:      	ldr	x9, [x0, #0x18]
  153844:      	cmp	x8, x9
  153848:      	b.ne	0x1536ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
  15384c:      	cmp	x1, #0x4
  153850:      	b.eq	0x1537e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
  153854:      	ldr	x8, [x19, #0xa0]
  153858:      	ldr	x9, [x0, #0x20]
  15385c:      	cmp	x8, x9
  153860:      	b.ne	0x1536ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
  153864:      	cmp	x1, #0x5
  153868:      	b.eq	0x1537e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
  15386c:      	ldr	x8, [x19, #0xa8]
  153870:      	ldr	x9, [x0, #0x28]
  153874:      	cmp	x8, x9
  153878:      	b.ne	0x1536ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
  15387c:      	cmp	x1, #0x6
  153880:      	b.eq	0x1537e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
  153884:      	ldr	x8, [x19, #0xb0]
  153888:      	ldr	x9, [x0, #0x30]
  15388c:      	cmp	x8, x9
  153890:      	b.ne	0x1536ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
  153894:      	cmp	x1, #0x7
  153898:      	b.eq	0x1537e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
  15389c:      	ldr	x8, [x19, #0xb8]
  1538a0:      	ldr	x9, [x0, #0x38]
  1538a4:      	cmp	x8, x9
  1538a8:      	b.ne	0x1536ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
  1538ac:      	b	0x1537e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
  1538b0:      	ldr	x8, [x19, #0x88]
  1538b4:      	ldr	x9, [sp, #0x118]
  1538b8:      	cmp	x8, x9
  1538bc:      	b.ne	0x1535a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
  1538c0:      	cmp	x22, #0x2
  1538c4:      	b.eq	0x153800 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
  1538c8:      	ldr	x8, [x19, #0x90]
  1538cc:      	ldr	x9, [sp, #0x120]
  1538d0:      	cmp	x8, x9
  1538d4:      	b.ne	0x1535a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
  1538d8:      	cmp	x22, #0x3
  1538dc:      	b.eq	0x153800 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
  1538e0:      	ldr	x8, [x19, #0x98]
  1538e4:      	ldr	x9, [sp, #0x128]
  1538e8:      	cmp	x8, x9
  1538ec:      	b.ne	0x1535a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
  1538f0:      	cmp	x22, #0x4
  1538f4:      	b.eq	0x153800 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
  1538f8:      	ldr	x8, [x19, #0xa0]
  1538fc:      	ldr	x9, [sp, #0x130]
  153900:      	cmp	x8, x9
  153904:      	b.ne	0x1535a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
  153908:      	cmp	x22, #0x5
  15390c:      	b.eq	0x153800 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
  153910:      	ldr	x8, [x19, #0xa8]
  153914:      	ldr	x9, [sp, #0x138]
  153918:      	cmp	x8, x9
  15391c:      	b.ne	0x1535a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
  153920:      	cmp	x22, #0x6
  153924:      	b.eq	0x153800 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
  153928:      	ldr	x8, [x19, #0xb0]
  15392c:      	ldr	x9, [sp, #0x140]
  153930:      	cmp	x8, x9
  153934:      	b.ne	0x1535a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
  153938:      	cmp	x22, #0x7
  15393c:      	b.eq	0x153800 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
  153940:      	ldr	x8, [x19, #0xb8]
  153944:      	ldr	x9, [sp, #0x148]
  153948:      	cmp	x8, x9
  15394c:      	b.ne	0x1535a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
  153950:      	b	0x153800 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
  153954:      	cmp	w8, #0x1
  153958:      	b.ne	0x1539d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11d0>
  15395c:      	adrp	x1, 0x153000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7fc>
  153960:      	add	x1, x1, #0x0
  153964:      	mov	x0, x20
  153968:      	bl	0x153968 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1164>
  15396c:      	strb	wzr, [x20, #0x20]
  153970:      	ldr	x8, [x20]
  153974:      	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
  153978:      	cmp	x8, x9
  15397c:      	b.lo	0x152914 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x110>
  153980:      	adrp	x0, 0x153000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7fc>
  153984:      	add	x0, x0, #0x0
  153988:      	bl	0x153988 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1184>
  15398c:      	cmp	w8, #0x2
  153990:      	b.eq	0x1539d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11d0>
  153994:      	adrp	x1, 0x153000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7fc>
  153998:      	add	x1, x1, #0x0
  15399c:      	mov	x0, x20
  1539a0:      	bl	0x1539a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x119c>
  1539a4:      	strb	wzr, [x20, #0x20]
  1539a8:      	ldr	x8, [x20]
  1539ac:      	cbz	x8, 0x153740 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf3c>
  1539b0:      	b	0x153a10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x120c>
  1539b4:      	adrp	x3, 0x153000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7fc>
  1539b8:      	add	x3, x3, #0x0
  1539bc:      	mov	x0, #0x0                ; =0
  1539c0:      	mov	x1, x22
  1539c4:      	mov	w2, #0x8                ; =8
  1539c8:      	bl	0x1539c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11c4>
  1539cc:      	cmp	w8, #0x2
  1539d0:      	b.ne	0x1539f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11f0>
  1539d4:      	adrp	x0, 0x153000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7fc>
  1539d8:      	add	x0, x0, #0x0
  1539dc:      	bl	0x1539dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11d8>
  1539e0:      	adrp	x3, 0x153000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7fc>
  1539e4:      	add	x3, x3, #0x0
  1539e8:      	mov	x0, #0x0                ; =0
  1539ec:      	mov	w2, #0x8                ; =8
  1539f0:      	bl	0x1539f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11ec>
  1539f4:      	adrp	x1, 0x153000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7fc>
  1539f8:      	add	x1, x1, #0x0
  1539fc:      	mov	x0, x20
  153a00:      	bl	0x153a00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11fc>
  153a04:      	strb	wzr, [x20, #0x20]
  153a08:      	ldr	x8, [x20]
  153a0c:      	cbz	x8, 0x15362c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe28>
  153a10:      	adrp	x0, 0x153000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7fc>
  153a14:      	add	x0, x0, #0x0
  153a18:      	bl	0x153a18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1214>
  153a1c:      	adrp	x0, 0x153000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7fc>
  153a20:      	add	x0, x0, #0x0
  153a24:      	bl	0x153a24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1220>
  153a28:      	adrp	x2, 0x153000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7fc>
  153a2c:      	add	x2, x2, #0x0
  153a30:      	mov	x0, x24
  153a34:      	mov	w1, #0x8                ; =8
  153a38:      	bl	0x153a38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1234>
  153a3c:      	adrp	x2, 0x153000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7fc>
  153a40:      	add	x2, x2, #0x0
  153a44:      	mov	x0, x1
  153a48:      	mov	x1, x9
  153a4c:      	bl	0x153a4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1248>
  153a50:      	adrp	x2, 0x153000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7fc>
  153a54:      	add	x2, x2, #0x0
  153a58:      	mov	x1, x9
  153a5c:      	bl	0x153a5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1258>
  153a60:      	adrp	x2, 0x153000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7fc>
  153a64:      	add	x2, x2, #0x0
  153a68:      	mov	w1, #0x8                ; =8
  153a6c:      	bl	0x153a6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1268>
  153a70:      	adrp	x2, 0x153000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7fc>
  153a74:      	add	x2, x2, #0x0
  153a78:      	mov	w1, #0x8                ; =8
  153a7c:      	bl	0x153a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1278>
  153a80:      	mov	w0, #0x8                ; =8
  153a84:      	mov	w1, #0x80               ; =128
  153a88:      	bl	0x153a88 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1284>

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.perry_runtime.51e3211f3b89fd3b-cgu.0.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.phf-fda76137c618ed94.phf.e4e92736a1df7d19-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.phf_shared-a99412ae5fa8df63.phf_shared.d4b5e8e0605a820e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.pin_project_lite-9112ff0b4ca4c5f5.pin_project_lite.9e3a833d7736b09d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.portable_atomic-ee537db1fe67f1f1.portable_atomic.3d3e8745d3fefd81-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.potential_utf-7290d80b7d4fd7a6.potential_utf.3d03ee8112fd1596-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.prefix_trie-40e0fdfa96a3a51b.prefix_trie.aa2676338b217d25-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.psm-9f3b8da3ad16e1fa.psm.78bcf4d21b57561-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rand-492323155da95b1d.rand.6529a7c3eb82dfd6-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rand_core-6bacf6ecfee8446a.rand_core.fec9fb7b016054b8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.regex-23a1744e34a6bdd8.regex.5fe00e4da3593f57-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.regex_automata-05498c6e8207064c.regex_automata.2113017827263087-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.regex_syntax-dc078710f3e283e5.regex_syntax.5d77536cdc21bec2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.regress-4af654b3baeba21a.regress.56c9efe3abfd7dd9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.resolv_conf-589bb5b300ae9b62.resolv_conf.ef8ce2570ae6b7ca-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_demangle-a0db1312f42a1e44.rustc_demangle.e8c1817fde257fa-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_demangle-a84069e27028b871.rustc_demangle.6e498b991fca6ce6-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_hash-6acac617e2694d16.rustc_hash.8dd8e3d9c15ad472-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_std_workspace_alloc-5b4356182ec17e27.rustc_std_workspace_alloc.95a6ecb1e2b64b16-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.rustc_std_workspace_core-91fae2e614e9d003.rustc_std_workspace_core.5c33cd8176fbdf03-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ryu-88f4114cfee0f920.ryu.e5b11607222e9f1-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.ryu_js-8203fc1e86d8300b.ryu_js.38024f8f2b58d396-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.scoped_tls-bea296576cbd4055.scoped_tls.4868881ed73f4220-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.scopeguard-3f34b2f52778ed6d.scopeguard.39c46ee7c3ff5c3a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.serde-b1698c4db99cd0f6.serde.ace619f76592a163-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.serde_core-7feea810e2b7e669.serde_core.91e6c9d28410876e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.serde_json-5f6cce1ec0bc1f51.serde_json.1881800b546529cc-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.serde_spanned-786a63d1fb99443c.serde_spanned.ecff9bd5fc6ed1cd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.signal_hook_registry-73f406794e9b58b9.signal_hook_registry.a304ee316af8aaf-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.simdutf8-6eaa160c64d9f76b.simdutf8.5e602d216e3b60b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.siphasher-3f0a76aeabf470da.siphasher.5dc93b2dddb35ff3-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.siphasher-a84eeb1952cd7c96.siphasher.63b0bb3e10f5fb09-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.slab-ce3c7619cdf98849.slab.4197f6b653c95390-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.slotmap-20ea319e01e10a36.slotmap.7f53c3097a475db5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.smallvec-0e7d453b7999d6bf.smallvec.a3fac2ce2795659-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.smartstring-dc627c0149b34430.smartstring.daa138bdd471414-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.socket2-c0fc5e20d9815054.socket2.325daa4db95003be-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.spin-419ef0217c1a7e9d.spin.124ce9ff3747f4d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.spki-68668ef35563db08.spki.dcea16c81f3faeb7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.stable_deref_trait-d05f845ec581f3c3.stable_deref_trait.20e7280df43487a4-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.stacker-e8215abced14b595.stacker.a64d36231c9b54e8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.static_assertions-26a67eb00cbe4a19.static_assertions.d246fd1a619c5f56-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.std-36f377630a6d9041.std.6435e32e5249d112-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.std_detect-4733c791661234cb.std_detect.19bab4874ad71232-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_atoms-920e18ec1ca531dc.swc_atoms.6e099e31e61309c3-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_common-d6bd2bc4e58d990f.swc_common.8fdf2470d9cfdc5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_ecma_ast-84ea4ee5ba95db2e.swc_ecma_ast.3d8d12e8f84f649c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_ecma_parser-8ec30cfb0eaf253d.swc_ecma_parser.bc422679edde26a7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_ecma_visit-b63461394357b0d4.swc_ecma_visit.c99e8944d3846bc7-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.swc_visit-64ac6e1c9cb7923d.swc_visit.2ab765cb666f8899-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.taffy-fe5c9a8e7c25c5f0.taffy.d86dff334662a800-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.temporal_rs-0fb585091cfff93a.temporal_rs.615be7171f19ae8f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.thiserror-1959f5c5ef95f8e0.thiserror.66a9b0aa6ac5659c-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.thiserror-819934ff4cff447d.thiserror.262fe98a9286a6f8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.timezone_provider-734aa3cb276ec3ef.timezone_provider.c5d1d9aad8d3988f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tinystr-7460fd70af50815a.tinystr.f12ac1933cb9ba2b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tinyvec-747e19215a97d544.tinyvec.c739c1e068ab99ed-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tinyvec_macros-03c0b3b0828d119a.tinyvec_macros.a5317fef04132c16-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tokio-c09ace7016a21111.tokio.10f85077cf846efc-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tokio_util-b3b32b3e68ae174b.tokio_util.c2188b63290972ae-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.toml-e1d9f60e2a93edf6.toml.69efb9df2f8e67b3-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.toml_datetime-da06043cbfd6a3ff.toml_datetime.eed1431b100c0ba5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.toml_parser-a8ea5ac599f8d731.toml_parser.4dda3eb99405abdd-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.toml_writer-86392e121e73ea49.toml_writer.612da603a2a255c9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tracing-1e99833042e023d4.tracing.480a63e3c00ffe5d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tracing_core-a4ce5df32b216be5.tracing_core.551518ce0c3162f-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.triomphe-1f26ad013b2edc2b.triomphe.df0393428d78f2d2-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.tzif-f601d4f6882f6c91.tzif.4b87cacab3be6a39-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_id_start-b1b648fdc7033911.unicode_id_start.b451d75f4870a19-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_normalization-74312452efd83ea5.unicode_normalization.a9dba2d72fcfb0e9-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_segmentation-9d17b5f253060a33.unicode_segmentation.418ba6cb19b4b691-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_width-9091f55f45a06a5b.unicode_width.2046f0e93b598eee-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unicode_width-eefe794da3ddc491.unicode_width.81acccf54ab200a6-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unsafe_libyaml-6fc9986bea6e83a2.unsafe_libyaml.498c10ddae7016fa-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.unwind-b34336196694d849.unwind.84a5a803a0d3b8e5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.url-937de9168f16e023.url.1a3dafb8678c931d-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.utf8_iter-495f179a61b481d6.utf8_iter.c6d05cdf24642122-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.winnow-19e99833af0373f3.winnow.82b0bb40063afce5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.writeable-590fc088fec40648.writeable.5b4332e450c8b833-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.x509_cert-23c04dad6503524d.x509_cert.a1cd03d282d34aa8-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.xxhash_rust-aca16904554a0e24.xxhash_rust.80a8560132cdda1a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.yoke-344345244b6e4947.yoke.e19373a6f771978b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zerocopy-99f7f8d1743ab073.zerocopy.c4d7aea3b77dbe79-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zerofrom-316567aba73be1b3.zerofrom.895504131b58bc4e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zeroize-c6a7916c40321e93.zeroize.9524028ebbc3b95a-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zerotrie-5524f4e315dcaf36.zerotrie.47410e50260eb1e0-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zerovec-8f5cd301f36e965a.zerovec.9ea12157016434b1-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zmij-8f9e3f41857f0483.zmij.180143115354781b-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zstd-2da8f76fd714c069.zstd.f736b1e5325616ef-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zstd_safe-e368634d5a7f6151.zstd_safe.828b5cf371cee27e-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(perry_runtime-3fdc211decb56e70.zstd_sys-959dee5ed6b0497e.zstd_sys.67acef213add5ee5-cgu.0.rcgu.o.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f17b5a9852f781a4-perry_sjlj.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-debug.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-entropy_common.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-error_private.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-fse_decompress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-pool.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-threading.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(44ff4c55aa9e5133-zstd_common.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-fse_compress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-hist.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-huf_compress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_compress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_compress_literals.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_compress_sequences.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_compress_superblock.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_double_fast.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_fast.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_lazy.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_ldm.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_opt.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstd_preSplit.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(fb80479a5fb81f6a-zstdmt_compress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(88f362f13b0528ed-huf_decompress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(88f362f13b0528ed-zstd_ddict.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(88f362f13b0528ed-zstd_decompress.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(88f362f13b0528ed-zstd_decompress_block.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(a6c81c75fc82913a-cover.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(a6c81c75fc82913a-divsufsort.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(a6c81c75fc82913a-fastcover.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(a6c81c75fc82913a-zdict.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v01.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v02.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v03.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v04.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v05.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v06.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(3f451b2306bc13c8-zstd_v07.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(7faed3f8272f2313-huf_decompress_amd64.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(b85de32113adef8e-static.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(4f9a91766097c4c5-aarch_aapcs64.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.000.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.001.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.002.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.003.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.004.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.005.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.006.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.007.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.008.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.009.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.010.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.011.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.012.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.013.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.014.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.015.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.016.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.017.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.018.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.019.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.020.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.021.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.022.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.023.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.024.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.025.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.026.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.027.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.028.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.029.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.030.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.031.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.032.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.033.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.034.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.035.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.036.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.037.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.038.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.039.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.040.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.041.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.042.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.043.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.044.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.045.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.046.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.047.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.048.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.049.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.050.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.051.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.052.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.053.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.054.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.055.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.056.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.057.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.058.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.059.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.060.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.061.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.062.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.063.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.064.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.065.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.066.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.067.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.068.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.069.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.070.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.071.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.072.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.073.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.074.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.075.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.076.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.077.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.078.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.079.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.080.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.081.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.082.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.083.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.084.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.085.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.086.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.087.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.088.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.089.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.090.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.091.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.092.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.093.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.094.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.095.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.096.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.097.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.098.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.099.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.100.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.101.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.102.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.103.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.104.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.105.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.106.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.107.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.108.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.109.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.110.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.111.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.112.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.113.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.114.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.115.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.116.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.117.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.118.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.119.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.120.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.121.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.122.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.123.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.124.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.125.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.126.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.127.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.128.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.129.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.130.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.131.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.132.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.133.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.134.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.135.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.136.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.137.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.138.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.139.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.140.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.141.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.142.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.143.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.144.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.145.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.146.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.147.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.148.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.149.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.150.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.151.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.152.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.153.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.154.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.155.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.156.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.157.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.158.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.159.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.160.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.161.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.162.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.163.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.164.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.165.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.166.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.167.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.168.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.169.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.170.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.171.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.172.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.173.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.174.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.175.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.176.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.177.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.178.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.179.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.180.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.181.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.182.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.183.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.184.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.185.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.186.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.187.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.188.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.189.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.190.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.191.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.192.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.193.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.194.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.195.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.196.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.197.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.198.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.199.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.200.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.201.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.202.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.203.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.204.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.205.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.206.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.207.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.208.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.209.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.210.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.211.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.212.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.213.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.214.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.215.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.216.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.217.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.218.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.219.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.220.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.221.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.222.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.223.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.224.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.225.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.226.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.227.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(compiler_builtins-cb40d0ec13be7830.compiler_builtins.6a4fe7a6098875a5-cgu.228.rcgu.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas1_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas1_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas1_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas1_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas2_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas2_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas2_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas2_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas4_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas4_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas4_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas4_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas8_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas8_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas8_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas8_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas16_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas16_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas16_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_cas16_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp1_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp1_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp1_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp1_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp2_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp2_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp2_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp2_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp4_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp4_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp4_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp4_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp8_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp8_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp8_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_swp8_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd1_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd1_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd1_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd1_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd2_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd2_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd2_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd2_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd4_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd4_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd4_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd4_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd8_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd8_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd8_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldadd8_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr1_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr1_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr1_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr1_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr2_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr2_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr2_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr2_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr4_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr4_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr4_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr4_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr8_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr8_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr8_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldclr8_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor1_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor1_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor1_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor1_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor2_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor2_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor2_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor2_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor4_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor4_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor4_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor4_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor8_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor8_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor8_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldeor8_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset1_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset1_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset1_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset1_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset2_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset2_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset2_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset2_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset4_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset4_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset4_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset4_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset8_relax.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset8_acq.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset8_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(0c1e52134db5f7fe-lse_ldset8_acq_rel.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(ad3ac4dcdcbf93cb-aarch64.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-absvdi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-absvsi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-absvti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-addvdi3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-addvsi3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-addvti3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-cmpdi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-cmpti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-divdc3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-divsc3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-fp_mode.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-ffsti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-int_util.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-muldc3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-mulsc3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-multc3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-mulvdi3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-mulvsi3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-mulvti3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negdf2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negdi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negsf2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negvdi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negvsi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-negvti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-paritydi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-paritysi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-parityti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-popcountdi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-popcountsi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-popcountti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-subvdi3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-subvsi3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-subvti3.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-ucmpdi2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-ucmpti2.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_flag_clear.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_flag_clear_explicit.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_flag_test_and_set.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_flag_test_and_set_explicit.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_signal_fence.o):	file format mach-o arm64

benchmarks/json_performance/.work/outlined-object-parser-r42/frozen-build/libperry_runtime.a(f3c5cc7ab326d4d0-atomic_thread_fence.o):	file format mach-o arm64
